#!/bin/bash

ps -ef | grep /app/smartseco/back/datasync/out-datasync-1.0.0.jar | grep -v grep | awk '{print $2}' | xargs kill -9