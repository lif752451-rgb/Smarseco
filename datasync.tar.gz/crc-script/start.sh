#!/bin/bash

cd /app/smartseco/back/datasync
nohup java -XX:+UseG1GC -Xms2048m -Xmx2048m  -Dloader.path=/app/smartseco/back/datasync/lib -jar /app/smartseco/back/datasync/out-datasync-1.0.0.jar --spring.config.location=/app/smartseco/back/datasync/config/ --logging.config=/app/smartseco/back/datasync/config/log4j2.xml &