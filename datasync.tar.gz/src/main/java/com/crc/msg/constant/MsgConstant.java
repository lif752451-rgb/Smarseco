package com.crc.msg.constant;

/**
 * 消息发送常量类
 *
 * @Author fuzhuangzhi
 * @Date 2023/2/13 14:46
 * @Version 1.0
 **/
public class MsgConstant {

    /**
     * 漏洞复查发送企业微信消息
     */
    public static final String QYVX_MSG_TEXT = "您于%s下发的复查任务（IP：%s，%s）已完成，其中，新增漏洞 %d 个，已修复漏洞 %d 个，未修复漏洞 %d 个，请前往网络安全管控平台<a href=%s target='_blank'>%s</a>查看。";
}
