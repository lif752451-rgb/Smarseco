package com.crc.msg.dingding;

import com.alibaba.fastjson.JSONObject;
import com.crc.common.utils.DataUtils;
import com.crc.common.utils.DictUtil;
import com.crc.common.utils.JsonUtils;
import com.crc.secface.domain.SysDictData;
import lombok.extern.slf4j.Slf4j;

@Slf4j
public class DingdingConfig {

    /*
    demo:
     {
            "url": "https://oapi.dingtalk.com",
            "appkey": "ww8f378f6acf884ff0",
            "appsecret": "kRyVNBLuwg6MLMVIQLLaqR_d1Bgvr5Hoh9PnZ8v7qSE",
            "agentid": 1000153
        }
     */
    public static JSONObject getConfig() {
        SysDictData dict = DictUtil.getDictByValue("dingding_push_auth", "dingding_push_auth");
        if (DataUtils.isBlankDict(dict)) {
            log.error("未配置企业微信推送参数,在字典,dingding_push_auth/dingding_push_auth【remark】类似：{\"appkey\":\"ww8983c5464774de88\",\n" +
                    "      \"appsecret\":\"pFtQN9BxZr-aa1Hf5caT7Ul2hw1zYVUAfmY0HDNmw58\"\n" +
                    "      \"agentid\":100002}");
            return null;
        }
        return JsonUtils.parse(dict.getRemark());
    }
}
