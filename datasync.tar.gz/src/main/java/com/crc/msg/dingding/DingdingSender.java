package com.crc.msg.dingding;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;
import com.crc.common.utils.HttpUtils;
import com.crc.common.utils.JsonUtils;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;


//查看创建好的应用信息，取得AgentId、AppKey和AppSecret，在API调用时要使用
@Slf4j
public class DingdingSender {

    /**
     * 获取钉钉token
     *
     * @return token
     */
    private static String getToken() {
        try {
            JSONObject jsonObject = DingdingConfig.getConfig();
            if (jsonObject == null) {
                return null;
            }
            String appkey = JsonUtils.getStr(jsonObject, "appkey");
            if (StringUtils.isBlank(appkey)) {
                appkey = JsonUtils.getStr(jsonObject, "appKey");
            }
            String appsecret = JsonUtils.getStr(jsonObject, "appsecret");
            if (StringUtils.isBlank(appsecret)) {
                appsecret = JsonUtils.getStr(jsonObject, "appSecret");
            }
            String url = JsonUtils.getStr(jsonObject, "url");
            if (StringUtils.isBlank(appkey) || StringUtils.isBlank(appsecret) || StringUtils.isBlank(url)) {
                log.error("配置错误：{}", JSON.toJSONString(jsonObject));
                return null;
            }
            String ret = HttpUtils.sendGet(url + "/gettoken", "appkey=" + appkey + "&appsecret=" + appsecret);
            log.info("获取token返回:" + ret);
            if (StringUtils.isBlank(ret)) {
                return null;
            } else {
                /*
                  {
                    "errcode": 0,
                    "errmsg": "ok",
                    "access_token": "fw8ef8we8f76e6f7s8df8s"
                }
                 */
                JSONObject retJson = JsonUtils.parse(ret);
                return JsonUtils.getStr(retJson, "access_token");
            }
        } catch (Exception e) {
            log.error(e.getMessage(), e);
        }
        return null;
    }

    //
    public static void sendDingDingMsg(String content) {
        try {
            JSONObject jsonObject = DingdingConfig.getConfig();
            if (jsonObject == null) {
                return ;
            }
            String url = JsonUtils.getStr(jsonObject, "url");
            // 钉钉的webhook
            //String dingDingToken="https://oapi.dingtalk.com/robot/send?access_token=0f0daca33m98gn78f00189fe1e1e908b81fa26d0d8ddd48fa78a844cd8636187";
            MessageText message = new MessageText();
            MessageContent messageContent = new MessageContent();
            message.setMsgtype("text");
            messageContent.setContent(content);
            message.setText(messageContent);
            String ret = HttpUtils.sendPost(url, JSON.toJSONString(message));
            log.info("发送消息：" + ret);
        } catch (Exception e) {
            log.error(e.getMessage(), e);
        }
    }
}


