package com.crc.msg.dingding;

import lombok.Data;

/**
 * 文本内容类
 * @author admin
 */
@Data
public class MessageContent {

    /**
     * 文本内容
     */
    private String content;

    public MessageContent() {
    }

    public MessageContent(String content) {
        this.content = content;
    }

}