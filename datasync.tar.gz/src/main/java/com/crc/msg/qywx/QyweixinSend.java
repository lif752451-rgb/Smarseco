package com.crc.msg.qywx;


import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;
import com.crc.common.constants.WeixinUrlConstants;
import com.crc.common.utils.HttpUtils;
import com.crc.common.utils.JsonUtils;
import lombok.Data;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;

import java.io.File;
import java.util.List;

/**
 * 微信对接
 */
@Slf4j
@Data
public class QyweixinSend extends Thread {
    private List<String> userList;
    private String msg;
    private String type;
    private String title;
    private String imgPath;

    public QyweixinSend(String type, List<String> userList, String msg, String title, String imgPath) {
        this.userList = userList;
        this.msg = msg;
        this.type = type;
        this.title = title;
        this.imgPath = imgPath;
    }

    @Override
    public void run() {

        if (userList == null || userList.size() < 1) {
            log.error("没有推送用户ID清单");
            return;
        }
        try {
            if ("text".equalsIgnoreCase(type)) {
                /*
                {
                  "touser": "HeJingSheng",
                  "toparty": "",
                  "totag": "",
                  "msgtype": "text",
                  "agentid": 1000002,
                  "text": {
                    "content": "你的快递已到，请携带工卡前往邮件中心领取。\n出发前可查看<a href=\"http://work.weixin.qq.com\">邮件中心视频实况</a>，聪明避开排队。"
                  },
                  "safe": 0,
                  "enable_id_trans": 0,
                  "enable_duplicate_check": 0
                }
                 */
                JSONObject json = new JSONObject();
                json.put("touser", String.join("|", userList));
                json.put("toparty", "");
                json.put("totag", "");
                json.put("msgtype", "text");
                JSONObject content = new JSONObject();
                content.put("content", msg);
                json.put("text", content);
                json.put("safe", 0);
                json.put("enable_id_trans", 0);
                json.put("agentid", JsonUtils.getInt(QyweixinConfig.getConfig(), "agentid"));
                json.put("enable_duplicate_check", 0);
                batchSend(json.toJSONString());
            } else if ("file".equalsIgnoreCase(type)) {
                /*
                 {
                   "touser" : "UserID1|UserID2|UserID3",
                   "toparty" : " PartyID1|PartyID2 ",
                   "totag" : " TagID1 | TagID2 ",
                   "msgtype" : "file",
                   "agentid" : 1,
                   "file" : {
                        "media_id" : "MEDIA_ID"
                   }
                }
                 */
                File file = new File(msg);
                String mediaId = QyWeixUploadFile.SendFile(file);
                if (StringUtils.isNotBlank(mediaId)) {
                    JSONObject json = new JSONObject();
                    json.put("touser", String.join("|", userList));
                    json.put("toparty", "");
                    json.put("totag", "");
                    json.put("msgtype", "file");
                    JSONObject content = new JSONObject();
                    content.put("media_id", mediaId);
                    json.put("file", content);
                    json.put("safe", 0);
                    json.put("enable_id_trans", 0);
                    json.put("agentid", JsonUtils.getInt(QyweixinConfig.getConfig(), "agentid"));
                    json.put("enable_duplicate_check", 0);
                    batchSend(json.toJSONString());
                } else {
                    log.error("企业微信上传图片失败");
                }
            }
        } catch (Exception e) {
            log.error(e.getMessage(), e);
        }
    }

    public static void batchSend(List<String> userList, String msg, String type) {
        (new QyweixinSend(type, userList, msg, null, null)).start();
    }

    /**
     * 批量发送消息
     */
    public static void batchSend(List<String> userList, String msg) {
        log.info("send#Vx :{},msg:{}", JSON.toJSONString(userList),msg);
        (new QyweixinSend("text", userList, msg, null, null)).start();
    }


    public static void sendFile(List<String> userList, String imgPath) {
        (new QyweixinSend("file", userList, imgPath, null, null)).start();
    }

    private static void batchSend(String Str) {
        JSONObject config = QyweixinConfig.getConfig();
        String token = QywxTokenThread.getToken();
        String url = JsonUtils.getStr(config, "url") + WeixinUrlConstants.QY_SEND_MESSAGE + "?access_token=" + token;
        //发送请求
        try {
            String ret = HttpUtils.sendPost(url, Str);
            JSONObject retJson = JsonUtils.parse(ret);
            if (JsonUtils.equalVal(retJson, "errmsg", "ok")) {
                log.info("发送消息成功,请求参数：" + Str);
            } else {
                log.error("发送失败！URL:{},错误参数：{}，请求返回信息：{}", url, Str, ret);
            }
        } catch (Exception e) {
            log.error("发送企业微信消息错误，URL：{},错误参数：{}", url, Str, e);
        }
    }
}

