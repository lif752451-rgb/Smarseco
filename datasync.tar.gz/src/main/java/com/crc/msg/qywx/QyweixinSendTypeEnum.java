package com.crc.msg.qywx;

import lombok.Getter;

/**
 * 企业微信发送消息类型
 *
 * @Author fuzhuangzhi
 * @Date 2023/2/9 18:25
 * @Version 1.0
 **/
@Getter
public enum QyweixinSendTypeEnum {
    TEXT("text","文本"),
    FILE("file","文件"),
    ;

    private String type;

    private String desc;

    QyweixinSendTypeEnum(String type, String desc) {
        this.type = type;
        this.desc = desc;
    }
}
