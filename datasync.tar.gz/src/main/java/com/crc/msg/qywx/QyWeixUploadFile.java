package com.crc.msg.qywx;


import com.alibaba.fastjson.JSONObject;
import com.crc.common.constants.WeixinUrlConstants;
import com.crc.common.utils.DataUtils;
import com.crc.common.utils.JsonUtils;
import lombok.extern.slf4j.Slf4j;
import org.apache.http.HttpEntity;
import org.apache.http.client.methods.CloseableHttpResponse;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.config.Registry;
import org.apache.http.config.RegistryBuilder;
import org.apache.http.conn.socket.ConnectionSocketFactory;
import org.apache.http.conn.socket.PlainConnectionSocketFactory;
import org.apache.http.conn.ssl.NoopHostnameVerifier;
import org.apache.http.conn.ssl.SSLConnectionSocketFactory;
import org.apache.http.conn.ssl.TrustSelfSignedStrategy;
import org.apache.http.entity.mime.MultipartEntityBuilder;
import org.apache.http.entity.mime.content.FileBody;
import org.apache.http.impl.client.BasicCookieStore;
import org.apache.http.impl.client.CloseableHttpClient;
import org.apache.http.impl.client.HttpClients;
import org.apache.http.impl.conn.PoolingHttpClientConnectionManager;
import org.apache.http.ssl.SSLContextBuilder;
import org.apache.http.util.EntityUtils;

import java.io.File;

@Slf4j
public class QyWeixUploadFile {

    public static CloseableHttpClient getHttpClient() {
        try {
            SSLContextBuilder builder = new SSLContextBuilder();
            builder.loadTrustMaterial(null, new TrustSelfSignedStrategy());
            SSLConnectionSocketFactory sslConnectionSocketFactory = new SSLConnectionSocketFactory(builder.build(),
                    NoopHostnameVerifier.INSTANCE);
            Registry<ConnectionSocketFactory> registry = RegistryBuilder.<ConnectionSocketFactory>create()
                    .register("http", new PlainConnectionSocketFactory())
                    .register("https", sslConnectionSocketFactory)
                    .build();
            PoolingHttpClientConnectionManager cm = new PoolingHttpClientConnectionManager(registry);
            cm.setMaxTotal(100);
            return HttpClients.custom()
                    .setSSLSocketFactory(sslConnectionSocketFactory)
                    .setDefaultCookieStore(new BasicCookieStore())
                    .setConnectionManager(cm).build();
        } catch (Exception e) {
            log.error(e.getMessage(), e);
        }
        return HttpClients.createDefault();
    }

    public static String SendFile(File file) {
        CloseableHttpClient httpClient = null;
        CloseableHttpResponse response = null;
        try {
            httpClient = getHttpClient();
            //?access_token=ACCESS_TOKEN&type=TYPE
            JSONObject config = QyweixinConfig.getConfig();
            HttpPost post = new HttpPost(JsonUtils.getStr(config, "url") + WeixinUrlConstants.WX_UPLOAD_MEDIA);
            final MultipartEntityBuilder builder = MultipartEntityBuilder.create();
            FileBody bin = new FileBody(file);
            builder.addPart("file", bin);
            builder.addTextBody("access_token", QywxTokenThread.getToken());
            builder.addTextBody("type", "file");
            HttpEntity multiPartEntity = builder.build();
            post.setEntity(multiPartEntity);
            response = httpClient.execute(post);
            String retMsg = DataUtils.toBodyString(response.getEntity());
            JSONObject json = JsonUtils.parse(retMsg);
            if ("ok".equalsIgnoreCase(JsonUtils.getStr(json, "errmsg"))) {
                return JsonUtils.getStr(json, "media_id");
            } else {
                log.error("企业微信上传文件失败！");
            }
        } catch (Exception e) {
            log.error(e.getMessage(), e);
        } finally {
            com.crc.common.utils.IOUtils.close(response);
            com.crc.common.utils.IOUtils.close(httpClient);
        }
        return "";
    }
}