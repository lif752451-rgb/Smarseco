package com.crc.msg.qywx;

import com.alibaba.fastjson.JSONObject;
import com.crc.common.constants.WeixinUrlConstants;
import com.crc.common.utils.DictUtil;
import com.crc.common.utils.HttpUtils;
import com.crc.common.utils.JsonUtils;
import com.crc.secface.domain.SysDictData;
import lombok.extern.slf4j.Slf4j;

@Slf4j
public class QyweixinConfig {

    /*
    demo:
     {
            "url": "http://qywx.szmc.net",
            "corpId": "ww8f378f6acf884ff0",
            "corpSecret": "kRyVNBLuwg6MLMVIQLLaqR_d1Bgvr5Hoh9PnZ8v7qSE",
            "agentid": 1000153
        }
     */
    public static JSONObject getConfig() {
        SysDictData dict = DictUtil.getDictByValue("qywx_push_auth", "qywx_push_auth");
        if (dict == null) {
            log.error("未配置企业微信推送参数,在字典,qywx_push_auth/qywx_push_auth【remark】类似：{\"corpId\":\"ww8983c5464774de88\",\n" +
                    "      \"corpSecret\":\"pFtQN9BxZr-aa1Hf5caT7Ul2hw1zYVUAfmY0HDNmw58\"\n" +
                    "      \"agentid\":100002}");
            return null;
        }
        return JsonUtils.parse(dict.getRemark());
    }

    /*
      demo:
       {
              "url": "http://qywx.szmc.net",
              "corpId": "ww8f378f6acf884ff0",
              "corpSecret": "kRyVNBLuwg6MLMVIQLLaqR_d1Bgvr5Hoh9PnZ8v7qSE",
              "agentid": 1000153
          }
       */
    public static String getToken(JSONObject json) {
        String url = JsonUtils.getStr(json, "url") + WeixinUrlConstants.QY_ACCESS_TOKEN + "?corpid=" + JsonUtils.getStr(json, "corpId") + "&corpsecret=" + JsonUtils.getStr(json, "corpSecret");
        try {
            String ret = HttpUtils.sendGet(url, "");
            JSONObject retJson = JsonUtils.parse(ret);
            if (JsonUtils.equalVal(retJson, "errmsg", "ok")) {
                log.info("获取企业微信token成功，返回信息：{}", ret);
                return JsonUtils.getStr(retJson, "access_token");
            } else {
                log.info("获取企业微信token失败，返回信息：{}", ret);
            }
        } catch (Exception e) {
            log.error("获取企业微信token错误，URL：{}", url, e);
        }
        return "";
    }
}
