package com.crc.msg.rwork;

import cn.hutool.core.collection.CollUtil;
import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;
import com.crc.secface.domain.dto.MsgSendDTO;
import org.apache.commons.lang3.StringUtils;
import org.apache.http.Header;
import org.apache.http.HttpEntity;
import org.apache.http.HttpHeaders;
import org.apache.http.client.config.RequestConfig;
import org.apache.http.client.methods.CloseableHttpResponse;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.conn.ssl.NoopHostnameVerifier;
import org.apache.http.conn.ssl.SSLConnectionSocketFactory;
import org.apache.http.conn.ssl.TrustSelfSignedStrategy;
import org.apache.http.entity.StringEntity;
import org.apache.http.impl.client.CloseableHttpClient;
import org.apache.http.impl.client.HttpClients;
import org.apache.http.ssl.SSLContextBuilder;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import javax.net.ssl.HostnameVerifier;
import javax.net.ssl.SSLContext;
import java.io.File;
import java.nio.charset.StandardCharsets;
import java.security.KeyManagementException;
import java.security.KeyStoreException;
import java.security.NoSuchAlgorithmException;
import java.text.SimpleDateFormat;
import java.util.*;

/**
 * Sspd API
 */
public class RworkSend extends Thread {
    //平台地址
    public static String URL = "https://ssdp.crc.com.cn";
    //调用方的应用编码
    public static String APP_SUB_ID = "0006003301KD";
    //调用方应用授权令牌
    public static String APP_TOKEN = "2ab2700162644922b22a8f579ae0fa96";
    //调用方的组织编码
    public static String PARTNER_ID = "00060000";
    //调用方的系统编码
    public static String SYS_ID = "00060033";
    //润工作信息
    public static String APP_ID = "cli_9e50ad556738d007";
    public static String APP_SECRET = "JYCCsv040LPnVOGGFaTZsevv8Lr6CVYE";
    private static final Logger log = LoggerFactory.getLogger(RworkSend.class);
    //文件路径

    private static String path = "./";

    static {
        path = "/app/data/";
        if (System.getProperty("os.name").toLowerCase().contains("windows")) {
            path = "c:\\tmp\\data\\";
        }
    }

    /**
     * 忽略HTTPS证书校验
     */
    public static CloseableHttpClient createAcceptSelfSignedCertificateClient()
            throws KeyManagementException, NoSuchAlgorithmException, KeyStoreException {
        SSLContext sslContext = SSLContextBuilder
                .create()
                .loadTrustMaterial(new TrustSelfSignedStrategy())
                .build();
        HostnameVerifier allowAllHosts = new NoopHostnameVerifier();
        SSLConnectionSocketFactory connectionFactory = new SSLConnectionSocketFactory(sslContext, allowAllHosts);
        return HttpClients
                .custom()
                .setSSLSocketFactory(connectionFactory)
                .build();
    }

    /**
     * SSDP Base64编码
     */
    public static String getBase64(Map<String, String> map) {
        String result = "";
        try {
            List<Map.Entry<String, String>> infoIds = new ArrayList<Map.Entry<String, String>>(map.entrySet());
            // 对所有传入参数按照字段名的 ASCII 码从小到大排序（字典序）
            Collections.sort(infoIds, new Comparator<Map.Entry<String, String>>() {
                @Override
                public int compare(Map.Entry<String, String> o1, Map.Entry<String, String> o2) {
                    return (o1.getKey()).compareTo(o2.getKey());
                }
            });
            // 构造签名键值对的格式
            StringBuilder str = new StringBuilder();
            for (int i = 0; i < infoIds.size(); i++) {
                if (infoIds.get(i).getKey() != null || !infoIds.get(i).getKey().equals("")) {
                    String key = infoIds.get(i).getKey();
                    String val = infoIds.get(i).getValue();
                    if (i == infoIds.size() - 1) {
                        str.append(key + "=" + val);
                    } else {
                        str.append(key + "=" + val + "&");
                    }
                }
            }
            result = Base64.getEncoder().encodeToString(str.toString().getBytes(StandardCharsets.UTF_8));
        } catch (Exception e) {
            log.error(e.getMessage(), e);
            return "";
        }
        return result;
    }


    private final List<String> userList;
    private final String msg;
    private final String type;
    private final String title;
    private final String imgPath;

    public RworkSend(String type, List<String> userList, String msg, String title, String imgPath) {
        this.userList = userList;
        this.msg = msg;
        this.type = type;
        this.title = title;
        this.imgPath = imgPath;
    }

    @Override
    public void run() {
        try {
            if ("text".equalsIgnoreCase(type)) {
                /**
                 * {
                 *     "department_ids": [
                 *         "od-9d1912863dceba33a33226b52b32a776",
                 *         "od-81d13d502aaa9514059ea570c37d6438"
                 *     ],
                 *     "open_ids": [
                 *         "ou_18eac85d35a26f989317ad4f02e8bbbb",
                 *         "ou_461cf042d9eedaa60d445f26dc747d5e"
                 *     ],
                 *     "user_ids": [
                 *         "7cdcc7c2",
                 *         "ca51d83b"
                 *     ],
                 *     "msg_type": "text",
                 *     "content": {
                 *         "text": "test content"
                 *     }
                 * }
                 */
                JSONObject json = new JSONObject();
                json.put("msg_type", "text");
                JSONObject content = new JSONObject();
                content.put("text", msg);
                json.put("content", content);
                json.put("user_ids", userList);
                batchSend(json.toJSONString());
            } else if ("image".equalsIgnoreCase(type)) {
                /**
                 * {
                 *    "open_id":"ou_5ad573a6411d72b8305fda3a9c15c70e",
                 *    "chat_id":"oc_5ad11d72b830411d72b836c20",
                 *    "root_id":"om_40eb06e7b84dc71c03e009ad3c754195",
                 *     "user_id": "92e39a99",
                 *     "email":"fanlv@gmail.com",
                 *     "msg_type":"image",
                 *     "content":{
                 *         "image_key": "1a0c4cb9-c680-4371-924c-ddb5f2750c3d"
                 *     }
                 * }
                 */
                File file = new File(msg);
                String imageKey = RworkUploadImg.SendImageByApacheHttpClient(file);
                if (StringUtils.isNotBlank(imageKey)) {
                    JSONObject json = new JSONObject();
                    json.put("msg_type", "image");
                    JSONObject content = new JSONObject();
                    content.put("image_key", imageKey);
                    json.put("content", content);
                    json.put("user_ids", userList);
                    batchSend(json.toJSONString());
                } else {
                    System.out.println("润工作上传图片失败");
                }
            } else if ("post".equalsIgnoreCase(type)) {
                /**
                 {
                 "email": "fanlv@bytedance.com",
                 "msg_type": "post",
                 "content": {
                 "post": {
                 "zh_cn": {
                 "title": "我是一个标题",
                 "content": [
                 [
                 {
                 "tag": "text",
                 "un_escape": true,
                 "text": "第一行&nbsp;:"
                 },
                 {
                 "tag": "a",
                 "text": "超链接",
                 "href": "http://www.feishu.cn"
                 },
                 {
                 "tag": "at",
                 "user_id": "ou_18eac85d35a26f989317ad4f02e8bbbb"
                 }
                 ],
                 [
                 {
                 "tag": "text",
                 "text": "第二行 :"
                 },
                 {
                 "tag": "text",
                 "text": "文本测试"
                 }
                 ],
                 [
                 {
                 "tag": "img",
                 "image_key": "d640eeea-4d2f-4cb3-88d8-c964fab53987",
                 "width": 300,
                 "height": 300
                 }
                 ]
                 ]
                 }
                 }
                 }
                 }
                 */
                File file = new File(imgPath);
                String imageKey = RworkUploadImg.SendImageByApacheHttpClient(file);
                if (StringUtils.isNotBlank(imageKey)) {
                    JSONObject json = new JSONObject();
                    json.put("msg_type", "post");
                    JSONObject content = new JSONObject();
                    JSONObject post = new JSONObject();
                    JSONObject zh_cn = new JSONObject();
                    post.put("zh_cn", zh_cn);
                    zh_cn.put("title", title);
                    content.put("post", post);
                    json.put("content", content);


                    List<JSONObject> one = new ArrayList<>();
                    one.add(new JSONObject());
                    one.get(0).put("tag", "text");
                    one.get(0).put("text", msg);

                    List<JSONObject> two = new LinkedList<>();
                    two.add(new JSONObject());
                    two.get(0).put("tag", "img");
                    two.get(0).put("image_key", imageKey);
                    two.get(0).put("width", 4034);
                    two.get(0).put("height", 899);

                    List<List<JSONObject>> textList = new ArrayList<>();
                    textList.add(one);
                    textList.add(two);

                    zh_cn.put("content", textList);

                    json.put("user_ids", userList);
                    batchSend(json.toJSONString());
                } else {
                    System.out.println("润工作上传图片失败");
                }
            }
        } catch (Exception e) {
            log.error(e.getMessage(), e);
        }
    }

    public static void batchSend(List<MsgSendDTO> dtoList) {
        if (CollUtil.isEmpty(dtoList)) {
            return;
        }
        dtoList.forEach(dto -> {
            sendNotice(dto);
        });
    }

    private static void sendNotice(MsgSendDTO dto) {
        String type = dto.getType();
        if ("text".equalsIgnoreCase(type)) {
            batchSend(dto.getTo(), dto.getMsg());
        } else if ("image".equalsIgnoreCase(type)) {
            sendImage(dto.getTo(), dto.getMsg());
        } else if ("post".equalsIgnoreCase(type)) {
            sendPost(dto.getTo(), dto.getMsg(), dto.getTitle(), dto.getImgPath());
        }
    }

    /**
     * 批量发送消息
     */
    public static void batchSend(List<String> userList, String msg) {
        (new RworkSend("text", userList, msg, null, null)).start();
    }


    public static void sendImage(List<String> userList, String imgPath) {
        (new RworkSend("image", userList, imgPath, null, null)).start();
    }

    public static void sendPost(List<String> userList, String msg, String title, String imgPath) {
        (new RworkSend("post", userList, msg, title, imgPath)).start();
    }

    private static void batchSend(String Str) {
        Map<String, String> parm = new HashMap<String, String>();
        parm.put("Api_ID", "crc.rgz.app.feishu_batch_send"); //	UAT环境crc.rgz.lark0sit.feishu_batch_send
        parm.put("Api_Version", "1.0");
        parm.put("App_Sub_ID", APP_SUB_ID);
        parm.put("App_Token", APP_TOKEN);
        parm.put("Partner_ID", PARTNER_ID);
        parm.put("Sign", "NO_SIGN");
        parm.put("Sys_ID", SYS_ID);
        parm.put("Time_Stamp", getTime());
        parm.put("User_Token", "");
        //发送请求
        CloseableHttpClient httpClient = null;
        CloseableHttpResponse response = null;
        try {
            httpClient = createAcceptSelfSignedCertificateClient();
            HttpPost HTTPRequest = new HttpPost(URL + "/ssdp/cls/rf/?ssdp=" + getBase64(parm));
            HTTPRequest.setHeader("Content-Type", "application/json");
            HTTPRequest.setHeader(HttpHeaders.AUTHORIZATION, "Bearer " + KeyThread.getToken());
            HTTPRequest.setEntity(new StringEntity(Str, "UTF-8"));
            // 设置连接超时时间2秒
            RequestConfig requestConfig = RequestConfig.custom().setSocketTimeout(50000)
                    .setConnectTimeout(50000)
                    .build();
            HTTPRequest.setConfig(requestConfig);
            response = httpClient.execute(HTTPRequest);
            HttpEntity entry = response.getEntity();
            Header[] Heads = response.getAllHeaders();
            boolean transmission = false;
            //JsonUtils.print(Heads);
            for (Header raw : Heads) {
                if ("RETURN_DESC".equals(raw.getName()) && "transmission succ".equals(raw.getValue())) {
                    transmission = true;
                    System.out.println("发送消息成功：" + Str);
                    break;
                }
            }
            if (transmission == false) {
                log.error("发送失败！请求返回信息：" + JSON.toJSONString(Heads));
            }
        } catch (Exception e) {
            log.error(e.getMessage(), e);
        } finally {
            try {
                if (httpClient != null) {
                    httpClient.close();
                }
            } catch (Exception e) {
                log.error(e.getMessage(), e);
            }

            try {
                if (response != null) {
                    response.close();
                }
            } catch (Exception e) {
                log.error(e.getMessage(), e);
            }

        }
    }


    /**
     * 获取现在时间
     */
    public static String getTime() {
        String DATE_TIME_FORMAT_STRING3 = "yyyy-MM-dd HH:mm:ss:SSS";
        TimeZone tz = TimeZone.getTimeZone("Asia/Shanghai");
        TimeZone.setDefault(tz);
        Date date = new Date();
        SimpleDateFormat sdf8 = new SimpleDateFormat(DATE_TIME_FORMAT_STRING3);
        return sdf8.format(date);
    }
}
