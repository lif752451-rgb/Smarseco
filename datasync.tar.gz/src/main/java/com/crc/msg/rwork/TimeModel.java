package com.crc.msg.rwork;

import lombok.Data;

/**
 * @Author shufengfeng
 * @Description TODO
 * @DateTime 2021/9/14 13:45
 */
@Data
public class TimeModel {

    private String key;

    private Long timestamp;
}
