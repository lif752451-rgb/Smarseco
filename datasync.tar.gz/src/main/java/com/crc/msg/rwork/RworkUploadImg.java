package com.crc.msg.rwork;


import com.alibaba.fastjson.JSONObject;
import com.crc.common.utils.DataUtils;
import com.crc.common.utils.JsonUtils;
import org.apache.http.HttpEntity;
import org.apache.http.HttpHeaders;
import org.apache.http.client.config.RequestConfig;
import org.apache.http.client.methods.CloseableHttpResponse;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.config.Registry;
import org.apache.http.config.RegistryBuilder;
import org.apache.http.conn.socket.ConnectionSocketFactory;
import org.apache.http.conn.socket.PlainConnectionSocketFactory;
import org.apache.http.conn.ssl.NoopHostnameVerifier;
import org.apache.http.conn.ssl.SSLConnectionSocketFactory;
import org.apache.http.conn.ssl.TrustSelfSignedStrategy;
import org.apache.http.entity.mime.MultipartEntityBuilder;
import org.apache.http.entity.mime.content.FileBody;
import org.apache.http.impl.client.BasicCookieStore;
import org.apache.http.impl.client.CloseableHttpClient;
import org.apache.http.impl.client.HttpClients;
import org.apache.http.impl.conn.PoolingHttpClientConnectionManager;
import org.apache.http.ssl.SSLContextBuilder;
import org.apache.http.util.EntityUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.File;
import java.io.IOException;
import java.security.KeyManagementException;
import java.security.KeyStoreException;
import java.security.NoSuchAlgorithmException;

public class RworkUploadImg {
    private static final Logger log = LoggerFactory.getLogger(RworkSend.class);

    public static CloseableHttpClient getHttpClient() {
        try {
            SSLContextBuilder builder = new SSLContextBuilder();
            builder.loadTrustMaterial(null, new TrustSelfSignedStrategy());
            SSLConnectionSocketFactory sslConnectionSocketFactory = new SSLConnectionSocketFactory(builder.build(),
                    NoopHostnameVerifier.INSTANCE);
            Registry<ConnectionSocketFactory> registry = RegistryBuilder.<ConnectionSocketFactory>create()
                    .register("http", new PlainConnectionSocketFactory())
                    .register("https", sslConnectionSocketFactory)
                    .build();
            PoolingHttpClientConnectionManager cm = new PoolingHttpClientConnectionManager(registry);
            cm.setMaxTotal(100);
            CloseableHttpClient httpclient = HttpClients.custom()
                    .setSSLSocketFactory(sslConnectionSocketFactory)
                    .setDefaultCookieStore(new BasicCookieStore())
                    .setConnectionManager(cm).build();
            return httpclient;
        } catch (KeyManagementException e) {
            e.printStackTrace();
        } catch (NoSuchAlgorithmException e) {
            e.printStackTrace();
        } catch (KeyStoreException e) {
            e.printStackTrace();
        }
        return HttpClients.createDefault();
    }

    public static String SendImageByApacheHttpClient(File file) throws IOException {
        CloseableHttpClient httpClient = null;
        CloseableHttpResponse response = null;
        try {
            httpClient = getHttpClient();

            HttpPost post = new HttpPost("https://open.rwork.crc.com.cn/open-apis/image/v4/put/");
            RequestConfig requestConfig = RequestConfig.custom()
                    .setConnectTimeout(45000).setConnectionRequestTimeout(45000)
                    .setSocketTimeout(45000).build();
            post.setConfig(requestConfig);
            final MultipartEntityBuilder builder = MultipartEntityBuilder.create();
            FileBody bin = new FileBody(file);
            builder.addPart("image", bin);
            builder.addTextBody("image_type", "message");
            HttpEntity multiPartEntity = builder.build();
            post.setEntity(multiPartEntity);
            post.setHeader(HttpHeaders.AUTHORIZATION, "Bearer " + KeyThread.getToken());
            response = httpClient.execute(post);
            //System.out.println("http response code:" + response.getStatusLine().getStatusCode());
//            for (Header header : response.getAllHeaders()) {
//                System.out.println(header.toString());
//            }
            //System.out.println("Response content length: " + resEntity.getContentLength());
            String retMsg = DataUtils.toBodyString(response.getEntity());
            JSONObject json = JsonUtils.parse(retMsg);
            if ("ok".equalsIgnoreCase(JsonUtils.getStr(json, "msg"))) {
                JSONObject data = json.getJSONObject("data");
                return JsonUtils.getStr(data, "image_key");
            }
        } catch (Exception e) {
            log.error(e.getMessage(), e);
        } finally {
            try {
                if (httpClient != null) {
                    httpClient.close();
                }
            } catch (Exception e) {
                log.error(e.getMessage(), e);
            }

            try {
                if (response != null) {
                    response.close();
                }
            } catch (Exception e) {
                log.error(e.getMessage(), e);
            }
        }
        return "";
    }
}

