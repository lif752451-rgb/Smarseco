package com.crc.msg.util;

import cn.hutool.core.date.DateUtil;
import com.crc.common.constants.Constants;
import com.crc.common.utils.DictUtil;
import com.crc.msg.factory.MsgSendFactory;
import com.crc.secface.domain.RiskTotal;
import com.crc.secface.domain.dto.MsgSendDTO;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;

import java.util.Arrays;
import java.util.Collections;
import java.util.Date;

import static com.crc.common.enums.ScanTypeEnums.WEAK_PASS_SCAN;
import static com.crc.common.enums.ScanTypeEnums.WEB_SCAN;
import static com.crc.msg.constant.MsgConstant.QYVX_MSG_TEXT;

/**
 * 消息发送工具类
 *
 * @Author fuzhuangzhi
 * @Date 2023/2/13 14:12
 * @Version 1.0
 **/
@Slf4j
public class MsgSendUtil {

    /**
     * 复查完成发送消息提醒
     *
     * @param user        收件人
     * @param sourceLabel 扫描器中文名称
     * @param category    漏洞类别 1：主机漏洞 2：WEB漏洞 3：弱口令漏洞
     * @param createTime  创建复查任务的时间
     * @param riskTotal   漏洞复查总量统计
     */
    public static void sendVulMsgNotice(String user, String sourceLabel, String category, Date createTime, RiskTotal riskTotal) {
        if ("super".equalsIgnoreCase(user) || StringUtils.isBlank(user)) {
            return;
        }
        try {
            // 链接跳转URL
            String basePath = DictUtil.getDictLabel("base_path", "base_path");

            String url = basePath+DictUtil.getDictLabel("vuln_mail_url", getJumpUrl(category));
            String text = String.format(QYVX_MSG_TEXT, DateUtil.formatDateTime(createTime), riskTotal.getIp(), sourceLabel, riskTotal.getNewFind(), riskTotal.getRepair(), riskTotal.getUnrepair(), url, url);
            MsgSendDTO msgSendDTO = MsgSendDTO.builder().type("text").to(Arrays.asList(user.split(Constants.Symbol.COMMA))).msg(text).build();
            MsgSendFactory.batchSend(Collections.singletonList(msgSendDTO), "vulnProcess");
        } catch (Exception e) {
            log.error("发送复查消息出错：{}", e.getMessage(), e);
        }
    }

    private static String getJumpUrl(String category) {
        String dictValue = null;
        if (String.valueOf(WEB_SCAN.getCode()).equals(category)) {
            dictValue = "vulnWebProcess";
        } else if (String.valueOf(WEAK_PASS_SCAN.getCode()).equals(category)) {
            dictValue = "vulnCodeProcess";
        } else {
            dictValue = "vulnHostProcess";
        }
        return dictValue;
    }
}
