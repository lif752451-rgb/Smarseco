package com.crc.msg.factory;

import cn.hutool.core.collection.CollUtil;
import cn.hutool.core.util.StrUtil;
import com.crc.common.utils.DictUtil;
import com.crc.msg.qywx.QyweixinSend;
import com.crc.msg.rwork.RworkSend;
import com.crc.secface.domain.dto.MsgSendDTO;
import lombok.extern.slf4j.Slf4j;

import java.util.Arrays;
import java.util.List;
import java.util.stream.Collectors;

import static com.crc.common.constants.Constants.Symbol.COMMA;
import static com.crc.common.constants.Constants.Symbol.ZH_COMMA;
import static com.crc.common.enums.MsgSendTypeEnum.FEI_SHU;
import static com.crc.common.enums.MsgSendTypeEnum.QYWX;

/**
 * 消息推送工厂类
 *
 * @Author fuzhuangzhi
 * @Date 2023/2/10 11:15
 * @Version 1.0
 **/
@Slf4j
public class MsgSendFactory {

    /**
     * 批量发送消息
     *
     * @param msgSendDTOList 发送消息实体集合
     * @param moduleName     发送消息字典：msg_send_config下配置的模块名称
     */
    public static void batchSend(List<MsgSendDTO> msgSendDTOList, String moduleName) {
        if (CollUtil.isEmpty(msgSendDTOList)) {
            return;
        }
        // 发送类型：qywx:企业微信 feishu:飞书 多个用英文逗号隔开
        String sendTypes = DictUtil.getDictValue("msg_send_config", moduleName);
        if (StrUtil.isEmpty(sendTypes)) {
            log.info("未配置消息发送类型");
            return;
        }
        List<MsgSendDTO> sendMsgList = msgSendDTOList.stream().filter(t -> CollUtil.isNotEmpty(t.getTo())).collect(Collectors.toList());
        if (CollUtil.isEmpty(sendMsgList)) {
            return;
        }
        List<String> sendTypeList = Arrays.stream(sendTypes.replace(ZH_COMMA, COMMA).split(COMMA)).distinct().collect(Collectors.toList());
        for (String sendType : sendTypeList) {
            if (QYWX.getType().equalsIgnoreCase(sendType)) {
                sendMsgList.forEach(t -> {
                    QyweixinSend.batchSend(t.getTo(), t.getMsg(),t.getType());
                });
            } else if (FEI_SHU.getType().equalsIgnoreCase(sendType)) {
                RworkSend.batchSend(sendMsgList);
            }
        }
    }
}
