package com.crc.api;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;
import com.crc.common.utils.IpUtils;
import com.crc.common.utils.ReqeustUtils;
import com.crc.secface.domain.Asset;
import com.crc.secface.queue.CrcAssetSyncQueue;
import com.crc.sync.cmdb.CmdbCenter;
import com.crc.sync.config.SyncSecConfigLoad;
import com.crc.sync.config.SyncSecConstants;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import javax.servlet.http.HttpServletRequest;

@RestController
@Slf4j
@RequestMapping("/asset/v1")
public class AssetController {

    @RequestMapping("/sync")
    public String sync(HttpServletRequest request) {
        //text/plain接收数据
        String requestBody = ReqeustUtils.getRequestBody(request);
        log.info("{},内容：{}", IpUtils.getIpAddr(request), requestBody);
        JSONObject retJson = new JSONObject();
        try {
            CmdbCenter.anlyDept();
            retJson.put("code", 200);
            retJson.put("msg", "推送成功");
        } catch (Exception e) {
            log.error(e.getMessage(), e);
            retJson.put("code", 500);
            retJson.put("msg", "推送失败");
        }
        return retJson.toJSONString();
    }


    @RequestMapping("/addAsset")
    public String addAsset(HttpServletRequest request) {
        String dbStr = SyncSecConfigLoad.getRemarkValue(SyncSecConstants.SYNC_ASSET_API_ENABLE);
        if (StringUtils.isBlank(dbStr)) {
            log.error("同步资产API配置错误SYNC_SEC_CONFIG【asset_api_enable】");
            return null;
        }
        //text/plain接收数据
        String requestBody = ReqeustUtils.getRequestBody(request);
        log.info("{},内容：{}", IpUtils.getIpAddr(request), requestBody);
        JSONObject retJson = new JSONObject();
        try {
            Asset asset = JSON.parseObject(requestBody, Asset.class);
            CrcAssetSyncQueue.getInstance().saveAsset(asset);
            retJson.put("code", 200);
            retJson.put("msg", "推送成功");
        } catch (Exception e) {
            log.error(e.getMessage(), e);
            retJson.put("code", 500);
            retJson.put("msg", "推送失败");
        }
        return retJson.toJSONString();
    }
}
