package com.crc.api;

import com.alibaba.fastjson.JSONObject;
import com.crc.common.gm.GuoMiTools;
import com.crc.common.utils.IpUtils;
import com.crc.common.utils.JsonUtils;
import com.crc.common.utils.ReqeustUtils;
import com.crc.sync.banboo.BanbooKeys;
import com.crc.sync.banboo.BanbooSyncWork;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import javax.servlet.http.HttpServletRequest;
import java.util.Map;

@RestController
@Slf4j
@RequestMapping("/banboo")
public class BanbooController {
    /**
     * 1-竹云7.0，2-华为oneaccess版本
     */
    public final static int ZY_VER_FIX = 2;

    private final static String ZY_UID = "smartseco";//系统分配ID

    @RequestMapping("/SchemaService")
    public String SchemaService(HttpServletRequest request) {
        //text/plain接收数据
        String requestBody = ReqeustUtils.getRequestBody(request);
        //获取到加密数据，进行解密
        String requestParam = GuoMiTools.decryptData(requestBody, BanbooKeys.getKey(), BanbooKeys.getType());
        log.info("{},内容：{}", IpUtils.getIpAddr(request),requestBody);
        //解密后强转为Map集合
        Map<String, Object> requestMap = JsonUtils.parse(requestParam);
        String jsonStr = "{\n" +
                "\t\"aimRequestId\": \"9e928d12ec8a4c1bb75283b8df71308d\",\n" +
                "\t\"account\": [{\n" +
                "\t\t\"multivalued\": false,\n" +
                "\t\t\"name\": \"user_id\",\n" +
                "\t\t\"required\": true,\n" +
                "\t\t\"type\": \"String\"\n" +
                "\t},{\n" +
                "\t\t\"multivalued\": false,\n" +
                "\t\t\"name\": \"email\",\n" +
                "\t\t\"required\": false,\n" +
                "\t\t\"type\": \"String\"\n" +
                "\t}, {\n" +
                "\t\t\"multivalued\": false,\n" +
                "\t\t\"name\": \"true_name\",\n" +
                "\t\t\"required\": false,\n" +
                "\t\t\"type\": \"String\"\n" +
                "\t}, {\n" +
                "\t\t\"multivalued\": true,\n" +
                "\t\t\"name\": \"org_unit_id\",\n" +
                "\t\t\"required\": true,\n" +
                "\t\t\"type\": \"String\"\n" +
                "\t}, {\n" +
                "\t\t\"multivalued\": false,\n" +
                "\t\t\"name\": \"user_status\",\n" +
                "\t\t\"required\": true,\n" +
                "\t\t\"type\": \"int\"\n" +
                "\t},{\n" +
                "\t\t\"multivalued\": false,\n" +
                "\t\t\"name\": \"mobile_number \",\n" +
                "\t\t\"required\": false,\n" +
                "\t\t\"type\": \"String\"\n" +
                "\t}],\n" +
                "\"organization\": [{\n" +
                "\t\t\"multivalued\": false,\n" +
                "\t\t\"name\": \"org_unit_id\",\n" +
                "\t\t\"required\": false,\n" +
                "\t\t\"type\": \"String\"\n" +
                "\t}, {\n" +
                "\t\t\"multivalued\": false,\n" +
                "\t\t\"name\": \"parent_org_unit_id\",\n" +
                "\t\t\"required\": false,\n" +
                "\t\t\"type\": \"String\"\n" +
                "\t}, {\n" +
                "\t\t\"multivalued\": false,\n" +
                "\t\t\"name\": \"org_unit_name\",\n" +
                "\t\t\"required\": true,\n" +
                "\t\t\"type\": \"String\"\n" +
                "\t}] }";
        JSONObject resultJSON = JsonUtils.parse(jsonStr);
        //成功报文如下
        resultJSON.put("bimRequestId", requestMap.get("bimRequestId"));
        if (ZY_VER_FIX == 2) {
            resultJSON.put("uid", ZY_UID);//uid文档没有此传参但是说必传---自己设一个就好，此处只做模拟
            resultJSON.put("aimRequestId", requestMap.get("iamRequestId"));
        }else {
            resultJSON.remove("uid");
            resultJSON.remove("aimRequestId");
        }

        //加密
        if (ZY_VER_FIX == 2) {
            return resultJSON.toJSONString();
        }
        return GuoMiTools.encryptData(resultJSON.toJSONString(), BanbooKeys.getKey(), BanbooKeys.getType());
    }

    @RequestMapping("/UserCreateService")
    public String UserCreateService(HttpServletRequest request) {
        //text/plain接收数据
        String requestBody = ReqeustUtils.getRequestBody(request);
        log.info("{},内容：{}", IpUtils.getIpAddr(request),requestBody);
        //获取到加密数据，进行解密
        String requestParam = requestBody;
        if (ZY_VER_FIX == 1) {
            requestParam = GuoMiTools.decryptData(requestBody, BanbooKeys.getKey(), BanbooKeys.getType());
        }
        //解密后强转为Map集合
        JSONObject requestJson = JsonUtils.parse(requestParam);

        //校验解密后的入参数据签名
        boolean verify = true;
        JSONObject resultJSON = new JSONObject();
        if (requestJson.containsKey("user_id")) {
            resultJSON.put("uid", JsonUtils.getStr(requestJson, "user_id"));
        } else if (requestJson.containsKey("__NAME__")) {
            resultJSON.put("uid", JsonUtils.getStr(requestJson, "__NAME__"));
        }
        resultJSON.put("bimRequestId", ((Map<String, Object>) requestJson).get("bimRequestId"));
        resultJSON.put("aimRequestId", ((Map<String, Object>) requestJson).get("iamRequestId"));
        if (verify) {
            //校验成功,模拟业务处理数据
            BanbooSyncWork.add(requestJson, "user", "1");
            //数据处理成功,返回响应报文并加密
            //成功报文如下
            if (StringUtils.isBlank(JsonUtils.getStr(resultJSON, "uid"))) {
                resultJSON.put("uid", ZY_UID);//uid文档没有此传参但是说必传---自己设一个就好，此处只做模拟
            }
            resultJSON.put("resultCode", "0");
        } else {
            //校验失败,返回错误信息
            resultJSON.put("resultCode", "500");
            resultJSON.put("message", "新增失败!");
        }
        if (ZY_VER_FIX == 2) {
            return resultJSON.toJSONString();
        }
        //加密
        return GuoMiTools.encryptData(resultJSON.toJSONString(), BanbooKeys.getKey(), BanbooKeys.getType());
    }


    @RequestMapping("/UserUpdateService")
    public String UserUpdateService(HttpServletRequest request) {
        //text/plain接收数据
        String requestBody = ReqeustUtils.getRequestBody(request);
        log.info("{},内容：{}", IpUtils.getIpAddr(request),requestBody);
        //获取到加密数据，进行解密
        String requestParam = requestBody;
        if (ZY_VER_FIX == 1) {
            requestParam = GuoMiTools.decryptData(requestBody, BanbooKeys.getKey(), BanbooKeys.getType());
        }
        //解密后强转为Map集合
        JSONObject requestJson = JsonUtils.parse(requestParam);
        //校验解密后的入参数据签名
        boolean verify = true;
        JSONObject resultJSON = new JSONObject();
        if (requestJson.containsKey("user_id")) {
            resultJSON.put("uid", JsonUtils.getStr(requestJson, "user_id"));
        } else if (requestJson.containsKey("__NAME__")) {
            resultJSON.put("uid", JsonUtils.getStr(requestJson, "__NAME__"));
        }
        resultJSON.put("bimRequestId", ((Map<String, Object>) requestJson).get("bimRequestId"));
        resultJSON.put("aimRequestId", ((Map<String, Object>) requestJson).get("iamRequestId"));
        if (verify) {
            //校验成功,模拟业务处理数据
            BanbooSyncWork.add(requestJson, "user", "2");
            //数据处理成功,返回响应报文并加密
            //成功报文如下
            if (StringUtils.isBlank(JsonUtils.getStr(resultJSON, "uid")))
                resultJSON.put("uid", ZY_UID);//uid文档没有此传参但是说必传
            resultJSON.put("resultCode", "0");
        } else {
            //校验失败,返回错误信息
            resultJSON.put("resultCode", "500");
            resultJSON.put("message", "新增失败!");
        }
        if (ZY_VER_FIX == 2) {
            return resultJSON.toJSONString();
        }
        //加密
        return GuoMiTools.encryptData(resultJSON.toJSONString(), BanbooKeys.getKey(), BanbooKeys.getType());
    }

    @RequestMapping("/UserDeleteService")
    public String UserDeleteService(HttpServletRequest request) {
        //text/plain接收数据
        String requestBody = ReqeustUtils.getRequestBody(request);
        log.info("{},内容：{}", IpUtils.getIpAddr(request),requestBody);
        //获取到加密数据，进行解密
        String requestParam = requestBody;
        if (ZY_VER_FIX == 1) {
            requestParam = GuoMiTools.decryptData(requestBody, BanbooKeys.getKey(), BanbooKeys.getType());
        }
        //解密后强转为Map集合
        JSONObject requestJson = JsonUtils.parse(requestParam);
        //校验解密后的入参数据签名
        boolean verify = true;
        JSONObject resultJSON = new JSONObject();
        if (requestJson.containsKey("user_id")) {
            resultJSON.put("uid", JsonUtils.getStr(requestJson, "user_id"));
        } else if (requestJson.containsKey("__NAME__")) {
            resultJSON.put("uid", JsonUtils.getStr(requestJson, "__NAME__"));
        }
        resultJSON.put("bimRequestId", ((Map<String, Object>) requestJson).get("bimRequestId"));
        resultJSON.put("aimRequestId", ((Map<String, Object>) requestJson).get("iamRequestId"));
        if (verify) {
            //校验成功,模拟业务处理数据
            BanbooSyncWork.add(requestJson, "user", "3");
            //数据处理成功,返回响应报文并加密
            //成功报文如下
            if (StringUtils.isBlank(JsonUtils.getStr(resultJSON, "uid")))
                resultJSON.put("uid", ZY_UID);//uid文档没有此传参但是说必传
            resultJSON.put("resultCode", "0");
        } else {
            //校验失败,返回错误信息
            resultJSON.put("resultCode", "500");
            resultJSON.put("message", "新增失败!");
        }
        if (ZY_VER_FIX == 2) {
            return resultJSON.toJSONString();
        }
        //加密
        return GuoMiTools.encryptData(resultJSON.toJSONString(), BanbooKeys.getKey(), BanbooKeys.getType());
    }


    @RequestMapping("/OrgCreateService")
    public String OrgCreateService(HttpServletRequest request) {
        //text/plain接收数据
        String requestBody = ReqeustUtils.getRequestBody(request);
        log.info("{},内容：{}", IpUtils.getIpAddr(request),requestBody);
        //获取到加密数据，进行解密
        String requestParam = requestBody;
        if (ZY_VER_FIX == 1) {
            requestParam = GuoMiTools.decryptData(requestBody, BanbooKeys.getKey(), BanbooKeys.getType());
        }
        //解密后强转为Map集合
        JSONObject requestJson = JsonUtils.parse(requestParam);
        //校验解密后的入参数据签名
        boolean verify = true;

        JSONObject resultJSON = new JSONObject();
        resultJSON.put("orgId", ((Map<String, Object>) requestJson).get("org_unit_id"));
        resultJSON.put("bimRequestId", ((Map<String, Object>) requestJson).get("bimRequestId"));
        resultJSON.put("aimRequestId", ((Map<String, Object>) requestJson).get("iamRequestId"));
        if (StringUtils.isBlank(JsonUtils.getStr(requestJson, "parent_org_unit_id"))) {
            requestJson.put("parent_org_unit_id", "CR005");
            requestJson.put("top_org_flag", "1");
        }
        if (verify) {
            //校验成功,模拟业务处理数据
            BanbooSyncWork.add(requestJson, "dept", "1");
            //数据处理成功,返回响应报文并加密
            //成功报文如下
            resultJSON.put("resultCode", "0");
            resultJSON.put("message", "成功");
        } else {
            //校验失败,返回错误信息
            resultJSON.put("resultCode", "500");
            resultJSON.put("message", "新增失败!");
        }
        if (ZY_VER_FIX == 2) {
            return resultJSON.toJSONString();
        }
        //加密
        return GuoMiTools.encryptData(resultJSON.toJSONString(), BanbooKeys.getKey(), BanbooKeys.getType());
    }


    @RequestMapping("/OrgUpdateService")
    public String OrgUpdateService(HttpServletRequest request) {
        //text/plain接收数据
        String requestBody = ReqeustUtils.getRequestBody(request);
        log.info("{},内容：{}", IpUtils.getIpAddr(request),requestBody);
        //获取到加密数据，进行解密
        String requestParam = requestBody;
        if (ZY_VER_FIX == 1) {
            requestParam = GuoMiTools.decryptData(requestBody, BanbooKeys.getKey(), BanbooKeys.getType());
        }
        //解密后强转为Map集合
        JSONObject requestJson = JsonUtils.parse(requestParam);
        //校验解密后的入参数据签名
        //Boolean verify = BamboocloudUtils.verify(requestJson, "SM3");
        boolean verify = true;
        JSONObject resultJSON = new JSONObject();
        resultJSON.put("orgId", ((Map<String, Object>) requestJson).get("org_unit_id"));
        resultJSON.put("bimRequestId", ((Map<String, Object>) requestJson).get("bimRequestId"));
        resultJSON.put("aimRequestId", ((Map<String, Object>) requestJson).get("iamRequestId"));
        if (verify) {
            //校验成功,模拟业务处理数据
            BanbooSyncWork.add(requestJson, "dept", "2");
            //数据处理成功,返回响应报文并加密
            resultJSON.put("resultCode", "0");
            resultJSON.put("message", "成功");
        } else {
            //校验失败,返回错误信息
            resultJSON.put("resultCode", "500");
            resultJSON.put("message", "新增失败!");
        }
        if (ZY_VER_FIX == 2) {
            return resultJSON.toJSONString();
        }
        //加密
        return GuoMiTools.encryptData(resultJSON.toJSONString(), BanbooKeys.getKey(), BanbooKeys.getType());
    }

    @RequestMapping("/OrgDeleteService")
    public String OrgDeleteService(HttpServletRequest request) {
        //text/plain接收数据
        String requestBody = ReqeustUtils.getRequestBody(request);
        log.info("{},内容：{}", IpUtils.getIpAddr(request),requestBody);
        //获取到加密数据，进行解密
        String requestParam = requestBody;
        if (ZY_VER_FIX == 1) {
            requestParam = GuoMiTools.decryptData(requestBody, BanbooKeys.getKey(), BanbooKeys.getType());
        }
        //解密后强转为Map集合
        JSONObject requestJson = JsonUtils.parse(requestParam);
        //校验解密后的入参数据签名
        boolean verify = true;
        JSONObject resultJSON = new JSONObject();
        resultJSON.put("orgId", ((Map<String, Object>) requestJson).get("org_unit_id"));
        resultJSON.put("bimRequestId", ((Map<String, Object>) requestJson).get("bimRequestId"));
        resultJSON.put("aimRequestId", ((Map<String, Object>) requestJson).get("iamRequestId"));
        if (verify) {
            //校验成功,模拟业务处理数据
            BanbooSyncWork.add(requestJson, "dept", "3");
            //数据处理成功,返回响应报文并加密
            //成功报文如下
            resultJSON.put("resultCode", "0");
            resultJSON.put("message", "成功");
        } else {
            //校验失败,返回错误信息
            resultJSON.put("resultCode", "500");
            resultJSON.put("message", "新增失败!");
        }
        if (ZY_VER_FIX == 2) {
            return resultJSON.toJSONString();
        }
        //加密
        return GuoMiTools.encryptData(resultJSON.toJSONString(), BanbooKeys.getKey(), BanbooKeys.getType());
    }
}
