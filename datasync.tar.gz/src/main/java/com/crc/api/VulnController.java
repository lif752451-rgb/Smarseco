package com.crc.api;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;
import com.crc.common.enums.ScannerEnums;
import com.crc.common.utils.IpUtils;
import com.crc.common.utils.JsonUtils;
import com.crc.common.utils.ReqeustUtils;
import com.crc.scanner.config.JtConfig;
import com.crc.scanner.tool.JiaotuUtils;
import com.crc.secface.domain.VulnProcessForm;
import com.crc.secface.schedule.assemble.CommonAssemble;
import com.crc.secface.schedule.assemble.host.JiaotuAssemble;
import com.crc.sync.jiaotu.JiaotuVulSync;
import com.crc.sync.qingteng.QingtengAssetSync;
import lombok.extern.slf4j.Slf4j;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import javax.servlet.http.HttpServletRequest;

@RestController
@Slf4j
@RequestMapping("/vuln/v1")
public class VulnController {
    @RequestMapping("/qt")
    public String qt(HttpServletRequest request, @RequestBody String param) {
        QingtengAssetSync tcmdb = new QingtengAssetSync();
        tcmdb.sync();
        return "good";
    }
    @RequestMapping("/vul")
    public String vul(HttpServletRequest request, @RequestBody String param) {
        (new JiaotuVulSync()).sync();
        return "good";
    }
    @RequestMapping("/uuid")
    public String jtuuid1(HttpServletRequest request, @RequestBody String param) {
        //text/plain接收数据
        log.info("{},内容：{}", IpUtils.getIpAddr(request), param);
        JSONObject retJson = JsonUtils.parse(param);
        try {
            String type = JsonUtils.getStr(retJson, "type");
            String ip = JsonUtils.getStr(retJson, "ip");
            try {
                CommonAssemble.engineMap.forEach((k, v) -> {
                    if (ScannerEnums.JIAOTU_SCANNER.getCode().equals(v.getEquipmentManufacture())) {
                        if ("2".equalsIgnoreCase(type)) {
                            uuidCurl(JiaotuAssemble.getJtConfig(k),ip);
                        }else {
                            uuid(JiaotuAssemble.getJtConfig(k),ip);
                        }

                    }
                });
            } catch (Exception e) {
                log.error(e.getMessage(), e);
            }

            retJson.put("code", 200);
            retJson.put("msg", "推送成功");
        } catch (Exception e) {
            log.error(e.getMessage(), e);
            retJson.put("code", 500);
            retJson.put("msg", "推送失败");
        }
        return retJson.toJSONString();
    }

    private void uuidCurl(JtConfig jtConfig,String ip) {
        String ret = JiaotuUtils.getAgentUuidByIpCurl(jtConfig, ip);
        log.info(ret);
    }

    private void uuid(JtConfig jtConfig,String ip) {
        String ret = JiaotuUtils.getAgentUuidByIp(jtConfig, ip);
        log.info(ret);
    }

    @RequestMapping("/addVuln")
    public String addVuln(HttpServletRequest request) {
        //text/plain接收数据
        String requestBody = ReqeustUtils.getRequestBody(request);
        log.info("{},内容：{}", IpUtils.getIpAddr(request), requestBody);
        JSONObject retJson = new JSONObject();
        try {
            VulnProcessForm vulnProcessForm = JSON.parseObject(requestBody, VulnProcessForm.class);
            CommonAssemble.saveVul(vulnProcessForm);
            retJson.put("code", 200);
            retJson.put("msg", "推送成功");
        } catch (Exception e) {
            log.error(e.getMessage(), e);
            retJson.put("code", 500);
            retJson.put("msg", "推送失败");
        }
        return retJson.toJSONString();
    }
}
