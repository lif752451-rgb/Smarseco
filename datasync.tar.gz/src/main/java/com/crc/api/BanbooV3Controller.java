package com.crc.api;

import com.alibaba.fastjson.JSONObject;
import com.crc.common.utils.JsonUtils;
import com.crc.common.utils.ReqeustUtils;
import com.crc.sync.banboo.BanbooSyncToUserDeptWork;
import com.crc.sync.banboo.RqBimDataSync;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.io.FileUtils;
import org.apache.commons.io.LineIterator;
import org.apache.commons.lang3.StringUtils;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import javax.servlet.http.HttpServletRequest;
import java.io.File;

/**
 * 水务
 */
@RestController
@Slf4j
@RequestMapping("/banboo/v3")
public class BanbooV3Controller {
    @RequestMapping("/cal")
    public String cal(HttpServletRequest request) {
        try {
            BanbooSyncToUserDeptWork work = new BanbooSyncToUserDeptWork();
            work.sync();
        } catch (Exception e) {
            log.error(e.getMessage(), e);
        }
        return "good";
    }
    @RequestMapping("/data")
    public String data(HttpServletRequest request) {
        String requestBody = ReqeustUtils.getRequestBody(request);
        //System.out.println(requestBody);
        //text/plain接收数据
        String filePath = request.getParameter("path");
        ///Users/hejingsheng/Desktop/Code/exp_2023_12_12_17_18_10.log
        try {
            LineIterator it = FileUtils.lineIterator(new File(filePath), "UTF-8");
            try {
                String fix = "Ret:";
                while (it.hasNext()) {
                    String line = it.nextLine();
                    if (StringUtils.isNotBlank(line)) {

                        int pos = line.indexOf(fix);
                        if (pos != -1) {
                            RqBimDataSync bimDataSync = new RqBimDataSync();
                            JSONObject pullTaskRetJson = JsonUtils.parse(line.substring(fix.length() + pos));
                            String objectType = JsonUtils.getStr(pullTaskRetJson, "objectType");
                            String effectOn = JsonUtils.getStr(pullTaskRetJson, "effectOn");
                            boolean success = pullTaskRetJson.getBoolean("success");
                            if (success) {
                                JSONObject data = pullTaskRetJson.getJSONObject("data");
                                if ("TARGET_ACCOUNT".equalsIgnoreCase(objectType)) {
                                    bimDataSync.syncUser(data, effectOn);
                                } else if ("TARGET_ORGANIZATION".equalsIgnoreCase(objectType)) {
                                    bimDataSync.syncOffice(data, effectOn);
                                } else {
                                    log.error("未知类型：{}", objectType);
                                }
                            }
                        }
                    }
                }
            } finally {
                LineIterator.closeQuietly(it);
            }
        } catch (Exception e) {
            log.error(e.getMessage(), e);
        }
        return "good";
    }
}
