package com.crc;


import com.crc.api.BanbooController;
import com.crc.secface.queue.QtAllRiskAutoFlowSyncQueue;
import com.crc.secface.queue.RiskAutoFlowSyncQueue;
import com.crc.sync.alarm.IpAlarmSync;
import com.crc.sync.banboo.BanbooSyncWork;
import com.crc.sync.banboo.DtBanbooSyncWork;
import com.crc.sync.event.EventTranSyncCenter;
import com.crc.sync.marvelnet.FirewallPolicySync;
import com.crc.sync.qingteng.v2.QingtengV2DataSync;
import com.crc.sync.work.PortSaveWork;
import com.crc.sync.work.QingtengPortWork;
import com.crc.sync.work.QingtengSoftwareWork;
import com.crc.sync.work.SoftwareSaveWork;
import lombok.extern.slf4j.Slf4j;

@Slf4j
public class StartUp {
    public static void start() {
        (new RiskAutoFlowSyncQueue()).start();
        (new QtAllRiskAutoFlowSyncQueue()).start();

        (new SoftwareSaveWork()).start();
        (new PortSaveWork()).start();
        (new QingtengPortWork()).start();
        (new QingtengSoftwareWork()).start();

        (new EventTranSyncCenter()).start();

        if (BanbooController.ZY_VER_FIX == 2) {
            (new DtBanbooSyncWork()).start();
        } else {
            (new BanbooSyncWork()).start();
        }
        (new IpAlarmSync()).start();
        (new FirewallPolicySync()).start();
        (new QingtengV2DataSync()).start();
        //(new BanbooSyncToUserDeptWork()).sync();
    }
}
