package com.crc.scanner.config;

import lombok.Data;

/**
 * 天擎配置
 */
@Data
public class TianQinConfig {
    String mode;
    String address;
    Long engineId;
    String username;
    String password;
    String version;
    public String getMode() {
        if (address != null) {
            if (address.toLowerCase().startsWith("https")) {
                mode = "https";
            } else {
                mode = "http";
            }
        }
        return mode;
    }

    public boolean isGoodConfig() {
        if (address != null) {
            return true;
        }
        return false;
    }
}
