package com.crc.scanner.config;

import lombok.Data;

@Data
public class SdnConfig {
    String username;
    String password;
    String mode;
    String level;
    String address;
    String token;
    Long engineId;

    public String getMode() {
        if (address != null) {
            if (address.toLowerCase().startsWith("https")) {
                mode = "https";
            } else {
                mode = "http";
            }
        }
        return mode;
    }

    public boolean isGoodConfig() {
        if (address != null ) {
            return true;
        }
        return false;
    }
}
