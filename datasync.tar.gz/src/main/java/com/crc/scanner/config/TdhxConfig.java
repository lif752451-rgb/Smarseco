package com.crc.scanner.config;


import lombok.Data;

@Data
public class TdhxConfig {
    String userName;
    String password;
    String token;
    String source;
    String mode;
    String address;
    public void setAddress(String address) {
        this.address = address;
        if (address != null) {
            if (!address.endsWith("/")) {
                refer = address + "/";
            }else {
                refer = address;
            }
        }
    }

    String refer;
    Long engineId;
    public String getMode() {
        if (address != null) {
            if (address.toLowerCase().startsWith("https")) {
                mode = "https";
            } else {
                mode = "http";
            }
        }
        return mode;
    }

    public boolean isGoodConfig() {
        return address != null;
    }
}
