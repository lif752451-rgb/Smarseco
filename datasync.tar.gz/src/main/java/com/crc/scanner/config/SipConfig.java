package com.crc.scanner.config;

import lombok.Data;

@Data
public class SipConfig {
    String username;
    String password;
    String mode;
    String address;
    String version;
    Long engineId;
    String platform;

    public String getMode() {
        if (address != null) {
            if (address.toLowerCase().startsWith("https")) {
                mode = "https";
            }else {
                mode = "http";
            }
        }
        return mode;
    }

    public boolean isGoodConfig() {
        if (address != null ) {
            return true;
        }
        return false;
    }
}
