package com.crc.scanner.config;


import lombok.Data;

@Data
public class LvmengConfig {
    private String username;
    private String password;
    private String mode;
    Long engineId;
    private String address;

    public String getMode() {
        if (address != null) {
            if (address.toLowerCase().startsWith("https")) {
                mode = "https";
            } else {
                mode = "http";
            }
        }
        return mode;
    }

    public boolean isGoodConfig() {
        if (address != null ) {
            return true;
        }
        return false;
    }
}
