package com.crc.scanner.config;

import lombok.Data;

/**
 * 魔方对接配置类
 *
 * @Author fuzhuangzhi
 * @Date 2022/9/5 17:42
 * @Version 1.0
 **/
@Data
public class MoFangConfig {
    String address;
    String accessKey;
    String secretKey;
    // 获取下发任务时间范围 如：2022-7-20/2022-8-20
    String interval;
    Long engineId;
    String mode;

    public String getMode() {
        if (address != null) {
            if (address.toLowerCase().startsWith("https")) {
                mode = "https";
            } else {
                mode = "http";
            }
        }
        return mode;
    }

    public boolean isGoodConfig() {
        if (address != null ) {
            return true;
        }
        return false;
    }
}
