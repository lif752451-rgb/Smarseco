package com.crc.scanner.config;

import lombok.Data;


@Data
public class GobyConfig {
    String level;
    String address;
    Long engineId;
    String mode;
    public String getMode() {
        if (address != null) {
            if (address.toLowerCase().startsWith("https")) {
                mode = "https";
            } else {
                mode = "http";
            }
        }
        return mode;
    }

    public boolean isGoodConfig() {
        if (address != null ) {
            return true;
        }
        return false;
    }
}
