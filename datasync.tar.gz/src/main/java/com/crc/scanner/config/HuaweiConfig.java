package com.crc.scanner.config;


import lombok.Data;

@Data
public class HuaweiConfig {
    String username;
    String password;
    String level;
    String mode;
    Long engineId;
    String userMask;
    String address;
    public String getMode() {
        if (address != null) {
            if (address.toLowerCase().startsWith("https")) {
                mode = "https";
            } else {
                mode = "http";
            }
        }
        return mode;
    }

    public boolean isGoodConfig() {
        if (address != null ) {
            return true;
        }
        return false;
    }
}
