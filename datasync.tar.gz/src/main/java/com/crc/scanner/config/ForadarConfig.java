package com.crc.scanner.config;

import lombok.Data;

/**
 * 安恒配置
 */
@Data
public class ForadarConfig {
    String mode;
    String email;
    String secretKey;
    String address;
    Long engineId;
    String proxyIp;
    boolean proxy = false;
    int proxyPort;
    public String getMode() {
        if (address != null) {
            if (address.toLowerCase().startsWith("https")) {
                mode = "https";
            } else {
                mode = "http";
            }
        }
        return mode;
    }

    public boolean isGoodConfig() {
        if (address != null) {
            return true;
        }
        return false;
    }
}
