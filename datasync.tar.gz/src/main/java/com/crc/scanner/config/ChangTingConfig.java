package com.crc.scanner.config;

import lombok.Data;

/**
 * @ClassName ChangTingConfig
 * @Description 长亭对接配置
 * @Author fuzhuangzhi
 * @Date 2022/05/19 16:47
 * @Version 1.0
 **/
@Data
public class ChangTingConfig {
    private String address;
    private String password;
    private String username;
    String mode;
    Long engineId;
    public String getMode() {
        if (address != null) {
            if (address.toLowerCase().startsWith("https")) {
                mode = "https";
            } else {
                mode = "http";
            }
        }
        return mode;
    }

    public boolean isGoodConfig() {
        if (address != null ) {
            return true;
        }
        return false;
    }
}
