package com.crc.scanner.config;

import lombok.Data;

/**
 * 自动化分析平台
 */
@Data
public class AutoAnalyConfig {
    String userName;
    String key;
    String mode;
    String address;
    Long engineId;
    public String getMode() {
        if (address != null) {
            if (address.toLowerCase().startsWith("https")) {
                mode = "https";
            } else {
                mode = "http";
            }
        }
        return mode;
    }

    public boolean isGoodConfig() {
        if (address != null) {
            return true;
        }
        return false;
    }
}
