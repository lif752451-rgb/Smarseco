package com.crc.scanner.config;

import lombok.Data;

/**
 * 安恒配置
 */
@Data
public class AnhengConfig {
    String userName;
    String password;
    String mode;
    String type;
    String token;
    String address;
    Long engineId;
    public String getMode() {
        if (address != null) {
            if (address.toLowerCase().startsWith("https")) {
                mode = "https";
            } else {
                mode = "http";
            }
        }
        return mode;
    }

    public boolean isGoodConfig() {
        if (address != null) {
            return true;
        }
        return false;
    }
}
