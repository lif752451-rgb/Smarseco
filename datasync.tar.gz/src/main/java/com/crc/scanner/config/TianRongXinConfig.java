package com.crc.scanner.config;


import lombok.Data;

@Data
public class TianRongXinConfig {
    String username;
    String password;
    String level;
    String mode;
    Long engineId;
    String userMask;
    boolean isXc;//是否为信创版本
    String address;
    public String getMode() {
        if (address != null) {
            if (address.toLowerCase().startsWith("https")) {
                mode = "https";
            } else {
                mode = "http";
            }
        }
        return mode;
    }

    public boolean isGoodConfig() {
        if (address != null ) {
            return true;
        }
        return false;
    }
}
