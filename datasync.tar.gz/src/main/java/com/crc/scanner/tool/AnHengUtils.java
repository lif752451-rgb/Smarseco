package com.crc.scanner.tool;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONArray;
import com.alibaba.fastjson.JSONObject;
import com.crc.common.utils.*;
import com.crc.scanner.config.AnhengConfig;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.apache.http.HttpHeaders;
import org.apache.http.client.config.RequestConfig;
import org.apache.http.client.methods.CloseableHttpResponse;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.client.methods.HttpRequestBase;
import org.apache.http.entity.StringEntity;
import org.apache.http.impl.client.CloseableHttpClient;
import org.apache.http.util.EntityUtils;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

/*
 * @ClassName AnHengUtils
 * @Description 安恒工具类
 * @Author fuzhuangzhi
 * @Date 2022/05/25 11:31
 * @Version 1.0
 **/
@Slf4j
public class AnHengUtils {
    public static int MODULE_WEB = 0;
    public static int MODULE_DB = 1;
    public static int MODULE_BASELINE = 5;
    public static int MODULE_HOST = 8;

    public static String regex = "[|&` <>$\\r\\n'\"/\\\\\\[\\]{}]";

    /**
     * 登录扫描器
     */
    public static void login(AnhengConfig scannerInfo) {
        //https://10.103.23.98:8891/api/normal/token?userName=update&userCode=63590973b11235150b67ad23a871404b
        String url = scannerInfo.getAddress() + "/api/normal/token";
        String param = String.format("userName=%s&userCode=%s", scannerInfo.getUserName(), Md5Utils.hash(scannerInfo.getPassword()));
        String ret = HttpUtils.sendGet(url, param);
        JSONObject retJson = JsonUtils.parse(ret);
        /*
        {
          "code": 200,
          "msg": "",
          "subMsg": "",
          "data": {
            HttpHeaders.AUTHORIZATION: "14d65a88142b2945babcb3f38dfbe5d6"
          }
        }
         */
        if (JsonUtils.equalVal(retJson, "code", "200")) {
            JSONObject data = retJson.getJSONObject("data");
            if (data != null) {
                scannerInfo.setToken(data.getString(HttpHeaders.AUTHORIZATION));
            }
        }
        if (StringUtils.isBlank(scannerInfo.getToken())) {
            log.error("获取token失败：" + ret);
        }
    }

    /**
     * 状态标识码	状态信息
     * 1	等待调度
     * 2	正在扫描
     * 3	暂停状态
     * 4	停止状态
     * 5	结束状态
     * 6	异常状态
     */
    public static JSONObject getTaskStatus(AnhengConfig scannerInfo, int moduleId, String taskId) {
        //https://{ip}:{port}/api/normal/task/getTaskStatus?module=8&taskId=13
        String url = scannerInfo.getAddress() + "/api/normal/task/getTaskStatus";
        String param = String.format("module=%d&taskId=%s", moduleId, taskId);

        JSONObject header = new JSONObject();
        if (StringUtils.isBlank(scannerInfo.getToken())) {
            login(scannerInfo);
        }
        header.put(HttpHeaders.AUTHORIZATION, scannerInfo.getToken());

        String ret = HttpUtils.sendGet(url, param, header);
        JSONObject retJson = JsonUtils.parse(ret);
        /*
        {
          "code": 200,
          "msg": "操作成功",
          "subMsg": "",
          "data": {
            "progress": 64.0,
            "state": 3
          }
        }
         */
        if (JsonUtils.equalVal(retJson, "code", "200")) {
            JSONObject data = retJson.getJSONObject("data");
            if (data != null) {
                return data;
            }
        }
        log.error("获取进度失败：" + ret);
        return null;
    }

    public static HashMap<String, JSONObject> getPolicyList(AnhengConfig scannerInfo, int moduleId) {
        //https://{ip}:{port}/api/normal/policy/get?module=8&policyNo=&offset=0&limit=2
        String url = scannerInfo.getAddress() + "/api/normal/policy/get";
        String param = String.format("module=%d&offset=0&limit=1", moduleId);
        JSONObject header = new JSONObject();
        if (StringUtils.isBlank(scannerInfo.getToken())) {
            login(scannerInfo);
        }
        header.put(HttpHeaders.AUTHORIZATION, scannerInfo.getToken());

        String ret = HttpUtils.sendGet(url, param, header);
        /*
        {
          "code": 200,
          "msg": "操作成功",
          "subMsg": "",
          "data": {
            "policies": [],
            "count": 3
          }
        }
         */
        JSONObject dataRet = JsonUtils.parse(ret);
        JSONObject dataJson = dataRet.getJSONObject("data");
        int total = JsonUtils.getInt(dataJson, "count");
        log.error(moduleId + ",获取策略总数：" + total);
        HashMap<String, JSONObject> dataList = new HashMap<>();
        if (total > 0) {
            for (int idx = 0; idx < DataUtils.getPageCount(total, 100, 0); idx++) {
                try {
                    param = String.format("module=%d&offset=%d&limit=100", moduleId, idx);
                    ret = HttpUtils.sendGet(url, param, header);
                    dataRet = JsonUtils.parse(ret);
                    dataJson = dataRet.getJSONObject("data");
                    if (dataJson != null) {
                        JSONArray policies = dataJson.getJSONArray("policies");
                        if (policies != null) {
                            for (int i = 0; i < policies.size(); i++) {
                                JSONObject p = policies.getJSONObject(i);
                                String policyNo = JsonUtils.getStr(p, "policyNo");
                                if (StringUtils.isNotBlank(policyNo)) {
                                    dataList.put(policyNo, p);
                                } else {
                                    log.error("策略信息policyNo为空{}", JSON.toJSONString(p));
                                }
                            }
                        }
                    }
                } catch (Exception e) {
                    log.error(e.getMessage(), e);
                }
            }
        }
        return dataList;
    }

    public static JSONObject getPolicyById(AnhengConfig scannerInfo, int moduleId, String policyNo) {
        //https://{ip}:{port}/api/normal/policy/get?module=8&policyNo=&offset=1&limit=2
        String url = scannerInfo.getAddress() + "/api/normal/policy/get";
        String param = String.format("module=%d&policyNo=%s&offset=0&limit=1", moduleId, policyNo);
        JSONObject header = new JSONObject();
        if (StringUtils.isBlank(scannerInfo.getToken())) {
            login(scannerInfo);
        }
        header.put(HttpHeaders.AUTHORIZATION, scannerInfo.getToken());

        String ret = HttpUtils.sendGet(url, param, header);
        /*
        {
          "code": 200,
          "msg": "操作成功",
          "subMsg": "",
          "data": {
            "policies": [],
            "count": 3
          }
        }
         */
        JSONObject dataRet = JsonUtils.parse(ret);
        JSONObject dataJson = dataRet.getJSONObject("data");
        int total = JsonUtils.getInt(dataJson, "count");
        log.error(moduleId + ",获取策略总数：" + total);
        if (dataJson != null) {
            JSONArray policies = dataJson.getJSONArray("policies");
            if (policies != null && policies.size() > 0) {
                return policies.getJSONObject(0);
            }
        }
        return null;
    }

    public static String createWebTask(AnhengConfig scannerInfo, String taskName, String targetUrl) {
        /*
        {
            "module": 0,
            "name": "网站扫描-200",
            "policyTemplate": "快速漏洞扫描",
            "parameters": {},
            "targets": [
                {
                    "ipaddr": "http://192.168.23.177/bWAPP/login.php",
                    "parameters": {}
                }
            ]
        }
         */
        JSONObject param = new JSONObject();
        param.put("module", MODULE_WEB);
        param.put("name", taskName.replaceAll(regex,"") + "-" + IdGen.uuid());
        param.put("policyTemplate", "快速漏洞扫描");
        param.put("parameters", new JSONObject());

        List<JSONObject> targets = new ArrayList<>();
        for (String ip : targetUrl.split(",")) {
            JSONObject target = new JSONObject();
            target.put("ipaddr", ip);
            target.put("parameters", new JSONObject());
            targets.add(target);
        }

        param.put("targets", targets);
        ///api/normal/task/create
        if (StringUtils.isBlank(scannerInfo.getToken())) {
            login(scannerInfo);
        }
        String url = "/api/normal/task/create";
        String ret = null;
        CloseableHttpResponse response = null;
        try {
            response = sendPost(scannerInfo, url, param);
            if(response != null) {
                ret = DataUtils.toBodyString(response.getEntity());
            }
            log.info("{},ret={}",url,ret);
            JSONObject retJson = JsonUtils.parse(ret);
            if (JsonUtils.equalVal(retJson, "code", "200")) {
                JSONObject data = retJson.getJSONObject("data");
                if (data != null) {
                    return data.getString("taskId");
                }
            }
        } catch (Exception e) {
            log.error(e.getMessage(), e);
        } finally {
            IOUtils.close(response);
        }
        log.error("创建任务失败：" + ret);
        return null;
    }


    public static String createHostTask(AnhengConfig scannerInfo, String taskName, String targetIp) {
        if (StringUtils.isBlank(targetIp)) {
            log.error("{},扫描目标为空", taskName);
            return "";
        }
        /*
        curl --request POST \
          --url http:/// https://10.112.9.251:8891/api/normal/task/create \
          --header 'Authorization: 1181ed9fb7b93047a78db47b21d5cc83' \
          --header 'content-type: application/json' \
          --data '{
         "module": 8,
         "name": "主机扫描-1021511",
         "policyTemplate": "快速扫描",
         "parameters": {
          "DetectIssue": "true",
          "WeakPwd": "false",
          "DetectPortService": "true"
         },
         "targets": [
          {
           "ipaddr": "192.168.23.195",
           "parameters": {}
          }
         ]
        }'
         */
        JSONObject param = new JSONObject();
        param.put("module", MODULE_HOST);
        param.put("name", taskName.replaceAll(regex,"") + "-" + IdGen.uuid());
        param.put("policyTemplate", "快速扫描");

        JSONObject parameters = new JSONObject();
        parameters.put("DetectIssue", "true");
        parameters.put("WeakPwd", "false");
        parameters.put("DetectPortService", "true");
        param.put("parameters", parameters);

        List<JSONObject> targets = new ArrayList<>();
        for (String ip : targetIp.split(",")) {
            JSONObject target = new JSONObject();
            target.put("ipaddr", ip);
            target.put("parameters", new JSONObject());
            targets.add(target);
        }

        param.put("targets", targets);
        ///api/normal/task/create
        if (StringUtils.isBlank(scannerInfo.getToken())) {
            login(scannerInfo);
        }
        String url = "/api/normal/task/create";
        String ret = null;
        CloseableHttpResponse response = null;
        try {
            response = sendPost(scannerInfo, url, param);
            if(response != null) {
                ret = DataUtils.toBodyString(response.getEntity());
            }
            log.info("{},ret={}",url,ret);
            JSONObject retJson = JsonUtils.parse(ret);
            if (JsonUtils.equalVal(retJson, "code", "200")) {
                JSONObject data = retJson.getJSONObject("data");
                if (data != null) {
                    return data.getString("taskId");
                }
            }
        } catch (Exception e) {
            log.error(e.getMessage(), e);
        } finally {
            IOUtils.close(response);
        }
        log.error("创建任务失败：" + ret);
        return null;
    }

    /**
     * POST请求
     */
    public static CloseableHttpResponse sendPost(AnhengConfig scannerInfo, String url, JSONObject parameter) throws Exception {
        HttpPost httpPost = buildHttpPostReq(scannerInfo, url);
        if (httpPost == null) {
            log.error("获取httpGet null");
            return null;
        }
        setRequestConfig(httpPost);
        httpPost.setHeader(HttpHeaders.AUTHORIZATION, scannerInfo.getToken());
        httpPost.setHeader(HttpHeaders.CONTENT_TYPE, "application/json");
        httpPost.setEntity(new StringEntity(parameter.toString(),"UTF-8"));
        log.info("apiUrl:{},参数:{},token={}", url, JSONObject.toJSONString(parameter), scannerInfo.getToken());
        CloseableHttpClient httpClient = HttpFileUtils.getHttpClient();
        return httpClient.execute(httpPost);
    }

    private static HttpPost buildHttpPostReq(AnhengConfig config, String url) {
        if (config == null || StringUtils.isBlank(config.getAddress())) {
            log.error("安恒config配置为空");
            return null;
        }
        StringBuilder sb = new StringBuilder();
        String token = config.getToken();
        if (StringUtils.isBlank(token)) {
            log.error("安恒token为空");
            return null;
        }
        return new HttpPost(String.valueOf(sb.append(config.getAddress()).append(url)));
    }

    private static void setRequestConfig(HttpRequestBase httpRequestBase) {
        RequestConfig requestConfig = RequestConfig.custom().setConnectionRequestTimeout(60000)
                .setConnectTimeout(60000).setSocketTimeout(60000).build();
        httpRequestBase.setConfig(requestConfig);
    }

}
