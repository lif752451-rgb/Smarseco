package com.crc.scanner.tool;

import cn.hutool.core.util.StrUtil;
import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONArray;
import com.alibaba.fastjson.JSONObject;
import com.alibaba.fastjson.serializer.SerializerFeature;
import com.crc.common.utils.DataUtils;
import com.crc.common.utils.DateUtils;
import com.crc.common.utils.DictUtil;
import com.crc.common.utils.HttpFileUtils;
import com.crc.common.utils.IpUtils;
import com.crc.common.utils.JsonUtils;
import com.crc.scanner.config.QtConfig;
import com.crc.secface.config.GetSpringBean;
import com.crc.secface.domain.QingtengAgent;
import com.crc.secface.mapper.QingtengAgentMapper;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.codec.digest.DigestUtils;
import org.apache.commons.lang3.StringUtils;
import org.apache.http.client.config.RequestConfig;
import org.apache.http.client.methods.CloseableHttpResponse;
import org.apache.http.client.methods.HttpDelete;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.entity.StringEntity;
import org.apache.http.impl.client.CloseableHttpClient;

import java.time.Instant;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;


@Slf4j
public class QingtengUtils {
    public static List<String> getAllHostIp(String ipStr) {
        String[] ipGroups = IpUtils.getIpSegment(ipStr);
        if (ipGroups == null) {
            return new ArrayList<>();
        }
        List<String> ipList = new ArrayList<>();
        for (String ip : ipGroups) {
            if (IpUtils.isIp(ip)) {
                ipList.add(ip);
            }
        }

        return ipList;
    }

    public static boolean isWindowsAgent(QingtengAgent agent) {
        if (agent == null) {
            return false;
        }
        return "win".equalsIgnoreCase(agent.getOsVersion());
    }

    public static boolean isWindowsAgent(String agentId) {
        if (agentId == null) {
            return false;
        }
        QingtengAgentMapper d01AgentMapper = GetSpringBean.getBean(QingtengAgentMapper.class);
        QingtengAgent tmp = d01AgentMapper.selectById(agentId);
        return "win".equalsIgnoreCase(tmp.getOsVersion());
    }

    /**
     * 检测资产扫描特定漏洞检查失败的清单
     */
    public static HashMap<String, String> GetErrorHost(QtConfig scannerInfo, String jobId, String agentId) {
        HashMap<String, String> errorCheckList = new HashMap<>();
        //{"jobId":"5bcef3c67d761b31e34ec895","jobType":"2","size":2,"page":3}
        JSONObject param = new JSONObject();
        param.put("jobId", jobId);
        //作业类型：1：全局作业 2：用户作业。必
        param.put("jobType", 2);
        ///external/api/vul/poc/job/{linux|win}/error_host
        String exeUrl = "/external/api/vul/poc/job/linux/error_host";
        if (isWindowsAgent(agentId)) {
            exeUrl = "/external/api/vul/poc/job/win/error_host";
        }
        try (CloseableHttpResponse response = post(scannerInfo, exeUrl, param)) {
            int code = response.getStatusLine().getStatusCode();
            if (code == 200) {
                String GetData = DataUtils.toBodyString(response.getEntity());
                /*
                {
                    "rows": [
                        {
                            "agentId": "27b1a655e425a833",
                            "vulId": "QT042018000035",
                            "title": "Struts2 S2-056拒绝服务漏洞(CVE-2018-1327)",
                            "displayIp": "192.168.77.199",
                            "internalIp": "192.168.77.199",
                            "externalIp": null,
                            "connectionIp": "58.49.121.58",
                            "hostname": "www.mycluster.com",
                            "group": 866,
                            "remark": null,
                            "hostTagList": [],
                            "code": 1,
                            "description": "主机不在线"
                        }
                    ],
                    "total": 11,
                    "charts": {}
                }
                 */
                if (JSONObject.isValidObject(GetData)) {
                    JSONObject result = JSONObject.parseObject(GetData);
                    if (JsonUtils.getIntX(result, "total") == 0) {
                        return errorCheckList;
                    } else {
                        JSONArray rows = result.getJSONArray("rows");
                        if (rows != null && rows.size() > 0) {
                            for (int i = 0; i < rows.size(); i++) {
                                JSONObject row = rows.getJSONObject(i);
                                String vulId = JsonUtils.getStr(row, "vulId");
                                String description = JsonUtils.getStr(row, "description");
                                String title = JsonUtils.getStr(row, "title");
                                if (StringUtils.isNotBlank(vulId)) {
                                    errorCheckList.put(vulId, title + "##" + description);
                                }
                            }
                        }
                    }
                    log.error("jobId:{},执行失败：{}", jobId, JSON.toJSONString(errorCheckList));
                } else {
                    log.error("检测资产清点任务状态错误！ID：" + jobId);
                }
            }
        } catch (Exception e) {
            log.error(e.getMessage(), e);
        }
        return errorCheckList;
    }

    /**
     * 是否命中青藤自身白名单
     *
     * @param obj json
     * @return t/f
     */
    public static boolean isWhiteRuleEffect(JSONObject obj) {
        try {
            if (obj.containsKey("whiteRuleEffect") && JsonUtils.getBoolean(obj, "whiteRuleEffect")) {
                return true;
            }
        } catch (Exception e) {
            log.error(e.getMessage(), e);
        }
        return false;
    }

    /**
     * 登录扫描器
     */
    public static void login(QtConfig scannerInfo) {

        String url = scannerInfo.getAddress();
        if (StringUtils.isBlank(url)) {
            return;
        }
        //获取扫描器信息
        HttpPost httpRequest = new HttpPost(url + "/v1/api/auth");
        if (url.toLowerCase().startsWith("https")) {
            httpRequest = new HttpPost(url + "/v1/api/auth");
        }
        RequestConfig requestConfig = RequestConfig.custom()
                .setConnectTimeout(45000).setConnectionRequestTimeout(45000)
                .setSocketTimeout(45000).build();
        httpRequest.setConfig(requestConfig);
        httpRequest.setHeader("Content-Type", "application/json");
        httpRequest.setEntity(new StringEntity("{\"username\": \"" + scannerInfo.getUsername() + "\", \"password\":\"" + scannerInfo.getPassword() + "\"}", "UTF-8"));
        try (CloseableHttpClient httpClient = HttpFileUtils.getHttpClient();
             CloseableHttpResponse response = httpClient.execute(httpRequest)) {
            int code = response.getStatusLine().getStatusCode();
            String ret = DataUtils.toBodyString(response.getEntity());
            if (code == 200) {
                JSONObject result = JsonUtils.parse(ret);
                if (result.getBoolean("success")) {
                    //重新登录获取session
                    scannerInfo.setSessionid(result.getString("data"));
                } else {
                    log.error("青藤主机防护登录错误！" + ret);
                }
            } else {
                log.error("青藤主机防护登录错误！" + ret);
            }
        } catch (Exception e) {
            log.error(e.getMessage(), e);
        }
    }

    /**
     * 获取青藤基线规则清单
     *
     * @param qtConfig 扫描引擎配置
     * @return 基线列表
     */
    public static String getBaseRuleList(QtConfig qtConfig, String type, int family) {
        ///external/api/baseline/spec/rule/{linux，win}
        /*
        {
            "osType": 1,  //操作系统，必填 1 linux 2 windows
            "family": 1,  //基线类别，必填 1 系统基线 2 应用基线
            "plaform": "ubuntu-16.04", //使用系统， 系统基线时过滤
            "appId": "6871696328758afa" //应用id， 应用基线时过滤
        }
         */
        int osType = 1;
        if ("win".equalsIgnoreCase(type)) {
            osType = 2;
        }

        try (CloseableHttpResponse response = get(qtConfig, "/external/api/baseline/spec/rule/" + type + "?", "osType=" + osType + "&family=" + family)) {
            if (response == null) {
                return "";
            }
            int code = response.getStatusLine().getStatusCode();
            String ret = DataUtils.toBodyString(response.getEntity());
            if (code == 200) {
                return ret;
            } else {
                log.error("拉取青藤基线规则报错" + "/external/api/baseline/spec/rule/" + type + "?" + "osType=" + osType + "&family=" + family + "，返回=" + ret);
            }
        } catch (Exception e) {
            log.error(e.getMessage(), e);
        }

        return "";
    }

    public static int getBaselineTaskStatus(QtConfig scannerInfo, String osType, String id) {
        String os = "linux";
        if ("2".equalsIgnoreCase(osType)) {
            os = "win";
        }

        try (CloseableHttpResponse response = get(scannerInfo, "/external/api/baseline/job/" + os + "/getStatus/" + id, "")) {
            if (response == null) {
                return 0;
            }
            int code = response.getStatusLine().getStatusCode();
            String GetData = DataUtils.toBodyString(response.getEntity());
            if (code == 200) {
                JSONObject jsonObject = JsonUtils.parse(GetData);
                if (jsonObject.containsKey("status") && JsonUtils.equal(jsonObject, "status", "Success")) {
                    return 1;
                }
            } else if (code == 404) {
                return -1;
            }
        } catch (Exception e) {
            log.error(e.getMessage(), e);
        }
        return 0;
    }

    /**
     * 创建基线任务
     *
     * @param scannerInfo 引擎配置
     * @param ruleId      规则ID
     * @param isCron      是否定时
     * @param name        名称
     * @param desc        描述
     * @param agentIds    ids
     * @return Job ID
     */
    public static String createBaselineJob(QtConfig scannerInfo, String osType, String ruleId, boolean isCron, String name, String desc, List<String> agentIds) {
        String specId = "";
        try {
            JSONObject jsonObject = new JSONObject();
            jsonObject.put("name", name);
            jsonObject.put("kind", 0);
            jsonObject.put("ruleId", ruleId);
            jsonObject.put("cronEnabled", isCron);
            jsonObject.put("description", desc);
            jsonObject.put("values", agentIds);
            String os = "linux";
            if ("2".equalsIgnoreCase(osType)) {
                os = "win";
            }
            try (CloseableHttpResponse response = QingtengUtils.post(scannerInfo, "/external/api/baseline/job/" + os, jsonObject)) {
                if (response == null) {
                    return specId;
                }
                int code = response.getStatusLine().getStatusCode();
                //{"id":"624654076055e247a11f7193","status":"Success"}
                String GetData = DataUtils.toBodyString(response.getEntity());
                if (code == 200) {
                    JSONObject json = JsonUtils.parse(GetData);
                    if (json.containsKey("status") && JsonUtils.equal(json, "status", "Success")) {
                        return JsonUtils.getStr(json, "id");
                    }
                } else {
                    log.error("createBaselineJob=RET" + GetData);
                    log.error(jsonObject.toJSONString());
                }
            } catch (Exception e) {
                log.error(e.getMessage(), e);
            }
        } catch (Exception e) {
            log.error(e.getMessage(), e);
        }

        return specId;
    }

    /**
     * agentId是否存在
     *
     * @param qtConfig 扫描引擎配置
     * @return Agent信息
     */
    public static QingtengAgent getQtAgentByIp(QtConfig qtConfig, String inIp) {
        List<JSONObject> dataList = getLinuxAgentByIp(qtConfig, inIp, "linux");
        if (dataList == null) {
            dataList = new ArrayList<>();
        }
        List<JSONObject> list1 = getLinuxAgentByIp(qtConfig, inIp, "win");
        if (list1 != null) {
            dataList.addAll(list1);
        }
        QingtengAgent target = null;
        try {
            long installTimeLong = 0;
            //获取最新的 Agent
            for (JSONObject jsonData : dataList) {
                String agentId = JsonUtils.getStr(jsonData, "agentId");//业务组
                if (StringUtils.isBlank(agentId)) {
                    continue;
                }
                String qingtengAssetType = DictUtil.getDictLabel("sync_qt_asset", "qt_asset_type", "displayIp");
                String ip = JsonUtils.getStr(jsonData, qingtengAssetType);//主机IP
                if (StrUtil.isEmpty(ip)) {
                    ip = JsonUtils.getStr(jsonData, "displayIp");
                }
                if (!IpUtils.isIp(ip)) {
                    ip = JsonUtils.getStr(jsonData, "connectionIp");//主机IP
                    if (!IpUtils.isIp(ip)) {
                        continue;
                    }
                }
                String localIp = null;
                // 增加本地ip校验
                if (ip.startsWith("192.168.") || ip.startsWith("172.16.")) {
                    String connectionIp = JsonUtils.getStr(jsonData, "connectionIp");
                    localIp = ip;
                    if (IpUtils.isIp(connectionIp)) {
                        ip = connectionIp;
                        // 不允许私网ip落库后的数据不存在AgentId
                        if (inIp.equals(ip)) {
                            continue;
                        }
                    }
                }
                //由于模糊查询，需要匹配
                if (!inIp.equals(ip)) {
                    continue;
                }
                String bizGroup = JsonUtils.getStr(jsonData, "bizGroup");//业务组
                String bizGroupId = JsonUtils.getStr(jsonData, "bizGroupId");//业务组ID
                String onlineStatus = JsonUtils.getStr(jsonData, "onlineStatus");//通信状态 1 – 在线 0 - 离线
                String agentStatus = JsonUtils.getStr(jsonData, "agentStatus");//Agent状态，0-在线 1-离线 2-停用 3-删除中
                String lastOnlineTime = JsonUtils.getStr(jsonData, "lastOnlineTime");//最后在线时间，时间戳秒
                String installTime = JsonUtils.getStr(jsonData, "installTime");//安装时间，时间戳秒
                String agentVersion = JsonUtils.getStr(jsonData, "agentVersion");//agent版本
                int offlineDays = JsonUtils.getInt(jsonData, "offlineDays");//不在线天数

                //生产商
                QingtengAgent d01Agent = new QingtengAgent();
                d01Agent.setId(agentId);
                d01Agent.setIp(inIp);
                if (StringUtils.isNotBlank(localIp)) {
                    d01Agent.setLocalIp(localIp);
                }
                d01Agent.setBizGroup(bizGroup);
                d01Agent.setBizGroupId(bizGroupId);
                d01Agent.setLastOnlineTime(DateUtils.parseDateTime1(lastOnlineTime, DateUtils.DATE_FORMAT_STRING1));
                d01Agent.setInstallTime(DateUtils.parseDateTime1(installTime, DateUtils.DATE_FORMAT_STRING1));
                long tmpTime = 0;
                if (d01Agent.getInstallTime() != null) {
                    tmpTime = d01Agent.getInstallTime().getTime();
                }
                d01Agent.setOfflineDays(offlineDays);
                d01Agent.setAgentStatus(agentStatus);
                d01Agent.setAgentVersion(agentVersion);
                d01Agent.setOnlineStatus(onlineStatus);
                d01Agent.setIsCrcCloud("1");
                d01Agent.setScannerConfig(qtConfig);
                d01Agent.setWindows(false);
                d01Agent.setOsVersion(JsonUtils.getStr(jsonData, "os_type"));
                if (d01Agent.isBadStatus()) {
                    log.info("getQtAgentByIp-agent：ip={},id={},状态异常", d01Agent.getIp(), d01Agent.getId());
                    continue;
                }
                if (installTimeLong < tmpTime) {
                    target = d01Agent;
                }
            }
        } catch (Exception e) {
            log.error(e.getMessage(), e);
        }
        return target;
    }

    /**
     * onlineStatus 通信状态 1 – 在线 0 - 离线
     * agentStatus 主机状态，0-在线 1-离线 2-停用
     *
     * @param qtConfig 扫描引擎配置
     * @return Agent信息
     */
    private static List<JSONObject> getLinuxAgentByIp(QtConfig qtConfig, String inIp, String type) {
        List<JSONObject> dataList = new ArrayList<>();
        if (StringUtils.isBlank(inIp)) {
            log.error("ip 为空");
            return dataList;
        }
        try (CloseableHttpResponse response = get(qtConfig, "/external/api/assets/host/" + type + "?", "&ip=" + inIp)) {
            if (response == null) {
                return dataList;
            }
            int code = response.getStatusLine().getStatusCode();
            String ret = DataUtils.toBodyString(response.getEntity());
            if (code == 200) {
                JSONObject allJsonData = JsonUtils.parse(ret);
                if (JsonUtils.getInt(allJsonData, "total") < 1) {
                    return dataList;
                }
                JSONArray rows = allJsonData.getJSONArray("rows");
                if (rows == null || rows.size() < 1) {
                    return dataList;
                }

                for (int i = 0; i < rows.size(); i++) {
                    JSONObject jsonData = rows.getJSONObject(i);
                    jsonData.put("os_type", type);
                    dataList.add(jsonData);
                }
            } else {
                log.error(inIp + "http请求失败=" + ret);
            }
        } catch (Exception e) {
            log.error(e.getMessage(), e);
        }
        return dataList;
    }

    /**
     * onlineStatus 通信状态 1 – 在线 0 - 离线
     * agentStatus 主机状态，0-在线 1-离线 2-停用
     *
     * @param qtConfig 扫描引擎配置
     * @return Agent信息
     */
    public static QingtengAgent getAgentById(QtConfig qtConfig, String agentId) {
        QingtengAgent target = null;
        if (StringUtils.isBlank(agentId)) {
            log.error("agentId 为空");
            return target;
        }
        String type = "linux";
        if (isWindowsAgent(agentId)) {
            type = "win";
        }
        try (CloseableHttpResponse response = get(qtConfig, "/external/api/assets/host/" + type + "?", "&agentId=" + agentId)) {
            if (response == null) {
                return target;
            }
            int code = response.getStatusLine().getStatusCode();
            String ret = DataUtils.toBodyString(response.getEntity());
            if (code == 200) {
                JSONObject allJsonData = JsonUtils.parse(ret);
                if (JsonUtils.getInt(allJsonData, "total") < 1) {
                    return target;
                }
                JSONArray rows = allJsonData.getJSONArray("rows");
                if (rows == null || rows.size() < 1) {
                    return target;
                }

                long installTimeLong = 0;
                for (int i = 0; i < rows.size(); i++) {
                    JSONObject jsonData = rows.getJSONObject(i);

                    String qingtengAssetType = DictUtil.getDictLabel("sync_qt_asset", "qt_asset_type", "displayIp");
                    String ip = JsonUtils.getStr(jsonData, qingtengAssetType);//主机IP
                    if (StrUtil.isEmpty(ip)) {
                        ip = JsonUtils.getStr(jsonData, "displayIp");
                    }
                    if (!IpUtils.isIp(ip)) {
                        ip = JsonUtils.getStr(jsonData, "connectionIp");//主机IP
                        if (!IpUtils.isIp(ip)) {
                            continue;
                        }
                    }
                    String localIp = null;
                    // 增加本地ip校验
                    if (ip.startsWith("192.168.") || ip.startsWith("172.16.")) {
                        localIp = jsonData.getString("local_ip");
                        String connectionIp = JsonUtils.getStr(jsonData, "connectionIp");
                        if (IpUtils.isIp(connectionIp)) {
                            ip = connectionIp;
                        }
                    }
                    String bizGroup = JsonUtils.getStr(jsonData, "bizGroup");//业务组
                    String bizGroupId = JsonUtils.getStr(jsonData, "bizGroupId");//业务组ID
                    String onlineStatus = JsonUtils.getStr(jsonData, "onlineStatus");//通信状态 1 – 在线 0 - 离线
                    String agentStatus = JsonUtils.getStr(jsonData, "agentStatus");//Agent状态，0-在线 1-离线 2-停用 3-删除中
                    String lastOnlineTime = JsonUtils.getStr(jsonData, "lastOnlineTime");//最后在线时间，时间戳秒
                    String installTime = JsonUtils.getStr(jsonData, "installTime");//安装时间，时间戳秒
                    String agentVersion = JsonUtils.getStr(jsonData, "agentVersion");//agent版本
                    int offlineDays = JsonUtils.getInt(jsonData, "offlineDays");//不在线天数

                    //生产商
                    QingtengAgent d01Agent = new QingtengAgent();
                    d01Agent.setId(agentId);
                    d01Agent.setIp(ip);
                    // 私网IP
                    if (StringUtils.isNotBlank(localIp)) {
                        d01Agent.setLocalIp(localIp);
                    }
                    d01Agent.setBizGroup(bizGroup);
                    d01Agent.setBizGroupId(bizGroupId);
                    d01Agent.setLastOnlineTime(DateUtils.parseDateTime1(lastOnlineTime, DateUtils.DATE_FORMAT_STRING1));
                    d01Agent.setInstallTime(DateUtils.parseDateTime1(installTime, DateUtils.DATE_FORMAT_STRING1));
                    long tmpTime = 0;
                    if (d01Agent.getInstallTime() != null) {
                        tmpTime = d01Agent.getInstallTime().getTime();
                    }
                    d01Agent.setOfflineDays(offlineDays);
                    d01Agent.setAgentStatus(agentStatus);
                    d01Agent.setAgentVersion(agentVersion);
                    d01Agent.setOnlineStatus(onlineStatus);
                    d01Agent.setIsCrcCloud("1");
                    d01Agent.setScannerConfig(qtConfig);
                    d01Agent.setWindows(false);
                    d01Agent.setOsVersion(type);
                    /*if (d01Agent.isBadStatus()) {
                        log.info("getAgentById-agent：ip={},id={},状态异常", d01Agent.getIp(), d01Agent.getId());
                        continue;
                    }*/
                    if (installTimeLong < tmpTime) {
                        target = d01Agent;
                    }
                }
            } else {
                log.error(agentId + "http请求失败=" + ret);
            }
        } catch (Exception e) {
            log.error(e.getMessage(), e);
        }
        return target;
    }

    /**
     * 创建基线任务
     *
     * @param scannerInfo 扫描引擎配置
     * @return 任务信息
     */
    public static String exeBaselineJob(QtConfig scannerInfo, String osType, String specId) {
        ///external/api/baseline/job/{linux，win}/execute
        try {
            if (StringUtils.isBlank(specId)) {
                return "";
            }
            JSONObject jsonObject = new JSONObject();
            jsonObject.put("specId", specId);
            String os = "linux";
            if ("2".equalsIgnoreCase(osType)) {
                os = "win";
            }
            //JsonUtils.print(jsonObject);
            try (CloseableHttpResponse response = QingtengUtils.post(scannerInfo, "/external/api/baseline/job/" + os + "/execute", jsonObject)) {
                if (response == null) {
                    return "";
                }
                int code = response.getStatusLine().getStatusCode();
                String GetData = DataUtils.toBodyString(response.getEntity());
                log.info("exeBaselineJob=" + GetData);
                if (code == 200) {
                    JSONObject json = JsonUtils.parse(GetData);
                    if (json.containsKey("status") && JsonUtils.equal(json, "status", "Success")) {
                        return JsonUtils.getStr(json, "id");
                    }
                }
            } catch (Exception e) {
                log.error(e.getMessage(), e);
            }
        } catch (Exception e) {
            log.error(e.getMessage(), e);
        }

        return "";
    }

    /**
     * 获取扫描插件
     */
    public static JSONArray GetRuleList(QtConfig scannerInfo, QingtengAgent agent) {
        JSONArray RuleList = new JSONArray();

        /**
         * GET /external/api/vul/poc/job/rule_list --linux
         * GET /external/api/vul/poc/job/win/rule_list --windows
         */
        String url = "/external/api/vul/poc/job/rule_list";
        if (isWindowsAgent(agent)) {
            url = "/external/api/vul/poc/job/win/rule_list";
        }
        try (CloseableHttpResponse response = get(scannerInfo, url, "")) {
            if (response == null) {
                return RuleList;
            }
            int code = response.getStatusLine().getStatusCode();
            if (code == 200) {
                String GetData = DataUtils.toBodyString(response.getEntity());
                JSONObject result = JsonUtils.parse(GetData);
                JSONArray rows = result.getJSONArray("rows");
                for (int i = 0; i < rows.size(); i++) {
                    JSONObject raw = new JSONObject();
                    JSONObject params = new JSONObject();
                    raw.put("vulId", rows.getJSONObject(i).getString("vulId"));
                    if (rows.getJSONObject(i).getJSONArray("permitExecuteTypes").size() > 1) {
                        JSONArray permitExecuteTypes = new JSONArray();
                        permitExecuteTypes.add(rows.getJSONObject(i).getJSONArray("permitExecuteTypes").get(1));
                        raw.put("executeTypes", permitExecuteTypes);
                    } else {
                        raw.put("executeTypes", rows.getJSONObject(i).getJSONArray("permitExecuteTypes"));
                    }
                    if (rows.getJSONObject(i).getJSONArray("inputSchemas").size() > 0) {
                        params.put(rows.getJSONObject(i).getJSONArray("inputSchemas").getJSONObject(0).getString("field"), rows.getJSONObject(i).getJSONArray("inputSchemas").getJSONObject(0).getString("defaultValue"));
                    }
                    raw.put("params", params);
                    RuleList.add(raw);
                }
            } else {
                log.error("获取青藤POC规则清点失败");
            }
        } catch (Exception e) {
            log.error(e.getMessage(), e);
        }
        return RuleList;
    }

    /**
     * 添加扫描任务,返回作业id
     */
    public static String AddTask(QtConfig scannerInfo, String Name, QingtengAgent agent) {
        String id = "";
        try {
            JSONObject Parameter = new JSONObject();
            Parameter.put("name", Name);
            Parameter.put("cronEnabled", false);
            Parameter.put("status", true);
            JSONObject realm = new JSONObject();
            realm.put("agents", Collections.singletonList(agent.getId()));
            realm.put("type", 1);
            Parameter.put("realm", realm);
            Parameter.put("realmName", "已选择1台主机");
            Parameter.put("remark", "CRC_AUTO");
            Parameter.put("pocTaskCreateParams", GetRuleList(scannerInfo, agent));
            ///external/api/vul/poc/job/{linux|win}/add
            String url = "/external/api/vul/poc/job/linux/add";
            if (isWindowsAgent(agent)) {
                url = "/external/api/vul/poc/job/win/add";
            }
            try (CloseableHttpResponse response = post(scannerInfo, url, Parameter)) {
                if (response == null) {
                    return id;
                }
                int code = response.getStatusLine().getStatusCode();
                String GetData = DataUtils.toBodyString(response.getEntity());
                if (code == 200 || code == 500) {
                    if (JSONObject.isValidObject(GetData)) {
                        JSONObject result = JsonUtils.parse(GetData);
                        if (result.containsKey("errorMessage") &&
                                result.getString("errorMessage").contains("已被删除")) {
                            id = "999";
                        }
                        if (result.containsKey("id")) {
                            //执行扫描任务
                            JSONObject Parameter_B = new JSONObject();
                            Parameter_B.put("jobId", result.getString("id"));
                            Parameter_B.put("jobType", 2);
                            ///external/api/vul/poc/job/{linux|win}/execute
                            String exeUrl = "/external/api/vul/poc/job/linux/execute";
                            if (isWindowsAgent(agent)) {
                                exeUrl = "/external/api/vul/poc/job/win/execute";
                            }
                            try (CloseableHttpResponse response_B = post(scannerInfo, exeUrl, Parameter_B)) {
                                if (response_B == null) {
                                    log.error(Name + "->任务报错:" + result.getString("id"));
                                    return id;
                                }
                                String GetData_B = DataUtils.toBodyString(response_B.getEntity());
                                if (JSONObject.isValidObject(GetData_B)) {
                                    JSONObject result_B = JsonUtils.parse(GetData_B);
                                    if (result_B.containsKey("errorMessage") && result_B.getString("errorMessage").contains("未发现在线")) {
                                        id = "666";
                                    }
                                    //添加成功
                                    if (result_B.containsKey("flag") && result_B.getBoolean("flag")) {
                                        id = result.getString("id");
                                    }
                                }
                            } catch (Exception e) {
                                log.error(e.getMessage(), e);
                            }
                        }
                    }
                } else {
                    log.error(Name + "->任务报错:" + GetData);
                }
            } catch (Exception e) {
                log.error(e.getMessage(), e);
            }
        } catch (Exception e) {
            log.error(e.getMessage(), e);
        }
        return id;
    }

    /**
     * 获取扫描任务数据
     */
    public static JSONArray GetTask(QtConfig scanInfo, String jobId, String agentId) {
        JSONArray data = new JSONArray();
        try {
            JSONObject Parameter = new JSONObject();
            Parameter.put("jobId", jobId);
            Parameter.put("jobType", 2);
            Parameter.put("page", 0);
            Parameter.put("size", 500);//默认情况下一个任务估计就几十个漏洞，这是个坑
            //POST /external/api/vul/poc/job/{linux|win}/result_detail
            String exeUrl = "/external/api/vul/poc/job/linux/result_detail";
            if (isWindowsAgent(agentId)) {
                exeUrl = "/external/api/vul/poc/job/win/result_detail";
            }
            try (CloseableHttpResponse response = post(scanInfo, exeUrl, Parameter)) {
                if (response == null) {
                    return data;
                }
                int code = response.getStatusLine().getStatusCode();
                if (code == 200) {
                    String GetData = DataUtils.toBodyString(response.getEntity());
                    if (JSONObject.isValidObject(GetData)) {
                        JSONObject result = JsonUtils.parse(GetData);
                        //返回漏洞为0
                        if (result.getInteger("total") == 0) {
                            return data;
                        }
                        return result.getJSONArray("rows");
                    }
                } else {
                    log.error("获取扫描任务数据错误！ID：" + jobId);
                }
            } catch (Exception e) {
                log.error(e.getMessage(), e);
            }
        } catch (Exception e) {
            log.error(e.getMessage(), e);
        }
        return data;
    }

    /**
     * 获取扫描任务基本信息(是否存在失败主机)
     */
    public static Boolean GetTaskStats(QtConfig scannerInfo, String jobId, String agentId) {
        JSONObject Parameter = new JSONObject();
        Parameter.put("jobId", jobId);
        Parameter.put("jobType", 2);
        String exeUrl = "/external/api/vul/poc/job/linux/stats";
        if (isWindowsAgent(agentId)) {
            exeUrl = "/external/api/vul/poc/job/win/stats";
        }
        try (CloseableHttpResponse response = post(scannerInfo, exeUrl, Parameter)) {
            if (response == null) {
                return false;
            }
            int code = response.getStatusLine().getStatusCode();
            if (code == 200) {
                String GetData = DataUtils.toBodyString(response.getEntity());
                JSONObject result = JsonUtils.parse(GetData);
                if ("3".equals(result.getString("executeStatus")) && result.getIntValue("failedHostCount") == 0) {
                    // 执行成功且不存在
                    return true;
                }
            } else {
                log.error("获取扫描任务基本数据错误！ID：" + jobId);
            }
        } catch (Exception e) {
            log.error(e.getMessage(), e);
        }
        return false;
    }

    /**
     * 获取扫描任务状态
     */
    public static int GetTaskStatus(QtConfig scannerInfo, String jobId, String agentId) {
        if ("999".equals(jobId)) {
            return 1;
        }
        JSONObject Parameter = new JSONObject();
        Parameter.put("jobId", jobId);
        Parameter.put("jobType", 2);
        String exeUrl = "/external/api/vul/poc/job/linux/status";
        if (isWindowsAgent(agentId)) {
            exeUrl = "/external/api/vul/poc/job/win/status";
        }
        try (CloseableHttpResponse response = post(scannerInfo, exeUrl, Parameter)) {
            if (response == null) {
                return 0;
            }
            int code = response.getStatusLine().getStatusCode();
            String GetData = DataUtils.toBodyString(response.getEntity());
            JSONObject result = JsonUtils.parse(GetData);
            if (code == 200) {
                if (JSONObject.isValidObject(GetData)) {
                    if (result.containsKey("status") && "Success".equalsIgnoreCase(result.getString("status"))) {
                        return 1;
                    }
                    //{"id":"631fd17a26d3a7c79fabda7d","status":"Failed"}
                    if (result.containsKey("status") && "Failed".equalsIgnoreCase(result.getString("status"))) {
                        return 2;
                    }
                    //临时 hejs
                    //return true;
                }
            } else {
                JSONObject result_B = JsonUtils.parse(GetData);
                if (result_B.containsKey("errorMessage")) {
                    if (result_B.getString("errorMessage").contains("未发现在线")) {
                        return -1;
                    }
                    if (result_B.getString("errorMessage").contains("数据不存在")) {
                        return -2;
                    }
                } else {
                    log.error("GetTaskStatus返回错误状态：" + GetData);
                }
            }
        } catch (Exception e) {
            log.error(e.getMessage(), e);
        }
        return 0;
    }

    /**
     * 检测资产清点任务状态
     */
    public static boolean getAssetsTaskStatus(QtConfig scannerInfo, String jobId) {
        if ("999".equals(jobId)) {
            return true;
        }
        try {
            //GET /external/api/assets/refreshjob/{jobId}
            CloseableHttpResponse response = get(scannerInfo, "/external/api/assets/refreshjob/" + jobId, "");
            if (response == null) {
                return false;
            }
            int code = response.getStatusLine().getStatusCode();
            if (code == 200) {
                String GetData = DataUtils.toBodyString(response.getEntity());
                if (JSONObject.isValidObject(GetData)) {
                    JSONObject result = JsonUtils.parse(GetData);
                    if (result.containsKey("status") && "Success".equalsIgnoreCase(result.getString("status"))) {
                        return true;
                    }
                } else {
                    log.error("检测资产清点任务状态错误！ID：" + jobId);
                }
            }
        } catch (Exception e) {
            log.error(e.getMessage(), e);
        }
        return false;
    }

    public static boolean getLoginStatus(QtConfig scannerInfo) {
        JSONObject sessionid = JsonUtils.parse(scannerInfo.getSessionid());
        return !StringUtils.isNotBlank(JsonUtils.getStr(sessionid, "comId")) || !StringUtils.isNotBlank(JsonUtils.getStr(sessionid, "jwt"));
    }

    /**
     * Get请求
     */
    public static CloseableHttpResponse get(QtConfig scannerInfo, String apiUrl, String param) throws Exception {
        //获取扫描器信息
        JSONObject sessionid = JsonUtils.parse(scannerInfo.getSessionid());
        if (sessionid == null || !sessionid.containsKey("comId")) {
            login(scannerInfo);
            sessionid = JsonUtils.parse(scannerInfo.getSessionid());
        }
        if (param == null) {
            param = "";
        }
        param = DataUtils.parseParam(param);
        String timestamp = String.valueOf(Instant.now().toEpochMilli() / 1000L);
        String sign = sessionid.getString("comId") + param.replace("=", "").replace("&", "")
                + timestamp + sessionid.getString("signKey");

        String url = scannerInfo.getAddress();
        HttpGet httpRequest = new HttpGet(url + apiUrl + param);
        RequestConfig requestConfig = RequestConfig.custom()
                .setConnectTimeout(60000).setConnectionRequestTimeout(60000)
                .setSocketTimeout(60000).build();
        httpRequest.setConfig(requestConfig);
        log.info(url + apiUrl + " " + param);
        //header('Content-type: application/json;charset=utf-8');
        httpRequest.setHeader("Content-Type", "application/json");
        httpRequest.setHeader("timestamp", timestamp);
        httpRequest.setHeader("comId", sessionid.getString("comId"));
        httpRequest.setHeader("Authorization", "Bearer " + sessionid.getString("jwt"));
        httpRequest.setHeader("sign", DigestUtils.sha1Hex(sign));
        //System.out.println(httpRequest.getURI());

        CloseableHttpClient httpClient = HttpFileUtils.getHttpClient();
        return httpClient.execute(httpRequest);
    }

    /**
     * Delete请求
     */
    public static CloseableHttpResponse delete(QtConfig scannerInfo, String apiUrl, String Parameter) throws Exception {
        //获取扫描器信息
        JSONObject sessionid = JsonUtils.parse(scannerInfo.getSessionid());
        String timestamp = String.valueOf(Instant.now().toEpochMilli() / 1000L);
        String sign = sessionid.getString("comId") + Parameter.replace("=", "").replace("&", "")
                + timestamp + sessionid.getString("signKey");
        String url = scannerInfo.getAddress();
        HttpDelete httpRequest = new HttpDelete(url + apiUrl + Parameter);
        if (url.toLowerCase().startsWith("https")) {
            httpRequest = new HttpDelete(url + apiUrl + Parameter);
        }
        RequestConfig requestConfig = RequestConfig.custom()
                .setConnectTimeout(45000).setConnectionRequestTimeout(45000)
                .setSocketTimeout(45000).build();
        httpRequest.setConfig(requestConfig);
        httpRequest.setHeader("Content-Type", "application/json");
        httpRequest.setHeader("timestamp", timestamp);
        httpRequest.setHeader("comId", sessionid.getString("comId"));
        httpRequest.setHeader("Authorization", "Bearer " + sessionid.getString("jwt"));
        httpRequest.setHeader("sign", DigestUtils.sha1Hex(sign));


        CloseableHttpClient httpClient = HttpFileUtils.getHttpClient();
        return httpClient.execute(httpRequest);
    }

    /**
     * post请求
     */
    public static CloseableHttpResponse post(QtConfig scannerInfo, String apiUrl, JSONObject param) throws Exception {
        //获取扫描器信息
        JSONObject sessionid = JsonUtils.parse(scannerInfo.getSessionid());
        if (sessionid == null || !sessionid.containsKey("comId")) {
            login(scannerInfo);
            sessionid = JsonUtils.parse(scannerInfo.getSessionid());
        }
        if (sessionid == null || !sessionid.containsKey("comId")) {
            log.error("青藤登陆获取token失败");
            return null;
        }
        String timestamp = String.valueOf(Instant.now().toEpochMilli() / 1000L);
        //签名
        String sign = "";
        if (param == null || param.size() < 1) {
            sign = JsonUtils.getStr(sessionid, "comId")
                    + timestamp + JsonUtils.getStr(sessionid, "signKey");
        } else {
            sign = JsonUtils.getStr(sessionid, "comId") + JSONObject.toJSONString(param, SerializerFeature.MapSortField)
                    + timestamp + JsonUtils.getStr(sessionid, "signKey");
        }
        //发送请求
        String url = scannerInfo.getAddress();
        HttpPost httpRequest = new HttpPost(url + apiUrl);
        if (url.toLowerCase().startsWith("https")) {
            httpRequest = new HttpPost(url + apiUrl);
        }
        if (param == null || param.size() < 1) {
            log.info(url + apiUrl);
        } else {
            log.info(url + apiUrl + ",参数：" + DataUtils.getShorter(JSON.toJSONString(param), 200));
        }
        RequestConfig requestConfig = RequestConfig.custom()
                .setConnectTimeout(120000).setConnectionRequestTimeout(120000)
                .setSocketTimeout(120000).build();
        httpRequest.setConfig(requestConfig);
        httpRequest.setHeader("Content-Type", "application/json");
        httpRequest.setHeader("timestamp", timestamp);
        httpRequest.setHeader("comId", JsonUtils.getStr(sessionid, "comId"));
        httpRequest.setHeader("Authorization", "Bearer " + JsonUtils.getStr(sessionid, "jwt"));
        httpRequest.setHeader("sign", DigestUtils.sha1Hex(sign));
        if (param != null && param.size() > 0) {
            httpRequest.setEntity(new StringEntity(JSONObject.toJSONString(param, SerializerFeature.MapSortField), "UTF-8"));
        }
        CloseableHttpClient httpClient = HttpFileUtils.getHttpClient();
        return httpClient.execute(httpRequest);
    }

    public static String AddWeakPwdTask(QtConfig scannerInfo, String name, QingtengAgent agent) {
        String id = "";
        try {
            String type = agent.getOsVersion();
            JSONObject param = new JSONObject();
            param.put("type", 1);
            param.put("ip", agent.getIp());
            param.put("agentIds", Collections.singletonList(agent.getId()));
            param.put("group", new ArrayList<>());
            try (CloseableHttpResponse response = QingtengUtils.post(scannerInfo, "/external/api/vul/weakpwd/" + type + "/check", param)) {
                if (response == null) {
                    return id;
                }
                int code = response.getStatusLine().getStatusCode();
                String GetData = DataUtils.toBodyString(response.getEntity());
                if (code == 200 || code == 500) {
                    if (JSONObject.isValidObject(GetData)) {
                        JSONObject result = JsonUtils.parse(GetData);

                        if (result.containsKey("id")) {
                            //执行扫描任务
                            return result.getString("id");
                        }
                        if (result.containsKey("errorMessage") &&
                                result.getString("errorMessage").contains("已被删除")) {
                            id = "999";
                        }
                    }
                } else {
                    log.error(name + "->任务报错:" + GetData);
                }
            } catch (Exception e) {
                log.error(e.getMessage(), e);
            }
        } catch (Exception e) {
            log.error(e.getMessage(), e);
        }
        return id;
    }

    public static int GetWeakTaskStatus(QtConfig scannerInfo, QingtengAgent agent) {
        //GET  /external/api/vul/weakpwd/{linux|win}/check/status
        String exeUrl = "/external/api/vul/weakpwd/linux/check/status";
        if (isWindowsAgent(agent)) {
            exeUrl = "/external/api/vul/weakpwd/win/check/status";
        }
        String id = "";
        try (CloseableHttpResponse response = QingtengUtils.get(scannerInfo, exeUrl, null)) {
            if (response == null) {
                return 0;
            }
            int code = response.getStatusLine().getStatusCode();
            String GetData = DataUtils.toBodyString(response.getEntity());
            JSONObject result = JsonUtils.parse(GetData);
            if (code == 200) {
                if (JSONObject.isValidObject(GetData)) {
                    if (result.containsKey("status") && "Success".equalsIgnoreCase(result.getString("status"))) {
                        return 1;
                    }
                    //{"id":"631fd17a26d3a7c79fabda7d","status":"Failed"}
                    if (result.containsKey("status") && "Failed".equalsIgnoreCase(result.getString("status"))) {
                        log.error("上次扫描失败！");
                        return 2;
                    }
                }
            } else {
                JSONObject result_B = JsonUtils.parse(GetData);
                if (result_B.containsKey("errorMessage") && (result_B.getString("errorMessage").contains("未发现在线") || result_B.getString("errorMessage").contains("数据不存在"))) {
                    return -1;
                } else {
                    log.error("GetTaskStatus返回错误状态：" + GetData);
                }
            }
        } catch (Exception e) {
            log.error(e.getMessage(), e);
        }
        return 0;
    }
}
