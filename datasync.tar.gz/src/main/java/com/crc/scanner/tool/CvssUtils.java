package com.crc.scanner.tool;

import com.crc.common.cvss.Cvss;
import com.crc.common.cvss.Score;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;

@Slf4j
public class CvssUtils {
    public static String getScore(String vector) {
        try {
            if (StringUtils.isBlank(vector)) {
                return "0";
            }
            Cvss cvss = Cvss.fromVector(vector);
            Score score = cvss.calculateScore();
            return String.valueOf(score.getBaseScore());
        } catch (Exception e) {
            log.error(e.getMessage(), e);
        }
        return "0";
    }
}
