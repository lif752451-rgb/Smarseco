package com.crc.scanner.tool;

import com.alibaba.fastjson.JSONArray;
import com.alibaba.fastjson.JSONObject;
import com.crc.common.utils.DictUtil;
import com.crc.common.utils.HttpUtils;
import com.crc.common.utils.JsonUtils;
import com.crc.scanner.config.JtConfig;
import com.crc.secface.domain.SysDictData;
import com.crc.sync.cmdb.JiaotuCmdbSync;
import com.crc.sync.config.SyncSecConstants;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;

import java.util.ArrayList;
import java.util.List;

@Slf4j
public class JiaotuUtils {

    public static String createVulTask(JtConfig scannerInfo, String taskName, List<String> uuids,List<String> ips) {
        ///kernelApi/kernelScanSrv/seTaskController/scanVulnerabilityTask
        /*
        {
        "token":"XXXXXXXXXXXXXXXXXXXXXXXXXXXX",
        "machineUuids":[
        "f6ad9a03d02ea06830ad93346fd249e2"
        ],
        "itemIds":[
        4002,
        4004,
        4005,
        4006
        ],
        "timeout":5,
        "subTaskCount":5 }
         */
        String url = scannerInfo.getAddress();
        String apiUrl = url + "/kernelApi/kernelScanSrv/seTaskController/scanVulnerabilityTask";
        JSONObject param = new JSONObject();
        param.put("token", JiaotuCmdbSync.getToken(scannerInfo));
        param.put("machineUuids", uuids);
        param.put("hostIps", ips);
        param.put("timeout", 10);

        String ret = HttpUtils.sendPost(apiUrl, param.toJSONString());
        JSONObject json = JsonUtils.parse(ret);
        try {
            if (json.containsKey("code") && JsonUtils.equal(json, "code", "1")) {
                JSONObject data = json.getJSONObject("data");
                return JsonUtils.getStr(data, "taskUuid");
            } else {
                log.error(taskName + " ret=" + ret);
            }
        } catch (Exception e) {
            log.error(e.getMessage(), e);
        }
        return "";
    }

    public static String createCrackTask(JtConfig scannerInfo, String taskName, List<String> ips) {
        ///api/scanSrv/weakPasswordController/scanWeakPasswordTask
        /*
        {
        "token":"XXXXXXXXXXXXXXXXXXXXXXXXXXXX",
        "machineUuids":[
        "f6ad9a03d02ea06830ad93346fd249e2"
        ],
        "itemIds":[
        4002,
        4004,
        4005,
        4006
        ],
        "timeout":5,
        "subTaskCount":5 }
         */
        String url = scannerInfo.getAddress();
        String apiUrl = url + "/api/scanSrv/weakPasswordController/scanWeakPasswordTask";
        JSONObject param = new JSONObject();
        param.put("token", JiaotuCmdbSync.getToken(scannerInfo));
        param.put("hostIps", ips);
        param.put("itemIds", getItemList(scannerInfo));
        List<String> pl = new ArrayList<>();
        pl.add("admin");
        pl.add("111111");
        pl.add("123456");
        pl.add("password");

        SysDictData dict = DictUtil.getDictByValue(SyncSecConstants.SYNC_SEC_CONFIG, "weak_pass_list");
        if (dict != null) {
            if (StringUtils.isNotBlank(dict.getRemark())) {
                for (String p : dict.getRemark().split(",")) {
                    if (StringUtils.isNotBlank(p)) {
                        pl.add(p);
                    }
                }
            }
        }

        param.put("weakPasswords", pl);
        param.put("timeout", 10);

        String ret = HttpUtils.sendPost(apiUrl, param.toJSONString());
        JSONObject json = JsonUtils.parse(ret);
        try {
            if (json.containsKey("code") && JsonUtils.equal(json, "code", "1")) {
                JSONObject data = json.getJSONObject("data");
                return JsonUtils.getStr(data, "taskUuid");
            } else {
                log.error(taskName + " ret=" + ret);
            }
        } catch (Exception e) {
            log.error(e.getMessage(), e);
        }
        return "";
    }

    /**
     * 1-运行中，2-完成，3-停止
     * @param scannerInfo
     * @param taskName
     * @param taskUuid
     * @return
     */
    public static JSONObject getTaskNgsocStatus(JtConfig scannerInfo, String taskName, String taskUuid) {
        String url = scannerInfo.getAddress();
        String apiUrl = url + "/api/scanSrv/weakPasswordController/getSskTaskStatus";
        JSONObject param = new JSONObject();
        param.put("token", JiaotuCmdbSync.getToken(scannerInfo));
        param.put("taskUuid", taskUuid);
        /**
         *  {
         * "code":"1",
         * "msg":"成功",
         * "data":{
         * 	"machineTotal":2,
         * 	"machineCompletions":1,
         * 	"status":1
         * 	  }
         * }
         */
        String ret = HttpUtils.sendPost(apiUrl, param.toJSONString());
        try {
            JSONObject json = JsonUtils.parse(ret);
            if (json.containsKey("code") && JsonUtils.equal(json, "code", "1")) {
                return json.getJSONObject("data");
            } else {
                log.error(taskName + " ret=" + ret);
            }

        } catch (Exception e) {
            log.error(e.getMessage(), e);
        }
        return null;
    }

    public static JSONObject getTaskStatus(JtConfig scannerInfo, String taskName, String taskUuid) {
        String url = scannerInfo.getAddress();
        String apiUrl = url + "/kernelApi/kernelScanSrv/seTaskController/getTaskStatus";
        JSONObject param = new JSONObject();
        param.put("token", JiaotuCmdbSync.getToken(scannerInfo));
        param.put("taskUuid", taskUuid);
        //{
        //    "token":"XXXXXXXXXXXXXXXXXXXXXXXXXXXX",
        //    "taskUuid":"2d27b61e6d00472db66e14e7742856fa"
        //}
        String ret = HttpUtils.sendPost(apiUrl, param.toJSONString());
        try {
            JSONObject json = JsonUtils.parse(ret);
            if (json.containsKey("code") && JsonUtils.equal(json, "code", "1")) {
                return json.getJSONObject("data");
            } else {
                log.error(taskName + " ret=" + ret);
            }

        } catch (Exception e) {
            log.error(e.getMessage(), e);
        }
        return null;
    }

    public static JSONArray getNgsocTask(JtConfig scannerInfo, String taskName, String taskUuid, String ip) {
        String url = scannerInfo.getAddress();
        String apiUrl = url + "/api/scanSrv/weakPasswordController/scanResults";
        JSONObject param = new JSONObject();
        param.put("token", JiaotuCmdbSync.getToken(scannerInfo));
        param.put("taskUuid", taskUuid);
        List<String> pl = new ArrayList<>();
        pl.add("admin");
        pl.add("111111");
        pl.add("123456");
        pl.add("password");

        SysDictData dict = DictUtil.getDictByValue(SyncSecConstants.SYNC_SEC_CONFIG, "weak_pass_list");
        if (dict != null) {
            if (StringUtils.isNotBlank(dict.getRemark())) {
                for (String p : dict.getRemark().split(",")) {
                    if (StringUtils.isNotBlank(p)) {
                        pl.add(p);
                    }
                }
            }
        }
        param.put("weakPwd", pl);
        param.put("hostIp", ip);
        /**
         * {
         * "token":"24c980389873439296fac2255c0924ca",
         * "weakPwd":["123456"],
         * "taskUuid":"9d17331caf0c415e96aba3f1673b6412",
         * "hostIp":"12.12.12.12"
         * }
         */
        String ret = HttpUtils.sendPost(apiUrl, param.toJSONString());
        try {
            JSONObject json = JsonUtils.parse(ret);
            if (json.containsKey("code") && JsonUtils.equal(json, "code", "1")) {
                return json.getJSONArray("data");
            } else {
                log.error(taskName + " ret=" + ret);
            }
        } catch (Exception e) {
            log.error(e.getMessage(), e);
        }
        return null;
    }

    public static JSONArray getTask(JtConfig scannerInfo, String taskName, String taskUuid, String uuid) {
        String url = scannerInfo.getAddress();
        String apiUrl = url + "/kernelApi/kernelScanSrv/seTaskController/scanResults";
        JSONObject param = new JSONObject();
        param.put("token", JiaotuCmdbSync.getToken(scannerInfo));
        param.put("taskUuid", taskUuid);
        param.put("machineUuid", uuid);
        //{
        //    "token":"XXXXXXXXXXXXXXXXXXXXXXXXXXXX",
        //    "taskUuid":"2d27b61e6d00472db66e14e7742856fa"
        //"machineUuid":"ef93fd43f2306e96c6f233f769e8b4bd"
        //}
        String ret = HttpUtils.sendPost(apiUrl, param.toJSONString());
        try {
            JSONObject json = JsonUtils.parse(ret);
            if (json.containsKey("code") && JsonUtils.equal(json, "code", "1")) {
                return json.getJSONArray("data");
            } else {
                log.error(taskName + " ret=" + ret);
            }
        } catch (Exception e) {
            log.error(e.getMessage(), e);
        }
        return null;
    }

    public static String getAgentUuidByIp(JtConfig scannerInfo, String ip) {
        String url = scannerInfo.getAddress();
        String apiUrl = url + "/api/assetSrv/zcMachineController/queryMachineUuidByIp";
        JSONObject param = new JSONObject();
        param.put("token", JiaotuCmdbSync.getToken(scannerInfo));
        param.put("hostIp", ip);
        /**
         * {
         * "code":"1",
         * "msg":"成功",
         * "data":{
         * "machineUuid":"6a26797eb4474a8f99c37d8d5272f29a"
         * }
         * }
         */
        String ret = HttpUtils.sendPost(apiUrl, param.toJSONString());
        try {
            JSONObject json = JsonUtils.parse(ret);
            if (json.containsKey("code") && JsonUtils.equal(json, "code", "1")) {
                if (json.containsKey("data")) {
                    return JsonUtils.getStr(json.getJSONObject("data"), "machineUuid");
                }else {
                    log.error("调用结果报错：" + ret);
                }
            } else {
                log.error("调用结果报错：" + ret);
            }
        } catch (Exception e) {
            log.error(e.getMessage(), e);
        }
        return null;
    }

    public static JSONObject getAgentByIp(JtConfig scannerInfo, String ip) {
        String url = scannerInfo.getAddress();
        String apiUrl = url + "/kernelApi/kernelCommonSrv/machineController/listMachinesByIp";
        JSONObject param = new JSONObject();
        param.put("token", JiaotuCmdbSync.getToken(scannerInfo));
        param.put("intranetIp", ip);
        //{
        //    "token":"XXXXXXXXXXXXXXXXXXXXXXXXXXXX",
        //    "taskUuid":"2d27b61e6d00472db66e14e7742856fa"
        //"machineUuid":"ef93fd43f2306e96c6f233f769e8b4bd"
        //}
        String ret = HttpUtils.sendPost(apiUrl, param.toJSONString());
        try {
            JSONObject json = JsonUtils.parse(ret);
            if (json.containsKey("code") && JsonUtils.equal(json, "code", "1")) {
                if (json.getJSONArray("data") != null && json.getJSONArray("data").size() > 0)
                    return json.getJSONArray("data").getJSONObject(0);
                else {
                    log.error("调用结果报错：" + ret);
                }
            } else {
                log.error("调用结果报错：" + ret);
            }
        } catch (Exception e) {
            log.error(e.getMessage(), e);
        }
        return null;
    }

    public static List<String> getItemList(JtConfig scannerInfo) {
        ///api/scanSrv/weakPasswordController/listWeakPasswordItems
        String url = scannerInfo.getAddress();
        String apiUrl = url + "/api/scanSrv/weakPasswordController/listWeakPasswordItems";
        JSONObject param = new JSONObject();
        param.put("token", JiaotuCmdbSync.getToken(scannerInfo));
        /**
         * {
         * "code":"1",
         * "msg":"成功",
         * "data":[
         * {
         * "itemId":6,
         * "cnDesc":"检查用户是否使用弱密码",
         * "osType":1
         * }
         */
        String ret = HttpUtils.sendPost(apiUrl, param.toJSONString());
        try {
            JSONObject json = JsonUtils.parse(ret);
            if (json.containsKey("code") && JsonUtils.equal(json, "code", "1")) {
                if (json.getJSONArray("data") != null && json.getJSONArray("data").size() > 0) {
                    JSONArray arr = json.getJSONArray("data");
                    List<String> itemList = new ArrayList<>();
                    for (int i = 0; i < arr.size(); i++) {
                        itemList.add(JsonUtils.getStr(arr.getJSONObject(i),"itemId"));
                    }
                    return itemList;
                }else {
                    log.error("调用结果报错：" + ret);
                }
            } else {
                log.error("调用结果报错：" + ret);
            }
        } catch (Exception e) {
            log.error(e.getMessage(), e);
        }
        return null;
    }

    public static String getAgentUuidByIpCurl(JtConfig scannerInfo, String ip) {
        String url = scannerInfo.getAddress();
        String apiUrl = url + "/api/assetSrv/zcMachineController/queryMachineUuidByIp";
        JSONObject param = new JSONObject();
        param.put("token", JiaotuCmdbSync.getToken(scannerInfo));
        param.put("hostIp", ip);
        String ret = HttpUtils.curlPost(apiUrl, param.toJSONString());
        try {
            JSONObject json = JsonUtils.parse(ret);
            if (json.containsKey("code") && JsonUtils.equal(json, "code", "1")) {
                if (json.containsKey("data")) {
                    return JsonUtils.getStr(json.getJSONObject("data"), "machineUuid");
                }else {
                    log.error("调用结果报错：" + ret);
                }
            } else {
                log.error("调用结果报错：" + ret);
            }
        } catch (Exception e) {
            log.error(e.getMessage(), e);
        }
        return null;
    }
}
