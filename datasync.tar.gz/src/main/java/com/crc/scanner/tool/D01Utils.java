package com.crc.scanner.tool;

import com.alibaba.fastjson.JSONArray;
import com.alibaba.fastjson.JSONObject;
import com.crc.common.utils.HttpUtils;
import com.crc.common.utils.JsonUtils;
import com.crc.scanner.config.DccConfig;
import com.crc.secface.domain.vo.JoeyeToken;
import com.crc.sync.d01.D01AssetSync;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.apache.http.conn.ssl.NoopHostnameVerifier;
import org.apache.http.conn.ssl.SSLConnectionSocketFactory;
import org.apache.http.conn.ssl.TrustSelfSignedStrategy;
import org.apache.http.impl.client.CloseableHttpClient;
import org.apache.http.impl.client.HttpClients;
import org.apache.http.ssl.SSLContextBuilder;

import javax.net.ssl.HostnameVerifier;
import javax.net.ssl.SSLContext;
import java.security.KeyManagementException;
import java.security.KeyStoreException;
import java.security.NoSuchAlgorithmException;
import java.util.*;
import java.util.concurrent.atomic.AtomicReference;

@Slf4j
public class D01Utils {
    /**
     * 忽略HTTPS证书校验
     */
    public static CloseableHttpClient createAcceptSelfSignedCertificateClient()
            throws KeyManagementException, NoSuchAlgorithmException, KeyStoreException {
        SSLContext sslContext = SSLContextBuilder.create().loadTrustMaterial(new TrustSelfSignedStrategy()).build();
        HostnameVerifier allowAllHosts = new NoopHostnameVerifier();
        SSLConnectionSocketFactory connectionFactory = new SSLConnectionSocketFactory(sslContext, allowAllHosts);
        return HttpClients.custom().setSSLSocketFactory(connectionFactory).build();
    }

    public static String parseParam(String str) {
        if (StringUtils.isBlank(str)) {
            return str;
        }
        Map<String, String> map = new TreeMap<String, String>(
                Comparator.naturalOrder());
        if (StringUtils.isBlank(str)) return "";
        Arrays.stream(str.split("&"))
                .filter(kv -> kv.contains("="))
                .map(kv -> kv.split("="))
                .forEach(array -> {
                    //map.put(array[0], array[1]);
                    if (array.length < 2) {
                        map.put(array[0], "");
                    } else {
                        map.put(array[0], array[1]);
                    }
                });
        AtomicReference<String> ret = new AtomicReference<>("");
        map.forEach((k, v) -> {
            if (StringUtils.isBlank(ret.get())) {
                ret.set(k + "=" + v);
            } else {
                ret.set(ret.get() + "&" + k + "=" + v);
            }
        });

        return ret.get();
    }

    public static JSONArray getTask(DccConfig d01Config, String taskName, String jobId) {
        JoeyeToken joeyeToken = D01AssetSync.getKey(d01Config);
        if (joeyeToken == null || StringUtils.isBlank(joeyeToken.getToken())) {
            log.error("获取D01 key失败！");
            return null;
        }
        String type = "tasks/finisheds/task_threats";
        int total = D01AssetSync.getTotal(d01Config, type, joeyeToken.getToken() + "&id=" + jobId);
        log.info(taskName + ",开始同步D01数据，数据量：" + total);
        JSONArray dataList = new JSONArray();
        if (total > 0) {
            int pageSize = 500;
            for (int i = 1; i < (Math.ceil(total / pageSize) + 2); i++) {
                String url = d01Config.getAddress();
                String email = d01Config.getUsername();
                String param = String.format("email=%s&key=%s", email, joeyeToken.getToken()) + "&page=1&per_page=1";
                String fullUrl = url + "/api/v2/" + type;
                String jsonStr = HttpUtils.sendGet(fullUrl, param);
                JSONObject jsonObject = JsonUtils.parse(jsonStr);
                if (jsonObject.containsKey("status_code") && "200".equals(JsonUtils.getStr(jsonObject, "status_code"))) {
                    //操作成功
                    if (jsonObject.containsKey("threats")) {
                        dataList.addAll(jsonObject.getJSONArray("threats"));
                    } else {
                        log.error("获取数据错误：" + jsonStr);
                    }
                } else {
                    log.error("获取数据错误非200OK：" + jsonStr);
                }
            }
        }
        return dataList;
    }
}
