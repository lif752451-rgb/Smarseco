package com.crc.scanner.tool;

import cn.hutool.core.date.DateTime;
import cn.hutool.core.date.DateUtil;
import com.alibaba.fastjson.JSONObject;
import com.alibaba.fastjson.util.IOUtils;
import com.crc.common.utils.*;
import com.crc.scanner.config.MoFangConfig;
import com.crc.secface.domain.EngineEquipmentManagement;
import com.crc.secface.domain.VulnScanTask;
import com.crc.secface.schedule.assemble.CommonAssemble;
import org.apache.commons.lang3.StringUtils;
import org.apache.http.Consts;
import org.apache.http.HttpEntity;
import org.apache.http.client.config.RequestConfig;
import org.apache.http.client.methods.CloseableHttpResponse;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.client.protocol.HttpClientContext;
import org.apache.http.entity.ContentType;
import org.apache.http.entity.mime.MultipartEntityBuilder;
import org.apache.http.entity.mime.content.StringBody;
import org.apache.http.impl.client.CloseableHttpClient;
import org.apache.http.impl.client.HttpClients;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import sun.net.www.protocol.https.Handler;

import javax.net.ssl.*;
import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.net.URL;
import java.security.cert.X509Certificate;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;
import java.util.Objects;

import static com.crc.common.constants.Constants.AnHengConstants.APPLICATION_JSON;
import static com.crc.common.constants.Constants.AnHengConstants.CONTENT_TYPE;
import static com.crc.common.constants.Constants.STATUS;
import static com.crc.common.constants.MoFangConstants.*;
import static com.crc.common.constants.MoFangConstants.ApiUrl.TASK_MANAGE_API_URL;
import static com.crc.common.utils.HttpUtils.CONN_TIME_OUT;
import static com.crc.common.utils.HttpUtils.READ_TIME_OUT;

/**
 * 魔方工具类
 *
 * @Author fuzhuangzhi
 * @Date 2022/9/6 10:05
 * @Version 1.0
 **/
public class MoFangUtils {
    private static final Logger logger = LoggerFactory.getLogger(MoFangUtils.class);

    /**
     * 获取魔方引擎配置信息
     *
     * @return
     */
    public static MoFangConfig getMoFangConfig(Long engineId) {
        EngineEquipmentManagement engine = CommonAssemble.engineMap.get(engineId);

        MoFangConfig mfConfig = new MoFangConfig();
        if (engine == null || engine.getId() == null) {
            return mfConfig;
        }
        String equipmentCapabilities = engine.getEquipmentCapabilities();
        JSONObject jsonObject = JsonUtils.parse(equipmentCapabilities);
        if (jsonObject != null) {
            String accessKey = JsonUtils.getStr(jsonObject, "accessKey");
            String secretKey = JsonUtils.getStr(jsonObject, "secretKey");
            // 扫描任务创建时间：默认最近20天的任务
            String createTimeRange = DateUtil.formatDate(DateUtil.offsetDay(new Date(), -20)) + "/" + DateUtil.formatDate(new Date());
            String interval = JsonUtils.getStr(jsonObject, "interval", createTimeRange);
            mfConfig.setAccessKey(accessKey);
            mfConfig.setSecretKey(secretKey);
            mfConfig.setInterval(interval);
        }
        mfConfig.setAddress(engine.getEquipmentAddress());
        return mfConfig;
    }

    /**
     * 魔方api get方法
     *
     * @param scannerInfo
     * @param url
     * @param parameter
     * @return
     */
    public static JSONObject get(MoFangConfig scannerInfo, String url, String parameter) {
        if (scannerInfo == null) {
            logger.error("获取魔方配置信息失败");
            return null;
        }
        if (StringUtils.isEmpty(url)) {
            logger.error("url为空");
            return null;
        }
        HttpGet httpRequest = new HttpGet(scannerInfo.getAddress() + url + parameter);
        RequestConfig requestConfig = RequestConfig.custom()
                .setConnectTimeout(45000).setConnectionRequestTimeout(45000)
                .setSocketTimeout(45000).build();
        httpRequest.setConfig(requestConfig);
        httpRequest.setHeader(CONTENT_TYPE, APPLICATION_JSON);
        httpRequest.setHeader(ACCESS_KEY, scannerInfo.getAccessKey());
        httpRequest.setHeader(SECRET_KEY, scannerInfo.getSecretKey());
        CloseableHttpResponse response = null;
        try {
            CloseableHttpClient httpClient = HttpFileUtils.getHttpClient();
            response = httpClient.execute(httpRequest);

            int code = response.getStatusLine().getStatusCode();
            if (code == 200) {
                return JsonUtils.parse(DataUtils.toBodyString(response.getEntity()));
            } else {
                logger.error("获取数据错误非200OK：" + response.getStatusLine() + "URL:" + httpRequest.getURI());
            }
        } catch (Exception e) {
            logger.error(e.getMessage());
        } finally {
            IOUtils.close(response);
        }
        return null;
    }

    /**
     * 魔方api post提交表单数据
     *
     * @param scannerInfo
     * @param apiUrl
     * @param params
     * @return
     */
    public static JSONObject post(MoFangConfig scannerInfo, String apiUrl, Map<String, String> params) {
        String url = null;
        if (StringUtils.isNotBlank(scannerInfo.getAddress())) {
            url = scannerInfo.getAddress();
        }
        HttpPost httpRequest = new HttpPost(url + apiUrl);
        httpRequest.setHeader(CONTENT_TYPE, APPLICATION_JSON);
        httpRequest.setHeader(ACCESS_KEY, scannerInfo.getAccessKey());
        httpRequest.setHeader(SECRET_KEY, scannerInfo.getSecretKey());
        RequestConfig requestConfig = RequestConfig.custom()
                .setConnectTimeout(45000).setConnectionRequestTimeout(45000)
                .setSocketTimeout(45000).build();
        httpRequest.setConfig(requestConfig);
        CloseableHttpResponse response = null;
        try {
            MultipartEntityBuilder builder = MultipartEntityBuilder.create();
            if (params != null) {
                for (String key : params.keySet()) {
                    builder.addPart(key, new StringBody(params.get(key), ContentType.create("application/json", Consts.UTF_8)));
                }
            }
            HttpEntity reqEntity = builder.build();
            httpRequest.setEntity(reqEntity);
            if (url.toLowerCase().startsWith("https")) {
                return sendPost(url + apiUrl, JSONObject.toJSONString(params), scannerInfo);
            } else {
                //获取扫描器信息
                CloseableHttpClient httpClient = HttpClients.createDefault();
                // 发起请求 并返回请求的响应
                response = httpClient.execute(httpRequest, HttpClientContext.create());
                if (response != null) {
                    String resultString = DataUtils.toBodyString(response.getEntity());
                    return JSONObject.parseObject(resultString, JSONObject.class);
                }
            }
        } catch (Exception e) {
            logger.error(e.getMessage(), e);
        } finally {
            IOUtils.close(response);
        }
        return null;
    }

    /**
     * @param urlPath 对方地址
     * @param json    要传送的数据
     * @return
     */
    public static JSONObject sendPost(String urlPath, String json, MoFangConfig scannerInfo) {
        OutputStreamWriter out = null;
        BufferedReader in = null;
        StringBuilder result = new StringBuilder();
        HttpsURLConnection urlConnection = null;
        try {
            SSLContext sslContext = SSLContext.getInstance("SSL");
            sslContext.init(null, new TrustManager[]{new HttpsUtils.TrustAnyTrustManager()}, new java.security.SecureRandom());

            // 获取SSLSocketFactory对象
            HostnameVerifier HostnameVerifier = (var1, var2) -> true;
            URL url = new URL(null, urlPath.replace("\n", "").replace(" ", ""), new Handler());
            urlConnection = (HttpsURLConnection) url.openConnection();
            urlConnection.setSSLSocketFactory(sslContext.getSocketFactory());
            // 设置doOutput属性为true表示将使用此urlConnection写入数据
            urlConnection.setDoOutput(true);
            // 定义待写入数据的内容类型，我们设置为application/x-www-form-urlencoded类型
            urlConnection.setRequestProperty("content-type", "application/json");
            urlConnection.setRequestProperty(ACCESS_KEY, scannerInfo.getAccessKey());
            urlConnection.setRequestProperty(SECRET_KEY, scannerInfo.getSecretKey());
            urlConnection.setConnectTimeout(CONN_TIME_OUT);
            urlConnection.setReadTimeout(READ_TIME_OUT);
            urlConnection.setHostnameVerifier(HostnameVerifier);
            // 得到请求的输出流对象
            out = new OutputStreamWriter(urlConnection.getOutputStream());
            // 把数据写入请求的Body
            if (StringUtils.isNotBlank(json))
                out.write(json);
            out.flush();
            // 定义BufferedReader输入流来读取URL的响应
            in = new BufferedReader(new InputStreamReader(urlConnection.getInputStream()));
            String line;
            while ((line = in.readLine()) != null) {
                result.append(line);
            }
        } catch (Exception e) {
            logger.error(e.getMessage(), e);
        }
        // 使用finally块来关闭输出流、输入流
        finally {
            org.apache.commons.io.IOUtils.closeQuietly(in);
            org.apache.commons.io.IOUtils.closeQuietly(out);
            try {
                if (urlConnection != null) {
                    urlConnection.disconnect();
                }
            } catch (Exception ignored) {

            }
        }
        return JsonUtils.parse(result.toString());
    }


    private static class TrustAnyTrustManager implements X509TrustManager {
        @Override
        public void checkClientTrusted(X509Certificate[] chain, String authType) {
        }

        @Override
        public void checkServerTrusted(X509Certificate[] chain, String authType) {
        }

        @Override
        public X509Certificate[] getAcceptedIssuers() {
            return new X509Certificate[]{};
        }
    }

    private static class TrustAnyHostnameVerifier implements HostnameVerifier {
        @Override
        public boolean verify(String hostname, SSLSession session) {
            return true;
        }
    }


    /**
     * 下发扫描任务
     *
     * @param scannerInfo 引擎配置信息
     * @param task        任务
     * @return 接口扫描任务id
     * <p>
     * "zone_name":"default",
     * "name":"测试新建扫描任务：10.54238.153",
     * "scan_type":"base",
     * "port_type":"all",
     * "portdeep":1,
     * "value_type":"customize",
     * "value":"10.54.238.153\r\n10.54.238.152",
     * "portargv":"all",
     * "cycle":0,
     * "cycle_interval":"1",
     * "protdeep":"1",
     * "cpescan":"0",
     * "task_start_time":"2022-09-05 14:20:00"
     */
    public static String createVulTask(MoFangConfig scannerInfo, VulnScanTask task) {
        if (Objects.isNull(task)) {
            return StringUtils.EMPTY;
        }
        Map<String, String> params = buildAddTaskParams(task);
        JSONObject jsonData = post(scannerInfo, TASK_MANAGE_API_URL, params);
        if (JsonUtils.isEmpty(jsonData) || !JsonUtils.getBoolean(jsonData, STATUS)) {
            logger.info("下发魔方扫描任务失败，scannerInfo:【{}】,parms:【{}】", JSONObject.toJSONString(scannerInfo), JSONObject.toJSONString(params));
            return null;
        }
        JSONObject jsonInfo = JsonUtils.getJson(jsonData, INFO);
        if (!JsonUtils.isEmpty(jsonInfo)) {
            return JsonUtils.getStr(jsonInfo, "id");
        }
        return null;
    }

    /**
     * 构建下发扫描任务参数
     *
     * @param task
     * @return
     */
    private static Map<String, String> buildAddTaskParams(VulnScanTask task) {
        Map<String, String> params = new HashMap<>();
        // 当前时间5分钟之后
        DateTime taskStartTime = DateUtil.offsetMinute(DateUtil.date(), 5);
        // 任务开始时间
        params.put("task_start_time", DateUtils.getTimeFormatString(taskStartTime));
        // 任务名称
        params.put("name", task.getTaskName());
        // 扫描区域标识 default:默认区域
        params.put("zone_name", "default");
        /*base：基础模式
        domain：主域模式
        pocscan：PoC 巡检
        thirdscan：第三方扫描*/
        // 扫描模式
        params.put("scan_type", "base");
        /*all：全端口
        template：端口模板
        general：自定义端口*/
        // 端口类型
        params.put("port_type", "all");
        // 扫描方式 1 : 急速扫描 2：标准扫描
        params.put("portdeep", "1");
        // 扫描目标范围 customize：自定义,exist_ip：存活 ip,business：资产组
        params.put("value_type", "customize");
        // 扫描目标取值 根据目标范围取值（可单个ip,网段，多个用\r\n隔开）
        params.put("value", task.getScanContentX());
        // 端口取值范围 根据端口类型传值 all：代表所有端口
        params.put("portargv", "all");
        // 是否周期任务 0:否 1：是
        params.put("cycle", "0");
        // 周期扫描间隔（天）
        params.put("cycle_interval", "1");
        // 是否进行版本型扫描 1：是 0：否
        params.put("cpescan", "1");
        return params;
    }
}
