package com.crc.scanner.tool;

import com.alibaba.fastjson.JSONArray;
import com.alibaba.fastjson.JSONObject;
import com.crc.common.utils.DataUtils;
import com.crc.common.utils.HttpUtils;
import com.crc.common.utils.JsonUtils;
import com.crc.scanner.config.GobyConfig;
import com.crc.secface.domain.VulnScanTaskRecordLog;
import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.LinkedList;
import java.util.List;

public class GobyUtils {
    private static final Logger logger = LoggerFactory.getLogger(GobyUtils.class);

    public static HashMap<String, List<JSONObject>> assetSearch(GobyConfig gobyConfig, String taskName, String taskId) {
        HashMap<String, List<JSONObject>> dataMap = new HashMap<>();
        String jsonStr = "{\n" +
                "  \"query\": \"taskId=\\\"" + taskId + "\\\"\",\n" +
                "  \"options\": {\n" +
                "    \"order\": {\n" +
                "      \"vulnerabilities\": \"desc\",\n" +
                "      \"assets\": \"desc\"\n" +
                "    },\n" +
                "    \"page\": {\n" +
                "      \"page\": 0,\n" +
                "      \"size\": 1\n" +
                "    }\n" +
                "  }\n" +
                "}";
        JSONObject jsonObject = JsonUtils.parse(jsonStr);
        //System.out.println(jsonObject.toJSONString());
        String queryRet = HttpUtils.sendPost(gobyConfig.getAddress() + "/api/v1/assetSearch", jsonObject.toJSONString());
        logger.info("{}=assetSearch={}", taskName, queryRet);
        JSONObject json = JsonUtils.parse(queryRet);
        if ("200".equals(JsonUtils.getStr(json, "statusCode"))) {
            try {
                JSONObject data = json.getJSONObject("data");
                JSONObject queryTotal = data.getJSONObject("query_total");
                if (queryTotal != null) {
                    int total = JsonUtils.getInt(queryTotal, "ips");
                    if (total > 0) {
                        int pageSize = 100;
                        for (int i = 0; i < DataUtils.getPageCount(total, pageSize, 0); i++) {
                            String queryStr = "{\n" +
                                    "  \"query\": \"taskId=\\\"" + taskId + "\\\"\",\n" +
                                    "  \"options\": {\n" +
                                    "    \"order\": {\n" +
                                    "      \"vulnerabilities\": \"desc\",\n" +
                                    "      \"assets\": \"desc\"\n" +
                                    "    },\n" +
                                    "    \"page\": {\n" +
                                    "      \"page\": " + i + ",\n" +
                                    "      \"size\": " + pageSize + "\n" +
                                    "    }\n" +
                                    "  }\n" +
                                    "}";
                            JSONObject queryJson = JsonUtils.parse(queryStr);
                            String ret = HttpUtils.sendPost(gobyConfig.getAddress() + "/api/v1/assetSearch", queryJson.toJSONString());
                            JSONObject retJson = JsonUtils.parse(ret);
                            if ("200".equals(JsonUtils.getStr(retJson, "statusCode"))) {
                                JSONObject retData = retJson.getJSONObject("data");
                                if (retData != null) {
                                    JSONArray ipsArr = retData.getJSONArray("ips");
                                    if (ipsArr != null) {
                                        for (int x = 0; x < ipsArr.size(); x++) {
                                            JSONObject ipJson = ipsArr.getJSONObject(x);
                                            String ip = JsonUtils.getStr(ipJson, "ip");
                                            if (!dataMap.containsKey(ip))
                                                dataMap.put(ip, new LinkedList<>());
                                            HashMap<String, String> portMap = new HashMap<>();
                                            JSONArray ports = ipJson.getJSONArray("ports");
                                            if (ports == null) {
                                                continue;
                                            }
                                            for (int z = 0; z < ports.size(); z++) {
                                                JSONObject port = ports.getJSONObject(z);
                                                if (JsonUtils.getInt(port, "port") < 1) {
                                                    continue;
                                                }
                                                portMap.put(String.format("%s:%s", ip, JsonUtils.getStr(port, "port")), "1");
                                            }
                                            JSONObject protocols = ipJson.getJSONObject("protocols");
                                            /*
                                            "10.54.238.55:27017": {
                                            "port": "27017",
                                            "hostinfo": "10.54.238.55:27017",
                                            "url": "",
                                            "product": "OpenSSL|MongoDb",
                                            "protocol": "mongodb",
                                            "json": "",
                                            "products": [
                                              "OpenSSL",
                                              "MongoDb"
                                            ],
                                            "protocols": [
                                              "mongodb"
                                            ]
                                          }
                                             */
                                            if (protocols != null) {
                                                for (String key : portMap.keySet()) {
                                                    JSONObject assetJson = protocols.getJSONObject(key);
                                                    if (assetJson != null) {
                                                        dataMap.get(ip).add(assetJson);
                                                    }
                                                }
                                            }
                                        }
                                    }
                                }
                            } else {
                                logger.error("assetSearch ERROR1=" + ret);
                            }
                        }
                    }
                }
            } catch (Exception e) {
                logger.error(e.getMessage(), e);
            }
        } else {
            logger.error("assetSearch ERROR0=" + queryRet);
        }
        return dataMap;
    }

    public static List<VulnScanTaskRecordLog> getTaskList(GobyConfig gobyConfig) {
        if (StringUtils.isBlank(gobyConfig.getAddress())) {
            return new ArrayList<>();
        }
        String ret = HttpUtils.sendGet(gobyConfig.getAddress() + "/api/v1/tasks", "");
        JSONObject jsonAll = JsonUtils.parse(ret);
        List<VulnScanTaskRecordLog> taskList = new ArrayList<>();
        if ("200".equals(JsonUtils.getStr(jsonAll, "statusCode"))) {
            JSONArray data = jsonAll.getJSONArray("data");
            if (data != null && data.size() > 0) {

                for (int i = 0; i < data.size(); i++) {
                    JSONObject json = data.getJSONObject(i);
                    VulnScanTaskRecordLog task = new VulnScanTaskRecordLog();
                    task.setJobId(JsonUtils.getStr(json, "taskId"));
                    task.setCreateTime(JsonUtils.getDate(json, "created_time"));
                    task.setUpdateTime(JsonUtils.getDate(json, "end_time"));
                    task.setIp(JsonUtils.getStr(json, "targets"));
                    task.setProgress(JsonUtils.getInt(json, "progress"));
                    taskList.add(task);
                }
            }
        } else {
            logger.error("getTaskList失败=" + ret);
        }
        return taskList;
    }

    /**
     * 停止Goby任务
     *
     * @param gobyConfig goby配置
     * @param taskId     执行任务ID
     */
    public static void stopTask(GobyConfig gobyConfig, String taskId) {
        try {
            String jsonStr = "{ \"taskId\": \"" + taskId + "\" }";
            JSONObject jsonObject = JsonUtils.parse(jsonStr);
            String ret = HttpUtils.sendPost(gobyConfig.getAddress() + "/api/v1/stopScan", jsonObject.toJSONString());
            logger.info("stop goby task=" + taskId + " " + ret);
        } catch (Exception e) {
            logger.error(e.getMessage(), e);
        }
    }

    public static void deleteTask(GobyConfig gobyConfig, String taskId) {
        try {
            logger.info("停止任务" + taskId);
            stopTask(gobyConfig, taskId);
        } catch (Exception e) {
            logger.error(e.getMessage(), e);
        }
        try {
            List<String> taskIdList = new LinkedList<>();
            taskIdList.add(taskId);
            JSONObject jsonObject = new JSONObject();
            jsonObject.put("taskId", taskIdList);
            String ret = HttpUtils.sendPost(gobyConfig.getAddress() + "/api/v1/deleteTasks", jsonObject.toJSONString());
            logger.info(taskId + " to deleteTask= " + ret);
        } catch (Exception e) {
            logger.error(e.getMessage(),e);
        }
    }

    public static JSONObject scan(GobyConfig gobyConfig, String name, String ip) {
        String jsonStr = "{\n" +
                "  \"taskId\": \"1\",\n" +
                "  \"taskName\": \"" + DataUtils.urlEncode(name) + "\",\n" +
                "  \"asset\": {\n" +
                "    \"ips\": [\n" +
                "      \"" + ip + "\"\n" +
                "    ],\n" +
                "    \"ports\": \"7,11,13,15,17,19,20,21,22,23,25,26,30,31,32,36,37,38,43,49,51,U:53,53,67,U:67,U:69,70,79,80,U:80,81,82,83,84,85,86,87,88,U:88,89,98,102,104,110,111,U:113,113,119,121,U:123,135,U:137,138,139,143,U:161,U:162,175,179,199,211,264,280,311,389,U:391,U:427,443,U:443,444,445,449,465,U:500,500,502,503,505,512,515,U:520,U:523,540,548,554,564,587,620,U:623,U:626,631,636,646,666,U:705,771,777,789,800,801,808,U:853,873,876,880,888,898,900,901,902,990,992,993,994,995,999,1000,1010,1022,1023,1024,1025,1026,1027,U:1027,1042,1080,1099,1177,U:1194,1194,1200,1201,1212,1214,1234,1241,1248,1260,1290,1302,1311,1314,1344,1400,1433,U:1434,1443,1471,1494,1503,1505,1515,1521,1554,1588,U:1604,1610,U:1645,U:1701,1720,1723,1741,1777,U:1812,1830,1863,1880,1883,U:1900,1901,1911,1935,1947,1962,1967,1991,U:1993,2000,2001,2002,2010,2020,2022,2030,2049,2051,2052,2053,2055,2064,2077,2080,2082,U:2083,2083,2086,2087,U:2094,2095,2096,2121,U:2123,U:2152,2154,2160,2181,2222,2223,2252,2306,2323,2332,2375,2376,2379,2396,2401,2404,2406,U:2424,2424,U:2425,U:2427,2443,2455,2480,2501,2525,2600,2601,2604,2628,2715,2809,2869,3000,3001,3002,3005,3050,3052,3075,3097,3128,3260,3280,U:3283,3288,3299,3306,3307,3310,3311,3312,3333,U:3333,3337,3352,3372,3388,3389,3390,U:3391,3443,3460,U:3478,3520,3522,3523,3524,3525,3528,3531,3541,3542,U:3671,3689,3690,U:3702,3749,3780,U:3784,3790,4000,4022,4040,U:4050,4063,4064,U:4070,4155,4300,4369,4430,4433,4440,4443,4444,U:4500,4505,4506,4567,4660,4664,4711,4712,4730,4782,4786,U:4800,4840,4842,4848,4880,4911,4949,U:5000,5000,5001,U:5001,U:5002,5002,5003,U:5004,5004,5005,U:5005,5006,U:5006,5007,U:5007,U:5008,5008,5009,5010,5038,U:5050,5050,5051,U:5060,U:5061,5061,5080,5084,U:5093,U:5094,U:5095,5111,5222,5258,5269,5280,U:5351,U:5353,5357,5400,5427,5432,5443,5550,U:5554,5555,5560,5577,5598,5631,U:5632,5672,U:5673,5678,U:5683,5800,5801,5802,5820,5900,5901,5902,5903,5938,5984,5985,5986,6000,6001,6002,U:6002,6003,U:6003,6004,6005,6006,U:6006,6007,6008,6009,6010,6060,U:6060,6068,6080,6082,6103,6346,6363,6379,6443,6488,6544,6560,6565,6581,6588,6590,6600,6664,6665,6666,6667,6668,6669,6697,6699,6780,6782,U:6881,U:6969,6998,7000,U:7000,7001,U:7001,7002,7003,U:7003,7004,7005,U:7005,7007,7010,7014,7070,7071,7077,7080,7100,7144,7145,7170,7171,7180,7187,7199,7272,7288,7401,7402,7443,7474,7479,7493,7537,7547,7548,7634,7657,7676,7776,7777,7778,7779,7780,7788,7911,8000,8001,8002,U:8002,8003,8004,8005,8006,8007,8008,8009,8010,8020,8025,8030,8040,8058,8060,8069,8080,8081,8082,8083,8084,8085,8086,8087,8088,8089,8090,8091,8092,8093,8094,8095,8096,8097,8098,8099,8111,8112,8118,8123,8125,8126,8129,8138,8139,8140,8159,8161,8181,8182,8194,8200,8222,8291,8332,8333,8334,8351,8377,8378,8388,8443,8444,8480,8500,8529,8545,8546,8554,8649,8686,8765,8800,8834,8880,8881,8882,8883,8884,8885,8886,8887,8888,U:8888,8889,8890,8899,8983,8999,9000,U:9000,9001,9002,9003,9004,9005,9006,9007,9008,9009,9010,9030,9042,9050,9051,9080,9083,9090,9091,9100,U:9100,9151,9191,9200,9292,9295,9300,9306,9333,9334,9418,9443,9444,9446,9527,9530,9595,U:9600,9653,9668,9700,9711,9801,9864,9869,9870,9876,9943,9944,9981,9997,9999,10000,10001,U:10001,10003,10005,10030,10035,10162,10243,10250,10255,10332,10333,10443,10554,11001,11211,11300,11310,11371,11965,12000,12300,12345,12999,13579,13666,13720,13722,14000,14147,14265,14443,14534,15000,16000,16010,16030,16922,16923,16992,16993,17000,U:17185,17988,18000,18001,18080,18081,18086,18245,18246,18264,19150,19888,19999,20000,U:20000,20332,20547,20880,22105,22222,22335,23023,23424,25000,25010,25105,25565,26214,26470,27015,U:27015,27016,27017,28017,28080,U:28784,29876,29999,30001,U:30310,U:30311,U:30312,U:30313,U:30718,31337,32400,U:32768,32770,32771,32773,33338,33890,34567,34599,U:34962,U:34963,U:34964,37215,37777,40000,40001,41795,42873,44158,U:44818,44818,45554,U:47808,U:48899,49151,49152,49153,49154,49155,50000,50050,50060,50070,50075,50090,50100,50111,51106,52869,55442,55553,55555,U:59110,60001,60010,60030,60443,61613,61616,62078,64738\"\n" +
                "  },\n" +
                "  \"vulnerability\": {\n" +
                "    \"type\": \"-1\"   },\n" +
                "  \"options\": {\n" +
                "    \"queue\": 0,\n" +
                "    \"random\": true,\n" +
                "    \"rate\": 1000,\n" +
                "    \"portscanmode\": 0,\n" +
                "    \"disableMdns\": true,\n" +
                "    \"disableUpnp\": true,\n" +
                "    \"checkHoneyPot\": true,\n" +
                "    \"enableCrawler\": false,\n" +
                "    \"crawlerScope\": 0,\n" +
                "    \"crawlerConcurrent\": 5,\n" +
                "    \"crawlerMaxLinks\": 50,\n" +
                "    \"crawlerMaxCrawlLinks\": 1000,\n" +
                "    \"connectionSize\": 500,\n" +
                "    \"screenshotRDP\": false,\n" +
                "    \"screenshot\": false,\n" +
                "    \"deepAnalysis\": false,\n" +
                "    \"extracthost\": false,\n" +
                "    \"fofaFetchSubdomainEnabled\": false,\n" +
                "    \"fofaEmail\": \"\",\n" +
                "    \"fofaKey\": \"\",\n" +
                "    \"fofaFetchSize\": 100,\n" +
                "    \"pingFirst\": false,\n" +
                "    \"pingCheckSize\": 10,\n" +
                "    \"pingConcurrent\": 2,\n" +
                "    \"pingSendCount\": 2\n" +
                "  }\n" +
                "}";
        //System.out.println(jsonStr);
        JSONObject jsonObject = JsonUtils.parse(jsonStr);
        List<String> ipList = new LinkedList<>();
        ipList.add(ip);
        jsonObject.getJSONObject("asset").put("ips", ipList);
        jsonObject.remove("taskId");
        //System.out.println(jsonObject.toJSONString());

        String ret = HttpUtils.sendPost(gobyConfig.getAddress() + "/api/v1/startScan", jsonObject.toJSONString());
        //{"statusCode":200,"messages":"","data":{"taskId":"20220606172938"}}
        JSONObject retJson = new JSONObject();
        JSONObject json = JsonUtils.parse(ret);
        if ("200".equals(JsonUtils.getStr(json, "statusCode"))) {
            JSONObject data = json.getJSONObject("data");
            String taskId = JsonUtils.getStr(data, "taskId");
            retJson.put("taskId", taskId);
            retJson.put("code", 200);
        } else {
            logger.error("创建任务失败：" + ret);
            retJson.put("msg", ret);
            retJson.put("code", 500);
        }
        return retJson;
    }
}
