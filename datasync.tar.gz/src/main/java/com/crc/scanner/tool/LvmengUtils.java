package com.crc.scanner.tool;

import cn.hutool.core.io.FileUtil;
import cn.hutool.core.io.resource.ClassPathResource;
import com.alibaba.fastjson.JSONArray;
import com.alibaba.fastjson.JSONObject;
import com.alibaba.fastjson.serializer.SerializerFeature;
import com.crc.common.utils.*;
import com.crc.scanner.config.LvmengConfig;
import com.crc.secface.domain.vo.KvData;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.codec.binary.Base64;
import org.apache.commons.lang3.StringUtils;
import org.apache.http.Consts;
import org.apache.http.HttpEntity;
import org.apache.http.HttpHeaders;
import org.apache.http.client.config.RequestConfig;
import org.apache.http.client.methods.CloseableHttpResponse;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.client.protocol.HttpClientContext;
import org.apache.http.entity.ContentType;
import org.apache.http.entity.StringEntity;
import org.apache.http.entity.mime.MultipartEntityBuilder;
import org.apache.http.entity.mime.content.StringBody;
import org.apache.http.impl.client.CloseableHttpClient;

import java.io.BufferedReader;
import java.io.File;
import java.io.InputStreamReader;
import java.net.URLEncoder;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * @author jixiangqi
 * @date 2022/3/23
 */
@Slf4j
public class LvmengUtils {

    /**
     * Get方法
     *
     * @param scannerInfo 配置
     * @param apiUrl      api
     * @param Parameter   参数
     * @return 返回
     * @throws Exception 异常
     */
    public static CloseableHttpResponse get(LvmengConfig scannerInfo, String apiUrl, String Parameter) throws Exception {
        System.setProperty("jdk.tls.allowUnsafeServerCertChange", "true");
        System.setProperty("sun.security.ssl.allowUnsafeRenegotiation", "true");
        System.setProperty("jdk.tls.client.protocols", "TLSv1,TLSv1.1,TLSv1.2");
        String url = scannerInfo.getAddress();
        HttpGet HTTPRequest = new HttpGet(url + apiUrl + Parameter);
        String authString = scannerInfo.getUsername() + ":" + scannerInfo.getPassword();
        byte[] authEncBytes = Base64.encodeBase64(authString.getBytes());
        String authStringEnc = new String(authEncBytes);
        log.info("url:{},Auth:{}", url + apiUrl + Parameter, "Basic " + authStringEnc);
        HTTPRequest.setHeader(HttpHeaders.AUTHORIZATION, "Basic " + authStringEnc); //设置Authoriization字段
        RequestConfig requestConfig = RequestConfig.custom()
                .setConnectTimeout(45000).setConnectionRequestTimeout(45000)
                .setSocketTimeout(45000).build();
        HTTPRequest.setConfig(requestConfig);
        //获取扫描器信息
        CloseableHttpClient httpClient = HttpFileUtils.getHttpClient();
        return httpClient.execute(HTTPRequest);
    }


    /**
     * post提交表单数据
     *
     * @param scannerInfo 配置
     * @param apiUrl      api
     * @param params      参数
     * @return 返回
     */
    public static CloseableHttpResponse doPostForm(LvmengConfig scannerInfo, String apiUrl, Map<String, String> params) {
        System.setProperty("jdk.tls.allowUnsafeServerCertChange", "true");
        System.setProperty("sun.security.ssl.allowUnsafeRenegotiation", "true");
        System.setProperty("jdk.tls.client.protocols", "TLSv1,TLSv1.1,TLSv1.2");
        String url = scannerInfo.getAddress();
        HttpPost HTTPRequest = new HttpPost(url + apiUrl);

        String authString = scannerInfo.getUsername() + ":" + scannerInfo.getPassword();
        byte[] authEncBytes = Base64.encodeBase64(authString.getBytes());
        String authStringEnc = new String(authEncBytes);
        HTTPRequest.setHeader(HttpHeaders.AUTHORIZATION, "Basic " + authStringEnc); //设置Authoriization字段

        RequestConfig requestConfig = RequestConfig.custom()
                .setConnectTimeout(45000).setConnectionRequestTimeout(45000)
                .setSocketTimeout(45000).build();
        HTTPRequest.setConfig(requestConfig);
        log.info("url:{},Auth:{}", url + apiUrl, "Basic " + authStringEnc);
        try {

            MultipartEntityBuilder builder = MultipartEntityBuilder.create();
            if (params != null) {
                for (String key : params.keySet()) {
                    builder.addPart(key, new StringBody(params.get(key), ContentType.create("text/plain", Consts.UTF_8)));
                }
            }
            HttpEntity reqEntity = builder.build();
            HTTPRequest.setEntity(reqEntity);
            //获取扫描器信息
            CloseableHttpClient httpClient = HttpFileUtils.getHttpClient();
            // 发起请求 并返回请求的响应
            return httpClient.execute(HTTPRequest, HttpClientContext.create());
        } catch (Exception e) {
            log.error(e.getMessage(), e);
        }
        return null;
    }


    /**
     * POST请求
     *
     * @param scannerInfo 配置
     * @param iUrl        接口地址
     * @param Parameter   参数
     * @return 返回
     * @throws Exception 异常
     */
    public static CloseableHttpResponse post(LvmengConfig scannerInfo, String iUrl, JSONObject Parameter) throws Exception {
        System.setProperty("jdk.tls.allowUnsafeServerCertChange", "true");
        System.setProperty("sun.security.ssl.allowUnsafeRenegotiation", "true");
        System.setProperty("jdk.tls.client.protocols", "TLSv1,TLSv1.1,TLSv1.2");
        //获取扫描器信息'https://' + host + '/api/task/vul/create?username=' + username + '&password=' + password + '&format=' + result_format
        String url = scannerInfo.getAddress();
        String password = DataUtils.urlEncode(scannerInfo.getPassword());
        String apiUrl = String.format("%s?username=%s&password=%s&format=%s", iUrl, scannerInfo.getUsername(), password, "json");
        HttpPost HTTPRequest = new HttpPost(url + apiUrl);
        String auth = scannerInfo.getUsername() + ":" + scannerInfo.getPassword();
        byte[] encodedAuth = Base64.encodeBase64(auth.getBytes(StandardCharsets.US_ASCII));
        String authHeader = "Basic " + new String(encodedAuth);
        HTTPRequest.setHeader(HttpHeaders.AUTHORIZATION, authHeader);
        log.info("url:{},Auth:{}", url + apiUrl, authHeader);
        HTTPRequest.setHeader("Content-Type", "application/json");
        RequestConfig requestConfig = RequestConfig.custom()
                .setConnectTimeout(45000).setConnectionRequestTimeout(45000)
                .setSocketTimeout(45000).build();
        HTTPRequest.setConfig(requestConfig);
        HTTPRequest.setEntity(new StringEntity(JSONObject.toJSONString(Parameter, SerializerFeature.MapSortField), "UTF-8"));
        CloseableHttpClient httpClient = HttpFileUtils.getHttpClient();
        return httpClient.execute(HTTPRequest);
    }

    /**
     * 查询任务清单
     *
     * @param scannerInfo 配置
     * @param offset      分页
     * @return 总数
     */
    public static String getTaskList(LvmengConfig scannerInfo, int offset) {
        System.setProperty("jdk.tls.allowUnsafeServerCertChange", "true");
        System.setProperty("sun.security.ssl.allowUnsafeRenegotiation", "true");
        System.setProperty("jdk.tls.client.protocols", "TLSv1,TLSv1.1,TLSv1.2");
        CloseableHttpResponse response = null;
        try {
            String last7Day = DateUtils.getDateTimeStr(offset);
            String time = URLEncoder.encode(last7Day);
            response = get(scannerInfo, "/api/task/list?type=1&end_time_start=" + time, "");
            int code = response.getStatusLine().getStatusCode();
            if (code == 200) {
                return DataUtils.toBodyString(response.getEntity());
            }
        } catch (Exception e) {
            log.error(e.getMessage(), e);
        } finally {
            IOUtils.close(response);
        }
        return "";
    }

    /**
     * 获取任务清单总数
     *
     * @param scannerInfo 配置
     * @param offset      分页
     * @return 总数
     */
    public static int getTaskListTotal(LvmengConfig scannerInfo, int offset) {
        System.setProperty("jdk.tls.allowUnsafeServerCertChange", "true");
        System.setProperty("sun.security.ssl.allowUnsafeRenegotiation", "true");
        System.setProperty("jdk.tls.client.protocols", "TLSv1,TLSv1.1,TLSv1.2");
        CloseableHttpResponse response = null;
        try {
            if (offset > 0) {
                offset = offset * -1;
            }
            String last7Day = DateUtils.getDateTimeStr(offset);
            String time = URLEncoder.encode(last7Day);
            response = get(scannerInfo, "/api/task/list?type=1&end_time_start=" + time, "");
            int code = response.getStatusLine().getStatusCode();
            String ret = DataUtils.toBodyString(response.getEntity());
            if (code == 200) {
                try {
                    JSONObject json = JsonUtils.parse(ret);
                    if (json.containsKey("ret_msg") && JsonUtils.equal(json, "ret_msg", "success")) {
                        JSONObject data = JsonUtils.getJson(json, "data");
                        if (data != null) {
                            return JsonUtils.getInt(data, "task_total");
                        }
                    } else {
                        log.error("code=" + code + " ret=" + getLvmengError(ret));
                    }
                } catch (Exception e) {
                    log.error(e.getMessage(), e);
                }
            } else {
                log.error("code=" + code + " ret=" + getLvmengError(ret));
            }
        } catch (Exception e) {
            log.error(e.getMessage(), e);
        } finally {
            IOUtils.close(response);
        }
        return 0;
    }

    /**
     * 获取单个任务中扫描目标数
     *
     * @param scannerInfo 配置
     * @param taskId      id
     * @return id
     */
    public static int getTaskInfoTotal(LvmengConfig scannerInfo, String taskId) {
        System.setProperty("jdk.tls.allowUnsafeServerCertChange", "true");
        System.setProperty("sun.security.ssl.allowUnsafeRenegotiation", "true");
        System.setProperty("jdk.tls.client.protocols", "TLSv1,TLSv1.1,TLSv1.2");
        CloseableHttpResponse response = null;
        try {
            ///api/report/task/{task_id}
            response = get(scannerInfo, "/api/report/task/" + taskId + "?page=1&page_size=1", "");
            int code = response.getStatusLine().getStatusCode();
            String ret = DataUtils.toBodyString(response.getEntity());
            if (code == 200) {
                try {
                    JSONObject json = JsonUtils.parse(ret);
                    //System.out.println(json.toJSONString());
                    if (json.containsKey("ret_msg") && JsonUtils.equal(json, "ret_msg", "success")) {
                        JSONObject data = JsonUtils.getJson(json, "data");
                        if (data != null) {
                            return JsonUtils.getInt(data, "target_total");
                        }
                    } else {
                        log.error("code=" + code + " ret=" + getLvmengError(ret));
                    }
                } catch (Exception e) {
                    log.error(e.getMessage(), e);
                }
            } else {
                log.error("code=" + code + " ret=" + getLvmengError(ret));
            }
        } catch (Exception e) {
            log.error(e.getMessage(), e);
        } finally {
            IOUtils.close(response);
        }
        return 0;
    }


    /**
     * 查询任务任务状态
     */
    public static JSONObject getTaskStatus(LvmengConfig scannerInfo, String id) {
        System.setProperty("jdk.tls.allowUnsafeServerCertChange", "true");
        System.setProperty("sun.security.ssl.allowUnsafeRenegotiation", "true");
        System.setProperty("jdk.tls.client.protocols", "TLSv1,TLSv1.1,TLSv1.2");
        CloseableHttpResponse response = null;
        try {
            ///api/report/task/{task_id}
            response = get(scannerInfo, "/api/task/status/" + id, "");
            int code = response.getStatusLine().getStatusCode();
            String ret = DataUtils.toBodyString(response.getEntity());
            if (code == 200) {
                try {
                    JSONObject json = JsonUtils.parse(ret);
                    if (json.containsKey("ret_msg") && JsonUtils.equal(json, "ret_msg", "success")) {
                        return JsonUtils.getJson(json, "data");
                    } else {
                        log.error("id={},code=" + code + " ret=" + getLvmengError(ret), id);
                        //{"data":{"inner_error":"系统异常"},"ret_msg":"找不到任务","ret_code":"-1"}
                        if (JsonUtils.equalVal(json, "ret_code", "-1") && "找不到任务".equals(DataUtils.unicodeToCn(json.getString("ret_msg")))) {
                            JSONObject newRetJson = new JSONObject();
                            newRetJson.put("ret_code", "999");
                            return newRetJson;
                        }
                    }
                } catch (Exception e) {
                    log.error(e.getMessage(), e);
                }
            } else {
                log.error("id={},code=" + code + " ret=" + getLvmengError(ret), id);
            }
        } catch (Exception e) {
            log.error(e.getMessage(), e);
        } finally {
            IOUtils.close(response);
        }
        return null;
    }

    /**
     * 创建漏洞扫描任务
     *
     * @param scannerInfo 配置
     * @param taskName    任务
     * @param target      目标
     * @return ID
     */
    public static String createVulTask(LvmengConfig scannerInfo, String taskName, String target) {
        System.setProperty("jdk.tls.allowUnsafeServerCertChange", "true");
        System.setProperty("sun.security.ssl.allowUnsafeRenegotiation", "true");
        System.setProperty("jdk.tls.client.protocols", "TLSv1,TLSv1.1,TLSv1.2");
        CloseableHttpResponse response = null;
        try {
            ///api/report/task/{task_id}
            Map<String, String> map = new HashMap<>();
            map.put("name", taskName);
            map.put("targets", target);
            //String password = DataUtils.urlEncode(scannerInfo.getPassword());
            String password = scannerInfo.getPassword();
            //response = doPostForm(scannerInfo, "/api/task/vul/create?username=" + scannerInfo.getUsername() + "&password=" + password, map);
            response = doPostForm(scannerInfo, "/api/task/vul/create", map);
            if (response == null) {
                return null;
            }
            int code = response.getStatusLine().getStatusCode();
            String ret = DataUtils.toBodyString(response.getEntity());
            if (code == 200) {
                JSONObject json = JsonUtils.parse(ret);
                if (json.containsKey("ret_msg") && JsonUtils.equal(json, "ret_msg", "success")) {
                    JSONObject data = json.getJSONObject("data");
                    return JsonUtils.getStr(data, "task_id");
                } else {
                    log.error(taskName + ",code=" + code + " ret=" + getLvmengError(ret));
                }
            } else {
                log.error(taskName + ",code=" + code + " ret=" + getLvmengError(ret));
            }
        } catch (Exception e) {
            log.error(e.getMessage(), e);
        } finally {
            IOUtils.close(response);
        }
        return null;
    }

    private static String IP_DB_FILE_PATH = "";

    /**
     * 下发任务漏洞
     *
     * @param target   参数
     * @param taskName 任务名称
     * @return id
     */
    public static String addFileTask(LvmengConfig scannerInfo, String taskName, String target) {
        System.setProperty("jdk.tls.allowUnsafeServerCertChange", "true");
        System.setProperty("sun.security.ssl.allowUnsafeRenegotiation", "true");
        System.setProperty("jdk.tls.client.protocols", "TLSv1,TLSv1.1,TLSv1.2");
        boolean flag = false;
        String prexPath = "/info/pwd.xml";
        ClassPathResource classPathResource = new ClassPathResource(prexPath);
        String dbPath = classPathResource.getAbsolutePath();
        if (StringUtils.isNotBlank(dbPath)) {
            if (FileUtil.exist(dbPath)) {
                flag = true;
            } else {
                try {
                    dbPath = System.getProperty("user.dir") + prexPath;
                    File file = new File(dbPath);
                    if (StringUtils.isBlank(IP_DB_FILE_PATH)) {
                        FileUtils.createDirectory4FilePath(dbPath);
                        FileUtil.writeFromStream(classPathResource.getStream(), file);
                        IP_DB_FILE_PATH = dbPath;
                    }
                    flag = true;
                } catch (Exception e) {
                    log.error(e.getMessage(), e);
                }
            }
        }
        if (!flag) {
            return "";
        }
        if (StringUtils.isNotBlank(IP_DB_FILE_PATH)) {
            dbPath = IP_DB_FILE_PATH;
        }
        if (StringUtils.isBlank(dbPath)) {
            log.error("info/pwd.xml，不存在");
            return "";
        } else {
            String password = DataUtils.urlEncode(scannerInfo.getPassword());
            //String password = scannerInfo.getPassword();
            String xmlStr = FileUtils.readFileXmlStr(dbPath);
            String newStr = xmlStr.replace("##TASK_NAME##", taskName).replace("##TARGET##", target);
            String filePath = "/tmp/lm/";
            String xmlPath = filePath + File.separator + IdGen.uuid() + ".xml";
            FileUtils.createDirectory4FilePath(xmlPath);
            if (FileUtils.writeFile(xmlPath, newStr)) {
                //curl -F "config_xml=@d:/stp/new/1.xml" -F "type=4" -kv "https://10.24.254.212/api/task/create?username=admin&password=19985545%40YHsw&format=xml"
                String cUrlCheck = "curl -F \"config_xml=@" + xmlPath + "\" -F \"type=4\" -kv \"" + scannerInfo.getAddress() + "/api/task/create?username=" + scannerInfo.getUsername() + "&password=" + password + "&format=xml\"";
                String result = execCurl(cUrlCheck);
                if (result != null) {
                    String px = "<task_id>";
                    int pos = result.indexOf(px);
                    if (pos != -1) {
                        String newPx = result.substring(pos + px.length());
                        int pos2 = newPx.indexOf("<");
                        return newPx.substring(0, pos2);
                    }
                } else {
                    log.error(cUrlCheck + " 执行错误");
                }
            } else {
                log.error("写文件失败:{}", xmlPath);
            }
            return "";
        }

    }

    /**
     * java 调用 Curl的方法
     *
     * @param cmds
     * @return
     */
    public static String execCurl(String cmds) {
        ProcessBuilder processBuilder = new ProcessBuilder();
        if (!System.getProperty("os.name").contains("Windows")) {
            processBuilder.command("bash", "-c", cmds);
        } else {
            processBuilder.command("cmd.exe", "/c", cmds);
        }
        log.info(cmds);
        Process p = null;
        BufferedReader reader = null;
        try {
            p = processBuilder.start();
            reader = new BufferedReader(new InputStreamReader(p.getInputStream()));
            StringBuilder builder = new StringBuilder();
            String line;
            while ((line = reader.readLine()) != null) {
                builder.append(line);
            }
            int exitVal = p.waitFor();
            if (exitVal == 0) {
                log.info("Curl command to cUrlCheck requested ..." + builder);
            } else {
                log.error("Curl command to cUrlCheck executed with error ..." + builder);
            }
            return builder.toString();
        } catch (Exception e) {
            log.error(e.getMessage(), e);
        } finally {
            IOUtils.close(reader);
            try {
                if (p != null) {
                    p.destroy();
                }
            } catch (Exception ignored) {

            }
        }
        return null;
    }

    /**
     * 创建弱口令扫描任务
     *
     * @param scannerInfo 配置
     * @param taskName    任务
     * @param target      目标
     * @return ID
     */
    public static String createPwsTask(LvmengConfig scannerInfo, String taskName, String target) {
        System.setProperty("jdk.tls.allowUnsafeServerCertChange", "true");
        System.setProperty("sun.security.ssl.allowUnsafeRenegotiation", "true");
        System.setProperty("jdk.tls.client.protocols", "TLSv1,TLSv1.1,TLSv1.2");
        CloseableHttpResponse response = null;
        try {
            ///api/report/task/{task_id}
            Map<String, String> map = new HashMap<>();
            map.put("name", taskName);
            map.put("targets", target);
            //map.put("service_type", "SMB|TELNET|FTP|SSH|POP3|TOMCAT|MSSQL|ORACLE|MYSQL|SYBASE|DB2|MONGODB");
            map.put("service_type", "SSH");
            map.put("template_id", "190");
            map.put("pass_mode", "standard");
            String password = DataUtils.urlEncode(scannerInfo.getPassword());
            //response = doPostForm(scannerInfo, "/api/task/pwd/create?username=" + scannerInfo.getUsername() + "&password=" + password, map);
            response = doPostForm(scannerInfo, "/api/task/pwd/create", map);
            int code = response.getStatusLine().getStatusCode();
            String ret = DataUtils.toBodyString(response.getEntity());
            if (code == 200) {
                JSONObject json = JsonUtils.parse(ret);
                if (json.containsKey("ret_msg") && JsonUtils.equal(json, "ret_msg", "success")) {
                    JSONObject data = json.getJSONObject("data");
                    return JsonUtils.getStr(data, "task_id");
                } else {
                    log.error(taskName + ",code=" + code + " ret=" + getLvmengError(ret));
                }
            } else {
                log.error(taskName + ",code=" + code + " ret=" + getLvmengError(ret));
            }
        } catch (Exception e) {
            log.error(e.getMessage(), e);
        } finally {
            IOUtils.close(response);
        }
        return "";
    }


    /**
     * 创建漏洞扫描任务
     *
     * @param scannerInfo 配置
     * @param taskName    任务
     * @param target      目标
     * @return ID
     */
    public static String createVulWebTask(LvmengConfig scannerInfo, String taskName, String target) {
        System.setProperty("jdk.tls.allowUnsafeServerCertChange", "true");
        System.setProperty("sun.security.ssl.allowUnsafeRenegotiation", "true");
        System.setProperty("jdk.tls.client.protocols", "TLSv1,TLSv1.1,TLSv1.2");
        CloseableHttpResponse response = null;
        try {
            ///api/report/task/{task_id}
            Map<String, String> map = new HashMap<>();
            map.put("name", taskName);
            map.put("targets", target);
            String password = DataUtils.urlEncode(scannerInfo.getPassword());
            //response = doPostForm(scannerInfo, "/api/task/web/create?username=" + scannerInfo.getUsername() + "&password=" + password, map);
            response = doPostForm(scannerInfo, "/api/task/web/create", map);
            int code = response.getStatusLine().getStatusCode();
            String ret = DataUtils.toBodyString(response.getEntity());
            if (code == 200) {
                JSONObject json = JsonUtils.parse(ret);
                if (json.containsKey("ret_msg") && JsonUtils.equal(json, "ret_msg", "success")) {
                    JSONObject data = json.getJSONObject("data");
                    return JsonUtils.getStr(data, "task_id");
                } else {
                    log.error(taskName + ",code=" + code + " ret=" + getLvmengError(ret));
                }
            } else {
                log.error(taskName + ",code=" + code + " ret=" + getLvmengError(ret));
            }
        } catch (Exception e) {
            log.error(e.getMessage(), e);
        } finally {
            IOUtils.close(response);
        }
        return "";
    }

    /**
     * 获取弱口令模版列表
     *
     * @return 列表
     */
    public static List<KvData> getPwdTempList(LvmengConfig scannerInfo, String taskName) {
        System.setProperty("jdk.tls.allowUnsafeServerCertChange", "true");
        System.setProperty("sun.security.ssl.allowUnsafeRenegotiation", "true");
        System.setProperty("jdk.tls.client.protocols", "TLSv1,TLSv1.1,TLSv1.2");
        ///api/userpwd/list
        CloseableHttpResponse response = null;
        try {
            response = get(scannerInfo, "/api/userpwd/list", "");
            int code = response.getStatusLine().getStatusCode();
            String ret = DataUtils.toBodyString(response.getEntity());
            if (code == 200) {
                JSONObject json = JsonUtils.parse(ret);
                if (json.containsKey("ret_msg") && JsonUtils.equal(json, "ret_msg", "success")) {
                    JSONArray data = json.getJSONArray("data");
                    if (data != null) {
                        List<KvData> temList = new ArrayList<>();
                        for (int i = 0; i < data.size(); i++) {
                            JSONObject jsonObject = data.getJSONObject(i);
                            int id = JsonUtils.getInt(jsonObject, "id");
                            if (id > 0) {
                                KvData kv = new KvData();
                                kv.setKey(String.valueOf(id));
                                kv.setStr(JsonUtils.getStr(jsonObject, "title"));
                                temList.add(kv);
                            }
                        }
                        return temList;
                    } else {
                        log.error(taskName + ",code22=" + code + " ret=" + getLvmengError(ret));
                    }

                } else {
                    log.error(taskName + ",code=" + code + " ret=" + getLvmengError(ret));
                }
            } else {
                log.error(taskName + ",code=" + code + " ret=" + getLvmengError(ret));
            }
        } catch (Exception e) {
            log.error(e.getMessage(), e);
        } finally {
            IOUtils.close(response);
        }
        return null;
    }

    private static String getLvmengError(String ret) {
        try {
            JSONObject json = JsonUtils.parse(ret);
            JSONObject data = json.getJSONObject("data");
            if (data != null && data.containsKey("param_error")) {
                data.put("param_error", DataUtils.unicodeToCn(data.getString("param_error")));
            }
            if (json.containsKey("ret_msg")) {
                json.put("ret_msg", DataUtils.unicodeToCn(json.getString("ret_msg")));
            }
            return json.toJSONString();
        } catch (Exception e) {
            return ret;
        }
    }
}
