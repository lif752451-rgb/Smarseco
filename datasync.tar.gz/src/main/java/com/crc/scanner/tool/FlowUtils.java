package com.crc.scanner.tool;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;
import com.crc.common.utils.HttpUtils;
import lombok.extern.slf4j.Slf4j;

import java.util.List;

@Slf4j
public class FlowUtils {

    public static String unrepaired(String api, List<String> idList) {
        try {
            String ret = HttpUtils.sendPost(api + "/vuln/process/loop/review/reject", JSON.toJSONString(idList));
            log.info(api + ",unrepaired=" + ret);
            return ret;
        } catch (Exception e) {
            log.error(e.getMessage(), e);
        }
        return "";
    }

    public static String repaired(String api, List<String> idList) {
        try {
            String ret = HttpUtils.sendPost(api + "/vuln/process/loop/review/pass", JSON.toJSONString(idList));
            log.info(api + "，repaired=" + ret);
            return ret;
        } catch (Exception e) {
            log.error(e.getMessage(), e);
        }
        return "";
    }

    public static String vulCallBack(String api, JSONObject json) {
        try {
            String ret = HttpUtils.sendPost(api + "/vuln/process/loop/callback", json.toJSONString());
            log.info(api + "，callback=" + ret);
            return ret;
        } catch (Exception e) {
            log.error(e.getMessage(), e);
        }
        return "";
    }

}
