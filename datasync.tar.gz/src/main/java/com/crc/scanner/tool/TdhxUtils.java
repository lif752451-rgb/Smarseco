package com.crc.scanner.tool;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONArray;
import com.alibaba.fastjson.JSONObject;
import com.crc.common.constants.Constants;
import com.crc.common.utils.DataUtils;
import com.crc.common.utils.HttpUtils;
import com.crc.common.utils.IOUtils;
import com.crc.common.utils.IdGen;
import com.crc.common.utils.JsonUtils;
import com.crc.scanner.config.TdhxConfig;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.apache.http.client.config.RequestConfig;
import org.apache.http.client.methods.CloseableHttpResponse;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.config.Registry;
import org.apache.http.config.RegistryBuilder;
import org.apache.http.conn.socket.ConnectionSocketFactory;
import org.apache.http.conn.socket.PlainConnectionSocketFactory;
import org.apache.http.conn.ssl.NoopHostnameVerifier;
import org.apache.http.conn.ssl.SSLConnectionSocketFactory;
import org.apache.http.conn.ssl.TrustStrategy;
import org.apache.http.entity.ContentType;
import org.apache.http.entity.mime.MultipartEntityBuilder;
import org.apache.http.entity.mime.content.StringBody;
import org.apache.http.impl.client.BasicCookieStore;
import org.apache.http.impl.client.CloseableHttpClient;
import org.apache.http.impl.client.HttpClients;
import org.apache.http.impl.conn.PoolingHttpClientConnectionManager;
import org.apache.http.ssl.SSLContextBuilder;

import javax.net.ssl.HostnameVerifier;
import javax.net.ssl.SSLContext;
import java.nio.charset.StandardCharsets;
import java.util.HashMap;
import java.util.Map;

@Slf4j
public class TdhxUtils {

    /**
     * 任务类型对照MAP
     */
    public static Map<String, String> TASK_TYPE_MAP = new HashMap<String, String>() {
        {
            // 数据库扫描任务返回字段共用 sys_task_id
            put("0", "sys_task_id");
            put("1", "ret_crack_task_id");
            put("3", "web_task_id");
            put("7", "alive_task_id");
        }
    };

    /**
     * 登录扫描器
     */
    public static void login(TdhxConfig scannerInfo) {
        // https://10.232.73.9/async/login/token/?user=admin&pwd=secRoot%23123456
        String url = scannerInfo.getAddress() + "/async/login/token/";
        //String param = String.format("user=%s&pwd=%s", scannerInfo.getUserName(), scannerInfo.getPassword());
        //String ret = HttpUtils.sendGet(url, param);
        Map<String, String> map = new HashMap<>();
        map.put("user", scannerInfo.getUserName());
        map.put("pwd", scannerInfo.getPassword());
        String ret = sendPostFormData(url, null, map);
        JSONObject retJson = JsonUtils.parse(ret);
        if (JsonUtils.getBoolean(retJson, Constants.SUCC)) {
            scannerInfo.setToken(retJson.getString("token"));
        }
        if (StringUtils.isBlank(scannerInfo.getToken())) {
            log.error("获取token失败：" + ret);
        }
    }

    /**
     * 查询规则库模板名称及ID
     */
    public static JSONArray getTemplateList(TdhxConfig scannerInfo, String type) {
        // https://10.232.73.9/async/ruletemplate/query/?type=sysscan sysscan：系统漏洞；webscan：WEB漏洞
        String url = scannerInfo.getAddress() + "/async/ruletemplate/query/";
        String param = String.format("type=%s", type);

        JSONObject header = new JSONObject();
        if (StringUtils.isBlank(scannerInfo.getToken())) {
            login(scannerInfo);
        }
        header.put("token", scannerInfo.getToken());

        String ret = HttpUtils.sendGet(url, param, header);
        JSONObject retJson = JsonUtils.parse(ret);
        if (JsonUtils.getBoolean(retJson, Constants.SUCC)) {
            JSONArray jsonArray = retJson.getJSONArray("aData");
            if (jsonArray != null) {
                return jsonArray;
            }
        }
        log.error("获取规则库模板失败：" + ret);
        return null;
    }

    /**
     * 任务列表查询
     */
    public static JSONArray postTaskList(TdhxConfig scannerInfo, String type) {
        // https://10.232.73.9/async/tasklist/query/
        String url = scannerInfo.getAddress() + "/async/tasklist/query/";

        if (StringUtils.isBlank(scannerInfo.getToken())) {
            login(scannerInfo);
        }
        String ret = sendPostFormData(url, scannerInfo.getToken(), new HashMap<>(1));
        JSONObject retJson = JsonUtils.parse(ret);
        if (JsonUtils.getBoolean(retJson, Constants.SUCC)) {
            JSONArray jsonArray = retJson.getJSONArray("aaData");
            if (jsonArray != null) {
                return jsonArray;
            }
        }
        log.error("获取任务列表失败：" + ret);
        return null;
    }

    /**
     * 告警模板查询
     */
    public static JSONArray findAlarmTemplateList(TdhxConfig scannerInfo) {
        // https://10.232.73.9/async/alarm/query/
        String url = scannerInfo.getAddress() + "/async/alarm/query/";

        JSONObject header = new JSONObject();
        if (StringUtils.isBlank(scannerInfo.getToken())) {
            login(scannerInfo);
        }
        header.put("token", scannerInfo.getToken());

        String ret = HttpUtils.sendPost(url, null, header);
        JSONObject retJson = JsonUtils.parse(ret);
        if (JsonUtils.getBoolean(retJson, Constants.SUCC)) {
            JSONArray jsonArray = retJson.getJSONArray("aData");
            if (jsonArray != null) {
                return jsonArray;
            }
        }
        log.error("获取告警模板失败：" + ret);
        return null;
    }

    /**
     * 状态标识码	状态信息
     * 0: 未提交
     * 1: 已提交
     * 2: 提交失败
     * 3: 正在运行
     * 4: 已完成
     * 5：已跳过
     * 6: 已停止
     * 7：已暂停
     * 8：等待
     * 9：已超时
     * 状态为 4、6时，可以跳过任务不再查询状态
     */
    public static JSONObject postTaskStatus(TdhxConfig scannerInfo, Integer taskId) {
        // https://10.232.73.9/async/status/?taskallid=4
        String url = scannerInfo.getAddress() + "/async/status/";
        if (StringUtils.isBlank(scannerInfo.getToken())) {
            login(scannerInfo);
        }
        Map<String, String> map = new HashMap<>(16);
        map.put("taskallid", taskId.toString());
        String ret = sendPostFormData(url, scannerInfo.getToken(), map);
        JSONObject retJson = JsonUtils.parse(ret);
        /*
         * {
         * 	"progress": 100,
         * 	"scheduletype": 0,
         * 	"status": 4,
         * 	"success": true,
         * 	"sys_progress": 100
         * }
         */
        if (JsonUtils.getBoolean(retJson, Constants.SUCC)) {
            return retJson;
        }
        log.error("获取进度失败：" + ret);
        return null;
    }

    /**
     * 系统漏洞扫描结果数据查询
     */
    public static JSONObject postSysVulResult(TdhxConfig scannerInfo, Integer taskId) {
        // https://10.232.73.9/async/sysscan/query/?taskid=3
        String url = scannerInfo.getAddress() + "/async/sysscan/query/";
        if (StringUtils.isBlank(scannerInfo.getToken())) {
            login(scannerInfo);
        }
        Map<String, String> map = new HashMap<>(16);
        map.put("taskid", taskId.toString());
        String ret = sendPostFormData(url, scannerInfo.getToken(), map);
        JSONObject retJson = JsonUtils.parse(ret);
        if (JsonUtils.getBoolean(retJson, Constants.SUCC)) {
            return retJson;
        }
        log.error("获取系统漏洞扫描结果数据失败：" + ret);
        return null;
    }

    /**
     * 弱口令漏洞扫描结果数据查询
     */
    public static JSONObject postCrackVulResult(TdhxConfig scannerInfo, Integer taskId) {
        // https://10.232.73.9/async/crack/query/?taskid=3
        String url = scannerInfo.getAddress() + "/async/crack/query/";
        if (StringUtils.isBlank(scannerInfo.getToken())) {
            login(scannerInfo);
        }
        Map<String, String> map = new HashMap<>(16);
        map.put("taskid", taskId.toString());
        String ret = sendPostFormData(url, scannerInfo.getToken(), map);
        JSONObject retJson = JsonUtils.parse(ret);
        if (JsonUtils.getBoolean(retJson, Constants.SUCC)) {
            return retJson;
        }
        log.error("获取弱口令漏洞扫描结果数据失败：" + ret);
        return null;
    }

    /**
     * WEB漏洞扫描结果数据查询
     */
    public static JSONObject postWebVulResult(TdhxConfig scannerInfo, Integer taskId) {
        // https://10.232.73.9/async/webscan/query/?taskid=3
        String url = scannerInfo.getAddress() + "/async/webscan/query/";
        if (StringUtils.isBlank(scannerInfo.getToken())) {
            login(scannerInfo);
        }
        Map<String, String> map = new HashMap<>(16);
        map.put("taskid", taskId.toString());
        String ret = sendPostFormData(url, scannerInfo.getToken(), map);
        JSONObject retJson = JsonUtils.parse(ret);
        if (JsonUtils.getBoolean(retJson, Constants.SUCC)) {
            return retJson;
        }
        log.error("获取WEB漏洞扫描结果数据失败：" + ret);
        return null;
    }

    public static JSONObject createTask(TdhxConfig scannerInfo, String taskType, String taskName, String targetUrl) {
        String url = scannerInfo.getAddress() + "/async/newtask/add/";
        /*
        默认为0（默认时只下发系统扫描任务）可选0（系统扫描），1（口令猜解）3（WEB扫描），4 （数据库）,7（存活探测），只要选7则系统只进行存活探测，不进行其他扫描。
        {
            "name": "网站扫描-200",
            "task_type": "0",
            "target": "10.207.32.70"
        }
         */
        JSONObject param = new JSONObject();
        param.put("name", taskName + "-" + IdGen.uuid());
        param.put("task_type", taskType);
        param.put("target", targetUrl);

        if (StringUtils.isBlank(scannerInfo.getToken())) {
            login(scannerInfo);
        }
        JSONObject header = new JSONObject();
        header.put("token", scannerInfo.getToken());

        String ret = HttpUtils.sendPost(url, JSON.toJSONString(param), header);
        JSONObject retJson = JsonUtils.parse(ret);
        if (JsonUtils.getBoolean(retJson, Constants.SUCC)) {
            return retJson;
        }
        log.error("创建任务失败：" + ret);
        return null;
    }

    /**
     * POST form-data请求
     *
     * @param url   接口地址
     * @param param json参数
     * @return 返回
     */
    public static String sendPostFormData(String url, String token, Map<String, String> param) {
        CloseableHttpClient httpClient = null;
        CloseableHttpResponse response = null;
        try {
            httpClient = getHttpClient();

            HttpPost post = new HttpPost(url);
            RequestConfig requestConfig = RequestConfig.custom().setConnectionRequestTimeout(600000)
                    .setConnectTimeout(600000).setSocketTimeout(600000).build();
            post.setConfig(requestConfig);
            log.info("sendPostFormData:" + url + "参数：{}", param.toString());
            final MultipartEntityBuilder builder = MultipartEntityBuilder.create();
            if (param.size() > 0) {
                param.forEach((k, v) -> builder.addPart(k, new StringBody(v, ContentType.TEXT_PLAIN.withCharset(StandardCharsets.UTF_8))));
            }
            builder.setCharset(StandardCharsets.UTF_8);
            builder.setContentType(ContentType.MULTIPART_FORM_DATA);
            post.setEntity(builder.build());
            if (StringUtils.isNotBlank(token)) {
                post.setHeader("token", token);
            }
            // 发送请求并处理响应
            response = httpClient.execute(post);
            return DataUtils.toBodyString(response.getEntity());
        } catch (Exception e) {
            log.error(e.getMessage(), e);
        } finally {
            IOUtils.close(response);
            IOUtils.close(httpClient);
        }
        return null;
    }

    public static CloseableHttpClient getHttpClient() {
        try {
            System.setProperty("jdk.tls.allowUnsafeServerCertChange", "true");
            System.setProperty("sun.security.ssl.allowUnsafeRenegotiation", "true");
            System.setProperty("jdk.tls.client.protocols", "TLSv1,TLSv1.1,TLSv1.2");
            //使用 loadTrustMaterial() 方法实现一个信任策略，信任所有证书
            // 信任所有
            SSLContext sslContext = new SSLContextBuilder().loadTrustMaterial(null, (TrustStrategy) (chain, authType) -> true).build();
            //NoopHostnameVerifier类:  作为主机名验证工具，实质上关闭了主机名验证，它接受任何
            //有效的SSL会话并匹配到目标主机。
            HostnameVerifier hostnameVerifier = NoopHostnameVerifier.INSTANCE;
            SSLConnectionSocketFactory sslsf = new SSLConnectionSocketFactory(sslContext, hostnameVerifier);

            Registry<ConnectionSocketFactory> registry = RegistryBuilder.<ConnectionSocketFactory>create()
                    .register("http", new PlainConnectionSocketFactory())
                    .register("https", sslsf)
                    .build();
            PoolingHttpClientConnectionManager cm = new PoolingHttpClientConnectionManager(registry);
            cm.setMaxTotal(100);
            return HttpClients.custom()
                    .setSSLSocketFactory(sslsf)
                    .setDefaultCookieStore(new BasicCookieStore())
                    .setConnectionManager(cm).build();
        } catch (Exception e) {
            log.error(e.getMessage(), e);
        }
        return HttpClients.createDefault();
    }

}
