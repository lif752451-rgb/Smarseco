package com.crc.scanner.tool;

import com.alibaba.fastjson.JSONObject;
import com.crc.common.utils.*;
import com.crc.scanner.config.QtConfig;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import sun.net.www.protocol.https.Handler;

import javax.net.ssl.HostnameVerifier;
import javax.net.ssl.HttpsURLConnection;
import javax.net.ssl.SSLContext;
import javax.net.ssl.TrustManager;
import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.ArrayList;
import java.util.List;


@Slf4j
public class QingtengV2Utils {

    /**
     * 获取漏洞 ID 列表
     *
     * @param scannerInfo 扫描器
     * @return 清单
     */
    public static List<JSONObject> getVulnListByIp(QtConfig scannerInfo, String url, String ip) {
        url = scannerInfo.getAddress() + url;
        String param = "{\n" +
                "\t\"filters\": [\n" +
                "\t\t\"group\"\n" +
                "\t],\n" +
                "\t\"size\": 500,\n" +
                "\t\"page\": 1,\n" +
                "\t\"orders\": [\n" +
                "\t\t{\n" +
                "\t\t\t\"field\": \"total\",\n" +
                "\t\t\t\"ascend\": false\n" +
                "\t\t},\n" +
                "\t\t{\n" +
                "\t\t\t\"field\": \"ip\",\n" +
                "\t\t\t\"ascend\": false\n" +
                "\t\t}\n" +
                "\t],\n" +
                "\t\"search\": {\n" +
                "\t\t\"ip\": \"" + ip + "\"\n" +
                "\t}\n" +
                "}";
        JSONObject header = new JSONObject();
        String sessionId = loginV2(scannerInfo);
        if (StringUtils.isBlank(sessionId)) {
            log.error("获取token 为空：" + url);
            return new ArrayList<>();
        }
        header.put("Cookie", sessionId);
        header.put("Referer", scannerInfo.getRefer());
        String ret = HttpUtils.sendPost(url, param, header);
        System.out.println(ret);
        return new ArrayList<>();
    }

    /**
     * 获取漏洞 ID 列表
     *
     * @param scannerInfo 扫描器
     * @return 清单
     */
    public static List<JSONObject> getVulnIdList(QtConfig scannerInfo, String url) {
        url = scannerInfo.getAddress() + url;
        String param = "{\n" +
                "\t\"size\": 10000,\n" +
                "\t\"orders\": [\n" +
                "\t\t{\n" +
                "\t\t\t\"field\": \"publicDate\",\n" +
                "\t\t\t\"ascend\": false\n" +
                "\t\t}\n" +
                "\t]\n" +
                "}";
        JSONObject header = new JSONObject();
        String sessionId = loginV2(scannerInfo);
        if (StringUtils.isBlank(sessionId)) {
            log.error("获取token 为空：" + url);
            return new ArrayList<>();
        }
        header.put("Cookie", sessionId);
        header.put("Referer", scannerInfo.getRefer());
        String ret = HttpUtils.sendPost(url, param, header);
        System.out.println(ret);
        return new ArrayList<>();
    }

    /**
     * 登录扫描器
     */
    public static String loginV2(QtConfig scannerInfo) {

        String url = scannerInfo.getAddress();
        if (StringUtils.isBlank(url)) {
            return "";
        }
        String ret = HttpUtils.sendGet(scannerInfo.getAddress() + "/v1/api/front/get_frontend_config", null);
        JSONObject retJson = JsonUtils.parse(ret);
        long timestamp = System.currentTimeMillis() / 1000;
        String newPass = RSAUtils.encrypt(String.format("%s%d", scannerInfo.getPassword(), timestamp), JsonUtils.getStr(retJson, "data"));
        System.out.println(timestamp);
        JSONObject param = new JSONObject();
        param.put("username", scannerInfo.getUsername());
        param.put("password", newPass);
        param.put("timestamp", timestamp);
        param.put("step", "1");


        return sendPostSession(scannerInfo.getAddress() + "/v1/api/front/login", param.toJSONString());
    }

    public static String sendPostSession(String urlPath, String json) {
        if (StringUtils.isBlank(urlPath)) {
            return null;
        }
        if (urlPath.startsWith("https")) {
            return sendHttpsPostSession(urlPath, json);
        }
        OutputStream out = null;
        BufferedReader in = null;
        HttpURLConnection urlConnection = null;
        try {
//            log.info("sendPost - " + urlPath + ",JSON参数：" + json);
            URL url = new URL(urlPath);
            urlConnection = (HttpURLConnection) url.openConnection();
            // 设置doOutput属性为true表示将使用此urlConnection写入数据
            urlConnection.setDoOutput(true);
            urlConnection.setRequestMethod("POST");
            // 定义待写入数据的内容类型，我们设置为application/x-www-form-urlencoded类型
            urlConnection.setRequestProperty("accept", "*/*");
            urlConnection.setRequestProperty("Connection", "Keep-Alive");
            urlConnection.setRequestProperty("Charset", "UTF-8");
            urlConnection.setRequestProperty("Content-Type", "application/json;charset=UTF-8");
            urlConnection.setConnectTimeout(HttpUtils.CONN_TIME_OUT);
            urlConnection.setReadTimeout(HttpUtils.READ_TIME_OUT);

            // 得到请求的输出流对象
            out = urlConnection.getOutputStream();
            // 把数据写入请求的Body
            if (StringUtils.isNotBlank(json)) {
                out.write(json.getBytes());
            }
            out.flush();
            // 定义BufferedReader输入流来读取URL的响应
            in = new BufferedReader(new InputStreamReader(urlConnection.getInputStream()));
            String line;
            StringBuilder result = new StringBuilder();
            while ((line = in.readLine()) != null) {
                result.append(line);
            }
            log.info(result.toString());
            //第一次运行的时候，记录下来session的值
            String cookieVal = urlConnection.getHeaderField("Set-Cookie");
            if (cookieVal != null) {
                return cookieVal.substring(0, cookieVal.indexOf(";"));
            }

        } catch (Exception e) {
            log.error(urlPath + " -- " + e.getMessage(), e);
        }
        // 使用finally块来关闭输出流、输入流
        finally {
            IOUtils.close(in);
            IOUtils.close(out);
            IOUtils.close(urlConnection);
        }
        return "";
    }

    /**
     * @param urlPath 对方地址
     * @param json    要传送的数据
     * @return
     */
    public static String sendHttpsPostSession(String urlPath, String json) {
        OutputStream out = null;
        BufferedReader in = null;
        StringBuilder result = new StringBuilder();
        HttpsURLConnection urlConnection = null;
        try {
            SSLContext sslContext = SSLContext.getInstance("SSL");
            sslContext.init(null, new TrustManager[]{new HttpsUtils.TrustAnyTrustManager()}, new java.security.SecureRandom());
//            log.info("sendPostSession - " + urlPath + ",JSON参数：" + json);
            // 获取SSLSocketFactory对象
            HostnameVerifier HostnameVerifier = (var1, var2) -> true;
            URL url = new URL(null, urlPath.replace("\n", "").replace(" ", ""), new Handler());
            urlConnection = (HttpsURLConnection) url.openConnection();
            urlConnection.setSSLSocketFactory(sslContext.getSocketFactory());
            // 设置doOutput属性为true表示将使用此urlConnection写入数据
            urlConnection.setDoOutput(true);
            // 定义待写入数据的内容类型，我们设置为application/x-www-form-urlencoded类型
            urlConnection.setRequestProperty("accept", "*/*");
            urlConnection.setRequestProperty("Connection", "Keep-Alive");
            urlConnection.setRequestProperty("Charset", "UTF-8");
            urlConnection.setRequestProperty("Content-Type", "application/json;charset=UTF-8");
            urlConnection.setConnectTimeout(HttpUtils.CONN_TIME_OUT);
            urlConnection.setReadTimeout(HttpUtils.READ_TIME_OUT);
            urlConnection.setHostnameVerifier(HostnameVerifier);
            // 得到请求的输出流对象
            out = urlConnection.getOutputStream();
            // 把数据写入请求的Body
            if (StringUtils.isNotBlank(json)) {
                out.write(json.getBytes());
            }
            out.flush();
            // 定义BufferedReader输入流来读取URL的响应
            in = new BufferedReader(new InputStreamReader(urlConnection.getInputStream()));
            String line;
            while ((line = in.readLine()) != null) {
                result.append(line);
            }
            //第一次运行的时候，记录下来session的值
            String cookieVal = urlConnection.getHeaderField("Set-Cookie");
            if (cookieVal != null) {
                return cookieVal.substring(0, cookieVal.indexOf(";"));
            }
            log.info(result.toString());
        } catch (Exception e) {
            log.error(urlPath + " -- " + e.getMessage(), e);
        }
        // 使用finally块来关闭输出流、输入流
        finally {
            IOUtils.close(in);
            IOUtils.close(out);
            IOUtils.close(urlConnection);
        }
        return "";
    }

    public static String getVulListById(QtConfig scannerInfo, String url, String agentId) {
        url = scannerInfo.getAddress() + url;
        String param = "{\n" +
                "\t\"page\": 1,\n" +
                "\t\"size\": 500,\n" +
                "\t\"orders\": [\n" +
                "\t\t{\n" +
                "\t\t\t\"field\": \"severity\",\n" +
                "\t\t\t\"ascend\": false\n" +
                "\t\t}\n" +
                "\t],\n" +
                "\t\"params\": {\n" +
                "\t\t\"agentId\": \""+agentId+"\"\n" +
                "\t},\n" +
                "\t\"filters\": []\n" +
                "}";
        JSONObject header = new JSONObject();
        String sessionId = loginV2(scannerInfo);
        if (StringUtils.isBlank(sessionId)) {
            log.error("获取token 为空：" + url);
            return null;
        }
        header.put("Cookie", sessionId);
        header.put("Referer", scannerInfo.getRefer());
        return HttpUtils.sendPost(url, param, header);
    }
}
