package com.crc.scanner.tool;

import com.alibaba.fastjson.JSONArray;
import com.alibaba.fastjson.JSONObject;
import com.crc.common.utils.DataUtils;
import com.crc.common.utils.HttpFileUtils;
import com.crc.common.utils.JsonUtils;
import com.crc.scanner.config.ZhuoMuNiaoConfig;
import com.crc.secface.domain.CodeCheckRule;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;

import java.io.File;
import java.util.ArrayList;
import java.util.List;

@Slf4j
public class ZhuoMuNiaoUtils {

    /**
     * 下发任务漏洞
     *
     * @param config   配置
     * @param param    参数
     * @param taskName 任务名称
     * @return id
     */
    public static String addTask(ZhuoMuNiaoConfig config, JSONObject param, String taskName) {
        ///cp4/webInterface/postSourceCodeBySvnGit.action
        String url = config.getAddress() + "/cp4/webInterface/postSourceCodeBySvnGit.action";


        param.put("auth", config.getPassword());
        //{"status":0,"projetcId":"xxx","taskId":"yyy"}
        String ret = HttpFileUtils.sendPostFormData(url, param);

        JSONObject retJson = JsonUtils.parse(ret);
        if (JsonUtils.equal(retJson, "status", "0")) {
            String taskId = JsonUtils.getStr(retJson, "taskId");
            log.info("{}新增任务{}", taskName, taskId);
            return taskId;
        } else {
            log.info("{}新增任务={}", taskName, ret);
        }
        return "";
    }


    public static List<String> getLanguageList(ZhuoMuNiaoConfig config) {
        ///cp4/webInterface/queryLangType.action
        String url = config.getAddress() + "/cp4/webInterface/queryLangType.action";

        JSONObject jsonObject = new JSONObject();
        jsonObject.put("auth", config.getPassword());

        String ret = HttpFileUtils.sendPostFormData(url, jsonObject);

        //{"status":0,"language":["JAVA","C","PYTHON","PHP","SQL","JAVASCRIPT","CS","GO"]}
        JSONObject retJson = JsonUtils.parse(ret);
        List<String> langList = new ArrayList<>();
        if (JsonUtils.equal(retJson, "status", "0")) {
            JSONArray jsonArray = retJson.getJSONArray("language");
            if (jsonArray != null) {
                for (int i = 0; i < jsonArray.size(); i++) {
                    if (StringUtils.isNotBlank(jsonArray.getString(i))) {
                        langList.add(jsonArray.getString(i).trim());
                    }
                }
            }
        }
        return langList;
    }

    public static int getProjId(ZhuoMuNiaoConfig config) {
        ///cp4/webInterface/queryLangType.action
        String url = config.getAddress() + "/cp4/webInterface/queryProjectGroup.action";

        JSONObject jsonObject = new JSONObject();
        jsonObject.put("auth", config.getPassword());

        String ret = HttpFileUtils.sendPostFormData(url, jsonObject);

        //{"status":0,"result":[{"id":16,"projectName":"默认"," departmentId":1},{"id":15,"projectName":"TestGroup"," departmentId ":1}]}
        //{"status":1,"errorMsg":"xxxx"}
        JSONObject retJson = JsonUtils.parse(ret);
        if (JsonUtils.equal(retJson, "status", "0")) {
            JSONArray jsonArray = retJson.getJSONArray("result");
            if (jsonArray != null) {
                for (int i = 0; i < jsonArray.size(); i++) {
                    JSONObject proj = jsonArray.getJSONObject(i);
                    if (proj != null && proj.containsKey("id")) {
                        int projId = DataUtils.toInt(proj.getString("id"));
                        if (projId > 0) {
                            return projId;
                        }
                    }
                }
            }
        }
        return 0;
    }

    public static List<CodeCheckRule> getRuleList(ZhuoMuNiaoConfig config) {
        ///cp4/webInterface/queryRuleList.action
        String url = config.getAddress() + "/cp4/webInterface/queryRuleList.action";

        JSONObject jsonObject = new JSONObject();
        jsonObject.put("auth", config.getPassword());

        String ret = HttpFileUtils.sendPostFormData(url, jsonObject);

        //{"status":0,"ruleList":[{"ruleId":"17","name":"zdy","extra":"CP.VUL.XSS,CP.VUL.XSS.DB,CP.VUL.XSS.REF,CP.JAVA.SQL.Injection","language":"JAVA"},{"ruleId":"18","name":"gghh","extra":"CP.PHP.Command.Injection,CP.PHP.SQL.Injection","language":"PHP"}]}
        JSONObject retJson = JsonUtils.parse(ret);
        List<CodeCheckRule> langList = new ArrayList<>();
        if (JsonUtils.equal(retJson, "status", "0")) {
            JSONArray jsonArray = retJson.getJSONArray("ruleList");
            if (jsonArray != null) {
                for (int i = 0; i < jsonArray.size(); i++) {
                    CodeCheckRule vo = new CodeCheckRule();
                    JSONObject json = jsonArray.getJSONObject(i);
                    if (StringUtils.isNotBlank(JsonUtils.getStr(json, "ruleId"))) {
                        vo.setId(JsonUtils.getStr(json, "ruleId"));
                        vo.setExtraList(JsonUtils.getStr(json, "extra"));
                        vo.setLang(JsonUtils.getStr(json, "language"));
                        vo.setName(JsonUtils.getStr(json, "name"));
                        langList.add(vo);
                    }
                }
            }
        }
        return langList;
    }

    /**
     * 下发任务漏洞
     *
     * @param config     配置
     * @param jsonObject 参数
     * @param taskName   任务名称
     * @param filePath   文件路径
     * @return id
     */
    public static String addFileTask(ZhuoMuNiaoConfig config, JSONObject jsonObject, String taskName, String filePath) {
        ///cp4/webInterface/queryRuleList.action
        String url = config.getAddress() + "/cp4/webInterface/postSourceCode.action";
        jsonObject.put("auth", config.getPassword());
        log.info("addFileTask=" + filePath);
        String ret = HttpFileUtils.sendPostFile(url, jsonObject, new File(filePath));
        JSONObject retJson = JsonUtils.parse(ret);
        if (JsonUtils.equal(retJson, "status", "0")) {
            String taskId = JsonUtils.getStr(retJson, "taskId");
            log.info("{}新增任务{}", taskName, taskId);
            return taskId;
        } else {
            log.error("{}=执行任务错误:{}", taskName, ret);
        }
        return "";
    }

    /**
     * 任务状态
     *
     * @param config   配置
     * @param taskName 任务名称
     * @param jobId    执行任务ID
     * @return 状态
     */
    public static String getTaskStatus(ZhuoMuNiaoConfig config, String taskName, String jobId) {
        ///cp4/webInterface/queryTaskStatus.action
        String url = config.getAddress() + "/cp4/webInterface/queryTaskStatus.action";
        JSONObject jsonObject = new JSONObject();
        jsonObject.put("auth", config.getPassword());
        jsonObject.put("taskId", jobId);

        String ret = HttpFileUtils.sendPostFormData(url, jsonObject);
        JSONObject retJson = JsonUtils.parse(ret);
        //{"status":0,"taskId":"xxxx" ,"taskStatus ":1}
        //taskStatus: 该检测任务的当前状态码：0上传成功或解压失败；1已解压待检测；2检测中；3检测完成；4检测异常；99排队中；
        if (JsonUtils.equal(retJson, "status", "0")) {
            String taskStatus = JsonUtils.getStr(retJson, "taskStatus");
            log.info("{}任务状态：{}", taskName, taskStatus);
            return taskStatus;
        }
        return "";
    }

    //一般reqNum应从1开始，在返回的json中有problemCount表示总缺陷数，然后用户根据总缺陷数进行多次调用，
    //每次获取的条数，默认500条，不足500的，也算一次
    public static JSONObject getTask(ZhuoMuNiaoConfig config, String taskName, String jobId, int reqNum) {
        String url = config.getAddress() + "/cp4/webInterface/getTaskResult.action";
        JSONObject jsonObject = new JSONObject();
        jsonObject.put("auth", config.getPassword());
        jsonObject.put("taskId", jobId);
        jsonObject.put("requestNum", reqNum);

        String ret = HttpFileUtils.sendPostFormData(url, jsonObject);
        JSONObject retJson = JsonUtils.parse(ret);
        //{"status":0,"taskId":"xxxx" ,"taskStatus ":1}
        //taskStatus: 该检测任务的当前状态码：0上传成功或解压失败；1已解压待检测；2检测中；3检测完成；4检测异常；99排队中；
        if (JsonUtils.equal(retJson, "status", "0")) {
            log.info("{}获取代码缺陷：{}", taskName, JsonUtils.getStr(retJson, "problemCount"));
            return retJson;
        }
        return null;
    }

    public static String getReport(ZhuoMuNiaoConfig config, String taskId) {
        ///cp4/webInterface/getPdfReport.action
        String url = config.getAddress() + "/cp4/webInterface/getPdfReport.action";
        JSONObject jsonObject = new JSONObject();
        jsonObject.put("auth", config.getPassword());
        jsonObject.put("taskId", taskId);
        jsonObject.put("reportType", "pdf");

        String filePath = HttpFileUtils.sendGetFile(url, jsonObject);
        log.info("{}获取代码缺陷报告：{}", taskId, filePath);
        return filePath;
    }
}
