package com.crc.scanner.tool;

import com.alibaba.fastjson.JSONArray;
import com.alibaba.fastjson.JSONObject;
import com.crc.common.utils.DataUtils;
import com.crc.common.utils.HttpUtils;
import com.crc.common.utils.IdGen;
import com.crc.common.utils.JsonUtils;
import com.crc.scanner.config.TianRongXinConfig;
import com.crc.secface.domain.VulnScanTaskRecordLog;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;

import java.util.List;


@Slf4j
public class TianRongXinUtils {
    /**
     * 下发主机扫描任务
     */
    public static void createVulTask(TianRongXinConfig scannerInfo, VulnScanTaskRecordLog task, List<String> uuids) {
        ///async/sysscan/add/?target=xxx&user=xxx&pwd=xxx 多个地址用英文逗号(,)分隔
        String target = String.join(",", uuids);
        String password = DataUtils.urlEncode(scannerInfo.getPassword());
        String url = scannerInfo.getAddress() + "/async/sysscan/add/?target=" + target + "&user=" + scannerInfo.getUsername() + "&pwd=" + password + "&name=" + DataUtils.urlEncode(task.getTaskName());
        //数据返回{"success":true, "taskid":1, "jobid":1 }
        String ret = HttpUtils.sendGet(url, "");
        JSONObject retJson = JsonUtils.parse(ret);
        if (retJson.containsKey("success") && retJson.getBoolean("success")) {
            String taskid = JsonUtils.getStr(retJson, "taskid");
            String jobid = JsonUtils.getStr(retJson, "jobid");
            task.setJobId(taskid);
            task.setGroupId(jobid);
        } else {
            log.error("创建天融信扫描任务失败" + task.getTaskName() + " -> " + target + " 返回=" + ret);
        }
    }

    /**
     * 下发主机扫描任务--信创版
     */
    public static void createVulTaskXc(TianRongXinConfig scannerInfo, VulnScanTaskRecordLog task, List<String> uuids) {
        ///async/sysscan/add/?target=xxx&user=xxx&pwd=xxx 多个地址用英文逗号(,)分隔
        try {
            String target = String.join(",", uuids);
            login(scannerInfo);
            String url = scannerInfo.getAddress() + "/home/Api/TaskManage/addVulTask/";
            String params = "scan_name=" + DataUtils.urlEncode(task.getTaskName()) + IdGen.uuid() + "&target_hosts=" + DataUtils.urlEncode(target) + "&userMark=" + scannerInfo.getUserMask();
            String ret = HttpUtils.sendGet(url, params);
            JSONObject data = JsonUtils.parse(ret);
            if (data.containsKey("data") && data.getJSONObject("data").containsKey("uuid")) {
                String uuid = data.getJSONObject("data").getString("uuid");
                if (StringUtils.isNotBlank(uuid)) {
                    task.setJobId(uuid);
                }
            } else {
                log.error("{}下发系统扫描任务错误:{}", task.getTaskName(), ret);
            }
        } catch (Exception e) {
            log.error(e.getMessage(), e);
        }
    }

    /**
     * 下发弱口令任务
     */
    public static void createCrackTask(TianRongXinConfig scannerInfo, VulnScanTaskRecordLog task, List<String> uuids) {
        ///async/sysscan/add/?target=xxx&user=xxx&pwd=xxx 多个地址用英文逗号(,)分隔
        String target = String.join(",", uuids);
        String password = DataUtils.urlEncode(scannerInfo.getPassword());
        String url = scannerInfo.getAddress() + "/async/crack/add/?target=" + target + "&user=" + scannerInfo.getUsername() + "&pwd=" + password + "&name=" + DataUtils.urlEncode(task.getTaskName());
        //数据返回{"success":true, "taskid":1, "jobid":1 }
        String ret = HttpUtils.sendGet(url, "");
        JSONObject retJson = JsonUtils.parse(ret);
        if (retJson.containsKey("success") && retJson.getBoolean("success")) {
            String taskid = JsonUtils.getStr(retJson, "taskid");
            String jobid = JsonUtils.getStr(retJson, "jobid");
            task.setJobId(taskid);
            task.setGroupId(jobid);
        } else {
            log.error("创建天融信扫描任务失败" + task.getTaskName() + " -> " + target + " 返回=" + ret);
        }
    }

    /**
     * 下发弱口令任务
     */
    public static void createCrackTaskXc(TianRongXinConfig scannerInfo, VulnScanTaskRecordLog task, List<String> uuids) {
        try {
            String target = String.join(",", uuids);
            login(scannerInfo);
            String url = scannerInfo.getAddress() + "/home/Api/TaskManage/addWeakTask/";
            String params = "scan_name=" + DataUtils.urlEncode(task.getTaskName()) + IdGen.uuid() + "&target_hosts=" + DataUtils.urlEncode(target) + "&userMark=" + scannerInfo.getUserMask() + "&protocol_dictionarys[]=ftp,1,FTP服务默认用户,通用-常见口令";
            String ret = HttpUtils.sendGet(url, params);
            JSONObject data = JsonUtils.parse(ret);
            if (data.containsKey("data") && data.getJSONObject("data").containsKey("uuid")) {
                String uuid = data.getJSONObject("data").getString("uuid");
                if (StringUtils.isNotBlank(uuid)) {
                    task.setJobId(uuid);
                }
            } else {
                log.error("{}下发系统扫描任务错误:{}", task.getTaskName(), ret);
            }
        } catch (Exception e) {
            log.error(e.getMessage(), e);
        }
    }

    /**
     * 下发WEB扫描任务
     */
    public static void createVulWebTask(TianRongXinConfig scannerInfo, VulnScanTaskRecordLog task, List<String> uuids) {
        ///async/webscan/add/?target=xxx&user=xxx&pwd=xxx 多个地址用英文逗号(,)分隔
        String target = String.join(",", uuids);
        String password = DataUtils.urlEncode(scannerInfo.getPassword());
        String url = scannerInfo.getAddress() + "/async/webscan/add/?target=" + target + "&user=" + scannerInfo.getUsername() + "&pwd=" + password + "&name=" + DataUtils.urlEncode(task.getTaskName());
        //数据返回{"success":true, "taskid":1, "jobid":1 }
        String ret = HttpUtils.sendGet(url, "");
        JSONObject retJson = JsonUtils.parse(ret);
        if (retJson.containsKey("success") && retJson.getBoolean("success")) {
            String taskid = JsonUtils.getStr(retJson, "taskid");
            String jobid = JsonUtils.getStr(retJson, "jobid");
            task.setJobId(taskid);
            task.setGroupId(jobid);
        } else {
            log.error("创建天融信扫描任务失败" + task.getTaskName() + " -> " + target + " 返回=" + ret);
        }
    }

    /**
     * 下发WEB扫描任务
     */
    public static void createVulWebTaskXc(TianRongXinConfig scannerInfo, VulnScanTaskRecordLog task, List<String> uuids) {
        try {
            String target = String.join(",", uuids);
            login(scannerInfo);
            String url = scannerInfo.getAddress() + "/home/Api/TaskManage/addWebTask/";
            String params = "scan_name=" + DataUtils.urlEncode(task.getTaskName()) + IdGen.uuid() + "&target_hosts=" + DataUtils.urlEncode(target) + "&userMark=" + scannerInfo.getUserMask() + "&protocol_dictionarys[]=ftp,1,FTP服务默认用户,通用-常见口令";
            String ret = HttpUtils.sendGet(url, params);
            JSONObject data = JsonUtils.parse(ret);
            if (data.containsKey("data") && data.getJSONObject("data").containsKey("uuid")) {
                String uuid = data.getJSONObject("data").getString("uuid");
                if (StringUtils.isNotBlank(uuid)) {
                    task.setJobId(uuid);
                }
            } else {
                log.error("{}下发系统扫描任务错误:{}", task.getTaskName(), ret);
            }
        } catch (Exception e) {
            log.error(e.getMessage(), e);
        }
    }

    /**
     * 获取任务状态
     *
     * @param scannerInfo
     * @param taskName
     * @param d01TaskId
     * @return
     */
    public static JSONObject getTaskStatus(TianRongXinConfig scannerInfo, String taskName, String d01TaskId) {
        ///async/status/?&taskid=xxx&user=xxx&pwd=xxx
//        0: 未提交
//        1: 已提交
//        2: 提交失败
//        3: 正在运行
//        4: 已完成
//        5：已跳过
//        6: 已停止
//        7：已暂停
//        8：等待
//        9：已超时
        String url = scannerInfo.getAddress() + "/async/status/?taskid=" + d01TaskId + "&user=" + scannerInfo.getUsername() + "&pwd=" + scannerInfo.getPassword();
        String ret = HttpUtils.sendGet(url, "");
        JSONObject retJson = JsonUtils.parse(ret);
        if (retJson.containsKey("success") && retJson.getBoolean("success")) {
            return retJson;
        } else {
            log.error("获取天融信扫描任务失败" + taskName + " -> " + d01TaskId + " 返回=" + ret);
        }
        //{"success":true , "status":0 , "progress": "50%" }
        return retJson;
    }

    /**
     * 获取任务状态
     *
     * @param scannerInfo
     * @param taskName
     * @param d01TaskId
     * @return
     */
    public static JSONObject getTaskStatusXc(TianRongXinConfig scannerInfo, String taskName, String d01TaskId) {
        login(scannerInfo);
        ///async/status/?&taskid=xxx&user=xxx&pwd=xxx
//        0: 未提交
//        1: 已提交
//        2: 提交失败
//        3: 正在运行
//        4: 已完成
//        5：已跳过
//        6: 已停止
//        7：已暂停
//        8：等待
//        9：已超时
        String url = scannerInfo.getAddress() + "/home/Api/TaskManage/showTaskStatus/?uuid=" + d01TaskId + "&userMark=" + scannerInfo.getUserMask();
        String ret = HttpUtils.sendGet(url, "");
        JSONObject retJson = JsonUtils.parse(ret);
        if (retJson.containsKey("result") && retJson.getBoolean("result")) {
            return retJson.getJSONObject("rows");
        } else {
            log.error("获取天融信扫描任务失败" + taskName + " -> " + d01TaskId + " 返回=" + ret);
        }
        //{"success":true , "status":0 , "progress": "50%" }
        return retJson;
    }

    public static JSONArray getTask(TianRongXinConfig scannerInfo, String taskName, String d01TaskId, String jobId) {
        ///async/sysscan/query/?taskid=xxx&user=xxx&pwd=xxx
        String url = scannerInfo.getAddress() + "/async/sysscan/query/?taskid=" + d01TaskId + "&jobid=" + jobId + "&user=" + scannerInfo.getUsername() + "&pwd=" + scannerInfo.getPassword();
        String ret = HttpUtils.sendGet(url, "");
        try {
            JSONObject json = JsonUtils.parse(ret);
            if (json.containsKey("success") && json.getBoolean("success")) {
                return json.getJSONArray("hosts");
            } else {
                log.error(taskName + " ret=" + ret);
            }
        } catch (Exception e) {
            log.error(e.getMessage(), e);
        }
        return null;
    }

    public static JSONArray getWebTask(TianRongXinConfig scannerInfo, String taskName, String d01TaskId, String jobId) {
        ///async/sysscan/query/?taskid=xxx&user=xxx&pwd=xxx
        String url = scannerInfo.getAddress() + "/async/webscan/query/?taskid=" + d01TaskId + "&jobid=" + jobId + "&user=" + scannerInfo.getUsername() + "&pwd=" + scannerInfo.getPassword();
        String ret = HttpUtils.sendGet(url, "");
        try {
            JSONObject json = JsonUtils.parse(ret);
            if (json.containsKey("success") && json.getBoolean("success")) {
                return json.getJSONArray("hosts");
            } else {
                log.error(taskName + " ret=" + ret);
            }
        } catch (Exception e) {
            log.error(e.getMessage(), e);
        }
        return null;
    }

    /**
     * 获取弱口令任务
     *
     * @param scannerInfo
     * @param taskName
     * @param d01TaskId
     * @param jobId
     * @return
     */
    public static JSONArray getCrackTask(TianRongXinConfig scannerInfo, String taskName, String d01TaskId, String jobId) {
        ///async/sysscan/query/?taskid=xxx&user=xxx&pwd=xxx
        String url = scannerInfo.getAddress() + "/async/crack/query/?taskid=" + d01TaskId + "&jobid=" + jobId + "&user=" + scannerInfo.getUsername() + "&pwd=" + scannerInfo.getPassword();
        String ret = HttpUtils.sendGet(url, "");
        try {
            JSONObject json = JsonUtils.parse(ret);
            if (json.containsKey("success") && json.getBoolean("success")) {
                return json.getJSONArray("hosts");
            } else {
                log.error(taskName + " ret=" + ret);
            }
        } catch (Exception e) {
            log.error(e.getMessage(), e);
        }
        return null;
    }

    /**
     * 登录--信创版
     *
     * @return
     */
    public static void login(TianRongXinConfig scannerInfo) {
        if (StringUtils.isNotBlank(scannerInfo.getUserMask())) {
            return;
        }
        String url = scannerInfo.getAddress() + "/home/Api/Register/restLogin/";
        String params = "name=" + scannerInfo.getUsername() + "&password=" + scannerInfo.getPassword() + "&tk=";
        String ret = HttpUtils.sendGet(url, params);
        JSONObject body = JsonUtils.parse(ret);
        if (body.containsKey("data") && body.getJSONObject("data").containsKey("authid")) {
            String userMask = body.getJSONObject("data").getString("authid");
            scannerInfo.setUserMask(userMask);
        } else {
            log.error("登录错误:{}", ret);
        }
    }


    public static long getHostTotal(TianRongXinConfig scannerInfo, String uuid) {
        login(scannerInfo);
        String url = scannerInfo.getAddress() + "/home/Api/VulTaskResult/showHostList/?page=1&rows=1&uuid=" + uuid + "&userMark=" + scannerInfo.getUserMask();
        String ret = HttpUtils.sendGet(url, null);
        JSONObject data = JsonUtils.parse(ret);
        if (data.containsKey("total")) {
            return data.getLongValue("total");
        }
        return 0;
    }

    public static long getWeakTotal(TianRongXinConfig scannerInfo, String uuid) {
        login(scannerInfo);
        String url = scannerInfo.getAddress() + "/home/Api/TaskManage/showWeakTaskResults/?page=1&rows=1&uuid=" + uuid + "&userMark=" + scannerInfo.getUserMask();
        String ret = HttpUtils.sendGet(url, null);
        JSONObject data = JsonUtils.parse(ret);
        if (data.containsKey("total")) {
            return data.getLongValue("total");
        }
        return 0;
    }
}
