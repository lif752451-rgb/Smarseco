package com.crc.scanner.tool;

import cn.hutool.core.collection.CollUtil;
import cn.hutool.core.io.IoUtil;
import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONArray;
import com.alibaba.fastjson.JSONObject;
import com.alibaba.fastjson.serializer.SerializerFeature;
import com.crc.common.utils.DataUtils;
import com.crc.common.utils.HttpFileUtils;
import com.crc.common.utils.JsonUtils;
import com.crc.scanner.config.ChangTingConfig;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.apache.http.HttpEntity;
import org.apache.http.client.config.RequestConfig;
import org.apache.http.client.methods.CloseableHttpResponse;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.client.methods.HttpRequestBase;
import org.apache.http.entity.StringEntity;
import org.apache.http.impl.client.CloseableHttpClient;
import org.apache.http.util.EntityUtils;

import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

import static com.crc.common.constants.Constants.*;
import static com.crc.common.constants.Constants.ChangTingApiUrl.*;

/**
 * @ClassName ChangTingUtils
 * @Description 长亭对接工具类
 * @Author fuzhuangzhi
 * @Date 2022/05/19 16:35
 * @Version 1.0
 **/
@Slf4j
public class ChangTingUtils {

    public static JSONObject sendGet(ChangTingConfig scannerInfo, String url, String parameter) {
        log.info("url:{},parameter={}",url,parameter);
        HttpGet httpGet = buildHttpGetReq(scannerInfo, url, parameter);
        if (httpGet == null) {
            log.error("获取httpGet null");
            return new JSONObject();
        }
        setRequestConfig(httpGet);
        CloseableHttpResponse response = null;
        httpGet.setHeader(TOKEN, scannerInfo.getPassword());
        CloseableHttpClient httpClient = null;
        try {
            httpClient = HttpFileUtils.getHttpClient();
            response = httpClient.execute(httpGet);
            int code = response.getStatusLine().getStatusCode();
            String result = DataUtils.toBodyString(response.getEntity());
            if (code == 200) {
                return JsonUtils.parse(result);
            } else {
                log.error("获取数据错误非200OK：{},ret={}", response.getStatusLine(), result);
            }
        } catch (Exception e) {
            log.error(url + " -- " + e.getMessage());
        } finally {
            IoUtil.close(response);
        }
        return new JSONObject();
    }

    private static void setRequestConfig(HttpRequestBase httpRequestBase) {
        RequestConfig requestConfig = RequestConfig.custom().setConnectionRequestTimeout(60000)
                .setConnectTimeout(60000).setSocketTimeout(60000).build();
        httpRequestBase.setConfig(requestConfig);
    }

    private static HttpGet buildHttpGetReq(ChangTingConfig config, String url, String parameter) {
        if (config == null || StringUtils.isBlank(config.getAddress())) {
            log.error("长亭config配置为空");
            return null;
        }
        StringBuilder sb = new StringBuilder();
        String token = config.getPassword();
        if (StringUtils.isBlank(token)) {
            log.error("长亭token为空");
            return null;
        }
        return new HttpGet(String.valueOf(sb.append(config.getAddress()).append(url).append(parameter)));
    }

    private static HttpPost buildHttpPostReq(ChangTingConfig config, String url) {
        if (config == null || StringUtils.isBlank(config.getAddress())) {
            log.error("长亭config配置为空");
            return null;
        }
        StringBuilder sb = new StringBuilder();
        String token = config.getPassword();
        if (StringUtils.isBlank(token)) {
            log.error("长亭token为空");
            return null;
        }
        return new HttpPost(String.valueOf(sb.append(config.getAddress()).append(url)));
    }

    /**
     * POST请求
     */
    public static CloseableHttpResponse sendPost(ChangTingConfig scannerInfo, String url, JSONObject parameter) throws Exception {
        HttpPost httpPost = buildHttpPostReq(scannerInfo, url);
        if (httpPost == null) {
            log.error("获取httpGet null");
            return null;
        }
        httpPost.setHeader(TOKEN, scannerInfo.getPassword());
        setRequestConfig(httpPost);
        httpPost.setHeader("Content-Type", "application/json");
        httpPost.setEntity(new StringEntity(JSONObject.toJSONString(parameter, SerializerFeature.MapSortField),
                "UTF-8"));
        log.info("apiUrl:{},参数:{}", url, DataUtils.getShorter(JSONObject.toJSONString(parameter),200));
        CloseableHttpClient httpClient = HttpFileUtils.getHttpClient();
        return httpClient.execute(httpPost);
    }

    /**
     * 获取所有的工作区
     *
     * @param scannerInfo
     * @param url
     * @param parameter
     * @return
     * @throws Exception
     */
    public static List<Integer> getWorkAreaIds(ChangTingConfig scannerInfo, String url, String parameter) {
        try {
            JSONObject result = sendGet(scannerInfo, url, parameter);
            if (result.containsKey("data")) {
                JSONObject json = result.getJSONObject("data");
                JSONArray contents = JsonUtils.getJsonArray(json, "content");
                return contents.stream().map(t -> ((JSONObject) t).getInteger("id")).collect(Collectors.toList());
            } else {
                log.error("获取工作区错误：" + result);
            }
            return new ArrayList<>();
        } catch (Exception e) {
            log.error(e.getMessage(), e);
        }
        return null;
    }

    /**
     * 获取所有数量
     *
     * @param scannerInfo
     * @param url
     * @param parameter
     * @return
     * @throws Exception
     */
    public static long getTotal(ChangTingConfig scannerInfo, String url, JSONObject parameter) {
        CloseableHttpResponse response = null;
        try {
            response = sendPost(scannerInfo, url, parameter);
            int code = response.getStatusLine().getStatusCode();
            String result = DataUtils.toBodyString(response.getEntity());
            if (code == 200) {
                JSONObject retJson = JsonUtils.parse(result);
                if (retJson.containsKey("data")) {
                    JSONObject json = retJson.getJSONObject("data");
                    return JsonUtils.getLong(json, "total");
                } else {
                    log.error("获取总数量错误：{}", result);
                }
            } else {
                log.error("获取总数量错误非200OK：url:{},result：{}", url, result);
            }
        } catch (Exception e) {
            log.error(e.getMessage(), e);
        } finally {
            IoUtil.close(response);
        }
        return 0;
    }


    /**
     * 获取 XProcess所有已扫描完成的任务
     *
     * @param scannerInfo
     * @param planId      下发扫描id
     * @return XProcess id
     * @throws Exception
     */
    public static JSONObject getXprocess(ChangTingConfig scannerInfo, String planId) {
        CloseableHttpResponse response = null;
        try {
            JSONObject parameter = new JSONObject();
            // 获取工作区id
            List<Integer> workAreaIds = getWorkAreaIds(scannerInfo, WORK_AREA_API_URL, "?limit=200&offset=0");
            if (CollUtil.isEmpty(workAreaIds)) {
                log.error("workAreaIds empty!");
                return null;
            }
            parameter.put("plan_id", planId);
//            parameter.put("XProcessStatusEnum", "FINISHED");
            parameter.put("project_id", workAreaIds.get(0));
            response = sendPost(scannerInfo, XPROCESS_FILTER_API_URL, parameter);
            int code = response.getStatusLine().getStatusCode();
            String ret = DataUtils.toBodyString(response.getEntity());
            if (code == 200) {
                JSONObject result = JsonUtils.parse(ret);
                if (result.containsKey("data")) {
                    JSONObject json = result.getJSONObject("data");
                    if (json == null || json.isEmpty()) {
                        log.error("获取扫描完成任务错误，任务id:{},ret = {}", planId, ret);
                        return null;
                    }
                    JSONArray list = json.getJSONArray(RESULT);
                    if (CollUtil.isNotEmpty(list)) {
                        log.info("获取扫描进度：" + ret);
                        return list.getJSONObject(0);
                    }
                } else {
                    log.error("获取总数量错误：" + ret);
                }
            } else {
                log.error("获取总数量错误非200OK：url:{},ret：{}", XPROCESS_FILTER_API_URL, ret);
            }
        } catch (Exception e) {
            log.error(e.getMessage(), e);
        } finally {
            IoUtil.close(response);
        }
        return null;
    }

    /**
     * 获取漏洞类型列表
     *
     * @param scannerInfo
     * @return
     */
    public static String getVulnCategory(ChangTingConfig scannerInfo,
                                         String typeValue) {
        JSONObject jsonObject = sendGet(scannerInfo, VULN_CATEGORY_API_URL, "");
        if (jsonObject != null && !jsonObject.isEmpty()) {
            JSONArray categorys = JsonUtils.getJsonArray(jsonObject, "data");
            for (Object category : categorys) {
                JSONObject categoryJson = (JSONObject) category;
                if (categoryJson != null && typeValue.equalsIgnoreCase(categoryJson.getString("value"))) {
                    return categoryJson.getString("label");
                }
            }
        }
        return null;
    }

    /**
     * 获取基础Web 漏洞扫描模板id
     *
     * @return
     */
    private static int getBasicWebTemplate(ChangTingConfig scannerInfo, String url, String parameter) {
        JSONObject jsonObject = sendGet(scannerInfo, url, parameter);
        if (jsonObject != null && !jsonObject.isEmpty()) {
            JSONObject dataList = JsonUtils.getJson(jsonObject, DATA_LIST_TAG);
            if (!JsonUtils.isEmpty(dataList)) {
                JSONArray list = JsonUtils.getJsonArray(dataList, CONTENT);
                for (Object data : list) {
                    JSONObject json = (JSONObject) data;
                    if (json != null) {
                        JSONObject strategy = JsonUtils.getJson(json, STRATEGY);
                        if (strategy != null && !strategy.isEmpty()) {
                            String name = JsonUtils.getStr(strategy, "name");
                            if (StringUtils.isNotBlank(name) && name.equalsIgnoreCase("basic_web")) {
                                return JsonUtils.getInt(strategy, "id");
                            }
                        }
                    } else {
                        log.error("获取基础Web 漏洞扫描模板id错误,url:{},parameter:{}", url, parameter);
                    }
                }
            }
        }
        log.info("获取基础Web 漏洞扫描模板id错误,url:{},parameter:{},ret={}", url, parameter, JSON.toJSONString(jsonObject));
        return 0;
    }

    /**
     * 获取基础Web 漏洞扫描模板id
     *
     * @return
     */
    private static int getBasicHostTemplate(ChangTingConfig scannerInfo, String url, String parameter) {
        JSONObject jsonObject = sendGet(scannerInfo, url, parameter);
        if (jsonObject != null && !jsonObject.isEmpty()) {
            JSONObject dataList = JsonUtils.getJson(jsonObject, DATA_LIST_TAG);
            if (!JsonUtils.isEmpty(dataList)) {
                JSONArray list = JsonUtils.getJsonArray(dataList, CONTENT);
                for (Object data : list) {
                    JSONObject json = (JSONObject) data;
                    if (json != null) {
                        JSONObject strategy = JsonUtils.getJson(json, STRATEGY);
                        if (strategy != null && !strategy.isEmpty()) {
                            String name = JsonUtils.getStr(strategy, "name");
                            if (StringUtils.isNotBlank(name) && name.equalsIgnoreCase("basic_host")) {
                                return JsonUtils.getInt(strategy, "id");
                            }
                        }
                    } else {
                        log.error("获取基础服务漏洞扫描模板id错误,url:{},parameter:{}", url, parameter);
                    }
                }
            }
        }
        log.info("获取基础服务漏洞扫描模板id错误,url:{},parameter:{},ret={}", url, parameter, JSON.toJSONString(jsonObject));
        return 0;
    }

    /**
     * 组装
     * "active":true,
     * "basic_setting":{
     * "remark": "",
     * "taskName": "测试任务:10.200.199.21",
     * "whiteList": [],
     * "taskTarget": { "target": ["http://10.200.199.21/"], "targetType": "MANUAL" },
     * "planSetting": { "enabled": false, "planType": "NOW" },
     * "engineChoice": ["3ee3783fb6b44453aedbd191c7290ed8"],
     * "executionSetting": { "enabled": false }
     * },
     * "exec_right_now":true,
     * "task_template_id":18
     *
     * @return
     */
    private static JSONObject getParms(ChangTingConfig scannerInfo, String taskName, int templateId, List<String> targets) {
        if (targets == null || targets.size() < 1) {
            log.error("未配置对应的ip:{}", taskName);
            return null;
        }

        JSONObject parms = new JSONObject();
        JSONObject basicSetting = new JSONObject();
        JSONObject taskTarget = new JSONObject();
        JSONObject planSetting = new JSONObject();
        JSONObject executionSetting = new JSONObject();
        parms.put("active", true);
        basicSetting.put("remark", taskName);
        basicSetting.put("taskName", taskName);
        basicSetting.put("whiteList", new JSONArray());
        taskTarget.put("target", targets);
        taskTarget.put("targetType", "MANUAL"); // 设置手动
        planSetting.put("enabled", false);
        planSetting.put("planType", "NOW");
        basicSetting.put("taskTarget", taskTarget);
        JSONObject jsonObject = new JSONObject();
        jsonObject.put(LIMIT, 20);
        jsonObject.put(OFFSET, 0);
        List<String> engineIds = getEngine(scannerInfo, ENGINE_FILTER_API_URL, jsonObject);
        if (CollUtil.isEmpty(engineIds)) {
            log.error("获取引擎列表失败");
            return null;
        }
        basicSetting.put("engineChoice", engineIds);
        executionSetting.put("enabled", false);
        basicSetting.put("executionSetting", executionSetting);
        basicSetting.put("planSetting", planSetting);
        parms.put("basic_setting", basicSetting);
        parms.put("exec_right_now", true);
        parms.put("task_template_id", templateId);
        return parms;
    }

    /**
     * 获取引擎节点
     *
     * @param scannerInfo
     * @param url
     * @param parameter
     * @return
     */
    private static List<String> getEngine(ChangTingConfig scannerInfo, String url, JSONObject parameter) {
        CloseableHttpResponse response = null;
        try {
            response = sendPost(scannerInfo, url, parameter);
            int code = response.getStatusLine().getStatusCode();
            if (code == 200) {
                JSONObject result = JsonUtils.parse(DataUtils.toBodyString(response.getEntity()));
                if (result.containsKey(DATA_LIST_TAG)) {
                    JSONObject data = result.getJSONObject(DATA_LIST_TAG);
                    if (data != null && !data.isEmpty()) {
                        JSONArray jsonArray = JsonUtils.getJsonArray(data, CONTENT);
                        if (jsonArray != null && !jsonArray.isEmpty()) {
                            return jsonArray.stream().map(t -> ((JSONObject) t).getString("id")).collect(Collectors.toList());
                        }
                    }
                } else {
                    log.error("获取数据错误：" + result);
                }
            } else {
                log.error("获取数据错误非200OK：" + response.getStatusLine());
            }
        } catch (Exception e) {
            log.error(e.getMessage(), e);
        } finally {
            IoUtil.close(response);
        }
        return null;
    }

    /**
     * 获取漏洞扫描结果
     *
     * @param scannerInfo
     * @param parameter
     * @return
     */
    public static JSONObject getScanResult(ChangTingConfig scannerInfo, JSONObject parameter) {
        CloseableHttpResponse response = null;
        try {
            response = sendPost(scannerInfo, RESULT_FILTER_API_URL, parameter);
            int code = response.getStatusLine().getStatusCode();
            String ret = DataUtils.toBodyString(response.getEntity());
            if (code == 200) {
                JSONObject result = JsonUtils.parse(ret);
                if (result.containsKey(DATA_LIST_TAG)) {
                    JSONObject data = result.getJSONObject(DATA_LIST_TAG);
                    if (JsonUtils.isEmpty(data)) {
                        log.error("获取漏洞扫描结果错误，ret:{}", ret);
                        return null;
                    }
                    return data;
                } else {
                    log.error("获取数据错误：" + ret);
                }
            } else {
                log.error("获取数据错误非200OK：" + ret);
            }
        } catch (Exception e) {
            log.error(e.getMessage(), e);
        } finally {
            IoUtil.close(response);
        }
        return null;
    }

    public static String createVulTask(ChangTingConfig scannerInfo, String taskName, List<String> targets) {
        CloseableHttpResponse response = null;
        try {
            // 获取基础Web 漏洞扫描模板id
            int templateId = getBasicHostTemplate(scannerInfo, TEMPLATE_API_URL + "?", "limit=100&offset=0");
            JSONObject parms = getParms(scannerInfo, taskName, templateId, targets);
            response = sendPost(scannerInfo, PLAN_CREATE_API_URL, parms);
            int code = response.getStatusLine().getStatusCode();
            String ret = DataUtils.toBodyString(response.getEntity());
            if (code == 200) {

                JSONObject result = JsonUtils.parse(ret);
                if (result.containsKey(DATA_LIST_TAG)) {
                    JSONObject data = result.getJSONObject(DATA_LIST_TAG);
                    if (data != null && !data.isEmpty()) {
                        return JsonUtils.getStr(data, "id");
                    }
                } else {
                    log.error("获取数据错误：" + ret);
                }
            } else {
                log.error("获取数据错误非200OK：url:{},ret:{}", PLAN_CREATE_API_URL, ret);
            }
        } catch (Exception e) {
            log.error(e.getMessage(), e);
        } finally {
            IoUtil.close(response);
        }
        return null;
    }

    public static String createVulWebTask(ChangTingConfig scannerInfo, String taskName, List<String> targets) {
        CloseableHttpResponse response = null;
        try {
            // 获取基础Web 漏洞扫描模板id
            int templateId = getBasicWebTemplate(scannerInfo, TEMPLATE_API_URL + "?", "limit=100&offset=0");
            JSONObject parms = getParms(scannerInfo, taskName, templateId, targets);
            response = sendPost(scannerInfo, PLAN_CREATE_API_URL, parms);
            int code = response.getStatusLine().getStatusCode();
            String ret = DataUtils.toBodyString(response.getEntity());
            if (code == 200) {

                JSONObject result = JsonUtils.parse(ret);
                if (result.containsKey(DATA_LIST_TAG)) {
                    JSONObject data = result.getJSONObject(DATA_LIST_TAG);
                    if (data != null && !data.isEmpty()) {
                        return JsonUtils.getStr(data, "id");
                    }
                } else {
                    log.error("获取数据错误：" + ret);
                }
            } else {
                log.error("获取数据错误非200OK：url:{},ret:{}", PLAN_CREATE_API_URL, ret);
            }
        } catch (Exception e) {
            log.error(e.getMessage(), e);
        } finally {
            IoUtil.close(response);
        }
        return null;
    }
}

