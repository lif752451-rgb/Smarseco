package com.crc.scanner.tool;

import com.alibaba.fastjson.JSONArray;
import com.crc.common.utils.JsonUtils;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;

import java.util.ArrayList;
import java.util.List;
import java.util.Objects;

@Slf4j
public class ScanInputUtils {
    /*
   自定义输入 1
  从IP资产中选择 2
  从资产网段中选择 3
  从应用系统中选择 4
  从在建应用系统中选择 5
    */
    public static String getScanContent(String scanContent, Integer contentType) {
        return getScanContent(scanContent, contentType, "\n");
    }

    /*
    自定义输入 1
   从IP资产中选择 2
   从资产网段中选择 3
   从应用系统中选择 4
   从在建应用系统中选择 5
     */
    public static String getScanContent(String scanContent, Integer contentType, String split) {
        if (StringUtils.isBlank(scanContent)) {
            return "";
        }

        if (contentType == null) {
            return scanContent;
        }

        scanContent = scanContent.trim();
        if (Objects.equals(1, contentType)) {
            if (Objects.equals(split, "\n")) {
                return scanContent;
            } else {
                return scanContent.replace("\n", split);
            }
        } else if (Objects.equals(2, contentType)) {
            //[{"id":596,"internalIp":"10.201.0.97"},{"id":794,"internalIp":"10.203.0.95"},{"id":1100,"internalIp":"10.102.0.101"}]
            JSONArray jsonArray = JsonUtils.parseArray(scanContent);
            if (jsonArray != null) {
                List<String> ipList = new ArrayList<>();
                for (int i = 0; i < jsonArray.size(); i++) {
                    String ip = jsonArray.getJSONObject(i).getString("internalIp");
                    if (StringUtils.isBlank(ip)) {
                        continue;
                    }
                    ipList.add(ip);
                }
                return String.join(split, ipList);
            }
        } else if (Objects.equals(3, contentType)) {
            /*
            [
                {
                    "id": 119,
                    "segment": "10.0.76.223"
                }
            ]
             */
            JSONArray jsonArray = JsonUtils.parseArray(scanContent);
            if (jsonArray != null) {
                List<String> ipList = new ArrayList<>();
                for (int i = 0; i < jsonArray.size(); i++) {
                    String ip = jsonArray.getJSONObject(i).getString("segment");
                    if (StringUtils.isBlank(ip)) {
                        continue;
                    }
                    ipList.add(ip);
                }
                return String.join(split, ipList);
            }
        } else if (Objects.equals(4, contentType) || Objects.equals(5, contentType)) {
            /*
            包含去重逻辑，无法指定id
            [{"10.54.238.2","10.54.238.1"}]
             */
            JSONArray jsonArray = JsonUtils.parseArray(scanContent);
            if (jsonArray != null) {
                List<String> ipList = jsonArray.toJavaList(String.class);
                return String.join(split, ipList);
            }
        }

        return scanContent;
    }
}
