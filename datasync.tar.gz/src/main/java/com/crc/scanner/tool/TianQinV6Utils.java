package com.crc.scanner.tool;

import com.alibaba.fastjson.JSONObject;
import com.crc.common.utils.DataUtils;
import com.crc.common.utils.HttpFileUtils;
import com.crc.common.utils.JsonUtils;
import com.crc.scanner.config.TianQinConfig;
import lombok.extern.slf4j.Slf4j;
import org.apache.http.client.config.RequestConfig;
import org.apache.http.client.methods.CloseableHttpResponse;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.impl.client.CloseableHttpClient;
import org.apache.http.impl.client.HttpClients;


@Slf4j
public class TianQinV6Utils {
    /**
     * 登录扫描器
     */
    public static String getToken(TianQinConfig scannerInfo) {

        String url = scannerInfo.getAddress();
        String prefix = "/oauth/token?client_id=skylar6_ent_odp&grant_type=password&username=" + scannerInfo.getUsername() + "&password=" + DataUtils.urlEncode(scannerInfo.getPassword());
        //获取扫描器信息
        HttpPost httpRequest = new HttpPost(url + prefix);
        if (url.toLowerCase().startsWith("https")) {
            httpRequest = new HttpPost(url + prefix);
        }
        RequestConfig requestConfig = RequestConfig.custom()
                .setConnectTimeout(45000).setConnectionRequestTimeout(45000)
                .setSocketTimeout(45000).build();
        /*
                {
            "access_token": "767bc09f-acb0-4fe6-82ad-7ce568e33501",
            "expires_in": 2592000,
            "status": "ok"
        }
         */
        httpRequest.setConfig(requestConfig);
        if ("https".equalsIgnoreCase(scannerInfo.getMode())) {
            try (CloseableHttpClient httpClient = HttpFileUtils.getHttpClient();
                 CloseableHttpResponse response = httpClient.execute(httpRequest)) {
                int code = response.getStatusLine().getStatusCode();
                if (code == 200) {
                    String ret = DataUtils.toBodyString(response.getEntity());
                    JSONObject result = JsonUtils.parse(ret);
                    if (JsonUtils.equalVal(result, "status", "ok")) {
                        //重新登录获取session
                        return JsonUtils.getStr(result, "access_token");
                    } else {
                        log.error("天擎登录错误！" + ret);
                    }
                } else {
                    String ret = DataUtils.toBodyString(response.getEntity());
                    log.error("天擎登录错误！" + ret);
                }
            } catch (Exception e) {
                log.error(e.getMessage(), e);
            }
            return null;
        }
        try (CloseableHttpClient httpClient = HttpClients.createDefault();
             CloseableHttpResponse response = httpClient.execute(httpRequest)) {
            int code = response.getStatusLine().getStatusCode();
            if (code == 200) {
                String ret = DataUtils.toBodyString(response.getEntity());
                JSONObject result = JsonUtils.parse(ret);
                if (JsonUtils.equalVal(result, "status", "ok")) {
                    //重新登录获取session
                    return JsonUtils.getStr(result, "access_token");
                } else {
                    log.error("天擎登录错误！" + ret);
                }
            } else {
                String ret = DataUtils.toBodyString(response.getEntity());
                log.error("天擎登录错误！" + ret);
            }
        } catch (Exception e) {
            log.error(e.getMessage(), e);
        }
        return null;
    }
}
