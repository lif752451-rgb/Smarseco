package com.crc.scanner.tool;

import com.alibaba.fastjson.JSONObject;
import com.crc.common.utils.DataUtils;
import com.crc.common.utils.HttpFileUtils;
import com.crc.common.utils.JsonUtils;
import com.crc.scanner.config.SdnConfig;
import lombok.extern.slf4j.Slf4j;
import org.apache.http.client.config.RequestConfig;
import org.apache.http.client.methods.CloseableHttpResponse;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.entity.StringEntity;
import org.apache.http.impl.client.CloseableHttpClient;
import org.apache.http.impl.client.HttpClients;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;

@Slf4j
public class SdnUtils {
    /**
     * 登录扫描器
     */
    public static void login(SdnConfig scannerInfo) {

        String url = scannerInfo.getAddress();
        //获取扫描器信息http://10.114.117.95:30000/token/generate
        HttpPost httpRequest = new HttpPost(url + "/token/generate");
        if (url.toLowerCase().startsWith("https")) {
            httpRequest = new HttpPost(url + "/token/generate");
        }
        RequestConfig requestConfig = RequestConfig.custom()
                .setConnectTimeout(45000).setConnectionRequestTimeout(45000)
                .setSocketTimeout(45000).build();
        httpRequest.setConfig(requestConfig);
        httpRequest.setHeader(HttpHeaders.ACCEPT, MediaType.APPLICATION_JSON_VALUE);
        httpRequest.setHeader(HttpHeaders.CONTENT_TYPE, MediaType.APPLICATION_JSON_UTF8_VALUE);
        httpRequest.setEntity(new StringEntity("{\"userName\": \"" + scannerInfo.getUsername() + "\", \"passWord\":\"" + scannerInfo.getPassword() + "\"}", "UTF-8"));

        if ("https".equalsIgnoreCase(scannerInfo.getMode())) {
            try (CloseableHttpClient httpClient = HttpFileUtils.getHttpClient();
                 CloseableHttpResponse response = httpClient.execute(httpRequest)) {
                int code = response.getStatusLine().getStatusCode();
                String ret = DataUtils.toBodyString(response.getEntity());
                if (code == 200) {
                    JSONObject result = JsonUtils.parse(ret);
                    if (result.containsKey("token")) {
                        //重新登录获取session
                        scannerInfo.setToken(result.getString("token"));
                    } else {
                        log.error("SDN登录错误2！" + ret);
                    }
                }else {
                    log.error("SDN登录错误1！" + ret);
                }
            } catch (Exception e) {
                log.error(e.getMessage(), e);
            }
            return;
        }
        try (CloseableHttpClient httpClient = HttpClients.createDefault();
             CloseableHttpResponse response = httpClient.execute(httpRequest)) {
            int code = response.getStatusLine().getStatusCode();
            String ret = DataUtils.toBodyString(response.getEntity());
            if (code == 200) {
                JSONObject result = JsonUtils.parse(ret);
                if (result.containsKey("token")) {
                    //重新登录获取session
                    scannerInfo.setToken(result.getString("token"));
                } else {
                    log.error("SDN登录错误2！" + ret);
                }
            }else {
                log.error("SDN登录错误1！" + ret);
            }
        } catch (Exception e) {
            log.error(e.getMessage(), e);
        }
    }
}
