package com.crc.sync.alarm;

import cn.hutool.core.convert.Convert;
import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;
import com.crc.common.code.CreateInsert;
import com.crc.common.enums.DatabaseEnums;
import com.crc.common.utils.*;
import com.crc.secface.config.GetSpringBean;
import com.crc.secface.domain.SysDictData;
import com.crc.secface.domain.vo.AlarmNoIp;
import com.crc.secface.domain.vo.AlarmVo;
import com.crc.secface.mapper.AssetAlarmMapper;
import com.crc.secface.mapper.CommonMapper;
import com.crc.sync.config.SyncSecConfigLoad;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.function.Function;
import java.util.stream.Collectors;

/**
 * @author hejingsheng1
 * @title IpAlarmSync
 * @date 2023/7/31 11:05
 * @description 告警关联资产, IP_ALARM 关系
 */
@Slf4j
public class IpAlarmSync extends Thread {
    @Override
    public void run() {
        if (VersionUtils.getDatabase() != DatabaseEnums.MYSQL.getCode()) {
            log.info("只支持MYSQL");
            return;
        }
        while (true) {
            MyTheadUtils.sleepBySec(1);

            if (SyncSecConfigLoad.isEnable("ip_alarm_sync")) {
                sync();
            }
            MyTheadUtils.sleepBySec(60 * 2);
        }
    }

    private void sync() {
        try {
            CommonMapper commonMapper = GetSpringBean.getBean(CommonMapper.class);
            SysDictData dict = SyncSecConfigLoad.getConfig("alarm_limit_day");
            int offset = 100;
            if (!StringUtils.isBlank(dict.getRemark())) {
                int data = Convert.toInt(dict.getRemark());
                if (data > 100) {
                    offset = data;
                }
            }
            int tatal = 0;
            int alarmHvvCount = 0;
            while (true) {
                String sql = "SELECT id,attack_ip,victimized_ip,alarm_id FROM tb_alarm_combat_report r WHERE  r.del_flag = '0' and  r.create_time >  DATE_SUB(NOW(), INTERVAL " + offset + " DAY) and  not exists (select 1 from tb_ip_alarm a where a.alarm_type = '2' and a.alarm_code = r.alarm_id) and  not exists (select 1 from tb_no_ip_alarm a where  a.alarm_id = r.alarm_id)    limit  1000";
                if (VersionUtils.getDatabase() == DatabaseEnums.DaMeng.getCode()) {
                    sql = "SELECT id,attack_ip,victimized_ip,alarm_id FROM tb_alarm_combat_report r WHERE  r.del_flag = '0' and  r.create_time >=  sysdate - " + offset + " and  not exists (select 1 from tb_ip_alarm a where a.alarm_type = '2' and a.alarm_code = r.alarm_id) and  not exists (select 1 from tb_no_ip_alarm a where  a.alarm_id = r.alarm_id)   limit  1000";
                }
                List<JSONObject> mapList = commonMapper.query(sql);
                if (mapList.size() < 1) {
                    break;
                }
                log.info("同步实战化告警IP_ALARM天数：" + offset + String.format(",size=%d", mapList.size()));
                try {
                    int size = procData(mapList, "2");
                    if (size == 0) {
                        tatal++;
                    }
                    if (tatal > 3) {
                        break;
                    }
                    alarmHvvCount += size;
                } catch (Exception e) {
                    log.error(e.getMessage(), e);
                }
                MyTheadUtils.sleepBySec(1);
            }
            log.info("同步实战化告警IP_ALARM总数：{}", alarmHvvCount);
            tatal = 0;
            int alarmCount = 0;
            while (true) {
                String sql = "SELECT id,attack_ip,victimized_ip,alarm_id FROM tb_alarm_report r WHERE r.del_flag = '0' and  r.create_time >  DATE_SUB(NOW(), INTERVAL " + offset + " DAY) and  not exists (select 1 from tb_ip_alarm a where a.alarm_type = '1' and a.alarm_code = r.alarm_id) and  not exists (select 1 from tb_no_ip_alarm a where  a.alarm_id = r.alarm_id)  order by create_time desc  limit 1000";
                if (VersionUtils.getDatabase() == DatabaseEnums.DaMeng.getCode()) {
                    sql = "SELECT id,attack_ip,victimized_ip,alarm_id FROM tb_alarm_report r WHERE r.del_flag = '0' and  r.create_time >= sysdate - " + offset + "  and  not exists (select 1 from tb_ip_alarm a where a.alarm_type = '1' and a.alarm_code = r.alarm_id) and  not exists (select 1 from tb_no_ip_alarm a where  a.alarm_id = r.alarm_id)  order by create_time desc  limit 1000";
                }
                List<JSONObject> mapList = commonMapper.query(sql);
                if (mapList.size() < 1) {
                    break;
                }
                log.info("同步安全告警IP_ALARM天数：" + offset + String.format(",size=%d", mapList.size()));
                try {
                    int size = procData(mapList, "1");
                    if (size == 0) {
                        tatal++;
                    }
                    if (tatal > 3) {
                        break;
                    }
                    alarmCount += size;

                } catch (Exception e) {
                    log.error(e.getMessage(), e);
                }
                MyTheadUtils.sleepBySec(1);
            }
            log.info("同步安全告警IP_ALARM总数：{}", alarmCount);
            MyTheadUtils.sleepBySec(1);
            log.info("同步安全告警IP_ALARM完成==");

            //更新删除的实战的状态
            commonMapper.exeSQL("UPDATE tb_ip_alarm a  INNER JOIN tb_alarm_combat_report c ON c.del_flag = '1' and a.alarm_type = '2' and a.alarm_code = c.alarm_id SET a.del_flag = '1'");
            //更新删除的告警闭环的状态
            commonMapper.exeSQL("UPDATE tb_ip_alarm a  INNER JOIN tb_alarm_report c ON c.del_flag = '1' and a.alarm_type = '1' and a.alarm_code = c.alarm_id  SET a.del_flag = '1'");

            if (SyncSecConfigLoad.isEnable("asset_alarm_sync")) {
                AssetAlarmSync sync = new AssetAlarmSync();
                sync.sync();
            }

            if (SyncSecConfigLoad.isEnable("ip_segment_alarm_sync")) {
                IpSegmentAlarmSync sync = new IpSegmentAlarmSync();
                sync.sync();
            }

        } catch (Exception e) {
            log.error(e.getMessage(), e);
        }
    }

    public int procData(List<JSONObject> dataList, String alarmType) {
        if (dataList.size() < 1) {
            return 0;
        }
        List<AlarmVo> alarmList = new ArrayList<>();
        String alarmId = null;
        for (JSONObject alarm : dataList) {
            String attackIp = JsonUtils.getStr(alarm, "attack_ip");
            alarmId = JsonUtils.getStr(alarm, "alarm_id");
            String victimizedIp = JsonUtils.getStr(alarm, "victimized_ip");
            List<String> srcIpList = IpUtils.getIps(attackIp);
            Map<String, String> srcMap = srcIpList.stream().collect(Collectors.toMap(Function.identity(), Function.identity(), (k1, k2) -> k2));
            List<String> victimizedIpList = IpUtils.getIps(victimizedIp);
            Map<String, String> destMap = victimizedIpList.stream().collect(Collectors.toMap(Function.identity(), Function.identity(), (k1, k2) -> k2));
            for (String ip : srcMap.keySet()) {
                String type = "1";
                if (destMap.containsKey(ip)) {
                    type = "3";
                }
                AlarmVo v = new AlarmVo();
                v.setAlarmCode(alarmId);
                v.setAlarmId(JsonUtils.getStr(alarm, "id"));
                v.setIp(ip);
                v.setType(type);
                v.setDelFlag("0");
                v.setLongIp(IpUtils.getIp2long(ip));
                v.setAlarmType(alarmType);
                if (!DataUtils.bigTo0(v.getLongIp()) || StringUtils.isBlank(v.getAlarmCode())) {
                    continue;
                }
                alarmList.add(v);
            }
            for (String ip : destMap.keySet()) {
                if (srcMap.containsKey(ip)) {
                    continue;
                }
                AlarmVo v = new AlarmVo();
                v.setAlarmId(JsonUtils.getStr(alarm, "id"));
                v.setAlarmCode(alarmId);
                v.setIp(ip);
                v.setType("2");
                v.setDelFlag("0");
                v.setLongIp(IpUtils.getIp2long(ip));
                v.setAlarmType(alarmType);
                if (!DataUtils.bigTo0(v.getLongIp()) || StringUtils.isBlank(v.getAlarmCode())) {
                    continue;
                }
                alarmList.add(v);
            }
        }

        if (alarmList.size() < 1) {
            log.info("没有发现有有效 IP 或告警 Id：{}", alarmId);
            AlarmNoIp alarmNoIp = new AlarmNoIp();
            alarmNoIp.setAlarmId(alarmId);
            alarmNoIp.setCreateTime(DateUtils.getTime(DateUtils.DATE_FORMAT_STRING1));
            try {
                CommonMapper commonMapper = GetSpringBean.getBean(CommonMapper.class);
                if (commonMapper.getCount("select count(1) from tb_no_ip_alarm where alarm_id = '" + alarmId + "'") < 1) {
                    CreateInsert<AlarmNoIp> createInsert = new CreateInsert<>();
                    String sql = createInsert.createinsert(alarmNoIp, "tb_no_ip_alarm");
                    commonMapper.exeSQL(sql);
                }
            } catch (Exception e) {
                log.error(e.getMessage(),e);
            }
            return 0;
        }
        AssetAlarmMapper assetAlarmMapper = GetSpringBean.getBean(AssetAlarmMapper.class);
        log.info("batchInsertIpAlarm:{}", alarmList.size());
        try {
            assetAlarmMapper.batchInsertIpAlarm(alarmList);
        } catch (Exception e) {
            log.error("批量插入失败：" + JSON.toJSONString(alarmList), e);
        }
        MyTheadUtils.sleep(100);
        return alarmList.size();
    }
}
