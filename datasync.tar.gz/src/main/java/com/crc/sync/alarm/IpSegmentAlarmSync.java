package com.crc.sync.alarm;

import cn.hutool.core.collection.CollUtil;
import cn.hutool.core.date.DateUtil;
import com.alibaba.fastjson.JSONObject;
import com.crc.common.enums.AlarmCombatNodeEnum;
import com.crc.common.enums.DatabaseEnums;
import com.crc.common.utils.IpUtils;
import com.crc.common.utils.JsonUtils;
import com.crc.common.utils.Md5Utils;
import com.crc.common.utils.VersionUtils;
import com.crc.secface.domain.AssetSegementIp;
import com.crc.secface.config.GetSpringBean;
import com.crc.secface.domain.CommonIpSegmentCalAlarm;
import com.crc.secface.domain.vo.CommonIpSegmentVo;
import com.crc.secface.mapper.CommonIpSegmentCalAlarmMapper;
import com.crc.secface.mapper.CommonIpSegmentMapper;
import com.crc.secface.mapper.CommonMapper;
import lombok.extern.slf4j.Slf4j;

import java.util.List;

/**
 * @author fuzhuangzhi
 * @title IpSegmentAlarmSync
 * @date 2023/8/2 18:59
 * @description IP/网段关联告警同步
 */
@Slf4j
public class IpSegmentAlarmSync {

    /**
     * 计算资产关联告警
     */
    public void sync() {
        if (VersionUtils.getDatabase() != DatabaseEnums.MYSQL.getCode()) {
            log.info("只支持MYSQL");
            return;
        }
        log.info("自定义IP或网段数据,告警关联开始");
        CommonIpSegmentMapper commonIpSegmentMapper = GetSpringBean.getBean(CommonIpSegmentMapper.class);
        // 查询已经入库的业务ip或端口
        List<CommonIpSegmentVo> list = commonIpSegmentMapper.getSegment();
        if (!CollUtil.isEmpty(list)) {
            CommonIpSegmentCalAlarmMapper commonIpSegmentCalAlarmMapper = GetSpringBean.getBean(CommonIpSegmentCalAlarmMapper.class);
            CommonMapper commonMapper = GetSpringBean.getBean(CommonMapper.class);
            for (CommonIpSegmentVo vo : list) {
                Long commentId = vo.getId();
                List<AssetSegementIp> segList = IpUtils.getSegementIpList(vo.getSegment());
                if (segList.size() < 1) {
                    log.error("没有识别到网段{}", vo.getSegment());
                    continue;
                }

                // 先删除之前的告警
                commonIpSegmentCalAlarmMapper.deleteByCommonId(commentId);
                for (AssetSegementIp assetSegementIp : segList) {
                    String sql = "select * from tb_ip_alarm where del_flag = '0' and long_ip >= " + assetSegementIp.getSlip() + " and long_ip <= " + assetSegementIp.getElip() + " order by alarm_code desc limit 1000";
                    List<JSONObject> dataList = commonMapper.query(sql);
                    //log.info("{} => {}", vo.getSegment(), dataList.size());
                    for (JSONObject data : dataList) {
                        try {
                            CommonIpSegmentCalAlarm alarmVo = new CommonIpSegmentCalAlarm();
                            // 如果是实战告警，转换工单状态
                            String alarmType = JsonUtils.getStr(data, "alarm_type");
                            alarmVo.setOrderStatus(JsonUtils.getStr(data, "order_status"));
                            alarmVo.setCommonIpSegmentId(commentId);
                            alarmVo.setAlarmType(alarmType);
                            alarmVo.setIp(JsonUtils.getStr(data, "ip"));
                            alarmVo.setAlarmId(JsonUtils.getStr(data, "alarm_code"));
                            alarmVo.setType(JsonUtils.getStr(data, "type"));
                            String uuid = alarmVo.getCommonIpSegmentId() + "#" + alarmVo.getIp() + "#" + alarmVo.getAlarmId() + "#" + alarmVo.getType() + "#" +
                                    alarmVo.getAlarmType();
                            alarmVo.setUuid(Md5Utils.hash(uuid));
                            alarmVo.setCreateTime(DateUtil.date());
                            alarmVo.setUpdateTime(DateUtil.date());
                            commonIpSegmentCalAlarmMapper.insertOrUpdate(alarmVo);
                        } catch (Exception e) {
                            log.error(e.getMessage(), e);
                        }
                    }
                }
            }

            //更新实战 order_status
            commonMapper.exeSQL("UPDATE tb_common_ip_segment_cal_alarm a  INNER JOIN tb_alarm_combat_report c ON c.del_flag = '0' and a.alarm_type = '2' and a.alarm_id = c.alarm_id SET a.order_status = (case when c.order_status = 'noDeal' then '无需处置' when c.order_status = 'deal' then '处置' when c.order_status = 'follow' then '后续跟进' when c.order_status = 'audit' then '审核' when c.order_status = 'complete' then '归档' else '研判' end )");
            //更新告警闭环 order_status
            commonMapper.exeSQL("UPDATE tb_common_ip_segment_cal_alarm a  INNER JOIN tb_alarm_report c ON c.del_flag = '0' and a.alarm_type = '1' and a.alarm_id = c.alarm_id  SET a.order_status = c.order_status");

        }
        log.info("自定义IP或网段数据,告警关联结束");
    }
}
