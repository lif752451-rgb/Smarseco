package com.crc.sync.alarm;

import cn.hutool.core.util.StrUtil;
import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;
import com.crc.common.enums.DatabaseEnums;
import com.crc.common.utils.JsonUtils;
import com.crc.common.utils.Md5Utils;
import com.crc.common.utils.MyTheadUtils;
import com.crc.common.utils.VersionUtils;
import com.crc.secface.config.GetSpringBean;
import com.crc.secface.domain.Asset;
import com.crc.secface.domain.AssetAlarm;
import com.crc.secface.domain.AssetSegement;
import com.crc.secface.mapper.AssetAlarmMapper;
import com.crc.secface.mapper.CommonMapper;
import com.crc.sync.net.NewSegmentLoad;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

/**
 * @author fuzhuangzhi
 * @title AssetAlarmSync
 * @date 2023/7/31 11:05
 * @description 告警关联资产数据同步
 */
@Slf4j
public class AssetAlarmSync {

    public void sync() {
        if (VersionUtils.getDatabase() != DatabaseEnums.MYSQL.getCode()) {
            log.info("只支持MYSQL");
            return;
        }
        try {
            CommonMapper commonMapper = GetSpringBean.getBean(CommonMapper.class);
            int tatal = 0;
            int sum = 0;
            while (true) {//add
                String sql = "select a.id,a.affiliation_dept_name,a.area_name,i.alarm_type,i.type,i.ip,i.alarm_code,i.alarm_id from tb_asset a inner join tb_ip_alarm i on a.del_flag = '0' and a.internal_ip = i.ip where not exists (select 1 from tb_asset_alarm x where i.alarm_id  = x.alarm_id) limit 1000";
                List<JSONObject> mapList = commonMapper.query(sql);
                if (mapList.size() < 1) {
                    break;
                }
                log.info("同步告警ASSET_ALARM天数：" + 100 + String.format(",size=%d", mapList.size()));
                try {
                    int size = procData(mapList);
                    if (size == 0) {
                        tatal++;
                    }
                    if (tatal > 3) {
                        break;
                    }
                    sum += size;
                } catch (Exception e) {
                    log.error(e.getMessage(), e);
                }
                MyTheadUtils.sleepBySec(1);
            }
            log.info("同步告警ASSET_ALARM总数：{}", sum);

            //更新实战 order_status
            commonMapper.exeSQL("UPDATE tb_asset_alarm a  INNER JOIN tb_alarm_combat_report c ON c.del_flag = '0' and a.alarm_type = '2' and a.alarm_code = c.alarm_id SET a.order_status = (case when c.order_status = 'noDeal' then '无需处置' when c.order_status = 'deal' then '处置' when c.order_status = 'follow' then '后续跟进' when c.order_status = 'audit' then '审核' when c.order_status = 'complete' then '归档' else '研判' end )");
            //更新告警闭环 order_status
            commonMapper.exeSQL("UPDATE tb_asset_alarm a  INNER JOIN tb_alarm_report c ON c.del_flag = '0' and a.alarm_type = '1' and a.alarm_code = c.alarm_id  SET a.order_status = c.order_status");
            //更新资产
            log.info("tb_asset_alarm更新资产 开始");
            commonMapper.exeSQL("UPDATE tb_asset_alarm a  INNER JOIN tb_asset c ON c.del_flag = '0' and a.ip  = c.internal_ip  SET a.affiliation_dept_name = c.affiliation_dept_name,a.area_name = c.area_name");
            log.info("tb_asset_alarm更新资产 结束");
            MyTheadUtils.sleepBySec(1);
            log.info("同步安全告警ASSET_ALARM完成==");
        } catch (Exception e) {
            log.error(e.getMessage(), e);
        }
    }

    public int procData(List<JSONObject> dataList) {
        if (dataList.size() < 1) {
            return 0;
        }
        List<AssetAlarm> alarmList = new ArrayList<>();
        for (JSONObject alarm : dataList) {
            try {
                AssetAlarm assetAlarm = new AssetAlarm();
                String ip4Bu = getIp4Bu(JsonUtils.getStr(alarm, "ip"), JsonUtils.getStr(alarm, "affiliation_dept_name"));
                assetAlarm.setAffiliationDeptDame(ip4Bu);
                assetAlarm.setAreaName(JsonUtils.getStr(alarm, "area_name"));
                assetAlarm.setAssetId(JsonUtils.getLong(alarm, "id"));
                assetAlarm.setOrderStatus(JsonUtils.getStr(alarm, "order_status"));
                assetAlarm.setAlarmType(JsonUtils.getStr(alarm, "alarm_type"));
                assetAlarm.setIp(JsonUtils.getStr(alarm, "ip"));
                assetAlarm.setAlarmId(JsonUtils.getStr(alarm, "alarm_id"));
                assetAlarm.setAlarmCode(JsonUtils.getStr(alarm, "alarm_code"));
                assetAlarm.setType(JsonUtils.getStr(alarm, "type"));
                String uuid = assetAlarm.getAssetId() + "#" + assetAlarm.getAlarmId() + "#" + assetAlarm.getType() + "#" +
                        assetAlarm.getAlarmType();
                assetAlarm.setUuid(Md5Utils.hash(uuid));
                assetAlarm.setCreateTime(new Date());
                assetAlarm.setUpdateTime(new Date());
                alarmList.add(assetAlarm);
            } catch (Exception e) {
                log.error(e.getMessage(), e);
            }
        }
        AssetAlarmMapper assetAlarmMapper = GetSpringBean.getBean(AssetAlarmMapper.class);
        log.info("batchInsertAssetAlarm:{}", alarmList.size());
        try {
            assetAlarmMapper.batchInsertAssetAlarm(alarmList);
        } catch (Exception e) {
            log.error("批量插入失败：" + JSON.toJSONString(alarmList),e);
        }
        MyTheadUtils.sleep(100);
        return alarmList.size();
    }

    /**
     * 查询IP BU归属
     *
     * @param ip
     * @return
     */
    private String getIp4Bu(String ip,String affiliationDeptName) {
        if (StrUtil.isNotEmpty(affiliationDeptName)) {
            return affiliationDeptName;
        } else {
            AssetSegement rdata = NewSegmentLoad.getIPSegmentByHalf(ip);
            if (rdata != null) {
                return rdata.getAffiliationDeptName();
            }
        }
        return "";
    }
}
