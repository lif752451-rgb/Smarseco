package com.crc.sync.mail;

import com.alibaba.fastjson.JSONObject;
import com.crc.common.code.CodeTool;
import com.crc.common.utils.DataUtils;
import com.crc.common.utils.DateUtils;
import com.crc.common.utils.JsonUtils;
import com.crc.common.utils.Md5Utils;
import com.crc.common.utils.MyTheadUtils;
import com.crc.common.utils.SqlUtils;
import com.crc.secface.config.GetSpringBean;
import com.crc.secface.db.ConfBuzziMySql;
import com.crc.secface.domain.vo.DbConfig;
import com.crc.secface.mapper.CommonMapper;
import com.crc.sync.config.SyncSecConfigLoad;
import com.crc.sync.config.SyncSecConstants;
import com.google.common.collect.Lists;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringEscapeUtils;
import org.apache.commons.lang3.StringUtils;

import java.util.Date;
import java.util.HashMap;
import java.util.List;

/**
 * @author YUYUHANG5
 */
@Slf4j
public class FishMailSync extends Thread {

    @Override
    public void run() {
        while (true) {
            if (SyncSecConfigLoad.isEnable(SyncSecConstants.FISH_DB_CONFIG)) {
                MyTheadUtils.sleepBySec(5);
                try {
                    FishNewDataSync fishDataSync = new FishNewDataSync();
                    fishDataSync.sync();
                } catch (Exception e) {
                    log.error(e.getMessage(), e);
                }
            }
            if (SyncSecConfigLoad.isEnable(SyncSecConstants.FISH_SYNC_ENABLE)) {
                MyTheadUtils.sleepBySec(5);
                try {
                    sync();
                } catch (Exception e) {
                    log.error(e.getMessage(), e);
                }
            }
        }
    }


    public void sync() {

        if (!SyncSecConfigLoad.isEnable(SyncSecConstants.FISH_SYNC_ENABLE)) {
            return;
        }
        log.info("钓鱼邮件计算开始");


        String dbStr = SyncSecConfigLoad.getRemarkValue(SyncSecConstants.FISH_DB_CONFIG);

        if (dbStr == null || StringUtils.isBlank(dbStr)) {
            log.error("钓鱼邮件数据库配置错误SYNC_SEC_CONFIG【fish_db_config】");
            return;
        }
        if (!SyncSecConfigLoad.isEnable(SyncSecConstants.FISH_SYNC_ENABLE)) {
            return;
        }
        log.info("钓鱼数据同步开始");
        JSONObject json = JsonUtils.parse(dbStr);
        DbConfig dbConfig = new DbConfig();
        dbConfig.setUrl(StringEscapeUtils.unescapeHtml4(JsonUtils.getStr(json, "url")));
        dbConfig.setUsername(JsonUtils.getStr(json, "username"));
        dbConfig.setPassword(JsonUtils.getStr(json, "password"));
        dbConfig.setDriverClassName("com.mysql.cj.jdbc.Driver");
        if (StringUtils.isBlank(dbConfig.getUrl())) {
            log.error("钓鱼邮件数据库配置错误SYNC_SEC_CONFIG【fish_db_config】");
            return;
        }

        /*
        钓鱼项目清单
         */
        String taskListSQL = "select t.*,d.dict_label as project_name from tb_fish_task t inner join (select * from sys_dict_data where dict_type = 'fish_project' and remark = '1') d on t.project_ids = d.dict_value  where del_flag = '0' and task_type = '0'";

        List<JSONObject> taskList = ConfBuzziMySql.query(dbConfig, taskListSQL);
        List<String> taskIdList = Lists.newArrayList();
        for (JSONObject task : taskList) {
            String taskName = DataUtils.getString(task, "project_name");
            taskIdList.add("NEW#" + Md5Utils.hash(taskName));
        }
        if (taskIdList.size() < 1) {
            log.info("没有检测到要计算到钓鱼项目fish_project/remark=1");
            return;
        }

        String sqlInTask = SqlUtils.getInSql(taskIdList);

        CommonMapper commonMapper = GetSpringBean.getBean(CommonMapper.class);
        assert commonMapper != null;
        commonMapper.deleteOldTaskInfo();
        commonMapper.deleteOldTaskCap();
        String taskInfosSql = "SELECT * FROM task_infos where task_id in " + sqlInTask;
        String targetTotalSql1 = "SELECT COUNT(1) FROM (SELECT email FROM target_emplorees WHERE task_id = '%s'  GROUP BY email) s";
        List<HashMap<String, Object>> list = commonMapper.queryX(taskInfosSql);
        String queryCapSql1 = "select count(1) from task_cap where task_id = '%s' and bu_name = '%s' ";
        String updateCapSql1 = "update task_cap set flag='1',cap_rate = '%s' where task_id = '%s' and bu_name = '%s' ";
        String insertCapSql1 = "insert into task_cap(task_id,bu_name,cap_name,cap_start,cap_rate,task_type,flag)values('%s','%s','%s','%s','%s','%s','1')";
        String insertTaskInfoSql1 = "insert into task_info(task_id,bu_name,total,num_of_send,bu_parent,flag)values('%s','%s',%d,%d,'%s','1')";
        String queryTaskInfoSql1 = "select count(1) from task_info where task_id = '%s' and bu_name = '%s'";
        String updateTaskInfoSql1 = "update task_info set flag='1',total = %d,num_of_send=%d where task_id = '%s' and bu_name = '%s'";
        String sqlGroup1 = "SELECT depend1, total  FROM send_statistics WHERE task_id = '%s'";
        String sqlTargetGroup1 = "SELECT depend1,COUNT(DISTINCT (email)) total FROM target_emplorees WHERE task_id = '%s' GROUP BY depend1";
        commonMapper.exeSQL("update task_cap set flag = '0' where task_id in " + sqlInTask);
        commonMapper.exeSQL("update task_info set flag = '0' where task_id in " + sqlInTask);
        if (list != null && list.size() > 0) {
            for (HashMap<String, Object> map : list) {
                String taskType = DataUtils.getStr(map, "task_type");
                String taskId = DataUtils.getStr(map, "task_id");
                int sendNum = DataUtils.getInt(map, "num_of_send");
                String capStart = DataUtils.getStr(map, "cap_start");
                String capEnd = DataUtils.getStr(map, "cap_end");
                String buName = DataUtils.getStr(map, "bu_name");
                if ("0".equalsIgnoreCase(taskType)) {
                    buName = "华润集团（全集团）";
                }
                int target1 = commonMapper.getCount(String.format(targetTotalSql1, taskId));
                String perTarget1 = DataUtils.getPercent00(target1, sendNum);
                Date startDate = DateUtils.parseDate(capStart, DateUtils.DATE_FORMAT_STRING1);
                Date endDate = DateUtils.parseDate(capEnd, DateUtils.DATE_FORMAT_STRING1);
                String pre = DateUtils.parseDateToStr(DateUtils.DATE_FORMAT_X, startDate);
                String str = String.format("%s（%s-%s）", pre, DateUtils.parseDateToStr(DateUtils.DATE_FORMAT_STRING6, startDate), DateUtils.parseDateToStr(DateUtils.DATE_FORMAT_STRING6, endDate));
                if (commonMapper.getCount(String.format(queryCapSql1, taskId, buName)) > 0) {
                    commonMapper.exeSQL(String.format(updateCapSql1, perTarget1, taskId, buName));
                } else {
                    String insertSQL = String.format(insertCapSql1, taskId, buName, str, capStart, perTarget1, taskType);
                    commonMapper.exeSQL(insertSQL);
                }
                if ("0".equalsIgnoreCase(taskType)) {
                    List<HashMap<String, Object>> buList1 = commonMapper.queryX(String.format(sqlGroup1, taskId));
                    List<HashMap<String, Object>> targBuList1 = commonMapper.queryX(String.format(sqlTargetGroup1, taskId));
                    for (HashMap<String, Object> jsonObject : buList1) {
                        String depend = DataUtils.getStr(jsonObject, "depend1");
                        int buCount = 0;
                        int buSend = 0;
                        String querySendStatSQL = "SELECT * FROM send_statistics WHERE task_id = '%s' AND depend1 = '%s'";
                        List<HashMap<String, Object>> qlist1 = commonMapper.queryX(String.format(querySendStatSQL, taskId, depend));
                        if (qlist1.size() > 0) {
                            buCount = DataUtils.getInt(qlist1.get(0), "total");
                            buSend = DataUtils.getInt(qlist1.get(0), "num_of_send");
                        }
                        if (commonMapper.getCount(String.format(queryTaskInfoSql1, taskId, depend)) > 0) {
                            String updateTaskSQL = String.format(updateTaskInfoSql1, buCount, buSend, taskId, depend);
                            commonMapper.exeSQL(updateTaskSQL);
                        } else {
                            String insertTaskSQL = String.format(insertTaskInfoSql1, taskId, depend, buCount, buSend, "");
                            commonMapper.exeSQL(insertTaskSQL);
                        }
                        int targetBuCount = 0;
                        for (HashMap<String, Object> stringObjectHashMap : targBuList1) {
                            String dependx = DataUtils.getStr(stringObjectHashMap, "depend1");
                            if (depend.equalsIgnoreCase(dependx)) {
                                targetBuCount = DataUtils.getInt(stringObjectHashMap, "total");
                                break;
                            }
                        }
                        String insertSQL;
                        querySendStatSQL = "SELECT * FROM send_statistics WHERE task_id = '%s' AND depend1 = '%s' and depend2 = '%s'";
                        if ("华润数科".equalsIgnoreCase(depend) || "润联科技".equalsIgnoreCase(depend) || "集团总部".equalsIgnoreCase(depend)) {
                            if ("润联科技".equalsIgnoreCase(depend)) {
                                depend = "华润数科";
                            }
                            String rlSQl = "SELECT depend2  FROM send_statistics WHERE task_id = '%s' AND depend1 = '%s' GROUP BY depend2";
                            List<HashMap<String, Object>> buListx = commonMapper.queryX(String.format(rlSQl, taskId, depend));
                            int totalBuCount = 0, totalBuSend = 0;
                            for (HashMap<String, Object> jsonx : buListx) {
                                String depend2 = DataUtils.getStr(jsonx, "depend2");
                                int buCount2 = 0;
                                int buSend2 = 0;
                                List<HashMap<String, Object>> qlist2 = commonMapper.queryX(String.format(querySendStatSQL, taskId, depend, depend2));
                                if (qlist2.size() > 0) {
                                    buCount2 = DataUtils.getInt(qlist2.get(0), "total");
                                    buSend2 = DataUtils.getInt(qlist2.get(0), "num_of_send");
                                }
                                if (commonMapper.getCount(String.format(queryTaskInfoSql1, taskId, depend2)) > 0) {
                                    String updateTaskSQL = String.format(updateTaskInfoSql1, buCount2, buSend2, taskId, depend2);
                                    commonMapper.exeSQL(updateTaskSQL);
                                } else {
                                    String insertTaskSQL = String.format(insertTaskInfoSql1, taskId, depend2, buCount2, buSend2, depend);
                                    commonMapper.exeSQL(insertTaskSQL);
                                }
                                totalBuCount += buCount2;
                                totalBuSend += buSend2;
                            }
                            String updateTaskSQL = String.format(updateTaskInfoSql1, totalBuCount, totalBuSend, taskId, depend);
                            commonMapper.exeSQL(updateTaskSQL);

                            String perTarget = DataUtils.getPercent00(targetBuCount, totalBuCount);
                            insertSQL = String.format(insertCapSql1, taskId, depend, str, capStart, perTarget, taskType);
                            if (commonMapper.getCount(String.format(queryCapSql1, taskId, depend)) > 0) {
                                commonMapper.exeSQL(String.format(updateCapSql1, perTarget, taskId, depend));
                            } else {
                                commonMapper.exeSQL(insertSQL);
                            }
                        } else {
                            String perTarget = DataUtils.getPercent00(targetBuCount, buSend);
                            insertSQL = String.format(insertCapSql1, taskId, depend, str, capStart, perTarget, taskType);
                            if (commonMapper.getCount(String.format(queryCapSql1, taskId, depend)) > 0) {
                                commonMapper.exeSQL(String.format(updateCapSql1, perTarget, taskId, depend));
                            } else {
                                commonMapper.exeSQL(insertSQL);
                            }
                        }
                    }

                }
            }
        }
        commonMapper.exeSQL("delete from task_cap where flag = '0' and task_id in " + sqlInTask);
        commonMapper.exeSQL("delete from task_info where flag = '0' and task_id in " + sqlInTask);
        log.info("钓鱼邮件计算结束");
    }
}
