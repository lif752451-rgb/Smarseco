package com.crc.sync.mail;

import com.alibaba.fastjson.JSONObject;
import com.crc.common.code.CodeTool;
import com.crc.common.utils.DataUtils;
import com.crc.common.utils.JsonUtils;
import com.crc.common.utils.Md5Utils;
import com.crc.secface.config.GetSpringBean;
import com.crc.secface.db.ConfBuzziMySql;
import com.crc.secface.domain.FishTask;
import com.crc.secface.domain.SysDept;
import com.crc.secface.domain.vo.DbConfig;
import com.crc.secface.mapper.CommonMapper;
import com.crc.secface.mapper.SysDeptMapper;
import com.crc.secface.mapper.SysUserMapper;
import com.crc.sync.config.SyncSecConfigLoad;
import com.crc.sync.config.SyncSecConstants;
import com.google.common.collect.Maps;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringEscapeUtils;
import org.apache.commons.lang3.StringUtils;

import java.math.BigDecimal;
import java.util.HashMap;
import java.util.List;


/**
 * 同步钓鱼邮件数据
 */
@Slf4j
public class FishDataSync {
    public void sync() {
        try {
            String dbStr = SyncSecConfigLoad.getRemarkValue(SyncSecConstants.FISH_DB_CONFIG);
            if (dbStr == null || StringUtils.isBlank(dbStr)) {
                log.error("钓鱼邮件数据库配置错误SYNC_SEC_CONFIG【fish_db_config】");
                return;
            }
            if (!SyncSecConfigLoad.isEnable(SyncSecConstants.FISH_SYNC_ENABLE)) {
                return;
            }
            log.info("钓鱼数据同步开始");
            JSONObject json = JsonUtils.parse(dbStr);
            DbConfig dbConfig = new DbConfig();
            dbConfig.setUrl(StringEscapeUtils.unescapeHtml4(JsonUtils.getStr(json, "url")));
            dbConfig.setUsername(JsonUtils.getStr(json, "username"));
            dbConfig.setPassword(CodeTool.decrypt(JsonUtils.getStr(json, "password")));
            dbConfig.setDriverClassName("com.mysql.cj.jdbc.Driver");
            if (StringUtils.isBlank(dbConfig.getUrl())) {
                log.error("钓鱼邮件数据库配置错误SYNC_SEC_CONFIG【fish_db_config】");
                return;
            }

            //dict_type = fish_project
        /*
        钓鱼项目清单
         */
            String taskListSQL = "select t.*,d.dict_label as project_name from tb_fish_task t inner join (select * from sys_dict_data where dict_type = 'fish_project') d on t.project_ids = d.dict_value  where del_flag = '0' and task_type = '0'";
            CommonMapper commonMapper = GetSpringBean.getBean(CommonMapper.class);
            boolean testMode = false;//测试开关
            if (!testMode) {
                commonMapper.exeSQL("update tb_fish_task_group_info set flag = '1'");
                commonMapper.exeSQL("update tb_fish_target_emploree set flag = '1'");
                commonMapper.exeSQL("update tb_fish_send_emploree set flag = '1'");
            }
            List<JSONObject> taskList = ConfBuzziMySql.query(dbConfig, taskListSQL);
            String sendCountListSQL = "select * from tb_fish_task_record where task_id =  %s";
            SysUserMapper sysUserMapper = GetSpringBean.getBean(SysUserMapper.class);
            SysDeptMapper sysDeptMapper = GetSpringBean.getBean(SysDeptMapper.class);

            HashMap<String, FishTask> taskMap = Maps.newHashMap();
            for (JSONObject task : taskList) {
                String taskName = DataUtils.getString(task, "project_name");
                String id = DataUtils.getString(task, "id");
                String startTime = JsonUtils.getDateStr(task, "start_time");
                String endTime = JsonUtils.getDateStr(task, "end_time");
                List<JSONObject> recordList = ConfBuzziMySql.query(dbConfig, String.format(sendCountListSQL, id));
                if (!testMode) {
                    for (JSONObject record : recordList) {
                        HashMap<String, String> userMap = Maps.newHashMap();
                        try {
                            userMap = sysUserMapper.selectUserByEmail(JsonUtils.getStr(record, "employee_email"));
                        } catch (Exception ignored) {

                        }
                        try {
                            if (JsonUtils.equalVal(record, "cheated", "1")) {
                                String taskId = Md5Utils.hash(taskName);
                                String email = JsonUtils.getStr(record, "employee_email");
                                if (StringUtils.isBlank(email)) {
                                    return;
                                }
                                String selSql = "select count(1) from tb_fish_target_emploree where task_id = '%s' and email = '%s'";
                                String upSql = "update tb_fish_target_emploree set flag = '0' where task_id = '%s' and email = '%s'";
                                String inSql = "insert into tb_fish_target_emploree(task_id,task_name,name,email,bu_id,bu_name,cap_time,type,flag,bu_tree_id,bu_tree_name) values('%s','%s','%s','%s',%s,'%s','%s',%d,%d,'%s','%s')";
                                if (commonMapper.getCount(String.format(selSql, taskId, email)) > 0) {
                                    commonMapper.exeSQL(String.format(upSql, taskId, email));
                                } else {
                                    String userName = DataUtils.getString(userMap, "user_name");
                                    String nickName = DataUtils.getString(userMap, "nick_name");
                                    if (StringUtils.isNotBlank(nickName)) {
                                        userName = String.format("%s(%s)", nickName, userName);
                                    }
                                    String deptId = DataUtils.getString(userMap, "dept_id");
                                    String deptName = DataUtils.getString(userMap, "dept_name");
                                    String ancestors = DataUtils.getString(userMap, "ancestors") + "," + deptId;
                                    String fullName = DataUtils.getString(userMap, "full_name");
                                    String cheatedTime = JsonUtils.getDateStr(record, "cheated_time");
                                    int type = 0;
                                    if (JsonUtils.equalVal(record, "url_click_status", "1")) {
                                        type = 4;
                                    } else if (JsonUtils.equalVal(record, "url_click_status", "1")) {
                                        type = 3;
                                    } else if (JsonUtils.equalVal(record, "attachment_open_status", "1")) {
                                        type = 2;
                                    } else if (JsonUtils.equalVal(record, "email_open_status", "1")) {
                                        type = 1;
                                    }
                                    if (JsonUtils.equalVal(record, "cheated", "0")) {
                                        type = 0;
                                    }
                                    commonMapper.exeSQL(String.format(inSql, taskId, taskName, userName, email, deptId, deptName, cheatedTime, type, 0, ancestors, fullName));
                                }
                            }
                        } catch (Exception e) {
                            log.error(e.getMessage(), e);
                        }
                        try {
                            String taskId = Md5Utils.hash(taskName);
                            String email = JsonUtils.getStr(record, "employee_email");
                            if (StringUtils.isBlank(email)) {
                                return;
                            }
                            String selSql = "select count(1) from tb_fish_send_emploree where task_id = '%s' and email = '%s'";
                            String upSql = "update tb_fish_send_emploree set flag = '0' where task_id = '%s' and email = '%s'";
                            String inSql = "insert into tb_fish_send_emploree(task_id,task_name,email,flag,bu_tree_id,bu_tree_name,cheated) values('%s','%s','%s',0,'%s','%s',%s)";
                            if (commonMapper.getCount(String.format(selSql, taskId, email)) > 0) {
                                commonMapper.exeSQL(String.format(upSql, taskId, email));
                            } else {
                                String deptId = DataUtils.getString(userMap, "dept_id");
                                String ancestors = DataUtils.getString(userMap, "ancestors") + "," + deptId;
                                String fullName = DataUtils.getString(userMap, "full_name");
                                String cheated = JsonUtils.getStr(record, "cheated");
                                commonMapper.exeSQL(String.format(inSql, taskId, taskName, email, ancestors, fullName, cheated));
                            }
                        } catch (Exception e) {
                            log.error(e.getMessage(), e);
                        }
                    }
                }
                FishTask fishTask = new FishTask();
                fishTask.setCapStart(startTime);
                fishTask.setCapEnd(endTime);
                //fishTask.setJobId(id);
                fishTask.setTaskId(Md5Utils.hash(taskName));
                fishTask.setTaskName(taskName);
                taskMap.put(fishTask.getTaskId(), fishTask);
            }
            commonMapper.exeSQL("delete from tb_fish_target_emploree where flag = '1'");
            commonMapper.exeSQL("delete from tb_fish_send_emploree where flag = '1'");


            SysDept root = sysDeptMapper.selectByDeptId(100);
            taskMap.forEach((k, v) -> {
                try {
                    String totalQuery = "select count(1) total,sum(cheated) cheatedTotal from tb_fish_send_emploree where task_id = '" + k + "' and  bu_tree_id like '0,%'";
                    JSONObject jsonObject = commonMapper.queryOne(totalQuery);
                    int total = JsonUtils.getInt(jsonObject, "total");
                    int cheatedCount = JsonUtils.getInt(jsonObject, "cheatedTotal");
                    v.setTotal(total);
                    v.setNumOfSend(JsonUtils.getInt(jsonObject, "total"));
                    //v.setBuId(root.getDeptId());
                    v.setBuName(root.getDeptName());

                    String selSql = "select count(1) from tb_fish_task_group_info where task_id = '%s'";
                    String upSql = "update tb_fish_task_group_info set flag = '0',total=%d,num_of_send=%d where task_id = '%s'";
                    String inSql = "insert into tb_fish_task_group_info(task_id,task_name,flag,bu_id,bu_name,total,num_of_send,cap_start,cap_end) values('%s','%s',0,%d,'%s',%d,%d,'%s','%s')";
                    if (commonMapper.getCount(String.format(selSql, k)) > 0) {
                        commonMapper.exeSQL(String.format(upSql, v.getTotal(), v.getNumOfSend(), k));
                    } else {
                        commonMapper.exeSQL(String.format(inSql, v.getTaskId(), v.getTaskName(), v.getBuId(), v.getBuName(), v.getTotal(), v.getNumOfSend(), v.getCapStart(), v.getCapEnd()));
                    }


                    String cap = "0";
                    if (total > 0) {
                        double perTarget = (cheatedCount * 100 * 1.0) / total;
                        BigDecimal bd = new BigDecimal(perTarget);
                        bd = bd.setScale(2, BigDecimal.ROUND_HALF_UP);
                        cap = bd.toString();
                    }
                    try {
                        selSql = "select count(1) from tb_fish_task_bu_info where bu_id = %d and task_id = '%s'";
                        upSql = "update tb_fish_task_bu_info set flag = '0',total=%d,num_of_send=%d where bu_id = %d and task_id = '%s'";
                        inSql = "insert into tb_fish_task_bu_info(task_id,task_name,flag,bu_id,bu_name,total,num_of_send,bu_tree_id) values('%s','%s',0,%d,'%s',%d,%d,'%s')";
                        if (commonMapper.getCount(String.format(selSql, root.getDeptId(), k)) > 0) {
                            commonMapper.exeSQL(String.format(upSql, total, total, root.getDeptId(), k));
                        } else {
                            String ancestors = root.getAncestors() + "," + root.getDeptId();
                            commonMapper.exeSQL(String.format(inSql, v.getTaskId(), v.getTaskName(), root.getDeptId(), root.getDeptName(), total, total, ancestors));
                        }
                    } catch (Exception e) {
                        log.error(e.getMessage(), e);
                    }

                    try {
                        selSql = "select count(1) from tb_fish_task_cap where bu_id = %d and task_id = '%s'";
                        upSql = "update tb_fish_task_cap set flag = '0',cap_rate=%s where bu_id = %d and task_id = '%s'";
                        inSql = "insert into tb_fish_task_cap(task_id,flag,bu_id,bu_name,cap_rate,bu_tree_id,cap_start,cap_end) values('%s',0,%d,'%s',%s,'%s','%s','%s')";
                        if (commonMapper.getCount(String.format(selSql, root.getDeptId(), k)) > 0) {
                            commonMapper.exeSQL(String.format(upSql, cap, root.getDeptId(), k));
                        } else {
                            String ancestors = root.getAncestors() + "," + root.getDeptId();
                            commonMapper.exeSQL(String.format(inSql, v.getTaskId(), root.getDeptId(), root.getDeptName(), cap, ancestors, v.getCapStart(), v.getCapEnd()));
                        }
                    } catch (Exception e) {
                        log.error(e.getMessage(), e);
                    }
                } catch (Exception e) {
                    log.error(e.getMessage(), e);
                }

                iter(v, root.getDeptId());
            });


            log.info("钓鱼数据同步结束");
        } catch (Exception e) {
            log.error(e.getMessage(), e);
        }
    }

    private void iter(FishTask fishTask, long rootId) {
        CommonMapper commonMapper = GetSpringBean.getBean(CommonMapper.class);
        SysDeptMapper sysDeptMapper = GetSpringBean.getBean(SysDeptMapper.class);
        String k = fishTask.getTaskId();
        String totalQuery = "select d.dept_id,count(1) total,sum(cheated) cheatedTotal from tb_fish_send_emploree s , sys_dept d  where s.task_id = '" + k + "' and d.parent_id = " + rootId + " and s.bu_tree_id like concat(d.ancestors,',',d.dept_id,'%') group by d.dept_id";
        List<JSONObject> dataList = commonMapper.query(totalQuery);
        for (JSONObject json : dataList) {
            try {
                int total = JsonUtils.getInt(json, "total");
                long deptId = JsonUtils.getLong(json, "dept_id");
                int cheatedCount = JsonUtils.getInt(json, "cheatedTotal");
                log.info("size={},dept_id={}---total={}", dataList.size(), deptId, total);
                String cap = "0";
                if (total > 0) {
                    double perTarget = (cheatedCount * 100 * 1.0) / total;
                    BigDecimal bd = new BigDecimal(perTarget);
                    bd = bd.setScale(2, BigDecimal.ROUND_HALF_UP);
                    cap = bd.toString();
                } else {
                    continue;
                }
                SysDept firstDept = sysDeptMapper.selectByDeptId(deptId);
                try {
                    String selSql = "select count(1) from tb_fish_task_bu_info where bu_id = %d and task_id = '%s'";
                    String upSql = "update tb_fish_task_bu_info set flag = '0',total=%d,num_of_send=%d where bu_id = %d and task_id = '%s'";
                    String inSql = "insert into tb_fish_task_bu_info(task_id,task_name,flag,bu_id,bu_name,total,num_of_send,bu_tree_id) values('%s','%s',0,%d,'%s',%d,%d,'%s')";
                    if (commonMapper.getCount(String.format(selSql, firstDept.getDeptId(), k)) > 0) {
                        commonMapper.exeSQL(String.format(upSql, total, total, firstDept.getDeptId(), k));
                    } else {
                        String ancestors = firstDept.getAncestors() + "," + firstDept.getDeptId();
                        commonMapper.exeSQL(String.format(inSql, fishTask.getTaskId(), fishTask.getTaskName(), firstDept.getDeptId(), firstDept.getDeptName(), total, total, ancestors));
                    }
                } catch (Exception e) {
                    log.error(e.getMessage(), e);
                }

                try {
                    String selSql = "select count(1) from tb_fish_task_cap where bu_id = %d and task_id = '%s'";
                    String upSql = "update tb_fish_task_cap set flag = '0',cap_rate=%s where bu_id = %d and task_id = '%s'";
                    String inSql = "insert into tb_fish_task_cap(task_id,flag,bu_id,bu_name,cap_rate,bu_tree_id,cap_start,cap_end) values('%s',0,%d,'%s',%s,'%s','%s','%s')";
                    if (commonMapper.getCount(String.format(selSql, firstDept.getDeptId(), k)) > 0) {
                        commonMapper.exeSQL(String.format(upSql, cap, firstDept.getDeptId(), k));
                    } else {
                        String ancestors = firstDept.getAncestors() + "," + firstDept.getDeptId();
                        commonMapper.exeSQL(String.format(inSql, fishTask.getTaskId(), firstDept.getDeptId(), firstDept.getDeptName(), cap, ancestors, fishTask.getCapStart(), fishTask.getCapEnd()));
                    }
                } catch (Exception e) {
                    log.error(e.getMessage(), e);
                }
                iter(fishTask, deptId);
            } catch (Exception e) {
                log.error(e.getMessage(), e);
            }
        }


    }
}
