package com.crc.sync.mail;

import com.alibaba.fastjson.JSONObject;
import com.crc.common.code.CodeTool;
import com.crc.common.code.CreateInsert;
import com.crc.common.utils.DataUtils;
import com.crc.common.utils.JsonUtils;
import com.crc.common.utils.Md5Utils;
import com.crc.common.utils.SqlUtils;
import com.crc.secface.config.GetSpringBean;
import com.crc.secface.db.ConfBuzziMySql;
import com.crc.secface.domain.FishTask;
import com.crc.secface.domain.TaskRecord;
import com.crc.secface.domain.TaskSend;
import com.crc.secface.domain.vo.DbConfig;
import com.crc.secface.mapper.CommonMapper;
import com.crc.sync.config.SyncSecConfigLoad;
import com.crc.sync.config.SyncSecConstants;
import com.google.common.collect.Lists;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringEscapeUtils;
import org.apache.commons.lang3.StringUtils;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

/**
 * <p>
 * 同步钓鱼邮件数据
 * </p>
 *
 * @author yuyuhang5
 * @createDate 2024/5/21 16:46
 */
@Slf4j
public class FishNewDataSync {

    public void sync() {
        String dbStr = SyncSecConfigLoad.getRemarkValue(SyncSecConstants.FISH_DB_CONFIG);
        if (dbStr == null || StringUtils.isBlank(dbStr)) {
            log.error("钓鱼邮件数据库配置错误SYNC_SEC_CONFIG【fish_db_config】");
            return;
        }
        if (!SyncSecConfigLoad.isEnable(SyncSecConstants.FISH_SYNC_ENABLE)) {
            return;
        }
        log.info("钓鱼数据同步开始");
        JSONObject json = JsonUtils.parse(dbStr);
        DbConfig dbConfig = new DbConfig();
        dbConfig.setUrl(StringEscapeUtils.unescapeHtml4(JsonUtils.getStr(json, "url")));
        dbConfig.setUsername(JsonUtils.getStr(json, "username"));
        dbConfig.setPassword(JsonUtils.getStr(json, "password"));
        dbConfig.setDriverClassName("com.mysql.cj.jdbc.Driver");
        if (StringUtils.isBlank(dbConfig.getUrl())) {
            log.error("钓鱼邮件数据库配置错误SYNC_SEC_CONFIG【fish_db_config】");
            return;
        }

        /*
        钓鱼项目清单
         */
        String taskListSql = "select t.*,d.dict_label as project_name from tb_fish_task t inner join (select * from sys_dict_data where dict_type = 'fish_project' and remark = '1') d on t.project_ids = d.dict_value  where del_flag = '0' and task_type = '0'";
        CommonMapper commonMapper = GetSpringBean.getBean(CommonMapper.class);

        List<JSONObject> taskList = ConfBuzziMySql.query(dbConfig, taskListSql);
        List<String> taskIdList = Lists.newArrayList();
        for (JSONObject task : taskList) {
            String taskName = DataUtils.getString(task, "project_name");
            taskIdList.add("NEW#" + Md5Utils.hash(taskName));
        }

        if (taskIdList.size() < 1) {
            log.info("没有检测到要计算到钓鱼项目fish_project/remark=1");
            return;
        }

        String sqlInTask = SqlUtils.getInSql(taskIdList);
        assert commonMapper != null;
        commonMapper.exeSQL("update task_infos set flag = '0' where task_id in " + sqlInTask);
        commonMapper.exeSQL("update target_emplorees set flag = '0' where task_id in " + sqlInTask);
        commonMapper.exeSQL("update send_statistics set flag = '0' where task_id  in " + sqlInTask);

        HashMap<String, FishTask> taskMap = new HashMap<>(16);
        HashMap<String, TaskSend> recordMap = new HashMap<>(16);

        String sendCountListSql = "select * from tb_fish_task_record where task_id =  %s";
        List<TaskRecord> recordDataList = new ArrayList<>();
        for (JSONObject task : taskList) {
            String taskName = DataUtils.getString(task, "project_name");
            String id = DataUtils.getString(task, "id");
            int total = 0;
            int sendTotal = 0;
            if (!taskMap.containsKey(taskName)) {
                FishTask taskObj = new FishTask();
                taskObj.setTotal(total);
                taskObj.setNumOfSend(sendTotal);
                taskObj.setTaskName(taskName);
                taskObj.setBuId("集团");
                taskObj.setTaskType("0");
                taskObj.setBuName("集团");
                taskObj.setTaskId("NEW#" + Md5Utils.hash(taskName));
                taskObj.setCapStart(JsonUtils.getStr(task, "start_time"));
                taskObj.setCapEnd(JsonUtils.getStr(task, "end_time"));
                String fishType = JsonUtils.getStr(task, "send_type");
                if (!"2".equals(fishType)) {
                    fishType = "1";
                }
                taskObj.setSendType(fishType);
                taskMap.put(taskName, taskObj);
            } else {
                taskMap.get(taskName).addNumOfSend(sendTotal);
                taskMap.get(taskName).addTotal(total);
                if (taskMap.get(taskName).getCapStart() == null && StringUtils.isNotBlank(JsonUtils.getStr(task, "start_time"))) {
                    taskMap.get(taskName).setCapStart(JsonUtils.getStr(task, "start_time"));
                }
                if (taskMap.get(taskName).getCapEnd() == null && StringUtils.isNotBlank(JsonUtils.getStr(task, "end_time"))) {
                    taskMap.get(taskName).setCapEnd(JsonUtils.getStr(task, "end_time"));
                }
            }

            List<JSONObject> recordList = ConfBuzziMySql.query(dbConfig, String.format(sendCountListSql, id));
            for (JSONObject record : recordList) {
                String deptPath = JsonUtils.getStr(record, "dept_path_name");
                if (StringUtils.isBlank(deptPath)) {
                    continue;
                }
                String fishType = JsonUtils.getStr(record, "fish_type");
                if (!"2".equals(fishType)) {
                    fishType = "1";
                }
                String firstOffice = DataUtils.getDeptTree(deptPath, 1);
                String secondOffice = DataUtils.getDeptTree(deptPath, 2);
                String key = taskMap.get(taskName).getTaskId() + "#" + firstOffice;
                if ("华润数科".equalsIgnoreCase(firstOffice) || "润联科技".equalsIgnoreCase(firstOffice) || "集团总部".equalsIgnoreCase(firstOffice)) {
                    key = taskMap.get(taskName).getTaskId() + "#" + firstOffice + "#" + secondOffice;
                }
                if (!recordMap.containsKey(key)) {
                    TaskSend taskObj = new TaskSend();
                    taskObj.addTotal(1);
                    if (JsonUtils.equal(record, "email_send_status", "1")) {
                        taskObj.addNumOfSend(1);
                    }
                    taskObj.setTaskId(taskMap.get(taskName).getTaskId());
                    taskObj.setDepend1(firstOffice);
                    taskObj.setDepend2(secondOffice);
                    taskObj.setFishType(fishType);
                    recordMap.put(key, taskObj);
                } else {
                    if (JsonUtils.equal(record, "email_send_status", "1")) {
                        recordMap.get(key).addNumOfSend(1);
                    }
                    if (StringUtils.isBlank(recordMap.get(key).getDepend2())) {
                        recordMap.get(key).setDepend2(secondOffice);
                    }
                    recordMap.get(key).addTotal(1);
                }
                if (JsonUtils.equal(record, "cheated", "1")) {
                    TaskRecord taskRecord = new TaskRecord();
                    taskRecord.setCapTime(JsonUtils.getStr(record, "cheated_time"));
                    taskRecord.setTaskId(taskMap.get(taskName).getTaskId());
                    taskRecord.setEmail(JsonUtils.getStr(record, "employee_email"));
                    taskRecord.setName(JsonUtils.getStr(record, "employee_name"));
                    taskRecord.setFishType(fishType);
                    taskRecord.setPhone(JsonUtils.getStr(record, "employee_phone"));
                    taskRecord.setDepend1(firstOffice);
                    taskRecord.setDepend2(secondOffice);
                    //STATUS  2邮件附件  1邮件链接  3邮件输入敏感信息  4短信链接 5扫描二维码
                    //status = 2打开附件人数;status = 1  点击链接
                    StringBuilder statusFlagString = new StringBuilder();
                    if ("1".equals(fishType)) {

                        if (JsonUtils.equal(record, "attachment_open_status", "1")) {
                            statusFlagString.append("2,");
                        }
                        if (JsonUtils.equal(record, "input_status", "1")) {
                            statusFlagString.append("3,");
                        }
                        if (JsonUtils.equal(record, "qr_code_click_status", "1")) {
                            statusFlagString.append("5,");
                        }
                        if(statusFlagString.length()<=0){
                            statusFlagString.append("1,");
                        }

                    } else {
                        statusFlagString.append("4,");
                    }
                    taskRecord.setStatus(statusFlagString.toString());
                    recordDataList.add(taskRecord);
                }

            }
        }

        commonMapper.exeSQL("update target_emplorees set flag = '0' where task_id in " + sqlInTask);

        String taskRecordCount1 = "select count(1) from target_emplorees where task_id = '%s' and email= '%s' and fish_type = '1' ";
        String taskRecordSql1 = "update target_emplorees set flag = '1',cap_time='%s',status = '%s' where task_id = '%s' and email= '%s' and fish_type = '1' ";
        String taskRecordCount2 = "select count(1) from target_emplorees where task_id = '%s' and email= '%s' and fish_type = '2' ";
        String taskRecordSql2 = "update target_emplorees set flag = '1',cap_time='%s',status = '%s' where task_id = '%s' and email= '%s' and fish_type = '2' ";
        recordDataList.forEach(v -> {
            if ("1".equals(v.getFishType())) {
                if (commonMapper.getCount(String.format(taskRecordCount1, v.getTaskId(), v.getEmail())) > 0) {
                    commonMapper.exeSQL(String.format(taskRecordSql1, v.getCapTime(), v.getStatus(), v.getTaskId(), v.getEmail()));
                } else {
                    CreateInsert<TaskRecord> fti = new CreateInsert<>();
                    v.setFlag("1");
                    String cSql = fti.createinsert(v, "target_emplorees");
                    commonMapper.exeSQL(cSql);
                }
            } else if ("2".equals(v.getFishType())) {
                if (commonMapper.getCount(String.format(taskRecordCount2, v.getTaskId(), v.getEmail())) > 0) {
                    commonMapper.exeSQL(String.format(taskRecordSql2, v.getCapTime(), v.getStatus(), v.getTaskId(), v.getEmail()));
                } else {
                    CreateInsert<TaskRecord> fti = new CreateInsert<>();
                    v.setFlag("1");
                    String cSql = fti.createinsert(v, "target_emplorees");
                    commonMapper.exeSQL(cSql);
                }
            }
        });

        commonMapper.exeSQL("delete from target_emplorees where flag = '0' and task_id in " + sqlInTask);


        String taskSendCount1 = "select count(1) from send_statistics where task_id = '%s' and depend1= '%s'";
        String taskSendCount2 = "select count(1) from send_statistics where task_id = '%s' and depend1= '%s' and depend2= '%s'";
        String updateSendSql1 = "update send_statistics set flag = '1',total=%d,num_of_send =%d where task_id = '%s' and depend1= '%s' ";
        String updateSendSql2 = "update send_statistics set flag = '1',total=%d,num_of_send =%d where task_id = '%s' and depend1= '%s' and depend2= '%s'";

        recordMap.forEach((k, v) -> {
            //if ("华润数科".equalsIgnoreCase(firstOffice) || "润联科技".equalsIgnoreCase(firstOffice) || "集团总部".equalsIgnoreCase(firstOffice)) {
            if (k.contains("华润数科") || k.contains("润联科技") || k.contains("集团总部")) {
                if (commonMapper.getCount(String.format(taskSendCount2, v.getTaskId(), v.getDepend1(), v.getDepend2())) > 0) {
                    commonMapper.exeSQL(String.format(updateSendSql2, v.getTotal(), v.getNumOfSend(), v.getTaskId(), v.getDepend1(), v.getDepend2()));
                } else {
                    CreateInsert<TaskSend> fti = new CreateInsert<>();
                    v.setFlag("1");
                    String cSql = fti.createinsert(v, "send_statistics");
                    commonMapper.exeSQL(cSql);
                }
            } else {
                if (commonMapper.getCount(String.format(taskSendCount1, v.getTaskId(), v.getDepend1())) > 0) {
                    commonMapper.exeSQL(String.format(updateSendSql1, v.getTotal(), v.getNumOfSend(), v.getTaskId(), v.getDepend1()));
                } else {
                    CreateInsert<TaskSend> fti = new CreateInsert<>();
                    v.setFlag("1");
                    String cSql = fti.createinsert(v, "send_statistics");
                    commonMapper.exeSQL(cSql);
                }

            }
        });
        commonMapper.exeSQL("delete from send_statistics where flag = '0' and task_id in " + sqlInTask);

        String taskInfosCount = "select count(1) from task_infos where task_id = '%s'";
        String updateTaskInfoSql = "update task_infos set flag = '1',task_name = '%s',total=%d,num_of_send =%d where task_id='%s'";
        taskMap.forEach((k, v) -> {
            String sendCountAllSql = "select sum(num_of_send) num_of_send,sum(total) total from send_statistics where task_id = '" + v.getTaskId() + "'";
            List<HashMap<String, Object>> list = commonMapper.queryX(sendCountAllSql);
            if (list != null && list.size() > 0) {
                v.setTotal(DataUtils.getInt(DataUtils.getStr(list.get(0), "total")));
                v.setNumOfSend(DataUtils.getInt(DataUtils.getStr(list.get(0), "num_of_send")));
            }
            v.setSendType(null);
            if (commonMapper.getCount(String.format(taskInfosCount, v.getTaskId())) > 0) {
                commonMapper.exeSQL(String.format(updateTaskInfoSql, v.getTaskName(), v.getTotal(), v.getNumOfSend(), v.getTaskId()));
            } else {
                CreateInsert<FishTask> fti = new CreateInsert<>();
                v.setFlag("1");
                v.setNewType("1");
                String cSql = fti.createinsert(v, "task_infos");
                commonMapper.exeSQL(cSql);
            }
        });
        commonMapper.exeSQL("delete from task_infos where flag = '0' and task_id in " + sqlInTask);
        log.info("钓鱼数据同步结束");
    }
}
