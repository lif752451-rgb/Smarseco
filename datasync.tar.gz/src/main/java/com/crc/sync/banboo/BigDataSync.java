package com.crc.sync.banboo;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONArray;
import com.alibaba.fastjson.JSONObject;
import com.crc.common.banboo.BanbooLoad;
import com.crc.common.utils.HttpFileUtils;
import com.crc.common.utils.JsonUtils;
import com.crc.common.utils.MyTheadUtils;
import com.crc.secface.config.GetSpringBean;
import com.crc.secface.domain.AuthDept;
import com.crc.secface.domain.AuthUser;
import com.crc.secface.mapper.AuthDeptMapper;
import com.crc.secface.mapper.AuthUserMapper;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;

/**
 * 地铁大数据平台同步
 */
@Slf4j
public class BigDataSync {
    private final static int TIME_INTERVAL = 10;
    private final static int PAGE_SIZE = 5000;
    private final static int USER_PAGE_SIZE = 5000;

    public void sync() {
        JSONObject configJson = BanbooLoad.getBigDataConfig();
        if (configJson != null && configJson.size() > 0) {
            String hwId = JsonUtils.getStr(configJson, "X-HW-ID");
            String hwKey = JsonUtils.getStr(configJson, "X-HW-APPKEY");
            String ak = JsonUtils.getStr(configJson, "AK");
            String url = JsonUtils.getStr(configJson, "url");
            String officeService = JsonUtils.getStr(configJson, "OFFICE_SERVICE");
            String userService = JsonUtils.getStr(configJson, "USER_SERVICE");
            String getAll = JsonUtils.getStr(configJson, "GET_ALL");
            JSONObject paramJson = new JSONObject();
            paramJson.put("Format", "JSON");
            paramJson.put("AK", ak);
            //{"Format":"JSON","Service":"","PageSize":"2","PageNumber":"1","AK":"4OmFUEElKFqPJiEH7l4PYuuuFEqGhBmh/1aYcu7gXK8=","Condition":"DW_LAST_UPDATE_DATE>=TRUNC(SYSDATE)-1"}

            log.info("@@刷大数据组织开始");
            try {
                syncOffices(url, paramJson, hwId, hwKey, getAll, officeService);
            } catch (Exception e) {
                log.error(e.getMessage(), e);
            }
            log.info("@@刷大数据组织结束，开始刷用户");
            try {
                syncUsers(url, paramJson, hwId, hwKey, getAll, userService);
            } catch (Exception e) {
                log.error(e.getMessage(), e);
            }
        } else {
            log.error("zy_auth_config/big_data_auth没有配置");
        }

        log.info("@@刷大数据用户结束，开始刷数据到 STP");
        try {
            BanbooSyncToUserDeptWork work = new BanbooSyncToUserDeptWork();
            work.sync();
        } catch (Exception e) {
            log.error(e.getMessage(), e);
        }
        log.info("@@刷大数据结束");
    }


    /**
     * 同步组织数据
     *
     * @param url
     * @param paramJson
     * @param hwId
     * @param hwKey
     * @param officeService
     */
    private void syncOffices(String url, JSONObject paramJson, String hwId, String hwKey, String getAll, String officeService) {
        //https://roma.shenzhenmc.com/service/metro/mdm/query
        JSONObject headers = new JSONObject();
        headers.put("X-HW-ID", hwId);
        headers.put("X-HW-APPKEY", hwKey);
        //PageSize 分页大小，每页中包含的记录数。默认值为1000
        //PageNumber 分页的页号，比如PageNumber=2，则返回第二页的数据。默认值为1
        if (!"T".equals(getAll)) {//是否存在所有，否则查下最近一天数据
            paramJson.put("Condition", "DW_LAST_UPDATE_DATE>=TRUNC(SYSDATE)-1");
        } else {
            paramJson.put("Condition", "DW_LAST_UPDATE_DATE>=TRUNC(SYSDATE)-9999");
        }
        paramJson.put("Service", "DW_DEPT_INFO_SIT");
        if (StringUtils.isNotBlank(officeService)) {
            paramJson.put("Service", officeService);
            if (!"T".equals(getAll)) {//是否存在所有，否则查下最近一天数据
                paramJson.put("Condition", "LAST_UPDATE_DATE>=TRUNC(SYSDATE)-1");
            } else {
                paramJson.put("Condition", "LAST_UPDATE_DATE>=TRUNC(SYSDATE)-9999");
            }
        }
        paramJson.put("PageSize", 1);
        paramJson.put("PageNumber", 1);
        MyTheadUtils.sleepBySec(TIME_INTERVAL);
        String ret = HttpFileUtils.sendPost(url + "/service/metro/mdm/query", paramJson, headers);
        log.info(ret);
        JSONObject retJson = JsonUtils.parse(ret);
        long total = JsonUtils.getLong(retJson, "Total");
        log.info("syncUsers total={} ", total);
        if (total > 0) {
            AuthDeptMapper authDeptMapper = GetSpringBean.getBean(AuthDeptMapper.class);
            for (int i = 0; i < (Math.ceil(total / PAGE_SIZE) + 3); i++) {
                MyTheadUtils.sleepBySec(TIME_INTERVAL);
                paramJson.put("PageSize", PAGE_SIZE);
                paramJson.put("PageNumber", i);
                String data = HttpFileUtils.sendPost(url + "/service/metro/mdm/query", paramJson, headers);
                //{"Code":-6,"Message":"访问频率过高，请稍候再试"}
                JSONObject dataJson = JsonUtils.parse(data);
                int count = 1;
                while (!dataJson.containsKey("Rows") && count < 3) {
                    MyTheadUtils.sleepBySec(TIME_INTERVAL);
                    log.info("ERROR Data retry:{}", data);
                    try {
                        data = HttpFileUtils.sendPost(url + "/service/metro/mdm/query", paramJson, headers);
                        dataJson = JsonUtils.parse(data);
                    } catch (Exception e) {
                        log.error(e.getMessage(), e);
                    }
                    count++;
                }
                if (dataJson.containsKey("Rows")) {
                    JSONArray rows = dataJson.getJSONArray("Rows");
                    int rowTotal = rows.size();
                    int rowInsert = 0;
                    int rowUpdate = 0;
                    for (int j = 0; j < rows.size(); j++) {
                        AuthDept tbAuthDept = new AuthDept();
                        tbAuthDept.setUd2("BD");
                        JSONObject jsonObject = rows.getJSONObject(j);
                        if (jsonObject.containsKey("DEPT_ID")) {
                            tbAuthDept.setDeptId(JsonUtils.getStr(jsonObject, "DEPT_ID"));
                        }
                        if (jsonObject.containsKey("DEPT_DESC")) {
                            tbAuthDept.setDeptName(JsonUtils.getStr(jsonObject, "DEPT_DESC"));
                        }
                        if (jsonObject.containsKey("PART_DEPT_ID")) {
                            tbAuthDept.setDeptParentId(JsonUtils.getStr(jsonObject, "PART_DEPT_ID"));
                        }
                        tbAuthDept.setDeptFullName(JsonUtils.getStr(jsonObject, "DEPT_DESC_ALL"));
                        //A/I 对于 A:有效 I:无效
                        String EFF_STATUS = JsonUtils.getStr(jsonObject, "EFF_STATUS");
                        tbAuthDept.setUd1(EFF_STATUS);
                        String delFlag = JsonUtils.getStr(jsonObject, "DEL_FLAG");
                        if (StringUtils.isBlank(tbAuthDept.getDeptId())) {
                            log.error("部门id为空=" + JSON.toJSONString(jsonObject));
                            continue;
                        }
                        tbAuthDept.setUpdateTime(JsonUtils.getDateX(jsonObject, "LAST_UPDATE_DATE"));
                        tbAuthDept.setCreateTime(JsonUtils.getDateX(jsonObject, "CREATE_DATE"));
                        if ("I".equalsIgnoreCase(EFF_STATUS)) {//删除
                            AuthDept tmp = authDeptMapper.selectTbAuthDeptByDeptId(tbAuthDept.getDeptId());
                            boolean flag = false;
                            if (tmp != null) {
                                if (tbAuthDept.getUpdateTime() != null && tmp.getUpdateTime() != null) {
                                    if (tbAuthDept.getUpdateTime().after(tmp.getUpdateTime())) {
                                        flag = true;
                                    }
                                } else if (tbAuthDept.getUpdateTime() != null) {
                                    flag = true;
                                } else {
                                    if (tbAuthDept.getCreateTime() != null && tmp.getCreateTime() != null) {
                                        if (tbAuthDept.getCreateTime().after(tmp.getCreateTime())) {
                                            flag = true;
                                        }
                                    } else if (tbAuthDept.getCreateTime() != null) {
                                        flag = true;
                                    }
                                }
                            }
                            if (!flag) {
                                long refDeptId = 0L;
                                if (tmp != null && tmp.getRefDeptId() != null) {
                                    refDeptId = tmp.getRefDeptId();
                                    authDeptMapper.deleteSysDept(tmp.getRefDeptId());
                                }
                                log.info("bigdata-del dept id={},name={},refId={},data={}", tbAuthDept.getDeptId(), tbAuthDept.getDeptName(), refDeptId, JSON.toJSONString(jsonObject));
                                authDeptMapper.deleteDeptById(tbAuthDept.getDeptId());
                            } else {
                                log.info("{},无法判断更新时间或者时间比较老：{}", tbAuthDept.getDeptName(), JSON.toJSONString(jsonObject));
                            }
                        } else {//修改/增加
                            tbAuthDept.setDelFlag("0");
                            AuthDept tmp = authDeptMapper.selectTbAuthDeptByDeptId(tbAuthDept.getDeptId());
                            if (tmp == null) {
                                tbAuthDept.setUd2("0");
                                rowInsert++;
                                authDeptMapper.insert(tbAuthDept);
                            } else {
                                if (tbAuthDept.getUpdateTime() != null && tmp.getUpdateTime() != null) {
                                    if (tbAuthDept.getUpdateTime().after(tmp.getUpdateTime())) {
                                        rowUpdate++;
                                        authDeptMapper.updateAuthDept(tbAuthDept);
                                    } else {
                                        log.info("11={},getUpdateTime：{} 时间更新,old={}", tbAuthDept.getDeptName(), tbAuthDept.getUpdateTime(), tmp.getUpdateTime());
                                    }
                                } else if (tbAuthDept.getUpdateTime() != null) {
                                    rowUpdate++;
                                    authDeptMapper.updateAuthDept(tbAuthDept);
                                } else {
                                    if (tbAuthDept.getCreateTime() != null && tmp.getCreateTime() != null) {
                                        if (tbAuthDept.getCreateTime().after(tmp.getCreateTime())) {
                                            rowUpdate++;
                                            authDeptMapper.updateAuthDept(tbAuthDept);
                                        } else {
                                            log.info("11={},getCreateTime：{} 时间更新,old={}", tbAuthDept.getDeptName(), tbAuthDept.getCreateTime(), tmp.getCreateTime());
                                        }
                                    } else if (tbAuthDept.getCreateTime() != null) {
                                        rowUpdate++;
                                        authDeptMapper.updateAuthDept(tbAuthDept);
                                    } else {
                                        //log.info("{},无法判断更新时间：{}", tbAuthDept.getDeptName(), JSON.toJSONString(jsonObject));
                                    }
                                }
                            }
                        }
                    }
                    log.info("row total={},insert={},update={}", rowTotal, rowInsert, rowUpdate);
                } else {
                    log.error("数据不完整：" + data);
                }
            }
        }
    }

    /**
     * 同步用户数据
     *
     * @param url
     * @param paramJson
     * @param hwId
     * @param hwKey
     * @param userService
     */
    private void syncUsers(String url, JSONObject paramJson, String hwId, String hwKey, String getAll, String userService) {
        //https://10.34.55.109/service/metro/mdm/query
        JSONObject headers = new JSONObject();
        headers.put("X-HW-ID", hwId);
        headers.put("X-HW-APPKEY", hwKey);
        //PageSize 分页大小，每页中包含的记录数。默认值为1000
        //PageNumber 分页的页号，比如PageNumber=2，则返回第二页的数据。默认值为1
        paramJson.put("Service", "EMPLOYEE_INFO_IOPS_SIT");
        if (StringUtils.isNotBlank(userService)) {
            paramJson.put("Service", userService);
        }
        paramJson.put("PageSize", 1);
        paramJson.put("PageNumber", 1);
        if (!"T".equals(getAll)) {//是否存在所有，否则查下最近一天数据
            paramJson.put("Condition", "DW_LAST_UPDATE_DATE>=TRUNC(SYSDATE)-1");
        } else {
            paramJson.put("Condition", "DW_LAST_UPDATE_DATE>=TRUNC(SYSDATE)-9999");
        }
        MyTheadUtils.sleepBySec(TIME_INTERVAL);
        String ret = HttpFileUtils.sendPost(url + "/service/metro/mdm/query", paramJson, headers);
        log.info(ret);
        JSONObject retJson = JsonUtils.parse(ret);
        long total = JsonUtils.getLong(retJson, "Total");
        log.info("syncUsers total={} ", total);
        if (total > 0) {
            AuthUserMapper authUserMapper = GetSpringBean.getBean(AuthUserMapper.class);
            for (int i = 0; i < (Math.ceil(total / USER_PAGE_SIZE) + 3); i++) {
                MyTheadUtils.sleepBySec(TIME_INTERVAL);
                paramJson.put("PageSize", USER_PAGE_SIZE);
                paramJson.put("PageNumber", i);
                String data = HttpFileUtils.sendPost(url + "/service/metro/mdm/query", paramJson, headers);
                JSONObject dataJson = JsonUtils.parse(data);
                int count = 1;
                while (!dataJson.containsKey("Rows") && count < 3) {
                    MyTheadUtils.sleepBySec(TIME_INTERVAL);
                    log.info("ERROR Data retry:{}", data);
                    try {
                        data = HttpFileUtils.sendPost(url + "/service/metro/mdm/query", paramJson, headers);
                        dataJson = JsonUtils.parse(data);
                    } catch (Exception e) {
                        log.error(e.getMessage(), e);
                    }
                    count++;
                }
                if (dataJson.containsKey("Rows")) {
                    JSONArray rows = dataJson.getJSONArray("Rows");
                    int rowTotal = rows.size();
                    int rowInsert = 0;
                    int rowUpdate = 0;
                    for (int j = 0; j < rows.size(); j++) {
                        JSONObject jsonObject = rows.getJSONObject(j);
                        AuthUser tbAuthUser = new AuthUser();
                        tbAuthUser.setUd2("BD");
                        if (jsonObject.containsKey("OA_ACCOUNT")) {
                            tbAuthUser.setUserName(JsonUtils.getStr(jsonObject, "OA_ACCOUNT"));
                        } else {
                            log.error("用户OA_ACCOUNT为空=" + JSON.toJSONString(jsonObject));
                            continue;
                        }
                        if (jsonObject.containsKey("NAME")) {
                            tbAuthUser.setDisplayName(JsonUtils.getStr(jsonObject, "NAME"));
                        }
                        if (jsonObject.containsKey("USER_ID")) {
                            tbAuthUser.setEmpno(JsonUtils.getStr(jsonObject, "USER_ID"));
                        }
                        if (jsonObject.containsKey("EMAIL_ADDR")) {
                            tbAuthUser.setUserMail(JsonUtils.getStr(jsonObject, "EMAIL_ADDR"));
                        }
                        if (jsonObject.containsKey("CELLPHONE")) {
                            tbAuthUser.setUserMobile(JsonUtils.getStr(jsonObject, "CELLPHONE"));
                        }
                        if (jsonObject.containsKey("DEPTID")) {
                            tbAuthUser.setDeptId(JsonUtils.getStr(jsonObject, "DEPTID"));
                        }
                        if (StringUtils.isBlank(tbAuthUser.getEmpno())) {
                            tbAuthUser.setEmpno(tbAuthUser.getUserName());
                        }
                        if (StringUtils.isBlank(tbAuthUser.getDisplayName())) {
                            tbAuthUser.setDisplayName(tbAuthUser.getUserName());
                        }
                        if (StringUtils.isBlank(tbAuthUser.getUserName())) {
                            tbAuthUser.setUserName(tbAuthUser.getEmpno());
                        }

                        if (StringUtils.isBlank(tbAuthUser.getEmpno())) {
                            log.error("用户id为空=" + JSON.toJSONString(jsonObject));
                            continue;
                        }
                        //A/I 对于 A:有效 I:无效
                        String HR_STATUS = JsonUtils.getStr(jsonObject, "HR_STATUS");
                        tbAuthUser.setUpdateTime(JsonUtils.getDateX(jsonObject, "LAST_UPDATE_DATE"));
                        tbAuthUser.setCreateTime(JsonUtils.getDateX(jsonObject, "CREATE_DATE"));
                        tbAuthUser.setUd1(HR_STATUS);
                        if ("I".equalsIgnoreCase(HR_STATUS)) {//删除
                            boolean flag = false;
                            AuthUser tmp = authUserMapper.selectByEmpo(tbAuthUser.getEmpno());
                            if (tmp != null) {
                                if (tbAuthUser.getUpdateTime() != null && tmp.getUpdateTime() != null) {
                                    if (tbAuthUser.getUpdateTime().after(tmp.getUpdateTime())) {
                                        flag = true;
                                    }
                                } else if (tbAuthUser.getUpdateTime() != null) {
                                    flag = true;
                                } else {
                                    if (tbAuthUser.getCreateTime() != null && tmp.getCreateTime() != null) {
                                        if (tbAuthUser.getCreateTime().after(tmp.getCreateTime())) {
                                            flag = true;
                                        }
                                    } else if (tbAuthUser.getCreateTime() != null) {
                                        flag = true;
                                    }
                                }
                            }
                            if (!flag) {
                                authUserMapper.deleteTbAuthUserByEmpno(tbAuthUser.getEmpno());
                                authUserMapper.deleteUser(tbAuthUser.getEmpno());
                            } else {
                                //log.info("{},无法判断更新时间或者时间比较老：{}", tbAuthUser.getUserName(), JSON.toJSONString(jsonObject));
                            }
                        } else {//修改/增加
                            tbAuthUser.setDelFlag("0");
                            AuthUser tmp = authUserMapper.selectByEmpo(tbAuthUser.getEmpno());
                            if (tmp == null) {
                                tbAuthUser.setUd2("0");
                                rowInsert++;
                                authUserMapper.insert(tbAuthUser);
                            } else {
                                if (tbAuthUser.getUpdateTime() != null && tmp.getUpdateTime() != null) {
                                    if (tbAuthUser.getUpdateTime().after(tmp.getUpdateTime())) {
                                        rowUpdate++;
                                        authUserMapper.updateAuthUser(tbAuthUser);
                                    } else {
                                        log.info("11={},getUpdateTime：{} 时间更新,old={}", tbAuthUser.getUserName(), tbAuthUser.getUpdateTime(), tmp.getUpdateTime());
                                    }
                                } else if (tbAuthUser.getUpdateTime() != null) {
                                    rowUpdate++;
                                    authUserMapper.updateAuthUser(tbAuthUser);
                                } else {
                                    if (tbAuthUser.getCreateTime() != null && tmp.getCreateTime() != null) {
                                        if (tbAuthUser.getCreateTime().after(tmp.getCreateTime())) {
                                            rowUpdate++;
                                            authUserMapper.updateAuthUser(tbAuthUser);
                                        } else {
                                            log.info("11={},getCreateTime：{} 时间更新,old={}", tbAuthUser.getUserName(), tbAuthUser.getCreateTime(), tmp.getCreateTime());
                                        }
                                    } else if (tbAuthUser.getCreateTime() != null) {
                                        rowUpdate++;
                                        authUserMapper.updateAuthUser(tbAuthUser);
                                    } else {
                                        //log.info("{},无法判断更新时间：{}", tbAuthUser.getUserName(), JSON.toJSONString(jsonObject));
                                    }
                                }
                            }
                        }
                    }
                    log.info("row total={},insert={},update={}", rowTotal, rowInsert, rowUpdate);
                } else {
                    log.error("数据不完整：" + data);
                }
            }
        }
    }
}
