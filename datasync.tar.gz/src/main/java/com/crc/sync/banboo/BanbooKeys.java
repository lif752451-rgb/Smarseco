package com.crc.sync.banboo;

import com.alibaba.fastjson.JSONObject;
import com.crc.common.banboo.BanbooLoad;
import com.crc.common.utils.JsonUtils;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;

@Slf4j
public class BanbooKeys {
    private static String BANBOO_KEY = "";
    private static String BANBOO_TYPE = "";

    private static String BANBOO_SIGN = "";

    public static String getKey() {
        if (StringUtils.isNotBlank(BANBOO_KEY)) {
            return BANBOO_KEY;
        } else {
            JSONObject json = BanbooLoad.getPushConfig();
            if (json == null) {
                BANBOO_KEY = "1234567890000000";
                log.error("竹云推送配置有误，zy_auth_config/zy_push_auth,使用默认值");
            } else {
                BANBOO_KEY = JsonUtils.getStr(json, "key");
            }
        }
        return BANBOO_KEY;
    }

    public static String getType() {
        if (StringUtils.isNotBlank(BANBOO_TYPE)) {
            return BANBOO_TYPE;
        } else {
            JSONObject json = BanbooLoad.getPushConfig();
            if (json == null) {
                BANBOO_TYPE = "SM4";
                log.error("竹云推送配置有误，zy_auth_config/zy_push_auth,使用默认值");
            } else {
                BANBOO_TYPE = JsonUtils.getStr(json, "type");
            }
        }
        return BANBOO_TYPE;
    }

    public static String getSignature() {
        if (StringUtils.isNotBlank(BANBOO_SIGN)) {
            return BANBOO_SIGN;
        } else {
            JSONObject json = BanbooLoad.getPushConfig();
            if (json == null) {
                BANBOO_SIGN = "4ea5487e4eb76b689f873be82891826935134b9008da478358a9f5b15d465e63";
                log.error("竹云推送配置有误，zy_auth_config/zy_push_auth,使用默认值");
            } else {
                BANBOO_SIGN = JsonUtils.getStr(json, "signature");
            }
        }
        return BANBOO_SIGN;
    }
}
