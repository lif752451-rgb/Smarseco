package com.crc.sync.banboo;

import com.alibaba.fastjson.JSONObject;
import com.crc.common.banboo.BanbooLoad;
import com.crc.common.code.SimpleCodeTool;
import com.crc.common.utils.*;
import com.crc.secface.config.GetSpringBean;
import com.crc.secface.domain.AuthData;
import com.crc.secface.domain.AuthDept;
import com.crc.secface.domain.AuthUser;
import com.crc.secface.domain.SysDictData;
import com.crc.secface.mapper.AuthDataMapper;
import com.crc.secface.mapper.AuthDeptMapper;
import com.crc.secface.mapper.AuthUserMapper;
import com.crc.secface.mapper.CommonMapper;
import com.crc.sync.config.SyncSecConfigLoad;
import com.crc.sync.config.SyncSecConstants;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;

import java.util.Date;
import java.util.HashMap;
import java.util.List;

@Slf4j
public class BanbooSyncWork extends Thread {
    private HashMap<String, String> userMapList;
    private HashMap<String, String> deptMapList;

    public static void add(JSONObject data, String type, String op) {
        AuthData banbooData = new AuthData();
        banbooData.setOp(op);
        banbooData.setType(type);
        banbooData.setStatus("0");
        try {
            banbooData.setData(SimpleCodeTool.encryptBase64(data.toJSONString()));
            banbooData.setCreateTime(new Date());
            AuthDataMapper authDataMapper = GetSpringBean.getBean(AuthDataMapper.class);
            authDataMapper.insert(banbooData);
        } catch (Exception e) {
            log.error(e.getMessage(), e);
        }
    }

    public void run() {
        while (true) {
            MyTheadUtils.sleepBySec(10);
            try {
                if (SyncSecConfigLoad.isEnable(SyncSecConstants.ZHUYUN_SYNC_TO_STP_ENABLE)) {
                    continue;
                }
                if (BanbooLoad.getPushConfig() == null) {
                    continue;
                }
                CommonMapper commonMapper = GetSpringBean.getBean(CommonMapper.class);
                List<JSONObject> list = commonMapper.query("select * from tb_auth_data where status = '0' limit 100");
                for (JSONObject map : list) {
                    AuthData banbooData = new AuthData();
                    banbooData.setData(SimpleCodeTool.decryptBase64(DataUtils.getString(map, "data")));
                    banbooData.setType(DataUtils.getString(map, "type"));
                    banbooData.setOp(DataUtils.getString(map, "op"));
                    int ret = proc(banbooData);
                    if (ret >= 0) {
                        commonMapper.exeSQL("update tb_auth_data set status = '1' where id = " + DataUtils.getString(map, "id"));
                    }
                }
            } catch (Exception e) {
                log.error(e.getMessage(), e);
            }
            MyTheadUtils.sleepBySec(5);
        }
    }

    public int proc(AuthData banbooData) {
        if (banbooData == null || banbooData.getData() == null) {
            return 0;
        }
        JSONObject jsonObject = JsonUtils.parse(banbooData.getData());
        if (jsonObject.size() < 1) {
            return 0;
        }
        if ("user".equalsIgnoreCase(banbooData.getType())) {
            if (userMapList == null || userMapList.size() < 1) {
                if (userMapList == null) {
                    userMapList = new HashMap<>();
                }
                List<SysDictData> userList = DictUtil.getDict("zy_user_mapping");
                if (userList != null) {
                    for (SysDictData v : userList) {
                        if (v.getDictLabel() != null && v.getDictValue() != null) {
                            userMapList.put(v.getDictLabel(), v.getDictValue());
                        }
                    }
                }
            }
            if (userMapList == null || userMapList.size() < 1) {
                log.info("请配置用户映射表，字典zy_user_mapping");
            }
            AuthUserMapper authUserMapper = GetSpringBean.getBean(AuthUserMapper.class);
            AuthUser tbAuthUser = new AuthUser();
            HashMap<String, String> dataMap = new HashMap<>();
            userMapList.forEach((km, vm) -> {
                //km 自己的字段
                //vm 对方字段
                dataMap.put(km, JsonUtils.getStrByPath(jsonObject,vm));
            });
            RefectUtils.setBeanFieldValue(tbAuthUser, dataMap);
            if (StringUtils.isBlank(tbAuthUser.getEmpno())) {
                tbAuthUser.setEmpno(tbAuthUser.getUserName());
            }
            if (StringUtils.isBlank(tbAuthUser.getEmpno())) {
                log.error("用户id为空");
                return 0;
            }

            if ("3".equalsIgnoreCase(banbooData.getOp())) {//删除
                authUserMapper.deleteById(tbAuthUser.getEmpno());
            } else {//修改/增加
                tbAuthUser.setDelFlag("0");
                AuthUser tmp = authUserMapper.selectByEmpo(tbAuthUser.getEmpno());
                if (tmp != null) {
                    tbAuthUser.setUpdateTime(new Date());
                    authUserMapper.updateAuthUser(tbAuthUser);
                } else {
                    tbAuthUser.setUd2("0");
                    tbAuthUser.setUpdateTime(new Date());
                    tbAuthUser.setCreateTime(new Date());
                    authUserMapper.insert(tbAuthUser);
                }
            }
        } else if ("dept".equalsIgnoreCase(banbooData.getType())) {
            if (deptMapList == null || deptMapList.size() < 1) {
                if (deptMapList == null) {
                    deptMapList = new HashMap<>();
                }
                List<SysDictData> deptList = DictUtil.getDict("zy_dept_mapping");
                if (deptList != null) {
                    for (SysDictData v : deptList) {
                        if (v.getDictLabel() != null && v.getDictValue() != null) {
                            deptMapList.put(v.getDictLabel(), v.getDictValue());
                        }
                    }
                }
            }
            if (deptMapList == null || deptMapList.size() < 1) {
                log.info("请配置组织映射表，zy_dept_mapping");
            }
            AuthDeptMapper authDeptMapper = GetSpringBean.getBean(AuthDeptMapper.class);
            AuthDept tbAuthDept = new AuthDept();
            HashMap<String, String> dataMap = new HashMap<>();
            deptMapList.forEach((km, vm) -> {
                //km 自己的字段
                //vm 对方字段
                dataMap.put(km, JsonUtils.getStrByPath(jsonObject,vm));
            });
            RefectUtils.setBeanFieldValue(tbAuthDept, dataMap);
            if (StringUtils.isBlank(tbAuthDept.getDeptId())) {
                log.error("用户id为空");
                return 0;
            }

            if ("3".equalsIgnoreCase(banbooData.getOp())) {//删除
                authDeptMapper.deleteById(tbAuthDept.getDeptId());
            } else {//修改/增加
                tbAuthDept.setDelFlag("0");
                AuthDept tmp = authDeptMapper.selectById(tbAuthDept.getDeptId());
                if (tmp != null) {
                    tbAuthDept.setUpdateTime(new Date());
                    authDeptMapper.updateAuthDept(tbAuthDept);
                } else {
                    tbAuthDept.setUpdateTime(new Date());
                    tbAuthDept.setCreateTime(new Date());
                    tbAuthDept.setUd2("0");
                    authDeptMapper.insert(tbAuthDept);
                }
            }
        }
        return 0;
    }


}
