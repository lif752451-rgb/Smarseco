package com.crc.sync.banboo;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;
import com.crc.common.banboo.BanbooLoad;
import com.crc.common.utils.HttpUtils;
import com.crc.common.utils.JsonUtils;
import com.crc.common.utils.Md5Utils;
import com.crc.common.utils.MyTheadUtils;
import com.crc.secface.config.GetSpringBean;
import com.crc.secface.domain.AuthDept;
import com.crc.secface.domain.AuthUser;
import com.crc.secface.mapper.AuthDeptMapper;
import com.crc.secface.mapper.AuthUserMapper;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;

import java.net.URLEncoder;
import java.util.Date;

/**
 * 深圳燃气大数据对接
 */
@Slf4j
public class RqBimDataSync {

    public void sync() {
        boolean goodSync = syncData();
        log.info("@@刷大数据用户结束，开始刷数据到 STP");
        if (goodSync) {
            try {
                BanbooSyncToUserDeptWork work = new BanbooSyncToUserDeptWork();
                work.sync();
            } catch (Exception e) {
                log.error(e.getMessage(), e);
            }
        } else {
            log.info("没有新数据。");
        }
        log.info("@@刷大数据结束");
    }

    public boolean syncData() {
        long counter = 0;
        try {
            JSONObject configJson = BanbooLoad.getRqBimDataConfig();
            if (configJson != null && configJson.size() > 0) {
                String url = JsonUtils.getStr(configJson, "url");
                String systemCode = JsonUtils.getStr(configJson, "systemCode");
                String integrationKey = JsonUtils.getStr(configJson, "integrationKey");
                boolean force = configJson.getBoolean("force");

            /*
                http://10.9.7.74:8080/bim-server/integration/api.json?method=login&request=
                {
                  "systemCode" : “OA",
                  "integrationKey" : "P@ssW0rd",
                  "force" : false,
                  "timestamp" : 1458793365386
                }
             */
                JSONObject reqJson = new JSONObject();
                reqJson.put("systemCode", systemCode);
                reqJson.put("integrationKey", integrationKey);
                reqJson.put("force", force);
                reqJson.put("timestamp", System.currentTimeMillis());
                try {
                    String param = "method=login&request=" + URLEncoder.encode(reqJson.toJSONString(), "UTF-8");

                    String loginRet = HttpUtils.sendPostSession(url + "/bim-server/integration/api.json", param);
                    //log.info("ret={}", loginRet);
                    JSONObject loginRetJson = JsonUtils.parse(loginRet);
                    String tokenId = JsonUtils.getStr(loginRetJson, "tokenId");
                    if (StringUtils.isBlank(tokenId)) {
                        log.error("login 失败！{}", loginRet);
                        return false;
                    }
                    log.info("login成功：{}", tokenId);
                /*
                    http://10.9.7.74:8080/bim-server/integration/api.json?method=pullTask&request=
                    {
                      "tokenId" : "497a567f-e8af-41b4-b63c-3668a7ffbfe8",
                      "timestamp" : 1515339925636
                    }
                 */
                    reqJson = new JSONObject();
                    reqJson.put("tokenId", tokenId);
                    reqJson.put("timestamp", System.currentTimeMillis());
                    param = "method=pullTask&request=" + URLEncoder.encode(reqJson.toJSONString(), "UTF-8");
                    String pullTaskRet = HttpUtils.sendPostSession(url + "/bim-server/integration/api.json", param);
                    JSONObject pullTaskRetJson = JsonUtils.parse(pullTaskRet);
                    log.info("pullTask Ret:{}", pullTaskRet);
                    while (pullTaskRetJson != null && pullTaskRetJson.size() > 0) {
                        try {
                            String objectType = JsonUtils.getStr(pullTaskRetJson, "objectType");
                            String taskId = JsonUtils.getStr(pullTaskRetJson, "taskId");
                            String effectOn = JsonUtils.getStr(pullTaskRetJson, "effectOn");
                            String guid = JsonUtils.getStr(pullTaskRetJson, "guid");
                            boolean success = pullTaskRetJson.getBoolean("success");
                            if (success) {
                                JSONObject data = pullTaskRetJson.getJSONObject("data");
                                if ("TARGET_ACCOUNT".equalsIgnoreCase(objectType)) {
                                    String userId = syncUser(data, effectOn);
                                    if (StringUtils.isNotBlank(userId)) {
                                        guid = userId;
                                    }
                                    counter++;
                                } else if ("TARGET_ORGANIZATION".equalsIgnoreCase(objectType)) {
                                    String orgId = syncOffice(data, effectOn);
                                    if (StringUtils.isNotBlank(orgId)) {
                                        guid = orgId;
                                    }
                                    counter++;
                                } else {
                                    log.error("未知类型：{}", objectType);
                                }
                            } else {
                                log.error("拉数据失败:{}", pullTaskRet);
                                break;
                            }


                        /*
                    http://10.9.7.74:8080/bim-server/integration/api.json?method=pullFinish&request=
                        {
                          "tokenId" : "497a567f-e8af-41b4-b63c-3668a7ffbfe8",
                          "taskId" : "20180314094906454-DC3E-701858766",
                          "success" : true,
                          "guid" : " 827",
                          "timestamp" : 1515340105
                        }
                     */
                            reqJson = new JSONObject();
                            reqJson.put("tokenId", tokenId);
                            reqJson.put("taskId", taskId);
                            reqJson.put("guid", guid);
                            reqJson.put("success", success);
                            reqJson.put("timestamp", System.currentTimeMillis());
                            param = "method=pullFinish&request=" + URLEncoder.encode(reqJson.toJSONString(), "UTF-8");
                            String pullFinishRet = HttpUtils.sendPostSession(url + "/bim-server/integration/api.json", param);//反馈下拉数据完成
                            JSONObject pullFinishRetJson = JsonUtils.parse(pullFinishRet);
                            boolean flag = false;
                            if (pullFinishRetJson != null) {
                                success = pullFinishRetJson.getBoolean("success");
                                if (success) {
                                    flag = true;
                                }
                            }
                            if (!flag) {
                                log.error("下拉完成失败:{}", pullFinishRet);
                            }
                            reqJson = new JSONObject();
                            reqJson.put("tokenId", tokenId);
                            reqJson.put("timestamp", System.currentTimeMillis());
                            param = "method=pullTask&request=" + URLEncoder.encode(reqJson.toJSONString(), "UTF-8");
                            pullTaskRet = HttpUtils.sendPostSession(url + "/bim-server/integration/api.json", param);
                            pullTaskRetJson = JsonUtils.parse(pullTaskRet);
                            log.info("pullTask Ret:{}", pullTaskRet);
                        } catch (Exception e) {
                            log.error(e.getMessage(), e);
                        }

                        MyTheadUtils.sleep(10);
                    }
                    log.info("pullTask Ret done");

                /*
                http://10.9.7.74:8080/bim-server/integration/api.json?method=logout&request=
                {
                  "tokenId" : "a452c8a3-fa18-4b20-94c9-2e9cc626483b",
                  "timestamp" : 1515339070
                }
                 */
                    reqJson = new JSONObject();
                    reqJson.put("tokenId", tokenId);
                    reqJson.put("timestamp", System.currentTimeMillis());
                    param = "method=logout&request=" + URLEncoder.encode(reqJson.toJSONString(), "UTF-8");
                    String logoutRet = HttpUtils.sendPostSession(url + "/bim-server/integration/api.json", param);
                    log.info("logout={}", logoutRet);
                } catch (Exception e) {
                    log.error(e.getMessage(), e);
                }
            }
        } catch (Exception e) {
            log.error(e.getMessage(), e);
        }
        return counter > 0;
    }

    public String syncUser(JSONObject jsonObject, String effectOn) {
        String guid = "";
        try {
            AuthUser tbAuthUser = new AuthUser();
            tbAuthUser.setUd2("BIM");
            if (jsonObject.containsKey("username")) {
                tbAuthUser.setUserName(JsonUtils.getStr(jsonObject, "username"));
            } else {
                log.error("用户OA_ACCOUNT为空=" + JSON.toJSONString(jsonObject));
                return guid;
            }
            if (jsonObject.containsKey("fullname")) {
                tbAuthUser.setDisplayName(JsonUtils.getStr(jsonObject, "fullname"));
            }
            if (jsonObject.containsKey("guid")) {
                tbAuthUser.setEmpno(JsonUtils.getStr(jsonObject, "guid"));
            }
            if (jsonObject.containsKey("email")) {
                tbAuthUser.setUserMail(JsonUtils.getStr(jsonObject, "email"));
            }
            if (jsonObject.containsKey("mobile")) {
                tbAuthUser.setUserMobile(JsonUtils.getStr(jsonObject, "mobile"));
            }
            if (jsonObject.containsKey("_organization")) {
                tbAuthUser.setDeptId(JsonUtils.getStr(jsonObject, "_organization"));
            }
            if (StringUtils.isBlank(tbAuthUser.getEmpno())) {
                tbAuthUser.setEmpno(tbAuthUser.getUserName());
            }
            if (StringUtils.isBlank(tbAuthUser.getDisplayName())) {
                tbAuthUser.setDisplayName(tbAuthUser.getUserName());
            }
            if (StringUtils.isBlank(tbAuthUser.getUserName())) {
                tbAuthUser.setUserName(tbAuthUser.getEmpno());
            }

            if (StringUtils.isBlank(tbAuthUser.getEmpno())) {
                log.error("用户id为空=" + JSON.toJSONString(jsonObject));
                return "";
            }
            if (StringUtils.isBlank(tbAuthUser.getDeptId())) {
                log.error("部门id为空=" + JSON.toJSONString(jsonObject));
                return "";
            }
            AuthUserMapper authUserMapper = GetSpringBean.getBean(AuthUserMapper.class);
            //A/I 对于 A:有效 I:无效
            Boolean isDisabled = jsonObject.getBoolean("isDisabled");
            Boolean isLocked = jsonObject.getBoolean("isLocked");
            if ((effectOn != null && effectOn.toLowerCase().contains("delete")) || (isDisabled != null && isDisabled) || (isLocked != null && isLocked)) {
                authUserMapper.deleteTbAuthUserByEmpno(tbAuthUser.getEmpno());
                authUserMapper.deleteUser(tbAuthUser.getEmpno());
                guid = Md5Utils.hash(tbAuthUser.getUserName());
            } else {//修改/增加
                tbAuthUser.setDelFlag("0");
                guid = Md5Utils.hash(tbAuthUser.getUserName());
                String deptId = Md5Utils.hash(tbAuthUser.getDeptId());
                tbAuthUser.setDeptId(deptId);
                tbAuthUser.setUd2(guid);
                AuthUser tmp = authUserMapper.selectByEmpo(tbAuthUser.getEmpno());
                if (tmp != null) {
                    tbAuthUser.setUpdateTime(new Date());
                    authUserMapper.updateAuthUser(tbAuthUser);
                } else {
                    tbAuthUser.setUpdateTime(new Date());
                    tbAuthUser.setCreateTime(new Date());
                    authUserMapper.insert(tbAuthUser);
                }
            }
        } catch (Exception e) {
            log.error(e.getMessage(), e);
        }
        return guid;
    }

    public String syncOffice(JSONObject jsonObject, String effectOn) {
        String guid = "";
        try {
            AuthDeptMapper authDeptMapper = GetSpringBean.getBean(AuthDeptMapper.class);
            AuthDept tbAuthDept = new AuthDept();
            tbAuthDept.setUd2("BIM");
            if (jsonObject.containsKey("guid")) {
                tbAuthDept.setDeptId(JsonUtils.getStr(jsonObject, "guid"));
            }
            if (jsonObject.containsKey("_organization") && StringUtils.isBlank(tbAuthDept.getDeptId())) {
                tbAuthDept.setDeptId(JsonUtils.getStr(jsonObject, "_organization"));
            }
            if (jsonObject.containsKey("name")) {
                tbAuthDept.setDeptName(JsonUtils.getStr(jsonObject, "name"));
            }
            if (jsonObject.containsKey("parentId")) {
                tbAuthDept.setDeptParentId(JsonUtils.getStr(jsonObject, "parentId"));
            }
            if (jsonObject.containsKey("_parent")) {
                tbAuthDept.setDeptParentId(JsonUtils.getStr(jsonObject, "_parent"));
            }
            tbAuthDept.setDeptFullName(JsonUtils.getStr(jsonObject, "fullname"));
            tbAuthDept.setUd1(JsonUtils.getStr(jsonObject, "DEL_FLAG"));

            if (StringUtils.isBlank(tbAuthDept.getDeptId())) {
                log.error("部门id为空=" + JSON.toJSONString(jsonObject));
                return "";
            }
            boolean isDisabled = jsonObject.getBoolean("isDisabled");
            if ((effectOn != null && effectOn.toLowerCase().contains("delete")) || isDisabled) {
                AuthDept tmp = authDeptMapper.selectTbAuthDeptByDeptId(tbAuthDept.getDeptId());
                if (tmp != null && tmp.getRefDeptId() != null) {
                    authDeptMapper.deleteSysDept(tmp.getRefDeptId());
                }
                guid = Md5Utils.hash(tbAuthDept.getDeptId());
                authDeptMapper.deleteDeptById(tbAuthDept.getDeptId());
            } else {//修改/增加
                tbAuthDept.setDelFlag("0");
                guid = Md5Utils.hash(tbAuthDept.getDeptId());
                tbAuthDept.setUd2(guid);
                tbAuthDept.setDeptId(guid);
                AuthDept tmp = authDeptMapper.selectTbAuthDeptByDeptId(tbAuthDept.getDeptId());
                if (tmp != null) {
                    tbAuthDept.setUpdateTime(new Date());
                    authDeptMapper.updateAuthDept(tbAuthDept);
                } else {
                    tbAuthDept.setUpdateTime(new Date());
                    tbAuthDept.setCreateTime(new Date());
                    authDeptMapper.insert(tbAuthDept);
                }
            }
        } catch (Exception e) {
            log.error(e.getMessage(), e);
        }
        return guid;
    }
}
