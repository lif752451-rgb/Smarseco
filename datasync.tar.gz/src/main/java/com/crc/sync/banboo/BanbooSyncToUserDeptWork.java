package com.crc.sync.banboo;

import com.baomidou.mybatisplus.core.conditions.query.LambdaQueryWrapper;
import com.baomidou.mybatisplus.core.toolkit.Wrappers;
import com.crc.common.utils.DataUtils;
import com.crc.common.utils.DictUtil;
import com.crc.common.utils.MyTheadUtils;
import com.crc.common.utils.SecurityUtils;
import com.crc.secface.config.GetSpringBean;
import com.crc.secface.domain.AuthDept;
import com.crc.secface.domain.AuthUser;
import com.crc.secface.domain.SysDept;
import com.crc.secface.domain.SysDictData;
import com.crc.secface.domain.SysRole;
import com.crc.secface.domain.SysUser;
import com.crc.secface.domain.SysUserRole;
import com.crc.secface.domain.SysUserRoleDept;
import com.crc.secface.mapper.AuthDeptMapper;
import com.crc.secface.mapper.AuthUserMapper;
import com.crc.secface.mapper.SysDeptMapper;
import com.crc.secface.mapper.SysRoleMapper;
import com.crc.secface.mapper.SysUserMapper;
import com.crc.secface.mapper.SysUserRoleDeptMapper;
import com.crc.secface.mapper.SysUserRoleMapper;
import com.crc.sync.config.SyncSecConfigLoad;
import com.crc.sync.config.SyncSecConstants;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.collections4.CollectionUtils;
import org.apache.commons.lang3.StringUtils;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;


/**
 * 竹云用户同步到正式表
 */
@Slf4j
public class BanbooSyncToUserDeptWork {
    long deptInsertCount;
    long deptUpdateCount;
    long userInsertCount;
    long userUpdateCount;

    public void sync() {
        MyTheadUtils.sleepBySec(3);
        if (SyncSecConfigLoad.isEnable(SyncSecConstants.ZHUYUN_SYNC_TO_STP_ENABLE)) {
            try {
                log.info("@@开始同步刷新大数据数据");
                deptInsertCount = 0;
                deptUpdateCount = 0;
                userInsertCount = 0;
                userUpdateCount = 0;
                try {
                    syncDept();
                } catch (Exception e) {
                    log.error(e.getMessage(), e);
                }
                log.info("@@@ZY同步组织数量：new={},update={}", deptInsertCount, deptUpdateCount);
                try {
                    syncUser();
                } catch (Exception e) {
                    log.error(e.getMessage(), e);
                }
                log.info("@@@ZY同步用户数量：new={},update={}", userInsertCount, userUpdateCount);
            } catch (Exception e) {
                log.error(e.getMessage(), e);
            }
        }
    }

    private void syncUser() {
        AuthUserMapper tbAuthUserMapper = GetSpringBean.getBean(AuthUserMapper.class);
        SysRoleMapper sysRoleMapper = GetSpringBean.getBean(SysRoleMapper.class);
        SysUserMapper sysUserMapper = GetSpringBean.getBean(SysUserMapper.class);
        SysDeptMapper sysDeptMapper = GetSpringBean.getBean(SysDeptMapper.class);
        AuthDeptMapper authDeptMapper = GetSpringBean.getBean(AuthDeptMapper.class);
        LambdaQueryWrapper<SysRole> qs = Wrappers.lambdaQuery();
        qs.eq(SysRole::getRoleKey, "common");
        List<SysRole> roleList = sysRoleMapper.selectList(qs);
        List<SysUserRole> sysUserRoles = new ArrayList<>();
        for (SysRole sr : roleList) {
            SysUserRole sysUserRole = new SysUserRole();
            sysUserRole.setRoleId(sr.getRoleId());
            sysUserRole.setDataScope(sr.getDataScope());
            sysUserRoles.add(sysUserRole);
        }
        long defualDeptId = 0;
        SysDictData userRootDict = DictUtil.getDictByValue("zy_auth_config", "save_to_user_root_id");
        if (DataUtils.isBlankDict(userRootDict) || StringUtils.isBlank(userRootDict.getRemark())) {
            log.error("挂靠正式组织表根节点,即竹云组织挂靠的组织ID,zy_auth_config/save_to_user_root_id");
        } else {
            String saveRootId = userRootDict.getRemark().split("#")[0];
            long userRootId = DataUtils.toLong(saveRootId);
            if (userRootId > 100) {
                defualDeptId = userRootId;
            } else {
                defualDeptId = 100;
            }
        }
        String defaultPassword = SecurityUtils.encryptPassword(DictUtil.selectDictValueOrDefault("default_password", "default_pass", "admin123"));
        LambdaQueryWrapper<AuthUser> qu = Wrappers.lambdaQuery();
        long total = tbAuthUserMapper.selectCount(qu);
        int pageSize = 1000;
        for (int i = 0; i < (int) (total / pageSize) + 1; i++) {
            AuthUser q = new AuthUser();
            q.setOffset(i * pageSize);
            q.setPageSize(pageSize);
            List<AuthUser> list = tbAuthUserMapper.selectTbUserByOffset(q);
            for (AuthUser authUser : list) {
                try {
                    //无效账户
                    if ("I".equalsIgnoreCase(authUser.getUd1())) {
                        continue;
                    }
                    if (StringUtils.isBlank(authUser.getUserName()) || "null".equalsIgnoreCase(authUser.getUserName())) {
                        continue;
                    }
                    if (!StringUtils.isBlank(authUser.getDeptId())) {
                        long userRootId = DataUtils.toLong(authUser.getDeptId());
                        if (userRootId > 100) {
                            defualDeptId = userRootId;
                        } else {
                            defualDeptId = 100;
                        }
                    }
                    if (StringUtils.isBlank(authUser.getDeptId())) {
                        authUser.setDeptId(String.valueOf(defualDeptId));
                    }
                    List<AuthDept> deptList = authDeptMapper.selectTbAuthDeptByUserDeptId(authUser.getDeptId());
                    AuthDept dept = null;
                    if (CollectionUtils.isNotEmpty(deptList)) {
                        if (deptList.size() == 1) {
                            dept = deptList.get(0);
                        } else {
                            dept = deptList.get(0);
                            log.info("syncUser 用户：{}关联组织异常,组织数据为：{}", authUser, deptList);
                        }
                    }
                    if (dept == null || dept.getRefDeptId() == null || dept.getRefDeptId() < 1) {
                        SysDept tmp = sysDeptMapper.selectByDeptId(defualDeptId);
                        if (tmp != null) {
                            dept = new AuthDept();
                            dept.setRefDeptId(defualDeptId);
                            dept.setDeptName(tmp.getDeptName());
                        } else {
                            log.warn("用户{}关联组织未入库={}", authUser.getUserName(), authUser.getDeptId());
                            continue;
                        }
                    }

                    SysUser user = new SysUser();
                    user.setUserName(authUser.getUserName());
                    if (StringUtils.isBlank(user.getUserName())) {
                        user.setUserName(authUser.getEmpno());
                    }
                    user.setNickName(authUser.getDisplayName());
                    user.setDelFlag(authUser.getDelFlag());
                    user.setStatus("0");
                    SysUser tmp = sysUserMapper.selectUserByUserName(authUser.getUserName());
                    if (tmp == null) {//新增用户
                        if (StringUtils.isNotEmpty(user.getUserName())) {
                            user.setUserName(user.getUserName().toLowerCase());
                        }
                        user.setLdap(1L);
                        if (StringUtils.isEmpty(user.getPassword())) {
                            user.setPassword(user.getLdap() == 1L ? defaultPassword : SecurityUtils.encryptPassword(user.getPassword()));
                        }
                        user.setDeptId(dept.getRefDeptId());
                        //user.setDeptName(deptName);
                        SysDept sysDept = new SysDept();
                        sysDept.setDeptId(dept.getRefDeptId());
                        sysDept.setDeptName(dept.getDeptName());
                        user.setDept(sysDept);

                        if (user.getStatus() == null) {
                            user.setStatus("0");
                        }
                        user.setEmail(authUser.getUserMail());
                        user.setPhonenumber(authUser.getUserMobile());
                        user.setUserRoles(sysUserRoles);
                        user.setRemark("BIM");
                        user.setCreateTime(new Date());
                        insertUser(user);
                    } else {
                        //已经存在
                        if (user.getStatus() == null) {
                            user.setStatus("0");
                        }
                        tmp.setStatus(user.getStatus());
                        tmp.setDeptId(dept.getRefDeptId());
                        SysDept sysDept = new SysDept();
                        sysDept.setDeptId(dept.getRefDeptId());
                        sysDept.setDeptName(dept.getDeptName());
                        tmp.setDept(sysDept);
                        tmp.setLdap(1L);
                        tmp.setDelFlag(authUser.getDelFlag());
                        tmp.setRemark("BIM");
                        userUpdateCount++;
                        tmp.setEmail(authUser.getUserMail());
                        tmp.setPhonenumber(authUser.getUserMobile());
                        tmp.setUpdateTime(new Date());
                        sysUserMapper.updateById(tmp);
                    }
                } catch (Exception e) {
                    log.error(e.getMessage(), e);
                }
            }
        }
    }

    private void insertUser(SysUser user) {
        if (StringUtils.isBlank(user.getUserName()) || "null".equalsIgnoreCase(user.getUserName())) {
            return;
        }
        // 新增用户信息
        SysUserMapper sysUserMapper = GetSpringBean.getBean(SysUserMapper.class);
        SysUserRoleMapper userRoleMapper = GetSpringBean.getBean(SysUserRoleMapper.class);
        SysUserRoleDeptMapper userRoleDeptMapper = GetSpringBean.getBean(SysUserRoleDeptMapper.class);
        if (StringUtils.isBlank(user.getNickName())) {
            user.setNickName(user.getUserName());
        }
        sysUserMapper.insert(user);
        log.info("新增用户:{}", user.getUserName());
        userInsertCount++;
        // 新增用户与角色管理
        List<SysUserRole> roles = user.getUserRoles();
        List<SysUserRole> newRoles = new ArrayList<>();
        if (roles != null && !roles.isEmpty()) {
            roles.forEach(role -> {
                role.setUserId(user.getUserId());
                role.setStatus(0);
                if (userRoleMapper.existUserRole(role) < 1) {
                    newRoles.add(role);
                }
            });
            if (!newRoles.isEmpty()) {
                userRoleMapper.batchUserRole(newRoles);
            }
            newRoles.forEach(sysUserRole -> {
                String dataScope = sysUserRole.getDataScope();
                if ("2".equals(dataScope)) {
                    List<Long> deptIds = sysUserRole.getDeptIds();
                    if (deptIds != null && !deptIds.isEmpty()) {
                        List<SysUserRoleDept> sysUserRoleDeptList = new ArrayList<>();
                        deptIds.forEach(deptId -> {
                            SysUserRoleDept sysUserRoleDept = new SysUserRoleDept();
                            sysUserRoleDept.setDeptId(deptId);
                            sysUserRoleDept.setRoleId(sysUserRole.getRoleId());
                            sysUserRoleDept.setUserId(sysUserRole.getUserId());
                            sysUserRoleDeptList.add(sysUserRoleDept);
                        });
                        if (!sysUserRoleDeptList.isEmpty()) {
                            userRoleDeptMapper.batchRoleDept(sysUserRoleDeptList);
                        }
                    }
                }
            });
        }
    }

    private void syncDept() {
        SysDictData pushRootDict = DictUtil.getDictByValue("zy_auth_config", "push_dept_root_id");
        if (DataUtils.isBlankDict(pushRootDict) || StringUtils.isBlank(pushRootDict.getRemark())) {
            log.error("接收推送的根节点,即竹云选择的组织树根节点,zy_auth_config/push_dept_root_id");
            return;
        }

        AuthDeptMapper authDeptMapper = GetSpringBean.getBean(AuthDeptMapper.class);

        List<AuthDept> rootList = authDeptMapper.getRootList();

        SysDictData userRootDict = DictUtil.getDictByValue("zy_auth_config", "save_to_user_root_id");
        if (DataUtils.isBlankDict(userRootDict) || StringUtils.isBlank(userRootDict.getRemark())) {
            log.error("挂靠正式组织表根节点,即竹云组织挂靠的组织ID,zy_auth_config/save_to_user_root_id");
            return;
        }
        String saveRootId = userRootDict.getRemark().split("#")[0];
        long userRootId = DataUtils.toLong(saveRootId);

        int index = 1;
        for (AuthDept rootNode : rootList) {
            String rootId = rootNode.getDeptId();
            if (StringUtils.isBlank(rootNode.getDeptName()) || "null".equalsIgnoreCase(rootNode.getDeptName())) {
                continue;
            }
            log.info("@@开始刷根节点 root={},name={}", rootId, rootNode.getDeptName());
            if (StringUtils.isBlank(rootId) && userRootId > 0) {
                log.error("挂靠正式组织表根节点,即竹云组织挂靠的组织ID,zy_auth_config/save_to_user_root_id");
                return;
            }
            try {
                iterDeptPath(rootNode, userRootId, index++);
            } catch (Exception e) {
                log.error(e.getMessage(), e);
            }
        }
    }

    /**
     * 迭代遍历组织
     *
     * @param rootNode   竹云根ID
     * @param saveRootId 平台根ID
     */
    public void iterDeptPath(AuthDept rootNode, long saveRootId, int orderNum) {
        AuthDeptMapper authDeptMapper = GetSpringBean.getBean(AuthDeptMapper.class);
        SysDeptMapper deptMapper = GetSpringBean.getBean(SysDeptMapper.class);
        try {
            if (StringUtils.isBlank(rootNode.getDeptName()) || "null".equalsIgnoreCase(rootNode.getDeptName())) {
                return;
            }
            //被删除了
            if ("Y".equalsIgnoreCase(rootNode.getUd1())) {
                return;
            }
            //支持多个根节点
            SysDept rootTmp = deptMapper.checkDeptNameUnique(rootNode.getDeptName(), saveRootId);
            if (rootTmp == null) {
                SysDept dept = new SysDept();
                dept.setDeptName(rootNode.getDeptName());
                dept.setParentId(saveRootId);
                dept.setDelFlag(rootNode.getDelFlag());
                dept.setOrderNum(orderNum);
                if ("1".equals(rootNode.getDelFlag())) {
                    dept.setStatus(rootNode.getDelFlag());
                } else {
                    dept.setStatus("0");
                }
                dept.setUpdateTime(new Date());
                SysDept info = deptMapper.selectByDeptId(dept.getParentId());
                if (info != null) {
                    dept.setEmail("BIM");
                    dept.setAncestors(info.getAncestors() + "," + dept.getParentId());
                    dept.setSource(1);
                    dept.setCreateTime(new Date());
                    dept.setTag("风险,告警");
                    deptMapper.insert(dept);
                    deptInsertCount++;
                    SysDept tmp = deptMapper.checkDeptNameUnique(dept.getDeptName(), dept.getParentId());
                    if (tmp != null) {
                        dept.setDeptId(tmp.getDeptId());
                        //更新关联ID
                        rootNode.setRefDeptId(tmp.getDeptId());
                        authDeptMapper.updateAuthDept(rootNode);
                        saveRootId = tmp.getDeptId();
                    }
                    if (StringUtils.isBlank(rootNode.getDeptFullName())) {
                        rootNode.setDeptFullName(rootNode.getDeptName());
                    }
                    log.info("@@新增组织：{},saveRoot={},insert={}", rootNode.getDeptFullName(), saveRootId, deptInsertCount);
                }
            } else {
                saveRootId = rootTmp.getDeptId();
                rootTmp.setOrderNum(orderNum);
                if ("1".equals(rootNode.getDelFlag())) {
                    rootTmp.setStatus(rootNode.getDelFlag());
                } else {
                    rootTmp.setStatus("0");
                    rootTmp.setDelFlag("0");
                }
                rootNode.setRefDeptId(rootTmp.getDeptId());
                authDeptMapper.updateAuthDept(rootNode);
                rootTmp.setUpdateTime(new Date());
                rootTmp.setEmail("BIM");
                rootTmp.setSource(1);
                rootTmp.setTag("风险,告警");
                deptUpdateCount++;
                deptMapper.updateById(rootTmp);
                log.info("@@已存在组织：{},saveRoot={},update={}", rootTmp.getDeptName(), saveRootId, deptUpdateCount);
            }
        } catch (Exception e) {
            log.error(e.getMessage(), e);
        }
        //遍历下一个叶子节点
        int newIndex = 1;
        try {
            List<AuthDept> rootDeptList = authDeptMapper.selectTbAuthDeptByParentDeptId(rootNode.getDeptId());
            if (rootDeptList == null || rootDeptList.isEmpty()) {
                return;
            }
            for (AuthDept depart : rootDeptList) {
                iterDeptPath(depart, saveRootId, newIndex++);
            }
        } catch (Exception e) {
            log.error(e.getMessage(), e);
        }
    }
}
