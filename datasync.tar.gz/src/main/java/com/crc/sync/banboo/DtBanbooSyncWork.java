package com.crc.sync.banboo;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;
import com.crc.common.banboo.BanbooLoad;
import com.crc.common.code.SimpleCodeTool;
import com.crc.common.constants.BanbooAuthConstants;
import com.crc.common.utils.DataUtils;
import com.crc.common.utils.DictUtil;
import com.crc.common.utils.JsonUtils;
import com.crc.common.utils.MyTheadUtils;
import com.crc.secface.config.GetSpringBean;
import com.crc.secface.domain.AuthData;
import com.crc.secface.domain.AuthDept;
import com.crc.secface.domain.AuthUser;
import com.crc.secface.domain.SysDictData;
import com.crc.secface.mapper.AuthDataMapper;
import com.crc.secface.mapper.AuthDeptMapper;
import com.crc.secface.mapper.AuthUserMapper;
import com.crc.secface.mapper.CommonMapper;
import com.crc.sync.config.SyncSecConfigLoad;
import com.crc.sync.config.SyncSecConstants;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;

import java.util.Date;
import java.util.List;

/**
 * 深圳地铁定制版本
 */
@Slf4j
public class DtBanbooSyncWork extends Thread {
    public static void add(JSONObject data, String type, String op) {
        AuthData banbooData = new AuthData();
        banbooData.setOp(op);
        banbooData.setType(type);
        banbooData.setStatus("0");
        try {
            banbooData.setData(SimpleCodeTool.encryptBase64(data.toJSONString()));
            banbooData.setCreateTime(new Date());
            AuthDataMapper authDataMapper = GetSpringBean.getBean(AuthDataMapper.class);
            authDataMapper.insert(banbooData);
        } catch (Exception e) {
            log.error(e.getMessage(), e);
        }
    }

    public void run() {
        log.info("DtBanbooSyncWork start....");
        while (true) {
            MyTheadUtils.sleepBySec(10);
            try {
                if (SyncSecConfigLoad.isEnable(SyncSecConstants.ZHUYUN_SYNC_TO_STP_ENABLE)) {
                    continue;
                }
                if (BanbooLoad.getPushConfig() == null) {
                    continue;
                }
                CommonMapper commonMapper = GetSpringBean.getBean(CommonMapper.class);
                SysDictData dataMapping = DictUtil.getDictByValue("zy_auth_config", "data_mapping");
                List<JSONObject> list = commonMapper.query("select * from tb_auth_data where status = '0' order by id asc limit 500");
                log.info("DtBanbooSyncWork 带解析数据=" + list.size());
                for (JSONObject map : list) {
                    AuthData banbooData = new AuthData();
                    banbooData.setData(SimpleCodeTool.decryptBase64(DataUtils.getString(map, "data")));
                    banbooData.setType(DataUtils.getString(map, "type"));
                    banbooData.setOp(DataUtils.getString(map, "op"));
                    int ret = procDT(banbooData, dataMapping);
                    if (ret >= 0) {
                        commonMapper.exeSQL("update tb_auth_data set status = '1' where id = " + DataUtils.getString(map, "id"));
                    }
                }
            } catch (Exception e) {
                log.error(e.getMessage(), e);
            }
            MyTheadUtils.sleepBySec(5);
        }

    }

    /**
     * 地铁定制
     */
    private int procDT(AuthData banbooData, SysDictData dataMapping) {
        if (banbooData == null || banbooData.getData() == null) {
            return 0;
        }
        JSONObject jsonObject = JsonUtils.parse(banbooData.getData());
        if (jsonObject.size() < 1) {
            return 0;
        }
        if ("user".equalsIgnoreCase(banbooData.getType())) {
            AuthUserMapper authUserMapper = GetSpringBean.getBean(AuthUserMapper.class);
            AuthUser tbAuthUser = new AuthUser();
            if (jsonObject.containsKey("uid")) {
                tbAuthUser.setUserName(JsonUtils.getStr(jsonObject, "uid"));
            }
            if (jsonObject.containsKey("bimUid")) {
                tbAuthUser.setUserName(JsonUtils.getStr(jsonObject, "bimUid"));
            }
            //loginName/ fullName /bimUid
            if (jsonObject.containsKey("loginName")) {
                tbAuthUser.setUserName(JsonUtils.getStr(jsonObject, "loginName"));
            }
            if (jsonObject.containsKey("fullName")) {
                tbAuthUser.setDisplayName(JsonUtils.getStr(jsonObject, "fullName"));
            }
            if (jsonObject.containsKey("user_id")) {
                tbAuthUser.setEmpno(JsonUtils.getStr(jsonObject, "user_id"));
            }
            if (jsonObject.containsKey("__NAME__")) {
                tbAuthUser.setUserName(JsonUtils.getStr(jsonObject, "__NAME__"));
            }
            if (jsonObject.containsKey("true_name")) {
                tbAuthUser.setDisplayName(JsonUtils.getStr(jsonObject, "true_name"));
            }
            if (jsonObject.containsKey("email")) {
                tbAuthUser.setUserMail(JsonUtils.getStr(jsonObject, "email"));
            }
            if (jsonObject.containsKey("mobile_number")) {
                tbAuthUser.setUserMobile(JsonUtils.getStr(jsonObject, "mobile_number"));
            }
            if (jsonObject.containsKey("org_unit_id")) {
                tbAuthUser.setDeptId(JsonUtils.getStr(jsonObject, "org_unit_id"));
            }
            if (StringUtils.isBlank(tbAuthUser.getEmpno())) {
                tbAuthUser.setEmpno(tbAuthUser.getUserName());
            }
            if (StringUtils.isBlank(tbAuthUser.getDisplayName())) {
                tbAuthUser.setDisplayName(tbAuthUser.getUserName());
            }
            if (StringUtils.isBlank(tbAuthUser.getUserName())) {
                tbAuthUser.setUserName(tbAuthUser.getEmpno());
            }

            /*
               "user":{}
             */
            if (dataMapping != null && StringUtils.isNotBlank(dataMapping.getRemark())) {
                JSONObject dmJson = JsonUtils.parse(dataMapping.getRemark());
                if (dmJson != null && dmJson.size() > 0) {
                    if (dmJson.containsKey("user")) {
                        JSONObject userJson = dmJson.getJSONObject("user");
                        String userId = JsonUtils.getStrByPath(jsonObject, JsonUtils.getStr(userJson, BanbooAuthConstants.USER_Id));
                        if (StringUtils.isNotBlank(userId)) {
                            tbAuthUser.setEmpno(userId);
                        }
                        String username = JsonUtils.getStrByPath(jsonObject, JsonUtils.getStr(userJson, BanbooAuthConstants.USER_NAME));
                        if (StringUtils.isNotBlank(username)) {
                            tbAuthUser.setUserName(username);
                        }

                        String cnName = JsonUtils.getStrByPath(jsonObject, JsonUtils.getStr(userJson, BanbooAuthConstants.USER_CN_NAME));
                        if (StringUtils.isNotBlank(cnName)) {
                            tbAuthUser.setDisplayName(cnName);
                        }
                        String userMail = JsonUtils.getStrByPath(jsonObject, JsonUtils.getStr(userJson, BanbooAuthConstants.USER_MAIL));
                        if (StringUtils.isNotBlank(userMail)) {
                            tbAuthUser.setUserMail(userMail);
                        }

                        String userPhone = JsonUtils.getStrByPath(jsonObject, JsonUtils.getStr(userJson, BanbooAuthConstants.USER_PHONE));
                        if (StringUtils.isNotBlank(userPhone)) {
                            tbAuthUser.setUserMobile(userPhone);
                        }
                        String deptId = JsonUtils.getStrByPath(jsonObject, JsonUtils.getStr(userJson, BanbooAuthConstants.DEPT_ID));
                        if (StringUtils.isNotBlank(deptId)) {
                            tbAuthUser.setDeptId(deptId);
                        }
                    }
                }
            }


            if (StringUtils.isBlank(tbAuthUser.getEmpno())) {
                log.error("用户id为空=" + JSON.toJSONString(tbAuthUser));
                return 0;
            }

            if ("3".equalsIgnoreCase(banbooData.getOp())) {//删除
                authUserMapper.deleteTbAuthUserByEmpno(tbAuthUser.getEmpno());
                authUserMapper.deleteUser(tbAuthUser.getEmpno());
            } else {//修改/增加
                tbAuthUser.setDelFlag("0");
                AuthUser tmp = authUserMapper.selectByEmpo(tbAuthUser.getEmpno());
                if (tmp != null) {
                    tbAuthUser.setUpdateTime(new Date());
                    authUserMapper.updateAuthUser(tbAuthUser);
                } else {
                    if ("1".equalsIgnoreCase(banbooData.getOp())) {
                        tbAuthUser.setUpdateTime(new Date());
                        tbAuthUser.setCreateTime(new Date());
                        tbAuthUser.setUd2("0");
                        authUserMapper.insert(tbAuthUser);
                    }else {
                        log.error("修改操作，却找不到数据，改新增操作：" + tbAuthUser.getEmpno());
                        tbAuthUser.setUpdateTime(new Date());
                        tbAuthUser.setCreateTime(new Date());
                        tbAuthUser.setUd2("0");
                        authUserMapper.insert(tbAuthUser);
                    }
                }
            }
        } else if ("dept".equalsIgnoreCase(banbooData.getType())) {
            AuthDeptMapper authDeptMapper = GetSpringBean.getBean(AuthDeptMapper.class);
            AuthDept tbAuthDept = new AuthDept();

            if (jsonObject.containsKey("orgId")) {
                tbAuthDept.setDeptId(JsonUtils.getStr(jsonObject, "orgId"));
            }
            if (jsonObject.containsKey("org_unit_id")) {
                tbAuthDept.setDeptId(JsonUtils.getStr(jsonObject, "org_unit_id"));
            }
            if (jsonObject.containsKey("bimOrgId")) {
                tbAuthDept.setDeptId(JsonUtils.getStr(jsonObject, "bimOrgId"));
            }
            if (jsonObject.containsKey("org_unit_name")) {
                tbAuthDept.setDeptName(JsonUtils.getStr(jsonObject, "org_unit_name"));
            }
            if (jsonObject.containsKey("orgName")) {
                tbAuthDept.setDeptName(JsonUtils.getStr(jsonObject, "orgName"));
            }
            if (jsonObject.containsKey("parent_org_unit_id")) {
                tbAuthDept.setDeptParentId(JsonUtils.getStr(jsonObject, "parent_org_unit_id"));
            }
            if (jsonObject.containsKey("parentOrgId")) {
                tbAuthDept.setDeptParentId(JsonUtils.getStr(jsonObject, "parentOrgId"));
            }

            /*
               "user":{}
             */
            if (dataMapping != null && StringUtils.isNotBlank(dataMapping.getRemark())) {
                JSONObject dmJson = JsonUtils.parse(dataMapping.getRemark());
                if (dmJson != null && dmJson.size() > 0) {
                    if (dmJson.containsKey("dept")) {
                        JSONObject userJson = dmJson.getJSONObject("dept");
                        String deptId = JsonUtils.getStrByPath(jsonObject, JsonUtils.getStr(userJson, BanbooAuthConstants.DEPT_ID));
                        if (StringUtils.isNotBlank(deptId)) {
                            tbAuthDept.setDeptId(deptId);
                        }
                        String deptPid = JsonUtils.getStrByPath(jsonObject, JsonUtils.getStr(userJson, BanbooAuthConstants.DEPT_PARENT_ID));
                        if (StringUtils.isNotBlank(deptPid)) {
                            tbAuthDept.setDeptParentId(deptPid);
                        }
                        String deptName = JsonUtils.getStrByPath(jsonObject, JsonUtils.getStr(userJson, BanbooAuthConstants.DEPT_NAME));
                        if (StringUtils.isNotBlank(deptName)) {
                            tbAuthDept.setDeptName(deptName);
                        }
                    }
                }
            }


            if (StringUtils.isBlank(tbAuthDept.getDeptId())) {
                log.error("部门id为空=" + JSON.toJSONString(tbAuthDept));
                return 0;
            }
            if ("3".equalsIgnoreCase(banbooData.getOp())) {//删除
                AuthDept tmp = authDeptMapper.selectTbAuthDeptByDeptId(tbAuthDept.getDeptId());
                if(tmp != null && tmp.getRefDeptId() != null) {
                    authDeptMapper.deleteSysDept(tmp.getRefDeptId());
                }
                authDeptMapper.deleteDeptById(tbAuthDept.getDeptId());
            } else {//修改/增加
                tbAuthDept.setDelFlag("0");
                AuthDept tmp = authDeptMapper.selectTbAuthDeptByDeptId(tbAuthDept.getDeptId());
                if (tmp != null) {
                    tbAuthDept.setUpdateTime(new Date());
                    authDeptMapper.updateAuthDept(tbAuthDept);
                } else {
                    if ("1".equalsIgnoreCase(banbooData.getOp())) {
                        tbAuthDept.setUpdateTime(new Date());
                        tbAuthDept.setCreateTime(new Date());
                        tbAuthDept.setUd2("0");
                        authDeptMapper.insert(tbAuthDept);
                    } else {
                        //修改操作，确找不到数据
                        log.error("修改操作，确找不到数据" + tbAuthDept.getDeptId());
                    }
                }
            }
        }
        return 0;
    }

}
