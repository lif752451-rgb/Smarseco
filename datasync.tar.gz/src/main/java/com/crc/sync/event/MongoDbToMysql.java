package com.crc.sync.event;

import com.alibaba.fastjson.JSONObject;
import com.baomidou.mybatisplus.core.conditions.query.LambdaQueryWrapper;
import com.baomidou.mybatisplus.core.toolkit.Wrappers;
import com.crc.common.enums.DatabaseEnums;
import com.crc.common.utils.*;
import com.crc.secface.config.GetSpringBean;
import com.crc.secface.db.ConfBuzziMySql;
import com.crc.secface.domain.Asset;
import com.crc.secface.domain.AssetSegement;
import com.crc.secface.domain.Event;
import com.crc.secface.mapper.AssetMapper;
import com.crc.secface.mapper.CommonMapper;
import com.crc.secface.mapper.EventMapper;
import com.crc.sync.net.NewSegmentLoad;
import com.crc.sync.terminal.alarm.AlarmAllAssetSync;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;

import java.util.Date;
import java.util.HashMap;
import java.util.List;


@Slf4j
public class MongoDbToMysql {
    public static HashMap<String, String> AttackResultMap = new HashMap<>();

    static {
        AttackResultMap.put("疑似成功", "1");
        AttackResultMap.put("企图", "0");
        AttackResultMap.put("失败", "3");
        AttackResultMap.put("疑似失陷", "2");
        AttackResultMap.put("已失陷", "4");
        AttackResultMap.put("攻击成功", "5");
    }


    public void sync() {
        try {
            CommonMapper commonMapper = GetSpringBean.getBean(CommonMapper.class);
            int offset = 30;
            int count = 0;
            boolean exitCombatReport = false;
            while (ConfBuzziMySql.existTable("tb_alarm_combat_report") == 1) {
                exitCombatReport = true;
                String sql = "SELECT r.* FROM tb_alarm_combat_report r WHERE r.del_flag = '0' and  r.create_time >  DATE_SUB(NOW(), INTERVAL " + offset + " DAY) and  not exists (select 1 from tb_event a where  a.qaxt_id = r.alarm_id) order by create_time desc  limit 1000";
                if(VersionUtils.getDatabase() == DatabaseEnums.DaMeng.getCode()){
                    sql = "SELECT r.* FROM tb_alarm_combat_report r WHERE r.del_flag = '0' and  r.create_time >=  sysdate - " + offset + " and  not exists (select 1 from tb_event a where  a.qaxt_id = r.alarm_id) order by create_time desc  limit 1000";
                }
                List<JSONObject> mapList = commonMapper.query(sql);
                if (mapList.size() < 1) {
                    break;
                }
                log.info("同步实战化告警EVENT_ALARM天数：" + offset + String.format(",size=%d", mapList.size()));
                try {
                    for (JSONObject eventDoc : mapList) {
                        try {
                            eventDoc.put("CRC_ALARM_TYPE", "combatAlarm");
                            procData(eventDoc);
                        } catch (Exception e) {
                            log.error(e.getMessage(), e);
                        }
                    }
                } catch (Exception e) {
                    log.error(e.getMessage(), e);
                }
                count++;
                if (count > 100) {
                    break;
                }
                MyTheadUtils.sleepBySec(1);
            }
            count = 0;
            while (ConfBuzziMySql.existTable("tb_alarm_report") == 1) {
                String sql = "SELECT r.* FROM tb_alarm_report r WHERE r.del_flag = '0' and  r.create_time >  DATE_SUB(NOW(), INTERVAL " + offset + " DAY) and  not exists (select 1 from tb_event a where  a.qaxt_id = r.alarm_id) order by create_time desc  limit 1000";
                if(VersionUtils.getDatabase() == DatabaseEnums.DaMeng.getCode()){
                    sql = "SELECT r.* FROM tb_alarm_report r WHERE r.del_flag = '0' and  r.create_time >=  sysdate - " + offset + "  and  not exists (select 1 from tb_event a where  a.qaxt_id = r.alarm_id) order by create_time desc  limit 1000";
                }
                List<JSONObject> mapList = commonMapper.query(sql);
                if (mapList.size() < 1) {
                    break;
                }
                log.info("同步安全告警EVENT_ALARM天数：" + offset + String.format(",size=%d", mapList.size()));
                try {
                    for (JSONObject eventDoc : mapList) {
                        try {
                            //告警类型(normAlarm 常态化告警、combatAlarm 实战告警)
                            eventDoc.put("CRC_ALARM_TYPE", "normAlarm");
                            procData(eventDoc);
                        } catch (Exception e) {
                            log.error(e.getMessage(), e);
                        }
                    }
                } catch (Exception e) {
                    log.error(e.getMessage(), e);
                }
                count++;
                if (count > 100) {
                    break;
                }
                MyTheadUtils.sleepBySec(1);
            }
            MyTheadUtils.sleepBySec(1);
            //更新实战 order_status
            if (exitCombatReport) {
                if(VersionUtils.getDatabase() == DatabaseEnums.MYSQL.getCode()){
                    commonMapper.exeSQL("UPDATE tb_event a  INNER JOIN (select * from tb_alarm_combat_report where create_time >  DATE_SUB(NOW(), INTERVAL " + offset + " DAY)) c ON c.del_flag = '0'  and a.qaxt_id = c.alarm_id SET a.event_source = c.alarm_source_label ,a.status = (case when c.order_status = 'noDeal' then '无需处置' when c.order_status = 'deal' then '处置' when c.order_status = 'follow' then '后续跟进' when c.order_status = 'audit' then '审核' when c.order_status = 'complete' then '归档' else '研判' end )," +
                            "a.event_level = c.level_label,a.attack_result = (case when c.attack_result_label = '疑似成功' then '1' when c.attack_result_label = '企图' then '0' when c.attack_result_label = '失败' then '3' when c.attack_result_label = '疑似失陷' then '2' when c.attack_result_label = '已失陷' then '4'  when c.attack_result_label = '攻击成功' then '5' else '3' end )");
                }else if(VersionUtils.getDatabase() == DatabaseEnums.DaMeng.getCode()){
                    commonMapper.exeSQL("UPDATE tb_event a  INNER JOIN (select * from tb_alarm_combat_report where create_time >= sysdate - " + offset + " ) c ON c.del_flag = '0'  and a.qaxt_id = c.alarm_id SET a.event_source = c.alarm_source_label ,a.status = (case when c.order_status = 'noDeal' then '无需处置' when c.order_status = 'deal' then '处置' when c.order_status = 'follow' then '后续跟进' when c.order_status = 'audit' then '审核' when c.order_status = 'complete' then '归档' else '研判' end )," +
                            "a.event_level = c.level_label,a.attack_result = (case when c.attack_result_label = '疑似成功' then '1' when c.attack_result_label = '企图' then '0' when c.attack_result_label = '失败' then '3' when c.attack_result_label = '疑似失陷' then '2' when c.attack_result_label = '已失陷' then '4'  when c.attack_result_label = '攻击成功' then '5' else '3' end )");

                }
            }
            //更新告警闭环 order_status
            if(VersionUtils.getDatabase() == DatabaseEnums.MYSQL.getCode()){
                commonMapper.exeSQL("UPDATE tb_event a  INNER JOIN (select * from tb_alarm_report where create_time >  DATE_SUB(NOW(), INTERVAL " + offset + " DAY)) c ON c.del_flag = '0'  and a.qaxt_id = c.alarm_id  SET a.event_source = c.alarm_source,a.status = c.order_status," +
                        "a.event_level = c.level_label,a.attack_result = (case when c.attack_result_label = '疑似成功' then '1' when c.attack_result_label = '企图' then '0' when c.attack_result_label = '失败' then '3' when c.attack_result_label = '疑似失陷' then '2' when c.attack_result_label = '已失陷' then '4'  when c.attack_result_label = '攻击成功' then '5' else '3' end )");
            }else if(VersionUtils.getDatabase() == DatabaseEnums.DaMeng.getCode()){
                commonMapper.exeSQL("UPDATE tb_event a  INNER JOIN (select * from tb_alarm_report where create_time >=  sysdate - " + offset + " ) c ON c.del_flag = '0'  and a.qaxt_id = c.alarm_id  SET a.event_source = c.alarm_source,a.status = c.order_status," +
                        "a.event_level = c.level_label,a.attack_result = (case when c.attack_result_label = '疑似成功' then '1' when c.attack_result_label = '企图' then '0' when c.attack_result_label = '失败' then '3' when c.attack_result_label = '疑似失陷' then '2' when c.attack_result_label = '已失陷' then '4'  when c.attack_result_label = '攻击成功' then '5' else '3' end )");
            }
            log.info("同步安全告警EVENT_ALARM完成==");
        } catch (Exception e) {
            log.error(e.getMessage(), e);
        }
    }

    /**
     * 获取数据并解析
     */
    public String procData(JSONObject object) {
        Event event = new Event();
        String areaName = null;
        try {
            String id = JsonUtils.getStr(object, "id");//事件ID
            int attack_count = JsonUtils.getInt(object, "attack_count");//攻击次数
            if (attack_count < 1)
                attack_count = 1;
            Date alarm_time = JsonUtils.getDate(object, "alarm_time");//攻击时间
            Date end_time = JsonUtils.getDate(object, "complete_time");
            String attack_result_label = JsonUtils.getStr(object, "attack_result_label");//攻击结果
            String attack_type = JsonUtils.getStr(object, "attack_means_label");//攻击类型
            String attacker = JsonUtils.getStr(object, "attack_ip");//攻击IP
            Date commit_time = JsonUtils.getDate(object, "create_time");//提交时间
            Date createTime = JsonUtils.getDate(object, "create_time");
            String commiter = JsonUtils.getStr(object, "commit_user_name");//提交人
            //String company_id = JsonUtils.getStr(object, "event_new_level");//归属公司
            String level_label = JsonUtils.getStr(object, "level_label");//事件级别

            //String event_status = JsonUtils.getStr(object, "node_name");//攻击结果
            String remarks = JsonUtils.getStr(object, "detail");//事件类型
            String source = JsonUtils.getStr(object, "alarm_source_label");
            if (StringUtils.isBlank(source)) {
                source = JsonUtils.getStr(object, "alarm_source");//事件来源
            }
            String judge_opinions = "";//JsonUtils.getStr(object, "intent_order.judge_opinions");//处置建议
            String handle_opinions = "";//JsonUtils.getStr(object, "intent_order.handle_opinions");//处置过程
            String qaxtId = JsonUtils.getStr(object, "alarm_id");
            String order_status = JsonUtils.getStr(object, "order_status");
            String is_whitelist = "0";
            if (StringUtils.isBlank(qaxtId)) {
                is_whitelist = "1";
            }
            //String handle_dep = JsonUtils.getStr(object, "intent_order.handle_dep");
            String fall_ips = "";//JsonUtils.getStr(object, "intent_order.fall_ips");
            String victim = JsonUtils.getStr(object, "victimized_ip");//受害ip/url
            String eventName = JsonUtils.getStr(object, "title");
            String oriEventId = "";//JsonUtils.getStr(object, "intent_order.ori_event_id");
            String add_info = JsonUtils.getStr(object, "ai_check");
            //intent_order.tab 和  intent_order.tab_desc
            String tab = "";//JsonUtils.getStr(object, "intent_order.tab");
            String tab_desc = "";//JsonUtils.getStr(object, "intent_order.tab_desc");

            event.setTab(tab);
            event.setTabDesc(tab_desc);
            event.setId(id);
            event.setQaxtId(qaxtId);
            event.setTotaId(qaxtId);
            event.setRemarks(remarks);
            if (StringUtils.isBlank(remarks))
                event.setRemarks(eventName);
            event.setAlarmTime(alarm_time);
            event.setDisposeContent(judge_opinions);
            event.setAuditContent(handle_opinions);
            event.setEventStartTime(alarm_time);
            event.setAttackIp(attacker);
            event.setAttackUrl(victim);
            String key = AttackResultMap.get(attack_result_label);
            if (StringUtils.isBlank(key))
                key = "0";

            event.setAttackResult(key);
            if (StringUtils.isBlank(eventName)) {
                eventName = attack_type;
            }
            if ("其他".equals(attack_type) || StringUtils.isBlank(attack_type)) {
                attack_type = "0_其它";
            }

            if (StringUtils.isNotBlank(add_info) && DataUtils.getDouble(add_info) > 0) {
                event.setAttach(add_info);
            }

            event.setEventName(eventName);
            event.setAttackType(attack_type);
            event.setDelFlag(0);
            event.setEventSource(source);
            if (order_status.contains("研判") || order_status.contains("judge") || order_status.contains("create")) {
                order_status = "研判";
            } else if (order_status.contains("溯源") || order_status.contains("跟进")) {
                order_status = "溯源/跟进";
            } else if (order_status.contains("无需") || order_status.contains("noDeal")) {
                order_status = "无需处置";
            } else if (order_status.contains("处置") || order_status.contains("deal") || order_status.contains("follow")) {
                order_status = "处置";
            } else if (order_status.contains("归档") || order_status.contains("complete")) {
                order_status = "归档";
            } else if (order_status.contains("审核") || order_status.contains("audit")) {
                order_status = "审核";
            }
            event.setAttackCount(attack_count);
            event.setOriEventId(oriEventId);
            //event.setRemarks(DocDataUtils.getString(object, "extend_alarm_detail"));
            // String commiter = dataMap.get("commiter_id").get(commiter_id);
            event.setCommiterId(commiter);
            event.setCommitTime(commit_time);
            event.setIsWhitelist(is_whitelist);
            //1：待研判，2：待处置，3：待审核，4：已归档，5：误判事件
            //normal handle recheck finish
            //未处置 处置中 处置结束 审核通过
            event.setEventLevel(level_label);
            if (StringUtils.isNotBlank(fall_ips)) {
                fall_ips = fall_ips.trim();
                event.setRiskIp(fall_ips);
            }
            if (createTime == null) {
                createTime = alarm_time;
            }
            event.setEventEndTime(end_time);
            event.setAttackType(event.getAttackType());
            event.setEventSource(event.getEventSource());
            String srcIp = event.getAttackIp();//攻击ip
            String destIp = event.getAttackUrl();//受害ip

            event.setDesignatedDepartment(JsonUtils.getStr(object, "duty_dept_name"));
            event.setEventId("1".equalsIgnoreCase(JsonUtils.getStr(object, "behavior_nature")) ? "异常" : "正常");
            event.setNodeDepartment(JsonUtils.getStr(object, "current_deal_user_nick_name"));
            if (StringUtils.isBlank(event.getEventLevel()))
                event.setEventLevel("四级");
            event.setGoStatus("1");
            event.setStatus(order_status);
            AssetSegement rdata = null;
            List<String> srcList = IpUtils.getIps(srcIp);
            if (srcList.size() > 0) {
                for (String ip : srcList) {
                    rdata = NewSegmentLoad.getIPSegmentByHalf(ip);
                    if (rdata != null) {
                        if (StringUtils.isBlank(event.getRiskIp())) {
                            event.setRiskIp(ip);
                        }
                        break;
                    }
                }
            }
            List<String> destList = IpUtils.getIps(destIp);
            if (rdata == null) {
                for (String ip : destList) {
                    rdata = NewSegmentLoad.getIPSegmentByHalf(ip);
                    if (rdata != null) {
                        if (StringUtils.isBlank(event.getRiskIp())) {
                            event.setRiskIp(destIp);
                        }
                        break;
                    }
                }
            }
            AlarmAllAssetSync.sync(srcIp, destIp);
            //snData 4 swData 3 shData 3 ddData lrData bgwData
            event.setSn("0");
            if (rdata != null) {
                String bu = rdata.getAffiliationDeptName();
                areaName = rdata.getAreaName();

                event.setRegArea(DataUtils.getDeptTree(areaName, 1));
                event.setRegSubArea(DataUtils.getDeptTree(areaName, 2));
                event.setRegBu(DataUtils.getDeptTree(bu, 1));
                event.setSnBu(bu);
            } else if (event.getRiskIp() != null) {
                AssetMapper tbAssetMapper = GetSpringBean.getBean(AssetMapper.class);
                Asset asset = tbAssetMapper.selectAssetByInnerIp(event.getRiskIp());
                if (asset != null) {
                    String bu = asset.getAffiliationDeptName();
                    areaName = asset.getAreaName();
                    event.setRegArea(DataUtils.getDeptTree(areaName, 1));
                    event.setRegSubArea(DataUtils.getDeptTree(areaName, 2));
                    event.setRegBu(DataUtils.getDeptTree(bu, 1));
                }
            }
            event.setId(id);
            event.setOriEventId(id);
            //System.out.println(counter.addAndGet(1));
            event.setGoStatus("1");
            EventMapper tbEventMapper = GetSpringBean.getBean(EventMapper.class);
            LambdaQueryWrapper<Event> queryWrapper = Wrappers.lambdaQuery();
            queryWrapper.eq(Event::getId, event.getId());
            queryWrapper.last(" limit 1");
            Event tmpEvent = tbEventMapper.selectOne(queryWrapper);
            if (tmpEvent == null) {
                event.setTab("0");
                event.setCreateTime(createTime);
                tbEventMapper.insert(event);
            } else {
                event.setId(tmpEvent.getId());
                event.setUpdateTime(new Date());
                tbEventMapper.updateEvent(event);
            }
        } catch (Exception e) {
            log.error(object.toJSONString() + " => " + e.getMessage(), e);
        }
        return event.getId();
    }
}
