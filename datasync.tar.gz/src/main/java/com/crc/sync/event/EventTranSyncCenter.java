package com.crc.sync.event;

import com.crc.common.utils.MyTheadUtils;
import com.crc.secface.config.GetSpringBean;
import com.crc.secface.mapper.EventMapper;
import com.crc.sync.config.SyncSecConfigLoad;
import com.crc.sync.config.SyncSecConstants;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class EventTranSyncCenter extends Thread {
    private static final Logger logger = LoggerFactory.getLogger(EventTranSyncCenter.class);

    public void run() {
        while (true) {
            MyTheadUtils.sleepBySec(20);
            /*
             同步青藤
            */
            try {
                if (SyncSecConfigLoad.isEnable(SyncSecConstants.ALARM_EVENT_SYNC_ENABLE)) {
                    logger.info("告警事件同步计算开始");
                    (new MongoDbToMysql()).sync();
                    logger.info("告警事件同步计算结束");
                    logger.info("驾驶舱计算开始");
                    try {
                        (new TopCalculatianTask(30)).sync();
                    } catch (Exception e) {
                        logger.error(e.getMessage(), e);
                    }
                    logger.info("驾驶舱计算结束");
                }
            } catch (Exception e) {
                logger.error(e.getMessage(), e);
            }
            MyTheadUtils.sleepBySec(60* 5);
        }
    }
}
