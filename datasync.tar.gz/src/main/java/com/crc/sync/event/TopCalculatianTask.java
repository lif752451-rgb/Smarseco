package com.crc.sync.event;

import com.crc.common.utils.DataUtils;
import com.crc.common.utils.DateUtils;
import com.crc.common.utils.IpUtils;
import com.crc.secface.config.GetSpringBean;
import com.crc.secface.domain.Asset;
import com.crc.secface.domain.AssetSegement;
import com.crc.secface.domain.Event;
import com.crc.secface.mapper.AssetMapper;
import com.crc.secface.mapper.EventCalculationMapper;
import com.crc.sync.net.NewSegmentLoad;
import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.*;
import java.util.concurrent.ConcurrentHashMap;

public class TopCalculatianTask {
    protected Logger logger = LoggerFactory.getLogger(TopCalculatianTask.class);
    private static final ConcurrentHashMap<String, String> keyMap = new ConcurrentHashMap<>();
    private final String startTime;
    private final String endTime;

    //统计时差
    public TopCalculatianTask(int offset) {
        String startTime = DateUtils.getDate(offset * -1);
        String endTime = DateUtils.getDate(1);
        this.startTime = startTime;
        this.endTime = endTime;
    }

    public void sync() {
        try {
            cal();
        } catch (Exception e) {
            logger.error(e.getMessage(), e);
        }
    }

    private AssetMapper assetMapper;

    private EventCalculationMapper topCalculationMapper;

    private void cal() {
        topCalculationMapper = GetSpringBean.getBean(EventCalculationMapper.class);
        assetMapper = GetSpringBean.getBean(AssetMapper.class);
        topCalculationMapper.delOldEvent();
        List<Event> eventDatas = topCalculationMapper.queryAllEvent(startTime, endTime, null, null);
        logger.info(DateUtils.getDateTimeString2(new Date()) + "驾驶舱统计数据计算。。" + startTime + " " + endTime + " size:" + eventDatas.size());
        if (!eventDatas.isEmpty()) {
            eventDatas.forEach(dataMap -> {
                String ipStr = dataMap.getAttackUrl() + " " + dataMap.getAttackIp();
                //解析所有IP，并统计所有
                List<String> ips = IpUtils.getIps(ipStr);
                ips = ipFilter(ips);

                Set<String> ipset = new HashSet<>(ips);
                if (!ipset.isEmpty()) {
                    for (String ip : ipset) {
                        AssetSegement rdata = NewSegmentLoad.getIPSegmentByHalf(ip);
                        String bu = "";
                        if (rdata != null) {
                            bu = rdata.getAffiliationDeptName();
                        }
                        if (StringUtils.isBlank(bu)) {
                            bu = getIp4Bu(ip);
                            if (StringUtils.isNotBlank(bu)) {
                                createCalculationMap(dataMap, bu, ip);
                            }
                        } else {
                            createCalculationMap(dataMap, bu, ip);
                        }
                    }
                }
            });
        }

        //topCalculationMapper.deleteAll();
        logger.info("驾驶舱统计数据计算结束");
    }

    /**
     * 查询IP BU归属
     *
     * @param ip
     * @return
     */
    private String getIp4Bu(String ip) {
        Asset asset = assetMapper.selectAssetByInnerIp(ip);
        if (asset != null && StringUtils.isNotBlank(asset.getAffiliationDeptName())) {
            return asset.getAffiliationDeptName();
        } else {
            AssetSegement rdata = NewSegmentLoad.getIPSegmentByHalf(ip);
            if (rdata != null) {
                return rdata.getAffiliationDeptName();
            }
        }
        return "";
    }

    private void createCalculationMap(Event dataMap, String company, String ip) {
        try {
            Map<String, String> map = new HashMap<>();
            map.put("id", dataMap.getQaxtId());
            map.put("qaxtId", dataMap.getQaxtId());
            map.put("attackResult", dataMap.getAttackResult());
            map.put("alarmTime", DateUtils.getDateTimeString1(dataMap.getAlarmTime()));
            map.put("ip", ip);
            if (company != null && (company.contains("守正")))
                company = "集团总部";
            map.put("company", company);
            map.put("attackType", dataMap.getAttackType());

            if (StringUtils.isBlank(dataMap.getQaxtId()))
                return;
            if (topCalculationMapper.getCalculationOne(DataUtils.getString(map, "id")) > 0) {
                topCalculationMapper.updateCalculationOne(map);
            } else {
                topCalculationMapper.saveCalculationOne(map);
            }
        } catch (Exception e) {
            logger.error(e.getMessage(), e);
        }
    }

    String[] ipFilterStr = {"0.0.0.0"};

    private List<String> ipFilter(List<String> ips) {
        List<String> result = new ArrayList<>();
        if (null != ips && !ips.isEmpty()) {
            out:
            for (String ip : ips) {
                for (String fileIp : ipFilterStr) {
                    if (ip.startsWith(fileIp)) {
                        continue out;
                    }
                }
                result.add(ip);
            }
        }
        return result;
    }
}
