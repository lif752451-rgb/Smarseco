package com.crc.sync.net;

import com.crc.common.utils.DataUtils;
import com.crc.common.utils.IpUtils;
import com.crc.secface.config.GetSpringBean;
import com.crc.secface.domain.Asset;
import com.crc.secface.domain.AssetSegement;
import com.crc.secface.service.AssetRecordService;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;

import java.math.BigInteger;
import java.util.List;
import java.util.concurrent.ConcurrentHashMap;
import java.util.stream.Collectors;

/*
 * 集团网段加载功能
 */
@Slf4j
public class NewSegmentLoad {
    private static final ConcurrentHashMap<String, List<AssetSegement>> ipSegMap = new ConcurrentHashMap<>();
    public static boolean FILTER_SEGMENT_FLAG = false;//是否只认网段 IP 范围数据

    public static void setAllSegment(List<AssetSegement> segementList) {
        if (segementList != null) {
            ipSegMap.put("seg", segementList);
        }
    }

    public static List<AssetSegement> getAllSegment() {
        return ipSegMap.get("seg");
    }

    /*
      获取 IP 命中的最新网段
     */
    public static AssetSegement getIPSegmentByHalf(String ip) {
        List<AssetSegement> allSegment = getAllSegment();
        try {
            if (allSegment == null) {
                return null;
            }
            List<AssetSegement> list = allSegment.stream().filter(tbSegementInfoEvery -> {
                String segmentStr = tbSegementInfoEvery.getSegment();
                if (StringUtils.isEmpty(segmentStr)) {
                    return false;
                }
                //是否属于该网段
                return NewSegmentLoad.isBelongThisSegment(segmentStr, ip);
            }).collect(Collectors.toList());
            if (!list.isEmpty()) {
                return list.get(0);
            }
        } catch (Exception e) {
            log.error(e.getMessage(), e);
        }
        return null;
    }

    public static boolean getIPByHalf(List<String> ipSetList, String ip) {
        return isBelongThisSegment(String.join("\n", ipSetList), ip);
    }

    public static boolean isBelongThisSegment(String segmentStr, String targetIpStr) {
        if (StringUtils.isEmpty(segmentStr) || StringUtils.isEmpty(targetIpStr)) {
            return false;
        }
        BigInteger ip2long = IpUtils.getIp2long(targetIpStr.trim());
        String[] ipList = IpUtils.getIpSegment(segmentStr);
        for (String cidr : ipList) {
            BigInteger[] rets = IpUtils.getIpStartAndEnd(cidr);
            if (rets == null || rets.length != 2) {
                continue;
            }
            BigInteger startIp2long = rets[0];
            BigInteger endIp2long = rets[1];
            if (DataUtils.isIpInSegment(startIp2long, ip2long, endIp2long)) {
                return true;
            }
        }
        return false;
    }

    public static void getSegementInfo(Asset asset) {
        List<String> ipList = IpUtils.getIps(asset.getInternalIp());
        if (ipList.size() > 0) {
            asset.setInternalIp(ipList.get(0));
        }
        AssetSegement rdata = getIPSegmentByHalf(asset.getInternalIp());
        if (rdata != null) {
            log.info("{}-> 获取到网段:{}", asset.getInternalIp(), rdata.getName());
            asset.setAreaName(rdata.getAreaName());
            asset.setAreaCustomUuid(rdata.getAreaCustomUuid());
            asset.setAffiliationDeptName(rdata.getAffiliationDeptName());
            asset.setAffiliationDeptNodeId(rdata.getAffiliationDeptNodeId());
            if (asset.getEnvironmentType() == null) {
                String envType = rdata.getEvn();
                if (envType != null) {
                    int type = 1;
                    if (envType.contains("测试")) {
                        type = 2;
                    } else if (envType.contains("灾备")) {
                        type = 3;
                    }
                    asset.setEnvironmentType(type);
                }
            }
        }

        try {
            AssetRecordService assetRecordService = GetSpringBean.getBean(AssetRecordService.class);
            assetRecordService.setDefaultTypeAndArea(asset);
        } catch (Exception e) {
            log.error(e.getMessage(), e);
        }
    }
}
