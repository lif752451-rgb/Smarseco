package com.crc.sync.git;

import com.crc.common.utils.FileUtils;
import lombok.extern.slf4j.Slf4j;
import org.eclipse.jgit.api.Git;
import org.eclipse.jgit.api.errors.GitAPIException;
import org.eclipse.jgit.internal.storage.file.FileRepository;
import org.eclipse.jgit.lib.Ref;
import org.eclipse.jgit.lib.StoredConfig;
import org.eclipse.jgit.revwalk.RevCommit;
import org.eclipse.jgit.transport.UsernamePasswordCredentialsProvider;

import java.io.File;
import java.util.ArrayList;
import java.util.Collection;
import java.util.List;

/**
 * Git客户端
 *
 * @author: 村长
 * @date: 2023-03-22 09:57:20
 */
@Slf4j
public class GitClient {
    /**
     * 本地存储路径
     */
    public static String LOCALPATH;
    /**
     * 远程仓库地址
     */
    public static String URI;
    /**
     * 用户名
     */
    public static String USER;
    /**
     * 密码
     */
    public static String PASSWORD;
    /**
     * 分支
     */
    public static String BRANCH;

    /**
     * GitClient
     *
     * @param localpath 本地存储路径
     * @param url       远程仓库地址
     * @param user      用户名
     * @param password  密码
     * @param branch    分支
     */
    public GitClient(String localpath, String url, String user, String password, String branch) {
        GitClient.LOCALPATH = localpath;
        GitClient.URI = url;
        GitClient.USER = user;
        GitClient.PASSWORD = password;
        GitClient.BRANCH = branch;
    }

    /**
     * 克隆分支
     */
    public void cloneRepo() {
        Git git = null;
        try {
            git = Git.cloneRepository().setURI(URI).setGitDir(new File(LOCALPATH + "/.git")).setDirectory(new File(LOCALPATH)).setCredentialsProvider(new UsernamePasswordCredentialsProvider(USER, PASSWORD)).setBranch(BRANCH).call();
            StoredConfig config = git.getRepository().getConfig();
            config.setBoolean("http", null, "sslVerify", false);
            config.save();
        } catch (Exception e) {
            log.error("git克隆错误:{}", e.getMessage(),e);
        } finally {
            if (git != null) {
                git.close();
            }
        }
    }

    /**
     * 克隆分支，指定文件克隆
     * 指定文件之后无法获取日志的
     *
     * @param subPath 文件||文件夹路径
     */
    public void cloneRepo(String subPath) {
        Git git = null;
        try {
            FileUtils.createDirectory4FilePath(subPath);
            log.info("cloneRepo");
            git = Git.cloneRepository().setURI(URI).setGitDir(new File(LOCALPATH + "/.git")).setDirectory(new File(LOCALPATH)).setCredentialsProvider(new UsernamePasswordCredentialsProvider(USER, PASSWORD)).setNoCheckout(true).setBranch(BRANCH).call();
            //checkout指定文件||文件夹
            git.checkout().setName(BRANCH).setStartPoint("origin/" + BRANCH).addPath(subPath).call();
            //忽略HTTPS校验
            StoredConfig config = git.getRepository().getConfig();
            config.setBoolean("http", null, "sslVerify", false);
            config.save();
        } catch (Exception e) {
            log.error("git克隆错误:{}", e.getMessage(),e);
        } finally {
            if (git != null) {
                git.close();
            }
        }
    }

    /**
     * pull拉取远程仓库文件
     */
    public void pullBranchToLocal() {
        Git git = null;
        try {
            log.info("pullBranchToLocal");
            git = new Git(new FileRepository(LOCALPATH + "/.git"));
            git.pull().setCredentialsProvider(new UsernamePasswordCredentialsProvider(USER, PASSWORD)).setRemoteBranchName(BRANCH).call();
        } catch (Exception e) {
            log.error("git克隆错误:{}", e.getMessage(),e);
        } finally {
            if (git != null) {
                git.close();
            }
        }
    }

    /**
     * 获取分支列表
     *
     * @return
     */
    public List<String> branchList() {
        List<String> branchnameList = new ArrayList<>();
        Collection<Ref> git;
        try {
            git = Git.lsRemoteRepository().setCredentialsProvider(new UsernamePasswordCredentialsProvider(USER, PASSWORD)).setHeads(true).setRemote(URI).call();
            for (Ref ref : git) {
                String refName = ref.getName();
                if (refName.startsWith("refs/heads/")) {
                    branchnameList.add(refName.replace("refs/heads/", ""));
                }
            }
        } catch (GitAPIException e) {
            log.error("git分支列表读取错误:{}", e.getMessage(),e);
        }
        return branchnameList;
    }

    /**
     * 读取提交日志
     * 需先pull，这个是读取本地文件的信息
     *
     * @return
     */
    public List<CommitLog> getLogs() {
        List<CommitLog> data = new ArrayList<>();
        Git git = null;
        try {
            git = new Git(new FileRepository(LOCALPATH + "/.git"));
            // 只返回两条
            Iterable<RevCommit> logs = git.log().call();
            for (RevCommit rev : logs) {
                CommitLog commitLog = new CommitLog();
                commitLog.setDes(rev.getFullMessage());
                commitLog.setEmail(rev.getAuthorIdent().getEmailAddress());
                commitLog.setId(rev.getName());
                commitLog.setUser(rev.getAuthorIdent().getName());
                commitLog.setTime(rev.getCommitTime());
                data.add(commitLog);
            }
        } catch (Exception e) {
            log.error("git日志读取错误:{}", e.getMessage(),e);
        } finally {
            if (git != null) {
                git.close();
            }
        }
        return data;
    }
}
