package com.crc.sync.git;

import com.alibaba.fastjson.JSONObject;
import com.baomidou.mybatisplus.core.conditions.update.LambdaUpdateWrapper;
import com.baomidou.mybatisplus.core.toolkit.Wrappers;
import com.crc.common.code.CodeTool;
import com.crc.common.nginxparser.NgxBlock;
import com.crc.common.nginxparser.NgxConfig;
import com.crc.common.nginxparser.NgxEntry;
import com.crc.common.nginxparser.NgxParam;
import com.crc.common.nginxparser.enity.Location;
import com.crc.common.nginxparser.enity.NginxData;
import com.crc.common.nginxparser.enity.NginxServer;
import com.crc.common.utils.*;
import com.crc.secface.config.GetSpringBean;
import com.crc.secface.domain.F5NgConf;
import com.crc.secface.domain.SysDictData;
import com.crc.secface.domain.vo.IpPortVo;
import com.crc.secface.mapper.F5NgConfMapper;
import com.google.common.collect.Lists;
import com.google.common.collect.Maps;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;

import java.io.File;
import java.io.IOException;
import java.nio.file.*;
import java.nio.file.attribute.BasicFileAttributes;
import java.util.HashMap;
import java.util.List;

@Slf4j
public class NginxAllDataSync {
    public void syncAll() {
        try {
            F5NgConfMapper ngConfMapper = GetSpringBean.getBean(F5NgConfMapper.class);

            try {
                ngConfMapper = GetSpringBean.getBean(F5NgConfMapper.class);
                ngConfMapper.deleteAll();
            } catch (Exception e) {
                log.error(e.getMessage(), e);
            }

            List<SysDictData> list = DictUtil.getDict("nginx_conf_list");

            for (SysDictData dict : list) {
                try {
                    JSONObject jsonObject = JsonUtils.parse(dict.getRemark());
                    String gitUrl = JsonUtils.getStr(jsonObject, "gitUrl");
                    String gitUser = JsonUtils.getStr(jsonObject, "gitUser");
                    if (StringUtils.isBlank(gitUser) || StringUtils.isBlank(gitUrl)) {
                        log.error("{},参数不完整！", dict.getRemark());
                        continue;
                    }
                    String localPath = JsonUtils.getStr(jsonObject, "localPath") + "/" + dict.getDictCode();
                    FileUtils.createDirectory4FilePath(localPath);
                    GitClient gitClient = new GitClient(localPath,
                            gitUrl,
                            gitUser,
                            CodeTool.decrypt(JsonUtils.getStr(jsonObject, "gitPass")),
                            JsonUtils.getStr(jsonObject, "gitBranch")
                    );
                    //需要的文件或者文件夹路径
                    String subPath = "/";
                    //克隆远程分支到本地
                    File file = new File(localPath + "/.git");
                    if (file.exists()) {
                        gitClient.pullBranchToLocal();
                    } else {
                        gitClient.cloneRepo(subPath);
                    }
                    try {
                        LambdaUpdateWrapper<F5NgConf> uq = Wrappers.lambdaUpdate();
                        uq.set(F5NgConf::getDelFlag, 1);
                        uq.eq(F5NgConf::getNgPach, gitUrl);
                        ngConfMapper.update(null, uq);
                    } catch (Exception e) {
                        log.error(e.getMessage(), e);
                    }
                    List<Path> pathList = findAllFile(localPath);
                    pathList.forEach((v) -> syncNginx(v.toAbsolutePath().toString(), gitUrl));
                } catch (Exception e) {
                    log.error(dict.getRemark() + " " + e.getMessage(), e);
                }
            }

            /*List<Path> pathList = findAllFile("D:\\gitlab");
            pathList.forEach((v) -> syncNginx(v.toAbsolutePath().toString(), "https://gitlab.crc.com.cn/crcsoft-smart-sec/linkage.git"));*/
        } catch (Exception e) {
            log.error(e.getMessage(), e);
        }
    }

    /**
     * 递归遍历conf配置文件
     */
    public List<Path> findAllFile(String rootPath) {
        List<Path> nginxConfPathList = Lists.newArrayList();
        try {
            Path path = Paths.get(rootPath);
            Files.walkFileTree(path, new FileVisitor<Path>() {
                //访问文件夹之前调用此方法
                @Override
                public FileVisitResult preVisitDirectory(Path dir, BasicFileAttributes attrs) {
                    return FileVisitResult.CONTINUE;
                }

                //访问文件时调用此方法
                @Override
                public FileVisitResult visitFile(Path file, BasicFileAttributes attrs) {
                    if (!attrs.isDirectory()) {
                        String originalFilename = file.getFileName().toString();
                        int pos = originalFilename.lastIndexOf(".");
                        String suffix = "";
                        if (pos != -1) {
                            suffix = originalFilename.substring(originalFilename.lastIndexOf(".") + 1);
                        }
                        if ("conf".equalsIgnoreCase(suffix)) {
                            nginxConfPathList.add(file);
                        }
                    }
                    return FileVisitResult.CONTINUE;
                }

                //访问文件失败时调用此方法
                @Override
                public FileVisitResult visitFileFailed(Path file, IOException exc) {
                    log.error(file + "\t文件访问受限: ");
                    return FileVisitResult.CONTINUE;

                }

                //访问文件夹之后调用此方法
                @Override
                public FileVisitResult postVisitDirectory(Path dir, IOException exc) {
                    if (exc != null) {
                        log.error(dir + "\t文件夹访问受限，跳过" + exc);
                    }
                    return FileVisitResult.CONTINUE;
                }
            });
        } catch (Exception e) {
            log.error(e.getMessage(), e);
        }
        return nginxConfPathList;
    }

    public void syncNginx(String filePath, String gitUrl) {
        try {
            NginxData nginxData = new NginxData();
            File file = new File(filePath);
            nginxData.setFileName(file.getName());
            HashMap<String, String> includeMap = new HashMap<>();
            iterServer(nginxData, filePath, includeMap);

            if (nginxData.getNginxServerList() == null || nginxData.getNginxServerList().size() < 1) {
                log.info("nginx server没有数据");
            } else {

                F5NgConfMapper ngConfMapper = GetSpringBean.getBean(F5NgConfMapper.class);
                nginxData.getNginxServerList().forEach((nginxServer -> nginxServer.getLocationList().forEach(location -> {
                    try {
                        F5NgConf ngConf = new F5NgConf();
                        ngConf.setNgName(nginxData.getFileName());
                        ngConf.setPort(nginxServer.getPort());
                        ngConf.setDomainName(nginxServer.getServerName());
                        ngConf.setProxyPass(location.getProxyPass());
                        ngConf.setNgPach(filePath);
                        ngConf.setPath(location.getPath());
                        String domain = UrlUtils.getDomain(location.getProxyPass());
                        if (IpUtils.isIp(domain)) {
                            IpPortVo vo = UrlUtils.getIpAndPort(location.getProxyPass());
                            if (vo.getPort() > 0) {
                                ngConf.setLbVsIp(vo.getIp());
                                ngConf.setLbVsPort(vo.getPort());
                            }
                        }
                        //String uuid = Md5Utils.hash(ngConf.getDomainName(), ngConf.getPort(), ngConf.getNgPach(), ngConf.getProxyPass(), ngConf.getPath());
                        //ngConf.setUuid(uuid);
                        //LambdaQueryWrapper<F5NgConf> q = Wrappers.lambdaQuery();
                        //q.eq(F5NgConf::getUuid, uuid);
                        //q.last(" limit 1");
                        //F5NgConf tmp = ngConfMapper.selectOne(q);
                        //if (tmp == null) {
                        ngConfMapper.insert(ngConf);
                        /*} else {
                            LambdaUpdateWrapper<F5NgConf> uq = Wrappers.lambdaUpdate();
                            uq.set(F5NgConf::getDelFlag, 0);
                            uq.eq(F5NgConf::getUuid, uuid);
                            ngConfMapper.update(null, uq);
                        }*/
                    } catch (Exception e) {
                        log.error(e.getMessage(), e);
                    }
                })));
            }
        } catch (Exception e) {
            log.error(e.getMessage(), e);
        }
    }

    /**
     * 递归遍历conf文件
     */
    public static void iterServer(NginxData nginxData, String ngFile, HashMap<String, String> includeMap) {
        //include /app/nginx/cr_test.d/*.conf;
        if (nginxData.getNginxServerList() == null) {
            nginxData.setNginxServerList(Lists.newArrayList());
        }
        NgxConfig conf = NgxConfig.read(ngFile);
        if (conf != null) {
            List<NgxEntry> udpServers = conf.findAll(NgxConfig.BLOCK, "upstream");
            log.info("udpServers={}", udpServers.size());
            HashMap<String, String> upstreamMap = Maps.newHashMap();
            for (NgxEntry entry : udpServers) {
                String upstream = ((NgxBlock) entry).getValue();
                //System.out.println(upstream);
                NgxParam server = ((NgxBlock) entry).findParam("server");
                if (server != null) {
                    //System.out.println(server.getValue());
                    upstreamMap.put(upstream, server.getValue());
                }
            }

            List<NgxEntry> httpServers = conf.findAll(NgxConfig.BLOCK, "server"); // Ex.3
            log.info("httpServers={}", httpServers.size());
            for (NgxEntry entry : httpServers) {
                NgxParam listen = ((NgxBlock) entry).findParam("listen");
                NgxParam server_name = ((NgxBlock) entry).findParam("server_name");
                if(server_name == null)
                {
                    continue;
                }
                NginxServer nginxServer = new NginxServer();
                nginxServer.setServerName(server_name.getValue());
                if (includeMap.containsKey(server_name.getValue() + ":" + listen.getValue())) {
                    continue;
                } else {
                    includeMap.put(server_name.getValue() + ":" + listen.getValue(), "1");
                }
                if (listen.getValue().contains(":")) {
                    String[] arr = listen.getValue().split(":");
                    nginxServer.setPort(DataUtils.getInt(arr[arr.length - 1]));
                } else {
                    nginxServer.setPort(DataUtils.getInt(listen.getValue()));
                }
                nginxServer.setLocationList(Lists.newArrayList());
                //location
                List<NgxEntry> locations = ((NgxBlock) entry).findAll(NgxConfig.BLOCK, "location"); // Ex.4
                //log.info(JSON.toJSONString(locations));
                for (NgxEntry local : locations) {
                    Location location = new Location();
                    String value = ((NgxBlock) local).getValue();
                    if (StringUtils.isBlank(value)) {
                        continue;
                    }
                    if (value.startsWith("=")) {
                        /*
                           文件服务代理
                         */
                        //location.setRoot(value);
                        String[] valueArr = value.split("=");
                        location.setPath(valueArr[1].trim());
                        NgxParam proxy_pass = ((NgxBlock) local).findParam("root");
                        if(proxy_pass == null)
                        {
                            proxy_pass = ((NgxBlock) local).findParam("proxy_pass");
                        }

                        if (proxy_pass != null) {
                            if (StringUtils.isNoneBlank(proxy_pass.getValue())) {
                                location.setProxyPass(proxy_pass.getValue());
                                nginxServer.getLocationList().add(location);
                            }
                        }
                    } else if (StringUtils.isNoneBlank(value)) {
                        /*
                           域名服务代理
                         */
                        location.setPath(value);
                        NgxParam proxy_pass = ((NgxBlock) local).findParam("proxy_pass");
                        if (proxy_pass != null) {
                            if (StringUtils.isNoneBlank(proxy_pass.getValue())) {
                                location.setProxyPass(proxy_pass.getValue());
                                if (upstreamMap.size() > 0 && location.getProxyPass() != null) {
                                    String domain = UrlUtils.getDomain(location.getProxyPass());
                                    if (upstreamMap.containsKey(domain)) {//命中upstream
                                        int pos1 = location.getProxyPass().indexOf("//");
                                        if (pos1 != -1) {
                                            String http = location.getProxyPass().substring(0, pos1);
                                            String sub = location.getProxyPass().substring(pos1 + 2);
                                            int pos2 = sub.indexOf("/");
                                            if (pos2 != -1) {
                                                String sub2 = sub.substring(pos2);
                                                String newUrl = http + "//" + upstreamMap.get(domain) + sub2;
                                                location.setProxyPass(newUrl);
                                            }else {
                                                String newUrl = http + "//" + upstreamMap.get(domain) ;
                                                location.setProxyPass(newUrl);
                                            }
                                        }
                                    }
                                }
                                nginxServer.getLocationList().add(location);
                            }
                        }
                    }
                }
                nginxData.getNginxServerList().add(nginxServer);
            }


            for (NgxEntry entry : conf.getEntries()) {
                if (entry.getClass().equals(NgxBlock.class)) {
                    NgxBlock includes = ((NgxBlock) entry); // Ex.4
                    for (NgxEntry include : includes) {
                        if (include.getClass().equals(NgxParam.class)) {
                            NgxParam ngxParam = (NgxParam) include;
                            if (ngxParam.getName().equalsIgnoreCase("include")) {
                                String filePath = ngxParam.getValue();
                                if (filePath.contains("*")) {
                                    String dir = filePath.substring(0, filePath.indexOf("*"));
                                    if(dir.contains(File.separator))
                                    dir = dir.substring(0, dir.lastIndexOf(File.separator));
                                    File file = new File(dir);
                                    if (file.exists()) {
                                        String[] list = file.list((dirPath, name) -> name.endsWith(".conf"));
                                        if (list != null) {
                                            for (String fileName : list) {
                                                String newPath = file.getAbsolutePath() + File.separator + fileName;
                                                if (includeMap.containsKey(newPath)) {
                                                    continue;
                                                } else {
                                                    includeMap.put(newPath, "1");
                                                }
                                                iterServer(nginxData, newPath, includeMap);
                                            }
                                        }
                                    }
                                } else {
                                    if (FileUtils.isExists(filePath)) {
                                        if (!includeMap.containsKey(filePath)) {
                                            iterServer(nginxData, filePath, includeMap);
                                            includeMap.put(filePath, "1");
                                        }

                                    }
                                }
                            }
                        }
                    }
                }
            }
        }

    }
}
