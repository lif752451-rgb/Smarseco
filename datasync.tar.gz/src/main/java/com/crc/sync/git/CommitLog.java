package com.crc.sync.git;

/**
 * 提交人日志
 *
 * @author: 村长
 * @date: 2023-03-22 14:49:18
 */
public class CommitLog {

    /**
     * 提交ID
     */
    private String id;
    /**
     * 描述
     */
    private String des;
    /**
     * 提交用户
     */
    private String user;
    /**
     * email
     */
    private String email;
    /**
     * 提交时间
     */
    private Integer time;

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getDes() {
        return des;
    }

    public void setDes(String des) {
        this.des = des;
    }

    public String getUser() {
        return user;
    }

    public void setUser(String user) {
        this.user = user;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public Integer getTime() {
        return time;
    }

    public void setTime(Integer time) {
        this.time = time;
    }
}
