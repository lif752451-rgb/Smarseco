package com.crc.sync.changting;

import cn.hutool.core.util.StrUtil;

/**
 * @ClassName AssetSeverEnum
 * @Description TODO
 * @Author fuzhuangzhi
 * @Date 2022/05/20 17:43
 * @Version 1.0
 **/
public enum AssetSeverEnum {
    UNKNOW("UNKNOWN", "3"),
    NONE("NONE", "3"),
    LOW("LOW", "3"),
    MEDIUM("MEDIUM", "2"),
    HIGH("HIGH", "1"),
    ;
    private String name;
    private String  value;

    AssetSeverEnum(String name, String value) {
        this.name = name;
        this.value = value;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getValue() {
        return value;
    }

    public void setValue(String value) {
        this.value = value;
    }

    public static String getValueByName(String name){
        if (StrUtil.isBlank(name)){
            return null;
        }
        for (AssetSeverEnum level : AssetSeverEnum.values()){
            if (level.getName().equals(name)){
                return level.getValue();
            }
        }
        return null;
    }
}
