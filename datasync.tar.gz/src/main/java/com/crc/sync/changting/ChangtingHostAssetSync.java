package com.crc.sync.changting;

import cn.hutool.core.collection.CollUtil;
import cn.hutool.core.io.IoUtil;
import cn.hutool.core.util.StrUtil;
import com.alibaba.fastjson.JSONArray;
import com.alibaba.fastjson.JSONObject;
import com.crc.common.code.SimpleCodeTool;
import com.crc.common.constants.Constants;
import com.crc.common.enums.AssetSourceEnums;
import com.crc.common.enums.ScannerEnums;
import com.crc.common.utils.DataUtils;
import com.crc.common.utils.DateUtils;
import com.crc.common.utils.IpUtils;
import com.crc.common.utils.JsonUtils;
import com.crc.scanner.config.ChangTingConfig;
import com.crc.scanner.tool.ChangTingUtils;
import com.crc.secface.config.GetSpringBean;
import com.crc.secface.domain.Asset;
import com.crc.secface.domain.AssetPort;
import com.crc.secface.domain.EngineEquipmentManagement;
import com.crc.secface.queue.CrcAssetSyncQueue;
import com.crc.secface.schedule.assemble.CommonAssemble;
import com.crc.secface.service.AssetRecordService;
import com.crc.sync.work.PortSaveWork;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.apache.http.HttpEntity;
import org.apache.http.client.methods.CloseableHttpResponse;
import org.apache.http.util.EntityUtils;

import java.util.Date;
import java.util.List;
import java.util.concurrent.atomic.AtomicBoolean;

import static com.crc.common.constants.Constants.*;

/**
 * @ClassName ChangtingHostAssetSync
 * @Description 长亭主机资产同步
 * @Author fuzhuangzhi
 * @Date 2022/05/19 19:16
 * @Version 1.0
 */
@Slf4j
public class ChangtingHostAssetSync {
    public static ChangTingConfig getCtConfig(Long engineId) {
        EngineEquipmentManagement engine = CommonAssemble.engineMap.get(engineId);

        ChangTingConfig qtConfig = new ChangTingConfig();
        if (engine == null) {
            return qtConfig;
        }
        qtConfig.setEngineId(engineId);
        qtConfig.setAddress(engine.getEquipmentAddress());
        qtConfig.setPassword(engine.getPassword());
        String PASS = qtConfig.getPassword().trim();
        try {
            PASS = SimpleCodeTool.decrypt(PASS);
            qtConfig.setPassword(PASS);
        } catch (Exception e) {
            log.error(e.getMessage(), e);
        }
        qtConfig.setUsername(engine.getLoginUser());
        return qtConfig;
    }

    public void sync() {
        try {
            CommonAssemble.engineMap.forEach((k, v) -> {
                if (ScannerEnums.CHANGTING_SCANNER.getCode().equals(v.getEquipmentManufacture())) {
                    sync(getCtConfig(k));
                }
            });
        } catch (Exception e) {
            log.error(e.getMessage(), e);
        }
    }

    public void sync(ChangTingConfig scannerInfo) {
        log.info("ChangtingHostAssetSync开始同步长亭主机资产 " + scannerInfo.getAddress());
        try {
            String parameter = "?limit=200&offset=0";
            // 工作区集合
            List<Integer> workAreaIds = ChangTingUtils.getWorkAreaIds(scannerInfo,
                    Constants.ChangTingApiUrl.WORK_AREA_API_URL, parameter);
            if (CollUtil.isEmpty(workAreaIds)) {
                log.error("获取工作区失败！,长亭配置信息：{}", scannerInfo.getAddress());
                return;
            }
            AtomicBoolean flag = new AtomicBoolean(false);
            JSONObject defaultParam = new JSONObject();
            defaultParam.put(LIMIT, 1);
            defaultParam.put(OFFSET, 0);
            defaultParam.put("is_alive", "ALIVE");
            workAreaIds.forEach(projectId -> {
                try {
                    long total = ChangTingUtils.getTotal(scannerInfo,
                            Constants.ChangTingApiUrl.HOST_ASSET_API_URL + Symbol.ZH_QUESTION + PROJECT_ID + Symbol.EQUAL + projectId, defaultParam);
                    log.info("获取到的主机资产数量：" + total);
                    if (total > 0) {
                        int pageSize = 400;
                        for (int i = 1; i < Math.ceil(total / pageSize) + 2; i++) {
                            CloseableHttpResponse response = null;
                            try {
                                response = ChangTingUtils.sendPost(scannerInfo,
                                        Constants.ChangTingApiUrl.HOST_ASSET_API_URL + Symbol.ZH_QUESTION + Constants.PROJECT_ID + Symbol.EQUAL + projectId, getJsonParamters(i, pageSize));
                                int code = response.getStatusLine().getStatusCode();
                                String ret = DataUtils.toBodyString(response.getEntity());
                                if (code == 200) {
                                    JSONObject result = JsonUtils.parse(ret);
                                    if (result.containsKey(DATA_LIST_TAG)) {
                                        JSONObject data = result.getJSONObject(DATA_LIST_TAG);
                                        if (data != null && !data.isEmpty()) {
                                            getIpAssetList(scannerInfo, data.getJSONArray(CONTENT));
                                            flag.getAndSet(true);
                                        }
                                    } else {
                                        log.error("获取数据错误：" + ret);
                                    }
                                } else {
                                    log.error("获取数据错误非200OK：" + ret);
                                }
                                if (!flag.get()) {
                                    return;
                                }
                            } catch (Exception e) {
                                log.error(e.getMessage(), e);
                                if (!flag.get()) {
                                    return;
                                }
                            } finally {
                                IoUtil.close(response);
                            }
                        }
                    }

                } catch (Exception e) {
                    log.error(e.getMessage(), e);
                }
            });
        } catch (Exception e) {
            log.error(e.getMessage(), e);
        }
    }

    /**
     * 保存主机资产
     *
     * @param dataList
     */
    private void getIpAssetList(ChangTingConfig scannerInfo, JSONArray dataList) {
        try {
            for (int i = 0; i < dataList.size(); i++) {
                try {
                    JSONObject json = dataList.getJSONObject(i);
                    if (json == null || json.isEmpty()) {
                        continue;
                    }
                    int id = JsonUtils.getInt(json, "id");
                    String url = String.format(ChangTingApiUrl.HOST_ASSET_BY_ID_API_URL, id);
                    JSONObject result = ChangTingUtils.sendGet(scannerInfo, url, StringUtils.EMPTY);
                    if (result.containsKey(DATA_LIST_TAG)) {
                        JSONObject data = JsonUtils.getJson(result, DATA_LIST_TAG);
                        data.put("type", SERVICE);
                        procData(data);
                    } else {
                        log.error("获取数据错误：" + result);
                    }
                } catch (Exception e) {
                    log.error(e.getMessage(), e);
                }
            }
        } catch (Exception e) {
            log.error(e.getMessage(), e);
        }
    }

    /**
     * 获取数据并解析
     */
    public static void procData(JSONObject jsonData) {
        try {
            String is_alive = JsonUtils.getStr(jsonData, "is_alive");
            //DEAD, ALIVE, UNKNOWN
            if (!"ALIVE".equalsIgnoreCase(is_alive)) {
                return;
            }
            String ip = null;
            if (jsonData.getString("type").equals(SERVICE)) {
                ip = JsonUtils.getStr(jsonData, ADDRESS);//主机IP
            } else if (jsonData.getString("type").equals(WEBSITE)) {
                String url = JsonUtils.getStr(jsonData, "url");
                String[] str = DataUtils.getIpAndPort(url);
                if (str.length > 0) {
                    ip = str[0];
                }
                if (!IpUtils.isIp(ip)) {
                    if (!IpUtils.isIp(ip)) {
                        log.error("空IP!!" + jsonData.toJSONString());
                        return;
                    }
                }
                String port = null;
                if (str.length > 1) {
                    port = str[1];
                }
                if (StrUtil.isNotBlank(port) && !"0".equals(port) && StringUtils.isNumeric(port)) {
                    AssetPort tbAssetPort = new AssetPort();
                    tbAssetPort.setIp(ip);
                    tbAssetPort.setPort(port);
                    tbAssetPort.setType(JsonUtils.getStr(jsonData, "title"));
                    tbAssetPort.setProto(null);
                    tbAssetPort.setCreateDate(new Date());
                    tbAssetPort.setSyncStatus(AssetSourceEnums.CHANGTING_CMDB.getCode());
                    tbAssetPort.setDevType("1");
                    PortSaveWork.magicQueue.put(tbAssetPort);
                }
            }
            if (!IpUtils.isIp(ip)) {
                if (!IpUtils.isIp(ip)) {
                    log.error("空IP!!" + jsonData.toJSONString());
                    return;
                }
            }

            // 创建时间
            String createTime = JsonUtils.getStr(jsonData, "createTime");
            // 修改时间
            String updateTime = JsonUtils.getStr(jsonData, "updateTime");
            // 最后存活时间
            String lastSurvivalTime = JsonUtils.getStr(jsonData, "last_survival_time");
            // 来源
            String origin = JsonUtils.getStr(jsonData, "origin");
            // 信息
            String information = JsonUtils.getStr(jsonData, "information");
            // 备注
            String remark = JsonUtils.getStr(jsonData, "remark");
            // 资产名称
            String hostname = JsonUtils.getStr(jsonData, "hostname");
            // 资产权重
            String weight = JsonUtils.getStr(jsonData, "weight");
            // 资产等级
            String assetSeverity = JsonUtils.getStr(jsonData, "asset_severity");
            // IP运营商
            String operator = JsonUtils.getStr(jsonData, "operator");
            // IP geo位置
            String internetGeolocation = JsonUtils.getStr(jsonData, "internet_geolocation");

            Asset asset = new Asset();
            asset.setInternalIp(ip);
            asset.setKeyAsset(DataUtils.toInt(AssetSeverEnum.getValueByName(assetSeverity)));
            asset.setRemarks(remark);
            asset.setInstance(hostname);
            asset.setHostName(hostname);
            asset.setGeographicLocation(internetGeolocation);
            asset.setEqualProtectionFirstTime(DateUtils.parseDateForGMT(lastSurvivalTime));
            saveAsset(asset);
        } catch (Exception e) {
            log.error(e.getMessage(), e);
        }
    }

    private static void saveAsset(Asset asset) {
        try {
            if (StringUtils.isBlank(asset.getInternalIp())) {
                return;
            }
            //资产类型：(服务器，通信网络设备，安全设备，物联网设备)
            /*
            服务器		["通用","Web","文件","数据库","云平台","其他服务器设备"]
           通信网络设备	["路由器","交换机","网络存储","无线网络","其他网络设备"]
           安全设备	["VPN产品","防火墙","远程审计堡垒机","漏洞扫描","网络入侵检测与防御","威胁分析与管理","防病毒网关","安全内容管理","其他安全设备","IPS","WAF","主机防护","容器防护","防病毒","态势感知","日志审计","数据库审计","堡垒机","威胁情报","蜜罐"]
           物联网设备	["视频监控","门禁系统","语音视频","工业控制","其他物联网设备"]
             */
            asset.setType("服务器");
            asset.setSubType("通用");
            //资产状态，可选项：1在用、2停用、3下架、4库存备用、5故障设备、6已临时关停、7待修、8在修、9闲置、10待报废、11报废、12转交
            asset.setOperatingStatus(1);
            // 设置为：长亭Waf
            asset.setSource(AssetSourceEnums.CHANGTING_CMDB.getCode());
            try {
                //数据来源，仅详情展示；1传统资源池CMDB、2华润云CMDB、3青藤、4D01、5"
                if (asset.getGeographicLocation() != null) {
                    if (asset.getGeographicLocation().contains("汕尾")) {
                        asset.setArea("汕尾数据中心");
                    } else if (asset.getGeographicLocation().contains("沙河")) {
                        asset.setArea("沙河灾备");
                    }
                }
                if (StringUtils.isBlank(asset.getInstance())) {
                    asset.setInstance(asset.getInternalIp());
                }
            } catch (Exception e) {
                log.error(e.getMessage(), e);
            }
            Asset oldAsset = CrcAssetSyncQueue.getInstance().getAssetFullByIp(asset.getInternalIp());
            if (CrcAssetSyncQueue.getInstance().saveAsset(asset)) {
                AssetRecordService assetRecordService = GetSpringBean.getBean(AssetRecordService.class);
                assetRecordService.addChangeRecord(oldAsset, CrcAssetSyncQueue.getInstance().getAssetFullByIp(asset.getInternalIp()));
            }
        } catch (Exception e) {
            log.error(e.getMessage(), e);
        }
    }


    private String getStr(String str) {
        if (StrUtil.isNotBlank(str)) {
            return str + "/";
        }
        return StringUtils.EMPTY;
    }


    private JSONObject getJsonParamters(int i, int pageSize) {
        JSONObject parms = new JSONObject();
        parms.put(LIMIT, pageSize);
        parms.put(OFFSET, (i - 1) * pageSize);
        parms.put("is_alive", "ALIVE");
        return parms;
    }
}

