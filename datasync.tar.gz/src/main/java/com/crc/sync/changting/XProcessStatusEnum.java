package com.crc.sync.changting;

import cn.hutool.core.util.StrUtil;

public enum XProcessStatusEnum {
    /**
     * 等待排期
     */
    APPOINT("APPOINT", "0", "等待排期"),

    /**
     * 等待扫描
     */
    QUEUING("QUEUING", "0", "等待扫描"),

    /**
     * 正在扫描
     */
    WORKING("WORKING", "1", "正在扫描"),

    /**
     * 扫描成功
     */
    FINISHED("FINISHED", "2", "扫描成功"),

    /**
     * 暂停
     */
    PAUSED("PAUSED", "3", "暂停"),

    /**
     * 部分阶段暂停
     */
    PARTIAL_PAUSED("PARTIAL_PAUSED", "3", "部分阶段暂停"),

    /**
     * 扫描失败
     */
    FAILED("FAILED", "4", "扫描失败"),
    ;
    private String name;
    private String value;
    private String desc;

    XProcessStatusEnum(String name, String value, String desc) {
        this.name = name;
        this.value = value;
        this.desc = desc;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getValue() {
        return value;
    }

    public void setValue(String value) {
        this.value = value;
    }

    public String getDesc() {
        return desc;
    }

    public void setDesc(String desc) {
        this.desc = desc;
    }

    public static XProcessStatusEnum getValueByName(String name) {
        if (StrUtil.isBlank(name)) {
            return null;
        }
        for (XProcessStatusEnum status : XProcessStatusEnum.values()) {
            if (status.getName().equals(name)) {
                return status;
            }
        }
        return null;
    }
}
