package com.crc.sync.marvelnet;

import com.alibaba.fastjson.JSONArray;
import com.alibaba.fastjson.JSONObject;
import com.crc.common.code.CreateInsert;
import com.crc.common.utils.*;
import com.crc.secface.config.GetSpringBean;
import com.crc.secface.domain.AssetPolicy;
import com.crc.secface.domain.SysDictData;
import com.crc.secface.mapper.CommonMapper;
import com.crc.sync.config.SyncSecConfigLoad;
import com.crc.sync.config.SyncSecConstants;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;

import java.util.Date;

@Slf4j
public class FirewallPolicySync extends Thread {
    @Override
    public void run() {
        while (true) {
            MyTheadUtils.sleepBySec(4 * 60);
            if (SyncSecConfigLoad.isEnable(SyncSecConstants.MAVELNET_SYNC_ENABLE)) {
                try {
                    sync();
                } catch (Exception e) {
                    log.error(e.getMessage(), e);
                }
                MyTheadUtils.sleepBySec(60 * 30);
            }
        }
    }

    private void sync() {
        SysDictData dict = DictUtil.getDictByLabel("mn_api_config", "policy_list_api_url");
        if (DataUtils.isBlankDict(dict)) {
            return;
        }
        String apiUrl = dict.getDictValue();
        if (StringUtils.isBlank(apiUrl)) {
            log.error("资产策略地址同步错误，请配置字典mn_api_config/policy_list_api_url");
            return;
        }
        JSONObject q = new JSONObject();
        q.put("page", 1);
        q.put("size", 1);
        CommonMapper commonMapper = GetSpringBean.getBean(CommonMapper.class);
        int total = getTotal(apiUrl, q);
        if (total > 0) {
            log.info("拉起M防火墙策略总数：" + total);
            int pageSize = 400;
            for (int i = 1; i <= DataUtils.getPageCount(total,pageSize,1); i++) {
                q.put("page", i);
                q.put("size", pageSize);
                try {
                    String ret = HttpUtils.sendPost(apiUrl, q.toJSONString());
                    JSONObject retJson = JsonUtils.parse(ret);
                    if ("S".equalsIgnoreCase(JsonUtils.getStr(retJson, "code")) && "查询成功".equals(JsonUtils.getStr(retJson, "msg"))) {
                        JSONArray dataArr = retJson.getJSONObject("data").getJSONArray("data");
                        if (dataArr != null) {
                            for (int j = 0; j < dataArr.size(); j++) {
                                try {

                                    JSONObject json = dataArr.getJSONObject(j);
                                    AssetPolicy assetPolicy = new AssetPolicy();
                                    assetPolicy.setBatchId(JsonUtils.getStr(json, "_id"));
                                    assetPolicy.setName(JsonUtils.getStr(json, "policy_name"));
                                    assetPolicy.setIp(JsonUtils.getStr(json, "device_ip"));
                                    assetPolicy.setAreaInteface(getZone(json));
                                    assetPolicy.setSrcAddr(JsonUtils.getListToStr(json, "source_address"));
                                    assetPolicy.setDstAddr(JsonUtils.getListToStr(json, "dest_address"));
                                    assetPolicy.setBehavor(JsonUtils.getStr(json, "action"));
                                    assetPolicy.setStatus(JsonUtils.getBoolean(json, "status") ? "accept" : "reject");
                                    assetPolicy.setRemark(JsonUtils.getStr(json, "policy_desc"));
                                    assetPolicy.setServ(getServ(json));
                                    assetPolicy.setDelFlag("0");
                                    assetPolicy.setCreateTime(DateUtils.getDateTimeString1(new Date()));
                                    if (commonMapper.getCount("select count(1) from tb_asset_policy where del_flag = '0' and batch_id = '" + assetPolicy.getBatchId() + "'") < 1) {
                                        CreateInsert<AssetPolicy> createInsert = new CreateInsert<>();
                                        String sql = createInsert.createinsert(assetPolicy, "tb_asset_policy");
                                        commonMapper.exeSQL(sql);
                                    } else {
                                        String upSQL = "update tb_asset_policy set src_addr='%s',dst_addr='%s',status = '%s',behavor='%s',update_time=now(),serv='%s' where batch_id = '%s'";
                                        commonMapper.exeSQL(String.format(upSQL, assetPolicy.getSrcAddr(), assetPolicy.getDstAddr(), assetPolicy.getStatus(), assetPolicy.getBehavor(), assetPolicy.getServ(), assetPolicy.getBehavor()));
                                    }
                                } catch (Exception e) {
                                    log.error(e.getMessage(), e);
                                }
                            }
                        }
                    }
                } catch (Exception e) {
                    log.error(e.getMessage(), e);
                }
            }
        }
    }

    private String getServ(JSONObject json) {
        //"service_port": [        服务对象名称
        //          {
        //            "dst_port": "tcp_443",
        //            "src_port": "tcp_0to65535"
        //          }
        //        ],
        JSONArray service_port = json.getJSONArray("service_port");
        if (service_port != null && service_port.size() > 0) {
            JSONObject jsonObject = service_port.getJSONObject(0);
            String ret = "";
            if (jsonObject.containsKey("src_port"))
                ret += "src_port :" + jsonObject.getString("src_port");
            if (jsonObject.containsKey("dst_port"))
                ret += ",dst_port :" + jsonObject.getString("dst_port");
            return ret;
        }
        return "";
    }

    private String getZone(JSONObject json) {
        JSONArray source_zone = json.getJSONArray("source_zone");
        JSONArray dest_zone = json.getJSONArray("dest_zone");
        String ret = "";
        if (source_zone != null && source_zone.size() > 0) {
            ret = "FROM :" + source_zone.getString(0);
        }
        if (dest_zone != null && dest_zone.size() > 0) {
            ret = ret + ",TO :" + dest_zone.getString(0);
        }
        return ret;
    }

    public int getTotal(String url, JSONObject jsonObject) {
        try {
            String ret = HttpUtils.sendPost(url, jsonObject.toJSONString());
            JSONObject retJson = JsonUtils.parse(ret);
            if ("S".equalsIgnoreCase(JsonUtils.getStr(retJson, "code")) && "查询成功".equals(JsonUtils.getStr(retJson, "msg"))) {
                return retJson.getJSONObject("data").getIntValue("count");
            }
        } catch (Exception e) {
            log.error(e.getMessage(), e);
        }
        return 0;
    }
}
