package com.crc.sync.foradar.frapi;

import com.alibaba.fastjson.JSONArray;
import com.alibaba.fastjson.JSONObject;
import com.crc.common.utils.HttpUtils;
import com.crc.common.utils.JsonUtils;
import com.crc.scanner.config.ForadarConfig;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.codec.digest.DigestUtils;

/**
 * Foradar http客户端
 *
 * @author: 村长
 * @date: 2023-03-01 17:03:43
 */

@Slf4j
public class ForadarHttpClient {

    /**
     * 返回key
     */
    protected static final String RESULT_DATA = "data";
    /**
     * 返回数组
     */
    protected static final String RESULT_ITEMS = "items";
    protected static final String RESULT_LIST = "list";
    /**
     * 最后一页
     */
    protected static final String LAST_PAGE = "last_page";

    /**
     * token
     */
    private static String ACCESS_TOKEN;
    /**
     * 对接秘钥
     */
    private static String SECRET_KEY;
    /**
     * 服务器地址
     */
    private static String URL;
    /**
     * 邮箱
     */
    private static String EMAIL;
    private static String proxyIp;
    private static int proxyPort;
    private static boolean proxy;


    /**
     * @param config 配置
     * @throws Exception 获取token异常
     */
    public ForadarHttpClient(ForadarConfig config) {
        ForadarHttpClient.URL = config.getAddress();
        ForadarHttpClient.SECRET_KEY = config.getSecretKey();
        ForadarHttpClient.EMAIL = config.getEmail();
        ForadarHttpClient.proxyIp = config.getProxyIp();
        ForadarHttpClient.proxyPort = config.getProxyPort();
        ForadarHttpClient.proxy = config.isProxy();
        ForadarHttpClient.ACCESS_TOKEN = getToken();
    }

    /**
     * 获取Token
     */
    public String getToken() {
        try {
            String parameter = "email=" + EMAIL + "&page=1&size=10&timestamp=" + System.currentTimeMillis() / 1000;
            String stringSignTemp = parameter + "&secret_key=" + SECRET_KEY;
            String sig = DigestUtils.md5Hex(stringSignTemp).toUpperCase();
            parameter = parameter + "&sign=" + sig;
            String ret = "";
            if (!proxy) {
                ret = HttpUtils.sendGet(URL + "/api/v1/auth/gen_api_token", parameter);
            } else {
                ret = HttpUtils.sendGetProxy(URL + "/api/v1/auth/gen_api_token", parameter, proxyIp, proxyPort);
            }
            JSONObject retJson = JsonUtils.parse(ret);
            if (JsonUtils.equal(retJson, "code", "0")) {
                JSONObject jsonObject = retJson.getJSONObject(RESULT_DATA);
                if (jsonObject != null && jsonObject.containsKey("access_token")) {
                    String token = JsonUtils.getStr(jsonObject, "access_token");
                    log.info("成功获取token：{}", token);
                    return token;
                }
            } else {
                log.info("获取token失败：{}", ret);
            }
        } catch (Exception e) {
            log.error(e.getMessage(), e);
        }
        log.info("成功获取token失败");
        return null;
    }

    /**
     * 通用获取页数
     *
     * @param path URL后缀
     * @return
     */
    public long commonTotal(String path) {
        try {
            JSONObject headers = getHeaders();
            String ret = "";
            if (!proxy) {
                ret = HttpUtils.sendGet(URL + path, null, headers);
            } else {
                ret = HttpUtils.sendGetProxy(URL + path, null, headers, proxyIp, proxyPort);
            }
            JSONObject retJson = JsonUtils.parse(ret);
            if (JsonUtils.equal(retJson, "code", "0")) {
                JSONObject jsonObject = retJson.getJSONObject(RESULT_DATA);
                if (jsonObject != null && jsonObject.containsKey("total")) {
                    long token = JsonUtils.getLong(jsonObject, "total");
                    log.info("{}成功获取total：{}", path, token);
                    return token;
                } else {
                    if (jsonObject != null && jsonObject.containsKey(RESULT_LIST)) {
                        JSONObject listJson = jsonObject.getJSONObject(RESULT_LIST);
                        if (listJson != null && listJson.containsKey("total")) {
                            long token = JsonUtils.getLong(listJson, "total");
                            log.info("{}成功获取total：{}", path, token);
                            return token;
                        }
                    }
                }
            } else {
                log.info("获取total失败：{}", ret);
            }
        } catch (Exception e) {
            log.error(path + e.getMessage(), e);
            return -1;
        }
        return 0;
    }

    /**
     * 通用GET
     *
     * @param path URL后缀
     * @return
     */
    public JSONArray commonGetItems(String path) {
        try {
            JSONObject headers = getHeaders();
            String ret = "";
            if (!proxy) {
                ret = HttpUtils.sendGet(URL + path, null, headers);
            } else {
                ret = HttpUtils.sendGetProxy(URL + path, null, headers, proxyIp, proxyPort);
            }
            //log.info(ret);
            JSONObject retJson = JsonUtils.parse(ret);
            if (JsonUtils.equal(retJson, "code", "0")) {
                JSONObject jsonObject = retJson.getJSONObject(RESULT_DATA);
                if (jsonObject != null && jsonObject.containsKey(RESULT_ITEMS)) {
                    JSONArray jsonArray = jsonObject.getJSONArray(RESULT_ITEMS);
                    log.info("{}成功获取：{}", path, jsonArray == null ? 0 : jsonArray.size());
                    return jsonArray;
                }
            } else {
                log.info("获取Items失败：{}", ret);
            }
        } catch (Exception e) {
            log.error(path + e.getMessage(), e);
        }
        return new JSONArray();
    }

    /**
     * 通用GET
     *
     * @param path URL后缀
     * @return
     */
    public JSONArray commonGetList(String path) {
        try {
            JSONObject headers = getHeaders();
            String ret = "";
            if (!proxy) {
                ret = HttpUtils.sendGet(URL + path, null, headers);
            } else {
                ret = HttpUtils.sendGetProxy(URL + path, null, headers, proxyIp, proxyPort);
            }
            //log.info(ret);
            JSONObject retJson = JsonUtils.parse(ret);
            if (JsonUtils.equal(retJson, "code", "0")) {
                JSONObject jsonObject = retJson.getJSONObject(RESULT_DATA);
                if (jsonObject != null && jsonObject.containsKey(RESULT_LIST)) {
                    JSONObject listJson = jsonObject.getJSONObject(RESULT_LIST);
                    if (listJson != null && listJson.containsKey(RESULT_DATA)) {
                        JSONArray jsonArray = listJson.getJSONArray(RESULT_DATA);
                        log.info("{}成功获取：{}", path, jsonArray == null ? 0 : jsonArray.size());
                        return jsonArray;
                    }
                }
            } else {
                log.info("获取DataList失败：{}", ret);
            }
        } catch (Exception e) {
            log.error(path + e.getMessage(), e);
        }
        return new JSONArray();
    }

    /**
     * 构建请求头
     */
    public static JSONObject getHeaders() {
        JSONObject headers = new JSONObject();
        headers.put("Accept", "*/*");
        headers.put("Content-Type", "application/json");
        headers.put("Authorization", "Bearer " + ACCESS_TOKEN);
        return headers;
    }
}
