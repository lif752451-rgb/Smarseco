package com.crc.sync.foradar.info;

/**
 * 数据泄露文库
 * @author: 村长
 * @date: 2023-03-02 14:30:05
 */
public class DataLeak {

  /** id */
  private Integer id;
  /** userId */
  private Integer userId;
  /** companyId */
  private Integer companyId;
  /** 企业名称 */
  private String companyName;
  /** 关键字词 */
  private String keyword;
  /** 泄漏链接 */
  private String url;
  /** 文件名 */
  private String name;
  /** 截图 */
  private String imgUrl;
  /** 平台 */
  private String platName;

  /**
   * 状态
   * 0  待处理
   * 1  已确认
   *  */
  private Integer status;

  public Integer getId() {
    return id;
  }

  public void setId(Integer id) {
    this.id = id;
  }

  public Integer getUserId() {
    return userId;
  }

  public void setUserId(Integer userId) {
    this.userId = userId;
  }

  public Integer getCompanyId() {
    return companyId;
  }

  public void setCompanyId(Integer companyId) {
    this.companyId = companyId;
  }

  public String getCompanyName() {
    return companyName;
  }

  public void setCompanyName(String companyName) {
    this.companyName = companyName;
  }

  public String getKeyword() {
    return keyword;
  }

  public void setKeyword(String keyword) {
    this.keyword = keyword;
  }

  public String getUrl() {
    return url;
  }

  public void setUrl(String url) {
    this.url = url;
  }

  public String getName() {
    return name;
  }

  public void setName(String name) {
    this.name = name;
  }

  public String getImgUrl() {
    return imgUrl;
  }

  public void setImgUrl(String imgUrl) {
    this.imgUrl = imgUrl;
  }

  public Integer getStatus() {
    return status;
  }

  public void setStatus(Integer status) {
    this.status = status;
  }

  public String getPlatName() {
    return platName;
  }

  public void setPlatName(String platName) {
    this.platName = platName;
  }
}
