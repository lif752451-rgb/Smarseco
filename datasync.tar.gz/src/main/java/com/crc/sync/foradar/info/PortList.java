package com.crc.sync.foradar.info;

import lombok.Data;

import java.util.List;

/**
 * 资产详情
 * @author: 村长
 * @date: 2023-03-01 16:40:39
 */

@Data
public class PortList {

  /** 是否开放 */
  private Integer isOpen;
  /** 网站标题 */
  private String title;
  /** url */
  private String url;
  /** 协议 */
  private String protocol;
  /** 端口 */
  private String port;
  /** 域名 */
  private String subdomain;
  /** 公司名称 */
  private List<String> clueCompanyName;
}
