package com.crc.sync.foradar.info;

import lombok.Data;

/**
 * 数据泄露网盘
 * @author: 村长
 * @date: 2023-03-02 14:30:05
 */
@Data
public class LeakagePan {

  /** id */
  private Integer id;
  /** userId */
  private Integer userId;
  /** companyId */
  private Integer companyId;
  /** 企业名称 */
  private String companyName;
  /** 关键字词 */
  private String keyword;
  /** 泄漏链接 */
  private String url;
  /** 文件名 */
  private String name;
  /** 截图 */
  private String imgUrl;
  /**
   * 状态
   * 0  待处理
   * 1  已确认
   *  */
  private Integer status;
}
