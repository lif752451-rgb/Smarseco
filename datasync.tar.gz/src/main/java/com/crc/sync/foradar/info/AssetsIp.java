package com.crc.sync.foradar.info;

import lombok.Data;

import java.util.List;

/**
 * IP资产台账列表
 *
 * @author: 村长
 * @date: 2023-02-28 10:15:23
 */
@Data
public class AssetsIp {

  private String id;
  /**
   * 企业名称
   */
  private List<String> clueCompanyName;
  /** 创建时间 */
  private String createTime;
  /** 经纬度 */
  private Geo geo;
  /** ip */
  private String ip;
  /** 更新时间 */
  private String lastUpdateTime;
  /** 纬度 */
  private String latitude;
  /** 经度 */
  private String longitude;
  /**  资产状态  多选；0：离线 ，1：在线 */
  private Long onlineState;
  /** 端口列表 */
  private List<PortList> portList;
  private List<PortList> detail;
  /** 端口数量 */
  private Long portSize;
  /** 用户id */
  private Long userId;
}
