package com.crc.sync.foradar;

import com.baomidou.mybatisplus.core.conditions.query.LambdaQueryWrapper;
import com.baomidou.mybatisplus.core.toolkit.StringUtils;
import com.baomidou.mybatisplus.core.toolkit.Wrappers;
import com.crc.common.code.SimpleCodeTool;
import com.crc.common.enums.ScannerEnums;
import com.crc.common.utils.DataUtils;
import com.crc.common.utils.IdGen;
import com.crc.common.utils.IpUtils;
import com.crc.common.utils.MyTheadUtils;
import com.crc.scanner.config.ForadarConfig;
import com.crc.secface.config.GetSpringBean;
import com.crc.secface.domain.*;
import com.crc.secface.mapper.AssetAsmDomainMapper;
import com.crc.secface.mapper.AssetAsmInfoLeakMapper;
import com.crc.secface.mapper.AssetAsmInternetMapper;
import com.crc.secface.mapper.AssetAsmPortMapper;
import com.crc.secface.schedule.assemble.CommonAssemble;
import com.crc.sync.foradar.frapi.ForadarClient;
import com.crc.sync.foradar.info.AssetsDomain;
import com.crc.sync.foradar.info.AssetsIp;
import com.crc.sync.foradar.info.DataLeak;
import com.crc.sync.foradar.info.PortList;
import com.crc.sync.safedog.sdapi.SdapiHttpClient;
import lombok.extern.slf4j.Slf4j;

import java.util.Date;
import java.util.List;

/**
 * Foradar数据同步
 */
@Slf4j
public class ForadarAllDataSync {
    public void sync() {
        try {
            CommonAssemble.engineMap.forEach((k, v) -> {
                if (ScannerEnums.FORADAR_SCANNER.getCode().equals(v.getEquipmentManufacture())) {
                    //IP资产、疑似资产、威胁资产
                    syncInternetIpList(getForadarConfig(k));
                    //syncUnsureIpList(getForadarConfig(k));
                    syncThreatenIpList(getForadarConfig(k));
                    //域名资产
                    syncDomainList(getForadarConfig(k));
                    //数据泄露
                    syncDataLeakList(getForadarConfig(k));
                }
            });
        } catch (Exception e) {
            log.error(e.getMessage(), e);
        }
    }

    private void syncDataLeakList(ForadarConfig config) {
        AssetAsmInfoLeakMapper assetAsmInfoLeakMapper = GetSpringBean.getBean(AssetAsmInfoLeakMapper.class);
        //1网盘 2文库 3代码仓库
        for (int type = 1; type <= 3; type++) {
            try {
                ForadarClient foradarClient = new ForadarClient(config);
                long total = foradarClient.commonTotal("/api/v1/leakage?status=1&type=" + type + "&page=1&per_page=10");
                log.info("数据泄露 syncDataLeakList={},total={}", type, total);
                if (total > 0) {
                    try {
                        for (int i = 1; i < DataUtils.getPageCount(total, SdapiHttpClient.PAGE_SIZE, 1); i++) {
                            // 接口每分钟只能请求100次
                            MyTheadUtils.sleepBySec(1);
                            List<DataLeak> list = foradarClient.getDataLeakList(String.valueOf(type), i);
                            if (list != null) {
                                log.info("getDataLeakList,,total={}", list.size());
                                for (DataLeak dl : list) {
                                    AssetAsmInfoLeak assetAsmInfoLeak = new AssetAsmInfoLeak();
                                    assetAsmInfoLeak.setDelFlag("0");
                                    assetAsmInfoLeak.setSource(dl.getPlatName());
                                    if (type == 3)
                                        assetAsmInfoLeak.setType("1");
                                    else if (type == 2) {
                                        assetAsmInfoLeak.setType("2");
                                    } else if (type == 1) {
                                        assetAsmInfoLeak.setType("2");
                                    } else {
                                        assetAsmInfoLeak.setType("2");
                                    }
                                    assetAsmInfoLeak.setUrl(dl.getUrl());
                                    assetAsmInfoLeak.setContentSummary(dl.getName());
                                    assetAsmInfoLeak.setLabel(dl.getKeyword());
                                    if (StringUtils.isNotBlank(dl.getImgUrl())) {
                                        int pos = dl.getImgUrl().lastIndexOf(".");
                                        assetAsmInfoLeak.setFileSuffix(dl.getImgUrl().substring(pos));
                                    }

                                    try {
                                        LambdaQueryWrapper<AssetAsmInfoLeak> q = Wrappers.lambdaQuery();
                                        q.eq(AssetAsmInfoLeak::getType, assetAsmInfoLeak.getType());
                                        q.eq(AssetAsmInfoLeak::getUrl, assetAsmInfoLeak.getUrl());
                                        q.last(" limit 1");
                                        AssetAsmInfoLeak tmp = assetAsmInfoLeakMapper.selectOne(q);
                                        if (tmp == null) {
                                            assetAsmInfoLeak.setInfoId("IL-" + IdGen.uuid8());
                                            assetAsmInfoLeak.setUpdateTime(new Date());
                                            assetAsmInfoLeak.setCreateTime(new Date());
                                            assetAsmInfoLeakMapper.insert(assetAsmInfoLeak);
                                        } else {
                                            assetAsmInfoLeak.setId(tmp.getId());
                                            assetAsmInfoLeak.setUpdateTime(new Date());
                                            assetAsmInfoLeakMapper.updateAssetAsmInfoLeak(assetAsmInfoLeak);
                                        }
                                    } catch (Exception e) {
                                        log.error(e.getMessage(), e);
                                    }
                                }
                            }
                        }
                    } catch (Exception e) {
                        log.error(e.getMessage(), e);
                    }
                }
            } catch (Exception e) {
                log.error(e.getMessage(), e);
            }
        }

    }

    private void syncThreatenIpList(ForadarConfig config) {
        try {
            ForadarClient foradarClient = new ForadarClient(config);
            long total = foradarClient.commonTotal("/api/v1/threaten/assets?status%5B0%5D=3&page=1&per_page=10");
            log.info("互联网IP清单 syncThreatenIpList,,total={}", total);
            if (total > 0) {
                saveIpData(foradarClient, total, 3);
            }
        } catch (Exception e) {
            log.error(e.getMessage(), e);
        }
    }

    private void syncUnsureIpList(ForadarConfig config) {
        try {
            ForadarClient foradarClient = new ForadarClient(config);
            long total = foradarClient.commonTotal("/api/v1/unsure/assets?status%5B0%5D=0&page=1&per_page=10");
            log.info("互联网IP清单 syncUnsureIpList,,total={}", total);
            if (total > 0) {
                saveIpData(foradarClient, total, 2);
            }
        } catch (Exception e) {
            log.error(e.getMessage(), e);
        }
    }


    public static ForadarConfig getForadarConfig(Long engineId) {
        EngineEquipmentManagement engine = CommonAssemble.engineMap.get(engineId);
        ForadarConfig qtConfig = new ForadarConfig();
        if (engine == null || engine.getId() == null) {
            return qtConfig;
        }
        qtConfig.setEngineId(engineId);
        qtConfig.setAddress(engine.getEquipmentAddress());
        qtConfig.setSecretKey(engine.getPassword());
        qtConfig.setProxy(false);
        if (StringUtils.isNotBlank(engine.getEquipmentCapabilities())) {
            //是否有代理
            if (engine.getEquipmentCapabilities().contains(":")) {
                String ip = engine.getEquipmentCapabilities().split(":")[0];
                String port = engine.getEquipmentCapabilities().split(":")[1];
                if (IpUtils.isIp(ip) && DataUtils.toInt(port) > 0) {
                    qtConfig.setProxyIp(ip);
                    qtConfig.setProxyPort(DataUtils.toInt(port));
                    qtConfig.setProxy(true);
                }
            }
        }
        String PASS = qtConfig.getSecretKey().trim();
        try {
            PASS = SimpleCodeTool.decrypt(PASS);
            qtConfig.setSecretKey(PASS);
        } catch (Exception e) {
            log.error(e.getMessage(), e);
        }
        qtConfig.setEmail(engine.getLoginUser());
        return qtConfig;
    }

    /**
     * 域名清单
     *
     * @param config 配置
     */
    private void syncDomainList(ForadarConfig config) {
        try {
            ForadarClient foradarClient = new ForadarClient(config);
            long total = foradarClient.commonTotal("/api/v1/domain_assets/list?page=1&per_page=10");
            log.info("域名清单 domain_assets,,total={}", total);
            if (total > 0) {
                AssetAsmDomainMapper assetAsmDomainMapper = GetSpringBean.getBean(AssetAsmDomainMapper.class);
                for (int i = 1; i < DataUtils.getPageCount(total, SdapiHttpClient.PAGE_SIZE, 1); i++) {
                    // 接口每分钟只能请求100次
                    MyTheadUtils.sleepBySec(1);
                    List<AssetsDomain> list = foradarClient.getAssetsDomainList(i);
                    if (list != null) {
                        log.info("AssetsDomain,,total={}", list.size());
                        for (AssetsDomain ai : list) {
                            ForadarToF5Sync.sync(ai);
                            AssetAsmDomain asmInternet = new AssetAsmDomain();

                            asmInternet.setDelFlag("0");
                            asmInternet.setDomainName(ai.getDomain());
                            asmInternet.setOrganizerName(ai.getCompanyName());
                            try {
                                LambdaQueryWrapper<AssetAsmDomain> q = Wrappers.lambdaQuery();
                                q.eq(AssetAsmDomain::getDomainName, ai.getDomain());
                                q.last(" limit 1");
                                AssetAsmDomain tmp = assetAsmDomainMapper.selectOne(q);
                                if (tmp == null) {
                                    asmInternet.setUpdateTime(new Date());
                                    asmInternet.setCreateTime(new Date());
                                    assetAsmDomainMapper.insert(asmInternet);
                                } else {
                                    asmInternet.setId(tmp.getId());
                                    asmInternet.setUpdateTime(new Date());
                                    assetAsmDomainMapper.updateAssetAsmDomain(asmInternet);
                                }
                            } catch (Exception e) {
                                log.error(e.getMessage(), e);
                            }
                        }
                    }
                }
            }
        } catch (Exception e) {
            log.error(e.getMessage(), e);
        }
    }


    /**
     * 互联网IP清单
     *
     * @param config 配置
     */
    private void syncInternetIpList(ForadarConfig config) {

        try {
            ForadarClient foradarClient = new ForadarClient(config);
            long total = foradarClient.commonTotal("/api/v1/assets/account?second_confirm=1&page=1&per_page=10");
            log.info("互联网IP清单 getAssetsIpList,,total={}", total);
            if (total > 0) {
                saveIpData(foradarClient, total, 1);
            }
        } catch (Exception e) {
            log.error(e.getMessage(), e);
        }
    }

    private void saveIpData(ForadarClient foradarClient, long total, int type) {
        AssetAsmInternetMapper assetAsmInternetMapper = GetSpringBean.getBean(AssetAsmInternetMapper.class);
        AssetAsmPortMapper assetAsmPortMapper = GetSpringBean.getBean(AssetAsmPortMapper.class);
        for (int i = 1; i < DataUtils.getPageCount(total, SdapiHttpClient.PAGE_SIZE, 1); i++) {
            // 接口每分钟只能请求100次
            MyTheadUtils.sleepBySec(1);
            List<AssetsIp> list = null;
            if (type == 1) {
                list = foradarClient.getAssetsIpList(i);
            } else if (type == 2) {
                list = foradarClient.getUnsureIpList(i);
            } else if (type == 3) {
                list = foradarClient.getThreatenIpList(i);
            }
            if (list != null) {
                log.info("getAssetsIpList,,total={}", list.size());
                for (AssetsIp ai : list) {
                    if (!IpUtils.isIp(ai.getIp())) {
                        continue;
                    }
                    if (ai.getPortList() == null) {
                        ai.setPortList(ai.getDetail());
                    }else{
                        if (ai.getDetail() != null) {
                            ai.getPortList().addAll(ai.getDetail());
                        }
                    }
                    if (ai.getPortList() != null) {
                        for (PortList pl : ai.getPortList()) {
                            AssetAsmInternet asmInternet = new AssetAsmInternet();
                            asmInternet.setIp(ai.getIp());
                            asmInternet.setPort(pl.getPort());
                            asmInternet.setDomainName(pl.getSubdomain());
                            asmInternet.setAccessAddress(pl.getUrl());
                            asmInternet.setDataSource("攻击面自动探测");
                            asmInternet.setUseStatus(1);
                            if (pl.getClueCompanyName() != null && pl.getClueCompanyName().size() > 0) {
                                asmInternet.setWebServiceName(pl.getClueCompanyName().get(0));
                            }
                            asmInternet.setWebTitle(pl.getTitle());
                            if (pl.getProtocol() != null) {
                                if (pl.getProtocol().equalsIgnoreCase("https")) {
                                    asmInternet.setAgreement(3);
                                } else if (pl.getProtocol().equalsIgnoreCase("http")) {
                                    asmInternet.setAgreement(2);
                                }
                            }
                            ForadarToF5Sync.sync(asmInternet, ai.getGeo(), pl);
                            try {
                                LambdaQueryWrapper<AssetAsmInternet> q = Wrappers.lambdaQuery();
                                q.eq(AssetAsmInternet::getIp, ai.getIp());
                                q.eq(AssetAsmInternet::getPort, asmInternet.getPort());
                                q.eq(AssetAsmInternet::getAccessAddress,asmInternet.getAccessAddress());
                                q.last(" limit 1");
                                AssetAsmInternet tmp = assetAsmInternetMapper.selectOne(q);
                                if (tmp == null) {
                                    asmInternet.setAssetId("IA-" + IdGen.uuid8());
                                    asmInternet.setUpdateTime(new Date());
                                    asmInternet.setCreateTime(new Date());
                                    assetAsmInternetMapper.insert(asmInternet);
                                } else {
                                    int index = 0;
                                    if (StringUtils.isNotBlank(asmInternet.getWebTitle())) {
                                        tmp.setWebTitle(asmInternet.getWebTitle());
                                        index++;
                                    }
                                    if (StringUtils.isNotBlank(asmInternet.getWebServiceName())) {
                                        tmp.setWebServiceName(asmInternet.getWebServiceName());
                                        index++;
                                    }
                                    if (StringUtils.isNotBlank(asmInternet.getDomainName())) {
                                        tmp.setDomainName(asmInternet.getDomainName());
                                        index++;
                                    }
                                    if (StringUtils.isNotBlank(asmInternet.getAccessAddress())) {
                                        tmp.setAccessAddress(asmInternet.getAccessAddress());
                                        index++;
                                    }
                                    if (index > 0) {
                                        asmInternet.setId(tmp.getId());
                                        asmInternet.setUseStatus(1);
                                        asmInternet.setUpdateTime(new Date());
                                        assetAsmInternetMapper.updateAssetAsmInternet(tmp);
                                    }
                                }
                            } catch (Exception e) {
                                log.error(e.getMessage(), e);
                            }

                            if (asmInternet.getPort() != null && DataUtils.toInt(asmInternet.getPort()) > 0) {
                                try {
                                    LambdaQueryWrapper<AssetAsmPort> q = Wrappers.lambdaQuery();
                                    q.eq(AssetAsmPort::getSrcIp, asmInternet.getIp());
                                    q.eq(AssetAsmPort::getSrcPort, asmInternet.getPort());
                                    q.last(" limit 1");
                                    AssetAsmPort assetAsmPort = new AssetAsmPort();
                                    assetAsmPort.setSrcIp(asmInternet.getIp());
                                    assetAsmPort.setSrcPort(asmInternet.getPort());
                                    assetAsmPort.setDestIp(asmInternet.getIp());
                                    assetAsmPort.setDestPort(asmInternet.getPort());
                                    assetAsmPort.setStatus("1");
                                    assetAsmPort.setDelFlag("0");
                                    AssetAsmPort tmp = assetAsmPortMapper.selectOne(q);
                                    if (tmp == null) {
                                        assetAsmPort.setCreateTime(new Date());
                                        assetAsmPort.setUpdateTime(new Date());
                                        assetAsmPortMapper.insert(assetAsmPort);
                                    } else {
                                        assetAsmPort.setId(tmp.getId());
                                        assetAsmPort.setUpdateTime(new Date());
                                        assetAsmPortMapper.updateAssetAsmPort(assetAsmPort);
                                    }
                                } catch (Exception e) {
                                    log.error(e.getMessage(), e);
                                }
                            }
                        }
                    }else {

                    }
                }
            }
        }
    }
}
