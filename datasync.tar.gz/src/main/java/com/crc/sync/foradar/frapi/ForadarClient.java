package com.crc.sync.foradar.frapi;

import com.alibaba.fastjson.JSONArray;
import com.alibaba.fastjson.JSONObject;
import com.crc.scanner.config.ForadarConfig;
import com.crc.sync.foradar.info.*;

import java.util.ArrayList;
import java.util.List;

/**
 * 互联网资产攻击面管理平台客户端
 *
 * @author: 村长
 * @date: 2023-02-22 18:29:37
 */
public class ForadarClient extends ForadarHttpClient {

    /**
     * @param config   配置
     * @throws Exception 获取token异常
     */
    public ForadarClient(ForadarConfig config) {
        super(config);
    }

    /**
     * 获取疑似资产列表
     *
     * @return
     */
    public List<AssetsIp> getUnsureIpList(int page) {
        JSONArray data = commonGetItems("/api/v1/unsure/assets?status%5B0%5D=0&page=" + page + "&per_page=100");
        if (data != null && data.size() > 0) {
            return JSONObject.parseArray(data.toJSONString(), AssetsIp.class);
        }
        return new ArrayList<>();
    }

    public List<AssetsIp> getThreatenIpList(int page) {
        JSONArray data = commonGetItems("/api/v1/threaten/assets?status%5B0%5D=3&page=" + page + "&per_page=100");
        if (data != null && data.size() > 0) {
            return JSONObject.parseArray(data.toJSONString(), AssetsIp.class);
        }
        return new ArrayList<>();
    }

    /**
     * 获取IP资产列表--second_confirm=0是未确权，1是已确权
     *
     * @return
     */
    public List<AssetsIp> getAssetsIpList(int page) {
        JSONArray data = commonGetItems("/api/v1/assets/account?second_confirm=1&page=" + page + "&per_page=100");
        if (data != null && data.size() > 0) {
            return JSONObject.parseArray(data.toJSONString(), AssetsIp.class);
        }
        return new ArrayList<>();
    }

    /**
     * 获取域名资产列表
     *
     * @return
     */
    public List<AssetsDomain> getAssetsDomainList(int page) {
        JSONArray data = commonGetItems("/api/v1/domain_assets/list?page=" + page + "&per_page=100");
        if (data != null && data.size() > 0) {
            return JSONObject.parseArray(data.toJSONString(), AssetsDomain.class);
        }
        return new ArrayList<>();
    }

    /**
     * 获取证书资产列表
     *
     * @return
     */
    public List<AssetsCert> getAssetsCertList(int page) {
        JSONArray data = commonGetItems("/api/v1/cert_assets?page=" + page + "&per_page=100");
        if (data != null && data.size() > 0) {
            return JSONObject.parseArray(data.toJSONString(), AssetsCert.class);
        }
        return new ArrayList<>();
    }

    /**
     * 获取数字资产App列表 status=1是已确认，删除是获取全部
     *
     * @return
     */
    public List<AssetsDataApp> getAssetsDataAppList(int page) {
        JSONArray list = commonGetList("/api/v1/data_assets?type=6&status=1&page=" + page + "&per_page=100");
        if (list != null && list.size() > 0) {
            return JSONObject.parseArray(list.toJSONString(), AssetsDataApp.class);
        }
        return new ArrayList<>();
    }

    /**
     * 获取数字资产台账微信小程序列表
     *
     * @return
     */
    public List<AssetsDataApplet> getAssetsDataAppletList(int page) {
        JSONArray list = commonGetList("/api/v1/data_assets?type=5&page=" + page + "&per_page=100");
        if (list != null && list.size() > 0) {
            return JSONObject.parseArray(list.toJSONString(), AssetsDataApplet.class);
        }
        return new ArrayList<>();
    }

    /**
     * 获取数字资产台账微信公众号列表
     *
     * @return
     */
    public List<AssetsDataWeiXin> getAssetsDataWeiXinList(int page) {
        JSONArray list = commonGetList("/api/v1/data_assets?type=4&page=" + page + "&per_page=100");
        if (list != null && list.size() > 0) {
            return JSONObject.parseArray(list.toJSONString(), AssetsDataWeiXin.class);
        }
        return new ArrayList<>();
    }

    /**
     * 获取数据泄露列表 status=1是已确认，删除是获取全部
     *
     * @param type 数据泄漏类型 1网盘 2文库 3代码仓库
     * @return
     */
    public List<DataLeak> getDataLeakList(String type, int page) {
        JSONArray list = commonGetList("/api/v1/leakage?status=1&type=" + type + "&page=" + page + "&per_page=100");
        if (list != null && list.size() > 0) {
            return JSONObject.parseArray(list.toJSONString(), DataLeak.class);
        }
        return new ArrayList<>();
    }
}
