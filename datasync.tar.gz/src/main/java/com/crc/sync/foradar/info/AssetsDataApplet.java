package com.crc.sync.foradar.info;

/**
 * 数字资产台账小程序列表
 * @author: 村长
 * @date: 2023-03-02 14:12:45
 */
public class AssetsDataApplet {

  /** id */
  private Integer id;
  /** userId */
  private Integer userId;
  /** companyId */
  private Integer companyId;
  /** 企业名称 */
  private String companyName;
  /** AppID */
  private String account;
  /** 简介 */
  private String description;
  /** 首次发现时间 */
  private String createdAt;
  /** 最近发现时间 */
  private String updatedAt;
  /** logo */
  private String logo;
  /** 小程序名称 */
  private String name;
  /** 帐号主体 */
  private String owner;
  /**
   * 状态
   * 0  待处理
   * 1  已确认
   *  */
  private Integer status;

  public Integer getId() {
    return id;
  }

  public void setId(Integer id) {
    this.id = id;
  }

  public Integer getUserId() {
    return userId;
  }

  public void setUserId(Integer userId) {
    this.userId = userId;
  }

  public Integer getCompanyId() {
    return companyId;
  }

  public void setCompanyId(Integer companyId) {
    this.companyId = companyId;
  }

  public String getCompanyName() {
    return companyName;
  }

  public void setCompanyName(String companyName) {
    this.companyName = companyName;
  }

  public String getAccount() {
    return account;
  }

  public void setAccount(String account) {
    this.account = account;
  }

  public String getDescription() {
    return description;
  }

  public void setDescription(String description) {
    this.description = description;
  }

  public String getCreatedAt() {
    return createdAt;
  }

  public void setCreatedAt(String createdAt) {
    this.createdAt = createdAt;
  }

  public String getUpdatedAt() {
    return updatedAt;
  }

  public void setUpdatedAt(String updatedAt) {
    this.updatedAt = updatedAt;
  }

  public String getLogo() {
    return logo;
  }

  public void setLogo(String logo) {
    this.logo = logo;
  }

  public String getName() {
    return name;
  }

  public void setName(String name) {
    this.name = name;
  }

  public String getOwner() {
    return owner;
  }

  public void setOwner(String owner) {
    this.owner = owner;
  }

  public Integer getStatus() {
    return status;
  }

  public void setStatus(Integer status) {
    this.status = status;
  }
}
