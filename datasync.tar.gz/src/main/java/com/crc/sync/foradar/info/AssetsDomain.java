package com.crc.sync.foradar.info;

/**
 * 域名资产台账列表
 * @author: 村长
 * @date: 2023-03-02 10:28:42
 */
public class AssetsDomain {

  /** id */
  private Integer id;
  /** userId */
  private Integer userId;
  /** companyId */
  private Integer companyId;
  /** 域名 */
  private String domain;
  /** 企业名称 */
  private String companyName;
  /** IPV4的解析记录 */
  private String dnsA;
  /** IPV6的解析记录 */
  private String dnsAaaa;
  /** cname */
  private String cname;
  /** 域名状态 0/1 已失效/可解析 */
  private Integer status;
  /**  域名类型 0/1 子域名/主域名 */
  private Integer type;
  /** 发现时间 */
  private String createdAt;
  /** 更新时间 */
  private String updatedAt;

  public Integer getId() {
    return id;
  }

  public void setId(Integer id) {
    this.id = id;
  }

  public Integer getUserId() {
    return userId;
  }

  public void setUserId(Integer userId) {
    this.userId = userId;
  }

  public Integer getCompanyId() {
    return companyId;
  }

  public void setCompanyId(Integer companyId) {
    this.companyId = companyId;
  }

  public String getDomain() {
    return domain;
  }

  public void setDomain(String domain) {
    this.domain = domain;
  }

  public String getCompanyName() {
    return companyName;
  }

  public void setCompanyName(String companyName) {
    this.companyName = companyName;
  }

  public String getDnsA() {
    return dnsA;
  }

  public void setDnsA(String dnsA) {
    this.dnsA = dnsA;
  }

  public String getDnsAaaa() {
    return dnsAaaa;
  }

  public void setDnsAaaa(String dnsAaaa) {
    this.dnsAaaa = dnsAaaa;
  }

  public String getCname() {
    return cname;
  }

  public void setCname(String cname) {
    this.cname = cname;
  }

  public Integer getStatus() {
    return status;
  }

  public void setStatus(Integer status) {
    this.status = status;
  }

  public Integer getType() {
    return type;
  }

  public void setType(Integer type) {
    this.type = type;
  }

  public String getCreatedAt() {
    return createdAt;
  }

  public void setCreatedAt(String createdAt) {
    this.createdAt = createdAt;
  }

  public String getUpdatedAt() {
    return updatedAt;
  }

  public void setUpdatedAt(String updatedAt) {
    this.updatedAt = updatedAt;
  }
}
