package com.crc.sync.foradar;

import com.baomidou.mybatisplus.core.conditions.query.LambdaQueryWrapper;
import com.baomidou.mybatisplus.core.toolkit.Wrappers;
import com.crc.common.utils.DataUtils;
import com.crc.common.utils.Md5Utils;
import com.crc.secface.config.GetSpringBean;
import com.crc.secface.domain.AssetAsmInternet;
import com.crc.secface.domain.F5ForadarInfo;
import com.crc.secface.mapper.F5ForadarInfoMapper;
import com.crc.sync.foradar.info.AssetsDomain;
import com.crc.sync.foradar.info.Geo;
import com.crc.sync.foradar.info.PortList;
import lombok.extern.slf4j.Slf4j;

import java.util.Date;

@Slf4j
public class ForadarToF5Sync {
    public static void sync(AssetsDomain assetsDomain) {
        try {
            F5ForadarInfoMapper foradarInfoMapper = GetSpringBean.getBean(F5ForadarInfoMapper.class);
            F5ForadarInfo f5ForadarInfo = new F5ForadarInfo();
            //f5ForadarInfo.setSource(asmInternet.getDataSource());
            //f5ForadarInfo.setPort(asmInternet.getPort());
            f5ForadarInfo.setCompanyName(assetsDomain.getCompanyName());
//            f5ForadarInfo.setProto(a);
            f5ForadarInfo.setInternetIp(assetsDomain.getDnsA());
            f5ForadarInfo.setSiteCode(assetsDomain.getStatus() == null ? "0" : assetsDomain.getStatus().toString());
            f5ForadarInfo.setUrl(assetsDomain.getDomain());
//            f5ForadarInfo.setSiteTitle(assetsDomain.);
            f5ForadarInfo.setDelFlag(0);
//            f5ForadarInfo.setSource(pl.getSubdomain());
            String uuid = Md5Utils.hash(f5ForadarInfo.getUrl(), f5ForadarInfo.getInternetIp());
            f5ForadarInfo.setUuid(uuid);

            LambdaQueryWrapper<F5ForadarInfo> q = Wrappers.lambdaQuery();
            q.eq(F5ForadarInfo::getUuid, uuid);
            q.last(" limit 1");
            F5ForadarInfo tmp = foradarInfoMapper.selectOne(q);
            if (tmp == null) {
                f5ForadarInfo.setCreateTime(new Date());
                f5ForadarInfo.setUpdateTime(new Date());
                foradarInfoMapper.insert(f5ForadarInfo);
            } else {
                f5ForadarInfo.setId(tmp.getId());
                f5ForadarInfo.setUpdateTime(new Date());
                foradarInfoMapper.updateF5ForadarInfo(f5ForadarInfo);
            }
        } catch (Exception e) {
            log.error(e.getMessage(), e);
        }
    }

    public static void sync(AssetAsmInternet asmInternet, Geo geo, PortList pl) {
        try {
            F5ForadarInfoMapper foradarInfoMapper = GetSpringBean.getBean(F5ForadarInfoMapper.class);
            F5ForadarInfo f5ForadarInfo = new F5ForadarInfo();
            if (geo != null) {
                f5ForadarInfo.setArea(DataUtils.group("/", geo.getCountry(), geo.getProvince(), geo.getCity(), geo.getIsp()));
            }
            //f5ForadarInfo.setSource(asmInternet.getDataSource());
            f5ForadarInfo.setPort(asmInternet.getPort());
            f5ForadarInfo.setCompanyName(asmInternet.getWebServiceName());
            f5ForadarInfo.setProto(pl.getProtocol());
            f5ForadarInfo.setInternetIp(asmInternet.getIp());
            f5ForadarInfo.setSiteCode(pl.getIsOpen() == null ? "0" : pl.getIsOpen().toString());
            f5ForadarInfo.setUrl(pl.getUrl());
            f5ForadarInfo.setSiteTitle(pl.getTitle());
            f5ForadarInfo.setDelFlag(0);
            f5ForadarInfo.setSource(pl.getSubdomain());
            String uuid = Md5Utils.hash(f5ForadarInfo.getUrl(), f5ForadarInfo.getInternetIp());
            f5ForadarInfo.setUuid(uuid);

            try {
                LambdaQueryWrapper<F5ForadarInfo> q = Wrappers.lambdaQuery();
                q.eq(F5ForadarInfo::getUuid, uuid);
                q.last(" limit 1");
                F5ForadarInfo tmp = foradarInfoMapper.selectOne(q);
                if (tmp == null) {
                    f5ForadarInfo.setCreateTime(new Date());
                    f5ForadarInfo.setUpdateTime(new Date());
                    foradarInfoMapper.insert(f5ForadarInfo);
                } else {
                    f5ForadarInfo.setId(tmp.getId());
                    f5ForadarInfo.setUpdateTime(new Date());
                    foradarInfoMapper.updateF5ForadarInfo(f5ForadarInfo);
                }
            } catch (Exception e) {
                log.error(e.getMessage(),e);
            }
        } catch (Exception e) {
            log.error(e.getMessage(), e);
        }
    }
}
