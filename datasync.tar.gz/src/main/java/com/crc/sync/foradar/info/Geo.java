package com.crc.sync.foradar.info;

/**
 * IP归属地
 *
 * @author: 村长
 * @date: 2023-02-28 10:12:31
 */
public class Geo {

  /** 城市 */
  private String city;
  /** 省份 */
  private String province;
  /** 国家 */
  private String country;
  /** 电信运营商 */
  private String isp;
  /** 纬度 */
  private String lat;
  /** 经度 */
  private String lon;

  public String getCity() {
    return city;
  }

  public void setCity(String city) {
    this.city = city;
  }

  public String getProvince() {
    return province;
  }

  public void setProvince(String province) {
    this.province = province;
  }

  public String getCountry() {
    return country;
  }

  public void setCountry(String country) {
    this.country = country;
  }

  public String getLat() {
    return lat;
  }

  public void setLat(String lat) {
    this.lat = lat;
  }

  public String getLon() {
    return lon;
  }

  public void setLon(String lon) {
    this.lon = lon;
  }

  public String getIsp() {
    return isp;
  }

  public void setIsp(String isp) {
    this.isp = isp;
  }
}
