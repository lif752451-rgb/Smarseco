package com.crc.sync.foradar.info;

/**
 * 证书资产台账列表
 * @author: 村长
 * @date: 2023-03-02 10:39:03
 */
public class AssetsCert {

  /** id */
  private Integer id;
  /** userId */
  private Integer userId;
  /** companyId */
  private Integer companyId;
  /** 企业名称 */
  private String companyName;
  /** 颁发者信息-组织（O） */
  private String issuerOrg;
  /** 颁发者信息-颁发者（CN） */
  private String issuerCns;
  /** 颁发者信息-组织单位（OU） */
  private String issuerOu;
  /** 使用者信息-组织（O） */
  private String subjectOrg;
  /** 使用者信息-使用者（CN） */
  private String subjectCns;
  /** 使用者信息-组织单位（OU） */
  private String subjectOu;
  /** 证书版本 */
  private String version;
  /** 证书内容(内容比较长) */
  private String cert;
  /** 证书sn*/
  private String sn;
  /** 关联IP */
  private String ipCount;
  /** 关联域名 */
  private String domainCount;
  /** 颁发日期 */
  private String notBefore;
  /** 截止日期 */
  private String notAfter;

  public String getCert() {
    return cert;
  }

  public void setCert(String cert) {
    this.cert = cert;
  }

  public String getSn() {
    return sn;
  }

  public void setSn(String sn) {
    this.sn = sn;
  }

  public Integer getId() {
    return id;
  }

  public void setId(Integer id) {
    this.id = id;
  }

  public Integer getUserId() {
    return userId;
  }

  public void setUserId(Integer userId) {
    this.userId = userId;
  }

  public Integer getCompanyId() {
    return companyId;
  }

  public void setCompanyId(Integer companyId) {
    this.companyId = companyId;
  }

  public String getCompanyName() {
    return companyName;
  }

  public void setCompanyName(String companyName) {
    this.companyName = companyName;
  }

  public String getIssuerOrg() {
    return issuerOrg;
  }

  public void setIssuerOrg(String issuerOrg) {
    this.issuerOrg = issuerOrg;
  }

  public String getIssuerCns() {
    return issuerCns;
  }

  public void setIssuerCns(String issuerCns) {
    this.issuerCns = issuerCns;
  }

  public String getIssuerOu() {
    return issuerOu;
  }

  public void setIssuerOu(String issuerOu) {
    this.issuerOu = issuerOu;
  }

  public String getSubjectOrg() {
    return subjectOrg;
  }

  public void setSubjectOrg(String subjectOrg) {
    this.subjectOrg = subjectOrg;
  }

  public String getSubjectCns() {
    return subjectCns;
  }

  public void setSubjectCns(String subjectCns) {
    this.subjectCns = subjectCns;
  }

  public String getSubjectOu() {
    return subjectOu;
  }

  public void setSubjectOu(String subjectOu) {
    this.subjectOu = subjectOu;
  }

  public String getVersion() {
    return version;
  }

  public void setVersion(String version) {
    this.version = version;
  }

  public String getIpCount() {
    return ipCount;
  }

  public void setIpCount(String ipCount) {
    this.ipCount = ipCount;
  }

  public String getDomainCount() {
    return domainCount;
  }

  public void setDomainCount(String domainCount) {
    this.domainCount = domainCount;
  }

  public String getNotBefore() {
    return notBefore;
  }

  public void setNotBefore(String notBefore) {
    this.notBefore = notBefore;
  }

  public String getNotAfter() {
    return notAfter;
  }

  public void setNotAfter(String notAfter) {
    this.notAfter = notAfter;
  }
}
