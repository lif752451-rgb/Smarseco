package com.crc.sync.dept;

import com.baomidou.mybatisplus.core.conditions.query.LambdaQueryWrapper;
import com.crc.secface.config.GetSpringBean;
import com.crc.secface.domain.SysDept;
import com.crc.secface.mapper.SysDeptMapper;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;

import java.util.List;

@Slf4j
public class SysDeptFullNameSync {
    public void sync() {
        log.info("刷新部门树信息开始");
        try {
            iter(100L, null, 1);
        } catch (Exception e) {
            log.error(e.getMessage(), e);
        }
        log.info("刷新部门树信息结束");
    }

    private void iter(Long deptId, String fullPath, int level) {
        if (deptId == null || deptId < 1L) {
            return;
        }
        SysDeptMapper sysDeptMapper = GetSpringBean.getBean(SysDeptMapper.class);
        LambdaQueryWrapper<SysDept> query = new LambdaQueryWrapper<>();
        query.eq(SysDept::getDeptId, deptId);
        query.last(" limit 1");
        SysDept rootDept = sysDeptMapper.selectOne(query);
        if (rootDept == null) {
            return;
        }
        setFullPath(rootDept, fullPath, level);

        LambdaQueryWrapper<SysDept> query2 = new LambdaQueryWrapper<>();
        query2.eq(SysDept::getDelFlag, "0");
        query2.eq(SysDept::getParentId, deptId);
        List<SysDept> deptList = sysDeptMapper.selectList(query2);
        if (deptList != null && deptList.size() > 0) {
            if (StringUtils.isBlank(fullPath) && level == 1) {
                fullPath = null;
            } else if (level > 1) {
                if (StringUtils.isBlank(fullPath)) {
                    fullPath = rootDept.getDeptName();
                } else {
                    fullPath = String.format("%s/%s", fullPath, rootDept.getDeptName());
                }
            }
            for (SysDept dept : deptList) {
                iter(dept.getDeptId(), fullPath, level + 1);
            }
        }
    }

    private void setFullPath(SysDept dept, String fullPath, int level) {
        try {
            SysDeptMapper sysDeptMapper = GetSpringBean.getBean(SysDeptMapper.class);
            if (!StringUtils.isNotBlank(fullPath) && level == 1) {
                return;
            } else {
                if (StringUtils.isBlank(fullPath)) {
                    fullPath = dept.getDeptName();
                } else {
                    fullPath = String.format("%s/%s", fullPath, dept.getDeptName());
                }
            }
            dept.setFullPathIds(String.format("%s.%d", dept.getAncestors(), dept.getDeptId()));
            dept.setFullPath(fullPath);
            sysDeptMapper.updateSysDept(dept);
        } catch (Exception e) {
            log.error(e.getMessage(), e);
        }
    }

}
