package com.crc.sync.keywords;

import cn.hutool.core.collection.CollUtil;
import cn.hutool.core.convert.Convert;
import cn.hutool.core.map.MapUtil;
import cn.hutool.core.util.ObjectUtil;
import cn.hutool.core.util.ReflectUtil;
import cn.hutool.core.util.StrUtil;
import com.alibaba.fastjson.JSONObject;
import com.baomidou.mybatisplus.core.conditions.query.LambdaQueryWrapper;
import com.baomidou.mybatisplus.core.toolkit.Wrappers;
import com.crc.common.enums.AlarmBehaviorNatureEnum;
import com.crc.common.enums.AlarmCombatNodeEnum;
import com.crc.common.enums.CommonKeywordsTypeEnum;
import com.crc.common.enums.DatabaseEnums;
import com.crc.common.enums.DelFlagEnum;
import com.crc.common.enums.DictTypeEnum;
import com.crc.common.utils.DictUtil;
import com.crc.common.utils.IdGen;
import com.crc.common.utils.JsonUtils;
import com.crc.common.utils.MyTheadUtils;
import com.crc.common.utils.VersionUtils;
import com.crc.secface.domain.AlarmCombatReport;
import com.crc.secface.domain.AlarmReport;
import com.crc.secface.domain.Asset;
import com.crc.secface.domain.AssetAppSystem;
import com.crc.secface.domain.CommonKeywords;
import com.crc.secface.domain.vo.AssetAppSystemKeywordsVo;
import com.crc.secface.domain.vo.AssetKeywordsVo;
import com.crc.secface.mapper.AlarmCombatReportMapper;
import com.crc.secface.mapper.AlarmReportMapper;
import com.crc.secface.mapper.AssetAppSystemMapper;
import com.crc.secface.mapper.AssetAreaMapper;
import com.crc.secface.mapper.AssetMapper;
import com.crc.secface.mapper.CommonKeywordsMapper;
import com.crc.secface.mapper.CommonMapper;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.scheduling.annotation.EnableScheduling;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Component;

import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.stream.Collectors;
import java.util.stream.Stream;

import static com.crc.common.constants.Constants.Symbol.BLANK;
import static com.crc.common.constants.Constants.Symbol.COMMA;
import static com.crc.common.enums.DictTypeEnum.ASSET_IP_SOURCE;
import static com.crc.common.enums.DictTypeEnum.COMBAT_JUDGE_TAG;
import static com.crc.common.enums.DictTypeEnum.COMMON_KEYWORDS_SYNC;
import static com.crc.common.enums.DictTypeEnum.ENVIRONMENT_TYPE;
import static com.crc.common.enums.DictTypeEnum.KEY_ASSET;
import static com.crc.common.enums.DictTypeEnum.OPERATING_STATUS;
import static com.crc.common.enums.DictTypeEnum.SOURCE_TYPE;

/**
 * @author fuzhuangzhi
 * @title CommonKeywordsSync
 * @date 2023/10/9 15:05
 * @description tb_common_keywords表数据同步
 */
@Slf4j
@Component
@EnableScheduling
public class CommonKeywordsSync implements CommandLineRunner {

    @Autowired
    AssetMapper assetMapper;

    @Autowired
    AlarmReportMapper alarmReportMapper;

    @Autowired
    AlarmCombatReportMapper alarmCombatReportMapper;


    @Autowired
    AssetAppSystemMapper appSystemMapper;

    @Autowired
    CommonMapper commonMapper;

    @Autowired
    AssetAreaMapper assetAreaMapper;

    @Autowired
    CommonKeywordsMapper commonKeywordsMapper;


    // 资产等级字典map
    private Map<String, String> keyAssetMap;

    // 资产状态字段map
    private Map<String, String> operateStatusMap;

    //环境类型字典map
    private Map<String, String> environmentMap;

    // 最近更新来源字典map
    private Map<String, String> assetIpSourceMap;

    // 资源类型字典map
    private Map<String, String> sourceTypeMap;

    // 研判标签字典map
    private Map<String, String> judgeTagMap;

    private static int PAGE_SIZE = 1000;

    // 关键系统关键字搜索属性
    //private static final String ASSET_APP_SYSTEM_KEY_WORD = "id,assetNumer,sysZhName,sysEnName,sysLevelLabel,sysTypeLabel,sysStatusLabel,domain,deptName,dutyPersonName,operatingPersonName,label,remark,updateBy,internalIp";
    private static final String ASSET_APP_SYSTEM_KEY_WORD = "id,systemName,childSystemName,standardizationCode,geographicLocation,iamCode,iamName,internalPublishIp,internalUrl,internalDomain,serverAddress,publishLocation,internetIpPort,internetUrl,internetDomain,businessDepartment,businessDepartmentContactName,updateBy,internetIp";
    // 资产关键字搜索属性
    private static final String ASSET_KEY_WORD = "id,internalIp,instance,hostName,macAddress,internetIp,assetTypeName,os,kernelVersion,domain,appSysName,assetTag,updateBy,affiliationDeptName,personName,equipmentManufacturer,equipmentModel,equipmentStorageAddress," +
            "equipmentManagerAddress,assetNumber,equipmentVersion,geographicLocation,frontComputerRoomCity,safetyTechnicalSupportUnit,remarks,keyAsset,operatingStatus,environmentType,source,sourceType,localIp,virtualIp,outofbandIp";
    // 常态化告警搜索属性
    private static final String ALARM = "alarmId,title,attackIp,attackAssetName,victimizedIp,victimizedAssetName,levelLabel,attackResultLabel,attackMeansLabel,behaviorNature,alarmSource,commitUserName,commitNickName," +
            "dutyDeptName,orderStatus,vulKeyword,detail";

    // 实战告警搜索属性
    private static final String ALARM_HVV = "alarmId,title,attackIp,attackAssetName,victimizedIp,victimizedAssetName,levelLabel,attackResultLabel,attackMeansLabel,judgeTag,behaviorNature,alarmSource,traceabilityStatusLabel,createByLabel," +
            "dutyDeptName,orderStatus,vulKeyword,detail";

    @Override
    public void run(String... args) throws Exception {
        MyTheadUtils.sleepBySec(5);
        // 资产全文检索
        if (DictUtil.isEnable(DictTypeEnum.COMMON_KEYWORDS_SYNC.getName(), "asset")) {
            Long assetCount = getBusinessTypeCount(CommonKeywordsTypeEnum.ASSET.getType());
            if (assetCount <= 0) {
                // 同步资产全局搜索字段
                syncAssetKeywords();
            }
        }

        // 应用系统全文检索
        if (DictUtil.isEnable(DictTypeEnum.COMMON_KEYWORDS_SYNC.getName(), "assetAppSystem")) {
            Long assetAppSysCount = getBusinessTypeCount(CommonKeywordsTypeEnum.ASSET_APP_SYSTEM.getType());
            if (assetAppSysCount <= 0) {
                // 同步应用系统全局搜索字段
                syncAssetAppSystemKeywords();
            }
        }

        // 常态化告警
        if (DictUtil.isEnable(DictTypeEnum.COMMON_KEYWORDS_SYNC.getName(), "alarm")) {
            Long alarmCount = getBusinessTypeCount(CommonKeywordsTypeEnum.ALARM.getType());
            if (alarmCount <= 0) {
                // 同步常态化告警全局搜索字段
                syncAlarmKeywords();
            }
        }

        // 实战告警
        if (DictUtil.isEnable(DictTypeEnum.COMMON_KEYWORDS_SYNC.getName(), "alarmHvv")) {
            Long alarmHvvCount = getBusinessTypeCount(CommonKeywordsTypeEnum.ALARM_HVV.getType());
            if (alarmHvvCount <= 0) {
                // 同步实战告警全局搜索字段
                syncAlarmHvvKeywords();
            }
        }
    }

    private Long getBusinessTypeCount(String businessType) {
        log.info("run getBusinessTypeCount: " + businessType);
        LambdaQueryWrapper<CommonKeywords> query = Wrappers.lambdaQuery();
        query.eq(CommonKeywords::getBusinessType, businessType);
        query.eq(CommonKeywords::getDelFlag, DelFlagEnum.AVAILABLE.getValue().toString());
        return commonKeywordsMapper.selectCount(query);
    }

    // 每天晚上四点全量同步实战告警全文检索表tb_common_keywords
    @Scheduled(cron = "0 0 4 * * ?")
    private void syncAlarmHvvKeywords() {
        MyTheadUtils.sleepBySec(5);
        if (DictUtil.isEnable(DictTypeEnum.COMMON_KEYWORDS_SYNC.getName(), "alarmHvv")) {
            log.info("清空全文检索表tb_common_keywords中的实战告警数据开始");
            // 清空表
            commonMapper.exeSQL("DELETE FROM tb_common_keywords WHERE business_type = 'alarmHvv'");
            log.info("清空全文检索表tb_common_keywords中的实战告警数据结束");
            log.info("开始同步全文检索表tb_common_keywords实战告警数据");
            int sum = 0;
            // 获取实战告警全文检索字段数据
            LambdaQueryWrapper<AlarmCombatReport> alarmReportQw = Wrappers.lambdaQuery();
            alarmReportQw.eq(AlarmCombatReport::getDelFlag, DelFlagEnum.AVAILABLE.getValue().toString());
            Long total = alarmCombatReportMapper.selectCount(alarmReportQw);
            if (total <= 0) {
                return;
            }
            log.info("查询到的实战告警总数：{}", total);
            // 研判标签字典map
            judgeTagMap = MapUtil.emptyIfNull(DictUtil.getMapValueLabel(COMBAT_JUDGE_TAG.getName()));
            for (int i = 0; i < (int) (total / PAGE_SIZE) + 1; i++) {
                List<AlarmCombatReport> list = alarmCombatReportMapper.selectAlarmReportList(i * PAGE_SIZE, PAGE_SIZE);
                if (CollUtil.isEmpty(list)) {
                    continue;
                }
                try {
                    // 开始组装实战告警数据
                    int size = procAlarmCombatReportData(list);
                    sum += size;
                    log.info("tb_common_keywords已同步实战告警数据总数：{}", sum);
                    MyTheadUtils.sleep(100);
                } catch (Exception e) {
                    log.error(e.getMessage(), e);
                }
            }
        }
    }

    private int procAlarmCombatReportData(List<AlarmCombatReport> alarmCombatReportList) {
        if (CollUtil.isEmpty(alarmCombatReportList)) {
            return 0;
        }
        String fields = getFields(COMMON_KEYWORDS_SYNC.getName(), "alarmHvv", ALARM_HVV);
        Set<String> sum = new HashSet<>();
        List<CommonKeywords> dataList = alarmCombatReportList.stream().map(alarmCombatReport -> {
            // 关键字
            Stream<String> fieldKeywordStream = getFieldKeywordStream(fields, alarmCombatReport);
            String keyWords = getKeywords(alarmCombatReport, fieldKeywordStream);
            return getCommonKeywords(keyWords, CommonKeywordsTypeEnum.ALARM_HVV, alarmCombatReport.getId(), sum);
        }).filter(t -> StrUtil.isAllNotEmpty(t.getKeywords(), t.getBusinessId())).collect(Collectors.toList());
        log.info("syncAlarmHvvKeywords procAlarmCombatReportData Data too long, count :" + sum.size());
        return commonKeywordsMapper.insertBatch(dataList);
    }

    private String getKeywords(AlarmCombatReport alarmCombatReport, Stream<String> fieldKeywordStream) {
        // 行为性质
        String behaviorNature = null;
        if (ReflectUtil.hasField(alarmCombatReport.getClass(), "behaviorNature")) {
            behaviorNature = AlarmBehaviorNatureEnum.getEnum(alarmCombatReport.getBehaviorNature());
        }
        // 工单状态
        String orderStatus = null;
        if (ReflectUtil.hasField(alarmCombatReport.getClass(), "orderStatus")) {
            orderStatus = AlarmCombatNodeEnum.getEnumLabelByNodeKey(alarmCombatReport.getOrderStatus());
        }
        // 研判标签
        String judgeTag = null;
        if (ReflectUtil.hasField(alarmCombatReport.getClass(), "judgeTag")) {
            judgeTag = this.getJudgeTagLabel(alarmCombatReport.getJudgeTag(), judgeTagMap);
        }
        // 字典映射字段
        Stream<String> otherStream = Stream.of(behaviorNature, orderStatus, judgeTag);
        // 获取keyword
        String keyWords = null;
        if (ObjectUtil.isNull(otherStream)) {
            keyWords = fieldKeywordStream.filter(StrUtil::isNotEmpty).collect(Collectors.joining(BLANK));
        } else {
            keyWords = Stream.concat(otherStream, fieldKeywordStream).filter(StrUtil::isNotEmpty).collect(Collectors.joining(BLANK));
        }
        return keyWords;
    }

    /**
     * 研判标签转换
     *
     * @param judgeTag    研判标签
     * @param judgeTagMap 研判标签数据字典
     * @return String
     */
    public String getJudgeTagLabel(String judgeTag, Map<String, String> judgeTagMap) {
        String judgeTagLabel = "";
        if (StringUtils.isNotEmpty(judgeTag) && CollUtil.isNotEmpty(judgeTagMap)) {
            judgeTagLabel = Stream.of(judgeTag.split(COMMA)).map(judgeTagMap::get).filter(StringUtils::isNotEmpty)
                    .distinct().collect(Collectors.joining(COMMA));
        }
        return judgeTagLabel;
    }

    // 每天晚上三点全量同步常态化全文检索表tb_common_keywords
    @Scheduled(cron = "0 0 3 * * ?")
    private void syncAlarmKeywords() {
        MyTheadUtils.sleepBySec(5);
        if (DictUtil.isEnable(DictTypeEnum.COMMON_KEYWORDS_SYNC.getName(), "alarm")) {
            log.info("清空全文检索表tb_common_keywords中的常态化告警数据开始");
            // 清空表
            commonMapper.exeSQL("DELETE FROM tb_common_keywords WHERE business_type = 'alarm'");
            log.info("清空全文检索表tb_common_keywords中的常态化告警数据结束");
            log.info("开始同步全文检索表tb_common_keywords常态化告警数据");
            int sum = 0;
            // 获取常态化告警全文检索字段数据
            LambdaQueryWrapper<AlarmReport> alarmReportQw = Wrappers.lambdaQuery();
            alarmReportQw.eq(AlarmReport::getDelFlag, DelFlagEnum.AVAILABLE.getValue().toString());
            Long total = alarmReportMapper.selectCount(alarmReportQw);
            if (total <= 0) {
                return;
            }
            log.info("查询到的常态化告警总数：{}", total);
            for (int i = 0; i < (int) (total / PAGE_SIZE) + 1; i++) {
                List<AlarmReport> list = alarmReportMapper.selectAlarmReportList(i * PAGE_SIZE, PAGE_SIZE);
                if (CollUtil.isEmpty(list)) {
                    continue;
                }
                try {
                    // 开始组装常态化告警数据
                    int size = procAlarmReportData(list);
                    sum += size;
                    log.info("tb_common_keywords已同步常态化告警数据总数：{}", sum);
                    MyTheadUtils.sleep(100);
                } catch (Exception e) {
                    log.error(e.getMessage(), e);
                }
            }
        }
    }

    private int procAlarmReportData(List<AlarmReport> alarmReportList) {
        if (CollUtil.isEmpty(alarmReportList)) {
            return 0;
        }
        String fields = getFields(COMMON_KEYWORDS_SYNC.getName(), "alarm", ALARM);
        Set<String> sum = new HashSet<>();
        List<CommonKeywords> dataList = alarmReportList.stream().map(alarmReport -> {
            // 关键字
            String keyWords = getFieldKeywordStream(fields, alarmReport).filter(StrUtil::isNotEmpty)
                    .collect(Collectors.joining(BLANK));
            // 行为性质
            String behaviorNature = null;
            if (ReflectUtil.hasField(alarmReport.getClass(), "behaviorNature")) {
                behaviorNature = AlarmBehaviorNatureEnum.getEnum(alarmReport.getBehaviorNature());
            }
            keyWords = Stream.of(keyWords, behaviorNature).filter(StrUtil::isNotEmpty).collect(Collectors.joining(BLANK));
            return getCommonKeywords(keyWords, CommonKeywordsTypeEnum.ALARM, Convert.toStr(alarmReport.getId()), sum);
        }).filter(t -> StrUtil.isAllNotEmpty(t.getKeywords(), t.getBusinessId())).collect(Collectors.toList());
        log.info("syncAlarmKeywords procAlarmReportData Data too long, count :" + sum.size());
        return commonKeywordsMapper.insertBatch(dataList);
    }

    // 每天晚上一点全量同步资产全文检索表tb_common_keywords
    @Scheduled(cron = "0 0 1 * * ?")
    private void syncAssetKeywords() {
        MyTheadUtils.sleepBySec(5);
        if (DictUtil.isEnable(DictTypeEnum.COMMON_KEYWORDS_SYNC.getName(), "asset")) {
            log.info("清空全文检索表tb_common_keywords中的资产数据开始");
            // 清空表
            commonMapper.exeSQL("DELETE FROM tb_common_keywords WHERE business_type = 'asset'");
            log.info("清空全文检索表tb_common_keywords中的资产数据结束");
            log.info("开始同步全文检索表tb_common_keywords资产数据");
            // 资产等级
            keyAssetMap = DictUtil.getMapValueLabel(KEY_ASSET.getName());
            // 资产状态
            operateStatusMap = DictUtil.getMapValueLabel(OPERATING_STATUS.getName());
            environmentMap = DictUtil.getMapValueLabel(ENVIRONMENT_TYPE.getName());
            assetIpSourceMap = DictUtil.getMapValueLabel(ASSET_IP_SOURCE.getName());
            sourceTypeMap = DictUtil.getMapValueLabel(SOURCE_TYPE.getName());
            int sum = 0;
            // 获取资产全文检索字段数据
            LambdaQueryWrapper<Asset> assetQuery = Wrappers.lambdaQuery();
            assetQuery.eq(Asset::getDelFlag, DelFlagEnum.AVAILABLE.getValue().toString());
            Long total = assetMapper.selectCount(assetQuery);
            if (total <= 0) {
                return;
            }
            log.info("查询到的资产总数：{}", total);
            for (int i = 0; i < (int) (total / PAGE_SIZE) + 1; i++) {
                Asset q = new Asset();
                q.setOffset(i * PAGE_SIZE);
                q.setPageSize(PAGE_SIZE);
                List<Asset> list = assetMapper.selectTbAssetByOffset(q);
                if (CollUtil.isEmpty(list)) {
                    continue;
                }
                List<Long> idList = list.stream().map(Asset::getId).collect(Collectors.toList());
                List<AssetKeywordsVo> assetKeywordsList = assetMapper.getCommonKeywords(idList);
                try {
                    // 开始组装数据
                    int size = procAssetData(assetKeywordsList);
                    sum += size;
                    log.info("tb_common_keywords已同步资产数据总数：{}", sum);
                    MyTheadUtils.sleep(100);
                } catch (Exception e) {
                    log.error(e.getMessage(), e);
                }
            }
        }
    }

    // 每天晚上二点全量同步应用系统全文检索表tb_common_keywords
    @Scheduled(cron = "0 0 2 * * ?")
    private void syncAssetAppSystemKeywords() {
        MyTheadUtils.sleepBySec(5);
        if (DictUtil.isEnable(DictTypeEnum.COMMON_KEYWORDS_SYNC.getName(), "assetAppSystem")) {
            log.info("清空全文检索表tb_common_keywords中的应用系统数据开始");
            // 清空表
            commonMapper.exeSQL("DELETE FROM tb_common_keywords WHERE business_type = 'assetAppSystem'");
            log.info("清空全文检索表tb_common_keywords中的应用系统数据结束");
            log.info("开始同步全文检索表tb_common_keywords应用系统数据");
            int sum = 0;
            // 获取应用系统全文检索字段数据
            LambdaQueryWrapper<AssetAppSystem> assetQuery = Wrappers.lambdaQuery();
            assetQuery.eq(AssetAppSystem::getDelFlag, DelFlagEnum.AVAILABLE.getValue().toString());
            Long total = appSystemMapper.selectCount(assetQuery);
            if (total <= 0) {
                return;
            }
            log.info("查询到的应用系统总数：{}", total);
            for (int i = 0; i < (int) (total / PAGE_SIZE) + 1; i++) {
                List<AssetAppSystemKeywordsVo> list = null;
                if (VersionUtils.getDatabase() == DatabaseEnums.MYSQL.getCode()) {
                    list = appSystemMapper.getListByPage(i * PAGE_SIZE, PAGE_SIZE);
                } else {
                    list = appSystemMapper.getListByPageOracle(i * PAGE_SIZE, PAGE_SIZE);
                }
                if (CollUtil.isEmpty(list)) {
                    continue;
                }
                try {
                    // 开始组装应用系统数据
                    int size = procAppSysData(list);
                    sum += size;
                    log.info("tb_common_keywords已同步应用系统数据总数：{}", sum);
                    MyTheadUtils.sleep(100);
                } catch (Exception e) {
                    log.error(e.getMessage(), e);
                }
            }
        }
    }

    private int procAppSysData(List<AssetAppSystemKeywordsVo> appSystemKeywordsVoList) {
        String fields = getFields(COMMON_KEYWORDS_SYNC.getName(), "assetAppSystem", ASSET_APP_SYSTEM_KEY_WORD);
        Set<String> sum = new HashSet<>();
        List<CommonKeywords> dataList = appSystemKeywordsVoList.stream().map(appSystemVo -> {
            // 关键字
            String keyWords = getFieldKeywordStream(fields, appSystemVo).filter(StrUtil::isNotEmpty)
                    .collect(Collectors.joining(BLANK));
            return getCommonKeywords(keyWords, CommonKeywordsTypeEnum.ASSET_APP_SYSTEM, appSystemVo.getId(), sum);
        }).filter(t -> StrUtil.isAllNotEmpty(t.getKeywords(), t.getBusinessId())).collect(Collectors.toList());
        log.info("syncAssetAppSystemKeywords procAppSysData Data too long, count :" + sum.size());
        return commonKeywordsMapper.insertBatch(dataList);
    }

    private String getFields(String dictType, String dictValue, final String defaultVal) {
        String remark = DictUtil.getRemark(dictType, dictValue);
        if (StrUtil.isEmpty(remark)) {
            return defaultVal;
        }
        JSONObject json = JsonUtils.parse(remark);
        return JsonUtils.getStr(json, "field");
    }

    private int procAssetData(List<AssetKeywordsVo> assetKeywordsList) {
        if (CollUtil.isEmpty(assetKeywordsList)) {
            return 0;
        }
        String fields = getFields(COMMON_KEYWORDS_SYNC.getName(), "asset", ASSET_KEY_WORD);
        Set<String> sum = new HashSet<>();
        List<CommonKeywords> dataList = assetKeywordsList.stream().map(assetKeywordsVo -> {
            String keyWords = getKeywords(fields, assetKeywordsVo);
            return getCommonKeywords(keyWords, CommonKeywordsTypeEnum.ASSET, String.valueOf(assetKeywordsVo.getId()), sum);
        }).filter(t -> StrUtil.isAllNotEmpty(t.getKeywords(), t.getBusinessId())).collect(Collectors.toList());
        log.info("syncAssetKeywords procAssetData Data too long, count :" + sum.size());
        return commonKeywordsMapper.insertBatch(dataList);
    }

    private String getKeywords(String fields, AssetKeywordsVo assetKeywordsVo) {
        // 搜索关键字
        Stream<String> fieldKeywordStream = getFieldKeywordStream(fields, assetKeywordsVo);
        // 网络区域
        String areaFullName = null;
        if (ReflectUtil.hasField(assetKeywordsVo.getClass(), "areaCustomUuid")) {
            if (VersionUtils.getDatabase() == DatabaseEnums.MYSQL.getCode()) {
                areaFullName = assetAreaMapper.findAreaFullNameByCustomUuid(assetKeywordsVo.getAreaCustomUuid());
            } else {
                areaFullName = assetAreaMapper.findAreaFullNameByCustomUuidOracle(assetKeywordsVo.getAreaCustomUuid());
            }

        }
        // 资产等级
        String keyAsset = null;
        if (ReflectUtil.hasField(assetKeywordsVo.getClass(), "keyAsset")) {
            keyAsset = MapUtil.getStr(keyAssetMap, Convert.toStr(assetKeywordsVo.getKeyAsset()));
        }
        // 资产状态
        String operateStatus = null;
        if (ReflectUtil.hasField(assetKeywordsVo.getClass(), "operatingStatus")) {
            operateStatus = MapUtil.getStr(operateStatusMap, Convert.toStr(assetKeywordsVo.getOperatingStatus()));
        }
        // 环境类型
        String environmentType = null;
        if (ReflectUtil.hasField(assetKeywordsVo.getClass(), "environmentType")) {
            environmentType = MapUtil.getStr(environmentMap, Convert.toStr(assetKeywordsVo.getEnvironmentType()));
        }
        // 资产来源
        String ipSource = null;
        if (ReflectUtil.hasField(assetKeywordsVo.getClass(), "source")) {
            ipSource = MapUtil.getStr(assetIpSourceMap, assetKeywordsVo.getSource());
        }
        // 资源类型
        String sourceType = null;
        if (ReflectUtil.hasField(assetKeywordsVo.getClass(), "sourceType")) {
            sourceType = MapUtil.getStr(sourceTypeMap, Convert.toStr(assetKeywordsVo.getSourceType()));
        }
        // 字典映射字段
        Stream<String> otherStream = Stream.of(areaFullName, keyAsset, operateStatus, environmentType, ipSource, sourceType);
        // 获取keyword
        String keyWords = null;
        if (ObjectUtil.isNull(otherStream)) {
            keyWords = fieldKeywordStream.filter(StrUtil::isNotEmpty).collect(Collectors.joining(BLANK));
        } else {
            keyWords = Stream.concat(otherStream, fieldKeywordStream).filter(StrUtil::isNotEmpty).collect(Collectors.joining(BLANK));
        }
        return keyWords;
    }

    private <T> Stream<String> getFieldKeywordStream(String fields, T keywordVo) {
        Stream<String> fieldKeywordStream = StrUtil.split(fields, COMMA).stream().map(fieldName -> {
            try {
                if (ReflectUtil.hasField(keywordVo.getClass(), fieldName)) {
                    return ReflectUtil.getFieldValue(keywordVo, fieldName);
                }
                return null;
            } catch (Exception e) {
                return null;
            }
        }).filter(ObjectUtil::isNotEmpty).map(ObjectUtil::toString);
        return fieldKeywordStream;
    }

    private CommonKeywords getCommonKeywords(String keyWords, CommonKeywordsTypeEnum keywordsTypeEnum, String businessId, Set<String> sum) {
        CommonKeywords commonKeywords = new CommonKeywords();
        commonKeywords.setId(IdGen.uuid());
        commonKeywords.setCreateBy("system");
        commonKeywords.setUpdateBy("system");
        if (keyWords.length() > 65535) {
            log.info("CommonKeywords The original file exceeds (" + keyWords.length() + ") characters ;" + "businessId : " + businessId + "CommonKeywordsTypeEnum : " + keywordsTypeEnum.getModule() + "keyWords :" + keyWords);
            keyWords = keyWords.substring(0, 65535);
            sum.add(businessId);
        }
        commonKeywords.setKeywords(keyWords);
        commonKeywords.setBusinessType(keywordsTypeEnum.getType());
        commonKeywords.setBusinessId(businessId);
        return commonKeywords;
    }

}
