package com.crc.sync.config;

public class SyncSecConstants {
    public static final String LVMENT_IOC_THREAT_SYNC_ENABLE = "lvmeng_ioc_threat";
    public static final String LVMENG_SYNC_DAYS = "lvmeng_sync_days";
    public static final String LVMENT_VUL_THREAT_SYNC_ENABLE = "lvmeng_vul_threat";
    public static final String LVMENT_SEND_THREAT_SYNC_ENABLE = "lvmeng_send_threat";
    public static final String QT_PATCH_SYNC_ENABLE = "qt_patch_sync_enable";
    public static String FILTER_SEGMENT_ENABLE = "filter_segment_enable";
    public static final String ASSET_SCORE_SYNC = "asset_score_sync";

    /**
     * 网段告警计算配置开关
     */
    public static final String SEGMENT_ALARM_SYNC = "segment_alarm_sync";

    /**
     * 资产告警计算配置开关
     */
    public static final String ASSET_ALARM_SYNC = "asset_alarm_sync";

    public static final String MAVELNET_SYNC_ENABLE = "mavelnet_score_sync";
    public static final String ZHUYUN_SYNC_TO_STP_ENABLE = "zy_sync_stp_enable";
    public static final String FISH_DB_CONFIG = "fish_db_config";
    public static final String COMMON_KEYWORD_SYNC_ENABLE = "common_keywords_sync";

    /*
        数据同步的字典配置
         */
    public static String SYNC_SEC_CONFIG = "sync_sec_config";
    public static String STP_UPLOAD_CONFIG = "stp_upload_config";
    /*
    青藤登录配置
     */
    public static String QT_LOGIN_CONFIG = "qt_login_config";

    /*
    长亭登录配置
     */
    public static String CT_LOGIN_CONFIG = "ct_login_config";

    /*
    Dcc登录配置
     */
    public static String DCC_LOGIN_CONFIG = "dcc_login_config";

    /*
    绿盟登录配置
     */
    public static String LVMENG_LOGIN_CONFIG = "lvmeng_login_config";

    /*
     传统CMDB登录配置
   */
    public static String CMDB_LOGIN_CONFIG = "cmdb_login_config";

    /*
    安恒登录配置
     */
    public static String AN_HENG_LOGIN_CONFIG = "an_heng_login_config";

    /*
    华润云CMDB登录配置
     */
    public static String CMDB_PLUS_LOGIN_CONFIG = "cmdb_plus_login_config";

    /*
    是否启动青藤漏洞同步-一部版
     */
    public static String QT_GROUP_SYNC_ENABLE = "qt_group_sync_enable";

    /*
    是否启动青藤漏洞同步-标准版
     */
    public static String QT_STANDARD_SYNC_ENABLE = "qt_standard_sync_enable";
    public static String AA_SYNC_ENABLE = "aa_sync_enable";

    public static String ZHUOMUNIAO_SYNC_ENABLE = "zhuominiao_sync_enable";
    public static String JIAOTU_SYNC_ENABLE = "jiaotu_sync_enable";
    public static String TIANRONGXIN_SYNC_ENABLE = "tianrongxin_sync_enable";
    public static String HUAWEI_SYNC_ENABLE = "huawei_sync_enable";
    /*
    推送STP的URL
     */
    public static String STP_API_URL = "stp_api_url";
    public static String BEAT_API_URL = "beta_api_url";

    /*
    是否启动DCC漏洞对接
     */
    public static String DCC_SYNC_ENABLE = "dcc_sync_enable";
    public static String GOBY_SYNC_ENABLE = "goby_sync_enable";

    public static String NAMP_SYNC_ENABLE = "nmap_sync_enable";
    /*
   是否启动长亭漏洞对接
    */
    public static String CHANGTING_SYNC_ENABLE = "changting_sync_enable";
    public static String CHANGTING_ASSET_SYNC_ENABLE = "changting_asset_sync_enable";

    /**
     * 是否同步安恒扫描引擎
     */
    public static String ANHENG_SYNC_ENABLE = "anheng_sync_enable";
    public static String SAFE_DOG_WEAK_SYNC_ENABLE = "safedog_weak_sync_enable";
    /*
    是否启动钓鱼邮件分析
     */
    public static String FISH_SYNC_ENABLE = "fish_sync_enable";

    /*
    是否同步青藤资产
     */
    public static String QT_ASSET_SYNC_ENABLE = "qt_asset_sync_enable";
    public static String QT_ASSET_HOST_TAG_SYNC_ENABLE = "qt_asset_host_tag_sync_enable";
    public static String BETA_ASSET_SYNC_ENABLE = "bata_asset_sync_enable";

    /*
    是否同步青藤资产的组件数据
     */
    public static String QT_COMP_SYNC_ENABLE = "qt_comp_sync_enable";
    public static String SD_COMP_SYNC_ENABLE = "safedog_comp_sync_enable";
    public static String QT_SYS_SYNC_ENABLE = "qt_sys_sync_enable";

    /*
    是否同步传统CMDB资产
     */
    public static String CMDB_SYNC_ENABLE = "cmdb_sync_enable";

    /*
    是否同步华润云资产
     */
    public static String CMDB_PLUS_SYNC_ENABLE = "cmdb_plus_sync_enable";

    /*
    是否同步D01资产
     */
    public static String D01_ASSET_SYNC_ENABLE = "d01_asset_sync_enable";
    public static String DCC_ASSET_SYNC_ENABLE = "dcc_asset_sync_enable";
    public static String SAFEDOG_ASSET_SYNC_ENABLE = "safedog_asset_sync_enable";
    public static String SAFEDOG_SYNC_ENABLE = "safedog_sync_enable";


    public static String D01_SYNC_ENABLE = "d01_sync_enable";

    /*
   是否同步告警事件到中间表
    */
    public static String ALARM_EVENT_SYNC_ENABLE = "alarm_event_sync_enable";
    /*
     是否同步告警事件到中间表
      */
    public static String LVMENG_SYNC_ENABLE = "lvmeng_sync_enable";

    /*
是否同步青藤资产的组件数据
 */
    public static String QT_BASELINE_SYNC_ENABLE = "qt_baseline_sync_enable";
    public static String QT_WEAKPASS_SYNC_ENABLE = "qt_weakpass_sync_enable";

    /*
   是否同步长亭资产
    */
    public static String CT_ASSET_SYNC_ENABLE = "changting_asset_sync_enable";

    /*
   是否同步安恒资产
    */
    public static String AN_HENG_ASSET_SYNC_ENABLE = "an_heng_asset_sync_enable";
    /*
   是否同步安恒资产的组件数据
    */
    public static String AN_HENG_COMP_SYNC_ENABLE = "an_heng_comp_sync_enable";

    /*
    是否同步魔方资产
    */
    public static String MO_FANG_ASSET_SYNC_ENABLE = "mo_fang_asset_sync_enable";

    /*
   是否同步安恒魔方的组件数据
    */
    public static String MO_FANG_COMP_SYNC_ENABLE = "mo_fang_comp_sync_enable";

    /*
   是否同步安恒魔方的漏洞数据
    */
    public static String MO_FANG_SYNC_ENABLE = "mo_fang_sync_enable";

    public static String LANJING_SYNC_ENABLE = "lanjing_sync_enable";

    /**
     * 是否同步天地和兴的漏洞数据
     */
    public static String TDHX_SYNC_ENABLE = "tdhx_sync_enable";

    public static String USER_LOG_SYNC_TERMINAL_ENABLE = "user_log_sync_terminal";

    /**
     * 是否启用同步资产API
     */
    public static String SYNC_ASSET_API_ENABLE = "asset_api_enable";

    /**
     * 是否启用同步资产回传API
     */
    public static String SYNC_ASSET_SYNC_API_SOURCE = "asset_sync_api_source";

    /**
     * 是否启用同步资产删除旧资产
     */
    public static String SYNC_OLD_ASSET_DEL_ENABLE = "old_asset_del_enable";

    /**
     * 同步物联网中台登录配置
     */
    public static String IOT_LOGIN_CONFIG = "iot_login_config";

    /**
     * 同步Ngsoc登录配置
     */
    public static String NGSOC_LOGIN_CONFIG = "ngsoc_login_config";

    /**
     * 华东石油局项目专属，支持多台安恒态势感知
     * 同步安恒资产数据来源
     */
    public static String AN_HENG_SOURCE_IP_1 = "ip1";
    public static String AN_HENG_SOURCE_IP_2 = "ip2";
    public static String AN_HENG_SOURCE_IP_3 = "ip3";
}
