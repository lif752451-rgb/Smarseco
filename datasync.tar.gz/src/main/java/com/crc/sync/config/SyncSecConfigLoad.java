package com.crc.sync.config;

import com.alibaba.fastjson.JSONObject;
import com.crc.common.code.CodeTool;
import com.crc.common.utils.DataUtils;
import com.crc.common.utils.DictUtil;
import com.crc.common.utils.JsonUtils;
import com.crc.secface.config.BanbooConfig;
import com.crc.secface.domain.SysDictData;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringEscapeUtils;
import org.apache.commons.lang3.StringUtils;

@Slf4j
public class SyncSecConfigLoad {

    public static boolean isEnable(String value) {
        try {
            SysDictData config = getConfig(value);
            return !StringUtils.isBlank(config.getDictValue());
        } catch (Exception e) {
            log.error(e.getMessage(), e);
        }
        return false;
    }

    public static SysDictData getConfig(String value) {
        SysDictData dict = new SysDictData();
        if (value == null) {
            return dict;
        }
        SysDictData config = DictUtil.getDictByValue(SyncSecConstants.SYNC_SEC_CONFIG, value);
        if (config == null) {
            return dict;
        }
        return config;
    }

    public static String getRemarkValue(String value) {
        if (value == null) {
            return "";
        }
        try {
            SysDictData config = DictUtil.getDictByValue(SyncSecConstants.SYNC_SEC_CONFIG, value);
            if (config == null) {
                return "";
            }
            return StringEscapeUtils.unescapeXml(config.getRemark());
        } catch (Exception e) {
            return null;
        }
    }

    public static BanbooConfig getZyConfig(SysDictData dict) {
        BanbooConfig qtConfig = new BanbooConfig();
        if (DataUtils.isBlankDict(dict) || StringUtils.isBlank(dict.getRemark())) {
            return qtConfig;
        }
        JSONObject json = JsonUtils.parse(dict.getRemark());
        qtConfig.setPassword(JsonUtils.getStr(json, "password"));
        String PASS = qtConfig.getPassword().trim();
        try {
            if (PASS.startsWith("ENC") && json.containsKey("publicKey")) {
                PASS = PASS.replace("ENC(", "").replace(")", "");
                PASS = CodeTool.decrypt(PASS, JsonUtils.getStr(json, "publicKey"));
                qtConfig.setPassword(PASS);
            }
        } catch (Exception e) {
            log.error(e.getMessage(), e);
        }
        qtConfig.setUsername(JsonUtils.getStr(json, "username"));
        qtConfig.setAppId(JsonUtils.getStr(json, "appid"));
        qtConfig.setAuthUrl(JsonUtils.getStr(json, "authUrl"));
        return qtConfig;
    }
}
