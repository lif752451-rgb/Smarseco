package com.crc.sync.d01;

import com.alibaba.fastjson.JSONArray;
import com.alibaba.fastjson.JSONObject;
import com.crc.common.utils.DataUtils;
import com.crc.common.utils.IOUtils;
import com.crc.common.utils.JsonUtils;
import com.crc.scanner.config.DccConfig;
import com.crc.scanner.tool.D01Utils;
import org.apache.http.HttpEntity;
import org.apache.http.client.config.RequestConfig;
import org.apache.http.client.methods.CloseableHttpResponse;
import org.apache.http.client.methods.HttpDelete;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.impl.client.CloseableHttpClient;
import org.apache.http.impl.client.HttpClients;
import org.apache.http.util.EntityUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.util.DigestUtils;

public class DccTaskSync {
    private static final Logger logger = LoggerFactory.getLogger(DccTaskSync.class);


    public static void del(DccConfig scannerInfo, String type, String params) {
        //api/service/taskRecords/id?email=admin@dcc.com&timestamp=1556518255&sign=9A0A8659F005D6984697E2CA0A9CF3B7
        CloseableHttpClient httpClient;
        CloseableHttpResponse response = null;
        try {
            String url = scannerInfo.getAddress();
            if (url.toLowerCase().startsWith("https")) {
                httpClient = D01Utils.createAcceptSelfSignedCertificateClient();
            } else {
                httpClient = HttpClients.createDefault();
            }
            long timestamp = System.currentTimeMillis() / 1000 - scannerInfo.getOffset();
            String stringA = "email=" + scannerInfo.getUsername() + params + "&timestamp=" + timestamp;
            stringA = D01Utils.parseParam(stringA);
            String stringSignTemp = stringA + "&secret_key=" + scannerInfo.getPassword();
            String sign = DigestUtils.md5DigestAsHex(stringSignTemp.getBytes()).toUpperCase();
            String fullUrl = url + "/api/service/" + type + "?" + stringA + "&sign=" + sign;
            logger.info(fullUrl);
            HttpDelete httpdelete = new HttpDelete(fullUrl);
            RequestConfig requestConfig = RequestConfig.custom()
                    .setConnectTimeout(45000).setConnectionRequestTimeout(45000)
                    .setSocketTimeout(45000).build();
            httpdelete.setConfig(requestConfig);
            response = httpClient.execute(httpdelete);
            int code = response.getStatusLine().getStatusCode();
            JSONObject result = JsonUtils.parse(DataUtils.toBodyString(response.getEntity()));
            if (code == 200) {
                logger.error("成功：" + result);
            } else {
                logger.error("获取数据错误非200OK：" + result);
            }
        } catch (Exception e) {
            logger.error(e.getMessage(), e);
        } finally {
            IOUtils.close(response);
        }
    }

    public static String add(DccConfig scannerInfo, String type, String params) {
        ///api/service/groups?email=admin@dcc.com&timestamp=1556518255&sign=9A0A8659F005D6984697E2CA0A9CF3B7
        CloseableHttpClient httpClient;
        CloseableHttpResponse response = null;
        try {
            if ("http".equalsIgnoreCase(scannerInfo.getMode())) {
                httpClient = HttpClients.createDefault();
            } else {
                httpClient = D01Utils.createAcceptSelfSignedCertificateClient();
            }
            //params = DataUtils.encode(params);
            long timestamp = System.currentTimeMillis() / 1000 - scannerInfo.getOffset();
            String stringA = "email=" + scannerInfo.getUsername() + params + "&timestamp=" + timestamp;
            stringA = D01Utils.parseParam(stringA);
            String stringSignTemp = stringA + "&secret_key=" + scannerInfo.getPassword();
            String sign = DigestUtils.md5DigestAsHex(stringSignTemp.getBytes()).toUpperCase();
            String url = scannerInfo.getAddress();
            String fullUrl = url + "/api/service/" + type + "?" + stringA + "&sign=" + sign;
            logger.info(fullUrl);
            HttpPost HTTPRequest = new HttpPost(fullUrl);
            RequestConfig requestConfig = RequestConfig.custom()
                    .setConnectTimeout(45000).setConnectionRequestTimeout(45000)
                    .setSocketTimeout(45000).build();
            HTTPRequest.setConfig(requestConfig);
            response = httpClient.execute(HTTPRequest);
            int code = response.getStatusLine().getStatusCode();
            JSONObject result = JsonUtils.parse(DataUtils.toBodyString(response.getEntity()));
            if (code == 200) {
                if (result.containsKey("data")) {
                    if (result.getJSONObject("data").containsKey("id"))
                        return result.getJSONObject("data").getString("id");
                    else if (result.getJSONObject("data").containsKey("ids")) {
                        return result.getJSONObject("data").getString("ids");
                    } else if (result.getJSONObject("data").containsKey("task_id")) {
                        return result.getJSONObject("data").getString("task_id");
                    }
                } else {
                    logger.error("获取数据错误：" + result);
                }
            } else {
                logger.error("获取数据错误非200OK：" + result);
            }
        } catch (Exception e) {
            logger.error(e.getMessage(), e);
        } finally {
            IOUtils.close(response);
        }
        return "";
    }

    /**
     * type=threats 资产漏洞 type=assets 资产列表
     *
     * @param type
     * @return
     */
    public static int getTotal(DccConfig scannerInfo, String type) {
        int total = 0;
        CloseableHttpClient httpClient;
        CloseableHttpResponse response = null;
        try {
            if ("http".equalsIgnoreCase(scannerInfo.getMode())) {
                httpClient = HttpClients.createDefault();
            } else {
                httpClient = D01Utils.createAcceptSelfSignedCertificateClient();
            }
            long timestamp = System.currentTimeMillis() / 1000 - scannerInfo.getOffset();
            String stringA = "email=" + scannerInfo.getUsername() + "&page=1&size=1&timestamp=" + timestamp;
            stringA = D01Utils.parseParam(stringA);
            String stringSignTemp = stringA + "&secret_key=" + scannerInfo.getPassword();
            String sign = DigestUtils.md5DigestAsHex(stringSignTemp.getBytes()).toUpperCase();
            String url = scannerInfo.getAddress();
            String fullUrl = url + "/api/service/" + type + "?" + stringA + "&sign=" + sign;
            logger.info(fullUrl);
            HttpGet HTTPRequest = new HttpGet(fullUrl);
            RequestConfig requestConfig = RequestConfig.custom()
                    .setConnectTimeout(45000).setConnectionRequestTimeout(45000)
                    .setSocketTimeout(45000).build();
            HTTPRequest.setConfig(requestConfig);
            response = httpClient.execute(HTTPRequest);
            int code = response.getStatusLine().getStatusCode();
            if (code == 200) {
                JSONObject result = JsonUtils.parse(DataUtils.toBodyString(response.getEntity()));
                if (result.containsKey("data")) {
                    total = result.getJSONObject("data").getInteger("total");
                } else {
                    logger.error("获取条数错误：" + result);
                }
            } else {
                logger.error("获取条数错误非200OK：" + response.getStatusLine());
            }
        } catch (Exception e) {
            logger.error(e.getMessage(), e);
        } finally {
            IOUtils.close(response);
        }
        return total;
    }

    /**
     * type=threats 资产漏洞 type=assets 资产列表
     *
     * @param type
     * @return
     */
    public static int getTotal(DccConfig scannerInfo, String type, String param) {
        int total = 0;
        CloseableHttpClient httpClient;
        CloseableHttpResponse response = null;
        try {
            if ("http".equalsIgnoreCase(scannerInfo.getMode())) {
                httpClient = HttpClients.createDefault();
            } else {
                httpClient = D01Utils.createAcceptSelfSignedCertificateClient();
            }

            long timestamp = System.currentTimeMillis() / 1000 - scannerInfo.getOffset();
            String stringA = "email=" + scannerInfo.getUsername() + param + "&timestamp=" + timestamp;
            stringA = D01Utils.parseParam(stringA);
            String stringSignTemp = stringA + "&secret_key=" + scannerInfo.getPassword();
            String sign = DigestUtils.md5DigestAsHex(stringSignTemp.getBytes()).toUpperCase();
            String url = scannerInfo.getAddress();
            String fullUrl = url + "/api/service/" + type + "?" + stringA + "&sign=" + sign;
            logger.info(fullUrl);
            HttpGet HTTPRequest = new HttpGet(fullUrl);
            RequestConfig requestConfig = RequestConfig.custom()
                    .setConnectTimeout(45000).setConnectionRequestTimeout(45000)
                    .setSocketTimeout(45000).build();
            HTTPRequest.setConfig(requestConfig);
            response = httpClient.execute(HTTPRequest);
            int code = response.getStatusLine().getStatusCode();
            if (code == 200) {
                JSONObject result = JsonUtils.parse(DataUtils.toBodyString(response.getEntity()));
                if (result.getJSONObject("data") != null && result.getJSONObject("data").containsKey("total")) {
                    total = result.getJSONObject("data").getInteger("total");
                } else {
                    logger.error("获取条数错误：" + result);
                }
            } else {
                logger.error("获取条数错误非200OK：" + response.getStatusLine());
            }
        } catch (Exception e) {
            logger.error(e.getMessage(), e);
        } finally {
            IOUtils.close(response);
        }
        return total;
    }

    /**
     * type=threats 资产漏洞 type=assets 资产列表
     *
     * @param type
     * @return
     */
    public static JSONArray getList(DccConfig scannerInfo, String type, String param) {
        CloseableHttpClient httpClient;
        CloseableHttpResponse response = null;
        try {
            if ("http".equalsIgnoreCase(scannerInfo.getMode())) {
                httpClient = HttpClients.createDefault();
            } else {
                httpClient = D01Utils.createAcceptSelfSignedCertificateClient();
            }
            long timestamp = System.currentTimeMillis() / 1000 - scannerInfo.getOffset();
            String stringA = "email=" + scannerInfo.getUsername() + param + "&timestamp=" + timestamp;
            stringA = D01Utils.parseParam(stringA);
            String stringSignTemp = stringA + "&secret_key=" + scannerInfo.getPassword();
            String sign = DigestUtils.md5DigestAsHex(stringSignTemp.getBytes()).toUpperCase();
            String url = scannerInfo.getAddress();
            String fullUrl = url + "/api/service/" + type + "?" + stringA + "&sign=" + sign;
            logger.info(fullUrl);
            HttpGet HTTPRequest = new HttpGet(fullUrl);
            RequestConfig requestConfig = RequestConfig.custom()
                    .setConnectTimeout(45000).setConnectionRequestTimeout(45000)
                    .setSocketTimeout(45000).build();
            HTTPRequest.setConfig(requestConfig);
            response = httpClient.execute(HTTPRequest);
            int code = response.getStatusLine().getStatusCode();
            JSONObject result = JsonUtils.parse(DataUtils.toBodyString(response.getEntity()));
            //JsonUtils.print(result);
            if (code == 200) {
                if (result.containsKey("data")) {
                    if (result.getJSONObject("data").containsKey("data"))
                        return result.getJSONObject("data").getJSONArray("data");
                    else {
                        if (result.getJSONObject("data").containsKey("list")) {
                            return result.getJSONObject("data").getJSONArray("list");
                        } else
                            logger.info(result.toJSONString());
                    }
                } else {
                    logger.error("获取数据错误：" + result);
                }
            } else {
                logger.error("获取条数错误非200OK：" + result);
            }
        } catch (Exception e) {
            logger.error(e.getMessage(), e);
        } finally {
            IOUtils.close(response);
        }
        return null;
    }
}
