package com.crc.sync.d01;

import com.alibaba.fastjson.JSONArray;
import com.alibaba.fastjson.JSONObject;
import com.crc.common.utils.DataUtils;
import com.crc.common.utils.JsonUtils;
import com.crc.scanner.config.DccConfig;
import com.crc.secface.domain.VulnScanTaskRecordLog;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;


@Slf4j
public class DccTaskCenter {
    public static String PASS = "1";

    public static String startScanTask(DccConfig scaninfo, VulnScanTaskRecordLog task, String nodeName) {
        //logger.info(add(scaninfo, "groups", "&name=13&parent_id=4"));//ok
        boolean exist = true;
        if (StringUtils.isBlank(task.getJobId())) {
            //task.setTaskId(IdGen.uuid());
            exist = false;
        }

        String groupName = String.format("%s-%s", DataUtils.encode(DataUtils.getSubString(task.getTaskName(), 0, 19)), task.getTaskId());
        JSONArray groupList = DccTaskSync.getList(scaninfo, "groups", "&search=" + groupName);
        String groupId = "";
        //创建业务组
        if (groupList != null) {
            if (groupList.size() > 0) {
                JSONObject jsonObject = groupList.getJSONObject(0);
                if (jsonObject.containsKey("items")) {
                    JSONArray items = jsonObject.getJSONArray("items");
                    JSONObject json = items.getJSONObject(0);
                    groupId = JsonUtils.getStr(json, "id");
                }
                log.info("已有分组:" + groupId);
                task.setGroupId(groupId);
            }
        }
        if (StringUtils.isBlank(groupId)) {
            groupId = DccTaskSync.add(scaninfo, "groups", "&parent_id=1&name=" + groupName);
            task.setGroupId(groupId);
            log.info("创建分组:" + groupId);
        }

        if (StringUtils.isBlank(groupId)) {
            log.error("创建业务组:" + DataUtils.getSubString(task.getTaskName(), 0, 19));
            return "-1";
        }

        /*
         * 新任务需要添加IP段
         */
        if (!exist && StringUtils.isNotBlank(task.getScanContent())) {
            String ipRanges = "";
            for (String ip : task.getScanContent().split("\n")) {
                if (StringUtils.isBlank(ip.trim()))
                    continue;
                if (StringUtils.isBlank(ipRanges)) {
                    ipRanges = ip.trim();
                } else {
                    ipRanges += "," + ip.trim();
                }
            }
            String id = DccTaskSync.add(scaninfo, "ip_ranges", String.format("&gid=%s&ip_ranges=%s", groupId, ipRanges));
            log.info("创建IP段:" + id);
        }
        //VulTask  0-全部，1-漏洞扫描，2-资产探测
        /*
         * band_width: "500"
         * category: ["1"]
         * cycle_protocol: 0
         * deep_scan: 0
         * name: "本地测试漏洞下发"
         * ping: 0
         * port: 7
         * protocol_concurrency: "0"
         * scan_node_target: ["MIDZ98DK3J6F6XF"]
         * scan_target: [35]
         * scan_target_type: 2
         */
        String params = "&name=" + DataUtils.encode(DataUtils.getSubString(task.getTaskName(),0,19)) + "&scan_target=" + groupId + "&scan_node_target=" + nodeName;
        String id = DccTaskSync.add(scaninfo, "taskRecords", "&scan_target_type=2&band_width=500&category=3&ping=0&port=7&protocol_concurrency=0&deep_scan=0&cycle_protocol=0" + params);
        if (StringUtils.isNotBlank(id)) {
            task.setJobId(id);
            task.setScanStatus(1);
            log.info("创建漏洞扫描立即任务：" + id);
            return DccTaskCenter.PASS;
        }
        log.error("创建漏洞扫描立即任务失败,name={}", task.getTaskName());
        return "-1";
    }


    public static void delScanTask(DccConfig d01Config, VulnScanTaskRecordLog assetVulTask) {
        DccTaskSync.del(d01Config, "taskRecords/" + assetVulTask.getJobId(), "");
    }

}
