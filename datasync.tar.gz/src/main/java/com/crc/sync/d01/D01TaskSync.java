package com.crc.sync.d01;

import com.alibaba.fastjson.JSONArray;
import com.alibaba.fastjson.JSONObject;
import com.crc.common.utils.HttpUtils;
import com.crc.common.utils.JsonUtils;
import com.crc.scanner.config.DccConfig;
import com.crc.secface.domain.VulnScanTaskRecordLog;
import com.crc.secface.domain.vo.JoeyeToken;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;

@Slf4j
public class D01TaskSync {
    public static String startScanTask(DccConfig scannerInfo, VulnScanTaskRecordLog task) {
        /*
        curl -X POST "https://[device-ip]/api/v2/tasks/taskings5" -H "accept: application/json" -H "X-Access-Token: xxx" -H "Content-Type: application/json" -d
         --data-binary  {
               file : test       #上传文件Id列表.
                   当selected_ip_ranges为upload_file时，此字段为必填.
                  pocscantype : normal       #PoC范围, "normal": 普通PoC, "weak_pwd": 弱口令, "all": 全部PoC, "special": 指定PoC
                  selectedipranges : all       #任务要扫描的ip范围.all或10.10.10.0/24,10.10.10.1-100, 多个ip段用英文逗号(,)隔开; upload_file代表上传文件，要在file字段里加上文件。.
                  selectedpocs : 1,2,3       #当poc_scan_type为special时需要此参数,poc的poc_id用逗号间隔，如：1,2,3.
                  bandwidth : 300      #扫描带宽.
                  begintime : once      #开始时间
                  category : task      #任务类型.
                  deepscan : off      #深度扫描, 可选参数,　只有scan_type为quick时有效, on: 开启, off: 关闭
                  iptype : 1      #IP类型. 可选项(ipv4:1, ipv6:2)1:扫描ipv4，2:扫描ipv6, 默认为1, 只有scan_type为common时才支持ipv6
                  repeattype : once      #重复类型. 可选项（执行一次 ：once ，每周重复：weekly，每日重复 ：daily，每月重复 ：monthly）
                  scanporttemplateid : 7      #端口分组id.
                  scantype : quick      #扫描类型, common: 精准扫描， quick: 极速扫描, 默认: common
                  tasktype : 3      #任务类型，1:资产扫描、2:漏洞扫描、3:资产及漏洞扫描.
                  title : test任务      #标题名称.
               }
        }
         */
        /*
        {"title":"HEJS","bandwidth":300,"category":"task","concurrency":0,"ip_range_type":"user_input","ip_type":1,
        "other_cfgs":{"is_deep_scan":false,"is_treck_recognition":false,"is_ping_recognition":false,"is_cycle_protocol":false,
        "is_deep_recognition":false,"is_crack_dns":false,"is_version_recognition":false,"is_crawler":false,"is_disable_scan_print":false},
        "poc_scan_type":"all","scan_port_template_id":7,"scan_type":"common","selected_ip_ranges":["10.54.238.51","10.54.238.52","10.54.238.150","10.54.238.151","10.54.238.50"],"task_type":3}
         */
        String email = scannerInfo.getUsername();
        JoeyeToken joeyeToken = D01AssetSync.getKey(scannerInfo);
        if (joeyeToken == null) {
            log.error("创建漏洞扫描立即任务失败：{},name={}", "获取Token失败！" , task.getTaskName());
            return null;
        }
        int portTmpId = D01AssetSync.getPortTemplateId(scannerInfo, joeyeToken);
        log.info("获取端口模板 ID:{}",portTmpId);
        JSONObject jsonObject = new JSONObject();
        jsonObject.put("selected_ip_ranges", task.getIp());
        jsonObject.put("poc_scan_type", "all");
        JSONObject tasking = new JSONObject();
        tasking.put("title", task.getTaskName());
        tasking.put("bandwidth", 500);
        tasking.put("repeat_type", "once");
        tasking.put("begin_time", "once");
        tasking.put("task_type", 3);
        tasking.put("scan_type", "common");
        tasking.put("category", "task");
        tasking.put("deep_scan", "on");
        tasking.put("poc_scan_type", "normal");
        tasking.put("scan_port_template_id", portTmpId);
        tasking.put("ip_type", 1);
        jsonObject.put("tasking", tasking);

        JSONObject otherCfgs = new JSONObject();
        otherCfgs.put("protocol_concurrency", 1);
        //otherCfgs.put("protocolconcurrency", 1);
        otherCfgs.put("ping", "on");
        otherCfgs.put("treck_scan", "on");
        //otherCfgs.put("treckscan", "on");
        otherCfgs.put("deep_recognition", "on");
        //otherCfgs.put("deeprecognition", "on");
        otherCfgs.put("cycle_protocol", "off");
        //otherCfgs.put("cycleprotocol", "off");
        otherCfgs.put("version_recognition", "off");
        //otherCfgs.put("versionrecognition", "off");
        otherCfgs.put("crack_dns", "off");
        //otherCfgs.put("crackdns", "off");
        tasking.put("other_cfgs", otherCfgs);

        String fullUrl = scannerInfo.getAddress() + "/api/v2/tasks/taskings" + String.format("?email=%s&key=%s", email, joeyeToken.getToken());
        log.debug(jsonObject.toJSONString());
        String jsonStr = HttpUtils.sendPost(fullUrl, jsonObject.toJSONString());
        JSONObject retJson = JsonUtils.parse(jsonStr);
        if (retJson.containsKey("status_code") && "200".equals(JsonUtils.getStr(retJson, "status_code"))) {
            String id = JsonUtils.getStr(retJson, "task_id");
            if (StringUtils.isNotBlank(id)) {
                task.setJobId(id);
                task.setScanStatus(1);
                log.info("创建漏洞扫描立即任务：{},name={}", id, task.getTaskName());
                return DccTaskCenter.PASS;
            }
        }else {
            log.error("创建漏洞扫描立即任务失败：{},name={}", jsonStr, task.getTaskName());
        }

        return "";
    }

    public static String startScanTaskV3(DccConfig scannerInfo, VulnScanTaskRecordLog task) {
        /*
        {
            "selected_ip_ranges": "",//多个 ip 段用英文逗号(,)隔开
            "ip_range_type": "all",
            "poc_scan_type": "all",
            "selected_pocs": "",
            "tasking": {
                "title": "test 任务",
                "task_type": 3,
                "scan_port_template_id": 1,
                "bandwidth": 500,
                "scan_type": "common",
                "deep_scan": "on",
                "ip_type": 1,
                "other_cfgs": {
                    "protocol_concurrency": 1,
                    "ping": "on",
                    "cycle_protocol": "off",
                    "treck_scan": "on",
                    "version_recognition": "off",
                    "deep_recognition": "on",
                    "crack_dns": "off"
                }
            }
        }
         */
        String email = scannerInfo.getUsername();
        JoeyeToken joeyeToken = D01AssetSync.getKey(scannerInfo);
        if (joeyeToken == null) {
            log.error("创建漏洞扫描立即任务失败：{},name={}", "获取Token失败！" , task.getTaskName());
            return null;
        }
        int portTmpId = D01AssetSync.getPortTemplateId(scannerInfo, joeyeToken);
        log.info("获取端口模板 ID:{}",portTmpId);
        JSONObject jsonObject = new JSONObject();
        jsonObject.put("selected_ip_ranges", task.getIp());
        jsonObject.put("poc_scan_type", "all");
        jsonObject.put("ip_range_type", "user_input");
        jsonObject.put("selected_pocs", "");
        JSONObject tasking = new JSONObject();
        tasking.put("title", task.getTaskName());
        tasking.put("task_type", 3);
        //tasking.put("tasktype", 3);
        tasking.put("scan_port_template_id", portTmpId);
        //tasking.put("scanporttemplateid", portTmpId);
        tasking.put("bandwidth", 500);
        tasking.put("scan_type", "common");
        //tasking.put("scantype", "common");
        tasking.put("deep_scan", "on");
        //tasking.put("deepscan", "on");
        tasking.put("ip_type", 1);
        //tasking.put("iptype", 1);
        jsonObject.put("tasking", tasking);

        JSONObject otherCfgs = new JSONObject();
        otherCfgs.put("protocol_concurrency", 1);
        //otherCfgs.put("protocolconcurrency", 1);
        otherCfgs.put("ping", "on");
        otherCfgs.put("treck_scan", "on");
        //otherCfgs.put("treckscan", "on");
        otherCfgs.put("deep_recognition", "on");
        //otherCfgs.put("deeprecognition", "on");
        otherCfgs.put("cycle_protocol", "off");
        //otherCfgs.put("cycleprotocol", "off");
        otherCfgs.put("version_recognition", "off");
        //otherCfgs.put("versionrecognition", "off");
        otherCfgs.put("crack_dns", "off");
        //otherCfgs.put("crackdns", "off");
        tasking.put("other_cfgs", otherCfgs);


        String fullUrl = scannerInfo.getAddress() + "/api/v2/tasks/taskings" + String.format("?email=%s&key=%s", email, joeyeToken.getToken());
        String jsonStr = HttpUtils.sendPost(fullUrl, jsonObject.toJSONString());
        JSONObject retJson = JsonUtils.parse(jsonStr);
        //{"status":"ok", "task_id": 1, "msg":"任务创建成功", "status_code": 200}
        if (retJson.containsKey("status_code") && "200".equals(JsonUtils.getStr(retJson, "status_code"))) {
            String id = JsonUtils.getStr(retJson, "task_id");
            if (StringUtils.isNotBlank(id)) {
                task.setJobId(id);
                task.setScanStatus(1);
                log.info("创建漏洞扫描立即任务：{},name={}", id, task.getTaskName());
                return DccTaskCenter.PASS;
            }
        }else {
            log.error("创建漏洞扫描立即任务失败：{},name={}", jsonStr, task.getTaskName());
        }

        return "";
    }
}
