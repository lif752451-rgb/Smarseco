package com.crc.sync.d01;

import com.alibaba.fastjson.JSONArray;
import com.alibaba.fastjson.JSONObject;
import com.crc.common.enums.AssetSourceEnums;
import com.crc.common.enums.ScannerEnums;
import com.crc.common.utils.DataUtils;
import com.crc.common.utils.IOUtils;
import com.crc.common.utils.IpUtils;
import com.crc.common.utils.JsonUtils;
import com.crc.scanner.config.DccConfig;
import com.crc.scanner.tool.D01Utils;
import com.crc.secface.config.GetSpringBean;
import com.crc.secface.domain.Asset;
import com.crc.secface.domain.AssetPort;
import com.crc.secface.domain.AssetSoftware;
import com.crc.secface.queue.CrcAssetSyncQueue;
import com.crc.secface.schedule.assemble.CommonAssemble;
import com.crc.secface.schedule.assemble.host.DccAssemble;
import com.crc.secface.service.AssetRecordService;
import com.crc.sync.work.PortSaveWork;
import org.apache.commons.lang3.StringUtils;
import org.apache.http.HttpEntity;
import org.apache.http.client.config.RequestConfig;
import org.apache.http.client.methods.CloseableHttpResponse;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.impl.client.CloseableHttpClient;
import org.apache.http.impl.client.HttpClients;
import org.apache.http.util.EntityUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.util.DigestUtils;


public class DccAssetSync {
    private static final Logger logger = LoggerFactory.getLogger(DccAssetSync.class);

    public void sync() {
        try {
            CommonAssemble.engineMap.forEach((k, v) -> {
                if (ScannerEnums.DCC_SCANNER.getCode().equals(v.getEquipmentManufacture())) {
                    syncDcc(DccAssemble.getDccConfig(k), "assets");
                }
            });
        } catch (Exception e) {
            logger.error(e.getMessage(), e);
        }
    }

    /**
     * type=threats 资产漏洞 type=assets 资产列表
     *
     * @param type 资产漏洞/资产列表
     */
    public void syncDcc(DccConfig d01Config, String type) {
        int total = getDccTotal(d01Config, type);
        logger.info("开始同步Dcc数据，数据量：" + total);
        if (total > 0) {
            int pageSize = 500;
            for (int i = 1; i < DataUtils.getPageCount(total, pageSize, 1); i++) {
                //for (int i = 1; i <= total; i += pageSize) {
                CloseableHttpClient httpClient;
                CloseableHttpResponse response = null;
                try {
                    httpClient = D01Utils.createAcceptSelfSignedCertificateClient();
                    long timestamp = System.currentTimeMillis() / 1000 - d01Config.getOffset();
                    String stringSignTemp = "email=" + d01Config.getUsername() + "&page=" + i + "&size=" + pageSize + "&timestamp="
                            + timestamp + "&secret_key=" + d01Config.getPassword();
                    String sign = DigestUtils.md5DigestAsHex(stringSignTemp.getBytes()).toUpperCase();
                    String url = d01Config.getAddress();
                    String fullUrl = url + "/api/service/" + type + "?email=" + d01Config.getUsername() + "&page=" + i
                            + "&size=" + pageSize + "&timestamp=" + timestamp + "&sign=" + sign;
                    HttpGet HTTPRequest = new HttpGet(fullUrl);
                    RequestConfig requestConfig = RequestConfig.custom()
                            .setConnectTimeout(45000).setConnectionRequestTimeout(45000)
                            .setSocketTimeout(45000).build();
                    HTTPRequest.setConfig(requestConfig);
                    response = httpClient.execute(HTTPRequest);
                    int code = response.getStatusLine().getStatusCode();
                    if (code == 200) {
                        JSONObject result = JsonUtils.parse(DataUtils.toBodyString(response.getEntity()));
                        boolean flag = false;
                        if (result.containsKey("list")) {
                            JSONArray arr = result.getJSONArray("list");
                            if (arr != null && arr.size() > 0) {
                                flag = true;
                                saveDcc(type, arr);
                            }
                        }
                        if (!flag && result.containsKey("data")) {
                            saveDcc(type, result.getJSONObject("data").getJSONArray("list"));
                        }
                    } else {
                        logger.error("获取数据错误非200OK：" + response.getStatusLine());
                    }
                } catch (Exception e) {
                    logger.error(e.getMessage(), e);
                } finally {
                    IOUtils.close(response);
                }
            }
        }
        logger.info("Dcc数据同步完成！");
    }

    /**
     * type=threats 资产漏洞 type=assets 资产列表
     *
     * @param type 资产漏洞/资产列表
     * @return int
     */
    public int getDccTotal(DccConfig d01Config, String type) {
        int total = 0;
        CloseableHttpClient httpClient;
        CloseableHttpResponse response = null;
        try {
            if ("http".equalsIgnoreCase(d01Config.getMode())) {
                httpClient = HttpClients.createDefault();
            } else {
                httpClient = D01Utils.createAcceptSelfSignedCertificateClient();
            }
            long timestamp = System.currentTimeMillis() / 1000 - d01Config.getOffset();
            String stringA = "email=" + d01Config.getUsername() + "&page=1&size=1&timestamp=" + timestamp;
            String stringSignTemp = stringA + "&secret_key=" + d01Config.getPassword();
            String sign = DigestUtils.md5DigestAsHex(stringSignTemp.getBytes()).toUpperCase();
            String url = d01Config.getAddress();
            String fullUrl = url + "/api/service/" + type + "?email=" + d01Config.getUsername() + "&page=1&size=1&timestamp=" + timestamp + "&sign=" + sign;
            HttpGet HTTPRequest = new HttpGet(fullUrl);
            RequestConfig requestConfig = RequestConfig.custom()
                    .setConnectTimeout(45000).setConnectionRequestTimeout(45000)
                    .setSocketTimeout(45000).build();
            HTTPRequest.setConfig(requestConfig);
            response = httpClient.execute(HTTPRequest);
            int code = response.getStatusLine().getStatusCode();
            JSONObject result = JsonUtils.parse(DataUtils.toBodyString(response.getEntity()));
            if (code == 200) {
                if (result.containsKey("data")) {
                    total = result.getJSONObject("data").getInteger("total");
                } else {
                    logger.error("获取条数错误：" + result);
                }
            } else {
                logger.error("获取条数错误非200OK：" + result);
            }
        } catch (Exception e) {
            logger.error(e.getMessage(), e);
        } finally {
            IOUtils.close(response);
        }
        return total;
    }


    public void saveDcc(String type, JSONArray dataList) {
        try {
            if (dataList == null) {
                return;
            }
            //logger.info(dataList.size());
            logger.info("获取到DCC资产数量:" + dataList.size());
            int total = 0;
            for (int i = 0; i < dataList.size(); i++) {
                try {
                    JSONObject jsonx = dataList.getJSONObject(i);
                    JSONObject json = jsonx.getJSONObject("_source");
                    if ("assets".equals(type)) {
                        boolean ret = procData(json);
                        if (ret) {
                            total++;
                        }
                    }
                } catch (Exception e) {
                    logger.error(e.getMessage(), e);
                }
            }
            logger.info("清洗成功，获取到DCC资产数量:" + total);
        } catch (Exception e) {
            logger.error(e.getMessage(), e);
        }
    }

    /**
     * 获取数据并解析
     */
    public boolean procData(JSONObject jsonData) {
        boolean flag = false;
        try {
            String ip = JsonUtils.getStr(jsonData, "ip");//IP地址
            if (!IpUtils.isIp(ip)) {
                logger.error("DCC资产无效IP=" + ip);
                return false;
            }

            CrcAssetSyncQueue.getInstance().saveData(ip, jsonData, AssetSourceEnums.D01_CMDB.getCode());

            //long office_id = JsonUtils.getLong(jsonData, "office_id");//节点id名称
            String mid_name = JsonUtils.getStr(jsonData, "mid_name");//节点id名称
            //String ip_online = JsonUtils.getStr(jsonData, "ip_online");
            //String proxy = JsonUtils.getStr(jsonData, "proxy");//是否代理理 0没有代理理 1有代理理
            //String externalIp = JsonUtils.getStr(jsonData, "externalIp");//外部IP
            String kernelVersion = JsonUtils.getStr(jsonData, "kernelVersion");//内核版本
            //String hostname = JsonUtils.getStr(jsonData, "hostname");//主机名
            String mac = JsonUtils.getStr(jsonData, "mac");//mac地址
            String os = JsonUtils.getStr(jsonData, "os");//操作系统
            //String mid = JsonUtils.getStr(jsonData, "mid");//漏洞描述

            Asset asset = new Asset();
            asset.setInternalIp(ip);
            asset.setOs(os);
            asset.setOfficeName(mid_name);
            if (StringUtils.isNotBlank(kernelVersion)) {
                asset.setOs(os + kernelVersion);
            }
            asset.setMacAddress(mac);
            Asset oldAsset = CrcAssetSyncQueue.getInstance().getAssetFullByIp(asset.getInternalIp());
            flag = saveAsset(asset);

            if(flag) {
                AssetRecordService assetRecordService = GetSpringBean.getBean(AssetRecordService.class);
                assetRecordService.addChangeRecord(oldAsset, CrcAssetSyncQueue.getInstance().getAssetFullByIp(asset.getInternalIp()));
            }
            if (jsonData.containsKey("ports")) {
                try {
                    JSONArray portArray = jsonData.getJSONArray("ports");
                    for (int i = 0; i < portArray.size(); i++) {
                        JSONObject jsonObject = portArray.getJSONObject(i);
                        String protocol = JsonUtils.getStr(jsonObject, "protocol");
                        String port = JsonUtils.getStr(jsonObject, "port");
                        if (StringUtils.isNotBlank(port) && !"0".equals(port) && StringUtils.isNumeric(port)) {
                            String rule = JsonUtils.getStr(jsonObject, "rule").replace("[", "").replace("]", "").replace("\"", "").replace("-", "");
                            AssetPort assetPort = new AssetPort();
                            assetPort.setIp(ip);
                            assetPort.setPort(port);
                            assetPort.setProto(protocol);
                            assetPort.setType(rule);
                            assetPort.setSyncStatus(AssetSourceEnums.D01_CMDB.getCode());
                            assetPort.setDevType("1");
                            PortSaveWork.magicQueue.put(assetPort);
                        }
                    }
                } catch (Exception e) {
                    logger.error(e.getMessage(), e);
                }
            }
            if (jsonData.containsKey("rule_infos")) {
                try {
                    JSONArray jsonArray = jsonData.getJSONArray("rule_infos");
                    if (jsonArray == null || jsonArray.size() < 1) {
                        //无数据
                    } else {
                        for (int i = 0; i < jsonArray.size(); i++) {
                            JSONObject jsonObject = jsonArray.getJSONObject(i);
                            String first_cat_tag = JsonUtils.getStr(jsonObject, "first_cat_tag");
                            String second_cat_tag = JsonUtils.getStr(jsonObject, "second_cat_tag");
                            String company = JsonUtils.getStr(jsonObject, "company");
                            String title = JsonUtils.getStr(jsonObject, "title");
                            String ports = JsonUtils.getStr(jsonObject, "ports").replace("[", "").replace("]", "").replace("\"", "").replace("-", "");
                            AssetSoftware software = new AssetSoftware();
                            software.setSoftName(title);
                            software.setSortPort(ports);
                            software.setIp(ip);
                            software.setSoftManu(company);
                            software.setFirstCatTag(first_cat_tag);
                            software.setSecondCatTag(second_cat_tag);
                            software.setSource(AssetSourceEnums.GOBY_CMDB.getCode());
                        }
                    }
                } catch (Exception e) {
                    logger.error(e.getMessage(), e);
                }
            }
        } catch (Exception e) {
            logger.error(e.getMessage(), e);
        }
        return flag;
    }


    public boolean saveAsset(Asset asset) {
        try {
            if (StringUtils.isBlank(asset.getInternalIp())) {
                return false;
            }
            //资产类型：(服务器，通信网络设备，安全设备，物联网设备)
            /*
            服务器		["通用","Web","文件","数据库","云平台","其他服务器设备"]
           通信网络设备	["路由器","交换机","网络存储","无线网络","其他网络设备"]
           安全设备	["VPN产品","防火墙","远程审计堡垒机","漏洞扫描","网络入侵检测与防御","威胁分析与管理","防病毒网关","安全内容管理","其他安全设备","IPS","WAF","主机防护","容器防护","防病毒","态势感知","日志审计","数据库审计","堡垒机","威胁情报","蜜罐"]
           物联网设备	["视频监控","门禁系统","语音视频","工业控制","其他物联网设备"]
             */
            asset.setType("服务器");
            asset.setSubType("通用");
            //资产状态，可选项：1在用、2停用、3下架、4库存备用、5故障设备、6已临时关停、7待修、8在修、9闲置、10待报废、11报废、12转交
            asset.setOperatingStatus(1);
            //数据来源，仅详情展示；1传统资源池CMDB、2华润云CMDB、3青藤、4D01、5"
            asset.setSource(AssetSourceEnums.D01_CMDB.getCode());
            return  CrcAssetSyncQueue.getInstance().saveAsset(asset);
        } catch (Exception e) {
            logger.error(e.getMessage(), e);
        }
        return false;
    }
}
