package com.crc.sync.d01;

import com.alibaba.fastjson.JSONArray;
import com.alibaba.fastjson.JSONObject;
import com.crc.common.enums.AssetSourceEnums;
import com.crc.common.enums.ScannerEnums;
import com.crc.common.utils.DataUtils;
import com.crc.common.utils.HttpUtils;
import com.crc.common.utils.IpUtils;
import com.crc.common.utils.JsonUtils;
import com.crc.scanner.config.DccConfig;
import com.crc.secface.config.GetSpringBean;
import com.crc.secface.domain.Asset;
import com.crc.secface.domain.AssetPort;
import com.crc.secface.domain.AssetSoftware;
import com.crc.secface.domain.vo.JoeyeToken;
import com.crc.secface.queue.CrcAssetSyncQueue;
import com.crc.secface.schedule.assemble.CommonAssemble;
import com.crc.secface.schedule.assemble.host.FoeyeAssemble;
import com.crc.secface.service.AssetRecordService;
import com.crc.sync.work.PortSaveWork;
import com.crc.sync.work.SoftwareSaveWork;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;

@Slf4j
public class D01AssetSync {

    public void sync() {
        try {
            CommonAssemble.engineMap.forEach((k, v) -> {
                if (ScannerEnums.D01_SCANNER.getCode().equals(v.getEquipmentManufacture())) {
                    syncD01(FoeyeAssemble.getD01Config(k), "assets");
                }
            });
        } catch (Exception e) {
            log.error(e.getMessage(), e);
        }
    }

    /**
     * type=threats 资产漏洞 type=assets 资产列表
     *
     * @param type 资产漏洞/资产列表
     */
    public void syncD01(DccConfig d01Config, String type) {
        JoeyeToken joeyeToken = getKey(d01Config);
        if (joeyeToken == null || StringUtils.isBlank(joeyeToken.getToken())) {
            log.error("获取D01/Joeye key失败！");
            return;
        }
        int total = postTotal(d01Config, type, joeyeToken.getToken());
        log.info("开始同步D01数据，数据量：" + total);
        if (total > 0) {
            int pageSize = 500;
            for (int i = 1; i < (Math.ceil(total / pageSize) + 2); i++) {
                JSONObject json = new JSONObject();
                json.put("page", i);
                json.put("per_page", pageSize);
                json.put("type", "query");
                String url = d01Config.getAddress();
                String email = d01Config.getUsername();
                String fullUrl = url + "/api/v2/" + type + String.format("?email=%s&key=%s", email, joeyeToken.getToken());
                String jsonStr = HttpUtils.sendPost(fullUrl, json.toJSONString());
                JSONObject jsonObject = JsonUtils.parse(jsonStr);
                if (jsonObject.containsKey("status_code") && "200".equals(JsonUtils.getStr(jsonObject, "status_code"))) {
                    //操作成功
                    if (jsonObject.containsKey("list")) {
                        saveD01(type, jsonObject.getJSONArray("list"));
                    } else {
                        log.error("获取数据错误：" + jsonStr);
                    }
                } else {
                    log.error("获取数据错误非200OK：" + jsonStr);
                }
            }
        }
    }

    /**
     * curl -X POST 'https://[device-ip]/api/v2/assets?email=[emails]&key=[key]' \
     * -H 'Content-Type: application/json' \
     * --data-binary '{
     * "page": 1,
     * "per_page": 15,
     * "vulnerabilities": true,
     * "type": "query",
     * "keyword": "10.10.10.183"
     * }'
     *
     * @param type
     * @return
     */
    public static int postTotal(DccConfig scannerInfo, String type, String key) {
        int total = 0;
        JSONObject json = new JSONObject();
        json.put("page", 1);
        json.put("per_page", 1);
        json.put("type", "query");
        String url = scannerInfo.getAddress();
        String email = scannerInfo.getUsername();
        String fullUrl = url + "/api/v2/" + type + String.format("?email=%s&key=%s", email, key);
        String jsonStr = HttpUtils.sendPost(fullUrl, json.toJSONString());
        log.info(jsonStr);
        JSONObject jsonObject = JsonUtils.parse(jsonStr);
        if (jsonObject.containsKey("status_code") && "200".equals(JsonUtils.getStr(jsonObject, "status_code"))) {
            //操作成功
            return JsonUtils.getInt(jsonObject, "total_entries");
        } else {
            log.error("获取数据错误非200OK：" + jsonStr);
        }
        return total;
    }

    public static int getTotal(DccConfig scannerInfo, String type, String key) {
        int total = 0;
        String url = scannerInfo.getAddress();
        String email = scannerInfo.getUsername();
        String fullUrl = url + "/api/v2/" + type;
        String param = String.format("email=%s&key=%s", email, key) + "&page=1&per_page=1";
        String jsonStr = HttpUtils.sendGet(fullUrl, param);
        JSONObject jsonObject = JsonUtils.parse(jsonStr);
        if (jsonObject.containsKey("status_code") && "200".equals(JsonUtils.getStr(jsonObject, "status_code"))) {
            //操作成功
            return JsonUtils.getInt(jsonObject, "total_entries");
        } else {
            log.error("获取数据错误非200OK：" + jsonStr);
        }
        return total;
    }


    public static String getData(DccConfig scannerInfo, String type, String key, String id) {
        String url = scannerInfo.getAddress();
        String email = scannerInfo.getUsername();
        String fullUrl = url + "/api/v2/" + type;
        String param = String.format("email=%s&key=%s", email, key) + "&id=" + id;
        return HttpUtils.sendGet(fullUrl, param);
    }


    public void saveD01(String type, JSONArray dataList) {
        try {
            //logger.info(dataList.size());
            log.info("获取到D01资产数量:" + dataList.size());
            int total = 0;
            for (int i = 0; i < dataList.size(); i++) {
                try {
                    JSONObject json = dataList.getJSONObject(i);
                    if ("assets".equals(type)) {
                        boolean ret = procData(json);
                        if (ret) {
                            total++;
                        }
                    }
                } catch (Exception e) {
                    log.error(e.getMessage(), e);
                }
            }
            log.info("清洗成功，获取到D01资产数量:" + total);
        } catch (Exception e) {
            log.error(e.getMessage(), e);
        }
    }

    /**
     * 获取数据并解析
     */
    public boolean procData(JSONObject jsonData) {
        boolean flag = false;
        try {
            String ip = JsonUtils.getStr(jsonData, "ip");//IP地址
            if (!IpUtils.isIp(ip)) {
                log.error("D01资产无效IP=" + jsonData.toJSONString());
                return false;
            }

            CrcAssetSyncQueue.getInstance().saveData(ip, jsonData, AssetSourceEnums.D01_CMDB.getCode());

            String status = JsonUtils.getStr(jsonData, "status");//1:在线, 0:离线
            String name = JsonUtils.getStr(jsonData, "name");//内核版本
            String mac = JsonUtils.getStr(jsonData, "mac");//mac地址
            String username = JsonUtils.getStr(jsonData, "username");//mac地址
            String managerMobile = JsonUtils.getStr(jsonData, "manager_mobile");//mac地址
            String managerEmail = JsonUtils.getStr(jsonData, "manager_email");//mac地址
            CrcAssetSyncQueue.getInstance().saveAssetPerson(ip, username, "1");
            Asset asset = new Asset();
            asset.setInternalIp(ip);
            asset.setMacAddress(mac);
            //资产状态，可选项：1在用、2停用、3下架、4库存备用、5故障设备、6已临时关停、7待修、8在修、9闲置、10待报废、11报废、12转交
            asset.setOperatingStatus(1);
            if (StringUtils.isBlank(name)) {
                asset.setInstance(name);
            }
            if (StringUtils.isBlank(asset.getInstance())) {
                asset.setInstance(ip);
            }
            if (jsonData.containsKey("port_list")) {
                try {
                    JSONArray portArray = jsonData.getJSONArray("port_list");
                    if (portArray == null || portArray.size() < 1) {
                        //无数据
                    } else {
                        for (int i = 0; i < portArray.size(); i++) {
                            JSONObject jsonObject = portArray.getJSONObject(i);
                            String protocol = JsonUtils.getStr(jsonObject, "protocol");
                            String port = JsonUtils.getStr(jsonObject, "port");
                            if (StringUtils.isNotBlank(port) && !"0".equals(port) && StringUtils.isNumeric(port)) {
                                String rule = JsonUtils.getStr(jsonObject, "banner");
                                rule = DataUtils.getSubString(rule, 1, 127);
                                AssetPort assetPort = new AssetPort();
                                assetPort.setIp(ip);
                                assetPort.setPort(port);
                                assetPort.setProto(protocol);
                                assetPort.setType(rule);
                                assetPort.setSyncStatus(AssetSourceEnums.D01_CMDB.getCode());
                                assetPort.setDevType("1");
                                PortSaveWork.magicQueue.put(assetPort);
                            }
                        }
                    }
                } catch (Exception e) {
                    log.error(e.getMessage(), e);
                }
            }
            if (jsonData.containsKey("rule_infos")) {
                try {
                    JSONArray jsonArray = jsonData.getJSONArray("rule_infos");
                    if (jsonArray == null || jsonArray.size() < 1) {
                        //无数据
                    } else {
                        for (int i = 0; i < jsonArray.size(); i++) {
                            JSONObject jsonObject = jsonArray.getJSONObject(i);
                            String first_cat_tag = JsonUtils.getStr(jsonObject, "first_cat_tag");
                            String second_cat_tag = JsonUtils.getStr(jsonObject, "second_cat_tag");
                            String title = JsonUtils.getStr(jsonObject, "title");
                            if ("操作系统".equals(second_cat_tag)) {
                                asset.setOs(title);
                            }
                            String company = JsonUtils.getStr(jsonObject, "company");
                            String ports = JsonUtils.getStr(jsonObject, "ports").replace("[", "").replace("]", "").replace("\"", "").replace("-", "");
                            AssetSoftware software = new AssetSoftware();
                            software.setSoftName(title);
                            software.setSortPort(ports);
                            software.setIp(ip);
                            software.setSoftManu(company);
                            software.setFirstCatTag(first_cat_tag);
                            software.setSecondCatTag(second_cat_tag);
                            software.setSource(AssetSourceEnums.D01_CMDB.getCode());
                            SoftwareSaveWork.magicQueue.put(software);
                        }
                    }
                } catch (Exception e) {
                    log.error(e.getMessage(), e);
                }
            }
            Asset oldAsset = CrcAssetSyncQueue.getInstance().getAssetFullByIp(asset.getInternalIp());
            flag = saveAsset(asset);

            if (flag) {
                AssetRecordService assetRecordService = GetSpringBean.getBean(AssetRecordService.class);
                assetRecordService.addChangeRecord(oldAsset, CrcAssetSyncQueue.getInstance().getAssetFullByIp(asset.getInternalIp()));
            }
        } catch (Exception e) {
            log.error(e.getMessage(), e);
        }
        return flag;
    }


    public boolean saveAsset(Asset asset) {
        try {
            if (StringUtils.isBlank(asset.getInternalIp())) {
                return false;
            }
            //资产类型：(服务器，通信网络设备，安全设备，物联网设备)
            /*
            服务器		["通用","Web","文件","数据库","云平台","其他服务器设备"]
           通信网络设备	["路由器","交换机","网络存储","无线网络","其他网络设备"]
           安全设备	["VPN产品","防火墙","远程审计堡垒机","漏洞扫描","网络入侵检测与防御","威胁分析与管理","防病毒网关","安全内容管理","其他安全设备","IPS","WAF","主机防护","容器防护","防病毒","态势感知","日志审计","数据库审计","堡垒机","威胁情报","蜜罐"]
           物联网设备	["视频监控","门禁系统","语音视频","工业控制","其他物联网设备"]
             */
            asset.setType("服务器");
            asset.setSubType("通用");
            //资产状态，可选项：1在用、2停用、3下架、4库存备用、5故障设备、6已临时关停、7待修、8在修、9闲置、10待报废、11报废、12转交
            asset.setOperatingStatus(1);
            //数据来源，仅详情展示；1传统资源池CMDB、2华润云CMDB、3青藤、4D01、5"
            asset.setSource(AssetSourceEnums.D01_CMDB.getCode());
            return CrcAssetSyncQueue.getInstance().saveAsset(asset);
        } catch (Exception e) {
            log.error(e.getMessage(), e);
        }
        return false;
    }

    /**
     * 获取 token
     */
    public static JoeyeToken getKey(DccConfig scannerInfo) {
        JSONObject json = new JSONObject();
        json.put("user", new JSONObject());
        json.getJSONObject("user").put("login", scannerInfo.getUsername());
        json.getJSONObject("user").put("password", scannerInfo.getPassword());
        String url = scannerInfo.getAddress();
        String fullUrl = url + "/api/v2/get_key";
        String jsonStr = HttpUtils.sendPost(fullUrl, json.toJSONString());
        JSONObject jsonObject = JsonUtils.parse(jsonStr);
        if (jsonObject.containsKey("status_code") && "200".equals(JsonUtils.getStr(jsonObject, "status_code"))) {
            //操作成功
            JoeyeToken token = new JoeyeToken();
            token.setToken(JsonUtils.getStr(jsonObject, "key"));
            token.setUsername(JsonUtils.getStr(jsonObject, "username"));
            token.setEmail(JsonUtils.getStr(jsonObject, "email"));
            token.setStatus(JsonUtils.getStr(jsonObject, "status"));
            return token;
        } else {
            log.error("获取 token 失败：" + jsonStr);
        }
        return null;
    }

    /**
     * 端口管理类接口
     */
    public static int getPortTemplateId(DccConfig scannerInfo, JoeyeToken token) {
        if (token == null) {
            return 1;
        }
        ///api/v2/scan_port_templates
        //curl -X GET 'https://[foeye-ip]/api/v2/scan_ports?email=[emails]&key=[key]'
        String url = scannerInfo.getAddress() + "/api/v2/scan_port_templates?email=" + token.getEmail() + "&key=" + token.getToken() + "&page=1&per_page=100";
        String jsonStr = HttpUtils.sendGet(url, null);
        //log.info(jsonStr);
        JSONObject jsonObject = JsonUtils.parse(jsonStr);
        if (jsonObject.containsKey("status_code") && "200".equals(JsonUtils.getStr(jsonObject, "status_code"))) {
            //操作成功
            if (jsonObject.containsKey("list")) {
                JSONArray arr = jsonObject.getJSONArray("list");
                if (arr != null) {
                    int count = 0;
                    int id = 1;
                    for (int i = 0; i < arr.size(); i++) {
                        String ports = JsonUtils.getStr(arr.getJSONObject(i), "ports");
                        if (StringUtils.isNotBlank(ports)) {
                            int size = ports.split(",").length;
                            if (count < size) {
                                count = size;
                                id = JsonUtils.getInt(arr.getJSONObject(i), "id");
                            }
                        }
                    }
                    return id;
                }
            }
        } else {
            log.error("获取数据错误非200OK：" + jsonStr);
        }
        return 1;
    }
}
