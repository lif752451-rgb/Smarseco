package com.crc.sync.jiaotu;


import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONArray;
import com.alibaba.fastjson.JSONObject;
import com.crc.common.enums.AssetSourceEnums;
import com.crc.common.enums.ScanTypeEnums;
import com.crc.common.enums.ScannerEnums;
import com.crc.common.utils.*;
import com.crc.scanner.config.JtConfig;
import com.crc.secface.config.GetSpringBean;
import com.crc.secface.domain.Asset;
import com.crc.secface.domain.VulnProcessForm;
import com.crc.secface.mapper.AssetMapper;
import com.crc.secface.queue.CrcAssetSyncQueue;
import com.crc.secface.schedule.assemble.CommonAssemble;
import com.crc.secface.schedule.assemble.host.JiaotuAssemble;
import com.crc.sync.cmdb.JiaotuCmdbSync;
import com.crc.sync.config.SyncSecConfigLoad;
import com.crc.sync.config.SyncSecConstants;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.apache.http.client.methods.CloseableHttpResponse;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.concurrent.atomic.AtomicInteger;

@Slf4j
public class JiaotuVulSync {
    public void sync() {
        counter.set(0);
        try {
            CommonAssemble.engineMap.forEach((k, v) -> {
                if (ScannerEnums.JIAOTU_SCANNER.getCode().equals(v.getEquipmentManufacture())) {
                    syncVuln(JiaotuAssemble.getJtConfig(k));
                }
            });
        } catch (Exception e) {
            log.error(e.getMessage(), e);
        }
    }

    private void syncVuln(JtConfig config) {
        if (SyncSecConfigLoad.isEnable(SyncSecConstants.JIAOTU_SYNC_ENABLE)) {
            if (!"NGSOC".equalsIgnoreCase(config.getVersion())) {
                log.info("支持 ngsoc 版本");
                return;
            }
            log.info("开始同步椒图漏洞数据");
            CloseableHttpResponse response = null;
            try {
                JSONObject q = new JSONObject();
                q.put("token", JiaotuCmdbSync.getToken(config));
                String ret = HttpUtils.sendPost(config.getAddress() + "/api/scanSrv/loopholesInfoController/listAll", q.toJSONString());
                JSONObject result = JsonUtils.parse(ret);
                //{"code":"1","msg":"成功","data":{"list":[],"total":0}}
                if (result.containsKey("data")) {
                    try {
                        JSONArray jarr = result.getJSONObject("data").getJSONArray("list");
                        saveVuln(config, jarr);
                    } catch (Exception e) {
                        log.error("获取数据错误：" + ret);
                    }
                } else {
                    log.error("获取数据错误：" + ret);
                }
            } catch (Exception e) {
                log.error(e.getMessage(), e);
            } finally {
                IOUtils.close(response);
            }
            log.info("椒图漏洞数据同步完成！");
        }
    }

    AtomicInteger counter = new AtomicInteger(0);

    private void saveVuln(JtConfig jtConfig, JSONArray rows) {
        log.info("处理椒图漏洞数据：" + counter.addAndGet(rows.size()));
        AssetMapper assetMapper = GetSpringBean.getBean(AssetMapper.class);
        for (int i = 0; i < rows.size(); i++) {
            JSONObject jsonData = null;
            try {
                jsonData = rows.getJSONObject(i);
            } catch (Exception e) {
                log.error("数据异常：{}", JSON.toJSONString(rows.get(i)));
            }
            if (jsonData == null) {
                continue;
            }
            String ip = JsonUtils.getStr(jsonData, "ip");//主机IP
            if (!IpUtils.isIp(ip)) {
                continue;
            }

            Asset asset = assetMapper.selectAssetByInnerIp(ip);
            if (asset == null || asset.getAffiliationDeptNodeId() == null) {
                asset = new Asset();
                asset.setInternalIp(ip);
                String hostname = JsonUtils.getStr(jsonData, "machineName");//主机名
                asset.setHostName(hostname);
                saveAsset(asset);
            }

            //获取单个agentId漏洞
            try {
                VulnProcessForm vul = getVulFromJson(jsonData,ip, jtConfig.getEngineId());
                if (vul != null) {
                    CommonAssemble.saveVul(vul);
                } else {
                    log.error("解析漏洞失败:" + JSON.toJSONString(jsonData));
                }
            } catch (Exception e) {
                log.error(e.getMessage(), e);
            }
        }
    }

    private VulnProcessForm getVulFromJson(JSONObject json,String ip, Long engineId) {
        String vulName = JsonUtils.getStr(json, "vulnerName");
        if (StringUtils.isBlank(vulName)) {
            return null;
        }
        String desc = JsonUtils.getStr(json, "summary") + ";" + JsonUtils.getStr(json, "detail");
        String solution = JsonUtils.getStr(json, "repairAdvice");
        Date firstCheckDate = JsonUtils.getDate(json, "createTime");
        Date publicDate = JsonUtils.getDateX(json, "releaseTime");

        //0:低危, 1:中危, 2:高危, 3:严重
        int level = 0;
        switch (JsonUtils.getInt(json, "impactLevel")) {
            case 0:
                break;
            case 2:
                level = 1;
                break;
            case 3:
                level = 2;
                break;
            case 4:
                level = 3;
                break;
            default:
        }
        String filter = SyncSecConfigLoad.getRemarkValue(SyncSecConstants.JIAOTU_SYNC_ENABLE);
        try {
            boolean flag = false;
            if (filter != null && filter.contains("=") && filter.contains("level")) {
                String filterLevel = filter.split("=")[1];
                String slevel = JsonUtils.getStr(json, "impactLevel");
                for (String fl : filterLevel.split(",")) {
                    if (StringUtils.isNotBlank(slevel) && slevel.equalsIgnoreCase(fl)) {
                        flag = true;
                        break;
                    }
                }
            } else {
                flag = true;
            }
            if (!flag) {
                return null;
            }
        } catch (Exception e) {
            log.error(e.getMessage(), e);
        }
        //漏洞特征 1：存在EXP 2：存在POC 3：远程执行 4：本地提权 5：内核漏洞
        List<String> feats = new ArrayList<>();
        try {
            if (json.containsKey("hasExp")) {
                if (json.getBoolean("hasExp") == null || json.getBoolean("hasExp")) {
                    feats.add("1");
                }
            }
            if (json.containsKey("hasPoc")) {
                if (json.getBoolean("hasPoc") == null || json.getBoolean("hasPoc")) {
                    feats.add("2");
                }
            }
            if (json.containsKey("remote")) {
                if (json.getBoolean("remote") == null || json.getBoolean("remote")) {
                    feats.add("3");
                }
            }
            if (json.containsKey("localEscalation")) {
                if (json.getBoolean("localEscalation") == null || json.getBoolean("localEscalation")) {
                    feats.add("4");
                }
            }
            if (json.containsKey("kernel")) {
                if (json.getBoolean("kernel") == null || json.getBoolean("kernel")) {
                    feats.add("5");
                }
            }
        } catch (Exception e) {
            log.error(e.getMessage(), e);
        }
        String CVE = JsonUtils.getStr(json,"cveCode");

        VulnProcessForm vul = new VulnProcessForm();
        vul.setIp(ip);
        vul.setEngineId(String.valueOf(engineId));
        //修复影响：0-未知；1-无需重启；2-服务重启；3系统重启 （仅linux）
        vul.setVulHostInfluence(JsonUtils.getStr(json,"repairInfluence"));
        vul.setRefLink(JsonUtils.getStr(json, "officialLink"));
        vul.setCvss(JsonUtils.getStr(json, "cvssScore"));
        vul.setVulnName(vulName);
        vul.setCode(String.format("VUL_%s", IdGen.uuid8()));
        vul.setLevel(String.valueOf(level));
        vul.setSource(ScannerEnums.JIAOTU_SCANNER.getCode());
        String id = Md5Utils.hash(ip + "#" + vulName + "#" + CVE + "#" + vul.getSource());
        vul.setId(id);
        vul.setVulnType(JsonUtils.getStr(json, "type"));
        vul.setCategory(ScanTypeEnums.HOST_SCAN.getCode());
        vul.setDescription(desc);
        vul.setSolution(solution);
        vul.setAvailableCondition(JsonUtils.getStr(json, "exploitCondition"));
        vul.setCveCode(CVE);
        vul.setValidInfo(JsonUtils.getStr(json, "verificationInfo"));
        vul.setAffectApplication(JsonUtils.getStr(json, "impactVersion"));
        vul.setCreateTime(new Date());
        vul.setUpdateTime(new Date());
        vul.setFirstTime(firstCheckDate);
        vul.setRecentlyTime(firstCheckDate);
        vul.setPublishTime(publicDate);
        vul.setVulFeatures(String.join(",", feats));
        CommonAssemble.saveVulAssetInfo(vul, ip);
        return vul;
    }


    public void saveAsset(Asset asset) {
        try {
            if (StringUtils.isBlank(asset.getInternalIp())) {
                return;
            }

            //资产类型：(服务器，通信网络设备，安全设备，物联网设备)
            /*
            服务器		["通用","Web","文件","数据库","云平台","其他服务器设备"]
           通信网络设备	["路由器","交换机","网络存储","无线网络","其他网络设备"]
           安全设备	["VPN产品","防火墙","远程审计堡垒机","漏洞扫描","网络入侵检测与防御","威胁分析与管理","防病毒网关","安全内容管理","其他安全设备","IPS","WAF","主机防护","容器防护","防病毒","态势感知","日志审计","数据库审计","堡垒机","威胁情报","蜜罐"]
           物联网设备	["视频监控","门禁系统","语音视频","工业控制","其他物联网设备"]
             */
            asset.setType("服务器");
            asset.setSubType("通用");
            //资产状态，可选项：1在用、2停用、3下架、4库存备用、5故障设备、6已临时关停、7待修、8在修、9闲置、10待报废、11报废、12转交
            asset.setOperatingStatus(1);
            //数据来源，仅详情展示；1传统资源池CMDB、2华润云CMDB、3青藤、4D01、5"
            asset.setSource(AssetSourceEnums.JIAOTU_CMDB.getCode());
            CrcAssetSyncQueue.getInstance().saveAsset(asset);
        } catch (Exception e) {
            log.error(e.getMessage(), e);
        }
    }
}
