package com.crc.sync.cmdb.f5;

import com.alibaba.fastjson.JSONArray;
import com.alibaba.fastjson.JSONObject;
import com.baomidou.mybatisplus.core.conditions.query.LambdaQueryWrapper;
import com.baomidou.mybatisplus.core.toolkit.Wrappers;
import com.crc.common.enums.AssetSourceEnums;
import com.crc.common.utils.*;
import com.crc.secface.config.GetSpringBean;
import com.crc.secface.domain.*;
import com.crc.secface.mapper.*;
import com.crc.secface.queue.CrcAssetSyncQueue;
import com.crc.sync.work.PortSaveWork;
import com.google.common.collect.Lists;
import com.google.common.collect.Maps;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;

import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;

@Slf4j
public class F5CmdbSync {

    public void sync() {
        try {
            List<SysDictData> dictList = DictUtil.getDict("f5_cmdb_sync");
            for (SysDictData dictData : dictList) {
                if (StringUtils.isBlank(dictData.getDictValue()) || StringUtils.isBlank(dictData.getRemark())) {
                    continue;
                }
                JSONObject json = JsonUtils.parse(dictData.getRemark());
                if (JsonUtils.isEmpty(json)) {
                    log.error(dictData.getDictLabel() + "配置为空！");
                    continue;
                }
                syncData(dictData.getDictLabel(), json);
            }
        } catch (Exception e) {
            log.error(e.getMessage(), e);
        }
    }

    private void syncData(String dictLabel, JSONObject json) {
        /*
         * {
         *     "url": "http://127.0.0.1:800",
         *     "access-key": "5ujdBmloMQ4aVerWh4VaiznSxGtz"
         * }
         */
        log.info("{} start...", dictLabel);
        try {
            String url = JsonUtils.getStr(json, "url");
            getCmdbInstancesByPage(url, JsonUtils.getStr(json, "access-key"));
        } catch (Exception e) {
            log.error(e.getMessage(), e);
        }
        log.info("{} end...", dictLabel);
    }

    /**
     * 获取所有实例，里面可以得到资产IP和端口
     *
     * @param apiUrl
     * @param accessKey
     */
    public void getCmdbInstancesByPage(String apiUrl, String accessKey) {
        try {
            HashMap<String, String> typeMap = Maps.newHashMap();
            typeMap.put("instance", "标准实例");
            typeMap.put("micro_service", "微服务");
            typeMap.put("weblogicdomain", "WebLogic域");
            typeMap.put("weblogic", "WebLogic实例");
            typeMap.put("tomcat", "Tomcat实例");
            typeMap.put("nginx", "NGINX实例");
            typeMap.put("nginx_rule", "NGINX转发规则");
            typeMap.put("appservice", "应用服务实例");
            typeMap.put("bes", "bes_server");
            typeMap.put("besdomain", "bes_admin");
            typeMap.put("besnode", "bes_node");
            JSONObject headers = new JSONObject();
            headers.put("access-key", accessKey);
            String url = apiUrl + "/cmdb-server/openapi/v1/instance/record/getCmdbInstancesByPage";


            for (String type : typeMap.keySet()) {
                long total = getCmdbInstancesTotal(url, type, headers);
                log.error("getCmdbInstancesTotal={},type={}", total, type);
                int pagesize = 100;
                for (int index = 1; index < DataUtils.getPageCount(total, pagesize, 1); index++) {
                    HashMap<String, Asset> assetMap = Maps.newHashMap();
                    List<String> cmdbIdList = Lists.newArrayList();
                    JSONObject param = new JSONObject();
                    param.put("ciCode", type);
                    param.put("pagenum", index);
                    param.put("pagesize", pagesize);
                    String ret = HttpUtils.sendPost(url, param.toJSONString(), headers);
                    JSONObject retJson = JsonUtils.parse(ret);
                    if (JsonUtils.equal(retJson, "msgCode", "200")) {
                        try {
                            JSONObject dataJson = retJson.getJSONObject("data");

                            if (dataJson != null) {
                                JSONArray records = dataJson.getJSONArray("records");
                                if (records != null && records.size() > 0) {
                                    log.info("getCmdbInstancesByPage--size={},type={}", records.size(), type);
                                    for (int i = 0; i < records.size(); i++) {
                                        JSONObject data = records.getJSONObject(i);
                                        String cmdbId = JsonUtils.getStr(data, "cmdb_id");
                                        String status = JsonUtils.getStr(data, "status");
                                        String ip = JsonUtils.getStr(data, "ip");
                                        String port = JsonUtils.getStr(data, "port");
                                        if (!"1".equals(status)) {
                                            continue;
                                        }
                                        AssetPort assetPort = new AssetPort();
                                        assetPort.setPort(port);
                                        assetPort.setIp(ip);
                                        assetPort.setDevType("1");
                                        PortSaveWork.magicQueue.put(assetPort);

                                        Asset asset = new Asset();
                                        //资产等级,可选项：1核心、2重要、3一般
                                        asset.setKeyAsset(3);
                                        asset.setInternalIp(ip);
                                        asset.setAssetPort(port);
                                        if (StringUtils.isNotBlank(cmdbId)) {
                                            assetMap.put(cmdbId, asset);
                                            cmdbIdList.add(cmdbId);
                                        }
                                    }
                                }
                            }
                        } catch (Exception e) {
                            log.error(e.getMessage(), e);
                        }
                        if (cmdbIdList.size() > 0) {
                            getInstanceRelations(apiUrl, cmdbIdList, assetMap, headers);
                        }
                    } else {
                        log.error("查询getCmdbInstancesByPagee失败={},type={}", ret, type);
                    }
                }


            }

        } catch (Exception e) {
            log.error(e.getMessage(), e);
        }
    }

    /**
     * 获取实例对应的系统中文名system_name    和   cmdb_id
     *
     * @param apiUrl
     * @param cmdbIdList
     * @param assetMap
     * @param headers
     */
    private void getInstanceRelations(String apiUrl, List<String> cmdbIdList, HashMap<String, Asset> assetMap, JSONObject headers) {
        /*
         *     {
         *         "cmdbIds": ["tomcat_10000014","tomcat_10000015","tomcat_10000016"],
         *         "quoteCiCode": "application_system",
         *         "relationTypeName": "支持"
         *     }
         */
        HashMap<String, HashMap<String, Asset>> newAssetMap = Maps.newHashMap();
        List<String> appCmdbIdList = Lists.newArrayList();
        JSONObject param = new JSONObject();
        param.put("cmdbIds", cmdbIdList);
        param.put("quoteCiCode", "application_system");
        param.put("relationTypeName", "支持");
        String url = apiUrl + "/cmdb-server/openapi/v1/instance/relation/getInstanceRelations";
        String ret = HttpUtils.sendPost(url, param.toJSONString(), headers);
        JSONObject retJson = JsonUtils.parse(ret);
        if (JsonUtils.equal(retJson, "msgCode", "200")) {
            try {
                JSONArray dataJson = retJson.getJSONArray("data");
                if (dataJson != null && dataJson.size() > 0) {
                    for (int i = 0; i < dataJson.size(); i++) {
                        JSONObject data = dataJson.getJSONObject(i);
                        String instanceCmdbId = JsonUtils.getStr(data, "cmdbId");
                        JSONArray relations = data.getJSONArray("relations");
                        if (relations != null && relations.size() > 0 && assetMap.containsKey(instanceCmdbId)) {
                            JSONObject rel = relations.getJSONObject(0);
                            if (!JsonUtils.equal(rel, "status", "1")) {
                                continue;
                            }
                            String businessLevel = JsonUtils.getStr(rel, "business_level");
                            //资产等级,可选项：1核心、2重要、3一般
                            Asset asset = assetMap.get(instanceCmdbId);
                            asset.setKeyAsset(3);
                            asset.setSource(AssetSourceEnums.COMMON_CMDB.getCode());
                            if (businessLevel.contains("A")) {
                                asset.setKeyAsset(1);
                            } else if (businessLevel.contains("B")) {
                                asset.setKeyAsset(2);
                            } else {
                                asset.setKeyAsset(3);
                            }
                            asset.setTag(JsonUtils.getStr(rel, "label").replace(";", ","));
                            asset.setRemarks(JsonUtils.getStr(rel, "function"));
                            asset.setInstance(JsonUtils.getStr(rel, "system_name"));
                            asset.setInstanceCode(JsonUtils.getStr(rel, "system_code"));

                            String appCmdbId = JsonUtils.getStr(rel, "cmdb_id");
                            String assetCmdbId = appCmdbId + "&" + instanceCmdbId;
                            if (!newAssetMap.containsKey(assetCmdbId)) {
                                newAssetMap.put(assetCmdbId, new HashMap<>());
                            }
                            newAssetMap.get(assetCmdbId).put(instanceCmdbId, asset);
                            appCmdbIdList.add(appCmdbId);
                        }
                    }
                }
            } catch (Exception e) {
                log.error(e.getMessage(), e);
            }
        } else {
            log.error("ret={}", ret);
        }
        log.info("保存资产：{}", assetMap.size());
        assetMap.forEach((k, v) -> {
            try {
                CrcAssetSyncQueue.getInstance().saveAsset(v);
            } catch (Exception e) {
                log.error(e.getMessage(), e);
            }
        });
        if (appCmdbIdList.size() > 0) {
            getInstanceRelationsPm(apiUrl, appCmdbIdList, newAssetMap, headers);
        }
    }

    private void getInstanceRelationsPm(String apiUrl, List<String> appCmdbIdList, HashMap<String, HashMap<String, Asset>> newAssetMap, JSONObject headers) {
        /*
        {
            "cmdbIds": ["application_system_10000362","application_system_10001318"],
            "quoteCiCode": "staff",
            "relationTypeName": "由..管理"
        }
         */
        JSONObject param = new JSONObject();
        param.put("cmdbIds", appCmdbIdList);
        param.put("quoteCiCode", "staff");
        param.put("relationTypeName", "由..管理");
        String url = apiUrl + "/cmdb-server/openapi/v1/instance/relation/getInstanceRelations";
        String ret = HttpUtils.sendPost(url, param.toJSONString(), headers);
        JSONObject retJson = JsonUtils.parse(ret);
        HashMap<String, List<AssetPerson>> personHashMap = Maps.newHashMap();
        AssetPersonMapper assetPersonMapper = GetSpringBean.getBean(AssetPersonMapper.class);
        if (JsonUtils.equal(retJson, "msgCode", "200")) {
            try {
                JSONArray dataJson = retJson.getJSONArray("data");
                if (dataJson != null && dataJson.size() > 0) {
                    for (int i = 0; i < dataJson.size(); i++) {
                        JSONObject data = dataJson.getJSONObject(i);
                        String appCmdbId = JsonUtils.getStr(data, "cmdbId");
                        JSONArray relations = data.getJSONArray("relations");
                        if (relations != null && relations.size() > 0) {
                            for (int j = 0; j < relations.size(); j++) {
                                JSONObject rel = relations.getJSONObject(j);
                                if (!JsonUtils.equal(rel, "status", "1")) {
                                    continue;
                                }
                                newAssetMap.forEach((m, assetPortMap) -> {
                                    for (String temp : assetPortMap.keySet())
                                    {
                                        String[] assetKeyArr =  temp.split("&");
                                        if(assetKeyArr!=null && assetKeyArr.length>0 && assetKeyArr[0] == appCmdbId)
                                        {
                                            HashMap<String, Asset> assetMap = newAssetMap.get(temp);
                                            for (String ci : assetMap.keySet()) {
                                                Asset asset = assetMap.get(ci);
                                                if (asset.getId() == null) {
                                                    asset = CrcAssetSyncQueue.getInstance().getByIp(asset.getInternalIp());
                                                }
                                                if (asset.getId() == null) {
                                                    continue;
                                                }
                                                String account = JsonUtils.getStr(rel, "account");
                                                String email = JsonUtils.getStr(rel, "email");
                                                String name = JsonUtils.getStr(rel, "name");
                                                String phone = JsonUtils.getStr(rel, "phone");
                                                try {
                                                    AssetPerson assetPerson = new AssetPerson();
                                                    assetPerson.setAssetId(asset.getId().toString());
                                                    assetPerson.setType("1");//责任人
                                                    assetPerson.setUser(account);
                                                    assetPerson.setUserName(String.format("%s(%s)", name, account));
                                                    assetPerson.setPhone(phone);
                                                    assetPerson.setEmail(email);
                                                    if (StringUtils.isBlank(assetPerson.getUserName()) && StringUtils.isBlank(assetPerson.getPhone())) {
                                                        log.warn("{}--无效数据-资产责任人", asset.getInternalIp());
                                                        continue;
                                                    }

                                                    LambdaQueryWrapper<AssetPerson> q = Wrappers.lambdaQuery();
                                                    q.eq(AssetPerson::getAssetId, assetPerson.getAssetId());
                                                    q.eq(AssetPerson::getType, "1");
                                                    q.eq(AssetPerson::getUserName, assetPerson.getUserName());
                                                    if (StringUtils.isNotBlank(assetPerson.getPhone())) {
                                                        q.eq(AssetPerson::getPhone, assetPerson.getPhone());
                                                    }
                                                    q.last(" limit 1");
                                                    // 同步责任人导致资产认领bug，去掉
                                                    /* AssetPerson tmp = assetPersonMapper.selectOne(q);
                                                    if (tmp == null) {
                                                        assetPersonMapper.insert(assetPerson);
                                                    }*/
                                                    if (!personHashMap.containsKey(asset.getInternalIp())) {
                                                        personHashMap.put(asset.getInternalIp(), new ArrayList<>());
                                                    }
                                                    personHashMap.get(asset.getInternalIp()).add(assetPerson);
                                                } catch (Exception e) {
                                                    log.error(e.getMessage(), e);
                                                }

                                                syncUser(account, name, email, phone);
                                            }
                                        }
                                    }
                                });
                            }
                        }
                    }
                }
            } catch (Exception e) {
                log.error(e.getMessage(), e);
            }
        } else {
            log.error("ret={}", ret);
        }
        //AssetAppSystemMapper assetAppSystemMapper = GetSpringBean.getBean(AssetAppSystemMapper.class);
        /*
         *  更新应用系统信息
         */
        /*newAssetMap.forEach((k, assetMap) -> {
            for (String ci : assetMap.keySet()) {
                try {
                    Asset asset = assetMap.get(ci);
                    AssetAppSystem assetAppSystemOld = new AssetAppSystem();
                    assetAppSystemOld.setSysZhName(asset.getInstance());
                    if (asset.getKeyAsset() == 3) {
                        assetAppSystemOld.setSysLevel("0");
                        assetAppSystemOld.setSysLevelLabel("普通");
                    } else if (asset.getKeyAsset() == 2) {
                        assetAppSystemOld.setSysLevel("1");
                        assetAppSystemOld.setSysLevelLabel("重要");
                    } else if (asset.getKeyAsset() == 1) {
                        assetAppSystemOld.setSysLevel("2");
                        assetAppSystemOld.setSysLevelLabel("核心");
                    }
                    assetAppSystemOld.setSysStatus("0");
                    assetAppSystemOld.setSysStatusLabel("在用");

                    assetAppSystemOld.setSysType("0");
                    assetAppSystemOld.setSysTypeLabel("信息系统");
                    assetAppSystemOld.setDelFlag("0");


                    String[] assetkey =  k.split("&");
                    if(assetkey!=null && assetkey.length>0)
                    {
                        assetAppSystemOld.setId(assetkey[0]);
                        assetAppSystemOld.setAssetNumer(assetkey[0]);
                    }else
                    {
                        assetAppSystemOld.setId(k);
                        assetAppSystemOld.setAssetNumer(k);
                    }

                    if (personHashMap.containsKey(asset.getInternalIp())) {
                        List<AssetPerson> personList = personHashMap.get(asset.getInternalIp());
                        if (personList.size() > 0) {
                            List<String> accountList = Lists.newArrayList();
                            List<String> nameList = Lists.newArrayList();
                            HashMap<String, String> tm = new HashMap<>();
                            for (AssetPerson p : personList) {
                                if (tm.containsKey(p.getUserName())) {
                                    continue;
                                }
                                accountList.add(p.getUser());
                                nameList.add(p.getUserName());
                                tm.put(p.getUserName(), "1");
                            }

                            assetAppSystemOld.setDutyPerson(String.join(",", accountList));
                            assetAppSystemOld.setDutyPersonName(String.join(",", nameList));
                        }
                    }

                    LambdaQueryWrapper<AssetAppSystem> q = Wrappers.lambdaQuery();
                    q.eq(AssetAppSystem::getId, assetAppSystemOld.getId());
                    q.last(" limit 1");
                    updateFullAreaDept(assetAppSystemOld);
                    AssetAppSystem tmp = assetAppSystemMapper.selectOne(q);
                    if (tmp == null) {
                        assetAppSystemOld.setCreateTime(new Date());
                        assetAppSystemOld.setUpdateTime(new Date());
                        assetAppSystemMapper.insert(assetAppSystemOld);
                    } else {
                        assetAppSystemOld.setUpdateTime(new Date());
                        assetAppSystemMapper.updateAssetAppSystem(assetAppSystemOld);
                    }

                    *//*List<String> ports = Lists.newArrayList();
                    if (DataUtils.isInteger(asset.getAssetPort())) {
                        ports.add(asset.getAssetPort());
                    }*//*

                    AppSystemRelationAssetMapper appSystemRelationAssetMapper = GetSpringBean.getBean(AppSystemRelationAssetMapper.class);
                    LambdaQueryWrapper<AppSystemRelationAsset> qr = Wrappers.lambdaQuery();
                    qr.eq(AppSystemRelationAsset::getAppSystemId, assetAppSystemOld.getId());
                    qr.eq(AppSystemRelationAsset::getAssetId, asset.getId());
                    qr.last(" limit 1");
                    AppSystemRelationAsset tmpQr = appSystemRelationAssetMapper.selectOne(qr);
                    if (tmpQr == null) {
                        AppSystemRelationAsset appSystemRelationAsset = new AppSystemRelationAsset();
                        appSystemRelationAsset.setAppSystemId(assetAppSystemOld.getId());
                        appSystemRelationAsset.setAssetId(asset.getId());
                        appSystemRelationAsset.setDelFlag("0");
                        appSystemRelationAsset.setPort(asset.getAssetPort());
                        appSystemRelationAssetMapper.insert(appSystemRelationAsset);
                    } else {
                        if(!(tmpQr.getPort()+",").contains(asset.getAssetPort()+","))
                        {
                            tmpQr.setPort(tmpQr.getPort() + "," + asset.getAssetPort());
                            LambdaUpdateWrapper<AppSystemRelationAsset> ap = Wrappers.lambdaUpdate();
                            ap.eq(AppSystemRelationAsset::getId, tmpQr.getId());
                            ap.set(AppSystemRelationAsset::getPort, tmpQr.getPort());
                            appSystemRelationAssetMapper.update(null, ap);
                        }
                    }
                } catch (Exception e) {
                    log.error(e.getMessage(), e);
                }
            }
        });*/
    }

    private long getCmdbInstancesTotal(String url, String type, JSONObject headers) {
        try {
            JSONObject param = new JSONObject();
            param.put("ciCode", type);
            param.put("pagenum", 1);
            param.put("pagesize", 1);
            String ret = HttpUtils.sendPost(url, param.toJSONString(), headers);
            JSONObject retJson = JsonUtils.parse(ret);
            if (JsonUtils.equal(retJson, "msgCode", "200")) {
                JSONObject data = retJson.getJSONObject("data");
                if (data != null) {
                    return JsonUtils.getInt(data, "rowCount");
                }
            } else {
                log.error("ret={}", ret);
            }
        } catch (Exception e) {
            log.error(e.getMessage(), e);
        }
        return 0;
    }

    private void syncUser(String account, String name, String email, String phone) {
        SysRoleMapper sysRoleMapper = GetSpringBean.getBean(SysRoleMapper.class);
        SysUserMapper sysUserMapper = GetSpringBean.getBean(SysUserMapper.class);
        SysDeptMapper sysDeptMapper = GetSpringBean.getBean(SysDeptMapper.class);
        LambdaQueryWrapper<SysRole> qs = Wrappers.lambdaQuery();
        qs.eq(SysRole::getRoleKey, "common");
        List<SysRole> roleList = sysRoleMapper.selectList(qs);
        List<SysUserRole> sysUserRoles = new ArrayList<>();
        for (SysRole sr : roleList) {
            SysUserRole sysUserRole = new SysUserRole();
            sysUserRole.setRoleId(sr.getRoleId());
            sysUserRole.setDataScope(sr.getDataScope());
            sysUserRoles.add(sysUserRole);
        }
        try {
            //用户添加到根节点
            long defualDeptId = 100;
            SysDept dept = sysDeptMapper.selectByDeptId(defualDeptId);
            SysUser user = new SysUser();
            user.setUserName(account);
            user.setNickName(name);
            user.setEmail(email);
            user.setPhonenumber(phone);
            user.setDelFlag("0");
            user.setStatus("0");
            SysUser tmp = sysUserMapper.selectUserByUserName(user.getUserName());
            if (tmp == null) {
                if (StringUtils.isNotEmpty(user.getUserName())) {
                    user.setUserName(user.getUserName().toLowerCase());
                }
                user.setLdap(1L);
                if (StringUtils.isEmpty(user.getPassword())) {
                    user.setPassword(user.getLdap() == 1L ? SecurityUtils.encryptPassword(DictUtil.selectDictValueOrDefault("default_password", "default_pass", "admin123")) :
                            SecurityUtils.encryptPassword(user.getPassword()));
                }
                user.setDeptId(dept.getDeptId());
                user.setDept(dept);

                if (user.getStatus() == null) {
                    user.setStatus("0");
                }
                user.setUserRoles(sysUserRoles);
                user.setRemark("ZY");
                insertUser(user);
            } else {
                //已经存在
                if (user.getStatus() == null) {
                    user.setStatus("0");
                }
                user.setNickName(name);
                user.setUserId(tmp.getUserId());
                user.setEmail(email);
                user.setPhonenumber(phone);
                user.setUpdateTime(new Date());
                sysUserMapper.updateSysUser(user);
            }
        } catch (Exception e) {
            log.error(e.getMessage(), e);
        }
    }

    private void insertUser(SysUser user) {
        // 新增用户信息
        SysUserMapper sysUserMapper = GetSpringBean.getBean(SysUserMapper.class);
        SysUserRoleMapper userRoleMapper = GetSpringBean.getBean(SysUserRoleMapper.class);
        SysUserRoleDeptMapper userRoleDeptMapper = GetSpringBean.getBean(SysUserRoleDeptMapper.class);
        if (StringUtils.isBlank(user.getNickName())) {
            user.setNickName(user.getUserName());
        }
        sysUserMapper.insert(user);
        log.info("新增用户:{}", user.getUserName());
        // 新增用户与角色管理
        List<SysUserRole> roles = user.getUserRoles();
        List<SysUserRole> newRoles = new ArrayList<>();
        if (roles != null && !roles.isEmpty()) {
            roles.forEach(role -> {
                role.setUserId(user.getUserId());
                role.setStatus(0);
                if (userRoleMapper.existUserRole(role) < 1) {
                    newRoles.add(role);
                }
            });
            userRoleMapper.batchUserRole(newRoles);
            newRoles.forEach(sysUserRole -> {
                String dataScope = sysUserRole.getDataScope();
                if ("2".equals(dataScope)) {
                    List<Long> deptIds = sysUserRole.getDeptIds();
                    if (deptIds != null && !deptIds.isEmpty()) {
                        List<SysUserRoleDept> sysUserRoleDeptList = new ArrayList<SysUserRoleDept>();
                        deptIds.forEach(deptId -> {
                            SysUserRoleDept sysUserRoleDept = new SysUserRoleDept();
                            sysUserRoleDept.setDeptId(deptId);
                            sysUserRoleDept.setRoleId(sysUserRole.getRoleId());
                            sysUserRoleDept.setUserId(sysUserRole.getUserId());
                            sysUserRoleDeptList.add(sysUserRoleDept);
                        });
                        if (sysUserRoleDeptList.size() > 0) {
                            userRoleDeptMapper.batchRoleDept(sysUserRoleDeptList);
                        }
                    }
                }
            });
        }
    }


    /*public void updateFullAreaDept(AssetAppSystem assetAppSystem) {
        SysDeptMapper sysDeptMapper = GetSpringBean.getBean(SysDeptMapper.class);
        try {
            if (!StringUtils.isBlank(assetAppSystem.getDeptId())) {
                ////update  tb_asset set dept_path=(select concat(',',ancestors,',',dept_id,',') from sys_dept where dept_id=affiliation_dept_node_id)
                String deptPath = sysDeptMapper.getDeptPath(DataUtils.toLong(assetAppSystem.getDeptId()));
                assetAppSystem.setDeptPath(deptPath);
            }
        } catch (Exception e) {
            log.error(e.getMessage(), e);
        }
    }*/

}
