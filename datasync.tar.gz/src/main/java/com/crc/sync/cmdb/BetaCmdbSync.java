package com.crc.sync.cmdb;

import com.alibaba.fastjson.JSONArray;
import com.alibaba.fastjson.JSONObject;
import com.crc.common.enums.AssetSourceEnums;
import com.crc.common.utils.DataUtils;
import com.crc.common.utils.HttpUtils;
import com.crc.common.utils.IpUtils;
import com.crc.common.utils.JsonUtils;
import com.crc.secface.config.GetSpringBean;
import com.crc.secface.domain.Asset;
import com.crc.secface.domain.AssetRef;
import com.crc.secface.domain.TbAssetExt;
import com.crc.secface.domain.vo.BetaCmdb;
import com.crc.secface.domain.vo.BizType;
import com.crc.secface.queue.CrcAssetSyncQueue;
import com.crc.secface.service.AssetRecordService;
import com.crc.sync.config.SyncSecConfigLoad;
import com.crc.sync.config.SyncSecConstants;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;

import java.math.BigDecimal;
import java.math.RoundingMode;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

@Slf4j
public class BetaCmdbSync {
    public void sync() {
        log.info("开始同步北塔cmdb");
        try {
            String apiUrl = SyncSecConfigLoad.getRemarkValue(SyncSecConstants.BEAT_API_URL);
            if (StringUtils.isBlank(apiUrl)) {
                log.error("没有配置北塔CMDB API地址");
                return;
            }
            List<BizType> typeList = getBizType(apiUrl);
            log.info("北塔类型数量:{}", typeList.size());
            AssetRecordService assetRecordService = GetSpringBean.getBean(AssetRecordService.class);
            for (BizType bizType : typeList) {
                try {
                    List<BetaCmdb> cmdbList = getBetaCmdb(apiUrl, bizType.getName());
                    for (BetaCmdb cmdb : cmdbList) {
                        if ("IPMAC".equals(bizType.getName())) {
                            CrcAssetSyncQueue.getInstance().delAsset(cmdb.getIp());
                            continue;
                        }
                        Asset asset = new Asset();
                        if (IpUtils.isIp(cmdb.getIp())) {
                            CrcAssetSyncQueue.getInstance().saveData(cmdb.getIp(), cmdb, AssetSourceEnums.BETA_CMDB.getCode());
                            asset.setInternalIp(cmdb.getIp());
                            asset.setSource(AssetSourceEnums.BETA_CMDB.getCode());
                            asset.setStatus(0);
                            asset.setInstance(cmdb.getName());
                            asset.setMacAddress(cmdb.getGDH_HostMac());
                            asset.setRemarks(cmdb.getGDH_AssetDescription());
                            asset.setAffiliationDeptName(cmdb.getDepartment());
                            asset.setGeographicLocation(cmdb.getLocation());
                            asset.setInternetIp(cmdb.getGDH_PublicNetwork());
                            asset.setAreaName(cmdb.getGDH_NetworkRegion());
                            int key = 3;
                            if (DataUtils.contains(cmdb.getGDH_AssetClass(), "核心")) {
                                key = 1;
                            } else if (DataUtils.contains(cmdb.getGDH_AssetClass(), "重要")) {
                                key = 2;
                            }
                            asset.setKeyAsset(key);
                            asset.setOs(cmdb.getGDH_HostSystemVersion());
                            asset.setType(cmdb.getClassify());
                            asset.setOperatingStatus(1);
                            asset.setKernelVersion(cmdb.getGDH_KernelVersion());
                            asset.setDomain(cmdb.getGDH_HostDomainName());
                            asset.setTag(cmdb.getTag());
                            asset.setInternetPublic(DataUtils.toInt(cmdb.getGDH_ReleaseInternet()));
                            asset.setSourceType(DataUtils.toLong(cmdb.getResModel()));
                            asset.setTransformationCompleted(DataUtils.toInt(cmdb.getGDH_TransformStatus()));
                            asset.setAssetPower(DataUtils.toInt(cmdb.getGDH_Status()));
                            asset.setSafetyTechnicalSupportUnit(cmdb.getGDH_SupportingUnit());
                            asset.setGeographicLocation(cmdb.getGDH_DeploymentLocation());
                            long date = DataUtils.toLong(cmdb.getExpirationDate());
                            if (date > 0) {
                                asset.setExpirtTime(new Date(date));
                            }
                            Asset oldAsset = CrcAssetSyncQueue.getInstance().getAssetFullByIp(asset.getInternalIp());
                            if (CrcAssetSyncQueue.getInstance().saveAsset(asset)) {

                                TbAssetExt ext = new TbAssetExt();
                                ext.setCpu(cmdb.getGDH_ServerCpuNumber());
                                ext.setMemoryUsage(DataUtils.toDouble(cmdb.getGDH_MEMUsageRate()));
                                ext.setMemory(DataUtils.toInt(cmdb.getGDH_MEMsize()));
                                ext.setDisk(DataUtils.toInt(cmdb.getGDH_HardDriveSize()));
                                ext.setDiskUsage(DataUtils.toDouble(cmdb.getGDH_HardUsageRate()));
                                ext.setDiskNum(DataUtils.toInt(cmdb.getGDH_HardNumber()));
                                ext.setEquipmentVersion(cmdb.getGDH_DeviceVersion());
                                //ext.setEquipmentManagerAddress(cmdb.getManageIP());
                                ext.setEquipmentManufacturer(cmdb.getSupplier());
                                ext.setAssetNumber(cmdb.getSn());
                                ext.setEquipmentModel(cmdb.getModel());


                                double assetImportance = 0;
                                if (ext.getConfidentiality() > 0) {
                                    assetImportance += 0.5 * ext.getConfidentiality();
                                }
                                if (ext.getCompleteness() > 0) {
                                    assetImportance += 0.3 * ext.getCompleteness();
                                }
                                if (ext.getUsability() > 0) {
                                    assetImportance += 0.2 * ext.getUsability();
                                }
                                BigDecimal temp = new BigDecimal(assetImportance).setScale(0, RoundingMode.HALF_UP);
                                ext.setAssetImportance(Integer.parseInt(temp.toString()));
                                AssetRef ref = new AssetRef();
                                ref.setExt(ext);
                                ref.setIp(asset.getInternalIp());
                                CrcAssetSyncQueue.getInstance().saveAssetExt(ref);

                                CrcAssetSyncQueue.getInstance().saveAssetPerson(asset.getInternalIp(), cmdb.getGDH_InformationCenter(), "1");
                                CrcAssetSyncQueue.getInstance().saveAssetPerson(asset.getInternalIp(), cmdb.getGDH_OperationManager(), "2");

                                assetRecordService.addChangeRecord(oldAsset, CrcAssetSyncQueue.getInstance().getAssetFullByIp(asset.getInternalIp()));
                            }
                        }
                    }
                } catch (Exception e) {
                    log.error(e.getMessage(), e);
                }
            }
        } catch (Exception e) {
            log.error(e.getMessage(), e);
        }
        log.info("同步北塔cmdb完成");
    }

    /**
     * 获取资产列表
     *
     * @param type 资产类型
     * @return
     */
    public List<BetaCmdb> getBetaCmdb(String apiUrl, String type) {
        String body = "{\"pageNo\":1,\"pageSize\":2}";
        String url = apiUrl + "/OneCMDB_T00_S01/api/v1/ci/query/bizField/" + type + "?bizType=asset&tenant=T01&roles=OneCMDB_T00_S01:platformAdmin&consumerid=BTPM_T00_S01&cascaded=true";
        List<BetaCmdb> list = new ArrayList<>();
        int total = 0;
        String ret = HttpUtils.sendPost(url, body);
        JSONObject data = JsonUtils.parse(ret);
        total = JsonUtils.getInt(data, "total");
        if (total > 0) {
            log.info("{}-北塔CMDB总数：{}", type, total);
            int pageSize = 400;
            for (int i = 1; i <= DataUtils.getPageCount(total, pageSize, 1); i++) {
                body = "{\"pageNo\":" + i + ",\"pageSize\":400}";
                String retDataStr = HttpUtils.sendPost(url, body);
                JSONObject retData = JsonUtils.parse(retDataStr);
                if (retData.containsKey("data")) {
                    list.addAll(JSONObject.parseArray(retData.getJSONArray("data").toJSONString(), BetaCmdb.class));
                }
            }
        }
        return list;
    }

    /**
     * 获取资源分类
     *
     * @return
     */
    public List<BizType> getBizType(String apiUrl) {
        // String url = SyncSecConfigLoad.getRemarkValue(SyncSecConstants.BEAT_API_URL);
        String url = apiUrl + "/OneCMDB_T00_S01/api/web/ciType/tree/root?bizType=asset";
        String ret = HttpUtils.sendGet(url, "");
        JSONObject data = JsonUtils.parse(ret);
        if (data.containsKey("data") && data.getJSONObject("data").containsKey("children")) {
            JSONArray root = data.getJSONObject("data").getJSONArray("children");
            if (root.size() > 0 && root.getJSONObject(0).containsKey("children")) {
                JSONArray tmoRoot = root.getJSONObject(0).getJSONArray("children");
                return JSONObject.parseArray(tmoRoot.toJSONString(), BizType.class);
            }
        }
        return new ArrayList<>();
    }
}
