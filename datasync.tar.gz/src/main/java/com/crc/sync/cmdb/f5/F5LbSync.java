package com.crc.sync.cmdb.f5;

import com.alibaba.fastjson.JSONArray;
import com.alibaba.fastjson.JSONObject;
import com.baomidou.mybatisplus.core.conditions.query.LambdaQueryWrapper;
import com.baomidou.mybatisplus.core.conditions.update.LambdaUpdateWrapper;
import com.baomidou.mybatisplus.core.toolkit.Wrappers;
import com.crc.common.code.CodeTool;
import com.crc.common.enums.F5LbTypeEnums;
import com.crc.common.utils.DataUtils;
import com.crc.common.utils.DictUtil;
import com.crc.common.utils.HttpUtils;
import com.crc.common.utils.JsonUtils;
import com.crc.secface.config.GetSpringBean;
import com.crc.secface.domain.*;
import com.crc.secface.mapper.*;
import com.crc.sync.git.NginxAllDataSync;
import com.crc.sync.work.PortSaveWork;
import com.google.common.collect.Maps;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;

import java.util.HashMap;
import java.util.List;

/**
 * 从运维平台获取虚拟服务VS POOL MEM IRUEL 4类信息
 */
@Slf4j
public class F5LbSync {
    public void sync() {
        log.info("从运维平台获取虚拟服务VS MEM IRUEL start...");
        try {
            List<SysDictData> dictList = DictUtil.getDict("f5_lb_sync");
            if (dictList != null && dictList.size() > 0) {
                F5Data502Mapper f5Data502Mapper = GetSpringBean.getBean(F5Data502Mapper.class);
                F5Data508Mapper f5Data508Mapper = GetSpringBean.getBean(F5Data508Mapper.class);
                F5Data506Mapper f5Data506Mapper = GetSpringBean.getBean(F5Data506Mapper.class);
                F5Data509Mapper f5Data509Mapper = GetSpringBean.getBean(F5Data509Mapper.class);
                F5DataGtmMapper f5DataGtmMapper = GetSpringBean.getBean(F5DataGtmMapper.class);
                //F5Data511Mapper f5Data511Mapper = GetSpringBean.getBean(F5Data511Mapper.class);
                //F5Data513Mapper f5Data513Mapper = GetSpringBean.getBean(F5Data513Mapper.class);
                for (SysDictData dictData : dictList) {
                    if (StringUtils.isBlank(dictData.getDictValue()) || StringUtils.isBlank(dictData.getRemark())) {
                        continue;
                    }
                    JSONObject json = JsonUtils.parse(dictData.getRemark());
                    if (JsonUtils.isEmpty(json)) {
                        log.error(dictData.getDictLabel() + "配置为空！");
                        continue;
                    }
                    String type = JsonUtils.getStr(json, "type");
                    String targetId = JsonUtils.getStr(json, "targetId");
                    try {
                        if (F5LbTypeEnums.VS.getCode().equals(type)) {
                            f5Data502Mapper.deleteAll();
                        } else if (F5LbTypeEnums.MEM.getCode().equals(type)) {
                            f5Data508Mapper.deleteAll();
                        } else if (F5LbTypeEnums.IRULES.getCode().equals(type)) {
                            f5Data506Mapper.deleteAll();
                        } else if ("f5gtm".equals(targetId)) {
                            f5DataGtmMapper.deleteAll();
                        } else if ("509".equals(type)) {
                            f5Data509Mapper.deleteAll();
                        }
                        /*else if (F5LbTypeEnums.DNS.getCode().equals(type)) {
                            LambdaUpdateWrapper<F5Data511> up = Wrappers.lambdaUpdate();
                            up.set(F5Data511::getFlag, 1);
                            f5Data511Mapper.update(null, up);
                        }else if (F5LbTypeEnums.DATA.getCode().equals(type)) {
                            LambdaUpdateWrapper<F5Data513> up = Wrappers.lambdaUpdate();
                            up.set(F5Data513::getFlag, 1);
                            f5Data513Mapper.update(null, up);
                        }*/
                    } catch (Exception e) {
                        log.error(e.getMessage(),e);
                    }
                    syncData(dictData.getDictLabel(), json);
                }
            }
        } catch (Exception e) {
            log.error(e.getMessage(), e);
        }
        log.info("从运维平台获取虚拟服务VS MEM IRUEL end...");
        log.info("Nginx data load start...");

        try {
            NginxAllDataSync sync = new NginxAllDataSync();
            sync.syncAll();
        } catch (Exception e) {
            log.error(e.getMessage(), e);
        }

        log.info("Nginx data load end...");

        try {
            parse();
        } catch (Exception e) {
            log.error(e.getMessage(), e);
        }
    }

    /**
     * 数据解析、关联
     */
    private void parse() {
        //tb_asset
        CommonMapper commonMapper = GetSpringBean.getBean(CommonMapper.class);
        try {
            commonMapper.exeSQL("INSERT INTO tb_asset (internal_ip,INSTANCE,dept_path)\n" +
                    " SELECT  DISTINCT ip,ip,',0,100,99,' FROM tb_f5_508 WHERE ip NOT IN " +
                    "(SELECT dict_value FROM sys_dict_data WHERE ((dict_label LIKE 'WAF%' AND dict_type = 'F5_WAF_IP')  " +
                    "OR (dict_label LIKE 'NGINX%' AND dict_type = 'F5_NGINX_IP'))) \n" +
                    " AND sid IN ('f5-payk-qrlh','f5-zygh-yupd','f5-swet-jvbg')  AND ip NOT IN(SELECT internal_ip FROM tb_asset)\n" +
                    " AND (INSTR(CONCAT(':',ip),CONCAT(':','10.')) OR INSTR(ip,':'))>0;");
        } catch (Exception e) {
            log.error(e.getMessage(),e);
        }

        commonMapper = GetSpringBean.getBean(CommonMapper.class);
        try {
            commonMapper.exeSQL("delete from tb_f5_base;");

            commonMapper.exeSQL("INSERT INTO tb_f5_base(lcsid,lcip,lcport,lcpool,awafip,awafport,iswaf,priority,extpool,intpool, intvsname,awafdomain,awafpath,awafintip,awafintport,domain_name,proxy_pass,lb_vs_ip,lb_vs_port,\n" + "asset_id,internal_ip,assetport,sys_zh_name,duty_person_name)\n" + "SELECT tmp.sid,tmp.lcip,tmp.lcport,tmp.lcpool,tmp.awafip,tmp.awafport,tmp.iswaf,tmp.priority,extpool,intpool,intvsname,tmp.awafdomain,tmp.awafpath,\n" + "tmp.awafintip,tmp.awafintport,g.domain_name,g.proxy_pass,g.lb_vs_ip,g.lb_vs_port,ee.id,ff.ip,ff.port,hh.sys_zh_name,hh.duty_person_name FROM \n" + "(SELECT DISTINCT a.sid,a.ip AS lcip,a.port AS lcport,a.pool AS lcpool,b.ip AS awafip,b.port AS awafport,1 as iswaf,b.priority ,c.name AS extpool,e.name AS intpool,e.virtual_data AS intvsname,e.domain AS awafdomain,e.path AS awafpath,\n" + "f.ip AS awafintip,f.port AS awafintport\n" + " FROM tb_f5_502 a,tb_f5_508 b,tb_f5_502 c,tb_f5_509 d,tb_f5_506 e,tb_f5_502 f   WHERE \n" + "a.sid IN (SELECT dict_value FROM sys_dict_data WHERE dict_label LIKE 'LC%' AND dict_type = 'F5_LC_SID' AND STATUS=0) \n" + "AND a.ip NOT BETWEEN '10.0.0.0' AND '10.255.255.255'  AND a.pool=b.pool AND a.sid=b.sid\n" + "AND b.sid IN (SELECT dict_value FROM sys_dict_data WHERE dict_label LIKE 'LC%' AND dict_type = 'F5_LC_SID' AND STATUS=0) AND b.ip IN \n" + "(SELECT dict_value FROM sys_dict_data WHERE dict_type LIKE '%WAF%' AND dict_type='F5_WAF_IP' AND STATUS=0) \n" + "AND IS_IPV4(a.ip) AND IS_IPV4(b.ip) AND b.ip=c.ip AND b.port=c.port AND c.sid IN (SELECT dict_value FROM sys_dict_data WHERE dict_label LIKE 'WAF%' AND dict_type = 'F5_WAF_SID' AND STATUS=0)\n" + "AND CONCAT('/Common/',c.name)=d.vsuid AND CONCAT('/Common/',e.name)=d.ruleuid AND f.name=e.virtual_data AND IS_IPV4(f.ip) ) tmp \n" + "LEFT JOIN tb_f5_ng_conf g\n" + "ON INSTR(CONCAT(',',REPLACE(g.domain_name,' ',','),','),CONCAT(',',tmp.awafdomain,','))>0 AND g.path=tmp.awafpath \n" + "LEFT JOIN tb_f5_502 aa ON g.lb_vs_port=aa.port AND g.lb_vs_ip=aa.ip AND aa.sid IN (SELECT dict_value FROM sys_dict_data WHERE dict_label LIKE 'LTM%' AND dict_type = 'F5_LTM_SID' AND STATUS=0) \n" + "LEFT JOIN tb_f5_508 bb ON aa.pool=bb.pool AND bb.sid  IN (SELECT dict_value FROM sys_dict_data WHERE dict_label LIKE 'LTM%' AND dict_type = 'F5_LTM_SID' AND STATUS=0)  \n" + "LEFT JOIN tb_asset ee ON  bb.ip=ee.internal_ip AND IS_IPV4(ee.internal_ip)\n" + "LEFT JOIN tb_asset_port ff ON  bb.ip=ff.ip AND bb.port = ff.port AND IS_IPV4(ff.ip)\n" + "LEFT JOIN tb_app_system_relation_asset gg ON ee.id=gg.asset_id AND INSTR(CONCAT(',',gg.port,','),CONCAT(',',ff.port,','))>0\n" + "LEFT JOIN tb_asset_app_system hh ON gg.app_system_id = hh.id\n" + "UNION\n" + "SELECT tmp.sid,tmp.lcip,tmp.lcport,tmp.lcpool,tmp.awafip,tmp.awafport,tmp.iswaf,tmp.priority ,extpool,intpool,intvsname,tmp.awafdomain,tmp.awafpath,\n" + "tmp.awafintip,tmp.awafintport,g.domain_name,g.proxy_pass,g.lb_vs_ip,g.lb_vs_port,ee.id,ff.ip,ff.port,hh.sys_zh_name,hh.duty_person_name FROM \n" + "(SELECT DISTINCT a.sid,a.ip AS lcip,a.port AS lcport,a.pool AS lcpool,b.ip AS awafip,b.port AS awafport,1 as iswaf,b.priority ,c.name AS extpool,e.name AS intpool,e.virtual_data AS intvsname,e.domain AS awafdomain,e.path AS awafpath,\n" + "f.ip AS awafintip,f.port AS awafintport\n" + " FROM tb_f5_502 a,tb_f5_508 b,tb_f5_502 c,tb_f5_509 d,tb_f5_506 e,tb_f5_502 f   WHERE \n" + "a.sid IN (SELECT dict_value FROM sys_dict_data WHERE dict_label LIKE 'LC%' AND dict_type = 'F5_LC_SID' AND STATUS=0)  AND (INSTR(a.ip,'2400:')>0 OR INSTR(a.ip,'2409:')>0)  AND a.pool=b.pool AND a.sid=b.sid\n" + "AND b.sid IN (SELECT dict_value FROM sys_dict_data WHERE dict_label LIKE 'LC%' AND dict_type = 'F5_LC_SID' AND STATUS=0) AND b.ip IN \n" + "(SELECT dict_value FROM sys_dict_data WHERE dict_type LIKE '%WAF%' AND dict_type='F5_WAF_IP' AND STATUS=0) \n" + "AND IS_IPV6(a.ip) AND IS_IPV6(b.ip) AND b.ip=c.ip AND b.port=c.port AND c.sid IN (SELECT dict_value FROM sys_dict_data WHERE dict_label LIKE 'WAF%' AND dict_type = 'F5_WAF_SID' AND STATUS=0)\n" + "AND CONCAT('/Common/',c.name)=d.vsuid AND CONCAT('/Common/',e.name)=d.ruleuid AND f.name=e.virtual_data AND IS_IPV6(f.ip)) tmp \n" + "LEFT JOIN tb_f5_ng_conf g\n" + "ON INSTR(CONCAT(',',REPLACE(g.domain_name,' ',','),','),CONCAT(',',tmp.awafdomain,','))>0 AND g.path=tmp.awafpath \n" + "LEFT JOIN tb_f5_502 aa ON g.lb_vs_port=aa.port AND g.lb_vs_ip=aa.ip AND aa.sid IN (SELECT dict_value FROM sys_dict_data WHERE dict_label LIKE 'LTM%' AND dict_type = 'F5_LTM_SID' AND STATUS=0) \n" + "LEFT JOIN tb_f5_508 bb ON aa.pool=bb.pool AND bb.sid  IN (SELECT dict_value FROM sys_dict_data WHERE dict_label LIKE 'LTM%' AND dict_type = 'F5_LTM_SID' AND STATUS=0)  \n" + "LEFT JOIN tb_asset ee ON  bb.ip=ee.internal_ip \n" + "LEFT JOIN tb_asset_port ff ON  bb.ip=ff.ip AND bb.port = ff.port \n" + "LEFT JOIN tb_app_system_relation_asset gg ON ee.id=gg.asset_id AND INSTR(CONCAT(',',gg.port,','),CONCAT(',',ff.port,','))>0\n" + "LEFT JOIN tb_asset_app_system hh ON gg.app_system_id = hh.id\n" + "UNION \n" + "SELECT a.sid,a.ip lcip,a.port lcport,a.pool lcpool,b.ip awafip,b.port awafport,0 AS iswaf,b.priority ,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,\n" + "ee.id,ee.internal_ip,ff.port,hh.sys_zh_name,hh.duty_person_name \n" + " FROM tb_f5_502 a JOIN tb_f5_508 b ON \n" + "a.sid IN (SELECT dict_value FROM sys_dict_data WHERE dict_label LIKE 'LC%' AND dict_type = 'F5_LC_SID' AND STATUS=0) AND b.sid IN (SELECT dict_value FROM sys_dict_data WHERE dict_label LIKE 'LC%' AND dict_type = 'F5_LC_SID' AND STATUS=0)   AND a.pool=b.pool AND a.sid=b.sid\n" + "AND a.ip NOT BETWEEN '10.0.0.0' AND '10.255.255.255'  AND  b.ip NOT IN \n" + "(SELECT dict_value FROM sys_dict_data WHERE dict_type LIKE '%WAF%' AND dict_type='F5_WAF_IP' AND STATUS=0)  AND IS_IPV4(b.ip) AND IS_IPV4(a.ip)\n" + "LEFT JOIN tb_asset ee ON  b.ip=ee.internal_ip \n" + "LEFT JOIN tb_asset_port ff ON  b.ip=ff.ip AND b.port = ff.port \n" + "LEFT JOIN tb_app_system_relation_asset gg ON ee.id=gg.asset_id AND INSTR(CONCAT(',',gg.port,','),CONCAT(',',ff.port,','))>0\n" + "LEFT JOIN tb_asset_app_system hh ON gg.app_system_id = hh.id \n" + "UNION\n" + "SELECT a.sid,a.ip lcip,a.port lcport,a.pool lcpool,b.ip awafip,b.port awafport,0 as iswaf,b.priority ,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,\n" + "ee.id,ee.internal_ip,ff.port,hh.sys_zh_name,hh.duty_person_name \n" + " FROM tb_f5_502 a JOIN tb_f5_508 b ON \n" + "a.sid IN (SELECT dict_value FROM sys_dict_data WHERE dict_label LIKE 'LC%' AND dict_type = 'F5_LC_SID' AND STATUS=0) AND b.sid IN (SELECT dict_value FROM sys_dict_data WHERE dict_label LIKE 'LC%' AND dict_type = 'F5_LC_SID' AND STATUS=0)   AND a.pool=b.pool  AND a.sid=b.sid\n" + "AND (INSTR(a.ip,'2400:')>0 OR INSTR(a.ip,'2409:')>0)  AND  b.ip NOT IN \n" + "(SELECT dict_value FROM sys_dict_data WHERE dict_type LIKE '%WAF%' AND dict_type='F5_WAF_IP' AND STATUS=0)  AND IS_IPV6(b.ip)  AND IS_IPV6(a.ip)\n" + "LEFT JOIN tb_asset ee ON  b.ip=ee.internal_ip \n" + "LEFT JOIN tb_asset_port ff ON  b.ip=ff.ip AND b.port = ff.port \n" + "LEFT JOIN tb_app_system_relation_asset gg ON ee.id=gg.asset_id AND INSTR(CONCAT(',',gg.port,','),CONCAT(',',ff.port,','))>0\n" + "LEFT JOIN tb_asset_app_system hh ON gg.app_system_id = hh.id ;");
        } catch (Exception e) {
            log.error(e.getMessage(),e);
        }

        //tb_f5_domain
        /*commonMapper = GetSpringBean.getBean(CommonMapper.class);
        try {
            commonMapper.exeSQL("delete from tb_f5_domain where type=0;");

            commonMapper.exeSQL("INSERT INTO tb_f5_domain(domain,ip) \n"
                    + "SELECT wideip,rdata FROM  tb_f5_gtm WHERE  wideip!='95590.cn' AND wideip!='ccic-net.com.cn' AND wideip!='ddsd-ccic.com'; ");
        } catch (Exception e) {
            log.error(e.getMessage(),e);
        }*/

        //tb_f5_awaf_int
       /* try {
            commonMapper.exeSQL("delete from tb_f5_awaf_int where type=0;");

            commonMapper.exeSQL("INSERT INTO tb_f5_awaf_int (ip,PORT,int_vs_name,domain_name,path)\n"
                    + "SELECT b.ip,b.port,b.name,c.domain,IF(c.path IS NULL,'/',c.path) AS path FROM \n"
                    + "(SELECT * FROM tb_f5_502 a WHERE a.sid IN \n"
                    + "(SELECT dict_value FROM sys_dict_data WHERE dict_label LIKE 'WAF%' AND dict_type = 'F5_WAF_SID' AND STATUS=0)\n"
                    + "  AND a.NAME LIKE '%int%') b LEFT JOIN tb_f5_506 c ON  \n"
                    + " c.sid IN \n"
                    + "(SELECT dict_value FROM sys_dict_data WHERE dict_label LIKE 'WAF%' AND dict_type = 'F5_WAF_SID' AND STATUS=0) \n"
                    + "AND c.virtual_data = b.name;");
        } catch (Exception e) {
            log.error(e.getMessage(),e);
        }*/
        //tb_f5_domain_awaf_int_ng_rela
        /*try {
            commonMapper.exeSQL("delete from tb_f5_domain_awaf_int_ng_rela where type=0;");

            commonMapper.exeSQL("INSERT INTO tb_f5_domain_awaf_int_ng_rela (domain_id,awaf_int_id,ng_conf_id)\n"
                    + "SELECT b.id AS domain_id,a.id AS awafintid,c.id AS nginxid FROM tb_f5_awaf_int a \n"
                    + "INNER JOIN tb_f5_domain b ON a.domain_name = b.domain \n"
                    + "LEFT JOIN tb_f5_ng_conf c ON INSTR(c.domain_name,a.domain_name)>0 AND a.path=c.path  AND a.del_flag=0 AND b.del_flag=0 AND c.del_flag=0;");
        } catch (Exception e) {
            log.error(e.getMessage(),e);
        }*/

        //tb_f5_domain_awaf_mem_rela
        /*try {
            commonMapper.exeSQL("delete from tb_f5_domain_awaf_mem_rela where type=0;");

            commonMapper.exeSQL("INSERT INTO tb_f5_domain_awaf_mem_rela(domain_id,domain_port,asset_id,asset_port_id,prority,asset_type)\n"
                    + "SELECT  c.id AS domain_id,a.port AS domain_port,d.id AS assetid,e.id AS assetportid,b.priority,IF(IS_IPV4(d.internal_ip),1,2) AS asset_type FROM tb_f5_domain c \n"
                    + "JOIN tb_f5_502 a  ON c.ip=a.ip  \n"
                    + "JOIN tb_f5_508 b  ON a.pool=b.pool \n"
                    + "AND a.sid IN (SELECT dict_value FROM sys_dict_data WHERE dict_label LIKE 'LC%' AND dict_type = 'F5_LC_SID' AND STATUS=0)  \n"
                    + "AND b.sid IN (SELECT dict_value FROM sys_dict_data WHERE dict_label LIKE 'LC%' AND dict_type = 'F5_LC_SID' AND STATUS=0)  \n"
                    + "JOIN tb_asset d  JOIN tb_asset_port e  ON d.internal_ip=b.ip AND e.port=b.port AND e.ip=d.internal_ip; ");
        } catch (Exception e) {
            log.error(e.getMessage(),e);
        }*/

        //tb_f5_ng_conf_asset_rela
        /*try {
            commonMapper.exeSQL("delete from tb_f5_ng_conf_asset_rela where type=0;");

            commonMapper.exeSQL("INSERT INTO tb_f5_ng_conf_asset_rela (f5_ng_conf_id,asset_id,asset_port_id,asset_system_id)\n"
                    + "SELECT tmp.nginxid,tmp.assetid,tmp.asserportid,h.id FROM \n"
                    + "(SELECT c.id AS nginxid,e.id AS assetid,f.id AS asserportid,b.ip,b.port FROM tb_f5_502 a JOIN tb_f5_508 b JOIN tb_f5_ng_confc JOIN tb_asset e JOIN \n"
                    + "tb_asset_port f \n" + "ON a.sid IN (SELECT dict_value FROM sys_dict_data WHERE dict_label LIKE 'LTM%' AND dict_type = 'F5_LTM_SID' AND STATUS=0) \n"
                    + "AND b.sid  IN (SELECT dict_value FROM sys_dict_data WHERE dict_label LIKE 'LTM%' AND dict_type = 'F5_LTM_SID' AND STATUS=0)  \n"
                    + "AND c.lb_vs_ip=a.ip AND c.lb_vs_port=a.port AND a.pool=b.pool \n"
                    + "AND b.ip=e.internal_ip AND b.ip=f.ip AND b.port = f.port) tmp \n"
                    + "LEFT JOIN tb_app_system_relation_asset g ON tmp.assetid=g.asset_id AND INSTR(CONCAT(',',g.port,','),CONCAT(',',tmp.port,','))>0\n"
                    + "LEFT JOIN tb_asset_app_system h ON g.app_system_id = h.id;");
        } catch (Exception e) {
            log.error(e.getMessage(),e);
        }*/

        //tb_f5_domain_data
        /*try {
            commonMapper.exeSQL("UPDATE tb_f5_domain_data SET del_flag = '1' WHERE del_flag = '0' AND type = '0' AND manual_flag = '0';");

            commonMapper.exeSQL("INSERT INTO tb_f5_domain_data (domain_id_str, link_id_str, domain, instance, asset_user, forbear, rel_asset_ip_str, ip_port_str, PORT, type, create_time, update_time)\n"
                    + "SELECT t.domain_id_str,t.link_id_str,t.domain,t.INSTANCE,t.asset_user,IF(t1.foradarCount = t1.whiteSum, '否', '是') AS forbear, \n"
                    + "t.rel_asset_ip_str, t.public_ip_port,t.PORT,0,NOW(),NOW()\n" + "FROM \n"
                    + "(SELECT tmp.domain,tmp.domain_id_str,tmp.domain_port,tmp.public_ip_port,tmp.link_id_str,\n"
                    + "GROUP_CONCAT(DISTINCT h.internal_ip) AS rel_asset_ip_str,GROUP_CONCAT(DISTINCT i.port) AS PORT,\n"
                    + "GROUP_CONCAT(DISTINCT j.sys_zh_name) INSTANCE,GROUP_CONCAT(DISTINCT j.duty_person_name) asset_user\n"
                    + "FROM \n" + "(SELECT a.domain ,GROUP_CONCAT(DISTINCT a.id) AS domain_id_str,b.domain_port,GROUP_CONCAT(DISTINCT a.ip,':',b.domain_port ) AS public_ip_port,\n"
                    + "GROUP_CONCAT(DISTINCT b.id  ) link_id_str\n" + "FROM tb_f5_domain a\n"
                    + "JOIN tb_f5_domain_awaf_mem_rela b ON a.id=b.domain_id AND IS_IPV4(a.ip)  \n"
                    + "JOIN tb_asset c ON b.asset_id=c.id AND IS_IPV4(c.internal_ip) \n"
                    + "JOIN tb_asset_port d ON d.id=b.asset_port_id\n" + "GROUP BY a.domain,b.domain_port) tmp  \n"
                    + "LEFT JOIN tb_f5_ng_conf e ON INSTR(e.domain_name,tmp.domain)>0  \t\n"
                    + "LEFT JOIN tb_f5_ng_conf_asset_rela g ON e.id = g.f5_ng_conf_id\n"
                    + "LEFT JOIN tb_asset h ON g.asset_id = h.id AND IS_IPV4(h.internal_ip)\n"
                    + "LEFT JOIN tb_asset_port i ON g.asset_port_id = i.id\n"
                    + "LEFT JOIN tb_asset_app_system j ON g.asset_system_id = j.id\n"
                    + "GROUP BY tmp.domain,tmp.domain_id_str,tmp.domain_port,tmp.public_ip_port,tmp.link_id_str\n"
                    + "UNION\n" + "SELECT tmp.domain,tmp.domain_id_str,tmp.domain_port,tmp.public_ip_port,tmp.link_id_str,\n"
                    + "GROUP_CONCAT(DISTINCT h.internal_ip) AS rel_asset_ip_str,GROUP_CONCAT(DISTINCT i.port) AS PORT,\n"
                    + "GROUP_CONCAT(DISTINCT j.sys_zh_name) INSTANCE,GROUP_CONCAT(DISTINCT j.duty_person_name) asset_user\n"
                    + "FROM \n" + "(SELECT a.domain ,GROUP_CONCAT(DISTINCT a.id) AS domain_id_str,b.domain_port,GROUP_CONCAT(DISTINCT a.ip,':',b.domain_port ) AS public_ip_port,\n"
                    + "GROUP_CONCAT(DISTINCT b.id  ) link_id_str\n" + "FROM tb_f5_domain a\n" + "JOIN tb_f5_domain_awaf_mem_rela b ON a.id=b.domain_id AND IS_IPV6(a.ip)  \n"
                    + "JOIN tb_asset c ON b.asset_id=c.id AND IS_IPV6(c.internal_ip) \n" + "JOIN tb_asset_port d ON d.id=b.asset_port_id\n"
                    + "GROUP BY a.domain,b.domain_port) tmp  \n" + "LEFT JOIN tb_f5_ng_conf e ON INSTR(e.domain_name,tmp.domain)>0  \t\n"
                    + "LEFT JOIN tb_f5_ng_conf_asset_rela g ON e.id = g.f5_ng_conf_id\n" + "LEFT JOIN tb_asset h ON g.asset_id = h.id AND IS_IPV6(h.internal_ip)\n"
                    + "LEFT JOIN tb_asset_port i ON g.asset_port_id = i.id\n" + "LEFT JOIN tb_asset_app_system j ON g.asset_system_id = j.id\n"
                    + "GROUP BY tmp.domain,tmp.domain_id_str,tmp.domain_port,tmp.public_ip_port,tmp.link_id_str) t \n" + "LEFT JOIN (\n" + "    SELECT\n"
                    + "        a.domain,\n" + "        COUNT(DISTINCT tffi.id) AS foradarCount,\n" + "        IFNULL(SUM(a.ip = tffi.internet_ip ), 0) AS whiteSum\n"
                    + "    FROM\n" + "        tb_f5_domain a\n" + "    LEFT JOIN tb_f5_foradar_info tffi\n" + "        ON\n" + "        a.domain = tffi.source\n"
                    + "    GROUP BY\n" + "        a.domain) t1 ON\n" + "    t.domain = t1.domain  ORDER BY forbear DESC; ");
        } catch (Exception e) {
            log.error(e.getMessage(),e);
        }*/
    }

    /**
     * 同步接口数据
     * @param dictLabel 同步内容
     * @param json 参数配置
     */
    private void syncData(String dictLabel, JSONObject json) {
        /*
         * {
         *     "url": "http://127.0.0.1:800",
         *     "username": "admin",
         *     "password": "ENC(5ujdBmloMQ4aVerWh4VaiznSxGtz+QPSIF/HS8D0CpZHiL1jR0ssVw==)",
         *     "type": "502"
         * }
         */
        String type = JsonUtils.getStr(json, "type");
        String token = getToken(json);
        if (StringUtils.isBlank(token)) {
            log.error("获取Token失败");
            return;
        }

        //GTM数据采用另外的接口单独获取
        if(dictLabel.equalsIgnoreCase("gtm"))
        {
            F5DataGtmMapper f5DataGtmMapper = GetSpringBean.getBean(F5DataGtmMapper.class);
            JSONArray dataArr = getGtmData(json, token);
            if (dataArr != null) {
                log.info("f5_lb_sync=>gtm--size={}", dataArr.size());
                for (int i = 0; i < dataArr.size(); i++) {
                    JSONObject data = dataArr.getJSONObject(i);
                    F5DataGtm f5DataGtm = F5DataSync.parseGtm(data.toJSONString());
                    if (f5DataGtm != null) {
                        LambdaQueryWrapper<F5DataGtm> fq = Wrappers.lambdaQuery();
                        fq.eq(F5DataGtm::getRdata, f5DataGtm.getRdata());
                        fq.eq(F5DataGtm::getWideip, f5DataGtm.getWideip());
                        if (f5DataGtmMapper.selectCount(fq) < 1) {
                            f5DataGtmMapper.insert(f5DataGtm);
                        } else {
                            LambdaUpdateWrapper<F5DataGtm> up = Wrappers.lambdaUpdate();
                            up.eq(F5DataGtm::getWideip, f5DataGtm.getWideip());
                            up.eq(F5DataGtm::getRdata, f5DataGtm.getRdata());
                            f5DataGtmMapper.update(f5DataGtm, up);
                        }
                    }
                }
            }
        }else
        {
            long total = getTotal(json, token, type);

            log.info("{}==={}--Total={}", dictLabel, type, total);
            F5Data502Mapper f5Data502Mapper = GetSpringBean.getBean(F5Data502Mapper.class);
            F5Data508Mapper f5Data508Mapper = GetSpringBean.getBean(F5Data508Mapper.class);
            F5Data506Mapper f5Data506Mapper = GetSpringBean.getBean(F5Data506Mapper.class);
            F5Data509Mapper f5Data509Mapper = GetSpringBean.getBean(F5Data509Mapper.class);
            //F5Data511Mapper f5Data511Mapper = GetSpringBean.getBean(F5Data511Mapper.class);
            //F5Data513Mapper f5Data513Mapper = GetSpringBean.getBean(F5Data513Mapper.class);
            if (total > 0) {
                int pageSize = 400;
                for (int index = 0; index < DataUtils.getPageCount(total, pageSize, 0); index++) {
                    JSONArray dataArr = getPageList(json, token, type, (index + 1), pageSize);
                    if (dataArr != null) {
                        log.info("f5_lb_sync=>{}--total={}--page={},size={}", type, total, (index + 1), dataArr.size());
                        for (int j = 0; j < dataArr.size(); j++) {
                            JSONObject data = dataArr.getJSONObject(j);
                            try {
                                if (F5LbTypeEnums.VS.getCode().equals(type)) {
                                    /*
                                     * {
                                     * 			"PORT": "11345",
                                     * 			"OBJ": "96633",
                                     * 			"PARTITION_": "VLB_4570412875",
                                     * 			"IP": "10.2.13.31%1",
                                     * 			"POOL": "/VLB_4570412875/pool_tdsql",
                                     * 			"ID": 92,
                                     * 			"FULLPATH": "/VLB_4570412875/vs_tdsql",
                                     * 			"SID": "f5-ncyo-kyli",
                                     * 			"NAME": "vs_tdsql"
                                     *                }
                                     */
                                    F5Data502 f5Data502 = F5DataSync.parse502(data.toJSONString());
                                    if (f5Data502 != null) {
                                        LambdaQueryWrapper<F5Data502> fq = Wrappers.lambdaQuery();
                                        fq.eq(F5Data502::getDataId, f5Data502.getDataId());
                                        if (f5Data502Mapper.selectCount(fq) < 1) {
                                            f5Data502Mapper.insert(f5Data502);
                                        } else {
                                            LambdaUpdateWrapper<F5Data502> up = Wrappers.lambdaUpdate();
                                            up.eq(F5Data502::getDataId, f5Data502.getDataId());
                                            up.set(F5Data502::getFlag, "0");
                                            f5Data502Mapper.update(f5Data502, up);
                                        }
                                    }
                                }
                                /*else if (F5LbTypeEnums.DNS.getCode().equals(type)) {
                                    F5Data511 f5Data511 = F5DataSync.parse511(data.toJSONString());
                                    if (f5Data511 != null) {
                                        LambdaQueryWrapper<F5Data511> fq = Wrappers.lambdaQuery();
                                        fq.eq(F5Data511::getDataId, f5Data511.getDataId());
                                        if (f5Data511Mapper.selectCount(fq) < 1) {
                                            f5Data511Mapper.insert(f5Data511);
                                        } else {
                                            LambdaUpdateWrapper<F5Data511> up = Wrappers.lambdaUpdate();
                                            up.eq(F5Data511::getDataId, f5Data511.getDataId());
                                            up.set(F5Data511::getFlag, "0");
                                            f5Data511Mapper.update(f5Data511, up);
                                        }
                                    }
                                }
                                else if (F5LbTypeEnums.DATA.getCode().equals(type)) {
                                    F5Data513 f5Data513 = F5DataSync.parse513(data.toJSONString());
                                    if (f5Data513 != null) {
                                        LambdaQueryWrapper<F5Data513> fq = Wrappers.lambdaQuery();
                                        fq.eq(F5Data513::getDataId, f5Data513.getDataId());
                                        if (f5Data513Mapper.selectCount(fq) < 1) {
                                            f5Data513Mapper.insert(f5Data513);
                                        } else {
                                            LambdaUpdateWrapper<F5Data513> up = Wrappers.lambdaUpdate();
                                            up.eq(F5Data513::getDataId, f5Data513.getDataId());
                                            up.set(F5Data513::getFlag, "0");
                                            f5Data513Mapper.update(f5Data513, up);
                                        }
                                    }
                                } */
                                else if (F5LbTypeEnums.MEM.getCode().equals(type)) {
                                    /*
                                     * {
                                     * 			"OBJ": "10.2.10.163%1:11347",
                                     * 			"ADDRESS": "10.2.10.163%1",
                                     * 			"STATE": "up",
                                     * 			"POOL": "/VLB_4570412875/pool_tdsql",
                                     * 			"ID": 176,
                                     * 			"FULLPATH": "/VLB_4570412875/10.2.10.163%1:11347",
                                     * 			"SID": "f5-ncyo-kyli",
                                     * 			"NAME": "10.2.10.163%1:11347"
                                     *                }
                                     */
                                    F5Data508 f5Data508 = F5DataSync.parse508(data.toJSONString());
                                    if (f5Data508 != null) {
                                        LambdaQueryWrapper<F5Data508> fq = Wrappers.lambdaQuery();
                                        fq.eq(F5Data508::getDataId, f5Data508.getDataId());
                                        if (f5Data508Mapper.selectCount(fq) < 1) {
                                            f5Data508Mapper.insert(f5Data508);
                                        } else {
                                            LambdaUpdateWrapper<F5Data508> up = Wrappers.lambdaUpdate();
                                            up.eq(F5Data508::getDataId, f5Data508.getDataId());
                                            up.set(F5Data508::getFlag, "0");
                                            f5Data508Mapper.update(f5Data508, up);
                                        }


                                        if (DataUtils.toInt(f5Data508.getPort()) > 0) {
                                            AssetPort assetPort = new AssetPort();
                                            assetPort.setPort(f5Data508.getPort());
                                            assetPort.setIp(f5Data508.getIp());
                                            PortSaveWork.magicQueue.offer(assetPort);
                                        }
                                    }
                                } else if (F5LbTypeEnums.IRULES.getCode().equals(type)) {
                                    /*
                                     * {
                                     * 			"API_ANONYMOUS": "d2hlbiBIVFRQX1JFUVVFU1QgeyBpZiB7KFtIVFRQOjpjb29raWUgbmFtZV0gY29udGFpbnMgIkJJR2lwU2VydmVyIil9eyBwZXJzaXN0IGNvb2tpZSB9ZWxzZSB7IHBlcnNpc3Qgc291cmNlX2FkZHIgfSB9",
                                     * 			"OBJ": "SDN_rule",
                                     * 			"PARTITION_": "VLB_7432480211",
                                     * 			"FULLPATH": "/VLB_7432480211/SDN_rule",
                                     * 			"SID": "f5-ncyo-kyli",
                                     * 			"NAME": "SDN_rule"
                                     *                }
                                     */
                                    List<F5Data506> list = F5DataSync.parse506(data.toJSONString());
                                    if (list != null) {
                                        for (F5Data506 f5Data506 : list) {
                                            LambdaQueryWrapper<F5Data506> fq = Wrappers.lambdaQuery();
                                            fq.eq(F5Data506::getSid, f5Data506.getSid());
                                            fq.eq(F5Data506::getRuleMd5, f5Data506.getRuleMd5());
                                            if (f5Data506Mapper.selectCount(fq) < 1) {
                                                f5Data506Mapper.insert(f5Data506);
                                            } else {
                                                LambdaUpdateWrapper<F5Data506> up = Wrappers.lambdaUpdate();
                                                up.eq(F5Data506::getSid, f5Data506.getSid());
                                                up.eq(F5Data506::getRuleMd5, f5Data506.getRuleMd5());
                                                up.set(F5Data506::getFlag, "0");
                                                f5Data506Mapper.update(f5Data506, up);
                                            }
                                        }
                                    }
                                }
                                else if ("509".equals(type)) {
                                    /*
                                       {
                                        "VS_UID": "/Common/vs_awaf_ext_9443_95590",
                                        "ID": 2311,
                                        "RULE_UID": "/Common/irules_nginx_10_1_31_24_9443"
                                        }
                                     */
                                    F5Data509 f5Data509 = F5DataSync.parse509(data.toJSONString());
                                    f5Data509Mapper.insert(f5Data509);
                                }
                            } catch (Exception e) {
                                log.error(e.getMessage(), e);
                            }
                        }
                    }
                }
            }
        }
    }

    /**
     * 分页获取数据
     * @param json 参数
     * @param token token
     * @param type 类型
     * @param page 页数
     * @param pageSize 每页数据量
     * @return 内容
     */
    public JSONArray getPageList(JSONObject json, String token, String type, int page, int pageSize) {
        String param = String.format("ciId=%s&page=%d&pageSize=%d", type, page, pageSize);
        HashMap<String, String> heads = Maps.newHashMap();
        heads.put("Authorization", "Bearer "+token);
        String url = JsonUtils.getStr(json, "url") + "/admin/cidata/getData";
        String ret = HttpUtils.sendPostForm(url, param, heads);
        JSONObject retJson = JsonUtils.parse(ret);
        if (retJson.containsKey("content")) {
            JSONObject content = retJson.getJSONObject("content");
            if (content != null) {
                return content.getJSONArray("data");
            }
        }
        return null;
    }

    /**
     * 获取数据量总数
     */
    public long getTotal(JSONObject json, String token, String type) {
        String param = String.format("ciId=%s&page=1&pageSize=1", type);
        HashMap<String, String> heads = Maps.newHashMap();
        heads.put("Authorization", "Bearer "+token);
        String url = JsonUtils.getStr(json, "url") + "/admin/cidata/getData";
        String ret = HttpUtils.sendPostForm(url, param, heads);
        JSONObject retJson = JsonUtils.parse(ret);
        if (retJson.containsKey("content")) {
            JSONObject content = retJson.getJSONObject("content");
            if (content != null) {
                JSONObject page = content.getJSONObject("page");
                return JsonUtils.getLong(page, "total");
            }
        }
        return 0;
    }

    /**
     * 获取Token
     * @param json 参数
     * @return token
     */
    public String getToken(JSONObject json) {
        /*
         * {
         * 	"code": 200,
         * 	"msg": null,
         * 	"data": {
         * 		"access_token": "eyJhbGciOiJIUzUxMiJ9.eyJ1c2VyX2lkIjoxMDcsInVzZXJfa2V5IjoiNzdmMWY3MmEtN2Y3Yy00MmYyLTgwZGMtYWRkYjUxOWM4YmYxIiwidXNlcm5hbWUiOiJhcGl1c2VyIn0.CkaFWxi9AtOcERyQy4TaPfTUjBjZj9ttqrLcVYNR7v3q6X3ugbsc7nrmyUkzkqvFyfnqQC5YZvst-7NPTw7j2w",
         * 		"expires_in": 720
         *   }
         * }
         */
        String url = JsonUtils.getStr(json, "url") + "/x-api/auth/login";
        JSONObject param = new JSONObject();
        param.put("username", JsonUtils.getStr(json, "username"));
        param.put("password", CodeTool.decrypt(JsonUtils.getStr(json, "password")));
        String ret = HttpUtils.sendPost(url, param.toJSONString());
        JSONObject retJson = JsonUtils.parse(ret);
        if (JsonUtils.equal(retJson, "code", "200")) {
            JSONObject data = retJson.getJSONObject("data");
            if (data != null) {
                return JsonUtils.getStr(data, "access_token");
            }
        }
        return null;
    }


    /**
     * 分页获取数据
     * @param json 参数
     * @param token token
     * @return 内容
     */
    public JSONArray getGtmData(JSONObject json, String token) {
        HashMap<String, String> heads = Maps.newHashMap();
        heads.put("Authorization", "Bearer "+token);
        String url = JsonUtils.getStr(json, "url") + "/x-api/device/mstConfig/listTab?pageNum=1&pageSize=10000";
        JSONObject param = new JSONObject();
        param.put("targetId", JsonUtils.getStr(json, "targetId"));

        String ret = HttpUtils.sendPost(url, param.toJSONString(), heads);
        //String ret = HttpUtils.sendPostForm(url, param.toJSONString(), heads);
        JSONObject retJson = JsonUtils.parse(ret);
        if (retJson != null) {
            return retJson.getJSONArray("rows");
        }
        return null;
    }
}
