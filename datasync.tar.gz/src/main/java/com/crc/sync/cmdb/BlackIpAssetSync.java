package com.crc.sync.cmdb;

import com.baomidou.mybatisplus.core.conditions.update.LambdaUpdateWrapper;
import com.baomidou.mybatisplus.core.toolkit.Wrappers;
import com.crc.common.utils.DictUtil;
import com.crc.common.utils.IpUtils;
import com.crc.common.utils.MyTheadUtils;
import com.crc.secface.config.GetSpringBean;
import com.crc.secface.domain.Asset;
import com.crc.secface.domain.SysDictData;
import com.crc.secface.mapper.AssetMapper;
import lombok.extern.slf4j.Slf4j;

import java.util.List;

/**
 * IP 黑名单，去掉某些IP资产
 */
@Slf4j
public class BlackIpAssetSync extends Thread {
    @Override
    public void run() {
        while (true) {
            try {
                List<SysDictData> list = DictUtil.getDict("asset_black_ip");
                if(list.size() > 0) {
                    log.info("IP 黑名单，去掉某些IP资产--开始");
                    AssetMapper assetMapper = GetSpringBean.getBean(AssetMapper.class);
                    for (SysDictData sysDictData : list) {
                        if (IpUtils.isIp(sysDictData.getDictValue())) {
                            Asset asset = assetMapper.selectAssetByInnerIp(sysDictData.getDictValue());
                            if (asset != null) {
                                LambdaUpdateWrapper<Asset> up = Wrappers.lambdaUpdate();
                                up.eq(Asset::getId, asset.getId());
                                up.set(Asset::getDelFlag, "1");
                                assetMapper.update(null, up);
                            }
                        }
                    }
                    log.info("IP 黑名单，去掉某些IP资产--结束");
                }
            } catch (Exception e) {
                log.error(e.getMessage(), e);
            }
            MyTheadUtils.sleepBySec(60 * 5);
        }
    }
}
