package com.crc.sync.cmdb;

import com.crc.common.enums.AssetSourceEnums;
import com.crc.common.enums.ScannerEnums;
import com.crc.common.utils.DataUtils;
import com.crc.common.utils.MyTheadUtils;
import com.crc.scanner.config.SafedogConfig;
import com.crc.secface.config.GetSpringBean;
import com.crc.secface.domain.Asset;
import com.crc.secface.queue.CrcAssetSyncQueue;
import com.crc.secface.queue.CrcRiskAutoDataQueue;
import com.crc.secface.schedule.assemble.CommonAssemble;
import com.crc.secface.schedule.assemble.host.SafedogAssemble;
import com.crc.secface.service.AssetRecordService;
import com.crc.sync.safedog.sdapi.SdapiClient;
import com.crc.sync.safedog.sdapi.SdapiHttpClient;
import com.crc.sync.safedog.sdapi.list.ServerInfoList;
import lombok.extern.slf4j.Slf4j;

import java.util.List;

/**
 * 安全狗资产协同核心逻辑
 */
@Slf4j
public class SafedogCmdbSync {
    public void sync() {
        try {
            CommonAssemble.engineMap.forEach((k, v) -> {
                if (ScannerEnums.SAFEDOG_SCANNER.getCode().equals(v.getEquipmentManufacture())) {
                    sync(SafedogAssemble.getSafedogConfig(k));
                }
            });
        } catch (Exception e) {
            log.error(e.getMessage(), e);
        }
    }

    private void sync(SafedogConfig config) {
        if (!config.isGoodConfig()) {
            log.error("未在引擎管理配置安全狗参数");
            return;
        }
        SdapiClient sdapiClient = new SdapiClient(config.getAddress(),config.getAppId(),config.getKey());
        long total = sdapiClient.assets().getServerInfoListTotal();
        log.info("获取服务器列表,total={}",total);
        AssetRecordService assetRecordService = GetSpringBean.getBean(AssetRecordService.class);
        if (total > 0) {
            for (int i = 1; i < DataUtils.getPageCount(total, SdapiHttpClient.PAGE_SIZE, 1); i++) {
                // 接口每分钟只能请求100次
                MyTheadUtils.sleepBySec(1);
                List<ServerInfoList> list = sdapiClient.assets().getServerInfoList(String.valueOf(i));
                if (list != null) {
                    for (ServerInfoList si : list) {
                        try {
                            if (!"1".equals(si.getIsEnabled())) {
                                log.error("{}不可用", si.getServerIp());
                                continue;
                            }

                            CrcAssetSyncQueue.getInstance().saveData(si.getServerIp(), si, AssetSourceEnums.SAFEDOG_CMDB.getCode());

                            Asset asset = new Asset();
                            asset.setInternalIp(si.getServerIp());
                            asset.setLocalIp(si.getServerLocalIp());
                            asset.setOs(si.getOsType());
                            asset.setSource(AssetSourceEnums.SAFEDOG_CMDB.getCode());
                            //asset.setMacAddress(si.getMacCode());
                            asset.setHostName(si.getHostName());
                            asset.setKernelVersion(si.getSystemKernel());
                            asset.setCode(si.getMacCode());
                            //资产状态，可选项：1在用、2停用、3下架、4库存备用、5故障设备、6已临时关停、7待修、8在修、9闲置、10待报废、11报废、12转交
                            //1-在线，0-离线
                            asset.setOperatingStatus(1);
                            Asset oldAsset = CrcAssetSyncQueue.getInstance().getAssetFullByIp(asset.getInternalIp());
                            if(CrcAssetSyncQueue.getInstance().saveAsset(asset)) {
                                assetRecordService.addChangeRecord(oldAsset, CrcAssetSyncQueue.getInstance().getAssetFullByIp(asset.getInternalIp()));
                                CrcRiskAutoDataQueue.getInstance().saveQingTengAgentX(asset.getInternalIp(), AssetSourceEnums.SAFEDOG_CMDB.getCode());
                            }
                        } catch (Exception e) {
                            log.error(e.getMessage(),e);
                        }
                    }
                }
            }
        }
    }
}
