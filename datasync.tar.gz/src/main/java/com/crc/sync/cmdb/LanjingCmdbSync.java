package com.crc.sync.cmdb;

import com.alibaba.fastjson.JSONArray;
import com.alibaba.fastjson.JSONObject;
import com.crc.common.enums.AssetSourceEnums;
import com.crc.common.utils.DataUtils;
import com.crc.common.utils.DictUtil;
import com.crc.common.utils.HttpUtils;
import com.crc.common.utils.JsonUtils;
import com.crc.secface.db.ConfBuzziMySql;
import com.crc.secface.domain.Asset;
import com.crc.secface.domain.AssetRef;
import com.crc.secface.domain.SysDictData;
import com.crc.secface.domain.TbAssetExt;
import com.crc.secface.queue.CrcAssetSyncQueue;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;

/**
 * 蓝鲸CMDB同步
 */
@Slf4j
public class LanjingCmdbSync {

    public void sync() {
        SysDictData dict = DictUtil.getDictByLabel("sync_sec_config", "lanjing_asset_api_url");
        if (DataUtils.isBlankDict(dict)) {
            return;
        }
        String apiUrl = dict.getDictValue();
        if (StringUtils.isBlank(apiUrl)) {
            log.error("蓝鲸CMDB接口地址配置错误，请配置字典sync_sec_config/lanjing_asset_api_url");
            return;
        }

        /**
         * {
         *   "bk_app_code": "bk_monitorv3",
         *   "bk_app_secret": "cabb68f9-c0ef-49f7-bb37-20289b5ba3f2",
         *   "bk_username": "admin"
         * }
         */
        SysDictData authDict = DictUtil.getDictByLabel("sync_sec_config", "lanjing_auth_api_url");
        if (DataUtils.isBlankDict(authDict)) {
            log.error("蓝鲸CMDB认证配置错误，未配置字典sync_sec_config/lanjing_auth_api_url");
            return;
        }
        String remark = dict.getRemark();
        if (StringUtils.isBlank(remark)) {
            log.error("蓝鲸CMDB认证配置错误，请配置字典sync_sec_config/lanjing_asset_api_url/remark");
            return;
        }

        /**
         * {
         *   "bk_app_code": "bk_monitorv3",
         *   "bk_app_secret": "cabb68f9-c0ef-49f7-bb37-20289b5ba3f2",
         *   "bk_username": "admin",
         *   "page": {
         *     "start": 0,
         *     "limit": 10,
         *     "sort": "bk_host_id"
         *   }
         * }
         */
        JSONObject q = JsonUtils.parse(remark);
        String bk_username = JsonUtils.getStr(q, "bk_username");
        if (StringUtils.isBlank(bk_username)) {
            bk_username = "admin";
            q.put(bk_username, bk_username);
        }
        String bk_app_code = JsonUtils.getStr(q, "bk_app_code");
        if (StringUtils.isBlank(bk_app_code)) {
            bk_app_code = "bk_monitorv3";
            q.put(bk_app_code, bk_app_code);
        }
        String bk_app_secret = JsonUtils.getStr(q, "bk_app_secret");
        if (StringUtils.isBlank(bk_app_secret)) {
            bk_app_secret = "cabb68f9-c0ef-49f7-bb37-20289b5ba3f2";
            q.put(bk_app_secret, bk_app_secret);
        }

        JSONObject page = new JSONObject();
        page.put("start", 1);
        page.put("limit", 1);
        page.put("sort", "bk_host_id");
        q.put("page", page);

        int isAssetExt = ConfBuzziMySql.existTable("tb_asset_ext");

        int total = getTotal(apiUrl, q);
        if (total > 0) {
            log.info("拉起蓝鲸CMDB总数：" + total);
            int pageSize = 400;
            for (int i = 1; i <= DataUtils.getPageCount(total,pageSize,1); i++) {
                q.getJSONObject("page").put("start", i);
                q.getJSONObject("page").put("limit", pageSize);
                try {
                    String ret = HttpUtils.sendPost(apiUrl, q.toJSONString());
                    JSONObject retJson = JsonUtils.parse(ret);
                    if ("success".equalsIgnoreCase(JsonUtils.getStr(retJson, "bk_error_msg"))) {
                        JSONArray dataArr = retJson.getJSONObject("data").getJSONArray("info");
                        if (dataArr != null) {
                            for (int j = 0; j < dataArr.size(); j++) {
                                try {
                                    JSONObject json = dataArr.getJSONObject(j).getJSONObject("host");
                                    /*
                                      "bk_asset_id": "DKUXHBUH189",
                                      "bk_bak_operator": "admin",
                                      "bk_cloud_id": [
                                        {
                                          "id": "0",
                                          "bk_obj_id": "plat",
                                          "bk_obj_icon": "",
                                          "bk_inst_id": 0,
                                          "bk_obj_name": "",
                                          "bk_inst_name": "default area"
                                        }
                                      ],
                                      "bk_comment": "",
                                      "bk_cpu": 8,
                                      "bk_cpu_mhz": 2609,
                                      "bk_cpu_module": "E5-2620",
                                      "bk_disk": 300000,
                                      "bk_host_id": 17,
                                      "bk_host_innerip": "192.168.1.1",
                                      "bk_host_name": "nginx-1",
                                      "bk_host_outerip": "",
                                      "bk_isp_name": null,
                                      "bk_mac": "",
                                      "bk_mem": 32000,
                                      "bk_os_bit": ""
                                     */
                                    Asset asset = new Asset();
                                    asset.setInternalIp(JsonUtils.getStr(json, "bk_host_innerip"));
                                    asset.setInternetIp(JsonUtils.getStr(json, "bk_host_outerip"));
                                    asset.setOperatingUser(JsonUtils.getStr(json, "bk_bak_operator"));
                                    asset.setSource(AssetSourceEnums.LANJING_CMDB.getCode());
                                    asset.setMacAddress(JsonUtils.getStr(json, "bk_mac"));
                                    asset.setOs(JsonUtils.getStr(json, "bk_os_bit"));
                                    CrcAssetSyncQueue.getInstance().saveAsset(asset);

                                    if (isAssetExt == 1) {
                                        TbAssetExt ext = new TbAssetExt();
                                        ext.setCpu(JsonUtils.getStr(json, "bk_cpu") + "/" + JsonUtils.getStr(json, "bk_cpu_mhz"));
                                        ext.setMemory(JsonUtils.getInt(json, "bk_mem"));
                                        ext.setDisk(JsonUtils.getInt(json, "bk_disk"));

                                        AssetRef ref = new AssetRef();
                                        ref.setExt(ext);
                                        ref.setIp(asset.getInternalIp());
                                        CrcAssetSyncQueue.getInstance().saveAssetExt(ref);
                                    }

                                } catch (Exception e) {
                                    log.error(e.getMessage(), e);
                                }
                            }
                        }
                    }
                } catch (Exception e) {
                    log.error(e.getMessage(), e);
                }
            }
        }
    }


    public int getTotal(String url, JSONObject jsonObject) {
        try {
            String ret = HttpUtils.sendPost(url, jsonObject.toJSONString());
            JSONObject retJson = JsonUtils.parse(ret);
            if ("success".equalsIgnoreCase(JsonUtils.getStr(retJson, "bk_error_msg"))) {
                return retJson.getJSONObject("data").getIntValue("count");
            }
        } catch (Exception e) {
            log.error(e.getMessage(), e);
        }
        return 0;
    }
}
