package com.crc.sync.cmdb;


import com.crc.common.constants.QingtengConstants;
import com.crc.common.enums.AssetSourceEnums;
import com.crc.common.enums.ScannerEnums;
import com.crc.common.utils.DataUtils;
import com.crc.common.utils.MyTheadUtils;
import com.crc.scanner.config.QtConfig;
import com.crc.scanner.config.SafedogConfig;
import com.crc.secface.domain.AssetPort;
import com.crc.secface.domain.AssetSoftware;
import com.crc.secface.schedule.assemble.CommonAssemble;
import com.crc.secface.schedule.assemble.host.QingtengAssemble;
import com.crc.secface.schedule.assemble.host.SafedogAssemble;
import com.crc.sync.config.SyncSecConfigLoad;
import com.crc.sync.config.SyncSecConstants;
import com.crc.sync.qingteng.QingtengDataSync;
import com.crc.sync.qingteng.QingtengPortSync;
import com.crc.sync.safedog.sdapi.SdapiClient;
import com.crc.sync.safedog.sdapi.SdapiHttpClient;
import com.crc.sync.safedog.sdapi.info.*;
import com.crc.sync.safedog.sdapi.list.*;
import com.crc.sync.work.PortSaveWork;
import com.crc.sync.work.SoftwareSaveWork;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;

import java.util.List;

@Slf4j
public class ComponentCenter {

    public void sync() {
        try {
            CommonAssemble.engineMap.forEach((k, v) -> {
                if (ScannerEnums.QINGTENG_SCANNER.getCode().equals(v.getEquipmentManufacture())) {
                    syncQt(QingtengAssemble.getQtConfig(k));
                }
            });
        } catch (Exception e) {
            log.error(e.getMessage(), e);
        }

        try {
            CommonAssemble.engineMap.forEach((k, v) -> {
                if (ScannerEnums.SAFEDOG_SCANNER.getCode().equals(v.getEquipmentManufacture())) {
                    syncSd(SafedogAssemble.getSafedogConfig(k));
                }
            });
        } catch (Exception e) {
            log.error(e.getMessage(), e);
        }
    }

    private static void syncQt(QtConfig scanInfo) {
        /*
           同步青藤组件
        */
        try {
            if (SyncSecConfigLoad.isEnable(SyncSecConstants.QT_COMP_SYNC_ENABLE)) {
                log.info("青藤组件数据同步开始");
                QingtengDataSync qingtengDataSync = new QingtengDataSync();
                qingtengDataSync.sync(scanInfo, "linux", QingtengConstants.APP, "支撑系统", "组件");
                qingtengDataSync.sync(scanInfo, "win", QingtengConstants.APP, "支撑系统", "组件");

                qingtengDataSync.sync(scanInfo, "linux", QingtengConstants.WEB_APP, "支撑系统", "中间件");
                qingtengDataSync.sync(scanInfo, "win", QingtengConstants.WEB_APP, "支撑系统", "中间件");

                qingtengDataSync.sync(scanInfo, "linux", QingtengConstants.WEB_FRAME, "支撑系统", "开发框架");
                qingtengDataSync.sync(scanInfo, "win", QingtengConstants.WEB_FRAME, "支撑系统", "开发框架");

                qingtengDataSync.sync(scanInfo, "linux", QingtengConstants.DB, "系统软件", "数据库系统");
                qingtengDataSync.sync(scanInfo, "win", QingtengConstants.DB, "系统软件", "数据库系统");

                qingtengDataSync.sync(scanInfo, "linux", QingtengConstants.PROCESS, "支撑系统", "组件");
                qingtengDataSync.sync(scanInfo, "win", QingtengConstants.PROCESS, "支撑系统", "组件");
                //@小兵 太慢了，建议去掉。20240723
//                qingtengDataSync.sync(scanInfo, "linux", QingtengConstants.PKG, "支撑系统", "组件");
//                qingtengDataSync.sync(scanInfo, "win", QingtengConstants.PKG, "支撑系统", "组件");

                qingtengDataSync.sync(scanInfo, "linux", QingtengConstants.JAR, "支撑系统", "组件");
                qingtengDataSync.sync(scanInfo, "win", QingtengConstants.JAR, "支撑系统", "组件");
                //@小兵 太慢了，建议去掉。20240723
//                qingtengDataSync.sync(scanInfo, "linux", QingtengConstants.WEB_SITE, "支撑系统", "服务");
//                qingtengDataSync.sync(scanInfo, "win", QingtengConstants.WEB_SITE, "支撑系统", "服务");

                (new QingtengPortSync()).sync(scanInfo);
                log.info("青藤组件数据同步结束");
            }
        } catch (Exception e) {
            log.error(e.getMessage(), e);
        }
    }

    private static void syncSd(SafedogConfig config) {

        /*
           同步安全狗组件
        */
        try {
            if (SyncSecConfigLoad.isEnable(SyncSecConstants.SD_COMP_SYNC_ENABLE)) {
                log.info("安全狗组件数据同步开始");
                SdapiClient sdapiClient = new SdapiClient(config.getAddress(),config.getAppId(),config.getKey());
                long total = sdapiClient.assets().getServerDatabaseInfoListTotal();
                log.info("getServerDatabaseInfoListTotal,total={}",total);
                if (total > 0) {
                    for (int i = 1; i < DataUtils.getPageCount(total, SdapiHttpClient.PAGE_SIZE, 1); i++) {
                        // 接口每分钟只能请求100次
                        MyTheadUtils.sleepBySec(1);
                        List<ServerDatabaseInfoList> list = sdapiClient.assets().getServerDatabaseInfoList(String.valueOf(i));
                        if (list != null) {
                            for (ServerDatabaseInfoList si : list) {
                                String serverIp = si.getServerIp();
                                if (si.getDatebaseInfoList() != null) {
                                    try {
                                        for (DatebaseInfo datebaseInfo : si.getDatebaseInfoList()) {
                                            AssetSoftware assetSoftware = new AssetSoftware();
                                            String port = "";
                                            if (StringUtils.isNotBlank(datebaseInfo.getBindIp())) {
                                                String ipStr = datebaseInfo.getBindIp().split(";")[0];
                                                String []portS = ipStr.split(":");
                                                if (portS.length > 1) {
                                                    port = portS[portS.length - 1];
                                                }
                                            }
                                            assetSoftware.setSortPort(port);
                                            assetSoftware.setIp(serverIp);
                                            assetSoftware.setSoftName(datebaseInfo.getName());
                                            assetSoftware.setSoftVersion(datebaseInfo.getVersion());
                                            assetSoftware.setSoftPath(datebaseInfo.getPath());
                                            assetSoftware.setInstallDate(datebaseInfo.getInsertTime());
                                            assetSoftware.setSoftType("db");
                                            assetSoftware.setFirstCatTag("系统软件");
                                            assetSoftware.setSecondCatTag("数据库系统");

                                            assetSoftware.setDevType("1");
                                            assetSoftware.setSource(AssetSourceEnums.SAFEDOG_CMDB.getCode());
                                            SoftwareSaveWork.magicQueue.offer(assetSoftware);
                                        }
                                    } catch (Exception e) {
                                        log.error(e.getMessage(),e);
                                    }
                                }
                            }
                        }
                    }
                }

                total = sdapiClient.assets().getServerSoftwareInfoListTotal();
                log.info("getServerSoftwareInfoListTotal,total={}",total);
                if (total > 0) {
                    for (int i = 1; i < DataUtils.getPageCount(total, SdapiHttpClient.PAGE_SIZE, 1); i++) {
                        // 接口每分钟只能请求100次
                        MyTheadUtils.sleepBySec(1);
                        List<ServerSoftwareInfoList> list = sdapiClient.assets().getServerSoftwareInfoList(String.valueOf(i));
                        if (list != null) {
                            for (ServerSoftwareInfoList si : list) {
                                String serverIp = si.getServerIp();
                                if (si.getSoftwareInfoList() != null) {
                                    try {
                                        for (SoftwareInfo softwareInfo : si.getSoftwareInfoList()) {
                                            AssetSoftware assetSoftware = new AssetSoftware();
                                            assetSoftware.setIp(serverIp);
                                            assetSoftware.setSoftName(softwareInfo.getName());
                                            assetSoftware.setSoftVersion(softwareInfo.getVersion());
                                            assetSoftware.setSoftPath(softwareInfo.getPath());
                                            assetSoftware.setInstallDate(softwareInfo.getInsertTime());
                                            assetSoftware.setSoftType("app");
                                            assetSoftware.setFirstCatTag("支撑系统");
                                            assetSoftware.setSecondCatTag("组件");

                                            assetSoftware.setDevType("1");
                                            assetSoftware.setSource(AssetSourceEnums.SAFEDOG_CMDB.getCode());
                                            SoftwareSaveWork.magicQueue.offer(assetSoftware);
                                        }
                                    } catch (Exception e) {
                                        log.error(e.getMessage(),e);
                                    }
                                }
                            }
                        }
                    }
                }


                total = sdapiClient.assets().getServerJarInfoListTotal();
                log.info("getServerSoftwareInfoListTotal,total={}",total);
                if (total > 0) {
                    for (int i = 1; i < DataUtils.getPageCount(total, SdapiHttpClient.PAGE_SIZE, 1); i++) {
                        // 接口每分钟只能请求100次
                        MyTheadUtils.sleepBySec(1);
                        List<ServerJarInfoList> list = sdapiClient.assets().getServerJarInfoList(String.valueOf(i));
                        if (list != null) {
                            for (ServerJarInfoList si : list) {
                                String serverIp = si.getServerIp();
                                if (si.getJarInfoList() != null) {
                                    try {
                                        for (JarInfo jarInfo : si.getJarInfoList()) {
                                            AssetSoftware assetSoftware = new AssetSoftware();
                                            assetSoftware.setIp(serverIp);
                                            assetSoftware.setSoftName(jarInfo.getName());
                                            assetSoftware.setSoftVersion(jarInfo.getVersion());
                                            assetSoftware.setSoftPath(jarInfo.getAbsPath());
                                            assetSoftware.setInstallDate(jarInfo.getInsertTime());
                                            assetSoftware.setSoftType("jar");
                                            assetSoftware.setFirstCatTag("支撑系统");
                                            assetSoftware.setSecondCatTag("组件");

                                            assetSoftware.setDevType("1");
                                            assetSoftware.setSource(AssetSourceEnums.SAFEDOG_CMDB.getCode());
                                            SoftwareSaveWork.magicQueue.offer(assetSoftware);
                                        }
                                    } catch (Exception e) {
                                        log.error(e.getMessage(),e);
                                    }
                                }
                            }
                        }
                    }
                }

                total = sdapiClient.assets().getServerPackageInfoListTotal();
                log.info("getServerSoftwareInfoListTotal,total={}",total);
                if (total > 0) {
                    for (int i = 1; i < DataUtils.getPageCount(total, SdapiHttpClient.PAGE_SIZE, 1); i++) {
                        // 接口每分钟只能请求100次
                        MyTheadUtils.sleepBySec(1);
                        List<ServerPackageInfoList> list = sdapiClient.assets().getServerPackageInfoList(String.valueOf(i));
                        if (list != null) {
                            for (ServerPackageInfoList si : list) {
                                String serverIp = si.getServerIp();
                                if (si.getPackageInfoList() != null) {
                                    try {
                                        for (PackageInfo jarInfo : si.getPackageInfoList()) {
                                            AssetSoftware assetSoftware = new AssetSoftware();
                                            assetSoftware.setIp(serverIp);
                                            assetSoftware.setSoftName(jarInfo.getName());
                                            assetSoftware.setSoftVersion(jarInfo.getVersion());
                                            assetSoftware.setSoftPath(jarInfo.getPath());
                                            assetSoftware.setSoftManu(jarInfo.getVendor());
                                            assetSoftware.setInstallDate(jarInfo.getInstallDate());
                                            assetSoftware.setSoftType("pkg");
                                            assetSoftware.setFirstCatTag("支撑系统");
                                            assetSoftware.setSecondCatTag("组件");

                                            assetSoftware.setDevType("1");
                                            assetSoftware.setSource(AssetSourceEnums.SAFEDOG_CMDB.getCode());
                                            SoftwareSaveWork.magicQueue.offer(assetSoftware);
                                        }
                                    } catch (Exception e) {
                                        log.error(e.getMessage(),e);
                                    }
                                }
                            }
                        }
                    }
                }

                total = sdapiClient.assets().getServerWebContainerInfoListTotal();
                log.info("getServerSoftwareInfoListTotal,total={}",total);
                if (total > 0) {
                    for (int i = 1; i < DataUtils.getPageCount(total, SdapiHttpClient.PAGE_SIZE, 1); i++) {
                        // 接口每分钟只能请求100次
                        MyTheadUtils.sleepBySec(1);
                        List<ServerWebContainerInfoList> list = sdapiClient.assets().getServerWebContainerInfoList(String.valueOf(i));
                        if (list != null) {
                            for (ServerWebContainerInfoList si : list) {
                                String serverIp = si.getServerIp();
                                if (si.getWebContainerInfoList() != null) {
                                    try {
                                        for (WebContainerInfo jarInfo : si.getWebContainerInfoList()) {
                                            AssetSoftware assetSoftware = new AssetSoftware();
                                            assetSoftware.setIp(serverIp);
                                            assetSoftware.setSoftName(jarInfo.getName());
                                            assetSoftware.setSoftVersion(jarInfo.getVersion());
                                            assetSoftware.setSoftPath(jarInfo.getPath());
                                            assetSoftware.setInstallDate(jarInfo.getInsertTime());
                                            assetSoftware.setSoftType("webapp");
                                            assetSoftware.setFirstCatTag("支撑系统");
                                            assetSoftware.setSecondCatTag("中间件");

                                            assetSoftware.setDevType("1");
                                            assetSoftware.setSource(AssetSourceEnums.SAFEDOG_CMDB.getCode());
                                            SoftwareSaveWork.magicQueue.offer(assetSoftware);
                                        }
                                    } catch (Exception e) {
                                        log.error(e.getMessage(),e);
                                    }
                                }
                            }
                        }
                    }
                }

                total = sdapiClient.assets().getServerPortInfoListTotal();
                log.info("getServerSoftwareInfoListTotal,total={}",total);
                if (total > 0) {
                    for (int i = 1; i < DataUtils.getPageCount(total, SdapiHttpClient.PAGE_SIZE, 1); i++) {
                        // 接口每分钟只能请求100次
                        MyTheadUtils.sleepBySec(1);
                        List<ServerPortInfoList> list = sdapiClient.assets().getServerPortInfoList(String.valueOf(i));
                        if (list != null) {
                            for (ServerPortInfoList si : list) {
                                String serverIp = si.getServerIp();
                                if (si.getPortInfoList() != null) {
                                    try {
                                        for (PortInfoList jarInfo : si.getPortInfoList()) {
                                            AssetPort tbAssetPort = new AssetPort();
                                            /* 协议 1 TCP|2 UDP|3 TCP、UDP */
                                            if (jarInfo.getProtocolType() != null) {
                                                if (jarInfo.getProtocolType() == 1) {
                                                    tbAssetPort.setProto("TCP");
                                                }else if (jarInfo.getProtocolType() == 2) {
                                                    tbAssetPort.setProto("UDP");
                                                }else {
                                                    tbAssetPort.setProto("TCP、UDP");
                                                }
                                            }
                                            tbAssetPort.setIp(serverIp);
                                            tbAssetPort.setPort(jarInfo.getPort() + "");
                                            tbAssetPort.setSyncStatus("0");
                                            tbAssetPort.setListenerProcess(jarInfo.getProcessName());
                                            PortSaveWork.magicQueue.put(tbAssetPort);
                                        }
                                    } catch (Exception e) {
                                        log.error(e.getMessage(),e);
                                    }
                                }
                            }
                        }
                    }
                }


                log.info("安全狗组件数据同步结束");
            }
        } catch (Exception e) {
            log.error(e.getMessage(), e);
        }
    }
}
