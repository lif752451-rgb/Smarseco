package com.crc.sync.cmdb;

import com.alibaba.fastjson.JSONArray;
import com.alibaba.fastjson.JSONObject;
import com.crc.common.enums.AssetSourceEnums;
import com.crc.common.enums.ScannerEnums;
import com.crc.common.utils.DataUtils;
import com.crc.common.utils.HttpUtils;
import com.crc.common.utils.JsonUtils;
import com.crc.common.utils.Md5Utils;
import com.crc.scanner.config.JtConfig;
import com.crc.secface.config.GetSpringBean;
import com.crc.secface.domain.Asset;
import com.crc.secface.domain.AssetPort;
import com.crc.secface.domain.AssetSoftware;
import com.crc.secface.domain.JiaotuAgent;
import com.crc.secface.mapper.JiaotuAgentMapper;
import com.crc.secface.queue.CrcAssetSyncQueue;
import com.crc.secface.schedule.assemble.CommonAssemble;
import com.crc.secface.schedule.assemble.host.JiaotuAssemble;
import com.crc.sync.work.PortSaveWork;
import com.crc.sync.work.SoftwareSaveWork;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
/**
 * 复制联动授权码，并计算token，公式：sha256(授权码+&+时间戳)+时间戳
 * 例如NGSOC联动授权码是：312a36744a2144429af6f22019dcdae9，时间戳是1682068637000（精确到毫秒）
 * 计算方式如下：
 * 1，计算sha256(312a36744a2144429af6f22019dcdae9&1682068637000)，结果为：f659b13f362fc97f707c943548612f3ed2e38760f0b9d1c95398b545e629b377
 * 2，再拼接时间戳：f659b13f362fc97f707c943548612f3ed2e38760f0b9d1c95398b545e629b3771682068637000
 */

/**
 * 蓝鲸CMDB同步
 */
@Slf4j
public class JiaotuCmdbSync {
    public static String getToken(JtConfig config) {
        String ts = String.valueOf(System.currentTimeMillis());
        String sha256 = Md5Utils.sha256(config.getToken() + "&" + ts);
        //log.info("{}-{}",config.getToken(),ts);
        return sha256 + ts;
    }

    public void sync() {
        try {
            CommonAssemble.engineMap.forEach((k, v) -> {
                if (ScannerEnums.JIAOTU_SCANNER.getCode().equals(v.getEquipmentManufacture())) {
                    sync(JiaotuAssemble.getJtConfig(k));
                }
            });
        } catch (Exception e) {
            log.error(e.getMessage(), e);
        }
    }

    private void sync(JtConfig config) {
        if (!config.isGoodConfig()) {
            log.error("未在引擎管理配置椒图参数");
            return;
        }
        if ("NGSOC".equalsIgnoreCase(config.getVersion())) {
            syncNgsoc(config);
            return;
        }
        String token = getToken(config);

        /*
        {
        "token":"XXXXXXXXXXXXXXXXXXXXXXXXXXXX",
        "currentPage":1,
        "maxResults":10
        }
         */
        JSONObject q = new JSONObject();
        q.put("currentPage", 1);
        q.put("maxResults", 1);
        q.put("token", token);


        int total = getTotal(config.getAddress() + "/kernelApi/kernelCommonSrv/machineController/listMachines", q);
        if (total > 0) {
            log.info("拉起椒图CMDB总数：" + total);
            int pageSize = 400;
            for (int i = 1; i <= DataUtils.getPageCount(total, pageSize, 1); i++) {
                q.put("currentPage", i);
                q.put("maxResults", pageSize);
                try {
                    String ret = HttpUtils.sendPost(config.getAddress() + "/kernelApi/kernelCommonSrv/machineController/listMachines", q.toJSONString());
                    JSONObject retJson = JsonUtils.parse(ret);
                    if ("1".equalsIgnoreCase(JsonUtils.getStr(retJson, "code"))) {
                        JSONArray dataArr = retJson.getJSONObject("data").getJSONArray("list");
                        if (dataArr != null) {
                            for (int j = 0; j < dataArr.size(); j++) {
                                try {
                                    JSONObject json = dataArr.getJSONObject(j);
                                    /*
                                    {
                                        "uuid":"fcd6e9eac7c61d18dec154ca2d77a378",
                                        "machineName":"iZ210tr26x9Z",
                                        "mac":"6C:92:BF:C9:C3:78",
                                        "extranetIp":"127.0.0.1",
                                        "intranetIp":"172.29.147.24",
                                        "onlineStatus":1,
                                        "osType":0,
                                        "operatingSystem":"Microsoft Windows Server 2008 R2 Enterprise
                                        Edition 64-bit",
                                        "softwareVersion":"win_2.2.130",
                                        "ifDelete":1
                                        }
                                     */
                                    saveAgent(JsonUtils.getStr(json, "intranetIp"), JsonUtils.getStr(json, "uuid"));
                                    CrcAssetSyncQueue.getInstance().saveData(JsonUtils.getStr(json, "intranetIp"), json, AssetSourceEnums.JIAOTU_CMDB.getCode());
                                    Asset asset = new Asset();
                                    asset.setInternalIp(JsonUtils.getStr(json, "intranetIp"));
                                    asset.setInternetIp(JsonUtils.getStr(json, "extranetIp"));
                                    asset.setInternetIp(JsonUtils.getStr(json, "extranetIp"));
                                    asset.setSource(AssetSourceEnums.JIAOTU_CMDB.getCode());
                                    asset.setMacAddress(JsonUtils.getStr(json, "mac"));
                                    asset.setOs(JsonUtils.getStr(json, "operatingSystem"));
                                    //资产状态，可选项：1在用、2停用、3下架、4库存备用、5故障设备、6已临时关停、7待修、8在修、9闲置、10待报废、11报废、12转交
                                    //1-在线，0-离线
                                    asset.setOperatingStatus(1);
                                    CrcAssetSyncQueue.getInstance().saveAsset(asset);
                                } catch (Exception e) {
                                    log.error(e.getMessage(), e);
                                }
                            }
                        }
                    }
                } catch (Exception e) {
                    log.error(e.getMessage(), e);
                }
            }
        }
    }

    private void syncNgsoc(JtConfig config) {
        String token = getToken(config);

        /*
        {
        "token":"XXXXXXXXXXXXXXXXXXXXXXXXXXXX",
        "currentPage":1,
        "maxResults":10
        }
         */
        JSONObject q = new JSONObject();
        q.put("currentPage", 1);
        q.put("maxResults", 1);
        q.put("token", token);


        int total = getTotal(config.getAddress() + "/api/assetSrv/zcMachineController/listMachineBaseInfos", q);
        if (total > 0) {
            log.info("拉起椒图CMDB总数：" + total);
            int pageSize = 400;
            for (int i = 1; i <= DataUtils.getPageCount(total, pageSize, 1); i++) {
                q.put("currentPage", i);
                q.put("maxResults", pageSize);
                try {
                    String ret = HttpUtils.sendPost(config.getAddress() + "/kernelApi/kernelCommonSrv/machineController/listMachines", q.toJSONString());
                    JSONObject retJson = JsonUtils.parse(ret);
                    if ("1".equalsIgnoreCase(JsonUtils.getStr(retJson, "code"))) {
                        JSONArray dataArr = retJson.getJSONObject("data").getJSONArray("list");
                        if (dataArr != null) {
                            for (int j = 0; j < dataArr.size(); j++) {
                                try {
                                    JSONObject json = dataArr.getJSONObject(j);
                                    /*
                                    {
                                        "uuid":"fcd6e9eac7c61d18dec154ca2d77a378",
                                        "machineName":"iZ210tr26x9Z",
                                        "mac":"6C:92:BF:C9:C3:78",
                                        "extranetIp":"127.0.0.1",
                                        "intranetIp":"172.29.147.24",
                                        "onlineStatus":1,
                                        "osType":0,
                                        "operatingSystem":"Microsoft Windows Server 2008 R2 Enterprise Edition 64-bit",
                                        "softwareVersion":"win_2.2.130",
                                        "ifDelete":1
                                        }
                                     */
                                    saveAgent(JsonUtils.getStr(json, "intranetIp"), JsonUtils.getStr(json, "uuid"));
                                    CrcAssetSyncQueue.getInstance().saveData(JsonUtils.getStr(json, "intranetIp"), json, AssetSourceEnums.JIAOTU_CMDB.getCode());
                                    Asset asset = new Asset();
                                    asset.setInternalIp(JsonUtils.getStr(json, "intranetIp"));
                                    asset.setInternetIp(JsonUtils.getStr(json, "extranetIp"));
                                    asset.setSource(AssetSourceEnums.JIAOTU_CMDB.getCode());
                                    asset.setMacAddress(JsonUtils.getStr(json, "mac"));
                                    asset.setHostName(JsonUtils.getStr(json, "machineName"));
                                    asset.setOs(JsonUtils.getStr(json, "softwareVersion"));
                                    //资产状态，可选项：1在用、2停用、3下架、4库存备用、5故障设备、6已临时关停、7待修、8在修、9闲置、10待报废、11报废、12转交
                                    //1-在线，0-离线
                                    asset.setOperatingStatus(1);
                                    CrcAssetSyncQueue.getInstance().saveAsset(asset);

                                    syncHostDetail(config, asset.getInternalIp());
                                } catch (Exception e) {
                                    log.error(e.getMessage(), e);
                                }
                            }
                        }
                    }
                } catch (Exception e) {
                    log.error(e.getMessage(), e);
                }
            }
        }
    }

    private void syncHostDetail(JtConfig scannerInfo,String ip) {
        String url = scannerInfo.getAddress();
        String apiUrl = url + "/api/assetSrv/esZcController/zcForNGSOC";
        JSONObject param = new JSONObject();
        param.put("token", JiaotuCmdbSync.getToken(scannerInfo));
        param.put("hostIp", ip);
        String ret = HttpUtils.sendPost(apiUrl, param.toJSONString());
        try {
            JSONObject json = JsonUtils.parse(ret);
            if (json.containsKey("code") && JsonUtils.equal(json, "code", "1")) {
                JSONObject data = json.getJSONObject("data");
                if (data.containsKey("webServers")) {
                    JSONArray webServers = data.getJSONArray("webServers");
                    if (webServers != null && webServers.size() > 0) {
                        for (int i = 0; i < webServers.size(); i++) {
                            JSONObject jsonObject = webServers.getJSONObject(i);
                            AssetSoftware softwareInfo = new AssetSoftware();
                            softwareInfo.setIp(ip);
                            softwareInfo.setFirstCatTag("支撑系统");
                            softwareInfo.setSecondCatTag("服务");
                            softwareInfo.setSoftName(JsonUtils.getStr(jsonObject, "webServerName"));
                            softwareInfo.setSoftVersion(JsonUtils.getStr(jsonObject, "webServerVersion"));
                            softwareInfo.setSoftPath(JsonUtils.getFieldStr(jsonObject, "processPath","进程路径"));
                            softwareInfo.setSortPort(JsonUtils.getStr(jsonObject, "port"));
                            softwareInfo.setDevType("1");
                            softwareInfo.setSource(AssetSourceEnums.JIAOTU_CMDB.getCode());
                            SoftwareSaveWork.magicQueue.offer(softwareInfo);
                        }
                    }
                }
                if (data.containsKey("webFrames")) {
                    JSONArray webServers = data.getJSONArray("webFrames");
                    if (webServers != null && webServers.size() > 0) {
                        for (int i = 0; i < webServers.size(); i++) {
                            JSONObject jsonObject = webServers.getJSONObject(i);
                            AssetSoftware softwareInfo = new AssetSoftware();
                            softwareInfo.setIp(ip);
                            softwareInfo.setFirstCatTag("支撑系统");
                            softwareInfo.setSecondCatTag("开发框架");
                            softwareInfo.setSoftName(JsonUtils.getStr(jsonObject, "webFrameName"));
                            softwareInfo.setSoftVersion(JsonUtils.getStr(jsonObject, "webFrameVersion"));
                            softwareInfo.setSoftPath(JsonUtils.getFieldStr(jsonObject, "webFramePath","应用路径"));
                            softwareInfo.setDevType("1");
                            softwareInfo.setSource(AssetSourceEnums.JIAOTU_CMDB.getCode());
                            SoftwareSaveWork.magicQueue.offer(softwareInfo);
                        }
                    }
                }
                if (data.containsKey("databases")) {
                    JSONArray webServers = data.getJSONArray("databases");
                    if (webServers != null && webServers.size() > 0) {
                        for (int i = 0; i < webServers.size(); i++) {
                            JSONObject jsonObject = webServers.getJSONObject(i);
                            AssetSoftware softwareInfo = new AssetSoftware();
                            softwareInfo.setIp(ip);
                            softwareInfo.setFirstCatTag("系统软件");
                            softwareInfo.setSecondCatTag("数据库系统");
                            softwareInfo.setSoftName(JsonUtils.getStr(jsonObject, "databaseName"));
                            softwareInfo.setSortPort(JsonUtils.getStr(jsonObject, "port"));
                            softwareInfo.setSoftVersion(JsonUtils.getStr(jsonObject, "databaseVersion"));
                            softwareInfo.setSoftPath(JsonUtils.getFieldStr(jsonObject, "webFramePath","应用路径"));
                            softwareInfo.setDevType("1");
                            softwareInfo.setSource(AssetSourceEnums.JIAOTU_CMDB.getCode());
                            SoftwareSaveWork.magicQueue.offer(softwareInfo);
                        }
                    }
                }
                if (data.containsKey("ports")) {
                    JSONArray webServers = data.getJSONArray("ports");
                    if (webServers != null && webServers.size() > 0) {
                        for (int i = 0; i < webServers.size(); i++) {
                            JSONObject jsonObject = webServers.getJSONObject(i);
                            AssetPort softwareInfo = new AssetPort();
                            softwareInfo.setIp(ip);
                            softwareInfo.setPort(JsonUtils.getStr(jsonObject, "port"));
                            softwareInfo.setProto(JsonUtils.getStr(jsonObject, "protocal"));
                            softwareInfo.setListenerProcess(JsonUtils.getStr(jsonObject, "processName"));
                            softwareInfo.setDevType("1");
                            PortSaveWork.magicQueue.offer(softwareInfo);
                        }
                    }
                }
            } else {
                log.error(ip + " ret=" + ret);
            }

        } catch (Exception e) {
            log.error(e.getMessage(), e);
        }
    }

    public int getTotal(String url, JSONObject jsonObject) {
        try {
            String ret = HttpUtils.sendPost(url, jsonObject.toJSONString());
            JSONObject retJson = JsonUtils.parse(ret);
            if ("1".equalsIgnoreCase(JsonUtils.getStr(retJson, "code"))) {
                return retJson.getJSONObject("data").getIntValue("total");
            }
        } catch (Exception e) {
            log.error(e.getMessage(), e);
        }
        return 0;
    }

    public void saveAgent(JSONObject json) {
        JiaotuAgent agent = new JiaotuAgent();
        agent.setIp(JsonUtils.getStr(json, "intranetIp"));
        agent.setId(JsonUtils.getStr(json, "uuid"));
        agent.setStatus(JsonUtils.getInt(json, "onlineStatus"));
        agent.setType(JsonUtils.getInt(json, "osType"));
        agent.setIfDel(JsonUtils.getInt(json, "ifDelete"));
        if (StringUtils.isBlank(agent.getIp()) || StringUtils.isBlank(agent.getId())) {
            return;
        }
        JiaotuAgentMapper jiaotuAgentMapper = GetSpringBean.getBean(JiaotuAgentMapper.class);
        JiaotuAgent tmp = jiaotuAgentMapper.selectById(agent.getId());
        if (tmp == null) {
            jiaotuAgentMapper.insert(agent);
        } else {
            jiaotuAgentMapper.updateById(agent);
        }
    }

    /**
     * 保存椒图 agent
     * @param ip
     * @param uuid
     */
    public void saveAgent(String ip,String uuid) {
        JiaotuAgent agent = new JiaotuAgent();
        agent.setIp(ip);
        agent.setId(uuid);
        if (StringUtils.isBlank(agent.getIp()) || StringUtils.isBlank(agent.getId())) {
            return;
        }
        JiaotuAgentMapper jiaotuAgentMapper = GetSpringBean.getBean(JiaotuAgentMapper.class);
        JiaotuAgent tmp = jiaotuAgentMapper.selectById(agent.getId());
        if (tmp == null) {
            jiaotuAgentMapper.insert(agent);
        } else {
            jiaotuAgentMapper.updateById(agent);
        }
    }
}
