package com.crc.sync.cmdb;

import com.alibaba.fastjson.JSONObject;
import com.baomidou.mybatisplus.core.conditions.query.LambdaQueryWrapper;
import com.crc.common.constants.LogConstants;
import com.crc.common.enums.TerminalSourceEnums;
import com.crc.common.utils.JsonUtils;
import com.crc.common.utils.MyTheadUtils;
import com.crc.secface.config.ElasticsearchProperties;
import com.crc.secface.config.GetSpringBean;
import com.crc.secface.db.EsSingleFactory;
import com.crc.secface.domain.AssetTerminalEquipment;
import com.crc.secface.mapper.AssetTerminalEquipmentMapper;
import com.crc.sync.config.SyncSecConfigLoad;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.elasticsearch.action.search.SearchRequest;
import org.elasticsearch.action.search.SearchResponse;
import org.elasticsearch.client.RequestOptions;
import org.elasticsearch.client.RestHighLevelClient;
import org.elasticsearch.index.query.BoolQueryBuilder;
import org.elasticsearch.index.query.QueryBuilders;
import org.elasticsearch.search.SearchHit;
import org.elasticsearch.search.SearchHits;
import org.elasticsearch.search.builder.SearchSourceBuilder;
import org.elasticsearch.search.sort.FieldSortBuilder;
import org.elasticsearch.search.sort.SortOrder;

import java.util.Date;

@Slf4j
public class TerminalSyncToDb extends Thread {
    @Override
    public void run() {
        while (true) {
            MyTheadUtils.sleepBySec(30);
            try {
                if (SyncSecConfigLoad.isEnable("ues_terminal_sync")) {
                    sync();
                }
            } catch (Exception e) {
                log.error(e.getMessage(), e);
            }
            MyTheadUtils.sleepBySec(60);
        }

    }

    public void sync() {
        SearchSourceBuilder sourceBuilder = new SearchSourceBuilder();
        sourceBuilder.size(2000);
        sourceBuilder.sort(new FieldSortBuilder(LogConstants.LOG_TIME).order(SortOrder.DESC));
        ElasticsearchProperties esProperty = GetSpringBean.getBean(ElasticsearchProperties.class);
        AssetTerminalEquipmentMapper equipmentMapper = GetSpringBean.getBean(AssetTerminalEquipmentMapper.class);
        RestHighLevelClient restHighLevelClient = null;
        try {
            restHighLevelClient = EsSingleFactory.getInstance().getHighLevelClient(esProperty);
            log.info("ElasticsearchProperties " + esProperty.toString());
            BoolQueryBuilder boolBuilder = QueryBuilders.boolQuery();
            boolBuilder.must(QueryBuilders.matchPhraseQuery("product.keyword", "慧盾UES"));
            boolBuilder.must(QueryBuilders.wildcardQuery("src_ip", "10.*"));
            boolBuilder.must(QueryBuilders.existsQuery("op_name"));
            boolBuilder.mustNot(QueryBuilders.matchPhraseQuery("op_name", ""));
            boolBuilder.mustNot(QueryBuilders.termQuery("src_ip", "10.0.150.166"));
            sourceBuilder.query(boolBuilder);
            SearchRequest searchRequest = new SearchRequest("sec_all-ues-*");
            searchRequest.source(sourceBuilder);
            SearchResponse response = restHighLevelClient.search(searchRequest, RequestOptions.DEFAULT);
            SearchHits sh = response.getHits();
            log.info("发现终端{}", sh.getHits().length);
            for (SearchHit s : sh) {
                JSONObject client = JsonUtils.parse(s.getSourceAsString());
                String ip = null;
                if (client != null) {
                    String GroupName = JsonUtils.getStr(client, "GroupName");
                    String User = JsonUtils.getStr(client, "op_name");
                    String Name = JsonUtils.getStr(client, "Name");//hostname
                    String Mac = JsonUtils.getStr(client, "Mac");
                    if (StringUtils.isBlank(Mac)) {
                        Mac = JsonUtils.getStr(client, "mac");
                    }
                    if (StringUtils.isBlank(Mac)) {
                        Mac = JsonUtils.getStr(client, "host_mac");
                    }
                    if (StringUtils.isBlank(Name)) {
                        Name = JsonUtils.getStr(client, "host_name");
                    }
                    if (StringUtils.isBlank(GroupName)) {
                        GroupName = JsonUtils.getStr(client, "org_name");
                    }
                    GroupName = GroupName.replace("全网终端.账号树.华润集团UD.华润集团.", "");
                    StringUtils.isBlank(ip);
                    ip = JsonUtils.getStr(client, "src_ip");
                    if (StringUtils.isBlank(User)) {
                        User = JsonUtils.getStr(client, "User");
                    }
                    String Guid = JsonUtils.getStr(client, "Guid");
                    if (StringUtils.isBlank(Guid)) {
                        Guid = JsonUtils.getStr(client, "id");
                    }
                    if (StringUtils.isBlank(Guid)) {
                        Guid = Mac;
                    }
                    if (StringUtils.isBlank(Guid)) {
                        Guid = ip;
                    }
                    if (StringUtils.isBlank(ip)) {
                        continue;
                    }
                    AssetTerminalEquipment terminal = new AssetTerminalEquipment();
                    terminal.setReportIp(ip);
                    terminal.setIp(ip);
                    terminal.setId(Guid);
                    terminal.setUseBod(User);
                    terminal.setGroupName(GroupName);
                    terminal.setMacAddress(Mac);
                    terminal.setDataSource(TerminalSourceEnums.TENGXUN_CMDB.getCode());
                    terminal.setOrganization(GroupName);
                    terminal.setComputerName(Name);
                    LambdaQueryWrapper<AssetTerminalEquipment> q = new LambdaQueryWrapper<>();
                    q.eq(AssetTerminalEquipment::getId, Guid);
                    q.last(" limit 1");
                    AssetTerminalEquipment tmp = equipmentMapper.selectOne(q);
                    if (tmp != null) {
                        terminal.setId(tmp.getId());
                        terminal.setCreateTime(tmp.getCreateTime());
                        terminal.setUpdateTime(new Date());
                        terminal.setCreateBy(tmp.getCreateBy());
                        terminal.setUpdateBy(tmp.getUpdateBy());
                        equipmentMapper.updateById(terminal);
                    } else {
                        terminal.setCreateTime(new Date());
                        terminal.setUpdateTime(new Date());
                        terminal.setUpdateBy("system");
                        terminal.setCreateBy("system");
                        equipmentMapper.insert(terminal);
                    }
                }
            }
        } catch (Exception e) {
            log.error(e.getMessage(), e);
        } finally {
            EsSingleFactory.getInstance().close(restHighLevelClient);
        }
    }
}

