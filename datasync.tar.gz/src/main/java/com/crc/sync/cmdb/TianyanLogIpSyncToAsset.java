package com.crc.sync.cmdb;

import com.alibaba.fastjson.JSONArray;
import com.alibaba.fastjson.JSONObject;
import com.crc.common.constants.LogConstants;
import com.crc.common.enums.AssetSourceEnums;
import com.crc.common.utils.*;
import com.crc.secface.config.ElasticsearchProperties;
import com.crc.secface.config.GetSpringBean;
import com.crc.secface.domain.Asset;
import com.crc.secface.domain.AssetSegement;
import com.crc.secface.domain.SysDictData;
import com.crc.secface.queue.CrcAssetSyncQueue;
import com.crc.sync.net.NewSegmentLoad;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;

import java.util.HashMap;
import java.util.List;

/**
 * 天眼资产同步
 */
@Slf4j
public class TianyanLogIpSyncToAsset {

    public void sync() {
        try {
            List<SysDictData> dictList = DictUtil.getDict("tianyan_log_ip_data_sync");
            for (SysDictData dictData : dictList) {
                if (StringUtils.isBlank(dictData.getDictValue()) || StringUtils.isBlank(dictData.getRemark())) {
                    continue;
                }
                JSONObject json = JsonUtils.parse(dictData.getRemark());
                if (JsonUtils.isEmpty(json)) {
                    log.error(dictData.getDictLabel() + "配置为空！");
                    continue;
                }
                syncData(dictData.getDictLabel(), json, dictData.getDictValue());
            }
        } catch (Exception e) {
            log.error(e.getMessage(),e);
        }
    }

    private void syncData(String label, JSONObject json, String esIndex) {
        try {
            String[] queryTimes = DateUtils.getminuHourTimeRange(-1);
            String dsl = json.toJSONString().replace("#START_TIME#", queryTimes[0]).replace("#END_TIME#", queryTimes[1]);
            //log.info(dsl);
            try {
                ElasticsearchProperties esConfig = GetSpringBean.getBean(ElasticsearchProperties.class);
                String ret = HttpUtils.sendEsGet(esConfig, esIndex, dsl);
                JSONObject retJson = JsonUtils.parse(ret);
                JSONObject hitsTop = retJson.getJSONObject("hits");
                if (hitsTop == null) {
                    return;
                }
                JSONArray hits = hitsTop.getJSONArray("hits");
                if (hits == null) {
                    return;
                }
                HashMap<String, JSONObject> hashMap = new HashMap<>();
                for (int idx = 0; idx < hits.size(); idx++) {
                    JSONObject logJson = hits.getJSONObject(idx).getJSONObject("_source");
                    String ip = JsonUtils.getStr(logJson, LogConstants.SRC_IP);
                    hashMap.put(ip, logJson);
                    ip = JsonUtils.getStr(logJson, LogConstants.DEST_IP);
                    hashMap.put(ip, logJson);
                    ip = JsonUtils.getStr(logJson, LogConstants.LOG_DEV_IP);
                    hashMap.put(ip, logJson);
                }
                log.info(label + "发现天眼资产IP数据：" + hashMap.size());
                hashMap.forEach(this::saveIpAsset);
            } catch (Exception e) {
                log.error(e.getMessage(), e);
            }
        } catch (Exception e) {
            log.error(e.getMessage(), e);
        }
    }

    void saveIpAsset(String ip,JSONObject logJson){
        try {
            if (IpUtils.isIp(ip)) {
                AssetSegement rdata = NewSegmentLoad.getIPSegmentByHalf(ip);
                if (rdata != null) {
                    Asset asset = new Asset();
                    asset.setInternalIp(ip);
                    asset.setSource(AssetSourceEnums.TIANYAN_CMDB.getCode());
                    asset.setMacAddress(JsonUtils.getStr(logJson, "mac"));
                    asset.setHostName(JsonUtils.getStr(logJson, "hostname"));
                    CrcAssetSyncQueue.getInstance().saveAsset(asset,false);
                }
            }
        } catch (Exception e) {
            log.error(e.getMessage(),e);
        }
    }
}
