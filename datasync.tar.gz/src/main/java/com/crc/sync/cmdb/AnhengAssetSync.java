package com.crc.sync.cmdb;

import com.alibaba.fastjson.JSONArray;
import com.alibaba.fastjson.JSONObject;
import com.crc.common.enums.AssetSourceEnums;
import com.crc.common.enums.ScannerEnums;
import com.crc.common.utils.DataUtils;
import com.crc.common.utils.HttpUtils;
import com.crc.common.utils.IpUtils;
import com.crc.common.utils.JsonUtils;
import com.crc.scanner.config.AnhengConfig;
import com.crc.scanner.tool.AnHengUtils;
import com.crc.secface.domain.Asset;
import com.crc.secface.queue.CrcAssetSyncQueue;
import com.crc.secface.schedule.assemble.CommonAssemble;
import com.crc.secface.schedule.assemble.host.AnhengAssemble;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;

import java.util.List;

@Slf4j
public class AnhengAssetSync {
    public void sync() {
        try {
            CommonAssemble.engineMap.forEach((k, v) -> {
                if (ScannerEnums.ANHENG_SCANNER.getCode().equals(v.getEquipmentManufacture())) {
                    sync(AnhengAssemble.getAnhengConfig(k));
                    syncV2(AnhengAssemble.getAnhengConfig(k));
                }
            });
        } catch (Exception e) {
            log.error(e.getMessage(), e);
        }
    }

    private void sync(AnhengConfig scannerInfo) {
        try {
            String url = scannerInfo.getAddress() + "/api/normal/asset/get";
            String param = String.format("module=%d&offset=0&limit=1", AnHengUtils.MODULE_HOST);
            JSONObject header = new JSONObject();
            if (StringUtils.isBlank(scannerInfo.getToken())) {
                AnHengUtils.login(scannerInfo);
            }
            header.put("Authorization", scannerInfo.getToken());

            String ret = HttpUtils.sendGet(url, param, header);
        /*
        {
          "code": 200,
          "msg": "操作成功",
          "subMsg": "",
          "data": {
            "policies": [],
            "count": 3
          }
        }
         */
            JSONObject dataRet = JsonUtils.parse(ret);
            JSONObject dataJson = dataRet.getJSONObject("data");
            int total = JsonUtils.getInt(dataJson, "count");
            log.info(AnHengUtils.MODULE_HOST + ",资产总数：" + total);
            if (total > 0) {
                for (int idx = 0; idx < DataUtils.getPageCount(total, 100, 0); idx++) {
                    try {
                        param = String.format("module=%d&offset=%d&limit=100", AnHengUtils.MODULE_HOST, idx);
                        ret = HttpUtils.sendGet(url, param, header);
                        dataRet = JsonUtils.parse(ret);
                        dataJson = dataRet.getJSONObject("data");
                        if (dataJson != null) {
                            JSONArray policies = dataJson.getJSONArray("assets");
                            if (policies != null) {
                                for (int i = 0; i < policies.size(); i++) {
                                    JSONObject p = policies.getJSONObject(i);
                                    String ipaddr = JsonUtils.getStr(p, "ipaddr");
                                    if (IpUtils.isIp(ipaddr)) {
                                        Asset asset = new Asset();
                                        asset.setInternalIp(ipaddr);
                                        asset.setInstance(JsonUtils.getStr(p, "name"));
                                        asset.setSource(AssetSourceEnums.ANHENG_CMDB.getCode());
                                        CrcAssetSyncQueue.getInstance().saveAsset(asset, false);
                                    } else {
                                        List<String> ips = IpUtils.getIps(ipaddr);
                                        for (String ip : ips) {
                                            Asset asset = new Asset();
                                            asset.setInternalIp(ip);
                                            asset.setInstance(JsonUtils.getStr(p, "name"));
                                            asset.setSource(AssetSourceEnums.ANHENG_CMDB.getCode());
                                            CrcAssetSyncQueue.getInstance().saveAsset(asset, false);
                                        }
                                    }

                                }
                            }
                        }
                    } catch (Exception e) {
                        log.error(e.getMessage(), e);
                    }
                }
            }
        } catch (Exception e) {
            log.error(e.getMessage(), e);
        }
    }

    private void syncV2(AnhengConfig scannerInfo) {
        try {
            String url = scannerInfo.getAddress() + "/api/v2/normal/asset/get";
            String param = String.format("module=%d&offset=0&limit=1", AnHengUtils.MODULE_HOST);
            JSONObject header = new JSONObject();
            if (StringUtils.isBlank(scannerInfo.getToken())) {
                AnHengUtils.login(scannerInfo);
            }
            header.put("Authorization", scannerInfo.getToken());

            String ret = HttpUtils.sendGet(url, param, header);
        /*
        {
          "code": 200,
          "msg": "操作成功",
          "subMsg": "",
          "data": {
            "policies": [],
            "count": 3
          }
        }
         */
            JSONObject dataRet = JsonUtils.parse(ret);
            JSONObject dataJson = dataRet.getJSONObject("data");
            int total = JsonUtils.getInt(dataJson, "count");
            log.info(AnHengUtils.MODULE_HOST + ",资产总数V2：" + total);
            if (total > 0) {
                for (int idx = 0; idx < DataUtils.getPageCount(total, 100, 0); idx++) {
                    try {
                        param = String.format("module=%d&offset=%d&limit=100", AnHengUtils.MODULE_HOST, idx);
                        ret = HttpUtils.sendGet(url, param, header);
                        dataRet = JsonUtils.parse(ret);
                        dataJson = dataRet.getJSONObject("data");
                        if (dataJson != null) {
                            JSONArray policies = dataJson.getJSONArray("assets");
                            if (policies != null) {
                                for (int i = 0; i < policies.size(); i++) {
                                    JSONObject p = policies.getJSONObject(i);
                                    String ipaddr = JsonUtils.getStr(p, "ipaddr");
                                    if (IpUtils.isIp(ipaddr)) {
                                        Asset asset = new Asset();
                                        asset.setInternalIp(ipaddr);
                                        asset.setInstance(JsonUtils.getStr(p, "name"));
                                        asset.setSource(AssetSourceEnums.ANHENG_CMDB.getCode());
                                        CrcAssetSyncQueue.getInstance().saveAsset(asset, false);
                                    } else {
                                        List<String> ips = IpUtils.getIps(ipaddr);
                                        for (String ip : ips) {
                                            Asset asset = new Asset();
                                            asset.setInternalIp(ip);
                                            asset.setInstance(JsonUtils.getStr(p, "name"));
                                            asset.setSource(AssetSourceEnums.ANHENG_CMDB.getCode());
                                            CrcAssetSyncQueue.getInstance().saveAsset(asset, false);
                                        }
                                    }
                                }
                            }
                        }
                    } catch (Exception e) {
                        log.error(e.getMessage(), e);
                    }
                }
            }
        } catch (Exception e) {
            log.error(e.getMessage(), e);
        }
    }
}
