package com.crc.sync.cmdb;

import com.crc.common.enums.DatabaseEnums;
import com.crc.common.utils.VersionUtils;
import com.crc.secface.config.GetSpringBean;
import com.crc.secface.mapper.CommonMapper;
import com.crc.secface.schedule.assemble.host.GobyAssemble;
import com.crc.sync.changting.ChangtingHostAssetSync;
import com.crc.sync.config.SyncSecConfigLoad;
import com.crc.sync.config.SyncSecConstants;
import com.crc.sync.d01.D01AssetSync;
import com.crc.sync.d01.DccAssetSync;
import com.crc.sync.qingteng.QingtengAssetSync;
import lombok.extern.slf4j.Slf4j;

@Slf4j
public class CmdbCenter {
    public static boolean IS_DEPT_RUN = false;
    public static void sync() {
        if (SyncSecConfigLoad.isEnable(SyncSecConstants.QT_ASSET_SYNC_ENABLE)) {
            try {
                log.info("青藤资产同步");
                QingtengAssetSync tcmdb = new QingtengAssetSync();
                tcmdb.sync();
            } catch (Exception e) {
                log.error(e.getMessage(), e);
            }
        }

        if (SyncSecConfigLoad.isEnable(SyncSecConstants.BETA_ASSET_SYNC_ENABLE)) {
            try {
                log.info("北塔资产同步");
                BetaCmdbSync sync = new BetaCmdbSync();
                sync.sync();
            } catch (Exception e) {
                log.error(e.getMessage(), e);
            }
        }

        if (SyncSecConfigLoad.isEnable(SyncSecConstants.DCC_ASSET_SYNC_ENABLE)) {
            try {
                log.info("DCC资产同步");
                DccAssetSync tcmdb = new DccAssetSync();
                tcmdb.sync();
            } catch (Exception e) {
                log.error(e.getMessage(), e);
            }
        }

        if (SyncSecConfigLoad.isEnable(SyncSecConstants.GOBY_SYNC_ENABLE)) {
            log.info("parseTask定时同步Goby任务");
            try {
                GobyAssemble.parseTask();
            } catch (Exception e) {
                log.error(e.getMessage(), e);
            }
            log.info("parseTask定时同步Goby任务完成");
        }


        if (SyncSecConfigLoad.isEnable(SyncSecConstants.D01_ASSET_SYNC_ENABLE)) {
            try {
                log.info("D01资产同步");
                D01AssetSync tcmdb = new D01AssetSync();
                tcmdb.sync();
            } catch (Exception e) {
                log.error(e.getMessage(), e);
            }
        }

        if (SyncSecConfigLoad.isEnable(SyncSecConstants.SAFEDOG_ASSET_SYNC_ENABLE)) {
            try {
                log.info("安全狗资产同步");
                SafedogCmdbSync tcmdb = new SafedogCmdbSync();
                tcmdb.sync();
            } catch (Exception e) {
                log.error(e.getMessage(), e);
            }
        }


        if (SyncSecConfigLoad.isEnable(SyncSecConstants.CHANGTING_ASSET_SYNC_ENABLE)) {
            try {
                log.info("长亭资产同步");
                ChangtingHostAssetSync tcmdb = new ChangtingHostAssetSync();
                tcmdb.sync();
            } catch (Exception e) {
                log.error(e.getMessage(), e);
            }
        }

        if (SyncSecConfigLoad.isEnable(SyncSecConstants.AN_HENG_ASSET_SYNC_ENABLE)) {
            try {
                log.info("安恒资产同步");
                AnhengAssetSync tcmdb = new AnhengAssetSync();
                tcmdb.sync();
            } catch (Exception e) {
                log.error(e.getMessage(), e);
            }
        }
        anlyDept();
    }

    public static void anlyDept() {
        if (IS_DEPT_RUN) {
            log.info("正在执行");
            return;
        }
        log.info("重刷资产路径@@");
        IS_DEPT_RUN = true;
        try {
            CommonMapper commonMapper = GetSpringBean.getBean(CommonMapper.class);

            try {
                commonMapper.exeSQL("UPDATE \n" +
                        "  tb_asset \n" +
                        "SET\n" +
                        "  affiliation_dept_node_id = NULL \n" +
                        "WHERE del_flag = '0' \n" +
                        "  AND NOT EXISTS \n" +
                        "  (SELECT \n" +
                        "    1 \n" +
                        "  FROM\n" +
                        "    sys_dept sd \n" +
                        "  WHERE sd.del_flag = '0' \n" +
                        "    AND sd.dept_id = tb_asset.affiliation_dept_node_id)");
            } catch (Exception e) {
                log.error(e.getMessage(), e);
            }

            try {
                commonMapper.exeSQL("update  tb_asset set dept_path=(select concat(',',ancestors,',',dept_id,',') from sys_dept where dept_id=affiliation_dept_node_id)");
            } catch (Exception e) {
                log.error(e.getMessage(), e);
            }
            try {
                commonMapper.exeSQL("update  tb_asset set dept_path=',0,100,99,' where dept_path is null");
                commonMapper.exeSQL("UPDATE  tb_asset SET dept_path=',0,100,99,' WHERE affiliation_dept_node_id = ''");
            } catch (Exception e) {
                log.error(e.getMessage(), e);
            }
            try {
                commonMapper.exeSQL("update  tb_asset set area_path=(select concat(',',ancestors,',',custom_uuid,',') from tb_asset_area where custom_uuid=area_custom_uuid)");
            } catch (Exception e) {
                log.error(e.getMessage(), e);
            }
            try {
                commonMapper.exeSQL("update  tb_asset set area_path=',0,96,' where area_path is null");
            } catch (Exception e) {
                log.error(e.getMessage(), e);
            }

            if (VersionUtils.getDatabase() == DatabaseEnums.MYSQL.getCode()) {
                try {
                    commonMapper.exeSQL("delete c1  FROM tb_asset_person c1\n" +
                            "INNER JOIN tb_asset_person c2 \n" +
                            "WHERE\n" +
                            "    c1.id < c2.id AND \n" +
                            "    c1.user_name = c2.user_name and c1.asset_id = c2.asset_id and c1.type = c2.type");
                } catch (Exception e) {

                }
            }
        } catch (Exception e) {
            log.error(e.getMessage(), e);
        }
        IS_DEPT_RUN = false;
    }
}
