package com.crc.sync.cmdb.f5;

import com.alibaba.fastjson.JSONObject;
import com.baomidou.mybatisplus.core.toolkit.StringUtils;
import com.crc.common.code.SimpleCodeTool;
import com.crc.common.utils.DataUtils;
import com.crc.common.utils.IpUtils;
import com.crc.common.utils.JsonUtils;
import com.crc.common.utils.Md5Utils;
import com.crc.secface.argo.RuleArgo;
import com.crc.secface.domain.*;
import com.crc.secface.domain.vo.RuleVo;
import com.google.common.collect.Lists;
import lombok.extern.slf4j.Slf4j;

import java.util.List;

@Slf4j
public class F5DataSync {

    public static F5Data508 parse508(String str) {
        /*
         * {
         * 			"OBJ": "10.2.10.163%1:11347",
         * 			"ADDRESS": "10.2.10.163%1",
         * 			"STATE": "up",
         * 			"POOL": "/VLB_4570412875/pool_tdsql",
         * 			"ID": 176,
         * 			"FULLPATH": "/VLB_4570412875/10.2.10.163%1:11347",
         * 			"SID": "f5-ncyo-kyli",
         * 			"NAME": "10.2.10.163%1:11347"
         * }
         */
        try {
            JSONObject jsonObject = JsonUtils.parse(str);
            F5Data508 vo = new F5Data508();
            vo.setIp(JsonUtils.getStr(jsonObject, "ADDRESS").split("%")[0]);
            //if (StringUtils.isBlank(vo.getIp())) {
            //    return null;
            //}
            String[] arr = JsonUtils.getStr(jsonObject, "NAME").split(":");
            if (arr.length > 1) {
                int port = DataUtils.toInt(arr[arr.length - 1]);
                vo.setPort(String.valueOf(port));
            }
            if (IpUtils.isIpv6(vo.getIp())) {
                arr = JsonUtils.getStr(jsonObject, "NAME").split("\\.");
                if (arr.length > 1) {
                    int port = DataUtils.toInt(arr[arr.length - 1]);
                    vo.setPort(String.valueOf(port));
                }
            }
            vo.setApiType(JsonUtils.getStr(jsonObject, "API_TYPE"));
            vo.setPriority(JsonUtils.getStr(jsonObject, "PRIORITYGROUP"));
            vo.setPool(JsonUtils.getStr(jsonObject, "POOL"));
            vo.setObj(JsonUtils.getStr(jsonObject, "OBJ"));
            vo.setSid(JsonUtils.getStr(jsonObject, "SID"));
            vo.setName(JsonUtils.getStr(jsonObject, "NAME"));
            vo.setDataId(JsonUtils.getInt(jsonObject, "ID"));
            vo.setFlag(0);
            return vo;
        } catch (Exception e) {
            log.error(e.getMessage(), e);
        }
        return null;
    }

    public static List<F5Data506> parse506(String str) {
        /*
         * {
         * 			"API_ANONYMOUS": "d2hlbiBIVFRQX1JFUVVFU1QgeyBpZiB7KFtIVFRQOjpjb29raWUgbmFtZV0gY29udGFpbnMgIkJJR2lwU2VydmVyIil9eyBwZXJzaXN0IGNvb2tpZSB9ZWxzZSB7IHBlcnNpc3Qgc291cmNlX2FkZHIgfSB9",
         * 			"OBJ": "SDN_rule",
         * 			"PARTITION_": "VLB_7432480211",
         * 			"FULLPATH": "/VLB_7432480211/SDN_rule",
         * 			"SID": "f5-ncyo-kyli",
         * 			"NAME": "SDN_rule"
         *                }
         */
        try {
            JSONObject jsonObject = JsonUtils.parse(str);

            String sid = JsonUtils.getStr(jsonObject, "SID");
            String name = JsonUtils.getStr(jsonObject, "NAME");
            String newStr = SimpleCodeTool.decryptBase64(JsonUtils.getStr(jsonObject, "API_ANONYMOUS"));
            List<RuleVo> ruleList = RuleArgo.getRuleList(newStr);
            if (ruleList.size() < 1)
                return null;

            List<F5Data506> dataList = Lists.newArrayList();
            for (RuleVo vo : ruleList) {
                F5Data506 f5Data506 = new F5Data506();
                f5Data506.setSid(sid);
                f5Data506.setName(name);
                f5Data506.setPath(vo.getPath());
                f5Data506.setDomain(vo.getDomain());
                f5Data506.setVirtualData(vo.getVirtual());
                f5Data506.setRuleMd5(Md5Utils.hash(vo.getPath(), vo.getVirtual(), vo.getDomain()));
                f5Data506.setFlag(0);
                dataList.add(f5Data506);
            }

            return dataList;
        } catch (Exception e) {
            log.error(e.getMessage(), e);
        }
        return null;
    }

    public static F5Data502 parse502(String str) {
        /*
         * LTM {
         * 			"PORT": "11345",
         * 			"OBJ": "96633",
         * 			"PARTITION_": "VLB_4570412875",
         * 			"IP": "10.2.13.31%1",
         * 			"POOL": "/VLB_4570412875/pool_tdsql",
         * 			"ID": 92,
         * 			"FULLPATH": "/VLB_4570412875/vs_tdsql",
         * 			"SID": "f5-ncyo-kyli",
         * 			"NAME": "vs_tdsql"
         *                }
         *
         */
        try {
            JSONObject jsonObject = JsonUtils.parse(str);
            F5Data502 vo = new F5Data502();
            vo.setIp(JsonUtils.getStr(jsonObject, "IP").split("%")[0]);
            if (StringUtils.isBlank(vo.getIp())) {
                return null;
            }
            vo.setPool(JsonUtils.getStr(jsonObject, "POOL"));
            vo.setPort(JsonUtils.getStr(jsonObject, "PORT"));
            vo.setSid(JsonUtils.getStr(jsonObject, "SID"));
            vo.setName(JsonUtils.getStr(jsonObject, "NAME"));
            vo.setDataId(JsonUtils.getInt(jsonObject, "ID"));
            vo.setFlag(0);
            return vo;
        } catch (Exception e) {
            log.error(e.getMessage(), e);
        }
        return null;
    }

    public static F5DataGtm parseGtm(String str) {
        /*
         * GTM {
            "DEVICE_NAME": "dns.ccic-net.com.cn",
            "DC_PARTITION": "Common",
            "WideIp": "gdmeeting-video2.ccic-net.com.cn",
            "TYPE": "A",
            "DATA_CENTER": "dc-bg",
            "Pool": "pool_gdmeeting-video2.ccic-net.com.cn",
            "SERVER": "vs_117.184.207.74_bgyd",
            "SV_NAME": "117_184_207_74",
            "Member": "vs_117.184.207.74_bgyd:117_184_207_74",
            "SV_PARTITION": "Common",
            "TTL": "3600",
            "RDATA": "117.184.207.74"
        }
         */
        try {
            JSONObject jsonObject = JsonUtils.parse(str);
            F5DataGtm vo = new F5DataGtm();
            String type = JsonUtils.getStr(jsonObject, "TYPE");
            String wideIp = JsonUtils.getStr(jsonObject, "WideIp");
            if(wideIp!=null && wideIp.length()>0 && wideIp.endsWith("."))
            {
                wideIp = wideIp.substring(0, wideIp.length()-1);
            }
            vo.setType(type);
            vo.setWideip(wideIp);
            vo.setRdata(JsonUtils.getStr(jsonObject, "RDATA"));
            if (StringUtils.isBlank(vo.getRdata()) || StringUtils.isBlank(vo.getWideip())) {
                return null;
            }
            if(type!=null && (type.equalsIgnoreCase("A") || type.equalsIgnoreCase("AAAA")))
            {
                return vo;
            }
        } catch (Exception e) {
            log.error(e.getMessage(), e);
        }
        return null;
    }

    public static F5Data509 parse509(String str) {
        try {
            JSONObject jsonObject = JsonUtils.parse(str);
            F5Data509 vo = new F5Data509();
            int id = JsonUtils.getInt(jsonObject, "ID");
            String vsuid = JsonUtils.getStr(jsonObject, "VS_UID");
            String ruleuid = JsonUtils.getStr(jsonObject, "RULE_UID");
            vo.setId(id);
            vo.setRuleuid(ruleuid);
            vo.setVsuid(vsuid);
            return vo;
        } catch (Exception e) {
            log.error(e.getMessage(), e);
        }
        return null;
    }

    public static F5Data511 parse511(String str) {
        try {
            JSONObject jsonObject = JsonUtils.parse(str);
            F5Data511 vo = new F5Data511();
            vo.setSid(JsonUtils.getStr(jsonObject, "SID"));

            String domain = JsonUtils.getStr(jsonObject, "NAME");
            if (domain.endsWith(".")) {
                domain = domain.substring(0, domain.length() - 1);
            } else if (domain.endsWith(".~")) {
                domain = domain.substring(0, domain.length() - 2);
            }
            vo.setType(JsonUtils.getStr(jsonObject, "TYPE"));
            vo.setName(domain);
            vo.setPoolNames(JsonUtils.getStr(jsonObject, "POOLS_NAMES").split(",")[0]);
            vo.setIp(JsonUtils.getStr(jsonObject, "RDATA"));
            vo.setPartitionName(JsonUtils.getStr(jsonObject, "PARTITION_"));
            vo.setDataId(JsonUtils.getInt(jsonObject, "ID"));
            vo.setFlag(0);
            return vo;
        } catch (Exception e) {
            log.error(e.getMessage(), e);
        }
        return null;
    }

    public static F5Data513 parse513(String str) {
        try {
            JSONObject jsonObject = JsonUtils.parse(str);
            F5Data513 vo = new F5Data513();
            vo.setSid(JsonUtils.getStr(jsonObject, "SID"));

            String domain = JsonUtils.getStr(jsonObject, "NAME");
            vo.setVServerName(JsonUtils.getStr(jsonObject, "VSERVER_NAMES"));
            vo.setName(domain);
            vo.setProduct(JsonUtils.getStr(jsonObject, "PRODUCT"));
            vo.setAddress(JsonUtils.getStr(jsonObject, "ADDRESS"));
            vo.setPartitionName(JsonUtils.getStr(jsonObject, "PARTITION_"));
            vo.setDataId(JsonUtils.getInt(jsonObject, "ID"));
            vo.setFullPath(JsonUtils.getStr(jsonObject, "FULLPATH"));
            vo.setFlag(0);
            return vo;
        } catch (Exception e) {
            log.error(e.getMessage(), e);
        }
        return null;
    }
}
