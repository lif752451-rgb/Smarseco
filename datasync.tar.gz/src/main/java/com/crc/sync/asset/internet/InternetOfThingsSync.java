package com.crc.sync.asset.internet;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONArray;
import com.alibaba.fastjson.JSONObject;
import com.baomidou.mybatisplus.core.conditions.query.LambdaQueryWrapper;
import com.baomidou.mybatisplus.core.conditions.update.LambdaUpdateWrapper;
import com.crc.common.enums.DelFlagEnum;
import com.crc.common.utils.DateUtils;
import com.crc.common.utils.HttpUtils;
import com.crc.common.utils.IdGen;
import com.crc.common.utils.JsonUtils;
import com.crc.secface.config.GetSpringBean;
import com.crc.secface.config.ThreadPoolConfig;
import com.crc.secface.domain.AssetIotEquipment;
import com.crc.secface.domain.SysDictData;
import com.crc.secface.mapper.AssetIotEquipmentMapper;
import com.crc.sync.config.SyncSecConfigLoad;
import com.crc.sync.config.SyncSecConstants;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.collections4.CollectionUtils;
import org.apache.commons.lang3.StringUtils;

import java.util.Date;

/**
 * <p>
 * 物联网资产同步
 * </p>
 *
 * @author yuyuhang5
 * @createDate 2024/9/4 14:28
 * @Description
 */
@Slf4j
public class InternetOfThingsSync {

    private ThreadPoolConfig threadPoolConfig;

    public void sync() {
        log.info("同步物联网中台资产-开始");
        long start = System.currentTimeMillis();
        try {
            threadPoolConfig = GetSpringBean.getBean(ThreadPoolConfig.class);
            // 同步安恒资产系统配置
            SysDictData sysDictData = SyncSecConfigLoad.getConfig(SyncSecConstants.IOT_LOGIN_CONFIG);
            if (StringUtils.isNotBlank(sysDictData.getRemark())) {
                JSONObject config = JsonUtils.parse(sysDictData.getRemark());
                if (JsonUtils.isEmpty(config)) {
                    log.info("同步物联网中台资产-相关配置不存在");
                    return;
                }
                // 根据配置中是否存在全量(isAll)同步来区分入参
                JSONObject param = new JSONObject();
                param.put("pageRow", 1);
                param.put("pageSize", 500);
                if (config.getIntValue("isAll") != 0) {
                    JSONObject condition = new JSONObject();
                    String startDate = DateUtils.getDate(0);
                    String endDate = DateUtils.getDate(1);
                    String value = String.format("[{\"operational\":\">=\",\"value\":\"to_date('%s','yyyy-mm-dd')\",\"isFunction\":\"true\",\"relation\":\"and \"},{\"operational\":\"<\",\"value\":\"to_date('%s','yyyy-mm-dd')\",\"isFunction\":\"true\",\"relation\":\"and\"}]", startDate, endDate);
                    condition.put("condition", JSON.parseArray(value));
                    param.put("UPDATE_TIME", condition);
                }
                proc(config, param);
            } else {
                log.info("同步物联网中台资产-数据字典不存在");
            }
        } catch (Exception e) {
            log.error(e.getMessage(), e);
        }
        log.info("同步物联网中台资产-结束，总耗时：{}", System.currentTimeMillis() - start);
    }

    private void proc(JSONObject config, JSONObject param) {
        try {
            String dataStr = HttpUtils.sendPost(config.getString("listUrl"), param.toJSONString());
            if (StringUtils.isEmpty(dataStr)) {
                log.error("同步物联网中台资产-调用API返回数据为空");
                return;
            }
            JSONObject dataJson = JsonUtils.parse(dataStr);
            if (JsonUtils.isEmpty(dataJson)) {
                log.error("同步物联网中台资产-调用API返回数据格式异常");
                return;
            }
            JSONObject dataResultJson = dataJson.getJSONObject("data");
            if (dataResultJson == null) {
                log.error("同步物联网中台资产-调用API错误:{}", dataJson.toJSONString());
                return;
            }
            JSONArray dataArray = JsonUtils.getJsonArray(dataResultJson, "rows");
            if (CollectionUtils.isEmpty(dataArray)) {
                log.error("同步物联网中台资产-调用API返回数据Data为空");
                return;
            }
            int total = dataResultJson.getIntValue("total");
            int pageNum = param.getIntValue("pageRow");
            int pageSize = param.getIntValue("pageSize");
            if (pageNum == 1) {
                log.info("同步物联网中台资产-调用API返回数据总量为：{}", total);
            }
            // 校验是否需要再次调用同步接口
            int pages = (int) Math.ceil(total / (double) pageSize);
            if (pages > pageNum) {
                param.put("pageRow", ++pageNum);
                threadPoolConfig.threadPoolTaskExecutor().execute(() -> {
                    try {
                        proc(config, param);
                    } catch (Exception e) {
                        log.error("同步物联网中台资产-多线程处理异常", e);
                    }
                });
            }
            saveMysql(dataArray);
        } catch (Exception e) {
            log.error("同步物联网中台资产-调用接口异常", e);
        }
    }

    /**
     * 保存数据
     *
     * @param dataList 返回数据列表
     */
    public void saveMysql(JSONArray dataList) {
        try {
            for (int i = 0; i < dataList.size(); i++) {
                JSONObject jsonData = dataList.getJSONObject(i);
                try {
                    // 设置ip
                    String ip = JsonUtils.getStr(jsonData, "D_IP");
                    if (StringUtils.isEmpty(ip)) {
                        log.error("同步物联网中台资产-空IP!!" + jsonData.toJSONString());
                        return;
                    }
                    // 资产id唯一标识 （设备编号）
                    String id = JsonUtils.getStr(jsonData, "D_ID");
                    // 实例名称
                    String name = JsonUtils.getStr(jsonData, "D_NAME");
                    // 状态(1 运行 2 离线 3 故障)
                    String status = JsonUtils.getStr(jsonData, "D_STATUS");
                    // 组id
                    String groupId = JsonUtils.getStr(jsonData, "D_GROUP_ID");
                    // 组名称
                    String groupName = JsonUtils.getStr(jsonData, "D_GROUP_NAME");
                    // 端口
                    String port = JsonUtils.getStr(jsonData, "D_PORT");
                    // 通道
                    String channel = JsonUtils.getStr(jsonData, "D_CHANNEL");
                    // 类型
                    String type = JsonUtils.getStr(jsonData, "D_TYPE");
                    // 类型
                    String rtuId = JsonUtils.getStr(jsonData, "RTU_ID");
                    // 类型
                    String rtuName = JsonUtils.getStr(jsonData, "RTU_NAME");
                    // 井号
                    String orgGroupName = JsonUtils.getStr(jsonData, "ORG_GROUP_NAME");
                    String orgGroupId = JsonUtils.getStr(jsonData, "ORG_GROUP_ID");
                    // 是否停用 （Y 停用  N 启用）
                    String isEnable = JsonUtils.getStr(jsonData, "UNCONFIRMED");
                    Date dateTime = JsonUtils.getDate(jsonData, "CREATE_TIME");

                    AssetIotEquipmentMapper assetIotEquipmentMapper = GetSpringBean.getBean(AssetIotEquipmentMapper.class);
                    LambdaQueryWrapper<AssetIotEquipment> query = new LambdaQueryWrapper<>();
                    query.eq(AssetIotEquipment::getUniqueCode, id);
                    query.eq(AssetIotEquipment::getDelFlag, String.valueOf(DelFlagEnum.AVAILABLE.getValue()));
                    query.last(" limit 1");
                    assert assetIotEquipmentMapper != null;
                    AssetIotEquipment tmp = assetIotEquipmentMapper.selectOne(query);
                    // 存在走更新逻辑
                    if (tmp == null) {
                        // 不存在走新增逻辑
                        AssetIotEquipment iotEquipment = new AssetIotEquipment();
                        iotEquipment.setId(IdGen.uuid());
                        iotEquipment.setIp(ip);
                        iotEquipment.setUniqueCode(id);
                        iotEquipment.setName(name);
                        iotEquipment.setPort(port);
                        iotEquipment.setChannel(channel);
                        iotEquipment.setStatus(status);
                        iotEquipment.setType(type);
                        iotEquipment.setRtuId(rtuId);
                        iotEquipment.setRtuName(rtuName);
                        iotEquipment.setGroupId(groupId);
                        iotEquipment.setGroupName(groupName);
                        iotEquipment.setOrgGroupId(orgGroupId);
                        iotEquipment.setOrgGroupName(orgGroupName);
                        iotEquipment.setIsEnable(isEnable);
                        iotEquipment.setDataTime(dateTime);
                        iotEquipment.setDelFlag("0");
                        iotEquipment.setCreateBy("system");
                        iotEquipment.setCreateTime(new Date());
                        iotEquipment.setUpdateBy("system");
                        iotEquipment.setUpdateTime(new Date());
                        assetIotEquipmentMapper.insert(iotEquipment);
                    } else {
                        log.info("同步物联网中台资产-updateMysql ip:{},uniqueCode:{}, name:{}", ip, id, name);
                        LambdaUpdateWrapper<AssetIotEquipment> updateWrapper = new LambdaUpdateWrapper<>();
                        updateWrapper.eq(AssetIotEquipment::getId, tmp.getId());
                        updateWrapper.set(AssetIotEquipment::getChannel, channel);
                        updateWrapper.set(AssetIotEquipment::getName, name);
                        updateWrapper.set(AssetIotEquipment::getPort, port);
                        updateWrapper.set(AssetIotEquipment::getIp, ip);
                        updateWrapper.set(AssetIotEquipment::getGroupId, groupId);
                        updateWrapper.set(AssetIotEquipment::getGroupName, groupName);
                        updateWrapper.set(AssetIotEquipment::getOrgGroupId, orgGroupId);
                        updateWrapper.set(AssetIotEquipment::getOrgGroupName, orgGroupName);
                        updateWrapper.set(AssetIotEquipment::getRtuId, rtuId);
                        updateWrapper.set(AssetIotEquipment::getRtuName, rtuName);
                        updateWrapper.set(AssetIotEquipment::getIsEnable, isEnable);
                        updateWrapper.set(AssetIotEquipment::getStatus, status);
                        updateWrapper.set(AssetIotEquipment::getType, type);
                        updateWrapper.set(AssetIotEquipment::getUpdateTime, new Date());
                        assetIotEquipmentMapper.update(null, updateWrapper);
                    }
                } catch (Exception e) {
                    log.error(e.getMessage(), e);
                }
            }
        } catch (Exception e) {
            log.error(e.getMessage(), e);
        }
    }
}
