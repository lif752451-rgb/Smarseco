package com.crc.sync.asset.anheng;

import com.alibaba.fastjson.JSONArray;
import com.alibaba.fastjson.JSONObject;
import com.baomidou.mybatisplus.core.conditions.query.LambdaQueryWrapper;
import com.crc.common.enums.AssetSourceEnums;
import com.crc.common.enums.DelFlagEnum;
import com.crc.common.utils.DictUtil;
import com.crc.common.utils.HttpUtils;
import com.crc.common.utils.IpUtils;
import com.crc.common.utils.JsonUtils;
import com.crc.secface.config.GetSpringBean;
import com.crc.secface.config.ThreadPoolConfig;
import com.crc.secface.domain.Asset;
import com.crc.secface.domain.SysDictData;
import com.crc.secface.mapper.AssetMapper;
import com.crc.secface.queue.CrcAssetSyncQueue;
import com.crc.sync.config.SyncSecConstants;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.collections4.CollectionUtils;
import org.apache.commons.lang3.StringUtils;

import java.util.Date;
import java.util.List;

/**
 * <p>
 * 安恒工控态势感知资产
 * </p>
 *
 * @author yuyuhang5
 * @Date 2024/9/4 14:37
 * @Description AnHengSync
 */
@Slf4j
public class AnHengSync {

    private ThreadPoolConfig threadPoolConfig;

    public void sync() {
        log.info("同步安恒资产-开始");
        long start = System.currentTimeMillis();
        try {
            threadPoolConfig = GetSpringBean.getBean(ThreadPoolConfig.class);
            // 同步安恒资产系统配置
            /*
             * dictType   sync_sec_config
             * dictValue  an_heng_login_config 登录相关配置
             * dictLabel  对应真实来源：AN_HENG_SOURCE_IP_1、AN_HENG_SOURCE_IP_2、AN_HENG_SOURCE_IP_3
             * remark  登录信息
             */
            List<SysDictData> dictDataList = DictUtil.getDictTypeAndValue(SyncSecConstants.SYNC_SEC_CONFIG, SyncSecConstants.AN_HENG_LOGIN_CONFIG);
            if (CollectionUtils.isNotEmpty(dictDataList)) {
                for (SysDictData data : dictDataList) {
                    if (StringUtils.isNotBlank(data.getRemark())) {
                        JSONObject config = JsonUtils.parse(data.getRemark());
                        String param = String.format("$page=%s&$size=%s", 1, 200);
                        proc(config, param, data.getDictLabel());
                    } else {
                        log.info("同步安恒资产-数据字典不存在");
                    }
                }
            }
        } catch (Exception e) {
            log.error(e.getMessage(), e);
        }
        log.info("同步安恒资产-结束，总耗时：{}", System.currentTimeMillis() - start);
    }

    private void proc(JSONObject config, String param, String source) {
        try {
            JSONObject headers = new JSONObject();
            headers.put("apiKey", config.getString("token"));
            String dataStr = HttpUtils.sendGet(config.getString("listUrl"), param, headers);
            if (StringUtils.isEmpty(dataStr)) {
                log.error("同步安恒资产-调用API返回数据为空");
                return;
            }
            JSONObject dataJson = JsonUtils.parse(dataStr);
            if (JsonUtils.isEmpty(dataJson)) {
                log.error("同步安恒资产-调用API返回数据格式异常");
                return;
            }
            JSONArray dataArray = JsonUtils.getJsonArray(dataJson, "data");
            if (CollectionUtils.isEmpty(dataArray)) {
                log.error("同步安恒资产-调用API返回数据Data为空");
                return;
            }
            int total = dataJson.getIntValue("total");
            int pageNum = dataJson.getIntValue("$page");
            int pageSize = dataJson.getIntValue("$size");
            if (pageNum == 1) {
                log.info("同步安恒资产-调用API返回数据总量为：{}", total);
            }
            // 校验是否需要再次调用同步接口
            int pages = (int) Math.ceil(total / (double) pageSize);
            if (pages > pageNum) {
                pageNum++;
                int finalNum = pageNum;
                threadPoolConfig.threadPoolTaskExecutor().execute(() -> {
                    try {
                        proc(config, String.format("$page=%d&$size=%s", finalNum, pageSize), source);
                    } catch (Exception e) {
                        log.error("同步安恒资产-多线程处理异常", e);
                    }
                });
            }
            saveMysql(dataArray, source);
        } catch (Exception e) {
            log.error("同步安恒资产-调用接口异常", e);
        }
    }

    /**
     * 保存数据
     *
     * @param dataList 返回数据列表
     * @param source   真实来源
     */
    public void saveMysql(JSONArray dataList, String source) {
        try {
            for (int i = 0; i < dataList.size(); i++) {
                JSONObject jsonData = dataList.getJSONObject(i);
                try {
                    // 设置ip
                    String ip = null;
                    //资产标识值
                    String identification = JsonUtils.getStr(jsonData, "identification");
                    if (StringUtils.isNotBlank(identification)) {
                        String[] strings = identification.split("、");
                        for (String string : strings) {
                            if (IpUtils.isIp(string)) {
                                ip = string;
                                break;
                            }
                        }
                    }
                    if (StringUtils.isEmpty(ip)) {
                        log.error("同步安恒资产-空IP!!" + jsonData.toJSONString());
                        return;
                    }
                    // 安恒资产id唯一标识
                    String id = JsonUtils.getStr(jsonData, "assetId");
                    // 实例名称
                    String instance = JsonUtils.getStr(jsonData, "assetName");
                    // 资产重要程度 core(核心),common(普通)
                    String assetImportance = JsonUtils.getStr(jsonData, "assetImportance");
                    // 组织架构 ID
                    String orgId = JsonUtils.getStr(jsonData, "orgId");
                    // 组织名称
                    String orgName = JsonUtils.getStr(jsonData, "orgName");
                    // 组织全路径
                    String orgFullPathName = JsonUtils.getStr(jsonData, "orgFullPathName");

                    AssetMapper assetMapper = GetSpringBean.getBean(AssetMapper.class);
                    LambdaQueryWrapper<Asset> query = new LambdaQueryWrapper<>();
                    query.eq(Asset::getUniqueCode, id);
                    query.eq(Asset::getRealSource, source);
                    query.eq(Asset::getDelFlag, String.valueOf(DelFlagEnum.AVAILABLE.getValue()));
                    query.last(" limit 1");
                    Asset tmp = assetMapper.selectOne(query);
                    // 存在走更新逻辑
                    if (tmp == null) {
                        // 不存在走新增逻辑
                        Asset asset = new Asset();
                        asset.setInternalIp(ip);
                        asset.setUniqueCode(id);
                        asset.setInstance(instance);
                        //资产等级,可选项：1核心、2重要、3一般
                        asset.setKeyAsset("core".equalsIgnoreCase(assetImportance) ? 1 : 3);
                        asset.setSource(AssetSourceEnums.ANHENG_CMDB.getCode());
                        asset.setRealSource(source);
                        CrcAssetSyncQueue.getInstance().saveAsset(asset, false);
                    } else {
                        //认领或人工维护的不更新,但被删除了，需要变更资产
                        boolean flag = !"1".equalsIgnoreCase(tmp.getApply()) && StringUtils.isBlank(tmp.getUpdateBy());
                        if (flag) {
                            log.info("同步安恒资产-updateMysql ip:{},uniqueCode:{},instance:{}", ip, id, instance);
                            Asset newAsset = new Asset();
                            newAsset.setId(tmp.getId());
                            newAsset.setInternalIp(ip);
                            newAsset.setInstance(instance);
                            newAsset.setUpdateTime(new Date());
                            newAsset.setSource(AssetSourceEnums.ANHENG_CMDB.getCode());
                            newAsset.setRealSource(source);
                            newAsset.setAffiliationDeptName(orgName);
                            assetMapper.updateAsset(newAsset);
                        }
                    }
                } catch (Exception e) {
                    log.error(e.getMessage(), e);
                }
            }
        } catch (Exception e) {
            log.error(e.getMessage(), e);
        }
    }

}
