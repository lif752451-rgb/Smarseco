package com.crc.sync.asset;

import com.baomidou.mybatisplus.core.conditions.update.LambdaUpdateWrapper;
import com.crc.common.enums.DelFlagEnum;
import com.crc.common.utils.DateUtils;
import com.crc.secface.config.GetSpringBean;
import com.crc.secface.domain.Asset;
import com.crc.secface.domain.SysDictData;
import com.crc.secface.mapper.AssetMapper;
import com.crc.sync.config.SyncSecConfigLoad;
import com.crc.sync.config.SyncSecConstants;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;

import java.util.Arrays;
import java.util.Date;

/**
 * <p>
 * 同步资产删除旧资产
 * </p>
 *
 * @author yuyuhang5
 * @Date 2024/9/10 14:46
 * @Description AssetDelSync
 */
@Slf4j
public class AssetDelSync {

    public void sync() {
        log.info("AssetDelSync-Start");
        long start = System.currentTimeMillis();
        try {
            // 同步资产删除旧资产
            SysDictData sysDictData = SyncSecConfigLoad.getConfig(SyncSecConstants.SYNC_OLD_ASSET_DEL_ENABLE);
            if (StringUtils.isNotBlank(sysDictData.getDictValue())) {
                AssetMapper assetMapper = GetSpringBean.getBean(AssetMapper.class);
                LambdaUpdateWrapper<Asset> updateWrapper = new LambdaUpdateWrapper<>();
                updateWrapper.eq(Asset::getDelFlag, String.valueOf(DelFlagEnum.AVAILABLE.getValue()));
                updateWrapper.in(Asset::getSource, Arrays.asList(sysDictData.getDictValue().split(",")));
                updateWrapper.lt(Asset::getUpdateTime, DateUtils.minusDays(new Date(), 3));
                updateWrapper.set(Asset::getDelFlag, String.valueOf(DelFlagEnum.DISABLE.getValue()));
                updateWrapper.set(Asset::getUpdateTime, new Date());
                assetMapper.update(null, updateWrapper);
            } else {
                log.info("AssetDelSync-数据字典不存在");
            }
        } catch (Exception e) {
            log.error(e.getMessage(), e);
        }
        log.info("AssetDelSync-End，总耗时：{}", System.currentTimeMillis() - start);
    }

}
