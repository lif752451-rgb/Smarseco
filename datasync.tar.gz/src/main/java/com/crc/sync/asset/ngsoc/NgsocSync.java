package com.crc.sync.asset.ngsoc;

import com.alibaba.fastjson.JSONArray;
import com.alibaba.fastjson.JSONObject;
import com.baomidou.mybatisplus.core.conditions.query.LambdaQueryWrapper;
import com.crc.common.enums.AssetSourceEnums;
import com.crc.common.enums.DelFlagEnum;
import com.crc.common.utils.HttpUtils;
import com.crc.common.utils.JsonUtils;
import com.crc.secface.config.GetSpringBean;
import com.crc.secface.config.ThreadPoolConfig;
import com.crc.secface.domain.Asset;
import com.crc.secface.domain.SysDictData;
import com.crc.secface.mapper.AssetMapper;
import com.crc.secface.queue.CrcAssetSyncQueue;
import com.crc.sync.config.SyncSecConfigLoad;
import com.crc.sync.config.SyncSecConstants;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.collections4.CollectionUtils;
import org.apache.commons.lang3.StringUtils;

import java.util.Date;

/**
 * <p>
 *
 * </p>
 *
 * @author yuyuhang5
 * @Date 2024/9/4 14:46
 * @Description NgsocSync
 */
@Slf4j
public class NgsocSync {

    private ThreadPoolConfig threadPoolConfig;

    public void sync() {
        log.info("同步办公网态势感知资产-开始");
        long start = System.currentTimeMillis();
        try {
            threadPoolConfig = GetSpringBean.getBean(ThreadPoolConfig.class);
            // 同步办公网态势感知系统配置
            SysDictData sysDictData = SyncSecConfigLoad.getConfig(SyncSecConstants.NGSOC_LOGIN_CONFIG);
            if (StringUtils.isNotBlank(sysDictData.getRemark())) {
                JSONObject config = JsonUtils.parse(sysDictData.getRemark());
                JSONObject param = new JSONObject();
                param.put("viewId", 1);
                param.put("page", 1);
                param.put("size", 200);
                proc(config, param);
            } else {
                log.info("同步办公网态势感知资产-数据字典不存在");
            }
        } catch (Exception e) {
            log.error(e.getMessage(), e);
        }
        log.info("同步办公网态势感知资产-结束，总耗时：{}", System.currentTimeMillis() - start);
    }

    /**
     * OkHttpClient client = new OkHttpClient().newBuilder()
     * .build();
     * MediaType mediaType = MediaType.parse("application/json");
     * RequestBody body = RequestBody.create(mediaType, "{\"condition\":{\"viewId\":1},\"orderBy\":\"-updateTime\",\"size\":100,\"page\":2,\"viewId\":1}");
     * Request request = new Request.Builder()
     * .url("https://10.207.32.212/api/v1/assets/assets")
     * .method("POST", body)
     * .addHeader("NGSOC-Access-Token", "54a0282970e68c489562a4863c1975008b0ff926e826231a4b7d9896fe482c4a")
     * .addHeader("Content-Type", "application/json")
     * .addHeader("Cookie", "NGSOC-Secret=$2a$10$WzN0Aa8LsdDrvnX333ZLseq37GqdFXgm84hYCYrkLg5zHnjK.xRF6")
     * .build();
     * Response response = client.newCall(request).execute();
     */
    private void proc(JSONObject config, JSONObject param) {
        try {
            JSONObject headers = new JSONObject();
            headers.put("NGSOC-Access-Token", config.getString("token"));
            String dataStr = HttpUtils.sendPost(config.getString("listUrl"), param.toJSONString(), headers);
            if (StringUtils.isEmpty(dataStr)) {
                log.error("同步办公网态势感知资产-调用API返回数据为空");
                return;
            }
            JSONObject dataJson = JsonUtils.parse(dataStr);
            if (JsonUtils.isEmpty(dataJson)) {
                log.error("同步办公网态势感知资产-调用API返回数据格式异常");
                return;
            }
            JSONObject dataResultJson = dataJson.getJSONObject("data");
            if (dataResultJson == null) {
                log.error("同步办公网态势感知资产-调用API错误:{}", dataJson.toJSONString());
                return;
            }
            JSONArray dataArray = JsonUtils.getJsonArray(dataResultJson, "data");
            if (CollectionUtils.isEmpty(dataArray)) {
                log.error("同步办公网态势感知资产-调用API返回数据Data为空");
                return;
            }
            int total = dataResultJson.getIntValue("total");
            int pageNum = dataResultJson.getIntValue("page");
            int pageSize = dataResultJson.getIntValue("size");
            if (pageNum == 1) {
                log.info("同步办公网态势感知资产-调用API返回数据总量为：{}", total);
            }
            // 校验是否需要再次调用同步接口
            int pages = (int) Math.ceil(total / (double) pageSize);
            if (pages > pageNum) {
                pageNum++;
                param.put("page", pageNum);
                threadPoolConfig.threadPoolTaskExecutor().execute(() -> {
                    try {
                        proc(config, param);
                    } catch (Exception e) {
                        log.error("同步办公网态势感知资产-多线程处理异常", e);
                    }
                });
            }
            saveMysql(dataArray);
        } catch (Exception e) {
            log.error("同步办公网态势感知资产-调用接口异常", e);
        }
    }

    /**
     * 保存数据
     *
     * @param dataList 返回数据列表
     */
    public void saveMysql(JSONArray dataList) {
        try {
            for (int i = 0; i < dataList.size(); i++) {
                JSONObject jsonData = dataList.getJSONObject(i);
                try {
                    // 设置ip
                    String ip = JsonUtils.getStr(jsonData, "ip");
                    if (StringUtils.isEmpty(ip)) {
                        log.error("同步办公网态势感知资产-空IP!!" + jsonData.toJSONString());
                        return;
                    }
                    // 资产id唯一标识
                    String id = JsonUtils.getStr(jsonData, "id");
                    // 实例名称
                    String instance = JsonUtils.getStr(jsonData, "assetName");
                    // 操作系统
                    String os = JsonUtils.getStr(jsonData, "os");
                    // MAC地址
                    String mac = JsonUtils.getStr(jsonData, "mac");
                    /*Integer 保密性 = JsonUtils.getInt(jsonData, "confidentiality");
                    Integer 完整性 = JsonUtils.getInt(jsonData, "integrity");
                    Integer 可用性 = JsonUtils.getInt(jsonData, "availability");
                    Integer 资产价值 = JsonUtils.getInt(jsonData, "value");*/
                    // TODO 发现方式
                    String taskType = JsonUtils.getStr(jsonData, "taskType");
                    String dataSources = JsonUtils.getStr(jsonData, "dataSources");
                    Date firstTime = JsonUtils.getDate(jsonData, "firstTime");

                    // 资产重要程度 core(核心),common(普通)
                    String assetImportance = JsonUtils.getStr(jsonData, "assetImportance");
                    // 组织架构 ID
                    String orgId = JsonUtils.getStr(jsonData, "orgId");
                    // 组织名称
                    String orgName = JsonUtils.getStr(jsonData, "orgName");
                    // 组织全路径
                    String orgFullPathName = JsonUtils.getStr(jsonData, "orgFullPathName");

                    AssetMapper assetMapper = GetSpringBean.getBean(AssetMapper.class);
                    LambdaQueryWrapper<Asset> query = new LambdaQueryWrapper<>();
                    query.eq(Asset::getUniqueCode, id);
                    query.eq(Asset::getRealSource, AssetSourceEnums.NGSOC_CMDB.getCode());
                    query.eq(Asset::getDelFlag, String.valueOf(DelFlagEnum.AVAILABLE.getValue()));
                    query.orderByDesc(Asset::getCreateTime);
                    query.last(" limit 1");
                    Asset tmp = assetMapper.selectOne(query);
                    // 存在走更新逻辑
                    if (tmp == null) {
                        // 不存在走新增逻辑
                        Asset asset = new Asset();
                        asset.setInternalIp(ip);
                        asset.setUniqueCode(id);
                        asset.setInstance(instance);
                        //资产等级,可选项：1核心、2重要、3一般
                        asset.setKeyAsset("core".equalsIgnoreCase(assetImportance) ? 1 : 3);
                        asset.setOs(os);
                        asset.setMacAddress(mac);
                        asset.setAffiliationDeptName(orgName);
                        asset.setSource(AssetSourceEnums.NGSOC_CMDB.getCode());
                        asset.setRealSource(AssetSourceEnums.NGSOC_CMDB.getCode());
                        CrcAssetSyncQueue.getInstance().saveAsset(asset, false);
                    } else {
                        if (tmp.getInternalIp().equals(ip)) {
                            //认领或人工维护的不更新,但被删除了，需要变更资产
                            boolean flag = !"1".equalsIgnoreCase(tmp.getApply()) && StringUtils.isBlank(tmp.getUpdateBy());
                            if (flag) {
                                log.info("同步办公网态势感知资产-updateMysql ip:{},uniqueCode:{},instance:{}", ip, id, instance);
                                Asset newAsset = new Asset();
                                newAsset.setId(tmp.getId());
                                newAsset.setInstance(instance);
                                newAsset.setUpdateTime(new Date());
                                newAsset.setOs(os);
                                newAsset.setMacAddress(mac);
                                newAsset.setSource(AssetSourceEnums.NGSOC_CMDB.getCode());
                                newAsset.setRealSource(AssetSourceEnums.NGSOC_CMDB.getCode());
                                newAsset.setAffiliationDeptName(orgName);
                                assetMapper.updateAsset(newAsset);
                            }
                        } else {
                            // IP发生变化走新增逻辑
                            Asset asset = new Asset();
                            asset.setInternalIp(ip);
                            asset.setUniqueCode(id);
                            asset.setInstance(instance);
                            //资产等级,可选项：1核心、2重要、3一般
                            asset.setKeyAsset("core".equalsIgnoreCase(assetImportance) ? 1 : 3);
                            asset.setOs(os);
                            asset.setMacAddress(mac);
                            asset.setAffiliationDeptName(orgName);
                            asset.setSource(AssetSourceEnums.NGSOC_CMDB.getCode());
                            asset.setRealSource(AssetSourceEnums.NGSOC_CMDB.getCode());
                            CrcAssetSyncQueue.getInstance().saveAsset(asset, false);
                            // 删除旧数据
                            Asset newAsset = new Asset();
                            newAsset.setId(tmp.getId());
                            newAsset.setDelFlag(String.valueOf(DelFlagEnum.DISABLE.getValue()));
                            assetMapper.updateAsset(newAsset);
                        }
                    }
                } catch (Exception e) {
                    log.error(e.getMessage(), e);
                }
            }
        } catch (Exception e) {
            log.error(e.getMessage(), e);
        }
    }
}
