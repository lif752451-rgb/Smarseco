package com.crc.sync.ai;

import com.alibaba.fastjson.JSONObject;
import com.crc.common.utils.CronUtils;
import com.crc.common.utils.DateUtils;
import com.crc.common.utils.HttpUtils;
import com.crc.common.utils.JsonUtils;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;

import java.util.Date;


@Slf4j
public class AITrainSync {

    public static void train(JSONObject jsonObject) {
        /*
            {
            "type": "aiTrain",
            "cron": "0 *\\/1 * * * ?",
             "url": "http://10.54.14.155:8080/train",
              "incre_learn": true
            }
            incre_learn为true则增量训练，为false则覆盖原模型重新训练

            {
                "start_time": "2023-02-16 00:00:00",
                "end_time": "2023-02-23 00:00:00",
                "incre_learn": true
            }
         */
        try {

            String url = JsonUtils.getStr(jsonObject, "url");
            JSONObject param = new JSONObject();
            param.put("incre_learn", jsonObject.get("incre_learn"));
            String endTime = DateUtils.getDateTimeString1(new Date());
            String[] startTimes = CronUtils.getLastTriggerTime(JsonUtils.getStr(jsonObject, "cron"));
            if (startTimes != null) {
                if (endTime.equals(startTimes[0])) {
                    param.put("start_time", startTimes[1]);
                } else {
                    param.put("start_time", startTimes[0]);
                }

            }
            param.put("end_time", endTime);

            if (StringUtils.isNotBlank(url)) {
                String ret = HttpUtils.sendPost(url, param.toJSONString());
                log.info("请求={},返回={}", url, ret);
            } else {
                log.error("AI训练配置，不正确；请检查；job_data_sync/aiTrain");
            }
        } catch (Exception e) {
            log.error(e.getMessage(),e);
        }
    }
}
