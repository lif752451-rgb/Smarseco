package com.crc.secface.config;

import lombok.Data;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.context.annotation.Configuration;

/**
 * druid 配置属性
 *
 * @author wst
 */
@Data
@Configuration
@ConfigurationProperties(prefix = "spring.druid")
public class DruidJdbcProperties {
    private String url;

    private String username;

    private String password;

    private String driverClassName;
}
