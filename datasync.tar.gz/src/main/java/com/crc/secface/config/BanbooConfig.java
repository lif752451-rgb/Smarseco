package com.crc.secface.config;


import lombok.Data;

/**
 * {
 *   "username": "teststp",
 *   "password": "admin123",
 *   "appid": "CRDIGITAL_STP",
 *   "authUrl": "https://10.200.198.63"
 * }
 */
@Data
public class BanbooConfig {
    String username;
    String password;
    String appId;
    String authUrl;
}
