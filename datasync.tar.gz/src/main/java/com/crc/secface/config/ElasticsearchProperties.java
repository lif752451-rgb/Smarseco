package com.crc.secface.config;


import com.crc.common.code.CodeTool;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.context.annotation.Configuration;

/**
 * @author simba@onlying.cn
 * @date 2020/7/21 13:36
 */
@Configuration
@ConfigurationProperties(prefix = "es.config")
public class ElasticsearchProperties {
    private String host;
    private int port;
    private String schema;

    private String proxyHeader;
    private String userName;

    private String password;

    private String mode;

    /**
     * 连接超时时间(毫秒)
     */
    private Integer connectTimeout = 10000;

    /**
     * socket 超时时间
     */
    private Integer socketTimeout = 60000;

    /**
     * 连接请求超时时间
     */
    private Integer connectionRequestTimeout = 5000;

    /**
     * 每个路由的最大连接数量
     */
    private Integer maxConnectPerRoute = 10;

    /**
     * 最大连接总数量
     */
    private Integer maxConnectTotal = 50;

    public Integer getConnectTimeout() {
        return connectTimeout;
    }

    public void setConnectTimeout(Integer connectTimeout) {
        this.connectTimeout = connectTimeout;
    }

    public Integer getSocketTimeout() {
        return socketTimeout;
    }

    public void setSocketTimeout(Integer socketTimeout) {
        this.socketTimeout = socketTimeout;
    }

    public Integer getConnectionRequestTimeout() {
        return connectionRequestTimeout;
    }

    public void setConnectionRequestTimeout(Integer connectionRequestTimeout) {
        this.connectionRequestTimeout = connectionRequestTimeout;
    }

    public Integer getMaxConnectPerRoute() {
        return maxConnectPerRoute;
    }

    public void setMaxConnectPerRoute(Integer maxConnectPerRoute) {
        this.maxConnectPerRoute = maxConnectPerRoute;
    }

    public Integer getMaxConnectTotal() {
        return maxConnectTotal;
    }

    public void setMaxConnectTotal(Integer maxConnectTotal) {
        this.maxConnectTotal = maxConnectTotal;
    }

    public String getMode() {
        return mode;
    }

    public void setMode(String mode) {
        this.mode = mode;
    }

    public void setHost(String host) {
        this.host = host;
    }

    public void setPort(int port) {
        this.port = port;
    }

    public void setSchema(String schema) {
        this.schema = schema;
    }

    public void setProxyHeader(String proxyHeader) {
        this.proxyHeader = proxyHeader;
    }

    public void setUserName(String userName) {
        this.userName = userName;
    }

    public void setPassword(String password) {
        this.password = CodeTool.decrypt(password);
    }

    public String getHost() {
        return host;
    }

    public int getPort() {
        return port;
    }

    public String getSchema() {
        return schema;
    }

    public String getProxyHeader() {
        return proxyHeader;
    }

    public String getUserName() {
        return userName;
    }

    public String getPassword() {
        return password;
    }

    public String getBaseUrl() {
        return String.format("%s://%s:%d", getSchema(), getHost(), getPort());
    }


    @Override
    public String toString() {
        return "EsProperty{" +
                "host='" + host + '\'' +
                ", port=" + port +
                ", schema='" + schema + '\'' +
                ", proxyHeader='" + proxyHeader + '\'' +
                ", userName='" + userName + '\'' +
                ", password='"  + '\'' +
                ", mode='" + mode + '\'' +
                ", connectTimeout=" + connectTimeout +
                ", socketTimeout=" + socketTimeout +
                ", connectionRequestTimeout=" + connectionRequestTimeout +
                ", maxConnectPerRoute=" + maxConnectPerRoute +
                ", maxConnectTotal=" + maxConnectTotal +
                '}';
    }
}
