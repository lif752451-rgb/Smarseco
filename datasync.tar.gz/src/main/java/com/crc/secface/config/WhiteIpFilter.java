package com.crc.secface.config;

import com.alibaba.fastjson.JSON;
import com.crc.common.utils.IOUtils;
import com.crc.common.utils.IpUtils;
import com.crc.common.utils.JsonUtils;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.env.Environment;

import javax.servlet.*;
import javax.servlet.FilterConfig;
import javax.servlet.http.HttpServletRequest;
import java.io.IOException;
import java.io.PrintWriter;

/**
 * 访问接口白名单
 */
@Slf4j
public class WhiteIpFilter implements Filter {
    @Autowired
    Environment env;

    @Override
    public void init(FilterConfig filterConfig) throws ServletException {

    }

    @Override
    public void doFilter(ServletRequest request, ServletResponse response, FilterChain chain)
            throws IOException, ServletException {
        HttpServletRequest req = (HttpServletRequest) request;
        String remoteIp = getIpAddr(req);
        log.info("请求:{},ip:{}", req.getRequestURI(), remoteIp);
        if (env == null) {
            env = GetSpringBean.getBean(Environment.class);
        }
        try {
            String whiteIpListStr = env.getProperty("whiteIp.list");
            if (StringUtils.isNotBlank(whiteIpListStr)) {
                String[] ips = whiteIpListStr.split(",");
                boolean goodFilter = false;
                for (String ip : ips) {
                    ip = ip.trim();
                    if (IpUtils.isIp(ip) && ip.equals(remoteIp)) {
                        goodFilter = true;
                        break;
                    }
                }
                if (!goodFilter) {
                    returnJson(response, JSON.toJSONString(JsonUtils.error(999, "非法IP访问接口，请联系系统管理源")));
                    return;
                }
            }
        } catch (Exception ignored) {

        }
        chain.doFilter(request, response);
    }


    @Override
    public void destroy() {

    }

    private void returnJson(ServletResponse response, String json) {
        PrintWriter writer = null;
        response.setCharacterEncoding("UTF-8");
        response.setContentType("application/json; charset=utf-8");
        try {
            writer = response.getWriter();
            writer.print(json);

        } catch (IOException e) {
            log.error("response error", e);
        } finally {
            IOUtils.close(writer);
        }
    }


    public static String getIpAddr(HttpServletRequest request) {
        if (request == null) {
            return "unknown";
        }
        String ip = request.getHeader("x-forwarded-for");
        if (ip == null || ip.length() == 0 || "unknown".equalsIgnoreCase(ip) || "127.0.0.1".equals(ip)) {
            ip = request.getHeader("Proxy-Client-IP");
        }
        if (ip == null || ip.length() == 0 || "unknown".equalsIgnoreCase(ip) || "127.0.0.1".equals(ip)) {
            ip = request.getHeader("X-Forwarded-For");
        }
        if (ip == null || ip.length() == 0 || "unknown".equalsIgnoreCase(ip) || "127.0.0.1".equals(ip)) {
            ip = request.getHeader("WL-Proxy-Client-IP");
        }
        if (ip == null || ip.length() == 0 || "unknown".equalsIgnoreCase(ip) || "127.0.0.1".equals(ip)) {
            ip = request.getHeader("X-Real-IP");
        }
        if (ip == null || ip.length() == 0 || "unknown".equalsIgnoreCase(ip) || "127.0.0.1".equals(ip)) {
            ip = request.getRemoteAddr();
        }

        return "0:0:0:0:0:0:0:1".equals(ip) ? "127.0.0.1" : ip;
    }
}