package com.crc.secface.config;

import lombok.Data;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.context.annotation.Configuration;

/**
 * @author simba@onlying.cn
 * @date 2020/7/21 14:53
 */

@Data
@Configuration
@ConfigurationProperties(prefix = "spring.druid")
public class JdbcConfig {
    private String url;
    private String username;
    private String password;
    private String driverClassName;
}
