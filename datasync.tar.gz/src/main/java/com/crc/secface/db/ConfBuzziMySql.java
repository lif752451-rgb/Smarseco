package com.crc.secface.db;

import cn.hutool.db.DbUtil;
import com.alibaba.fastjson.JSONObject;
import com.crc.SpringbootApplication;
import com.crc.common.code.CodeTool;
import com.crc.common.enums.DatabaseEnums;
import com.crc.common.utils.DataUtils;
import com.crc.common.utils.JsonUtils;
import com.crc.common.utils.MyTheadUtils;
import com.crc.common.utils.VersionUtils;
import com.crc.secface.config.DruidJdbcProperties;
import com.crc.secface.config.GetSpringBean;
import com.crc.secface.domain.vo.DbConfig;
import com.crc.secface.mapper.CommonMapper;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.springframework.core.env.Environment;

import java.sql.*;
import java.util.LinkedList;
import java.util.List;

@Slf4j
public class ConfBuzziMySql {

    public static int getCount(String sql) {
        try {
            CommonMapper commonMapper = GetSpringBean.getBean(CommonMapper.class);
            return commonMapper.getCount(sql);
        } catch (Exception e) {
            log.error(e.getMessage(), e);
        }
        return 0;

    }


    public static void exeSQL(String sql) {
        try {
            CommonMapper commonMapper = GetSpringBean.getBean(CommonMapper.class);
            commonMapper.exeSQL(sql);
        } catch (Exception se) {
            log.error(se.getMessage(), se);
        }
    }


    public static List<JSONObject> query(String sql) {
        try {
            CommonMapper commonMapper = GetSpringBean.getBean(CommonMapper.class);
            return commonMapper.query(sql);
        } catch (Exception se) {
            log.error(se.getMessage(), se);
        }
        return new LinkedList<>();
    }

    public static List<JSONObject> query(DbConfig dbConfig, String sql) {
        List<JSONObject> jsonList = new LinkedList<>();
        Connection conn = null;
        PreparedStatement ps = null;
        ResultSet rs = null;

        try {
            conn = getConnection(dbConfig);
            if (conn == null)
                return jsonList;
            ps = conn.prepareStatement(sql);
            rs = ps.executeQuery();
            while (rs.next()) {
                ResultSetMetaData rsmd = rs.getMetaData();
                JSONObject jsonObject = new JSONObject();
                for (int i = 1; i <= rsmd.getColumnCount(); i++) {
                    String col = rsmd.getColumnLabel(i);
                    jsonObject.put(col, getStr(rs, col));
                }
                jsonList.add(jsonObject);
            }
        } catch (Exception se) {
            log.error(se.getMessage(), se);
        } finally {
            DbUtil.close(rs, ps, conn);
        }
        return jsonList;
    }


    public static String getStr(ResultSet rs, String filter) {
        try {
            return rs.getString(filter);
        } catch (Exception e) {
            return "";
        }
    }

    public static int getInt(ResultSet rs, String filter) {
        try {
            return rs.getInt(filter);
        } catch (Exception e) {
            return 0;
        }
    }

    public static List<JSONObject> getAllTable() {
        List<JSONObject> tbList = new LinkedList<>();
        if (VersionUtils.getDatabase() == DatabaseEnums.MYSQL.getCode()) {
            List<JSONObject> list = query("select database() as dbname");
            if (list == null || list.size() < 1) {
                return tbList;
            }

            String dbname = JsonUtils.getStr(list.get(0), "dbname");
            if (StringUtils.isNotBlank(dbname)) {
                String sql = "SELECT table_name FROM information_schema.tables WHERE table_schema='" + dbname + "'";
                return query(sql);
            }
        }else {
            String sql = "SELECT table_name FROM user_tables";
            return query(sql);
        }
        return tbList;
    }

    public static int existTable(String tableName) {
        try {
            if (VersionUtils.getDatabase() == DatabaseEnums.MYSQL.getCode()) {
                List<JSONObject> list = query("select database() as dbname");
                if (list == null || list.size() < 1) {
                    return -1;
                }

                String dbname = DataUtils.getString(list.get(0), "dbname");
                if (StringUtils.isNotBlank(dbname)) {
                    String sql = "SELECT count(1) FROM information_schema.tables WHERE table_schema='%s' and table_name = '%s'";
                    if (getCount(String.format(sql, dbname, tableName)) > 0) {
                        return 1;
                    } else {
                        return 0;
                    }
                }
            } else {
                String sql = "SELECT count(1)  from user_tables where table_name='%s' ";
                if (getCount(String.format(sql, tableName.toUpperCase())) > 0) {
                    return 1;
                } else {
                    return 0;
                }
            }

        } catch (Exception se) {
            log.error(se.getMessage(), se);
        }
        return -1;
    }

    public static Connection getConnection(DbConfig dbConfig) {
        try {
            // 注册 JDBC 驱动
            Class.forName(dbConfig.getDriverClassName()).newInstance();
            return DriverManager.getConnection(dbConfig.getUrl(), dbConfig.getUsername(), dbConfig.getPassword());
        } catch (Exception e) {
            log.error(e.getMessage(), e);
        }
        return null;
    }

    public static Connection getConnection() {
        try {
            DruidJdbcProperties env = GetSpringBean.getBean(DruidJdbcProperties.class);
            if (env.getUrl() == null) {
                return null;
            }
            DbConfig dbConfig = new DbConfig();
            dbConfig.setDriverClassName(env.getDriverClassName());
            dbConfig.setUrl(env.getUrl());
            dbConfig.setUsername(env.getUsername());
            dbConfig.setPassword(env.getPassword());
            return getConnection(dbConfig);
        } catch (Exception e) {
            log.error(e.getMessage(), e);
        }
        return null;
    }

    public static String getValueBySql(String sql, String filter) {
        try {
            List<JSONObject> list = query(sql);
            if (list == null || list.size() < 1) {
                return "";
            }

            return JsonUtils.getStr(list.get(0), filter);
        } catch (Exception se) {
            log.error(se.getMessage(), se);
        }
        return "";
    }
}

