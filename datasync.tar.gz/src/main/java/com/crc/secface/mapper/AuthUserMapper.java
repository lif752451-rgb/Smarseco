package com.crc.secface.mapper;

import com.crc.secface.domain.AuthUser;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;

import java.util.List;

/**
 * <p>
 * 第三方账号表 Mapper 接口
 * </p>
 *
 * @author hejingsheng1
 * @since 2022-12-28
 */
public interface AuthUserMapper extends BaseMapper<AuthUser> {

    void deleteTbAuthUserByEmpno(String empno);

    void updateAuthUser(AuthUser authUser);

    List<AuthUser> selectTbUserByOffset(AuthUser q);

    AuthUser selectByEmpo(String empno);

    void deleteUser(String empno);
}
