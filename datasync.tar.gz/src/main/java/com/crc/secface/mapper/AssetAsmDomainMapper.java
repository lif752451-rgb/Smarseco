package com.crc.secface.mapper;

import com.crc.secface.domain.AssetAsmDomain;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;

/**
 * <p>
 * 攻击面-域名管理表 Mapper 接口
 * </p>
 *
 * @author hejingsheng1
 * @since 2023-05-16
 */
public interface AssetAsmDomainMapper extends BaseMapper<AssetAsmDomain> {
    void updateAssetAsmDomain(AssetAsmDomain assetAsmDomain);
}
