package com.crc.secface.mapper;

import com.crc.secface.domain.AssetTerminalEquipment;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;

/**
 * <p>
 * 终端资产-终端设备表 Mapper 接口
 * </p>
 *
 * @author hejingsheng1
 * @since 2023-03-27
 */
public interface AssetTerminalEquipmentMapper extends BaseMapper<AssetTerminalEquipment> {

}
