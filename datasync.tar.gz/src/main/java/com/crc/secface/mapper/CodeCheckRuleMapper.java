package com.crc.secface.mapper;

import com.crc.secface.domain.CodeCheckRule;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;

/**
 * <p>
 * 检测规则列表 Mapper 接口
 * </p>
 *
 * @author hejingsheng1
 * @since 2023-01-06
 */
public interface CodeCheckRuleMapper extends BaseMapper<CodeCheckRule> {

}
