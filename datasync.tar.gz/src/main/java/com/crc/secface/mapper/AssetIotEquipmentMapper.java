package com.crc.secface.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.crc.secface.domain.AssetIotEquipment;

/**
 * <p>
 *
 * </p>
 *
 * @author yuyuhang5
 * @Date 2024/9/11 15:51
 * @Description AssetIotEquipmentMapper
 */
public interface AssetIotEquipmentMapper extends BaseMapper<AssetIotEquipment> {
}
