package com.crc.secface.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.crc.secface.domain.VulnScanTaskRecordLog;

import java.util.List;

/**
 * <p>
 * 漏洞扫描任务表记录表 Mapper 接口
 * </p>
 *
 * @author hejingsheng
 * @since 2022-12-05
 */
public interface VulnScanTaskRecordLogMapper extends BaseMapper<VulnScanTaskRecordLog> {
    void updateVulnScanTaskRecordLog(VulnScanTaskRecordLog vulnScanTaskRecordLog);

    void updateVulnScanTaskRecordLogByRecordId(VulnScanTaskRecordLog vulnScanTaskRecordLog);

    void deleteByRecordId(Long recordId);

    List<VulnScanTaskRecordLog> getAllRecordLogList(VulnScanTaskRecordLog q);
}
