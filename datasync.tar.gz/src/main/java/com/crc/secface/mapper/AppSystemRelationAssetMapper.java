package com.crc.secface.mapper;

import com.crc.secface.domain.AppSystemRelationAsset;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;

/**
 * <p>
 * 应用系统关联资产表 Mapper 接口
 * </p>
 *
 * @author hejingsheng1
 * @since 2023-05-16
 */
public interface AppSystemRelationAssetMapper extends BaseMapper<AppSystemRelationAsset> {
    void updateAppSystemRelationAsset(AppSystemRelationAsset appSystemRelationAsset);
}
