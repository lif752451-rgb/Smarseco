package com.crc.secface.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.crc.secface.domain.CodeCheckRecord;

/**
 * <p>
 * 代码检测记录表 Mapper 接口
 * </p>
 *
 * @author hejingsheng1
 * @since 2023-01-05
 */
public interface CodeCheckRecordMapper extends BaseMapper<CodeCheckRecord> {

    CodeCheckRecord getLastRecordByTaskId(String id);

    void updateCodeCheckRecord(CodeCheckRecord record);
}
