package com.crc.secface.mapper;

import com.crc.secface.domain.Asset;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.crc.secface.domain.vo.AssetKeywordsVo;
import com.crc.secface.domain.vo.AssetVo;
import org.apache.ibatis.annotations.Param;

import java.util.List;

/**
 * <p>
 * 资产信息表 Mapper 接口
 * </p>
 *
 * @author hejingsheng1
 * @since 2022-12-06
 */
public interface AssetMapper extends BaseMapper<Asset> {
    Asset selectAssetByInnerIp(@Param("internalIp")String internalIp);

    void updateAsset(Asset asset);

    void updateAssetCode(Asset asset);

    List<Asset> selectTbAssetByOffset(Asset q);

    void deleteByIp(String ip);

    /**
     * 获取资产全文检索的搜索条件数据
     * @return 搜索条件数据
     */
    List<AssetKeywordsVo> getCommonKeywords(@Param("idList") List<Long> idList);
    List<AssetKeywordsVo> getCommonKeywordsOracle(@Param("idList") List<Long> idList);

    void updateAssetScore(AssetVo vo);

    void updateAssetFlag(Long id);
}
