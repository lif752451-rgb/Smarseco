package com.crc.secface.mapper;

import com.crc.secface.domain.VulWhiteList;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;

/**
 * <p>
 * 漏洞白名单 Mapper 接口
 * </p>
 *
 * @author hejingsheng1
 * @since 2022-12-16
 */
public interface VulWhiteListMapper extends BaseMapper<VulWhiteList> {

}
