package com.crc.secface.mapper;

import com.crc.secface.domain.SysEmailConfig;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;

/**
 * <p>
 * 邮件服务器配置表 Mapper 接口
 * </p>
 *
 * @author hejingsheng1
 * @since 2023-11-23
 */
public interface SysEmailConfigMapper extends BaseMapper<SysEmailConfig> {

}
