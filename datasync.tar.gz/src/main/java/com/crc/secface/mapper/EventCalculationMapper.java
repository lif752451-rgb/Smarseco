package com.crc.secface.mapper;

import com.crc.secface.domain.Event;
import com.crc.secface.domain.EventCalculation;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;

import java.util.List;
import java.util.Map;

/**
 * <p>
 * Mapper 接口
 * </p>
 *
 * @author hejingsheng1
 * @since 2022-12-28
 */
public interface EventCalculationMapper extends BaseMapper<EventCalculation> {
    void delOldEvent();

    List<Event> queryAllEvent(String startTime, String endTime, String attackType, String attackResult);

    int getCalculationOne(String id);

    void updateCalculationOne(Map<String, String> map);

    void saveCalculationOne(Map<String, String> map);
}
