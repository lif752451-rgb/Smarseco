package com.crc.secface.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.crc.secface.domain.F5Data509;

/**
 * <p>
 *  Mapper 接口
 * </p>
 *
 * @author hejingsheng1
 * @since 2023-04-28
 */
public interface F5Data509Mapper
        extends BaseMapper<F5Data509> {
    void deleteAll();
}
