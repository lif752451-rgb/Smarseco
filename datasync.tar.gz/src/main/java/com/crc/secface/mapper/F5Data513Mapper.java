package com.crc.secface.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.crc.secface.domain.F5Data513;

/**
 * <p>
 *  Mapper 接口
 * </p>
 *
 * @author wenxiaoming3
 * @since 2023-05-17
 */
public interface F5Data513Mapper extends BaseMapper<F5Data513> {

}
