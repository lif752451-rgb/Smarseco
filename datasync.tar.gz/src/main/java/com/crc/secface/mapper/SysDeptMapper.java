package com.crc.secface.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.crc.secface.domain.SysDept;
import org.apache.ibatis.annotations.Mapper;

/**
 * <p>
 * 部门表 Mapper 接口
 * </p>
 *
 * @author hejingsheng1
 * @since 2022-12-06
 */
@Mapper
public interface SysDeptMapper extends BaseMapper<SysDept> {

    SysDept checkDeptNameUnique(String deptName, Long parentId);
    SysDept selectByDeptId(long deptId);
    void updateSysDept(SysDept dept);

    String getFullDeptNameById(Long affiliationDeptNodeId);

    String getDeptPath(Long affiliationDeptNodeId);
}
