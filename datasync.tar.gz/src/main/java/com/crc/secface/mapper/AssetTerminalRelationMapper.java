package com.crc.secface.mapper;

import com.crc.secface.domain.AssetTerminalRelation;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;

/**
 * <p>
 * 终端资产-终端设备、软件关联表 Mapper 接口
 * </p>
 *
 * @author hejingsheng1
 * @since 2023-03-27
 */
public interface AssetTerminalRelationMapper extends BaseMapper<AssetTerminalRelation> {

}
