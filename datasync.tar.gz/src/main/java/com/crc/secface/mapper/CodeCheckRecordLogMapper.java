package com.crc.secface.mapper;

import com.crc.secface.domain.CodeCheckRecordLog;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;

/**
 * <p>
 * 任务执行记录表 Mapper 接口
 * </p>
 *
 * @author hejingsheng1
 * @since 2023-01-10
 */
public interface CodeCheckRecordLogMapper extends BaseMapper<CodeCheckRecordLog> {

}
