package com.crc.secface.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.crc.secface.domain.CodeCheckTask;

/**
 * <p>
 * 代码检测任务表 Mapper 接口
 * </p>
 *
 * @author hejingsheng1
 * @since 2023-01-05
 */
public interface CodeCheckTaskMapper extends BaseMapper<CodeCheckTask> {
    void updateCodeCheckTask(CodeCheckTask checkTask);
}
