package com.crc.secface.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.crc.secface.domain.AlarmCombatReport;
import com.crc.secface.domain.AssetAlarm;
import com.crc.secface.domain.SegmentAlarm;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;

import java.util.List;

/**
 * @author fuzhuangzhi
 * @title AlarmCombatReportMapper
 * @date 2023/6/27 16:59
 * @description TODO
 */
@Mapper
public interface AlarmCombatReportMapper extends BaseMapper<AlarmCombatReport> {

    /**
     * 分页查询告警
     *
     * @param alarmReport
     * @return
     */
    List<SegmentAlarm> selectAllAlarm(AlarmCombatReport alarmReport);

    /**
     * 分页查询资产关联实战告警数据
     *
     * @param alarmReport 告警参数
     * @return 告警数据
     */
    List<AssetAlarm> selectAssetAllAlarm(AlarmCombatReport alarmReport);

    /**
     * 查询
     *
     * @param alarmReport
     * @return
     */
    Integer selectAssetCount(AlarmCombatReport alarmReport);

    /**
     * 分页查询实战告警列表
     * @param offset 偏移量
     * @param pageSize 页容量
     * @return 实战告警列表
     */
    List<AlarmCombatReport> selectAlarmReportList(@Param("offset") int offset, @Param("pageSize") int pageSize);
}
