package com.crc.secface.mapper;

import com.crc.secface.domain.VulnScanTaskOplog;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;

/**
 * <p>
 * 任务操作日志 Mapper 接口
 * </p>
 *
 * @author hejingsheng1
 * @since 2022-12-13
 */
public interface VulnScanTaskOplogMapper extends BaseMapper<VulnScanTaskOplog> {
    /**
     * 获取最新的任务操作记录
     * @param taskId 任务ID
     * @return 操作记录
     */
    VulnScanTaskOplog getLastTaskOpLog(String taskId);
}
