package com.crc.secface.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.crc.secface.domain.VulnScanTask;

import java.util.List;

/**
 * <p>
 * 漏洞扫描任务表 Mapper 接口
 * </p>
 *
 * @author hejingsheng
 * @since 2022-12-05
 */
public interface VulnScanTaskMapper extends BaseMapper<VulnScanTask> {
    void updateVulnScanTask(VulnScanTask vulnScanTask);

    List<VulnScanTask> getScanTaskList(VulnScanTask vulnScanTask);

    VulnScanTask getScanTaskByJobId(String id);

    String getDccNodeName(Long engineId);
}
