package com.crc.secface.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.crc.secface.domain.CommonKeywords;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;

import java.util.List;

/**
 * @author fuzhuangzhi
 * @title CommonKeywordsMapper
 * @date 2023/10/7 16:37
 * @description 公共全文检索mapper
 */

@Mapper
public interface CommonKeywordsMapper extends BaseMapper<CommonKeywords> {
    /**
     * 批量保存公共全文检索数据
     * @param dataList 全文检索数据
     * @return 插入条数
     */
    int insertBatch(@Param("list") List<CommonKeywords> dataList);
}