package com.crc.secface.mapper;

import com.crc.secface.domain.SysUserRoleDept;

import java.util.List;


/**
 * 用户与角色关联表 数据层
 *
 * @author wst
 */
public interface SysUserRoleDeptMapper {
    /**
     * 批量新增角色部门信息
     *
     * @param roleDeptList 角色部门列表
     * @return 结果
     */
    int batchRoleDept(List<SysUserRoleDept> roleDeptList);
}
