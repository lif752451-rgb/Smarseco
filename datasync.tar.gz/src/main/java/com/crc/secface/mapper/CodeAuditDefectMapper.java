package com.crc.secface.mapper;

import com.crc.secface.domain.CodeAuditDefect;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;

/**
 * <p>
 * 代码审计上报缺陷表 Mapper 接口
 * </p>
 *
 * @author hejingsheng1
 * @since 2023-01-11
 */
public interface CodeAuditDefectMapper extends BaseMapper<CodeAuditDefect> {
    CodeAuditDefect getCodeAuditRefInfo(Long id);
}
