package com.crc.secface.mapper;

import com.crc.secface.domain.SysUserRole;

import java.util.List;


/**
 * 用户与角色关联表 数据层
 *
 * @author wst
 */
public interface SysUserRoleMapper {
    /**
     * 批量新增用户角色信息
     *
     * @param userRoleList 用户角色列表
     * @return 结果
     */
    int batchUserRole(List<SysUserRole> userRoleList);

    int existUserRole(SysUserRole userRole);
}
