package com.crc.secface.mapper;

import com.crc.secface.domain.BaselineProcessForm;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;

/**
 * <p>
 * 基线主表 Mapper 接口
 * </p>
 *
 * @author hejingsheng1
 * @since 2024-03-19
 */
public interface BaselineProcessFormMapper extends BaseMapper<BaselineProcessForm> {
    void updateBaselineProcessForm(BaselineProcessForm baselineProcessForm);
}
