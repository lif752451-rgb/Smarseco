package com.crc.secface.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.crc.secface.domain.F5Data502;

/**
 * <p>
 *  Mapper 接口
 * </p>
 *
 * @author hejingsheng1
 * @since 2023-04-28
 */
public interface F5Data502Mapper extends BaseMapper<F5Data502> {
    void deleteAll();
}
