package com.crc.secface.mapper;

import com.crc.secface.domain.SeverAssetType;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import org.apache.ibatis.annotations.Param;

import java.util.List;

/**
 * <p>
 * 服务器资产类型 Mapper 接口
 * </p>
 *
 * @author hejingsheng1
 * @since 2023-09-21
 */
public interface SeverAssetTypeMapper extends BaseMapper<SeverAssetType> {

    List<SeverAssetType> getFullParentPath(String ancestors);

    List<SeverAssetType> findAssetTypeAll();

    SeverAssetType getDefaultType();

    String getAssetTypePath(@Param("assetTypeId") String assetTypeId);
}
