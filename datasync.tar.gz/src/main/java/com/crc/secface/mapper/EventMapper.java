package com.crc.secface.mapper;

import com.crc.secface.domain.Event;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;

/**
 * <p>
 * 实时事件处置 Mapper 接口
 * </p>
 *
 * @author hejingsheng1
 * @since 2022-12-28
 */
public interface EventMapper extends BaseMapper<Event> {
    void updateEvent(Event event);

    Event selectTbEventByQaxtId(Event event);
}
