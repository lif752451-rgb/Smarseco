package com.crc.secface.mapper;

import com.crc.secface.domain.AssetChangeRecord;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;

/**
 * <p>
 *  Mapper 接口
 * </p>
 *
 * @author hejingsheng1
 * @since 2023-09-21
 */
public interface AssetChangeRecordMapper extends BaseMapper<AssetChangeRecord> {

}
