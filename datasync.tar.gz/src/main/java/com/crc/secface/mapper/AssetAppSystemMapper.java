package com.crc.secface.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.crc.secface.domain.AssetAppSystem;
import com.crc.secface.domain.vo.AssetAppSystemKeywordsVo;
import org.apache.ibatis.annotations.Param;

import java.util.List;

/**
 * <p>
 * Mapper 接口
 * </p>
 *
 * @author hejingsheng1
 * @since 2023-05-16
 */
public interface AssetAppSystemMapper extends BaseMapper<AssetAppSystem> {
    void updateAssetAppSystem(AssetAppSystem assetAppSystem);

    /**
     * 分页查询应用系统数据
     *
     * @param offset   当前页
     * @param pageSize 页容量
     * @return 应用系统数据
     */
    List<AssetAppSystemKeywordsVo> getListByPage(@Param("offset") int offset, @Param("pageSize") int pageSize);
    List<AssetAppSystemKeywordsVo> getListByPageOracle(@Param("offset") int offset, @Param("pageSize") int pageSize);
}
