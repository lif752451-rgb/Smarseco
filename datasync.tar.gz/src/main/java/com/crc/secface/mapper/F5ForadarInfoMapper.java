package com.crc.secface.mapper;

import com.crc.secface.domain.F5ForadarInfo;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;

/**
 * <p>
 * foradar扫描互联网信息 Mapper 接口
 * </p>
 *
 * @author hejingsheng1
 * @since 2023-04-03
 */
public interface F5ForadarInfoMapper extends BaseMapper<F5ForadarInfo> {
    void updateF5ForadarInfo(F5ForadarInfo f5ForadarInfo);
}
