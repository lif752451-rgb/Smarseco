package com.crc.secface.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.crc.secface.domain.AssetAlarm;
import com.crc.secface.domain.vo.AlarmVo;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;

import java.util.List;

/**
 * @title AssetAlarmMapper
 * @date 2023/7/31 11:17
 * @author fuzhuangzhi
 * @description TODO
 */

@Mapper
public interface AssetAlarmMapper extends BaseMapper<AssetAlarm> {
    int insertOrUpdate(AssetAlarm record);

    int insertOrUpdateSelective(AssetAlarm record);

    void batchInsertAssetAlarm(List<AssetAlarm> alarmList);

    /**
     * 插入数据列表
     *
     * @param dataList 数据列表
     */
    void batchInsertIpAlarm(@Param("list") List<AlarmVo> dataList);
}