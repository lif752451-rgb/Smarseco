package com.crc.secface.mapper;

import com.alibaba.fastjson.JSONObject;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;

import java.util.HashMap;
import java.util.List;

@Mapper
public interface CommonMapper {
    List<HashMap<String, Object>> queryX(@Param("sql") String sql);
    List<JSONObject> query(@Param("sql") String sql);
    int getCount(@Param("sql")String sql);

    void deleteOldTaskInfo();

    void deleteOldTaskCap();

    void exeSQL(@Param("sql")String sql);

    JSONObject queryOne(String totalQuery);
}
