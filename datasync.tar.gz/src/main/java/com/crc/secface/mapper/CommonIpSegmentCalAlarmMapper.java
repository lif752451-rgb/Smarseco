package com.crc.secface.mapper;

import com.crc.secface.domain.CommonIpSegmentCalAlarm;

/**
 * @author fuzhuangzhi
 * @title CommonIpSegmentCalAlarmMapper
 * @date 2023/8/2 18:57
 * @description TODO
 */

public interface CommonIpSegmentCalAlarmMapper {
    int insertOrUpdate(CommonIpSegmentCalAlarm record);

    int insertOrUpdateSelective(CommonIpSegmentCalAlarm record);

    int deleteByCommonId(Long commonIpSegmentId);
}