package com.crc.secface.mapper;

import com.crc.secface.domain.AssetSegement;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;

/**
 * <p>
 * 集团网段 Mapper 接口
 * </p>
 *
 * @author hejingsheng
 * @since 2022-12-06
 */
public interface AssetSegementMapper extends BaseMapper<AssetSegement> {

}
