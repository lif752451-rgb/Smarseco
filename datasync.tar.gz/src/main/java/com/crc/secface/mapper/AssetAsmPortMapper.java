package com.crc.secface.mapper;

import com.crc.secface.domain.AssetAsmPort;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;

/**
 * <p>
 * 攻击面端口映射关系表 Mapper 接口
 * </p>
 *
 * @author hejingsheng1
 * @since 2023-05-18
 */
public interface AssetAsmPortMapper extends BaseMapper<AssetAsmPort> {
    void updateAssetAsmPort(AssetAsmPort assetAsmPort);
}
