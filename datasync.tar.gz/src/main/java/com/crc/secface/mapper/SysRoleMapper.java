package com.crc.secface.mapper;

import com.crc.secface.domain.SysRole;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;

/**
 * <p>
 * 角色信息表 Mapper 接口
 * </p>
 *
 * @author hejingsheng1
 * @since 2022-12-28
 */
public interface SysRoleMapper extends BaseMapper<SysRole> {

}
