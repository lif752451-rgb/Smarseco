package com.crc.secface.mapper;

import com.crc.secface.domain.EngineEquipmentManagement;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;

/**
 * <p>
 * 引擎管理 Mapper 接口
 * </p>
 *
 * @author hejingsheng1
 * @since 2022-12-08
 */
public interface EngineEquipmentManagementMapper extends BaseMapper<EngineEquipmentManagement> {

}
