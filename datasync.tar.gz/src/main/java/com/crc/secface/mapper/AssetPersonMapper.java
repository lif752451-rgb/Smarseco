package com.crc.secface.mapper;

import com.crc.secface.domain.AssetPerson;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import org.apache.ibatis.annotations.Param;

import java.util.List;

/**
 * <p>
 *  Mapper 接口
 * </p>
 *
 * @author hejingsheng1
 * @since 2023-04-17
 */
public interface AssetPersonMapper extends BaseMapper<AssetPerson> {
    void updateAssetPerson(AssetPerson assetPerson);

    List<AssetPerson> getListByIp(AssetPerson assetPerson);

    /**
     * 根据资产id删除
     *
     * @param idList
     * @param type
     * @return
     */
    void deleteByAssetIdsAndType(@Param("idList") List<Long> idList, @Param("type") String type);

    void batchInsert(List<AssetPerson> persons);

}
