package com.crc.secface.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.crc.secface.domain.SegmentAlarm;
import org.apache.ibatis.annotations.Mapper;

/**
 * @title SegmentAlarmMapper
 * @date 2023/6/27 16:16
 * @author fuzhuangzhi
 * @description TODO
 */

@Mapper
public interface SegmentAlarmMapper extends BaseMapper<SegmentAlarm> {

    /***
     * 新增或修改
     * @param record
     * @return
     */
    int insertOrUpdate(SegmentAlarm record);

}