package com.crc.secface.mapper;

import com.crc.secface.domain.SysUser;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import org.apache.ibatis.annotations.Param;

import java.util.HashMap;

/**
 * <p>
 * 用户信息表 Mapper 接口
 * </p>
 *
 * @author hejingsheng1
 * @since 2022-12-15
 */
public interface SysUserMapper extends BaseMapper<SysUser> {

    SysUser getByUserId(Long userId);

    SysUser selectUserByUserName(String userName);

    HashMap<String,String> selectUserByEmail(@Param("email") String email);

    void updateSysUser(SysUser sysUser);
}
