package com.crc.secface.mapper;

import com.crc.secface.domain.TerminalSoftwareInstall;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;

/**
 * <p>
 * 终端软件安装统计表 Mapper 接口
 * </p>
 *
 * @author hejingsheng1
 * @since 2022-12-13
 */
public interface TerminalSoftwareInstallMapper extends BaseMapper<TerminalSoftwareInstall> {

}
