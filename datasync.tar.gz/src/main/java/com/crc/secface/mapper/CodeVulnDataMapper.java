package com.crc.secface.mapper;

import com.crc.secface.domain.CodeVulnData;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;

/**
 * <p>
 * 代码缺陷主表 Mapper 接口
 * </p>
 *
 * @author hejingsheng1
 * @since 2023-01-11
 */
public interface CodeVulnDataMapper extends BaseMapper<CodeVulnData> {
    void updateCodeVulnData(CodeVulnData codeVulnData);
}
