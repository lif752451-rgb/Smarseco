package com.crc.secface.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.crc.secface.domain.F5Data506;

/**
 * <p>
 *  Mapper 接口
 * </p>
 *
 * @author hejingsheng1
 * @since 2023-04-28
 */
public interface F5Data506Mapper extends BaseMapper<F5Data506> {
    void deleteAll();
}
