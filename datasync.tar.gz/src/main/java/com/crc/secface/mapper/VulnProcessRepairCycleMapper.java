package com.crc.secface.mapper;

import com.crc.secface.domain.VulnProcessRepairCycle;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;

/**
 * <p>
 * 漏洞修复周期表 Mapper 接口
 * </p>
 *
 * @author hejingsheng1
 * @since 2022-12-15
 */
public interface VulnProcessRepairCycleMapper extends BaseMapper<VulnProcessRepairCycle> {

}
