package com.crc.secface.mapper;

import com.crc.secface.domain.AssetArea;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;

/**
 * <p>
 * 区域管理 Mapper 接口
 * </p>
 *
 * @author hejingsheng1
 * @since 2023-06-12
 */
public interface AssetAreaMapper extends BaseMapper<AssetArea> {

    String getAreaPath(String areaCustomUuid);

    String findAreaFullNameByCustomUuid(String customUuid);
    String findAreaFullNameByCustomUuidOracle(String customUuid);
}
