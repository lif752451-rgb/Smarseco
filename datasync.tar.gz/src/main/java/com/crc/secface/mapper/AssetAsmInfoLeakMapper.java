package com.crc.secface.mapper;

import com.crc.secface.domain.AssetAsmInfoLeak;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;

/**
 * <p>
 * 攻击面信息泄漏管理表 Mapper 接口
 * </p>
 *
 * @author hejingsheng1
 * @since 2023-05-16
 */
public interface AssetAsmInfoLeakMapper extends BaseMapper<AssetAsmInfoLeak> {
    void updateAssetAsmInfoLeak(AssetAsmInfoLeak assetAsmInfoLeak);
}
