package com.crc.secface.mapper;

import com.crc.secface.domain.AssetIpData;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;

/**
 * <p>
 * 资产缓存信息表 Mapper 接口
 * </p>
 *
 * @author hejingsheng1
 * @since 2023-09-19
 */
public interface AssetIpDataMapper extends BaseMapper<AssetIpData> {

}
