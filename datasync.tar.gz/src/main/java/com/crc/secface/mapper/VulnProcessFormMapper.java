package com.crc.secface.mapper;

import com.alibaba.fastjson.JSONObject;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.crc.secface.domain.VulnProcessForm;
import org.apache.ibatis.annotations.Param;

import java.util.List;

/**
 * <p>
 * 漏洞主表 Mapper 接口
 * </p>
 *
 * @author hejingsheng1
 * @since 2022-12-06
 */
public interface VulnProcessFormMapper extends BaseMapper<VulnProcessForm> {

    void updateVulnProcessForm(VulnProcessForm vul);

    VulnProcessForm getEngineId(@Param("ip") String ip);
    List<VulnProcessForm> getNoRespUserVulnList();

    /**
     * 通过去重规则查询漏洞个数
     *
     * @param form 实体
     * @return
     */
    VulnProcessForm getValidVulnUnique(VulnProcessForm form);

    Long getDealUserByIp(@Param("ip") String ip, @Param("roleKey") String roleKey);

    List<JSONObject> getDealUserListByIp(@Param("ip") String ip, @Param("roleKey") String roleKey);

    Long getDealUserByRoleAndOrganizationId(@Param("organizationId") Long organizationId, @Param("roleKey") String roleKey);

    Long getDealUserByDomain(@Param("domain") String domain, @Param("roleKey") String roleKey, @Param("dbType") String dbType);

    void stillExist(String id);

    String selectWhiteStatus(String id);
}
