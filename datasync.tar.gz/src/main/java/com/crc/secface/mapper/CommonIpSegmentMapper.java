package com.crc.secface.mapper;

import com.crc.secface.domain.CommonIpSegment;
import com.crc.secface.domain.vo.CommonIpSegmentVo;

import java.util.List;

/**
 * @author fuzhuangzhi
 * @title CommonIpSegmentMapper
 * @date 2023/8/2 18:57
 * @description TODO
 */

public interface CommonIpSegmentMapper {

    List<Long> selectBusinessIds();

    int insertOrUpdate(CommonIpSegment record);

    int insertOrUpdateSelective(CommonIpSegment record);

    List<CommonIpSegmentVo> getSegment();
}