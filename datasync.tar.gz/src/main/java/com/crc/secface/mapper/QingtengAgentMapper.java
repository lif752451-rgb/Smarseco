package com.crc.secface.mapper;

import com.crc.secface.domain.QingtengAgent;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;

/**
 * <p>
 *  Mapper 接口
 * </p>
 *
 * @author hejingsheng
 * @since 2022-12-06
 */
public interface QingtengAgentMapper extends BaseMapper<QingtengAgent> {

    QingtengAgent getByIp(String internalIp);
}
