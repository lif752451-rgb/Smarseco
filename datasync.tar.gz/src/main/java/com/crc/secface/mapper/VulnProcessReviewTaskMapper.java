package com.crc.secface.mapper;

import com.crc.secface.domain.VulnProcessReviewTask;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import org.apache.ibatis.annotations.Param;

import java.util.List;

/**
 * <p>
 * 漏洞下发复查任务表 Mapper 接口
 * </p>
 *
 * @author hejingsheng1
 * @since 2022-12-07
 */
public interface VulnProcessReviewTaskMapper extends BaseMapper<VulnProcessReviewTask> {

    List<String> getReviewIp();

    VulnProcessReviewTask getLastCall(@Param("ip") String ip);

    List<VulnProcessReviewTask> getReviewByVulCode(@Param("codeList") List<String> codeList);
}
