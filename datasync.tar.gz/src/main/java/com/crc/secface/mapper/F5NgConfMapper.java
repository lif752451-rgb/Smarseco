package com.crc.secface.mapper;

import com.crc.secface.domain.F5NgConf;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;

/**
 * <p>
 * f5_ng_conf配置解析表 Mapper 接口
 * </p>
 *
 * @author hejingsheng1
 * @since 2023-04-03
 */
public interface F5NgConfMapper extends BaseMapper<F5NgConf> {
    void deleteAll();
}
