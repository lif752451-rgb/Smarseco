package com.crc.secface.mapper;

import com.crc.secface.domain.AssetAsmInternet;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;

/**
 * <p>
 * 攻击面_互联网资产管理 Mapper 接口
 * </p>
 *
 * @author hejingsheng1
 * @since 2023-03-08
 */
public interface AssetAsmInternetMapper extends BaseMapper<AssetAsmInternet> {
    void updateAssetAsmInternet(AssetAsmInternet asmInternet);
}
