package com.crc.secface.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.crc.secface.domain.VulnScanTask;
import com.crc.secface.domain.VulnScanTaskRecord;

import java.util.List;

/**
 * <p>
 * 漏洞扫描任务表记录表 Mapper 接口
 * </p>
 *
 * @author hejingsheng
 * @since 2022-12-05
 */
public interface VulnScanTaskRecordMapper extends BaseMapper<VulnScanTaskRecord> {
    /*
    获取最新的record
     */
    VulnScanTaskRecord getLastRecordByTaskId(String taskId);

    VulnScanTaskRecord getByRecordId(Long id);

    void updateVulnScanTaskRecord(VulnScanTaskRecord vulnScanTaskRecord);

    void deleteByTaskId(String taskId);

    List<VulnScanTaskRecord> getAllTaskRecordList(VulnScanTask task);
}
