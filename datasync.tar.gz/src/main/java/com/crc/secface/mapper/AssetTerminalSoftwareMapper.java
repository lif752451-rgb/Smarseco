package com.crc.secface.mapper;

import com.crc.secface.domain.AssetTerminalSoftware;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;

/**
 * <p>
 * 终端资产-终端软件表 Mapper 接口
 * </p>
 *
 * @author hejingsheng1
 * @since 2023-03-27
 */
public interface AssetTerminalSoftwareMapper extends BaseMapper<AssetTerminalSoftware> {

}
