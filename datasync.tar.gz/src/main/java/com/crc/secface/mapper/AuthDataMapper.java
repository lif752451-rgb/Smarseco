package com.crc.secface.mapper;

import com.crc.secface.domain.AuthData;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;

/**
 * <p>
 *  Mapper 接口
 * </p>
 *
 * @author hejingsheng1
 * @since 2022-12-28
 */
public interface AuthDataMapper extends BaseMapper<AuthData> {

}
