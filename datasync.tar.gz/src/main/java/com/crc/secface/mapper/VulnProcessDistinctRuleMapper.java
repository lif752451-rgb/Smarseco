package com.crc.secface.mapper;

import com.crc.secface.domain.VulnProcessDistinctRule;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;

/**
 * <p>
 * 漏洞去重规则表 Mapper 接口
 * </p>
 *
 * @author hejingsheng1
 * @since 2022-12-15
 */
public interface VulnProcessDistinctRuleMapper extends BaseMapper<VulnProcessDistinctRule> {

}
