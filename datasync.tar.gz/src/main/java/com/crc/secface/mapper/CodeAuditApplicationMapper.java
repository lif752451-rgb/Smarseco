package com.crc.secface.mapper;

import com.crc.secface.domain.CodeAuditApplication;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;

/**
 * <p>
 * 代码审计应用表 Mapper 接口
 * </p>
 *
 * @author hejingsheng1
 * @since 2023-01-10
 */
public interface CodeAuditApplicationMapper extends BaseMapper<CodeAuditApplication> {
    void updateAppCheckCount(Long appId);

    void updateAppCheckCountX(Long appId);

    void updateProjCheckCount(CodeAuditApplication application);

    void updateProjCheckCountX(CodeAuditApplication application);
}
