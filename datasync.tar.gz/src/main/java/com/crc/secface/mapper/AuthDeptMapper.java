package com.crc.secface.mapper;

import com.crc.secface.domain.AuthDept;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;

import java.util.List;

/**
 * <p>
 *  Mapper 接口
 * </p>
 *
 * @author hejingsheng1
 * @since 2022-12-28
 */
public interface AuthDeptMapper extends BaseMapper<AuthDept> {

    List<AuthDept> selectTbAuthDeptByParentDeptId(String rootId);
    List<AuthDept> getRootList();

    AuthDept selectTbAuthDeptByDeptId(String rootId);

    List<AuthDept> selectTbAuthDeptByUserDeptId(String rootId);

    void updateAuthDept(AuthDept authDept);

    void deleteSysDept(long deptId);

    void deleteDeptById(String deptId);
}
