package com.crc.secface.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.crc.secface.domain.AlarmReport;
import com.crc.secface.domain.AssetAlarm;
import com.crc.secface.domain.SegmentAlarm;
import com.crc.secface.domain.vo.AssetAlarmVo;
import com.crc.secface.domain.vo.SegmentAlarmVo;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;

import java.util.List;

/**
 * @author fuzhuangzhi
 * @title AlarmReportMapper
 * @date 2023/6/27 16:56
 * @description TODO
 */
@Mapper
public interface AlarmReportMapper extends BaseMapper<AlarmReport> {

    /**
     * 分页查询告警信息
     *
     * @param alarmReport 告警参数
     * @return
     */
    List<SegmentAlarm> selectAllAlarm(AlarmReport alarmReport);

    /**
     * 分页查询资产关联告警数据
     *
     * @param alarmReport 告警参数
     * @return 告警数据
     */
    List<AssetAlarm> selectAssetAllAlarm(AlarmReport alarmReport);

    /**
     * 查询
     *
     * @param alarmReport
     * @return
     */
    Integer selectAssetCount(AlarmReport alarmReport);


    /**
     * 分页查询告警信息
     *
     * @param offset   偏移量
     * @param pageSize 页容量
     * @return 告警闭环列表
     */
    List<AlarmReport> selectAlarmReportList(@Param("offset") int offset, @Param("pageSize") int pageSize);

}
