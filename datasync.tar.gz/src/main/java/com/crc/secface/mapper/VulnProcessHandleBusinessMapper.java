package com.crc.secface.mapper;

import com.crc.secface.domain.VulnProcessHandleBusiness;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;

/**
 * <p>
 * 漏洞处置流程业务 Mapper 接口
 * </p>
 *
 * @author hejingsheng1
 * @since 2022-12-16
 */
public interface VulnProcessHandleBusinessMapper extends BaseMapper<VulnProcessHandleBusiness> {

}
