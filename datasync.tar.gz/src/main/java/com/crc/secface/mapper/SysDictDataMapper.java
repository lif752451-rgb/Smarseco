package com.crc.secface.mapper;

import com.crc.secface.domain.SysDictData;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;

/**
 * <p>
 * 字典数据表 Mapper 接口
 * </p>
 *
 * @author hejingsheng1
 * @since 2022-12-06
 */
public interface SysDictDataMapper extends BaseMapper<SysDictData> {

}
