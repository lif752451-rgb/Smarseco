package com.crc.secface.mapper;

import com.crc.secface.domain.CodeAuditProject;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;

/**
 * <p>
 * 代码审计项目表 Mapper 接口
 * </p>
 *
 * @author hejingsheng1
 * @since 2023-01-11
 */
public interface CodeAuditProjectMapper extends BaseMapper<CodeAuditProject> {
    CodeAuditProject getProjct(String id);
}
