package com.crc.secface.mapper;

import com.crc.secface.domain.F5NgConfAssetRela;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;

/**
 * <p>
 * 关系表 Mapper 接口
 * </p>
 *
 * @author hejingsheng1
 * @since 2023-04-03
 */
public interface F5NgConfAssetRelaMapper extends BaseMapper<F5NgConfAssetRela> {

}
