package com.crc.secface.queue;

import cn.hutool.core.collection.CollUtil;
import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;
import com.baomidou.mybatisplus.core.conditions.query.LambdaQueryWrapper;
import com.baomidou.mybatisplus.core.conditions.update.LambdaUpdateWrapper;
import com.baomidou.mybatisplus.core.toolkit.Wrappers;
import com.crc.common.code.CreateInsert;
import com.crc.common.code.SimpleCodeTool;
import com.crc.common.enums.AssetSourceEnums;
import com.crc.common.enums.DictTypeEnum;
import com.crc.common.utils.DataUtils;
import com.crc.common.utils.DictUtil;
import com.crc.common.utils.IdGen;
import com.crc.common.utils.IpUtils;
import com.crc.common.utils.JsonUtils;
import com.crc.secface.config.GetSpringBean;
import com.crc.secface.db.ConfBuzziMySql;
import com.crc.secface.domain.Asset;
import com.crc.secface.domain.AssetIpData;
import com.crc.secface.domain.AssetPerson;
import com.crc.secface.domain.AssetRef;
import com.crc.secface.domain.AssetSegement;
import com.crc.secface.domain.SeverAssetType;
import com.crc.secface.domain.SysDept;
import com.crc.secface.domain.SysDictData;
import com.crc.secface.domain.SysUser;
import com.crc.secface.domain.TbAssetExt;
import com.crc.secface.mapper.AssetAreaMapper;
import com.crc.secface.mapper.AssetIpDataMapper;
import com.crc.secface.mapper.AssetMapper;
import com.crc.secface.mapper.AssetPersonMapper;
import com.crc.secface.mapper.CommonMapper;
import com.crc.secface.mapper.SeverAssetTypeMapper;
import com.crc.secface.mapper.SysDeptMapper;
import com.crc.secface.mapper.SysUserMapper;
import com.crc.secface.service.AssetRecordService;
import com.crc.sync.config.SyncSecConstants;
import com.crc.sync.net.NewSegmentLoad;
import com.crc.sync.terminal.alarm.AlarmAllAssetSync;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.BeanUtils;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Comparator;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Objects;

import static com.crc.common.enums.DictTypeEnum.ENVIRONMENT_TYPE;
import static com.crc.common.enums.DictTypeEnum.EQUAL_PROTECTION_LEVEL;
import static com.crc.common.enums.StatusEnum.NO;

/*
   资产同步刷入，按新规则
 */
@Slf4j
public class CrcAssetSyncQueue {
    private static final CrcAssetSyncQueue instance = new CrcAssetSyncQueue();

    public static CrcAssetSyncQueue getInstance() {
        return instance;
    }

    private CrcAssetSyncQueue() {

    }

    /**
     * 保存资产信息
     */
    public boolean saveAsset(Asset asset) {
        return saveAsset(asset, true);
    }

    public Asset getAssetFullByIp(String ip) {
        AssetMapper assetMapper = GetSpringBean.getBean(AssetMapper.class);
        AssetPersonMapper assetPersonMapper = GetSpringBean.getBean(AssetPersonMapper.class);
        Asset asset = assetMapper.selectAssetByInnerIp(ip);
        if (asset != null) {
            if (StringUtils.isNotBlank(asset.getInternalIp())) {
                AssetPerson q = new AssetPerson();
                q.setInternalIp(asset.getInternalIp());
                q.setType("1");
                asset.setDutyUsers(assetPersonMapper.getListByIp(q));

                q.setType("2");
                asset.setOperatingUsers(assetPersonMapper.getListByIp(q));
            }
        }
        return asset;
    }

    public Asset getByIp(String ip) {
        AssetMapper assetMapper = GetSpringBean.getBean(AssetMapper.class);
        return assetMapper.selectAssetByInnerIp(ip);
    }

    /**
     * 保存资产信息
     */
    public boolean saveAsset(Asset asset, boolean updateFlag) {
        try {
            if (StringUtils.isBlank(asset.getInternalIp()) || !IpUtils.isIp(asset.getInternalIp())) {
                log.error("非法IP={}，禁止入库", asset.getInternalIp());
                return false;
            }

            AssetSegement seg = NewSegmentLoad.getIPSegmentByHalf(asset.getInternalIp());
            if (NewSegmentLoad.FILTER_SEGMENT_FLAG && seg == null) {
                log.error("启用了网段识别 IP 过滤机制，非网段数据不入库sync_sec_config/filter_segment_enable，ip={}，不入库", asset.getInternalIp());
                return false;
            }

            if (isManagerIp(asset.getInternalIp())) {
                log.error("管理IP={}，不入库", asset.getInternalIp());
                return false;
            }

            if (seg != null && StringUtils.isNotBlank(seg.getRemark())) {
                if (seg.getRemark().contains("办公网")) {
                    AlarmAllAssetSync.save(asset.getInternalIp(), asset.getMacAddress(), seg);
                    log.info("{},为办公网 IP", asset.getInternalIp());
                    return false;
                }
            }
            // 判断是否有效部门
            if (Objects.nonNull(asset.getAffiliationDeptNodeId())) {
                SysDeptMapper sysDeptMapper = GetSpringBean.getBean(SysDeptMapper.class);
                SysDept sysDept = sysDeptMapper.selectByDeptId(asset.getAffiliationDeptNodeId());
                if (Objects.nonNull(sysDept)) {
                    asset.setAffiliationDeptName(StringUtils.isNotBlank(sysDept.getFullPath()) ? sysDept.getFullPath() : sysDept.getDeptName());
                }
            } else {
                NewSegmentLoad.getSegementInfo(asset);
            }

            if (StringUtils.isBlank(asset.getInstance())) {
                if (StringUtils.isNotBlank(asset.getHostName())) {
                    asset.setInstance(asset.getHostName());
                }
            }
            AssetRecordService assetRecordService = GetSpringBean.getBean(AssetRecordService.class);
            SeverAssetType defaultAssetType = assetRecordService.findAssetTypeAll().stream()
                    .filter(type -> type.getId().equals(type.getAncestors()))
                    .min(Comparator.comparing(SeverAssetType::getSortNum)).orElse(null);
            List<SysDictData> keyAssetList = DictUtil.getDict("asset_ip_level");
            List<SysDictData> environmentTypeList = DictUtil.getDict(ENVIRONMENT_TYPE.getName());
            List<SysDictData> equalProtectionLevelList = DictUtil.getDict(EQUAL_PROTECTION_LEVEL.getName());
            if (Objects.isNull(asset.getKeyAsset())) {
                asset.setKeyAsset(3);
            }
            if (asset.getOperatingStatus() == null) {
                asset.setOperatingStatus(1);
            }

            if (StringUtils.isBlank(asset.getInstance())) {
                asset.setInstance(asset.getInternalIp());
            }
            //insert
            if (asset.getOperatingStatus() == null) {
                asset.setOperatingStatus(1);
            }
            asset.setStatus(0);
            asset.setUpdateTime(new Date());
            if (asset.getCreateTime() == null) {
                asset.setCreateTime(new Date());
            }
            // 资产等级
            keyAssetList.stream().findFirst().ifPresent(dict -> {
                if ("3".equals(dict.getDictValue())) {
                    asset.setKeyAsset(DataUtils.toInt(dict.getDictValue()));
                    asset.setKeyAssetLabel(dict.getDictLabel());
                }
            });
            // 资产类型
            if (Objects.nonNull(defaultAssetType)) {
                asset.setAssetTypeId(defaultAssetType.getId());
                asset.setAssetTypeName(defaultAssetType.getFullPath());
                asset.setAssetTypePath(defaultAssetType.getAncestors());
            }
            // 环境类型
            String environmentType =
                    DictUtil.getDictDataValueOrDefault(environmentTypeList, asset.getEnvironmentTypeLabel());
            if (StringUtils.isNotEmpty(environmentType)) {
                asset.setEnvironmentType(Integer.parseInt(environmentType));
            }
            // 是否为关键基础设施
            asset.setAssetPower(NO.getValue());
            // 是否完成国密改造0否1是 默认 0 否
            asset.setTransformationCompleted(NO.getValue());
            // 是否发布互联网
            asset.setInternetPublic(NO.getValue());
            // 是否集权系统 0否1是
            asset.setCentralizedSystem(NO.getValue());
            // 等保定级
            equalProtectionLevelList.stream().findFirst().ifPresent(dict -> {
                asset.setEqualProtectionLevel(DataUtils.toInt(dict.getDictValue()));
                asset.setEqualProtectionLevelLabel(dict.getDictLabel());
            });
            // 实战期间是否授权关闭
            asset.setIsCombatOff(NO.getValue());
            // 实战期间是否有关闭计划
            asset.setIsCombatPlan(NO.getValue());
            // 是否包含个人信息 0 否(默认) 1 是
            asset.setIsPersonalInfo(NO.getValue());
            anlyFullDept(asset);
            //同步到UDC
            AssetMapper assetMapper = GetSpringBean.getBean(AssetMapper.class);
            LambdaQueryWrapper<Asset> query = new LambdaQueryWrapper<>();
            query.eq(Asset::getInternalIp, asset.getInternalIp());
            query.eq(Asset::getDelFlag, "0");
            query.last(" limit 1");
            Asset tmp = assetMapper.selectOne(query);
            if (tmp == null) {
                asset.setInternetPublic(0);
                asset.setEqualProtectionLevel(0);
                asset.setUpdateTime(new Date());
                asset.setCreateTime(new Date());
                updateFullAreaDept(asset);
                assetMapper.insert(asset);
                // 添加用户关联信息
                addPerson(asset);
                return true;
            } else {
                asset.setId(tmp.getId());
                //更新
                if (updateFlag) {
                    //只获取更新部分
                    boolean flag;
                    //认领或人工维护的不更新,但被删除了，需要变更资产
                    flag = !"1".equalsIgnoreCase(tmp.getApply()) && StringUtils.isBlank(tmp.getUpdateBy());
                    if (flag) {
                        log.info("update {} {} {}", asset.getInternalIp(), asset.getAffiliationDeptNodeId(), asset.getAffiliationDeptName());
                        tmp.setInstance(asset.getInstance());//不更新实例
                        tmp.setHostName(asset.getHostName());
                        tmp.setOs(asset.getOs());
                        tmp.setEnvironmentType(asset.getEnvironmentType());
                        tmp.setType(asset.getType());
                        tmp.setOperatingStatus(1);
                        tmp.setSubType(asset.getSubType());
                        tmp.setUpdateTime(new Date());
                        if (tmp.getCreateTime() == null) {
                            tmp.setCreateTime(new Date());
                        }
                        if (StringUtils.isNotBlank(asset.getTag())) {
                            if (StringUtils.isNotBlank(tmp.getTag())) {
                                String[] tags = tmp.getTag().split(",");
                                HashMap<String, String> map = new HashMap<>();
                                for (String tag : tags) {
                                    map.put(tag, "1");
                                }
                                map.put(asset.getTag(), "1");
                                tmp.setTag(String.join(",", map.keySet()));
                            } else {
                                tmp.setTag(asset.getTag());
                            }
                        }

                        tmp.setGeographicLocation(asset.getGeographicLocation());
                        tmp.setAreaName(asset.getAreaName());
                        tmp.setAreaCustomUuid(asset.getAreaCustomUuid());
                        tmp.setAffiliationDeptName(asset.getAffiliationDeptName());
                        tmp.setAffiliationDeptNodeId(asset.getAffiliationDeptNodeId());
                        tmp.setCode(asset.getCode());
                        updateFullAreaDept(tmp);
                        assetMapper.updateAsset(tmp);
                        // 添加用户关联信息
                        addPerson(asset);
                        return true;
                    } else {
                        if (AssetSourceEnums.SAFEDOG_CMDB.getCode().equals(asset.getSource())) {
                            try {
                                if (StringUtils.isNotBlank(asset.getCode())) {
                                    assetMapper.updateAssetCode(asset);
                                }
                            } catch (Exception e) {
                                log.error(e.getMessage(), e);
                            }
                        } else if (AssetSourceEnums.QINGTENG_CMDB.getCode().equals(asset.getSource())) {
                            if (DictUtil.isEnable(SyncSecConstants.SYNC_SEC_CONFIG, SyncSecConstants.QT_ASSET_HOST_TAG_SYNC_ENABLE)) {
                                try {
                                    Asset newAsset = new Asset();
                                    newAsset.setId(tmp.getId());
                                    newAsset.setHostName(asset.getHostName());
                                    newAsset.setInstance(asset.getInstance());
                                    newAsset.setUpdateTime(new Date());
                                    newAsset.setSource(AssetSourceEnums.QINGTENG_CMDB.getCode());
                                    assetMapper.updateAsset(newAsset);
//                                // 添加用户关联信息
//                                addPerson(asset);
                                } catch (Exception e) {
                                    log.error(e.getMessage(), e);
                                }
                            }
                        }
                    }
                }
            }
        } catch (Exception e) {
            log.error(e.getMessage(), e);
        }
        return false;
    }

    private void addPerson(Asset asset) {
        AssetPersonMapper assetPersonMapper = GetSpringBean.getBean(AssetPersonMapper.class);
        // 负责人列表
        List<AssetPerson> respUsersList = new ArrayList<>();
        // 运维人列表
        List<AssetPerson> operUsersList = new ArrayList<>();
        if (CollUtil.isNotEmpty(asset.getDutyUsers())) {
            // 删除历史数据/新增新数据
            assetPersonMapper.deleteByAssetIdsAndType(Arrays.asList(asset.getId()), "1");
            asset.getDutyUsers().forEach(data -> {
                AssetPerson assetPerson = new AssetPerson();
                BeanUtils.copyProperties(data, assetPerson);
                assetPerson.setUserId(data.getUserId());
                assetPerson.setId(IdGen.uuid());
                assetPerson.setAssetId(asset.getId().toString());
                assetPerson.setType("1");
                assetPerson.setInternalIp(asset.getInternalIp());
                respUsersList.add(assetPerson);
            });
            assetPersonMapper.batchInsert(respUsersList);
        }

        if (CollUtil.isNotEmpty(asset.getOperatingUsers())) {
            // 删除历史数据/新增新数据
            assetPersonMapper.deleteByAssetIdsAndType((Arrays.asList(asset.getId())), "2");
            asset.getOperatingUsers().forEach(data -> {
                AssetPerson assetPerson = new AssetPerson();
                BeanUtils.copyProperties(data, assetPerson);
                assetPerson.setUserId(data.getUserId());
                assetPerson.setId(IdGen.uuid());
                assetPerson.setAssetId(asset.getId().toString());
                assetPerson.setType("2");
                assetPerson.setInternalIp(asset.getInternalIp());
                operUsersList.add(assetPerson);
            });
            assetPersonMapper.batchInsert(operUsersList);
        }
    }

    private void anlyFullDept(Asset asset) {
        try {
            if (asset.getAffiliationDeptNodeId() == null || asset.getAffiliationDeptNodeId() == 0L) {
                //update  tb_asset set dept_path=',0,100,99,' where dept_path is null
                asset.setDeptPath(",0,100,99,");
            } else {
                ////update  tb_asset set dept_path=(select concat(',',ancestors,',',dept_id,',') from sys_dept where dept_id=affiliation_dept_node_id)
                SysDeptMapper sysDeptMapper = GetSpringBean.getBean(SysDeptMapper.class);
                String deptPath = sysDeptMapper.getDeptPath(asset.getAffiliationDeptNodeId());
                asset.setDeptPath(deptPath);
            }
            if (StringUtils.isBlank(asset.getAreaCustomUuid())) {
                asset.setAreaPath(",0,96,");
            } else {
                AssetAreaMapper assetAreaMapper = GetSpringBean.getBean(AssetAreaMapper.class);
                String areaPath = assetAreaMapper.getAreaPath(asset.getAreaCustomUuid());
                asset.setAreaPath(areaPath);
            }
            if (StringUtils.isBlank(asset.getAssetTypeId())) {
                asset.setAssetTypePath(null);
            } else {
                SeverAssetTypeMapper severAssetTypeMapper = GetSpringBean.getBean(SeverAssetTypeMapper.class);
                String assetTypePath = severAssetTypeMapper.getAssetTypePath(asset.getAssetTypeId());
                asset.setAssetTypePath(assetTypePath);
            }
        } catch (Exception e) {
            log.error(e.getMessage(), e);
        }
    }

    /**
     * 设置资产责任人
     *
     * @param username 用户信息
     * @param type     类型；1，责任人；2，运维人
     */
    public void saveAssetPerson(String ip, String username, String type) {
        try {
            if (StringUtils.isBlank(username)) {
                return;
            }
            SysUserMapper sysUserMapper = GetSpringBean.getBean(SysUserMapper.class);
            SysUser user = sysUserMapper.selectUserByUserName(username);
            if (user != null) {
                saveAssetPerson(ip, user, type);
            } else {
                if (StringUtils.isNotBlank(ip) && StringUtils.isNotBlank(username)) {
                    Asset asset = CrcAssetSyncQueue.getInstance().getByIp(ip);
                    if (asset == null || StringUtils.isBlank(asset.getInternalIp())) {
                        return;
                    }
                    boolean flag = !"1".equalsIgnoreCase(asset.getApply()) && StringUtils.isBlank(asset.getUpdateBy());
                    if (flag) {
                        AssetPersonMapper assetPersonMapper = GetSpringBean.getBean(AssetPersonMapper.class);
                        LambdaQueryWrapper<AssetPerson> dq = Wrappers.lambdaQuery();
                        dq.eq(AssetPerson::getType, type);
                        dq.eq(AssetPerson::getInternalIp, asset.getInternalIp());
                        assetPersonMapper.delete(dq);

                        AssetPerson assetPerson = new AssetPerson();
                        assetPerson.setId(IdGen.uuid());
                        assetPerson.setType(type);
                        assetPerson.setAssetId(asset.getId().toString());
                        assetPerson.setUserName(username);
                        assetPerson.setInternalIp(asset.getInternalIp());
                        assetPersonMapper.insert(assetPerson);
                    }
                }
            }
        } catch (Exception e) {
            log.error(e.getMessage(), e);
        }

    }


    /**
     * 设置资产责任人
     *
     * @param user 用户信息
     * @param type 类型；1，责任人；2，运维人
     */
    void saveAssetPerson(String ip, SysUser user, String type) {
        try {
            if (StringUtils.isNotBlank(ip) && user != null && StringUtils.isNotBlank(user.getUserName())) {
                Asset asset = CrcAssetSyncQueue.getInstance().getByIp(ip);
                if (asset == null || StringUtils.isBlank(asset.getInternalIp())) {
                    return;
                }
                boolean flag = !"1".equalsIgnoreCase(asset.getApply()) && StringUtils.isBlank(asset.getUpdateBy());
                if (flag) {
                    AssetPersonMapper assetPersonMapper = GetSpringBean.getBean(AssetPersonMapper.class);
                    LambdaQueryWrapper<AssetPerson> dq = Wrappers.lambdaQuery();
                    dq.eq(AssetPerson::getType, type);
                    dq.eq(AssetPerson::getInternalIp, asset.getInternalIp());
                    assetPersonMapper.delete(dq);

                    AssetPerson assetPerson = new AssetPerson();
                    assetPerson.setId(IdGen.uuid());
                    assetPerson.setType(type);
                    assetPerson.setAssetId(asset.getId().toString());
                    assetPerson.setEmail(user.getEmail());
                    assetPerson.setUserName(String.format("%s(%s)", user.getNickName(), user.getUserName()));
                    assetPerson.setPhone(user.getPhonenumber());
                    assetPerson.setInternalIp(asset.getInternalIp());
                    assetPersonMapper.insert(assetPerson);
                }
            }
        } catch (Exception e) {
            log.error(e.getMessage(), e);
        }
    }


    public void updateFullAreaDept(Asset asset) {
        SysDeptMapper sysDeptMapper = GetSpringBean.getBean(SysDeptMapper.class);
        AssetAreaMapper assetAreaMapper = GetSpringBean.getBean(AssetAreaMapper.class);
        try {
            if (asset.getAffiliationDeptNodeId() == null || asset.getAffiliationDeptNodeId() == 0L) {
                //update  tb_asset set dept_path=',0,100,99,' where dept_path is null
                asset.setDeptPath(",0,100,99,");
            } else {
                ////update  tb_asset set dept_path=(select concat(',',ancestors,',',dept_id,',') from sys_dept where dept_id=affiliation_dept_node_id)
                String deptPath = sysDeptMapper.getDeptPath(asset.getAffiliationDeptNodeId());
                asset.setDeptPath(deptPath);
            }
            if (StringUtils.isBlank(asset.getAreaCustomUuid())) {
                asset.setAreaPath(",0,96,");
            } else {
                String areaPath = assetAreaMapper.getAreaPath(asset.getAreaCustomUuid());
                asset.setAreaPath(areaPath);
            }
        } catch (Exception e) {
            log.error(e.getMessage(), e);
        }
    }

    public boolean isManagerIp(String ip) {
        if (!IpUtils.isIp(ip)) {
            return false;
        }
        AssetMapper assetMapper = GetSpringBean.getBean(AssetMapper.class);
        CommonMapper commonMapper = GetSpringBean.getBean(CommonMapper.class);
        boolean flag = false;
        try {
            int isAssetExt = ConfBuzziMySql.existTable("tb_asset_ext");
            if (isAssetExt == 1) {
                String sql = "select asset_id,equipment_manager_address  from tb_asset_ext where equipment_manager_address like '%" + ip + "%' ";
                List<JSONObject> list = commonMapper.query(sql);
                if (list != null && list.size() > 0) {
                    for (JSONObject jsonObject : list) {
                        String ipStr = JsonUtils.getStr(jsonObject, "equipment_manager_address");
                        List<String> ipList = IpUtils.getIps(ipStr);
                        for (String manIp : ipList) {
                            if (ip.equals(manIp)) {
                                flag = true;
                            }
                            Asset tmp = assetMapper.selectAssetByInnerIp(manIp);
                            if (tmp != null) {//存在其他IP把管理ip当作资产
                                try {
                                    LambdaUpdateWrapper<Asset> up = Wrappers.lambdaUpdate();
                                    up.eq(Asset::getId, tmp.getId());
                                    up.set(Asset::getDelFlag, "1");
                                    assetMapper.update(null, up);
                                } catch (Exception e) {
                                    log.error(e.getMessage(), e);
                                }

                            }
                        }
                    }

                }
            }
        } catch (Exception e) {
            log.error(e.getMessage(), e);
        }

        return flag;
    }

    /**
     * 保存资产扩展信息
     */
    public void saveAssetExt(AssetRef ref) {
        if (StringUtils.isBlank(ref.getIp()) || ref.getExt() == null) {
            return;
        }
        AssetMapper assetMapper = GetSpringBean.getBean(AssetMapper.class);
        CommonMapper commonMapper = GetSpringBean.getBean(CommonMapper.class);
        LambdaQueryWrapper<Asset> query = new LambdaQueryWrapper<>();
        query.eq(Asset::getInternalIp, ref.getIp());
        query.eq(Asset::getDelFlag, "0");
        query.last(" limit 1");
        Asset tmp = assetMapper.selectOne(query);
        if (tmp != null) {
            if (commonMapper.getCount("select count(1) from tb_asset_ext where asset_id = " + tmp.getId()) < 1) {
                CreateInsert<TbAssetExt> createInsert = new CreateInsert<>();
                ref.getExt().setAssetId(tmp.getId());
                String sql = createInsert.createinsert(ref.getExt(), "tb_asset_ext");
                commonMapper.exeSQL(sql);
            } else {
                CreateInsert<TbAssetExt> createInsert = new CreateInsert<>();
                ref.getExt().setAssetId(tmp.getId());
                String sql = createInsert.createupdate(ref.getExt(), "tb_asset_ext", " asset_id = " + tmp.getId());
                commonMapper.exeSQL(sql);
            }
        }
    }

    public void delAsset(String ip) {
        try {
            if (!IpUtils.isIp(ip)) {
                return;
            }
            AssetMapper assetMapper = GetSpringBean.getBean(AssetMapper.class);
            assetMapper.deleteByIp(ip);
        } catch (Exception e) {
            log.error(e.getMessage(), e);
        }
    }

    public void saveData(String ip, JSONObject json, String type) {
        try {
            AssetIpDataMapper assetIpDataMapper = GetSpringBean.getBean(AssetIpDataMapper.class);
            LambdaQueryWrapper<AssetIpData> q = Wrappers.lambdaQuery();
            q.eq(AssetIpData::getType, type);
            q.eq(AssetIpData::getIp, ip);
            q.last(" limit 1");
            AssetIpData ipData = assetIpDataMapper.selectOne(q);
            if (ipData == null) {
                AssetIpData obj = new AssetIpData();
                obj.setData(SimpleCodeTool.decryptBase64(json.toJSONString()));
                obj.setType(type);
                obj.setIp(ip);
                obj.setCreateTime(new Date());
                assetIpDataMapper.insert(obj);
            } else {
                ipData.setCreateTime(new Date());
                ipData.setData(SimpleCodeTool.decryptBase64(json.toJSONString()));
                assetIpDataMapper.updateById(ipData);
            }
        } catch (Exception e) {
            log.error(e.getMessage(), e);
        }
    }

    public void saveData(String ip, Object jsonStr, String type) {
        try {
            AssetIpDataMapper assetIpDataMapper = GetSpringBean.getBean(AssetIpDataMapper.class);
            LambdaQueryWrapper<AssetIpData> q = Wrappers.lambdaQuery();
            q.eq(AssetIpData::getType, type);
            q.eq(AssetIpData::getIp, ip);
            q.last(" limit 1");
            AssetIpData ipData = assetIpDataMapper.selectOne(q);
            if (ipData == null) {
                AssetIpData obj = new AssetIpData();
                obj.setData(SimpleCodeTool.decryptBase64(JSON.toJSONString(jsonStr)));
                obj.setType(type);
                obj.setIp(ip);
                obj.setCreateTime(new Date());
                assetIpDataMapper.insert(obj);
            } else {
                ipData.setCreateTime(new Date());
                ipData.setData(SimpleCodeTool.decryptBase64(JSON.toJSONString(jsonStr)));
                assetIpDataMapper.updateById(ipData);
            }
        } catch (Exception e) {
            log.error(e.getMessage(), e);
        }
    }
}
