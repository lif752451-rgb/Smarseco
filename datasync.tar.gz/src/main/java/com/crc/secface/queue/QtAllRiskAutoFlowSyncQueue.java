package com.crc.secface.queue;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;
import com.baomidou.mybatisplus.core.conditions.query.LambdaQueryWrapper;
import com.crc.common.enums.ScanTypeEnums;
import com.crc.common.enums.ScannerEnums;
import com.crc.common.utils.DataUtils;
import com.crc.common.utils.JsonUtils;
import com.crc.common.utils.MyTheadUtils;
import com.crc.scanner.tool.FlowUtils;
import com.crc.secface.config.GetSpringBean;
import com.crc.secface.domain.VulnProcessForm;
import com.crc.secface.domain.vo.AllRiskVo;
import com.crc.secface.mapper.CommonMapper;
import com.crc.secface.mapper.VulnProcessFormMapper;
import com.crc.sync.config.SyncSecConfigLoad;
import com.crc.sync.config.SyncSecConstants;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;

import java.util.List;
import java.util.concurrent.ArrayBlockingQueue;

/**
 * 青藤全量漏洞同步处理逻辑
 *
 * @author YUYUHANG5
 */
@Slf4j
public class QtAllRiskAutoFlowSyncQueue extends Thread {

    public static final ArrayBlockingQueue<AllRiskVo> vulFlowQueue = new ArrayBlockingQueue<>(10000);

    @Override
    public void run() {
        log.info("QtAllRiskAutoFlowSyncQueue推送");
        while (true) {
            if (vulFlowQueue.isEmpty()) {
                MyTheadUtils.sleepBySec(1);
            } else {
                while (!vulFlowQueue.isEmpty()) {
                    try {
                        AllRiskVo vo = vulFlowQueue.poll();
                        try {
                            procData(vo);
                        } catch (Exception e) {
                            log.error(e.getMessage(), e);
                        }
                        MyTheadUtils.sleep(10);
                    } catch (Exception e) {
                        log.error(e.getMessage(), e);
                    }
                }
            }
        }
    }

    public static void flowToQueue(String agentId, String action, String msg) {
        if (StringUtils.isBlank(agentId)) {
            return;
        }
        try {
            VulnProcessFormMapper vulnProcessFormMapper = GetSpringBean.getBean(VulnProcessFormMapper.class);
            LambdaQueryWrapper<VulnProcessForm> qw = new LambdaQueryWrapper<>();
            qw.eq(VulnProcessForm::getAgentId, agentId);
            // 全量漏洞修复时，无须关注漏洞状态
            if (!"allRiskPass".equals(action)) {
                qw.eq(VulnProcessForm::getStatus, 0);
            }
            qw.eq(VulnProcessForm::getSource, ScannerEnums.QINGTENG_SCANNER.getCode());
            qw.eq(VulnProcessForm::getCategory, ScanTypeEnums.HOST_SCAN.getCode());
            List<VulnProcessForm> list = vulnProcessFormMapper.selectList(qw);
            log.info("QtAllRiskAutoFlowSyncQueue-agentId :{},flowToQueue vulProcessForm list :{}", agentId, list.size());
            for (VulnProcessForm form : list) {
                flowToQueue(form, action, msg);
            }
        } catch (Exception e) {
            log.error(e.getMessage(), e);
        }
    }

    public static void flowToQueue(VulnProcessForm form, String action, String msg) {
        //工单状态（1.待处置，2.待审核，3.已归档，4.复查中）
        CommonMapper commonMapper = GetSpringBean.getBean(CommonMapper.class);
        try {
            List<JSONObject> list = commonMapper.query("select b.work_order_state from tb_vuln_process_form v inner join tb_vuln_process_handle_business b on v.code = b.vuln_code and b.del_flag = '0' where v.id =  '" + form.getId() + "'  order by b.create_time desc");
            String workStatus = "";
            if (list != null && list.size() > 0) {
                workStatus = JsonUtils.getStr(list.get(0), "work_order_state");
            }

            if (StringUtils.isBlank(workStatus)) {
                log.info("QtAllRiskAutoFlowSyncQueue-{},{},{}在工单找不到漏洞，不推送自动单据处理。", form.getCode(), form.getIp(), form.getAgentId());
                return;
            }
            log.info("QtAllRiskAutoFlowSyncQueue-{},{},{},{}在工单找到漏洞，开始推送自动关单。工单状态（1.待处置，2.待审核，3.已归档，4.复查中），当前：{}", form.getCode(), form.getIp(), action, form.getAgentId(), workStatus);

            // 构建插入对象信息
            AllRiskVo vo = new AllRiskVo();
            vo.setAction(action);
            vo.setVulCode(form.getCode());
            vo.setIp(form.getIp());
            vo.setAgentId(form.getAgentId());
            vo.setMsg(msg);
            switch (action) {
                //全量同步通过
                case "allRiskPass":
                    // 复查通过
                case "reviewPass":
                    // 工单状态（1.待处置，2.待审核，3.已归档，4.复查中）
                    if (DataUtils.equalsAny(workStatus, "1", "2", "4")) {
                        vulFlowQueue.offer(vo);
                    }
                    break;
                //全量同步不通过
                case "allRiskReject":
                    // 开启单据(已归档，复查中)-带处置状态
                    if (DataUtils.equalsAny(workStatus, "3", "4")) {
                        vulFlowQueue.offer(vo);
                    }
                    break;
                // 复查不通过
                case "reviewReject":
                    if (DataUtils.equalsAny(workStatus, "4")) {
                        vulFlowQueue.offer(vo);
                    }
                    break;
                default:
            }
        } catch (Exception e) {
            log.error(e.getMessage(), e);
        }
    }

    private void procData(AllRiskVo o) {
        try {
            if (o == null || StringUtils.isBlank(o.getVulCode())) {
                return;
            }
            JSONObject request = new JSONObject();
            request.put("vulCode", o.getVulCode());
            request.put("action", o.getAction());
            request.put("msg", o.getMsg());
            // 通过状态判断调用方法
            /**
             * reviewFallback  复查超时
             * allRiskPass 全量同步，关闭
             * allRiskReject 全量同步，恢复
             * reviewReject 复查不通过
             * reviewPass 复查通过
             */
            // 回调调用
            log.info(vulFlowQueue.size() + " -> AllRiskVo:" + JSON.toJSONString(o));
            String ret = FlowUtils.vulCallBack(SyncSecConfigLoad.getRemarkValue(SyncSecConstants.STP_API_URL), request);
            processResult(o, ret);
        } catch (Exception e) {
            log.error(e.getMessage(), e);
        }
    }

    private void processResult(AllRiskVo o, String ret) throws InterruptedException {
        JSONObject jsonObject = JsonUtils.parse(ret);
        if (jsonObject.containsKey("code") && !"200".equals(JsonUtils.getStr(jsonObject, "code"))) {
            // 限流逻辑未启用
            if (JsonUtils.getStr(jsonObject, "msg").contains("限流中")) {
                log.info("QtAllRiskAutoFlowSyncQueue-限流中：{},vulName={}", ret, JSON.toJSONString(o));
                MyTheadUtils.sleepBySec(2);
                vulFlowQueue.put(o);
            } else {
                log.info("QtAllRiskAutoFlowSyncQueue-推送失败：" + ret);
            }
        }
    }

}
