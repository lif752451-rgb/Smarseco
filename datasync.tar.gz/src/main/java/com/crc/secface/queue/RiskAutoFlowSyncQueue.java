package com.crc.secface.queue;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;
import com.baomidou.mybatisplus.core.conditions.query.LambdaQueryWrapper;
import com.crc.common.enums.ScanTypeEnums;
import com.crc.common.enums.ScannerEnums;
import com.crc.common.utils.DataUtils;
import com.crc.common.utils.JsonUtils;
import com.crc.common.utils.MyTheadUtils;
import com.crc.scanner.tool.FlowUtils;
import com.crc.secface.config.GetSpringBean;
import com.crc.secface.domain.VulnProcessForm;
import com.crc.secface.domain.vo.RiskVo;
import com.crc.secface.mapper.CommonMapper;
import com.crc.secface.mapper.VulnProcessFormMapper;
import com.crc.sync.config.SyncSecConfigLoad;
import com.crc.sync.config.SyncSecConstants;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;

import java.util.List;
import java.util.concurrent.ArrayBlockingQueue;

/*
批量发送工单修复
 */

@Slf4j
public class RiskAutoFlowSyncQueue extends Thread {
    public static final ArrayBlockingQueue<RiskVo> vulnFlowQueue = new ArrayBlockingQueue<>(10000);

    @Override
    public void run() {
        log.info("RiskAutoFlowSyncQueue推送");
        while (true) {
            if (vulnFlowQueue.isEmpty()) {
                MyTheadUtils.sleepBySec(1);
            } else {
                while (!vulnFlowQueue.isEmpty()) {
                    try {
                        RiskVo vo = vulnFlowQueue.poll();
                        try {
                            procData(vo);
                        } catch (Exception e) {
                            log.error(e.getMessage(), e);
                        }
                        MyTheadUtils.sleep(10);
                    } catch (Exception e) {
                        log.error(e.getMessage(), e);
                    }
                }
            }
        }
    }

    public static void flowToQueue(String ip, String scannerSource, boolean repair) {
        if (StringUtils.isBlank(ip)) {
            return;
        }
        if (!repair) {
            log.error("只允许修复调用！！" + ip);
            return;
        }
        try {
            VulnProcessFormMapper vulnProcessFormMapper = GetSpringBean.getBean(VulnProcessFormMapper.class);
            LambdaQueryWrapper<VulnProcessForm> qw = new LambdaQueryWrapper<>();
            qw.eq(VulnProcessForm::getIp, ip);
            qw.eq(VulnProcessForm::getStatus, 0);
            qw.eq(VulnProcessForm::getSource, scannerSource);
            qw.eq(VulnProcessForm::getCategory, ScanTypeEnums.HOST_SCAN.getCode());
            List<VulnProcessForm> list = vulnProcessFormMapper.selectList(qw);
            log.info("ip :{},flowToQueue vulnProcessForm list :{}", ip, list.size());
            for (VulnProcessForm form : list) {
                flowToQueue(form, repair);
            }
        } catch (Exception e) {
            log.error(e.getMessage(), e);
        }
    }

    public static void flowToWebQueue(String domain, boolean repair) {
        if (StringUtils.isBlank(domain)) {
            return;
        }
        if (!repair) {
            log.error("只允许修复调用！！" + domain);
            return;
        }
        try {
            VulnProcessFormMapper vulnProcessFormMapper = GetSpringBean.getBean(VulnProcessFormMapper.class);
            LambdaQueryWrapper<VulnProcessForm> qw = new LambdaQueryWrapper<>();
            qw.eq(VulnProcessForm::getDomain, domain);
            qw.eq(VulnProcessForm::getStatus, 0);
            qw.eq(VulnProcessForm::getCategory, ScanTypeEnums.WEB_SCAN.getCode());
            List<VulnProcessForm> list = vulnProcessFormMapper.selectList(qw);
            for (VulnProcessForm form : list) {
                flowToQueue(form, repair);
            }
        } catch (Exception e) {
            log.error(e.getMessage(), e);
        }
    }

    public static void flowToQueue(VulnProcessForm form, boolean repair) {
        //工单状态（1.待处置，2.待审核，3.已归档，4.复查中）
        CommonMapper commonMapper = GetSpringBean.getBean(CommonMapper.class);
        try {
            List<JSONObject> list = commonMapper.query("select b.work_order_state from tb_vuln_process_form v inner join tb_vuln_process_handle_business b on v.code = b.vuln_code and b.del_flag = '0' where v.id =  '" + form.getId() + "'  order by b.create_time desc");
            String workStatus = "";
            if (list != null && list.size() > 0) {
                workStatus = JsonUtils.getStr(list.get(0), "work_order_state");
            }

            if (StringUtils.isBlank(workStatus)) {
                log.info("{},{},在工单找不到漏洞，不推送自动关单。", form.getCode(), form.getIp());
                return;
            }
            log.info("{},{},在工单找到漏洞，开始推送自动关单。工单状态（1.待处置，2.待审核，3.已归档，4.复查中），当前：{}", form.getCode(), form.getIp(), workStatus);
            //工单状态（1.待处置，2.待审核，3.已归档，4.复查中）
            if (repair) {
                if (DataUtils.equalsAny(workStatus, "1", "2", "4")) {
                    RiskVo vo = new RiskVo();
                    vo.setVulnCode(form.getCode());
                    vo.setRepair(repair);
                    vo.setVulnName(form.getVulnName());
                    vo.setIp(form.getIp());
                    vulnFlowQueue.offer(vo);
                }
            } else {
                if (DataUtils.equalsAny(workStatus, "4")) {
                    RiskVo vo = new RiskVo();
                    vo.setVulnCode(form.getCode());
                    vo.setRepair(repair);
                    vo.setVulnName(form.getVulnName());
                    vo.setIp(form.getIp());
                    vulnFlowQueue.offer(vo);
                }
            }
        } catch (Exception e) {
            log.error(e.getMessage(), e);
        }
    }

    private void procData(RiskVo o) {
        try {
            if (o == null || StringUtils.isBlank(o.getVulnCode())) {
                return;
            }
            if (o.isRepair()) {
                log.info(vulnFlowQueue.size() + " -> " + o.getIp() + " 已经修复系统关单：" + o.getVulnName());
                List<String> idList = DataUtils.singleToList(o.getVulnCode());
                if (idList.size() > 0) {
                    //{"msg":"操作成功","code":200}
                    String ret = FlowUtils.repaired(SyncSecConfigLoad.getRemarkValue(SyncSecConstants.STP_API_URL), idList);
                    JSONObject jsonObject = JsonUtils.parse(ret);
                    if (jsonObject.containsKey("code") && "200".equals(JsonUtils.getStr(jsonObject, "code"))) {
                        //操作成功
                    } else {
                        if (JsonUtils.getStr(jsonObject, "msg").contains("限流中")) {
                            log.info("限流中：{},vuln={}", ret, JSON.toJSONString(o));
                            MyTheadUtils.sleepBySec(2);
                            vulnFlowQueue.put(o);
                        } else {
                            log.info("推送失败：" + ret);
                        }
                    }
                }
            }
            if (!o.isRepair()) {
                log.info(vulnFlowQueue.size() + " -> " + o.getIp() + " 未修复系统关单：" + o.getVulnName());
                List<String> idList = DataUtils.singleToList(o.getVulnCode());
                if (idList.size() > 0) {
                    //{"msg":"操作成功","code":200}
                    String ret = FlowUtils.unrepaired(SyncSecConfigLoad.getRemarkValue(SyncSecConstants.STP_API_URL), idList);
                    JSONObject jsonObject = JsonUtils.parse(ret);
                    if (jsonObject.containsKey("code") && "200".equals(JsonUtils.getStr(jsonObject, "code"))) {
                        //操作成功
                    } else {
                        if (JsonUtils.getStr(jsonObject, "msg").contains("限流中")) {
                            log.info("限流中：{},vuln={}", ret, JSON.toJSONString(o));
                            MyTheadUtils.sleepBySec(2);
                            vulnFlowQueue.put(o);
                        } else {
                            log.info("推送失败：" + ret);
                        }
                    }
                }
            }
        } catch (Exception e) {
            log.error(e.getMessage(), e);
        }
    }
}
