package com.crc.secface.queue;

import com.alibaba.fastjson.JSON;
import com.crc.common.enums.AssetSourceEnums;
import com.crc.common.utils.IdGen;
import com.crc.common.utils.IpUtils;
import com.crc.secface.config.GetSpringBean;
import com.crc.secface.domain.QingtengAgent;
import com.crc.secface.mapper.QingtengAgentMapper;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;

import java.util.Date;

@Slf4j
public class CrcRiskAutoDataQueue {
    private static final CrcRiskAutoDataQueue instance = new CrcRiskAutoDataQueue();

    private CrcRiskAutoDataQueue() {

    }

    public static CrcRiskAutoDataQueue getInstance() {
        return instance;
    }

    public void saveQingTengAgent(QingtengAgent qtAgent) {
        if (!IpUtils.isIp(qtAgent.getIp())) {
            log.error("空或非法IP!!" + JSON.toJSONString(qtAgent));
            return;
        }
        if (StringUtils.isBlank(qtAgent.getId())) {
            log.error(qtAgent.getIp() + "agent Id 为空" + JSON.toJSONString(qtAgent));
            return;
        }
        qtAgent.setIsCrcCloud(AssetSourceEnums.QINGTENG_CMDB.getCode());
        QingtengAgentMapper d01AgentMapper = GetSpringBean.getBean(QingtengAgentMapper.class);
        QingtengAgent tmp = d01AgentMapper.selectById(qtAgent.getId());

        if (tmp == null) {
            qtAgent.setCreateTime(new Date());
            d01AgentMapper.insert(qtAgent);
        } else {
            if (StringUtils.isBlank(qtAgent.getOsVersion()) && StringUtils.isNotBlank(tmp.getOsVersion())) {
                qtAgent.setOsVersion(tmp.getOsVersion());
            }
            if (StringUtils.isNotBlank(tmp.getOnlineStatus()) && StringUtils.isNotBlank(qtAgent.getOnlineStatus())) {
                if (StringUtils.isNotBlank(tmp.getLocalIp()) && !tmp.getLocalIp().equals(qtAgent.getLocalIp())) {
                    log.info("CrcRiskAutoDataQueue saveQTAgent oldIp:{},newIp:{},oldLocalIp：{},newLocalIp：{} ,agentId：{}，当前数据异常", tmp.getIp(), qtAgent.getIp(), tmp.getLocalIp(), qtAgent.getLocalIp(), qtAgent.getId());
                }
                qtAgent.setUpdateTime(new Date());
                d01AgentMapper.updateById(qtAgent);
            } else {
                //log.info("{},getInstallTime：{} 时间更新", qtAgent.getIp(), tmp.getInstallTime());
            }
        }
    }

    public void saveQingTengAgentX(String ip, String source) {
        QingtengAgent safeDogAgent = new QingtengAgent();
        safeDogAgent.setIp(ip);
        if (!IpUtils.isIp(safeDogAgent.getIp())) {
            log.error("空或非法IP!!" + JSON.toJSONString(safeDogAgent));
            return;
        }
        QingtengAgentMapper d01AgentMapper = GetSpringBean.getBean(QingtengAgentMapper.class);
        QingtengAgent tmp = d01AgentMapper.getByIp(safeDogAgent.getIp());
        if (tmp == null) {
            safeDogAgent.setId(IdGen.uuid());
            safeDogAgent.setIsCrcCloud(source);
            safeDogAgent.setCreateTime(new Date());
            d01AgentMapper.insert(safeDogAgent);
        }
    }
}
