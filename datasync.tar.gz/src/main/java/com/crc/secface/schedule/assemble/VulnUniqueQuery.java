package com.crc.secface.schedule.assemble;

import cn.hutool.core.util.ReflectUtil;
import com.baomidou.mybatisplus.core.conditions.query.LambdaQueryWrapper;
import com.baomidou.mybatisplus.core.toolkit.Wrappers;
import com.crc.secface.config.GetSpringBean;
import com.crc.secface.domain.VulnProcessDistinctRule;
import com.crc.secface.domain.VulnProcessForm;
import com.crc.secface.mapper.VulnProcessDistinctRuleMapper;
import com.crc.secface.mapper.VulnProcessFormMapper;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;

import java.util.Objects;

import static com.crc.common.constants.Constants.Symbol.COMMA;

@Slf4j
public class VulnUniqueQuery {
    public static boolean isUnique(VulnProcessForm vul) {
        if (validVulnUnique(vul)) {
            log.info("{}命中去重规则，漏洞不入库！", vul.getVulnName());
            return true;
        }
        return false;
    }

    private static boolean validVulnUnique(VulnProcessForm vulnProcessFormReq) {
        if (Objects.isNull(vulnProcessFormReq)) {
            return Boolean.FALSE;
        }
        Integer category = vulnProcessFormReq.getCategory();
        if (category == null) {
            return Boolean.FALSE;
        }
        Boolean isValid = Boolean.FALSE;
        VulnProcessDistinctRuleMapper ruleService = GetSpringBean.getBean(VulnProcessDistinctRuleMapper.class);
        VulnProcessFormMapper vulnProcessFormMapper = GetSpringBean.getBean(VulnProcessFormMapper.class);
        LambdaQueryWrapper<VulnProcessDistinctRule> query = Wrappers.lambdaQuery();
        query.eq(VulnProcessDistinctRule::getCategory, category);
        query.last(" limit 1");
        VulnProcessDistinctRule rule = ruleService.selectOne(query);
        if (Objects.isNull(rule)) {
            return Boolean.FALSE;
        }
        String fields = rule.getFields();
        if (StringUtils.isBlank(fields)) {
            return Boolean.FALSE;
        }
        VulnProcessForm form = new VulnProcessForm();
        form.setCategory(category);
        String[] ruleFields = fields.split(COMMA);
        for (String ruleField : ruleFields) {
            Object fieldValue = ReflectUtil.getFieldValue(vulnProcessFormReq, ruleField);
            ReflectUtil.setFieldValue(form, ruleField, fieldValue);
        }
        VulnProcessForm tmp = vulnProcessFormMapper.getValidVulnUnique(form);
        if (tmp != null) {
            // 存在ip、category、vulnName、cveCode 一致，但是id不同的数据，特殊处理,不排除此数据
            if (tmp.getSource().equals(vulnProcessFormReq.getSource())) {
                log.info("命中去除规则，漏洞数据ip：{},存在id不同的情况，id为：{}，特殊处理不排除", tmp.getIp(), tmp.getId());
            } else {
                log.info("命中去除规则，漏洞数据ip：{}", tmp.getIp());
                isValid = Boolean.TRUE;
            }
        }
        return isValid;
    }
}
