package com.crc.secface.schedule.assemble.host;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONArray;
import com.alibaba.fastjson.JSONObject;
import com.baomidou.mybatisplus.core.conditions.query.LambdaQueryWrapper;
import com.crc.common.code.SimpleCodeTool;
import com.crc.common.enums.ScanStatusEnums;
import com.crc.common.enums.ScanTypeEnums;
import com.crc.common.enums.ScannerEnums;
import com.crc.common.utils.IdGen;
import com.crc.common.utils.JsonUtils;
import com.crc.common.utils.Md5Utils;
import com.crc.scanner.config.AutoAnalyConfig;
import com.crc.scanner.tool.AutoAnalyUtils;
import com.crc.scanner.tool.QingtengUtils;
import com.crc.secface.config.GetSpringBean;
import com.crc.secface.domain.*;
import com.crc.secface.mapper.*;
import com.crc.secface.schedule.assemble.CommonAssemble;
import com.crc.secface.schedule.assemble.WhiteListQuery;
import com.crc.sync.config.SyncSecConfigLoad;
import com.crc.sync.config.SyncSecConstants;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;

import java.util.*;

@Slf4j
public class AutoAnalyAsssemble {

    public static AutoAnalyConfig getAAConfig(Long engineId) {
        EngineEquipmentManagement engine = CommonAssemble.engineMap.get(engineId);
        AutoAnalyConfig qtConfig = new AutoAnalyConfig();
        if (engine == null || engine.getId() == null) {
            return qtConfig;
        }
        qtConfig.setEngineId(engineId);
        qtConfig.setAddress(engine.getEquipmentAddress());
        qtConfig.setKey(engine.getPassword());
        String PASS = qtConfig.getKey().trim();
        try {
            PASS = SimpleCodeTool.decrypt(PASS);
            qtConfig.setKey(PASS);
        } catch (Exception e) {
            log.error(e.getMessage(), e);
        }
        qtConfig.setUserName(engine.getLoginUser());
        return qtConfig;
    }

    public static void addTask() {
        try {
            VulnScanTaskRecordLogMapper taskRecordLogMapper = GetSpringBean.getBean(VulnScanTaskRecordLogMapper.class);
            VulnScanTaskRecordMapper taskRecordMapper = GetSpringBean.getBean(VulnScanTaskRecordMapper.class);
            VulnScanTaskMapper scanTaskMapper = GetSpringBean.getBean(VulnScanTaskMapper.class);
            List<VulnScanTask> list = CommonAssemble.getCheckingScantask(ScannerEnums.AA_SCANNER.getCode(), ScanTypeEnums.HOST_SCAN.getCode(), Arrays.asList(1, 2));
            log.info("需要自动化执行资产扫描任务" + list.size());
            for (VulnScanTask vul : list) {
                try {
                    AutoAnalyConfig scannerInfo = getAAConfig(vul.getEngineId());
                    VulnScanTaskRecord record = taskRecordMapper.getLastRecordByTaskId(vul.getId());
                    if (record == null) {
                        continue;
                    }
                    List<String> ipList = QingtengUtils.getAllHostIp(vul.getScanContentX());
                    if (ipList.size() < 1) {
                        log.error("{}({})任务无法解析出有效IP", vul.getTaskName(), vul.getId());
                        CommonAssemble.startFail(vul, "任务无法解析出有效IP");
                        continue;
                    }
                    String token = AutoAnalyUtils.getToken(scannerInfo);
                    log.info("识别出IP：{}", JSON.toJSONString(ipList));
                    for (String ip : ipList) {
                        LambdaQueryWrapper<VulnScanTaskRecordLog> qlog = new LambdaQueryWrapper<>();
                        qlog.eq(VulnScanTaskRecordLog::getRecordId, record.getId());
                        qlog.eq(VulnScanTaskRecordLog::getIp, ip);
                        if (taskRecordLogMapper.selectCount(qlog) < 1) {
                            String jobId = AutoAnalyUtils.addScanTask(scannerInfo,token, ip, vul.getTaskName());
                            log.info("{} 成功下发任务：{}", vul.getTaskName(), ip);
                            VulnScanTaskRecordLog log = new VulnScanTaskRecordLog();
                            log.setJobId(jobId);
                            log.setIp(ip);
                            log.setTaskId(record.getTaskId());
                            log.setRecordId(record.getId());
                            log.setEngineId(vul.getEngineId());
                            log.setCreateTime(new Date());
                            log.setType(ScannerEnums.AA_SCANNER.getCode());
                            //任务状态(0 未开始 1 执行中 2 执行完成 3 执行失败)
                            log.setScanStatus(1);
                            taskRecordLogMapper.insert(log);
                        } else {
                            log.info("{}{},已在资产执行中", vul.getTaskName(), ip);
                        }
                    }
                    record.setTaskId(vul.getId());
                    record.setScanStartTime(new Date());
                    record.setUpdateTime(new Date());
                    record.setIpTotal((long) ipList.size());
                    taskRecordMapper.updateVulnScanTaskRecord(record);

                    vul.setScanStatus(ScanStatusEnums.SCAN_ING.getCode());
                    vul.setUpdateTime(new Date());
                    scanTaskMapper.updateVulnScanTask(vul);
                } catch (Exception e) {
                    log.error(e.getMessage(), e);
                }
            }
        } catch (Exception e) {
            log.error(e.getMessage(), e);
        }
    }



    public static void getTask() {
        try {
            CommonAssemble.engineMap.forEach((k, v) -> {
                if (ScannerEnums.AA_SCANNER.getCode().equals(v.getEquipmentManufacture())) {
                    getTask(getAAConfig(k));
                }
            });
        } catch (Exception e) {
            log.error(e.getMessage(), e);
        }
    }

    private static void getTask(AutoAnalyConfig scannerInfo) {
        VulnScanTaskRecordLogMapper taskRecordLogMapper = GetSpringBean.getBean(VulnScanTaskRecordLogMapper.class);
        try {
            VulnScanTaskRecordLog q = new VulnScanTaskRecordLog();
            q.setScanStatus(1);//扫描中
            q.setScanType(ScanTypeEnums.HOST_SCAN.getCode());
            q.setEngineName(ScannerEnums.AA_SCANNER.getCode());
            List<VulnScanTaskRecordLog> recordList = taskRecordLogMapper.getAllRecordLogList(q);
            log.info("自动化分析平台资产复查扫描中任务" + recordList.size());
            for (VulnScanTaskRecordLog recordLog : recordList) {
                String token = AutoAnalyUtils.getToken(scannerInfo);
                JSONObject retJson = AutoAnalyUtils.getScanTask(scannerInfo,token, recordLog.getJobId());
                int retStatus = JsonUtils.getInt(retJson, "openvasTaskStatus");
                int openvasProgress = JsonUtils.getInt(retJson, "openvasProgress");
                //状态 0: 队列中 1: 扫描中 2: 完成 3: 失败 4: 取消
                if (retStatus > 0) {
                    try {
                        if (retStatus == 2) {
                            JSONArray taskList = AutoAnalyUtils.getScanReport(scannerInfo,token, recordLog.getJobId());
                            //没有漏洞
                            if (taskList != null && taskList.size() == 0) {
                                //都已经修复
                                repairAllByIp(recordLog.getIp());
                            } else if(taskList != null){
                                //处理漏洞
                                log.info("GetTask定时自动化分析平台获取漏洞数：" + taskList.size());
                                handle(taskList, recordLog);
                            }
                            recordLog.setScanStatus(2);
                        } else if (retStatus == 3 || retStatus == 4) {
                            recordLog.setScanStatus(3);
                            log.info("GetTask 扫描失败/取消@@@@" + recordLog.getIp());
                        }
                        if (openvasProgress < 0) {
                            openvasProgress = 0;
                        }
                        if (retStatus == 2) {
                            openvasProgress = 100;
                        }
                        recordLog.setProgress(openvasProgress);
                        recordLog.setUpdateTime(new Date());
                        taskRecordLogMapper.updateVulnScanTaskRecordLog(recordLog);
                    } catch (Exception e) {
                        log.error(e.getMessage(), e);
                    }
                }
            }
        } catch (Exception e) {
            log.error(e.getMessage(), e);
        }
    }

    public static void handle(JSONArray vuln, VulnScanTaskRecordLog recordLog) {
        VulnProcessFormMapper vulnProcessFormMapper = GetSpringBean.getBean(VulnProcessFormMapper.class);
        AssetMapper assetMapper = GetSpringBean.getBean(AssetMapper.class);
        //原有漏洞查询
        LambdaQueryWrapper<VulnProcessForm> vq = new LambdaQueryWrapper<>();
        String ip = recordLog.getIp();
        vq.eq(VulnProcessForm::getIp, ip);
        vq.eq(VulnProcessForm::getSource, ScannerEnums.AA_SCANNER.getCode());
        vq.eq(VulnProcessForm::getCategory, ScanTypeEnums.HOST_SCAN.getCode());
        List<VulnProcessForm> vulList = vulnProcessFormMapper.selectList(vq);
        List<VulnProcessForm> repairedList = new LinkedList<>();
        List<VulnProcessForm> unrepairedList = new LinkedList<>();
        List<VulnProcessForm> newVulList = new LinkedList<>();
        log.info(ip + " 库存漏洞：" + vulList.size() + " 当前有漏洞：" + vuln.size());
        int newTotal = 0;
        int dropTotal = 0;
        //扫描到漏洞
        for (int b = 0; b < vuln.size(); b++) {
            JSONObject raw = vuln.getJSONObject(b);
            VulnProcessForm curVul = getVulFromJson(raw, recordLog);
            if (curVul == null) {
                dropTotal++;
                continue;
            }
            //白名单
            if (WhiteListQuery.isWhiteList(curVul)) {
                dropTotal++;
                continue;
            }
            newVulList.add(curVul);
            //是否新漏洞
            boolean isnew = true;
            LambdaQueryWrapper<VulnProcessForm> q = new LambdaQueryWrapper<>();
            q.eq(VulnProcessForm::getId, curVul.getId());
            if (vulnProcessFormMapper.selectCount(q) > 0) {
                vulnProcessFormMapper.stillExist(curVul.getId());
                isnew = false;
            }

            if (isnew) {
                //新漏洞
                if (CommonAssemble.saveVul(curVul)) {
                    newTotal++;
                } else {
                    dropTotal++;
                }
            }
        }
        //已修复的漏洞判断
        for (VulnProcessForm oldVul : vulList) {
            boolean isRepair = true;
            for (VulnProcessForm newVul : newVulList) {
                //漏洞名称 节点IP是否相同
                if (newVul.getId().equalsIgnoreCase(oldVul.getId())) {
                    isRepair = false;
                    break;
                }
            }
            //漏洞已修复
            if (isRepair) {
                repairedList.add(oldVul);
            } else {
                //未修复
                unrepairedList.add(oldVul);
            }
        }
        log.info(ip + " @@@@@@@@@@@@库存漏洞：" + vulList.size() + " 丢弃漏洞：" + dropTotal + " 新增漏洞：" + newTotal + " 未修复漏洞：" + unrepairedList.size() + " 修复漏洞：" + repairedList.size());
        if (repairedList.size() > 0) {
            repairedList.forEach((CommonAssemble::repairedVul));
        }
        if (unrepairedList.size() > 0) {
            unrepairedList.forEach((CommonAssemble::unRepairedVul));
        }
    }

    /**
     * 获取漏洞详情
     *
     * @param json      原始
     * @param recordLog Ip
     * @return 漏洞信息
     */
    public static VulnProcessForm getVulFromJson(JSONObject json,  VulnScanTaskRecordLog recordLog) {
        String vulName = JsonUtils.getStr(json, "name");
        if (StringUtils.isBlank(vulName)) {
            return null;
        }
        String desc = JsonUtils.getStr(json, "description") + " " + JsonUtils.getStr(json,"insight");
        String solution = JsonUtils.getStr(json, "solution");
        Date firstCheckDate = JsonUtils.getDate(json, "firstCheckTime");
        Date publicDate = JsonUtils.getDateX(json, "publicDate");
        double riskPoints = JsonUtils.getDouble(json, "severity");
        int level = 0;
        if (riskPoints >= 7) {
            level = 2;
        } else if (riskPoints >= 4) {
            level = 1;
        }
        String filter = SyncSecConfigLoad.getRemarkValue(SyncSecConstants.AA_SYNC_ENABLE);
        try {
            boolean flag = false;
            if (filter != null && filter.contains("=") && filter.contains("level")) {
                String filterLevel = filter.split("=")[1];
                String slevel = JsonUtils.getStr(json, "severity");
                for (String fl : filterLevel.split(",")) {
                    if (StringUtils.isNotBlank(slevel) && slevel.equalsIgnoreCase(fl)) {
                        flag = true;
                        break;
                    }
                }
            } else {
                flag = true;
            }
            if (!flag) {
                return null;
            }
        } catch (Exception e) {
            log.error(e.getMessage(), e);
        }
        //漏洞特征 1：存在EXP 2：存在POC 3：远程执行 4：本地提权 5：内核漏洞
        List<String> feats = new ArrayList<>();
        List<String> cveList = new LinkedList<>();
        List<String> linkList = new LinkedList<>();

        JSONArray refs = json.getJSONArray("refs");
        if (refs != null) {
            for (int i = 0; i < refs.size(); i++) {
                if("cve".equals(refs.getJSONObject(i).getString("refType"))){
                    String val = JsonUtils.getStr(refs.getJSONObject(i), "refId");
                    if (StringUtils.isNotBlank(val)) {
                        cveList.add(val);
                    }
                }else if("url".equals(refs.getJSONObject(i).getString("refType"))){
                    String val = JsonUtils.getStr(refs.getJSONObject(i), "refId");
                    if (StringUtils.isNotBlank(val)) {
                        linkList.add(val);
                    }
                }
            }
        }



        VulnProcessForm vul = new VulnProcessForm();
        vul.setIp(recordLog.getIp());
        vul.setEngineId(String.valueOf(recordLog.getEngineId()));
        //修复影响：0-未知；1-无需重启；2-服务重启；3系统重启 （仅linux）
        vul.setCvss(JsonUtils.getStr(json, "cvss"));
        vul.setVulnName(vulName);
        vul.setCode(String.format("VUL_%s", IdGen.uuid8()));
        vul.setLevel(String.valueOf(level));
        vul.setSource(ScannerEnums.AA_SCANNER.getCode());
        String id = Md5Utils.hash(recordLog.getIp() + "#" + vulName + "#" + String.join(",",cveList) + "#" + vul.getSource());
        vul.setId(id);
        vul.setVulnType("主机漏洞");
        vul.setCategory(ScanTypeEnums.HOST_SCAN.getCode());
        vul.setDescription(desc);
        vul.setSolution(solution);
        vul.setRefLink(String.join(",", linkList));
        vul.setAvailableCondition(JsonUtils.getStr(json, "affected"));
        vul.setCveCode(String.join(",",cveList));
        vul.setValidInfo(JsonUtils.getStr(json, "vuldetect"));
        vul.setAffectApplication(JsonUtils.getStr(json, "appVersion"));
        vul.setCreateTime(new Date());
        vul.setUpdateTime(new Date());
        vul.setFirstTime(firstCheckDate);
        vul.setRecentlyTime(firstCheckDate);
        vul.setPublishTime(publicDate);
        vul.setVulFeatures(String.join(",", feats));
        CommonAssemble.saveVulAssetInfo(vul, recordLog.getIp());
        return vul;
    }

    /**
     * IP全部修复
     *
     * @param ip IP
     */
    public static void repairAllByIp(String ip) {
        try {
            CommonAssemble.repairAll(ip, ScannerEnums.AA_SCANNER.getCode(), ScanTypeEnums.HOST_SCAN.getCode());
        } catch (Exception e) {
            log.error(e.getMessage(), e);
        }
    }
}
