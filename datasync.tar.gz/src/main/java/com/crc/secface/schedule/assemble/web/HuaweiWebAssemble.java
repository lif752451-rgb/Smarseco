package com.crc.secface.schedule.assemble.web;

import com.alibaba.fastjson.JSONArray;
import com.alibaba.fastjson.JSONObject;
import com.baomidou.mybatisplus.core.conditions.query.LambdaQueryWrapper;
import com.baomidou.mybatisplus.core.conditions.update.LambdaUpdateWrapper;
import com.crc.common.code.SimpleCodeTool;
import com.crc.common.enums.ScanStatusEnums;
import com.crc.common.enums.ScanTypeEnums;
import com.crc.common.enums.ScannerEnums;
import com.crc.common.utils.*;
import com.crc.scanner.config.HuaweiConfig;
import com.crc.scanner.tool.CvssUtils;
import com.crc.scanner.tool.HuaweiUtils;
import com.crc.secface.config.GetSpringBean;
import com.crc.secface.domain.*;
import com.crc.secface.domain.vo.WebScanVulnInfos;
import com.crc.secface.domain.vo.WebUrlInfos;
import com.crc.secface.mapper.VulnProcessFormMapper;
import com.crc.secface.mapper.VulnScanTaskMapper;
import com.crc.secface.mapper.VulnScanTaskRecordLogMapper;
import com.crc.secface.mapper.VulnScanTaskRecordMapper;
import com.crc.secface.queue.RiskAutoFlowSyncQueue;
import com.crc.secface.schedule.assemble.CommonAssemble;
import com.crc.secface.schedule.assemble.WhiteListQuery;
import com.crc.sync.config.SyncSecConfigLoad;
import com.crc.sync.config.SyncSecConstants;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;

import java.util.*;

@Slf4j
public class HuaweiWebAssemble {
    public static HuaweiConfig getTrxConfig(Long engineId) {
        EngineEquipmentManagement engine = CommonAssemble.engineMap.get(engineId);
        HuaweiConfig qtConfig = new HuaweiConfig();
        if (engine == null || engine.getId() == null) {
            return qtConfig;
        }
        qtConfig.setEngineId(engineId);
        qtConfig.setAddress(engine.getEquipmentAddress());
        qtConfig.setPassword(engine.getPassword());
        String PASS = qtConfig.getPassword().trim();
        try {
            PASS = SimpleCodeTool.decrypt(PASS);
            qtConfig.setPassword(PASS);
        } catch (Exception e) {
            log.error(e.getMessage(), e);
        }
        qtConfig.setUsername(engine.getLoginUser());
        return qtConfig;
    }


    public static void addTask() {
        try {
            VulnScanTaskRecordMapper taskRecordMapper = GetSpringBean.getBean(VulnScanTaskRecordMapper.class);
            VulnScanTaskRecordLogMapper taskRecordLogMapper = GetSpringBean.getBean(VulnScanTaskRecordLogMapper.class);
            List<VulnScanTask> list = CommonAssemble.getCheckingScantask(ScannerEnums.HUAWEI_SCANNER.getCode(), ScanTypeEnums.WEB_SCAN.getCode(), Arrays.asList(1, 2));
            for (VulnScanTask task : list) {
                try {
                    VulnScanTaskRecord record = taskRecordMapper.getLastRecordByTaskId(task.getId());
                    if (record == null) {
                        continue;
                    }
                    LambdaQueryWrapper<VulnScanTaskRecordLog> qlog = new LambdaQueryWrapper<>();
                    qlog.eq(VulnScanTaskRecordLog::getRecordId, record.getId());
                    qlog.eq(VulnScanTaskRecordLog::getTaskId, task.getId());
                    String scanContent = task.getScanContentX();
                    if (taskRecordLogMapper.selectCount(qlog) > 0) {
                        log.info("{}{},已在执行中", task.getTaskName(), scanContent);
                        continue;
                    }

                    VulnScanTaskRecordLog recordLog = new VulnScanTaskRecordLog();
                    recordLog.setIp(scanContent);
                    recordLog.setTaskId(record.getTaskId());
                    recordLog.setTaskName(task.getTaskName());
                    recordLog.setRecordId(record.getId());
                    recordLog.setEngineId(task.getEngineId());
                    recordLog.setCreateTime(new Date());
                    recordLog.setType(ScannerEnums.HUAWEI_SCANNER.getCode());
                    //任务状态(0 未开始 1 执行中 2 执行完成 3 执行失败)
                    recordLog.setScanStatus(0);
                    HuaweiConfig scannerInfo = getTrxConfig(task.getEngineId());
                    List<String> uuids = new ArrayList<>();
                    if (!StringUtils.isBlank(scanContent)) {
                        //多个地址用英文逗号(,)分隔
                        for (String ipStr : scanContent.split("\n")) {
                            String ip = ipStr.trim();
                            if (!UrlUtils.isValidUrl(ip)) {
                                continue;
                            }
                            uuids.add(ip);
                        }
                    }
                    String id = "";
                    if (uuids.size() < 1) {
                        log.error("创建任务:" + task.getTaskName() + " -> 失败，没有找到真实URL");
                        CommonAssemble.startFail(task, "任务没有找到有效URL");
                        continue;
                    } else {
                        HuaweiUtils.createVulWebTask(scannerInfo, recordLog, uuids);
                    }
                    id = recordLog.getJobId();
                    String taskMsg = "执行成功";


                    if (StringUtils.isNotBlank(id)) {
                        recordLog.setScanStatus(1);
                        recordLog.setJobId(id);
                        recordLog.setResult(taskMsg);
                        taskRecordLogMapper.insert(recordLog);
                    } else {
                        //失败
                        recordLog.setScanStatus(3);
                        taskMsg = "执行失败";
                        recordLog.setResult(taskMsg);
                        taskRecordLogMapper.insert(recordLog);
                        CommonAssemble.startFail(recordLog, taskMsg);
                    }

                    log.info("创建任务:" + task.getTaskName() + " -> " + taskMsg + " 返回ID：" + id);
                    record.setScanResult(taskMsg);
                    record.setScanStatus(1);
                    taskRecordMapper.updateVulnScanTaskRecord(record);
                } catch (Exception e) {
                    log.error(e.getMessage(), e);
                }
            }
        } catch (Exception e) {
            log.error(e.getMessage(), e);
        }
    }

    public static void getTask() {
        VulnScanTaskRecordLogMapper taskRecordLogMapper = GetSpringBean.getBean(VulnScanTaskRecordLogMapper.class);
        VulnScanTaskRecordMapper taskRecordMapper = GetSpringBean.getBean(VulnScanTaskRecordMapper.class);
        VulnScanTaskMapper scanTaskMapper = GetSpringBean.getBean(VulnScanTaskMapper.class);
        try {
            VulnScanTaskRecordLog q = new VulnScanTaskRecordLog();
            q.setScanStatus(1);//扫描中
            q.setScanType(ScanTypeEnums.WEB_SCAN.getCode());
            q.setEngineName(ScannerEnums.HUAWEI_SCANNER.getCode());
            List<VulnScanTaskRecordLog> recordList = taskRecordLogMapper.getAllRecordLogList(q);
            for (VulnScanTaskRecordLog task : recordList) {
                try {
                    HuaweiConfig scannerInfo = getTrxConfig(task.getEngineId());
                    // 扫描任务id
                    ///async/status/?&taskid=xxx&user=xxx&pwd=xxx
                    JSONObject retJson = HuaweiUtils.getTaskStatus(scannerInfo, task.getTaskName(), task.getJobId());
                    /*
                     * {
                     * "code":"1",
                     * "msg":"成功",
                     * "data":{
                     * "machineTotal":2,
                     * "machineCompletions":1,
                     * "status":1
                     */

                    if (retJson != null) {
                        if (retJson.containsKey("status")) {
                            //1-运行中，2-完成，3-停止
                            int istatus = JsonUtils.getInt(retJson, "status");
                            String progress = JsonUtils.getStr(retJson, "progress").replace("%", "");
                            boolean stop = false;
                            if (istatus == 0 || istatus == 1 || istatus == 3 || istatus == 7 || istatus == 8) {
                                //进行中
                            } else if (istatus == 4) {
                                progress = "100";
                            } else {
                                stop = true;
                            }

                            task.setProgress(DataUtils.toInt(progress));
                            int status = 1;
                            if (task.getProgress() == 100) {
                                status = 2;
                            }


                            if (stop) {
                                log.error("任务异常停止:" + task.getTaskName() + " -> " + " 进度：" + progress + ",status=" + istatus);
                                status = 2;
                            } else {
                                log.info("读取任务:" + task.getTaskName() + " -> " + " 进度：" + progress + ",status=" + istatus);
                            }
                            task.setScanStatus(status);
                            taskRecordLogMapper.updateById(task);
                            if (task.getProgress() == 100 && !stop && istatus == 4) {

                                JSONArray retArr = HuaweiUtils.getWebTask(scannerInfo, task.getTaskName(), task.getJobId(), task.getGroupId());
                                if (retArr != null && retArr.size() > 0) {
                                    log.info("解析任务:" + task.getTaskName() + " -> " + " 发现漏洞域名：" + retArr.size() + ",获取漏洞清单");
                                    MyTheadUtils.sleepBySec(3);
                                    for (int i = 0; i < retArr.size(); i++) {
                                        JSONObject host = retArr.getJSONObject(i);
                                        if (!JsonUtils.equalVal(host, "status", "completed")) {
                                            log.error(JsonUtils.getStr(host, "name") + "未扫描完成");
                                            continue;
                                        }
                                        JSONObject detail = host.getJSONObject("vulns");
                                        JSONObject site = host.getJSONObject("site");
                                        String domain = JsonUtils.getStr(site, "domain");
                                        if (StringUtils.isNotBlank(domain) && (domain.toLowerCase().startsWith("http"))) {
                                            domain = UrlUtils.getDomain(domain);
                                        }
                                        int vulcount = JsonUtils.getInt(host, "total");
                                        if (vulcount > 0) {
                                            log.info("解析任务:" + task.getTaskName() + " -> " + " 发现漏洞：" + vulcount + ",等待5分钟，获取漏洞清单");
                                            if (detail.getJSONArray("rules") == null) {
                                                log.info("天融信空数据！！");
                                                log.info(host.toJSONString());
                                            } else {
                                                handle(task.getEngineId(), detail.getJSONArray("rules"), domain);
                                            }
                                        } else {
                                            log.info(domain + "解析任务:" + task.getTaskName() + " -> " + " 未发现漏洞");
                                            //如何判断全部修复
                                            repairAllByDomain(domain);
                                        }
                                    }
                                }
                            }


                            /*
                             * 更新业务段任务进度
                             */
                            try {
                                VulnScanTaskRecord taskRecord = taskRecordMapper.selectById(task.getRecordId());
                                taskRecord.setScanProgress(task.getProgress());
                                if (status == 2) {
                                    taskRecord.setScanEndTime(new Date());
                                    taskRecord.setDuration(DateUtils.getDiffSec(taskRecord.getScanStartTime(), taskRecord.getScanEndTime()));
                                    taskRecord.setScanStatus(2);
                                    taskRecord.setScanResult("扫描完成");
                                }
                                taskRecordMapper.updateVulnScanTaskRecord(taskRecord);

                                VulnScanTask scanTask = new VulnScanTask();
                                scanTask.setId(taskRecord.getTaskId());
                                scanTask.setUpdateTime(new Date());
                                scanTask.setScanProgress(taskRecord.getScanProgress());

                                if (taskRecord.getScanStatus() != null && taskRecord.getScanStatus() > 1) {
                                    scanTask.setScanStatus(ScanStatusEnums.SCAN_FINISH.getCode());
                                }
                                scanTaskMapper.updateVulnScanTask(scanTask);
                            } catch (Exception e) {
                                log.error(e.getMessage(), e);
                            }
                        }
                    }
                } catch (Exception e) {
                    log.error(e.getMessage(), e);
                }
            }
        } catch (Exception e) {
            log.error(e.getMessage(), e);
        }
    }

    private static void handle(Long engineId, JSONArray vuln, String domain) {
        if (StringUtils.isBlank(domain)) {
            log.error("非法域名");
            return;
        }
        domain = UrlUtils.getDomain(domain);
        //原有漏洞查询
        VulnProcessFormMapper vulnProcessFormMapper = GetSpringBean.getBean(VulnProcessFormMapper.class);
        //原有漏洞查询
        LambdaQueryWrapper<VulnProcessForm> vq = new LambdaQueryWrapper<>();
        vq.eq(VulnProcessForm::getSource, ScannerEnums.HUAWEI_SCANNER.getCode());
        vq.eq(VulnProcessForm::getCategory, ScanTypeEnums.WEB_SCAN.getCode());
        vq.eq(VulnProcessForm::getDomain, domain);
        List<VulnProcessForm> vulList = vulnProcessFormMapper.selectList(vq);
        List<VulnProcessForm> repairedList = new LinkedList<>();
        List<VulnProcessForm> unrepairedList = new LinkedList<>();
        List<VulnProcessForm> newVulList = new LinkedList<>();
        log.info(domain + " 库存漏洞：" + vulList.size() + " 当前有漏洞：" + vuln.size());
        int newTotal = 0;
        int dropTotal = 0;
        //扫描到漏洞
        for (Object value : vuln) {

            String vulStr = DataUtils.getStrX(value);
            JSONObject raw = JsonUtils.parse(vulStr);
            if (raw == null || raw.size() < 1) {
                log.error("非法JSON：" + value);
                dropTotal++;
                continue;
            }
            if (JsonUtils.equal(raw, "code", "2")) {
                log.error("无效漏洞：" + value);
                dropTotal++;
                continue;
            }
            VulnProcessForm curVul = getVulFromJson(engineId, raw, domain);
            if (curVul == null) {
                log.error("解析失败：" + value);
                dropTotal++;
                continue;
            }
            //白名单
            if (WhiteListQuery.isWhiteList(curVul)) {
                dropTotal++;
                continue;
            }
            newVulList.add(curVul);
            //是否新漏洞
            boolean isnew = true;
            VulnProcessForm tmp = vulnProcessFormMapper.selectById(curVul.getId());
            if (tmp != null) {
                vulnProcessFormMapper.stillExist(curVul.getId());
                isnew = false;
            }

            if (isnew) {
                //新漏洞
                if (CommonAssemble.saveVul(curVul)) {
                    newTotal++;
                } else {
                    dropTotal++;
                }
            }
        }
        //已修复的漏洞判断
        for (VulnProcessForm oldVul : vulList) {
            boolean isRepair = true;
            for (VulnProcessForm newVul : newVulList) {
                //漏洞名称 节点IP是否相同
                if (newVul.getId().equalsIgnoreCase(oldVul.getId())) {
                    isRepair = false;
                    break;
                }
            }
            //漏洞已修复
            if (isRepair) {
                repairedList.add(oldVul);
            } else {
                //未修复
                unrepairedList.add(oldVul);
            }
        }
        log.info(domain + " @@@@@@@@@@@@库存漏洞：" + vulList.size() + " 丢弃漏洞：" + dropTotal + " 新增漏洞：" + newTotal + " 未修复漏洞：" + unrepairedList.size() + " 修复漏洞：" + repairedList.size());
        if (repairedList.size() > 0) {
            repairedList.forEach((CommonAssemble::repairedVul));
        }
        if (unrepairedList.size() > 0) {
            unrepairedList.forEach((CommonAssemble::unRepairedVul));
        }
        String ip = vulList.stream().findFirst().orElseGet(VulnProcessForm::new).getIp();
        CommonAssemble.sendMsg(vulList, ScannerEnums.HUAWEI_SCANNER.getName(), ScanTypeEnums.WEB_SCAN.getCode(), ip, newTotal, unrepairedList.size(), repairedList.size());
    }

    private static VulnProcessForm getVulFromJson(Long engineId, JSONObject json, String domain) {
        if (json == null || json.size() < 5) {
            return null;
        }
        String vulName = JsonUtils.getStr(json, "name");
        if (StringUtils.isBlank(vulName)) {
            log.error("没有识别漏洞名称" + json.toJSONString());
            return null;
        }

        String desc = JsonUtils.getStr(json, "descr");
//        String solution = JsonUtils.getStr(json, "proposal") + JsonUtils.getStr(json, "seealso");
        Date firstCheckDate = JsonUtils.getDate(json, "time");
        Date publicDate = JsonUtils.getDate(json, "time");
        String vulType = JsonUtils.getStr(json, "groupname");
        JSONArray vl = json.getJSONArray("rvs");
        String solution = JsonUtils.getStr(json, "solution");
        String url = "";
        if (vl != null && vl.size() > 0) {
            JSONObject jsonObject = vl.getJSONObject(0);
            url = JsonUtils.getStr(jsonObject, "url");
        }

        if (!UrlUtils.isValidUrl(url)) {
            log.error("{}非法URL", url);
            return null;
        }

        //--漏洞风险级别。高危漏洞=0，中危漏洞=1，低危漏洞=2，信息漏洞=3
        //我们0:低危, 1:中危, 2:高危, 3:严重
        int level = JsonUtils.getIntX(json, "severity");
        if (level > 2) {
            level = 0;
        } else if (level == 2) {
            level = 1;
        } else if (level == 1) {
            level = 2;
        } else if (level == 0) {
            level = 3;
        } else {
            level = 0;
        }
        String filter = SyncSecConfigLoad.getRemarkValue(SyncSecConstants.HUAWEI_SYNC_ENABLE);
        try {
            boolean flag = false;
            if (filter != null && filter.contains("=") && filter.contains("level")) {
                String filterLevel = filter.split("=")[1];
                String slevel = JsonUtils.getStr(json, "severity");
                for (String fl : filterLevel.split(",")) {
                    if (StringUtils.isNotBlank(slevel) && slevel.equalsIgnoreCase(fl)) {
                        flag = true;
                        break;
                    }
                    if (level == 0 && "1".equalsIgnoreCase(fl)) {
                        flag = true;
                        break;
                    }
                }
            } else {
                flag = true;
            }
            if (!flag) {
                log.error("级别过滤" + level);
                return null;
            }
        } catch (Exception e) {
            log.error(e.getMessage(), e);
        }
        //漏洞特征 1：存在EXP 2：存在POC 3：远程执行 4：本地提权 5：内核漏洞
        List<String> feats = new ArrayList<>();
        if (json.containsKey("hasExp")) {
            if (json.getBoolean("hasExp")) {
                feats.add("1");
            }
        }
        if (json.containsKey("hasPoc")) {
            if (json.getBoolean("hasPoc")) {
                feats.add("2");
            }
        }
        if (json.containsKey("remote")) {
            if (json.getBoolean("remote")) {
                feats.add("3");
            }
        }
        if (json.containsKey("localEscalation")) {
            if (json.getBoolean("localEscalation")) {
                feats.add("4");
            }
        }
        if (json.containsKey("kernel")) {
            if (json.getBoolean("kernel")) {
                feats.add("5");
            }
        }
        String CVE = JsonUtils.getStr(json, "cves");
        String cvss = JsonUtils.getStr(json, "cvss_vector");
        VulnProcessForm vul = new VulnProcessForm();
        vul.setIp(url);
        vul.setEngineId(engineId + "");
        vul.setVulnName(vulName);
        vul.setDomain(domain);
        vul.setCvss(CvssUtils.getScore(cvss));
        vul.setRefLink(JsonUtils.getStr(json, "seealso"));
        vul.setCode(String.format("VUL_%s", IdGen.uuid8()));
        vul.setLevel(level + "");
        vul.setCategory(ScanTypeEnums.WEB_SCAN.getCode());
        vul.setSource(ScannerEnums.HUAWEI_SCANNER.getCode());
        String id = Md5Utils.hash(url + "#" + vulName + "#" + CVE + "#" + vul.getSource());
        vul.setId(id);
        vul.setVulnType(vulType);
        vul.setDescription(desc);
        vul.setSolution(solution);
        vul.setCveCode(CVE);
        vul.setCreateTime(new Date());
        vul.setUpdateTime(new Date());
        vul.setFirstTime(firstCheckDate);
        vul.setRecentlyTime(firstCheckDate);
        vul.setPublishTime(publicDate);
        vul.setVulFeatures(String.join(",", feats));
        vul.setStatus("0");
        return vul;
    }

    private static VulnProcessForm getVulFromJsonXc(Long engineId, WebScanVulnInfos vulnInfos, WebUrlInfos urlInfos) {
        if (vulnInfos == null) {
            return null;
        }
        String vulName = vulnInfos.getName();
        if (StringUtils.isBlank(vulName)) {
            log.error("没有识别漏洞名称");
            return null;
        }

        String desc = vulnInfos.getDescription();
        Date firstCheckDate = DateUtils.parseDate1(vulnInfos.getFindTime());
        Date publicDate = DateUtils.parseDate1(vulnInfos.getFindTime());
        String vulType = "Web漏洞";
        String solution = vulnInfos.getSolution();
        String url = urlInfos.getUrl();

        if (!UrlUtils.isValidUrl(url)) {
            log.error("{}非法URL", url);
            return null;
        }

        //--漏洞风险级别。高危漏洞=0，中危漏洞=1，低危漏洞=2，信息漏洞=3
        //我们0:低危, 1:中危, 2:高危, 3:严重
        int dt = DataUtils.getInt(vulnInfos.getRiskValue());
        int level = 0;
        if (dt < 4) {
            level = 0;
        } else if (dt < 7) {
            level = 1;
        } else {
            level = 2;
        }
        String filter = SyncSecConfigLoad.getRemarkValue(SyncSecConstants.TIANRONGXIN_SYNC_ENABLE);
        try {
            boolean flag = false;
            if (filter != null && filter.contains("=") && filter.contains("level")) {
                String filterLevel = filter.split("=")[1];
                String slevel = (level + 1) + "";
                for (String fl : filterLevel.split(",")) {
                    if (StringUtils.isNotBlank(slevel) && slevel.equalsIgnoreCase(fl)) {
                        flag = true;
                        break;
                    }
                    if (level == 0 && "1".equalsIgnoreCase(fl)) {
                        flag = true;
                        break;
                    }
                }
            } else {
                flag = true;
            }
            if (!flag) {
                log.error("级别过滤" + level);
                return null;
            }
        } catch (Exception e) {
            log.error(e.getMessage(), e);
        }
        //漏洞特征 1：存在EXP 2：存在POC 3：远程执行 4：本地提权 5：内核漏洞
        List<String> feats = new ArrayList<>();
        String CVE = vulnInfos.getCve();
        VulnProcessForm vul = new VulnProcessForm();
        vul.setIp(url);
        vul.setEngineId(engineId + "");
        vul.setVulnName(vulName);
        vul.setDomain(UrlUtils.getDomain(url));
        vul.setCvss(vulnInfos.getCvssv2());
        vul.setRefLink(vulnInfos.getRefer());
        vul.setCode(String.format("VUL_%s", IdGen.uuid8()));
        vul.setLevel(level + "");
        vul.setCategory(ScanTypeEnums.WEB_SCAN.getCode());
        vul.setSource(ScannerEnums.HUAWEI_SCANNER.getCode());
        String id = Md5Utils.hash(url + "#" + vulName + "#" + CVE + "#" + vul.getSource());
        vul.setId(id);
        vul.setVulnType(vulType);
        vul.setDescription(desc);
        vul.setSolution(solution);
        vul.setCveCode(CVE);
        vul.setCreateTime(new Date());
        vul.setUpdateTime(new Date());
        vul.setFirstTime(firstCheckDate);
        vul.setRecentlyTime(firstCheckDate);
        vul.setPublishTime(publicDate);
        vul.setAvailableCondition(urlInfos.getRequest());
        vul.setVulFeatures(String.join(",", feats));
        vul.setStatus("0");
        return vul;
    }

    /**
     * IP全部修复
     *
     * @param domain IP/url
     */
    public static void repairAllByDomain(String domain) {
        try {
            // TODO 建议逻辑后置，未反馈bug，暂不处理
            VulnProcessFormMapper vulnProcessFormMapper = GetSpringBean.getBean(VulnProcessFormMapper.class);
            LambdaUpdateWrapper<VulnProcessForm> uw = new LambdaUpdateWrapper<>();
            uw.eq(VulnProcessForm::getDelFlag, "0");
            uw.eq(VulnProcessForm::getIsPushStatus, "1");
            uw.set(VulnProcessForm::getStatus, "1");
            uw.eq(VulnProcessForm::getSource, ScannerEnums.HUAWEI_SCANNER.getCode());
            uw.eq(VulnProcessForm::getCategory, ScanTypeEnums.WEB_SCAN.getCode());
            uw.eq(VulnProcessForm::getDomain, domain);
            vulnProcessFormMapper.update(null, uw);

            RiskAutoFlowSyncQueue.flowToWebQueue(domain, true);
        } catch (Exception e) {
            log.error(e.getMessage(), e);
        }
    }
}
