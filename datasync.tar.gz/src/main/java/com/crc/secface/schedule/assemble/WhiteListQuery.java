package com.crc.secface.schedule.assemble;

import com.baomidou.mybatisplus.core.conditions.query.LambdaQueryWrapper;
import com.crc.common.utils.DataUtils;
import com.crc.secface.config.GetSpringBean;
import com.crc.secface.domain.VulWhiteList;
import com.crc.secface.domain.VulnProcessForm;
import com.crc.secface.mapper.VulWhiteListMapper;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;

import java.util.Objects;


@Slf4j
public class WhiteListQuery {

    /**
     * 是否白名单
     *
     * @param vul 漏洞信息
     * @return t/f
     */
    public static boolean isWhiteList(VulnProcessForm vul) {
        //白名单 比对
        if (StringUtils.isBlank(vul.getIp()) || StringUtils.isBlank(vul.getVulnName())) {
            return false;
        }
        VulWhiteListMapper vulWhiteListMapper = GetSpringBean.getBean(VulWhiteListMapper.class);
        LambdaQueryWrapper<VulWhiteList> q = new LambdaQueryWrapper<>();
        q.eq(VulWhiteList::getIp, vul.getIp());
        q.eq(VulWhiteList::getVulName, vul.getVulnName());
        q.eq(VulWhiteList::getCategory, vul.getCategory() + "");
        q.orderByDesc(VulWhiteList::getId);
        q.last(" limit 1");
        VulWhiteList c = vulWhiteListMapper.selectOne(q);
        if (c != null && Objects.equals(c.getStatus(), 1)) {
            log.info(String.format("1-命中白名单%s=%s", vul.getIp(), vul.getVulnName()));
            return true;
        }
        /*
         * 转码一次
         */
        String newVulName = DataUtils.convertSpecialChar(vul.getVulnName());
        if (!newVulName.equals(vul.getVulnName())) {
            q.eq(VulWhiteList::getVulName, newVulName);
            q.last(" limit 1");
            c = vulWhiteListMapper.selectOne(q);
            if (c != null && Objects.equals(c.getStatus(), 1)) {
                log.info(String.format("2-命中白名单%s=%s", vul.getIp(), vul.getVulnName()));
                return true;
            }
        }

        return false;
    }

}
