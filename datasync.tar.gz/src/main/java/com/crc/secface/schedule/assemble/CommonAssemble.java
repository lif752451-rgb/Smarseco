package com.crc.secface.schedule.assemble;

import cn.hutool.core.collection.CollUtil;
import cn.hutool.core.date.DateUtil;
import cn.hutool.core.util.StrUtil;
import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;
import com.baomidou.mybatisplus.core.conditions.query.LambdaQueryWrapper;
import com.baomidou.mybatisplus.core.conditions.update.LambdaUpdateWrapper;
import com.baomidou.mybatisplus.core.toolkit.Wrappers;
import com.crc.common.constants.Constants;
import com.crc.common.enums.AssetSourceEnums;
import com.crc.common.enums.CheckStatusEnums;
import com.crc.common.enums.CodeCheckResultEnum;
import com.crc.common.enums.DatabaseEnums;
import com.crc.common.enums.ScanStatusEnums;
import com.crc.common.enums.ScanTypeEnums;
import com.crc.common.enums.ScannerEnums;
import com.crc.common.enums.SysRoleEnum;
import com.crc.common.utils.DataUtils;
import com.crc.common.utils.DateUtils;
import com.crc.common.utils.DictUtil;
import com.crc.common.utils.EncryptUtil;
import com.crc.common.utils.IdGen;
import com.crc.common.utils.IpUtils;
import com.crc.common.utils.JsonUtils;
import com.crc.common.utils.UrlUtils;
import com.crc.common.utils.VersionUtils;
import com.crc.msg.qywx.QyweixinSend;
import com.crc.msg.util.MsgSendUtil;
import com.crc.scanner.tool.QingtengUtils;
import com.crc.secface.config.GetSpringBean;
import com.crc.secface.domain.Asset;
import com.crc.secface.domain.AssetSegement;
import com.crc.secface.domain.BaselineProcessForm;
import com.crc.secface.domain.CodeCheckRecord;
import com.crc.secface.domain.CodeCheckRecordLog;
import com.crc.secface.domain.CodeCheckTask;
import com.crc.secface.domain.EngineEquipmentManagement;
import com.crc.secface.domain.RiskTotal;
import com.crc.secface.domain.SysUser;
import com.crc.secface.domain.VulnProcessForm;
import com.crc.secface.domain.VulnProcessRepairCycle;
import com.crc.secface.domain.VulnProcessReviewTask;
import com.crc.secface.domain.VulnScanTask;
import com.crc.secface.domain.VulnScanTaskOplog;
import com.crc.secface.domain.VulnScanTaskRecord;
import com.crc.secface.domain.VulnScanTaskRecordLog;
import com.crc.secface.domain.vo.AllRiskVo;
import com.crc.secface.domain.vo.ReviewVo;
import com.crc.secface.mapper.AssetMapper;
import com.crc.secface.mapper.BaselineProcessFormMapper;
import com.crc.secface.mapper.CodeCheckRecordLogMapper;
import com.crc.secface.mapper.CodeCheckRecordMapper;
import com.crc.secface.mapper.CodeCheckTaskMapper;
import com.crc.secface.mapper.CommonMapper;
import com.crc.secface.mapper.SysUserMapper;
import com.crc.secface.mapper.VulnProcessFormMapper;
import com.crc.secface.mapper.VulnProcessReviewTaskMapper;
import com.crc.secface.mapper.VulnScanTaskMapper;
import com.crc.secface.mapper.VulnScanTaskOplogMapper;
import com.crc.secface.mapper.VulnScanTaskRecordLogMapper;
import com.crc.secface.mapper.VulnScanTaskRecordMapper;
import com.crc.secface.queue.CrcAssetSyncQueue;
import com.crc.secface.queue.QtAllRiskAutoFlowSyncQueue;
import com.crc.secface.queue.RiskAutoFlowSyncQueue;
import com.crc.sync.net.NewSegmentLoad;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.collections4.CollectionUtils;
import org.apache.commons.lang3.StringUtils;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Calendar;
import java.util.Comparator;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Objects;
import java.util.TreeSet;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.atomic.AtomicInteger;
import java.util.concurrent.atomic.AtomicLong;
import java.util.stream.Collectors;


@Slf4j
public class CommonAssemble {

    /**
     * 引擎清单信息MAP
     */
    public static ConcurrentHashMap<Long, EngineEquipmentManagement> engineMap = new ConcurrentHashMap<>();

    /**
     * 修复截止时间规则
     */
    public static ConcurrentHashMap<Long, VulnProcessRepairCycle> repairCycleMap = new ConcurrentHashMap<>();

    /*
       获取待执行任务
     */
    public static List<VulnScanTask> getCheckingScantask(String engineCode, int scanType, List<Integer> scanStates) {
        try {
            VulnScanTaskMapper scanTaskMapper = GetSpringBean.getBean(VulnScanTaskMapper.class);
            VulnScanTask q = new VulnScanTask();
            q.setEngineName(engineCode);
            q.setScanType(scanType);
            if (scanStates != null && scanStates.size() > 0) {
                q.setScanStates(scanStates);
            }
            List<VulnScanTask> taskList1 = scanTaskMapper.getScanTaskList(q);

            return taskList1.stream()
                    .collect(Collectors.collectingAndThen(Collectors.toCollection(
                            () -> new TreeSet<>(Comparator.comparing(VulnScanTask::getId))), ArrayList::new));
        } catch (Exception e) {
            log.error(e.getMessage());
        }
        return new ArrayList<>();
    }

    /**
     * 获取待执行任务
     */
    public static List<VulnScanTask> getScanTask(List<String> engines, int scanType, List<Integer> scanStates) {
        try {
            VulnScanTaskMapper scanTaskMapper = GetSpringBean.getBean(VulnScanTaskMapper.class);
            VulnScanTask q = new VulnScanTask();
            q.setEquipmentManufactures(engines);
            q.setScanType(scanType);
            if (scanStates != null && scanStates.size() > 0) {
                q.setScanStates(scanStates);
            }
            List<VulnScanTask> taskList1 = scanTaskMapper.getScanTaskList(q);

            return taskList1.stream()
                    .collect(Collectors.collectingAndThen(Collectors.toCollection(
                            () -> new TreeSet<>(Comparator.comparing(VulnScanTask::getId))), ArrayList::new));
        } catch (Exception e) {
            log.error(e.getMessage());
        }
        return new ArrayList<>();
    }


    /**
     * 是否已经停止
     *
     * @param task 任务
     * @return t/f
     */
    public static boolean isStartNow(VulnScanTask task) {
        if (ScanStatusEnums.SCAN_ING.getCode() == task.getScanStatus()) {
            //用户下发立即扫描
            return true;
        }
        boolean startNow = false;

        if (task.getScanPeriod() == 1) {//立即执行
            startNow = true;
        } else if (task.getScanPeriod() == 2) {//定时执行一次
            String dateStr = String.format("%s %s", task.getScanDate(), task.getScanTime());
            Date startDate = DateUtils.parseDate(dateStr, DateUtils.DATE_TIME_FORMAT_STRING2);
            if (startDate == null) {
                log.error("{}定时执行一次,时间错误{}", task.getTaskName(), dateStr);
                return startNow;
            }
            if (startDate.before(new Date())) {
                startNow = true;
            }
        } else if (task.getScanPeriod() == 3) {//每天执行一次
            String dateStr = DateUtils.getDateTimeString(DateUtils.DATE_FORMAT, new Date()) + " " + task.getScanTime();
            Date startDate = DateUtils.parseDate(dateStr, DateUtils.DATE_TIME_FORMAT_STRING2);
            if (startDate == null) {
                log.error("{}每天执行一次,时间错误{}", task.getTaskName(), dateStr);
                return startNow;
            }
            if (startDate.before(new Date())) {
                startNow = true;
            }
        } else if (task.getScanPeriod() == 4) {//每周执行一次
            String weekStr = DateUtils.getWeekStr();
            String dateStr = DateUtils.getDateTimeString(DateUtils.DATE_FORMAT, new Date()) + " " + task.getScanTime();
            Date startDate = DateUtils.parseDate(dateStr, DateUtils.DATE_TIME_FORMAT_STRING2);
            if (startDate == null) {
                log.error("{}每周执行一次,时间错误{}", task.getTaskName(), dateStr);
                return startNow;
            }
            if (startDate.before(new Date()) && weekStr.equals(task.getScanDate())) {
                startNow = true;
            }
        } else if (task.getScanPeriod() == 5) {//每月执行一次
            Calendar calendar = Calendar.getInstance();
            int day = calendar.get(Calendar.DAY_OF_MONTH);
            String dayStr = String.format("%d", day);
            String dateStr = DateUtils.getDateTimeString(DateUtils.DATE_FORMAT, new Date()) + " " + task.getScanTime();
            Date startDate = DateUtils.parseDate(dateStr, DateUtils.DATE_TIME_FORMAT_STRING2);
            if (startDate == null || task.getScanDate() == null) {
                log.error("{}每周执行一次,时间错误{}", task.getTaskName(), dateStr);
                return startNow;
            }
            if (startDate.before(new Date()) && dayStr.equals(task.getScanDate().replace("号", ""))) {
                startNow = true;
            }
        }
        try {
            VulnScanTaskOplogMapper vulnScanTaskOplogMapper = GetSpringBean.getBean(VulnScanTaskOplogMapper.class);
            VulnScanTaskOplog lastOpLog = vulnScanTaskOplogMapper.getLastTaskOpLog(task.getId());
            if (lastOpLog != null) {
                if (ScanStatusEnums.SCAN_ING.getCode() == lastOpLog.getNewStatus() || ScanStatusEnums.SCAN_QUEUE.getCode() == lastOpLog.getNewStatus()) {
                    //用户下发立即扫描
                    log.info("用户{}操作{}立即扫描{}", lastOpLog.getCreateBy(), lastOpLog.getTaskId(), lastOpLog.getNewStatus());
                    try {
                        LambdaUpdateWrapper<VulnScanTaskOplog> qw = new LambdaUpdateWrapper<>();
                        qw.eq(VulnScanTaskOplog::getTaskId, task.getId());
                        vulnScanTaskOplogMapper.delete(qw);
                    } catch (Exception e) {
                        log.error(e.getMessage(), e);
                    }
                    return true;
                }
            }
        } catch (Exception e) {
            log.error(e.getMessage(), e);
        }
        return startNow;
    }

    /**
     * 漏洞入库
     *
     * @param vul 漏洞信息
     */
    public static boolean saveVul(VulnProcessForm vul) {
        if (vul == null) {
            return false;
        }
        if (IpUtils.isIp(vul.getIp())) {
            AssetSegement seg = NewSegmentLoad.getIPSegmentByHalf(vul.getIp());
            if (NewSegmentLoad.FILTER_SEGMENT_FLAG && seg == null) {
                log.error("启用了网段识别 IP 过滤机制，非网段数据不入库sync_sec_config/filter_segment_enable，ip={}，不入库", vul.getIp());
                return false;
            }
        }
        AssetMapper assetMapper = GetSpringBean.getBean(AssetMapper.class);
        if (StringUtils.isBlank(vul.getStatus())) {
            vul.setStatus("0");
        }

        if (StringUtils.isNotBlank(vul.getPassword())) {
            vul.setPassword(EncryptUtil.aesEncrypt(vul.getPassword()));
        }

        if (StringUtils.isNotBlank(vul.getCveCode()) && "null".equalsIgnoreCase(vul.getCveCode())) {
            vul.setCveCode("");
        }


        Asset asset = null;
        if (Objects.equals(vul.getCategory(), ScanTypeEnums.HOST_SCAN.getCode()) || Objects.equals(vul.getCategory(), ScanTypeEnums.WEAK_PASS_SCAN.getCode())) {
            asset = assetMapper.selectAssetByInnerIp(vul.getIp());

        } else if (Objects.equals(vul.getCategory(), ScanTypeEnums.WEB_SCAN.getCode())) {
            LambdaQueryWrapper<Asset> qw = Wrappers.lambdaQuery();
            qw.like(Asset::getDomain, vul.getDomain());
            qw.last(Constants.LIMIT_ONE);
            asset = assetMapper.selectOne(qw);
        }
        if ((asset == null || asset.getAffiliationDeptNodeId() == null) && Objects.equals(vul.getCategory(), ScanTypeEnums.HOST_SCAN.getCode())) {
            if (asset == null) {
                asset = new Asset();
            }
            asset.setInternalIp(vul.getIp());
            AssetSegement rdata = NewSegmentLoad.getIPSegmentByHalf(vul.getIp());
            if (rdata != null) {
                asset.setAreaName(rdata.getAreaName());
                asset.setAreaCustomUuid(rdata.getAreaCustomUuid());
                asset.setAffiliationDeptName(rdata.getAffiliationDeptName());
                asset.setAffiliationDeptNodeId(rdata.getAffiliationDeptNodeId());
                if (asset.getEnvironmentType() == null) {
                    String envType = rdata.getAreaName();
                    if (envType != null) {
                        int type = 1;
                        if (envType.contains("测试")) {
                            type = 2;
                        } else if (envType.contains("灾备")) {
                            type = 3;
                        }
                        asset.setEnvironmentType(type);
                    }
                }
                if (ScannerEnums.CHANGTING_SCANNER.getCode().equalsIgnoreCase(vul.getSource())) {
                    asset.setSource(AssetSourceEnums.CHANGTING_CMDB.getCode());
                } else if (ScannerEnums.D01_SCANNER.getCode().equalsIgnoreCase(vul.getSource()) || ScannerEnums.DCC_SCANNER.getCode().equalsIgnoreCase(vul.getSource())) {
                    asset.setSource(AssetSourceEnums.D01_CMDB.getCode());
                } else if (ScannerEnums.LVMENG_SCANNER.getCode().equalsIgnoreCase(vul.getSource())) {
                    asset.setSource(AssetSourceEnums.LVMENT_CMDB.getCode());
                } else if (ScannerEnums.QINGTENG_SCANNER.getCode().equalsIgnoreCase(vul.getSource())) {
                    asset.setSource(AssetSourceEnums.QINGTENG_CMDB.getCode());
                } else if (ScannerEnums.GOBY_SCANNER.getCode().equalsIgnoreCase(vul.getSource())) {
                    asset.setSource(AssetSourceEnums.GOBY_CMDB.getCode());
                } else if (ScannerEnums.ANHENG_SCANNER.getCode().equalsIgnoreCase(vul.getSource())) {
                    asset.setSource(AssetSourceEnums.ANHENG_CMDB.getCode());
                } else if (ScannerEnums.MO_FANG_SCANNER.getCode().equalsIgnoreCase(vul.getSource())) {
                    asset.setSource(AssetSourceEnums.MO_FANG_CMDB.getCode());
                } else if (ScannerEnums.JIAOTU_SCANNER.getCode().equalsIgnoreCase(vul.getSource())) {
                    asset.setSource(AssetSourceEnums.JIAOTU_CMDB.getCode());
                } else if (ScannerEnums.TIANRONGXIN_SCANNER.getCode().equalsIgnoreCase(vul.getSource())) {
                    asset.setSource(AssetSourceEnums.TIANRONGXIN_CMDB.getCode());
                } else if (ScannerEnums.HUAWEI_SCANNER.getCode().equalsIgnoreCase(vul.getSource())) {
                    asset.setSource(AssetSourceEnums.HUAWEI_CMDB.getCode());
                } else if (ScannerEnums.AA_SCANNER.getCode().equalsIgnoreCase(vul.getSource())) {
                    asset.setSource(AssetSourceEnums.AA_CMDB.getCode());
                } else if (ScannerEnums.TDHX_LF_SCANNER.getCode().equalsIgnoreCase(vul.getSource())) {
                    asset.setSource(AssetSourceEnums.TDHX_LF_CMDB.getCode());
                } else if (ScannerEnums.TDHX_YT_SCANNER.getCode().equalsIgnoreCase(vul.getSource())) {
                    asset.setSource(AssetSourceEnums.TDHX_YT_CMDB.getCode());
                } else if (ScannerEnums.TDHX_TZ_SCANNER.getCode().equalsIgnoreCase(vul.getSource())) {
                    asset.setSource(AssetSourceEnums.TDHX_TZ_CMDB.getCode());
                } else if (ScannerEnums.TDHX_CQ_SCANNER.getCode().equalsIgnoreCase(vul.getSource())) {
                    asset.setSource(AssetSourceEnums.TDHX_CQ_CMDB.getCode());
                }
                //漏洞来源转资产类型 hejs
                CrcAssetSyncQueue.getInstance().saveAsset(asset);
                if (asset.getAffiliationDeptNodeId() != null) {
                    vul.setAffiliationDeptNodeId(asset.getAffiliationDeptNodeId());
                    vul.setAffiliationDeptName(asset.getAffiliationDeptName());
                    vul.setAssetName(asset.getInstance());
                }
            }
        }
        if (asset != null) {
            vul.setAffiliationDeptNodeId(asset.getAffiliationDeptNodeId());
            vul.setAffiliationDeptName(asset.getAffiliationDeptName());
            vul.setAssetName(asset.getInstance());
        }

        vul.setIsSend("0");//是否发送邮件 0：是 1：否
        /*
        设置处置人
         */
        getDealUser(vul);

        /*
           计算修复截止时间
         */
        Asset finalAsset = asset;
        AtomicInteger offset = new AtomicInteger(90);
        for (Long key : repairCycleMap.keySet()) {
            VulnProcessRepairCycle v = repairCycleMap.get(key);
            if (v.getCategory().equalsIgnoreCase(String.valueOf(vul.getCategory()))) {
                //资产等级,可选项：1核心、2重要、3一般
                //漏洞等级 字典：vul_level 0:低危, 漏洞等级 1:中危, 2:⾼危, 3:严重
                String keyAsset = "3";
                if (finalAsset != null) {
                    if (finalAsset.getKeyAsset() != null && finalAsset.getKeyAsset() > 0) {
                        keyAsset = String.valueOf(finalAsset.getKeyAsset());
                    }
                }
                String level = vul.getLevel();
                if (StringUtils.isBlank(level)) {
                    level = "0";
                }
                if (ScanTypeEnums.WEAK_PASS_SCAN.getCode() == vul.getCategory()) {
                    if (keyAsset.equalsIgnoreCase(v.getAssetLevel())) {
                        offset.set(v.getDay());
                        break;
                    }
                } else {
                    if (keyAsset.equalsIgnoreCase(v.getAssetLevel()) && level.equalsIgnoreCase(v.getVulLevel())) {
                        offset.set(v.getDay());
                        break;
                    }
                }
            }
        }
        if (Objects.equals(vul.getCategory(), ScanTypeEnums.WEAK_PASS_SCAN.getCode())) {
            vul.setLevel("2");
        }
        VulnProcessFormMapper vulnProcessFormMapper = GetSpringBean.getBean(VulnProcessFormMapper.class);
        VulnProcessForm tmp = vulnProcessFormMapper.selectById(vul.getId());
        if (tmp == null) {
            try {
                int i = Integer.parseInt(vul.getVulHostInfluence());
                vul.setVulHostInfluence(String.valueOf(i));
            } catch (Exception e) {
                vul.setVulHostInfluence("0");
            }
            if (StringUtils.isBlank(vul.getCreateBy())) {
                vul.setCreateBy("系统");
                vul.setCreateByLabel("系统");
            }
            if (!"1".equalsIgnoreCase(vul.getStatus())) {
                if (VulnUniqueQuery.isUnique(vul)) {
                    return false;
                }
                vul.setStatus("0");
                vul.setDelFlag("0");
                vul.setCreateTime(new Date());
                vul.setUpdateTime(new Date());
                Date repairTime = DateUtils.minusDays(vul.getCreateTime(), offset.get() * -1);
                log.info("{}---{}---{}---insert修复截止时间:{}", vul.getIp(), vul.getVulnName(), offset, DateUtils.getDateTimeString1(repairTime));
                vul.setRepairTime(repairTime);
                vulnProcessFormMapper.insert(vul);
            }
        } else {
            if (StringUtils.isBlank(vul.getStatus())) {
                vul.setStatus(tmp.getStatus());
            }
            LambdaUpdateWrapper<VulnProcessForm> updateWrapper = Wrappers.lambdaUpdate();
            updateWrapper.eq(VulnProcessForm::getId, vul.getId());
            updateWrapper.set(VulnProcessForm::getStatus, vul.getStatus());
            if ("0".equals(vul.getStatus())) {
                updateWrapper.set(VulnProcessForm::getRecentlyTime, new Date());
            }
            updateWrapper.set(VulnProcessForm::getDelFlag, "0");
            updateWrapper.set(VulnProcessForm::getDescription, vul.getDescription());
            updateWrapper.set(VulnProcessForm::getSolution, vul.getSolution());
            if (StringUtils.isNotBlank(vul.getAffectApplication())) {
                updateWrapper.set(VulnProcessForm::getAffectApplication, vul.getAffectApplication());
            }
            // 更新历史数据的部门信息
            updateWrapper.set(VulnProcessForm::getAffiliationDeptNodeId, vul.getAffiliationDeptNodeId());
            updateWrapper.set(VulnProcessForm::getAffiliationDeptName, vul.getAffiliationDeptName());
            updateWrapper.set(VulnProcessForm::getUpdateTime, new Date());
            log.info("{}---{}---update", vul.getIp(), vul.getVulnName());
            vulnProcessFormMapper.update(null, updateWrapper);
        }
        return true;
    }


    /**
     * 漏洞入库
     *
     * @param vul 漏洞信息
     */
    public static boolean saveBaseline(BaselineProcessForm vul) {
        if (vul == null) {
            return false;
        }
        if (IpUtils.isIp(vul.getIp())) {
            AssetSegement seg = NewSegmentLoad.getIPSegmentByHalf(vul.getIp());
            if (NewSegmentLoad.FILTER_SEGMENT_FLAG && seg == null) {
                log.error("启用了网段识别 IP 过滤机制，非网段数据不入库sync_sec_config/filter_segment_enable，ip={}，不入库", vul.getIp());
                return false;
            }
        }
        AssetMapper assetMapper = GetSpringBean.getBean(AssetMapper.class);
        if (StringUtils.isBlank(vul.getStatus())) {
            vul.setStatus("0");
        }

        Asset asset = assetMapper.selectAssetByInnerIp(vul.getIp());
        if ((asset == null || asset.getAffiliationDeptNodeId() == null)) {
            if (asset == null) {
                asset = new Asset();
            }
            asset.setInternalIp(vul.getIp());
            AssetSegement rdata = NewSegmentLoad.getIPSegmentByHalf(vul.getIp());
            if (rdata != null) {
                asset.setAreaName(rdata.getAreaName());
                asset.setAreaCustomUuid(rdata.getAreaCustomUuid());
                asset.setAffiliationDeptName(rdata.getAffiliationDeptName());
                asset.setAffiliationDeptNodeId(rdata.getAffiliationDeptNodeId());
                if (asset.getEnvironmentType() == null) {
                    String envType = rdata.getAreaName();
                    if (envType != null) {
                        int type = 1;
                        if (envType.contains("测试")) {
                            type = 2;
                        } else if (envType.contains("灾备")) {
                            type = 3;
                        }
                        asset.setEnvironmentType(type);
                    }
                }
                if (ScannerEnums.CHANGTING_SCANNER.getCode().equalsIgnoreCase(vul.getSource())) {
                    asset.setSource(AssetSourceEnums.CHANGTING_CMDB.getCode());
                } else if (ScannerEnums.D01_SCANNER.getCode().equalsIgnoreCase(vul.getSource()) || ScannerEnums.DCC_SCANNER.getCode().equalsIgnoreCase(vul.getSource())) {
                    asset.setSource(AssetSourceEnums.D01_CMDB.getCode());
                } else if (ScannerEnums.LVMENG_SCANNER.getCode().equalsIgnoreCase(vul.getSource())) {
                    asset.setSource(AssetSourceEnums.LVMENT_CMDB.getCode());
                } else if (ScannerEnums.QINGTENG_SCANNER.getCode().equalsIgnoreCase(vul.getSource())) {
                    asset.setSource(AssetSourceEnums.QINGTENG_CMDB.getCode());
                } else if (ScannerEnums.GOBY_SCANNER.getCode().equalsIgnoreCase(vul.getSource())) {
                    asset.setSource(AssetSourceEnums.GOBY_CMDB.getCode());
                } else if (ScannerEnums.ANHENG_SCANNER.getCode().equalsIgnoreCase(vul.getSource())) {
                    asset.setSource(AssetSourceEnums.ANHENG_CMDB.getCode());
                } else if (ScannerEnums.MO_FANG_SCANNER.getCode().equalsIgnoreCase(vul.getSource())) {
                    asset.setSource(AssetSourceEnums.MO_FANG_CMDB.getCode());
                } else if (ScannerEnums.JIAOTU_SCANNER.getCode().equalsIgnoreCase(vul.getSource())) {
                    asset.setSource(AssetSourceEnums.JIAOTU_CMDB.getCode());
                } else if (ScannerEnums.TIANRONGXIN_SCANNER.getCode().equalsIgnoreCase(vul.getSource())) {
                    asset.setSource(AssetSourceEnums.TIANRONGXIN_CMDB.getCode());
                } else if (ScannerEnums.HUAWEI_SCANNER.getCode().equalsIgnoreCase(vul.getSource())) {
                    asset.setSource(AssetSourceEnums.HUAWEI_CMDB.getCode());
                } else if (ScannerEnums.AA_SCANNER.getCode().equalsIgnoreCase(vul.getSource())) {
                    asset.setSource(AssetSourceEnums.AA_CMDB.getCode());
                }
                //漏洞来源转资产类型 hejs
                CrcAssetSyncQueue.getInstance().saveAsset(asset);
                if (asset.getAffiliationDeptNodeId() != null) {
                    vul.setAffiliationDeptNodeId(asset.getAffiliationDeptNodeId());
                    vul.setAffiliationDeptName(asset.getAffiliationDeptName());
                    vul.setAssetName(asset.getInstance());
                }
            }
        }
        if (asset != null) {
            vul.setAffiliationDeptNodeId(asset.getAffiliationDeptNodeId());
            vul.setAffiliationDeptName(asset.getAffiliationDeptName());
            vul.setAssetName(asset.getInstance());
        }

        /*
        设置处置人
         */
        getDealUser(vul);

        /*
           计算修复截止时间
         */
        Asset finalAsset = asset;
        AtomicInteger offset = new AtomicInteger(90);
        for (Long key : repairCycleMap.keySet()) {
            VulnProcessRepairCycle v = repairCycleMap.get(key);
            if (v.getCategory().equalsIgnoreCase(String.valueOf(1))) {
                //资产等级,可选项：1核心、2重要、3一般
                //漏洞等级 字典：vul_level 0:低危, 漏洞等级 1:中危, 2:⾼危, 3:严重
                String keyAsset = "3";
                if (finalAsset.getKeyAsset() != null && finalAsset.getKeyAsset() > 0) {
                    keyAsset = String.valueOf(finalAsset.getKeyAsset());
                }
                String level = vul.getLevel();
                if (StringUtils.isBlank(level)) {
                    level = "0";
                }
                if (keyAsset.equalsIgnoreCase(v.getAssetLevel()) && level.equalsIgnoreCase(v.getVulLevel())) {
                    offset.set(v.getDay());
                    break;
                }
            }
        }

        BaselineProcessFormMapper vulnProcessFormMapper = GetSpringBean.getBean(BaselineProcessFormMapper.class);
        BaselineProcessForm tmp = vulnProcessFormMapper.selectById(vul.getId());
        if (tmp == null) {
            if (StringUtils.isBlank(vul.getCreateBy())) {
                vul.setCreateBy("系统");
                vul.setCreateByLabel("系统");
            }
            if (!"1".equalsIgnoreCase(vul.getStatus())) {
                vul.setStatus("0");
                vul.setDelFlag("0");
                vul.setCreateTime(new Date());
                vul.setUpdateTime(new Date());
                Date repairTime = DateUtils.minusDays(vul.getCreateTime(), offset.get() * -1);
                vul.setRepairTime(repairTime);
                vulnProcessFormMapper.insert(vul);
            }
        } else {
            if (StringUtils.isBlank(vul.getStatus())) {
                vul.setStatus(tmp.getStatus());
            }
            vul.setStatus(tmp.getStatus());
            LambdaUpdateWrapper<BaselineProcessForm> updateWrapper = Wrappers.lambdaUpdate();
            updateWrapper.eq(BaselineProcessForm::getId, vul.getId());
            updateWrapper.set(BaselineProcessForm::getStatus, vul.getStatus());
            if ("0".equals(vul.getStatus())) {
                updateWrapper.set(BaselineProcessForm::getRecentlyTime, new Date());
            }
            updateWrapper.set(BaselineProcessForm::getDelFlag, "0");
            updateWrapper.set(BaselineProcessForm::getCheckContent, vul.getCheckContent());
            updateWrapper.set(BaselineProcessForm::getSolution, vul.getSolution());
            updateWrapper.set(BaselineProcessForm::getUpdateTime, new Date());
            log.info("{}---{}---update", vul.getIp(), vul.getCheckName());
            vulnProcessFormMapper.update(null, updateWrapper);
        }
        return true;
    }

    /**
     * 从资产同步处置人
     *
     * @return 用户账号
     */
    public static boolean getDealUser(VulnProcessForm vulnProcessForm) {
        VulnProcessFormMapper vulnProcessFormMapper = GetSpringBean.getBean(VulnProcessFormMapper.class);
        SysUserMapper sysUserMapper = GetSpringBean.getBean(SysUserMapper.class);
        Long userId = null;
        if (Objects.equals(vulnProcessForm.getCategory(), ScanTypeEnums.HOST_SCAN.getCode()) || Objects.equals(vulnProcessForm.getCategory(), ScanTypeEnums.WEAK_PASS_SCAN.getCode())) {
            // userId = vulnProcessFormMapper.getDealUserByIp(vulnProcessForm.getIp(), SysRoleEnum.VULN_HANDLE.getKey());
            List<JSONObject> userList = vulnProcessFormMapper.getDealUserListByIp(vulnProcessForm.getIp(), SysRoleEnum.VULN_HANDLE.getKey());
            if (CollectionUtils.isNotEmpty(userList)) {
                for (JSONObject jsonObject : userList) {
                    if ("2".equals(jsonObject.getString("type"))) {
                        userId = jsonObject.getLong("user_id");
                        break;
                    } else {
                        userId = jsonObject.getLong("user_id");
                    }
                }
            }
        } else if (Objects.equals(vulnProcessForm.getCategory(), ScanTypeEnums.WEB_SCAN.getCode())) {
            String dbType = "other";
            if (VersionUtils.getDatabase() == DatabaseEnums.MYSQL.getCode()) {
                dbType = "mysql";
            }
            userId = vulnProcessFormMapper.getDealUserByDomain(vulnProcessForm.getDomain(), SysRoleEnum.VULN_HANDLE.getKey(), dbType);
        }

        if (Objects.isNull(userId)) {
            // 查询组织下安全接口人
            if (Objects.nonNull(vulnProcessForm.getAffiliationDeptNodeId())) {
                userId = vulnProcessFormMapper.getDealUserByRoleAndOrganizationId(vulnProcessForm.getAffiliationDeptNodeId(), SysRoleEnum.SECURITY_USER.getKey());
            }
            if (Objects.isNull(userId)) {
                return false;
            }
        }
        SysUser sysUser = sysUserMapper.getByUserId(userId);
        if (Objects.isNull(sysUser)) {
            return false;
        }
        if (StringUtils.isBlank(sysUser.getUserName())) {
            return false;
        }
        String nickName = sysUser.getNickName();
        vulnProcessForm.setHandlePerson(sysUser.getUserName());
        if (StrUtil.isEmpty(nickName)) {
            vulnProcessForm.setHandlePersonLabel(sysUser.getUserName());
        } else {
            vulnProcessForm.setHandlePersonLabel(nickName + Constants.Symbol.ZH_LEFT_PARENTHESES + sysUser.getUserName() + Constants.Symbol.ZH_RIGHT_PARENTHESES);
        }
        log.info("{}-{},设置责任人：{}", vulnProcessForm.getIp(), vulnProcessForm.getVulnName(), vulnProcessForm.getHandlePersonLabel());
        return true;
    }

    /**
     * 从资产同步处置人
     *
     * @return 用户账号
     */
    public static boolean getDealUser(BaselineProcessForm vulnProcessForm) {
        VulnProcessFormMapper vulnProcessFormMapper = GetSpringBean.getBean(VulnProcessFormMapper.class);
        SysUserMapper sysUserMapper = GetSpringBean.getBean(SysUserMapper.class);
        Long userId = vulnProcessFormMapper.getDealUserByIp(vulnProcessForm.getIp(), SysRoleEnum.VULN_HANDLE.getKey());
        if (Objects.isNull(userId)) {
            return false;
        }
        SysUser sysUser = sysUserMapper.getByUserId(userId);
        if (Objects.isNull(sysUser)) {
            return false;
        }
        if (StringUtils.isBlank(sysUser.getUserName())) {
            return false;
        }
        String nickName = sysUser.getNickName();
        vulnProcessForm.setHandlePerson(sysUser.getUserName());
        if (StrUtil.isEmpty(nickName)) {
            vulnProcessForm.setHandlePersonLabel(sysUser.getUserName());
        } else {
            vulnProcessForm.setHandlePersonLabel(nickName + Constants.Symbol.ZH_LEFT_PARENTHESES + sysUser.getUserName() + Constants.Symbol.ZH_RIGHT_PARENTHESES);
        }
        log.info("{}-{},设置责任人：{}", vulnProcessForm.getIp(), vulnProcessForm.getCheckName(), vulnProcessForm.getHandlePersonLabel());
        return true;
    }

    /**
     * 判断任务是否已经停止或删除
     */
    public static boolean isStopNow(VulnScanTaskRecordLog recordLog) {
        try {
            VulnScanTaskMapper scanTaskMapper = GetSpringBean.getBean(VulnScanTaskMapper.class);
            VulnScanTask scanTask = scanTaskMapper.selectById(recordLog.getTaskId());
            if (scanTask.getDelFlag() == 1) {
                log.error("{}({})任务被删除", scanTask.getTaskName(), scanTask.getId());
                startFail(recordLog, "任务被删除");
                return true;
            }
            if (!CommonAssemble.isStartNow(scanTask)) {
                log.info("{}{}还没有到启动时间", scanTask.getTaskName(), scanTask.getId());
                return true;
            }
        } catch (Exception e) {
            log.error(e.getMessage(), e);
        }
        return false;
    }

    public static boolean isStopNow(VulnScanTask scanTask) {
        try {
            if (scanTask == null) {
                return false;
            }
            if (scanTask.getDelFlag() == 1) {
                log.error("{}({})任务被删除", scanTask.getTaskName(), scanTask.getId());
                startFail(scanTask, "任务被删除");
                return true;
            }
            if (!CommonAssemble.isStartNow(scanTask)) {
                log.info("{}{}还没有到启动时间", scanTask.getTaskName(), scanTask.getId());
                return true;
            }
        } catch (Exception e) {
            log.error(e.getMessage(), e);
        }
        return false;
    }

    public static void updateVulData(String id) {
        try {
            VulnProcessFormMapper vulnProcessFormMapper = GetSpringBean.getBean(VulnProcessFormMapper.class);
            // 删除未推送数据及更新状态
            LambdaUpdateWrapper<VulnProcessForm> updateWrapper = new LambdaUpdateWrapper<>();
            updateWrapper.eq(VulnProcessForm::getDelFlag, "0");
            updateWrapper.eq(VulnProcessForm::getId, id);
            updateWrapper.set(VulnProcessForm::getStatus, "1");
            updateWrapper.set(VulnProcessForm::getDelFlag, "1");
            vulnProcessFormMapper.update(null, updateWrapper);
        } catch (Exception e) {
            log.error(e.getMessage(), e);
        }
    }


    /**
     * 扫描失败
     *
     * @param action  动作
     * @param vulCode 漏洞code
     * @param ip      主机ip
     * @param errMsg  错误原因
     */
    public static void startFail(String action, String vulCode, String ip, String errMsg) {
        try {
            AllRiskVo vo = new AllRiskVo();
            vo.setAction(action);
            vo.setVulCode(vulCode);
            vo.setIp(ip);
            vo.setMsg(errMsg);
            if (!QtAllRiskAutoFlowSyncQueue.vulFlowQueue.contains(vo)) {
                QtAllRiskAutoFlowSyncQueue.vulFlowQueue.offer(vo);
            }
        } catch (Exception e) {
            log.error(e.getMessage(), e);
        }
    }

    /**
     * 扫描失败，结束
     *
     * @param task       扫描失败
     * @param scanStatus 任务状态
     * @param errMsg     错误原因
     */
    public static void startFail(VulnScanTask task, Integer scanStatus, String errMsg) {
        try {
            VulnScanTaskRecordMapper taskRecordMapper = GetSpringBean.getBean(VulnScanTaskRecordMapper.class);
            VulnScanTaskMapper scanTaskMapper = GetSpringBean.getBean(VulnScanTaskMapper.class);
            VulnScanTaskRecord record = taskRecordMapper.getLastRecordByTaskId(task.getId());
            if (Objects.nonNull(record)) {
                record.setScanEndTime(new Date());
                record.setDuration(0L);
                record.setScanResult(errMsg);
                record.setUpdateTime(new Date());
                record.setScanStatus(3);//失败
                taskRecordMapper.updateVulnScanTaskRecord(record);
            }

            task.setScanStatus(scanStatus);
            task.setUpdateTime(new Date());
            scanTaskMapper.updateVulnScanTask(task);
        } catch (Exception e) {
            log.error(e.getMessage(), e);
        }
    }

    /**
     * 扫描失败
     *
     * @param task 扫描失败
     */
    public static void startFail(VulnScanTask task, String errMsg) {
        startFail(task, ScanStatusEnums.SCAN_STOP.getCode(), errMsg);
    }

    /**
     * 扫描失败
     *
     * @param recordLog 扫描失败
     */
    public static void startFail(VulnScanTaskRecordLog recordLog, String errMsg) {
        try {
            VulnScanTaskRecordMapper taskRecordMapper = GetSpringBean.getBean(VulnScanTaskRecordMapper.class);
            VulnScanTaskMapper scanTaskMapper = GetSpringBean.getBean(VulnScanTaskMapper.class);
            VulnScanTaskRecord record = taskRecordMapper.getLastRecordByTaskId(recordLog.getTaskId());
            record.setScanStartTime(record.getScanStartTime());
            record.setScanEndTime(new Date());
            record.setDuration(0L);
            record.setScanResult(errMsg);
            record.setUpdateTime(new Date());
            record.setScanStatus(3);//失败
            taskRecordMapper.updateVulnScanTaskRecord(record);

            VulnScanTask task = new VulnScanTask();
            task.setId(recordLog.getTaskId());
            task.setScanStatus(ScanStatusEnums.SCAN_STOP.getCode());
            task.setUpdateTime(new Date());
            scanTaskMapper.updateVulnScanTask(task);
        } catch (Exception e) {
            log.error(e.getMessage(), e);
        }
    }

    /**
     * 扫描失败
     *
     * @param recordLog 扫描失败
     */
    public static void startCodeFail(CodeCheckRecordLog recordLog) {
        try {
            CodeCheckRecordMapper taskRecordMapper = GetSpringBean.getBean(CodeCheckRecordMapper.class);
            CodeCheckTaskMapper scanTaskMapper = GetSpringBean.getBean(CodeCheckTaskMapper.class);
            CodeCheckRecord record = taskRecordMapper.getLastRecordByTaskId(recordLog.getTaskId());

            record.setCheckEndTime(new Date());
            record.setCheckConsuming(0L);
            record.setResult("2");
            taskRecordMapper.updateCodeCheckRecord(record);

            CodeCheckTask task = new CodeCheckTask();
            task.setId(recordLog.getTaskId());
            task.setStatus(CheckStatusEnums.CHECK_FINISH.getCode());
            task.setUpdateTime(new Date());
            scanTaskMapper.updateCodeCheckTask(task);
        } catch (Exception e) {
            log.error(e.getMessage(), e);
        }
    }

    /**
     * 任务进度计算
     */
    public static void syncStatus() {
        VulnScanTaskMapper scanTaskMapper = GetSpringBean.getBean(VulnScanTaskMapper.class);
        VulnScanTaskRecordMapper taskRecordMapper = GetSpringBean.getBean(VulnScanTaskRecordMapper.class);
        VulnScanTaskRecordLogMapper taskRecordLogMapper = GetSpringBean.getBean(VulnScanTaskRecordLogMapper.class);
        try {
            log.info("syncStatus 任务进度分析");
            VulnScanTask q = new VulnScanTask();
            q.setScanStates(Arrays.asList(1, 2));
            List<VulnScanTask> list = scanTaskMapper.getScanTaskList(q);
            log.info("syncStatus 执行中扫描任务：" + list.size());
            for (VulnScanTask task : list) {
                VulnScanTaskRecord taskRecord = taskRecordMapper.getLastRecordByTaskId(task.getId());
                if (taskRecord == null) {
                    continue;
                }
                if (taskRecord.getIpTotal() == null) {
                    taskRecord.setIpTotal(0L);
                }
                AtomicLong total = new AtomicLong(taskRecord.getIpTotal());
                if (total.get() < 1) {
                    engineMap.forEach((k, v) -> {
                        if (Objects.equals(k, task.getEngineId()) && Objects.equals(ScannerEnums.QINGTENG_SCANNER.getCode(), v.getEquipmentManufacture())) {
                            List<String> ipList = QingtengUtils.getAllHostIp(task.getScanContentX());
                            total.set(ipList.size());
                        }
                        if (Objects.equals(k, task.getEngineId()) && Objects.equals(ScannerEnums.AA_SCANNER.getCode(), v.getEquipmentManufacture())) {
                            List<String> ipList = QingtengUtils.getAllHostIp(task.getScanContentX());
                            total.set(ipList.size());
                        }
                    });
                }
                if (total.get() < 1) {
                    total.set(1);
                }
                LambdaQueryWrapper<VulnScanTaskRecordLog> ql = new LambdaQueryWrapper<>();
                ql.gt(VulnScanTaskRecordLog::getScanStatus, 1);
                ql.eq(VulnScanTaskRecordLog::getRecordId, taskRecord.getId());
                long finish = taskRecordLogMapper.selectCount(ql);
                taskRecord.setScanProgress(DataUtils.getPercent(finish, total.get()));
                if (taskRecord.getScanStartTime() == null) {
                    taskRecord.setScanStartTime(taskRecord.getCreateTime());
                }
                taskRecord.setIpTotal(total.get());
                if (finish >= total.get()) {
                    taskRecord.setScanEndTime(new Date());
                    taskRecord.setDuration(DateUtils.getDiffSec(taskRecord.getScanStartTime(), taskRecord.getScanEndTime()));
                    taskRecord.setScanStatus(2);
                    taskRecord.setScanResult("扫描完成");
                }
                taskRecordMapper.updateVulnScanTaskRecord(taskRecord);

                if (taskRecord.getScanStatus() != null && taskRecord.getScanStatus() > 1) {
                    VulnScanTask scanTask = new VulnScanTask();
                    scanTask.setId(taskRecord.getTaskId());
                    scanTask.setUpdateTime(new Date());
                    scanTask.setScanProgress(taskRecord.getScanProgress());
                    scanTask.setScanStatus(ScanStatusEnums.SCAN_FINISH.getCode());
                    scanTaskMapper.updateVulnScanTask(scanTask);
                }
            }
        } catch (Exception e) {
            log.error(e.getMessage(), e);
        }

        try {
            //log.info("已停止或暂停任务分析");
            LambdaQueryWrapper<VulnScanTask> q = new LambdaQueryWrapper<>();
            q.eq(VulnScanTask::getDelFlag, 0);
            q.in(VulnScanTask::getScanStatus, ScanStatusEnums.SCAN_STOP.getCode(), ScanStatusEnums.SCAN_PAUSE.getCode());
            List<VulnScanTask> list = scanTaskMapper.selectList(q);
            log.info("syncStatus 已停止或暂停任务：" + list.size());
            for (VulnScanTask task : list) {
                VulnScanTaskRecord taskRecord = taskRecordMapper.getLastRecordByTaskId(task.getId());
                if (taskRecord != null) {
                    taskRecord.setScanStatus(2);
                    taskRecord.setUpdateTime(new Date());
                    taskRecordMapper.updateById(taskRecord);
                    taskRecordLogMapper.deleteByRecordId(taskRecord.getId());
                }
            }
        } catch (Exception e) {
            log.error(e.getMessage(), e);
        }
    }

    /**
     * 代码检测任务进度计算
     */
    public static void syncCodeStatus() {
        CodeCheckTaskMapper scanTaskMapper = GetSpringBean.getBean(CodeCheckTaskMapper.class);
        CodeCheckRecordMapper taskRecordMapper = GetSpringBean.getBean(CodeCheckRecordMapper.class);
        CodeCheckRecordLogMapper taskRecordLogMapper = GetSpringBean.getBean(CodeCheckRecordLogMapper.class);
        try {
            log.info("任务进度分析");
            LambdaQueryWrapper<CodeCheckTask> q = Wrappers.lambdaQuery();
            q.in(CodeCheckTask::getStatus, Arrays.asList("1", "2", "4", "5"));
            List<CodeCheckTask> list = scanTaskMapper.selectList(q);
            log.info("待执行和执行中扫描任务：" + list.size());
            for (CodeCheckTask task : list) {
                CodeCheckRecord taskRecord = taskRecordMapper.getLastRecordByTaskId(task.getId());
                if (taskRecord == null) {
                    continue;
                }

                LambdaQueryWrapper<CodeCheckRecordLog> ql = new LambdaQueryWrapper<>();
                ql.gt(CodeCheckRecordLog::getScanStatus, 1);
                ql.eq(CodeCheckRecordLog::getRecordId, taskRecord.getId());
                long finish = taskRecordLogMapper.selectCount(ql);
                if (finish >= 1) {
                    taskRecord.setCheckEndTime(new Date());
                    taskRecord.setProgress(100);
                    taskRecord.setCheckConsuming(DateUtils.getDiffSec(taskRecord.getCheckStartTime(), taskRecord.getCheckEndTime()));
                    taskRecord.setResult(CodeCheckResultEnum.SUCCESS.getResult());
                }
                taskRecordMapper.updateCodeCheckRecord(taskRecord);

                if (DataUtils.toInt(taskRecord.getResult()) > 0) {
                    CodeCheckTask scanTask = new CodeCheckTask();
                    scanTask.setId(taskRecord.getTaskId());
                    scanTask.setUpdateTime(new Date());
                    scanTask.setStatus(CheckStatusEnums.CHECK_FINISH.getCode());
                    scanTaskMapper.updateCodeCheckTask(scanTask);
                }
            }
        } catch (Exception e) {
            log.error(e.getMessage(), e);
        }
    }

    public static void syncReview() {
        VulnScanTaskMapper scanTaskMapper = GetSpringBean.getBean(VulnScanTaskMapper.class);
        SysUserMapper sysUserMapper = GetSpringBean.getBean(SysUserMapper.class);
        VulnProcessFormMapper vulnProcessFormMapper = GetSpringBean.getBean(VulnProcessFormMapper.class);
        VulnProcessReviewTaskMapper reviewTaskMapper = GetSpringBean.getBean(VulnProcessReviewTaskMapper.class);

        LambdaQueryWrapper<VulnProcessReviewTask> viewQuery = Wrappers.lambdaQuery();
        viewQuery.eq(VulnProcessReviewTask::getStatus, 0);
        viewQuery.orderByDesc(VulnProcessReviewTask::getId);
        List<VulnProcessReviewTask> allList = reviewTaskMapper.selectList(viewQuery);
        log.info("复查任务数量：" + allList.size());
        HashMap<String, List<ReviewVo>> reviewIpMap = new HashMap<>();
        for (VulnProcessReviewTask rt : allList) {
            LambdaQueryWrapper<VulnProcessForm> q = new LambdaQueryWrapper<>();
            q.eq(VulnProcessForm::getCode, rt.getVulnCode());
            q.last(Constants.LIMIT_ONE);
            VulnProcessForm vul = vulnProcessFormMapper.selectOne(q);

            if (vul == null) {
                LambdaUpdateWrapper<VulnProcessReviewTask> delQuery = new LambdaUpdateWrapper<>();
                delQuery.eq(VulnProcessReviewTask::getVulnCode, rt.getVulnCode());
                delQuery.set(VulnProcessReviewTask::getStatus, 1);
                delQuery.set(VulnProcessReviewTask::getUpdateTime, new Date());
                reviewTaskMapper.update(null, delQuery);
                log.error("找不到漏洞{}", rt.getVulnCode());
                continue;
            }
            // TODO 单个漏洞下发改造起点
            String keys = vul.getIp();
//            if (Objects.equals(vul.getCategory(), 2)) {//web
//                String url = "http://" + vul.getDomain();
//                if (vul.getIp().toLowerCase().startsWith("https")) {
//                    url = "https://" + vul.getDomain();
//                }
//                IpPortVo ipp = UrlUtils.getIpAndPort(vul.getIp());
//                if (ipp.getPort() == 80 || ipp.getPort() == 443) {
//
//                } else {
//                    url = url + ":" + ipp.getPort();
//                }
//                keys = url;
//            }


            if (!reviewIpMap.containsKey(keys)) {
                reviewIpMap.put(keys, new ArrayList<>());
            }
            ReviewVo vo = new ReviewVo();
            vo.setIp(keys);
            vo.setId(rt.getId());
            vo.setVulId(vul.getId());
            vo.setEngineId(DataUtils.toLong(vul.getEngineId()));
            if (vo.getEngineId() < 1) {
                log.error("漏洞{}没有引擎Id", vul.getCode());
                continue;
            }
            vo.setVulCode(vul.getCode());
            vo.setCreateBy(rt.getCreateBy());
            vo.setCategory(vul.getCategory());
            reviewIpMap.get(keys).add(vo);
            log.info("复查任务识别->" + vul.getIp());
        }

        for (String ip : reviewIpMap.keySet()) {
            try {
                List<ReviewVo> reviews = reviewIpMap.get(ip);
                if (reviews != null && reviews.size() > 0) {
                    VulnScanTask vulnScanTask = new VulnScanTask();
                    vulnScanTask.setId(String.format("SCAN_%s", IdGen.uuid8()));
                    Date now = new Date();
                    // 对漏洞任务名称特殊字符转移
                    vulnScanTask.setTaskName(ip + " 漏洞复查");
                    // 处理Reviews数据
                    String codes = reviews.stream().map(ReviewVo::getVulCode).collect(Collectors.joining(","));
                    vulnScanTask.setReviews(codes);
                    ReviewVo review = reviews.get(0);
                    vulnScanTask.setCreateBy(review.getCreateBy());
                    vulnScanTask.setCreateTime(now);
                    if (StringUtils.isBlank(review.getCreateBy())) {
                        review.setCreateBy("super");
                    }
                    if (StringUtils.isNotBlank(review.getCreateBy())) {
                        LambdaQueryWrapper<SysUser> qw = new LambdaQueryWrapper<>();
                        qw.eq(SysUser::getUserName, review.getCreateBy());
                        qw.last(" limit 1");
                        SysUser user = sysUserMapper.selectOne(qw);
                        if (user != null) {
                            vulnScanTask.setCreateByLabel(user.getNickName() + " (" + user.getUserName() + ") ");
                        }
                    }
                    vulnScanTask.setScanContent(ip);
                    vulnScanTask.setScanProgress(0);
                    vulnScanTask.setUpdateBy(review.getCreateBy());
                    vulnScanTask.setUpdateTime(now);
                    vulnScanTask.setContentType(1);
                    vulnScanTask.setScanPeriod(1);
                    vulnScanTask.setScanType(review.getCategory());
                    vulnScanTask.setEngineId(review.getEngineId());
                    if (vulnScanTask.getEngineId() < 1) {
                        VulnProcessForm tmp = vulnProcessFormMapper.getEngineId(ip);
                        if (tmp != null) {
                            vulnScanTask.setEngineId(DataUtils.toLong(tmp.getEngineId()));
                        }
                    }

                    if (vulnScanTask.getEngineId() != null && vulnScanTask.getEngineId() > 0) {
                        vulnScanTask.setScanStatus(ScanStatusEnums.SCAN_QUEUE.getCode());
                        scanTaskMapper.insert(vulnScanTask);
                        log.info("创建复查任务成功：" + ip);
                        for (ReviewVo v : reviews) {
                            LambdaUpdateWrapper<VulnProcessReviewTask> delQuery = new LambdaUpdateWrapper<>();
                            delQuery.eq(VulnProcessReviewTask::getId, v.getId());
                            delQuery.set(VulnProcessReviewTask::getStatus, 1);
                            delQuery.set(VulnProcessReviewTask::getUpdateTime, new Date());
                            reviewTaskMapper.update(null, delQuery);
                        }
                    } else {
                        log.error("{}复查创建任务失败引擎ID为空", ip);
                    }
                }
            } catch (Exception e) {
                log.error(e.getMessage(), e);
            }
        }
    }

    public static void startCodeFail(CodeCheckTask task) {
        try {
            CodeCheckRecordMapper taskRecordMapper = GetSpringBean.getBean(CodeCheckRecordMapper.class);
            CodeCheckTaskMapper scanTaskMapper = GetSpringBean.getBean(CodeCheckTaskMapper.class);
            CodeCheckRecord record = taskRecordMapper.getLastRecordByTaskId(task.getId());
            record.setCheckEndTime(new Date());
            record.setCheckConsuming(0L);
            record.setResult("2");//失败
            taskRecordMapper.updateCodeCheckRecord(record);

            task.setStatus(CheckStatusEnums.CHECK_FINISH.getCode());
            task.setUpdateTime(new Date());
            scanTaskMapper.updateCodeCheckTask(task);
        } catch (Exception e) {
            log.error(e.getMessage(), e);
        }
    }

    public static void repairAll(String ip, String scanner, int scanType) {
        try {
            VulnProcessFormMapper vulnProcessFormMapper = GetSpringBean.getBean(VulnProcessFormMapper.class);
            // 删除未推送数据及更新状态
            LambdaUpdateWrapper<VulnProcessForm> uw1 = new LambdaUpdateWrapper<>();
            uw1.eq(VulnProcessForm::getDelFlag, "0");
            uw1.eq(VulnProcessForm::getIsPushStatus, "0");
            uw1.eq(VulnProcessForm::getSource, scanner);
            uw1.eq(VulnProcessForm::getCategory, scanType);
            uw1.eq(VulnProcessForm::getIp, ip);

            uw1.set(VulnProcessForm::getStatus, "1");
            uw1.set(VulnProcessForm::getDelFlag, "1");
            vulnProcessFormMapper.update(null, uw1);
            // 调用修复漏洞接口，修复数据
            RiskAutoFlowSyncQueue.flowToQueue(ip, scanner, true);
            // 更已推送数据的状态
            LambdaUpdateWrapper<VulnProcessForm> uw = new LambdaUpdateWrapper<>();
            uw.eq(VulnProcessForm::getDelFlag, "0");
            uw.eq(VulnProcessForm::getIsPushStatus, "1");
            uw.eq(VulnProcessForm::getSource, scanner);
            uw.eq(VulnProcessForm::getCategory, scanType);
            uw.eq(VulnProcessForm::getIp, ip);

            uw.set(VulnProcessForm::getStatus, "1");
            vulnProcessFormMapper.update(null, uw);
        } catch (Exception e) {
            log.error(e.getMessage(), e);
        }
    }

    /**
     * 发送消息提醒
     *
     * @param vulList     所有旧漏洞集合
     * @param sourceLabel 来源中文名称
     * @param category    漏洞分类
     * @param ip          ip
     * @param findNew     新增漏洞数量
     * @param unRepaired  未修复漏洞数量
     * @param repair      已修复漏洞数量
     */
    public static void sendMsg(List<VulnProcessForm> vulList, String sourceLabel, int category, String ip, int findNew, int unRepaired, int repair) {
        if (CollUtil.isEmpty(vulList)) {
            return;
        }
        List<String> codeList = vulList.stream().map(VulnProcessForm::getCode).collect(Collectors.toList());
        sendMsgByCodeList(codeList, sourceLabel, category, ip, findNew, unRepaired, repair);
    }

    /**
     * 发送消息提醒
     *
     * @param codeList    所有漏洞集合
     * @param sourceLabel 来源中文名称
     * @param category    漏洞分类
     * @param ip          ip
     * @param findNew     新增漏洞数量
     * @param unRepaired  未修复漏洞数量
     * @param repair      已修复漏洞数量
     */
    public static void sendMsgByCodeList(List<String> codeList, String sourceLabel, int category, String ip, int findNew, int unRepaired, int repair) {
        if (CollUtil.isEmpty(codeList)) {
            return;
        }
        // 漏洞闭环_人工点击复查完成企业微信推送 (0-关闭,1-开启)
        String dictValue = DictUtil.getDictValue("loop_Wecom_notice", "vulArtiReviewWeCom");
        if (!Constants.STR_VALUE_ONE.equals(dictValue)) {
            log.info("漏洞闭环_人工点击复查完成企业微信推送开关未打开,字典类型：loop_Wecom_notice，字典label：vulArtiReviewWeCom");
            return;
        }

        RiskTotal riskTotal = new RiskTotal();
        riskTotal.setIp(ip);
        riskTotal.setNewFind(findNew);
        riskTotal.setRepair(repair);
        riskTotal.setUnrepair(unRepaired);
        VulnProcessReviewTaskMapper taskMapper = GetSpringBean.getBean(VulnProcessReviewTaskMapper.class);
        List<VulnProcessReviewTask> taskList = taskMapper.getReviewByVulCode(codeList);
        if (CollUtil.isEmpty(taskList)) {
            return;
        }
        // 收件人
        String user = taskList.stream().map(VulnProcessReviewTask::getCreateBy).distinct().collect(Collectors.joining(Constants.Symbol.COMMA));
        Date createTime = taskList.stream().sorted(Comparator.comparing(VulnProcessReviewTask::getCreateTime)).findFirst().orElseGet(VulnProcessReviewTask::new).getCreateTime();
        if (createTime == null) {
            createTime = DateUtil.date();
        }
        MsgSendUtil.sendVulMsgNotice(user, sourceLabel, String.valueOf(category), createTime, riskTotal);
    }

    public static void closeRecord() {
        //select * from  tb_vuln_scan_task_record where scan_status < 2 and scan_start_time <  DATE_SUB(NOW(), INTERVAL 1 DAY)
        VulnScanTaskRecordMapper taskRecordMapper = GetSpringBean.getBean(VulnScanTaskRecordMapper.class);
        CommonMapper commonMapper = GetSpringBean.getBean(CommonMapper.class);
        try {
            List<JSONObject> list = commonMapper.query("select * from  tb_vuln_scan_task_record where scan_status < 2 and scan_start_time <  DATE_SUB(NOW(), INTERVAL 1 DAY)");
            log.info("closeRecord 超时Record任务数量:{}", list.size());
            for (JSONObject jsonObject : list) {
                long id = JsonUtils.getLong(jsonObject, "id");
                LambdaUpdateWrapper<VulnScanTaskRecord> uw = Wrappers.lambdaUpdate();
                uw.eq(VulnScanTaskRecord::getId, id);
                uw.set(VulnScanTaskRecord::getScanStatus, 3);
                uw.set(VulnScanTaskRecord::getScanResult, "超时未执行，异常！");
                taskRecordMapper.update(null, uw);
                log.info("closeRecord :{}-超时Record未执行，异常！", id);
            }
        } catch (Exception e) {
            log.error(e.getMessage(), e);
        }

        try {
            VulnScanTaskRecordLogMapper taskRecordLogMapper = GetSpringBean.getBean(VulnScanTaskRecordLogMapper.class);
            List<JSONObject> list = commonMapper.query("select * from  tb_vuln_scan_task_record_log where scan_status < 2 and create_time <  DATE_SUB(NOW(), INTERVAL 1 DAY)");
            log.info("closeRecord 超时RecordLog任务数量:{}", list.size());
            for (JSONObject jsonObject : list) {
                long id = JsonUtils.getLong(jsonObject, "id");
                LambdaUpdateWrapper<VulnScanTaskRecordLog> uw = Wrappers.lambdaUpdate();
                uw.eq(VulnScanTaskRecordLog::getId, id);
                uw.set(VulnScanTaskRecordLog::getScanStatus, 3);
                uw.set(VulnScanTaskRecordLog::getResult, "超时未执行，异常！");
                taskRecordLogMapper.update(null, uw);
                log.info("closeRecord : {}-超时RecordLog未执行，异常！", id);
            }
        } catch (Exception e) {
            log.error(e.getMessage(), e);
        }
    }

    public String pushQyWx(String msg, List<String> userIdList) {
        try {
            List<String> userIds = new ArrayList<>();
            for (String userId : userIdList) {
                if (userId.contains("@")) {
                    userId = userId.split("@")[0];
                }
                userIds.add(userId);
            }
            if (StringUtils.isBlank(msg)) {
                log.error("推送内容为空，不推送飞书");
            }

            if (userIds.size() > 0) {
                QyweixinSend.batchSend(userIds, msg);
            }
            log.info("推送企业微信：" + msg + ",to user:{}", JSON.toJSONString(userIds));
            return "推送成功";
        } catch (Exception e) {
            log.error(e.getMessage(), e);
            log.error("企业微信推送失败");
            return "推送失败";
        }
    }

    public static void unRepairedVul(VulnProcessForm vul) {
        unRepairedVul(vul, false);
    }

    public static void unRepairedVul(VulnProcessForm vul, Boolean isAllRisk) {
        try {
            log.info("unRepairedVul,ip={},vuln_name={}", vul.getIp(), vul.getVulnName());
            VulnProcessFormMapper vulnProcessFormMapper = GetSpringBean.getBean(VulnProcessFormMapper.class);
            LambdaUpdateWrapper<VulnProcessForm> uw = new LambdaUpdateWrapper<>();
            uw.eq(VulnProcessForm::getId, vul.getId());
            uw.set(VulnProcessForm::getStatus, "0");
            uw.set(VulnProcessForm::getRecentlyTime, new Date());
            if (vul.getDescription() != null) {
                uw.set(VulnProcessForm::getDescription, vul.getDescription());
            }
            if (vul.getValidInfo() != null) {
                uw.set(VulnProcessForm::getValidInfo, vul.getValidInfo());
            }
            if (vul.getSolution() != null) {
                uw.set(VulnProcessForm::getSolution, vul.getSolution());
            }
            uw.set(VulnProcessForm::getUpdateTime, new Date());
            /*if (vul.getAffiliationDeptNodeId() != null) {
                uw.set(VulnProcessForm::getAffiliationDeptNodeId, vul.getAffiliationDeptNodeId());
            }
            if (StringUtils.isNotBlank(vul.getAffiliationDeptName())) {
                uw.set(VulnProcessForm::getAffiliationDeptName, vul.getAffiliationDeptName());
            }*/
            // 判断是否存在AgentId
            if (StringUtils.isNotBlank(vul.getAgentId())) {
                uw.set(VulnProcessForm::getAgentId, vul.getAgentId());
            }
            // 直接更新组织数据
            if ("0".equals(vul.getIsPushStatus())) {
                uw.set(VulnProcessForm::getAffiliationDeptNodeId, vul.getAffiliationDeptNodeId());
                uw.set(VulnProcessForm::getAffiliationDeptName, vul.getAffiliationDeptName());
            }
            // 直接更新最新Ip
            if (isAllRisk && StringUtils.isNotBlank(vul.getIp())) {
                uw.set(VulnProcessForm::getIp, vul.getIp());
            }
            uw.set(VulnProcessForm::getDelFlag, "0");
            vulnProcessFormMapper.update(null, uw);
            if (isAllRisk) {
                QtAllRiskAutoFlowSyncQueue.flowToQueue(vul, "allRiskReject", null);
            } else {
                RiskAutoFlowSyncQueue.flowToQueue(vul, false);
            }
        } catch (Exception e) {
            log.error(e.getMessage(), e);
        }
    }

    public static void repairedVul(VulnProcessForm vul) {
        repairedVul(vul, false);
    }

    public static void repairedVul(VulnProcessForm vul, Boolean isAllRisk) {
        try {
            log.info("repairedVul,ip={},vuln_name={}", vul.getIp(), vul.getVulnName());
            VulnProcessFormMapper vulnProcessFormMapper = GetSpringBean.getBean(VulnProcessFormMapper.class);
            LambdaUpdateWrapper<VulnProcessForm> updateWrapper = Wrappers.lambdaUpdate();
            updateWrapper.eq(VulnProcessForm::getId, vul.getId());
            updateWrapper.set(VulnProcessForm::getStatus, "1");
            VulnProcessForm tmp = vulnProcessFormMapper.selectById(vul.getId());
            if (tmp != null) {
                //推送状态 0：未推送 ,数据逻辑删除掉
                if (!"1".equalsIgnoreCase(tmp.getIsPushStatus())) {
                    updateWrapper.set(VulnProcessForm::getDelFlag, "1");
                }
                // 判断是否存在AgentId
                if (StringUtils.isBlank(tmp.getAgentId()) && StringUtils.isNotBlank(vul.getAgentId())) {
                    updateWrapper.set(VulnProcessForm::getAgentId, vul.getAgentId());
                }
                // 判断是否Ip相同
                if (!vul.getIp().equals(tmp.getIp())) {
                    log.info("repairedVul 更新漏洞ip数据,oldIp:{},newIp={}", tmp.getIp(), vul.getIp());
                    updateWrapper.set(VulnProcessForm::getIp, vul.getIp());
                }
            }
            updateWrapper.set(VulnProcessForm::getUpdateTime, new Date());
            vulnProcessFormMapper.update(null, updateWrapper);
            if (isAllRisk) {
                QtAllRiskAutoFlowSyncQueue.flowToQueue(vul, "allRiskPass", null);
            } else {
                RiskAutoFlowSyncQueue.flowToQueue(vul, true);
            }
        } catch (Exception e) {
            log.error(e.getMessage(), e);
        }
    }

    public static void unRepairedBaseline(BaselineProcessForm vul) {
        try {
            log.info("unRepairedBaseline,ip={},vuln_name={}", vul.getIp(), vul.getCheckName());
            BaselineProcessFormMapper vulnProcessFormMapper = GetSpringBean.getBean(BaselineProcessFormMapper.class);
            LambdaUpdateWrapper<BaselineProcessForm> uw = new LambdaUpdateWrapper<>();
            uw.eq(BaselineProcessForm::getId, vul.getId());
            uw.set(BaselineProcessForm::getStatus, "0");
            uw.set(BaselineProcessForm::getRecentlyTime, new Date());
            if (vul.getCheckContent() != null) {
                uw.set(BaselineProcessForm::getCheckContent, vul.getCheckContent());
            }
            if (vul.getSolution() != null) {
                uw.set(BaselineProcessForm::getSolution, vul.getSolution());
            }
            uw.set(BaselineProcessForm::getUpdateTime, new Date());
            if (vul.getAffiliationDeptNodeId() != null) {
                uw.set(BaselineProcessForm::getAffiliationDeptNodeId, vul.getAffiliationDeptNodeId());
            }
            if (vul.getAffiliationDeptNodeId() != null) {
                uw.set(BaselineProcessForm::getAffiliationDeptName, vul.getAffiliationDeptName());
            }
            uw.set(BaselineProcessForm::getDelFlag, "0");
            vulnProcessFormMapper.update(null, uw);
        } catch (Exception e) {
            log.error(e.getMessage(), e);
        }
    }

    public static void repairedBaseline(BaselineProcessForm vul) {
        try {
            log.info("repairedBaseline,ip={},vuln_name={}", vul.getIp(), vul.getCheckName());
            BaselineProcessFormMapper vulnProcessFormMapper = GetSpringBean.getBean(BaselineProcessFormMapper.class);
            LambdaUpdateWrapper<BaselineProcessForm> updateWrapper = Wrappers.lambdaUpdate();
            updateWrapper.eq(BaselineProcessForm::getId, vul.getId());
            updateWrapper.set(BaselineProcessForm::getStatus, "1");
            BaselineProcessForm tmp = vulnProcessFormMapper.selectById(vul.getId());
            if (tmp != null) {
                //推送状态 0：未推送 ,数据逻辑删除掉
                if (!"1".equalsIgnoreCase(tmp.getIsPushStatus())) {
                    updateWrapper.set(BaselineProcessForm::getDelFlag, "1");
                }
            }
            updateWrapper.set(BaselineProcessForm::getUpdateTime, new Date());
            vulnProcessFormMapper.update(null, updateWrapper);
        } catch (Exception e) {
            log.error(e.getMessage(), e);
        }
    }

    public static void saveVulAssetInfo(VulnProcessForm vul, String ip) {
        if (ip != null && vul != null) {
            saveVulAssetInfo(vul, CrcAssetSyncQueue.getInstance().getByIp(ip));
        }
    }

    public static void saveVulAssetInfo(VulnProcessForm vul, Asset asset) {
        if (asset != null && vul != null) {
            try {
                vul.setAffiliationDeptNodeId(asset.getAffiliationDeptNodeId());
                vul.setAffiliationDeptName(asset.getAffiliationDeptName());
                vul.setAssetName(asset.getInstance());
            } catch (Exception e) {
                log.error(e.getMessage(), e);
            }
        }
    }

    public static List<String> getScanUrls(String taskId) {
        List<String> uuids = new ArrayList<>();
        try {
            VulnScanTaskMapper taskMapper = GetSpringBean.getBean(VulnScanTaskMapper.class);
            VulnScanTask task = taskMapper.selectById(taskId);
            if (task == null) {
                return uuids;
            }
            String scanContent = task.getScanContentX();

            if (!StringUtils.isBlank(scanContent)) {
                //多个地址用英文逗号(;)分隔
                for (String ipStr : scanContent.split("\n")) {
                    String ip = ipStr.trim();
                    if (!UrlUtils.isValidUrl(ip)) {
                        continue;
                    }
                    uuids.add(ip);
                }
            }
        } catch (Exception e) {
            log.error(e.getMessage(), e);
        }
        return uuids;
    }
}
