package com.crc.secface.schedule.assemble.host;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONArray;
import com.alibaba.fastjson.JSONObject;
import com.baomidou.mybatisplus.core.conditions.query.LambdaQueryWrapper;
import com.crc.common.code.SimpleCodeTool;
import com.crc.common.enums.AssetSourceEnums;
import com.crc.common.enums.ScanStatusEnums;
import com.crc.common.enums.ScanTypeEnums;
import com.crc.common.enums.ScannerEnums;
import com.crc.common.utils.*;
import com.crc.scanner.config.JtConfig;
import com.crc.scanner.tool.CvssUtils;
import com.crc.scanner.tool.JiaotuUtils;
import com.crc.secface.config.GetSpringBean;
import com.crc.secface.domain.*;
import com.crc.secface.mapper.*;
import com.crc.secface.queue.CrcAssetSyncQueue;
import com.crc.secface.schedule.assemble.CommonAssemble;
import com.crc.secface.schedule.assemble.WhiteListQuery;
import com.crc.sync.cmdb.JiaotuCmdbSync;
import com.crc.sync.config.SyncSecConfigLoad;
import com.crc.sync.config.SyncSecConstants;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;

import java.util.*;

/**
 * Jiaotu 漏洞协同核心逻辑
 */
@Slf4j
public class JiaotuCrackAssemble {
    public static void addTask() {
        try {
            VulnScanTaskRecordMapper taskRecordMapper = GetSpringBean.getBean(VulnScanTaskRecordMapper.class);
            VulnScanTaskRecordLogMapper taskRecordLogMapper = GetSpringBean.getBean(VulnScanTaskRecordLogMapper.class);
            JiaotuAgentMapper jiaotuAgentMapper = GetSpringBean.getBean(JiaotuAgentMapper.class);
            List<VulnScanTask> list = CommonAssemble.getCheckingScantask(ScannerEnums.JIAOTU_SCANNER.getCode(), ScanTypeEnums.WEAK_PASS_SCAN.getCode(), Arrays.asList(1, 2));
            for (VulnScanTask task : list) {
                try {
                    VulnScanTaskRecord record = taskRecordMapper.getLastRecordByTaskId(task.getId());
                    if (record == null) {
                        continue;
                    }
                    JtConfig scannerInfo = getJtConfig(task.getEngineId());
                    LambdaQueryWrapper<VulnScanTaskRecordLog> qlog = new LambdaQueryWrapper<>();
                    qlog.eq(VulnScanTaskRecordLog::getRecordId, record.getId());
                    qlog.eq(VulnScanTaskRecordLog::getTaskId, task.getId());
                    String scanContent = task.getScanContentX();
                    if (taskRecordLogMapper.selectCount(qlog) > 0) {
                        log.info("{}{},已在执行中", task.getTaskName(), scanContent);
                        continue;
                    }

                    VulnScanTaskRecordLog recordLog = new VulnScanTaskRecordLog();
                    recordLog.setIp(scanContent);
                    recordLog.setTaskId(record.getTaskId());
                    recordLog.setTaskName(task.getTaskName());
                    recordLog.setRecordId(record.getId());
                    recordLog.setEngineId(task.getEngineId());
                    recordLog.setCreateTime(new Date());
                    recordLog.setType(ScannerEnums.JIAOTU_SCANNER.getCode());
                    //任务状态(0 未开始 1 执行中 2 执行完成 3 执行失败)
                    recordLog.setScanStatus(0);


                    List<String> uuids = new ArrayList<>();
                    List<String> ips = new ArrayList<>();
                    if (!StringUtils.isBlank(scanContent)) {
                        for (String ipStr : scanContent.split("\n")) {
                            String ip = ipStr.trim();
                            if (!IpUtils.isIp(ip)) {
                                continue;
                            }
                            LambdaQueryWrapper<JiaotuAgent> jq = new LambdaQueryWrapper<>();
                            jq.eq(JiaotuAgent::getIp, ip);
                            jq.last(" limit 1");
                            JiaotuAgent jiaotuAgent = jiaotuAgentMapper.selectOne(jq);
                            String uuid = "";
                            if (jiaotuAgent != null) {
                                uuid = jiaotuAgent.getId();
                            }
                            if (StringUtils.isNotBlank(uuid)) {
                                uuids.add(uuid);
                                ips.add(ip);
                            } else {
                                if ("NGSOC".equalsIgnoreCase(scannerInfo.getVersion())) {
                                    uuid = JiaotuUtils.getAgentUuidByIp(scannerInfo, ip);
                                    if (StringUtils.isNotBlank(uuid)) {
                                        Asset asset = new Asset();
                                        asset.setInternalIp(ip);
                                        asset.setSource(AssetSourceEnums.JIAOTU_CMDB.getCode());
                                        //资产状态，可选项：1在用、2停用、3下架、4库存备用、5故障设备、6已临时关停、7待修、8在修、9闲置、10待报废、11报废、12转交
                                        //1-在线，0-离线
                                        asset.setOperatingStatus(1);
                                        CrcAssetSyncQueue.getInstance().saveAsset(asset);
                                        JiaotuCmdbSync jiaotuCmdbSync = new JiaotuCmdbSync();
                                        jiaotuCmdbSync.saveAgent(ip, uuid);
                                        uuids.add(uuid);
                                        ips.add(ip);
                                    }
                                } else {
                                    JSONObject json = JiaotuUtils.getAgentByIp(scannerInfo, ip);
                                    if (json != null && json.size() > 0) {
                                        Asset asset = new Asset();
                                        asset.setInternalIp(JsonUtils.getStr(json, "intranetIp"));
                                        asset.setInternetIp(JsonUtils.getStr(json, "extranetIp"));
                                        asset.setInternetIp(JsonUtils.getStr(json, "extranetIp"));
                                        asset.setSource(AssetSourceEnums.JIAOTU_CMDB.getCode());
                                        asset.setMacAddress(JsonUtils.getStr(json, "mac"));
                                        asset.setOs(JsonUtils.getStr(json, "operatingSystem"));
                                        //资产状态，可选项：1在用、2停用、3下架、4库存备用、5故障设备、6已临时关停、7待修、8在修、9闲置、10待报废、11报废、12转交
                                        //1-在线，0-离线
                                        asset.setOperatingStatus(1);
                                        CrcAssetSyncQueue.getInstance().saveAsset(asset);
                                        JiaotuCmdbSync jiaotuCmdbSync = new JiaotuCmdbSync();
                                        jiaotuCmdbSync.saveAgent(json);
                                        uuid = JsonUtils.getStr(json, "uuid");
                                        if (StringUtils.isNotBlank(uuid)) {
                                            uuids.add(uuid);
                                            ips.add(ip);
                                        }
                                    }
                                }
                            }
                        }
                    }
                    String id = "";
                    if (uuids.size() < 1) {
                        log.error("创建任务:" + task.getTaskName() + " -> 失败，没有找到对应IP的UUID");
                        CommonAssemble.startFail(task, "任务没有找到对应IP的UUID");
                        continue;
                    } else {
                        id = JiaotuUtils.createCrackTask(scannerInfo, task.getTaskName(), ips);
                    }

                    String taskMsg = "执行成功";


                    if (StringUtils.isNotBlank(id)) {
                        recordLog.setScanStatus(1);
                        recordLog.setJobId(id);
                        recordLog.setUuid(String.join(",", uuids));
                        recordLog.setResult(taskMsg);
                        taskRecordLogMapper.insert(recordLog);
                    } else {
                        //失败
                        recordLog.setScanStatus(3);
                        taskMsg = "执行失败";
                        recordLog.setResult(taskMsg);
                        taskRecordLogMapper.insert(recordLog);
                        CommonAssemble.startFail(recordLog, taskMsg);
                    }

                    log.info("创建任务:" + task.getTaskName() + " -> " + taskMsg + " 返回ID：" + id);
                    record.setScanResult(taskMsg);
                    record.setScanStatus(1);
                    taskRecordMapper.updateVulnScanTaskRecord(record);
                } catch (Exception e) {
                    log.error(e.getMessage(), e);
                }
            }
        } catch (Exception e) {
            log.error(e.getMessage(), e);
        }
    }

    public static JtConfig getJtConfig(Long engineId) {
        EngineEquipmentManagement engine = CommonAssemble.engineMap.get(engineId);
        JtConfig qtConfig = new JtConfig();
        if (engine == null || engine.getId() == null) {
            return qtConfig;
        }
        qtConfig.setEngineId(engineId);
        qtConfig.setVersion(engine.getEquipmentVersion());
        String PASS = engine.getPassword().trim();
        qtConfig.setToken(PASS);
        try {
            PASS = SimpleCodeTool.decrypt(PASS);
            qtConfig.setToken(PASS);
        } catch (Exception e) {
            log.error(e.getMessage(), e);
        }
        qtConfig.setAddress(engine.getEquipmentAddress());
        return qtConfig;
    }

    public static void getTask() {
        VulnScanTaskRecordLogMapper taskRecordLogMapper = GetSpringBean.getBean(VulnScanTaskRecordLogMapper.class);
        JiaotuAgentMapper jiaotuAgentMapper = GetSpringBean.getBean(JiaotuAgentMapper.class);
        VulnScanTaskRecordMapper taskRecordMapper = GetSpringBean.getBean(VulnScanTaskRecordMapper.class);
        VulnScanTaskMapper scanTaskMapper = GetSpringBean.getBean(VulnScanTaskMapper.class);
        try {
            ///kernelApi/kernelScanSrv/seTaskController/getTaskStatus
            VulnScanTaskRecordLog q = new VulnScanTaskRecordLog();
            q.setScanStatus(1);//扫描中
            q.setScanType(ScanTypeEnums.WEAK_PASS_SCAN.getCode());
            q.setEngineName(ScannerEnums.JIAOTU_SCANNER.getCode());
            List<VulnScanTaskRecordLog> recordList = taskRecordLogMapper.getAllRecordLogList(q);
            for (VulnScanTaskRecordLog task : recordList) {
                try {
                    JtConfig scannerInfo = getJtConfig(task.getEngineId());
                    // 扫描任务id
                    JSONObject retJson = JiaotuUtils.getTaskNgsocStatus(scannerInfo, task.getTaskName(), task.getJobId());
                    /*
                     * {
                     * "code":"1",
                     * "msg":"成功",
                     * "data":{
                     * "machineTotal":2,
                     * "machineCompletions":1,
                     * "status":1
                     */
                    if (retJson != null) {
                        if (retJson.containsKey("status")) {
                            //1-运行中，2-完成，3-停止
                            double proc = DataUtils.percentage(JsonUtils.getInt(retJson, "machineCompletions"), JsonUtils.getInt(retJson, "machineCompletions"), 0);
                            if (JsonUtils.equal(retJson, "status", "2") || JsonUtils.equal(retJson, "status", "3")) {
                                proc = 100;
                            }
                            log.info("读取任务:" + task.getTaskName() + " -> " + " 进度：" + proc);
                            task.setProgress((int) proc);
                            int status = 1;
                            if (task.getProgress() == 100) {
                                status = 2;
                            }

                            task.setScanStatus(status);
                            taskRecordLogMapper.updateById(task);


                            if (task.getProgress() == 100) {
                                if (StringUtils.isNotBlank(task.getUuid())) {
                                    for (String uuid : task.getUuid().split(",")) {
                                        LambdaQueryWrapper<JiaotuAgent> jq = new LambdaQueryWrapper<>();
                                        jq.eq(JiaotuAgent::getId, uuid);
                                        jq.last(" limit 1");
                                        JiaotuAgent jiaotuAgent = jiaotuAgentMapper.selectOne(jq);
                                        if (jiaotuAgent == null || StringUtils.isBlank(jiaotuAgent.getIp())) {
                                            log.error("读取任务:" + task.getTaskName() + " -> " + " 找不到对应IP：" + uuid);
                                            continue;
                                        }

                                        JSONArray retArr = JiaotuUtils.getNgsocTask(scannerInfo, task.getTaskName(), task.getJobId(), jiaotuAgent.getIp());
                                        if (retArr != null && retArr.size() > 0) {
                                            log.info("解析任务:" + task.getTaskName() + " -> " + " 发现漏洞：" + retArr.size() + ",等待5分钟，获取漏洞清单");
                                            MyTheadUtils.sleepBySec(60);
                                            handle(task.getEngineId(), retArr, jiaotuAgent.getIp());
                                        } else {
                                            log.info("解析任务:" + task.getTaskName() + " -> " + " 未发现漏洞");
                                            repairAllByIp(jiaotuAgent.getIp());
                                        }

                                    }
                                }
                            }

                            /*
                             * 更新业务段任务进度
                             */
                            try {
                                VulnScanTaskRecord taskRecord = taskRecordMapper.selectById(task.getRecordId());
                                taskRecord.setScanProgress(task.getProgress());
                                if (status == 2) {
                                    taskRecord.setScanEndTime(new Date());
                                    taskRecord.setDuration(DateUtils.getDiffSec(taskRecord.getScanStartTime(), taskRecord.getScanEndTime()));
                                    taskRecord.setScanStatus(2);
                                    taskRecord.setScanResult("扫描完成");
                                }
                                taskRecordMapper.updateVulnScanTaskRecord(taskRecord);

                                VulnScanTask scanTask = new VulnScanTask();
                                scanTask.setId(taskRecord.getTaskId());
                                scanTask.setUpdateTime(new Date());
                                scanTask.setScanProgress(taskRecord.getScanProgress());

                                if (taskRecord.getScanStatus() != null && taskRecord.getScanStatus() > 1) {
                                    scanTask.setScanStatus(ScanStatusEnums.SCAN_FINISH.getCode());
                                }
                                scanTaskMapper.updateVulnScanTask(scanTask);
                            } catch (Exception e) {
                                log.error(e.getMessage(), e);
                            }

                        }
                    }
                } catch (Exception e) {
                    log.error(e.getMessage(), e);
                }
            }
        } catch (Exception e) {
            log.error(e.getMessage(), e);
        }
    }

    private static void handle(Long engineId, JSONArray vuln, String ip) {
        //原有漏洞查询
        VulnProcessFormMapper vulnProcessFormMapper = GetSpringBean.getBean(VulnProcessFormMapper.class);
        AssetMapper assetMapper = GetSpringBean.getBean(AssetMapper.class);
        //原有漏洞查询
        LambdaQueryWrapper<VulnProcessForm> vq = new LambdaQueryWrapper<>();
        vq.eq(VulnProcessForm::getIp, ip);
        vq.eq(VulnProcessForm::getCategory, ScanTypeEnums.WEAK_PASS_SCAN.getCode());
        vq.eq(VulnProcessForm::getSource, ScannerEnums.JIAOTU_SCANNER.getCode());
        List<VulnProcessForm> vulList = vulnProcessFormMapper.selectList(vq);
        List<VulnProcessForm> repairedList = new LinkedList<>();
        List<VulnProcessForm> unrepairedList = new LinkedList<>();
        List<VulnProcessForm> newVulList = new LinkedList<>();
        log.info(ip + " 库存漏洞：" + vulList.size() + " 当前有漏洞：" + vuln.size());
        int newTotal = 0;
        int dropTotal = 0;
        //扫描到漏洞
        for (int i = 0; i < vuln.size(); i++) {
            JSONObject raw = null;
            try {
                raw = vuln.getJSONObject(i);
            } catch (Exception e) {
                raw = JsonUtils.parse(vuln.getString(i));
            }
            if (raw == null || raw.size() < 1) {
                log.error("非法JSON：" + vuln.getString(i));
                dropTotal++;
                continue;
            }
            if (!JsonUtils.equal(raw, "code", "1")) {
                log.error("无效漏洞：" + vuln.getString(i));
                dropTotal++;
                continue;
            }
            if (raw.containsKey("items")) {
                JSONArray items = raw.getJSONArray("items");
                if (items == null) {
                    continue;
                }
                for (int j = 0; j < items.size(); j++) {
                    if(items.getJSONObject(j).containsKey("weakPwd")&&!items.getJSONObject(j).getBoolean("weakPwd")){
                        log.error("无效弱口令：" + items.getString(j));
                        continue;
                    }
                    VulnProcessForm curVul = getVulFromJson(items.getJSONObject(j), ip, engineId);
                    if (curVul == null) {
                        log.error("解析失败：" + vuln.getString(i));
                        dropTotal++;
                        continue;
                    }
                    curVul.setEngineId(String.valueOf(engineId));
                    Asset asset = assetMapper.selectAssetByInnerIp(ip);
                    if (asset == null) {
                        asset = new Asset();
                        asset.setSource(AssetSourceEnums.JIAOTU_CMDB.getCode());
                        asset.setInternalIp(ip);
                        CrcAssetSyncQueue.getInstance().saveAsset(asset);
                    }
                    //白名单
                    if (WhiteListQuery.isWhiteList(curVul)) {
                        dropTotal++;
                        continue;
                    }
                    newVulList.add(curVul);
                    //是否新漏洞
                    boolean isnew = true;
                    VulnProcessForm tmp = vulnProcessFormMapper.selectById(curVul.getId());
                    if (tmp != null) {
                        vulnProcessFormMapper.stillExist(curVul.getId());
                        isnew = false;
                    }

                    if (isnew) {
                        //新漏洞
                        if (CommonAssemble.saveVul(curVul)) {
                            newTotal++;
                        } else {
                            dropTotal++;
                        }
                    }
                }
            }

        }
        //已修复的漏洞判断
        for (VulnProcessForm oldVul : vulList) {
            boolean isRepair = true;
            for (VulnProcessForm newVul : newVulList) {
                //漏洞名称 节点IP是否相同
                if (newVul.getId().equalsIgnoreCase(oldVul.getId())) {
                    isRepair = false;
                    break;
                }
            }
            //漏洞已修复
            if (isRepair) {
                repairedList.add(oldVul);
            } else {
                //未修复
                unrepairedList.add(oldVul);
            }
        }
        log.info(ip + " @@@@@@@@@@@@库存漏洞：" + vulList.size() + " 丢弃漏洞：" + dropTotal + " 新增漏洞：" + newTotal + " 未修复漏洞：" + unrepairedList.size() + " 修复漏洞：" + repairedList.size());
        if (repairedList.size() > 0) {
            repairedList.forEach((CommonAssemble::repairedVul));
        }
        if (unrepairedList.size() > 0) {
            unrepairedList.forEach((CommonAssemble::unRepairedVul));
        }
        CommonAssemble.sendMsg(vulList, ScannerEnums.LVMENG_SCANNER.getName(), ScanTypeEnums.WEB_SCAN.getCode(), ip, newTotal, unrepairedList.size(), repairedList.size());
    }

    private static VulnProcessForm getVulFromJson(JSONObject json, String ip, long engineId) {
        if (json == null || json.size() < 5) {
            return null;
        }
        /*
        {
           "login":" root",  --用户名
            "host": " 172.16.10.11",  --主机名
           "password": " 123456",  --密码
           "port": " 22",  --端口
          "service":" ssh",  --服务
        }
         */
        String vulName = JsonUtils.getStr(json, "username") + JsonUtils.getStr(json, "plainText") + JsonUtils.getStr(json, "appType");
        if (StringUtils.isBlank(vulName)) {
            log.error("没有识别漏洞名称" + json.toJSONString());
            return null;
        }

        String desc = JsonUtils.getStr(json, "appType") + "服务存在弱口令，登陆当前登陆账号：" + JsonUtils.getStr(json, "username");
        Date firstCheckDate = JsonUtils.getDate(json, "time");
        Date publicDate = JsonUtils.getDate(json, "time");
        String vulType = JsonUtils.getStr(json, "groupname");
        String solution = "请修改相关弱口令，并举一反三全面排查系统弱口令，增加口令默认配置策略。";

        //高危=4或者3，中危=2，低危=1或者0
        //我们0:低危, 1:中危, 2:高危, 3:严重
        int level = JsonUtils.getInt(json, "severity");
        if (level < 2) {
            level = 0;
        } else if (level == 2) {
            level = 1;
        } else {
            level = 2;
        }
        String filter = SyncSecConfigLoad.getRemarkValue(SyncSecConstants.JIAOTU_SYNC_ENABLE);
        try {
            boolean flag = false;
            if (filter != null && filter.contains("=") && filter.contains("level")) {
                String filterLevel = filter.split("=")[1];
                String slevel = JsonUtils.getStr(json, "severity");
                for (String fl : filterLevel.split(",")) {
                    if (StringUtils.isNotBlank(slevel) && slevel.equalsIgnoreCase(fl)) {
                        flag = true;
                        break;
                    }
                    if (level == 0 && "1".equalsIgnoreCase(fl)) {
                        flag = true;
                        break;
                    }
                }
            } else {
                flag = true;
            }
            if (!flag) {
                log.error("级别过滤" + level);
                return null;
            }
        } catch (Exception e) {
            log.error(e.getMessage(), e);
        }
        //漏洞特征 1：存在EXP 2：存在POC 3：远程执行 4：本地提权 5：内核漏洞
        List<String> feats = new ArrayList<>();
        if (json.containsKey("hasExp")) {
            if (json.getBoolean("hasExp")) {
                feats.add("1");
            }
        }
        if (json.containsKey("hasPoc")) {
            if (json.getBoolean("hasPoc")) {
                feats.add("2");
            }
        }
        if (json.containsKey("remote")) {
            if (json.getBoolean("remote")) {
                feats.add("3");
            }
        }
        if (json.containsKey("localEscalation")) {
            if (json.getBoolean("localEscalation")) {
                feats.add("4");
            }
        }
        if (json.containsKey("kernel")) {
            if (json.getBoolean("kernel")) {
                feats.add("5");
            }
        }
        String CVE = JsonUtils.getStr(json, "cves");
        String cvss = JsonUtils.getStr(json, "cvss_vector");
        VulnProcessForm vul = new VulnProcessForm();
        vul.setIp(ip);
        vul.setEngineId(String.valueOf(engineId));
        vul.setVulnName(vulName);
        vul.setCvss(CvssUtils.getScore(cvss));
        vul.setRefLink(JsonUtils.getStr(json, "seealso"));
        vul.setCode(String.format("VUL_%s", IdGen.uuid8()));
        vul.setLevel(String.valueOf(level));
        vul.setCategory(ScanTypeEnums.WEAK_PASS_SCAN.getCode());
        vul.setSource(ScannerEnums.JIAOTU_SCANNER.getCode());
        String id = Md5Utils.hash(ip + "#" + vulName + "#" + CVE + "#" + vul.getSource());
        vul.setId(id);
        vul.setVulnType(vulType);
        vul.setDescription(desc);
        vul.setSolution(solution);
        vul.setCveCode(CVE);
        vul.setCreateTime(new Date());
        vul.setUpdateTime(new Date());
        vul.setFirstTime(firstCheckDate);
        vul.setRecentlyTime(firstCheckDate);
        vul.setPublishTime(publicDate);
        vul.setUserName(JsonUtils.getStr(json, "username"));
        vul.setPassword(JsonUtils.getStr(json, "password"));
        vul.setVulFeatures(String.join(",", feats));
        vul.setPort(JsonUtils.getStr(json, "port"));
        vul.setService(JsonUtils.getStr(json, "service"));
        vul.setStatus("0");
        if (StringUtils.isBlank(vul.getVulnType())) {
            vul.setVulnType("常见弱密码");
        }
        CommonAssemble.saveVulAssetInfo(vul, ip);
        return vul;
    }

    /**
     * IP全部修复
     *
     * @param ip IP
     */
    public static void repairAllByIp(String ip) {
        try {
            CommonAssemble.repairAll(ip, ScannerEnums.JIAOTU_SCANNER.getCode(), ScanTypeEnums.WEAK_PASS_SCAN.getCode());
        } catch (Exception e) {
            log.error(e.getMessage(), e);
        }
    }
}
