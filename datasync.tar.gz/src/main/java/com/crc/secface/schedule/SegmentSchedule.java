package com.crc.secface.schedule;

import com.baomidou.mybatisplus.core.conditions.query.LambdaQueryWrapper;
import com.baomidou.mybatisplus.core.toolkit.Wrappers;
import com.crc.StartUp;
import com.crc.common.utils.MyTheadUtils;
import com.crc.secface.domain.AssetSegement;
import com.crc.secface.mapper.AssetSegementMapper;
import com.crc.secface.schedule.assemble.code.ZhuoMuNiaoAssemble;
import com.crc.sync.config.SyncSecConfigLoad;
import com.crc.sync.config.SyncSecConstants;
import com.crc.sync.net.NewSegmentLoad;
import com.crc.sync.system.SqlColumSync;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.scheduling.annotation.EnableScheduling;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Component;

import java.util.List;

/*
 * 集团网段加载功能
 */

@Slf4j
@Component
@EnableScheduling
public class SegmentSchedule implements CommandLineRunner {

    @Override
    public void run(String... args) {
        MyTheadUtils.sleepBySec(1);
        StartUp.start();
        (new SqlColumSync()).sync();
        sync();
    }


    @Autowired
    AssetSegementMapper assetSegementMapper;

    /**
     * 每N分钟统计一次
     */
    @Scheduled(cron = "0 0/5 * * * ?")
    public void sync() {
        MyTheadUtils.sleepBySec(1);
        loadAllSeg();
        if (SyncSecConfigLoad.isEnable(SyncSecConstants.ZHUOMUNIAO_SYNC_ENABLE)) {
            ZhuoMuNiaoAssemble.syncBaseData();
        }

        NewSegmentLoad.FILTER_SEGMENT_FLAG = SyncSecConfigLoad.isEnable(SyncSecConstants.FILTER_SEGMENT_ENABLE);
        log.info("是否启用了网段识别 IP 过滤机制，{}", NewSegmentLoad.FILTER_SEGMENT_FLAG);
    }

    private void loadAllSeg() {
        try {
            LambdaQueryWrapper<AssetSegement> queryWrapper = Wrappers.lambdaQuery();
            //query.setIsEnable(0L);
            queryWrapper.eq(AssetSegement::getIsEnable, 0);
            queryWrapper.orderByDesc(AssetSegement::getUpdateTime);
            List<AssetSegement> allSegment = assetSegementMapper.selectList(queryWrapper);
            NewSegmentLoad.setAllSegment(allSegment);
            log.info("2023成功加载IP网段信息数：" + allSegment.size());
        } catch (Exception e) {
            log.error(e.getMessage(), e);
        }
    }


}
