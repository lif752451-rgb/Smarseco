package com.crc.secface.schedule.assemble.asset;

import com.alibaba.fastjson.JSONObject;
import com.crc.common.utils.HttpUtils;
import com.crc.common.utils.JsonUtils;
import com.crc.secface.config.GetSpringBean;
import com.crc.secface.domain.Asset;
import com.crc.secface.domain.SysDictData;
import com.crc.secface.mapper.AssetMapper;
import com.crc.sync.config.SyncSecConfigLoad;
import com.crc.sync.config.SyncSecConstants;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.collections4.CollectionUtils;
import org.apache.commons.lang3.StringUtils;

import java.util.List;

/**
 * <p>
 * 办公网态势感知资产回传（奇安信网神）
 * </p>
 *
 * @author yuyuhang5
 * @Date 2024/9/9 15:15
 * @Description NgsocAssetAssemble
 */

@Slf4j
public class NgsocAssetAssemble {

    public static void updateAsset(List<Asset> updateAssetList) {
        if (CollectionUtils.isNotEmpty(updateAssetList)) {
            // 同步办公网态势感知资产系统配置
            SysDictData sysDictData = SyncSecConfigLoad.getConfig(SyncSecConstants.NGSOC_LOGIN_CONFIG);
            if (StringUtils.isNotBlank(sysDictData.getRemark())) {
                JSONObject config = JsonUtils.parse(sysDictData.getRemark());
                proc(config, updateAssetList);
            } else {
                log.info("更新办公网态势感知资产-数据字典不存在");
            }
        }
    }

    private static void proc(JSONObject config, List<Asset> updateAssetList) {
        AssetMapper assetMapper = GetSpringBean.getBean(AssetMapper.class);
        for (Asset asset : updateAssetList) {
            try {
                JSONObject headers = new JSONObject();
                headers.put("apiKey", config.getString("token"));
                String url = config.getString("infoUrl") + asset.getUniqueCode();
                String dataStr = HttpUtils.sendGet(url, null, headers);
                if (StringUtils.isEmpty(dataStr)) {
                    log.error("更新办公网态势感知资产-调用API返回数据为空");
                    return;
                }
                JSONObject dataJson = JsonUtils.parse(dataStr);
                if (JsonUtils.isEmpty(dataJson)) {
                    log.error("更新办公网态势感知资产-调用API返回数据格式异常");
                    return;
                }
                JSONObject responseJson = dataJson.getJSONObject("data");
                if (JsonUtils.isEmpty(responseJson)) {
                    log.error("更新办公网态势感知资产-调用API返回数据data为空,AssetId:{},返回信息：{}", asset.getUniqueCode(), dataStr);
                    continue;
                }
                JSONObject request = new JSONObject();
                request.put("assetId", asset.getUniqueCode());
                request.put("assetName", asset.getInstance());
                //request.put("orgId", asset.getAffiliationDeptNodeId());
                request.put("assetType", responseJson.getString("assetType"));
                request.put("assetIdentifications", responseJson.getJSONArray("assetIdentifications"));
                /*
                 * 返回值示例
                 * {"error":{"code":"BadArgument","message":"组织架构ID错误"}}
                 * {"data":"修改资产成功"}
                 */
                String resultStr = HttpUtils.sendPost(config.getString("updateUrl"), request.toJSONString(), headers);
                JSONObject resultJson = JsonUtils.parse(resultStr);
                if (!JsonUtils.isEmpty(resultJson)) {
                    assetMapper.updateAssetFlag(asset.getId());
                }
            } catch (Exception e) {
                log.error("更新办公网态势感知资产-调用接口异常", e);
            }
        }
    }
}
