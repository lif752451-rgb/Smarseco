package com.crc.secface.schedule;


import com.crc.common.utils.DateUtils;
import com.crc.common.utils.DictUtil;
import com.crc.common.utils.MyTheadUtils;
import com.crc.job.JobManager;
import com.crc.secface.domain.SysDictData;
import lombok.extern.slf4j.Slf4j;
import org.springframework.boot.CommandLineRunner;
import org.springframework.scheduling.annotation.EnableScheduling;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Component;

import java.util.HashMap;
import java.util.List;

@Slf4j
@Component
@EnableScheduling
public class QuartzJobSchedule implements CommandLineRunner {
    @Override
    public void run(String... args) throws Exception {
        MyTheadUtils.sleepBySec(5);
        sync();
    }


    /**
     * 每N分钟统计一次
     */
    @Scheduled(cron = "0 0/3 * * * ?")
    private void sync() {
        MyTheadUtils.sleepBySec(5);
        try {
            List<SysDictData> tempList = DictUtil.getDict("job_data_sync");
            HashMap<String, String> linshiMap = new HashMap<>();
            for (SysDictData tm : tempList) {
                String id = String.valueOf(tm.getDictCode());
                if (JobManager.tempMap.containsKey(id)) {
                    //已启动
                    //判断版本号是否一致
                    String curVer = DateUtils.getDateTimeString1(tm.getUpdateTime());
                    String tempVer = DateUtils.getDateTimeString1(JobManager.tempMap.get(id).getUpdateTime());
                    if (!curVer.equals(tempVer)) {
                        //版本更新
                        //stop
                        JobManager.deleteJob(tm);
                        //start
                        JobManager.startJob(tm);
                    }
                } else {
                    //新任务需启动
                    JobManager.startJob(tm);
                }
                linshiMap.put(id, id);
            }
            HashMap<String, String> linshiMap2 = new HashMap<>();
            JobManager.tempMap.forEach((k, v) -> {
                if (!linshiMap.containsKey(k)) {
                    //已停止
                    JobManager.deleteJob(v);
                    linshiMap2.put(k, k);
                    //logger.info("Stop Job: " + k);
                }
            });
            linshiMap2.forEach((k, v) -> {
                JobManager.tempMap.remove(k);
            });
        } catch (Exception e) {
            log.error(e.getMessage(), e);
        }
    }
}
