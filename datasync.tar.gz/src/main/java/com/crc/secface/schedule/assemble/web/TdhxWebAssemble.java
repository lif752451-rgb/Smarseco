package com.crc.secface.schedule.assemble.web;

import com.alibaba.fastjson.JSONArray;
import com.alibaba.fastjson.JSONObject;
import com.baomidou.mybatisplus.core.conditions.query.LambdaQueryWrapper;
import com.crc.common.code.SimpleCodeTool;
import com.crc.common.enums.ScanStatusEnums;
import com.crc.common.enums.ScanTypeEnums;
import com.crc.common.enums.ScannerEnums;
import com.crc.common.utils.DateUtils;
import com.crc.common.utils.IdGen;
import com.crc.common.utils.JsonUtils;
import com.crc.common.utils.Md5Utils;
import com.crc.common.utils.UrlUtils;
import com.crc.scanner.config.TdhxConfig;
import com.crc.scanner.tool.TdhxUtils;
import com.crc.secface.config.GetSpringBean;
import com.crc.secface.domain.EngineEquipmentManagement;
import com.crc.secface.domain.VulnProcessForm;
import com.crc.secface.domain.VulnScanTask;
import com.crc.secface.domain.VulnScanTaskRecord;
import com.crc.secface.domain.VulnScanTaskRecordLog;
import com.crc.secface.mapper.AssetMapper;
import com.crc.secface.mapper.VulnProcessFormMapper;
import com.crc.secface.mapper.VulnScanTaskMapper;
import com.crc.secface.mapper.VulnScanTaskRecordLogMapper;
import com.crc.secface.mapper.VulnScanTaskRecordMapper;
import com.crc.secface.schedule.assemble.CommonAssemble;
import com.crc.secface.schedule.assemble.WhiteListQuery;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.HashMap;
import java.util.LinkedList;
import java.util.List;
import java.util.Objects;


/**
 * @author YUYUHANG5
 */
@Slf4j
public class TdhxWebAssemble {

    public static TdhxConfig getConfig(Long engineId) {
        EngineEquipmentManagement engine = CommonAssemble.engineMap.get(engineId);
        // 当对应引擎不存在或者未启用时，不处理对应数据
        if (engine == null || engine.getId() == null) {
            return null;
        }
        TdhxConfig tdhxConfig = new TdhxConfig();
        tdhxConfig.setEngineId(engineId);
        tdhxConfig.setAddress(engine.getEquipmentAddress());
        // 设置对应引擎Code
        tdhxConfig.setSource(engine.getEquipmentManufacture());
        String pass = engine.getPassword().trim();
        tdhxConfig.setPassword(pass);
        try {
            pass = SimpleCodeTool.decrypt(pass);
            tdhxConfig.setPassword(pass);
        } catch (Exception e) {
            log.error(e.getMessage(), e);
        }
        tdhxConfig.setUserName(engine.getLoginUser());
        return tdhxConfig;
    }

    public static void addTask() {
        List<String> engines = Arrays.asList(ScannerEnums.TDHX_LF_SCANNER.getCode(), ScannerEnums.TDHX_YT_SCANNER.getCode(), ScannerEnums.TDHX_CQ_SCANNER.getCode(), ScannerEnums.TDHX_TZ_SCANNER.getCode());
        try {
            VulnScanTaskRecordLogMapper taskRecordLogMapper = GetSpringBean.getBean(VulnScanTaskRecordLogMapper.class);
            VulnScanTaskRecordMapper taskRecordMapper = GetSpringBean.getBean(VulnScanTaskRecordMapper.class);
            VulnScanTaskMapper scanTaskMapper = GetSpringBean.getBean(VulnScanTaskMapper.class);
            List<VulnScanTask> list = CommonAssemble.getScanTask(engines, ScanTypeEnums.WEB_SCAN.getCode(), Arrays.asList(1, 2));
            log.info("天地和兴待执行的WEB扫描任务数为：{}", list.size());
            for (VulnScanTask task : list) {
                try {
                    // 1.先判断引擎是否启用
                    TdhxConfig scannerInfo = getConfig(task.getEngineId());
                    if (scannerInfo == null) {
                        CommonAssemble.startFail(task, "天地和兴配置不存在或者未启用,请检查配置");
                        log.error(task.getTaskName() + "-天地和兴配置不存在或者未启用,请检查配置," + task.getEngineId());
                        continue;
                    }
                    // 2.判断是否可执行
                    VulnScanTaskRecord record = taskRecordMapper.getLastRecordByTaskId(task.getId());
                    if (record == null) {
                        continue;
                    }
                    // 获取扫描任务对象数据（ip,url）
                    String scanContent = task.getScanContentX(",");
                    // 3.判断是否执行中
                    LambdaQueryWrapper<VulnScanTaskRecordLog> wrapper = new LambdaQueryWrapper<>();
                    wrapper.eq(VulnScanTaskRecordLog::getRecordId, record.getId());
                    wrapper.eq(VulnScanTaskRecordLog::getTaskId, task.getId());
                    if (taskRecordLogMapper.selectCount(wrapper) > 0) {
                        log.info("天地和兴,WEB扫描:{}==={},已在执行中", task.getTaskName(), scanContent);
                        continue;
                    }
                    // 4.获取token
                    TdhxUtils.login(scannerInfo);
                    if (StringUtils.isBlank(scannerInfo.getToken())) {
                        CommonAssemble.startFail(task, "天地和兴登陆失败,请检查配置");
                        log.error(task.getTaskName() + "-天地和兴登陆失败请检查配置," + scannerInfo.getAddress() + " " + scannerInfo.getUserName());
                        continue;
                    }
                    // 5.判断扫描对象
                    if (StringUtils.isBlank(scanContent)) {
                        log.error("天地和兴,WEB扫描:{}({})任务无法解析出有效IP", task.getTaskName(), task.getId());
                        CommonAssemble.startFail(task, ScanStatusEnums.SCAN_FINISH.getCode(), "任务无法解析出有效地址");
                        continue;
                    }
                    VulnScanTaskRecordLog recordLog = new VulnScanTaskRecordLog();
                    recordLog.setIp(scanContent);
                    recordLog.setTaskId(record.getTaskId());
                    recordLog.setTaskName(task.getTaskName());
                    recordLog.setRecordId(record.getId());
                    recordLog.setEngineId(task.getEngineId());
                    recordLog.setCreateTime(new Date());
                    // 对应的数据引擎
                    recordLog.setType(scannerInfo.getSource());
                    // 任务状态(0 未开始 1 执行中 2 执行完成 3 执行失败)
                    recordLog.setScanStatus(0);
                    JSONObject response =  TdhxUtils.createTask(scannerInfo, "3", task.getTaskName(), scanContent);
                    String taskMsg = "执行成功";
                    if (Objects.nonNull(response)) {
                        recordLog.setScanStatus(1);
                        recordLog.setJobId(response.getString("taskall_id"));
                        recordLog.setChildTaskId(response.getString("web_task_id"));
                        recordLog.setResult(taskMsg);
                        taskRecordLogMapper.insert(recordLog);
                        log.info("创建任务:" + task.getTaskName() + " -> " + taskMsg + " 返回ID：" + recordLog.getJobId() + " WEB扫描");
                    } else {
                        // 失败
                        recordLog.setScanStatus(3);
                        taskMsg = "执行失败";
                        recordLog.setResult(taskMsg);
                        taskRecordLogMapper.insert(recordLog);
                        CommonAssemble.startFail(recordLog, taskMsg);
                        log.error("创建任务失败:" + task.getTaskName() + " -> " + taskMsg + " WEB扫描");
                    }
                    record.setScanResult(taskMsg);
                    record.setUpdateTime(new Date());
                    taskRecordMapper.updateVulnScanTaskRecord(record);

                    task.setScanStatus(ScanStatusEnums.SCAN_ING.getCode());
                    task.setUpdateTime(new Date());
                    scanTaskMapper.updateVulnScanTask(task);
                } catch (Exception e) {
                    log.error(e.getMessage(), e);
                }
            }
        } catch (
                Exception e) {
            log.error(e.getMessage(), e);
        }
    }

    /**
     * WEB漏洞的处理逻辑
     */
    public static void getTask() {
        List<String> engines = Arrays.asList(ScannerEnums.TDHX_LF_SCANNER.getCode(), ScannerEnums.TDHX_YT_SCANNER.getCode(), ScannerEnums.TDHX_CQ_SCANNER.getCode(), ScannerEnums.TDHX_TZ_SCANNER.getCode());
        VulnScanTaskRecordLogMapper taskRecordLogMapper = GetSpringBean.getBean(VulnScanTaskRecordLogMapper.class);
        VulnScanTaskRecordMapper taskRecordMapper = GetSpringBean.getBean(VulnScanTaskRecordMapper.class);
        VulnScanTaskMapper scanTaskMapper = GetSpringBean.getBean(VulnScanTaskMapper.class);
        VulnScanTaskRecordLog q = new VulnScanTaskRecordLog();
        q.setScanStatus(1);//扫描中
        q.setScanType(ScanTypeEnums.WEB_SCAN.getCode());
        q.setEquipmentManufactures(engines);
        List<VulnScanTaskRecordLog> recordList = taskRecordLogMapper.getAllRecordLogList(q);
        log.info("天地和兴-WEB漏洞，扫描中的任务数为：{}", recordList.size());
        for (VulnScanTaskRecordLog task : recordList) {
            try {
                TdhxConfig scannerInfo = getConfig(task.getEngineId());
                if (scannerInfo == null) {
                    log.error(task.getTaskName() + "-天地和兴配置不存在或者未启用,请检查配置," + task.getEngineId());
                    task.setScanStatus(3);
                    task.setResult("天地和兴配置不存在或者未启用");
                    taskRecordLogMapper.updateById(task);
                    continue;
                }
                JSONObject retJson = TdhxUtils.postTaskStatus(scannerInfo, Integer.parseInt(task.getJobId()));
                if (retJson != null) {
                    if (retJson.getBooleanValue("success")) {
                        /* 0: 未提交 1: 已提交 2: 提交失败 3: 正在运行 4: 已完成 5：已跳过 6: 已停止 7：已暂停 8：等待 9：已超时 状态为 4、6时，可以跳过任务不再查询状态 */
                        int isStatus = JsonUtils.getInt(retJson, "status");
                        boolean stop = false;
                        if (isStatus == 0 || isStatus == 1 || isStatus == 3 || isStatus == 7 || isStatus == 8) {
                            //进行中
                        } else if (isStatus == 2 || isStatus == 6) {
                            stop = true;
                        }
                        task.setProgress(JsonUtils.getInt(retJson, "progress"));
                        int status = 1;
                        if (task.getProgress() == 100 && isStatus == 4) {
                            status = 2;
                        }
                        if (stop) {
                            log.error("任务异常停止:" + task.getTaskName() + " -> " + " 进度：" + task.getProgress() + ",status=" + isStatus);
                            status = 3;
                        } else {
                            log.info(task.getJobId() + ",读取任务:" + task.getTaskName() + " -> " + " 进度：" + JsonUtils.getInt(retJson, "progress") + ",status=" + isStatus);
                        }
                        task.setScanStatus(status);
                        taskRecordLogMapper.updateById(task);
                        if (task.getProgress() == 100 && !stop && isStatus == 4) {
                            JSONObject resultJson = TdhxUtils.postWebVulResult(scannerInfo, Integer.parseInt(task.getChildTaskId()));
                            if (resultJson != null) {
                                int total = JsonUtils.getInt(resultJson, "total");
                                log.info("{}/{},job_id={},目标总数={}", task.getTaskName(), task.getTaskId(), task.getJobId(), total);
                                HashMap<String, List<VulnProcessForm>> dataMap = new HashMap<>(16);
                                if (total > 0) {
                                    JSONArray hosts = resultJson.getJSONArray("hosts");
                                    // 根据主机开始for循环处理漏洞数据
                                    for (int i = 0; i < hosts.size(); i++) {
                                        try {
                                            JSONObject hostJson = hosts.getJSONObject(i);
                                            if (!JsonUtils.isEmpty(hostJson)) {
                                                int vulCount = JsonUtils.getInt(hostJson, "vulcount");
                                                // 详情信息
                                                JSONObject site = hostJson.getJSONObject("site");
                                                String ip = JsonUtils.getStr(site, "ip");
                                                // 漏洞详情
                                                JSONArray vulList = hostJson.getJSONArray("vulns");
                                                for (int j = 0; j < vulList.size(); j++) {
                                                    try {
                                                        JSONObject vulJsonInfo = vulList.getJSONObject(j);
                                                        // 传递ip信息
                                                        vulJsonInfo.put("targetIp", ip);
                                                        VulnProcessForm curVul = getVulFromJson(vulJsonInfo, scannerInfo, hostJson.getDate("start"));
                                                        if (curVul == null) {
                                                            continue;
                                                        }
                                                        if (dataMap.containsKey(curVul.getDomain())) {
                                                            dataMap.get(curVul.getDomain()).add(curVul);
                                                        } else {
                                                            dataMap.put(curVul.getDomain(), new ArrayList<>());
                                                            dataMap.get(curVul.getDomain()).add(curVul);
                                                        }
                                                    } catch (Exception e) {
                                                        log.error(e.getMessage(), e);
                                                    }
                                                }
                                            }
                                        } catch (Exception e) {
                                            log.error(e.getMessage(), e);
                                        }
                                    }
                                }
                                for (String url : dataMap.keySet()) {
                                    List<VulnProcessForm> curList = dataMap.get(url);
                                    if (curList.size() > 0) {
                                        log.info("解析任务:" + task.getTaskName() + " " + url + " -> " + " 发现漏洞：" + curList.size());
                                        handle(scannerInfo.getSource(), url, curList);
                                    } else {
                                        log.info("解析任务:" + task.getTaskName() + " " + url + " -> " + " 未发现漏洞");
                                        repairAllByUrl(scannerInfo.getSource(), url);
                                    }
                                }
                            }
                        }
                        /*
                         * 更新业务段任务进度
                         */
                        try {
                            VulnScanTaskRecord taskRecord = taskRecordMapper.selectById(task.getRecordId());
                            taskRecord.setScanProgress(task.getProgress());
                            if (status > 1) {
                                taskRecord.setScanEndTime(new Date());
                                taskRecord.setDuration(DateUtils.getDiffSec(taskRecord.getScanStartTime(), taskRecord.getScanEndTime()));
                                taskRecord.setScanStatus(status);
                                taskRecord.setScanResult("扫描完成");
                            }
                            taskRecordMapper.updateVulnScanTaskRecord(taskRecord);

                            VulnScanTask scanTask = new VulnScanTask();
                            scanTask.setId(taskRecord.getTaskId());
                            scanTask.setUpdateTime(new Date());
                            scanTask.setScanProgress(taskRecord.getScanProgress());

                            if (taskRecord.getScanStatus() != null && taskRecord.getScanStatus() > 1) {
                                scanTask.setScanStatus(ScanStatusEnums.SCAN_FINISH.getCode());
                            }
                            scanTaskMapper.updateVulnScanTask(scanTask);
                        } catch (Exception e) {
                            log.error(e.getMessage(), e);
                        }
                    } else {
                        log.error("{}-获取WEB漏洞数据失败原因:{}", task.getTaskName(), retJson);
                    }
                } else {
                    log.error("{}-获取任务状态失败", task.getTaskName());
                }
            } catch (Exception e) {
                log.error("{}-执行失败==", task.getTaskName(), e);
            }
        }
    }

    private static void handle(String source, String url, List<VulnProcessForm> culList) {
        String domain = UrlUtils.getDomain(url);
        //原有漏洞查询
        VulnProcessFormMapper vulnProcessFormMapper = GetSpringBean.getBean(VulnProcessFormMapper.class);
        AssetMapper assetMapper = GetSpringBean.getBean(AssetMapper.class);
        //原有漏洞查询
        LambdaQueryWrapper<VulnProcessForm> vq = new LambdaQueryWrapper<>();
        vq.eq(VulnProcessForm::getIp, url);
        vq.eq(VulnProcessForm::getSource, source);
        vq.eq(VulnProcessForm::getCategory, ScanTypeEnums.WEB_SCAN.getCode());
        List<VulnProcessForm> vulList = vulnProcessFormMapper.selectList(vq);
        List<VulnProcessForm> repairedList = new LinkedList<>();
        List<VulnProcessForm> unRepairedList = new LinkedList<>();
        List<VulnProcessForm> newVulList = new LinkedList<>();
        log.info(url + " 库存漏洞：" + vulList.size() + " 当前有漏洞：" + culList.size());
        int newTotal = 0;
        int dropTotal = 0;
        //扫描到漏洞
        for (VulnProcessForm curVul : culList) {
            //白名单
            if (WhiteListQuery.isWhiteList(curVul)) {
                dropTotal++;
                continue;
            }
            newVulList.add(curVul);
            //是否新漏洞
            boolean isnew = true;
            VulnProcessForm tmp = vulnProcessFormMapper.selectById(curVul.getId());
            if (tmp != null) {
                vulnProcessFormMapper.stillExist(curVul.getId());
                isnew = false;
            }

            if (isnew) {
                //新漏洞
                if (CommonAssemble.saveVul(curVul)) {
                    newTotal++;
                } else {
                    dropTotal++;
                }
            }
        }
        //已修复的漏洞判断
        for (VulnProcessForm oldVul : vulList) {
            boolean isRepair = true;
            for (VulnProcessForm newVul : newVulList) {
                //漏洞名称 节点IP是否相同
                if (newVul.getId().equalsIgnoreCase(oldVul.getId())) {
                    isRepair = false;
                    break;
                }
            }
            //漏洞已修复
            if (isRepair) {
                repairedList.add(oldVul);
            } else {
                //未修复
                unRepairedList.add(oldVul);
            }
        }
        log.info("引擎来源：" + source + "url: " + url + " @@@@@@@@@@@@库存漏洞：" + vulList.size() + " 丢弃漏洞：" + dropTotal + " 新增漏洞：" + newTotal + " 未修复漏洞：" + unRepairedList.size() + " 修复漏洞：" + repairedList.size());
        if (repairedList.size() > 0) {
            repairedList.forEach((CommonAssemble::repairedVul));
        }
        if (unRepairedList.size() > 0) {
            unRepairedList.forEach((CommonAssemble::unRepairedVul));
        }
        CommonAssemble.sendMsg(vulList, source, ScanTypeEnums.WEB_SCAN.getCode(), url, newTotal, unRepairedList.size(), repairedList.size());
    }

    /**
     * 获取漏洞详情
     *
     * @param json 原始
     * @return 漏洞信息
     */
    public static VulnProcessForm getVulFromJson(JSONObject json, TdhxConfig scannerInfo, Date startTime) {
        JSONArray vl = json.getJSONArray("rvs");
        String url = "";
        if (vl != null && vl.size() > 0) {
            JSONObject jsonObject = vl.getJSONObject(0);
            url = JsonUtils.getStr(jsonObject, "url");
        }
        if (!UrlUtils.isValidUrl(url)) {
            log.error("{}非法URL", url);
            return null;
        }

        String domain = UrlUtils.getDomain(url);

        // severity=0 表示 '高风险'，  severity=1 表示'中风险'， severity=2 表示 '低风险'， severity=3 表示 '信息'
        int level = JsonUtils.getInt(json, "severity");
        if (level > 2) {
            return null;
        } else {
            if (level == 0) {
                level = 2;
            } else if (level == 2) {
                level = 0;
            }
        }
        String vulName = JsonUtils.getStr(json, "name");
        String desc = JsonUtils.getStr(json, "descr");
        String solution = JsonUtils.getStr(json, "solution");
        String vulType = JsonUtils.getStr(json, "groupname");
        //String cve = JsonUtils.getStr(json, "cves");
        //String cnnvd = JsonUtils.getStr(json, "cnnvd");

        VulnProcessForm vul = new VulnProcessForm();
        vul.setIp(url);
        vul.setDomain(domain);
        vul.setEngineId(String.valueOf(scannerInfo.getEngineId()));
        vul.setVulnName(vulName);
        vul.setCode(String.format("VUL_%s", IdGen.uuid8()));
        vul.setLevel(String.valueOf(level));
        vul.setSource(scannerInfo.getSource());
        String id = Md5Utils.hash(url + "#" + vulName + "#" + vul.getSource());
        vul.setId(id);
        vul.setVulnType(vulType);
        vul.setCategory(ScanTypeEnums.WEB_SCAN.getCode());
        vul.setDescription(desc);
        vul.setSolution(solution);
        vul.setCreateTime(new Date());
        vul.setUpdateTime(new Date());
        vul.setFirstTime(startTime);
        vul.setRecentlyTime(startTime);

        //修复影响：0-未知；1-无需重启；2-服务重启；3系统重启 （仅linux）
        //vul.setCvss(CvssUtils.getScore(JsonUtils.getStr(json, "cvss")));
        //vul.setCnnvd(cnnvd);
        //vul.setCveCode(cve);
        // 获取资产归属
        CommonAssemble.saveVulAssetInfo(vul, json.getString("targetIp"));
        return vul;
    }

    /**
     * 扫描链接对应漏洞全部修复
     *
     * @param source source
     * @param url    url
     */
    public static void repairAllByUrl(String source, String url) {
        try {
            CommonAssemble.repairAll(url, source, ScanTypeEnums.WEB_SCAN.getCode());
        } catch (Exception e) {
            log.error(e.getMessage(), e);
        }
    }

}
