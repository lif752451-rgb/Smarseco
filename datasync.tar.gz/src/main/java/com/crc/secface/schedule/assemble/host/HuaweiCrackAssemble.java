package com.crc.secface.schedule.assemble.host;

import com.alibaba.fastjson.JSONArray;
import com.alibaba.fastjson.JSONObject;
import com.baomidou.mybatisplus.core.conditions.query.LambdaQueryWrapper;
import com.crc.common.code.SimpleCodeTool;
import com.crc.common.enums.AssetSourceEnums;
import com.crc.common.enums.ScanStatusEnums;
import com.crc.common.enums.ScanTypeEnums;
import com.crc.common.enums.ScannerEnums;
import com.crc.common.utils.*;
import com.crc.scanner.config.HuaweiConfig;
import com.crc.scanner.tool.CvssUtils;
import com.crc.scanner.tool.HuaweiUtils;
import com.crc.secface.config.GetSpringBean;
import com.crc.secface.domain.*;
import com.crc.secface.mapper.*;
import com.crc.secface.queue.CrcAssetSyncQueue;
import com.crc.secface.schedule.assemble.CommonAssemble;
import com.crc.secface.schedule.assemble.WhiteListQuery;
import com.crc.sync.config.SyncSecConfigLoad;
import com.crc.sync.config.SyncSecConstants;
import com.crc.sync.work.PortSaveWork;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;

import java.util.*;

@Slf4j
public class HuaweiCrackAssemble {
    public static HuaweiConfig getTrxConfig(Long engineId) {
        EngineEquipmentManagement engine = CommonAssemble.engineMap.get(engineId);
        HuaweiConfig qtConfig = new HuaweiConfig();
        if (engine == null || engine.getId() == null) {
            return qtConfig;
        }
        qtConfig.setEngineId(engineId);
        qtConfig.setAddress(engine.getEquipmentAddress());
        String PASS = engine.getPassword().trim();
        qtConfig.setPassword(PASS);
        try {
            PASS = SimpleCodeTool.decrypt(PASS);
            qtConfig.setPassword(PASS);
        } catch (Exception e) {
            log.error(e.getMessage(), e);
        }
        qtConfig.setUsername(engine.getLoginUser());
        return qtConfig;
    }


    public static void addTask() {
        try {
            VulnScanTaskRecordMapper taskRecordMapper = GetSpringBean.getBean(VulnScanTaskRecordMapper.class);
            VulnScanTaskRecordLogMapper taskRecordLogMapper = GetSpringBean.getBean(VulnScanTaskRecordLogMapper.class);
            List<VulnScanTask> list = CommonAssemble.getCheckingScantask(ScannerEnums.HUAWEI_SCANNER.getCode(), ScanTypeEnums.WEAK_PASS_SCAN.getCode(), Arrays.asList(1, 2));
            for (VulnScanTask task : list) {
                try {
                    VulnScanTaskRecord record = taskRecordMapper.getLastRecordByTaskId(task.getId());
                    LambdaQueryWrapper<VulnScanTaskRecordLog> qlog = new LambdaQueryWrapper<>();
                    qlog.eq(VulnScanTaskRecordLog::getRecordId, record.getId());
                    qlog.eq(VulnScanTaskRecordLog::getTaskId, task.getId());
                    String scanContent = task.getScanContentX();
                    if (taskRecordLogMapper.selectCount(qlog) > 0) {
                        log.info("{}{},已在执行中", task.getTaskName(), scanContent);
                        continue;
                    }

                    VulnScanTaskRecordLog recordLog = new VulnScanTaskRecordLog();
                    recordLog.setIp(scanContent);
                    recordLog.setTaskId(record.getTaskId());
                    recordLog.setTaskName(task.getTaskName());
                    recordLog.setRecordId(record.getId());
                    recordLog.setEngineId(task.getEngineId());
                    recordLog.setCreateTime(new Date());
                    recordLog.setType(ScannerEnums.HUAWEI_SCANNER.getCode());
                    //任务状态(0 未开始 1 执行中 2 执行完成 3 执行失败)
                    recordLog.setScanStatus(0);
                    HuaweiConfig scannerInfo = getTrxConfig(task.getEngineId());
                    List<String> uuids = new ArrayList<>();
                    if (!StringUtils.isBlank(scanContent)) {
                        //多个地址用英文逗号(,)分隔
                        for (String ipStr : scanContent.split("\n")) {
                            String ip = ipStr.trim();
                            if (StringUtils.isBlank(ip)) {
                                continue;
                            }
                            uuids.add(ip);
                        }
                    }
                    String id = "";
                    if (uuids.size() < 1) {
                        log.error("创建任务:" + task.getTaskName() + " -> 失败，没有找到真实IP");
                        CommonAssemble.startFail(task, "任务无法解析出有效IP");
                        continue;
                    } else {
                        HuaweiUtils.createCrackTask(scannerInfo, recordLog, uuids);
                    }
                    id = recordLog.getJobId();
                    String taskMsg = "执行成功";


                    if (StringUtils.isNotBlank(id)) {
                        recordLog.setScanStatus(1);
                        recordLog.setJobId(id);
                        recordLog.setResult(taskMsg);
                        taskRecordLogMapper.insert(recordLog);
                    } else {
                        //失败
                        recordLog.setScanStatus(3);
                        taskMsg = "执行失败";
                        recordLog.setResult(taskMsg);
                        taskRecordLogMapper.insert(recordLog);
                        CommonAssemble.startFail(recordLog, taskMsg);
                    }

                    log.info("创建任务:" + task.getTaskName() + " -> " + taskMsg + " 返回ID：" + id);
                    record.setScanResult(taskMsg);
                    record.setScanStatus(1);
                    taskRecordMapper.updateVulnScanTaskRecord(record);
                } catch (Exception e) {
                    log.error(e.getMessage(), e);
                }
            }
        } catch (Exception e) {
            log.error(e.getMessage(), e);
        }
    }

    public static void getTask() {
        VulnScanTaskRecordLogMapper taskRecordLogMapper = GetSpringBean.getBean(VulnScanTaskRecordLogMapper.class);
        VulnScanTaskRecordMapper taskRecordMapper = GetSpringBean.getBean(VulnScanTaskRecordMapper.class);
        VulnScanTaskMapper scanTaskMapper = GetSpringBean.getBean(VulnScanTaskMapper.class);
        try {
            VulnScanTaskRecordLog q = new VulnScanTaskRecordLog();
            q.setScanStatus(1);//扫描中
            q.setScanType(ScanTypeEnums.WEAK_PASS_SCAN.getCode());
            q.setEngineName(ScannerEnums.HUAWEI_SCANNER.getCode());
            List<VulnScanTaskRecordLog> recordList = taskRecordLogMapper.getAllRecordLogList(q);
            for (VulnScanTaskRecordLog task : recordList) {
                try {
                    HuaweiConfig scannerInfo = getTrxConfig(task.getEngineId());
                    // 扫描任务id
                    ///async/status/?&taskid=xxx&user=xxx&pwd=xxx
                    JSONObject retJson = HuaweiUtils.getTaskStatus(scannerInfo, task.getTaskName(), task.getJobId());
                    /*
                     * {
                     * "code":"1",
                     * "msg":"成功",
                     * "data":{
                     * "machineTotal":2,
                     * "machineCompletions":1,
                     * "status":1
                     */

                    if (retJson != null) {
                        if (retJson.containsKey("status")) {
                            //1-运行中，2-完成，3-停止
                            int istatus = JsonUtils.getInt(retJson, "status");
                            String progress = JsonUtils.getStr(retJson, "progress").replace("%", "");
                            boolean stop = false;
                            if (istatus == 0 || istatus == 1 || istatus == 3 || istatus == 7 || istatus == 8) {
                                //进行中
                            } else if (istatus == 4) {
                                progress = "100";
                            } else {
                                stop = true;
                            }

                            task.setProgress(DataUtils.toInt(progress));
                            int status = 1;
                            if (task.getProgress() == 100) {
                                status = 2;
                            }


                            if (stop) {
                                log.error("任务异常停止:" + task.getTaskName() + " -> " + " 进度：" + progress + ",status=" + istatus);
                                status = 2;
                            } else {
                                log.info("读取任务:" + task.getTaskName() + " -> " + " 进度：" + progress + ",status=" + istatus);
                            }
                            task.setScanStatus(status);
                            taskRecordLogMapper.updateById(task);
                            if (task.getProgress() == 100 && !stop && istatus == 4) {

                                JSONArray retArr = HuaweiUtils.getCrackTask(scannerInfo, task.getTaskName(), task.getJobId(), task.getGroupId());
                                if (retArr != null && retArr.size() > 0) {
                                    log.info("解析任务:" + task.getTaskName() + " -> " + " 发现漏洞主机：" + retArr.size() + ",获取漏洞清单");
                                    MyTheadUtils.sleepBySec(3);
                                    for (int i = 0; i < retArr.size(); i++) {
                                        JSONObject host = retArr.getJSONObject(i);
                                        if (!JsonUtils.equalVal(host, "status", "completed")) {
                                            log.error(task.getTaskName() + "未扫描完成");
                                            continue;
                                        }
                                        JSONArray results = host.getJSONArray("results");
                                        if (results == null) {
                                            log.error(task.getTaskName() + "内容未空");
                                            continue;
                                        }

                                        String ip = "";
                                        if (results.size() > 0) {
                                            ip = JsonUtils.getStr(results.getJSONObject(0), "host");
                                        }
                                        if (!IpUtils.isIp(ip)) {
                                            log.error(task.getTaskName() + ",未识别到IP");
                                            continue;
                                        }

                                        int vulcount = JsonUtils.getInt(host, "total");
                                        if (vulcount > 0) {
                                            log.info("解析任务:" + task.getTaskName() + " " + " -> " + " 发现漏洞：" + results.size() + ",等待5分钟，获取漏洞清单");
                                            handle(task.getEngineId(), results, ip);
                                        } else {
                                            log.info("解析任务:" + task.getTaskName() + " " + ip + " -> " + " 未发现漏洞");
                                            repairAllByIp(ip);
                                        }
                                    }
                                }
                            }


                            /*
                             * 更新业务段任务进度
                             */
                            try {
                                VulnScanTaskRecord taskRecord = taskRecordMapper.selectById(task.getRecordId());
                                taskRecord.setScanProgress(task.getProgress());
                                if (status == 2) {
                                    taskRecord.setScanEndTime(new Date());
                                    taskRecord.setDuration(DateUtils.getDiffSec(taskRecord.getScanStartTime(), taskRecord.getScanEndTime()));
                                    taskRecord.setScanStatus(2);
                                    taskRecord.setScanResult("扫描完成");
                                }
                                taskRecordMapper.updateVulnScanTaskRecord(taskRecord);

                                VulnScanTask scanTask = new VulnScanTask();
                                scanTask.setId(taskRecord.getTaskId());
                                scanTask.setUpdateTime(new Date());
                                scanTask.setScanProgress(taskRecord.getScanProgress());

                                if (taskRecord.getScanStatus() != null && taskRecord.getScanStatus() > 1) {
                                    scanTask.setScanStatus(ScanStatusEnums.SCAN_FINISH.getCode());
                                }
                                scanTaskMapper.updateVulnScanTask(scanTask);
                            } catch (Exception e) {
                                log.error(e.getMessage(), e);
                            }
                        }
                    }
                } catch (Exception e) {
                    log.error(e.getMessage(), e);
                }
            }
        } catch (Exception e) {
            log.error(e.getMessage(), e);
        }
    }

    private static void handle(Long engineId, JSONArray results, String ip) {
        //原有漏洞查询
        VulnProcessFormMapper vulnProcessFormMapper = GetSpringBean.getBean(VulnProcessFormMapper.class);
        AssetMapper assetMapper = GetSpringBean.getBean(AssetMapper.class);
        //原有漏洞查询
        LambdaQueryWrapper<VulnProcessForm> vq = new LambdaQueryWrapper<>();
        vq.eq(VulnProcessForm::getIp, ip);
        vq.eq(VulnProcessForm::getSource, ScannerEnums.HUAWEI_SCANNER.getCode());
        vq.eq(VulnProcessForm::getCategory, ScanTypeEnums.WEAK_PASS_SCAN.getCode());
        List<VulnProcessForm> vulList = vulnProcessFormMapper.selectList(vq);
        List<VulnProcessForm> repairedList = new LinkedList<>();
        List<VulnProcessForm> unrepairedList = new LinkedList<>();
        List<VulnProcessForm> newVulList = new LinkedList<>();
        log.info(ip + " 库存漏洞：" + vulList.size() + " 当前有漏洞：" + results.size());
        int newTotal = 0;
        int dropTotal = 0;
        //扫描到漏洞
        for (int i = 0; i < results.size(); i++) {
            JSONObject result = results.getJSONObject(i);
            VulnProcessForm curVul = getVulFromJson(engineId, result, ip);
            if (curVul == null) {
                dropTotal++;
                continue;
            }
            Asset asset = assetMapper.selectAssetByInnerIp(ip);
            if (asset == null) {
                asset = new Asset();
                asset.setSource(AssetSourceEnums.HUAWEI_CMDB.getCode());
                asset.setInternalIp(ip);
                CrcAssetSyncQueue.getInstance().saveAsset(asset);
            }
            //白名单
            if (WhiteListQuery.isWhiteList(curVul)) {
                dropTotal++;
                continue;
            }
            newVulList.add(curVul);
            //是否新漏洞
            boolean isnew = true;
            VulnProcessForm tmp = vulnProcessFormMapper.selectById(curVul.getId());
            if (tmp != null) {
                vulnProcessFormMapper.stillExist(curVul.getId());
                isnew = false;
            }

            if (isnew) {
                //新漏洞
                if (CommonAssemble.saveVul(curVul)) {
                    newTotal++;
                } else {
                    dropTotal++;
                }
            }
        }
        //已修复的漏洞判断
        for (VulnProcessForm oldVul : vulList) {
            boolean isRepair = true;
            for (VulnProcessForm newVul : newVulList) {
                //漏洞名称 节点IP是否相同
                if (newVul.getId().equalsIgnoreCase(oldVul.getId())) {
                    isRepair = false;
                    break;
                }
            }
            //漏洞已修复
            if (isRepair) {
                repairedList.add(oldVul);
            } else {
                //未修复
                unrepairedList.add(oldVul);
            }
        }
        log.info(ip + " @@@@@@@@@@@@库存漏洞：" + vulList.size() + " 丢弃漏洞：" + dropTotal + " 新增漏洞：" + newTotal + " 未修复漏洞：" + unrepairedList.size() + " 修复漏洞：" + repairedList.size());
        if (!repairedList.isEmpty()) {
            repairedList.forEach((CommonAssemble::repairedVul));
        }
        if (!unrepairedList.isEmpty()) {
            unrepairedList.forEach((CommonAssemble::unRepairedVul));
        }
        CommonAssemble.sendMsg(vulList, ScannerEnums.HUAWEI_SCANNER.getName(), ScanTypeEnums.WEAK_PASS_SCAN.getCode(), ip, newTotal, unrepairedList.size(), repairedList.size());
    }


    private static void handle(List<VulnProcessForm> culList, String ip) {
        //原有弱口令查询
        VulnProcessFormMapper vulnProcessFormMapper = GetSpringBean.getBean(VulnProcessFormMapper.class);
        AssetMapper assetMapper = GetSpringBean.getBean(AssetMapper.class);
        //原有弱口令查询
        LambdaQueryWrapper<VulnProcessForm> vq = new LambdaQueryWrapper<>();
        vq.eq(VulnProcessForm::getIp, ip);
        vq.eq(VulnProcessForm::getSource, ScannerEnums.HUAWEI_SCANNER.getCode());
        vq.eq(VulnProcessForm::getCategory, ScanTypeEnums.WEAK_PASS_SCAN.getCode());
        List<VulnProcessForm> vulList = vulnProcessFormMapper.selectList(vq);
        List<VulnProcessForm> repairedList = new LinkedList<>();
        List<VulnProcessForm> unrepairedList = new LinkedList<>();
        List<VulnProcessForm> newVulList = new LinkedList<>();
        log.info(ip + " 库存弱口令：" + vulList.size() + " 当前有弱口令：" + culList.size());
        int newTotal = 0;
        int dropTotal = 0;
        //扫描到弱口令
        for (VulnProcessForm curVul : culList) {
            Asset asset = assetMapper.selectAssetByInnerIp(ip);
            if (asset == null) {
                asset = new Asset();
                asset.setSource(AssetSourceEnums.HUAWEI_CMDB.getCode());
                asset.setInternalIp(ip);
                CrcAssetSyncQueue.getInstance().saveAsset(asset);
            }
            //白名单
            if (WhiteListQuery.isWhiteList(curVul)) {
                dropTotal++;
                continue;
            }
            newVulList.add(curVul);
            //是否新弱口令
            boolean isnew = true;
            VulnProcessForm tmp = vulnProcessFormMapper.selectById(curVul.getId());
            if (tmp != null) {
                vulnProcessFormMapper.stillExist(curVul.getId());
                isnew = false;
            }

            if (isnew) {
                //新弱口令
                if (CommonAssemble.saveVul(curVul)) {
                    newTotal++;
                } else {
                    dropTotal++;
                }
            }
        }
        //已修复的弱口令判断
        for (VulnProcessForm oldVul : vulList) {
            boolean isRepair = true;
            for (VulnProcessForm newVul : newVulList) {
                //弱口令名称 节点IP是否相同
                if (newVul.getId().equalsIgnoreCase(oldVul.getId())) {
                    isRepair = false;
                    break;
                }
            }
            //弱口令已修复
            if (isRepair) {
                repairedList.add(oldVul);
            } else {
                //未修复
                unrepairedList.add(oldVul);
            }
        }
        log.info(ip + " @@@@@@@@@@@@库存弱口令：" + vulList.size() + " 丢弃弱口令：" + dropTotal + " 新增弱口令：" + newTotal + " 未修复弱口令：" + unrepairedList.size() + " 修复弱口令：" + repairedList.size());
        if (!repairedList.isEmpty()) {
            repairedList.forEach((CommonAssemble::repairedVul));
        }
        if (!unrepairedList.isEmpty()) {
            unrepairedList.forEach((CommonAssemble::unRepairedVul));
        }
    }

    private static VulnProcessForm getVulFromJsonXc(Long engineId, JSONObject json) {
        if (json == null || json.size() < 5) {
            return null;
        }
        String ip = JsonUtils.getStr(json, "ip_address");
        /*
        {
           "user":" root",  --用户名
           "passwd": " 123456",  --密码
          "service":" ssh",  --服务
        }
         */
        String vulName = JsonUtils.getStr(json, "user") + JsonUtils.getStr(json, "passwd") + JsonUtils.getStr(json, "service");
        if (StringUtils.isBlank(vulName)) {
            log.error("没有识别漏洞名称" + json.toJSONString());
            return null;
        }

        String desc = JsonUtils.getStr(json, "service") + "服务存在弱口令，登陆当前登陆账号：" + JsonUtils.getStr(json, "user");
        Date firstCheckDate = JsonUtils.getDate(json, "time");
        Date publicDate = JsonUtils.getDate(json, "time");
        String vulType = "常见弱密码";
        String solution = "请修改相关弱口令，并举一反三全面排查系统弱口令，增加口令默认配置策略。";

        //高危=4或者3，中危=2，低危=1或者0
        //我们0:低危, 1:中危, 2:高危, 3:严重
        int level = JsonUtils.getInt(json, "severity");
        if (level < 2) {
            level = 0;
        } else if (level == 2) {
            level = 1;
        } else {
            level = 2;
        }
        String filter = SyncSecConfigLoad.getRemarkValue(SyncSecConstants.HUAWEI_SYNC_ENABLE);
        try {
            boolean flag = false;
            if (filter != null && filter.contains("=") && filter.contains("level")) {
                String filterLevel = filter.split("=")[1];
                String slevel = JsonUtils.getStr(json, "severity");
                for (String fl : filterLevel.split(",")) {
                    if (StringUtils.isNotBlank(slevel) && slevel.equalsIgnoreCase(fl)) {
                        flag = true;
                        break;
                    }
                    if (level == 0 && "1".equalsIgnoreCase(fl)) {
                        flag = true;
                        break;
                    }
                }
            } else {
                flag = true;
            }
            if (!flag) {
                log.error("级别过滤" + level);
                return null;
            }
        } catch (Exception e) {
            log.error(e.getMessage(), e);
        }
        //漏洞特征 1：存在EXP 2：存在POC 3：远程执行 4：本地提权 5：内核漏洞
        List<String> feats = new ArrayList<>();
        VulnProcessForm vul = new VulnProcessForm();
        vul.setIp(ip);
        vul.setEngineId(engineId + "");
        vul.setVulnName(vulName);
        vul.setRefLink(JsonUtils.getStr(json, "seealso"));
        vul.setCode(String.format("VUL_%s", IdGen.uuid8()));
        vul.setLevel(level + "");
        vul.setCategory(ScanTypeEnums.WEAK_PASS_SCAN.getCode());
        vul.setSource(ScannerEnums.HUAWEI_SCANNER.getCode());
        String id = Md5Utils.hash(ip + "#" + vulName + "#" + "" + "#" + vul.getSource());
        vul.setId(id);
        vul.setVulnType(vulType);
        vul.setDescription(desc);
        vul.setSolution(solution);
        vul.setCreateTime(new Date());
        vul.setUpdateTime(new Date());
        vul.setFirstTime(firstCheckDate);
        vul.setRecentlyTime(firstCheckDate);
        vul.setPublishTime(publicDate);
        vul.setUserName(JsonUtils.getStr(json, "user"));
        vul.setPassword(JsonUtils.getStr(json, "passwd"));
        vul.setVulFeatures(String.join(",", feats));
        vul.setPort(JsonUtils.getStr(json, "port"));
        vul.setService(JsonUtils.getStr(json, "service"));
        vul.setStatus("0");
        if (StringUtils.isBlank(vul.getVulnType())) {
            vul.setVulnType("常见弱密码");
        }
        return vul;
    }

    private static VulnProcessForm getVulFromJson(Long engineId, JSONObject json, String ip) {
        if (json == null || json.size() < 5) {
            return null;
        }
        /*
        {
           "login":" root",  --用户名
            "host": " 172.16.10.11",  --主机名
           "password": " 123456",  --密码
           "port": " 22",  --端口
          "service":" ssh",  --服务
        }
         */
        String vulName = JsonUtils.getStr(json, "login") + JsonUtils.getStr(json, "host") + JsonUtils.getStr(json, "password") + JsonUtils.getStr(json, "service");
        if (StringUtils.isBlank(vulName)) {
            log.error("没有识别漏洞名称" + json.toJSONString());
            return null;
        }

        String desc = JsonUtils.getStr(json, "service") + "服务存在弱口令，登陆当前登陆账号：" + JsonUtils.getStr(json, "login");
//        String solution = JsonUtils.getStr(json, "proposal") + JsonUtils.getStr(json, "seealso");
        Date firstCheckDate = JsonUtils.getDate(json, "time");
        Date publicDate = JsonUtils.getDate(json, "time");
        String vulType = JsonUtils.getStr(json, "groupname");
        String solution = "请修改相关弱口令，并举一反三全面排查系统弱口令，增加口令默认配置策略。";

        //高危=4或者3，中危=2，低危=1或者0
        //我们0:低危, 1:中危, 2:高危, 3:严重
        int level = JsonUtils.getInt(json, "severity");
        if (level < 2) {
            level = 0;
        } else if (level == 2) {
            level = 1;
        } else {
            level = 2;
        }
        String filter = SyncSecConfigLoad.getRemarkValue(SyncSecConstants.HUAWEI_SYNC_ENABLE);
        try {
            boolean flag = false;
            if (filter != null && filter.contains("=") && filter.contains("level")) {
                String filterLevel = filter.split("=")[1];
                String slevel = JsonUtils.getStr(json, "severity");
                for (String fl : filterLevel.split(",")) {
                    if (StringUtils.isNotBlank(slevel) && slevel.equalsIgnoreCase(fl)) {
                        flag = true;
                        break;
                    }
                    if (level == 0 && "1".equalsIgnoreCase(fl)) {
                        flag = true;
                        break;
                    }
                }
            } else {
                flag = true;
            }
            if (!flag) {
                log.error("级别过滤" + level);
                return null;
            }
        } catch (Exception e) {
            log.error(e.getMessage(), e);
        }
        //漏洞特征 1：存在EXP 2：存在POC 3：远程执行 4：本地提权 5：内核漏洞
        List<String> feats = new ArrayList<>();
        if (json.containsKey("hasExp")) {
            if (json.getBoolean("hasExp")) {
                feats.add("1");
            }
        }
        if (json.containsKey("hasPoc")) {
            if (json.getBoolean("hasPoc")) {
                feats.add("2");
            }
        }
        if (json.containsKey("remote")) {
            if (json.getBoolean("remote")) {
                feats.add("3");
            }
        }
        if (json.containsKey("localEscalation")) {
            if (json.getBoolean("localEscalation")) {
                feats.add("4");
            }
        }
        if (json.containsKey("kernel")) {
            if (json.getBoolean("kernel")) {
                feats.add("5");
            }
        }
        String CVE = JsonUtils.getStr(json, "cves");
        String cvss = JsonUtils.getStr(json, "cvss_vector");
        VulnProcessForm vul = new VulnProcessForm();
        vul.setIp(ip);
        vul.setEngineId(engineId + "");
        vul.setVulnName(vulName);
        vul.setCvss(CvssUtils.getScore(cvss));
        vul.setRefLink(JsonUtils.getStr(json, "seealso"));
        vul.setCode(String.format("VUL_%s", IdGen.uuid8()));
        vul.setLevel(level + "");
        vul.setCategory(ScanTypeEnums.WEAK_PASS_SCAN.getCode());
        vul.setSource(ScannerEnums.HUAWEI_SCANNER.getCode());
        String id = Md5Utils.hash(ip + "#" + vulName + "#" + CVE + "#" + vul.getSource());
        vul.setId(id);
        vul.setVulnType(vulType);
        vul.setDescription(desc);
        vul.setSolution(solution);
        vul.setCveCode(CVE);
        vul.setCreateTime(new Date());
        vul.setUpdateTime(new Date());
        vul.setFirstTime(firstCheckDate);
        vul.setRecentlyTime(firstCheckDate);
        vul.setPublishTime(publicDate);
        vul.setUserName(JsonUtils.getStr(json, "login"));
        vul.setPassword(JsonUtils.getStr(json, "password"));
        vul.setVulFeatures(String.join(",", feats));
        vul.setPort(JsonUtils.getStr(json, "port"));
        vul.setService(JsonUtils.getStr(json, "service"));
        vul.setStatus("0");
        if (StringUtils.isBlank(vul.getVulnType())) {
            vul.setVulnType("常见弱密码");
        }
        CommonAssemble.saveVulAssetInfo(vul, ip);
        return vul;
    }

    /**
     * IP全部修复
     *
     * @param ip IP
     */
    public static void repairAllByIp(String ip) {
        try {
            CommonAssemble.repairAll(ip, ScannerEnums.HUAWEI_SCANNER.getCode(), ScanTypeEnums.WEAK_PASS_SCAN.getCode());
        } catch (Exception e) {
            log.error(e.getMessage(), e);
        }
    }

    private static Asset saveHuaweiAsset(JSONObject detail) {
        Asset asset = new Asset();
        try {
           /* "end": "2018-08-19 14:22:43",  --检测结束时间
            "start": "2018-08-19 14:01:22",  --检测开始时间
            "mac": "00:1b:c0:b9:20:80",  --MAC地址
            "ip": "49.4.162.66",  --IP地址
            "os": "FortiOS on Fortinet FortiGate",  --操作系统*/
            asset.setInternalIp(JsonUtils.getStr(detail, "ip"));
            asset.setOs(JsonUtils.getStr(detail, "os"));
            asset.setMacAddress(JsonUtils.getStr(detail, "mac"));
            asset.setSource(AssetSourceEnums.HUAWEI_CMDB.getCode());
            CrcAssetSyncQueue.getInstance().saveAsset(asset);

            /*"port_list": [                  --端口列表
            {
                "port": "22",
                    "service": "ssh"，
                "protocol": "tcp"
            }
			  ]
             */
            if (detail != null) {
                JSONArray retArr = detail.getJSONArray("port_list");
                if (retArr != null && retArr.size() > 0) {
                    for (int i = 0; i < retArr.size(); i++) {
                        JSONObject host = retArr.getJSONObject(i);
                        AssetPort port = new AssetPort();
                        port.setIp(asset.getInternalIp());
                        port.setPort(JsonUtils.getStr(host, "port"));
                        port.setType(JsonUtils.getStr(host, "service"));
                        port.setProto(JsonUtils.getStr(host, "protocol"));
                        port.setSyncStatus(AssetSourceEnums.HUAWEI_CMDB.getCode());
                        PortSaveWork.magicQueue.put(port);
                    }
                }
            }

        } catch (Exception e) {
            log.error(e.getMessage(), e);
        }
        return asset;
    }
}
