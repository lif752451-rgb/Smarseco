package com.crc.secface.schedule.assemble.asset;

import com.alibaba.fastjson.JSONObject;
import com.crc.common.utils.DictUtil;
import com.crc.common.utils.HttpUtils;
import com.crc.common.utils.JsonUtils;
import com.crc.secface.config.GetSpringBean;
import com.crc.secface.domain.Asset;
import com.crc.secface.domain.SysDictData;
import com.crc.secface.mapper.AssetMapper;
import com.crc.sync.config.SyncSecConstants;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.collections4.CollectionUtils;
import org.apache.commons.lang3.StringUtils;

import java.util.List;
import java.util.Objects;

/**
 * <p>
 * 安恒资产回传
 * </p>
 *
 * @author yuyuhang5
 * @Date 2024/9/9 15:15
 * @Description AnhengAssetAssemble
 */

@Slf4j
public class AnhengAssetAssemble {

    public static void updateAsset(String source, List<Asset> updateAssetList) {
        if (CollectionUtils.isNotEmpty(updateAssetList)) {
            // 同步安恒资产系统配置
            SysDictData sysDictData = DictUtil.getDictTypeAndValueLabel(SyncSecConstants.SYNC_SEC_CONFIG, SyncSecConstants.AN_HENG_LOGIN_CONFIG, source);
            if (Objects.nonNull(sysDictData) && StringUtils.isNotBlank(sysDictData.getRemark())) {
                JSONObject config = JsonUtils.parse(sysDictData.getRemark());
                proc(config, updateAssetList);
            } else {
                log.info("更新安恒资产-数据字典不存在");
            }
        }
    }

    private static void proc(JSONObject config, List<Asset> updateAssetList) {
        AssetMapper assetMapper = GetSpringBean.getBean(AssetMapper.class);
        for (Asset asset : updateAssetList) {
            try {
                JSONObject headers = new JSONObject();
                headers.put("apiKey", config.getString("token"));
                String url = config.getString("infoUrl") + asset.getUniqueCode();
                String dataStr = HttpUtils.sendGet(url, null, headers);
                if (StringUtils.isEmpty(dataStr)) {
                    log.error("更新安恒资产-调用API返回数据为空");
                    return;
                }
                JSONObject dataJson = JsonUtils.parse(dataStr);
                if (JsonUtils.isEmpty(dataJson)) {
                    log.error("更新安恒资产-调用API返回数据格式异常");
                    return;
                }
                JSONObject responseJson = dataJson.getJSONObject("data");
                if (JsonUtils.isEmpty(responseJson)) {
                    log.error("更新安恒资产-调用API返回数据data为空,AssetId:{},返回信息：{}", asset.getUniqueCode(), dataStr);
                    continue;
                }
                JSONObject request = new JSONObject();
                request.put("assetId", asset.getUniqueCode());
                request.put("assetName", asset.getInstance());
                request.put("orgId", responseJson.getString("orgId"));
                request.put("assetType", responseJson.getString("assetType"));
                request.put("assetIdentifications", responseJson.getJSONArray("assetIdentifications"));
                /*
                 * 返回值示例
                 * {"error":{"code":"BadArgument","message":"组织架构ID错误"}}
                 * {"data":"修改资产成功"}
                 */
                String resultStr = HttpUtils.sendPost(config.getString("updateUrl"), request.toJSONString(), headers);
                JSONObject resultJson = JsonUtils.parse(resultStr);
                if (!JsonUtils.isEmpty(resultJson)) {
                    log.info("更新安恒资产-返回数据:{}", resultStr);
                    assetMapper.updateAssetFlag(asset.getId());
                }
            } catch (Exception e) {
                log.error("更新安恒资产-调用接口异常", e);
            }
        }
    }
}
