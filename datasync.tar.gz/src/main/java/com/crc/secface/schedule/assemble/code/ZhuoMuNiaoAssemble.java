package com.crc.secface.schedule.assemble.code;

import cn.hutool.core.io.FileUtil;
import com.alibaba.fastjson.JSONArray;
import com.alibaba.fastjson.JSONObject;
import com.baomidou.mybatisplus.core.conditions.query.LambdaQueryWrapper;
import com.crc.common.code.SimpleCodeTool;
import com.crc.common.enums.CheckStatusEnums;
import com.crc.common.enums.CodeCheckResultEnum;
import com.crc.common.enums.ScannerEnums;
import com.crc.common.utils.*;
import com.crc.scanner.config.ZhuoMuNiaoConfig;
import com.crc.scanner.tool.ZhuoMuNiaoUtils;
import com.crc.secface.config.GetSpringBean;
import com.crc.secface.domain.*;
import com.crc.secface.mapper.*;
import com.crc.secface.schedule.assemble.CommonAssemble;
import com.crc.sync.config.SyncSecConfigLoad;
import com.crc.sync.config.SyncSecConstants;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;

import java.io.File;
import java.net.URLEncoder;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

@Slf4j
public class ZhuoMuNiaoAssemble {
    public static void addTask() {
        try {
            CodeCheckRecordMapper taskRecordMapper = GetSpringBean.getBean(CodeCheckRecordMapper.class);
            CodeCheckTaskMapper scanTaskMapper = GetSpringBean.getBean(CodeCheckTaskMapper.class);
            CodeCheckRecordLogMapper taskRecordLogMapper = GetSpringBean.getBean(CodeCheckRecordLogMapper.class);
            CodeAuditApplicationMapper applicationMapper = GetSpringBean.getBean(CodeAuditApplicationMapper.class);
            CodeAuditProjectMapper projectMapper = GetSpringBean.getBean(CodeAuditProjectMapper.class);
            LambdaQueryWrapper<CodeCheckRecord> q = new LambdaQueryWrapper<>();
            q.eq(CodeCheckRecord::getResult, CodeCheckResultEnum.WAIT.getResult());
            List<CodeCheckRecord> list = taskRecordMapper.selectList(q);
            for (CodeCheckRecord record : list) {
                try {
                    ZhuoMuNiaoConfig scannerInfo = getEngine();
                    if (scannerInfo == null) {
                        log.error("没有代码扫描引擎配置信息！");
                        return;
                    }
                    CodeCheckTask task = scanTaskMapper.selectById(record.getTaskId());
                    if (task == null || task.getAppId() == null) {
                        log.error("没有具体任务或任务已经不存在！");
                        continue;
                    }
                    LambdaQueryWrapper<CodeCheckRecordLog> qlog = new LambdaQueryWrapper<>();
                    qlog.eq(CodeCheckRecordLog::getRecordId, record.getId());
                    qlog.eq(CodeCheckRecordLog::getTaskId, task.getId());
                    if (taskRecordLogMapper.selectCount(qlog) > 0) {
                        log.info("{}{},已在执行中", task.getTaskName(), task.getId());
                        continue;
                    }
                    CodeAuditApplication app = applicationMapper.selectById(task.getAppId());
                    if (app == null) {
                        log.error("没有具体应用或应用已经不存在！");
                        CommonAssemble.startCodeFail(task);
                        continue;
                    }
                    CodeAuditProject project = projectMapper.getProjct(app.getProjectId());
                    if (project == null) {
                        log.error("没有具体应用关联项目或应用关联项目已经不存在！");
                        CommonAssemble.startCodeFail(task);
                        continue;
                    }
                    CodeCheckRecordLog recordLog = new CodeCheckRecordLog();
                    recordLog.setAppId(task.getAppId());
                    recordLog.setTaskId(record.getTaskId());
                    recordLog.setTaskName(task.getTaskName());
                    recordLog.setRecordId(record.getId());
                    recordLog.setCreateTime(new Date());
                    //任务状态(0 未开始 1 执行中 2 执行完成 3 执行失败)
                    recordLog.setScanStatus(0);

                    SysDictData langDict = DictUtil.getDictByValue("codereview_scan_language_type", task.getLang());
                    SysDictData levelDict = DictUtil.getDictByValue("codereview_scan_safety_level", task.getSafetyLevel());
                    String lang = "JAVA";
                    if (!DataUtils.isBlankDict(langDict)){
                        lang = langDict.getDictLabel();
                    }
                    String projectLevel = "default";
                    if (!DataUtils.isBlankDict(levelDict)) {
                        projectLevel = levelDict.getDictValue();
                    }

                    //代码来源 1：git 2：SVN 3：上传源码
                    String id = "";
                    JSONObject param = new JSONObject();
                    if ("1".equals(task.getSource())) {
                        param.put("langType", lang);
                        param.put("projectLevel", projectLevel);
                        param.put("ruleId", task.getRuleId());
                        param.put("defectType", task.getDefectType());
                        //1：SVN；2：GIT
                        param.put("downloadType", 2);
                        param.put("svngitUrl", app.getAddress());
                        param.put("mavenUrl", app.getMavenUrl());
                        param.put("projectId", app.getProjectId());
                        param.put("email", project.getProjectDutyMail());
                        param.put("svngitUserName", app.getUserName());
                        param.put("svngitPassword", app.getPassWord());
                        param.put("gitBranchName", app.getBranch());
                        param.put("projectGroupId", ZhuoMuNiaoUtils.getProjId(scannerInfo));
                        if ("JAVA".equals(lang)) {
                            param.put("isClass", 1);
                        } else {
                            param.put("isClass", 0);
                        }
                        param.put("increment", 0);
                        param.put("carryAudit", 0);
                        id = ZhuoMuNiaoUtils.addTask(scannerInfo, param, task.getTaskName());
                    } else if ("2".equals(task.getSource())) {
                        param.put("langType", lang);
                        param.put("projectLevel", projectLevel);
                        param.put("ruleId", task.getRuleId());
                        param.put("defectType", task.getDefectType());
                        //1：SVN；2：GIT
                        param.put("downloadType", 1);
                        param.put("svngitUrl", app.getAddress());
                        param.put("mavenUrl", app.getMavenUrl());
                        param.put("projectId", app.getProjectId());
                        param.put("email", project.getProjectDutyMail());
                        param.put("svngitUserName", app.getUserName());
                        param.put("svngitPassword", app.getPassWord());
                        param.put("gitBranchName", app.getBranch());
                        param.put("projectGroupId", ZhuoMuNiaoUtils.getProjId(scannerInfo));
                        if ("JAVA".equals(lang)) {
                            param.put("isClass", 1);
                        } else {
                            param.put("isClass", 0);
                        }
                        param.put("increment", 0);
                        param.put("carryAudit", 0);
                        id = ZhuoMuNiaoUtils.addTask(scannerInfo, param, task.getTaskName());
                    } else if ("3".equals(task.getSource())) {
                        //[{"fileName":"zip.zip","name":"zip.zip","url":"/profile/upload/2023/01/11/202301111402071960000.zip"}]
                        JSONArray jsonArray = JsonUtils.parseArray(task.getFileJson());
                        if (jsonArray == null || jsonArray.size() < 1) {
                            log.error("{}未知安全代码扫描未检测附件：{}", task.getTaskName(), task.getSource());
                            CommonAssemble.startCodeFail(task);
                            continue;
                        }
                        String filePath = JsonUtils.getStr(jsonArray.getJSONObject(0), "url");
                        log.info("原附件地址="+filePath);
                        SysDictData stpUploadDict = DictUtil.getDictByValue(SyncSecConstants.SYNC_SEC_CONFIG, SyncSecConstants.STP_UPLOAD_CONFIG);
                        if (!DataUtils.isBlankDict(stpUploadDict)) {
                            JSONObject stpConfig = JsonUtils.parse(stpUploadDict.getRemark());
                            if(stpConfig.size() > 0) {
                                String fp = JsonUtils.getStr(stpConfig, "fakePre");
                                String np = JsonUtils.getStr(stpConfig, "truePre");
                                filePath = filePath.replace(fp, np);
                            }
                        }else {
                            log.error("未配置检测附件根路径：STP_UPLOAD_CONFIG");
                            CommonAssemble.startCodeFail(task);
                            continue;
                        }
                        if (StringUtils.isBlank(filePath) || !FileUtil.exist(filePath)) {
                            log.error("{}==未知安全代码扫描未检测附件：{}", task.getTaskName(), task.getFileJson());
                            CommonAssemble.startCodeFail(task);
                            continue;
                        }
                        //auth、uploadFile、projectId、projectLevel、langType
                        param.put("projectId", app.getProjectId());
                        param.put("langType", lang);
                        param.put("projectLevel", projectLevel);
                        if(StringUtils.isNoneBlank(task.getRuleId())) {
                            param.put("ruleId", task.getRuleId());
                        }
                        if(StringUtils.isNoneBlank(task.getDefectType())) {
                            param.put("defectType", task.getDefectType());
                        }
                        //1：SVN；2：GIT
                        //param.put("downloadType", 1);
                        //param.put("svngitUrl", app.getAddress());
                        //param.put("mavenUrl", app.getMavenUrl());
                        //param.put("email", project.getProjectDutyMail());
                        //param.put("svngitUserName", app.getUserName());
                        //param.put("svngitPassword", app.getPassWord());
                        //param.put("gitBranchName", app.getBranch());
                        //param.put("projectGroupId", ZhuoMuNiaoUtils.getProjId(scannerInfo));
//                        if ("JAVA".equals(lang)) {
//                            param.put("isClass", 1);
//                        } else {
//                            param.put("isClass", 0);
//                        }
                        //param.put("increment", 0);
                        //param.put("carryAudit", 0);

                        id = ZhuoMuNiaoUtils.addFileTask(scannerInfo, param, task.getTaskName(), filePath);
                    } else {
                        log.error("{}未知安全代码扫描来源：{}", task.getTaskName(), task.getSource());
                        CommonAssemble.startCodeFail(task);
                        continue;
                    }
                    String taskMsg = "执行成功";
                    boolean flag = false;
                    if (StringUtils.isNotBlank(id)) {
                        recordLog.setScanStatus(1);
                        recordLog.setJobId(id);
                        recordLog.setResult(taskMsg);
                        taskRecordLogMapper.insert(recordLog);
                        flag = true;
                    } else {
                        //失败
                        recordLog.setScanStatus(3);
                        taskMsg = "执行失败";
                        recordLog.setResult(taskMsg);
                        taskRecordLogMapper.insert(recordLog);
                        CommonAssemble.startCodeFail(recordLog);
                    }

                    log.info("创建任务:" + task.getTaskName() + " -> " + taskMsg + " 返回ID：" + id);

                    if (flag) {
                        task.setStatus(CheckStatusEnums.CHECK_ING.getCode());
                        scanTaskMapper.updateCodeCheckTask(task);
                    }
                    applicationMapper.updateAppCheckCount(app.getId());
                    applicationMapper.updateProjCheckCount(app);
                } catch (Exception e) {
                    log.error(e.getMessage(), e);
                }
            }
        } catch (Exception e) {
            log.error(e.getMessage(), e);
        }
    }

    public static ZhuoMuNiaoConfig getZhuoMuNiaoConfig(Long engineId) {
        EngineEquipmentManagement engine = CommonAssemble.engineMap.get(engineId);
        ZhuoMuNiaoConfig qtConfig = new ZhuoMuNiaoConfig();
        if (engine == null || engine.getId() == null) {
            return qtConfig;
        }
        qtConfig.setEngineId(engineId);
        String PASS = engine.getPassword().trim();
        qtConfig.setPassword(PASS);
        try {
            PASS = SimpleCodeTool.decrypt(PASS);
            qtConfig.setPassword(PASS);
        } catch (Exception e) {
            log.error(e.getMessage(), e);
        }
        qtConfig.setUsername(engine.getLoginUser());
        qtConfig.setAddress(engine.getEquipmentAddress());
        return qtConfig;
    }

    public static void getTask() {
        CodeCheckRecordMapper taskRecordMapper = GetSpringBean.getBean(CodeCheckRecordMapper.class);
        CodeCheckRecordLogMapper taskRecordLogMapper = GetSpringBean.getBean(CodeCheckRecordLogMapper.class);
        CodeCheckTaskMapper scanTaskMapper = GetSpringBean.getBean(CodeCheckTaskMapper.class);
        try {
            LambdaQueryWrapper<CodeCheckRecordLog> q = new LambdaQueryWrapper<>();
            //任务状态(0 未开始 1 执行中 2 执行完成 3 执行失败)
            q.eq(CodeCheckRecordLog::getScanStatus, 1);
            List<CodeCheckRecordLog> recordList = taskRecordLogMapper.selectList(q);
            for (CodeCheckRecordLog task : recordList) {
                try {
                    ZhuoMuNiaoConfig scannerInfo = getEngine();
                    if (scannerInfo == null) {
                        log.error("没有代码扫描引擎配置信息！");
                        continue;
                    }
                    // 扫描任务id
                    ///async/status/?&taskid=xxx&user=xxx&pwd=xxx
                    String taskStatus = ZhuoMuNiaoUtils.getTaskStatus(scannerInfo, task.getTaskId(), task.getJobId());
                    /*
                     * {
                     * "code":"1",
                     * "msg":"成功",
                     * "data":{
                     * "machineTotal":2,
                     * "machineCompletions":1,
                     * "status":1
                     */

                    if (StringUtils.isNotBlank(taskStatus)) {
                        //taskStatus: 该检测任务的当前状态码：0上传成功或解压失败；1已解压待检测；2检测中；3检测完成；4检测异常；99排队中；
                        int istatus = DataUtils.toInt(taskStatus);
                        boolean stop = false;
                        int progress = 0;
                        if (istatus == 0 || istatus == 1 || istatus == 2 || istatus == 4 || istatus == 99) {
                            //进行中
                        } else if (istatus == 3) {
                            progress = 100;
                        } else {
                            stop = true;
                        }

                        task.setProgress(progress);
                        int status = 1;
                        if (task.getProgress() == 100) {
                            status = 2;
                        }

                        if (stop) {
                            log.error("任务异常停止:" + task.getTaskId() + " -> " + " 进度：" + progress + ",status=" + istatus);
                            status = 2;
                        } else {
                            log.info("读取任务:" + task.getTaskId() + " -> " + " 进度：" + progress + ",status=" + istatus);
                        }
                        task.setScanStatus(status);
                        taskRecordLogMapper.updateById(task);
                        if (task.getProgress() == 100 && !stop) {
                            int total = 0;
                            JSONArray problemList = null;
                            JSONObject one = ZhuoMuNiaoUtils.getTask(scannerInfo, task.getTaskId(), task.getJobId(), 1);
                            if (one != null) {
                                problemList = one.getJSONArray("problem");
                                total = JsonUtils.getInt(one, "problemCount");
                                int pageNum = DataUtils.roundUp(500, total);
                                for (int i = 2; i <= pageNum; i++) {
                                    JSONObject two = ZhuoMuNiaoUtils.getTask(scannerInfo, task.getTaskId(), task.getJobId(), 1);
                                    if (two == null) {
                                        continue;
                                    }
                                    if (problemList == null) {
                                        problemList = two.getJSONArray("problem");
                                    } else {
                                        problemList.addAll(two.getJSONArray("problem"));
                                    }
                                }
                                total = problemList.size();
                                log.info(task.getTaskId() + "已完成的即时任务:" + total);
                            }
                            if (total > 0) {
                                handle(scannerInfo, problemList, task.getRecordId(), task.getJobId(), task.getAppId());
                            } else {
                                handle(scannerInfo, null, task.getRecordId(), task.getJobId(), task.getAppId());
                            }
                        }
                    }


                    /*
                     * 更新业务段任务进度
                     */
                    try {
                        CodeCheckRecord taskRecord = taskRecordMapper.selectById(task.getRecordId());
                        taskRecord.setProgress(task.getProgress());
                        if (task.getProgress() != null && task.getProgress() == 100) {
                            taskRecord.setCheckEndTime(new Date());
                            taskRecord.setCheckConsuming(DateUtils.getDiffSec(taskRecord.getCheckStartTime(), taskRecord.getCheckEndTime()));
                            taskRecord.setResult("1");
                            taskRecord.setProgress(100);
                            taskRecordMapper.updateCodeCheckRecord(taskRecord);
                        }

                        CodeCheckTask scanTask = new CodeCheckTask();
                        scanTask.setId(taskRecord.getTaskId());
                        scanTask.setUpdateTime(new Date());

                        if ("1".equals(taskRecord.getResult())) {
                            scanTask.setStatus(CheckStatusEnums.CHECK_FINISH.getCode());
                            scanTaskMapper.updateCodeCheckTask(scanTask);
                        }

                    } catch (Exception e) {
                        log.error(e.getMessage(), e);
                    }
                } catch (Exception e) {
                    log.error(e.getMessage(), e);
                }
            }
        } catch (Exception e) {
            log.error(e.getMessage(), e);
        }
    }

    private static void handle(ZhuoMuNiaoConfig config, JSONArray problemList, Long rocordId, String jobId, Long appId) {
        try {
            int y = 0;
            int g = 0;
            int z = 0;
            int d = 0;
            int f = 0;
            int total = 0;
            if (problemList != null) {
                total = problemList.size();
                for (int i = 0; i < total; i++) {
                    JSONObject json = problemList.getJSONObject(i);
                    //缺陷风险等级，所填数字释义：1严重,2高危,3中级,4低,5警告信息
                    if (JsonUtils.equal(json, "severityLevel", "1")) {
                        y++;
                    } else if (JsonUtils.equal(json, "severityLevel", "2")) {
                        g++;
                    } else if (JsonUtils.equal(json, "severityLevel", "3")) {
                        z++;
                    } else if (JsonUtils.equal(json, "severityLevel", "4")) {
                        d++;
                    } else {
                        f++;
                    }
                }
            }
            CodeAuditDefect codeAuditDefect = new CodeAuditDefect();
            codeAuditDefect.setCodeId(String.format("DE_%s", IdGen.uuid8()));
            codeAuditDefect.setAppId(appId);
            codeAuditDefect.setCreateBy("系统");
            codeAuditDefect.setCreateByLabel("系统");
            codeAuditDefect.setDelFlag(0);
            codeAuditDefect.setSeriousNum(y);
            codeAuditDefect.setHighRiskNum(g);
            codeAuditDefect.setMidRiskNum(z);
            codeAuditDefect.setLowRiskNum(d);
            codeAuditDefect.setInfoRiskNum(f);
            codeAuditDefect.setCreateTime(new Date());
            codeAuditDefect.setUpdateTime(new Date());
            codeAuditDefect.setTotalNum(total);
            codeAuditDefect.setStatus(0);
            codeAuditDefect.setSource("0");

            CodeAuditDefectMapper codeAuditDefectMapper = GetSpringBean.getBean(CodeAuditDefectMapper.class);
            CodeAuditDefect codeInfo = codeAuditDefectMapper.getCodeAuditRefInfo(appId);
            if (codeInfo != null) {
                codeAuditDefect.setProjectDuty(codeInfo.getProjectDuty());
                codeAuditDefect.setProjectDutyLabel(codeInfo.getProjectDutyLabel());
                codeAuditDefect.setAffiliationDeptName(codeInfo.getAffiliationDeptName());
                codeAuditDefect.setAffiliationDeptNodeId(codeInfo.getAffiliationDeptNodeId());
                codeAuditDefect.setAppName(codeInfo.getAppName());
                codeAuditDefect.setProjectName(codeInfo.getProjectName());
            }
            codeAuditDefectMapper.insert(codeAuditDefect);


            CodeCheckRecordMapper codeCheckRecordMapper = GetSpringBean.getBean(CodeCheckRecordMapper.class);
            CodeCheckRecord codeCheckRecord = new CodeCheckRecord();
            codeCheckRecord.setId(rocordId);
            codeCheckRecord.setDefectId(codeAuditDefect.getId());
            codeCheckRecordMapper.updateCodeCheckRecord(codeCheckRecord);
            String filePath = ZhuoMuNiaoUtils.getReport(config, jobId);
            if (StringUtils.isNotBlank(filePath)) {
                //String url = "https://dt_stp_dev.crc.com.cn/stp-stage-api/common/att/open/upload";
                String url = SyncSecConfigLoad.getRemarkValue(SyncSecConstants.STP_API_URL) + "/common/att/open/upload";
                JSONObject jsonObject = new JSONObject();
                jsonObject.put("businessId", codeAuditDefect.getId());
                jsonObject.put("businessType", "codeAuditDefect");
                String filename = "代码审计报告" + DateUtils.getDate1();
                filename = URLEncoder.encode(filename, "UTF-8");
                jsonObject.put("fileName", filename);
                String id = HttpFileUtils.sendPostFile(url, jsonObject, new File(filePath));
                log.info("@@{},上传文件成功，id={}", filePath, id);
            }

        } catch (Exception e) {
            log.error(e.getMessage(), e);
        }
    }

    public static ZhuoMuNiaoConfig getEngine() {
        try {
            for (Long id : CommonAssemble.engineMap.keySet()) {
                if (ScannerEnums.ZHUOMUNIAO_SCANNER.getCode().equals(CommonAssemble.engineMap.get(id).getEquipmentManufacture())) {
                    return getZhuoMuNiaoConfig(id);
                }
            }
        } catch (Exception e) {
            log.error(e.getMessage(), e);
        }
        return null;
    }

    public static void syncBaseData() {
        try {
            CommonAssemble.engineMap.forEach((k, v) -> {
                if (ScannerEnums.ZHUOMUNIAO_SCANNER.getCode().equals(v.getEquipmentManufacture())) {
                    try {
                        getLanguageList(getZhuoMuNiaoConfig(k));
                    } catch (Exception e) {
                        log.error(e.getMessage(), e);
                    }

                    try {
                        getRuleList(getZhuoMuNiaoConfig(k));
                    } catch (Exception e) {
                        log.error(e.getMessage(), e);
                    }
                }
            });
        } catch (Exception e) {
            log.error(e.getMessage(), e);
        }
    }

    private static void getLanguageList(ZhuoMuNiaoConfig zhuoMuNiaoConfig) {
        List<String> list = ZhuoMuNiaoUtils.getLanguageList(zhuoMuNiaoConfig);
        List<SysDictData> dataList = DictUtil.getDict("codereview_scan_language_type");
        if (dataList == null || dataList.size() < 1) {
            dataList = new ArrayList<>();
        }
        int max = 0;
        for (SysDictData dictData : dataList) {
            int code = DataUtils.getInt(dictData.getDictValue());
            if (code > max) {
                max = code;
            }
        }
        SysDictDataMapper sysDictDataService = GetSpringBean.getBean(SysDictDataMapper.class);
        Map<String, String> dictMap = dataList.stream().collect(Collectors.toMap(SysDictData::getDictLabel, SysDictData::getDictValue));
        for (String lang : list) {
            if (!dictMap.containsKey(lang)) {
                SysDictData sysDictData = new SysDictData();
                sysDictData.setDictLabel(lang);
                max = max + 1;
                sysDictData.setStatus("0");
                sysDictData.setDictValue(max + "");
                sysDictData.setDictSort(max);
                sysDictData.setCreateTime(new Date());
                sysDictData.setDictType("codereview_scan_language_type");
                sysDictDataService.insert(sysDictData);
            }
        }
    }

    private static void getRuleList(ZhuoMuNiaoConfig zhuoMuNiaoConfig) {
        try {
            List<CodeCheckRule> list = ZhuoMuNiaoUtils.getRuleList(zhuoMuNiaoConfig);

            CodeCheckRuleMapper codeCheckRuleMapper = GetSpringBean.getBean(CodeCheckRuleMapper.class);
            for (CodeCheckRule rule : list) {
                if (StringUtils.isNotBlank(rule.getId())) {
                    CodeCheckRule tmp = codeCheckRuleMapper.selectById(rule.getId());
                    if (tmp == null) {
                        codeCheckRuleMapper.insert(rule);
                    }
                }
            }
        } catch (Exception e) {
            log.error(e.getMessage(), e);
        }
    }
}
