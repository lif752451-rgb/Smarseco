package com.crc.secface.schedule;

import com.baomidou.mybatisplus.core.conditions.query.LambdaQueryWrapper;
import com.crc.common.utils.MyTheadUtils;
import com.crc.secface.domain.EngineEquipmentManagement;
import com.crc.secface.domain.VulnProcessRepairCycle;
import com.crc.secface.mapper.EngineEquipmentManagementMapper;
import com.crc.secface.mapper.VulnProcessRepairCycleMapper;
import com.crc.secface.schedule.assemble.CommonAssemble;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.scheduling.annotation.EnableScheduling;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Component;

import java.util.HashMap;
import java.util.List;

/*
 * 集团网段加载功能
 */

@Slf4j
@Component
@EnableScheduling
public class ScanEngineSchedule implements CommandLineRunner {
    @Override
    public void run(String... args) {
        sync();
    }


    @Autowired
    EngineEquipmentManagementMapper engineEquipmentManagementMapper;
    @Autowired
    VulnProcessRepairCycleMapper vulnProcessRepairCycleMapper;

    /**
     * 每N分钟统计一次
     */
    @Scheduled(cron = "0 * * * * *")
    public void sync() {
        MyTheadUtils.sleepBySec(5);
        try {
            HashMap<Long, String> linshiMap = new HashMap<>();
            try {
                LambdaQueryWrapper<EngineEquipmentManagement> query = new LambdaQueryWrapper<>();
                query.eq(EngineEquipmentManagement::getDelFlag, 0);
                //query.eq(EngineEquipmentManagement::getEnabled, 1);
                query.orderByDesc(EngineEquipmentManagement::getUpdateTime);
                List<EngineEquipmentManagement> listAll = engineEquipmentManagementMapper.selectList(query);
                for (EngineEquipmentManagement seg : listAll) {
                    try {
                        CommonAssemble.engineMap.put(seg.getId(), seg);
                        linshiMap.put(seg.getId(), "1");
                    } catch (Exception e) {
                        log.error(e.getMessage(), e);
                    }
                }
            } catch (Exception e) {
                log.error(e.getMessage(), e);
            }
            HashMap<Long, String> linshiMap2 = new HashMap<>();
            CommonAssemble.engineMap.forEach((k, v) -> {
                if (!linshiMap.containsKey(k)) {
                    linshiMap2.put(k, "1");
                }
            });
            linshiMap2.forEach((k, v) -> {
                CommonAssemble.engineMap.remove(k);
            });
            log.info("加载引擎信息数：" + CommonAssemble.engineMap.size());
            CommonAssemble.engineMap.forEach((k,v)->{
                log.info("引擎:{},url:{}",v.getEquipmentName(),v.getEquipmentAddress());
            });
        } catch (Exception e) {
            log.error(e.getMessage(), e);
        }




        try {
            try {
                LambdaQueryWrapper<VulnProcessRepairCycle> query = new LambdaQueryWrapper<>();
                query.eq(VulnProcessRepairCycle::getDelFlag, 0);
                List<VulnProcessRepairCycle> listAll = vulnProcessRepairCycleMapper.selectList(query);
                for (VulnProcessRepairCycle seg : listAll) {
                    try {
                        CommonAssemble.repairCycleMap.put(seg.getId(), seg);
                    } catch (Exception e) {
                        log.error(e.getMessage(), e);
                    }

                }
            } catch (Exception e) {
                log.error(e.getMessage(), e);
            }
            log.info("加载修复截止时间信息数：" + CommonAssemble.repairCycleMap.size());
        } catch (Exception e) {
            log.error(e.getMessage(), e);
        }
        MyTheadUtils.sleepBySec(5);
    }
}