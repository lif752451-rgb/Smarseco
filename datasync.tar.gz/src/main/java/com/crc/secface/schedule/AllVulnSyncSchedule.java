package com.crc.secface.schedule;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;
import com.crc.common.enums.ScannerEnums;
import com.crc.common.utils.DateUtils;
import com.crc.common.utils.DictUtil;
import com.crc.msg.qywx.QyweixinSend;
import com.crc.secface.config.GetSpringBean;
import com.crc.secface.domain.MailDTO;
import com.crc.secface.domain.VulnScanTaskSync;
import com.crc.secface.mapper.CommonMapper;
import com.crc.secface.schedule.assemble.CommonAssemble;
import com.crc.secface.schedule.assemble.host.DccAssemble;
import com.crc.secface.schedule.assemble.host.FoeyeAssemble;
import com.crc.secface.service.MailService;
import com.crc.sync.config.SyncSecConfigLoad;
import com.crc.sync.config.SyncSecConstants;
import com.crc.sync.qingteng.QingtengAllWeakPassSync;
import com.crc.sync.qingteng.v2.QingtengAllRiskSync;
import com.crc.sync.safedog.SafedogAllRiskSync;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.collections4.CollectionUtils;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Configuration;
import org.springframework.scheduling.annotation.Async;
import org.springframework.scheduling.annotation.EnableScheduling;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Component;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;
import java.util.concurrent.atomic.AtomicBoolean;
import java.util.stream.Collectors;

/**
 * 全量同步机制
 */
@Slf4j
@Component
@Configuration      //1.主要用于标记配置类，兼备Component的效果。
@EnableScheduling   // 2.开启定时任务
public class AllVulnSyncSchedule {
    @Autowired
    CommonMapper commonMapper;

    @Scheduled(cron = "0 0/1 * * * *")
    //@Async("threadPoolTaskExecutor")
    public void scanTask() {
        try {
            List<JSONObject> list = commonMapper.query("select * from tb_vuln_scan_task_sync where del_flag = '0' and scan_status = '0' order by id asc");
            log.info("立即全量同步任务数量:{}", list.size());
            // 判断是否存在数据
            if (CollectionUtils.isEmpty(list)) {
                return;
            }
            Map<String, String> engineMap = DictUtil.getMapValueLabel("vul_data_source");
            if (engineMap == null) {
                log.error("无引擎字典vul_data_source");
                return;
            }
            // 更新中间状态（处理中 ： 3）
            List<String> ids = list.stream().map(param -> param.getString("id")).distinct().collect(Collectors.toList());
            if (CollectionUtils.isNotEmpty(ids)) {
                try {
                    String update = "update tb_vuln_scan_task_sync set scan_status = '3',update_time=now(),scan_end_time=now() where id in (" + String.join(",", ids) + ")";
                    commonMapper.exeSQL(update);
                } catch (Exception e) {
                    // 状态异常直接退出当前任务
                    log.error(e.getMessage(), e);
                    return;
                }
            }

            // 更新中间状态
            for (JSONObject json : list) {
                VulnScanTaskSync task = JSON.parseObject(json.toJSONString(), VulnScanTaskSync.class);
                if (task.getScanStartTime() == null) {
                    task.setScanStartTime(task.getCreateTime());
                }
                String scans = task.getScanEngine();
                if (StringUtils.isBlank(scans)) {
                    log.info("null engine:{}", json.toJSONString());
                    continue;
                }
                AtomicBoolean foeye = new AtomicBoolean(false);
                AtomicBoolean dcc = new AtomicBoolean(false);
                AtomicBoolean safedog = new AtomicBoolean(false);
                AtomicBoolean qingteng = new AtomicBoolean(false);
                List<String> engineDesc = new ArrayList<>();
                for (String engineStr : scans.split(",")) {
                    try {
                        CommonAssemble.engineMap.forEach((k, v) -> {
                            if (v.getEquipmentManufacture().equals(engineStr)) {
                                if (ScannerEnums.D01_SCANNER.getCode().equals(engineStr)) {
                                    foeye.set(true);
                                } else if (ScannerEnums.DCC_SCANNER.getCode().equals(engineStr)) {
                                    dcc.set(true);
                                } else if (ScannerEnums.SAFEDOG_SCANNER.getCode().equals(engineStr)) {
                                    safedog.set(true);
                                } else if (ScannerEnums.QINGTENG_SCANNER.getCode().equals(engineStr)) {
                                    qingteng.set(true);
                                }
                            }
                        });
                    } catch (Exception e) {
                        log.error(e.getMessage(), e);
                    }
                    engineDesc.add(engineMap.get(engineStr));
                }
                if (foeye.get()) {
                    if (SyncSecConfigLoad.isEnable(SyncSecConstants.D01_SYNC_ENABLE)) {
                        log.info("parseTask定时同步All D01/Foeye任务");
                        try {
                            FoeyeAssemble.parseAllTask();
                        } catch (Exception e) {
                            log.error(e.getMessage(), e);
                        }
                        log.info("parseTask定时同步All D01/Foeye任务完成");
                    }
                }
                if (dcc.get()) {
                    if (SyncSecConfigLoad.isEnable(SyncSecConstants.DCC_SYNC_ENABLE)) {
                        log.info("parseTask定时同步All Dcc任务");
                        try {
                            DccAssemble.parseAllTask();
                        } catch (Exception e) {
                            log.error(e.getMessage(), e);
                        }
                        log.info("parseTask定时同步All Dcc任务完成");
                    }
                }
                if (qingteng.get()) {
                    try {
                        log.info("同步 all 青藤弱口令 start");
                        (new QingtengAllWeakPassSync()).sync();
                        log.info("同步 all 青藤弱口令 end");
                    } catch (Exception e) {
                        log.error(e.getMessage(), e);
                    }
                    try {
                        log.info("同步 all 青藤漏洞 start");
                        (new QingtengAllRiskSync()).sync();
                        log.info("同步 all 青藤漏洞 end");
                    } catch (Exception e) {
                        log.error(e.getMessage(), e);
                    }
                }

                if (safedog.get()) {
                    try {
                        log.info("同步 all 安全狗漏洞 start");
                        SafedogAllRiskSync sync = new SafedogAllRiskSync();
                        sync.sync();
                        log.info("同步 all 安全狗漏洞 end");
                    } catch (Exception e) {
                        log.error(e.getMessage(), e);
                    }
                }
                try {
                    //push msg
                    String emails = task.getEmailReceive();
                    if ("0".equals(task.getEmailStatus()) && StringUtils.isNotBlank(emails)) {
                        MailService mailService = GetSpringBean.getBean(MailService.class);
                        log.info("push email@@");
                        String sb = "【扫描任务反馈】全量同步任务已执行完毕，请关注！";
                        String msg = "<p><strong>尊敬的用户：</strong></p><p>您好！</p><p>#USER_NAME#于#DATE_TIME#提交的资产/漏洞全量同步扫描任务已执行完毕，扫描引擎为：#ENGINE_LIST#。请登录平台进行查看。</p><p><br></p><p><span style=\"color: rgb(143, 149, 158);\">----------------------------------------------------------------------------------------</span></p><p><span style=\"color: rgb(143, 149, 158);\"><em>温馨提示：此邮件为系统自动发出，请勿回复。如有问题，请与相关业务人员联系，谢谢。</em></span></p>";
                        MailDTO mailDTO = MailDTO.builder()
                                .to(emails)
                                .text(msg.replace("#USER_NAME#", task.getCreateByLabel()).replace("#DATE_TIME#", DateUtils.getDateTimeString1(task.getScanStartTime())).replace("#ENGINE_LIST#", String.join(",", engineDesc)))
                                .subject(sb)
                                .build();
                        mailService.sendHtmlMail(mailDTO);
                    } else {
                        log.info("不推送邮箱：stauts={},users={}", task.getEmailStatus(), emails);
                    }
                } catch (Exception e) {
                    log.error(e.getMessage(), e);
                }
                try {
                    String wxUsers = task.getVxReceive();
                    if ("0".equals(task.getVxStatus()) && StringUtils.isNotBlank(wxUsers)) {
                        log.info("push wx@@");
                        String msg = task.getCreateByLabel() + "于" + DateUtils.getDateTimeString1(task.getScanStartTime()) + "提交的资产/漏洞全量同步扫描任务已执行完毕，扫描引擎为：" + String.join(",", engineDesc) + "。请登录平台进行查看。";
                        QyweixinSend.batchSend(new LinkedList<>(Arrays.asList(wxUsers.split(","))), msg);
                    } else {
                        log.info("不推送微信：stauts={},users={}", task.getVxStatus(), wxUsers);
                    }
                } catch (Exception e) {
                    log.error(e.getMessage(), e);
                }
                // 更新为执行成功
                try {
                    String update = "update tb_vuln_scan_task_sync set scan_status = '1',update_time=now(),scan_end_time=now() where id = " + task.getId();
                    commonMapper.exeSQL(update);
                } catch (Exception e) {
                    log.error(e.getMessage(), e);
                }
            }
        } catch (Exception e) {
            log.error(e.getMessage(), e);
        }
    }
}
