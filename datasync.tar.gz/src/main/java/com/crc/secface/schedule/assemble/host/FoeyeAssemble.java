package com.crc.secface.schedule.assemble.host;

import com.alibaba.fastjson.JSONArray;
import com.alibaba.fastjson.JSONObject;
import com.baomidou.mybatisplus.core.conditions.query.LambdaQueryWrapper;
import com.crc.common.code.SimpleCodeTool;
import com.crc.common.enums.AssetSourceEnums;
import com.crc.common.enums.ScanStatusEnums;
import com.crc.common.enums.ScanTypeEnums;
import com.crc.common.enums.ScannerEnums;
import com.crc.common.utils.*;
import com.crc.scanner.config.DccConfig;
import com.crc.scanner.tool.D01Utils;
import com.crc.secface.config.GetSpringBean;
import com.crc.secface.domain.*;
import com.crc.secface.domain.vo.JoeyeToken;
import com.crc.secface.mapper.*;
import com.crc.secface.queue.CrcAssetSyncQueue;
import com.crc.secface.schedule.assemble.CommonAssemble;
import com.crc.secface.schedule.assemble.WhiteListQuery;
import com.crc.sync.config.SyncSecConfigLoad;
import com.crc.sync.config.SyncSecConstants;
import com.crc.sync.d01.D01AssetSync;
import com.crc.sync.d01.D01TaskSync;
import com.crc.sync.d01.DccTaskCenter;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;

import java.util.*;

/**
 * Foeye 漏洞协同核心逻辑
 */
@Slf4j
public class FoeyeAssemble {
    /**
     * curl -X POST 'https://[device-ip]/api/v2/get_key' -H 'Content-Type: application/json' \
     * --data-binary '{
     * "user": {
     * "login": "admin",
     * "password": "11111111"
     * }
     * }'
     *
     * @param scannerInfo
     * @return
     */
    public static String getKey(DccConfig scannerInfo) {
        JSONObject json = new JSONObject();
        json.put("user", new JSONObject());
        json.getJSONObject("user").put("login", scannerInfo.getUsername());
        json.getJSONObject("user").put("password", scannerInfo.getPassword());
        String url = scannerInfo.getAddress();
        String fullUrl = url + "/api/v2/get_key";
        String jsonStr = HttpUtils.sendPost(fullUrl, json.toJSONString());
        JSONObject jsonObject = JsonUtils.parse(jsonStr);
        if (jsonObject.containsKey("status_code") && "200".equals(JsonUtils.getStr(jsonObject, "status_code"))) {
            //操作成功
            return JsonUtils.getStr(jsonObject, "key");
        }
        return "";
    }


    public static DccConfig getD01Config(Long engineId) {
        EngineEquipmentManagement engine = CommonAssemble.engineMap.get(engineId);
        DccConfig qtConfig = new DccConfig();
        if (engine == null || engine.getId() == null) {
            return qtConfig;
        }
        try {
            qtConfig.setEngineId(engineId);
            qtConfig.setAddress(engine.getEquipmentAddress().trim());
            qtConfig.setVersion(engine.getEquipmentVersion().trim());
            String PASS = engine.getPassword().trim();
            qtConfig.setPassword(PASS);
            try {
                PASS = SimpleCodeTool.decrypt(PASS);
                qtConfig.setPassword(PASS.trim());
            } catch (Exception e) {
                log.error(e.getMessage(), e);
            }
            qtConfig.setUsername(engine.getLoginUser().trim());
        } catch (Exception e) {
            log.error(e.getMessage(), e);
        }
        return qtConfig;
    }

    /**
     * 下发Dcc核查任务
     */

    public static void addTask() {
        try {
            VulnScanTaskRecordMapper taskRecordMapper = GetSpringBean.getBean(VulnScanTaskRecordMapper.class);
            VulnScanTaskRecordLogMapper taskRecordLogMapper = GetSpringBean.getBean(VulnScanTaskRecordLogMapper.class);
            List<VulnScanTask> list = CommonAssemble.getCheckingScantask(ScannerEnums.D01_SCANNER.getCode(), ScanTypeEnums.HOST_SCAN.getCode(), Arrays.asList(1, 2));
            log.info("DCC待执行待任务数量：" + list.size());
            for (VulnScanTask task : list) {
                try {
                    DccConfig scannerInfo = getD01Config(task.getEngineId());
                    VulnScanTaskRecord record = taskRecordMapper.getLastRecordByTaskId(task.getId());
                    if (record == null) {
                        continue;
                    }
                    LambdaQueryWrapper<VulnScanTaskRecordLog> qlog = new LambdaQueryWrapper<>();
                    qlog.eq(VulnScanTaskRecordLog::getRecordId, record.getId());
                    qlog.eq(VulnScanTaskRecordLog::getTaskId, task.getId());
                    String scanContent = task.getScanContentX(",");
                    if (taskRecordLogMapper.selectCount(qlog) > 0) {
                        log.info("{}{},已在执行中", task.getTaskName(), scanContent);
                        continue;
                    }
                    VulnScanTaskRecordLog recordLog = new VulnScanTaskRecordLog();
                    recordLog.setIp(scanContent);
                    recordLog.setTaskId(record.getTaskId());
                    recordLog.setTaskName(task.getTaskName());
                    recordLog.setRecordId(record.getId());
                    recordLog.setEngineId(task.getEngineId());
                    recordLog.setCreateTime(new Date());
                    recordLog.setType(ScannerEnums.D01_SCANNER.getCode());
                    //任务状态(0 未开始 1 执行中 2 执行完成 3 执行失败)
                    recordLog.setScanStatus(0);

                    String ret = "";
                    if (StringUtils.isNotBlank(scannerInfo.getVersion()) && scannerInfo.getVersion().contains("V3")) {
                        ret = D01TaskSync.startScanTaskV3(scannerInfo, recordLog);
                    } else {
                        ret = D01TaskSync.startScanTask(scannerInfo, recordLog);
                    }
                    String taskMsg = "执行成功";

                    if (DccTaskCenter.PASS.equals(ret)) {
                        recordLog.setScanStatus(1);
                        recordLog.setResult(taskMsg);
                        record.setScanStatus(1);
                        taskRecordLogMapper.insert(recordLog);
                    } else {
                        recordLog.setScanStatus(3);
                        record.setScanStatus(3);
                        taskMsg = "执行失败";
                        recordLog.setResult(taskMsg);
                        taskRecordLogMapper.insert(recordLog);

                        CommonAssemble.startFail(recordLog, taskMsg);
                    }
                    log.info(String.format("task_id=%s,返回=%s,%s", recordLog.getTaskId(), ret, taskMsg));
                    record.setScanResult(taskMsg);
                    taskRecordMapper.updateVulnScanTaskRecord(record);
                    // }
                } catch (Exception e) {
                    log.error(e.getMessage(), e);
                }
            }
        } catch (Exception e) {
            log.error(e.getMessage(), e);
        }
    }

    public static void getTask() {
        try {
            CommonAssemble.engineMap.forEach((k, v) -> {
                if (ScannerEnums.D01_SCANNER.getCode().equals(v.getEquipmentManufacture())) {
                    getTask(getD01Config(k));
                }
            });
        } catch (Exception e) {
            log.error(e.getMessage(), e);
        }
    }

    private static void getTask(DccConfig d01Config) {
        VulnScanTaskRecordLogMapper taskRecordLogMapper = GetSpringBean.getBean(VulnScanTaskRecordLogMapper.class);
        VulnScanTaskRecordMapper taskRecordMapper = GetSpringBean.getBean(VulnScanTaskRecordMapper.class);
        VulnScanTaskMapper scanTaskMapper = GetSpringBean.getBean(VulnScanTaskMapper.class);
        try {
            VulnScanTaskRecordLog q = new VulnScanTaskRecordLog();
            q.setScanStatus(1);//扫描中
            q.setScanType(ScanTypeEnums.HOST_SCAN.getCode());
            q.setEngineName(ScannerEnums.D01_SCANNER.getCode());
            List<VulnScanTaskRecordLog> recordList = taskRecordLogMapper.getAllRecordLogList(q);
            for (VulnScanTaskRecordLog task : recordList) {
                try {
                    // 扫描任务id
                    String type = "tasks/task_info";
                    JoeyeToken token = D01AssetSync.getKey(d01Config);
                    if (token == null) {
                        log.error("获取 token 失败");
                        continue;
                    }
                    String ret = D01AssetSync.getData(d01Config, type, token.getToken(), task.getJobId());
                    JSONObject dataJson = JsonUtils.parse(ret);
                    JSONObject retJson = null;
                    if (dataJson.containsKey("task")) {
                        retJson = dataJson.getJSONObject("task");
                    }
                    /*
                     * {
                     * "code":"1",
                     * "msg":"成功",
                     * "data":{
                     * "machineTotal":2,
                     * "machineCompletions":1,
                     * "status":1
                     */

                    if (retJson != null) {
                        if (retJson.containsKey("state")) {
                            //任务状态 0: 等待, 1: 扫描中, 2: 暂停, 3: 完成, 4: 禁扫时间自动暂停
                            int istatus = JsonUtils.getInt(retJson, "state");
                            String progress = JsonUtils.getStr(retJson, "progress").replace("%", "");
                            boolean stop = false;
                            if (istatus == 0 || istatus == 1) {
                                //进行中
                            } else if (istatus == 3) {
                                progress = "100";
                            } else {
                                stop = true;
                            }

                            task.setProgress(DataUtils.toInt(progress));
                            int status = 1;
                            if (task.getProgress() == 100) {
                                status = 2;
                            }

                            //任务类型 1: 资产扫描, 2: 漏洞扫描, 3: 资产及漏洞扫描.
                            int scanType = JsonUtils.getInt(retJson, "task_type");
                            if (stop) {
                                log.error("任务异常停止:" + task.getTaskName() + " -> " + " 进度：" + progress + ",status=" + istatus);
                                status = 2;
                            } else {
                                log.info("读取任务:" + task.getTaskName() + " -> " + " 进度：" + progress + ",status=" + istatus);
                            }
                            task.setScanStatus(status);
                            taskRecordLogMapper.updateById(task);
                            if (task.getProgress() == 100 && !stop && scanType > 1) {

                                JSONArray retArr = D01Utils.getTask(d01Config, task.getTaskName(), task.getJobId());
                                if (retArr != null && retArr.size() > 0) {
                                    HashMap<String, List<VulnProcessForm>> dataMap = new HashMap<>();
                                    for (int i = 0; i < retArr.size(); i++) {
                                        try {
                                            JSONObject vulJson = retArr.getJSONObject(i);
                                            String ip = JsonUtils.getStr(vulJson, "ip");
                                            try {
                                                VulnProcessForm curVul = getVul(d01Config.getEngineId(), vulJson, ip, ScanTypeEnums.HOST_SCAN.getCode());
                                                if (curVul == null) {
                                                    log.info("{} -- 非法漏洞数据：{}", type, vulJson.toJSONString());
                                                    continue;
                                                }
                                                if (dataMap.containsKey(ip)) {
                                                    dataMap.get(ip).add(curVul);
                                                } else {
                                                    dataMap.put(ip, new ArrayList<>());
                                                    dataMap.get(ip).add(curVul);
                                                }
                                            } catch (Exception e) {
                                                log.error(e.getMessage(), e);
                                            }
                                        } catch (Exception e) {
                                            log.error(e.getMessage(), e);
                                        }

                                    }

                                    for (String ip : dataMap.keySet()) {
                                        List<VulnProcessForm> curList = dataMap.get(ip);
                                        if (curList.size() > 0) {
                                            log.info("解析任务:" + task.getTaskName() + " " + ip + " -> " + " 发现漏洞：" + curList.size());
                                            handle(curList, ip);
                                        } else {
                                            log.info("解析任务:" + task.getTaskName() + " " + ip + " -> " + " 未发现漏洞");
                                            repairAllByIp(ip);
                                        }
                                    }
                                } else {
                                    log.error("{}-获取漏洞数据失败", task.getTaskName());
                                }
                            }

                            /*
                             * 更新业务段任务进度
                             */
                            try {
                                VulnScanTaskRecord taskRecord = taskRecordMapper.selectById(task.getRecordId());
                                taskRecord.setScanProgress(task.getProgress());
                                if (status == 2) {
                                    taskRecord.setScanEndTime(new Date());
                                    taskRecord.setDuration(DateUtils.getDiffSec(taskRecord.getScanStartTime(), taskRecord.getScanEndTime()));
                                    taskRecord.setScanStatus(2);
                                    taskRecord.setScanResult("扫描完成");
                                }
                                taskRecordMapper.updateVulnScanTaskRecord(taskRecord);

                                VulnScanTask scanTask = new VulnScanTask();
                                scanTask.setId(taskRecord.getTaskId());
                                scanTask.setUpdateTime(new Date());
                                scanTask.setScanProgress(taskRecord.getScanProgress());

                                if (taskRecord.getScanStatus() != null && taskRecord.getScanStatus() > 1) {
                                    scanTask.setScanStatus(ScanStatusEnums.SCAN_FINISH.getCode());
                                }
                                scanTaskMapper.updateVulnScanTask(scanTask);
                            } catch (Exception e) {
                                log.error(e.getMessage(), e);
                            }
                        }
                    }
                } catch (Exception e) {
                    log.error(e.getMessage(), e);
                }
            }
        } catch (Exception e) {
            log.error(e.getMessage(), e);
        }
    }


    private static void handle(List<VulnProcessForm> culList, String ip) {
        //原有漏洞查询
        VulnProcessFormMapper vulnProcessFormMapper = GetSpringBean.getBean(VulnProcessFormMapper.class);
        AssetMapper assetMapper = GetSpringBean.getBean(AssetMapper.class);
        //原有漏洞查询
        LambdaQueryWrapper<VulnProcessForm> vq = new LambdaQueryWrapper<>();
        vq.eq(VulnProcessForm::getIp, ip);
        vq.eq(VulnProcessForm::getSource, ScannerEnums.D01_SCANNER.getCode());
        vq.eq(VulnProcessForm::getCategory, ScanTypeEnums.HOST_SCAN.getCode());
        List<VulnProcessForm> vulList = vulnProcessFormMapper.selectList(vq);
        List<VulnProcessForm> repairedList = new LinkedList<>();
        List<VulnProcessForm> unrepairedList = new LinkedList<>();
        List<VulnProcessForm> newVulList = new LinkedList<>();
        log.info(ip + " 库存漏洞：" + vulList.size() + " 当前有漏洞：" + culList.size());
        int newTotal = 0;
        int dropTotal = 0;
        //扫描到漏洞
        for (VulnProcessForm curVul : culList) {
            Asset asset = assetMapper.selectAssetByInnerIp(ip);
            if (asset == null) {
                asset = new Asset();
                asset.setSource(AssetSourceEnums.D01_CMDB.getCode());
                asset.setInternalIp(ip);
                CrcAssetSyncQueue.getInstance().saveAsset(asset);
            }
            //白名单
            if (WhiteListQuery.isWhiteList(curVul)) {
                dropTotal++;
                continue;
            }
            newVulList.add(curVul);
            //是否新漏洞
            boolean isnew = true;
            VulnProcessForm tmp = vulnProcessFormMapper.selectById(curVul.getId());
            if (tmp != null) {
                vulnProcessFormMapper.stillExist(curVul.getId());
                isnew = false;
            }

            if (isnew) {
                //新漏洞
                if (CommonAssemble.saveVul(curVul)) {
                    newTotal++;
                } else {
                    dropTotal++;
                }
            }
        }
        //已修复的漏洞判断
        for (VulnProcessForm oldVul : vulList) {
            boolean isRepair = true;
            for (VulnProcessForm newVul : newVulList) {
                //漏洞名称 节点IP是否相同
                if (newVul.getId().equalsIgnoreCase(oldVul.getId())) {
                    isRepair = false;
                    break;
                }
            }
            //漏洞已修复
            if (isRepair) {
                repairedList.add(oldVul);
            } else {
                //未修复
                unrepairedList.add(oldVul);
            }
        }
        log.info(ip + " @@@@@@@@@@@@库存漏洞：" + vulList.size() + " 丢弃漏洞：" + dropTotal + " 新增漏洞：" + newTotal + " 未修复漏洞：" + unrepairedList.size() + " 修复漏洞：" + repairedList.size());
        if (!repairedList.isEmpty()) {
            repairedList.forEach((CommonAssemble::repairedVul));
        }
        if (!unrepairedList.isEmpty()) {
            unrepairedList.forEach((CommonAssemble::unRepairedVul));
        }
        CommonAssemble.sendMsg(vulList, ScannerEnums.D01_SCANNER.getName(), ScanTypeEnums.HOST_SCAN.getCode(), ip, newTotal, unrepairedList.size(), repairedList.size());
    }

    /**
     * IP全部修复
     *
     * @param ip IP
     */
    public static void repairAllByIp(String ip) {
        try {
            CommonAssemble.repairAll(ip, ScannerEnums.D01_SCANNER.getCode(), ScanTypeEnums.HOST_SCAN.getCode());
        } catch (Exception e) {
            log.error(e.getMessage(), e);
        }
    }

    private static VulnProcessForm getVul(Long engineId, JSONObject jsonData, String ip, int code) {
        try {
            if (!IpUtils.isIp(ip)) {
                log.error("##漏洞 IP 为非法IP" + ip);
                return null;
            }
            String common_title = JsonUtils.getStr(jsonData, "common_title");//漏洞名称
            String createtime = JsonUtils.getStr(jsonData, "createtime");
            String lastupdatetime = JsonUtils.getStr(jsonData, "lastupdatetime");//是否代理理 0没有代理理 1有代理理
            String level = JsonUtils.getStr(jsonData, "level");//0:低危, 1:中危, 2:⾼危, 3:严重int
            String vulType = JsonUtils.getStr(jsonData, "vulType");//漏洞类型
            String cveId = JsonUtils.getStr(jsonData, "cveId");//cveId
            String common_impact = JsonUtils.getStr(jsonData, "common_impact");//漏洞危害
            String url = JsonUtils.getStr(jsonData, "url");//漏洞地址
            String filter = SyncSecConfigLoad.getRemarkValue(SyncSecConstants.D01_SYNC_ENABLE);
            try {
                boolean flag = false;
                if (filter != null && filter.contains("=") && filter.contains("level")) {
                    String filterLevel = filter.split("=")[1];
                    for (String fl : filterLevel.split(",")) {
                        if (StringUtils.isNotBlank(level) && level.equalsIgnoreCase(fl)) {
                            flag = true;
                            break;
                        }
                    }
                } else {
                    flag = true;
                }
                if (!flag) {
                    return null;
                }
            } catch (Exception e) {
                log.error(e.getMessage(), e);
            }

            String vulId = JsonUtils.getStr(jsonData, "id");//解决方案
            String recommandation = JsonUtils.getStr(jsonData, "recommandation");//解决方案
            String common_description = JsonUtils.getStr(jsonData, "common_description");//漏洞描述
            String mid = JsonUtils.getStr(jsonData, "mid");//漏洞描述
            VulnProcessForm vul = new VulnProcessForm();
            vul.setIp(ip);
            vul.setVulnName(common_title);
            vul.setLevel(level);
            vul.setSource(ScannerEnums.D01_SCANNER.getCode());
            String id = Md5Utils.hash(ip + "#" + common_title + "#" + cveId + "#" + vul.getSource());
            vul.setId(id);
            vul.setVulnType(vulType);
            vul.setDescription(common_description);
            vul.setSolution(recommandation);
            vul.setEngineId(String.valueOf(engineId));
            vul.setCategory(code);
            vul.setCveCode(cveId);
            vul.setRefLink(url);
            vul.setCode(String.format("VUL_%s", IdGen.uuid8()));
            vul.setCreateTime(DateUtils.parseDate(createtime, DateUtils.DATE_FORMAT_STRING1));
            vul.setUpdateTime(DateUtils.parseDate1(lastupdatetime, DateUtils.DATE_FORMAT_STRING1));
            vul.setFirstTime(vul.getCreateTime());
            if (vul.getUpdateTime() != null) {
                vul.setRecentlyTime(vul.getUpdateTime());
            }

            String status = JsonUtils.getStr(jsonData, "status");//1:在线, 0:离线
            String name = JsonUtils.getStr(jsonData, "name");//内核版本
            String mac = JsonUtils.getStr(jsonData, "mac");//mac地址
            String username = JsonUtils.getStr(jsonData, "username");//mac地址
            String managerMobile = JsonUtils.getStr(jsonData, "manager_mobile");//mac地址
            String managerEmail = JsonUtils.getStr(jsonData, "manager_email");//mac地址
            Asset asset = new Asset();
            asset.setInternalIp(ip);
            asset.setMacAddress(mac);
            asset.setInstance(JsonUtils.getStr(jsonData, "business_app"));
            //资产状态，可选项：1在用、2停用、3下架、4库存备用、5故障设备、6已临时关停、7待修、8在修、9闲置、10待报废、11报废、12转交
            asset.setOperatingStatus(1);
            if (StringUtils.isBlank(name)) {
                asset.setInstance(name);
            }
            if (StringUtils.isBlank(asset.getInstance())) {
                asset.setInstance(ip);
            }
            //数据来源，仅详情展示；1传统资源池CMDB、2华润云CMDB、3青藤、4D01、5 人工  6 GOBY 7 长亭 8 安恒"
            asset.setSource(AssetSourceEnums.D01_CMDB.getCode());
            CrcAssetSyncQueue.getInstance().saveAsset(asset);
            CrcAssetSyncQueue.getInstance().saveAssetPerson(asset.getInternalIp(), username, "1");
            CommonAssemble.saveVulAssetInfo(vul, asset);
            return vul;

        } catch (Exception e) {
            log.error(e.getMessage(), e);
        }
        return null;
    }

    public static void parseAllTask() {
        try {
            log.info("CommonAssemble.engineMap:{}", CommonAssemble.engineMap.size());
            CommonAssemble.engineMap.forEach((k, v) -> {
                if (ScannerEnums.D01_SCANNER.getCode().equals(v.getEquipmentManufacture())) {
                    String type = "threats";
                    ///api/v2/threats
                    parseAllTask(getD01Config(k), type);
                    ///api/v2/threats/repaireds
                    type = "threats/repaireds";
                    parseAllTask(getD01Config(k), type);
                }
            });
        } catch (Exception e) {
            log.error(e.getMessage(), e);
        }
    }

    public static void parseAllTask(DccConfig d01Config, String type) {
        try {
            JoeyeToken joeyeToken = D01AssetSync.getKey(d01Config);
            if (joeyeToken == null) {
                log.error("获取 token 失败");
                return;
            }
            VulnProcessFormMapper vulnProcessFormMapper = GetSpringBean.getBean(VulnProcessFormMapper.class);
            int total = D01AssetSync.getTotal(d01Config, type, joeyeToken.getToken());
            log.info("{} -- 漏洞数据：{}", type, total);
            if (total > 0) {
                //curl -X GET 'https://[foeye-ip]/api/v2/threats?email=[emails]&key=[key]&page=1&per_page=15'
                int pageSize = 500;
                for (int x = 1; x < (Math.ceil(total / pageSize) + 2); x++) {
                    String url = d01Config.getAddress();
                    String email = d01Config.getUsername();
                    String fullUrl = url + "/api/v2/" + type + String.format("?email=%s&key=%s&page=%d&per_page=%d", email, joeyeToken.getToken(), x, pageSize);
                    String jsonStr = HttpUtils.sendGet(fullUrl, null);
                    JSONObject jsonObject = JsonUtils.parse(jsonStr);
                    if (jsonObject.containsKey("status_code") && "200".equals(JsonUtils.getStr(jsonObject, "status_code"))) {
                        //操作成功
                        if (jsonObject.containsKey("list")) {
                            JSONArray retArr = jsonObject.getJSONArray("list");
                            if (retArr == null) {
                                continue;
                            }
                            log.info("{} -- 漏洞数据##：{}", type, retArr.size());
                            for (int i = 0; i < retArr.size(); i++) {
                                try {
                                    JSONObject vulJson = retArr.getJSONObject(i);
                                    String ip = JsonUtils.getStr(vulJson, "ip");
                                    VulnProcessForm curVul = getVul(d01Config.getEngineId(), vulJson, ip, ScanTypeEnums.HOST_SCAN.getCode());
                                    if (curVul == null) {
                                        log.info("{} -- 非法漏洞数据：{}", type, vulJson.toJSONString());
                                        continue;
                                    }
                                    if (type.contains("repaireds")) {//修复
                                        log.info("修复漏洞ip={},name={}", curVul.getIp(), curVul.getVulnName());
                                        CommonAssemble.repairedVul(curVul);
                                        continue;
                                    }
                                    curVul.setStatus("0");
                                    Asset asset = CrcAssetSyncQueue.getInstance().getByIp(ip);
                                    if (asset == null) {
                                        asset = new Asset();
                                        asset.setSource(AssetSourceEnums.D01_CMDB.getCode());
                                        asset.setInternalIp(ip);
                                        CrcAssetSyncQueue.getInstance().saveAsset(asset);
                                    }
                                    //白名单
                                    if (WhiteListQuery.isWhiteList(curVul)) {
                                        continue;
                                    }
                                    boolean isnew = true;
                                    VulnProcessForm tmp = vulnProcessFormMapper.selectById(curVul.getId());
                                    if (tmp != null) {
                                        vulnProcessFormMapper.stillExist(curVul.getId());
                                        isnew = false;
                                    }

                                    if (isnew) {
                                        CommonAssemble.saveVul(curVul);
                                    } else {
                                        CommonAssemble.unRepairedVul(curVul);
                                    }
                                } catch (Exception e) {
                                    log.error(e.getMessage(), e);
                                }
                            }
                        } else {
                            log.error("获取数据错误非200OK：" + jsonStr);
                        }
                    }
                }
            }
        } catch (Exception e) {
            log.error(e.getMessage(), e);
        }
    }
}
