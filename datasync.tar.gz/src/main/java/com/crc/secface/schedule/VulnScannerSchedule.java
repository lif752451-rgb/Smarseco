package com.crc.secface.schedule;

import com.alibaba.fastjson.JSONObject;
import com.baomidou.mybatisplus.core.conditions.query.LambdaQueryWrapper;
import com.baomidou.mybatisplus.core.conditions.update.LambdaUpdateWrapper;
import com.baomidou.mybatisplus.core.toolkit.Wrappers;
import com.crc.common.enums.DatabaseEnums;
import com.crc.common.enums.ScanStatusEnums;
import com.crc.common.enums.ScannerEnums;
import com.crc.common.utils.DateUtils;
import com.crc.common.utils.JsonUtils;
import com.crc.common.utils.MyTheadUtils;
import com.crc.common.utils.VersionUtils;
import com.crc.secface.config.GetSpringBean;
import com.crc.secface.domain.VulnScanTask;
import com.crc.secface.domain.VulnScanTaskRecord;
import com.crc.secface.domain.VulnScanTaskRecordLog;
import com.crc.secface.domain.vo.AllRiskVo;
import com.crc.secface.domain.vo.RiskVo;
import com.crc.secface.mapper.CommonMapper;
import com.crc.secface.mapper.VulnScanTaskMapper;
import com.crc.secface.mapper.VulnScanTaskOplogMapper;
import com.crc.secface.mapper.VulnScanTaskRecordLogMapper;
import com.crc.secface.mapper.VulnScanTaskRecordMapper;
import com.crc.secface.queue.QtAllRiskAutoFlowSyncQueue;
import com.crc.secface.queue.RiskAutoFlowSyncQueue;
import com.crc.secface.schedule.assemble.CommonAssemble;
import com.crc.secface.schedule.assemble.host.AnhengAssemble;
import com.crc.secface.schedule.assemble.host.AutoAnalyAsssemble;
import com.crc.secface.schedule.assemble.host.ChangtingAssemble;
import com.crc.secface.schedule.assemble.host.DccAssemble;
import com.crc.secface.schedule.assemble.host.FoeyeAssemble;
import com.crc.secface.schedule.assemble.host.GobyAssemble;
import com.crc.secface.schedule.assemble.host.HuaweiAssemble;
import com.crc.secface.schedule.assemble.host.HuaweiCrackAssemble;
import com.crc.secface.schedule.assemble.host.JiaotuAssemble;
import com.crc.secface.schedule.assemble.host.JiaotuCrackAssemble;
import com.crc.secface.schedule.assemble.host.LvmengAssemble;
import com.crc.secface.schedule.assemble.host.LvmengCrackAssemble;
import com.crc.secface.schedule.assemble.host.QingtengAssemble;
import com.crc.secface.schedule.assemble.host.SafedogAssemble;
import com.crc.secface.schedule.assemble.host.TdhxAssemble;
import com.crc.secface.schedule.assemble.host.TdhxCrackAssemble;
import com.crc.secface.schedule.assemble.host.TianRongXinAssemble;
import com.crc.secface.schedule.assemble.host.TianRongXinCrackAssemble;
import com.crc.secface.schedule.assemble.web.AnhengWebAssemble;
import com.crc.secface.schedule.assemble.web.ChangtingWebAssemble;
import com.crc.secface.schedule.assemble.web.HuaweiWebAssemble;
import com.crc.secface.schedule.assemble.web.LvmengWebAssemble;
import com.crc.secface.schedule.assemble.web.TdhxWebAssemble;
import com.crc.secface.schedule.assemble.web.TianRongXinWebAssemble;
import com.crc.sync.config.SyncSecConfigLoad;
import com.crc.sync.config.SyncSecConstants;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Configuration;
import org.springframework.scheduling.annotation.EnableScheduling;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Component;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Comparator;
import java.util.Date;
import java.util.List;
import java.util.Objects;
import java.util.TreeSet;
import java.util.stream.Collectors;

/**
 * 主机/web漏洞扫描器总线类
 */
@Slf4j
@Component
@Configuration      //1.主要用于标记配置类，兼备Component的效果。
@EnableScheduling   // 2.开启定时任务
public class VulnScannerSchedule {
    @Autowired
    VulnScanTaskMapper vulTaskMapper;

    @Autowired
    VulnScanTaskRecordMapper taskRecordMapper;

    @Autowired
    VulnScanTaskRecordLogMapper taskRecordLogMapper;

    @Autowired
    VulnScanTaskOplogMapper taskOplogMapper;

    @Scheduled(cron = "0 0/1 * * * *")
    public void scanTask() {
        MyTheadUtils.sleepBySec(1);
        /*
         * 主机/web漏洞复查任务同步
         */
        try {
            CommonAssemble.syncReview();
        } catch (Exception e) {
            log.error(e.getMessage(), e);
        }

        /*
         * 主机/web漏洞状态统计
         */
        try {
            CommonAssemble.syncStatus();
        } catch (Exception e) {
            log.error(e.getMessage(), e);
        }

        /*
         * 关闭超时 record
         */
        try {
            CommonAssemble.closeRecord();
        } catch (Exception e) {
            log.error(e.getMessage(), e);
        }
        try {
            LambdaQueryWrapper<VulnScanTask> queryWrapper = new LambdaQueryWrapper<>();
            queryWrapper.and(qw -> qw.in(VulnScanTask::getScanStatus, ScanStatusEnums.SCAN_QUEUE.getCode(), ScanStatusEnums.SCAN_WAIT.getCode(), ScanStatusEnums.SCAN_ING.getCode()));
            queryWrapper.orderByDesc(VulnScanTask::getCreateTime);
            queryWrapper.eq(VulnScanTask::getDelFlag, 0);
            List<VulnScanTask> taskList1 = vulTaskMapper.selectList(queryWrapper);

            LambdaQueryWrapper<VulnScanTask> queryWrapper2 = new LambdaQueryWrapper<>();
            queryWrapper2.eq(VulnScanTask::getDelFlag, 0);
            queryWrapper2.notIn(VulnScanTask::getScanStatus, Arrays.asList(3, 4));
            queryWrapper2.and(qw -> qw.gt(VulnScanTask::getScanPeriod, 2));//定时任务
            List<VulnScanTask> taskList2 = vulTaskMapper.selectList(queryWrapper2);
            taskList1.addAll(taskList2);

            List<VulnScanTask> taskList = taskList1.stream()
                    .collect(Collectors.collectingAndThen(Collectors.toCollection(
                            () -> new TreeSet<>(Comparator.comparing(VulnScanTask::getId))), ArrayList::new));

            log.info("待执行的任务数量：" + taskList.size());
            for (VulnScanTask task : taskList) {
            /*
            立即执行 1
            定时执行一次 2
            每天执行一次 3
            每周执行一次 4
            每月执行一次 5
             */
                if (task.getScanPeriod() == null || !task.isGoodData()) {
                    log.error("{}执行周期配置为有误！", task.getId());
                    task.setScanStatus(ScanStatusEnums.SCAN_STOP.getCode());
                    task.setUpdateTime(new Date());
                    vulTaskMapper.updateVulnScanTask(task);
                    continue;
                }
                boolean startNow = CommonAssemble.isStartNow(task);
                if (startNow) {
                    LambdaQueryWrapper<VulnScanTaskRecord> q = new LambdaQueryWrapper<>();
                    q.eq(VulnScanTaskRecord::getTaskId, task.getId());
                    q.lt(VulnScanTaskRecord::getScanStatus, 2);
                    long count = taskRecordMapper.selectCount(q);
                    if (count > 0) {
                        log.info("{} --> {},存在执行中的任务", task.getTaskName(), task.getId());
                        continue;
                    }
                    //定时任务一天最多执行一次
                    if (task.getScanPeriod() != null && task.getScanPeriod() > 2) {
                        VulnScanTaskRecord lastRecord = taskRecordMapper.getLastRecordByTaskId(task.getId());
                        if (lastRecord != null) {
                            if (Objects.equals(lastRecord.getScanStatus(), 2) || Objects.equals(lastRecord.getScanStatus(), 3)) {
                                Date date = lastRecord.getScanEndTime();
                                if (date == null) {
                                    date = lastRecord.getCreateTime();
                                }
                                if (DateUtils.formatDateTime(new Date(), DateUtils.DATE_FORMAT).equals(DateUtils.formatDateTime(date, DateUtils.DATE_FORMAT))) {
                                    log.info("{} --> {},定时任务今天已完成", task.getTaskName(), task.getId());
                                    continue;
                                }
                            }
                        }

                    }

                    VulnScanTaskRecord record = new VulnScanTaskRecord();
                    record.setTaskId(task.getId());
                    record.setCreateTime(new Date());
                    record.setScanStatus(0);
                    record.setScanStartTime(new Date());
                    record.setScanResult("队列中");
                    record.setReviews(task.getReviews());
                    taskRecordMapper.insert(record);

                    // 开始执行  等待 转  队列 (5 代表定时任务)
                    LambdaUpdateWrapper<VulnScanTask> uw = Wrappers.lambdaUpdate();
                    uw.eq(VulnScanTask::getId, task.getId());
                    uw.in(VulnScanTask::getScanStatus, Arrays.asList(5, 6, 7));
                    uw.set(VulnScanTask::getScanStatus, 1);
                    vulTaskMapper.update(null, uw);
                    log.info("{}开始执行{}", task.getTaskName(), task.getId());
                } else {
                    task.setScanStatus(ScanStatusEnums.SCAN_WAIT.getCode());
                    task.setUpdateTime(new Date());
                    vulTaskMapper.updateVulnScanTask(task);
                    log.info("{}等待执行{}", task.getTaskName(), task.getId());
                }
            }
        } catch (Exception e) {
            log.error(e.getMessage(), e);
        }

        /*
         *主机/web漏洞 更新已被删除的任务
         */
        try {
            LambdaQueryWrapper<VulnScanTask> queryWrapper = new LambdaQueryWrapper<>();
            queryWrapper.eq(VulnScanTask::getDelFlag, 1);
            List<VulnScanTask> taskList = vulTaskMapper.selectList(queryWrapper);
            for (VulnScanTask task : taskList) {
                LambdaQueryWrapper<VulnScanTaskRecord> rq = new LambdaQueryWrapper<>();
                rq.eq(VulnScanTaskRecord::getTaskId, task.getId());
                List<VulnScanTaskRecord> recordList = taskRecordMapper.selectList(rq);
                for (VulnScanTaskRecord record : recordList) {
                    LambdaQueryWrapper<VulnScanTaskRecordLog> qlog = new LambdaQueryWrapper<>();
                    qlog.eq(VulnScanTaskRecordLog::getRecordId, record.getId());
                    List<VulnScanTaskRecordLog> list = taskRecordLogMapper.selectList(qlog);
                    for (VulnScanTaskRecordLog recordLog : list) {
                        try {//删除已经停止的goby任务
                            CommonAssemble.engineMap.forEach((k, v) -> {
                                if (ScannerEnums.GOBY_SCANNER.getCode().equals(v.getEquipmentManufacture()) && Objects.equals(recordLog.getEngineId(), k)) {
                                    GobyAssemble.delTask(GobyAssemble.getGobyConfig(k), recordLog);
                                }
                            });
                        } catch (Exception e) {
                            log.error(e.getMessage(), e);
                        }
                    }
                    taskRecordLogMapper.deleteByRecordId(record.getId());
                }
                taskRecordMapper.deleteByTaskId(task.getId());
            }
        } catch (Exception e) {
            log.error(e.getMessage(), e);
        }
    }

    /**
     * 添加资产清点任务
     */
    @Scheduled(cron = "10 */1 * * * ?")
    public void startTaskScan() {
        MyTheadUtils.sleepBySec(3);
        if (SyncSecConfigLoad.isEnable(SyncSecConstants.QT_STANDARD_SYNC_ENABLE)) {
            log.info("添加青藤资产清点任务");
            try {
                QingtengAssemble.addAssetCheck();
                QingtengAssemble.syncAssetCheck();
            } catch (Exception e) {
                log.error(e.getMessage(), e);
            }
            log.info("添加青藤资产清点任务完成");
        }

        if (SyncSecConfigLoad.isEnable(SyncSecConstants.QT_STANDARD_SYNC_ENABLE)) {
            log.info("添加青藤资产弱口令任务");
            try {
                QingtengAssemble.addWeakCheck();
            } catch (Exception e) {
                log.error(e.getMessage(), e);
            }
            log.info("添加青藤资产弱口令任务完成");
        }

        AddTask();

        getTask();
    }

    /**
     * 定时同步下发扫描任务
     */
    public void AddTask() {
        if (SyncSecConfigLoad.isEnable(SyncSecConstants.AA_SYNC_ENABLE)) {
            log.info("AddTask定时同步自动化扫描任务");
            try {
                AutoAnalyAsssemble.addTask();
            } catch (Exception e) {
                log.error(e.getMessage(), e);
            }
            log.info("AddTask定时同步自动化扫描任务结束");
        }

        if (SyncSecConfigLoad.isEnable(SyncSecConstants.QT_STANDARD_SYNC_ENABLE)) {
            log.info("AddTask定时同步青藤扫描任务");
            try {
                QingtengAssemble.addTask();
            } catch (Exception e) {
                log.error(e.getMessage(), e);
            }
            log.info("AddTask定时同步青藤扫描任务结束");
        }

        if (SyncSecConfigLoad.isEnable(SyncSecConstants.QT_STANDARD_SYNC_ENABLE)) {
            log.info("AddTask定时同步青藤弱口令任务");
            try {
                QingtengAssemble.addWeakPwdTask();
            } catch (Exception e) {
                log.error(e.getMessage(), e);
            }
            log.info("AddTask定时同步青藤弱口令任务结束");
        }

        if (SyncSecConfigLoad.isEnable(SyncSecConstants.TIANRONGXIN_SYNC_ENABLE)) {
            log.info("addTask天融信扫描任务");
            try {
                TianRongXinAssemble.addTask();
            } catch (Exception e) {
                log.error(e.getMessage(), e);
            }
            log.info("addTask天融信扫描任务完成");
        }

        if (SyncSecConfigLoad.isEnable(SyncSecConstants.TIANRONGXIN_SYNC_ENABLE)) {
            log.info("addTask天融信扫WEB描任务");
            try {
                TianRongXinWebAssemble.addTask();
            } catch (Exception e) {
                log.error(e.getMessage(), e);
            }
            log.info("addTask天融信扫描WEB任务完成");
        }

        if (SyncSecConfigLoad.isEnable(SyncSecConstants.TIANRONGXIN_SYNC_ENABLE)) {
            log.info("addTask天融信弱口令扫描任务");
            try {
                TianRongXinCrackAssemble.addTask();
            } catch (Exception e) {
                log.error(e.getMessage(), e);
            }
            log.info("addTask天融信弱口令扫描任务完成");
        }


        if (SyncSecConfigLoad.isEnable(SyncSecConstants.HUAWEI_SYNC_ENABLE)) {
            log.info("addTask华为扫描任务");
            try {
                HuaweiAssemble.addTask();
            } catch (Exception e) {
                log.error(e.getMessage(), e);
            }
            log.info("addTask华为任务完成");
        }

        if (SyncSecConfigLoad.isEnable(SyncSecConstants.HUAWEI_SYNC_ENABLE)) {
            log.info("addTask华为WEB描任务");
            try {
                HuaweiWebAssemble.addTask();
            } catch (Exception e) {
                log.error(e.getMessage(), e);
            }
            log.info("addTask华为WEB任务完成");
        }

        if (SyncSecConfigLoad.isEnable(SyncSecConstants.ANHENG_SYNC_ENABLE)) {
            log.info("addTask安恒扫描任务");
            try {
                AnhengAssemble.addTask();
            } catch (Exception e) {
                log.error(e.getMessage(), e);
            }
            log.info("addTask安恒任务完成");
        }

        if (SyncSecConfigLoad.isEnable(SyncSecConstants.ANHENG_SYNC_ENABLE)) {
            log.info("addTask安恒WEB描任务");
            try {
                AnhengWebAssemble.addTask();
            } catch (Exception e) {
                log.error(e.getMessage(), e);
            }
            log.info("addTask安恒WEB任务完成");
        }

        if (SyncSecConfigLoad.isEnable(SyncSecConstants.HUAWEI_SYNC_ENABLE)) {
            log.info("addTask华为弱口令扫描任务");
            try {
                HuaweiCrackAssemble.addTask();
            } catch (Exception e) {
                log.error(e.getMessage(), e);
            }
            log.info("addTask华为弱口令扫描任务完成");
        }

        if (SyncSecConfigLoad.isEnable(SyncSecConstants.LVMENG_SYNC_ENABLE)) {
            log.info("addTask定时添加绿盟任务");
            try {
                LvmengAssemble.addTask();
            } catch (Exception e) {
                log.error(e.getMessage(), e);
            }
            log.info("addTask定时添加绿盟任务完成");
        }

        if (SyncSecConfigLoad.isEnable(SyncSecConstants.LVMENG_SYNC_ENABLE)) {
            log.info("addTask定时添加绿盟弱口令任务");
            try {
                LvmengCrackAssemble.addTask();
            } catch (Exception e) {
                log.error(e.getMessage(), e);
            }
            log.info("addTask定时添加绿盟弱口令任务完成");
        }

        if (SyncSecConfigLoad.isEnable(SyncSecConstants.LVMENG_SYNC_ENABLE)) {
            log.info("addTask定时添加绿盟WEB任务");
            try {
                LvmengWebAssemble.addTask();
            } catch (Exception e) {
                log.error(e.getMessage(), e);
            }
            log.info("addTask定时添加绿盟WEB任务完成");
        }
//
        if (SyncSecConfigLoad.isEnable(SyncSecConstants.GOBY_SYNC_ENABLE)) {
            log.info("addTask定时添加Goby任务");
            try {
                GobyAssemble.addTask();
            } catch (Exception e) {
                log.error(e.getMessage(), e);
            }
            log.info("addTask定时添加Goby任务完成");
        }

        if (SyncSecConfigLoad.isEnable(SyncSecConstants.SAFEDOG_SYNC_ENABLE)) {
            log.info("addTask定时添加safedog任务");
            try {
                SafedogAssemble.addTask();
            } catch (Exception e) {
                log.error(e.getMessage(), e);
            }
            log.info("addTask定时添加safedog任务完成");
        }
//
        if (SyncSecConfigLoad.isEnable(SyncSecConstants.DCC_SYNC_ENABLE)) {
            log.info("addTask定时添加Dcc任务");
            try {
                DccAssemble.addTask();
            } catch (Exception e) {
                log.error(e.getMessage(), e);
            }
            log.info("addTask定时添加Dcc任务完成");
        }

        if (SyncSecConfigLoad.isEnable(SyncSecConstants.D01_SYNC_ENABLE)) {
            log.info("addTask定时添加D01/Foeye任务");
            try {
                FoeyeAssemble.addTask();
            } catch (Exception e) {
                log.error(e.getMessage(), e);
            }
            log.info("addTask定时添加D01/Foeye任务完成");
        }

        if (SyncSecConfigLoad.isEnable(SyncSecConstants.JIAOTU_SYNC_ENABLE)) {
            log.info("addTask定时添加椒图扫描任务");
            try {
                JiaotuAssemble.addTask();
            } catch (Exception e) {
                log.error(e.getMessage(), e);
            }
            log.info("addTask定时添加椒图任务完成");
        }

        if (SyncSecConfigLoad.isEnable(SyncSecConstants.JIAOTU_SYNC_ENABLE)) {
            log.info("addTask定时添加椒图Crack扫描任务");
            try {
                JiaotuCrackAssemble.addTask();
            } catch (Exception e) {
                log.error(e.getMessage(), e);
            }
            log.info("addTask定时添加椒图Crack任务完成");
        }

        if (SyncSecConfigLoad.isEnable(SyncSecConstants.CHANGTING_SYNC_ENABLE)) {
            log.info("addTask长亭扫描任务");
            try {
                ChangtingAssemble.addTask();
            } catch (Exception e) {
                log.error(e.getMessage(), e);
            }
            log.info("addTask长亭任务完成");
        }

        if (SyncSecConfigLoad.isEnable(SyncSecConstants.CHANGTING_SYNC_ENABLE)) {
            log.info("addTask长亭WEB描任务");
            try {
                ChangtingWebAssemble.addTask();
            } catch (Exception e) {
                log.error(e.getMessage(), e);
            }
            log.info("addTask长亭WEB任务完成");
        }

        if (SyncSecConfigLoad.isEnable(SyncSecConstants.TDHX_SYNC_ENABLE)) {
            log.info("AddTask定时同步天地和兴扫描任务");
            try {
                TdhxAssemble.addTask();
            } catch (Exception e) {
                log.error(e.getMessage(), e);
            }
            log.info("AddTask定时同步天地和兴扫描任务结束");
        }

        if (SyncSecConfigLoad.isEnable(SyncSecConstants.TDHX_SYNC_ENABLE)) {
            log.info("AddTask定时同步天地和兴弱口令任务");
            try {
                TdhxCrackAssemble.addTask();
            } catch (Exception e) {
                log.error(e.getMessage(), e);
            }
            log.info("AddTask定时同步天地和兴弱口令任务结束");
        }

        if (SyncSecConfigLoad.isEnable(SyncSecConstants.TDHX_SYNC_ENABLE)) {
            log.info("AddTask定时同步天地和兴WEB任务");
            try {
                TdhxWebAssemble.addTask();
            } catch (Exception e) {
                log.error(e.getMessage(), e);
            }
            log.info("AddTask定时同步天地和兴WEB任务结束");
        }
    }


    /**
     * 定时获取任务状态及数据
     */
    public void getTask() {
        if (SyncSecConfigLoad.isEnable(SyncSecConstants.AA_SYNC_ENABLE)) {
            log.info("GetTask定时同步自动化扫描任务");
            try {
                AutoAnalyAsssemble.getTask();
            } catch (Exception e) {
                log.error(e.getMessage(), e);
            }
            log.info("GetTask定时同步自动化扫描任务结束");
        }

        if (SyncSecConfigLoad.isEnable(SyncSecConstants.QT_STANDARD_SYNC_ENABLE)) {
            log.info("GetTask定时青藤获取漏洞清单数据");
            try {
                QingtengAssemble.getTask();
            } catch (Exception e) {
                log.error(e.getMessage(), e);
            }
            log.info("GetTask定时青藤获取漏洞清单数据结束");
        }

        if (SyncSecConfigLoad.isEnable(SyncSecConstants.QT_STANDARD_SYNC_ENABLE)) {
            log.info("GetTask定时青藤获取弱口令清单数据");
            try {
                QingtengAssemble.getWeakPwdTask();
            } catch (Exception e) {
                log.error(e.getMessage(), e);
            }
            log.info("GetTask定时青藤获取弱口令清单数据结束");
        }

        if (SyncSecConfigLoad.isEnable(SyncSecConstants.TIANRONGXIN_SYNC_ENABLE)) {
            log.info("getTask天融信任务数据开始");
            try {
                TianRongXinAssemble.getTask();
            } catch (Exception e) {
                log.error(e.getMessage(), e);
            }
            log.info("getTask天融信任务数据结束");
        }

        if (SyncSecConfigLoad.isEnable(SyncSecConstants.TIANRONGXIN_SYNC_ENABLE)) {
            log.info("getTask天融信WEB任务数据开始");
            try {
                TianRongXinWebAssemble.getTask();
            } catch (Exception e) {
                log.error(e.getMessage(), e);
            }
            log.info("getTask天融信WEB任务数据结束");
        }


        if (SyncSecConfigLoad.isEnable(SyncSecConstants.TIANRONGXIN_SYNC_ENABLE)) {
            log.info("getTask天融信弱口令任务数据开始");
            try {
                TianRongXinCrackAssemble.getTask();
            } catch (Exception e) {
                log.error(e.getMessage(), e);
            }
            log.info("getTask天融信弱口令任务数据结束");
        }

        if (SyncSecConfigLoad.isEnable(SyncSecConstants.HUAWEI_SYNC_ENABLE)) {
            log.info("getTask华为扫描任务");
            try {
                HuaweiAssemble.getTask();
            } catch (Exception e) {
                log.error(e.getMessage(), e);
            }
            log.info("addTask华为任务完成");
        }

        if (SyncSecConfigLoad.isEnable(SyncSecConstants.HUAWEI_SYNC_ENABLE)) {
            log.info("getTask华为WEB描任务");
            try {
                HuaweiWebAssemble.getTask();
            } catch (Exception e) {
                log.error(e.getMessage(), e);
            }
            log.info("addTask华为WEB任务完成");
        }

        if (SyncSecConfigLoad.isEnable(SyncSecConstants.HUAWEI_SYNC_ENABLE)) {
            log.info("getTask华为弱口令扫描任务");
            try {
                HuaweiCrackAssemble.getTask();
            } catch (Exception e) {
                log.error(e.getMessage(), e);
            }
            log.info("getTask华为弱口令扫描任务完成");
        }

        if (SyncSecConfigLoad.isEnable(SyncSecConstants.ANHENG_SYNC_ENABLE)) {
            log.info("getTask安恒扫描任务");
            try {
                AnhengAssemble.getTask();
            } catch (Exception e) {
                log.error(e.getMessage(), e);
            }
            log.info("getTask安恒任务完成");
        }

        if (SyncSecConfigLoad.isEnable(SyncSecConstants.ANHENG_SYNC_ENABLE)) {
            log.info("getTask安恒WEB描任务");
            try {
                AnhengWebAssemble.getTask();
            } catch (Exception e) {
                log.error(e.getMessage(), e);
            }
            log.info("getTask安恒WEB任务完成");
        }

        if (SyncSecConfigLoad.isEnable(SyncSecConstants.LVMENG_SYNC_ENABLE)) {
            log.info("getTask定时同步绿盟任务");
            try {
                LvmengAssemble.getTask();
            } catch (Exception e) {
                log.error(e.getMessage(), e);
            }
            log.info("getTask定时同步绿盟任务完成");
        }

        if (SyncSecConfigLoad.isEnable(SyncSecConstants.LVMENG_SYNC_ENABLE)) {
            log.info("getTask定时同步绿盟WEB任务");
            try {
                LvmengWebAssemble.getTask();
            } catch (Exception e) {
                log.error(e.getMessage(), e);
            }
            log.info("getTask定时同步绿盟任务WEB完成");
        }


        if (SyncSecConfigLoad.isEnable(SyncSecConstants.LVMENG_SYNC_ENABLE)) {
            log.info("getTask定时同步绿盟弱口令任务");
            try {
                LvmengCrackAssemble.getTask();
            } catch (Exception e) {
                log.error(e.getMessage(), e);
            }
            log.info("getTask定时同步绿盟弱口令任务完成");
        }

        if (SyncSecConfigLoad.isEnable(SyncSecConstants.GOBY_SYNC_ENABLE)) {
            log.info("getTask定时同步Goby任务");
            try {
                GobyAssemble.getTask();
            } catch (Exception e) {
                log.error(e.getMessage(), e);
            }
            log.info("getTask定时同步Goby任务完成");
        }

        if (SyncSecConfigLoad.isEnable(SyncSecConstants.DCC_SYNC_ENABLE)) {
            log.info("getTask定时同步Dcc任务");
            try {
                DccAssemble.getTask();
            } catch (Exception e) {
                log.error(e.getMessage(), e);
            }
            log.info("getTask定时同步Dcc任务完成");
        }

        if (SyncSecConfigLoad.isEnable(SyncSecConstants.D01_SYNC_ENABLE)) {
            log.info("getTask定时同步D01/Foeye任务");
            try {
                FoeyeAssemble.getTask();
            } catch (Exception e) {
                log.error(e.getMessage(), e);
            }
            log.info("getTask定时同步D01/Foeye任务完成");
        }

        if (SyncSecConfigLoad.isEnable(SyncSecConstants.JIAOTU_SYNC_ENABLE)) {
            log.info("getTask定时解析椒图任务");
            try {
                JiaotuAssemble.getTask();
            } catch (Exception e) {
                log.error(e.getMessage(), e);
            }
            log.info("getTask定时解析椒图任务完成");
        }

        if (SyncSecConfigLoad.isEnable(SyncSecConstants.JIAOTU_SYNC_ENABLE)) {
            log.info("getTask定时解析椒图Crack任务");
            try {
                JiaotuCrackAssemble.getTask();
            } catch (Exception e) {
                log.error(e.getMessage(), e);
            }
            log.info("getTask定时解析椒图Crack任务完成");
        }

        if (SyncSecConfigLoad.isEnable(SyncSecConstants.CHANGTING_SYNC_ENABLE)) {
            log.info("getTask长亭扫描任务");
            try {
                ChangtingAssemble.getTask();
            } catch (Exception e) {
                log.error(e.getMessage(), e);
            }
            log.info("getTask长亭任务完成");
        }

        if (SyncSecConfigLoad.isEnable(SyncSecConstants.CHANGTING_SYNC_ENABLE)) {
            log.info("getTask长亭WEB描任务");
            try {
                ChangtingWebAssemble.getTask();
            } catch (Exception e) {
                log.error(e.getMessage(), e);
            }
            log.info("getTask长亭WEB任务完成");
        }

        if (SyncSecConfigLoad.isEnable(SyncSecConstants.TDHX_SYNC_ENABLE)) {
            log.info("getTask同步天地和兴扫描任务");
            try {
                TdhxAssemble.getTask();
            } catch (Exception e) {
                log.error(e.getMessage(), e);
            }
            log.info("getTask同步天地和兴扫描任务结束");
        }

        if (SyncSecConfigLoad.isEnable(SyncSecConstants.TDHX_SYNC_ENABLE)) {
            log.info("getTask同步天地和兴弱口令任务");
            try {
                TdhxCrackAssemble.getTask();
            } catch (Exception e) {
                log.error(e.getMessage(), e);
            }
            log.info("getTask同步天地和兴弱口令任务结束");
        }

        if (SyncSecConfigLoad.isEnable(SyncSecConstants.TDHX_SYNC_ENABLE)) {
            log.info("getTask定时同步天地和兴WEB任务");
            try {
                TdhxWebAssemble.getTask();
            } catch (Exception e) {
                log.error(e.getMessage(), e);
            }
            log.info("getTask定时同步天地和兴WEB任务结束");
        }
    }

    @Scheduled(cron = "30 */5 * * * ?")
    //@Async("threadPoolTaskExecutor")
    public void getAllAsset() {

        if (SyncSecConfigLoad.isEnable(SyncSecConstants.DCC_SYNC_ENABLE)) {
            log.info("parseTask定时同步Dcc任务");
            try {
                DccAssemble.parseTask();
            } catch (Exception e) {
                log.error(e.getMessage(), e);
            }
            log.info("parseTask定时同步Dcc任务完成");
        }

        //工单状态（1.待处置，2.待审核，3.已归档，4.复查中）
        CommonMapper commonMapper = GetSpringBean.getBean(CommonMapper.class);
        try {
            List<JSONObject> list = null;
            if (VersionUtils.getDatabase() == DatabaseEnums.MYSQL.getCode()) {
                list = commonMapper.query("select v.* from tb_vuln_process_form v inner join tb_vuln_process_handle_business b on v.code = b.vuln_code and v.del_flag = '0' and b.del_flag = '0' where b.work_order_state in ('4') and b.update_time  <  DATE_SUB(NOW(), INTERVAL 1 DAY)");
            } else if (VersionUtils.getDatabase() == DatabaseEnums.DaMeng.getCode()) {
                list = commonMapper.query("select v.* from tb_vuln_process_form v inner join tb_vuln_process_handle_business b on v.code = b.vuln_code and v.del_flag = '0' and b.del_flag = '0' where b.work_order_state in ('4') and b.update_time  <=  sysdate -1");
            }
            if (list != null) {
                for (JSONObject jsonObject : list) {
                    // 华润集团青藤漏洞复查
                    if (ScannerEnums.QINGTENG_SCANNER.getCode().equalsIgnoreCase(jsonObject.getString("source"))
                            && StringUtils.isNotBlank(jsonObject.getString("agent_id"))) {
                        AllRiskVo vo = new AllRiskVo();
                        vo.setAction("reviewFallback");
                        vo.setVulCode(JsonUtils.getStr(jsonObject, "code"));
                        vo.setAgentId(JsonUtils.getStr(jsonObject, "agent_id"));
                        vo.setIp(JsonUtils.getStr(jsonObject, "ip"));
                        log.info("青藤漏洞 超过 1 天未进行复查，回退：{}", vo.getVulCode());
                        if (!QtAllRiskAutoFlowSyncQueue.vulFlowQueue.contains(vo)) {
                            QtAllRiskAutoFlowSyncQueue.vulFlowQueue.offer(vo);
                        }
                    } else {
                        RiskVo vo = new RiskVo();
                        vo.setVulnCode(JsonUtils.getStr(jsonObject, "code"));
                        vo.setRepair(false);
                        vo.setVulnName(JsonUtils.getStr(jsonObject, "vuln_name"));
                        vo.setIp(JsonUtils.getStr(jsonObject, "ip"));
                        log.info("超过 1 天为进行复查，回退：{}", vo.getVulnCode());
                        RiskAutoFlowSyncQueue.vulnFlowQueue.offer(vo);
                    }
                }
            }
        } catch (Exception e) {
            log.error(e.getMessage(), e);
        }
    }
}
