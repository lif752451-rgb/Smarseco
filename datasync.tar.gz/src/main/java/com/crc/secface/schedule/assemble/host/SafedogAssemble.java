package com.crc.secface.schedule.assemble.host;

import com.baomidou.mybatisplus.core.conditions.update.LambdaUpdateWrapper;
import com.baomidou.mybatisplus.core.toolkit.Wrappers;
import com.crc.common.code.SimpleCodeTool;
import com.crc.common.enums.ScanTypeEnums;
import com.crc.common.enums.ScannerEnums;
import com.crc.scanner.config.SafedogConfig;
import com.crc.secface.config.GetSpringBean;
import com.crc.secface.domain.EngineEquipmentManagement;
import com.crc.secface.domain.VulnProcessForm;
import com.crc.secface.domain.VulnScanTask;
import com.crc.secface.domain.VulnScanTaskRecord;
import com.crc.secface.mapper.JiaotuAgentMapper;
import com.crc.secface.mapper.VulnProcessFormMapper;
import com.crc.secface.mapper.VulnScanTaskRecordLogMapper;
import com.crc.secface.mapper.VulnScanTaskRecordMapper;
import com.crc.secface.queue.RiskAutoFlowSyncQueue;
import com.crc.secface.schedule.assemble.CommonAssemble;
import lombok.extern.slf4j.Slf4j;

import java.util.Arrays;
import java.util.Date;
import java.util.List;

/**
 * 安全狗 漏洞协同核心逻辑
 */
@Slf4j
public class SafedogAssemble {
    public static void addTask() {
        try {
            VulnScanTaskRecordMapper taskRecordMapper = GetSpringBean.getBean(VulnScanTaskRecordMapper.class);
            List<VulnScanTask> list = CommonAssemble.getCheckingScantask(ScannerEnums.JIAOTU_SCANNER.getCode(), ScanTypeEnums.HOST_SCAN.getCode(), Arrays.asList(1, 2));
            for (VulnScanTask task : list) {
                VulnScanTaskRecord record = taskRecordMapper.getLastRecordByTaskId(task.getId());
                record.setScanResult("不支持安全狗主动下发扫描");
                record.setScanStatus(3);
                taskRecordMapper.updateVulnScanTaskRecord(record);
            }
        } catch (Exception e) {
            log.error(e.getMessage(),e);
        }
    }


    public static SafedogConfig getSafedogConfig(Long engineId) {
        EngineEquipmentManagement engine = CommonAssemble.engineMap.get(engineId);
        SafedogConfig qtConfig = new SafedogConfig();
        if (engine == null || engine.getId() == null) {
            return qtConfig;
        }
        qtConfig.setEngineId(engineId);
        qtConfig.setAddress(engine.getEquipmentAddress());
        qtConfig.setKey(engine.getPassword());
        String PASS = qtConfig.getKey().trim();
        try {
            PASS = SimpleCodeTool.decrypt(PASS);
            qtConfig.setKey(PASS);
        } catch (Exception e) {
            log.error(e.getMessage(), e);
        }
        qtConfig.setAppId(engine.getLoginUser());
        return qtConfig;
    }
}
