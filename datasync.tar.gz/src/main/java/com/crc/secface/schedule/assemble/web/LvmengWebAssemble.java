package com.crc.secface.schedule.assemble.web;

import com.alibaba.fastjson.JSONArray;
import com.alibaba.fastjson.JSONObject;
import com.baomidou.mybatisplus.core.conditions.query.LambdaQueryWrapper;
import com.crc.common.code.SimpleCodeTool;
import com.crc.common.enums.ScanStatusEnums;
import com.crc.common.enums.ScanTypeEnums;
import com.crc.common.enums.ScannerEnums;
import com.crc.common.utils.*;
import com.crc.scanner.config.LvmengConfig;
import com.crc.scanner.tool.LvmengUtils;
import com.crc.secface.config.GetSpringBean;
import com.crc.secface.domain.*;
import com.crc.secface.mapper.VulnProcessFormMapper;
import com.crc.secface.mapper.VulnScanTaskMapper;
import com.crc.secface.mapper.VulnScanTaskRecordLogMapper;
import com.crc.secface.mapper.VulnScanTaskRecordMapper;
import com.crc.secface.schedule.assemble.CommonAssemble;
import com.crc.secface.schedule.assemble.WhiteListQuery;
import com.crc.sync.config.SyncSecConfigLoad;
import com.crc.sync.config.SyncSecConstants;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.apache.http.client.methods.CloseableHttpResponse;

import java.util.*;


@Slf4j
public class LvmengWebAssemble {

    public static void addTask() {
        try {
            VulnScanTaskRecordMapper taskRecordMapper = GetSpringBean.getBean(VulnScanTaskRecordMapper.class);
            VulnScanTaskRecordLogMapper taskRecordLogMapper = GetSpringBean.getBean(VulnScanTaskRecordLogMapper.class);
            List<VulnScanTask> list = CommonAssemble.getCheckingScantask(ScannerEnums.LVMENG_SCANNER.getCode(), ScanTypeEnums.WEB_SCAN.getCode(), Arrays.asList(1, 2));
            for (VulnScanTask task : list) {
                try {
                    VulnScanTaskRecord record = taskRecordMapper.getLastRecordByTaskId(task.getId());
                    if (record == null) {
                        continue;
                    }
                    LambdaQueryWrapper<VulnScanTaskRecordLog> qlog = new LambdaQueryWrapper<>();
                    qlog.eq(VulnScanTaskRecordLog::getRecordId, record.getId());
                    qlog.eq(VulnScanTaskRecordLog::getTaskId, task.getId());
                    String scanContent = task.getScanContentX();
                    if (taskRecordLogMapper.selectCount(qlog) > 0) {
                        log.info("{}{},已在执行中", task.getTaskName(), scanContent);
                        continue;
                    }
                    List<String> uuids = new ArrayList<>();
                    if (!StringUtils.isBlank(scanContent)) {
                        //多个地址用英文逗号(;)分隔
                        for (String ipStr : scanContent.split("\n")) {
                            String ip = ipStr.trim();
                            if (!UrlUtils.isValidUrl(ip)) {
                                continue;
                            }
                            uuids.add(ip);
                        }
                    }

                    VulnScanTaskRecordLog recordLog = new VulnScanTaskRecordLog();
                    recordLog.setIp(scanContent);
                    recordLog.setTaskId(record.getTaskId());
                    recordLog.setTaskName(task.getTaskName());
                    recordLog.setRecordId(record.getId());
                    recordLog.setEngineId(task.getEngineId());
                    recordLog.setCreateTime(new Date());
                    recordLog.setType(ScannerEnums.LVMENG_SCANNER.getCode());
                    //任务状态(0 未开始 1 执行中 2 执行完成 3 执行失败)
                    recordLog.setScanStatus(0);


                    LvmengConfig scannerInfo = getLvConfig(task.getEngineId());
                    String id = "";
                    if (uuids.size() < 1) {
                        log.error("创建任务:" + task.getTaskName() + " -> 失败，没有找到真实IP");
                        CommonAssemble.startFail(task, "任务无法解析出有效IP");
                        continue;
                    } else if (uuids.size() > 5) {
                        log.error("创建任务:" + task.getTaskName() + " -> 失败，最多5个IP或者IP段");
                        CommonAssemble.startFail(task, "创建任务失败，最多5个IP或者IP段");
                        continue;
                    } else {
                        id = LvmengUtils.createVulWebTask(scannerInfo, task.getTaskName(), String.join(";", uuids));
                    }
                    String taskMsg = "执行成功";


                    if (StringUtils.isNotBlank(id)) {
                        recordLog.setScanStatus(1);
                        recordLog.setJobId(id);
                        recordLog.setResult(taskMsg);
                        taskRecordLogMapper.insert(recordLog);
                    } else {
                        //失败
                        recordLog.setScanStatus(3);
                        taskMsg = "执行失败";
                        recordLog.setResult(taskMsg);
                        taskRecordLogMapper.insert(recordLog);
                        CommonAssemble.startFail(recordLog, taskMsg);
                    }

                    log.info("创建任务:" + task.getTaskName() + " -> " + taskMsg + " 返回ID：" + id);
                    record.setScanResult(taskMsg);
                    record.setScanStatus(1);
                    taskRecordMapper.updateVulnScanTaskRecord(record);
                } catch (Exception e) {
                    log.error(e.getMessage(), e);
                }
            }
        } catch (Exception e) {
            log.error(e.getMessage(), e);
        }
    }

    public static LvmengConfig getLvConfig(Long engineId) {
        EngineEquipmentManagement engine = CommonAssemble.engineMap.get(engineId);
        LvmengConfig qtConfig = new LvmengConfig();
        if (engine == null) {
            return qtConfig;
        }
        qtConfig.setEngineId(engineId);
        qtConfig.setAddress(engine.getEquipmentAddress());
        qtConfig.setPassword(engine.getPassword());
        String PASS = qtConfig.getPassword().trim();
        try {
            PASS = SimpleCodeTool.decrypt(PASS);
            qtConfig.setPassword(PASS);
        } catch (Exception e) {
            log.error(e.getMessage(), e);
        }
        qtConfig.setUsername(engine.getLoginUser());
        return qtConfig;
    }

    public static void getTask() {
        VulnScanTaskRecordLogMapper taskRecordLogMapper = GetSpringBean.getBean(VulnScanTaskRecordLogMapper.class);
        VulnScanTaskRecordMapper taskRecordMapper = GetSpringBean.getBean(VulnScanTaskRecordMapper.class);
        VulnScanTaskMapper scanTaskMapper = GetSpringBean.getBean(VulnScanTaskMapper.class);
        try {
            VulnScanTaskRecordLog q = new VulnScanTaskRecordLog();
            q.setScanStatus(1);//扫描中
            q.setScanType(ScanTypeEnums.WEB_SCAN.getCode());
            q.setEngineName(ScannerEnums.LVMENG_SCANNER.getCode());
            List<VulnScanTaskRecordLog> recordList = taskRecordLogMapper.getAllRecordLogList(q);
            for (VulnScanTaskRecordLog task : recordList) {
                try {
                    LvmengConfig scannerInfo = getLvConfig(task.getEngineId());
                    // 扫描任务id
                    JSONObject retJson = LvmengUtils.getTaskStatus(scannerInfo, task.getJobId());
                    /*
                    0:等待扫描
                    2:正在扫描
                    5:扫描暂停
                    4:扫描完成
                    8:异常停止
                     */

                    if (retJson != null) {
                        if (retJson.containsKey("status")) {
                            //1-运行中，2-完成，3-停止
                            int istatus = JsonUtils.getInt(retJson, "status");
                            String progress = JsonUtils.getStr(retJson, "process").replace("%", "");
                            boolean stop = false;
                            if (istatus == 0 || istatus == 2 || istatus == 5) {
                                //进行中
                            } else if (istatus == 4) {
                                progress = "100";
                            } else {
                                stop = true;
                            }

                            task.setProgress(DataUtils.toInt(progress));
                            int status = 1;
                            if (task.getProgress() == 100 && istatus == 4) {
                                status = 2;
                            }


                            if (stop) {
                                log.error("任务异常停止:" + task.getTaskName() + " -> " + " 进度：" + progress + ",status=" + istatus);
                                status = 2;
                            } else {
                                log.info("读取任务:" + task.getTaskName() + " -> " + " 进度：" + progress + ",status=" + istatus);
                            }
                            task.setScanStatus(status);
                            taskRecordLogMapper.updateById(task);

                            List<String> scanUrls = CommonAssemble.getScanUrls(task.getTaskId());
                            log.info("{},扫描 url:{}",task.getTaskName(),scanUrls);
                            if (task.getProgress() == 100 && !stop && istatus == 4) {
                                CloseableHttpResponse response = null;
                                try {
                                    int total = LvmengUtils.getTaskInfoTotal(scannerInfo, task.getJobId());
                                    if (total > 0) {
                                        HashMap<String, List<VulnProcessForm>> dataMap = new HashMap<>();
                                        int pageSize = 5;
                                        for (int idx = 0; idx < DataUtils.getPageCount(total, pageSize, 0); idx++) {
                                            ///api/report/task/{task_id}
                                            response = LvmengUtils.get(scannerInfo, "/api/report/task/" + task.getJobId() + "?page=" + (idx + 1) + "&page_size=" + pageSize, "");
                                            int code = response.getStatusLine().getStatusCode();
                                            if (code == 200) {
                                                JSONObject json = JsonUtils.parse(DataUtils.toBodyString(response.getEntity()));
                                                int vulTotal = 0;
                                                if (json.containsKey("ret_msg") && JsonUtils.equal(json, "ret_msg", "success")) {
                                                    JSONObject data = JsonUtils.getJson(json, "data");
                                                    if (data != null && data.containsKey("report")) {
                                                        int curTaskTotal = JsonUtils.getInt(data, "target_total");
                                                        if (curTaskTotal < 1) {
                                                            break;
                                                        }
                                                        JSONArray vulList = data.getJSONObject("report").getJSONArray("targets");
                                                        String findTime = JsonUtils.getStr(data.getJSONObject("report").getJSONObject("task"), "time_end_scan");
                                                        if (vulList != null && vulList.size() > 0) {
                                                            for (int i = 0; i < vulList.size(); i++) {
                                                                try {
                                                                    JSONObject vulJson = vulList.getJSONObject(i);
                                                                    String ip = JsonUtils.getStr(vulJson, "site");
                                                                    JSONArray vulnDetailList = vulJson.getJSONArray("vuln_detail");
                                                                    int vulCount = 0;
                                                                    if (vulnDetailList != null) {
                                                                        vulCount = vulnDetailList.size();
                                                                    }
                                                                    vulTotal += vulCount;
                                                                    if (vulCount > 0) {
                                                                        for (int j = 0; j < vulCount; j++) {
                                                                            try {
                                                                                JSONObject vulJsonInfo = vulnDetailList.getJSONObject(j);
                                                                                String id = JsonUtils.getStr(vulJsonInfo, "vul_id");
                                                                                VulnProcessForm curVul = getVul(scannerInfo.getEngineId(), vulJsonInfo, ip, ScanTypeEnums.WEB_SCAN.getCode(), findTime);
                                                                                if (curVul == null) {
                                                                                    continue;
                                                                                }
                                                                                JSONArray jsonArray = vulJson.getJSONArray("vuln_scanned");
                                                                                if (jsonArray != null) {
                                                                                    for (int z = 0; z < jsonArray.size(); z++) {
                                                                                        JSONObject jsonObject = jsonArray.getJSONObject(z);
                                                                                        if (JsonUtils.getStr(jsonObject, "vul_id").equals(id)) {
                                                                                            curVul.setIp(JsonUtils.getStr(jsonObject, "url"));
                                                                                        }
                                                                                    }
                                                                                }
                                                                                if (curVul.getIp() == null) {
                                                                                    continue;
                                                                                }
                                                                                /*
                                                                                 * 判断是否为扫描起始 url
                                                                                 */
                                                                                boolean flag = false;
                                                                                for (String scanUrl : scanUrls) {
                                                                                    if (curVul.getIp().startsWith(scanUrl)) {
                                                                                        flag = true;
                                                                                        break;
                                                                                    }
                                                                                }
                                                                                if (!flag) {
                                                                                    continue;
                                                                                }

                                                                                if (dataMap.containsKey(ip)) {
                                                                                    dataMap.get(ip).add(curVul);
                                                                                } else {
                                                                                    dataMap.put(ip, new ArrayList<>());
                                                                                    dataMap.get(ip).add(curVul);
                                                                                }
                                                                            } catch (Exception e) {
                                                                                log.error(e.getMessage(), e);
                                                                            }
                                                                        }
                                                                    }
                                                                } catch (Exception e) {
                                                                    log.error(e.getMessage(), e);
                                                                }

                                                            }
                                                        }
                                                    }
                                                }
                                            }
                                        }

                                        for (String ip : dataMap.keySet()) {
                                            List<VulnProcessForm> curList = dataMap.get(ip);
                                            if (curList.size() > 0) {
                                                log.info("解析任务:" + task.getTaskName() + " " + ip + " -> " + " 发现漏洞：" + curList.size());
                                                handle(curList, ip);
                                            } else {
                                                log.info("解析任务:" + task.getTaskName() + " " + ip + " -> " + " 未发现漏洞");
                                                repairAllByIp(ip);
                                            }
                                        }
                                    }
                                } catch (Exception e) {
                                    log.error(e.getMessage(), e);
                                } finally {
                                    IOUtils.close(response);
                                }
                            }

                            /*
                             * 更新业务段任务进度
                             */
                            try {
                                VulnScanTaskRecord taskRecord = taskRecordMapper.selectById(task.getRecordId());
                                taskRecord.setScanProgress(task.getProgress());
                                if (status == 2) {
                                    taskRecord.setScanEndTime(new Date());
                                    taskRecord.setDuration(DateUtils.getDiffSec(taskRecord.getScanStartTime(), taskRecord.getScanEndTime()));
                                    taskRecord.setScanStatus(2);
                                    taskRecord.setScanResult("扫描完成");
                                }
                                taskRecordMapper.updateVulnScanTaskRecord(taskRecord);

                                VulnScanTask scanTask = new VulnScanTask();
                                scanTask.setId(taskRecord.getTaskId());
                                scanTask.setUpdateTime(new Date());
                                scanTask.setScanProgress(taskRecord.getScanProgress());

                                if (taskRecord.getScanStatus() != null && taskRecord.getScanStatus() > 1) {
                                    scanTask.setScanStatus(ScanStatusEnums.SCAN_FINISH.getCode());
                                }
                                scanTaskMapper.updateVulnScanTask(scanTask);
                            } catch (Exception e) {
                                log.error(e.getMessage(), e);
                            }
                        }else {
                            //{"data":{"inner_error":"系统异常"},"ret_msg":"找不到任务","ret_code":"-1"}
                            if(JsonUtils.equalVal(retJson,"ret_code","999")) {
                                try {
                                    task.setScanStatus(3);
                                    task.setResult("系统异常,找不到任务");
                                    taskRecordLogMapper.updateVulnScanTaskRecordLog(task);

                                    VulnScanTaskRecord taskRecord = taskRecordMapper.selectById(task.getRecordId());
                                    taskRecord.setScanProgress(task.getProgress());
                                    taskRecord.setScanEndTime(new Date());
                                    taskRecord.setDuration(DateUtils.getDiffSec(taskRecord.getScanStartTime(), taskRecord.getScanEndTime()));
                                    taskRecord.setScanStatus(2);
                                    taskRecord.setScanResult("系统异常,找不到任务");
                                    taskRecordMapper.updateVulnScanTaskRecord(taskRecord);

                                    VulnScanTask scanTask = new VulnScanTask();
                                    scanTask.setId(taskRecord.getTaskId());
                                    scanTask.setUpdateTime(new Date());
                                    scanTask.setScanProgress(taskRecord.getScanProgress());

                                    if (taskRecord.getScanStatus() != null && taskRecord.getScanStatus() > 1) {
                                        scanTask.setScanStatus(ScanStatusEnums.SCAN_FINISH.getCode());
                                    }
                                    scanTaskMapper.updateVulnScanTask(scanTask);
                                } catch (Exception e) {
                                    log.error(e.getMessage(), e);
                                }
                            }
                        }
                    }
                } catch (Exception e) {
                    log.error(e.getMessage(), e);
                }
            }
        } catch (Exception e) {
            log.error(e.getMessage(), e);
        }
        log.info("绿盟WEB同步结束");
    }


    /**
     * IP全部修复
     *
     * @param ip IP
     */
    public static void repairAllByIp(String ip) {
        try {
            CommonAssemble.repairAll(ip, ScannerEnums.LVMENG_SCANNER.getCode(), ScanTypeEnums.WEB_SCAN.getCode());
        } catch (Exception e) {
            log.error(e.getMessage(), e);
        }
    }

    private static void handle(List<VulnProcessForm> culList, String domain) {
        if (StringUtils.isBlank(domain)) {
            log.error("非法域名");
            return;
        }
        domain = UrlUtils.getDomain(domain);
        //原有漏洞查询
        VulnProcessFormMapper vulnProcessFormMapper = GetSpringBean.getBean(VulnProcessFormMapper.class);
        //原有漏洞查询
        LambdaQueryWrapper<VulnProcessForm> vq = new LambdaQueryWrapper<>();
        vq.eq(VulnProcessForm::getDomain, domain);
        vq.eq(VulnProcessForm::getSource, ScannerEnums.LVMENG_SCANNER.getCode());
        vq.eq(VulnProcessForm::getCategory, ScanTypeEnums.WEB_SCAN.getCode());
        List<VulnProcessForm> vulList = vulnProcessFormMapper.selectList(vq);
        List<VulnProcessForm> repairedList = new LinkedList<>();
        List<VulnProcessForm> unrepairedList = new LinkedList<>();
        List<VulnProcessForm> newVulList = new LinkedList<>();
        log.info(domain + " 库存漏洞：" + vulList.size() + " 当前有漏洞：" + culList.size());
        int newTotal = 0;
        int dropTotal = 0;
        //扫描到漏洞
        for (VulnProcessForm curVul : culList) {
            //白名单
            if (WhiteListQuery.isWhiteList(curVul)) {
                dropTotal++;
                continue;
            }
            newVulList.add(curVul);
            //是否新漏洞
            boolean isnew = true;
            VulnProcessForm tmp = vulnProcessFormMapper.selectById(curVul.getId());
            if (tmp != null) {
                vulnProcessFormMapper.stillExist(curVul.getId());
                isnew = false;
            }

            if (isnew) {
                //新漏洞
                if (CommonAssemble.saveVul(curVul)) {
                    newTotal++;
                } else {
                    dropTotal++;
                }
            }
        }
        //已修复的漏洞判断
        for (VulnProcessForm oldVul : vulList) {
            boolean isRepair = true;
            for (VulnProcessForm newVul : newVulList) {
                //漏洞名称 节点IP是否相同
                if (newVul.getId().equalsIgnoreCase(oldVul.getId())) {
                    isRepair = false;
                    break;
                }
            }
            //漏洞已修复
            if (isRepair) {
                repairedList.add(oldVul);
            } else {
                //未修复
                unrepairedList.add(oldVul);
            }
        }
        log.info(domain + " @@@@@@@@@@@@库存漏洞：" + vulList.size() + " 丢弃漏洞：" + dropTotal + " 新增漏洞：" + newTotal + " 未修复漏洞：" + unrepairedList.size() + " 修复漏洞：" + repairedList.size());
        if (repairedList.size() > 0) {
            repairedList.forEach((CommonAssemble::repairedVul));
        }
        if (unrepairedList.size() > 0) {
            unrepairedList.forEach((CommonAssemble::unRepairedVul));
        }
        CommonAssemble.sendMsg(vulList, ScannerEnums.LVMENG_SCANNER.getName(), ScanTypeEnums.WEB_SCAN.getCode(), domain, newTotal, unrepairedList.size(), repairedList.size());
    }

    /**
     * 解析漏洞数据
     *
     * @param engineId
     * @param json
     * @param ip
     * @param scanType
     * @return
     */
    private static VulnProcessForm getVul(Long engineId, JSONObject json, String ip, int scanType, String findTime) {
        /*
        {
              "nsfocus_id": "",
              "description": "OpenSSL是Openssl团队的一个开源的能够实现安全套接层（SSLv2/v3）和安全传输层（TLSv1）协议的通用加密库。该产品支持多种加密算法，包括对称密码、哈希算法、安全散列算法等。 \nOpenSSL 存在输入验证错误漏洞，攻击者可利用该漏洞导致应用程序行为不正确或崩溃。",
              "cve_id": "CVE-2021-23840",
              "application_category": "OpenSSL",
              "solution": "厂商补丁:\n\n目前厂商已发布升级补丁以修复漏洞，补丁获取链接： \nhttps://www.openssl.org/news/secadv/20210216.txt",
              "exp_desc": "-",
              "threat_category": "其他",
              "risk_points": 7.5,
              "name": "OpenSSL 安全漏洞(CVE-2021-23840)",
              "vul_id": 78226,
              "bugtraq_id": "",
              "cnnvd": "CNNVD-202102-1235",
              "plugin_id": 71074
            }
         */

        String vulName = JsonUtils.getStr(json, "name");
        if (StringUtils.isBlank(vulName)) {
            return null;
        }

        double riskPoints = JsonUtils.getDouble(json, "risk_points");
//        if (riskPoints < 1) {
//            log.info("信息级别漏洞丢弃：" + json.toJSONString());
//            return null;
//        }

        String desc = JsonUtils.getStr(json, "description");
        String solution = JsonUtils.getStr(json, "solution");
        //Date firstCheckDate = JsonUtils.getDate(json, "firstCheckTime");
        //Date publicDate = JsonUtils.getDate(json, "publicDate");
        String vulType = JsonUtils.getStr(json, "threat_category");
        String cnnvd = JsonUtils.getStr(json, "cnnvd");

        //高	7 <= 漏洞风险值 <= 10	攻击者可以远程执行任意命令或者代码，或对系统进行远程拒绝服务攻击。
        //中	4 <= 漏洞风险值 < 7	攻击者可以远程创建、修改、删除文件或数据，或对普通服务进行拒绝服务攻击。
        //低	0 <= 漏洞风险值 < 4	攻击者可以获取某些系统、服务的信息，或读取系统文件和数据。
        //0:低危, 1:中危, 2:高危, 3:严重
        int level = 0;
        if (riskPoints >= 7) {
            level = 2;
        } else if (riskPoints >= 4) {
            level = 1;
        }
        String filter = SyncSecConfigLoad.getRemarkValue(SyncSecConstants.LVMENG_SYNC_ENABLE);
        try {
            boolean flag = false;
            if (filter != null && filter.contains("=") && filter.contains("level")) {
                String filterLevel = filter.split("=")[1];
                String slevel = String.valueOf(level + 1);
                for (String fl : filterLevel.split(",")) {
                    if (StringUtils.isNotBlank(slevel) && slevel.equalsIgnoreCase(fl)) {
                        flag = true;
                        break;
                    }
                }
            } else {
                flag = true;
            }
            if (!flag) {
                return null;
            }
        } catch (Exception e) {
            log.error(e.getMessage(), e);
        }
        String cveId = JsonUtils.getStr(json, "cve_id");

        VulnProcessForm vul = new VulnProcessForm();
        if (scanType == ScanTypeEnums.WEB_SCAN.getCode()) {
            vul.setDomain(UrlUtils.getDomain(ip));
        }
        String vulId = JsonUtils.getStr(json, "vul_id");
        vul.setIp(ip);
        vul.setVulnName(vulName);
        vul.setCode(String.format("VUL_%s", IdGen.uuid8()));
        vul.setLevel(String.valueOf(level));
        vul.setCategory(scanType);
        vul.setSource(ScannerEnums.LVMENG_SCANNER.getCode());
        String id = Md5Utils.hash(ip + "#" + vulId + "#" + cveId + "#" + vul.getSource());
        vul.setId(id);
        vul.setVulnType(vulType);
        vul.setDescription(desc);
        vul.setSolution(solution);
        vul.setCnnvd(cnnvd);
        vul.setCveCode(cveId);
        vul.setEngineId(String.valueOf(engineId));
        vul.setCreateTime(new Date());
        vul.setUpdateTime(new Date());
        vul.setFirstTime(DateUtils.parseDateTime(findTime, DateUtils.DATE_FORMAT_STRING1));
        vul.setRecentlyTime(DateUtils.parseDateTime(findTime, DateUtils.DATE_FORMAT_STRING1));
        return vul;
    }
}
