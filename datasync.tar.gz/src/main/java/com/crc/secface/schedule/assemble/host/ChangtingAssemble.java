package com.crc.secface.schedule.assemble.host;

import cn.hutool.core.collection.CollUtil;
import com.alibaba.fastjson.JSONArray;
import com.alibaba.fastjson.JSONObject;
import com.baomidou.mybatisplus.core.conditions.query.LambdaQueryWrapper;
import com.baomidou.mybatisplus.core.conditions.update.LambdaUpdateWrapper;
import com.baomidou.mybatisplus.core.toolkit.Wrappers;
import com.crc.common.enums.AssetSourceEnums;
import com.crc.common.enums.ScanStatusEnums;
import com.crc.common.enums.ScanTypeEnums;
import com.crc.common.enums.ScannerEnums;
import com.crc.common.utils.*;
import com.crc.scanner.config.ChangTingConfig;
import com.crc.scanner.tool.ChangTingUtils;
import com.crc.secface.config.GetSpringBean;
import com.crc.secface.domain.*;
import com.crc.secface.mapper.*;
import com.crc.secface.queue.CrcAssetSyncQueue;
import com.crc.secface.schedule.assemble.CommonAssemble;
import com.crc.secface.schedule.assemble.WhiteListQuery;
import com.crc.sync.changting.ChangtingHostAssetSync;
import com.crc.sync.changting.XProcessStatusEnum;
import com.crc.sync.config.SyncSecConfigLoad;
import com.crc.sync.config.SyncSecConstants;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.apache.http.client.methods.CloseableHttpResponse;

import java.util.*;

import static com.crc.common.constants.Constants.*;


@Slf4j
public class ChangtingAssemble {

    public static void addTask() {
        try {
            VulnScanTaskRecordMapper taskRecordMapper = GetSpringBean.getBean(VulnScanTaskRecordMapper.class);
            VulnScanTaskRecordLogMapper taskRecordLogMapper = GetSpringBean.getBean(VulnScanTaskRecordLogMapper.class);
            List<VulnScanTask> list = CommonAssemble.getCheckingScantask(ScannerEnums.CHANGTING_SCANNER.getCode(), ScanTypeEnums.HOST_SCAN.getCode(), Arrays.asList(1, 2));
            log.info("需要下发的长亭主机扫描中任务数：" + list.size());
            for (VulnScanTask task : list) {
                try {
                    VulnScanTaskRecord record = taskRecordMapper.getLastRecordByTaskId(task.getId());
                    if (record == null) {
                        continue;
                    }
                    LambdaQueryWrapper<VulnScanTaskRecordLog> qlog = new LambdaQueryWrapper<>();
                    qlog.eq(VulnScanTaskRecordLog::getRecordId, record.getId());
                    qlog.eq(VulnScanTaskRecordLog::getTaskId, task.getId());
                    String scanContent = task.getScanContentX();
                    if (taskRecordLogMapper.selectCount(qlog) > 0) {
                        log.info("{}{},已在执行中", task.getTaskName(), scanContent);
                        continue;
                    }
                    List<String> uuids = new ArrayList<>();
                    if (!StringUtils.isBlank(scanContent)) {
                        //多个地址用英文逗号(,)分隔
                        for (String ipStr : scanContent.split("\n")) {
                            String ip = ipStr.trim();
                            if (StringUtils.isBlank(ip)) {
                                continue;
                            }
                            uuids.add(ip);
                        }
                    }

                    VulnScanTaskRecordLog recordLog = new VulnScanTaskRecordLog();
                    recordLog.setIp(scanContent);
                    recordLog.setTaskId(record.getTaskId());
                    recordLog.setTaskName(task.getTaskName());
                    recordLog.setRecordId(record.getId());
                    recordLog.setEngineId(task.getEngineId());
                    recordLog.setCreateTime(new Date());
                    recordLog.setType(ScannerEnums.CHANGTING_SCANNER.getCode());
                    //任务状态(0 未开始 1 执行中 2 执行完成 3 执行失败)
                    recordLog.setScanStatus(0);


                    ChangTingConfig scannerInfo = ChangtingHostAssetSync.getCtConfig(task.getEngineId());
                    String id = "";
                    if (uuids.size() < 1) {
                        log.error("创建任务:" + task.getTaskName() + " -> 失败，没有找到真实IP");
                        CommonAssemble.startFail(task, "任务无法解析出有效IP");
                        continue;
                    } else if (uuids.size() > 5) {
                        log.error("创建任务:" + task.getTaskName() + " -> 失败，最多5个IP或者IP段");
                        CommonAssemble.startFail(task, "创建任务失败，最多5个IP或者IP段");
                        continue;
                    } else {
                        id = ChangTingUtils.createVulTask(scannerInfo, task.getTaskName(), uuids);
                    }
                    String taskMsg = "执行成功";


                    if (StringUtils.isNotBlank(id)) {
                        recordLog.setScanStatus(1);
                        recordLog.setJobId(id);
                        recordLog.setResult(taskMsg);
                        taskRecordLogMapper.insert(recordLog);
                        log.info("创建任务:" + task.getTaskName() + " -> " + taskMsg + " 返回ID：" + id);
                    } else {
                        //失败
                        recordLog.setScanStatus(3);
                        taskMsg = "执行失败";
                        recordLog.setResult(taskMsg);
                        taskRecordLogMapper.insert(recordLog);
                        CommonAssemble.startFail(recordLog, taskMsg);
                        log.error("创建任务失败:" + task.getTaskName() + " -> " + taskMsg);
                    }


                    record.setScanResult(taskMsg);
                    record.setScanStatus(1);
                    taskRecordMapper.updateVulnScanTaskRecord(record);
                } catch (Exception e) {
                    log.error(e.getMessage(), e);
                }
            }
        } catch (Exception e) {
            log.error(e.getMessage(), e);
        }
    }

    public static void getTask() {
        VulnScanTaskRecordLogMapper taskRecordLogMapper = GetSpringBean.getBean(VulnScanTaskRecordLogMapper.class);
        VulnScanTaskRecordMapper taskRecordMapper = GetSpringBean.getBean(VulnScanTaskRecordMapper.class);
        VulnScanTaskMapper scanTaskMapper = GetSpringBean.getBean(VulnScanTaskMapper.class);
        try {
            VulnScanTaskRecordLog q = new VulnScanTaskRecordLog();
            q.setScanStatus(1);//扫描中
            q.setScanType(ScanTypeEnums.HOST_SCAN.getCode());
            q.setEngineName(ScannerEnums.CHANGTING_SCANNER.getCode());
            List<VulnScanTaskRecordLog> recordList = taskRecordLogMapper.getAllRecordLogList(q);
            for (VulnScanTaskRecordLog task : recordList) {
                try {
                    ChangTingConfig scannerInfo = ChangtingHostAssetSync.getCtConfig(task.getEngineId());
                    //已完成的即时任务xprocessId
                    JSONObject retJson = ChangTingUtils.getXprocess(scannerInfo, task.getJobId());
                    //log.info("jobId:{},status={}",task.getJobId(), JSON.toJSONString(retJson));
                    XProcessStatusEnum xProcessStatus = XProcessStatusEnum.getValueByName(JsonUtils.getStr(retJson, STATUS));
                    /*
                    0:等待扫描
                    2:正在扫描
                    5:扫描暂停
                    4:扫描完成
                    8:异常停止
                     */
                    //取值范围：任务实例状态 APPOINT：等待排期， QUEUING：等待扫描， WORKING：正在扫描， FINISHED： 扫描成功， PAUSED： 暂停扫描， PARTIAL_PAUSED： 部分阶段暂停，或FAILED：扫描失败
                    if (retJson != null && xProcessStatus != null) {
                        String xprocId = JsonUtils.getStr(retJson, "id");//xprocId
                        if (retJson.containsKey("status")) {
                            //1-运行中，2-完成，3-停止
                            String progress = JsonUtils.getStr(retJson, "progress").replace("%", "");
                            boolean stop = false;
                            if (xProcessStatus == XProcessStatusEnum.APPOINT || XProcessStatusEnum.PAUSED == xProcessStatus || XProcessStatusEnum.WORKING == xProcessStatus || XProcessStatusEnum.QUEUING == xProcessStatus) {
                                //进行中
                            } else if (xProcessStatus == XProcessStatusEnum.FINISHED) {
                                progress = "100";
                            } else {
                                stop = true;
                            }

                            task.setProgress(DataUtils.toInt(progress));
                            int status = 1;
                            if (task.getProgress() == 100 && xProcessStatus == XProcessStatusEnum.FINISHED) {
                                status = 2;
                            }


                            if (stop) {
                                log.error("任务异常停止:" + task.getTaskName() + " -> " + " 进度：" + progress + ",status=" + xProcessStatus.getDesc());
                                status = 2;
                            } else {
                                log.info("读取任务:" + task.getTaskName() + " -> " + " 进度：" + progress + ",status=" + xProcessStatus.getDesc());
                            }
                            task.setScanStatus(status);
                            taskRecordLogMapper.updateById(task);
                            if (task.getProgress() == 100 && !stop && xProcessStatus == XProcessStatusEnum.FINISHED) {
                                CloseableHttpResponse response = null;
                                try {
                                    JSONObject parameters = new JSONObject();
                                    parameters.put(LIMIT, 1);
                                    parameters.put(OFFSET, 0);
                                    parameters.put(XPROCESS_ID, xprocId);
                                    parameters.put(RESULT_TYPE, VULN);
                                    JSONObject result = ChangTingUtils.getScanResult(scannerInfo, parameters);
                                    if (JsonUtils.isEmpty(result)) {
                                        log.error("ChangTingUtils.getScanResult(scannerInfo, parameters) empty!");
                                        continue;
                                    }
                                    long total = JsonUtils.getLong(result, COUNT);
                                    log.info("ChangTingUtils.getScanResult={}",total);
                                    if (total > 0) {
                                        HashMap<String, List<VulnProcessForm>> dataMap = new HashMap<>();
                                        int pageSize = 5;
                                        for (int idx = 1; idx < Math.ceil(total / pageSize) + 2; idx++) {
                                            ///api/report/task/{task_id}
                                            JSONObject data = ChangTingUtils.getScanResult(scannerInfo, getJsonParamters(idx, pageSize, xprocId));
                                            if (JsonUtils.isEmpty(data)) {
                                                continue;
                                            }
                                            JSONArray list = data.getJSONArray(RESULT);
                                            if (CollUtil.isNotEmpty(list)) {
                                                log.info("ChangTingUtils.dataList={}",list.size());
                                                for (int j = 0; j < list.size(); j++) {
                                                    JSONObject vulJson = list.getJSONObject(j);
                                                    if (vulJson == null || vulJson.isEmpty()) {
                                                        continue;
                                                    }
                                                    JSONObject target = JsonUtils.getJson(vulJson, "target");
                                                    if (target == null) {
                                                        continue;
                                                    }
                                                    String ip = null;
                                                    if (target.containsKey("host")) {
                                                        ip = target.getString("host");
                                                        if (StringUtils.isBlank(ip)) {
                                                            continue;
                                                        }
                                                    }
                                                    if (StringUtils.isBlank(ip)) {
                                                        if (target.containsKey("url")) {
                                                            String url = target.getString("url");
                                                            ip = UrlUtils.getDomain(url);
                                                        }
                                                    }

                                                    if (!IpUtils.isIp(ip)) {
                                                        log.info("未找到 IP，{}",vulJson.toJSONString());
                                                        continue;
                                                    }

                                                    VulnProcessForm curVul = getVul(scannerInfo, vulJson, ip, ScanTypeEnums.HOST_SCAN.getCode());
                                                    if (curVul == null) {
                                                        log.info("vul null,{}",ip);
                                                        continue;
                                                    }
                                                    if (dataMap.containsKey(ip)) {
                                                        dataMap.get(ip).add(curVul);
                                                    } else {
                                                        dataMap.put(ip, new ArrayList<>());
                                                        dataMap.get(ip).add(curVul);
                                                    }
                                                }
                                            }
                                        }

                                        for (String ip : dataMap.keySet()) {
                                            List<VulnProcessForm> curList = dataMap.get(ip);
                                            if (curList.size() > 0) {
                                                log.info("解析任务:" + task.getTaskName() + " " + ip + " -> " + " 发现漏洞：" + curList.size());
                                                handle(curList, ip);
                                            } else {
                                                log.info("解析任务:" + task.getTaskName() + " " + ip + " -> " + " 未发现漏洞");
                                                repairAllByIp(ip);
                                            }
                                        }
                                    }
                                } catch (Exception e) {
                                    log.error(e.getMessage(), e);
                                } finally {
                                    IOUtils.close(response);
                                }
                            }

                            /*
                             * 更新业务段任务进度
                             */
                            try {
                                VulnScanTaskRecord taskRecord = taskRecordMapper.selectById(task.getRecordId());
                                taskRecord.setScanProgress(task.getProgress());
                                if (status == 2) {
                                    taskRecord.setScanEndTime(new Date());
                                    taskRecord.setDuration(DateUtils.getDiffSec(taskRecord.getScanStartTime(), taskRecord.getScanEndTime()));
                                    taskRecord.setScanStatus(2);
                                    taskRecord.setScanResult("扫描完成");
                                }
                                taskRecordMapper.updateVulnScanTaskRecord(taskRecord);

                                VulnScanTask scanTask = new VulnScanTask();
                                scanTask.setId(taskRecord.getTaskId());
                                scanTask.setUpdateTime(new Date());
                                scanTask.setScanProgress(taskRecord.getScanProgress());

                                if (taskRecord.getScanStatus() != null && taskRecord.getScanStatus() > 1) {
                                    scanTask.setScanStatus(ScanStatusEnums.SCAN_FINISH.getCode());
                                }
                                scanTaskMapper.updateVulnScanTask(scanTask);
                            } catch (Exception e) {
                                log.error(e.getMessage(), e);
                            }
                        }
                    }
                } catch (Exception e) {
                    log.error(e.getMessage(), e);
                }
            }
        } catch (Exception e) {
            log.error(e.getMessage(), e);
        }
        log.info("长亭主机同步结束");
    }

    private static void handle(List<VulnProcessForm> culList, String ip) {
        //原有漏洞查询
        VulnProcessFormMapper vulnProcessFormMapper = GetSpringBean.getBean(VulnProcessFormMapper.class);
        AssetMapper assetMapper = GetSpringBean.getBean(AssetMapper.class);
        //原有漏洞查询
        LambdaQueryWrapper<VulnProcessForm> vq = new LambdaQueryWrapper<>();
        vq.eq(VulnProcessForm::getIp, ip);
        vq.eq(VulnProcessForm::getSource, ScannerEnums.CHANGTING_SCANNER.getCode());
        vq.eq(VulnProcessForm::getCategory, ScanTypeEnums.HOST_SCAN.getCode());
        List<VulnProcessForm> vulList = vulnProcessFormMapper.selectList(vq);
        List<VulnProcessForm> repairedList = new LinkedList<>();
        List<VulnProcessForm> unrepairedList = new LinkedList<>();
        List<VulnProcessForm> newVulList = new LinkedList<>();
        log.info(ip + " 库存漏洞：" + vulList.size() + " 当前有漏洞：" + culList.size());
        int newTotal = 0;
        int dropTotal = 0;
        //扫描到漏洞
        for (VulnProcessForm curVul : culList) {
            Asset asset = assetMapper.selectAssetByInnerIp(ip);
            if (asset == null) {
                asset = new Asset();
                asset.setSource(AssetSourceEnums.CHANGTING_CMDB.getCode());
                asset.setInternalIp(ip);
                CrcAssetSyncQueue.getInstance().saveAsset(asset);
            }

            if ("1".equals(curVul.getStatus())) {
                dropTotal++;
                continue;
            }

            //白名单
            if (WhiteListQuery.isWhiteList(curVul)) {
                dropTotal++;
                continue;
            }
            newVulList.add(curVul);
            //是否新漏洞
            boolean isnew = true;
            VulnProcessForm tmp = vulnProcessFormMapper.selectById(curVul.getId());
            if (tmp != null) {
                vulnProcessFormMapper.stillExist(curVul.getId());
                isnew = false;
            }

            if (isnew) {
                //新漏洞
                if (CommonAssemble.saveVul(curVul)) {
                    newTotal++;
                } else {
                    dropTotal++;
                }
            } else {
                try {
                    LambdaUpdateWrapper<VulnProcessForm> updateWrapper = Wrappers.lambdaUpdate();
                    updateWrapper.eq(VulnProcessForm::getId, tmp.getId());
                    updateWrapper.set(VulnProcessForm::getDescription, curVul.getDescription());
                    updateWrapper.set(VulnProcessForm::getSolution, curVul.getSolution());
                    if (StringUtils.isNotBlank(curVul.getAffectApplication())) {
                        updateWrapper.set(VulnProcessForm::getAffectApplication, curVul.getAffectApplication());
                    }
                    updateWrapper.set(VulnProcessForm::getUpdateTime, new Date());
                    vulnProcessFormMapper.update(null, updateWrapper);
                } catch (Exception e) {
                    log.error(e.getMessage(), e);
                }
            }
        }
        //已修复的漏洞判断
        for (VulnProcessForm oldVul : vulList) {
            boolean isRepair = true;
            for (VulnProcessForm newVul : newVulList) {
                //漏洞名称 节点IP是否相同
                if (newVul.getId().equalsIgnoreCase(oldVul.getId())) {
                    isRepair = false;
                    break;
                }
            }
            //漏洞已修复
            if (isRepair) {
                repairedList.add(oldVul);
            } else {
                //未修复
                unrepairedList.add(oldVul);
            }
        }
        log.info(ip + " @@@@@@@@@@@@库存漏洞：" + vulList.size() + " 丢弃漏洞：" + dropTotal + " 新增漏洞：" + newTotal + " 未修复漏洞：" + unrepairedList.size() + " 修复漏洞：" + repairedList.size());
        if (repairedList.size() > 0) {
            repairedList.forEach((CommonAssemble::repairedVul));
        }
        if (unrepairedList.size() > 0) {
            unrepairedList.forEach((CommonAssemble::unRepairedVul));
        }
        CommonAssemble.sendMsg(vulList, ScannerEnums.CHANGTING_SCANNER.getName(), ScanTypeEnums.HOST_SCAN.getCode(), ip, newTotal, unrepairedList.size(), repairedList.size());
    }


    /**
     * IP全部修复
     *
     * @param ip IP
     */
    public static void repairAllByIp(String ip) {
        try {
            CommonAssemble.repairAll(ip, ScannerEnums.CHANGTING_SCANNER.getCode(), ScanTypeEnums.HOST_SCAN.getCode());
        } catch (Exception e) {
            log.error(e.getMessage(), e);
        }
    }

    private static VulnProcessForm getVul(ChangTingConfig scannerInfo, JSONObject json, String ip, int scanType) {
        // 漏洞名称
        String vulName = JsonUtils.getStr(json, "title");
        if (StringUtils.isBlank(vulName)) {
            log.info("vul error vulname null");
            return null;
        }
        try {
            // 解决方案
            String solution = JsonUtils.getStr(json, "solution");
            String category = JsonUtils.getStr(json, "category");
            // 漏洞类型
            String vulType = ChangTingUtils.getVulnCategory(scannerInfo, category);
            // 漏洞资产的确信度，疑似是开启漏洞库版本匹配产生的漏洞
            String definiteness = JsonUtils.getStr(json, "definiteness");
            // 漏洞资产状态：UNHANDLED, FIXING, FIXED, MISREPORT, VERIFYING, REVERIFYING或IGNORE
            String status = JsonUtils.getStr(json, "status");
            if ("FIXED".equals(status) || "MISREPORT".equals(status) || "IGNORE".equals(status)) {
                log.info("{} {} 状态{},当成修复==", ip, vulName, status);
                status = "1";
            } else {
                status = "0";
            }
            // 漏洞资产的严重程度：LOW,MEDIUM,HIGH,CRITICAL
            String severity = JsonUtils.getStr(json, "severity");
            // 漏洞修复时间
            String fixedTime = JsonUtils.getStr(json, "fixed_time");
            // poc
            String poc = JsonUtils.getStr(json, "poc");
            // exp
            String exp = JsonUtils.getStr(json, "exp");
            // impact
            String impact = JsonUtils.getStr(json, "impact");
            // 漏洞id
            String vulId = JsonUtils.getStr(json, "id");
            // 漏洞概述
            String summary = JsonUtils.getStr(json,"summary") + JsonUtils.getStr(json, "detail");
            String cvss = JsonUtils.getStr(json, "cvss");
            int level = 0;
            if (StringUtils.isBlank(severity)) {
                level = 0;
            } else {
                if (severity.equals("LOW")) {
                    level = 0;
                } else if (severity.equals("MEDIUM")) {
                    level = 1;
                } else if (severity.equals("HIGH")) {
                    level = 2;
                } else if (severity.equals("CRITICAL")) {
                    level = 3;
                } else {
                    level = 0;
                }
            }

            String CVE = "";
            JSONArray exposures = json.getJSONArray("exposures");
            if (CollUtil.isNotEmpty(exposures)) {
                Optional<Object> optional = exposures.stream().filter(t -> t.toString().startsWith("CVE-")).findFirst();
                if (optional.isPresent()) {
                    CVE = optional.get().toString();
                } else {
                    CVE = exposures.getString(0);
                }
            }
            Date publicDate = JsonUtils.getDate(json, "published_datetime");
            Date firstCheckDate = JsonUtils.getDate(json, "created_time");


            if (StringUtils.isBlank(vulName)) {
                return null;
            }
            String filter = SyncSecConfigLoad.getRemarkValue(SyncSecConstants.CHANGTING_SYNC_ENABLE);
            try {
                boolean flag = false;
                if (filter != null && filter.contains("=") && filter.contains("level")) {
                    String filterLevel = filter.split("=")[1];
                    String slevel = String.valueOf(level + 1);
                    for (String fl : filterLevel.split(",")) {
                        if (StringUtils.isNotBlank(slevel) && slevel.equalsIgnoreCase(fl)) {
                            flag = true;
                            break;
                        }
                    }
                } else {
                    flag = true;
                }
                if (!flag) {
                    return null;
                }
            } catch (Exception e) {
                log.error(e.getMessage(), e);
            }

            VulnProcessForm vul = new VulnProcessForm();
            vul.setIp(ip);
            vul.setCvss(cvss);
            vul.setStatus(status);
            vul.setVulnName(vulName);
            vul.setCode(String.format("VUL_%s", IdGen.uuid8()));
            vul.setLevel(String.valueOf(level));
            vul.setCategory(scanType);
            vul.setSource(ScannerEnums.CHANGTING_SCANNER.getCode());
            String id = Md5Utils.hash(ip + "#" + vulId + "#" + CVE + "#" + vul.getSource());
            vul.setId(id);
            vul.setVulnType(vulType);
            vul.setDescription(summary);
            vul.setSolution(solution);
            vul.setCveCode(CVE);
            vul.setEngineId(String.valueOf(scannerInfo.getEngineId()));
            vul.setCreateTime(new Date());
            vul.setUpdateTime(new Date());
            vul.setFirstTime(firstCheckDate);
            vul.setRecentlyTime(firstCheckDate);

            //漏洞特征 1：存在EXP 2：存在POC 3：远程执行 4：本地提权 5：内核漏洞
            List<String> feats = new ArrayList<>();
            try {
                if (exp.length() > 1 && !exp.equals("暂无")) {
                    feats.add("1");
                }
                if (poc.length() > 1 && !poc.equals("暂无")) {
                    feats.add("2");
                }
            } catch (Exception e) {
                log.error(e.getMessage(), e);
            }
            vul.setVulFeatures(String.join(",", feats));
            CommonAssemble.saveVulAssetInfo(vul, ip);
            return vul;
        } catch (Exception e) {
            log.error(e.getMessage(), e);
        }
        return null;
    }


    private static JSONObject getJsonParamters(int i, int pageSize, String xprocessId) {
        JSONObject parms = new JSONObject();
        parms.put(LIMIT, pageSize);
        parms.put(OFFSET, (i - 1) * pageSize);
        parms.put(XPROCESS_ID, xprocessId);
        parms.put(RESULT_TYPE, VULN);
        return parms;
    }
}
