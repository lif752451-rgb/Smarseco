package com.crc.secface.schedule.assemble.host;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONArray;
import com.alibaba.fastjson.JSONObject;
import com.baomidou.mybatisplus.core.conditions.query.LambdaQueryWrapper;
import com.crc.common.code.SimpleCodeTool;
import com.crc.common.enums.AssetSourceEnums;
import com.crc.common.enums.ScanStatusEnums;
import com.crc.common.enums.ScanTypeEnums;
import com.crc.common.enums.ScannerEnums;
import com.crc.common.utils.*;
import com.crc.scanner.config.AnhengConfig;
import com.crc.scanner.tool.AnHengUtils;
import com.crc.secface.config.GetSpringBean;
import com.crc.secface.domain.*;
import com.crc.secface.mapper.*;
import com.crc.secface.queue.CrcAssetSyncQueue;
import com.crc.secface.schedule.assemble.CommonAssemble;
import com.crc.secface.schedule.assemble.WhiteListQuery;
import com.crc.sync.config.SyncSecConfigLoad;
import com.crc.sync.config.SyncSecConstants;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;

import java.util.*;


@Slf4j
public class AnhengAssemble {
    public static AnhengConfig getAnhengConfig(Long engineId) {
        EngineEquipmentManagement engine = CommonAssemble.engineMap.get(engineId);
        AnhengConfig qtConfig = new AnhengConfig();
        if (engine == null || engine.getId() == null) {
            return qtConfig;
        }
        try {
            qtConfig.setEngineId(engineId);
            qtConfig.setAddress(engine.getEquipmentAddress().trim());
            String PASS = engine.getPassword().trim();
            qtConfig.setPassword(PASS);
            try {
                PASS = SimpleCodeTool.decrypt(PASS);
                qtConfig.setPassword(PASS.trim());
            } catch (Exception e) {
                log.error(e.getMessage(), e);
            }
            qtConfig.setUserName(engine.getLoginUser().trim());
        } catch (Exception e) {
            log.error(e.getMessage(), e);
        }
        return qtConfig;
    }

    public static void addTask() {
        try {
            VulnScanTaskRecordMapper taskRecordMapper = GetSpringBean.getBean(VulnScanTaskRecordMapper.class);
            VulnScanTaskRecordLogMapper taskRecordLogMapper = GetSpringBean.getBean(VulnScanTaskRecordLogMapper.class);
            List<VulnScanTask> list = CommonAssemble.getCheckingScantask(ScannerEnums.ANHENG_SCANNER.getCode(), ScanTypeEnums.HOST_SCAN.getCode(), Arrays.asList(1, 2));
            log.info("Anheng待执行待任务数量：" + list.size());
            for (VulnScanTask task : list) {
                try {
                    AnhengConfig scannerInfo = getAnhengConfig(task.getEngineId());
                    VulnScanTaskRecord record = taskRecordMapper.getLastRecordByTaskId(task.getId());
                    if (record == null) {
                        continue;
                    }
                    LambdaQueryWrapper<VulnScanTaskRecordLog> qlog = new LambdaQueryWrapper<>();
                    qlog.eq(VulnScanTaskRecordLog::getRecordId, record.getId());
                    qlog.eq(VulnScanTaskRecordLog::getTaskId, task.getId());
                    String scanContent = task.getScanContentX(",");
                    if (taskRecordLogMapper.selectCount(qlog) > 0) {
                        log.info("{}{},已在执行中", task.getTaskName(), scanContent);
                        continue;
                    }
                    VulnScanTaskRecordLog recordLog = new VulnScanTaskRecordLog();
                    recordLog.setIp(scanContent);
                    recordLog.setTaskId(record.getTaskId());
                    recordLog.setTaskName(task.getTaskName());
                    recordLog.setRecordId(record.getId());
                    recordLog.setEngineId(task.getEngineId());
                    recordLog.setCreateTime(new Date());
                    recordLog.setType(ScannerEnums.ANHENG_SCANNER.getCode());
                    //任务状态(0 未开始 1 执行中 2 执行完成 3 执行失败)
                    recordLog.setScanStatus(0);


                    String jobId = AnHengUtils.createHostTask(scannerInfo, task.getTaskName(), recordLog.getIp());
                    String taskMsg = "执行成功";

                    if (StringUtils.isNotBlank(jobId)) {
                        recordLog.setScanStatus(1);
                        recordLog.setResult(taskMsg);
                        record.setScanStatus(1);
                        recordLog.setJobId(jobId);
                        taskRecordLogMapper.insert(recordLog);
                    } else {
                        recordLog.setScanStatus(3);
                        record.setScanStatus(3);
                        taskMsg = "执行失败";
                        recordLog.setResult(taskMsg);
                        taskRecordLogMapper.insert(recordLog);

                        CommonAssemble.startFail(recordLog, taskMsg);
                    }
                    log.info(String.format("task_id=%s,返回=%s,%s", recordLog.getTaskId(), jobId, taskMsg));
                    record.setScanResult(taskMsg);
                    taskRecordMapper.updateVulnScanTaskRecord(record);
                    // }
                } catch (Exception e) {
                    log.error(e.getMessage(), e);
                }
            }
        } catch (Exception e) {
            log.error(e.getMessage(), e);
        }
    }

    public static void getTask() {
        try {
            CommonAssemble.engineMap.forEach((k, v) -> {
                if (ScannerEnums.ANHENG_SCANNER.getCode().equals(v.getEquipmentManufacture())) {
                    getTask(getAnhengConfig(k));
                }
            });
        } catch (Exception e) {
            log.error(e.getMessage(), e);
        }
    }

    private static void getTask(AnhengConfig anhengConfig) {
        VulnScanTaskRecordLogMapper taskRecordLogMapper = GetSpringBean.getBean(VulnScanTaskRecordLogMapper.class);
        VulnScanTaskRecordMapper taskRecordMapper = GetSpringBean.getBean(VulnScanTaskRecordMapper.class);
        VulnScanTaskMapper scanTaskMapper = GetSpringBean.getBean(VulnScanTaskMapper.class);
        try {
            VulnScanTaskRecordLog q = new VulnScanTaskRecordLog();
            q.setScanStatus(1);//扫描中
            q.setScanType(ScanTypeEnums.HOST_SCAN.getCode());
            q.setEngineName(ScannerEnums.ANHENG_SCANNER.getCode());
            List<VulnScanTaskRecordLog> recordList = taskRecordLogMapper.getAllRecordLogList(q);
            for (VulnScanTaskRecordLog task : recordList) {
                try {
                    // 扫描任务id
                    AnHengUtils.login(anhengConfig);
                    if (StringUtils.isBlank(anhengConfig.getToken())) {
                        log.error("获取 token 失败");
                        continue;
                    }
                    JSONObject retJson = AnHengUtils.getTaskStatus(anhengConfig, AnHengUtils.MODULE_HOST, task.getJobId());
                    /*
                     * {
                     * "code":"1",
                     * "msg":"成功",
                     * "data":{
                     * "progress":2,
                     * "state":1
                     */

                    if (retJson != null) {
                        if (retJson.containsKey("state")) {
                            //任务状态 1	等待调度, 2	正在扫描, 3	暂停状态, 4	停止状态, 5	结束状态 6	异常状态
                            int istatus = JsonUtils.getInt(retJson, "state");
                            String progress = JsonUtils.getStr(retJson, "progress").replace("%", "");
                            boolean stop = false;
                            if (istatus == 1 || istatus == 2) {
                                //进行中
                            } else if (istatus == 5 || istatus == 4) {
                                progress = "100";
                            } else {
                                stop = true;
                            }

                            task.setProgress(DataUtils.toInt(progress));
                            int status = 1;
                            if (task.getProgress() == 100) {
                                status = 2;
                            }

                            if (stop) {
                                log.error("任务异常停止:" + task.getTaskName() + " -> " + " 进度：" + progress + ",status=" + istatus);
                                status = 2;
                            } else {
                                log.info("读取任务:" + task.getTaskName() + " -> " + " 进度：" + progress + ",status=" + istatus);
                            }
                            task.setScanStatus(status);
                            taskRecordLogMapper.updateById(task);
                            if (task.getProgress() == 100 && !stop) {
                                //https://{ip}:{port}/api/normal/task/list/count?module=8&taskId=11&offset=1&limit=100
                                //JSONArray retArr = AnHengUtils.getTask(anhengConfig, task.getTaskName(), task.getJobId());
                                String url = anhengConfig.getAddress() + "/api/normal/task/result";
                                //offset 结果记录偏移量(offset>=0)，说明结果在第几页
                                //limit 结果获取量(0<limit<=100)，设置每页的数据条数
                                String param = String.format("module=%d&taskId=%s&offset=0&limit=1", AnHengUtils.MODULE_HOST, task.getJobId());

                                JSONObject header = new JSONObject();
                                header.put("Authorization", anhengConfig.getToken());

                                String ret = HttpUtils.sendGet(url, param, header);
                                JSONObject dataRet = JsonUtils.parse(ret);
                                JSONObject dataJson = dataRet.getJSONObject("data");
                                int total = JsonUtils.getInt(dataJson, "count");
                                log.info("{}漏洞总数:{}", task.getTaskName(), total);
                                HashMap<String, List<VulnProcessForm>> dataMap = new HashMap<>();
                                HashMap<String, List<VulnProcessForm>> dataWeakPswMap = new HashMap<>();
                                if (total > 0) {
                                    for (int idx = 1; idx < DataUtils.getPageCount(total, 100, 0); idx++) {
                                        try {
                                            param = String.format("module=%d&taskId=%s&offset=%d&limit=100", AnHengUtils.MODULE_HOST, task.getJobId(), idx);
                                            String retData = HttpUtils.sendGet(url, param, header);
                                            JSONObject retDataJson = JsonUtils.parse(retData);
                                            JSONObject data = retDataJson.getJSONObject("data");
                                            if (data == null) {
                                                log.error("数据为空");
                                                continue;
                                            }
                                            JSONArray retArr = data.getJSONArray("vuls");
                                            if (retArr == null) {
                                                log.error("数据为空");
                                                continue;
                                            }
                                            for (int i = 0; i < retArr.size(); i++) {
                                                JSONObject vulJson = retArr.getJSONObject(i);
                                                HashMap<String, String> ipMap = new HashMap<>();
                                                if (vulJson.containsKey("ipaddrs")) {
                                                    JSONArray ipaddrs = vulJson.getJSONArray("ipaddrs");
                                                    for (int j = 0; j < ipaddrs.size(); j++) {
                                                        String ip = ipaddrs.getString(j);
                                                        if (StringUtils.isNotBlank(ip)) {
                                                            ip = ip.trim().split(":")[0];
                                                            if (!IpUtils.isIp(ip)) {
                                                                log.error("##漏洞 IP 为非法IP" + ip);
                                                                continue;
                                                            }
                                                            ipMap.put(ip, "1");
                                                        }
                                                    }
                                                }
                                                if (vulJson.containsKey("ipaddr")) {
                                                    String ip = vulJson.getString("ipaddr");
                                                    if (StringUtils.isNotBlank(ip)) {
                                                        ipMap.put(ip.trim().split(":")[0], "1");
                                                    }
                                                }
                                                if (ipMap.size() < 1) {
                                                    log.error("未识别到 IP 信息:" + JSON.toJSONString(vulJson));
                                                    continue;
                                                }
                                                try {
                                                    VulnProcessForm curVul = getVul(anhengConfig, vulJson, ScanTypeEnums.HOST_SCAN.getCode());
                                                    if (curVul == null) {
                                                        log.info("非法漏洞数据：{}", vulJson.toJSONString());
                                                        continue;
                                                    }
                                                    log.info("发现 IP:{}", JSON.toJSONString(ipMap));
                                                    for (String ip : ipMap.keySet()) {
                                                        String id = Md5Utils.hash(ip + "#" + curVul.getVulnName() + "#" + curVul.getCveCode() + "#" + curVul.getSource());
                                                        curVul.setId(id);
                                                        curVul.setIp(ip);
                                                        Asset asset = new Asset();
                                                        asset.setInternalIp(ip);
                                                        //资产状态，可选项：1在用、2停用、3下架、4库存备用、5故障设备、6已临时关停、7待修、8在修、9闲置、10待报废、11报废、12转交
                                                        asset.setOperatingStatus(1);
                                                        asset.setSource(AssetSourceEnums.ANHENG_CMDB.getCode());
                                                        CrcAssetSyncQueue.getInstance().saveAsset(asset);
                                                        CommonAssemble.saveVulAssetInfo(curVul, asset);

                                                        if (ScanTypeEnums.WEAK_PASS_SCAN.getCode() == curVul.getCategory()) {
                                                            if (dataWeakPswMap.containsKey(ip)) {
                                                                dataWeakPswMap.get(ip).add(curVul);
                                                            } else {
                                                                dataWeakPswMap.put(ip, new ArrayList<>());
                                                                dataWeakPswMap.get(ip).add(curVul);
                                                            }
                                                        } else {
                                                            if (dataMap.containsKey(ip)) {
                                                                dataMap.get(ip).add(curVul);
                                                            } else {
                                                                dataMap.put(ip, new ArrayList<>());
                                                                dataMap.get(ip).add(curVul);
                                                            }
                                                        }
                                                    }
                                                } catch (Exception e) {
                                                    log.error(e.getMessage(), e);
                                                }
                                            }
                                        } catch (Exception e) {
                                            log.error(e.getMessage(), e);
                                        }
                                    }
                                }

                                for (String ip : dataMap.keySet()) {
                                    List<VulnProcessForm> curList = dataMap.get(ip);
                                    if (curList.size() > 0) {
                                        log.info("解析任务:" + task.getTaskName() + " " + ip + " -> " + " 发现漏洞：" + curList.size());
                                        handle(curList, ip);
                                    } else {
                                        log.info("解析任务:" + task.getTaskName() + " " + ip + " -> " + " 未发现漏洞");
                                        repairAllByIp(ip, ScanTypeEnums.HOST_SCAN.getCode());
                                    }
                                }
                                for (String ip : dataWeakPswMap.keySet()) {
                                    List<VulnProcessForm> curList = dataWeakPswMap.get(ip);
                                    if (curList.size() > 0) {
                                        log.info("解析任务:" + task.getTaskName() + " " + ip + " -> " + " 发现弱口令：" + curList.size());
                                        handleWeakPsw(curList, ip);
                                    } else {
                                        log.info("解析任务:" + task.getTaskName() + " " + ip + " -> " + " 未发现弱口令");
                                        repairAllByIp(ip, ScanTypeEnums.WEAK_PASS_SCAN.getCode());
                                    }
                                }
                            } else {
                                log.error("{}-获取漏洞数据失败", task.getTaskName());
                            }


                            /*
                             * 更新业务段任务进度
                             */
                            try {
                                VulnScanTaskRecord taskRecord = taskRecordMapper.selectById(task.getRecordId());
                                taskRecord.setScanProgress(task.getProgress());
                                if (status == 2) {
                                    taskRecord.setScanEndTime(new Date());
                                    taskRecord.setDuration(DateUtils.getDiffSec(taskRecord.getScanStartTime(), taskRecord.getScanEndTime()));
                                    taskRecord.setScanStatus(2);
                                    taskRecord.setScanResult("扫描完成");
                                }
                                taskRecordMapper.updateVulnScanTaskRecord(taskRecord);

                                VulnScanTask scanTask = new VulnScanTask();
                                scanTask.setId(taskRecord.getTaskId());
                                scanTask.setUpdateTime(new Date());
                                scanTask.setScanProgress(taskRecord.getScanProgress());

                                if (taskRecord.getScanStatus() != null && taskRecord.getScanStatus() > 1) {
                                    scanTask.setScanStatus(ScanStatusEnums.SCAN_FINISH.getCode());
                                }
                                scanTaskMapper.updateVulnScanTask(scanTask);
                            } catch (Exception e) {
                                log.error(e.getMessage(), e);
                            }
                        }
                    }
                } catch (Exception e) {
                    log.error(e.getMessage(), e);
                }
            }
        } catch (Exception e) {
            log.error(e.getMessage(), e);
        }
    }

    private static void repairAllByIp(String ip, int type) {
        try {
            CommonAssemble.repairAll(ip, ScannerEnums.ANHENG_SCANNER.getCode(), type);
        } catch (Exception e) {
            log.error(e.getMessage(), e);
        }
    }

    private static void handle(List<VulnProcessForm> culList, String ip) {
        //原有漏洞查询
        VulnProcessFormMapper vulnProcessFormMapper = GetSpringBean.getBean(VulnProcessFormMapper.class);
        AssetMapper assetMapper = GetSpringBean.getBean(AssetMapper.class);
        //原有漏洞查询
        LambdaQueryWrapper<VulnProcessForm> vq = new LambdaQueryWrapper<>();
        vq.eq(VulnProcessForm::getIp, ip);
        vq.eq(VulnProcessForm::getSource, ScannerEnums.ANHENG_SCANNER.getCode());
        vq.eq(VulnProcessForm::getCategory, ScanTypeEnums.HOST_SCAN.getCode());
        List<VulnProcessForm> vulList = vulnProcessFormMapper.selectList(vq);
        List<VulnProcessForm> repairedList = new LinkedList<>();
        List<VulnProcessForm> unrepairedList = new LinkedList<>();
        List<VulnProcessForm> newVulList = new LinkedList<>();
        log.info(ip + " 库存漏洞：" + vulList.size() + " 当前有漏洞：" + culList.size());
        int newTotal = 0;
        int dropTotal = 0;
        //扫描到漏洞
        for (VulnProcessForm curVul : culList) {
            Asset asset = assetMapper.selectAssetByInnerIp(ip);
            if (asset == null) {
                asset = new Asset();
                asset.setSource(AssetSourceEnums.ANHENG_CMDB.getCode());
                asset.setInternalIp(ip);
                CrcAssetSyncQueue.getInstance().saveAsset(asset);
            }
            //白名单
            if (WhiteListQuery.isWhiteList(curVul)) {
                dropTotal++;
                continue;
            }
            newVulList.add(curVul);
            //是否新漏洞
            boolean isnew = true;
            VulnProcessForm tmp = vulnProcessFormMapper.selectById(curVul.getId());
            if (tmp != null) {
                vulnProcessFormMapper.stillExist(curVul.getId());
                isnew = false;
            }

            if (isnew) {
                //新漏洞
                if (CommonAssemble.saveVul(curVul)) {
                    newTotal++;
                } else {
                    dropTotal++;
                }
            }
        }
        //已修复的漏洞判断
        for (VulnProcessForm oldVul : vulList) {
            boolean isRepair = true;
            for (VulnProcessForm newVul : newVulList) {
                //漏洞名称 节点IP是否相同
                if (newVul.getId().equalsIgnoreCase(oldVul.getId())) {
                    isRepair = false;
                    break;
                }
            }
            //漏洞已修复
            if (isRepair) {
                repairedList.add(oldVul);
            } else {
                //未修复
                unrepairedList.add(oldVul);
            }
        }
        log.info(ip + " @@@@@@@@@@@@库存漏洞：" + vulList.size() + " 丢弃漏洞：" + dropTotal + " 新增漏洞：" + newTotal + " 未修复漏洞：" + unrepairedList.size() + " 修复漏洞：" + repairedList.size());
        if (!repairedList.isEmpty()) {
            repairedList.forEach((CommonAssemble::repairedVul));
        }
        if (!unrepairedList.isEmpty()) {
            unrepairedList.forEach((CommonAssemble::unRepairedVul));
        }
        CommonAssemble.sendMsg(vulList, ScannerEnums.ANHENG_SCANNER.getName(), ScanTypeEnums.HOST_SCAN.getCode(), ip, newTotal, unrepairedList.size(), repairedList.size());
    }

    private static VulnProcessForm getVul(AnhengConfig engine, JSONObject jsonData, int code) {
        try {
            String username = JsonUtils.getStr(jsonData, "username");
            String password = JsonUtils.getStr(jsonData, "password");
            String svc = JsonUtils.getStr(jsonData, "svc");
            boolean weakPsw = false;
            if (StringUtils.isNotBlank(username) && StringUtils.isNotBlank(password) && StringUtils.isNotBlank(svc)) {
                weakPsw = true;
            }


            String policy = JsonUtils.getStr(jsonData, "policyNo");
            if (StringUtils.isBlank(policy)) {
                policy = JsonUtils.getStr(jsonData, "policy");
            }
            if (StringUtils.isBlank(policy)) {
                log.error("漏洞的策略 ID 为空！{}", JSON.toJSONString(jsonData));
                if (weakPsw) {
                    return getWeakPsw(jsonData, engine.getEngineId(), null);
                }
                return null;
            }
            JSONObject policyJson = AnHengUtils.getPolicyById(engine, AnHengUtils.MODULE_HOST, policy);
            if (policyJson == null) {
                log.error("漏洞的策略 ID {}不在策略列表中！", policy);
                if (weakPsw) {
                    return getWeakPsw(jsonData, engine.getEngineId(), null);
                }
                return null;
            }
            if (weakPsw) {
                return getWeakPsw(jsonData, engine.getEngineId(), policyJson);
            }
            String common_title = JsonUtils.getStr(policyJson, "name");//漏洞名称
            String levelStr = JsonUtils.getStr(policyJson, "level");//1:低危, 2:中危, 3:⾼危, 4:严重int
            String vulType = JsonUtils.getStr(policyJson, "type");//漏洞类型
            String cveId = JsonUtils.getStr(policyJson, "cve");//cveId


            //我们0:低危, 1:中危, 2:高危, 3:严重
            int dt = DataUtils.getInt(levelStr);
            int level = 0;
            if (dt < 2) {
                level = 0;
            } else if (dt < 3) {
                level = 1;
            } else {
                level = 2;
            }
            String filter = SyncSecConfigLoad.getRemarkValue(SyncSecConstants.ANHENG_SYNC_ENABLE);
            try {
                boolean flag = false;
                if (filter != null && filter.contains("=") && filter.contains("level")) {
                    String filterLevel = filter.split("=")[1];
                    String slevel = String.valueOf(level + 1);
                    for (String fl : filterLevel.split(",")) {
                        if (StringUtils.isNotBlank(slevel) && slevel.equalsIgnoreCase(fl)) {
                            flag = true;
                            break;
                        }
                        if (level == 0 && "1".equalsIgnoreCase(fl)) {
                            flag = true;
                            break;
                        }
                    }
                } else {
                    flag = true;
                }
                if (!flag) {
                    log.error("级别过滤" + level);
                    return null;
                }
            } catch (Exception e) {
                log.error(e.getMessage(), e);
            }

            String vulId = JsonUtils.getStr(jsonData, "_id");//解决方案
            String recommandation = JsonUtils.getStr(policyJson, "advice");//解决方案
            String common_description = JsonUtils.getStr(policyJson, "desct");//漏洞描述
            VulnProcessForm vul = new VulnProcessForm();
            vul.setVulnName(common_title);
            vul.setCvss(JsonUtils.getStr(policyJson, "cvss"));
            vul.setLevel(String.valueOf(level));
            vul.setSource(ScannerEnums.ANHENG_SCANNER.getCode());
            vul.setVulnType(vulType);
            vul.setDescription(common_description);
            vul.setSolution(recommandation);
            vul.setEngineId(String.valueOf(engine.getEngineId()));
            vul.setCategory(code);
            vul.setCveCode(cveId);
            vul.setCode(String.format("VUL_%s", IdGen.uuid8()));
            vul.setCreateTime(DateUtils.parseDate(JsonUtils.getStr(jsonData, "createTime"), DateUtils.DATE_FORMAT_STRING1));
            vul.setUpdateTime(new Date());
            vul.setFirstTime(vul.getCreateTime());
            if (vul.getUpdateTime() != null) {
                vul.setRecentlyTime(vul.getUpdateTime());
            }
            return vul;

        } catch (Exception e) {
            log.error(e.getMessage(), e);
        }
        return null;
    }

    /**
     * 获取弱口令详情
     *
     * @param json 原始
     * @return 弱口令信息
     */
    private static VulnProcessForm getWeakPsw(JSONObject json, long engineId, JSONObject policyJson) {
        try {
            String vulName = JsonUtils.getStr(json, "vulName") + JsonUtils.getStr(json, "uname") + JsonUtils.getStr(json, "port") + JsonUtils.getStr(json, "password") + JsonUtils.getStr(json, "app");
            if (StringUtils.isBlank(vulName)) {
                return null;
            }
            String solution = "请修改相关弱口令，并举一反三全面排查系统弱口令，增加口令默认配置策略。";
            //我们0:低危, 1:中危, 2:高危, 3:严重
            int dt = JsonUtils.getInt(json, "level");
            if (dt == 0) {
                dt = JsonUtils.getInt(policyJson, "level");
            }
            int level = 0;
            if (dt < 2) {
                level = 0;
            } else if (dt < 3) {
                level = 1;
            } else {
                level = 2;
            }

            VulnProcessForm vul = new VulnProcessForm();
            vul.setCvss(JsonUtils.getStr(policyJson, "cvss"));
            vul.setLevel(String.valueOf(level));
            vul.setSource(ScannerEnums.ANHENG_SCANNER.getCode());
            vul.setEngineId(String.valueOf(engineId));
            vul.setVulnName(vulName);
            vul.setCode(String.format("VUL_%s", IdGen.uuid8()));
            vul.setLevel(String.valueOf(level));
            vul.setCategory(ScanTypeEnums.WEAK_PASS_SCAN.getCode());
            String recommandation = JsonUtils.getStr(policyJson, "advice");//解决方案
            if (StringUtils.isBlank(recommandation)) {
                recommandation = solution;
            }
            String username = JsonUtils.getStr(json, "username");
            String password = JsonUtils.getStr(json, "password");
            String svc = JsonUtils.getStr(json, "svc");
            String common_description = JsonUtils.getStr(policyJson, "desct");//漏洞描述
            if (StringUtils.isBlank(common_description)) {
                common_description = svc + "服务存在弱口令，登陆当前登陆账号：" + username;
            }
            vul.setSolution(recommandation);
            vul.setDescription(common_description);
            String vulType = JsonUtils.getStr(policyJson, "type");//漏洞类型
            vul.setVulnType(vulType);
            String cveId = JsonUtils.getStr(policyJson, "cve");//cveId
            vul.setCveCode(cveId);
            vul.setValidInfo(JsonUtils.getStr(json, "checkInfo"));
            vul.setAffectApplication(JsonUtils.getStr(json, "appVersion"));
            vul.setCreateTime(DateUtils.parseDate(JsonUtils.getStr(json, "createTime"), DateUtils.DATE_FORMAT_STRING1));
            vul.setUpdateTime(new Date());
            vul.setFirstTime(vul.getCreateTime());
            if (vul.getUpdateTime() != null) {
                vul.setRecentlyTime(vul.getUpdateTime());
            }

            vul.setPassword(password);
            vul.setUserName(username);
            vul.setPort(JsonUtils.getStr(json, "port"));
            vul.setService(svc);
            if (StringUtils.isBlank(vul.getVulnType())) {
                vul.setVulnType("常见弱密码");
            }
            return vul;
        } catch (Exception e) {
            log.error(e.getMessage(), e);
        }
        return null;
    }

    private static void handleWeakPsw(List<VulnProcessForm> vuln, String ip) {
        VulnProcessFormMapper vulnProcessFormMapper = GetSpringBean.getBean(VulnProcessFormMapper.class);
        //原有弱口令查询
        LambdaQueryWrapper<VulnProcessForm> vq = new LambdaQueryWrapper<>();
        vq.eq(VulnProcessForm::getIp, ip);
        vq.eq(VulnProcessForm::getSource, ScannerEnums.ANHENG_SCANNER.getCode());
        vq.eq(VulnProcessForm::getCategory, ScanTypeEnums.WEAK_PASS_SCAN.getCode());
        List<VulnProcessForm> vulList = vulnProcessFormMapper.selectList(vq);
        List<VulnProcessForm> repairedList = new LinkedList<>();
        List<VulnProcessForm> unrepairedList = new LinkedList<>();
        List<VulnProcessForm> newVulList = new LinkedList<>();
        log.info(ip + " 库存弱口令：" + vulList.size() + " 当前有弱口令：" + vuln.size());
        int newTotal = 0;
        int dropTotal = 0;
        //扫描到弱口令
        for (VulnProcessForm curVul : vuln) {
            //白名单
            if (WhiteListQuery.isWhiteList(curVul)) {
                dropTotal++;
                continue;
            }
            newVulList.add(curVul);
            //是否新弱口令
            boolean isnew = true;
            LambdaQueryWrapper<VulnProcessForm> q = new LambdaQueryWrapper<>();
            q.eq(VulnProcessForm::getId, curVul.getId());
            if (vulnProcessFormMapper.selectCount(q) > 0) {
                vulnProcessFormMapper.stillExist(curVul.getId());
                isnew = false;
            }

            if (isnew) {
                //新弱口令
                if (CommonAssemble.saveVul(curVul)) {
                    newTotal++;
                } else {
                    dropTotal++;
                }
                //后台自动推送
            }
        }
        //已修复的弱口令判断
        for (VulnProcessForm oldVul : vulList) {
            boolean isRepair = true;
            for (VulnProcessForm newVul : newVulList) {
                //弱口令名称 节点IP是否相同
                if (newVul.getId().equalsIgnoreCase(oldVul.getId())) {
                    isRepair = false;
                    break;
                }
            }
            //弱口令已修复
            if (isRepair) {
                repairedList.add(oldVul);
            } else {
                //未修复
                unrepairedList.add(oldVul);
            }
        }
        log.info(ip + " @@@@@@@@@@@@库存弱口令：" + vulList.size() + " 丢弃弱口令：" + dropTotal + " 新增弱口令：" + newTotal + " 未修复弱口令：" + unrepairedList.size() + " 修复弱口令：" + repairedList.size());
        if (!repairedList.isEmpty()) {
            repairedList.forEach((CommonAssemble::repairedVul));
        }
        if (!unrepairedList.isEmpty()) {
            unrepairedList.forEach((CommonAssemble::unRepairedVul));
        }
    }
}
