package com.crc.secface.schedule;

import com.baomidou.mybatisplus.core.conditions.query.LambdaQueryWrapper;
import com.baomidou.mybatisplus.core.toolkit.Wrappers;
import com.crc.common.utils.DateUtils;
import com.crc.common.utils.MyTheadUtils;
import com.crc.secface.config.GetSpringBean;
import com.crc.secface.domain.CodeAuditApplication;
import com.crc.secface.domain.CodeAuditProject;
import com.crc.secface.domain.CodeCheckRecord;
import com.crc.secface.domain.CodeCheckTask;
import com.crc.secface.mapper.CodeAuditApplicationMapper;
import com.crc.secface.mapper.CodeAuditProjectMapper;
import com.crc.secface.mapper.CodeCheckRecordMapper;
import com.crc.secface.mapper.CodeCheckTaskMapper;
import com.crc.secface.schedule.assemble.CommonAssemble;
import com.crc.secface.schedule.assemble.code.ZhuoMuNiaoAssemble;
import com.crc.sync.config.SyncSecConfigLoad;
import com.crc.sync.config.SyncSecConstants;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.context.annotation.Configuration;
import org.springframework.scheduling.annotation.EnableScheduling;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Component;

import java.util.Arrays;
import java.util.Date;
import java.util.List;

/**
 * 代码扫描器总线类
 */
@Slf4j
@Component
@Configuration      //1.主要用于标记配置类，兼备Component的效果。
@EnableScheduling   // 2.开启定时任务
public class CodeScannerSchedule implements CommandLineRunner {

    @Autowired
    CodeCheckTaskMapper codeCheckTaskMapper;
    @Autowired
    CodeCheckRecordMapper codeCheckRecordMapper;

    @Override
    public void run(String... args) {
        MyTheadUtils.sleepBySec(5);
        ShotTimeTask s = new ShotTimeTask();
        s.start();
    }

    /**
     * 每N分钟统计一次
     */
    @Scheduled(cron = "0 0/1 * * * ?")
    //@Async("threadPoolTaskExecutor")
    public void syncTask() {
        MyTheadUtils.sleepBySec(5);
        if (SyncSecConfigLoad.isEnable(SyncSecConstants.ZHUOMUNIAO_SYNC_ENABLE)) {
            /*
             * 状态统计
             */
            try {
                CommonAssemble.syncCodeStatus();
            } catch (Exception e) {
                log.error(e.getMessage(), e);
            }

            try {
                LambdaQueryWrapper<CodeCheckTask> qw = Wrappers.lambdaQuery();
                qw.eq(CodeCheckTask::getExecPeriod, "1");
                qw.eq(CodeCheckTask::getDelFlag, "0");
                /*
                等待 1
                解压中 2
                解压失败 3
                待检测4
                检测中5
                检测完成6
                检测异常7
                 */
                qw.in(CodeCheckTask::getStatus, Arrays.asList("1", "2", "4"));
                List<CodeCheckTask> list = codeCheckTaskMapper.selectList(qw);
                list.forEach((this::startTaskRecord));
            } catch (Exception e) {
                log.error(e.getMessage(), e);
            }
            CodeAuditApplicationMapper applicationMapper = GetSpringBean.getBean(CodeAuditApplicationMapper.class);
            CodeAuditProjectMapper projectMapper = GetSpringBean.getBean(CodeAuditProjectMapper.class);

            /*
             *代码检测 APP已被删除的更新
             */
            log.info("代码检测 APP已被删除的更新,应用项目的数量统计");
            try {
                LambdaQueryWrapper<CodeAuditProject> queryWrapper = new LambdaQueryWrapper<>();
                queryWrapper.eq(CodeAuditProject::getDelFlag, 0);
                List<CodeAuditProject> projectList = projectMapper.selectList(queryWrapper);
                for (CodeAuditProject proj : projectList) {
                    try {
                        CodeAuditApplication app = new CodeAuditApplication();
                        app.setProjectId(proj.getId());
                        applicationMapper.updateProjCheckCountX(app);
                    } catch (Exception e) {
                        log.error(e.getMessage(), e);
                    }
                    try {
                        LambdaQueryWrapper<CodeAuditApplication> qw = new LambdaQueryWrapper<>();
                        qw.eq(CodeAuditApplication::getDelFlag, 0);
                        qw.eq(CodeAuditApplication::getProjectId, proj.getId());
                        List<CodeAuditApplication> appList = applicationMapper.selectList(qw);
                        for (CodeAuditApplication app : appList) {
                            applicationMapper.updateAppCheckCountX(app.getId());
                        }
                    } catch (Exception e) {
                        log.error(e.getMessage(), e);
                    }
                }
            } catch (Exception e) {
                log.error(e.getMessage(), e);
            }
            log.info("代码检测 APP已被删除的更新,应用项目的数量统计--finish");
        }
    }

    /**
     * 添加任务
     */
    @Scheduled(cron = "10 */1 * * * ?")
    //@Async("threadPoolTaskExecutor")
    public void startTaskScan() {
        MyTheadUtils.sleepBySec(3);

        AddTask();

        getTask();
    }

    private void AddTask() {
        if (SyncSecConfigLoad.isEnable(SyncSecConstants.ZHUOMUNIAO_SYNC_ENABLE)) {
            log.info("AddTask定时同步啄木鸟扫描任务");
            try {
                ZhuoMuNiaoAssemble.addTask();
            } catch (Exception e) {
                log.error(e.getMessage(), e);
            }
            log.info("AddTask定时同步啄木鸟扫描任务结束");
        }
    }

    private void getTask() {
        if (SyncSecConfigLoad.isEnable(SyncSecConstants.ZHUOMUNIAO_SYNC_ENABLE)) {
            log.info("getTask定时同步啄木鸟扫描任务");
            try {
                ZhuoMuNiaoAssemble.getTask();
            } catch (Exception e) {
                log.error(e.getMessage(), e);
            }
            log.info("getTask定时同步啄木鸟扫描任务结束");
        }
    }


    public void startTaskRecord(CodeCheckTask task) {
        LambdaQueryWrapper<CodeCheckRecord> q = new LambdaQueryWrapper<>();
        q.eq(CodeCheckRecord::getTaskId, task.getId());
        q.eq(CodeCheckRecord::getResult, "0");
        long count = codeCheckRecordMapper.selectCount(q);
        if (count > 0) {
            log.info("{}{}存在执行中的任务", task.getTaskName(), task.getId());
            return;
        }
        log.info("启动任务{}{}", task.getTaskName(), task.getId());
        CodeCheckRecord record = new CodeCheckRecord();
        record.setTaskId(task.getId());
        record.setProgress(0);
        record.setResult("0");
        record.setCheckStartTime(new Date());
        codeCheckRecordMapper.insert(record);
    }


    /**
     * 指定时间的任务
     */
    class ShotTimeTask extends Thread {
        public void run() {
            log.info("ShotTimeTask 启动一次!");
            while (true) {
                if (SyncSecConfigLoad.isEnable(SyncSecConstants.ZHUOMUNIAO_SYNC_ENABLE)) {
                    syncTask2();
                }
                MyTheadUtils.sleepBySec(60);
            }
        }

        public void syncTask2() {
            try {
                LambdaQueryWrapper<CodeCheckTask> qw = Wrappers.lambdaQuery();
                qw.eq(CodeCheckTask::getExecPeriod, "2");
                /*
                等待 1
                解压中 2
                解压失败 3
                待检测4
                检测中5
                检测完成6
                检测异常7
                 */
                qw.in(CodeCheckTask::getStatus, Arrays.asList("1", "2", "4"));
                qw.le(CodeCheckTask::getExecTime, DateUtils.parseDateTime(DateUtils.getDateTimeString1(new Date())));
                List<CodeCheckTask> list = codeCheckTaskMapper.selectList(qw);
                for (CodeCheckTask task : list) {
                    startTaskRecord(task);
                }
            } catch (Exception e) {
                log.error(e.getMessage(), e);
            }
        }

    }
}
