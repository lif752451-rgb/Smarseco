package com.crc.secface.schedule.assemble.asset;

import lombok.extern.slf4j.Slf4j;

/**
 * <p>
 * 物联网资产回传
 * </p>
 *
 * @author yuyuhang5
 * @Date 2024/9/9 15:15
 * @Description IotAssetAssemble
 */

@Slf4j
public class IotAssetAssemble {


}
