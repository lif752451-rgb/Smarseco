//package com.crc.secface.schedule.assemble;
//
//import cn.hutool.core.collection.CollUtil;
//import com.alibaba.fastjson.JSONArray;
//import com.alibaba.fastjson.JSONObject;
//import com.crc.common.code.CreateInsert;
//import com.crc.common.constants.ScannerConstants;
//import com.crc.common.utils.*;
//import com.crc.secface.entity.*;
//import com.crc.secface.entity.config.MoFangConfig;
//import com.crc.secface.mapper.CommonMapper;
//import com.crc.secface.mapper.TbAssetMapper;
//import com.crc.secface.mapper.TbAssetVulMapper;
//import com.crc.secface.mapper.TbAssetVulTaskMapper;
//import com.crc.secface.queue.RiskAutoFlowSyncQueue;
//import com.crc.secface.schedule.assemble.WhiteListQuery;
//import com.crc.sync.config.SyncSecConfigLoad;
//import com.crc.sync.config.SyncSecConstants;
//import lombok.extern.slf4j.Slf4j;
//import org.apache.commons.lang3.StringUtils;
//import org.apache.http.HttpEntity;
//import org.apache.http.client.methods.CloseableHttpResponse;
//import org.apache.http.util.EntityUtils;
//import org.slf4j.Logger;
//import org.slf4j.LoggerFactory;
//
//import java.util.*;
//import java.util.function.Function;
//import java.util.stream.Collectors;
//
//import static com.crc.common.constants.Constants.STATUS;
//import static com.crc.common.constants.MoFangConstants.ApiUrl.TASK_LIST_API_URL;
//import static com.crc.common.constants.MoFangConstants.ApiUrl.VUL_LIST_API_URL;
//import static com.crc.common.constants.MoFangConstants.COUNT;
//import static com.crc.common.constants.MoFangConstants.INFO;
//
///**
// * 魔方漏洞下发任务同步
// *
// * @Author fuzhuangzhi
// * @Date 2022/9/7 10:06
// * @Version 1.0
// **/
//@Slf4j
//public class MoFangAssemble {
//    private static final String TB_MOFANG_TASK_LIST = "tb_mofang_task_list";
//
//    /**
//     * 添加扫描任务
//     */
//    public static void addTask(TbAssetVulTaskMapper vulTaskMapper, CommonMapper commonMapper) {
//        try {
//            // 获取魔方配置
//            MoFangConfig scannerInfo = MoFangUtils.getMoFangConfig();
//            if (scannerInfo == null || StringUtils.isEmpty(scannerInfo.getAddress())) {
//                log.error("addTask获取魔方配置信息错误！");
//                return;
//            }
//            TbAssetVulTask q = new TbAssetVulTask();
//            q.setStatus("0");
//            q.setType(ScannerConstants.MO_FANG_SCANNER);
//            // 获取魔方引擎所有任务
//            List<TbAssetVulTask> list = vulTaskMapper.getAssetVulTaskByDevice(q);
//            for (TbAssetVulTask task : list) {
//                try {
//                    // 扫描任务id
//                    String id = MoFangUtils.createVulTask(scannerInfo, task);
//                    String taskSuc = "1";
//                    String taskMsg = "执行成功";
//                    if (StringUtils.isNotBlank(id)) {
//                        //成功
//                        task.setD01TaskId(id);
//                        task.setStatus("1");
//                        vulTaskMapper.updateTbAssetVulTask(task);
//                        taskSuc = "0";
//                    } else {
//                        //失败
//                        task.setStatus("2");
//                        vulTaskMapper.updateTbAssetVulTask(task);
//                        taskMsg = "执行失败";
//                    }
//                    log.info("创建任务:" + task.getTaskName() + " -> " + taskMsg + " 返回ID：" + id);
//                    String uSQL = "update tb_asset_task_record set meno= '%s',status = '%s' where task_id = '%s'";
//                    commonMapper.exeSQL(String.format(uSQL, taskMsg, taskSuc, task.getTaskId()));
//                } catch (Exception e) {
//                    log.error(e.getMessage(), e);
//                }
//            }
//        } catch (Exception e) {
//            log.error(e.getMessage(), e);
//        }
//    }
//
//    /**
//     * 获取魔方下发的任务列表
//     *
//     * @param vulTaskMapper
//     * @param commonMapper
//     */
//    public static void getTask(TbAssetVulTaskMapper vulTaskMapper, CommonMapper commonMapper) {
//        // 获取魔方配置
//        MoFangConfig scannerInfo = MoFangUtils.getMoFangConfig();
//        if (scannerInfo == null || StringUtils.isEmpty(scannerInfo.getAddress())) {
//            log.error("addTask获取魔方配置信息错误！");
//            return;
//        }
//        List<MoFangTask> taskIdList = new LinkedList<>();
//        try {
//            //已完成的即时任务
//            String cSQL = "select count(1) from tb_mofang_task_list where id = '%s'";
//            String existTasks = "select count(1) from tb_asset_vul_task where d01_task_id = '%s'";
//            String uSQL = "update tb_mofang_task_list set task_proc = '%s' where id = '%s'";
//            String interval = scannerInfo.getInterval();
//            int total = 0;
//            JSONObject jsonObject = MoFangUtils.get(scannerInfo, TASK_LIST_API_URL + "?", "limit=1&attach=count&create_time=" + interval);
//            if (!JsonUtils.isEmpty(jsonObject)) {
//                total = JsonUtils.getInt(jsonObject, COUNT);
//            }
//            log.info("开始同步魔方任务清单数据，数据量：" + total);
//            if (total > 0) {
//                int pageSize = 100;
//                for (int idx = 1; idx < Math.ceil(total / pageSize) + 2; idx++) {
//                    try {
//                        JSONObject result = MoFangUtils.get(scannerInfo, TASK_LIST_API_URL + "?",
//                                "offset=" + (idx - 1) * pageSize + "&limit=" + pageSize + "&create_time=" + interval);
//                        if (JsonUtils.isEmpty(result)) {
//                            log.error("获取魔方下发列表数据失败，interval:{}", interval);
//                            continue;
//                        }
//                        if (result.containsKey(INFO) && JsonUtils.getBoolean(result, STATUS)) {
//                            JSONArray taskList = result.getJSONArray(INFO);
//                            if (taskList != null && taskList.size() > 0) {
//                                for (int i = 0; i < taskList.size(); i++) {
//                                    try {
//                                        JSONObject taskJson = taskList.getJSONObject(i);
//                                        MoFangTask task = new MoFangTask();
//                                        //扫描任务id
//                                        task.setId(JsonUtils.getStr(taskJson, "id"));
//                                        task.setTaskName(JsonUtils.getStr(taskJson, "name"));
//                                        task.setStartTime(JsonUtils.getStr(taskJson, "start_time"));
//                                        String endTime = JsonUtils.getStr(taskJson, "end_time");
//                                        // 任务状态 0：未开始 1：端口服务探测 3：os识别 5：插件扫描 6：完成
//                                        int status = JsonUtils.getInt(taskJson, "status");
//                                        task.setEndTime(endTime);
//                                        task.setTaskProc(StringUtils.isBlank(endTime) || 6 != status ? "0" : "100");
//                                        taskIdList.add(task);
//                                        /*
//                                        必须是用户添加的任务
//                                         */
//                                        if (commonMapper.getCount(String.format(existTasks, task.getId())) < 1) {
//                                            continue;
//                                        }
//                                        // 新增任务
//                                        if (commonMapper.getCount(String.format(cSQL, task.getId())) > 0) {
//                                            commonMapper.exeSQL(String.format(uSQL, task.getTaskProc(), task.getId()));
//                                        } else {
//                                            task.setStatus("0");
//                                            task.setFlag("0");
//                                            CreateInsert<MoFangTask> createInsert = new CreateInsert<>();
//                                            String sql = createInsert.createinsert(task, "tb_mofang_task_list");
//                                            commonMapper.exeSQL(sql);
//                                        }
//                                    } catch (Exception e) {
//                                        log.error(e.getMessage(), e);
//                                    }
//                                }
//                            }
//                        }
//                    } catch (Exception e) {
//                        log.error(e.getMessage(), e);
//                    }
//                }
//            }
//        } catch (Exception e) {
//            log.error(e.getMessage(), e);
//        }
//
//        for (MoFangTask lvTask : taskIdList) {
//            TbAssetVulTask vulTask = vulTaskMapper.selectTbAssetVulTaskByD01Id(lvTask.getId());
//            if (vulTask != null) {
//                vulTask.setProgress(DataUtils.toLong(lvTask.getTaskProc()));
//                String status = "1";
//                if ("100".equalsIgnoreCase(lvTask.getTaskProc())) {
//                    status = "2";
//                }
//                vulTask.setStatus(status);
//                vulTaskMapper.updateTbAssetVulTask(vulTask);
//            }
//        }
//
//        log.info("getTask定时同步魔方任务结束");
//        String uSql1 = "update tb_mofang_task_list set status = 1,target_total=%s where id = '%s'";
//        String uSql2 = "update tb_mofang_task_list set status = 2,target_total=%s where id = '%s'";
//        log.info("同步魔方漏洞任务数据开始");
//        try {
//            List<HashMap<String, Object>> list = commonMapper.queryX("select * from tb_mofang_task_list where status = 0 and task_proc = 100");
//            for (HashMap<String, Object> map : list) {
//                String taskId = DataUtils.getString(map, "id");
//                String endTime = DataUtils.getStrX(map.get("end_time"));
//                try {
//                    // 通过taskid获取漏洞总数
//                    int total = getVulListTotal(scannerInfo, taskId);
//                    if (total > 0) {
//                        int pageSize = 100;
//                        for (int idx = 0; idx < Math.ceil(total / pageSize) + 1; idx++) {
//                            try {
//                                try {
//                                    JSONObject dataJson = MoFangUtils.get(scannerInfo, VUL_LIST_API_URL + "?", "taskids=" + taskId + "&offset=" + (idx - 1) * pageSize + "&limit=" + pageSize + "&attach=count");
//                                    if (dataJson != null && !dataJson.isEmpty() && JsonUtils.getBoolean(dataJson, STATUS)) {
//                                        if (dataJson != null && dataJson.containsKey(INFO)) {
//                                            int vulCount = JsonUtils.getInt(dataJson, COUNT);
//                                            if (vulCount < 1) {
//                                                break;
//                                            }
//                                            // 漏洞信息
//                                            JSONArray vulList = dataJson.getJSONArray(INFO);
//                                            if (CollUtil.isEmpty(vulList)) {
//                                                break;
//                                            }
//                                            Map<String, List<Object>> ipMap = vulList.stream().collect(Collectors.groupingBy(t -> ((JSONObject) t).getString("target")));
//
//                                            ipMap.forEach((ip, vulnList) -> {
//                                                try {
//                                                    for (int i = 0; i < vulnList.size(); i++) {
//                                                        JSONObject vulJson = (JSONObject) vulnList.get(i);
//                                                        try {
//                                                            // 漏洞id
//                                                            String id = JsonUtils.getStr(vulJson, "id");
//                                                            MoFangVul vul = new MoFangVul();
//                                                            vul.setVulId(id);
//                                                            vul.setIp(ip);
//                                                            vul.setTaskId(taskId);
//                                                            vul.setVulJson(JSONObject.toJSONString(vulJson));
//                                                            if (commonMapper.getCount(String.format("select count(1) from tb_mofang_vul_list where ip = '%s' and task_id = '%s' and vul_id = '%s'", ip, taskId, id)) < 1) {
//                                                                CreateInsert<MoFangVul> createInsert = new CreateInsert<>();
//                                                                String sql = createInsert.createinsert(vul, "tb_mofang_vul_list");
//                                                                commonMapper.exeSQL(sql);
//                                                            }
//                                                        } catch (Exception e) {
//                                                            log.error(e.getMessage(), e);
//                                                        }
//                                                    }
//                                                    MoFangTaskIp taskIp = new MoFangTaskIp();
//                                                    taskIp.setTaskIp(ip);
//                                                    taskIp.setTaskId(taskId);
//                                                    taskIp.setEndTime(endTime);
//                                                    // 同一个ip对应的漏洞数量
//                                                    taskIp.setVulCount(vulnList.size());
//                                                    if (commonMapper.getCount(String.format("select count(1) from tb_mofang_task_ip_list where task_ip = '%s' and task_id = '%s'", ip, taskId)) < 1) {
//                                                        CreateInsert<MoFangTaskIp> createInsert = new CreateInsert<>();
//                                                        String sql = createInsert.createinsert(taskIp, "tb_mofang_task_ip_list");
//                                                        commonMapper.exeSQL(sql);
//                                                    }
//                                                } catch (Exception e) {
//                                                    log.error(e.getMessage(), e);
//                                                }
//                                            });
//                                        }
//                                    }
//
//                                    int iflag = total > 0 ? 1 : 0;
//                                    String uSQL = "update tb_mofang_task_list set flag = '%d' where id = '%s'";
//                                    commonMapper.exeSQL(String.format(uSQL, iflag, taskId));
//                                } catch (Exception e) {
//                                    log.error(e.getMessage(), e);
//                                }
//                            } catch (Exception e) {
//                                log.error(e.getMessage(), e);
//                            }
//                        }
//                        commonMapper.exeSQL(String.format(uSql1, total, taskId));
//                    } else {
//                        commonMapper.exeSQL(String.format(uSql2, total, taskId));
//                    }
//
//                } catch (Exception e) {
//                    log.error(e.getMessage(), e);
//                }
//            }
//        } catch (Exception e) {
//            log.error(e.getMessage(), e);
//        }
//        log.info("同步魔方漏洞任务结束");
//    }
//
//    /**
//     * 通过taskid获取漏洞总数
//     *
//     * @param scannerInfo
//     * @param taskId
//     * @return
//     */
//    private static int getVulListTotal(MoFangConfig scannerInfo, String taskId) {
//        JSONObject result = MoFangUtils.get(scannerInfo, VUL_LIST_API_URL + "?", "taskids=" + taskId + "&limit=1&attach=count");
//        if (result != null && !result.isEmpty()) {
//            return JsonUtils.getInt(result, COUNT);
//        }
//        return 0;
//    }
//
//    /**
//     * 解析魔方漏洞数据
//     *
//     * @param assetMapper
//     * @param tbAssetVulMapper
//     * @param commonMapper
//     */
//    public static void parseTask(TbAssetMapper assetMapper, TbAssetVulMapper tbAssetVulMapper, CommonMapper commonMapper) {
//        try {
//            String sql = "select * from tb_mofang_task_list t where t.task_proc = 100 and t.status in (1,2) order by id asc";
//            String usql = "update tb_mofang_task_list set status = 3 where id = %s";
//            String vSQL = "select task_id,ip,vul_json,vul_id from tb_mofang_vul_list where task_id = '%s' and ip = '%s'";
//            String ipSQL = "select * from tb_mofang_task_ip_list where task_id = '%s'";
//            List<HashMap<String, Object>> list = commonMapper.queryX(sql);
//            if (list != null && list.size() > 0) {
//                log.info("解析魔方任务数：" + list.size());
//                for (HashMap<String, Object> map : list) {
//                    try {
//                        // 扫描任务id
//                        String taskId = DataUtils.getStrX(map.get("id"));
//                        // 任务结束时间
//                        String endtime = DataUtils.getStrX(map.get("end_time"));
//                        List<HashMap<String, Object>> ipList = commonMapper.queryX(String.format(ipSQL, taskId));
//                        if (ipList != null) {
//                            for (HashMap<String, Object> ipMap : ipList) {
//                                try {
//                                    String taskIp = DataUtils.getStrX(ipMap.get("task_ip"));
//                                    log.info(String.format("魔方分析任务id=%s，IP=%s", taskId, taskIp));
//                                    List<TbAssetVul> repairedList = new LinkedList<>();
//                                    List<TbAssetVul> unrepairedList = new LinkedList<>();
//                                    List<TbAssetVul> newVulList = new LinkedList<>();
//                                    List<HashMap<String, Object>> curList = commonMapper.queryX(String.format(vSQL, taskId, taskIp));
//                                    if (curList != null) {
//                                        for (HashMap<String, Object> vulMap : curList) {
//                                            try {
//                                                TbAssetVul curVul = getVul(vulMap, endtime);
//                                                if (curVul != null) {
//                                                    /**
//                                                     * 匹配白名单
//                                                     */
//                                                    if (WhiteListQuery.isWhiteList(curVul.getIp(), curVul.getName())) {
//                                                        continue;
//                                                    }
//                                                    newVulList.add(curVul);
//                                                    //是否新漏洞
//                                                    boolean isnew = true;
//                                                    TbAssetVul tmp = tbAssetVulMapper.selectTbAssetVulFlowById(curVul.getId());
//                                                    if (tmp != null) {
//                                                        isnew = false;
//                                                    }
//
//                                                    if (isnew) {
//                                                        //新漏洞
//                                                        CommonAssemble.saveVul(tbAssetVulMapper, assetMapper, curVul);
//                                                        //后台自动推送
//                                                    } else {
//
//                                                        String ud1 = curVul.getUd1();
//                                                        if (StringUtils.isNotEmpty(ud1)) {
//                                                            String[] statuses = ud1.split("#");
//                                                            // 漏洞变化状态 0遗留 1新增 3减少
//                                                            String changeStatus = statuses[0];
//                                                            // 漏洞处置状态 0：未处理 1：已确认 2：已修复 3：误报 4：待修复 5：修复失败 6：已验证 7：忽略
//                                                            String status = statuses[1];
//                                                            // 未修复
//                                                            if (!"2".equals(status)) {
//                                                                unrepairedList.add(curVul);
//                                                            } else {
//                                                                // 已修复
//                                                                TbAssetVul vul = tbAssetVulMapper.selectTbAssetVulFlowById(curVul.getId());
//                                                                if ("1".equals(vul.getStatus())) {
//                                                                    vul.setSend("1");
//                                                                    vul.setRepairTime(null);
//                                                                    tbAssetVulMapper.updateTbAssetVul(vul);
//                                                                } else {
//                                                                    vul.setSend("1");
//                                                                    vul.setStatus("1");
//                                                                    vul.setRepairTime(new Date());
//                                                                    tbAssetVulMapper.updateTbAssetVul(vul);
//                                                                }
//                                                                repairedList.add(vul);
//                                                            }
//                                                        }
//                                                    }
//                                                }
//                                            } catch (Exception e) {
//                                                log.error(e.getMessage(), e);
//                                            }
//                                        }
//                                    }
//                                    boolean flag = false;
//                                    //工单状态（1.待确认，2.待处置，3.待审核，4.已归档，5.误报，6.待确认(复查中)，7.待处置(复查中)，8.待审核(复查中)）
//                                    String xsql = "select p.id,v.code,p.work_order_state from tb_process_vuln_handle_business p inner join tb_vuln_data v on v.code = p.vuln_code where v.id = '%s'";
//                                    String uxsql = "update tb_process_vuln_handle_business set work_order_state = '%s' where id = %s";
//                                    if (repairedList.size() > 0) {
//                                        for (TbAssetVul vul : repairedList) {
//                                            List<HashMap<String, Object>> ol = commonMapper.queryX(String.format(xsql, vul.getId()));
//                                            if (ol != null && ol.size() > 0) {
//                                                int status = DataUtils.getInt(ol.get(0), "work_order_state");
//                                                String pid = DataUtils.getStr(ol.get(0), "id");
//                                                String newStatus = "6";
//                                                if (status > 0 && status < 4) {
//                                                    if (status > 2) {
//                                                        newStatus = "8";
//                                                    } else if (status > 1) {
//                                                        newStatus = "7";
//                                                    }
//                                                    commonMapper.exeSQL(String.format(uxsql, newStatus, pid));
//                                                }
//                                            }
//
//                                            try {
//                                                RiskStatus o = new RiskStatus();
//                                                o.setId(vul.getId());
//                                                o.setVulName(vul.getName());
//                                                o.setRepair(true);
//                                                o.setIp(vul.getIp());
//                                                o.setStatus("0");
//                                                RiskAutoFlowSyncQueue.addQueue("魔方 423 ", o);
//                                            } catch (Exception e) {
//                                                log.error(e.getMessage(), e);
//                                            }
//                                        }
//                                    }
//                                    Date curDate = new Date();
//                                    TbAssetVul updateMode = new TbAssetVul();
//                                    updateMode.setCreateTime(curDate);
//                                    if (unrepairedList.size() > 0) {
//                                        for (TbAssetVul vul : unrepairedList) {
//                                            List<HashMap<String, Object>> ol = commonMapper.queryX(String.format(xsql, vul.getId()));
//                                            if (ol != null && ol.size() > 0) {
//                                                int status = DataUtils.getInt(ol.get(0), "work_order_state");
//                                                String pid = DataUtils.getStr(ol.get(0), "id");
//                                                String newStatus = "6";
//                                                if (status > 0 && status < 4) {
//                                                    if (status > 2) {
//                                                        newStatus = "8";
//                                                    } else if (status > 1) {
//                                                        newStatus = "7";
//                                                    }
//                                                    commonMapper.exeSQL(String.format(uxsql, newStatus, pid));
//                                                }
//                                            }
//                                            try {
//                                                RiskStatus o = new RiskStatus();
//                                                o.setId(vul.getId());
//                                                o.setVulName(vul.getName());
//                                                o.setRepair(false);
//                                                o.setIp(vul.getIp());
//                                                o.setStatus("0");
//                                                RiskAutoFlowSyncQueue.addQueue("魔方 455 ", o);
//                                            } catch (Exception e) {
//                                                log.error(e.getMessage(), e);
//                                            }
//
//                                            if (!flag) {
//                                                updateMode.setId(vul.getId());
//                                                tbAssetVulMapper.updateFlowVulLastTimeById(updateMode);
//                                            }
//                                        }
//                                    }
//                                } catch (Exception e) {
//                                    log.error(e.getMessage(), e);
//                                }
//                            }
//                        }
//                        commonMapper.exeSQL(String.format(usql, taskId));
//                    } catch (Exception e) {
//                        log.error(e.getMessage(), e);
//                    }
//                }
//            }
//        } catch (Exception e) {
//            log.error(e.getMessage(), e);
//        }
//    }
//
//    private static TbAssetVul getVul(HashMap<String, Object> vulMap, String endtime) {
//        //ip
//        String ip = DataUtils.getStrX(vulMap.get("ip"));
//        // 漏洞json
//        String vulJson = DataUtils.getStrX(vulMap.get("vul_json"));
//        // 漏洞id
//        String vulId = DataUtils.getStrX(vulMap.get("vul_id"));
//        JSONObject json = JsonUtils.parse(vulJson);
//
//        /*
//        {
//            "id": 14,
//            "vul_title": "OpenSSH 安全漏洞",
//            "risklevel": "1",
//            "vul_type": "其他",
//            "target": "10.54.238.153",
//            "port": 22,
//            "change_state": 1,
//            "status": 0,
//            "exp": null,
//            "cve": "CVE-2016-20012",
//            "cnnvd": "CNNVD-202109-1073",
//            "bugtraq": null,
//            "cpe": "cpe:/a:openbsd:openssh:7.4",
//            "vul_description": "OpenSSH（OpenBSD Secure Shell）是Openbsd计划组的一套用于安全访问远程计算机的连接工具。该工具是SSH协议的开源实现，支持对所有的传输进行加密，可有效阻止窃听、连接劫持以及其他网络级的攻击。 \nOpenSSH 8.7之前版本存在安全漏洞，允许远程攻击者怀疑 SSH 服务器知道用户名和公钥的特定组合，以测试这种怀疑是否正确。 发生这种情况是因为仅当该组合对登录会话有效时才会发送质询。",
//            "vulinfo": "cpe:/a:openbsd:openssh:7.4",
//            "vul_solution": "目前厂商已发布升级补丁以修复漏洞，补丁获取链接： \nhttps://github.com/openssh/openssh-portable/pull/270",
//            "url": "https://github.com/openssh/openssh-portable/blob/d0fffc88c8fe90c1815c6f4097bc8cbcabc0f3dd/auth2-pubkey.c#L261-L265,https://github.com/openssh/openssh-portable/pull/270,https://security.netapp.com/advisory/ntap-20211014-0005/,https://rushter.com/blog/public-ssh-keys/,https://utcc.utoronto.ca/~cks/space/blog/tech/SSHKeysAreInfoLeak,https://vigilance.fr/vulnerability/OpenSSH-information-disclosure-via-Public-Key-Username-Combination-36441,https://nvd.nist.gov/vuln/detail/CVE-2016-20012",
//            "remarks": null,
//            "assets_group": {
//                "net": [],
//                "app": []
//            },
//            "createtime": "2022-09-07 17:55:40",
//            "uptime": "2022-09-07 17:55:40",
//            "handler_id": null,
//            "handler": null,
//            "taskids": [
//                5
//            ],
//            "plugin_id": "170251"
//            }
//         */
//        // 漏洞名称
//        String vulName = JsonUtils.getStr(json, "vul_title");
//        if (StringUtils.isBlank(vulName)) {
//            return null;
//        }
//
//        // 漏洞等级 0：低危 1:中危 2：高危 3：严重
//        double risklevel = JsonUtils.getDouble(json, "risklevel");
//        // 漏洞描述
//        String desc = JsonUtils.getStr(json, "vul_description");
//        // 解决方案
//        String solution = JsonUtils.getStr(json, "vul_solution");
//        // 首次发现时间
//        String firstTime = JsonUtils.getStr(json, "createtime");
//        // 最后发现时间
//        String recentlyTime = JsonUtils.getStr(json, "uptime");
//        // 漏洞类型
//        String vulType = JsonUtils.getStr(json, "vul_type");
//        // 参考链接
//        String url = JsonUtils.getStr(json, "url");
//        // 漏洞变化状态 0遗留 1新增 3减少
//        int changeState = JsonUtils.getInt(json, "change_state");
//        // 漏洞处置状态 0：未处理 1：已确认 2：已修复 3：误报 4：待修复 5：修复失败 6：已验证 7：忽略
//        int status = JsonUtils.getInt(json, "status");
//
//        //0:低危, 1:中危, 2:高危, 3:严重
//        String filter = SyncSecConfigLoad.getRemarkValue(SyncSecConstants.MO_FANG_SYNC_ENABLE);
//        try {
//            boolean flag = false;
//            if (filter != null && filter.contains("=") && filter.contains("level")) {
//                String filterLevel = filter.split("=")[1];
//                String slevel = risklevel + "";
//                for (String fl : filterLevel.split(",")) {
//                    if (StringUtils.isNotBlank(slevel) && slevel.equalsIgnoreCase(fl)) {
//                        flag = true;
//                        break;
//                    }
//                }
//            } else {
//                flag = true;
//            }
//            if (!flag) {
//                return null;
//            }
//        } catch (Exception e) {
//            log.error(e.getMessage(), e);
//        }
//        String hasExp = "0";
//        String hasPoc = "0";
//        String remote = "0";
//        String CVE = JsonUtils.getStr(json, "cve");
//
//        TbAssetVul vul = new TbAssetVul();
//        vul.setIp(ip);
//        vul.setName(vulName);
//        vul.setLevel(risklevel + "");
//        vul.setDataSource(ScannerConstants.MO_FANG_SCANNER);
//        String id = Md5Utils.hash(ip + "#" + vulId + "#" + CVE + "#" + vul.getDataSource());
//        vul.setId(id);
//        vul.setType(vulType);
//        vul.setDescription(desc);
//        vul.setSolution(solution);
//        vul.setCveId(CVE);
//        vul.setUrl(url);
//        vul.setCreateTime(new Date());
//        vul.setUpdateTime(new Date());
//        vul.setFirstTime(DateUtils.parseDateTime(firstTime, DateUtils.DATE_FORMAT_STRING1));
//        vul.setRecentlyTime(DateUtils.parseDateTime(recentlyTime, DateUtils.DATE_FORMAT_STRING1));
//        vul.setExistExp(hasExp);
//        vul.setExistPoc(hasPoc);
//        vul.setExistRemote(remote);
//        // 漏洞原始id
//        vul.setUd4(vulId);
//        // 冗余字段，判断漏洞是否已修复
//        vul.setUd1(String.valueOf(changeState) + "#" + String.valueOf(status));
//        return vul;
//    }
//}
