package com.crc.secface.schedule;

import com.baomidou.mybatisplus.core.conditions.query.LambdaQueryWrapper;
import com.crc.common.enums.AssetSourceEnums;
import com.crc.common.enums.DelFlagEnum;
import com.crc.secface.config.GetSpringBean;
import com.crc.secface.domain.Asset;
import com.crc.secface.domain.SysDictData;
import com.crc.secface.mapper.AssetMapper;
import com.crc.secface.schedule.assemble.asset.AnhengAssetAssemble;
import com.crc.secface.schedule.assemble.asset.NgsocAssetAssemble;
import com.crc.sync.config.SyncSecConstants;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.collections4.CollectionUtils;
import org.springframework.scheduling.annotation.EnableScheduling;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Component;

import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

import static com.crc.common.utils.DictUtil.getDict;

/**
 * <p>
 * 外部来源资产回传任务
 * </p>
 *
 * @author yuyuhang5
 * @Date 2024/9/9 15:15
 * @Description AssetSyncSchedule
 */
@Slf4j
@Component
@EnableScheduling
public class AssetSyncSchedule {

    @Scheduled(cron = "10 */5 * * * ?")
    public void getAllAsset() {
        log.info("AssetSyncSchedule-getAllAsset-start");
        // 获取需要同步资产数据的来源
        List<SysDictData> dataList = getDict(SyncSecConstants.SYNC_ASSET_SYNC_API_SOURCE);
        if (CollectionUtils.isNotEmpty(dataList)) {
            log.info("AssetSyncSchedule-dataList-size:" + dataList.size());
            List<String> sourceList = dataList.stream().map(SysDictData::getDictValue).collect(Collectors.toList());
            if (CollectionUtils.isNotEmpty(sourceList)) {
                log.info("AssetSyncSchedule-sourceList-size:" + sourceList.size());
                LambdaQueryWrapper<Asset> query = new LambdaQueryWrapper<>();
                query.in(Asset::getRealSource, sourceList);
                query.eq(Asset::getUpdateFlag, "2");
                query.eq(Asset::getDelFlag, String.valueOf(DelFlagEnum.AVAILABLE.getValue()));
                AssetMapper assetMapper = GetSpringBean.getBean(AssetMapper.class);
                List<Asset> assetList = assetMapper.selectList(query);
                log.info("AssetSyncSchedule-assetList-size:" + assetList.size());
                // 根据不同的数据来源获取对应的配置信息
                Map<String, List<Asset>> assetGroupMap = assetList.stream().collect(Collectors.groupingBy(Asset::getRealSource));
                log.info("AssetSyncSchedule-assetGroupMap-size:" + assetGroupMap.size());
                // 安恒工控 ip1
                if (assetGroupMap.get(SyncSecConstants.AN_HENG_SOURCE_IP_1) != null) {
                    AnhengAssetAssemble.updateAsset(SyncSecConstants.AN_HENG_SOURCE_IP_1, assetGroupMap.get(AssetSourceEnums.ANHENG_CMDB.getCode()));
                }
                // 安恒工控 ip2
                if (assetGroupMap.get(SyncSecConstants.AN_HENG_SOURCE_IP_2) != null) {
                    AnhengAssetAssemble.updateAsset(SyncSecConstants.AN_HENG_SOURCE_IP_2, assetGroupMap.get(AssetSourceEnums.ANHENG_CMDB.getCode()));
                }
                // 安恒工控 ip3
                if (assetGroupMap.get(SyncSecConstants.AN_HENG_SOURCE_IP_3) != null) {
                    AnhengAssetAssemble.updateAsset(SyncSecConstants.AN_HENG_SOURCE_IP_3, assetGroupMap.get(AssetSourceEnums.ANHENG_CMDB.getCode()));
                }
                // 物联网中台
                /*if (assetGroupMap.get(AssetSourceEnums.IOT_CMDB.getCode()) != null) {
                    IotAssetAssemble.updateAsset(assetGroupMap.get(AssetSourceEnums.IOT_CMDB.getCode()));
                }*/
                // 奇安信NGSOC
                if (assetGroupMap.get(AssetSourceEnums.NGSOC_CMDB.getCode()) != null) {
                    NgsocAssetAssemble.updateAsset(assetGroupMap.get(AssetSourceEnums.NGSOC_CMDB.getCode()));
                }
            }
        }
        log.info("AssetSyncSchedule-getAllAsset-end");
    }
}
