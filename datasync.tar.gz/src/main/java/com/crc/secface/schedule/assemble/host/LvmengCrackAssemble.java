package com.crc.secface.schedule.assemble.host;

import com.alibaba.fastjson.JSONArray;
import com.alibaba.fastjson.JSONObject;
import com.baomidou.mybatisplus.core.conditions.query.LambdaQueryWrapper;
import com.crc.common.code.SimpleCodeTool;
import com.crc.common.enums.AssetSourceEnums;
import com.crc.common.enums.ScanStatusEnums;
import com.crc.common.enums.ScanTypeEnums;
import com.crc.common.enums.ScannerEnums;
import com.crc.common.utils.*;
import com.crc.scanner.config.LvmengConfig;
import com.crc.scanner.tool.CvssUtils;
import com.crc.scanner.tool.LvmengUtils;
import com.crc.secface.config.GetSpringBean;
import com.crc.secface.domain.*;
import com.crc.secface.mapper.*;
import com.crc.secface.queue.CrcAssetSyncQueue;
import com.crc.secface.schedule.assemble.CommonAssemble;
import com.crc.secface.schedule.assemble.WhiteListQuery;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.apache.http.client.methods.CloseableHttpResponse;

import java.util.*;


@Slf4j
public class LvmengCrackAssemble {

    public static void addTask() {
        try {
            VulnScanTaskRecordMapper taskRecordMapper = GetSpringBean.getBean(VulnScanTaskRecordMapper.class);
            VulnScanTaskRecordLogMapper taskRecordLogMapper = GetSpringBean.getBean(VulnScanTaskRecordLogMapper.class);
            List<VulnScanTask> list = CommonAssemble.getCheckingScantask(ScannerEnums.LVMENG_SCANNER.getCode(), ScanTypeEnums.WEAK_PASS_SCAN.getCode(), Arrays.asList(1, 2));
            log.info("需下发的绿盟弱口令扫描中任务数：" + list.size());
            for (VulnScanTask task : list) {
                try {
                    VulnScanTaskRecord record = taskRecordMapper.getLastRecordByTaskId(task.getId());
                    if (record == null) {
                        continue;
                    }
                    LambdaQueryWrapper<VulnScanTaskRecordLog> qlog = new LambdaQueryWrapper<>();
                    qlog.eq(VulnScanTaskRecordLog::getRecordId, record.getId());
                    qlog.eq(VulnScanTaskRecordLog::getTaskId, task.getId());
                    String scanContent = task.getScanContentX();
                    if (taskRecordLogMapper.selectCount(qlog) > 0) {
                        log.info("{}{},已在执行中", task.getTaskName(), scanContent);
                        continue;
                    }
                    List<String> uuids = new ArrayList<>();
                    if (!StringUtils.isBlank(scanContent)) {
                        //多个地址用英文逗号(,)分隔
                        for (String ipStr : scanContent.split("\n")) {
                            String ip = ipStr.trim();
                            if (StringUtils.isBlank(ip)) {
                                continue;
                            }
                            uuids.add(ip);
                        }
                    }

                    VulnScanTaskRecordLog recordLog = new VulnScanTaskRecordLog();
                    recordLog.setIp(scanContent);
                    recordLog.setTaskId(record.getTaskId());
                    recordLog.setTaskName(task.getTaskName());
                    recordLog.setRecordId(record.getId());
                    recordLog.setEngineId(task.getEngineId());
                    recordLog.setCreateTime(new Date());
                    recordLog.setType(ScannerEnums.LVMENG_SCANNER.getCode());
                    //任务状态(0 未开始 1 执行中 2 执行完成 3 执行失败)
                    recordLog.setScanStatus(0);


                    LvmengConfig scannerInfo = getLvConfig(task.getEngineId());
                    String id = "";
                    if (uuids.size() < 1) {
                        log.error("创建任务:" + task.getTaskName() + " -> 失败，没有找到真实IP");
                        CommonAssemble.startFail(task, "任务无法解析出有效IP");
                        continue;
                    }else if (uuids.size() > 5) {
                        log.error("创建任务:" + task.getTaskName() + " -> 失败，最多5个IP或者IP段");
                        CommonAssemble.startFail(task, "创建任务失败，最多5个IP或者IP段");
                        continue;
                    }else {
                        //id = LvmengUtils.createPwsTask(scannerInfo, task.getTaskName(), String.join(";", uuids));
                        id = LvmengUtils.addFileTask(scannerInfo, task.getTaskName(), String.join(";", uuids));
                    }
                    String taskMsg = "执行成功";


                    if (StringUtils.isNotBlank(id)) {
                        recordLog.setScanStatus(1);
                        recordLog.setJobId(id);
                        recordLog.setResult(taskMsg);
                        taskRecordLogMapper.insert(recordLog);
                    } else {
                        //失败
                        recordLog.setScanStatus(3);
                        taskMsg = "执行失败";
                        recordLog.setResult(taskMsg);
                        taskRecordLogMapper.insert(recordLog);
                        CommonAssemble.startFail(recordLog, taskMsg);
                    }

                    log.info("创建任务:" + task.getTaskName() + " -> " + taskMsg + " 返回ID：" + id);
                    record.setScanResult(taskMsg);
                    record.setScanStatus(1);
                    taskRecordMapper.updateVulnScanTaskRecord(record);
                } catch (Exception e) {
                    log.error(e.getMessage(), e);
                }
            }
        } catch (Exception e) {
            log.error(e.getMessage(), e);
        }
    }

    public static LvmengConfig getLvConfig(Long engineId) {
        EngineEquipmentManagement engine = CommonAssemble.engineMap.get(engineId);
        LvmengConfig qtConfig = new LvmengConfig();
        if (engine == null) {
            return qtConfig;
        }
        qtConfig.setEngineId(engineId);
        qtConfig.setAddress(engine.getEquipmentAddress());
        String PASS = engine.getPassword().trim();
        qtConfig.setPassword(PASS);
        try {
            PASS = SimpleCodeTool.decrypt(PASS);
            qtConfig.setPassword(PASS);
        } catch (Exception e) {
            log.error(e.getMessage(), e);
        }
        qtConfig.setUsername(engine.getLoginUser());
        return qtConfig;
    }


    public static void getTask() {
        VulnScanTaskRecordLogMapper taskRecordLogMapper = GetSpringBean.getBean(VulnScanTaskRecordLogMapper.class);
        VulnScanTaskRecordMapper taskRecordMapper = GetSpringBean.getBean(VulnScanTaskRecordMapper.class);
        VulnScanTaskMapper scanTaskMapper = GetSpringBean.getBean(VulnScanTaskMapper.class);
        try {
            VulnScanTaskRecordLog q = new VulnScanTaskRecordLog();
            q.setScanStatus(1);//扫描中
            q.setScanType(ScanTypeEnums.WEAK_PASS_SCAN.getCode());
            q.setEngineName(ScannerEnums.LVMENG_SCANNER.getCode());
            List<VulnScanTaskRecordLog> recordList = taskRecordLogMapper.getAllRecordLogList(q);
            log.info("绿盟弱口令扫描中任务数：" + recordList.size());
            for (VulnScanTaskRecordLog task : recordList) {
                try {
                    LvmengConfig scannerInfo = getLvConfig(task.getEngineId());
                    // 扫描任务id
                    ///async/status/?&taskid=xxx&user=xxx&pwd=xxx
                    JSONObject retJson = LvmengUtils.getTaskStatus(scannerInfo, task.getJobId());
                    /*
                    0:等待扫描
                    2:正在扫描
                    5:扫描暂停
                    4:扫描完成
                    8:异常停止
                     */

                    if (retJson != null) {
                        if (retJson.containsKey("status")) {
                            //1-运行中，2-完成，3-停止
                            int istatus = JsonUtils.getInt(retJson, "status");
                            String progress = JsonUtils.getStr(retJson, "process").replace("%", "");
                            boolean stop = false;
                            if (istatus == 0 || istatus == 2 || istatus == 5) {
                                //进行中
                            } else if (istatus == 4) {
                                progress = "100";
                            } else {
                                stop = true;
                            }

                            task.setProgress(DataUtils.toInt(progress));
                            int status = 1;
                            if (task.getProgress() == 100 && istatus == 4) {
                                status = 2;
                            }


                            if (stop) {
                                log.error("任务异常停止:" + task.getTaskName() + " -> " + " 进度：" + progress + ",status=" + istatus);
                                status = 2;
                            } else {
                                log.info("读取任务:" + task.getTaskName() + " -> " + " 进度：" + progress + ",status=" + istatus);
                            }
                            task.setScanStatus(status);
                            taskRecordLogMapper.updateById(task);
                            if (task.getProgress() == 100 && !stop && istatus == 4) {
                                CloseableHttpResponse response = null;
                                try {
                                    int total = LvmengUtils.getTaskInfoTotal(scannerInfo, task.getJobId());
                                    if (total > 0) {
                                        HashMap<String, List<VulnProcessForm>> dataMap = new HashMap<>();
                                        int pageSize = 5;
                                        for (int idx = 0; idx < DataUtils.getPageCount(total,pageSize,0); idx++) {
                                            ///api/report/task/{task_id}
                                            response = LvmengUtils.get(scannerInfo, "/api/report/task/" + task.getJobId() + "?page=" + (idx + 1) + "&page_size=" + pageSize, "");
                                            int code = response.getStatusLine().getStatusCode();
                                            if (code == 200) {
                                                JSONObject json = JsonUtils.parse(DataUtils.toBodyString(response.getEntity()));
                                                int vulTotal = 0;
                                                if (json.containsKey("ret_msg") && JsonUtils.equal(json, "ret_msg", "success")) {
                                                    JSONObject data = JsonUtils.getJson(json, "data");
                                                    if (data != null && data.containsKey("report")) {
                                                        int curTaskTotal = JsonUtils.getInt(data, "target_total");
                                                        if (curTaskTotal < 1) {
                                                            break;
                                                        }
                                                        JSONArray vulList = data.getJSONObject("report").getJSONArray("targets");
                                                        String findTime = JsonUtils.getStr(data.getJSONObject("report").getJSONObject("task"), "time_end_scan");
                                                        if (vulList != null && vulList.size() > 0) {
                                                            for (int i = 0; i < vulList.size(); i++) {
                                                                try {
                                                                    JSONObject vulJson = vulList.getJSONObject(i);
                                                                    String ip = JsonUtils.getStr(vulJson, "ip");
                                                                    JSONArray vulnDetailList = vulJson.getJSONArray("vuln_scanned");
                                                                    int vulCount = 0;
                                                                    if (vulnDetailList != null) {
                                                                        vulCount = vulnDetailList.size();
                                                                    }
                                                                    vulTotal += vulCount;
                                                                    if (vulCount > 0) {
                                                                        for (int j = 0; j < vulCount; j++) {
                                                                            try {
                                                                                JSONObject vulJsonInfo = vulnDetailList.getJSONObject(j);
                                                                                VulnProcessForm curVul = getVul(scannerInfo.getEngineId(), vulJsonInfo, ip, ScanTypeEnums.WEAK_PASS_SCAN.getCode(), findTime);
                                                                                if (curVul == null) {
                                                                                    continue;
                                                                                }
                                                                                if (dataMap.containsKey(ip)) {
                                                                                    dataMap.get(ip).add(curVul);
                                                                                } else {
                                                                                    dataMap.put(ip, new ArrayList<>());
                                                                                    dataMap.get(ip).add(curVul);
                                                                                }
                                                                            } catch (Exception e) {
                                                                                log.error(e.getMessage(), e);
                                                                            }
                                                                        }
                                                                    }
                                                                } catch (Exception e) {
                                                                    log.error(e.getMessage(), e);
                                                                }

                                                            }
                                                        }
                                                    }
                                                }
                                            }
                                        }

                                        for (String ip : dataMap.keySet()) {
                                            List<VulnProcessForm> curList = dataMap.get(ip);
                                            if (curList.size() > 0) {
                                                log.info("解析任务:" + task.getTaskName() + " " + ip + " -> " + " 发现弱口令：" + curList.size());
                                                handle(curList, ip);
                                            } else {
                                                log.info("解析任务:" + task.getTaskName() + " " + ip + " -> " + " 未发现弱口令");
                                                repairAllByIp(ip);
                                            }
                                        }
                                    }
                                } catch (Exception e) {
                                    log.error(e.getMessage(), e);
                                } finally {
                                    IOUtils.close(response);
                                }
                            }

                            /*
                             * 更新业务段任务进度
                             */
                            try {
                                VulnScanTaskRecord taskRecord = taskRecordMapper.selectById(task.getRecordId());
                                taskRecord.setScanProgress(task.getProgress());
                                if (status == 2) {
                                    taskRecord.setScanEndTime(new Date());
                                    taskRecord.setDuration(DateUtils.getDiffSec(taskRecord.getScanStartTime(), taskRecord.getScanEndTime()));
                                    taskRecord.setScanStatus(2);
                                    taskRecord.setScanResult("扫描完成");
                                }
                                taskRecordMapper.updateVulnScanTaskRecord(taskRecord);

                                VulnScanTask scanTask = new VulnScanTask();
                                scanTask.setId(taskRecord.getTaskId());
                                scanTask.setUpdateTime(new Date());
                                scanTask.setScanProgress(taskRecord.getScanProgress());

                                if (taskRecord.getScanStatus() != null && taskRecord.getScanStatus() > 1) {
                                    scanTask.setScanStatus(ScanStatusEnums.SCAN_FINISH.getCode());
                                }
                                scanTaskMapper.updateVulnScanTask(scanTask);
                            } catch (Exception e) {
                                log.error(e.getMessage(), e);
                            }
                        }else {
                            //{"data":{"inner_error":"系统异常"},"ret_msg":"找不到任务","ret_code":"-1"}
                            if(JsonUtils.equalVal(retJson,"ret_code","999")) {
                                try {
                                    task.setScanStatus(3);
                                    task.setResult("系统异常,找不到任务");
                                    taskRecordLogMapper.updateVulnScanTaskRecordLog(task);

                                    VulnScanTaskRecord taskRecord = taskRecordMapper.selectById(task.getRecordId());
                                    taskRecord.setScanProgress(task.getProgress());
                                    taskRecord.setScanEndTime(new Date());
                                    taskRecord.setDuration(DateUtils.getDiffSec(taskRecord.getScanStartTime(), taskRecord.getScanEndTime()));
                                    taskRecord.setScanStatus(2);
                                    taskRecord.setScanResult("系统异常,找不到任务");
                                    taskRecordMapper.updateVulnScanTaskRecord(taskRecord);

                                    VulnScanTask scanTask = new VulnScanTask();
                                    scanTask.setId(taskRecord.getTaskId());
                                    scanTask.setUpdateTime(new Date());
                                    scanTask.setScanProgress(taskRecord.getScanProgress());

                                    if (taskRecord.getScanStatus() != null && taskRecord.getScanStatus() > 1) {
                                        scanTask.setScanStatus(ScanStatusEnums.SCAN_FINISH.getCode());
                                    }
                                    scanTaskMapper.updateVulnScanTask(scanTask);
                                } catch (Exception e) {
                                    log.error(e.getMessage(), e);
                                }
                            }
                        }
                    }
                } catch (Exception e) {
                    log.error(e.getMessage(), e);
                }
            }
        } catch (Exception e) {
            log.error(e.getMessage(), e);
        }
        log.info("同步绿盟任务数据结束");
    }

    /**
     * IP全部修复
     *
     * @param ip IP
     */
    public static void repairAllByIp(String ip) {
        try {
            CommonAssemble.repairAll(ip, ScannerEnums.LVMENG_SCANNER.getCode(), ScanTypeEnums.WEAK_PASS_SCAN.getCode());
        } catch (Exception e) {
            log.error(e.getMessage(), e);
        }
    }

    private static void handle(List<VulnProcessForm> culList, String ip) {
        //原有弱口令查询
        VulnProcessFormMapper vulnProcessFormMapper = GetSpringBean.getBean(VulnProcessFormMapper.class);
        AssetMapper assetMapper = GetSpringBean.getBean(AssetMapper.class);
        //原有弱口令查询
        LambdaQueryWrapper<VulnProcessForm> vq = new LambdaQueryWrapper<>();
        vq.eq(VulnProcessForm::getIp, ip);
        vq.eq(VulnProcessForm::getSource, ScannerEnums.LVMENG_SCANNER.getCode());
        vq.eq(VulnProcessForm::getCategory, ScanTypeEnums.WEAK_PASS_SCAN.getCode());
        List<VulnProcessForm> vulList = vulnProcessFormMapper.selectList(vq);
        List<VulnProcessForm> repairedList = new LinkedList<>();
        List<VulnProcessForm> unrepairedList = new LinkedList<>();
        List<VulnProcessForm> newVulList = new LinkedList<>();
        log.info(ip + " 库存弱口令：" + vulList.size() + " 当前有弱口令：" + culList.size());
        int newTotal = 0;
        int dropTotal = 0;
        //扫描到弱口令
        for (VulnProcessForm curVul : culList) {
            Asset asset = assetMapper.selectAssetByInnerIp(ip);
            if (asset == null) {
                asset = new Asset();
                asset.setSource(AssetSourceEnums.LVMENT_CMDB.getCode());
                asset.setInternalIp(ip);
                CrcAssetSyncQueue.getInstance().saveAsset(asset);
            }
            //白名单
            if (WhiteListQuery.isWhiteList(curVul)) {
                dropTotal++;
                continue;
            }
            newVulList.add(curVul);
            //是否新弱口令
            boolean isnew = true;
            VulnProcessForm tmp = vulnProcessFormMapper.selectById(curVul.getId());
            if (tmp != null) {
                vulnProcessFormMapper.stillExist(curVul.getId());
                isnew = false;
            }

            if (isnew) {
                //新弱口令
                if (CommonAssemble.saveVul(curVul)) {
                    newTotal++;
                } else {
                    dropTotal++;
                }
            }
        }
        //已修复的弱口令判断
        for (VulnProcessForm oldVul : vulList) {
            boolean isRepair = true;
            for (VulnProcessForm newVul : newVulList) {
                //弱口令名称 节点IP是否相同
                if (newVul.getId().equalsIgnoreCase(oldVul.getId())) {
                    isRepair = false;
                    break;
                }
            }
            //弱口令已修复
            if (isRepair) {
                repairedList.add(oldVul);
            } else {
                //未修复
                unrepairedList.add(oldVul);
            }
        }
        log.info(ip + " @@@@@@@@@@@@库存弱口令：" + vulList.size() + " 丢弃弱口令：" + dropTotal + " 新增弱口令：" + newTotal + " 未修复弱口令：" + unrepairedList.size() + " 修复弱口令：" + repairedList.size());
        if (repairedList.size() > 0) {
            repairedList.forEach((CommonAssemble::repairedVul));
        }
        if (unrepairedList.size() > 0) {
            unrepairedList.forEach((CommonAssemble::unRepairedVul));
        }
    }

    /**
     * 解析弱口令数据
     *
     * @param engineId
     * @param json
     * @param ip
     * @param scanType
     * @return
     */
    private static VulnProcessForm getVul(Long engineId, JSONObject json, String ip, int scanType, String findTime) {
        /*
        {
                            "protocol": "FTP",
                            "vul_id": "L5O94T39",
                            "port": "23",
                            "service": "FTP",
                            "mess_string": "FTP [root:123456]"
                        }
         */
        String messString = JsonUtils.getStr(json, "mess_string");
        String user = "";
        String password = "";
        try {
            String s1 = messString.split("\\[")[1].replace("]", "");
            user = s1.split(":")[0];
            password = s1.split(":")[1];
        } catch (Exception e) {
            log.error(e.getMessage(), e);
        }
        if (StringUtils.isBlank(user) && StringUtils.isBlank(password)) {
            return null;
        }
        String port = JsonUtils.getStr(json, "port");
        String service = JsonUtils.getStr(json, "service");
        String vulName = user + port + password + service;
        if (StringUtils.isBlank(vulName)) {
            return null;
        }
        Date publicDate = JsonUtils.getDateX(json, "publicDate");
        double riskPoints = JsonUtils.getDouble(json, "risk_points");
//        if (riskPoints < 1) {
//            log.info("信息级别弱口令丢弃：" + json.toJSONString());
//            return null;
//        }

        String desc = String.format("账号：%s，存在弱口令", user);
        String solution = "请修改相关弱口令，并举一反三全面排查系统弱口令，增加口令默认配置策略。";


        //高	7 <= 弱口令风险值 <= 10	攻击者可以远程执行任意命令或者代码，或对系统进行远程拒绝服务攻击。
        //中	4 <= 弱口令风险值 < 7	攻击者可以远程创建、修改、删除文件或数据，或对普通服务进行拒绝服务攻击。
        //低	0 <= 弱口令风险值 < 4	攻击者可以获取某些系统、服务的信息，或读取系统文件和数据。
        //0:低危, 1:中危, 2:高危, 3:严重
        int level = 0;
        if (riskPoints >= 7) {
            level = 2;
        } else if (riskPoints >= 4) {
            level = 1;
        }
        VulnProcessForm vul = new VulnProcessForm();
        vul.setIp(ip);
        vul.setEngineId(engineId + "");
        //修复影响：0-未知；1-无需重启；2-服务重启；3系统重启 （仅linux）
        vul.setVulHostInfluence(JsonUtils.getInt(json, "restartOpts") + "");
        vul.setRefLink(JsonUtils.getStr(json, "expRefs"));
        vul.setCvss(CvssUtils.getScore(JsonUtils.getStr(json, "cvss")));
        vul.setVulnName(vulName);
        vul.setCode(String.format("VUL_%s", IdGen.uuid8()));
        vul.setLevel(level + "");
        vul.setSource(ScannerEnums.LVMENG_SCANNER.getCode());
        String id = Md5Utils.hash(vulName + "#" + vul.getSource());
        vul.setId(id);
        vul.setCategory(ScanTypeEnums.WEAK_PASS_SCAN.getCode());
        vul.setDescription(desc);
        vul.setSolution(solution);
        vul.setAvailableCondition(JsonUtils.getStr(json, "condition"));
        vul.setCveCode("");
        vul.setValidInfo(JsonUtils.getStr(json, "checkInfo"));
        vul.setAffectApplication(JsonUtils.getStr(json, "appVersion"));
        vul.setCreateTime(new Date());
        vul.setUpdateTime(new Date());
        vul.setFirstTime(DateUtils.parseDateTime(findTime, DateUtils.DATE_FORMAT_STRING1));
        vul.setRecentlyTime(DateUtils.parseDateTime(findTime, DateUtils.DATE_FORMAT_STRING1));
        vul.setPublishTime(publicDate);
        vul.setUserName(user);
        vul.setPassword(password);
        vul.setPort(port);
        vul.setService(service);
        if (StringUtils.isBlank(vul.getVulnType())) {
            vul.setVulnType("常见弱密码");
        }
        CommonAssemble.saveVulAssetInfo(vul, ip);
        return vul;
    }

    /**
     * 保存绿盟资产数据
     *
     * @param ip IP
     */
    public static void saveAsset(String ip) {
        try {
            if (StringUtils.isBlank(ip)) {
                return;
            }
            Asset asset = new Asset();
            asset.setInternalIp(ip);
            //资产类型：(服务器，通信网络设备，安全设备，物联网设备)
            /*
            服务器		["通用","Web","文件","数据库","云平台","其他服务器设备"]
           通信网络设备	["路由器","交换机","网络存储","无线网络","其他网络设备"]
           安全设备	["VPN产品","防火墙","远程审计堡垒机","弱口令扫描","网络入侵检测与防御","威胁分析与管理","防病毒网关","安全内容管理","其他安全设备","IPS","WAF","主机防护","容器防护","防病毒","态势感知","日志审计","数据库审计","堡垒机","威胁情报","蜜罐"]
           物联网设备	["视频监控","门禁系统","语音视频","工业控制","其他物联网设备"]
             */
            asset.setType("服务器");
            asset.setSubType("通用");
            //资产状态，可选项：1在用、2停用、3下架、4库存备用、5故障设备、6已临时关停、7待修、8在修、9闲置、10待报废、11报废、12转交
            asset.setOperatingStatus(1);
            asset.setSource(AssetSourceEnums.LVMENT_CMDB.getCode());
            try {
                //数据来源，仅详情展示；1传统资源池CMDB、2华润云CMDB、3绿盟、4D01、5"
                if (StringUtils.isBlank(asset.getInstance())) {
                    asset.setInstance(asset.getInternalIp());
                }
            } catch (Exception e) {
                log.error(e.getMessage(), e);
            }

            CrcAssetSyncQueue.getInstance().saveAsset(asset);
        } catch (Exception e) {
            log.error(e.getMessage(), e);
        }
    }

}
