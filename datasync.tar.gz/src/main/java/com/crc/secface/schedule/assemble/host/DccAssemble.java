package com.crc.secface.schedule.assemble.host;

import com.alibaba.fastjson.JSONArray;
import com.alibaba.fastjson.JSONObject;
import com.baomidou.mybatisplus.core.conditions.query.LambdaQueryWrapper;
import com.baomidou.mybatisplus.core.conditions.update.LambdaUpdateWrapper;
import com.baomidou.mybatisplus.core.toolkit.Wrappers;
import com.crc.common.code.SimpleCodeTool;
import com.crc.common.enums.ScanStatusEnums;
import com.crc.common.enums.ScanTypeEnums;
import com.crc.common.enums.ScannerEnums;
import com.crc.common.utils.*;
import com.crc.scanner.config.DccConfig;
import com.crc.secface.config.GetSpringBean;
import com.crc.secface.domain.*;
import com.crc.secface.mapper.VulnProcessFormMapper;
import com.crc.secface.mapper.VulnScanTaskMapper;
import com.crc.secface.mapper.VulnScanTaskRecordLogMapper;
import com.crc.secface.mapper.VulnScanTaskRecordMapper;
import com.crc.secface.queue.RiskAutoFlowSyncQueue;
import com.crc.secface.schedule.assemble.CommonAssemble;
import com.crc.sync.config.SyncSecConfigLoad;
import com.crc.sync.config.SyncSecConstants;
import com.crc.sync.d01.DccTaskCenter;
import com.crc.sync.d01.DccTaskSync;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;

import java.util.*;

/**
 * DCC 漏洞协同核心逻辑
 */
@Slf4j
public class DccAssemble {

    public static DccConfig getDccConfig(Long engineId) {
        EngineEquipmentManagement engine = CommonAssemble.engineMap.get(engineId);
        DccConfig qtConfig = new DccConfig();
        if (engine == null || engine.getId() == null) {
            return qtConfig;
        }
        qtConfig.setEngineId(engineId);
        qtConfig.setAddress(engine.getEquipmentAddress());
        String PASS = engine.getPassword().trim();
        qtConfig.setPassword(PASS);
        try {
            PASS = SimpleCodeTool.decrypt(PASS);
            qtConfig.setPassword(PASS);
        } catch (Exception e) {
            log.error(e.getMessage(), e);
        }
        qtConfig.setUsername(engine.getLoginUser());
        return qtConfig;
    }

    /**
     * 下发Dcc核查任务
     */

    public static void addTask() {
        try {
            VulnScanTaskMapper vulnScanTaskMapper = GetSpringBean.getBean(VulnScanTaskMapper.class);
            VulnScanTaskRecordMapper taskRecordMapper = GetSpringBean.getBean(VulnScanTaskRecordMapper.class);
            VulnScanTaskRecordLogMapper taskRecordLogMapper = GetSpringBean.getBean(VulnScanTaskRecordLogMapper.class);
            List<VulnScanTask> list = CommonAssemble.getCheckingScantask(ScannerEnums.DCC_SCANNER.getCode(), ScanTypeEnums.HOST_SCAN.getCode(), Arrays.asList(1, 2));
            log.info("DCC待执行待任务数量：" + list.size());
            for (VulnScanTask task : list) {
                try {
                    DccConfig scannerInfo = getDccConfig(task.getEngineId());
                    String nodeName = vulnScanTaskMapper.getDccNodeName(task.getEngineId());
                    if (StringUtils.isBlank(nodeName)) {
                        log.error(task.getTaskName() + ",没有配置D01节点名称，在引擎管理，节点信息的名称配置D01的节点ID，在DCC的节点管理查询！！如：MIDZ98DK3J6F6XF");
                        continue;
                    }
                    VulnScanTaskRecord record = taskRecordMapper.getLastRecordByTaskId(task.getId());
                    if (record == null) {
                        continue;
                    }
                    LambdaQueryWrapper<VulnScanTaskRecordLog> qlog = new LambdaQueryWrapper<>();
                    qlog.eq(VulnScanTaskRecordLog::getRecordId, record.getId());
                    qlog.eq(VulnScanTaskRecordLog::getTaskId, task.getId());
                    String scanContent = task.getScanContentX();
                    if (taskRecordLogMapper.selectCount(qlog) > 0) {
                        log.info("{}{},已在执行中", task.getTaskName(), scanContent);
                        continue;
                    }

                    VulnScanTaskRecordLog recordLog = new VulnScanTaskRecordLog();
                    recordLog.setIp(scanContent);
                    recordLog.setTaskId(record.getTaskId());
                    recordLog.setTaskName(task.getTaskName());
                    recordLog.setRecordId(record.getId());
                    recordLog.setEngineId(task.getEngineId());
                    recordLog.setCreateTime(new Date());
                    recordLog.setType(ScannerEnums.DCC_SCANNER.getCode());
                    //任务状态(0 未开始 1 执行中 2 执行完成 3 执行失败)
                    recordLog.setScanStatus(0);

                    String ret = DccTaskCenter.startScanTask(scannerInfo, recordLog, nodeName);
                    String taskMsg = "执行成功";

                    if (DccTaskCenter.PASS.equals(ret)) {
                        recordLog.setScanStatus(1);
                        recordLog.setResult(taskMsg);
                        record.setScanStatus(1);
                        taskRecordLogMapper.insert(recordLog);
                    } else {
                        recordLog.setScanStatus(3);
                        record.setScanStatus(3);
                        taskMsg = "执行失败";
                        recordLog.setResult(taskMsg);
                        taskRecordLogMapper.insert(recordLog);

                        CommonAssemble.startFail(recordLog, taskMsg);
                    }
                    log.info(String.format("task_id=%s,返回=%s,%s", recordLog.getTaskId(), ret, taskMsg));
                    record.setScanResult(taskMsg);
                    taskRecordMapper.updateVulnScanTaskRecord(record);
                    // }
                } catch (Exception e) {
                    log.error(e.getMessage(), e);
                }
            }
        } catch (Exception e) {
            log.error(e.getMessage(), e);
        }
    }

    public static void getTask() {
        try {
            CommonAssemble.engineMap.forEach((k, v) -> {
                if (ScannerEnums.DCC_SCANNER.getCode().equals(v.getEquipmentManufacture())) {
                    getTask(getDccConfig(k));
                }
            });
        } catch (Exception e) {
            log.error(e.getMessage(), e);
        }
    }

    private static void getTask(DccConfig scannerInfo) {
        VulnScanTaskRecordLogMapper taskRecordLogMapper = GetSpringBean.getBean(VulnScanTaskRecordLogMapper.class);
        List<VulnScanTaskRecordLog> getTaskList = new ArrayList<>();
        try {
            //已完成的即时任务
            int total = DccTaskSync.getTotal(scannerInfo, "taskRecords", "&type=complete&page=1&per_page=1");
            log.info("已完成的即时任务:" + total);
            if (total > 0) {
                int pageSize = 200;
                for (int i = 1; i < DataUtils.getPageCount(total,pageSize,1); i++) {
                    JSONArray list = DccTaskSync.getList(scannerInfo, "taskRecords", "&type=complete&page=" + i + "&per_page=" + pageSize);
                    if (list != null && !list.isEmpty()) {
                        for (int j = 0; j < list.size(); j++) {
                            JSONObject json = list.getJSONObject(j);
                            String d01TaskId = JsonUtils.getStr(json, "id");
                            LambdaQueryWrapper<VulnScanTaskRecordLog> queryWrapper = new LambdaQueryWrapper<>();
                            queryWrapper.eq(VulnScanTaskRecordLog::getJobId, d01TaskId);
                            queryWrapper.last(" limit 1");
                            VulnScanTaskRecordLog task = taskRecordLogMapper.selectOne(queryWrapper);
                            if (task == null)
                                continue;

                            task.setProgress(100);
                            task.setScanStatus(2);
                            taskRecordLogMapper.updateById(task);
                            getTaskList.add(task);
                        }
                    }
                }
            }

            total = DccTaskSync.getTotal(scannerInfo, "taskRecords", "&page=1&per_page=1");
            log.info("未完成的即时任务:" + total);
            if (total > 0) {
                int pageSize = 200;
                for (int i = 1; i < DataUtils.getPageCount(total,pageSize,1); i++) {
                    JSONArray list = DccTaskSync.getList(scannerInfo, "taskRecords", "&page=" + i + "&per_page=" + pageSize);
                    if (list != null && !list.isEmpty()) {
                        for (int j = 0; j < list.size(); j++) {
                            JSONObject json = list.getJSONObject(j);
                            String d01TaskId = JsonUtils.getStr(json, "id");
                            LambdaQueryWrapper<VulnScanTaskRecordLog> queryWrapper = new LambdaQueryWrapper<>();
                            queryWrapper.eq(VulnScanTaskRecordLog::getJobId, d01TaskId);
                            queryWrapper.last(" limit 1");
                            VulnScanTaskRecordLog task = taskRecordLogMapper.selectOne(queryWrapper);
                            if (task == null)
                                continue;

                            JSONArray subset = json.getJSONArray("subset");
                            if (subset.size() > 0) {
                                JSONObject sub = subset.getJSONObject(0);
                                task.setProgress(JsonUtils.getInt(sub, "progress"));
                                task.setScanStatus(1);
                                taskRecordLogMapper.updateById(task);

                                getTaskList.add(task);
                            }
                        }
                    }
                }
            }
        } catch (Exception e) {
            log.error(e.getMessage(), e);
        }
        /*
         * 更新业务段任务进度
         */
        VulnScanTaskRecordMapper taskRecordMapper = GetSpringBean.getBean(VulnScanTaskRecordMapper.class);
        VulnScanTaskMapper scanTaskMapper = GetSpringBean.getBean(VulnScanTaskMapper.class);
        if (getTaskList.size() > 0) {
            try {
                for (VulnScanTaskRecordLog task : getTaskList) {
                    try {
                        if (task.getScanStatus() == null) {
                            continue;
                        }
                        VulnScanTaskRecord taskRecord = taskRecordMapper.selectById(task.getRecordId());
                        if (taskRecord.getScanStatus() != null && taskRecord.getScanStatus() > 1 && Objects.equals(taskRecord.getScanProgress(), 100)) {
                            //不重复计算
                            continue;
                        }
                        taskRecord.setScanProgress(task.getProgress());
                        if (Objects.equals(task.getScanStatus(), 2) || Objects.equals(task.getScanStatus(), 3)) {
                            taskRecord.setScanEndTime(new Date());
                            taskRecord.setDuration(DateUtils.getDiffSec(taskRecord.getScanStartTime(), taskRecord.getScanEndTime()));
                            taskRecord.setScanStatus(2);
                            taskRecord.setScanResult("扫描完成");
                        }
                        taskRecordMapper.updateVulnScanTaskRecord(taskRecord);

                        VulnScanTask scanTask = new VulnScanTask();
                        scanTask.setId(taskRecord.getTaskId());
                        scanTask.setUpdateTime(new Date());
                        scanTask.setScanProgress(taskRecord.getScanProgress());

                        if (taskRecord.getScanStatus() != null && taskRecord.getScanStatus() > 1) {
                            scanTask.setScanStatus(ScanStatusEnums.SCAN_FINISH.getCode());
                        }
                        scanTaskMapper.updateVulnScanTask(scanTask);
                    } catch (Exception e) {
                        log.error(e.getMessage(), e);
                    }
                }
            } catch (Exception e) {
                log.error(e.getMessage(), e);
            }
        }
    }

    public static void parseTask() {
        try {
            VulnScanTaskRecordLogMapper taskRecordLogMapper = GetSpringBean.getBean(VulnScanTaskRecordLogMapper.class);
            VulnScanTaskRecordLog q = new VulnScanTaskRecordLog();
            q.setScanStatus(2);//扫描完成
            q.setScanType(ScanTypeEnums.HOST_SCAN.getCode());
            q.setEngineName(ScannerEnums.DCC_SCANNER.getCode());
            List<VulnScanTaskRecordLog> recordList = taskRecordLogMapper.getAllRecordLogList(q);
            /*
             * 已经完成的资产探测扫描
             */
            for (VulnScanTaskRecordLog vulTask : recordList) {
                if (!StringUtils.isNotBlank(vulTask.getJobId()))
                    continue;
                if (CommonAssemble.isStopNow(vulTask)) {
                    continue;
                }
                notRepairSync(getDccConfig(vulTask.getEngineId()), vulTask.getEngineId(), vulTask.getJobId(), "threats");
                repairSync(getDccConfig(vulTask.getEngineId()), vulTask.getEngineId(), vulTask.getJobId(), "threats");
            }
        } catch (Exception e) {
            log.error(e.getMessage(), e);
        }
    }

    public static void parseAllTask() {
        try {
            CommonAssemble.engineMap.forEach((k, v) -> {
                if (ScannerEnums.DCC_SCANNER.getCode().equals(v.getEquipmentManufacture())) {
                    notRepairSync(getDccConfig(k), k, null, "threats");
                    repairSync(getDccConfig(k), k, null, "threats");
                }
            });
        } catch (Exception e) {
            log.error(e.getMessage(), e);
        }
    }

    /**
     * type=threats 资产漏洞 type=assets 资产列表
     *
     * @param type 类型
     */
    public static void notRepairSync(DccConfig scannerInfo, Long engineId, String taskId, String type) {
        if (scannerInfo == null || !scannerInfo.isGoodConfig()) {
            return;
        }
        String params = "&task_id=" + taskId + "&searchType=vul&type=1&page=1&size=1";
        if (StringUtils.isBlank(taskId)) {
            params = "&searchType=vul&type=1&page=1&size=1";
        }
        int total = DccTaskSync.getTotal(scannerInfo, type, params);
        log.info("开始同步D01数据，数据量：" + total);
        boolean flag = false;
        if (total > 0) {
            int pageSize = 200;
            for (int i = 1; i < DataUtils.getPageCount(total,pageSize,1); i++) {
                try {
                    params = "&task_id=" + taskId + "&searchType=vul&type=1&page=" + i + "&size=" + pageSize;
                    if (StringUtils.isBlank(taskId)) {
                        params = "&searchType=vul&type=1&page=" + i + "&size=" + pageSize;
                    }
                    JSONArray list = DccTaskSync.getList(scannerInfo, type, params);
                    saveMysql(engineId, taskId, list, false);
                } catch (Exception e) {
                    log.error(e.getMessage(), e);
                }
            }
        }
        log.info("D01未修复漏洞数据同步完成！" + total);
    }

    /**
     * type=threats 资产漏洞 type=assets 资产列表
     *
     * @param type 类型
     */
    public static void repairSync(DccConfig scannerInfo, Long engineId, String taskId, String type) {
        int total = DccTaskSync.getTotal(scannerInfo, type, "&task_id=" + taskId + "&searchType=vul&type=2&page=1&size=1");
        log.info("开始同步D01数据，数据量：" + total);
        boolean flag = false;
        if (total > 0) {
            int pageSize = 200;
            for (int i = 1; i < DataUtils.getPageCount(total,pageSize,1); i++) {
                try {
                    JSONArray list = DccTaskSync.getList(scannerInfo, type, "&task_id=" + taskId + "&searchType=vul&type=2&page=" + i + "&size=" + pageSize);
                    saveMysql(engineId, taskId, list, true);
                } catch (Exception e) {
                    log.error(e.getMessage(), e);
                }
            }
        }
        log.info("D01已修复漏洞数据同步完成！" + total);
    }


    /**
     * 保存漏洞数据
     *
     * @param taskId   任务ID
     * @param dataList 数据
     * @param repair   是否修复
     */
    public static void saveMysql(Long engineId, String taskId, JSONArray dataList, boolean repair) {
        if (dataList == null) {
            return;
        }
        for (int i = 0; i < dataList.size(); i++) {
            try {
                JSONObject jsonx = dataList.getJSONObject(i);
                String id = jsonx.getString("_id");
                JSONObject json = jsonx.getJSONObject("_source");
                procData(engineId, taskId, id, json, repair);
            } catch (Exception e) {
                log.error(e.getMessage(), e);
            }
        }
    }

    /**
     * 解析D01的漏洞数据
     *
     * @param taskId   任务ID
     * @param id       漏洞ID
     * @param jsonData 数据
     * @param repair   是否修复
     */
    public static void procData(Long engineId, String taskId, String id, JSONObject jsonData, boolean repair) {
        try {
            String ip = JsonUtils.getStr(jsonData, "ip");//IP地址
            if (!IpUtils.isIp(ip)) {
                log.info("非法IP" + ip);
                return;
            }
            String common_title = JsonUtils.getStr(jsonData, "common_title");//漏洞名称
            String createtime = JsonUtils.getStr(jsonData, "createtime");
            String lastupdatetime = JsonUtils.getStr(jsonData, "lastupdatetime");//是否代理理 0没有代理理 1有代理理
            String level = JsonUtils.getStr(jsonData, "level");//0:低危, 1:中危, 2:⾼危, 3:严重int
            String vulType = JsonUtils.getStr(jsonData, "vulType");//漏洞类型
            String cveId = JsonUtils.getStr(jsonData, "cveId");//cveId
            String common_impact = JsonUtils.getStr(jsonData, "common_impact");//漏洞危害
            String url = JsonUtils.getStr(jsonData, "url");//漏洞地址
            String filter = SyncSecConfigLoad.getRemarkValue(SyncSecConstants.DCC_SYNC_ENABLE);
            try {
                boolean flag = false;
                if (filter != null && filter.contains("=") && filter.contains("level")) {
                    String filterLevel = filter.split("=")[1];
                    for (String fl : filterLevel.split(",")) {
                        if (StringUtils.isNotBlank(level) && level.equalsIgnoreCase(fl)) {
                            flag = true;
                            break;
                        }
                    }
                } else {
                    flag = true;
                }
                if (!flag) {
                    return;
                }
            } catch (Exception e) {
                log.error(e.getMessage(), e);
            }


            String recommandation = JsonUtils.getStr(jsonData, "recommandation");//解决方案
            String common_description = JsonUtils.getStr(jsonData, "common_description");//漏洞描述
            String mid = JsonUtils.getStr(jsonData, "mid");//漏洞描述
            VulnProcessForm vul = new VulnProcessForm();
            vul.setIp(ip);
            vul.setVulnName(common_title);
            vul.setLevel(level);
            vul.setId(id);
            vul.setCode(String.format("VUL_%s", IdGen.uuid8()));
            vul.setEngineId(String.valueOf(engineId));
            vul.setVulnType(vulType);
            vul.setDescription(common_description);
            vul.setSolution(recommandation);
            vul.setCveCode(cveId);
            vul.setCreateTime(DateUtils.parseDate(createtime, DateUtils.DATE_FORMAT_STRING1));
            vul.setUpdateTime(DateUtils.parseDate1(lastupdatetime, DateUtils.DATE_FORMAT_STRING1));
            vul.setFirstTime(vul.getCreateTime());
            if (vul.getUpdateTime() != null)
                vul.setRecentlyTime(vul.getUpdateTime());
            vul.setCategory(ScanTypeEnums.HOST_SCAN.getCode());
            vul.setSource(ScannerEnums.DCC_SCANNER.getCode());
            CommonAssemble.saveVulAssetInfo(vul, ip);
            saveVul(vul, repair);

        } catch (Exception e) {
            log.error(e.getMessage(), e);
        }
    }

    /**
     * 漏洞写入库，并跟进D01返回的漏洞状态更新；
     *
     * @param vul    漏洞信息
     * @param repair 是否修复
     */
    public static void saveVul(VulnProcessForm vul, boolean repair) {
        if (vul == null || vul.getId() == null)
            return;
        VulnProcessFormMapper vulnProcessFormMapper = GetSpringBean.getBean(VulnProcessFormMapper.class);
        String status = repair ? "1" : "0";
        VulnProcessForm tmp = vulnProcessFormMapper.selectById(vul.getId());
        if (tmp != null) {
            vul.setStatus(status);

            if ("1".equalsIgnoreCase(status)) {
                if (!"1".equalsIgnoreCase(tmp.getStatus())) {//原来是未修复
                    LambdaUpdateWrapper<VulnProcessForm> updateWrapper = Wrappers.lambdaUpdate();
                    //推送状态 0：未推送 1：已推送
                    if (!"1".equalsIgnoreCase(tmp.getIsPushStatus())) {
                        updateWrapper.set(VulnProcessForm::getDelFlag, "1");
                    }

                    updateWrapper.eq(VulnProcessForm::getId, vul.getId());
                    updateWrapper.set(VulnProcessForm::getStatus, "1");
                    updateWrapper.set(VulnProcessForm::getUpdateTime, new Date());
                    vulnProcessFormMapper.update(null, updateWrapper);
                    //已修复
                    RiskAutoFlowSyncQueue.flowToQueue(vul, repair);
                }
            } else {
                LambdaUpdateWrapper<VulnProcessForm> uw = new LambdaUpdateWrapper<>();
                uw.eq(VulnProcessForm::getId, vul.getId());
                uw.set(VulnProcessForm::getRecentlyTime, new Date());
                uw.set(VulnProcessForm::getStatus, "0");
                vulnProcessFormMapper.update(null, uw);

                RiskAutoFlowSyncQueue.flowToQueue(vul, false);
            }
        } else {
            CommonAssemble.saveVul(vul);
        }
    }
}
