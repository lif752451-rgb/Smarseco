package com.crc.secface.schedule.assemble.host;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONArray;
import com.alibaba.fastjson.JSONObject;
import com.baomidou.mybatisplus.core.conditions.query.LambdaQueryWrapper;
import com.baomidou.mybatisplus.core.conditions.update.LambdaUpdateWrapper;
import com.crc.common.code.SimpleCodeTool;
import com.crc.common.enums.AssetSourceEnums;
import com.crc.common.enums.ScanStatusEnums;
import com.crc.common.enums.ScanTypeEnums;
import com.crc.common.enums.ScannerEnums;
import com.crc.common.utils.DataUtils;
import com.crc.common.utils.DateUtils;
import com.crc.common.utils.IdGen;
import com.crc.common.utils.IpUtils;
import com.crc.common.utils.JsonUtils;
import com.crc.common.utils.Md5Utils;
import com.crc.scanner.config.QtConfig;
import com.crc.scanner.tool.CvssUtils;
import com.crc.scanner.tool.QingtengUtils;
import com.crc.secface.config.GetSpringBean;
import com.crc.secface.domain.Asset;
import com.crc.secface.domain.EngineEquipmentManagement;
import com.crc.secface.domain.QingtengAgent;
import com.crc.secface.domain.VulnProcessForm;
import com.crc.secface.domain.VulnScanTask;
import com.crc.secface.domain.VulnScanTaskRecord;
import com.crc.secface.domain.VulnScanTaskRecordLog;
import com.crc.secface.mapper.AssetMapper;
import com.crc.secface.mapper.QingtengAgentMapper;
import com.crc.secface.mapper.VulnProcessFormMapper;
import com.crc.secface.mapper.VulnScanTaskMapper;
import com.crc.secface.mapper.VulnScanTaskRecordLogMapper;
import com.crc.secface.mapper.VulnScanTaskRecordMapper;
import com.crc.secface.queue.CrcAssetSyncQueue;
import com.crc.secface.queue.CrcRiskAutoDataQueue;
import com.crc.secface.queue.QtAllRiskAutoFlowSyncQueue;
import com.crc.secface.schedule.assemble.CommonAssemble;
import com.crc.secface.schedule.assemble.WhiteListQuery;
import com.crc.sync.config.SyncSecConfigLoad;
import com.crc.sync.config.SyncSecConstants;
import com.crc.sync.qingteng.QingtengWeakPassSync;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.apache.http.client.methods.CloseableHttpResponse;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.Date;
import java.util.HashMap;
import java.util.LinkedList;
import java.util.List;


@Slf4j
public class QingtengAssemble {
    static HashMap<String, String> typeMap = new HashMap<>();

    static {
        String data = "0 SQL注入,1 未授权访问,2 敏感信息泄露,3 XML外部实体注入,4 跨站脚本攻击,5 不安全的反序列,6 客户端请求伪造,7 服务端请求伪造,8 命令执行,9 代码执行,10 任意文件上传,11 任意文件读取,12 拒绝服务攻击,13 目录遍历,14 恶意后门,15 本地提权,16 注入漏洞";
        for (String x : data.split(",")) {
            String[] xx = x.split(" ");
            if (xx.length == 2) {
                typeMap.put(xx[0], xx[1]);
            }
        }
    }

    public static QtConfig getQtConfig(Long engineId) {
        EngineEquipmentManagement engine = CommonAssemble.engineMap.get(engineId);
        QtConfig qtConfig = new QtConfig();
        if (engine == null || engine.getId() == null) {
            return qtConfig;
        }
        qtConfig.setEngineId(engineId);
        qtConfig.setAddress(engine.getEquipmentAddress());
        String PASS = engine.getPassword().trim();
        qtConfig.setPassword(PASS);
        try {
            PASS = SimpleCodeTool.decrypt(PASS);
            qtConfig.setPassword(PASS);
        } catch (Exception e) {
            log.error(e.getMessage(), e);
        }
        qtConfig.setUsername(engine.getLoginUser());
        return qtConfig;
    }

    /**
     * 添加青藤资产清单任务
     */
    public static void addAssetCheck() {
        try {
            VulnScanTaskRecordLogMapper taskRecordLogMapper = GetSpringBean.getBean(VulnScanTaskRecordLogMapper.class);
            VulnScanTaskRecordMapper taskRecordMapper = GetSpringBean.getBean(VulnScanTaskRecordMapper.class);
            VulnScanTaskMapper scanTaskMapper = GetSpringBean.getBean(VulnScanTaskMapper.class);
            List<VulnScanTask> list = CommonAssemble.getCheckingScantask(ScannerEnums.QINGTENG_SCANNER.getCode(), ScanTypeEnums.HOST_SCAN.getCode(), Arrays.asList(1, 2));
            log.info("需要青藤执行资产扫描任务" + list.size());
            for (VulnScanTask vul : list) {
                try {
                    QtConfig scannerInfo = getQtConfig(vul.getEngineId());
                    QingtengUtils.login(scannerInfo);
                    if (QingtengUtils.getLoginStatus(scannerInfo)) {
                        CommonAssemble.startFail(vul, "青藤登陆失败,请检查配置");
                        log.error(vul.getTaskName() + " 青藤登陆失败请检查配置," + scannerInfo.getAddress() + " " + scannerInfo.getUsername());
                        continue;
                    }
                    VulnScanTaskRecord record = taskRecordMapper.getLastRecordByTaskId(vul.getId());
                    if (record == null) {
                        continue;
                    }
                    List<String> ipList = QingtengUtils.getAllHostIp(vul.getScanContentX());
                    if (ipList.size() < 1) {
                        log.error("{}({})任务无法解析出有效IP", vul.getTaskName(), vul.getId());
                        CommonAssemble.startFail(vul, ScanStatusEnums.SCAN_FINISH.getCode(), "任务无法解析出有效IP");
                        continue;
                    }

                    long start = System.currentTimeMillis();
                    VulnProcessFormMapper vulnProcessFormMapper = GetSpringBean.getBean(VulnProcessFormMapper.class);
                    LambdaQueryWrapper<VulnProcessForm> queryWrapper = new LambdaQueryWrapper<>();
                    queryWrapper.in(VulnProcessForm::getIp, ipList);
                    queryWrapper.eq(VulnProcessForm::getSource, ScannerEnums.QINGTENG_SCANNER.getCode());
                    queryWrapper.eq(VulnProcessForm::getCategory, ScanTypeEnums.HOST_SCAN.getCode());
                    List<VulnProcessForm> vulList = vulnProcessFormMapper.selectList(queryWrapper);
                    log.info("TaskName:{},addAssetCheck select VulProcessForm IP size:{},result size:{},耗时：{}", vul.getTaskName(), ipList.size(), vulList.size(), System.currentTimeMillis() - start);

                    HashMap<String, QingtengAgent> agentIdMaps = new HashMap<>(16);
                    for (VulnProcessForm vulnProcessForm : vulList) {
                        String agentId = vulnProcessForm.getAgentId();
                        // 存在AgentId
                        if (StringUtils.isNotBlank(agentId) && agentIdMaps.get(agentId) == null) {
                            // 校验Agent信息（AgentId为唯一数据）
                            QingtengAgent agent = QingtengUtils.getAgentById(scannerInfo, agentId);
                            if (agent != null) {
                                // 保存Agent信息
                                CrcRiskAutoDataQueue.getInstance().saveQingTengAgent(agent);
                                if (!agent.isBadStatus()) {
                                    // 保留在线的Agent
                                    agentIdMaps.put(agentId, agent);
                                } else {
                                    // agentId不在线,重新查
                                    agentId = null;
                                }
                            } else {
                                // agentId不正确,重新查
                                agentId = null;
                            }
                        }
                        if (StringUtils.isBlank(agentId)) {
                            // 复查操作不支持存在本地ip的漏洞出现AgentId 不存在或者不在线
                            QingtengAgent agent = QingtengUtils.getQtAgentByIp(scannerInfo, vulnProcessForm.getIp());
                            if (agent != null) {
                                agentId = agent.getId();
                                try {
                                    log.info("addAssetCheck update VulProcessForm AgentId:{},IP:{}", agentId, vulnProcessForm.getIp());
                                    // 漏洞同步AgentId
                                    LambdaUpdateWrapper<VulnProcessForm> uw = new LambdaUpdateWrapper<>();
                                    uw.eq(VulnProcessForm::getId, vulnProcessForm.getId());
                                    uw.set(VulnProcessForm::getAgentId, agentId);
                                    vulnProcessFormMapper.update(null, uw);
                                } catch (Exception e) {
                                    log.error("addAssetCheck error", e);
                                }
                                CrcRiskAutoDataQueue.getInstance().saveQingTengAgent(agent);
                                agentIdMaps.put(agentId, agent);
                            } else {
                                // 漏洞未检测出安装了青藤Agent对应漏洞状态修改为已归档
                                if ("1".equalsIgnoreCase(vulnProcessForm.getIsPushStatus())) {
                                    CommonAssemble.startFail("reviewPass", vulnProcessForm.getCode(), vulnProcessForm.getIp(), "对应Agent不在线");
                                } else {
                                    // 未推送漏洞删除逻辑
                                    CommonAssemble.updateVulData(vulnProcessForm.getId());
                                }
                            }
                        }
                    }
                    if (agentIdMaps.size() < 1) {
                        log.error("{}({})相关IP未检测出安装了青藤Agent", vul.getTaskName(), vul.getId());
                        CommonAssemble.startFail(vul, ScanStatusEnums.SCAN_FINISH.getCode(), "相关IP未检测出安装了青藤Agent");
                        continue;
                    }
                    for (String agentId : agentIdMaps.keySet()) {
                        QingtengAgent agent = agentIdMaps.get(agentId);
                        LambdaQueryWrapper<VulnScanTaskRecordLog> qlog = new LambdaQueryWrapper<>();
                        qlog.eq(VulnScanTaskRecordLog::getRecordId, record.getId());
                        qlog.eq(VulnScanTaskRecordLog::getUuid, agentId);
                        if (taskRecordLogMapper.selectCount(qlog) < 1) {
                            String id = addAssetCheckTask(scannerInfo, agentId, vul.getTaskName());
                            log.info("{} 成功下发清点任务：{}，AgentId:{}", vul.getTaskName(), agent.getIp(), agentId);
                            VulnScanTaskRecordLog log = new VulnScanTaskRecordLog();
                            log.setCheckId(id);
                            log.setIp(agent.getIp());
                            log.setTaskId(record.getTaskId());
                            log.setRecordId(record.getId());
                            log.setReviews(vul.getReviews());
                            log.setEngineId(vul.getEngineId());
                            log.setCreateTime(new Date());
                            log.setType(ScannerEnums.QINGTENG_SCANNER.getCode());
                            log.setUuid(agentId);
                            //任务状态(0 未开始 1 执行中 2 执行完成 3 执行失败)
                            log.setScanStatus(0);
                            //清点状态(0-待清点，1清点中，2清点成功，3清点失败)（业务不需要，预留给青藤）
                            log.setCheckStatus(1);
                            taskRecordLogMapper.insert(log);
                        } else {
                            log.info("{}--{},已在资产清点或执行中，AgentId:{}", vul.getTaskName(), agent.getIp(), agentId);
                        }
                    }
                    record.setTaskId(vul.getId());
                    record.setScanStartTime(new Date());
                    record.setUpdateTime(new Date());
                    record.setIpTotal((long) ipList.size());
                    taskRecordMapper.updateVulnScanTaskRecord(record);

                    vul.setScanStatus(ScanStatusEnums.SCAN_ING.getCode());
                    vul.setUpdateTime(new Date());
                    scanTaskMapper.updateVulnScanTask(vul);
                } catch (Exception e) {
                    log.error(e.getMessage(), e);
                }
            }
        } catch (
                Exception e) {
            log.error(e.getMessage(), e);
        }
    }

    /**
     * 添加青藤资产弱口令任务
     */
    public static void addWeakCheck() {
        try {
            VulnScanTaskRecordLogMapper taskRecordLogMapper = GetSpringBean.getBean(VulnScanTaskRecordLogMapper.class);
            VulnScanTaskRecordMapper taskRecordMapper = GetSpringBean.getBean(VulnScanTaskRecordMapper.class);
            VulnScanTaskMapper scanTaskMapper = GetSpringBean.getBean(VulnScanTaskMapper.class);
            List<VulnScanTask> list = CommonAssemble.getCheckingScantask(ScannerEnums.QINGTENG_SCANNER.getCode(), ScanTypeEnums.WEAK_PASS_SCAN.getCode(), Arrays.asList(1, 2));
            log.info("需要青藤执行资产弱口令任务" + list.size());
            for (VulnScanTask vul : list) {
                try {
                    QtConfig scannerInfo = getQtConfig(vul.getEngineId());
                    QingtengUtils.login(scannerInfo);
                    if (QingtengUtils.getLoginStatus(scannerInfo)) {
                        CommonAssemble.startFail(vul, "青藤登陆失败,请检查配置");
                        log.error("青藤登陆失败请检查配置," + scannerInfo.getAddress() + " " + scannerInfo.getUsername());
                        continue;
                    }
                    VulnScanTaskRecord record = taskRecordMapper.getLastRecordByTaskId(vul.getId());
                    if (record == null) {
                        continue;
                    }
                    List<String> ipList = QingtengUtils.getAllHostIp(vul.getScanContentX());
                    if (ipList.size() < 1) {
                        log.error("{}({})任务无法解析出有效IP", vul.getTaskName(), vul.getId());
                        CommonAssemble.startFail(vul, "任务无法解析出有效IP");
                        continue;
                    }
                    HashMap<String, String> agentIds = new HashMap<>();
                    for (String ip : ipList) {
                        QingtengAgent agent = QingtengUtils.getQtAgentByIp(scannerInfo, ip);
                        if (agent != null) {
                            CrcRiskAutoDataQueue.getInstance().saveQingTengAgent(agent);
                        }
                        if (agent != null) {
                            agentIds.put(agent.getId(), ip);
                        }
                    }
                    if (agentIds.size() < 1) {
                        log.error("{}({})相关IP未检测出安装了青藤Agent", vul.getTaskName(), vul.getId());
                        CommonAssemble.startFail(vul, "相关IP未检测出安装了青藤Agent");
                        continue;
                    }

                    for (String agentId : agentIds.keySet()) {
                        String ip = agentIds.get(agentId);
                        LambdaQueryWrapper<VulnScanTaskRecordLog> qlog = new LambdaQueryWrapper<>();
                        qlog.eq(VulnScanTaskRecordLog::getRecordId, record.getId());
                        qlog.eq(VulnScanTaskRecordLog::getIp, ip);
                        if (taskRecordLogMapper.selectCount(qlog) < 1) {
                            VulnScanTaskRecordLog log = new VulnScanTaskRecordLog();
                            log.setIp(ip);
                            log.setTaskId(record.getTaskId());
                            log.setRecordId(record.getId());
                            log.setEngineId(vul.getEngineId());
                            log.setCreateTime(new Date());
                            log.setType(ScannerEnums.QINGTENG_SCANNER.getCode());
                            log.setUuid(agentId);
                            //任务状态(0 未开始 1 执行中 2 执行完成 3 执行失败)
                            log.setScanStatus(0);
                            taskRecordLogMapper.insert(log);
                        } else {
                            log.info("任务：{}，content：{},已在复查或执行中", vul.getTaskName(), ip);
                        }
                    }
                    record.setTaskId(vul.getId());
                    record.setScanStartTime(new Date());
                    record.setUpdateTime(new Date());
                    record.setIpTotal((long) ipList.size());
                    taskRecordMapper.updateVulnScanTaskRecord(record);

                    vul.setScanStatus(ScanStatusEnums.SCAN_ING.getCode());
                    vul.setUpdateTime(new Date());
                    scanTaskMapper.updateVulnScanTask(vul);
                } catch (Exception e) {
                    log.error(e.getMessage(), e);
                }
            }
        } catch (Exception e) {
            log.error(e.getMessage(), e);
        }
    }

    /**
     * 同步资产清点任务
     */
    public static void syncAssetCheck() {
        VulnScanTaskRecordLogMapper taskRecordLogMapper = GetSpringBean.getBean(VulnScanTaskRecordLogMapper.class);
        try {
            VulnScanTaskRecordLog q = new VulnScanTaskRecordLog();
            q.setCheckStatus(1);//没开始扫描
            q.setScanType(ScanTypeEnums.HOST_SCAN.getCode());
            q.setEngineName(ScannerEnums.QINGTENG_SCANNER.getCode());
            List<VulnScanTaskRecordLog> list = taskRecordLogMapper.getAllRecordLogList(q);
            for (VulnScanTaskRecordLog recordLog : list) {
                QtConfig scannerInfo = getQtConfig(recordLog.getEngineId());
                boolean update = false;
                if ("666".equals(recordLog.getCheckId())) {
                    // 待处置
                    repairAllByAgent(recordLog.getIp(), recordLog.getUuid(), "reviewReject", "下发资产清点任务，青藤Agent主机不在线");
                    recordLog.setResult("青藤Agent主机不在线");
                    update = true;
                } else if ("999".equals(recordLog.getCheckId())) {
                    // 已归档
                    repairAllByAgent(recordLog.getIp(), recordLog.getUuid(), "reviewPass", "下发资产清点任务，青藤Agent已被删除或卸载");
                    recordLog.setResult("青藤Agent主机已被删除");
                    update = true;
                } else if (StringUtils.isBlank(recordLog.getCheckId())) {
                    log.warn("Ip:{}-AgentId{}获取下发清点任务，为空！", recordLog.getIp(), recordLog.getUuid());
                    recordLog.setResult("青藤异常或者网络波动");
                    update = true;
                }
                if (update) {
                    recordLog.setCheckStatus(3);
                    taskRecordLogMapper.updateVulnScanTaskRecordLog(recordLog);
                    continue;
                }

                //无法清点的资产，就直接下发漏洞扫描
                long interval = 60 * 2;
                //无法清点的资产，就直接下发漏洞扫描
                if (!QingtengUtils.getAssetsTaskStatus(scannerInfo, recordLog.getCheckId())) {
                    long diff = (System.currentTimeMillis() - recordLog.getCreateTime().getTime()) / 1000 / 60;
                    if (diff < interval) {
                        log.info(recordLog.getIp() + "资产清点未完成");
                        continue;
                    } else {
                        recordLog.setResult("资产清点超过阀值时间未清点完成");
                        log.error("资产清点超过阀值时间未清点完成，防止阻塞下发扫描任务，阀值（分钟）：" + interval);
                    }
                } else {
                    log.info(recordLog.getIp() + "资产清点完成@@");
                    recordLog.setResult("资产清点完成");
                }
                recordLog.setCheckStatus(2);
                taskRecordLogMapper.updateVulnScanTaskRecordLog(recordLog);
            }
        } catch (Exception e) {
            log.error(e.getMessage(), e);
        }
    }


    /**
     * 资产清点
     * id 为空 青藤异常或者网络波动
     * id 666 青藤Agent主机不在线
     * id 999 青藤Agent主机已被删除
     * id 正常数据
     */
    private static String addAssetCheckTask(QtConfig scannerInfo, String agentId, String taskName) {
        String id = "";
        JSONObject param = new JSONObject();
        param.put("type", 1);
        param.put("group", new JSONArray());
        param.put("agentIds", Collections.singletonList(agentId));
        //POST /external/api/assets/host/{win|linux}/refresh
        String url = "/external/api/assets/linux/refresh";
        if (QingtengUtils.isWindowsAgent(agentId)) {
            url = "/external/api/assets/win/refresh";
        }
        try (CloseableHttpResponse response = QingtengUtils.post(scannerInfo, url, param)) {
            if (scannerInfo.isGoodConfig()) {
                try {
                    if (response == null) {
                        return id;
                    }
                    int code = response.getStatusLine().getStatusCode();
                    String GetData = DataUtils.toBodyString(response.getEntity());
                    if (code == 200 || code == 500) {
                        JSONObject result = JsonUtils.parse(GetData);
                        if (result.containsKey("id")) {
                            id = result.getString("id");
                        }
                        if (result.containsKey("errorMessage") && "Agent主机不在线".equals(result.getString("errorMessage"))) {
                            id = "666";
                        }
                        if (result.containsKey("errorMessage") && result.getString("errorMessage").contains("已被删除")) {
                            id = "999";
                        }
                        log.error(taskName + ",添加资产清点：" + id + " " + JsonUtils.getStr(result, "errorMessage"));
                    } else {
                        log.error(taskName + ",2添加资产清点错误！清ID：" + agentId);
                    }
                    if (StringUtils.isBlank(id)) {
                        log.error("####资产清单没有返回：" + GetData);
                    }
                } catch (Exception e) {
                    log.error(e.getMessage(), e);
                }
            }
        } catch (Exception e) {
            log.error(e.getMessage(), e);
        }
        return id;
    }

    public static void addTask() {
        try {
            VulnScanTaskRecordLogMapper taskRecordLogMapper = GetSpringBean.getBean(VulnScanTaskRecordLogMapper.class);
            VulnScanTaskRecordLog q = new VulnScanTaskRecordLog();
            q.setScanStatus(0);//没开始扫描
            q.setCheckStatus(2);//已完成清点
            q.setScanType(ScanTypeEnums.HOST_SCAN.getCode());
            q.setEngineName(ScannerEnums.QINGTENG_SCANNER.getCode());
            List<VulnScanTaskRecordLog> recordList = taskRecordLogMapper.getAllRecordLogList(q);
            log.info("青藤带下发扫描任务:" + recordList.size());
            for (VulnScanTaskRecordLog recordLog : recordList) {
                try {
                    QtConfig scannerInfo = getQtConfig(recordLog.getEngineId());
                    StringBuilder sb = new StringBuilder();
                    try {
                        String name = IdGen.uuid8() + "/" + recordLog.getIp();
                        String agentId = recordLog.getUuid();
                        // 不存在AgentId数据不下发扫描
                        if (agentId == null) {
                            recordLog.setScanStatus(3);
                            log.error(recordLog.getTaskName() + ",添加扫描任务失败,不存在AgentId");
                            sb.append(recordLog.getIp()).append("添加任务失败,不存在AgentId").append(";");
                        } else {
                            // 获取agentId 对应配置
                            QingtengAgentMapper agentMapper = GetSpringBean.getBean(QingtengAgentMapper.class);
                            QingtengAgent agent = agentMapper.selectById(agentId);
                            if (agent == null) {
                                recordLog.setScanStatus(3);
                                log.error(recordLog.getTaskName() + ",添加任务失败,不存在Agent,agentId:" + agentId);
                                sb.append(recordLog.getIp()).append("添加任务失败,不存在Agent,agentId:").append(agentId).append(";");
                            } else {
                                String jobId = QingtengUtils.AddTask(scannerInfo, name, agent);
                                if (jobId.length() > 0) {
                                    if ("666".equals(recordLog.getCheckId())) {
                                        // 待处置
                                        repairAllByAgent(recordLog.getIp(), recordLog.getUuid(), "reviewReject", "下发扫描漏洞任务，青藤Agent主机不在线");
                                        sb.append(recordLog.getIp()).append("下发扫描任务完成，但Agent主机不在线").append(DateUtils.getDateTimeString1(new Date())).append("\n");
                                        recordLog.setCheckStatus(3);
                                    } else if ("999".equals(recordLog.getCheckId())) {
                                        // 已归档
                                        repairAllByAgent(recordLog.getIp(), recordLog.getUuid(), "reviewPass", "下发扫描漏洞任务，青藤Agent已被删除或卸载");
                                        recordLog.setCheckStatus(3);
                                        sb.append(recordLog.getIp()).append("下发扫描任务完成，但Agent已被删除或卸载").append(DateUtils.getDateTimeString1(new Date())).append("\n");
                                    } else {
                                        recordLog.setScanStatus(1);
                                        sb.append(recordLog.getIp()).append("下发扫描任务扫描完成").append(DateUtils.getDateTimeString1(new Date())).append("\n");
                                    }
                                    recordLog.setJobId(jobId);
                                    //taskRecordLogMapper.updateVulnScanTaskRecordLog(recordLog);
                                    addBaseTask(scannerInfo, recordLog, agent);
                                } else {
                                    // 待处置
                                    repairAllByAgent(recordLog.getIp(), recordLog.getUuid(), "reviewReject", "下发扫描漏洞任务，AddTask 异常");
                                    recordLog.setScanStatus(3);
                                    log.error(recordLog.getTaskName() + ",添加任务失败=" + recordLog.getIp() + " agentId:" + agentId);
                                    sb.append(recordLog.getIp()).append("添加任务失败").append(";");
                                }
                            }
                        }
                    } catch (Exception e) {
                        log.error(e.getMessage(), e);
                    }
                    recordLog.setResult(sb.toString());
                    taskRecordLogMapper.updateVulnScanTaskRecordLog(recordLog);
                } catch (Exception e) {
                    log.error(e.getMessage(), e);
                }
            }
        } catch (Exception e) {
            log.error(e.getMessage(), e);
        }
    }

    /**
     * 添加基线任务
     *
     * @param scannerInfo 配置
     * @param recordLog   任务信息
     */
    private static void addBaseTask(QtConfig scannerInfo, VulnScanTaskRecordLog recordLog, QingtengAgent agent) {
        try {
            String ruleId = "";
            String linuxRuleId = "5fba7c27fc524b1a0831";
            String winRuleId = "9054258982658c8e";
            if (agent == null || agent.isBadStatus()) {
                log.error("Agent不存在，创建基线任务失败=" + recordLog.getIp());
                return;
            }
            String osType = "1";
            ruleId = linuxRuleId;
            if (QingtengUtils.isWindowsAgent(agent)) {
                osType = "2";
                ruleId = winRuleId;
            }
            boolean isCron = false;
            String name = recordLog.getTaskName();

            /*
             * 创建任务
             */
            String specId = QingtengUtils.createBaselineJob(scannerInfo, osType, ruleId, isCron, name, "基线自动扫描", Collections.singletonList(agent.getId()));
            if (StringUtils.isBlank(specId)) {
                log.error("创建基线任务失败=" + name);
                return;
            }
            /*
             * 执行任务
             */
            String jobId = QingtengUtils.exeBaselineJob(scannerInfo, osType, specId);
            if (StringUtils.isBlank(jobId)) {
                log.error("执行基线任务失败=" + name);
                return;
            }

            log.info("任务下发成功" + name + " -> specId:" + specId + " jobId:" + recordLog.getJobId());
        } catch (Exception e) {
            log.error(e.getMessage(), e);
        }
    }

    public static void getTask() {
        try {
            CommonAssemble.engineMap.forEach((k, v) -> {
                if (ScannerEnums.QINGTENG_SCANNER.getCode().equals(v.getEquipmentManufacture())) {
                    getTask(getQtConfig(k));
                }
            });
        } catch (Exception e) {
            log.error(e.getMessage(), e);
        }
    }

    private static void getTask(QtConfig scannerInfo) {
        VulnScanTaskRecordLogMapper taskRecordLogMapper = GetSpringBean.getBean(VulnScanTaskRecordLogMapper.class);
        try {
            VulnScanTaskRecordLog q = new VulnScanTaskRecordLog();
            q.setScanStatus(1);//扫描中
            q.setScanType(ScanTypeEnums.HOST_SCAN.getCode());
            q.setEngineName(ScannerEnums.QINGTENG_SCANNER.getCode());
            List<VulnScanTaskRecordLog> recordList = taskRecordLogMapper.getAllRecordLogList(q);
            log.info("青藤资产复查扫描中任务" + recordList.size());
            for (VulnScanTaskRecordLog recordLog : recordList) {
                String agentId = recordLog.getUuid();
                recordLog.setScanStatus(3);
                if (agentId == null) {
                    log.error(recordLog.getTaskName() + ",下发扫描漏洞任务完成,不存在AgentId");
                    recordLog.setResult("下发扫描漏洞任务完成,不存在AgentId");
                } else {
                    int retStatus = QingtengUtils.GetTaskStatus(scannerInfo, recordLog.getJobId(), agentId);
                    // 为 0 时，继续扫描 Running
                    if (retStatus == 0) {
                        recordLog.setScanStatus(1);
                    } else {
                        try {
                            if (retStatus == -1) {
                                log.info("GetTask-IP:{}对应AgentId:{},被删除或不存在", recordLog.getIp(), agentId);
                                // 待处置
                                repairAllByAgent(recordLog.getIp(), agentId, "reviewReject", "查询扫描任务状态，但青藤Agent主机不在线");
                                recordLog.setResult("青藤Agent主机不在线");
                            } else if (retStatus == 1) {
                                // 作业执行漏洞结果查询
                                JSONArray taskList = QingtengUtils.GetTask(scannerInfo, recordLog.getJobId(), agentId);
                                // 没有漏洞
                                if (taskList.size() == 0) {
                                    // 判断是否任务执行失败
                                    if (QingtengUtils.GetTaskStats(scannerInfo, recordLog.getJobId(), agentId)) {
                                        recordLog.setScanStatus(2);
                                        // 都已经修复,已归档
                                        repairAllByAgent(recordLog.getIp(), agentId, "reviewPass", null);
                                    } else {
                                        // 待处置
                                        repairAllByAgent(recordLog.getIp(), agentId, "reviewReject", "青藤扫描任务执行失败");
                                        recordLog.setResult("青藤扫描任务执行失败(存在失败主机)");
                                        log.info("GetTask 青藤扫描任务执行失败(存在失败主机)@@@@IP:" + recordLog.getIp() + "AgentId:" + agentId);
                                    }
                                } else {
                                    recordLog.setScanStatus(2);
                                    // 查询作业执行失败主机
                                    HashMap<String, String> errVulCheckList = QingtengUtils.GetErrorHost(scannerInfo, recordLog.getJobId(), agentId);
                                    log.info("查询作业执行失败主机IP:" + recordLog.getIp() + "AgentId:" + agentId + "GetTask定时青藤获取漏洞数：" + taskList.size() + " 复查失败的漏洞：" + JSON.toJSONString(errVulCheckList));
                                    // 处理漏洞
                                    handle(taskList, recordLog, errVulCheckList, true);
                                }
                            } else if (retStatus == 2) {
                                // 待处置
                                repairAllByAgent(recordLog.getIp(), agentId, "reviewReject", "青藤扫描任务执行失败");
                                recordLog.setResult("青藤扫描任务执行失败");
                                log.info("GetTask 青藤扫描任务执行失败@@@@IP:" + recordLog.getIp() + "AgentId:" + agentId);
                            } else if (retStatus == -2) {
                                // 已归档
                                repairAllByAgent(recordLog.getIp(), agentId, "reviewPass", "查询扫描任务状态，青藤Agent已被删除或卸载");
                                recordLog.setResult("青藤Agent已被删除或卸载");
                                log.info("GetTask 青藤扫描任务执行失败(Agent已被删除或卸载)@@@@IP:" + recordLog.getIp() + "AgentId:" + agentId);
                            }
                        } catch (Exception e) {
                            log.error(e.getMessage(), e);
                        }
                    }
                }
                recordLog.setUpdateTime(new Date());
                taskRecordLogMapper.updateVulnScanTaskRecordLog(recordLog);
            }
        } catch (Exception e) {
            log.error(e.getMessage(), e);
        }
    }

    public static void allRiskHandle(JSONArray vul, VulnScanTaskRecordLog recordLog, String localIp, boolean msg) {
        VulnProcessFormMapper vulnProcessFormMapper = GetSpringBean.getBean(VulnProcessFormMapper.class);
        List<VulnProcessForm> vulList;
        String agentId = recordLog.getUuid();

        // 先根据最新逻辑查询数据
        LambdaQueryWrapper<VulnProcessForm> vq = new LambdaQueryWrapper<>();
        vq.eq(VulnProcessForm::getAgentId, agentId);
        vq.eq(VulnProcessForm::getSource, ScannerEnums.QINGTENG_SCANNER.getCode());
        vq.eq(VulnProcessForm::getCategory, ScanTypeEnums.HOST_SCAN.getCode());
        vulList = vulnProcessFormMapper.selectList(vq);

        // 正常逻辑
        List<VulnProcessForm> repairedList = new LinkedList<>();
        List<VulnProcessForm> unRepairedList = new LinkedList<>();
        List<VulnProcessForm> newVulList = new LinkedList<>();
        log.info(recordLog.getIp() + " @@@AgentId：" + agentId + " 库存漏洞：" + vulList.size() + " 当前有漏洞：" + vul.size());
        int newTotal = 0;
        int dropTotal = 0;
        //扫描到漏洞
        for (int b = 0; b < vul.size(); b++) {
            JSONObject raw = vul.getJSONObject(b);
            VulnProcessForm curVul = getVulFromJson(raw, agentId, recordLog);
            if (curVul == null) {
                dropTotal++;
                continue;
            }
            // 查询数据现存漏洞白名单状态
            String whiteStatus = vulnProcessFormMapper.selectWhiteStatus(curVul.getId());
            //白名单
            if ("2".equals(whiteStatus) || WhiteListQuery.isWhiteList(curVul)) {
                dropTotal++;
                continue;
            }
            newVulList.add(curVul);
            //是否新漏洞
            boolean isnew = true;
            if (StringUtils.isNotBlank(whiteStatus)) {
                vulnProcessFormMapper.stillExist(curVul.getId());
                isnew = false;
            }

            if (isnew) {
                //新漏洞
                if (CommonAssemble.saveVul(curVul)) {
                    newTotal++;
                } else {
                    dropTotal++;
                }
            }
        }
        //已修复的漏洞判断
        for (VulnProcessForm oldVul : vulList) {
            boolean isRepair = true;
            for (VulnProcessForm newVul : newVulList) {
                //漏洞名称 节点IP是否相同
                if (newVul.getId().equalsIgnoreCase(oldVul.getId())) {
                    // 相同漏洞更新数据
                    if (newVul.getDescription() != null) {
                        oldVul.setDescription(newVul.getDescription());
                    }
                    if (newVul.getValidInfo() != null) {
                        oldVul.setValidInfo(newVul.getValidInfo());
                    }
                    if (newVul.getSolution() != null) {
                        oldVul.setSolution(newVul.getSolution());
                    }
                    if ("0".equals(oldVul.getIsPushStatus())) {
                        oldVul.setAffiliationDeptNodeId(newVul.getAffiliationDeptNodeId());
                        oldVul.setAffiliationDeptName(newVul.getAffiliationDeptName());
                    }
                    if (!newVul.getIp().equals(oldVul.getIp())) {
                        log.info("NEW#全量漏洞-当前未修复漏洞ip数据不一致,oldIp:{},newIp={}", oldVul.getIp(), newVul.getIp());
                        oldVul.setIp(newVul.getIp());
                    }
                    oldVul.setAgentId(newVul.getAgentId());
                    isRepair = false;
                    break;
                }
            }
            //漏洞是否已修复
            if (isRepair) {
                repairedList.add(oldVul);
            } else {
                //未修复
                unRepairedList.add(oldVul);
            }
        }
        log.info(recordLog.getIp() + " @@@AgentId：" + agentId + " @@@@@@@@@@@@库存漏洞：" + vulList.size() + " 丢弃漏洞：" + dropTotal + " 新增漏洞：" + newTotal + " 未修复漏洞：" + unRepairedList.size() + " 已修复漏洞：" + repairedList.size());

        if (repairedList.size() > 0) {
            for (VulnProcessForm vulnProcessForm : repairedList) {
                CommonAssemble.repairedVul(vulnProcessForm, true);
            }
        }
        if (unRepairedList.size() > 0) {
            for (VulnProcessForm vulnProcessForm : unRepairedList) {
                CommonAssemble.unRepairedVul(vulnProcessForm, true);
            }
        }

        if (msg) {
            CommonAssemble.sendMsg(vulList, ScannerEnums.QINGTENG_SCANNER.getName(), ScanTypeEnums.HOST_SCAN.getCode(), recordLog.getIp(), newTotal, unRepairedList.size(), repairedList.size());
        }
    }

    public static void handle(JSONArray vuln, VulnScanTaskRecordLog recordLog, HashMap<String, String> errVulCheckList, boolean msg) {
        VulnProcessFormMapper vulnProcessFormMapper = GetSpringBean.getBean(VulnProcessFormMapper.class);
        AssetMapper assetMapper = GetSpringBean.getBean(AssetMapper.class);
        // 先根据最新逻辑查询原有漏洞数据
        LambdaQueryWrapper<VulnProcessForm> vq = new LambdaQueryWrapper<>();
        vq.eq(VulnProcessForm::getAgentId, recordLog.getUuid());
        vq.eq(VulnProcessForm::getSource, ScannerEnums.QINGTENG_SCANNER.getCode());
        vq.eq(VulnProcessForm::getCategory, ScanTypeEnums.HOST_SCAN.getCode());
        List<VulnProcessForm> vulList = vulnProcessFormMapper.selectList(vq);
        List<VulnProcessForm> repairedList = new LinkedList<>();
        List<VulnProcessForm> unRepairedList = new LinkedList<>();
        List<VulnProcessForm> newVulList = new LinkedList<>();
        log.info(recordLog.getIp() + " AgentId: " + recordLog.getUuid() + " 库存漏洞：" + vulList.size() + " 当前有漏洞：" + vuln.size());
        int newTotal = 0;
        int dropTotal = 0;
        //扫描到漏洞
        for (int b = 0; b < vuln.size(); b++) {
            JSONObject raw = vuln.getJSONObject(b);
            String agentId = JsonUtils.getStr(raw, "agentId");
            String localIp = null;
            String ip = JsonUtils.getStr(raw, "displayIp");
            // 增加本地ip校验
            if (ip.startsWith("192.168.") || ip.startsWith("172.16.")) {
                String connectionIp = JsonUtils.getStr(raw, "connectionIp");
                if (IpUtils.isIp(connectionIp)) {
                    localIp = ip;
                    ip = connectionIp;
                }
            }
            if (!StringUtils.isBlank(agentId)) {
                QingtengAgent agent = new QingtengAgent();
                agent.setId(agentId);
                agent.setIp(ip);
                if (StringUtils.isNotBlank(localIp)) {
                    agent.setLocalIp(localIp);
                }
                agent.setBizGroup(JsonUtils.getStr(raw, "bizGroup"));
                agent.setBizGroupId(JsonUtils.getStr(raw, "bizGroupId"));
                agent.setLastOnlineTime(DateUtils.parseDateTime1(JsonUtils.getStr(raw, "lastOnlineTime"), DateUtils.DATE_FORMAT_STRING1));
                agent.setInstallTime(DateUtils.parseDateTime1(JsonUtils.getStr(raw, "installTime"), DateUtils.DATE_FORMAT_STRING1));
                agent.setOfflineDays(JsonUtils.getInt(raw, "offlineDays"));
                agent.setAgentStatus(JsonUtils.getStr(raw, "agentStatus"));
                agent.setAgentVersion(JsonUtils.getStr(raw, "agentVersion"));
                agent.setOnlineStatus(JsonUtils.getStr(raw, "onlineStatus"));
                CrcRiskAutoDataQueue.getInstance().saveQingTengAgent(agent);
            }
            Asset asset = assetMapper.selectAssetByInnerIp(ip);

            if (asset == null || asset.getAffiliationDeptNodeId() == null) {
                asset = new Asset();
                asset.setInternalIp(ip);
                String platform = JsonUtils.getStr(raw, "platform");//操作系统
                asset.setOs(platform);
                String bizGroup = JsonUtils.getStr(raw, "bizGroup");//业务组
                asset.setOfficeName(bizGroup);
                String hostLocation = JsonUtils.getStr(raw, "hostLocation");//机房位置
                asset.setGeographicLocation(hostLocation);
                String kernelVersion = JsonUtils.getStr(raw, "kernelVersion");//内核版本
                if (StringUtils.isNotBlank(kernelVersion)) {
                    asset.setOs(platform + kernelVersion);
                }
                asset.setType("服务器");
                asset.setSubType("通用");
                asset.setSource(AssetSourceEnums.QINGTENG_CMDB.getCode());
                String username = JsonUtils.getStr(raw, "chargeName");//负责人
                asset.setAssetUser(username);
                CrcAssetSyncQueue.getInstance().saveAsset(asset);
                // 同步负责人
                CrcAssetSyncQueue.getInstance().saveAssetPerson(asset.getInternalIp(), username, "1");
            }
            String vulId = JsonUtils.getStr(raw, "vulId");
            if (StringUtils.isNotBlank(vulId) && errVulCheckList.containsKey(vulId)) {
                log.error("该漏洞检查失败：{}", errVulCheckList.get(vulId));
                dropTotal++;
                continue;
            }
            VulnProcessForm curVul = getVulFromJson(raw, agentId, recordLog);
            if (curVul == null) {
                dropTotal++;
                continue;
            }
            //白名单
            if (WhiteListQuery.isWhiteList(curVul)) {
                dropTotal++;
                continue;
            }
            newVulList.add(curVul);
            //是否新漏洞
            boolean isnew = true;
            LambdaQueryWrapper<VulnProcessForm> q = new LambdaQueryWrapper<>();
            q.eq(VulnProcessForm::getId, curVul.getId());
            if (vulnProcessFormMapper.selectCount(q) > 0) {
                vulnProcessFormMapper.stillExist(curVul.getId());
                isnew = false;
            }

            if (isnew) {
                //新漏洞
                if (CommonAssemble.saveVul(curVul)) {
                    newTotal++;
                } else {
                    dropTotal++;
                }
            }
        }
        //已修复的漏洞判断
        for (VulnProcessForm oldVul : vulList) {
            boolean isRepair = true;
            for (VulnProcessForm newVul : newVulList) {
                //漏洞名称 节点IP是否相同
                if (newVul.getId().equalsIgnoreCase(oldVul.getId())) {
                    // 相同漏洞更新数据
                    if (newVul.getDescription() != null) {
                        oldVul.setDescription(newVul.getDescription());
                    }
                    if (newVul.getValidInfo() != null) {
                        oldVul.setValidInfo(newVul.getValidInfo());
                    }
                    if (newVul.getSolution() != null) {
                        oldVul.setSolution(newVul.getSolution());
                    }
                    if ("0".equals(oldVul.getIsPushStatus())) {
                        oldVul.setAffiliationDeptNodeId(newVul.getAffiliationDeptNodeId());
                        oldVul.setAffiliationDeptName(newVul.getAffiliationDeptName());
                    }
                    if (!newVul.getIp().equals(oldVul.getIp())) {
                        log.info("复查操作-当前未修复漏洞ip数据不一致,oldIp:{},newIp={}", oldVul.getIp(), newVul.getIp());
                        oldVul.setIp(newVul.getIp());
                    }
                    isRepair = false;
                    break;
                }
            }
            //漏洞已修复
            if (isRepair) {
                repairedList.add(oldVul);
            } else {
                //未修复
                unRepairedList.add(oldVul);
            }
        }
        log.info(recordLog.getIp() + " AgentId: " + recordLog.getUuid() + " @@@@@@@@@@@@库存漏洞：" + vulList.size() + " 丢弃漏洞：" + dropTotal + " 新增漏洞：" + newTotal + " 未修复漏洞：" + unRepairedList.size() + " 修复漏洞：" + repairedList.size());
        if (repairedList.size() > 0) {
            repairedList.forEach((CommonAssemble::repairedVul));
        }
        if (unRepairedList.size() > 0) {
            unRepairedList.forEach((CommonAssemble::unRepairedVul));
        }
        if (msg) {
            if (StringUtils.isNotBlank(recordLog.getReviews())) {
                CommonAssemble.sendMsgByCodeList(Arrays.asList(recordLog.getReviews().split(",")), ScannerEnums.QINGTENG_SCANNER.getName(), ScanTypeEnums.HOST_SCAN.getCode(), recordLog.getIp(), newTotal, unRepairedList.size(), repairedList.size());
            } else {
                CommonAssemble.sendMsg(vulList, ScannerEnums.QINGTENG_SCANNER.getName(), ScanTypeEnums.HOST_SCAN.getCode(), recordLog.getIp(), newTotal, unRepairedList.size(), repairedList.size());
            }
        }
    }

    /**
     * 获取漏洞详情
     *
     * @param json      原始
     * @param agentId   agentId
     * @param recordLog Ip
     * @return 漏洞信息
     */
    public static VulnProcessForm getVulFromJson(JSONObject json, String agentId, VulnScanTaskRecordLog recordLog) {
        String vulName = JsonUtils.getStr(json, "vulName");
        if (StringUtils.isBlank(vulName)) {
            vulName = JsonUtils.getStr(json, "title");
        }
        if (StringUtils.isBlank(vulName)) {
            return null;
        }
        // 判断是否私网ip (recordLog内ip已经过处理，为非私网ip)
        if (!recordLog.getIp().equals(json.getString("displayIp"))) {
            vulName = vulName + "_" + json.getString("displayIp");
        }
        log.info("当前漏洞name ={},获取到的valid_info-checkInfo验证信息={},获取到的valid_info-pocCheckInfo验证信息={}", vulName, JsonUtils.getStr(json, "checkInfo"), JsonUtils.getStr(json, "pocCheckInfo"));
        String desc = JsonUtils.getStr(json, "desc");
        if (StringUtils.isBlank(desc)) {
            desc = JsonUtils.getStr(json, "description");
        }
        String solution = JsonUtils.getStr(json, "remedDescription");
        if (StringUtils.isBlank(solution)) {
            solution = JsonUtils.getStr(json, "remedDesc");
        }
        Date firstCheckDate = JsonUtils.getDate(json, "firstCheckTime");
        Date publicDate = JsonUtils.getDateX(json, "publicDate");
        String vulType = JsonUtils.getStr(json, "category");
        for (String data : vulType.replace("]", "").replace("[", "").split(",")) {
            if (StringUtils.isNotBlank(data)) {
                String key = data.trim();
                if (typeMap.containsKey(key)) {
                    vulType = typeMap.get(key);
                    break;
                }
            }
        }

        //0:低危, 1:中危, 2:高危, 3:严重
        int level = 0;
        switch (JsonUtils.getInt(json, "severity")) {
            case 0:
                break;
            case 2:
                level = 1;
                break;
            case 3:
                level = 2;
                break;
            case 4:
                level = 3;
                break;
            default:
        }
        String filter = SyncSecConfigLoad.getRemarkValue(SyncSecConstants.QT_STANDARD_SYNC_ENABLE);
        try {
            boolean flag = false;
            if (filter != null && filter.contains("=") && filter.contains("level")) {
                String filterLevel = filter.split("=")[1];
                String slevel = JsonUtils.getStr(json, "severity");
                for (String fl : filterLevel.split(",")) {
                    if (StringUtils.isNotBlank(slevel) && slevel.equalsIgnoreCase(fl)) {
                        flag = true;
                        break;
                    }
                }
            } else {
                flag = true;
            }
            if (!flag) {
                return null;
            }
        } catch (Exception e) {
            log.error(e.getMessage(), e);
        }
        //漏洞特征 1：存在EXP 2：存在POC 3：远程执行 4：本地提权 5：内核漏洞
        List<String> feats = new ArrayList<>();
        try {
            if (json.containsKey("hasExp")) {
                if (json.getBoolean("hasExp") == null || json.getBoolean("hasExp")) {
                    feats.add("1");
                }
            }
            if (json.containsKey("hasPoc")) {
                if (json.getBoolean("hasPoc") == null || json.getBoolean("hasPoc")) {
                    feats.add("2");
                }
            }
            if (json.containsKey("remote")) {
                if (json.getBoolean("remote") == null || json.getBoolean("remote")) {
                    feats.add("3");
                }
            }
            if (json.containsKey("localEscalation")) {
                if (json.getBoolean("localEscalation") == null || json.getBoolean("localEscalation")) {
                    feats.add("4");
                }
            }
            if (json.containsKey("kernel")) {
                if (json.getBoolean("kernel") == null || json.getBoolean("kernel")) {
                    feats.add("5");
                }
            }
        } catch (Exception e) {
            log.error(e.getMessage(), e);
        }
        String CVE = "";
        if (json.getJSONArray("cves") != null) {
            CVE = json.getJSONArray("cves").toString()
                    .replace("\"", "").replace("[", "").replace("]", "");
        }


        VulnProcessForm vul = new VulnProcessForm();
        vul.setIp(recordLog.getIp());
        vul.setAgentId(agentId);
        vul.setEngineId(String.valueOf(recordLog.getEngineId()));
        //修复影响：0-未知；1-无需重启；2-服务重启；3系统重启 （仅linux）
        vul.setVulHostInfluence(String.valueOf(JsonUtils.getInt(json, "restartOpts")));
        vul.setRefLink(JsonUtils.getStr(json, "expRefs"));
        vul.setCvss(CvssUtils.getScore(JsonUtils.getStr(json, "cvss")));
        vul.setVulnName(vulName);
        vul.setCode(String.format("VUL_%s", IdGen.uuid8()));
        vul.setLevel(String.valueOf(level));
        vul.setSource(ScannerEnums.QINGTENG_SCANNER.getCode());
        String id = Md5Utils.hash(agentId + "#" + vulName + "#" + CVE + "#" + vul.getSource());
        vul.setId(id);
        vul.setVulnType(vulType);
        vul.setCategory(ScanTypeEnums.HOST_SCAN.getCode());
        vul.setValidInfo(JsonUtils.getStr(json, "checkInfo"));
        if (StringUtils.isBlank(vul.getValidInfo())) {
            vul.setValidInfo(JsonUtils.getStr(json, "pocCheckInfo"));
        }
        //拼接对应参数
        JSONArray pocCheckResults = json.getJSONArray("pocCheckResults");
        String checkResult = JsonUtils.getStr(json, "checkResult");
        if (StringUtils.isNotBlank(checkResult)) {
            vul.setValidInfo(vul.getValidInfo() + "\\r\\n" + checkResult);
        }
        StringBuffer sBuffer = new StringBuffer();
        if (pocCheckResults != null) {
            pocCheckResults.stream().forEach(jsonobejct -> arrayIdToString((JSONObject) jsonobejct, sBuffer));
        }
        if (StringUtils.isNotBlank(sBuffer)) {
            vul.setValidInfo(vul.getValidInfo() + "\\r\\n" + sBuffer);
        }
        vul.setDescription(desc);
        vul.setSolution(solution);
        vul.setAvailableCondition(JsonUtils.getStr(json, "condition"));
        vul.setCveCode(CVE);
        vul.setAffectApplication(JsonUtils.getStr(json, "appVersion"));
        vul.setCreateTime(new Date());
        vul.setUpdateTime(new Date());
        vul.setFirstTime(firstCheckDate);
        vul.setRecentlyTime(firstCheckDate);
        vul.setPublishTime(publicDate);
        vul.setVulFeatures(String.join(",", feats));
        // 获取资产归属
        CommonAssemble.saveVulAssetInfo(vul, recordLog.getIp());
        return vul;
    }

    private static StringBuffer arrayIdToString(JSONObject jsonobejct,
                                                StringBuffer sBuffer) {
        return sBuffer.append(jsonobejct.getString("checkResult")).append(";\\r\\n");
    }

    /**
     * IP全部修复
     *
     * @param ip IP
     */
    public static void repairAllByIp(String ip) {
        try {
            CommonAssemble.repairAll(ip, ScannerEnums.QINGTENG_SCANNER.getCode(), ScanTypeEnums.HOST_SCAN.getCode());
        } catch (Exception e) {
            log.error(e.getMessage(), e);
        }
    }

    /**
     * Agent全部修复
     *
     * @param ip      ip
     * @param action  action
     * @param agentId agentId
     */
    public static void repairAllByAgent(String ip, String agentId, String action, String msg) {
        // 复查操作时，根据agentId查询数据，强制给localIp设置数据(全部设置agentId)
        try {
            VulnProcessFormMapper vulnProcessFormMapper = GetSpringBean.getBean(VulnProcessFormMapper.class);
            // 删除未推送数据及更新状态
            LambdaUpdateWrapper<VulnProcessForm> uw1 = new LambdaUpdateWrapper<>();
            uw1.eq(VulnProcessForm::getDelFlag, "0");
            uw1.eq(VulnProcessForm::getIsPushStatus, "0");
            uw1.eq(VulnProcessForm::getSource, ScannerEnums.QINGTENG_SCANNER.getCode());
            uw1.eq(VulnProcessForm::getCategory, ScanTypeEnums.HOST_SCAN.getCode());
            uw1.eq(VulnProcessForm::getAgentId, agentId);
            // 非私网ip，不修改更新逻辑
            /*if (StringUtils.isBlank(localIp)) {
                uw1.eq(VulnProcessForm::getIp, ip);
                // 全量漏洞时，筛选过Agent状态，可直接更新漏洞对应AgentId
                uw1.set(VulnProcessForm::getAgentId, agentId);
            } else {

            }*/

            uw1.set(VulnProcessForm::getStatus, "1");
            uw1.set(VulnProcessForm::getDelFlag, "1");
            //uw1.set(VulnProcessForm::getIp, ip);
            vulnProcessFormMapper.update(null, uw1);

            QtAllRiskAutoFlowSyncQueue.flowToQueue(agentId, action, msg);

/*            // 更已推送数据的状态
            LambdaUpdateWrapper<VulnProcessForm> uw = new LambdaUpdateWrapper<>();
            uw.eq(VulnProcessForm::getDelFlag, "0");
            uw.eq(VulnProcessForm::getIsPushStatus, "1");
            uw.eq(VulnProcessForm::getSource, ScannerEnums.QINGTENG_SCANNER.getCode());
            uw.eq(VulnProcessForm::getCategory, ScanTypeEnums.HOST_SCAN.getCode());
            // 非私网ip，不修改更新逻辑
            if (StringUtils.isBlank(localIp)) {
                uw.eq(VulnProcessForm::getIp, ip);
                // 全量漏洞时，筛选过Agent状态，可直接更新漏洞对应AgentId
                uw.set(VulnProcessForm::getAgentId, agentId);
            } else {
                uw.eq(VulnProcessForm::getAgentId, agentId);
            }

            uw.set(VulnProcessForm::getStatus, "1");
            vulnProcessFormMapper.update(null, uw);*/
        } catch (Exception e) {
            log.error(e.getMessage(), e);
        }
    }

    /**
     * IP全部修复
     *
     * @param ip IP
     */
    public static void repairAllWeakPwdByIp(String ip) {
        try {
            CommonAssemble.repairAll(ip, ScannerEnums.QINGTENG_SCANNER.getCode(), ScanTypeEnums.WEAK_PASS_SCAN.getCode());
        } catch (Exception e) {
            log.error(e.getMessage(), e);
        }
    }

    public static void addWeakPwdTask() {
        try {
            VulnScanTaskRecordLogMapper taskRecordLogMapper = GetSpringBean.getBean(VulnScanTaskRecordLogMapper.class);
            VulnScanTaskRecordLog q = new VulnScanTaskRecordLog();
            q.setScanStatus(0);//没开始扫描
            q.setScanType(ScanTypeEnums.WEAK_PASS_SCAN.getCode());
            q.setEngineName(ScannerEnums.QINGTENG_SCANNER.getCode());
            List<VulnScanTaskRecordLog> recordList = taskRecordLogMapper.getAllRecordLogList(q);
            log.info("青藤带下发弱口令任务:" + recordList.size());
            for (VulnScanTaskRecordLog recordLog : recordList) {
                try {
                    QtConfig scannerInfo = getQtConfig(recordLog.getEngineId());
                    QingtengAgent agent = QingtengUtils.getQtAgentByIp(scannerInfo, recordLog.getIp());
                    StringBuilder sb = new StringBuilder();
                    if (agent != null) {
                        int retStatus = QingtengUtils.GetWeakTaskStatus(scannerInfo, agent);
                        if (retStatus == 0) {
                            log.info("青藤弱口令未单例，请等待上次扫描");
                            continue;
                        }

                        try {
                            String name = recordLog.getTaskName();
                            String jobId = QingtengUtils.AddWeakPwdTask(scannerInfo, name, agent);
                            if (jobId.length() > 0) {
                                if ("999".equals(jobId)) {
                                    repairAllByIp(recordLog.getIp());
                                    recordLog.setScanStatus(3);
                                    sb.append(recordLog.getIp()).append("下发扫描任务完成，但Agent已被删除或卸载").append(DateUtils.getDateTimeString1(new Date())).append("\n");
                                } else {
                                    recordLog.setScanStatus(1);
                                    sb.append(recordLog.getIp()).append("下发扫描任务扫描完成").append(DateUtils.getDateTimeString1(new Date())).append("\n");
                                }
                                recordLog.setJobId(jobId);
                                taskRecordLogMapper.updateVulnScanTaskRecordLog(recordLog);
                            } else {
                                recordLog.setScanStatus(3);
                                log.error(recordLog.getTaskName() + ",添加任务失败=" + recordLog.getIp() + " agentId:" + recordLog.getUuid());
                                sb.append(recordLog.getIp()).append("添加任务失败").append(";");
                            }
                        } catch (Exception e) {
                            log.error(e.getMessage(), e);
                        }
                    } else {
                        repairAllByIp(recordLog.getIp());
                        recordLog.setScanStatus(3);
                        sb.append(recordLog.getIp()).append("下发扫描任务完成，但Agent已被删除或卸载").append(DateUtils.getDateTimeString1(new Date())).append("\n");
                    }
                    recordLog.setResult(sb.toString());
                    taskRecordLogMapper.updateVulnScanTaskRecordLog(recordLog);
                } catch (Exception e) {
                    log.error(e.getMessage(), e);
                }
            }
        } catch (Exception e) {
            log.error(e.getMessage(), e);
        }
    }

    public static void getWeakPwdTask() {
        try {
            CommonAssemble.engineMap.forEach((k, v) -> {
                if (ScannerEnums.QINGTENG_SCANNER.getCode().equals(v.getEquipmentManufacture())) {
                    getWeakPwdTask(getQtConfig(k));
                }
            });
        } catch (Exception e) {
            log.error(e.getMessage(), e);
        }
    }

    public static void getWeakPwdTask(QtConfig scannerInfo) {
        VulnScanTaskRecordLogMapper taskRecordLogMapper = GetSpringBean.getBean(VulnScanTaskRecordLogMapper.class);
        try {
            VulnScanTaskRecordLog q = new VulnScanTaskRecordLog();
            q.setScanStatus(1);//扫描中
            q.setScanType(ScanTypeEnums.WEAK_PASS_SCAN.getCode());
            q.setEngineName(ScannerEnums.QINGTENG_SCANNER.getCode());
            List<VulnScanTaskRecordLog> recordList = taskRecordLogMapper.getAllRecordLogList(q);
            log.info("青藤资产弱口令中任务" + recordList.size());
            List<String> finishIp = new ArrayList<>();
            for (VulnScanTaskRecordLog recordLog : recordList) {
                QingtengAgent agent = QingtengUtils.getQtAgentByIp(scannerInfo, recordLog.getIp());
                if (agent != null) {
                    int retStatus = QingtengUtils.GetWeakTaskStatus(scannerInfo, agent);
                    if (retStatus != 0) {
                        try {
                            if (retStatus == -1) {
                                log.info(recordLog.getIp() + " Agent被删除或不存在");
                                repairAllWeakPwdByIp(recordLog.getIp());
                                recordLog.setScanStatus(3);
                            } else if (retStatus == 1) {
                                recordLog.setScanStatus(2);
                                finishIp.add(recordLog.getIp());
                            } else if (retStatus == 2) {
                                recordLog.setScanStatus(3);
                                log.info("GetTask 扫描失败@@@@" + recordLog.getIp());
                            }
                            recordLog.setUpdateTime(new Date());
                            taskRecordLogMapper.updateVulnScanTaskRecordLog(recordLog);
                        } catch (Exception e) {
                            log.error(e.getMessage(), e);
                        }
                    }
                } else {
                    log.info(recordLog.getIp() + " Agent被删除或不存在");
                    repairAllWeakPwdByIp(recordLog.getIp());
                    recordLog.setScanStatus(3);
                    recordLog.setUpdateTime(new Date());
                    taskRecordLogMapper.updateVulnScanTaskRecordLog(recordLog);
                }

            }
            if (finishIp.size() > 0) {
                QingtengWeakPassSync sync = new QingtengWeakPassSync();
                sync.sync(finishIp);
            }

        } catch (Exception e) {
            log.error(e.getMessage(), e);
        }
    }
}
