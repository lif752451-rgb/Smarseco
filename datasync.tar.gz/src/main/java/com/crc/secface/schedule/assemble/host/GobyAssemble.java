package com.crc.secface.schedule.assemble.host;

import com.alibaba.fastjson.JSONArray;
import com.alibaba.fastjson.JSONObject;
import com.baomidou.mybatisplus.core.conditions.query.LambdaQueryWrapper;
import com.crc.common.enums.AssetSourceEnums;
import com.crc.common.enums.ScanStatusEnums;
import com.crc.common.enums.ScanTypeEnums;
import com.crc.common.enums.ScannerEnums;
import com.crc.common.utils.*;
import com.crc.scanner.config.GobyConfig;
import com.crc.scanner.tool.GobyUtils;
import com.crc.secface.config.GetSpringBean;
import com.crc.secface.domain.*;
import com.crc.secface.mapper.VulnScanTaskMapper;
import com.crc.secface.mapper.VulnScanTaskRecordLogMapper;
import com.crc.secface.mapper.VulnScanTaskRecordMapper;
import com.crc.secface.queue.CrcAssetSyncQueue;
import com.crc.secface.schedule.assemble.CommonAssemble;
import com.crc.sync.work.PortSaveWork;
import com.crc.sync.work.SoftwareSaveWork;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;

import java.util.*;

/**
 * Goby 漏洞协同核心逻辑
 */
@Slf4j
public class GobyAssemble {

    public static GobyConfig getGobyConfig(Long engineId) {
        EngineEquipmentManagement engine = CommonAssemble.engineMap.get(engineId);
        GobyConfig qtConfig = new GobyConfig();
        if (engine == null || engine.getId() == null) {
            return qtConfig;
        }
        qtConfig.setEngineId(engineId);
        qtConfig.setAddress(engine.getEquipmentAddress());
        return qtConfig;
    }

    public static boolean isHavingRunningTask(GobyConfig scannerInfo) {
        List<VulnScanTaskRecordLog> taskList = GobyUtils.getTaskList(scannerInfo);
        boolean flagV2 = false;
        /**
         * GOBY任何时候只能有一个任务执行
         */
        for (VulnScanTaskRecordLog task : taskList) {
            if (task.getProgress() < 100) {
                log.info("存在未完成任务：" + task.getJobId() + " 启动时间" + DateUtils.getDateTimeString1(task.getCreateTime()));
                flagV2 = true;

                try {
                    /*
                     * 超过2天没有完成到任务删除掉
                     */
                    if (task.getCreateTime() != null) {
                        if (task.getCreateTime().before(DateUtils.getDay(-2))) {
                            log.info("########删除2天前未完成任务：" + task.getJobId() + " 启动时间" + DateUtils.getDateTimeString1(task.getCreateTime()));
                            GobyUtils.deleteTask(scannerInfo, task.getJobId());
                        }
                    }
                } catch (Exception e) {
                    log.error(e.getMessage(), e);
                }
            }
        }
        return flagV2;
    }

    public static void addTask() {
        try {
            VulnScanTaskRecordMapper taskRecordMapper = GetSpringBean.getBean(VulnScanTaskRecordMapper.class);
            VulnScanTaskRecordLogMapper taskRecordLogMapper = GetSpringBean.getBean(VulnScanTaskRecordLogMapper.class);
            List<VulnScanTask> list = CommonAssemble.getCheckingScantask(ScannerEnums.GOBY_SCANNER.getCode(), ScanTypeEnums.HOST_SCAN.getCode(), Arrays.asList(1, 2));
            for (VulnScanTask task : list) {
                String taskName = task.getTaskName();
                try {
                    GobyConfig scannerInfo = getGobyConfig(task.getEngineId());
                    if (isHavingRunningTask(scannerInfo)) {
                        log.warn(taskName + ",存在执行的任务，Goby只支持单例");
                        return;
                    }

                    VulnScanTaskRecord record = taskRecordMapper.getLastRecordByTaskId(task.getId());
                    if (record == null) {
                        continue;
                    }
                    LambdaQueryWrapper<VulnScanTaskRecordLog> qlog = new LambdaQueryWrapper<>();
                    qlog.eq(VulnScanTaskRecordLog::getRecordId, record.getId());
                    qlog.eq(VulnScanTaskRecordLog::getTaskId, task.getId());
                    String scanContent = task.getScanContentX();
                    if (taskRecordLogMapper.selectCount(qlog) > 0) {
                        log.info("{}{},已在执行中", task.getTaskName(), scanContent);
                        continue;
                    }
                    List<String> uuids = new ArrayList<>();
                    if (!StringUtils.isBlank(scanContent)) {
                        //多个地址用英文逗号(,)分隔
                        for (String ipStr : scanContent.split("\n")) {
                            String ip = ipStr.trim();
                            if (StringUtils.isBlank(ip)) {
                                continue;
                            }
                            uuids.add(ip);
                        }
                    }
                    scanContent = String.join(",", uuids);
                    VulnScanTaskRecordLog recordLog = new VulnScanTaskRecordLog();
                    recordLog.setIp(scanContent);
                    recordLog.setTaskId(record.getTaskId());
                    recordLog.setTaskName(task.getTaskName());
                    recordLog.setRecordId(record.getId());
                    recordLog.setEngineId(task.getEngineId());
                    recordLog.setCreateTime(new Date());
                    recordLog.setType(ScannerEnums.GOBY_SCANNER.getCode());
                    //任务状态(0 未开始 1 执行中 2 执行完成 3 执行失败)
                    recordLog.setScanStatus(0);
                    //if (task.getScanEngine().toUpperCase(Locale.ROOT).contains("D01") || task.getScanEngine().toUpperCase(Locale.ROOT).contains("DCC")) {
                    JSONObject jsonObject = GobyUtils.scan(scannerInfo, taskName, scanContent);
                    String taskMsg = "执行成功";
                    if ("200".equals(JsonUtils.getStr(jsonObject, "code"))) {
                        recordLog.setScanStatus(1);
                        recordLog.setJobId(JsonUtils.getStr(jsonObject, "taskId"));
                        recordLog.setResult(taskMsg);
                        taskRecordLogMapper.insert(recordLog);
                    } else {
                        //失败
                        recordLog.setScanStatus(3);
                        taskMsg = "执行失败" + JsonUtils.getStr(jsonObject, "msg");
                        recordLog.setResult(taskMsg);
                        taskRecordLogMapper.insert(recordLog);

                        CommonAssemble.startFail(recordLog, taskMsg);
                    }
                    log.info("创建任务:" + task.getTaskName() + " -> " + taskMsg + " 返回ID：" + recordLog.getJobId());

                    record.setScanResult(taskMsg);
                    record.setScanStatus(1);
                    taskRecordMapper.updateVulnScanTaskRecord(record);

                    MyTheadUtils.sleepBySec(10);
                    if (isHavingRunningTask(scannerInfo)) {
                        return;
                    }
                } catch (Exception e) {
                    log.error(e.getMessage(), e);
                }

            }
        } catch (Exception e) {
            log.error(e.getMessage(), e);
        }
    }

    public static void getTask() {
        try {
            CommonAssemble.engineMap.forEach((k, v) -> {
                if (ScannerEnums.GOBY_SCANNER.getCode().equals(v.getEquipmentManufacture())) {
                    getTask(getGobyConfig(k));
                }
            });
        } catch (Exception e) {
            log.error(e.getMessage(), e);
        }
    }

    private static void getTask(GobyConfig scannerInfo) {
        VulnScanTaskRecordLogMapper taskRecordLogMapper = GetSpringBean.getBean(VulnScanTaskRecordLogMapper.class);
        VulnScanTaskRecordMapper taskRecordMapper = GetSpringBean.getBean(VulnScanTaskRecordMapper.class);
        VulnScanTaskMapper scanTaskMapper = GetSpringBean.getBean(VulnScanTaskMapper.class);
        try {
            //已完成的即时任务
            List<VulnScanTaskRecordLog> list = GobyUtils.getTaskList(scannerInfo);
            log.info("获取Goby任务:" + list.size());
            if (list.size() > 0) {
                for (VulnScanTaskRecordLog task : list) {
                    String jobId = task.getJobId();
                    LambdaQueryWrapper<VulnScanTaskRecordLog> q = new LambdaQueryWrapper<>();
                    q.eq(VulnScanTaskRecordLog::getJobId, jobId);
                    q.orderByDesc(VulnScanTaskRecordLog::getId);
                    q.last(" limit 1");
                    VulnScanTaskRecordLog tmp = taskRecordLogMapper.selectOne(q);
                    if (tmp == null)
                        continue;
                    if (CommonAssemble.isStopNow(tmp)) {
                        continue;
                    }
                    int status = 1;
                    if (task.getProgress() != null && task.getProgress() == 100L) {
                        status = 2;
                    }
                    task.setTaskId(tmp.getTaskId());
                    task.setScanStatus(status);
                    task.setId(tmp.getId());
                    taskRecordLogMapper.updateVulnScanTaskRecordLog(task);
                    log.info("task_id={}-record_id={}--job_id={}--status={}--progress={}",tmp.getTaskId(),tmp.getRecordId(),task.getJobId(),status,task.getProgress());
                    /*
                     * 更新业务段任务进度
                     */
                    try {
                        VulnScanTaskRecord taskRecord = taskRecordMapper.selectById(tmp.getRecordId());
                        if (taskRecord.getScanStatus() != null && taskRecord.getScanStatus() > 1 && Objects.equals(taskRecord.getScanProgress(), 100)) {
                            //不重复计算
                            continue;
                        }
                        taskRecord.setScanProgress(task.getProgress());
                        if (status == 2) {
                            taskRecord.setScanEndTime(new Date());
                            taskRecord.setDuration(DateUtils.getDiffSec(taskRecord.getScanStartTime(), taskRecord.getScanEndTime()));
                            taskRecord.setScanStatus(2);
                            taskRecord.setScanResult("扫描完成");
                        }
                        taskRecordMapper.updateVulnScanTaskRecord(taskRecord);

                        VulnScanTask scanTask = new VulnScanTask();
                        scanTask.setId(taskRecord.getTaskId());
                        scanTask.setUpdateTime(new Date());
                        scanTask.setScanProgress(taskRecord.getScanProgress());

                        if (taskRecord.getScanStatus() != null && taskRecord.getScanStatus() > 1) {
                            scanTask.setScanStatus(ScanStatusEnums.SCAN_FINISH.getCode());
                        }
                        scanTaskMapper.updateVulnScanTask(scanTask);
                    } catch (Exception e) {
                        log.error(e.getMessage(), e);
                    }
                }
            }
        } catch (Exception e) {
            log.error(e.getMessage(), e);
        }
    }

    public static void delTask(GobyConfig scannerInfo, VulnScanTaskRecordLog recordLog) {
        try {
            if (StringUtils.isNotBlank(recordLog.getJobId())) {
                try {
                    GobyUtils.deleteTask(scannerInfo, recordLog.getJobId());
                } catch (Exception e) {
                    log.error(e.getMessage(), e);
                }
            }
        } catch (Exception e) {
            log.error(e.getMessage(), e);
        }
    }

    public static void parseTask() {
        try {
            CommonAssemble.engineMap.forEach((k, v) -> {
                if (ScannerEnums.GOBY_SCANNER.getCode().equals(v.getEquipmentManufacture())) {
                    parseTask(getGobyConfig(k));
                }
            });
        } catch (Exception e) {
            log.error(e.getMessage(), e);
        }
    }

    private static void parseTask(GobyConfig scannerInfo) {
        try {
            VulnScanTaskRecordLogMapper taskRecordLogMapper = GetSpringBean.getBean(VulnScanTaskRecordLogMapper.class);
            VulnScanTaskRecordLog q = new VulnScanTaskRecordLog();
            q.setScanStatus(2);//扫描完成
            //q.setScanStatusList(Lists.newArrayList(1, 2));
            q.setScanType(ScanTypeEnums.HOST_SCAN.getCode());
            q.setEngineId(scannerInfo.getEngineId());
            List<VulnScanTaskRecordLog> recordList = taskRecordLogMapper.getAllRecordLogList(q);
            List<SysDictData> featureList = DictUtil.getDict("tb_software_feature");
            log.info("{}-需要解析的任务数:{}",scannerInfo.getEngineId(),recordList.size());
            if (recordList.size() > 0) {
                for (VulnScanTaskRecordLog vulTask : recordList) {
                    if (StringUtils.isNotBlank(vulTask.getJobId())) {
                        try {
                            HashMap<String, List<JSONObject>> dataMap = GobyUtils.assetSearch(scannerInfo,vulTask.getTaskName(), vulTask.getJobId());
                            log.info("任务:" + vulTask.getTaskName() + "，发现资产：" + dataMap.size());
                            if (dataMap.size() > 0) {
                                dataMap.forEach((k, v) -> {
                                    try {
                                        Asset asset = new Asset();
                                        asset.setInternalIp(k);
                                        saveAsset(asset);

                                        for (JSONObject jsonObject : v) {
                                            saveData(scannerInfo,k, jsonObject, featureList,vulTask.getJobId());
                                        }
                                    } catch (Exception e) {
                                        log.error(e.getMessage(), e);
                                    }
                                });
                            }
                        } catch (Exception e) {
                            log.error(e.getMessage(), e);
                        }
                    }
                }
            }
        } catch (Exception e) {
            log.error(e.getMessage(), e);
        }
        log.info("syncGobyAsset同步Goby资产结束");
    }

    private static void saveData(GobyConfig scannerInfo, String ip, JSONObject jsonData, List<SysDictData> featureList, String jobId) {
        try {
            if (!IpUtils.isIp(ip)) {
                return;
            }
         /*
                "10.54.238.55:27017": {
                "port": "27017",
                "hostinfo": "10.54.238.55:27017",
                "url": "",
                "product": "OpenSSL|MongoDb",
                "protocol": "mongodb",
                "json": "",
                "products": [
                  "OpenSSL",
                  "MongoDb"
                ],
                "protocols": [
                  "mongodb"
                ]
              }
         */


            String product = JsonUtils.getStr(jsonData, "product");//mac地址
            String port = JsonUtils.getStr(jsonData, "port");//操作系统
            String protocol = JsonUtils.getStr(jsonData, "protocol");//漏洞描述

            AssetPort assetPort = new AssetPort();
            assetPort.setIp(ip);
            assetPort.setPort(port);
            assetPort.setProto(protocol);
            assetPort.setType(product);
            assetPort.setSyncStatus(AssetSourceEnums.GOBY_CMDB.getCode());
            assetPort.setDevType("1");
            PortSaveWork.magicQueue.put(assetPort);
            if (jsonData.containsKey("products")) {
                JSONArray products = jsonData.getJSONArray("products");
                if (products != null) {
                    for (int i = 0; i < products.size(); i++) {
                        AssetSoftware software = new AssetSoftware();
                        software.setIp(ip);
                        software.setSortPort(port);
                        software.setSoftType(protocol);
                        software.setSoftName(products.getString(i));
                        software.setSoftManu(product);
                        software.setSource(AssetSourceEnums.GOBY_CMDB.getCode());
                        software.setDevType("1");
                        software.setFirstCatTag("支撑系统");
                        software.setSecondCatTag("组件");
                        String appName = products.getString(i);
                        if (featureList != null && featureList.size() > 0) {
                            for (SysDictData dict : featureList) {
                                try {
                                    if (appName.toLowerCase().contains(dict.getDictValue().toLowerCase())) {
                                        String[] arr = dict.getDictLabel().trim().split("#");
                                        if (arr.length == 2) {
                                            software.setFirstCatTag(arr[0]);
                                            software.setSecondCatTag(arr[1]);
                                            break;
                                        }
                                    }
                                } catch (Exception ignored) {
                                }
                            }
                        }
                        SoftwareSaveWork.magicQueue.put(software);
                    }
                    /*
                       数据用完就删除
                     */
                    GobyUtils.deleteTask(scannerInfo,jobId);
                }
            }

        } catch (Exception e) {
            log.error(e.getMessage(), e);
        }
    }

    private static void saveAsset(Asset asset) {
        try {
            if (StringUtils.isBlank(asset.getInternalIp())) {
                return;
            }
            //资产类型：(服务器，通信网络设备，安全设备，物联网设备)
            /*
            服务器		["通用","Web","文件","数据库","云平台","其他服务器设备"]
           通信网络设备	["路由器","交换机","网络存储","无线网络","其他网络设备"]
           安全设备	["VPN产品","防火墙","远程审计堡垒机","漏洞扫描","网络入侵检测与防御","威胁分析与管理","防病毒网关","安全内容管理","其他安全设备","IPS","WAF","主机防护","容器防护","防病毒","态势感知","日志审计","数据库审计","堡垒机","威胁情报","蜜罐"]
           物联网设备	["视频监控","门禁系统","语音视频","工业控制","其他物联网设备"]
             */
            asset.setType("服务器");
            asset.setSubType("通用");
            //资产状态，可选项：1在用、2停用、3下架、4库存备用、5故障设备、6已临时关停、7待修、8在修、9闲置、10待报废、11报废、12转交
            asset.setOperatingStatus(1);
            //数据来源，仅详情展示；1传统资源池CMDB、2华润云CMDB、3青藤、4D01、5 人工  6 GOBY 7 长亭 8 安恒"
            asset.setSource(AssetSourceEnums.GOBY_CMDB.getCode());

            CrcAssetSyncQueue.getInstance().saveAsset(asset);
        } catch (Exception e) {
            log.error(e.getMessage(), e);
        }
    }

}
