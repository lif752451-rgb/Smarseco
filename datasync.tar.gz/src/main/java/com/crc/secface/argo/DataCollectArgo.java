package com.crc.secface.argo;

import com.alibaba.fastjson.JSONObject;
import com.crc.common.code.CodeTool;
import com.crc.common.utils.HttpUtils;
import com.crc.common.utils.JsonUtils;
import org.apache.commons.lang3.StringUtils;

public class DataCollectArgo {
    /**
     * 根据规则获取Token
     *
     * @param tokenRuleStr 规则
     * @return token
     */
    public static JSONObject getToken(String tokenRuleStr) {
        JSONObject json = JsonUtils.parse(tokenRuleStr);
        JSONObject token = JsonUtils.getJson(json, "token");
        if (!JsonUtils.isEmpty(token)) {
            String method = JsonUtils.getStr(token, "method");
            if ("POST".equalsIgnoreCase(method)) {
                JSONObject param = decodeParam(token.getJSONObject("param"));
                String ret = HttpUtils.sendPost(JsonUtils.getStr(token, "url"), param.toJSONString(), token.getJSONObject("header"));
                String tokenStr = JsonArgo.getDymContent(JsonUtils.getStr(token, "token"), ret);
                return JsonUtils.createJson("token", tokenStr);
            } else if ("GET".equalsIgnoreCase(method)) {
                JSONObject param = decodeParam(token.getJSONObject("param"));
                String paramStr = HttpUtils.coverJson2String(param, null);

                String ret = HttpUtils.sendGet(JsonUtils.getStr(token, "url"), paramStr, token.getJSONObject("header"));
                String tokenStr = JsonArgo.getDymContent(JsonUtils.getStr(token, "token"), ret);
                return JsonUtils.createJson("token", tokenStr);
            }
        }
        return new JSONObject();
    }

    private static JSONObject decodeParam(JSONObject oriJson) {
        if (oriJson == null || oriJson.size() < 1) {
            return oriJson;
        }
        oriJson.forEach((k, v) -> {
            if (v instanceof String) {
                oriJson.put(k, CodeTool.decrypt(v.toString()));
            }
        });

        return oriJson;
    }

    private static JSONObject parseHeader(JSONObject oriJson, JSONObject value) {
        if (oriJson == null || oriJson.size() < 1) {
            return oriJson;
        }
        if (value == null || value.size() < 1) {
            return oriJson;
        }
        oriJson.forEach((k, v) -> {
            if (v instanceof String) {
                oriJson.put(k, JsonArgo.getDymContent(v.toString(), value));
            }
        });

        return oriJson;
    }

    /**
     * 根据规则获取Total
     *
     * @param totalRuleStr 规则
     * @return total json
     */
    public static JSONObject getTotal(String totalRuleStr, JSONObject tokenJson) {
        JSONObject json = JsonUtils.parse(totalRuleStr);
        JSONObject total = JsonUtils.getJson(json, "total");
        if (!JsonUtils.isEmpty(total)) {
            String method = JsonUtils.getStr(total, "method");
            if ("POST".equalsIgnoreCase(method)) {
                JSONObject param = decodeParam(total.getJSONObject("param"));
                JSONObject headerJson = parseHeader(total.getJSONObject("header"), tokenJson);

                String ret = HttpUtils.sendPost(JsonUtils.getStr(total, "url"), param.toJSONString(), headerJson);
                return JsonArgo.getDymContent(JsonUtils.getJson(total, "resp"), ret);
            } else if ("GET".equalsIgnoreCase(method)) {
                JSONObject param = decodeParam(total.getJSONObject("param"));
                String paramStr = HttpUtils.coverJson2String(param, null);
                JSONObject headerJson = parseHeader(total.getJSONObject("header"), tokenJson);
                String ret = HttpUtils.sendGet(JsonUtils.getStr(total, "url"), paramStr, headerJson);
                return JsonArgo.getDymContent(JsonUtils.getJson(total, "resp"), ret);
            }
        }
        return new JSONObject();
    }

    /**
     * 根据规则获取List
     *
     * @param listRuleStr 规则
     *
     */

    /**
     * 根据规则获取List
     *
     * @param listRuleStr 规则
     * @param tokenJson   回话
     * @param pageNumber  第N页
     * @param pageSize    每页数量
     * @param dynParam    额外动态参数
     */
    public static JSONObject getList(String listRuleStr, JSONObject tokenJson, int pageNumber, int pageSize, String dynParam) {
        JSONObject json = JsonUtils.parse(listRuleStr);
        JSONObject list = JsonUtils.getJson(json, "list");
        if (!JsonUtils.isEmpty(list)) {
            String method = JsonUtils.getStr(list, "method");
            if ("POST".equalsIgnoreCase(method)) {
                JSONObject param = decodeParam(JsonUtils.clone(JsonUtils.getJson(list, "param")));
                JSONObject headerJson = parseHeader(list.getJSONObject("header"), tokenJson);
                JSONObject page = JsonUtils.clone(JsonUtils.getJson(list, "page"));
                if (page != null) {
                    String pageStr = JsonUtils.getStr(page, "page");
                    if (StringUtils.isNotBlank(pageStr)) {
                        for (String ps : pageStr.split("#")) {
                            JsonUtils.setObj(param, ps, pageNumber);
                        }
                    }
                    String sizeStr = JsonUtils.getStr(page, "size");
                    if (StringUtils.isNotBlank(sizeStr)) {
                        for (String ps : sizeStr.split("#")) {
                            JsonUtils.setObj(param, ps, pageSize);
                        }
                    }
                }
                String dynParamKey = JsonUtils.getStr(list.getJSONObject("other"), "dynParam");
                if (list.containsKey("other") && StringUtils.isNotBlank(dynParamKey) && StringUtils.isNotBlank(dynParam)) {
                    param.put(dynParamKey, dynParam);
                }

                String ret = HttpUtils.sendPost(JsonUtils.getStr(list, "url"), param.toJSONString(), headerJson);
                //System.out.println(ret);
                JSONObject resp = JsonUtils.clone(JsonUtils.getJson(list, "resp"));
                return JsonArgo.getDymContent(resp, ret);

            } else if ("GET".equalsIgnoreCase(method)) {
                JSONObject param = decodeParam(JsonUtils.clone(JsonUtils.getJson(list, "param")));
                JSONObject headerJson = parseHeader(list.getJSONObject("header"), tokenJson);
                JSONObject page = JsonUtils.clone(JsonUtils.getJson(list, "page"));
                if (page != null) {
                    String pageStr = JsonUtils.getStr(page, "page");
                    if (StringUtils.isNotBlank(pageStr)) {
                        for (String ps : pageStr.split("#")) {
                            JsonUtils.setObj(param, ps, pageNumber);
                        }
                    }
                    String sizeStr = JsonUtils.getStr(page, "size");
                    if (StringUtils.isNotBlank(sizeStr)) {
                        for (String ps : sizeStr.split("#")) {
                            JsonUtils.setObj(param, ps, pageSize);
                        }
                    }
                }
                String dynParamKey = JsonUtils.getStr(list.getJSONObject("other"), "dynParam");
                if (list.containsKey("other") && StringUtils.isNotBlank(dynParamKey) && StringUtils.isNotBlank(dynParam)) {
                    param.put(dynParamKey, dynParam);
                }
                String paramStr = HttpUtils.coverJson2String(param, null);
                String ret = HttpUtils.sendGet(JsonUtils.getStr(list, "url"), paramStr, headerJson);
                //System.out.println(ret);
                JSONObject resp = JsonUtils.clone(JsonUtils.getJson(list, "resp"));
                return JsonArgo.getDymContent(resp, ret);
            }
        }
        return null;
    }

    public static JSONObject getData(JSONObject jsonObject, JSONObject map) {
        if (jsonObject == null || map == null) {
            return null;
        }
        JSONObject json = new JSONObject();
        map.forEach((k, v) -> {
            json.put(k, jsonObject.get(v));
        });
        return json;
    }
}
