package com.crc.secface.argo;

import com.crc.common.utils.DataUtils;
import com.crc.secface.domain.vo.RuleVo;
import com.google.common.collect.Lists;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;

import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

@Slf4j
public class RuleArgo {
    /*
    when HTTP_REQUEST {
    set hostName [ getfield [HTTP::host] : 1]
    set clientAddr [IP::remote_addr]
    set uri [HTTP::uri]
    set query [HTTP::query]
    set path [HTTP::path]
    switch -glob -- [string tolower $hostName] {
        "bdxt.95590.cn" {
           if { $path starts_with "/agency/ResultServlet" } {
            virtual vs_awaf_int_bdxt.95590.cn_nginx_171_27447_agency_ResultServlet
           return}
           if { $path starts_with "/lfw/" } {
            virtual vs_awaf_int_bdxt.95590.cn_nginx_171_27447_lfw
           return}
           if { $path starts_with "/ok.html" } {
            virtual vs_awaf_int_bdxt.95590.cn_nginx_171_27447_okhtml
           return}
        }
        "test.95590.cn" {
           if { $path starts_with "/agency/ResultServlet2" } {
            virtual vs_awaf_int_bdxt.95590.cn_nginx_171_27447_agency_ResultServlet22
           return}
           if { $path starts_with "/lfw2/" } {
            virtual vs_awaf_int_bdxt.95590.cn_nginx_171_27447_lfw22
           return}
           if { $path starts_with "/ok.html2" } {
            virtual vs_awaf_int_bdxt.95590.cn_nginx_171_27447_okhtml22
           return}
        }
        default { pool awaf_pool_27447_bdxt
    log local0. "unmatched $hostName $path"}
    }}
     */

    public static List<RuleVo> getRuleList(String ruleStr) {
        List<RuleVo> ruleList = Lists.newLinkedList();
        if (StringUtils.isNotBlank(ruleStr)) {
            try {
                String[] lines = ruleStr.split("\n");
                boolean afterSwtich = false;
                int index = -1;
                for (String line : lines) {
                    if (StringUtils.isNotBlank(line)) {
                        line = line.trim();

                        if (afterSwtich) {
                            if (line.startsWith("if")) {
                                ruleList.get(index).setPath(getPath(line));
                            } else if (line.startsWith("\"")) {
                                ruleList.get(index).setDomain(getMatch(line));
                            } else if (line.startsWith("virtual")) {
                                ruleList.get(index).setVirtual(line.split(" ")[1]);
                            } else if (line.startsWith("return")) {
                                ruleList.add(new RuleVo());
                                index++;
                                ruleList.get(index).setDomain(ruleList.get(index - 1).getDomain());
                            } else {
                                if (line.startsWith("default") || line.startsWith("log")) {
                                    break;
                                }else {
                                    line = line.replace("\n", "").replace(" ", "");
                                    if (line.equals("}") || line.equals("}}")) {
                                        ruleList.add(new RuleVo());
                                        index++;
                                    }
                                }
                            }
                        }
                        if (line.startsWith("switch")) {
                            afterSwtich = true;
                            ruleList.add(new RuleVo());
                            index++;
                        }
                    }
                }
            } catch (Exception e) {
                log.error(e.getMessage(), e);
            }
        }
        List<RuleVo> ruleList2 = Lists.newLinkedList();
        for (RuleVo ruleVo : ruleList) {
            if (StringUtils.isNotBlank(ruleVo.getDomain())) {
                ruleList2.add(ruleVo);
            }
        }
        return ruleList2;
    }

    private static String getPath(String str) {
        String match = getMatch(str);
        if (StringUtils.isBlank(match) || str.contains("matches_regex")) {
            String[] arr = str.split("matches_regex");
            String temp = arr[arr.length - 1];
            temp = DataUtils.getSubString(temp, DataUtils.getIndex(temp, "{") + 1);
            int index = DataUtils.getIndex(temp, "}");
            if (index != -1) {
                temp = DataUtils.getSubString(temp, 0, index);
                return temp.trim();
            }
        }
        return match.trim();
    }

    /**
     * 获取双引号内的内容
     *
     * @param str
     * @return
     */
    private static String getMatch(String str) {
        if (StringUtils.isBlank(str)) {
            return "";
        }
        Pattern p = Pattern.compile("\"(.*?)\"");
        Matcher m = p.matcher(str);
        while (m.find()) {
            return m.group().replace("\"", "").trim();
        }
        return "";
    }
}
