package com.crc.secface.argo;

import com.alibaba.fastjson.JSONObject;
import com.crc.common.utils.JsonUtils;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;

import java.util.regex.Matcher;
import java.util.regex.Pattern;


@Slf4j
public class JsonArgo {
    /**
     * 动态获取JSON内容
     *
     * @param oldContent 替换前内容
     * @param json       原始内容
     */
    public static String getDymContent(String oldContent, String json) {
        if (json == null) {
            return oldContent;
        }
        return getDymContent(oldContent, JsonUtils.parse(json));
    }

    /**
     * 动态获取JSON内容
     *
     * @param dymStr 替换前内容
     * @param json       原始内容
     */
    public static String getDymContent(String dymStr, JSONObject json) {
        if (StringUtils.isBlank(dymStr)) {
            return "";
        }
        //遍历大括号
        try {
            String reg2 = "(\\{(.*?)})";
            Pattern pattern2 = Pattern.compile(reg2);
            Matcher matcher2 = pattern2.matcher(dymStr);
            String msg = dymStr;
            while (matcher2.find()) {
                String key = matcher2.group(1);
                String kevOne = key.replace("{", "").replace("}", "").replace(" ", "").trim();
                kevOne = kevOne.replace(".keyword", "");
                kevOne = kevOne.replace(".keyword", "");
                if (kevOne.contains(".")) {
                    String[] ks = kevOne.split("\\.");
                    if (ks.length > 2) {
                        kevOne = String.format("%s.%s", ks[0], ks[1]);
                    }
                }
                kevOne = kevOne.replace(".", "_");
                String val = JsonUtils.getStr(json, kevOne);
                if (StringUtils.isEmpty(val)) {
                    val = JsonUtils.getStr(json, kevOne.toLowerCase());
                }
                if (StringUtils.isBlank(val)) {
                    msg = msg.replace(key, "");
                } else {
                    msg = msg.replace(key, val);
                }
            }
            return msg;
        } catch (Exception e) {
            log.error(e.getMessage(), e);
        }
        return dymStr.trim();
    }

    public static JSONObject getDymContent(JSONObject oriJson, JSONObject json) {
        oriJson.forEach((k, v) -> {
            if (v instanceof String) {
                oriJson.put(k, JsonArgo.getDymContent(v.toString(), json));
            }
        });
        return oriJson;
    }

    public static JSONObject getDymContent(JSONObject oriJson, String jsonStr) {
        if (jsonStr == null) {
            return oriJson;
        }
        return getDymContent(oriJson, JsonUtils.parse(jsonStr));
    }
}
