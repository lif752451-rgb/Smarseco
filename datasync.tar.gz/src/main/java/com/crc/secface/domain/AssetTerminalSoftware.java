package com.crc.secface.domain;

import com.baomidou.mybatisplus.annotation.TableName;
import com.baomidou.mybatisplus.extension.activerecord.Model;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.experimental.Accessors;

import java.util.Date;

/**
 * <p>
 * 终端资产-终端软件表
 * </p>
 *
 * @author hejingsheng1
 * @since 2023-03-27
 */
@Data
@EqualsAndHashCode(callSuper = false)
@Accessors(chain = true)
@TableName("tb_asset_terminal_software")
public class AssetTerminalSoftware extends Model<AssetTerminalSoftware> {

    private static final long serialVersionUID = 1L;

    /**
     * 主键
     */
    private String id;
    /**
     * 软件名称
     */
    private String softwareName;
    /**
     * 软件版本
     */
    private String softwareVersion;
    /**
     * 软件版本 数字类型
     */
    private Long softwareVersionNumber;
    /**
     * 软件厂商
     */
    private String softwareCorp;
    /**
     * 删除标记(0正常 1删除)
     */
    private String delFlag;
    /**
     * 创建人
     */
    private String createBy;
    /**
     * 创建时间
     */
    private Date createTime;
    /**
     * 最后修改人
     */
    private String updateBy;
    /**
     * 最后修改时间
     */
    private Date updateTime;


}
