package com.crc.secface.domain;

import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableId;
import com.baomidou.mybatisplus.annotation.TableName;
import com.baomidou.mybatisplus.extension.activerecord.Model;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.experimental.Accessors;

/**
 * <p>
 * 终端软件安装统计表
 * </p>
 *
 * @author hejingsheng1
 * @since 2022-12-13
 */
@Data
@EqualsAndHashCode(callSuper = false)
@Accessors(chain = true)
@TableName("tb_terminal_software_install")
public class TerminalSoftwareInstall extends Model<TerminalSoftwareInstall> {

    private static final long serialVersionUID = 1L;

    /**
     * 主键ID
     */
    @TableId(value = "id", type = IdType.AUTO)
    private Long id;
    /**
     * 用户账号
     */
    private String strUserName;
    /**
     * 合法软件安装数
     */
    private Integer iillegalInstallCount;
    /**
     * 部门
     */
    private String strRoleName;
    /**
     * uiddevrecordid
     */
    private String uidDevRecordId;
    /**
     * 用户名称
     */
    private String strUserDes;
    /**
     * IP
     */
    private String strDevIp;
    /**
     * 软件安装数
     */
    private Integer iinstallCount;
    /**
     * uidroleid
     */
    private String uidRoleId;
    /**
     * MAC地址
     */
    private String strMac;
    /**
     * 计算机名称
     */
    private String strDevName;
    /**
     * 非授权安装软件数
     */
    private Integer iauthInstallCount;

}
