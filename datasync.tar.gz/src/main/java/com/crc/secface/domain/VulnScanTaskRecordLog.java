package com.crc.secface.domain;

import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableField;
import com.baomidou.mybatisplus.annotation.TableId;
import com.baomidou.mybatisplus.annotation.TableName;
import com.baomidou.mybatisplus.extension.activerecord.Model;
import com.fasterxml.jackson.annotation.JsonFormat;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.experimental.Accessors;

import java.util.Date;
import java.util.List;

/**
 * <p>
 * 漏洞扫描任务表记录表
 * </p>
 *
 * @author hejingsheng
 * @since 2022-12-05
 */
@Data
@EqualsAndHashCode(callSuper = false)
@Accessors(chain = true)
@TableName("tb_vuln_scan_task_record_log")
public class VulnScanTaskRecordLog extends Model<VulnScanTaskRecordLog> {

    private static final long serialVersionUID = 1L;

    @TableId(value = "id", type = IdType.AUTO)
    private Long id;
    /**
     * 任务ID
     */
    private Long recordId;
    private Integer progress;
    /**
     * 扫描结果
     */
    private String checkId;
    /**
     * 任务状态 清点状态(0-待清点，1清点中，2清点成功，3清点失败)（业务不需要，预留给青藤）
     */
    private Integer checkStatus;
    String result;
    /**
     * IP
     */
    private String ip;
    /**
     * 扫描开始时间
     */
    @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss", timezone = "GMT+8")
    private Date createTime;
    /**
     * 扫描结束时间
     */
    @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss", timezone = "GMT+8")
    private Date updateTime;
    private String jobId;//扫描任务执行ID （业务不需要，扫描器执行的任务ID）
    private String childTaskId;//天地和兴返回获取结果id
    String groupId;//分组ID（业务不需要，预留给DCC）
    private String uuid;
    private String type;
    Integer scanStatus;
    /**
     * 具体漏洞数据（VulnProcessReviewTask的vulCode串）
     */
    private String reviews;

    @TableField(exist = false)
    List<Integer> scanStatusList;

    @TableField(exist = false)
    private List<String> equipmentManufactures;

    @TableField(exist = false)
    String engineName;
    @TableField(exist = false)
    Integer scanType;
    String taskId;//下发任务ID
    @TableField(exist = false)
    String taskName;
    @TableField(exist = false)
    String scanContent;
    Long engineId;
}
