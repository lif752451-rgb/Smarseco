package com.crc.secface.domain;

import com.baomidou.mybatisplus.annotation.TableName;
import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.extension.activerecord.Model;
import com.baomidou.mybatisplus.annotation.TableId;

import java.util.Date;

import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.experimental.Accessors;

/**
 * <p>
 * 公网域名公网IP表
 * </p>
 *
 * @author hejingsheng1
 * @since 2023-04-03
 */
@Data
@EqualsAndHashCode(callSuper = false)
@Accessors(chain = true)
@TableName("tb_f5_domain_awaf_mem_rela")
public class F5DomainAwafMemRela extends Model<F5DomainAwafMemRela> {

    private static final long serialVersionUID = 1L;

    /**
     * 主键ID
     */
    @TableId(value = "id", type = IdType.AUTO)
    private Long id;
    /**
     * f5_domain ID
     */
    private Integer domainId;
    /**
     * 资产表主键ID
     */
    private Long assetId;
    /**
     * 资产端口表主键ID
     */
    private String assetPortId;
    /**
     * 优先级
     */
    private Integer prority;
    /**
     * 创建时间
     */
    private Date createTime;
    /**
     * 修改时间
     */
    private Date updateTime;
    /**
     * 删除标记(0正常 1删除)
     */
    private Integer delFlag;

}
