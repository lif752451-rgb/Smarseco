package com.crc.secface.domain;

import com.baomidou.mybatisplus.annotation.TableField;
import com.baomidou.mybatisplus.annotation.TableName;
import com.baomidou.mybatisplus.extension.activerecord.Model;
import com.crc.common.enums.DatabaseEnums;
import com.crc.common.utils.VersionUtils;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.experimental.Accessors;

import java.util.Date;

/**
 * <p>
 * 邮件服务器配置表
 * </p>
 *
 * @author hejingsheng1
 * @since 2023-11-23
 */
@Data
@EqualsAndHashCode(callSuper = false)
@Accessors(chain = true)
@TableName("sys_email_config")
public class SysEmailConfig extends Model<SysEmailConfig> {

    private static final long serialVersionUID = 1L;

    private String id;
    /**
     * 发送人邮箱
     */
    private String sendEmail;
    /**
     * smtp 邮件服务器
     */
    private String sendHost;
    /**
     * 端口
     */
    private Integer port;
    /**
     * 密码
     */
    private String password;
    /**
     * 邮件服务状态  1  启用  0 停用
     */
    private Integer emailStatus;
    /**
     * 创建时间
     */
    private Date createTime;
    /**
     * 创建人
     */
    private String createBy;
    /**
     * 创建人姓名
     */
    private String createByLabel;
    /**
     * 修改时间
     */
    private Date updateTime;
    /**
     * 修改人
     */
    private String updateBy;
    @TableField(exist = false)
    private String dbType;

    public String getDbType() {
        if (VersionUtils.getDatabase() == DatabaseEnums.MYSQL.getCode()) {
            return "mysql";
        } else {
            return "other";
        }
    }

    public void setDbType(String dbType) {
        this.dbType = dbType;
    }
}
