package com.crc.secface.domain;

import lombok.Data;

@Data
public class AssetPolicy {
    //@TableField(value = "name")
    String name;
    //@TableField(value = "ip")
    String ip;
    //@TableField(value = "area_inteface")
    String areaInteface;
    //@TableField(value = "src_addr")
    String srcAddr;
    //@TableField(value = "dst_addr")
    String dstAddr;
    //@TableField(value = "serv")
    String serv;
    //@TableField(value = "behavor")
    String behavor;
    //@TableField(value = "status")
    String status;
    //@TableField(value = "addr_trans")
    String addrTrans;
    //@TableField(value = "del_flag")
    String delFlag;
    //@TableField(value = "batch_id")
    String batchId;
    //@TableField(value = "create_time")
    String createTime;
    //@TableField(value = "create_by")
    String createBy;
    //@TableField(value = "update_by")
    String updateBy;
    //@TableField(value = "update_time")
    String updateTime;
    //@TableField(value = "remark")
    String remark;
    String source;
}
