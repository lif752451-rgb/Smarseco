package com.crc.secface.domain;

import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableId;
import com.baomidou.mybatisplus.annotation.TableName;
import com.baomidou.mybatisplus.extension.activerecord.Model;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.experimental.Accessors;

import java.util.Date;

/**
 * <p>
 * 攻击面_互联网资产管理
 * </p>
 *
 * @author hejingsheng1
 * @since 2023-03-08
 */
@Data
@EqualsAndHashCode(callSuper = false)
@Accessors(chain = true)
@TableName("tb_asset_asm_internet")
public class AssetAsmInternet extends Model<AssetAsmInternet> {

    private static final long serialVersionUID = 1L;

    /**
     * 主键ID
     */
    @TableId(value = "id", type = IdType.AUTO)
    private Long id;
    /**
     * 资产ID
     */
    private String assetId;
    /**
     * IP
     */
    private String ip;
    /**
     * 端口
     */
    private String port;
    /**
     * 访问地址
     */
    private String accessAddress;
    /**
     * 网页标题
     */
    private String webTitle;
    /**
     * 域名
     */
    private String domainName;
    /**
     * 协议
     */
    private Integer agreement;
    /**
     * web服务名
     */
    private String webServiceName;
    /**
     * web指纹
     */
    private String webFingerprint;
    /**
     * 数据来源
     */
    private String dataSource;
    /**
     * 备注
     */
    private String remark;
    /**
     * 所属组织名称
     */
    private String affiliationDeptName;
    /**
     * 所属组织ID
     */
    private Long affiliationDeptNodeId;
    /**
     * 责任人
     */
    private String responsible;
    /**
     * 发布位置
     */
    private String publishLocation;
    /**
     * 状态
     */
    private Integer useStatus;
    /**
     * 创建人
     */
    private String createBy;
    /**
     * 创建人姓名(账号)
     */
    private String createByLabel;
    /**
     * 创建时间
     */
    private Date createTime;
    /**
     * 修改人
     */
    private String updateBy;
    /**
     * 最近更新时间
     */
    private Date updateTime;
    /**
     * 删除标识，0未删除，1已删除
     */
    private String delFlag;


}
