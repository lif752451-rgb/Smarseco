package com.crc.secface.domain.vo;

import lombok.Data;

/**
 * @author YUYUHANG5
 */
@Data
public class AllRiskVo {
    String action;
    String msg;
    String vulCode;
    String ip;
    String agentId;
}
