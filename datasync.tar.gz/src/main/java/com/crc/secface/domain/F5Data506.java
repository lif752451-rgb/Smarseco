package com.crc.secface.domain;

import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableField;
import com.baomidou.mybatisplus.annotation.TableId;
import com.baomidou.mybatisplus.annotation.TableName;
import com.baomidou.mybatisplus.extension.activerecord.Model;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.experimental.Accessors;

/**
 * <p>
 * 
 * </p>
 *
 * @author hejingsheng1
 * @since 2023-04-28
 */
@Data
@EqualsAndHashCode(callSuper = false)
@Accessors(chain = true)
@TableName("tb_f5_506")
public class F5Data506 extends Model<F5Data506> {

    private static final long serialVersionUID = 1L;

    @TableId(value = "id", type = IdType.AUTO)
    private Integer id;
    /**
     * 类型
     */
    private String path;
    /**
     * 数据内容
     */
    //@TableField(value = "\"DOMAIN\"")
    private String domain;
    private String ruleMd5;
    /**
     * 数据ID
     */
    private String virtualData;
    String sid;
    String name;
    /**
     * 引擎的逻辑判断0-有效，1无效
     */
    private Integer flag;
}
