package com.crc.secface.domain;

import lombok.Data;

@Data
public class TbAssetExt {
    long assetId;//资产主表主键id
    String equipmentManufacturer;//设备厂商
    String equipmentModel;//设备型号
    String equipmentVersion;//设备版本
    String equipmentStorageAddress;//设备存放地址
    String equipmentManagerAddress;//设备管理地址
    String cpu;//CPU大小
    int memory;//内存大小
    double memoryUsage;//内存使用率
    int disk;//硬盘大小
    double diskUsage;//硬盘使用率
    int diskNum;//硬盘个数
    String assetNumber;//资产编号
    int confidentiality;
    int completeness;
    int usability;
    int assetImportance;
}
