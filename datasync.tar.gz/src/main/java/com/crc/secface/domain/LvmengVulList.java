package com.crc.secface.domain;

import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableId;
import com.baomidou.mybatisplus.annotation.TableName;
import com.baomidou.mybatisplus.extension.activerecord.Model;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.experimental.Accessors;

/**
 * <p>
 * 
 * </p>
 *
 * @author hejingsheng1
 * @since 2022-12-14
 */
@Data
@EqualsAndHashCode(callSuper = false)
@Accessors(chain = true)
@TableName("tb_lvmeng_vul_list")
public class LvmengVulList extends Model<LvmengVulList> {

    private static final long serialVersionUID = 1L;

    @TableId(value = "id", type = IdType.AUTO)
    private Long id;
    /**
     * 任务Id
     */
    private String taskId;
    /**
     * 被扫描IP
     */
    private String ip;
    /**
     * JSON
     */
    private String vulJson;
    /**
     * 漏洞ID
     */
    private String vulId;
    private Integer status;

}
