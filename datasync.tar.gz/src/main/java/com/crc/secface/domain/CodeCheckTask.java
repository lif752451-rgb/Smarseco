package com.crc.secface.domain;

import com.baomidou.mybatisplus.annotation.TableField;
import com.baomidou.mybatisplus.annotation.TableName;
import com.baomidou.mybatisplus.extension.activerecord.Model;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.experimental.Accessors;

import java.util.Date;

/**
 * <p>
 * 代码检测任务表
 * </p>
 *
 * @author hejingsheng1
 * @since 2023-01-05
 */
@Data
@EqualsAndHashCode(callSuper = false)
@Accessors(chain = true)
@TableName("tb_code_check_task")
public class CodeCheckTask extends Model<CodeCheckTask> {

    private static final long serialVersionUID = 1L;

    /**
     * 主键ID，自动生成，格式：时间戳
     */
    private String id;
    /**
     * 任务名称
     */
    private String taskName;
    /**
     * 应用id
     */
    private Long appId;
    /**
     * 执行周期 1：立即执行 2：定时执行
     */
    private String execPeriod;
    /**
     * 代码来源 1：git 2：SVN 3：上传源码
     */
    private String source;
    /**
     * 语言类型 1：Java 2：C 3:PHP 4:Python
     */
    private String lang;
    /**
     * 检测安全级别 1：默认 2：高危 3:自定义
     */
    private String safetyLevel;
    /**
     * 任务状态 1：等待 2：解压中 3:解压失败 4：待检测 5：检测中 6：检测完成 7：检测异常
     */
    private String status;
    /**
     * 缺陷模板id
     */
    @TableField("ruleId")
    private String ruleId;
    /**
     * 缺陷类型
     */
    @TableField("defectType")
    private String defectType;
    /**
     * 删除标识(0 未删除 1 已删除)
     */
    private String delFlag;
    /**
     * 创建人
     */
    private String createBy;
    /**
     * 创建人label
     */
    private String createByLabel;
    /**
     * 创建时间
     */
    private Date createTime;
    /**
     * 最后更新人
     */
    private String updateBy;
    /**
     * 最后更新时间
     */
    private Date updateTime;

    private Date execTime;
    private String fileJson;
}
