package com.crc.secface.domain;

import com.baomidou.mybatisplus.annotation.TableName;
import com.baomidou.mybatisplus.extension.activerecord.Model;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.experimental.Accessors;

import java.util.Date;

/**
 * <p>
 * 基线主表
 * </p>
 *
 * @author hejingsheng1
 * @since 2024-03-19
 */
@Data
@EqualsAndHashCode(callSuper = false)
@Accessors(chain = true)
@TableName("tb_baseline_process_form")
public class BaselineProcessForm extends Model<BaselineProcessForm> {

    private static final long serialVersionUID = 1L;

    /**
     * 主键Id
     */
    private String id;
    /**
     * 基线问题ID
     */
    private String code;
    /**
     * Ip
     */
    private String ip;
    /**
     * 所属组织名称
     */
    private String affiliationDeptName;
    /**
     * 所属组织ID
     */
    private Long affiliationDeptNodeId;
    /**
     * 资产名称
     */
    private String assetName;
    /**
     * 处置人
     */
    private String handlePerson;
    /**
     * 处置人label
     */
    private String handlePersonLabel;
    /**
     * 修复截至时间
     */
    private Date repairTime;
    /**
     * 来源,字典:baseline_data_source
     */
    private String source;
    /**
     * 检查项名
     */
    private String checkName;
    /**
     * 风险等级,字典:baseline_level
     */
    private String level;
    /**
     * 检查项类别
     */
    private String checkType;
    /**
     * 检查内容
     */
    private String checkContent;
    /**
     * 检查结果详情
     */
    private String checkResult;
    /**
     * 修复建议
     */
    private String solution;
    /**
     * 检查说明
     */
    private String checkDesc;
    /**
     * 引用信息
     */
    private String refInfo;
    /**
     * 基线规则名称
     */
    private String baselineRule;
    /**
     * 首次发现时间
     */
    private Date firstTime;
    /**
     * 最近发现时间
     */
    private Date recentlyTime;
    /**
     * 附件
     */
    private String fileJson;
    /**
     * 创建人
     */
    private String createBy;
    /**
     * 创建人信息
     */
    private String createByLabel;
    /**
     * 创建时间
     */
    private Date createTime;
    /**
     * 修改人
     */
    private String updateBy;
    /**
     * 修改时间
     */
    private Date updateTime;
    /**
     * 删除标志(0 未删除  1已删除)
     */
    private String delFlag;
    /**
     * 状态 0：未修复 1：已修复
     */
    private String status;
    /**
     * 推送状态 0：未推送 1：已推送
     */
    private String isPushStatus;
    /**
     * 推送时间
     */
    private Date pushTime;

}
