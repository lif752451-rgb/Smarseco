package com.crc.secface.domain;

import com.baomidou.mybatisplus.annotation.TableName;
import com.baomidou.mybatisplus.extension.activerecord.Model;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.experimental.Accessors;

/**
 * <p>
 * 检测规则列表
 * </p>
 *
 * @author hejingsheng1
 * @since 2023-01-06
 */
@Data
@EqualsAndHashCode(callSuper = false)
@Accessors(chain = true)
@TableName("tb_code_check_rule")
public class CodeCheckRule extends Model<CodeCheckRule> {

    private static final long serialVersionUID = 1L;

    /**
     * ID
     */
    private String id;
    /**
     * 规则名称
     */
    private String name;
    /**
     * 检测类型列表
     */
    private String extraList;
    /**
     * 支持语言
     */
    private String lang;


}
