package com.crc.secface.domain.vo;

/**
 * web漏洞URL信息
 * @author: 村长
 * @date: 2023-04-04 10:49:20
 */
public class WebUrlInfos {

  /**受影响的站点 */
  private String url;
  /**元素名称 */
  private String vectorInputs;
  /**元素类型 */
  private String vectorType;
  /**问题参数 */
  private String param;
  /**请求 */
  private String request;

  public String getUrl() {
    return url;
  }

  public void setUrl(String url) {
    this.url = url;
  }

  public String getVectorInputs() {
    return vectorInputs;
  }

  public void setVectorInputs(String vectorInputs) {
    this.vectorInputs = vectorInputs;
  }

  public String getVectorType() {
    return vectorType;
  }

  public void setVectorType(String vectorType) {
    this.vectorType = vectorType;
  }

  public String getParam() {
    return param;
  }

  public void setParam(String param) {
    this.param = param;
  }

  public String getRequest() {
    return request;
  }

  public void setRequest(String request) {
    this.request = request;
  }
}
