package com.crc.secface.domain;

import com.baomidou.mybatisplus.annotation.TableField;
import com.baomidou.mybatisplus.annotation.TableName;
import com.baomidou.mybatisplus.extension.activerecord.Model;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.experimental.Accessors;

import java.util.Date;

/**
 * <p>
 * 代码审计项目表
 * </p>
 *
 * @author hejingsheng1
 * @since 2023-01-11
 */
@Data
@EqualsAndHashCode(callSuper = false)
@Accessors(chain = true)
@TableName("tb_code_audit_project")
public class CodeAuditProject extends Model<CodeAuditProject> {

    private static final long serialVersionUID = 1L;

    /**
     * 主键
     */
    private String id;
    /**
     * 项目名称
     */
    private String projectName;
    /**
     * 项目负责人
     */
    private String projectDuty;
    /**
     * 项目负责人label
     */
    private String projectDutyLabel;
    /**
     * 所属组织名称
     */
    private String affiliationDeptName;
    /**
     * 所属组织ID
     */
    private Long affiliationDeptNodeId;
    /**
     * 项目描述
     */
    private String description;
    /**
     * 最近检测时间
     */
    private Date recentCheckTime;
    /**
     * 代码检测次数
     */
    private Integer count;
    /**
     * 应用个数
     */
    private Integer applicationNum;
    /**
     * 删除标识(0 未删除 1 已删除)
     */
    private String delFlag;
    /**
     * 创建人
     */
    private String createBy;
    /**
     * 创建人label
     */
    private String createByLabel;
    /**
     * 创建时间
     */
    private Date createTime;
    /**
     * 最后更新人
     */
    private String updateBy;
    /**
     * 最后更新时间
     */
    private Date updateTime;

    @TableField(exist = false)
    private String projectDutyMail;
}
