package com.crc.secface.domain;

import com.baomidou.mybatisplus.annotation.TableName;
import com.baomidou.mybatisplus.extension.activerecord.Model;

import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.experimental.Accessors;

import java.util.Date;

/**
 * <p>
 * 攻击面端口映射关系表
 * </p>
 *
 * @author hejingsheng1
 * @since 2023-05-18
 */
@Data
@EqualsAndHashCode(callSuper = false)
@Accessors(chain = true)
@TableName("tb_asset_asm_port")
public class AssetAsmPort extends Model<AssetAsmPort> {

    private static final long serialVersionUID = 1L;

    /**
     * 主键id
     */
    private String id;
    /**
     * 源IP
     */
    private String srcIp;
    /**
     * 源端口
     */
    private String srcPort;
    /**
     * 目的IP
     */
    private String destIp;
    /**
     * 目的端口
     */
    private String destPort;
    /**
     * 创建人姓名
     */
    private String createByLabel;
    /**
     * 删除标记 0 未删除 1 删除
     */
    private String delFlag;
    /**
     * 创建人
     */
    private String createBy;
    /**
     * 创建时间
     */
    private Date createTime;
    /**
     * 更新人
     */
    private String updateBy;
    /**
     * 更新时间
     */
    private Date updateTime;
    /**
     * 状态 1 启用 2  关闭
     */
    private String status;
    /**
     * 备注
     */
    private String remark;

}
