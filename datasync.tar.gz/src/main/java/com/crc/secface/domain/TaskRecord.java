package com.crc.secface.domain;

public class TaskRecord {

    String depend1;
    String taskId;
    String depend2;

    String taskName;
    String name;
    String email;
    String capTime;
    String status;
    String input;

    /**
     * 钓鱼方式 2 短信 1邮件
     */
    String fishType;

    String phone;

    String flag;

    public String getFlag() {
        return flag;
    }

    public void setFlag(String flag) {
        this.flag = flag;
    }

    public String getDepend1() {
        return depend1;
    }

    public void setDepend1(String depend1) {
        this.depend1 = depend1;
    }

    public String getTaskId() {
        return taskId;
    }

    public void setTaskId(String taskId) {
        this.taskId = taskId;
    }

    public String getDepend2() {
        return depend2;
    }

    public void setDepend2(String depend2) {
        this.depend2 = depend2;
    }

    public String getTaskName() {
        return taskName;
    }

    public void setTaskName(String taskName) {
        this.taskName = taskName;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getCapTime() {
        return capTime;
    }

    public void setCapTime(String capTime) {
        this.capTime = capTime;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public String getInput() {
        return input;
    }

    public void setInput(String input) {
        this.input = input;
    }

    public String getFishType() {
        return fishType;
    }

    public void setFishType(String fishType) {
        this.fishType = fishType;
    }

    public String getPhone() {
        return phone;
    }

    public void setPhone(String phone) {
        this.phone = phone;
    }
}
