package com.crc.secface.domain;

import lombok.Data;

@Data
public class ChangeInfo {

    /**
     * 字段属性
     */
    private String name;

    /**
     * 字段属性-中文
     */
    private String nameCN;

    /**
     * 改变后的新值
     */
    private String newValue;

    /**
     * 改变前的旧值
     */
    private String oldValue;

    /**
     * 归属清空中的原因
     */
    private String remark;
}
