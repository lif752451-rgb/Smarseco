package com.crc.secface.domain;

import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableField;
import com.baomidou.mybatisplus.annotation.TableId;
import com.baomidou.mybatisplus.annotation.TableName;
import lombok.Data;

import java.util.Date;

/**
 * @title SegmentAlarm
 * @date 2023/6/27 16:16
 * @author fuzhuangzhi
 * @description TODO
 */

/**
 * 网段关联告警表
 */
@Data
@TableName(value = "tb_segment_alarm")
public class SegmentAlarm implements Cloneable {
    /**
     * 主键id
     */
    @TableId(value = "id", type = IdType.INPUT)
    private Long id;

    /**
     * 业务md5唯一值（segment_id,alarm_id,ip,type）
     */
    @TableField(value = "uuid")
    private String uuid;

    /**
     * 网段id
     */
    @TableField(value = "segment_id")
    private Long segmentId;

    /**
     * 告警主键id
     */
    @TableField(value = "alarm_id")
    private String alarmId;

    /**
     * 告警code
     */
    @TableField(value = "alarm_code")
    private String alarmCode;

    /**
     * ip
     */
    @TableField(value = "ip")
    private String ip;

    /**
     * ip所属单位
     */
    @TableField(value = "company")
    private String company;

    /**
     * ip所属类型 1：攻击IP 2:受害IP 3:攻击IP和受害IP
     */
    @TableField(value = "type")
    private String type;

    /**
     * 告警所属类型 1：告警闭环 2：实战告警
     */
    @TableField(value = "alarm_type")
    private String alarmType;

    /**
     * 告警级别
     */
    //@TableField(value = "\"LEVEL\"")
    private String level;

    /**
     * 告警级别名称
     */
    @TableField(value = "level_label")
    private String levelLabel;

    /**
     * 攻击结果
     */
    @TableField(value = "attack_result")
    private String attackResult;

    /**
     * 攻击结果名称
     */
    @TableField(value = "attack_result_label")
    private String attackResultLabel;

    /**
     * 攻击手段
     */
    @TableField(value = "attack_means")
    private String attackMeans;

    /**
     * 攻击手段名称
     */
    @TableField(value = "attack_means_label")
    private String attackMeansLabel;

    /**
     * 告警时间
     */
    @TableField(value = "alarm_time")
    private Date alarmTime;

    /**
     * 创建时间
     */
    @TableField(value = "create_time")
    private Date createTime;

    /**
     * 工单状态
     */
    @TableField(value = "order_status")
    private String orderStatus;

    /**
     * 攻击ip
     */
    @TableField(exist = false)
    private String attackIp;

    /**
     * 受害ip/url
     */
    @TableField(exist = false)
    private String victimizedIp;

    @Override
    public SegmentAlarm clone() {
        try {
            return (SegmentAlarm) super.clone();
        } catch (CloneNotSupportedException e) {
            return null;
        }
    }
}