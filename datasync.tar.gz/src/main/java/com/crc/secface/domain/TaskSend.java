package com.crc.secface.domain;

public class TaskSend {
    String depend1;
    int total;
    int numOfSend;
    String taskId;
    String depend2;
    String fishType;
    String flag;

    public String getFlag() {
        return flag;
    }

    public void setFlag(String flag) {
        this.flag = flag;
    }

    public String getDepend1() {
        return depend1;
    }

    public void setDepend1(String depend1) {
        this.depend1 = depend1;
    }

    public int getTotal() {
        return total;
    }

    public void setTotal(int total) {
        this.total = total;
    }

    public int getNumOfSend() {
        return numOfSend;
    }

    public void setNumOfSend(int numOfSend) {
        this.numOfSend = numOfSend;
    }

    public String getTaskId() {
        return taskId;
    }

    public void setTaskId(String taskId) {
        this.taskId = taskId;
    }

    public String getDepend2() {
        return depend2;
    }

    public void setDepend2(String depend2) {
        this.depend2 = depend2;
    }

    public void addTotal(int i) {
        this.total += i;
    }

    public void addNumOfSend(int i) {
        this.numOfSend += i;
    }

    public String getFishType() {
        return fishType;
    }

    public void setFishType(String fishType) {
        this.fishType = fishType;
    }
}
