package com.crc.secface.domain;

import com.baomidou.mybatisplus.annotation.TableName;
import com.baomidou.mybatisplus.extension.activerecord.Model;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.experimental.Accessors;

import java.util.Date;

/**
 * <p>
 *
 * </p>
 *
 * @author hejingsheng1
 * @since 2022-12-28
 */
@Data
@EqualsAndHashCode(callSuper = false)
@Accessors(chain = true)
@TableName("tb_event_calculation")
public class EventCalculation extends Model<EventCalculation> {

    private static final long serialVersionUID = 1L;

    /**
     * 事件主键
     */
    private String eventId;
    /**
     * 攻击IP
     */
    private String ip;
    /**
     * 攻击结果
     */
    private String attackResult;
    /**
     * 告警时间
     */
    private Date alarmTime;
    /**
     * 事件编号
     */
    private String qaxtId;
    private String company;
    /**
     * 攻击类型
     */
    private String attackType;


}
