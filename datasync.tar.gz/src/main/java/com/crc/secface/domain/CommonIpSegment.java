package com.crc.secface.domain;

import lombok.Data;

import java.util.Date;

/**
 * @title CommonIpSegment
 * @date 2023/8/2 18:57
 * @author fuzhuangzhi
 * @description TODO
 */

/**
 * 公共IP/网段表
 */
@Data
public class CommonIpSegment {
    /**
     * 主键id
     */
    private Long id;

    /**
     * 业务id
     */
    private String businessId;

    /**
     * 业务type
     */
    private String businessType;

    /**
     * 创建人
     */
    private String createBy;

    /**
     * 最后修改人
     */
    private String updateBy;

    /**
     * 创建时间
     */
    private Date createTime;

    /**
     * 最后修改时间
     */
    private Date updateTime;
}