package com.crc.secface.domain;

import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableId;
import com.baomidou.mybatisplus.annotation.TableName;
import com.baomidou.mybatisplus.extension.activerecord.Model;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.experimental.Accessors;

import java.util.Date;

/**
 * <p>
 * foradar扫描互联网信息
 * </p>
 *
 * @author hejingsheng1
 * @since 2023-04-03
 */
@Data
@EqualsAndHashCode(callSuper = false)
@Accessors(chain = true)
@TableName("tb_f5_foradar_info")
public class F5ForadarInfo extends Model<F5ForadarInfo> {

    private static final long serialVersionUID = 1L;
    String uuid;
    /**
     * 主键ID
     */
    @TableId(value = "id", type = IdType.AUTO)
    private Long id;
    /**
     * 互联网IP
     */
    private String internetIp;
    /**
     * 扫描来源
     */
    private String source;
    /**
     * 端口
     */
    private String port;
    /**
     * 协议
     */
    private String proto;
    /**
     * 企业名称
     */
    private String companyName;
    /**
     * URL
     */
    private String url;
    /**
     * 网站标题
     */
    private String siteTitle;
    /**
     * 状态码
     */
    private String siteCode;
    /**
     * 组件信息
     */
    private String softname;
    /**
     * 地理信息
     */
    private String area;
    /**
     * 创建时间
     */
    private Date createTime;
    /**
     * 修改时间
     */
    private Date updateTime;
    /**
     * 删除标记(0正常 1删除)
     */
    private Integer delFlag;

}
