package com.crc.secface.domain;

import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableField;
import com.baomidou.mybatisplus.annotation.TableId;
import com.baomidou.mybatisplus.annotation.TableName;
import java.util.Date;
import lombok.Data;

/**
 * @title AssetAlarm
 * @date 2023/7/31 11:17
 * @author fuzhuangzhi
 * @description TODO
 */

/**
    * 资产关联告警表
    */
@Data
@TableName(value = "tb_asset_alarm")
public class AssetAlarm {
    /**
     * 主键id
     */
    @TableId(value = "id", type = IdType.AUTO)
    private Long id;

    /**
     * 业务md5唯一值（asset_id,alarm_id,type,alarm_type）
     */
    @TableField(value = "uuid")
    private String uuid;

    /**
     * 资产id
     */
    @TableField(value = "asset_id")
    private Long assetId;

    /**
     * ip
     */
    @TableField(value = "ip")
    private String ip;

    /**
     * 告警主键id
     */
    @TableField(value = "alarm_id")
    private String alarmId;

    /**
     * 告警code
     */
    @TableField(value = "alarm_code")
    private String alarmCode;

    /**
     * 所属单位名称
     */
    @TableField(value = "affiliation_dept_name")
    private String affiliationDeptDame;

    /**
     * 网络区域名称
     */
    @TableField(value = "area_name")
    private String areaName;

    /**
     * ip所属类型 1：攻击IP 2:受害IP 3:攻击IP和受害IP
     */
    @TableField(value = "type")
    private String type;

    /**
     * 告警所属类型 1：告警闭环 2：实战告警
     */
    @TableField(value = "alarm_type")
    private String alarmType;

    /**
     * 工单状态
     */
    @TableField(value = "order_status")
    private String orderStatus;

    /**
     * 创建时间
     */
    @TableField(value = "create_time")
    private Date createTime;

    /**
     * 最后修改时间
     */
    @TableField(value = "update_time")
    private Date updateTime;

}