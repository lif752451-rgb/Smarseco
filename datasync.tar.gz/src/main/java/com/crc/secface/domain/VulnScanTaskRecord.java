package com.crc.secface.domain;

import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableField;
import com.baomidou.mybatisplus.annotation.TableId;
import com.baomidou.mybatisplus.annotation.TableName;
import com.baomidou.mybatisplus.extension.activerecord.Model;
import com.crc.scanner.tool.ScanInputUtils;
import com.fasterxml.jackson.annotation.JsonFormat;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.experimental.Accessors;

import java.util.Date;

/**
 * <p>
 * 漏洞扫描任务表记录表
 * </p>
 *
 * @author hejingsheng
 * @since 2022-12-05
 */
@Data
@EqualsAndHashCode(callSuper = false)
@Accessors(chain = true)
@TableName("tb_vuln_scan_task_record")
public class VulnScanTaskRecord extends Model<VulnScanTaskRecord> {

    private static final long serialVersionUID = 1L;

    @TableId(value = "id", type = IdType.AUTO)
    private Long id;
    /**
     * 任务ID
     */
    private String taskId;

    @TableField(exist = false)
    private String taskName;
    /**
     * 扫描结果
     */
    private String scanResult;
    /**
     * 具体漏洞数据（VulnProcessReviewTask的vulCode串）
     */
    private String reviews;
    /**
     * 任务状态
     */
    private Integer scanStatus;
    /**
     * 完成进度
     */
    private Integer scanProgress;
    /**
     * 扫描开始时间
     */
    @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss", timezone = "GMT+8")
    private Date scanStartTime;
    /**
     * 扫描结束时间
     */
    @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss", timezone = "GMT+8")
    private Date scanEndTime;
    /**
     * 创建人
     */
    private String createBy;
    /**
     * 创建人+中文
     */
    private String createByLabel;
    /**
     * 更新人
     */
    private String updateBy;
    /**
     * 更新时间
     */
    @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss", timezone = "GMT+8")
    private Date updateTime;
    /**
     * 创建时间
     */
    @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss", timezone = "GMT+8")
    private Date createTime;
    /**
     * 删除标记（0-有效，1-已删除）
     */
    private Integer delFlag;

    @TableField(exist = false)
    private Integer taskDelFlag;

    @TableField(exist = false)
    private Long engineId;

    @TableField(exist = false)
    private Integer contentType;

    @TableField(exist = false)
    private String scanContent;

    public String getScanContentX() {
        return ScanInputUtils.getScanContent(scanContent, contentType);
    }

    /**
     * 备注
     */
    private String remark;

    private Long duration;//耗时

    Long ipTotal;//有效IP总数
}
