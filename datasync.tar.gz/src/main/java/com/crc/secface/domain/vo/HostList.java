package com.crc.secface.domain.vo;

/**
 * 系统任务主机列表
 * @author: 村长
 * @date: 2023-04-03 15:02:34
 */
public class HostList {

  /** IP地址 */
  private String ipAddress;
  /** 主机名称 */
  private String ipName;
  /** 操作系统 */
  private String os;
  /** 主机风险评估分 */
  private String hostRiskValue;
  /** 扫描耗时 */
  private String hostCheckTime;
  /** 风险值的级别 */
  private String hostRiskLevel;
  /**任务创建时间 格式:1657019553 */
  private String createTime;
  /**任务唯一标识 */
  private String uuid;
  /**漏洞高风险（个） */
  private Integer high;
  /**漏洞中风险（个） */
  private Integer medium;
  /**漏洞低风险（个） */
  private Integer low;
  /**漏洞信息风险（个） */
  private Integer info;
  /**漏洞风险总计 */
  private Integer total;

  public String getIpAddress() {
    return ipAddress;
  }

  public void setIpAddress(String ipAddress) {
    this.ipAddress = ipAddress;
  }

  public String getIpName() {
    return ipName;
  }

  public void setIpName(String ipName) {
    this.ipName = ipName;
  }

  public String getOs() {
    return os;
  }

  public void setOs(String os) {
    this.os = os;
  }

  public String getHostRiskValue() {
    return hostRiskValue;
  }

  public void setHostRiskValue(String hostRiskValue) {
    this.hostRiskValue = hostRiskValue;
  }

  public String getHostCheckTime() {
    return hostCheckTime;
  }

  public void setHostCheckTime(String hostCheckTime) {
    this.hostCheckTime = hostCheckTime;
  }

  public String getHostRiskLevel() {
    return hostRiskLevel;
  }

  public void setHostRiskLevel(String hostRiskLevel) {
    this.hostRiskLevel = hostRiskLevel;
  }

  public String getCreateTime() {
    return createTime;
  }

  public void setCreateTime(String createTime) {
    this.createTime = createTime;
  }

  public String getUuid() {
    return uuid;
  }

  public void setUuid(String uuid) {
    this.uuid = uuid;
  }

  public Integer getHigh() {
    return high;
  }

  public void setHigh(Integer high) {
    this.high = high;
  }

  public Integer getMedium() {
    return medium;
  }

  public void setMedium(Integer medium) {
    this.medium = medium;
  }

  public Integer getLow() {
    return low;
  }

  public void setLow(Integer low) {
    this.low = low;
  }

  public Integer getInfo() {
    return info;
  }

  public void setInfo(Integer info) {
    this.info = info;
  }

  public Integer getTotal() {
    return total;
  }

  public void setTotal(Integer total) {
    this.total = total;
  }
}
