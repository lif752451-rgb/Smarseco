package com.crc.secface.domain.vo;

import lombok.Data;

import java.util.Date;

/**
 * @author fuzhuangzhi
 * @title CommonIpAndSegmentAlarmVo
 * @date 2023/8/3 9:38
 * @description IP/网段关联告警返回
 */
@Data
public class CommonIpAndSegmentAlarmVo {

    /**
     * 公共id
     */
    private Long commonIpSegmentId;

    /**
     * ip
     */
    private String ip;

    /**
     * 唯一标识
     */
    private String uuid;

    /**
     * 告警id
     */
    private String alarmId;

    /**
     * ip所属类型 1：攻击IP 2:受害IP 3:攻击IP和受害IP
     */
    private String type;

    /**
     * 告警所属类型 1：告警闭环 2：实战告警
     */
    private String alarmType;

    /**
     * 告警攻击IP
     */
    private String attackIp;

    /**
     * 告警受害IP
     */
    private String victimizedIp;

    /**
     * 工单状态
     */
    private String orderStatus;

    /**
     * 创建时间
     */
    private Date createTime;

    /**
     * 修改时间
     */
    private Date updateTime;
}
