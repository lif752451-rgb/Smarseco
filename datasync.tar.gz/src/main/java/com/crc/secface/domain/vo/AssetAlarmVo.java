package com.crc.secface.domain.vo;

import lombok.Data;

/**
 * @author fuzhuangzhi
 * @title AssetAlarmVo
 * @date 2023/7/31 13:56
 * @description TODO
 */
@Data
public class AssetAlarmVo {

    /**
     * ip
     */
    private String ip;

    /**
     * 资产主键id
     */
    private Long assetId;

    /**
     * 告警code
     */
    private String alarmCode;

    /**
     * 告警id
     */
    private String alarmId;

    /**
     * ip所属类型 1：攻击IP 2:受害IP 3:攻击IP和受害IP
     */
    private String type;

    /**
     * 告警攻击IP
     */
    private String attackIp;

    /**
     * 告警受害IP
     */
    private String victimizedIp;

    /**
     * 工单状态
     */
    private String orderStatus;
}
