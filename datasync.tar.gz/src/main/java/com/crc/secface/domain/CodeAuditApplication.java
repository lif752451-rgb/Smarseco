package com.crc.secface.domain;

import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableId;
import com.baomidou.mybatisplus.annotation.TableName;
import com.baomidou.mybatisplus.extension.activerecord.Model;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.experimental.Accessors;

import java.util.Date;

/**
 * <p>
 * 代码审计应用表
 * </p>
 *
 * @author hejingsheng1
 * @since 2023-01-10
 */
@Data
@EqualsAndHashCode(callSuper = false)
@Accessors(chain = true)
@TableName("tb_code_audit_application")
public class CodeAuditApplication extends Model<CodeAuditApplication> {

    private static final long serialVersionUID = 1L;

    /**
     * 主键
     */
    @TableId(value = "id", type = IdType.AUTO)
    private Long id;
    /**
     * 项目id
     */
    private String projectId;
    /**
     * 应用名称
     */
    private String applicationName;
    /**
     * 应用负责人
     */
    private String applicationDuty;
    /**
     * 应用负责人label
     */
    private String applicationDutyLabel;
    /**
     * 应用描述
     */
    private String description;
    /**
     * 代码来源 1：git 2：SVN
     */
    private String source;
    /**
     * 仓库地址
     */
    private String address;
    /**
     * 登录方式 1：账号登录 2：Token登录
     */
    private String loginType;
    /**
     * 用户名
     */
    private String userName;
    /**
     * 密码
     */
    private String passWord;
    /**
     * token
     */
    private String token;
    /**
     * 代码分支
     */
    private String branch;
    /**
     * 最近检测时间
     */
    private Date recentCheckTime;
    /**
     * 代码检测次数
     */
    private Integer count;
    /**
     * 删除标识(0 未删除 1 已删除)
     */
    private String delFlag;
    /**
     * 创建人
     */
    private String createBy;
    /**
     * 创建人label
     */
    private String createByLabel;
    /**
     * 创建时间
     */
    private Date createTime;
    /**
     * 最后更新人
     */
    private String updateBy;
    /**
     * 最后更新时间
     */
    private Date updateTime;

    private String mavenUrl;

}
