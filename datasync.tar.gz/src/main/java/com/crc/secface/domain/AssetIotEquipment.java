package com.crc.secface.domain;

import com.baomidou.mybatisplus.annotation.TableName;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.experimental.Accessors;

import java.util.Date;

/**
 * <p>
 * iot设备
 * </p>
 *
 * @author yuyuhang5
 * @Date 2024/9/11 14:58
 * @Description AssetIotEquipment
 */
@Data
@EqualsAndHashCode(callSuper = false)
@Accessors(chain = true)
@TableName("tb_asset_iot_equipment")
public class AssetIotEquipment {

    private static final long serialVersionUID = 1L;

    /**
     * 主键
     */
    private String id;

    /**
     * 唯一标识码
     */
    private String uniqueCode;

    /**
     * 设备名称
     */
    private String name;

    /**
     * rtuId
     */
    private String rtuId;

    /**
     * PLC
     */
    private String rtuName;

    /**
     * 终端分组id
     */
    private String groupId;

    /**
     * 终端分组
     */
    private String groupName;

    /**
     * 井号id
     */
    private String orgGroupId;

    /**
     * 井号名称
     */
    private String orgGroupName;

    /**
     * 通信IP地址
     */
    private String ip;

    /**
     * 端口号
     */
    private String port;

    /**
     * 通道
     */
    private String channel;

    /**
     * 类型
     */
    private String type;

    /**
     * 状态
     */
    private String status;

    /**
     * 是否停用 （Y 停用  N 启用）
     */
    private String isEnable;

    /**
     * 来源创建时间
     */
    private Date dataTime;

    /**
     * 相关点位
     */
    private String todo;

    /**
     * 删除标记(0正常 1删除)
     */
    private String delFlag;
    /**
     * 创建人
     */
    private String createBy;
    /**
     * 创建时间
     */
    private Date createTime;
    /**
     * 最后修改人
     */
    private String updateBy;
    /**
     * 最后修改时间
     */
    private Date updateTime;

}
