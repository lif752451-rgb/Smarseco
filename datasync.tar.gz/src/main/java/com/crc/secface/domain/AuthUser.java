package com.crc.secface.domain;

import com.baomidou.mybatisplus.annotation.TableField;
import com.baomidou.mybatisplus.annotation.TableName;
import com.baomidou.mybatisplus.extension.activerecord.Model;

import java.util.Date;

import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.experimental.Accessors;

/**
 * <p>
 * 第三方账号表
 * </p>
 *
 * @author hejingsheng1
 * @since 2022-12-28
 */
@Data
@EqualsAndHashCode(callSuper = false)
@Accessors(chain = true)
@TableName("tb_auth_user")
public class AuthUser extends Model<AuthUser> {

    private static final long serialVersionUID = 1L;

    /**
     * 员工号
     */
    private String empno;
    /**
     * 登陆账号
     */
    private String userName;
    /**
     * 部门ID
     */
    private String deptId;
    /**
     * 部门名称
     */
    private String deptName;
    /**
     * 名称
     */
    private String firstName;
    /**
     * 姓氏
     */
    private String lastName;
    /**
     * 中文姓名
     */
    private String firstNameChn;
    /**
     * 中文姓
     */
    private String lastNameChn;
    /**
     * 显示名称
     */
    private String displayName;
    /**
     * 邮箱
     */
    private String userMail;
    /**
     * 手机号
     */
    private String userMobile;
    private Date createTime;
    /**
     * 逻辑删除标记0-有效，1被删除
     */
    private String delFlag;
    private Date updateTime;
    /**
     * 关联用户表ID
     */
    private Long refUserId;
    /**
     * 备用字段
     */
    private String ud1;
    /**
     * 备用字段
     */
    private String ud2;

    @TableField(exist = false)
    int offset;
    @TableField(exist = false)
    int pageSize;

}
