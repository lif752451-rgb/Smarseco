package com.crc.secface.domain;

import com.baomidou.mybatisplus.annotation.TableName;
import com.baomidou.mybatisplus.extension.activerecord.Model;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.experimental.Accessors;

import java.util.Date;

/**
 * <p>
 * 漏洞处置流程业务
 * </p>
 *
 * @author hejingsheng1
 * @since 2022-12-16
 */
@Data
@EqualsAndHashCode(callSuper = false)
@Accessors(chain = true)
@TableName("tb_vuln_process_handle_business")
public class VulnProcessHandleBusiness extends Model<VulnProcessHandleBusiness> {

    private static final long serialVersionUID = 1L;

    /**
     * 主键
     */
    private String id;
    /**
     * 漏洞编码
     */
    private String vulnCode;
    /**
     * 最近发起人
     */
    private String lastStartUser;
    /**
     * 最近发起人label
     */
    private String lastStartUserLabel;
    /**
     * 最近发起时间
     */
    private Date lastStartTime;
    /**
     * 工单状态（1.待处置，2.待审核，3.已归档，4.复查中）
     */
    private String workOrderState;
    /**
     * 当前进行节点类型
     */
    private String currentNodeType;
    /**
     * 当前进行节点处理人的角色
     */
    private String currentNodeOperations;
    /**
     * 当前处理人
     */
    private String currentDealUser;
    /**
     * 当前处理人昵称
     */
    private String currentDealUserNickName;
    /**
     * 漏洞修复措施
     */
    private String vulnRepairMeasures;
    /**
     * 跳过节点(多个用,分割)
     */
    private String skipNode;
    /**
     * 删除标识(0 未删除 1 已删除)
     */
    private String delFlag;
    /**
     * 创建人
     */
    private String createBy;
    /**
     * 创建人label
     */
    private String createByLabel;
    /**
     * 创建时间
     */
    private Date createTime;
    /**
     * 最后更新人
     */
    private String updateBy;
    /**
     * 最后更新时间
     */
    private Date updateTime;

}
