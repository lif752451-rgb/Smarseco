package com.crc.secface.domain;

import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableField;
import com.baomidou.mybatisplus.annotation.TableId;
import com.baomidou.mybatisplus.annotation.TableName;
import com.fasterxml.jackson.annotation.JsonFormat;
import lombok.Data;

import java.util.Date;

/**
 * 实战告警闭环-告警信息主表
 * 
 * @author zhangbing
 */
@Data
@TableName(value = "tb_alarm_combat_report")
public class AlarmCombatReport {

    /**
     * 主键
     */
    @TableId(value = "id", type = IdType.ASSIGN_UUID)
    private String id;

    /**
     * 告警id
     */
    @TableField(value = "alarm_id")
    private String alarmId;

    /**
     * 标题
     */
    @TableField(value = "title")
    private String title;

    /**
     * 漏洞关键字
     */
    @TableField(value = "vul_keyword")
    private String vulKeyword;

    /**
     * 攻击ip
     */
    @TableField(value = "attack_ip")
    private String attackIp;

    /**
     * 攻击ip归属信息
     */
    @TableField(value = "attack_ascription")
    private String attackAscription;

    /**
     * 受害ip/url
     */
    @TableField(value = "victimized_ip")
    private String victimizedIp;

    /**
     * 受害ip/url归属信息
     */
    @TableField(value = "victimized_ascription")
    private String victimizedAscription;

    /**
     * 告警级别
     */
    @TableField(value = "level")
    private String level;

    /**
     * 告警级别名称
     */
    @TableField(value = "level_label")
    private String levelLabel;

    /**
     * 攻击结果
     */
    @TableField(value = "attack_result")
    private String attackResult;

    /**
     * 攻击结果名称
     */
    @TableField(value = "attack_result_label")
    private String attackResultLabel;

    /**
     * 攻击手段
     */
    @TableField(value = "attack_means")
    private String attackMeans;

    /**
     * 攻击手段名称
     */
    @TableField(value = "attack_means_label")
    private String attackMeansLabel;

    /**
     * 行为性质(0 正常 1 异常)
     */
    @TableField(value = "behavior_nature")
    private String behaviorNature;

    /**
     * 告警来源
     */
    @TableField(value = "alarm_source")
    private String alarmSource;

    /**
     * 告警来源名称
     */
    @TableField(value = "alarm_source_label")
    private String alarmSourceLabel;

    /**
     * 攻击次数
     */
    @TableField(value = "attack_count")
    private Integer attackCount;

    /**
     * 提交人
     */
    @TableField(value = "commit_user_name")
    private String commitUserName;

    /**
     * 提交人姓名
     */
    @TableField(value = "commit_nick_name")
    private String commitNickName;

    /**
     * 告警详情
     */
    @TableField(value = "detail")
    private String detail;

    /**
     * 告警时间
     */
    @TableField(value = "alarm_time")
    @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss", timezone = "GMT+8")
    private Date alarmTime;

    /**
     * 流程处理完成时间
     */
    @TableField(value = "complete_time")
    @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss", timezone = "GMT+8")
    private Date completeTime;

    /**
     * 备注
     */
    @TableField(value = "remark")
    private String remark;

    /**
     * 工单状态 创建 研判 处置 后续跟进 审核 归档 无需处置
     */
    @TableField(value = "order_status")
    private String orderStatus;

    /**
     * 当前处理人姓名
     */
    @TableField(value = "current_deal_user")
    private String currentDealUser;

    /**
     * 当前处理人姓名
     */
    @TableField(value = "current_deal_user_nick_name")
    private String currentDealUserNickName;

    /**
     * 节点名称
     */
    @TableField(value = "node_key")
    private String nodeKey;

    /**
     * 已失陷IP
     */
    @TableField(value = "fallen_ip")
    private String fallenIp;

    /**
     * 上报类型（0 手动 1 系统自动）
     */
    @TableField(value = "report_type")
    private Integer reportType;

    /**
     * 处理时间
     */
    @TableField(value = "handling_time")
    @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss", timezone = "GMT+8")
    private Date handlingTime;

    /**
     * 重点关注标记（0 未重点关注，1 已重点关注）
     */
    @TableField(value = "focus_tag")
    private Integer focusTag;

    /**
     * AI研判值
     */
    @TableField(value = "ai_check")
    private Double aiCheck;

    /**
     * 最后一次溯源状态(0 无需溯源 1 溯源中 2 溯源完毕)
     */
    @TableField(value = "traceability_status")
    private String traceabilityStatus;

    /**
     * 最后一次溯源状态名称
     */
    @TableField(value = "traceability_status_label")
    private String traceabilityStatusLabel;

    /**
     * 告警设备
     */
    @TableField(value = "device")
    private String device;

    /**
     * 告警模型ID
     */
    @TableField(value = "event_model_id")
    private String eventModelId;

    /**
     * 租户ID
     */
    @TableField(value = "organization_id")
    private String organizationId;

    /**
     * 作战周期类型
     */
    @TableField(value = "fight_period_type")
    private String fightPeriodType;

    /**
     * 租户ID 为100 不为空； 非100 为空 流程来源(集团流程、租户流程#租户一层部门名称#)
     */
    @TableField(value = "process_source")
    private String processSource;

    /**
     * 知识库告警处置建议知识ID
     */
    @TableField(value = "knowledge_alarm_handle_id")
    private String knowledgeAlarmHandleId;

    /**
     * 创建人姓名
     */
    @TableField(value = "create_by_label")
    private String createByLabel;

    /**
     * 删除标记(0正常 1删除)
     */
    @TableField(value = "del_flag")
    private String delFlag;

    /**
     * 责任部门ID
     */
    @TableField(value = "duty_dept_id")
    private Long dutyDeptId;

    /**
     * 创建时间
     */
    @TableField(value = "create_time")
    private Date createTime;

    /**
     * 上报集团流程成功租户的告警主表ID
     */
    @TableField(exist = false)
    private String reportGroupReportId;

    /**
     * 是否转风险
     */
    @TableField(exist = false)
    private String isTurnRisk;

    /**
     * 申请集团协助 0 否 1 是
     */
    @TableField(exist = false)
    private String applyGroupAssist;

    /**
     * 上报集团流程 0 未上报 1 已上报
     */
    @TableField(exist = false)
    private String reportGroupProcess;

    /**
     * 节点已读状态
     */
    @TableField(exist = false)
    private String nodeReadStatus;

    /**
     * 重点关注等级 0-5
     */
    @TableField(exist = false)
    private String attentionLevel;

    /**
     * 重点关注说明
     */
    @TableField(exist = false)
    private String attentionExplain;

    /**
     * 开始创建时间
     */
    @TableField(exist = false)
    private String createTimeStart;

    /**
     * 结束创建时间
     */
    @TableField(exist = false)
    private String createTimeEnd;

    /**
     * 每页大小
     */
    @TableField(exist = false)
    private Integer pageSize;

    /**
     * 当前页
     */
    @TableField(exist = false)
    private Integer pageNum;

    /**
     * 偏移量
     */
    @TableField(exist = false)
    private Integer offset;

    /**
     * 研判标签，多个用英文逗号隔开
     */
    @TableField(exist = false)
    private String judgeTag;

    /**
     * 责任部门名称
     */
    @TableField(exist = false)
    private String dutyDeptName;
}