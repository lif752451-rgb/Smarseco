package com.crc.secface.domain.vo;


import com.crc.secface.domain.AssetSegement;
import lombok.Data;

import java.util.Date;

@Data
public class IPBean {
    long begin;
    long end;
    AssetSegement segementInfo;
    String area;

    Date createTime;

    Date updateTime;

    public String getArea() {
        return area;
    }

    public void setArea(String area) {
        this.area = area;
    }

    public IPBean(long s, long e, AssetSegement segementInfo) {
        this.begin = s;
        this.end = e;
        this.segementInfo = segementInfo;
        this.createTime = segementInfo.getCreateTime();
        this.updateTime = segementInfo.getUpdateTime();
    }

    public IPBean(long s, long e, String area) {
        this.begin = s;
        this.end = e;
        this.area = area;
    }

    public long getBegin() {
        return begin;
    }

    public void setBegin(long begin) {
        this.begin = begin;
    }

    public long getEnd() {
        return end;
    }

    public void setEnd(long end) {
        this.end = end;
    }

    public AssetSegement getSegementInfo() {
        return segementInfo;
    }

    public void setSegementInfo(AssetSegement segementInfo) {
        this.segementInfo = segementInfo;
    }
}
