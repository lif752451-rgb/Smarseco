package com.crc.secface.domain;

import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableId;
import com.baomidou.mybatisplus.annotation.TableName;
import com.baomidou.mybatisplus.extension.activerecord.Model;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.experimental.Accessors;

import java.util.Date;

/**
 * <p>
 * 代码审计上报缺陷表
 * </p>
 *
 * @author hejingsheng1
 * @since 2023-01-11
 */
@Data
@EqualsAndHashCode(callSuper = false)
@Accessors(chain = true)
@TableName("tb_code_audit_defect")
public class CodeAuditDefect extends Model<CodeAuditDefect> {

    private static final long serialVersionUID = 1L;

    @TableId(value = "id", type = IdType.AUTO)
    private Long id;
    /**
     * 应用名称主键id
     */
    private Long appId;
    /**
     * 严重缺陷数
     */
    private Integer seriousNum;
    /**
     * 高危缺陷数
     */
    private Integer highRiskNum;
    /**
     * 中危缺陷数
     */
    private Integer midRiskNum;
    /**
     * 低危缺陷数
     */
    private Integer lowRiskNum;
    /**
     * 信息缺陷数
     */
    private Integer infoRiskNum;
    /**
     * 来源
     */
    private String source;
    /**
     * 创建时间
     */
    private Date createTime;
    /**
     * 创建人
     */
    private String createBy;
    /**
     * 更新时间
     */
    private Date updateTime;
    /**
     * 更新人
     */
    private String updateBy;
    /**
     * 删除标记 0 正常  1删除
     */
    private Integer delFlag;
    /**
     * 总数
     */
    private Integer totalNum;
    /**
     * 缺陷id
     */
    private String codeId;
    /**
     * 推送状态，0 未推送  1已推送
     */
    private Integer status;
    /**
     * 推送人
     */
    private String pushPerson;
    /**
     * 推送时间
     */
    private Date pushTime;
    /**
     * 创建人label
     */
    private String createByLabel;
    private String affiliationDeptName;

    private String affiliationDeptNodeId;

    private String appName;

    private String projectName;

    private String projectDutyLabel;

    private String projectDuty;

}
