package com.crc.secface.domain.vo;

import java.util.List;

/**
 * WEB扫描任务漏洞列表
 * @author: 村长
 * @date: 2023-04-04 10:52:08
 */
public class WebList {

  /**任务创建时间 格式:1675929721 */
  private String createTime;
  /**开始时间 格式:2023-02-09 16:02:16 */
  private String startTime;
  /**结束时间 格式:2023-02-09 16:38:39 */
  private String endTime;
  /**持续时间 格式:36mins23sec */
  private String checkTime;
  /**进度 格式:100% */
  private String progress;
  /**扫描引擎 */
  private String distributed;
  /**任务状态 */
  private String statusCn;
  /**站点信息 */
  private List<WebSites> sites;
  /**web漏洞信息 */
  private List<WebScanVulnInfos> webScanVulnInfos;

  public String getCreateTime() {
    return createTime;
  }

  public void setCreateTime(String createTime) {
    this.createTime = createTime;
  }

  public String getStartTime() {
    return startTime;
  }

  public void setStartTime(String startTime) {
    this.startTime = startTime;
  }

  public String getEndTime() {
    return endTime;
  }

  public void setEndTime(String endTime) {
    this.endTime = endTime;
  }

  public String getCheckTime() {
    return checkTime;
  }

  public void setCheckTime(String checkTime) {
    this.checkTime = checkTime;
  }

  public String getProgress() {
    return progress;
  }

  public void setProgress(String progress) {
    this.progress = progress;
  }

  public String getDistributed() {
    return distributed;
  }

  public void setDistributed(String distributed) {
    this.distributed = distributed;
  }

  public String getStatusCn() {
    return statusCn;
  }

  public void setStatusCn(String statusCn) {
    this.statusCn = statusCn;
  }

  public List<WebSites> getSites() {
    return sites;
  }

  public void setSites(List<WebSites> sites) {
    this.sites = sites;
  }

  public List<WebScanVulnInfos> getWebScanVulnInfos() {
    return webScanVulnInfos;
  }

  public void setWebScanVulnInfos(List<WebScanVulnInfos> webScanVulnInfos) {
    this.webScanVulnInfos = webScanVulnInfos;
  }
}
