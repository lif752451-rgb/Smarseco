package com.crc.secface.domain.vo;


import lombok.Data;

@Data
public class ReviewVo {
    Long id;
    String ip;
    String vulCode;
    Long engineId;
    String vulId;
    String createBy;
    Integer category;
}
