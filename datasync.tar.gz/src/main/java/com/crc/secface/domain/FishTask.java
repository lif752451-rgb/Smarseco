package com.crc.secface.domain;


public class FishTask {
    String taskName;
    String taskId;
    String taskType;
    String buId;
    String buName;
    int total;
    int numOfSend;
    String capStart;
    String capEnd;
    String flag;
    String newType;

    public String getNewType() {
        return newType;
    }

    public void setNewType(String newType) {
        this.newType = newType;
    }

    /**
     * 发送方式：1-邮件，2-短信
     */
    String sendType;

    public String getFlag() {
        return flag;
    }

    public void setFlag(String flag) {
        this.flag = flag;
    }

    public String getTaskName() {
        return taskName;
    }

    public void setTaskName(String taskName) {
        this.taskName = taskName;
    }

    public String getTaskId() {
        return taskId;
    }

    public void setTaskId(String taskId) {
        this.taskId = taskId;
    }

    public String getTaskType() {
        return taskType;
    }

    public void setTaskType(String taskType) {
        this.taskType = taskType;
    }

    public String getBuId() {
        return buId;
    }

    public void setBuId(String buId) {
        this.buId = buId;
    }

    public String getBuName() {
        return buName;
    }

    public void setBuName(String buName) {
        this.buName = buName;
    }

    public int getTotal() {
        return total;
    }

    public void setTotal(int total) {
        this.total = total;
    }

    public int getNumOfSend() {
        return numOfSend;
    }

    public void setNumOfSend(int numOfSend) {
        this.numOfSend = numOfSend;
    }

    public String getCapStart() {
        return capStart;
    }

    public void setCapStart(String capStart) {
        this.capStart = capStart;
    }

    public String getCapEnd() {
        return capEnd;
    }

    public void setCapEnd(String capEnd) {
        this.capEnd = capEnd;
    }

    public void addNumOfSend(int sendTotal) {
        this.numOfSend += sendTotal;
    }

    public void addTotal(int total) {
        this.total += total;
    }

    public String getSendType() {
        return sendType;
    }

    public void setSendType(String sendType) {
        this.sendType = sendType;
    }
}
