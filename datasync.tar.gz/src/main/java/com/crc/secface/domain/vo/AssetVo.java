package com.crc.secface.domain.vo;

import lombok.Data;

@Data
public class AssetVo {
    String ip;
    private Long affiliationDeptNodeId;
    private String affiliationDeptName;
    private Double safetyScore;
    /**
     * 部门路径
     */
    private String deptPath;
    /**
     * 区域路径
     */
    private String areaPath;

    /*
       存在资产责任人
     */
    public int havingAssetUser = 0;
    public int havingAssetDept = 0;
    public int assetAlarmScore = 30;
    public int assetAgentScore = 0;
    public int assetVulScore = 30;
    public int assetVulScoreLow = 0;
    public int assetVulScoreMid = 0;

}
