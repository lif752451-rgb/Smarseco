package com.crc.secface.domain.vo;

import lombok.Data;

@Data
public class CodeRuleVo {
    String id;
    String name;
    String extra;
    String lang;
}
