package com.crc.secface.domain;

import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableId;
import com.baomidou.mybatisplus.annotation.TableName;
import com.baomidou.mybatisplus.extension.activerecord.Model;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.experimental.Accessors;

import java.util.Date;

/**
 * <p>
 * 引擎管理
 * </p>
 *
 * @author hejingsheng1
 * @since 2022-12-08
 */
@Data
@EqualsAndHashCode(callSuper = false)
@Accessors(chain = true)
@TableName("tb_engine_equipment_management")
public class EngineEquipmentManagement extends Model<EngineEquipmentManagement> {

    private static final long serialVersionUID = 1L;

    /**
     * ID
     */
    @TableId(value = "id", type = IdType.AUTO)
    private Long id;
    /**
     * 创建者
     */
    private String createBy;
    /**
     * 创建时间
     */
    private Date createTime;
    /**
     * 修改者
     */
    private String updateBy;
    /**
     * 修改时间
     */
    private Date updateTime;
    /**
     * 自定义UUID
     */
    private String customUuid;
    /**
     * 删除标识(0否1是)
     */
    private Integer delFlag;
    /**
     * 设备地址
     */
    private String equipmentAddress;
    /**
     * 设备名称
     */
    private String equipmentName;
    /**
     * 扫描类型
     */
    private String scanType;
    /**
     * 设备版本
     */
    private String equipmentVersion;
    /**
     * 设备厂商
     */
    private String equipmentManufacture;
    /**
     * 设备功能
     */
    private String equipmentCapabilities;
    /**
     * 配置时间
     */
    private Date setupTime;
    /**
     * 登录用户
     */
    private String loginUser;
    /**
     * 密码
     */
    private String password;
    /**
     * 配置规则
     */
    private String rule;
    /**
     * 是否联通(0否1是)
     */
    private Integer connected;
    /**
     * 是否启用(0否1是)
     */
    private Integer enabled;
    /**
     * 节点信息
     */
    private String nodeDesc;
    /**
     * 备注
     */
    private String remark;

}
