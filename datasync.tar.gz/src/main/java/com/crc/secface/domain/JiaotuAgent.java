package com.crc.secface.domain;

import com.baomidou.mybatisplus.annotation.TableName;
import com.baomidou.mybatisplus.extension.activerecord.Model;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.experimental.Accessors;

import java.util.Date;


/**
 * <p>
 * 
 * </p>
 *
 * @author hejingsheng1
 * @since 2022-12-13
 */
@Data
@EqualsAndHashCode(callSuper = false)
@Accessors(chain = true)
@TableName("tb_jiaotu_agent")
public class JiaotuAgent extends Model<JiaotuAgent> {

    private static final long serialVersionUID = 1L;

    private String id;
    private String ip;
    /**
     * 1-在线，0-离线
     */
    private Integer status;
    /**
     * 1-linux，0-windows
     */
    private Integer type;
    /**
     * 1-卸载，0-未卸载
     */
    private Integer ifDel;
    private Date createTime;
    private Date updateTime;


}
