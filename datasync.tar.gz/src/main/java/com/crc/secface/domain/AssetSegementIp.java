package com.crc.secface.domain;

import lombok.Data;

import java.math.BigInteger;

/**
 * @author fuzhuangzhi
 * @title AssetSegementIp
 * @date 2023/6/15 19:03
 * @description TODO
 */
@Data
public class AssetSegementIp {
    private BigInteger slip;
    private BigInteger elip;
}
