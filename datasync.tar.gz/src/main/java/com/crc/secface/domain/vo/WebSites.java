package com.crc.secface.domain.vo;

/**
 * 站点信息
 * @author: 村长
 * @date: 2023-04-04 10:33:06
 */
public class WebSites {

  /**站点url */
  private String site;
  /**扫描时间 格式:12mins2sec */
  private String scanTime;
  /**风险值 */
  private String riskValue;

  public String getSite() {
    return site;
  }

  public void setSite(String site) {
    this.site = site;
  }

  public String getScanTime() {
    return scanTime;
  }

  public void setScanTime(String scanTime) {
    this.scanTime = scanTime;
  }

  public String getRiskValue() {
    return riskValue;
  }

  public void setRiskValue(String riskValue) {
    this.riskValue = riskValue;
  }
}
