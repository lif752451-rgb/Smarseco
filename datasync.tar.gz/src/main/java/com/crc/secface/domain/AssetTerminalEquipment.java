package com.crc.secface.domain;

import com.baomidou.mybatisplus.annotation.TableName;
import com.baomidou.mybatisplus.extension.activerecord.Model;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.experimental.Accessors;

import java.util.Date;

/**
 * <p>
 * 终端资产-终端设备表
 * </p>
 *
 * @author hejingsheng1
 * @since 2023-03-27
 */
@Data
@EqualsAndHashCode(callSuper = false)
@Accessors(chain = true)
@TableName("tb_asset_terminal_equipment")
public class AssetTerminalEquipment extends Model<AssetTerminalEquipment> {

    private static final long serialVersionUID = 1L;

    /**
     * 主键
     */
    private String id;
    private Long engineId;
    /**
     * IP地址
     */
    private String reportIp;
    /**
     * 计算机名
     */
    private String computerName;
    /**
     * MAC地址
     */
    private String macAddress;
    /**
     * 终端分组
     */
    private String groupName;
    /**
     * 通信IP地址
     */
    private String ip;
    /**
     * 所属组织
     */
    private String organization;
    /**
     * 责任人
     */
    private String dutyBod;
    /**
     * 使用人
     */
    private String useBod;
    /**
     * 激活状态 0 未激活 1 已激活 null 未知
     */
    private String activationStatus;
    /**
     * 在线状态 0 离线 1 在线 null 未知
     */
    private String onlineStatus;
    /**
     * 最后在线时间
     */
    private Date lastTime;
    /**
     * 操作系统版本
     */
    private String osVersion;
    /**
     * 系统架构
     */
    private String osBuild;
    /**
     * 操作系统账号
     */
    private String osAccount;
    /**
     * 最近检索时间
     */
    private Date lastRetrievalTime;
    /**
     * 序列号
     */
    private String serialNumber;
    /**
     * 数据来源
     */
    private String dataSource;
    /**
     * 删除标记(0正常 1删除)
     */
    private String delFlag;
    /**
     * 创建人
     */
    private String createBy;
    /**
     * 创建时间
     */
    private Date createTime;
    /**
     * 最后修改人
     */
    private String updateBy;
    /**
     * 最后修改时间
     */
    private Date updateTime;

    private String virusVersion;
    private String discoverVirusNum;
    private String untreatedVirusNum;
}
