package com.crc.secface.domain.vo;

import com.crc.secface.domain.Asset;
import lombok.Data;

/**
 * @author fuzhuangzhi
 * @title AssetKeywordsVo
 * @date 2023/10/9 15:13
 * @description 资产全文检索VO,用于组装tb_common_keywords中的搜索条件
 */
@Data
public class AssetKeywordsVo extends Asset {

    /**
     * 所属系统  多个用,拼接，例如：网络威胁情报平台(武汉公司),主机安全扫描系统绿盟RSAS(上海公司/上海一部)
     */
    private String appSysName;

    /**
     * 资产标签  多个用,拼接，例如：标签1,标签2,标签3
     */
    private String assetTag;

    /**
     * 责任人/运维人 只拼接姓名(账号)，多个用,拼接，例如：公娜兰(gongnalan),樊白萱(fanbaixuan)
     */
    private String personName;

    /**
     * 设备厂商
     */
    private String equipmentManufacturer;

    /**
     * 设备型号
     */
    private String equipmentModel;

    /**
     * 设备存放地址
     */
    private String equipmentStorageAddress;

    /**
     * 设备管理地址
     */
    private String equipmentManagerAddress;

    /**
     * 设备版本
     */
    private String equipmentVersion;

    /**
     * 资产编号
     */
    private String assetNumber;

    /**
     * 资产分组名称全路径
     */
    private String groupName;
}
