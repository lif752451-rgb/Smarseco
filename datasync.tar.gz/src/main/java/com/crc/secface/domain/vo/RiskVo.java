package com.crc.secface.domain.vo;

import lombok.Data;

@Data
public class RiskVo {
    boolean repair;
    String vulnCode;
    String ip;
    String agentId;
    String vulnName;
}
