package com.crc.secface.domain;

import com.baomidou.mybatisplus.annotation.TableField;
import com.baomidou.mybatisplus.annotation.TableName;
import com.baomidou.mybatisplus.extension.activerecord.Model;

import java.util.List;

import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.experimental.Accessors;

/**
 * <p>
 * 服务器资产类型
 * </p>
 *
 * @author hejingsheng1
 * @since 2023-09-21
 */
@Data
@EqualsAndHashCode(callSuper = false)
@Accessors(chain = true)
@TableName("tb_sever_asset_type")
public class SeverAssetType extends Model<SeverAssetType> {


    /**
     * 主键id
     */
    private String id;

    /**
     * 类型名称
     */
    private String typeName;

    /**
     * 父级id
     */
    private String parentId;

    /**
     * 排序
     */
    private int sortNum;

    /**
     * 备注
     */
    private String remark;

    /**
     * 创建人姓名
     */
    private String createByLabel;

    /**
     * 删除标记
     */
    private int delFlag;

    /**
     * 路径
     */
    private String ancestors;

    /**
     * 资产类型全称
     */
    @TableField(exist = false)
    private String fullPath;

    @TableField(exist = false)
    private List<SeverAssetType> children;

}
