package com.crc.secface.domain;

import com.baomidou.mybatisplus.annotation.TableField;
import com.baomidou.mybatisplus.annotation.TableName;
import com.baomidou.mybatisplus.extension.activerecord.Model;
import com.crc.scanner.tool.ScanInputUtils;
import com.fasterxml.jackson.annotation.JsonFormat;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.experimental.Accessors;
import org.apache.commons.lang3.StringUtils;

import java.util.Date;
import java.util.List;

/**
 * <p>
 * 漏洞扫描任务表
 * </p>
 *
 * @author hejingsheng
 * @since 2022-12-05
 */
@Data
@EqualsAndHashCode(callSuper = false)
@Accessors(chain = true)
@TableName("tb_vuln_scan_task")
public class VulnScanTask extends Model<VulnScanTask> {

    private static final long serialVersionUID = 1L;

    private String id;
    /**
     * 任务名称
     */
    private String taskName;

    @TableField(exist = false)
    private String engineName;

    @TableField(exist = false)
    private List<String> equipmentManufactures;

    @TableField(exist = false)
    private String engineUrl;
    @TableField(exist = false)
    private int checkStatus;
    @TableField(exist = false)
    private List<Integer> scanStates;
    /**
     * 检测类型
     */
    private Integer scanType;
    /**
     * 引擎ID
     */
    private Long engineId;
    /**
     * 执行周期
     */
    private Integer scanPeriod;
    /**
     * 扫描范围
     */
    private String scanContent;

    /**
     * 具体漏洞数据（VulnProcessReviewTask的vulCode串）
     */
    private String reviews;

    public String getScanContentX() {
        return ScanInputUtils.getScanContent(scanContent, contentType);
    }

    public String getScanContentX(String spit) {
        return ScanInputUtils.getScanContent(scanContent, contentType, spit);
    }

    /**
     * 任务状态
     */
    private Integer scanStatus;
    /**
     * 完成进度
     */
    private Integer scanProgress;
    /**
     * 扫描范围类型
     */
    private Integer contentType;
    /**
     * 定时执行日期
     */
    private String scanDate;
    /**
     * 定时执行时间
     */
    private String scanTime;
    /**
     * 创建人
     */
    private String createBy;
    /**
     * 创建人+中文
     */
    private String createByLabel;
    /**
     * 更新人
     */
    private String updateBy;
    /**
     * 更新时间
     */
    @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss", timezone = "GMT+8")
    private Date updateTime;
    /**
     * 创建时间
     */
    @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss", timezone = "GMT+8")
    private Date createTime;
    /**
     * 删除标记（0-有效，1-已删除）
     */
    private Integer delFlag;
    /**
     * 备注
     */
    private String remark;

    public boolean isGoodData() {
        if (scanPeriod == null || scanType == null || StringUtils.isBlank(scanContent) || engineId == null) {
            return false;
        }
        return true;
    }
}
