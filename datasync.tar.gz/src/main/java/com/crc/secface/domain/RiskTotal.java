package com.crc.secface.domain;

import org.apache.commons.lang3.StringUtils;

public class RiskTotal {
    String ip;
    // 总漏洞
    int total;
    // 已修复漏洞
    int repair;
    // 未修复漏洞
    int unrepair;
    // 丢弃漏洞
    int drop;

    int newFind;

    public  boolean isGood() {
        if (StringUtils.isNotBlank(ip)) {
            if (total > 0) {
                return total == (newFind + unrepair + repair);
            }
        }
        return false;
    }

    public int getNewFind() {
        return newFind;
    }

    public void setNewFind(int newFind) {
        this.newFind = newFind;
    }

    public String getIp() {
        return ip;
    }

    public void setIp(String ip) {
        this.ip = ip;
    }

    public int getTotal() {
        return total;
    }

    public void setTotal(int total) {
        this.total = total;
    }

    public int getRepair() {
        return repair;
    }

    public void setRepair(int repair) {
        this.repair = repair;
    }

    public int getUnrepair() {
        return unrepair;
    }

    public void setUnrepair(int unrepair) {
        this.unrepair = unrepair;
    }

    public int getDrop() {
        return drop;
    }

    public void setDrop(int drop) {
        this.drop = drop;
    }
}
