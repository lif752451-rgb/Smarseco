package com.crc.secface.domain;

import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableId;
import com.baomidou.mybatisplus.annotation.TableName;
import com.baomidou.mybatisplus.extension.activerecord.Model;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.experimental.Accessors;

/**
 * <p>
 * 
 * </p>
 *
 * @author hejingsheng1
 * @since 2023-04-28
 */
@Data
@EqualsAndHashCode(callSuper = false)
@Accessors(chain = true)
@TableName("tb_f5_502")
public class F5Data502 extends Model<F5Data502> {

    private static final long serialVersionUID = 1L;

    @TableId(value = "id", type = IdType.AUTO)
    private Integer id;
    /**
     * 类型
     */
    private String port;
    /**
     * 数据内容
     */
    private String ip;
    /**
     * 数据ID
     */
    private String pool;
    String sid;
    String name;
    /**
     * 引擎的逻辑判断0-有效，1无效
     */
    private Integer flag;
    private Integer dataId;
}
