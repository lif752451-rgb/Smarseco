package com.crc.secface.domain;

import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableId;
import com.baomidou.mybatisplus.annotation.TableName;
import com.baomidou.mybatisplus.extension.activerecord.Model;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.experimental.Accessors;

import java.util.Date;

/**
 * <p>
 * f5_ng_conf配置解析表
 * </p>
 *
 * @author hejingsheng1
 * @since 2023-04-03
 */
@Data
@EqualsAndHashCode(callSuper = false)
@Accessors(chain = true)
@TableName("tb_f5_ng_conf")
public class F5NgConf extends Model<F5NgConf> {

    private static final long serialVersionUID = 1L;

    /**
     * 主键ID
     */
    @TableId(value = "id", type = IdType.AUTO)
    private Long id;
    /**
     * nginx文件名
     */
    private String ngName;
    /**
     * nginx在gitlab的路径
     */
    private String ngPach;
    /**
     * 端口
     */
    private Integer port;
    /**
     * nginx解析得到的域名
     */
    private String domainName;
    /**
     * nginx解析得到的路径
     */
    private String path;
    /**
     * nginx proxy_pass字段
     */
    private String proxyPass;
    /**
     * F5LB虚拟服务器IP
     */
    private String lbVsIp;
    /**
     * F5LB虚拟服务器端口
     */
    private Integer lbVsPort;
    /**
     * 创建时间
     */
    private Date createTime;
    /**
     * 修改时间
     */
    private Date updateTime;
    /**
     * 删除标记(0正常 1删除)
     */
    private Integer delFlag;


    String uuid;
}
