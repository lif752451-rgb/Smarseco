package com.crc.secface.domain;

import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableId;
import com.baomidou.mybatisplus.annotation.TableName;
import com.baomidou.mybatisplus.extension.activerecord.Model;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.experimental.Accessors;

import java.util.Date;

/**
 * <p>
 * 代码缺陷主表
 * </p>
 *
 * @author hejingsheng1
 * @since 2023-01-11
 */
@Data
@EqualsAndHashCode(callSuper = false)
@Accessors(chain = true)
@TableName("tb_code_vuln_data")
public class CodeVulnData extends Model<CodeVulnData> {

    private static final long serialVersionUID = 1L;

    @TableId(value = "id", type = IdType.AUTO)
    private Long id;
    /**
     * 应用ID
     */
    private Long appId;
    /**
     * 来源
     */
    private Integer source;
    /**
     * 任务ID
     */
    private String taskId;
    /**
     * 缺陷代码路径
     */
    private String vulnFilePath;
    /**
     * 缺陷方法名称
     */
    private String vulnFunction;
    /**
     * 缺陷行数
     */
    private Integer vulnLine;
    /**
     * 缺陷列数
     */
    private Integer vulnCol;
    /**
     * 缺陷代码
     */
    private String errorCode;
    /**
     * 缺陷名称
     */
    private String vulnName;
    /**
     * 缺陷详情
     */
    private String meessage;
    /**
     * 缺陷级别
     */
    private Integer vulnLevel;
    private String createBy;
    private String updateBy;
    private Date createTime;
    private Date updateTime;
    private Integer delFlag;
    /**
     * 缺陷编号
     */
    private String vulnCode;
    /**
     * 缺陷扫描批次ID
     */
    private Long recordId;


}
