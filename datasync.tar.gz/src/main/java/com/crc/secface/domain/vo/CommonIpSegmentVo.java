package com.crc.secface.domain.vo;

import lombok.Data;

/**
 * @author fuzhuangzhi
 * @title CommonIpSegmentVo
 * @date 2023/8/2 19:57
 * @description TODO
 */
@Data
public class CommonIpSegmentVo {

    /**
     * common id
     */
    private Long id;

    /**
     * 输入的ip或端口
     */
    private String segment;
}
