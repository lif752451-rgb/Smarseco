package com.crc.secface.domain;

import lombok.Data;

@Data
public class AssetPatch {
    String patchId;
    String kbNum;
    String bulletId;
    String impacts;
    String patchName;
    int patchLevel;
    String publishTime;
    String patchDesc;
    String remedDesc;
    String remedCmd;
    String cvssScore;
    String cvssDetail;
    String patchRef;
    String restartOpts;
    String hasExp;
    String isKernel;
    String isLocalEscalation;
    String isRemote;
    String hasPoc;
    String pocRefs;
    String firstCheckTime;
    String businessImpact;
    String installPackage;
    String apps;
    String delFlag;
    String ip;
    String batchId;
    String createTime;

}
