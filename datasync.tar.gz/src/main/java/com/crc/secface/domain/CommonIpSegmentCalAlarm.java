package com.crc.secface.domain;

import lombok.Data;

import java.util.Date;

/**
 * @title CommonIpSegmentCalAlarm
 * @date 2023/8/2 18:57
 * @author fuzhuangzhi
 * @description TODO
 */

/**
    * 公共IP/网段关联告警表
    */
@Data
public class CommonIpSegmentCalAlarm {
    /**
    * 主键id
    */
    private Long id;

    /**
    * 公共IP/网段表主键id
    */
    private Long commonIpSegmentId;

    /**
    * 业务md5唯一值（common_ip_segment_id,ip,alarm_id,type,alarm_type）
    */
    private String uuid;

    /**
    * 相关ip
    */
    private String ip;

    /**
    * 告警主键id
    */
    private String alarmId;

    /**
    * ip所属类型 1：攻击IP 2:受害IP 3:攻击IP和受害IP
    */
    private String type;

    /**
    * 告警所属类型 1：告警闭环 2：实战告警
    */
    private String alarmType;

    /**
    * 备注
    */
    private String remark;

    /**
     * 工单状态
     */
    private String orderStatus;

    /**
    * 创建时间
    */
    private Date createTime;

    /**
    * 最后修改时间
    */
    private Date updateTime;
}