package com.crc.secface.domain;

import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableId;
import com.baomidou.mybatisplus.annotation.TableName;
import com.baomidou.mybatisplus.extension.activerecord.Model;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.experimental.Accessors;

import java.util.Date;

/**
 * <p>
 * 任务操作日志
 * </p>
 *
 * @author hejingsheng1
 * @since 2022-12-13
 */
@Data
@EqualsAndHashCode(callSuper = false)
@Accessors(chain = true)
@TableName("tb_vuln_scan_task_oplog")
public class VulnScanTaskOplog extends Model<VulnScanTaskOplog> {

    private static final long serialVersionUID = 1L;

    @TableId(value = "id", type = IdType.AUTO)
    private Long id;
    /**
     * 任务状态
     */
    private String taskId;
    /**
     * 旧状态
     */
    private Integer oldStatus;
    /**
     * 新状态
     */
    private Integer newStatus;
    private Date createTime;
    private String createBy;
    private Integer status;

}
