package com.crc.secface.domain.vo;

import lombok.Data;

/**
 * 北塔CMDB资产信息
 * @author: 村长
 * @date: 2023-05-31 15:28:51
 */
@Data
public class BetaCmdb {

  /** ip 有null的可能*/
  private String ip;
  /** 管理IP */
  private String manageIP;
  /** 资产名称 */
  private String name;
  /** 使用部门 */
  private String department;
  /** 信息中心负责人 */
  private String GDH_InformationCenter;
  /** 运维负责人 */
  private String GDH_OperationManager;
  /** 资产名称 */
  private String GDH_HostName;
  /** MAC地址 */
  private String GDH_HostMac;
  /** 网络区域 */
  private String GDH_NetworkRegion;
  /** 公网IP */
  private String GDH_PublicNetwork;
  /** 资产等级 */
  private String GDH_AssetClass;
  /** 资产分类 */
  private String classify;
  /** 环境 */
  private String GDH_Environment;
  /** 资产状态 */
  private String GDH_State;
  /** 操作系统版本 */
  private String GDH_HostSystemVersion;
  /** 内核版本 */
  private String GDH_KernelVersion;
  /** 域名 */
  private String GDH_HostDomainName;
  /** 标签 */
  private String tag;
  /** 供应商 */
  private String supplier;
  /** 品牌型号 */
  private String model;
  /** 设备版本 */
  private String GDH_DeviceVersion;
  /** 位置 */
  private String location;
  /** 管理地址 */
  private String GDH_ManageAddresses;
  /** CPU核数 */
  private String GDH_ServerCpuNumber;
  /** 内存大小（MB） */
  private String GDH_MEMsize;
  /** 内存使用率（%） */
  private String GDH_MEMUsageRate;
  /** 硬盘大小（MB） */
  private String GDH_HardDriveSize;
  /** 硬盘使用率(%) */
  private String GDH_HardUsageRate;
  /** 硬盘个数 */
  private String GDH_HardNumber;
  /** 机密性 */
  private String GDH_Confidential;
  /** 完整性 */
  private String GDH_Complete;
  /** 可用性 */
  private String GDH_Usability;
  /** 资产编号 */
  private String sn;
  /** 资源类型 */
  private String resModel;
  /** 部署位置 */
  private String GDH_DeploymentLocation;
  /** 安全支撑单位 */
  private String GDH_SupportingUnit;
  /** 是否关基 */
  private String GDH_Status;
  /** 国密改造状态 */
  private String GDH_TransformStatus;
  /** 发布互联网 */
  private String GDH_ReleaseInternet;
  /** 质保到期日 */
  private String expirationDate;
  /** 资产描述 */
  private String GDH_AssetDescription;
}
