package com.crc.secface.domain.vo;

import com.alibaba.fastjson.JSONObject;

import java.util.HashMap;

public class EventData {
    private String type;

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }

    public static EventData getData(HashMap<String, Object> document,String type) {
        EventData data = new EventData();
        data.setMap(document);
        data.setType(type);
        return data;
    }

    public static EventData getData(JSONObject document,String type) {
        EventData data = new EventData();
        data.setJson(document);
        data.setType(type);
        return data;
    }

    //Document eventDoc;
    JSONObject json;
    HashMap<String, Object> map;

    public HashMap<String, Object> getMap() {
        return map;
    }

    public void setMap(HashMap<String, Object> map) {
        this.map = map;
    }

//    public Document getEventDoc() {
//        return eventDoc;
//    }
//
//    public void setEventDoc(Document eventDoc) {
//        this.eventDoc = eventDoc;
//    }

    public JSONObject getJson() {
        return json;
    }

    public void setJson(JSONObject json) {
        this.json = json;
    }
}
