package com.crc.secface.domain.vo;

import lombok.Data;

@Data
public class RuleVo {
    String domain;
    String path;

    String virtual;
}
