package com.crc.secface.domain;

import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableField;
import com.baomidou.mybatisplus.annotation.TableId;
import com.baomidou.mybatisplus.annotation.TableName;
import com.baomidou.mybatisplus.extension.activerecord.Model;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.experimental.Accessors;

import java.util.Date;

/**
 * <p>
 * 任务执行记录表
 * </p>
 *
 * @author hejingsheng1
 * @since 2023-01-10
 */
@Data
@EqualsAndHashCode(callSuper = false)
@Accessors(chain = true)
@TableName("tb_code_check_record_log")
public class CodeCheckRecordLog extends Model<CodeCheckRecordLog> {

    private static final long serialVersionUID = 1L;

    @TableId(value = "id", type = IdType.AUTO)
    private Long id;
    private Long recordId;
    /**
     * 应用ID信息
     */
    private Long appId;
    /**
     * 扫描结果
     */
    private String result;
    private Date createTime;
    private Date updateTime;
    /**
     * 执行ID （扫描器执行的任务ID）
     */
    private String jobId;
    /**
     * 任务状态(0 未开始 1 执行中 2 执行完成 3 执行失败)
     */
    private Integer scanStatus;
    /**
     * 下发扫描任务ID
     */
    private String taskId;
    /**
     * 引擎ID
     */
    private Integer engineId;
    /**
     * 进度
     */
    private Integer progress;

    @TableField(exist = false)
    String taskName;

}
