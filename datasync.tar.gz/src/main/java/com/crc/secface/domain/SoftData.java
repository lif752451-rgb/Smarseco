package com.crc.secface.domain;

import com.alibaba.fastjson.JSONObject;
import lombok.Data;

/**
 * @author hejingsheng
 */
@Data
public class SoftData {
    String type;
    JSONObject data;
}
