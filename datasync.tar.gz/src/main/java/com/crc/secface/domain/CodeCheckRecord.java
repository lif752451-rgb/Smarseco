package com.crc.secface.domain;

import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableId;
import com.baomidou.mybatisplus.annotation.TableName;
import com.baomidou.mybatisplus.extension.activerecord.Model;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.experimental.Accessors;

import java.util.Date;

/**
 * <p>
 * 代码检测记录表
 * </p>
 *
 * @author hejingsheng1
 * @since 2023-01-05
 */
@Data
@EqualsAndHashCode(callSuper = false)
@Accessors(chain = true)
@TableName("tb_code_check_record")
public class CodeCheckRecord extends Model<CodeCheckRecord> {

    private static final long serialVersionUID = 1L;

    /**
     * 主键ID
     */
    @TableId(value = "id", type = IdType.AUTO)
    private Long id;
    /**
     * 任务id
     */
    private String taskId;
    /**
     * 缺陷id
     */
    private Long defectId;
    /**
     * 检测开始时间
     */
    private Date checkStartTime;
    /**
     * 检测结束时间
     */
    private Date checkEndTime;
    /**
     * 检测耗时
     */
    private Long checkConsuming;
    /**
     * 执行结果 1 执行成功 2 执行失败
     */
    private String result;
    /**
     * 删除标识(0 未删除 1 已删除)
     */
    private String delFlag;

    private Integer progress;
}
