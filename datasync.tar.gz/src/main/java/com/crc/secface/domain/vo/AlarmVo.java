package com.crc.secface.domain.vo;

import lombok.Data;

import java.math.BigInteger;
import java.util.Date;

/**
 * @author fuzhuangzhi
 * @title AlarmVo
 * @date 2023/8/2 21:16
 * @description TODO
 */
@Data
public class AlarmVo {
    long id;
    /**
     * 告警code
     */
    private String alarmCode;

    /**
     * 告警id
     */
    private String alarmId;


    /**
     * ip所属类型 1：攻击IP 2:受害IP 3:攻击IP和受害IP
     */
    private String type;

    /**
     * 告警所属类型 1：告警闭环 2：实战告警
     */
    private String alarmType;

    /**
     * 告警攻击IP
     */
    private String attackIp;

    /**
     * 告警受害IP
     */
    private String victimizedIp;

    /**
     * ip
     */
    private String ip;
    private BigInteger longIp;

    /**
     * remark
     */
    private String remark;

    /**
     * 工单状态
     */
    private String orderStatus;

    /**
     * 创建时间
     */
    private Date createTime;

    /**
     * 修改时间
     */
    private Date updateTime;
    String delFlag;
}
