package com.crc.secface.domain.vo;

import lombok.Data;

/**
 * @author fuzhuangzhi
 * @title SegmentAlarmVo
 * @date 2023/6/27 18:09
 * @description TODO
 */
@Data
public class SegmentAlarmVo {

    /**
     * 告警主键id
     */
    private String id;

    /**
     * 告警code
     */
    private String alarmId;

    /**
     * 攻击ip
     */
    private String attackIp;

    /**
     * 受害ip/url
     */
    private String victimizedIp;

    /**
     * 告警级别
     */
    private String level;

    /**
     * 告警级别名称
     */
    private String levelLabel;

    /**
     * 攻击结果
     */
    private String attackResult;

    /**
     * 攻击结果名称
     */
    private String attackResultLabel;

    /**
     * 攻击手段
     */
    private String attackMeans;

    /**
     * 攻击手段名称
     */
    private String attackMeansLabel;

    /**
     * 创建时间
     */
    private String createTime;

    /**
     * 告警时间
     */
    private String alarmTime;

    /**
     * 工单状态
     */
    private String orderStatus;

}
