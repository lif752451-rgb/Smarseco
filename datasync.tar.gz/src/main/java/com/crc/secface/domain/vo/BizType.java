package com.crc.secface.domain.vo;

/**
 * 设备类型
 * @author: 村长
 * @date: 2023-05-31 15:07:03
 */
public class BizType {

  /** name */
  private String name;
  /** displayName */
  private String displayName;

  public String getName() {
    return name;
  }

  public void setName(String name) {
    this.name = name;
  }

  public String getDisplayName() {
    return displayName;
  }

  public void setDisplayName(String displayName) {
    this.displayName = displayName;
  }
}
