package com.crc.secface.domain;

import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableField;
import com.baomidou.mybatisplus.annotation.TableId;
import com.baomidou.mybatisplus.annotation.TableName;
import com.baomidou.mybatisplus.extension.activerecord.Model;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.experimental.Accessors;

import java.util.Date;

/**
 * <p>
 * 
 * </p>
 *
 * @author hejingsheng1
 * @since 2022-12-28
 */
@Data
@EqualsAndHashCode(callSuper = false)
@Accessors(chain = true)
@TableName("tb_asset_baseline")
public class AssetBaseline extends Model<AssetBaseline> {

    private static final long serialVersionUID = 1L;

    @TableId(value = "id", type = IdType.AUTO)
    private Long id;
    /**
     * IP
     */
    private String ip;
    /**
     * 描述
     */
    private String description;
    /**
     * 检查类型
     */
    private String category;
    /**
     * 检查内容
     */
    private String content;
    /**
     * 检查项名称
     */
    private String title;
    /**
     * 引用信息
     */
    private String reference;
    /**
     * 危险级别0:低危, 1:中危, 2:高危, 3:严重
     */
    private Integer level;
    /**
     * 修复建议
     */
    private String remedDes;
    private String batchId;
    private String createBy;
    private Date createTime;
    private String updateBy;
    private Date updateTime;
    private String delFlag;
    /**
     * -1失败, 0未通过,1通过
     */
    private Integer flag;
    /**
     * 检查模版
     */
    private String ruleName;
    /**
     * 原始ID
     */
    private String baseId;

    String result;


    @TableField(exist = false)
    String key;
    public  String getKey(){
        return ip + title + level + category;
    }
}
