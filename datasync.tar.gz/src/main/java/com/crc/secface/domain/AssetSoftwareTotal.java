package com.crc.secface.domain;

import com.baomidou.mybatisplus.extension.activerecord.Model;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.experimental.Accessors;

/**
 * <p>
 * 
 * </p>
 *
 * @author hejingsheng
 * @since 2022-12-06
 */
@Data
@EqualsAndHashCode(callSuper = false)
@Accessors(chain = true)
public class AssetSoftwareTotal extends Model<AssetSoftwareTotal> {

    private static final long serialVersionUID = 1L;

    private long id;
    /**
     * 软件名称
     */
    private String softName;
    /**
     * 软件版本
     */
    private String softVersion;
    /**
     * 软件厂商
     */
    private String softManu;
    /**
     * 组件版本转换后数据
     */
    private Long softVersionNum;

    long total;
}
