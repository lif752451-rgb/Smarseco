package com.crc.secface.domain;

import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableId;
import com.baomidou.mybatisplus.annotation.TableName;
import com.baomidou.mybatisplus.extension.activerecord.Model;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.experimental.Accessors;

import java.util.Date;

/**
 * <p>
 * 关系表
 * </p>
 *
 * @author hejingsheng1
 * @since 2023-04-03
 */
@Data
@EqualsAndHashCode(callSuper = false)
@Accessors(chain = true)
@TableName("tb_f5_ng_conf_asset_rela")
public class F5NgConfAssetRela extends Model<F5NgConfAssetRela> {

    private static final long serialVersionUID = 1L;

    /**
     * 主键ID
     */
    @TableId(value = "id", type = IdType.AUTO)
    private Long id;
    /**
     * f5_ng_conf ID
     */
    private Long f5NgConfId;
    /**
     * 资产表主键ID
     */
    private Long assetId;
    /**
     * 资产端口表主键ID
     */
    private String assetPortId;
    /**
     * 创建时间
     */
    private Date createTime;
    /**
     * 修改时间
     */
    private Date updateTime;
    /**
     * 删除标记(0正常 1删除)
     */
    private Integer delFlag;

}
