package com.crc.secface.domain;

import com.baomidou.mybatisplus.annotation.TableField;
import com.baomidou.mybatisplus.annotation.TableName;
import com.baomidou.mybatisplus.extension.activerecord.Model;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.experimental.Accessors;

import java.util.Date;

/**
 * <p>
 *
 * </p>
 *
 * @author hejingsheng
 * @since 2022-12-06
 */
@Data
@EqualsAndHashCode(callSuper = false)
@Accessors(chain = true)
@TableName("tb_asset_port")
public class AssetPort extends Model<AssetPort> {

    private static final long serialVersionUID = 1L;

    private String id;
    /**
     * IP
     */
    private String ip;
    /**
     * 端口
     */
    private String port;
    /**
     * 协议
     */
    private String proto;
    /**
     * 服务类型
     */
    private String type;
    /**
     * 录入时间
     */
    private Date createDate;
    /**
     * 最近更新时间
     */
    private String lastUpdate;
    /**
     * 同步标志，无需展示
     */
    private String syncStatus;
    /**
     * 组织ID
     */
    private String companyId;
    /**
     * （1：主机；0：容器）
     */
    private String devType;

    private String listenerProcess;
    private String poolPath;

    @TableField(exist = false)
    Long assetId;
}
