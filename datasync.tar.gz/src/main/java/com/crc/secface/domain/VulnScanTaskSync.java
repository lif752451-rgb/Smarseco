package com.crc.secface.domain;

import lombok.Data;

import java.util.Date;

/**
 * @title VulnSync
 * @date 2023/11/22 15:39
 * @author fuzhuangzhi
 * @description TODO
 */

/**
 * 漏洞手动同步表
 */
@Data
public class VulnScanTaskSync  {
    Long id;
    /**
     * 引擎id,多个用英文逗号分隔，字典：vul_data_source
     */
    private String scanEngine;

    /**
     * 邮件是否发送，0：是 1：否
     */
    private String emailStatus;

    /**
     * 邮件接收人，多个用英文逗号分隔
     */
    private String emailReceive;

    /**
     * 企业微信是否发送，0：是 1：否
     */
    private String vxStatus;

    /**
     * 企业微信接收人，多个用英文逗号分隔
     */
    private String vxReceive;

    /**
     * 扫描开始时间
     */
    private Date scanStartTime;
    private Date createTime;

    /**
     * 扫描结束时间
     */
    private Date scanEndTime;

    /**
     * 扫描状态 0：待扫描 1：扫描成功 2：扫描失败
     */
    private String scanStatus;

    /**
     * 创建者label
     */
    private String createByLabel;

    /**
     * 删除标志（0代表存在 1代表删除）
     */
    private String delFlag;
}