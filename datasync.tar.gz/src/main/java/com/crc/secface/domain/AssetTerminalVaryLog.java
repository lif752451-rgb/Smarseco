package com.crc.secface.domain;

import com.baomidou.mybatisplus.annotation.TableName;
import com.baomidou.mybatisplus.extension.activerecord.Model;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.experimental.Accessors;

import java.util.Date;

/**
 * <p>
 * 终端资产-终端设备、软件关联表
 * </p>
 *
 * @author hejingsheng1
 * @since 2023-03-27
 */
@Data
@EqualsAndHashCode(callSuper = false)
@Accessors(chain = true)
@TableName("tb_asset_terminal_vary_log")
public class AssetTerminalVaryLog extends Model<AssetTerminalVaryLog> {

    private static final long serialVersionUID = 1L;

    /**
     * 主键
     */
    private String id;
    /**
     * 终端资产-终端设备表主键ID
     */
    private String terminalEquipmentId;
    /**
     * 变更前json
     */
    private String beforeVary;
    /**
     * 变更后json
     */
    private String afterVary;
    /**
     * 删除标记(0正常 1删除)
     */
    private String delFlag;
    /**
     * 创建人
     */
    private String createBy;
    /**
     * 创建时间
     */
    private Date createTime;
    /**
     * 最后修改人
     */
    private String updateBy;
    /**
     * 最后修改时间
     */
    private Date updateTime;

}
