package com.crc.secface.domain;

import com.baomidou.mybatisplus.annotation.TableName;
import com.baomidou.mybatisplus.extension.activerecord.Model;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.experimental.Accessors;

import java.util.Date;

/**
 * <p>
 * 终端资产-终端设备、软件关联表
 * </p>
 *
 * @author hejingsheng1
 * @since 2023-03-27
 */
@Data
@EqualsAndHashCode(callSuper = false)
@Accessors(chain = true)
@TableName("tb_asset_terminal_relation")
public class AssetTerminalRelation extends Model<AssetTerminalRelation> {

    private static final long serialVersionUID = 1L;

    /**
     * 主键
     */
    private String id;
    /**
     * 终端资产-终端设备表主键ID
     */
    private String terminalEquipmentId;
    /**
     * 终端资产-终端软件表主键ID
     */
    private String terminalSoftwareId;
    /**
     * 安装日期
     */
    private Date installTime;
    /**
     * 最近检索时间
     */
    private Date lastRetrievalTime;
    /**
     * 删除标记(0正常 1删除)
     */
    private String delFlag;

}
