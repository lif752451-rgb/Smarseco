package com.crc.secface.domain.vo;

import lombok.Data;

@Data
public class KvData {
    String key;
    String str;
}
