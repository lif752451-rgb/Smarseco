package com.crc.secface.domain;

import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableId;
import com.baomidou.mybatisplus.annotation.TableName;
import com.baomidou.mybatisplus.extension.activerecord.Model;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.experimental.Accessors;

import java.util.Date;

/**
 * <p>
 * 
 * </p>
 *
 * @author hejingsheng1
 * @since 2022-12-14
 */
@Data
@EqualsAndHashCode(callSuper = false)
@Accessors(chain = true)
@TableName("tb_lvmeng_task_ip_list")
public class LvmengTaskIpList extends Model<LvmengTaskIpList> {

    private static final long serialVersionUID = 1L;

    @TableId(value = "id", type = IdType.AUTO)
    private Long id;
    /**
     * 任务Id
     */
    private String taskIp;
    /**
     * 任务结束时间
     */
    private Date endTime;
    /**
     * 任务Id
     */
    private String taskId;
    /**
     * 漏洞数量
     */
    private Integer vulCount;
    /**
     * 是否被计算过
     */
    private Integer status;


}
