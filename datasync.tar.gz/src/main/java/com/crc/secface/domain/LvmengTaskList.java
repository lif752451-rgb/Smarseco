package com.crc.secface.domain;

import com.baomidou.mybatisplus.annotation.TableName;
import com.baomidou.mybatisplus.extension.activerecord.Model;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.experimental.Accessors;

import java.util.Date;

/**
 * <p>
 * 
 * </p>
 *
 * @author hejingsheng1
 * @since 2022-12-14
 */
@Data
@EqualsAndHashCode(callSuper = false)
@Accessors(chain = true)
@TableName("tb_lvmeng_task_list")
public class LvmengTaskList extends Model<LvmengTaskList> {

    private static final long serialVersionUID = 1L;

    private String id;
    /**
     * 任务名称
     */
    private String taskName;
    /**
     * 同步状态数据是否已经入库,0-未入库，1-入库
     */
    private Integer status;
    private Date startTime;
    private Date endTime;
    /**
     * 0-空任务，1-有数据任务
     */
    private Integer flag;

    private Long engineId;
    /**
     * 进度
     */
    private Integer taskProc;
    private Integer targetTotal;

}
