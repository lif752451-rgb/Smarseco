package com.crc.secface.domain;

import com.baomidou.mybatisplus.annotation.TableField;
import com.baomidou.mybatisplus.annotation.TableName;
import com.baomidou.mybatisplus.extension.activerecord.Model;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.experimental.Accessors;

import java.util.Date;

/**
 * <p>
 * 
 * </p>
 *
 * @author hejingsheng1
 * @since 2023-04-17
 */
@Data
@EqualsAndHashCode(callSuper = false)
@Accessors(chain = true)
@TableName("tb_asset_person")
public class AssetPerson extends Model<AssetPerson> {

    private static final long serialVersionUID = 1L;

    private String id;
    /**
     * 用户id
     */
    private String userId;
    /**
     * 用户名（全称）
     */
    private String userName;
    /**
     * 邮箱地址
     */
    private String email;
    /**
     * 联系电话
     */
    private String phone;
    /**
     * 类型；1，责任人；2，运维人
     */
    private String type;
    /**
     * 创建人
     */
    private String createBy;
    /**
     * 创建时间
     */
    private Date createTime;
    /**
     * 修改人
     */
    private String updateBy;
    /**
     * 修改时间
     */
    private Date updateTime;
    /**
     * 内网ip
     */
    private String internalIp;
    /**
     * 资产ID
     */
    private String assetId;

    @TableField(exist = false)
    String user;

}
