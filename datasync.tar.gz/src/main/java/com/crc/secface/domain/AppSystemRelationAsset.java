package com.crc.secface.domain;

import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableId;
import com.baomidou.mybatisplus.annotation.TableName;
import com.baomidou.mybatisplus.extension.activerecord.Model;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.experimental.Accessors;

/**
 * <p>
 * 应用系统关联资产表
 * </p>
 *
 * @author hejingsheng1
 * @since 2023-05-16
 */
@Data
@EqualsAndHashCode(callSuper = false)
@Accessors(chain = true)
@TableName("tb_app_system_relation_asset")
public class AppSystemRelationAsset extends Model<AppSystemRelationAsset> {

    private static final long serialVersionUID = 1L;

    /**
     * 主键ID
     */
    @TableId(value = "id", type = IdType.AUTO)
    private Long id;
    /**
     * 应用系统主键ID
     */
    private String appSystemId;
    /**
     * 资产表主键ID
     */
    private Long assetId;
    /**
     * 删除标识，0未删除，1已删除
     */
    private String delFlag;

}
