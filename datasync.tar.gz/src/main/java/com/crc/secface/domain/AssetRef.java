package com.crc.secface.domain;

import lombok.Data;

@Data
public class AssetRef {
    String ip;
    TbAssetExt ext;
}
