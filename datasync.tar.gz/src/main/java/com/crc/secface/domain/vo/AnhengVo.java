package com.crc.secface.domain.vo;

import com.alibaba.fastjson.JSONObject;
import lombok.Data;

@Data
public class AnhengVo {
    String ipaddr;
    JSONObject parameters;
}
