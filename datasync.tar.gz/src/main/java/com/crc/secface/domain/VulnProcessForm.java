package com.crc.secface.domain;

import com.baomidou.mybatisplus.annotation.TableField;
import com.baomidou.mybatisplus.annotation.TableName;
import com.baomidou.mybatisplus.extension.activerecord.Model;
import com.crc.common.enums.DatabaseEnums;
import com.crc.common.utils.VersionUtils;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.experimental.Accessors;

import java.util.Date;

/**
 * <p>
 * 漏洞主表
 * </p>
 *
 * @author hejingsheng1
 * @since 2022-12-06
 */
@Data
@EqualsAndHashCode(callSuper = false)
@Accessors(chain = true)
@TableName("tb_vuln_process_form")
public class VulnProcessForm extends Model<VulnProcessForm> {

    private static final long serialVersionUID = 1L;

    private String id;
    /**
     * 漏洞编号
     */
    private String code;
    /**
     * 漏洞类别 1:主机漏洞 2：WEB漏洞 3：弱口令
     */
    private Integer category;
    /**
     * IP/域名
     */
    private String ip;
    /**
     * agentId
     */
    private String agentId;
    /**
     * 资产名称
     */
    private String assetName;

    //@TableField(value = "\"DOMAIN\"")
    private String domain;
    /**
     * 所属单位名称
     */
    private String affiliationDeptName;
    /**
     * 所属组织ID
     */
    private Long affiliationDeptNodeId;
    /**
     * 漏洞名称
     */
    private String vulnName;
    /**
     * 漏洞描述
     */
    private String description;
    /**
     * 解决方案
     */
    private String solution;
    /**
     * 漏洞来源 字典：vul_data_source 1-人工渗透
     */
    private String source;
    /**
     * 漏洞等级 字典：vul_level 0:低危, 漏洞等级 1:中危, 2:⾼危, 3:严重
     */
    //@TableField(value = "\"LEVEL\"")
    private String level;
    /**
     * 漏洞类型
     */
    private String vulnType;
    /**
     * CVE编号
     */
    private String cveCode;

    public String getCveCode() {
        if (cveCode == null) {
            return "";
        }
        return cveCode;
    }

    public void setCveCode(String cveCode) {
        this.cveCode = cveCode;
    }

    /**
     * 首次发现时间
     */
    private Date firstTime;
    /**
     * 最近发现时间
     */
    private Date recentlyTime;
    /**
     * cnnvd
     */
    private String cnnvd;
    /**
     * cvss
     */
    private String cvss;
    /**
     * 状态 0：未修复 1：已修复
     */
    private String status;
    /**
     * 推送状态 0：未推送 1：已推送
     */
    private String isPushStatus;
    /**
     * 漏洞特征 1：存在EXP 2：存在POC 3：远程执行 4：本地提权 5：内核漏洞
     */
    private String vulFeatures;
    /**
     * 附件
     */
    private String fileJson;
    /**
     * 漏洞发布时间
     */
    private Date publishTime;//publish_time
    /**
     * 漏洞修复影响 0:未知 1：无需重启 2：服务重启 3：系统重启
     */
    private String vulHostInfluence;
    /**
     * 利用条件
     */
    private String availableCondition;
    /**
     * 影响应用
     */
    private String affectApplication;
    /**
     * 验证信息
     */
    private String validInfo;
    /**
     * 参考链接
     */
    private String refLink;
    private String createBy;
    private String createByLabel;
    private Date createTime;
    private String updateBy;
    private Date updateTime;
    private String delFlag;
    private String handlePersonLabel;
    /**
     * 白名单ID
     */
    private Long whiteListId;
    /**
     * 修复截止时间
     */
    private Date repairTime;
    /**
     * 处置人
     */
    private String handlePerson;
    /**
     * 是否发送邮件 0：是 1：否
     */
    private String isSend;
    /**
     * 抄送人
     */
    private String ccPerson;
    /**
     * 引擎ID
     */
    private String engineId;

    private String userName;
    String password;
    String port;
    String service;

    @TableField(exist = false)
    private String dbType;

    public String getDbType() {
        if (VersionUtils.getDatabase() == DatabaseEnums.MYSQL.getCode()) {
            return "mysql";
        } else {
            return "other";
        }
    }

    public void setDbType(String dbType) {
        this.dbType = dbType;
    }
}
