package com.crc.secface.domain;

import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableId;
import com.baomidou.mybatisplus.annotation.TableName;
import com.baomidou.mybatisplus.extension.activerecord.Model;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.experimental.Accessors;

import java.util.Date;

/**
 * <p>
 * 漏洞白名单
 * </p>
 *
 * @author hejingsheng1
 * @since 2022-12-16
 */
@Data
@EqualsAndHashCode(callSuper = false)
@Accessors(chain = true)
@TableName("tb_vul_white_list")
public class VulWhiteList extends Model<VulWhiteList> {

    private static final long serialVersionUID = 1L;

    /**
     * 主键
     */
    @TableId(value = "id", type = IdType.AUTO)
    private Integer id;
    /**
     * IP
     */
    private String ip;
    /**
     * 漏洞名称
     */
    private String vulName;
    /**
     * 加白原因
     */
    private String reason;
    /**
     * 申请人
     */
    private String applyUserName;
    /**
     * 申请人姓名
     */
    private String applyNickName;
    /**
     * 申请人所属部门ID
     */
    private Long applyUserDept;
    /**
     * 申请时间
     */
    private Date applyTime;
    /**
     * 附件
     */
    private String jsonFile;
    /**
     * 审批状态（0 待审批，1 通过，2 不通过）
     */
    private Integer status;
    /**
     * 审批人
     */
    private String approvalUserName;
    /**
     * 审批人姓名
     */
    private String approvalNickName;
    /**
     * 审批时间
     */
    private Date approvalTime;
    /**
     * 审批意见
     */
    private String approvalComment;
    /**
     * 漏洞id
     */
    private String vulId;
    /**
     * 漏洞大类  1 主机漏洞  2 web漏洞  3  弱口令
     */
    private String category;
    /**
     * 漏洞概述
     */
    private String vulContent;
    /**
     * 申请ID
     */
    private String applyId;
}
