package com.crc.secface.domain;

import com.baomidou.mybatisplus.annotation.TableField;
import com.baomidou.mybatisplus.annotation.TableId;
import com.baomidou.mybatisplus.annotation.TableName;
import com.baomidou.mybatisplus.extension.activerecord.Model;
import com.crc.common.enums.DatabaseEnums;
import com.crc.common.utils.VersionUtils;
import com.fasterxml.jackson.annotation.JsonFormat;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.experimental.Accessors;

import java.io.Serializable;
import java.util.Date;
import java.util.List;

/**
 * <p>
 *
 * </p>
 *
 * @author hejingsheng1
 * @since 2023-05-16
 */
@Data
@TableName("tb_asset_app_system")
public class AssetAppSystem implements Serializable {
    private static final long serialVersionUID = 1L;

    /**
     * 唯一主键
     */
    @TableId(value = "id")
    private String id;

    /**
     * 应用系统状态 0 未审批  1 审批中  2 审批驳回  3 审批通过
     */
    @TableField(value = "status")
    private Integer status;

    /**
     * 系统名称
     */
    @TableField(value = "system_name")
    private String systemName;

    /**
     * 子系统名称
     */
    @TableField(value = "child_system_name")
    private String childSystemName;

    /**
     * 标准化编码
     */
    @TableField(value = "standardization_code")
    private String standardizationCode;

    /**
     * 资产分类 1 自有  2 托管
     */
    @TableField(value = "asset_type")
    private Integer assetType;

    /**
     * 部署位置
     */
    @TableField(value = "geographic_location")
    private String geographicLocation;

    /**
     * 建设类型 1 自建  2 统建
     */
    @TableField(value = "construction_type")
    private Integer constructionType;

    /**
     * 是否近一年上线/验收  0：是 1：否
     */
    @TableField(value = "is_past_year_online")
    private Integer isPastYearOnline;

    /**
     * 近一年上线/验收类型  1  上线  2 验收
     */
    @TableField(value = "is_past_year_type")
    private Integer isPastYearType;

    /**
     * 是否与统一身份集成  0：是 1：否
     */
    @TableField(value = "is_iam")
    private Integer isIam;

    /**
     * 是否与统一身份进行账户集成  0：是 1：否
     */
    @TableField(value = "is_iam_account")
    private Integer isIamAccount;

    /**
     * 统一身份注册编码（PID）
     */
    @TableField(value = "iam_code")
    private String iamCode;

    /**
     * 统一身份注册名称
     */
    @TableField(value = "iam_name")
    private String iamName;

    /**
     * 是否与中国石化AD域集成  0：是 1：否
     */
    @TableField(value = "is_sinopec_ad")
    private Integer isSinopecAd;

    /**
     * 是否存在本地认证方式  0：是 1：否
     */
    @TableField(value = "is_local_auth")
    private Integer isLocalAuth;

    /**
     * 应用架构   1 C/S  2 B/S
     */
    @TableField(value = "app_architecture")
    private Integer appArchitecture;

    /**
     * 用户数量
     */
    @TableField(value = "user_count")
    private Integer userCount;

    /**
     * 内网发布IP
     */
    @TableField(value = "internal_publish_ip")
    private String internalPublishIp;

    /**
     * 内网Url
     */
    @TableField(value = "internal_url")
    private String internalUrl;

    /**
     * 内网域名
     */
    @TableField(value = "internal_domain")
    private String internalDomain;

    /**
     * 服务器地址(资产信息)
     */
    @TableField(value = "server_address")
    private String serverAddress;

    /**
     * 服务器详细名称(资产信息)
     */
    @TableField(value = "server_name")
    private String serverName;

    /**
     * 操作系统版本(资产信息)
     */
    @TableField(value = "os_version")
    private String osVersion;

    /**
     * 是否安装G01  0：是 1：否
     */
    @TableField(value = "is_install_g")
    private Integer isInstallG;

    /**
     * 等保级别 0=未定级,1=一级,2=二级,3=三级,4=四级,5=五级
     */
    @TableField(value = "equal_protection_level")
    private Integer equalProtectionLevel;

    /**
     * 定级备案状态  1 已备案  2 未备案
     */
    @TableField(value = "equal_protection_status")
    private Integer equalProtectionStatus;

    /**
     * 等保定级时间
     */
    @TableField(value = "equal_protection_rank_time")
    @JsonFormat(pattern = "yyyy-MM-dd", timezone = "GMT+8")
    private Date equalProtectionRankTime;

    /**
     * 等保备案时间
     */
    @TableField(value = "equal_protection_record_time")
    @JsonFormat(pattern = "yyyy-MM-dd", timezone = "GMT+8")
    private Date equalProtectionRecordTime;

    /**
     * 等保备案编号
     */
    @TableField(value = "equal_protection_code")
    private String equalProtectionCode;

    /**
     * 受理备案单位
     */
    @TableField(value = "equal_protection_unit")
    private String equalProtectionUnit;

    /**
     * 是否将定级信息上报至SMCC  0：是 1：否
     */
    @TableField(value = "is_rank_info_report_smcc")
    private Integer isRankInfoReportSmcc;

    /**
     * 是否发布互联网  0：是 1：否
     */
    @TableField(value = "is_internet_public")
    private Integer isInternetPublic;

    /**
     * 发布位置
     */
    @TableField(value = "publish_location")
    private String publishLocation;

    /**
     * 互联网IP及端口
     */
    @TableField(value = "internet_ip_port")
    private String internetIpPort;

    /**
     * 互联网URL
     */
    @TableField(value = "internet_url")
    private String internetUrl;

    /**
     * 互联网域名
     */
    @TableField(value = "internet_domain")
    private String internetDomain;

    /**
     * ICP是否备案  0：是 1：否
     */
    @TableField(value = "is_icp")
    private Integer isIcp;

    /**
     * ICP备案号/许可证号
     */
    @TableField(value = "icp_number")
    private String icpNumber;

    /**
     * 公网安是否备案  0：是 1：否
     */
    @TableField(value = "is_public_network_security")
    private Integer isPublicNetworkSecurity;

    /**
     * 公网安备案号
     */
    @TableField(value = "public_network_security_number")
    private String publicNetworkSecurityNumber;

    /**
     * 备案地公安机关
     */
    @TableField(value = "public_security_unit")
    private String publicSecurityUnit;

    /**
     * 网络安全责任书签署单位
     */
    @TableField(value = "network_security_sign_unit")
    private String networkSecuritySignUnit;

    /**
     * 网络安全责任书项目名称
     */
    @TableField(value = "network_security_project_name")
    private String networkSecurityProjectName;

    /**
     * 网络安全责任书责任人
     */
    @TableField(value = "network_security_responsible")
    private String networkSecurityResponsible;

    /**
     * 签订日期
     */
    @TableField(value = "sign_time")
    @JsonFormat(pattern = "yyyy-MM-dd", timezone = "GMT+8")
    private Date signTime;

    /**
     * 承诺期限（起止时间）
     */
    @TableField(value = "commitment_period_time")
    private String commitmentPeriodTime;

    /**
     * 承诺期限（起止时间）
     */
    @TableField(value = "commitment_period_start_time")
    @JsonFormat(pattern = "yyyy-MM-dd", timezone = "GMT+8")
    private Date commitmentPeriodStartTime;

    /**
     * 承诺期限（起止时间）
     */
    @TableField(value = "commitment_period_end_time")
    @JsonFormat(pattern = "yyyy-MM-dd", timezone = "GMT+8")
    private Date commitmentPeriodEndTime;

    /**
     * 业务主管部门
     */
    @TableField(value = "business_department")
    private String businessDepartment;

    /**
     * 所属组织名称
     */
    @TableField(value = "affiliation_dept_name")
    private String affiliationDeptName;

    /**
     * 所属组织id
     */
    @TableField(value = "affiliation_dept_node_id")
    private Long affiliationDeptNodeId;

    /**
     * 组织id全路径
     */
    @TableField(value = "dept_path")
    private String deptPath;

    /**
     * 业务主管部门联系人
     */
    @TableField(value = "business_department_contact")
    private String businessDepartmentContact;

    /**
     * 业务主管部门联系人名称
     */
    @TableField(value = "business_department_contact_name")
    private String businessDepartmentContactName;

    /**
     * 业务主管部门联系人电话
     */
    @TableField(value = "business_department_contact_mobile")
    private String businessDepartmentContactMobile;

    /**
     * 业务主管部门联系人邮箱
     */
    @TableField(value = "business_department_contact_email")
    private String businessDepartmentContactEmail;

    /**
     * 企业信息部门
     */
    @TableField(value = "enterprise_info_department")
    private String enterpriseInfoDepartment;

    /**
     * 企业信息部门联系人
     */
    @TableField(value = "enterprise_info_department_contact")
    private String enterpriseInfoDepartmentContact;

    /**
     * 企业信息部门联系人电话
     */
    @TableField(value = "enterprise_info_department_contact_mobile")
    private String enterpriseInfoDepartmentContactMobile;

    /**
     * 企业信息部门联系人邮箱
     */
    @TableField(value = "enterprise_info_department_contact_email")
    private String enterpriseInfoDepartmentContactEmail;

    /**
     * 承建单位
     */
    @TableField(value = "construction_unit")
    private String constructionUnit;

    /**
     * 承建单位联系人
     */
    @TableField(value = "construction_unit_contact")
    private String constructionUnitContact;

    /**
     * 承建单位联系人电话
     */
    @TableField(value = "construction_unit_contact_mobile")
    private String constructionUnitContactMobile;

    /**
     * 承建单位联系人邮箱
     */
    @TableField(value = "construction_unit_contact_email")
    private String constructionUnitContactEmail;

    /**
     * 运维单位
     */
    @TableField(value = "operation_unit")
    private String operationUnit;

    /**
     * 运维单位联系人
     */
    @TableField(value = "operation_unit_contact")
    private String operationUnitContact;

    /**
     * 运维联系人电话
     */
    @TableField(value = "operation_unit_contact_mobile")
    private String operationUnitContactMobile;

    /**
     * 运维联系人邮箱
     */
    @TableField(value = "operation_unit_contact_email")
    private String operationUnitContactEmail;

    /**
     * 删除标志(0:正常;1.删除)
     */
    @TableField("del_flag")
    private String delFlag;

    /**
     * 创建者
     */
    @TableField(value = "create_by")
    private String createBy;

    /**
     * 创建时间
     */
    @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss", timezone = "GMT+8")
    @TableField(value = "create_time")
    private Date createTime;

    /**
     * 更新者
     */
    @TableField(value = "update_by")
    private String updateBy;

    /**
     * 更新时间
     */
    @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss", timezone = "GMT+8")
    @TableField(value = "update_time")
    private Date updateTime;
    /**
     * 消息
     */
    @TableField("message")
    private String message;

    /**
     * 上线时间-冗余字段
     */
    @TableField(value = "online_time")
    private String onlineTime;

    /**
     * 系统开发商-冗余字段
     */
    @TableField(value = "system_developer")
    private String systemDeveloper;

    /**
     * 是否掌握源代码-冗余字段
     */
    @TableField(value = "source_code")
    private String sourceCode;

    /**
     * 开发语言-冗余字段
     */
    @TableField(value = "dev_language")
    private String devLanguage;

    /**
     * CPU资源总量-冗余字段
     */
    @TableField(value = "cpu_count")
    private String cpuCount;

    /**
     * 内存资源总量（G）-冗余字段
     */
    @TableField(value = "mem_count")
    private String memCount;

    /**
     * 系统盘（G）-冗余字段
     */
    @TableField(value = "sys_disk")
    private String sysDisk;

    /**
     * 数据盘（G)-冗余字段
     */
    @TableField(value = "data_disk")
    private String dataDisk;

    /**
     * 云/虚拟化软件厂商-冗余字段
     */
    @TableField(value = "virtual_software_vendor")
    private String virtualSoftwareVendor;

    /**
     * 物理服务器数量-冗余字段
     */
    @TableField(value = "physical_server_count")
    private String physicalServerCount;

    /**
     * 技术路线-冗余字段
     */
    @TableField(value = "technical_line")
    private String technicalLine;

    /**
     * 备份-冗余字段
     */
    @TableField(value = "backup")
    private String backup;

    /**
     * 冗余字段
     */
    @TableField(value = "field1")
    private String field1;

    /**
     * 冗余字段
     */
    @TableField(value = "field2")
    private String field2;

    /**
     * 冗余字段
     */
    @TableField(value = "field3")
    private String field3;

    @TableField(exist = false)
    private List<String> ips;

    /**
     * 包含id(根据查询结果在合并当前id的数据)
     */
    @TableField(exist = false)
    private List<String> includeIds;


    @TableField(exist = false)
    private String dbType;

    public String getDbType() {
        if (VersionUtils.getDatabase() == DatabaseEnums.MYSQL.getCode()) {
            return "mysql";
        } else {
            return "other";
        }
    }

    public void setDbType(String dbType) {
        this.dbType = dbType;
    }
}

