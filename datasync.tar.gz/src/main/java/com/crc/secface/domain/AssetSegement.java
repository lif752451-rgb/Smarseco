package com.crc.secface.domain;

import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableId;
import com.baomidou.mybatisplus.annotation.TableName;
import com.baomidou.mybatisplus.extension.activerecord.Model;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.experimental.Accessors;

import java.util.Date;

/**
 * <p>
 * 集团网段
 * </p>
 *
 * @author hejingsheng
 * @since 2022-12-06
 */
@Data
@EqualsAndHashCode(callSuper = false)
@Accessors(chain = true)
@TableName("tb_asset_segement")
public class AssetSegement extends Model<AssetSegement> {

    private static final long serialVersionUID = 1L;

    /**
     * ID
     */
    @TableId(value = "id", type = IdType.AUTO)
    private Long id;
    /**
     * 类型
     */
    private String type;
    /**
     * 环境
     */
    private String evn;
    /**
     * 网段
     */
    private String segment;
    /**
     * 网段名称
     */
    private String name;
    /**
     * 用途
     */
    private String remark;
    /**
     * 一级的单位ID
     */
    private Long firstUnitId;
    private String firstUnitName;
    /**
     * 二级单位ID
     */
    private Long secondUnitId;
    private String secondUnitName;
    /**
     * 自定义部门
     */
    private String customUnitName;
    private Integer areaId;
    private String areaName;
    private Integer subAreaId;
    private String subAreaName;
    /**
     * 是否启用
     */
    private Integer isEnable;
    /**
     * 创建者
     */
    private String createBy;
    /**
     * 创建时间
     */
    private Date createTime;
    /**
     * 修改者
     */
    private String updateBy;
    /**
     * 修改时间
     */
    private Date updateTime;
    /**
     * 所属单位名称
     */
    private String affiliationDeptName;
    /**
     * 所属单位叶子节点id
     */
    private Long affiliationDeptNodeId;
    /**
     * 租户名称
     */
    private String tenantName;
    /**
     * 网络区域自定义UUID
     */
    private String areaCustomUuid;

}
