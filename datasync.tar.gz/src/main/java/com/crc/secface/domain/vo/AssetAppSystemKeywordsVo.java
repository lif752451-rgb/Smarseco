package com.crc.secface.domain.vo;

import com.crc.secface.domain.AssetAppSystem;
import lombok.Data;

/**
 * @author fuzhuangzhi
 * @title AssetAppSystemKeywordsVo
 * @date 2023/10/13 11:41
 * @description 应用系统全文检索VO,用于组装tb_common_keywords中的搜索条件
 */
@Data
public class AssetAppSystemKeywordsVo extends AssetAppSystem {
    /**
     * 资产内网IP
     */
    private String internalIp;
}
