package com.crc.secface.domain;

import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableId;
import com.baomidou.mybatisplus.annotation.TableName;
import com.baomidou.mybatisplus.extension.activerecord.Model;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.experimental.Accessors;

/**
 * <p>
 *
 * </p>
 *
 * @author wenxiaoming
 * @since 2023-05-17
 */
@Data
@EqualsAndHashCode(callSuper = false)
@Accessors(chain = true)
@TableName("tb_f5_511")
public class F5Data511 extends Model<F5Data511> {

    private static final long serialVersionUID = 1L;

    @TableId(value = "id", type = IdType.AUTO)
    private Integer id;
    private String name;
    /**
     * 类型
     */
    private String type;
    private String sid;
    /**
     * 数据内容
     */
    private String ip;

    /**
     * 引擎的逻辑判断0-有效，1无效
     */
    private Integer flag;
    private Integer dataId;
    private String poolNames;
    String partitionName;
}
