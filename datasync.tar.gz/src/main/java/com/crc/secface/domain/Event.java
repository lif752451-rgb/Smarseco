package com.crc.secface.domain;

import com.baomidou.mybatisplus.annotation.TableName;
import com.baomidou.mybatisplus.extension.activerecord.Model;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.experimental.Accessors;

import java.math.BigDecimal;
import java.util.Date;

/**
 * <p>
 * 实时事件处置
 * </p>
 *
 * @author hejingsheng1
 * @since 2022-12-28
 */
@Data
@EqualsAndHashCode(callSuper = false)
@Accessors(chain = true)
@TableName("tb_event")
public class Event extends Model<Event> {

    private static final long serialVersionUID = 1L;

    /**
     * 主键
     */
    private String id;
    /**
     * 事件编号
     */
    private String eventNo;
    /**
     * 事件级别
     */
    private String eventLevel;
    /**
     * 事件来源
     */
    private String eventSource;
    /**
     * 攻击类型
     */
    private String attackType;
    /**
     * 攻击结果
     */
    private String attackResult;
    /**
     * 攻击次数
     */
    private Integer attackCount;
    /**
     * 攻击IP
     */
    private String attackIp;
    /**
     * 受害IP/URL
     */
    private String attackUrl;
    /**
     * 事件提交人
     */
    private String commiterId;
    /**
     * 待处置人
     */
    private String disposerId;
    /**
     * 审核人
     */
    private String auditorId;
    /**
     * 提交时间
     */
    private Date commitTime;
    /**
     * 处置时间
     */
    private Date disposeTime;
    /**
     * 审核时间
     */
    private Date auditTime;
    /**
     * 事件状态(TAB页用)
     */
    private String status;
    /**
     * 处置反馈
     */
    private String disposeContent;
    /**
     * 审核意见
     */
    private String auditContent;
    /**
     * 创建者
     */
    private String createBy;
    /**
     * 创建时间
     */
    private Date createTime;
    /**
     * 修改者
     */
    private String updateBy;
    /**
     * 修改时间
     */
    private Date updateTime;
    /**
     * 备注
     */
    private String remarks;
    /**
     * 创建类型
     */
    private String createType;
    /**
     * 关联事件ID
     */
    private String eventId;
    /**
     * 事件名称
     */
    private String eventName;
    /**
     * 事件发生时间
     */
    private Date eventStartTime;
    /**
     * 事件结束时间
     */
    private Date eventEndTime;
    /**
     * 附件
     */
    private String attach;
    /**
     * 删除标志（0代表存在 2代表删除）
     */
    private Integer delFlag;
    /**
     * 关联事件
     */
    private String oriEventId;
    /**
     * 告警时间
     */
    private Date alarmTime;
    /**
     * 指派部门
     */
    private String designatedDepartment;
    /**
     * 当前审核部门
     */
    private String nodeDepartment;
    /**
     * 齐安信ID
     */
    private String qaxtId;
    /**
     * tota系统ID
     */
    private String totaId;
    /**
     * 是否是dmz区 0:是,1:不是
     */
    private String isDmz;
    /**
     * 原IP类型
     */
    private String srcIpType;
    /**
     * 同步标记 0:旧数据 1：新数据
     */
    private String goStatus;
    /**
     * 归属区域
     */
    private String assetArea;
    /**
     * 子区域
     */
    private String subArea;
    /**
     * 风险IP
     */
    private String riskIp;
    /**
     * 业务模型
     */
    private String busModel;
    /**
     * 是否白名单:0.不是,1.是
     */
    private String isWhitelist;
    private String regArea;
    /**
     * BU
     */
    private String regBu;
    /**
     * 公司
     */
    private String regCompany;
    /**
     * 子区域
     */
    private String regSubArea;
    /**
     * 是否为水泥告警
     */
    private String sn;
    /**
     * 水泥大区
     */
    private String snBu;
    /**
     * 水泥公司
     */
    private String snArea;
    /**
     * 重点标记 0：未标记  1：典型案例 2：排查阶段 3：重点关注 4：疑似失陷 5：预判失陷
     */
    private String tab;
    /**
     * 重点标记描述
     */
    private String tabDesc;
    /**
     * AI研判置信度
     */
    private BigDecimal priority;
    /**
     * 研判意见
     */
    private String solution;
    /**
     * 研判分数
     */
    private String solutions;



}
