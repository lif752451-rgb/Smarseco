package com.crc.secface.domain;

import com.baomidou.mybatisplus.annotation.TableName;
import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.extension.activerecord.Model;
import com.baomidou.mybatisplus.annotation.TableId;
import java.util.Date;

import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.experimental.Accessors;

/**
 * <p>
 * 攻击面-域名管理表
 * </p>
 *
 * @author hejingsheng1
 * @since 2023-05-16
 */
@Data
@EqualsAndHashCode(callSuper = false)
@Accessors(chain = true)
@TableName("tb_asset_asm_domain")
public class AssetAsmDomain extends Model<AssetAsmDomain> {

    private static final long serialVersionUID = 1L;

    /**
     * 主键ID
     */
    @TableId(value = "id", type = IdType.AUTO)
    private Long id;
    /**
     * 域名
     */
    private String domainName;
    /**
     * 主办单位名称
     */
    private String organizerName;
    /**
     * 主办单位性质
     */
    private Integer organizerNature;
    /**
     * 网站备案号
     */
    private String webRecordNumber;
    /**
     * 网站名称
     */
    private String webName;
    /**
     * 网站负责人
     */
    private String webRegistrar;
    /**
     * 网站首页网址
     */
    private String webHomeAddr;
    /**
     * 审核时间
     */
    private Date auditTime;
    /**
     * 所属单位名称
     */
    private String affiliationDeptName;
    /**
     * 所属组织ID
     */
    private Long affiliationDeptNodeId;
    /**
     * 责任人
     */
    private String responsible;
    /**
     * 发布位置
     */
    private String publishLocation;
    /**
     * 使用状态 
     */
    private Long useStatus;
    /**
     * 法定代表人
     */
    private String legalRepresentative;
    /**
     * 注册资本
     */
    private String registeredCapital;
    /**
     * 注册时间
     */
    private Date registrationDate;
    /**
     * 公司状态
     */
    private Integer companyStatus;
    /**
     * 公司类型
     */
    private Integer companyType;
    /**
     * 工商注册号
     */
    private String businessRegistrationNumber;
    /**
     * 所属行业
     */
    private String industry;
    /**
     * 纳税人识别号
     */
    private String taxpayerNumber;
    /**
     * 控股比例
     */
    private String holdingRatio;
    /**
     * 注册地址
     */
    private String registeredAddress;
    /**
     * 核准日期
     */
    private Date approvedDate;
    /**
     * 经营范围
     */
    private String businessScope;
    /**
     * 创建人
     */
    private String createBy;
    /**
     * 创建人-全称
     */
    private String createByLabel;
    /**
     * 创建时间
     */
    private Date createTime;
    /**
     * 修改人
     */
    private String updateBy;
    /**
     * 修改时间
     */
    private Date updateTime;
    /**
     * 删除标识，0未删除，1已删除
     */
    private String delFlag;

}
