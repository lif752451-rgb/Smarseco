package com.crc.secface.domain;

import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableId;
import com.baomidou.mybatisplus.annotation.TableName;
import com.baomidou.mybatisplus.extension.activerecord.Model;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.experimental.Accessors;

import java.util.Date;

/**
 * <p>
 * 资产缓存信息表
 * </p>
 *
 * @author hejingsheng1
 * @since 2023-09-19
 */
@Data
@EqualsAndHashCode(callSuper = false)
@Accessors(chain = true)
@TableName("tb_asset_ip_data")
public class AssetIpData extends Model<AssetIpData> {

    private static final long serialVersionUID = 1L;

    @TableId(value = "id", type = IdType.AUTO)
    private Integer id;
    /**
     * 类型
     */
    private String type;
    /**
     * IP
     */
    private String ip;
    private Date createTime;
    /**
     * 原始数据
     */
    private String data;

    public void setData(String data) {
        if (null != data) {
            if (data.length() > 300) {
                this.data = "The original file exceeds (" + data.length() + ") characters ";
            } else {
                this.data = data;
            }
        }
    }

}
