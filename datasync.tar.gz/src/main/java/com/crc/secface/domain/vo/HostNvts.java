package com.crc.secface.domain.vo;

/**
 * 主机漏洞信息
 * @author: 村长
 * @date: 2023-04-03 16:33:58
 */
public class HostNvts {

  /** 漏洞名称 */
  private String nvtName;
  /** Bugtraq ID */
  private String bid;
  /** tvid编号 */
  private String tvid;
  /** 描述 */
  private String description;
  /** 解决办法 */
  private String solution;
  /** 影响的版本 */
  private String affected;
  /** 相关连接 */
  private String xref;
  /** 影响 */
  private String impact;
  /** 发布日期 格式如:2020-10-20 */
  private String publishDate;
  /** 威胁分值 */
  private String cvssBase;
  /** cnvd编号 */
  private String cnvd;
  /** CVE编号 */
  private String cve;
  /** cnnvd编号 */
  private String cnnvd;
  /** cncve编号 */
  private String cncve;
  /** ms编号 */
  private String msBulletin;
  /** 发现日期 */
  private String discoveryTime;

  public String getNvtName() {
    return nvtName;
  }

  public void setNvtName(String nvtName) {
    this.nvtName = nvtName;
  }

  public String getBid() {
    return bid;
  }

  public void setBid(String bid) {
    this.bid = bid;
  }

  public String getTvid() {
    return tvid;
  }

  public void setTvid(String tvid) {
    this.tvid = tvid;
  }

  public String getDescription() {
    return description;
  }

  public void setDescription(String description) {
    this.description = description;
  }

  public String getSolution() {
    return solution;
  }

  public void setSolution(String solution) {
    this.solution = solution;
  }

  public String getAffected() {
    return affected;
  }

  public void setAffected(String affected) {
    this.affected = affected;
  }

  public String getXref() {
    return xref;
  }

  public void setXref(String xref) {
    this.xref = xref;
  }

  public String getImpact() {
    return impact;
  }

  public void setImpact(String impact) {
    this.impact = impact;
  }

  public String getPublishDate() {
    return publishDate;
  }

  public void setPublishDate(String publishDate) {
    this.publishDate = publishDate;
  }

  public String getCvssBase() {
    return cvssBase;
  }

  public void setCvssBase(String cvssBase) {
    this.cvssBase = cvssBase;
  }

  public String getCnvd() {
    return cnvd;
  }

  public void setCnvd(String cnvd) {
    this.cnvd = cnvd;
  }

  public String getCve() {
    return cve;
  }

  public void setCve(String cve) {
    this.cve = cve;
  }

  public String getCnnvd() {
    return cnnvd;
  }

  public void setCnnvd(String cnnvd) {
    this.cnnvd = cnnvd;
  }

  public String getCncve() {
    return cncve;
  }

  public void setCncve(String cncve) {
    this.cncve = cncve;
  }

  public String getMsBulletin() {
    return msBulletin;
  }

  public void setMsBulletin(String msBulletin) {
    this.msBulletin = msBulletin;
  }

  public String getDiscoveryTime() {
    return discoveryTime;
  }

  public void setDiscoveryTime(String discoveryTime) {
    this.discoveryTime = discoveryTime;
  }
}
