package com.crc.secface.domain;

import com.baomidou.mybatisplus.annotation.TableName;
import com.baomidou.mybatisplus.extension.activerecord.Model;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.experimental.Accessors;

import java.util.Date;

/**
 * <p>
 * 
 * </p>
 *
 * @author hejingsheng
 * @since 2022-12-06
 */
@Data
@EqualsAndHashCode(callSuper = false)
@Accessors(chain = true)
@TableName("tb_asset_software")
public class AssetSoftware extends Model<AssetSoftware> implements Cloneable{

    private String id;
    /**
     * IP
     */
    private String ip;
    /**
     * 软件名称
     */
    private String softName;
    /**
     * 软件版本
     */
    private String softVersion;
    /**
     * 软件类型/协议
     */
    private String softType;
    /**
     * 软件路径
     */
    private String softPath;
    /**
     * 安装时间
     */
    private String installDate;
    /**
     * 录入时间
     */
    private Date createTime;
    /**
     * 软件厂商
     */
    private String softManu;
    /**
     * 软件端口
     */
    private String sortPort;
    /**
     * 同步标志，无需展示
     */
    private String syncStatus;
    private String source;//数据来源
    /**
     * 组织ID
     */
    private String companyId;
    /**
     * 一级分类
     */
    private String firstCatTag;
    /**
     * 二级分类
     */
    private String secondCatTag;
    /**
     * 是否服务器(1是，0终端）
     */
    private String devType;
    private String license;
    private Date expirtTime;
    private Date lastCheckTime;
    /**
     * 组件版本转换后数据
     */
    private Long softVersionNum;

    @Override
    public AssetSoftware clone() {
        try {
            return (AssetSoftware) super.clone();
        } catch (Exception e) {
            return null;
        }
    }
}
