package com.crc.secface.domain.vo;

import java.util.List;

/**
 * web漏洞信息
 * @author: 村长
 * @date: 2023-04-04 10:50:45
 */
public class WebScanVulnInfos {

  /**漏洞名称 */
  private String name;
  /**cvssv2 */
  private String cvssv2;
  /**详细描述 */
  private String description;
  /**影响 */
  private String impact;
  /**危险插件 */
  private String riskCheck;
  /**危险级别分值 */
  private String riskValue;
  /**解决办法 */
  private String solution;
  /**tvid编号 */
  private String tvid;
  /**cve编号 */
  private String cve;
  /**cnnvd编号 */
  private String cnnvd;
  /**cwe编号 */
  private String cwe;
  /**参考链接 */
  private String refer;
  /**更新日期 */
  private String findTime;
  /**发现日期 */
  private String updateDate;
  /**web漏洞URL信息 */
  private List<WebUrlInfos> urlInfos;

  public String getName() {
    return name;
  }

  public void setName(String name) {
    this.name = name;
  }

  public String getCvssv2() {
    return cvssv2;
  }

  public void setCvssv2(String cvssv2) {
    this.cvssv2 = cvssv2;
  }

  public String getDescription() {
    return description;
  }

  public void setDescription(String description) {
    this.description = description;
  }

  public String getImpact() {
    return impact;
  }

  public void setImpact(String impact) {
    this.impact = impact;
  }

  public String getRiskCheck() {
    return riskCheck;
  }

  public void setRiskCheck(String riskCheck) {
    this.riskCheck = riskCheck;
  }

  public String getRiskValue() {
    return riskValue;
  }

  public void setRiskValue(String riskValue) {
    this.riskValue = riskValue;
  }

  public String getSolution() {
    return solution;
  }

  public void setSolution(String solution) {
    this.solution = solution;
  }

  public String getTvid() {
    return tvid;
  }

  public void setTvid(String tvid) {
    this.tvid = tvid;
  }

  public String getCve() {
    return cve;
  }

  public void setCve(String cve) {
    this.cve = cve;
  }

  public String getCnnvd() {
    return cnnvd;
  }

  public void setCnnvd(String cnnvd) {
    this.cnnvd = cnnvd;
  }

  public String getCwe() {
    return cwe;
  }

  public void setCwe(String cwe) {
    this.cwe = cwe;
  }

  public String getRefer() {
    return refer;
  }

  public void setRefer(String refer) {
    this.refer = refer;
  }

  public String getFindTime() {
    return findTime;
  }

  public void setFindTime(String findTime) {
    this.findTime = findTime;
  }

  public String getUpdateDate() {
    return updateDate;
  }

  public void setUpdateDate(String updateDate) {
    this.updateDate = updateDate;
  }

  public List<WebUrlInfos> getUrlInfos() {
    return urlInfos;
  }

  public void setUrlInfos(List<WebUrlInfos> urlInfos) {
    this.urlInfos = urlInfos;
  }
}
