package com.crc.secface.domain;

import com.baomidou.mybatisplus.annotation.TableName;
import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.extension.activerecord.Model;
import com.baomidou.mybatisplus.annotation.TableId;

import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.experimental.Accessors;

import java.util.Date;

/**
 * <p>
 * 攻击面信息泄漏管理表
 * </p>
 *
 * @author hejingsheng1
 * @since 2023-05-16
 */
@Data
@EqualsAndHashCode(callSuper = false)
@Accessors(chain = true)
@TableName("tb_asset_asm_info_leak")
public class AssetAsmInfoLeak extends Model<AssetAsmInfoLeak> {

    private static final long serialVersionUID = 1L;

    @TableId(value = "id", type = IdType.AUTO)
    private Long id;
    /**
     * 信息ID
     */
    private String infoId;
    /**
     * 所属单位名称
     */
    private String affiliationDeptName;
    /**
     * 所属组织ID
     */
    private Long affiliationDeptNodeId;
    /**
     * 类型 1-代码 2-文档 3-邮箱
     */
    private String type;
    /**
     * 来源
     */
    private String source;
    /**
     * 内容概要
     */
    private String contentSummary;
    /**
     * 内容详情(纯文本)
     */
    private String contentDetailText;
    /**
     * 内容详情(富文本)
     */
    private String contentDetailRich;
    /**
     * 文件后缀
     */
    private String fileSuffix;
    /**
     * 链接
     */
    private String url;
    /**
     * 标签
     */
    private String label;
    /**
     * 风险指数(1-10)
     */
    private String riskIndex;
    /**
     * 核实状态，0待核实，1已核实
     */
    private String verifyStatus;
    /**
     * 核实人
     */
    private String verifyUser;
    /**
     * 核实人-全称
     */
    private String verifyUserLabel;
    /**
     * 核实时间
     */
    private Date verifyTime;
    /**
     * 核实备注
     */
    private String verifyRemark;
    /**
     * 归属是否正确，0否，1是
     */
    private String attributionIsCorrect;
    /**
     * 内容仍存在，0否，1是
     */
    private String contentExists;
    /**
     * 信息完整度(1-5)
     */
    private String infoCompleteness;
    /**
     * 是否需要跟进，0否，1是
     */
    private String isFollowUp;
    /**
     * 是否已转风险，0否，1是
     */
    private String isConvertRisk;
    /**
     * 关联风险ID
     */
    private String relationRiskId;
    /**
     * 备注
     */
    private String remark;
    /**
     * 创建人
     */
    private String createBy;
    /**
     * 创建人-全称
     */
    private String createByLabel;
    /**
     * 创建时间
     */
    private Date createTime;
    /**
     * 修改人
     */
    private String updateBy;
    /**
     * 修改时间
     */
    private Date updateTime;
    /**
     * 删除标识，0未删除，1已删除
     */
    private String delFlag;


}
