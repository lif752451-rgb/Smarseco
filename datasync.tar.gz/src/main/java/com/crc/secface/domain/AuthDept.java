package com.crc.secface.domain;

import com.baomidou.mybatisplus.annotation.TableName;
import com.baomidou.mybatisplus.extension.activerecord.Model;

import java.util.Date;

import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.experimental.Accessors;

/**
 * <p>
 * 
 * </p>
 *
 * @author hejingsheng1
 * @since 2022-12-28
 */
@Data
@EqualsAndHashCode(callSuper = false)
@Accessors(chain = true)
@TableName("tb_auth_dept")
public class AuthDept extends Model<AuthDept> {

    private static final long serialVersionUID = 1L;

    private String deptId;
    /**
     * 部门名称
     */
    private String deptName;
    /**
     * 部门全称
     */
    private String deptFullName;
    /**
     * 父节点ID
     */
    private String deptParentId;
    /**
     * 逻辑删除标记
     */
    private String delFlag;
    /**
     * 创建时间
     */
    private Date createTime;
    /**
     * 更新时间
     */
    private Date updateTime;
    /**
     * 父节点名称
     */
    private String deptParentName;
    /**
     * 父节点全称
     */
    private String deptParentFullname;
    /**
     * 关联部门表ID
     */
    private Long refDeptId;
    /**
     * 备用字段1
     */
    private String ud1;
    /**
     * 备用字段2
     */
    private String ud2;


}
