package com.crc.secface.domain;

import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableId;
import com.baomidou.mybatisplus.annotation.TableName;
import com.baomidou.mybatisplus.extension.activerecord.Model;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.experimental.Accessors;

import java.util.Date;

/**
 * <p>
 * 漏洞修复周期表
 * </p>
 *
 * @author hejingsheng1
 * @since 2022-12-15
 */
@Data
@EqualsAndHashCode(callSuper = false)
@Accessors(chain = true)
@TableName("tb_vuln_process_repair_cycle")
public class VulnProcessRepairCycle extends Model<VulnProcessRepairCycle> {

    private static final long serialVersionUID = 1L;

    /**
     * 主键ID
     */
    @TableId(value = "id", type = IdType.AUTO)
    private Long id;
    /**
     * 漏洞类别 1:主机漏洞 2：WEB漏洞 3：弱口令
     */
    private String category;
    /**
     * 漏洞等级 字典：vul_level 0:低危, 漏洞等级 1:中危, 2:⾼危, 3:严重
     */
    private String vulLevel;
    /**
     * 资产等级 1：普通 2：重要 3：核心
     */
    private String assetLevel;
    /**
     * 天数
     */
    private Integer day;
    /**
     * 创建人
     */
    private String createBy;
    /**
     * 创建时间
     */
    private Date createTime;
    /**
     * 修改人
     */
    private String updateBy;
    /**
     * 修改时间
     */
    private Date updateTime;
    private String delFlag;

}
