package com.crc.secface.domain.vo;

import lombok.Data;

@Data
public class JoeyeToken {
    String email;
    String token;
    String status;
    String username;
}
