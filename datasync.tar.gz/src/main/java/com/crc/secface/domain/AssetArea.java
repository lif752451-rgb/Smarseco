package com.crc.secface.domain;

import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableId;
import com.baomidou.mybatisplus.annotation.TableName;
import com.baomidou.mybatisplus.extension.activerecord.Model;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.experimental.Accessors;

import java.math.BigDecimal;
import java.util.Date;

/**
 * <p>
 * 区域管理
 * </p>
 *
 * @author hejingsheng1
 * @since 2023-06-12
 */
@Data
@EqualsAndHashCode(callSuper = false)
@Accessors(chain = true)
@TableName("tb_asset_area")
public class AssetArea extends Model<AssetArea> {

    private static final long serialVersionUID = 1L;

    /**
     * ID
     */
    @TableId(value = "id", type = IdType.AUTO)
    private Long id;
    /**
     * 创建者
     */
    private String createBy;
    /**
     * 创建时间
     */
    private Date createTime;
    /**
     * 修改者
     */
    private String updateBy;
    /**
     * 修改时间
     */
    private Date updateTime;
    /**
     * 自定义UUID
     */
    private String customUuid;
    /**
     * 路径
     */
    private String ancestors;
    /**
     * 删除标识
     */
    private Integer delFlag;
    /**
     * 区域名称
     */
    private String areaName;
    /**
     * 同级排序
     */
    private Integer sortCurrentLevel;
    /**
     * 经度
     */
    private BigDecimal longitude;
    /**
     * 纬度
     */
    private BigDecimal latitude;
    /**
     * 海拔
     */
    private BigDecimal altitude;
    /**
     * 父节点uuid
     */
    private String parentCustomUuid;
    /**
     * 是否是叶子节点
     */
    private Integer leafFlag;
    /**
     * 备注
     */
    private String remark;

}
