package com.crc.secface.domain.vo;

import lombok.Data;

@Data
public class IpPortVo {
    String ip;
    int port;
}
