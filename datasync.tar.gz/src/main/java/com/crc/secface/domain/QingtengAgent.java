package com.crc.secface.domain;

import com.baomidou.mybatisplus.annotation.TableField;
import com.baomidou.mybatisplus.annotation.TableName;
import com.baomidou.mybatisplus.extension.activerecord.Model;
import com.crc.common.utils.DataUtils;
import com.crc.scanner.config.QtConfig;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.experimental.Accessors;

import java.util.Date;

/**
 * <p>
 *
 * </p>
 *
 * @author hejingsheng
 * @since 2022-12-06
 */
@Data
@EqualsAndHashCode(callSuper = false)
@Accessors(chain = true)
@TableName("tb_qingteng_agent")
public class QingtengAgent extends Model<QingtengAgent> {

    private static final long serialVersionUID = 1L;

    private String id;
    /**
     * 通信状态 1 – 在线 0 - 离线
     */
    private String onlineStatus;
    /**
     * Agent状态，0-在线 1-离线 2-停用 3-删除中
     */
    private String agentStatus;
    /**
     * 业务组ID
     */
    private String agentVersion;
    /**
     * 业务组名
     */
    private String bizGroupId;
    private String bizGroup;
    private String ip;
    private String localIp;
    private Date lastOnlineTime;
    private Date installTime;
    private Date createTime;
    private Date updateTime;
    private Integer offlineDays;
    /**
     * （1：华润云；0：其他）
     */
    private String isCrcCloud;

    private String osVersion;

    private boolean isWindows;

    @TableField(exist = false)
    boolean badStatus;

    @TableField(exist = false)
    QtConfig scannerConfig;

    /**
     * onlineStatus 通信状态 1 – 在线 0 - 离线
     * agentStatus 主机状态，0-在线 1-离线 2-停用
     */
    public boolean isBadStatus() {
        return "0".equals(onlineStatus) || DataUtils.equalsAny(agentStatus, "1", "2");
    }
}
