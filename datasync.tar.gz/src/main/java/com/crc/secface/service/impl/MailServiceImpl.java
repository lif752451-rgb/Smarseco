package com.crc.secface.service.impl;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;
import com.baomidou.mybatisplus.core.conditions.query.LambdaQueryWrapper;
import com.baomidou.mybatisplus.core.toolkit.Wrappers;
import com.crc.common.constants.Constants;
import com.crc.common.utils.EncryptUtil;
import com.crc.secface.domain.MailDTO;
import com.crc.secface.domain.SysEmailConfig;
import com.crc.secface.mapper.SysEmailConfigMapper;
import com.crc.secface.service.MailService;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.mail.javamail.JavaMailSenderImpl;
import org.springframework.mail.javamail.MimeMessageHelper;
import org.springframework.stereotype.Service;
import org.springframework.util.StopWatch;

import javax.mail.MessagingException;
import java.io.File;
import java.util.Date;
import java.util.Properties;

/**
 * @author SHUFENGFENG
 */
@Slf4j
@Service
public class MailServiceImpl implements MailService {
    /**
     * 注入邮件工具类
     */
    private JavaMailSenderImpl mailSender = new JavaMailSenderImpl();

    @Autowired
    private SysEmailConfigMapper sysEmailConfigMapper;

    /**
     * from 发送来源
     */
   /* @Value("${spring.mail.from}")
    private String from;*/

    /**
     * 发送测试邮件
     */
    @Value("${sendTestMail:}")
    private String sendTestMail;

    @Override
    public MailDTO sendHtmlMail(MailDTO mailDTO) {
        try {
            if (StringUtils.isNotBlank(sendTestMail)) {
                mailDTO.setTo(sendTestMail);
            }
            log.info("send#Mail :{},msg:{}", mailDTO.getTo(), mailDTO.getText());
            //如果发送测试邮箱有配置则替换发送邮箱
            mailDTO.setFrom(mailDTO.getFrom());
            //1.检测邮件
            checkMail(mailDTO);
            //2.发送邮件
            sendMimeMail(mailDTO);
            //3.保存邮件
            return saveMail(mailDTO);
        } catch (Throwable e) {
            log.error("发送邮件失败:{},", JSONObject.toJSONString(mailDTO), e);
            mailDTO.setStatus(Constants.Mail.FAIL);
            mailDTO.setError(e.getMessage());
            return mailDTO;
        }
    }


    @Override
    public MailDTO sendMail(MailDTO mailDTO) {
        try {
            //如果发送测试邮箱有配置则替换发送邮箱
            if (StringUtils.isNotBlank(sendTestMail)) {
                mailDTO.setTo(sendTestMail);
            }
            mailDTO.setFrom(mailDTO.getFrom());
            //1.检测邮件
            checkMail(mailDTO);
            //2.发送邮件
            sendMimeMail(mailDTO);
            //3.保存邮件
            return saveMail(mailDTO);
        } catch (Throwable e) {
            log.error("发送邮件失败:{},", JSONObject.toJSONString(mailDTO), e);
            mailDTO.setStatus(Constants.Mail.FAIL);
            mailDTO.setError(e.getMessage());
            return mailDTO;
        }
    }

    /**
     * 检测邮件信息类
     *
     * @param mailDTO
     */
    private void checkMail(MailDTO mailDTO) {
        if (StringUtils.isEmpty(mailDTO.getTo())) {
            throw new RuntimeException(Constants.Mail.TO_IS_NULL);
        }
        if (StringUtils.isEmpty(mailDTO.getSubject())) {
            throw new RuntimeException(Constants.Mail.SUBJECT_IS_NULL);
        }
        if (StringUtils.isEmpty(mailDTO.getText())) {
            throw new RuntimeException(Constants.Mail.TEXT_IS_NULL);
        }
    }

    /**
     * 构建复杂邮件信息类
     *
     * @param mailDTO
     */
    private void sendMimeMail(MailDTO mailDTO) {
        try {
            LambdaQueryWrapper<SysEmailConfig> q = Wrappers.lambdaQuery();
            q.eq(SysEmailConfig::getEmailStatus, 1);
            q.orderByDesc(SysEmailConfig::getId);
            q.last(" limit 1");
            SysEmailConfig emailConfig = sysEmailConfigMapper.selectOne(q);

            if (null != emailConfig) {
                log.info(JSON.toJSONString(emailConfig));
                mailSender.setHost(emailConfig.getSendHost());
                mailSender.setPort(emailConfig.getPort());
                mailSender.setUsername(emailConfig.getSendEmail());
                //mailSender.setPassword(emailConfig.getPassword());
                mailSender.setPassword(EncryptUtil.aesDecrypt(emailConfig.getPassword()));
                // SMTP服务器的连接信息
                Properties props = new Properties();
                props.setProperty("mail.transport.protocol", "smtp"); // 使用的协议（JavaMail规范要求）
                props.put("mail.smtp.host", emailConfig.getSendHost()); // SMTP主机号
                props.put("mail.smtp.port", emailConfig.getPort()); // 主机端口号
                props.put("mail.smtp.auth", "true"); // 是否需要认证
                //props.put("mail.smtp.starttls.enable", "true"); // 启用TLS加密
                props.setProperty("mail.smtp.socketFactory.fallback", "false");
                props.setProperty("mail.smtp.socketFactory.port", String.valueOf(emailConfig.getPort()));
                props.setProperty("mail.smtp.socketFactory", "javax.net.ssl.SSLSocketFactory");

                props.put("mail.smtp.connectiontimeout", "5000");
                props.put("mail.smtp.timeout", 30 * 1000);
                mailSender.setJavaMailProperties(props);
                mailDTO.setHost(emailConfig.getSendHost() + " " + emailConfig.getPort());
                mailDTO.setFrom(emailConfig.getSendEmail());
            }else {
                log.error("未找到有效邮箱配置，退出发邮箱！!!");
                return;
            }

            //正式发送邮件
            StopWatch stopWatch = new StopWatch("MailService");
            stopWatch.start();
            MimeMessageHelper messageHelper = convertToHtml(mailDTO);
            stopWatch.stop();
            stopWatch.start();
            mailSender.send(messageHelper.getMimeMessage());
            stopWatch.stop();
            log.info("构建复杂邮件信息类,发送邮件耗时:{}", stopWatch.prettyPrint());
            mailDTO.setStatus(Constants.Mail.OK);
        } catch (Exception e) {
            log.error("发送邮件出错,{}",e.getMessage(), e);
        }
    }

    private MimeMessageHelper convertToHtml(MailDTO mailDTO) throws MessagingException {
        //true表示支持复杂类型
        MimeMessageHelper messageHelper = new MimeMessageHelper(mailSender.createMimeMessage(), true, "UTF-8");
        //邮件发信人
        messageHelper.setFrom(mailDTO.getFrom());
        //邮件收信人
        messageHelper.setTo(mailDTO.getTo().split(Constants.Symbol.COMMA));
        //邮件主题
        messageHelper.setSubject(mailDTO.getSubject());
        //邮件内容
        messageHelper.setText(mailDTO.getText(), true);
        //抄送
        if (StringUtils.isNotEmpty(mailDTO.getCc())) {
            messageHelper.setCc(mailDTO.getCc().split(Constants.Symbol.COMMA));
        }
        //密送
        if (StringUtils.isNotEmpty(mailDTO.getBcc())) {
            messageHelper.setCc(mailDTO.getBcc().split(Constants.Symbol.COMMA));
        }
        //添加邮件附件
        if (null != mailDTO.getFiles()) {
            for (File file : mailDTO.getFiles()) {
                messageHelper.addAttachment(file.getName(), file);
            }
        }
        //发送时间
        if (null == mailDTO.getSentDate()) {
            mailDTO.setSentDate(new Date());
        }
        messageHelper.setSentDate(mailDTO.getSentDate());
        return messageHelper;
    }


    private MimeMessageHelper convertTo(MailDTO mailDTO) throws MessagingException {
        //true表示支持复杂类型
        MimeMessageHelper messageHelper = new MimeMessageHelper(mailSender.createMimeMessage(), true);
        //邮件发信人
        messageHelper.setFrom(mailDTO.getFrom());
        //邮件收信人
        messageHelper.setTo(mailDTO.getTo().split(Constants.Symbol.COMMA));
        //邮件主题
        messageHelper.setSubject(mailDTO.getSubject());
        //邮件内容
        messageHelper.setText(mailDTO.getText(), false);
        //抄送
        if (StringUtils.isNotEmpty(mailDTO.getCc())) {
            messageHelper.setCc(mailDTO.getCc().split(Constants.Symbol.COMMA));
        }
        //密送
        if (StringUtils.isNotEmpty(mailDTO.getBcc())) {
            messageHelper.setCc(mailDTO.getBcc().split(Constants.Symbol.COMMA));
        }
        //添加邮件附件
        if (null != mailDTO.getFiles()) {
            for (File file : mailDTO.getFiles()) {
                messageHelper.addAttachment(file.getName(), file);
            }
        }
        //发送时间
        if (null == mailDTO.getSentDate()) {
            mailDTO.setSentDate(new Date());
        }
        messageHelper.setSentDate(mailDTO.getSentDate());
        return messageHelper;
    }

    /**
     * 保存邮件
     *
     * @param mailDTO
     * @return
     */
    private MailDTO saveMail(MailDTO mailDTO) {
        //将邮件保存到数据库..
        log.info("发送邮件结束,邮件内容:{}", JSONObject.toJSONString(mailDTO));
        return mailDTO;
    }

    /**
     * 获取邮件发信人
     *
     * @return
     */
    public String getMailSendFrom() {
        return mailSender.getJavaMailProperties().getProperty("from");
    }

}
