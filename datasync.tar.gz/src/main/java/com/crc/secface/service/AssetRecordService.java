package com.crc.secface.service;

import cn.hutool.core.collection.CollUtil;
import cn.hutool.core.date.DateUtil;
import cn.hutool.core.util.ReflectUtil;
import cn.hutool.core.util.StrUtil;
import com.alibaba.fastjson.JSONArray;
import com.alibaba.fastjson.JSONObject;
import com.baomidou.mybatisplus.core.conditions.query.LambdaQueryWrapper;
import com.baomidou.mybatisplus.core.toolkit.Wrappers;
import com.crc.common.constants.Constants;
import com.crc.common.enums.DatabaseEnums;
import com.crc.common.enums.StatusEnum;
import com.crc.common.utils.DataUtils;
import com.crc.common.utils.DictUtil;
import com.crc.common.utils.JsonUtils;
import com.crc.common.utils.VersionUtils;
import com.crc.secface.config.GetSpringBean;
import com.crc.secface.domain.*;
import com.crc.secface.mapper.*;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.*;
import java.util.stream.Collectors;
import java.util.stream.Stream;

import static com.crc.common.constants.AssetConstant.INTERNAL_IP_FIELDS;
import static com.crc.common.constants.AssetConstant.OPINION_FIELDS;
import static com.crc.common.constants.Constants.*;
import static com.crc.common.constants.Constants.Symbol.COMMA;
import static com.crc.common.constants.Constants.Symbol.SLASH;
import static com.crc.common.enums.DictTypeEnum.*;


@Slf4j
@Service
public class AssetRecordService {

    /**
     * 资产状态
     */
    private Map<String, String> operatingStatus;

    /**
     * 资产等级
     */
    private Map<String, String> keyAsset;

    /**
     * 环境类型
     */
    private Map<String, String> environmentType;

    /**
     * 资源类型
     */
    private Map<String, String> sourceType;

    /**
     * 等保定级
     */
    private Map<String, String> equalProtectionLevel;

    @Autowired
    AssetAreaMapper assetAreaMapper;
    @Autowired
    SeverAssetTypeMapper severAssetTypeMapper;

    @Autowired
    AssetChangeRecordMapper assetChangeRecordMapper;

    @Autowired
    AssetPersonMapper assetPersonMapper;

    @Autowired
    AssetMapper assetMapper;

    public void addChangeRecord(Asset oldAsset, Asset asset) {
        try {
            if (oldAsset == null) {
                oldAsset = new Asset();
            }
            if (asset == null) {
                return;
            }
            if (StrUtil.isNotEmpty(asset.getAreaCustomUuid())) {
                if (VersionUtils.getDatabase() == DatabaseEnums.MYSQL.getCode()) {
                    asset.setAreaName(findAreaFullNameByCustomUuid(asset.getAreaCustomUuid()));
                } else {
                    asset.setAreaName(findAreaFullNameByCustomUuidOracle(asset.getAreaCustomUuid()));
                }
            }
            if (StrUtil.isNotEmpty(asset.getAssetTypeId())) {
                asset.setAssetTypeName(getFullAssetTypeName(asset.getAssetTypeId()));
            }
            if (StringUtils.isNotBlank(asset.getInternalIp())) {
                AssetPerson q = new AssetPerson();
                q.setInternalIp(asset.getInternalIp());
                q.setType("1");
                asset.setDutyUsers(assetPersonMapper.getListByIp(q));

                q.setType("2");
                asset.setOperatingUsers(assetPersonMapper.getListByIp(q));
            }
            if (CollUtil.isEmpty(asset.getDutyUsers()) || asset.getDutyUsers().size() == 0) {
                asset.setDutyUsers(null);
            }
            if (CollUtil.isEmpty(asset.getOperatingUsers()) || asset.getOperatingUsers().size() == 0) {
                asset.setOperatingUsers(null);
            }
            if (CollUtil.isEmpty(oldAsset.getDutyUsers()) || oldAsset.getDutyUsers().size() == 0) {
                oldAsset.setDutyUsers(null);
            }
            if (CollUtil.isEmpty(oldAsset.getOperatingUsers()) || oldAsset.getOperatingUsers().size() == 0) {
                oldAsset.setOperatingUsers(null);
            }
            addAssetChangeRecord(asset, oldAsset, Asset.class, "asset_change_column");
        } catch (Exception e) {
            log.error(e.getMessage(), e);
        }
    }

    private void addAssetChangeRecord(Asset newAsset, Asset oldAsset, Class<Asset> tClass, String type) {
        Map<String, String> labelAndValue = DictUtil.getDict(type).stream()
                .collect(Collectors.toMap(SysDictData::getDictValue, SysDictData::getDictLabel));
        addAssetChangeRecord(newAsset, oldAsset, tClass, labelAndValue);
    }

    private void addAssetChangeRecord(Object newAsset, Object oldAsset, Class<?> tClass,
                                      Map<String, String> labelAndValue) {
        if (CollUtil.isNotEmpty(labelAndValue)) {
            // 获取资产相关数据字典
            findAssetDict();
            // 获取资产变更字段
            List<ChangeInfo> list = getChangeInfoList(newAsset, oldAsset, tClass, labelAndValue);
            AssetChangeRecord assetChangeRecord = buildAssetChangeRecord(newAsset, tClass, list);
            if (Objects.nonNull(assetChangeRecord)) {

                try {
                    String ip = String.valueOf(ReflectUtil.getFieldValue(newAsset, INTERNAL_IP_FIELDS));
                    LambdaQueryWrapper<AssetChangeRecord> q = Wrappers.lambdaQuery();
                    q.eq(AssetChangeRecord::getInternalIp, ip);
                    q.orderByDesc(AssetChangeRecord::getId);
                    q.last(" limit 1");
                    AssetChangeRecord data = assetChangeRecordMapper.selectOne(q);
                    if (data != null && StringUtils.isNotBlank(data.getChangeContent())) {
                        if (data.getChangeContent().equals(assetChangeRecord.getChangeContent())) {
                            log.info("{},跟最近一次变更一样，不更新",ip);
                            return;
                        }
                    }
                } catch (Exception e) {
                    log.error(e.getMessage(),e);
                }

                assetChangeRecordMapper.insert(assetChangeRecord);
            }
        }
    }

    /**
     * 构建新增资产变更记录实体类
     *
     * @param newAsset 变更后的值
     * @param tClass   映射实体对象class
     * @param list     变更字段
     * @return AssetChangeRecord
     */
    private AssetChangeRecord buildAssetChangeRecord(Object newAsset, Class<?> tClass, List<ChangeInfo> list) {
        // 判断资产变更字段、和内网ip 是否为空
        if (CollUtil.isNotEmpty(list) && ReflectUtil.hasField(tClass, INTERNAL_IP_FIELDS)) {
            String internalIp = String.valueOf(ReflectUtil.getFieldValue(newAsset, INTERNAL_IP_FIELDS));
            String sourceCode = String.valueOf(ReflectUtil.getFieldValue(newAsset, "source"));

            AssetChangeRecord assetChangeRecord = new AssetChangeRecord();
            assetChangeRecord.setUpdateByLabel("系统");
            assetChangeRecord.setCreateTime(new Date());
            assetChangeRecord.setUpdateTime(new Date());
            assetChangeRecord.setUpdateBy("system");
            assetChangeRecord.setCreateBy("system");
            assetChangeRecord.setInternalIp(internalIp);
            assetChangeRecord.setSource(sourceCode);
            assetChangeRecord.setChangeContent(JSONObject.toJSONString(list));
            assetChangeRecord
                    .setChangeColumn(list.stream().map(ChangeInfo::getNameCN).collect(Collectors.joining(COMMA)));
            return assetChangeRecord;
        }
        //log.info("构建资产变更记录缺乏关键参数");
        return null;
    }

    /**
     * 获取资产变更字段
     *
     * @param newAsset      变更后的值
     * @param oldAsset      变前的值
     * @param tClass        映射实体对象class
     * @param labelAndValue 需要记录变更字段
     * @return List
     */
    private List<ChangeInfo> getChangeInfoList(Object newAsset, Object oldAsset, Class<?> tClass,
                                               Map<String, String> labelAndValue) {
        // 变更后的值newAsset 变更前的值oldAsset
        DataUtils.convertSpecialChar(newAsset);
        List<ChangeInfo> list = new ArrayList<>();
        String opinion = ReflectUtil.hasField(tClass, OPINION_FIELDS)
                ? String.valueOf(ReflectUtil.getFieldValue(newAsset, OPINION_FIELDS)) : null;
        for (Map.Entry<String, String> entry : labelAndValue.entrySet()) {
            String attr = entry.getKey();
            // 字段不存在 不记录
            if (!ReflectUtil.hasField(tClass, attr)) {
                continue;
            }
            String newValue = this.getFieldValue(attr, newAsset);
            String oldValue = this.getFieldValue(attr, oldAsset);
            if (StringUtils.isBlank(newValue) || StringUtils.isBlank(oldValue)) {
                continue;
            }
            // 变更前、变更后 值都为空或值相等 不记录
            if (StringUtils.isAllBlank(newValue, oldValue) || newValue.equals(oldValue)) {
                continue;
            }
            //log.info("变更记录检查字段名：" + attr + "对应字段名称：" + entry.getValue());
            log.info("{}  变更字段，变更前值：" + oldValue + " 变更后值：" + newValue, this.getFieldValue("internalIp", newAsset));
            ChangeInfo changeInfo = new ChangeInfo();
            changeInfo.setName(attr);
            changeInfo.setNameCN(entry.getValue());
            changeInfo.setRemark(opinion);
            changeInfo.setNewValue(newValue);
            changeInfo.setOldValue(oldValue);
            list.add(changeInfo);
        }
        return list;
    }


    private String getFieldValue(String attr, Object obj) {
        Object fieldValue = ReflectUtil.getFieldValue(obj, attr);
        String value = "";
        if (Objects.isNull(fieldValue)) {
            return value;
        }
        if ("operatingStatus".equals(attr)) {
            value = operatingStatus.get(String.valueOf(fieldValue));
        } else if ("keyAsset".equals(attr)) {
            value = keyAsset.get(String.valueOf(fieldValue));
        } else if ("environmentType".equals(attr)) {
            value = environmentType.get(String.valueOf(fieldValue));
        } else if ("sourceType".equals(attr)) {
            value = sourceType.get(String.valueOf(fieldValue));
        } else if ("equalProtectionLevel".equals(attr)) {
            value = equalProtectionLevel.get(String.valueOf(fieldValue));
        } else if ("dutyUsers".equals(attr) || "operatingUsers".equals(attr)) {
            if (fieldValue instanceof List) {
                List<AssetPerson> assetPersonList =
                        JSONArray.parseArray(JsonUtils.toJSONString(fieldValue), AssetPerson.class);
                value = assetPersonList.stream()
                        .map(assetPerson -> Stream
                                .of(assetPerson.getUserName(), assetPerson.getEmail(), assetPerson.getPhone())
                                .filter(StringUtils::isNotEmpty).collect(Collectors.joining(SLASH)))
                        .collect(Collectors.joining(COMMA));
            }
        } else if ("assetPower".equals(attr) || "internetPublic".equals(attr) || "isCombatOff".equals(attr)
                || "isCombatPlan".equals(attr) || "isPersonalInfo".equals(attr) || "centralizedSystem".equals(attr)) {
            value = convertJudge(fieldValue);
        } else if ("transformationCompleted".equals(attr)) {
            Integer transformationCompleted = DataUtils.toInt(fieldValue);
            value = StatusEnum.YES.getValue().equals(transformationCompleted) ? FINISHED
                    : StatusEnum.YES.getValue().equals(transformationCompleted) ? UNFINISHED : NULL_STR;
        } else if ("offStartTime".equals(attr) || "offEndTime".equals(attr)) {
            if (fieldValue instanceof Date) {
                value = DateUtil.formatDateTime((Date) fieldValue);
            }
        } else if ("expirtTime".equals(attr) || "equalProtectionFirstTime".equals(attr)) {
            if (fieldValue instanceof Date) {
                value = DateUtil.formatDate((Date) fieldValue);
            }
        }
        if (StringUtils.isEmpty(value)) {
            value = String.valueOf(fieldValue);
        }
        return value;
    }

    /**
     * 转换判断
     *
     * @param source Integer
     * @return 0 否 1 是
     */
    private static String convertJudge(Object source) {
        if (null == source) {
            return Constants.BLANK_STR;
        }
        if (Constants.SYS_WHETHER_NO.equals(source.toString())) {
            return Constants.NO;
        } else if (Constants.SYS_WHETHER_YES.equals(source.toString())) {
            return Constants.YES;
        }
        return source.toString();
    }

    private void findAssetDict() {
        if (CollUtil.isEmpty(operatingStatus)) {
            operatingStatus = DictUtil.getMapValueLabel(OPERATING_STATUS.getName());
        }
        if (CollUtil.isEmpty(keyAsset)) {
            keyAsset = DictUtil.getMapValueLabel(KEY_ASSET.getName());
        }
        if (CollUtil.isEmpty(environmentType)) {
            environmentType = DictUtil.getMapValueLabel(ENVIRONMENT_TYPE.getName());
        }
        if (CollUtil.isEmpty(sourceType)) {
            sourceType = DictUtil.getMapValueLabel(SOURCE_TYPE.getName());
        }
        if (CollUtil.isEmpty(equalProtectionLevel)) {
            equalProtectionLevel = DictUtil.getMapValueLabel(EQUAL_PROTECTION_LEVEL.getName());
        }
    }

    public void setDefaultTypeAndArea(Asset asset) {
        try {
            SeverAssetType type = severAssetTypeMapper.getDefaultType();
            if (type != null) {
                asset.setAssetTypeId(type.getId());
                asset.setAssetTypeName(getFullAssetTypeName(type));
            }

            if (StrUtil.isNotEmpty(asset.getAreaCustomUuid())) {
                if (VersionUtils.getDatabase() == DatabaseEnums.MYSQL.getCode()) {
                    asset.setAreaName(findAreaFullNameByCustomUuid(asset.getAreaCustomUuid()));
                } else {
                    asset.setAreaName(findAreaFullNameByCustomUuidOracle(asset.getAreaCustomUuid()));
                }
            }
        } catch (Exception e) {
            log.error(e.getMessage(), e);
        }
    }

    private String getFullAssetTypeName(SeverAssetType severAssetType) {
        String path = "";
        if (StringUtils.isNotEmpty(severAssetType.getAncestors())) {
            List<SeverAssetType> parentPath = severAssetTypeMapper.getFullParentPath(severAssetType.getAncestors());
            StringBuffer sb = new StringBuffer();
            parentPath.forEach(str -> {
                sb.append(str.getTypeName()).append("/");
            });
            path = sb.substring(0, sb.toString().length() - 1);
        } else {
            path = severAssetType.getTypeName();
        }
        return path;
    }

    private String getFullAssetTypeName(String id) {
        SeverAssetType severAssetType = severAssetTypeMapper.selectById(id);
        String path = "";
        if (StringUtils.isNotEmpty(severAssetType.getAncestors())) {
            List<SeverAssetType> parentPath = severAssetTypeMapper.getFullParentPath(severAssetType.getAncestors());
            StringBuffer sb = new StringBuffer();
            parentPath.forEach(str -> {
                sb.append(str.getTypeName()).append("/");
            });
            path = sb.substring(0, sb.toString().length() - 1);
        } else {
            path = severAssetType.getTypeName();
        }
        return path;
    }

    public String findAreaFullNameByCustomUuid(String customUuid) {
        return assetAreaMapper.findAreaFullNameByCustomUuid(customUuid);
    }

    public String findAreaFullNameByCustomUuidOracle(String customUuid) {
        return assetAreaMapper.findAreaFullNameByCustomUuidOracle(customUuid);
    }

    public List<SeverAssetType> findAssetTypeAll() {
        try {
            SeverAssetTypeMapper severAssetTypeMapper = GetSpringBean.getBean(SeverAssetTypeMapper.class);
            List<SeverAssetType> typeAllList = severAssetTypeMapper.findAssetTypeAll();
            if (typeAllList != null && CollUtil.isNotEmpty(typeAllList)) {
                typeAllList.forEach(type -> {
                    List<String> typeNameList = new ArrayList<>();
                    if (StringUtils.isNotBlank(type.getAncestors())) {
                        for (String typeId : type.getAncestors().split(COMMA)) {
                            typeAllList.stream().filter(assetType -> typeId.equals(assetType.getId()))
                                    .map(SeverAssetType::getTypeName).findFirst().ifPresent(typeNameList::add);
                        }
                        type.setFullPath(StringUtils.join(typeNameList, SLASH));
                    }
                });
            }
        } catch (Exception e) {
            log.error(e.getMessage(), e);
        }
        return new ArrayList<>();
    }
}
