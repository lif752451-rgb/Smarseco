package com.crc.job;

import com.alibaba.fastjson.JSONObject;
import com.crc.common.utils.JsonUtils;
import com.crc.secface.domain.SysDictData;
import lombok.extern.slf4j.Slf4j;
import org.quartz.*;
import org.quartz.impl.StdSchedulerFactory;

import java.util.concurrent.ConcurrentHashMap;


@Slf4j
public class JobManager {
    public static String GROUP_NAME = "sync_group";
    public static String KEY_NAME = "sync_data";
    public static ConcurrentHashMap<String, SysDictData> tempMap = new ConcurrentHashMap<>();

    public static void startJob(SysDictData tm) {
        String id = String.valueOf(tm.getDictCode());
        JobDetail job = JobBuilder.newJob(com.crc.job.DataSyncJob.class).withIdentity(id, GROUP_NAME).build();
        job.getJobDataMap().put(KEY_NAME, tm);
        try {
            JSONObject json = JsonUtils.parse(tm.getRemark());
            if (!json.containsKey("cron")) {
                return;
            }
            String cron = JsonUtils.getStr(json, "cron");
            Trigger trigger = TriggerBuilder
                    .newTrigger()
                    .withSchedule(CronScheduleBuilder.cronSchedule(cron)).build();
            Scheduler scheduler = StdSchedulerFactory.getDefaultScheduler();
            scheduler.scheduleJob(job, trigger);
            if (!scheduler.isStarted()) {
                scheduler.start();
            }
            tempMap.put(id, tm);
            log.info("startJob " + tm.getDictLabel()  + " --> " + cron);
        } catch (Exception e) {
            log.error(e.getMessage(), e);
            deleteJob(tm);
        }
    }

    public static void deleteJob(SysDictData tm) {
        try {
            String id = String.valueOf(tm.getDictCode());
            JobKey jk = JobKey.jobKey(id, GROUP_NAME);
            Scheduler scheduler = StdSchedulerFactory.getDefaultScheduler();
            scheduler.deleteJob(jk);
            log.info("delete Job " + tm.getDictLabel());
        } catch (Exception e) {
            log.error(e.getMessage(), e);
        }
    }
}
