package com.crc.job;

import com.alibaba.fastjson.JSONObject;
import com.crc.common.utils.DateUtils;
import com.crc.common.utils.JsonUtils;
import com.crc.common.utils.MyTheadUtils;
import com.crc.secface.domain.SysDictData;
import com.crc.secface.schedule.assemble.host.DccAssemble;
import com.crc.secface.schedule.assemble.host.FoeyeAssemble;
import com.crc.sync.ai.AITrainSync;
import com.crc.sync.asset.AssetDelSync;
import com.crc.sync.asset.anheng.AnHengSync;
import com.crc.sync.asset.internet.InternetOfThingsSync;
import com.crc.sync.asset.ngsoc.NgsocSync;
import com.crc.sync.banboo.BigDataSync;
import com.crc.sync.banboo.RqBimDataSync;
import com.crc.sync.cmdb.CmdbCenter;
import com.crc.sync.cmdb.ComponentCenter;
import com.crc.sync.cmdb.TerminalSyncToDb;
import com.crc.sync.cmdb.TianyanLogIpSyncToAsset;
import com.crc.sync.cmdb.f5.F5CmdbSync;
import com.crc.sync.cmdb.f5.F5LbSync;
import com.crc.sync.config.SyncSecConfigLoad;
import com.crc.sync.config.SyncSecConstants;
import com.crc.sync.dept.SysDeptFullNameSync;
import com.crc.sync.foradar.ForadarAllDataSync;
import com.crc.sync.jiaotu.JiaotuVulSync;
import com.crc.sync.mail.FishMailSync;
import com.crc.sync.mail.FishNewDataSync;
import com.crc.sync.qingteng.QingtengAllBaselineSync;
import com.crc.sync.qingteng.QingtengAllPatchSync;
import com.crc.sync.qingteng.QingtengAllWeakPassSync;
import com.crc.sync.qingteng.v2.QingtengAllRiskSync;
import com.crc.sync.safedog.SafedogAllRiskSync;
import com.crc.sync.score.AssetScoreSyncV2;
import com.crc.sync.segment.SegmentAlarmSync;
import com.crc.sync.sip.SanforSipAssetSync;
import com.crc.sync.terminal.sdn.SdnAllAssetSync;
import com.crc.sync.terminal.tianqin.TianQinAllAssetSync;
import com.crc.sync.terminal.tianqin.TianQinV6AllAssetSync;
import com.crc.sync.vul.VulUserSync;
import lombok.extern.slf4j.Slf4j;
import org.quartz.DisallowConcurrentExecution;
import org.quartz.Job;
import org.quartz.JobDataMap;
import org.quartz.JobExecutionContext;
import org.quartz.JobExecutionException;

import java.util.Date;
import java.util.HashMap;

/**
 * 数据同步
 */
@Slf4j
@DisallowConcurrentExecution
public class DataSyncJob implements Job {
    SysDictData tm;
    static HashMap<String, String> typeMap = new HashMap<>();

    static {
        String data = "0 SQL注入,1 未授权访问,2 敏感信息泄露,3 XML外部实体注入,4 跨站脚本攻击,5 不安全的反序列,6 客户端请求伪造,7 服务端请求伪造,8 命令执行,9 代码执行,10 任意文件上传,11 任意文件读取,12 拒绝服务攻击,13 目录遍历,14 恶意后门,15 本地提权,16 注入漏洞";
        for (String x : data.split(",")) {
            String[] xx = x.split(" ");
            if (xx.length == 2) {
                typeMap.put(xx[0], xx[1]);
            }
        }
    }

    @Override
    public void execute(JobExecutionContext context) throws JobExecutionException {
        /*
         * Do something
         */
        JobDataMap map = context.getJobDetail().getJobDataMap();
        tm = (SysDictData) map.get(JobManager.KEY_NAME);
        if (tm == null) {
            return;
        }

        log.info(tm.getDictLabel() + " Start! ");
        try {
            JSONObject json = JsonUtils.parse(tm.getRemark());
            if (!json.containsKey("type")) {
                log.error("job type is null,{}", tm.getRemark());
                return;
            }
            String type = JsonUtils.getStr(json, "type");//
            if ("cmdb".equals(type)) {
                //CMDB同步
                CmdbCenter.sync();
            } else if ("component".equals(type)) {
                //组件同步
                (new ComponentCenter()).sync();
            } else if ("vulAuto".equals(type)) {
                //利润中心版本漏洞
                if (SyncSecConfigLoad.isEnable(SyncSecConstants.QT_WEAKPASS_SYNC_ENABLE)) {
                    try {
                        log.info("同步 all 弱口令 start");
                        (new QingtengAllWeakPassSync()).sync();
                        log.info("同步 all 弱口令 end");
                    } catch (Exception e) {
                        log.error(e.getMessage(), e);
                    }
                }
                if (SyncSecConfigLoad.isEnable(SyncSecConstants.QT_STANDARD_SYNC_ENABLE)) {
                    try {
                        log.info("同步 all 漏洞 start");
                        (new QingtengAllRiskSync()).sync();
                        log.info("同步 all 漏洞 end");
                    } catch (Exception e) {
                        log.error(e.getMessage(), e);
                    }
                }

                if (SyncSecConfigLoad.isEnable(SyncSecConstants.QT_PATCH_SYNC_ENABLE)) {
                    (new QingtengAllPatchSync()).sync();
                }
                if (SyncSecConfigLoad.isEnable(SyncSecConstants.QT_BASELINE_SYNC_ENABLE)) {
                    (new QingtengAllBaselineSync()).sync();
                }

                MyTheadUtils.sleepBySec(10);
                if (SyncSecConfigLoad.isEnable(SyncSecConstants.DCC_SYNC_ENABLE)) {
                    log.info("parseTask定时同步All Dcc任务");
                    try {
                        DccAssemble.parseAllTask();
                    } catch (Exception e) {
                        log.error(e.getMessage(), e);
                    }
                    log.info("parseTask定时同步All Dcc任务完成");
                }

                if (SyncSecConfigLoad.isEnable(SyncSecConstants.D01_SYNC_ENABLE)) {
                    log.info("parseTask定时同步All D01/Foeye任务");
                    try {
                        FoeyeAssemble.parseAllTask();
                    } catch (Exception e) {
                        log.error(e.getMessage(), e);
                    }
                    log.info("parseTask定时同步All D01/Foeye任务完成");
                }

                if (SyncSecConfigLoad.isEnable(SyncSecConstants.JIAOTU_SYNC_ENABLE)) {
                    log.info("parseTask定时同步All 椒图任务");
                    try {
                        (new JiaotuVulSync()).sync();
                    } catch (Exception e) {
                        log.error(e.getMessage(), e);
                    }
                    log.info("parseTask定时同步All D01/Foeye任务完成");
                }
            } else if ("assetScore".equals(type)) {
                AssetScoreSyncV2 assetScoreSync = new AssetScoreSyncV2();
                assetScoreSync.cal();
            } else if ("deptFullPath".equals(type)) {
                SysDeptFullNameSync fullNameSync = new SysDeptFullNameSync();
                fullNameSync.sync();
            } else if ("syncTerminal".equals(type)) {
                log.info("终端资产同步DB开始。。。。");
                TerminalSyncToDb jiaotuCmdbSync = new TerminalSyncToDb();
                jiaotuCmdbSync.sync();
                log.info("终端资产同步DB结束。。。。");
            } else if ("aiTrain".equals(type)) {
                /*
                推送AI重新学习入口
                 */
                AITrainSync.train(json);
            } else if ("safedogAuto".equals(type)) {
                /*
                安全狗对接入口
                 */
                SafedogAllRiskSync sync = new SafedogAllRiskSync();
                sync.sync();
            } else if ("foradarAuto".equals(type)) {
                /*
                foradar对接入库
                 */
                ForadarAllDataSync sync = new ForadarAllDataSync();
                sync.sync();
            } else if ("tianqin".equals(type)) {
                /*
                天擎对接入口
                 */
                TianQinAllAssetSync sync = new TianQinAllAssetSync();
                sync.sync();

                TianQinV6AllAssetSync syncV6 = new TianQinV6AllAssetSync();
                syncV6.sync();
            } else if ("tianyan".equals(type)) {
                /*
                天眼对接入口
                 */
                TianyanLogIpSyncToAsset sync = new TianyanLogIpSyncToAsset();
                sync.sync();
            } else if ("f5lb".equals(type)) {
                /*
                F5对接入口
                 */
                F5LbSync sync = new F5LbSync();
                sync.sync();
            } else if ("f5cmdb".equals(type)) {
                /*
                F5 CMDB对接入口
                 */
                F5CmdbSync sync = new F5CmdbSync();
                sync.sync();
            } else if ("fishData".equalsIgnoreCase(type)) {
                /*
                   钓鱼数据计算
                 */
                if (SyncSecConfigLoad.isEnable(SyncSecConstants.FISH_DB_CONFIG)) {
                    MyTheadUtils.sleepBySec(10);
                    try {
                        FishNewDataSync fishDataSync = new FishNewDataSync();
                        fishDataSync.sync();
                    } catch (Exception e) {
                        log.error("钓鱼数据同步异常", e);
                    }
                }
                if (SyncSecConfigLoad.isEnable(SyncSecConstants.FISH_SYNC_ENABLE)) {
                    MyTheadUtils.sleepBySec(10);
                    try {
                        FishMailSync fishMailSync = new FishMailSync();
                        fishMailSync.sync();
                    } catch (Exception e) {
                        log.error("钓鱼邮件计算异常", e);
                    }
                }
            } else if ("vulUser".equalsIgnoreCase(type)) {
                /*
                   更新漏洞处置人
                 */
                VulUserSync sync = new VulUserSync();
                sync.sync();
            } else if ("segmentAlarmSync".equalsIgnoreCase(type)) {
                /*
                   网段告警数据同步
                 */
                SegmentAlarmSync sync = new SegmentAlarmSync();
                sync.cal();
            } else if ("sdn".equalsIgnoreCase(type)) {
                /*
                   SDN数据同步
                 */
                SdnAllAssetSync sync = new SdnAllAssetSync();
                sync.sync();
            } else if ("bigdata".equalsIgnoreCase(type)) {
                /*
                   大数据同步
                 */
                BigDataSync sync = new BigDataSync();
                sync.sync();
            } else if ("bimdata".equalsIgnoreCase(type)) {
                /*
                   燃气BIM同步
                 */
                RqBimDataSync sync = new RqBimDataSync();
                sync.sync();
            } else if ("sip".equalsIgnoreCase(type)) {
                /*
                   燃气BIM同步
                 */
                SanforSipAssetSync sync = new SanforSipAssetSync();
                sync.sync();
            } else if ("anheng".equalsIgnoreCase(type)) {
                // 安恒工控态势感知资产同步
                AnHengSync sync = new AnHengSync();
                sync.sync();
            } else if ("iot".equalsIgnoreCase(type)) {
                // 物联网中台资产同步
                InternetOfThingsSync sync = new InternetOfThingsSync();
                sync.sync();
            } else if ("ngsoc".equalsIgnoreCase(type)) {
                // 安全分析与管理系统资产同步
                NgsocSync sync = new NgsocSync();
                sync.sync();
            } else if ("assetDelete".equalsIgnoreCase(type)) {
                // 资产更新删除历史数据（根据更新时间）
                AssetDelSync sync = new AssetDelSync();
                sync.sync();
            }
        } catch (Exception e) {
            log.error(e.getMessage(), e);
        }
        log.info(tm.getDictLabel() + "  end! " + DateUtils.getDateTimeString1(new Date()));
    }


}
