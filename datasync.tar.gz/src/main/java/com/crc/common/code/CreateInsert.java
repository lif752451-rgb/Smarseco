package com.crc.common.code;


import org.apache.commons.lang3.CharUtils;
import org.apache.commons.lang3.StringUtils;

import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class CreateInsert<T> {

    /**
     * 创建插入SQL语句
     */
    public String createinsert(T entity, String tableName) {
        String sql = "insert into ";
        StringBuilder column = new StringBuilder(); // 列
        StringBuilder c_values = new StringBuilder(); // 列值
        List<Map<String, Object>> list = getFiledsInfo(entity);
        sql += tableName + " ";
        for (Map<String, Object> stringObjectMap : list) {
            if (stringObjectMap.get("f_value") != null) {
                // System.out.println("属性数据类型：" + list.get(i).get("f_type"));
                column.append(propertyToField(stringObjectMap.get("f_name"))).append(",");
                boolean isDigit = false;
                if (stringObjectMap.get("f_value") instanceof Integer) {// 处理小数字段类型
                    isDigit = true;
                } else if (stringObjectMap.get("f_value") instanceof Long) {//text
                    isDigit = true;
                } else if (stringObjectMap.get("f_value") instanceof Double) {//text
                    isDigit = true;
                } else if (stringObjectMap.get("f_value") instanceof Float) {//text
                    isDigit = true;
                }
                String v = stringObjectMap.get("f_value").toString();
                if (isDigit) {
                    c_values.append(" ").append(v).append(" ,");
                } else {
                    if (v.contains("'"))
                        v = v.replace("'", "\"");
                    else if (v.contains("&"))
                        v = v.replace("&", "%26");
                    c_values.append("'").append(v).append("',");
                }
            }

        }
        sql += "(" + column.substring(0, column.length() - 1) + ") values (" + c_values.substring(0, c_values.length() - 1) + ")";

        return sql;
    }

    /**
     * 创建更新SQL语句
     */
    public String createupdate(T entity, String tableName, String fixSql) {
        String sql = "update ";
        StringBuilder colEqVal = new StringBuilder(); // 列
        List<Map<String, Object>> list = getFiledsInfo(entity);
        sql += tableName + " set ";
        for (Map<String, Object> stringObjectMap : list) {
            if (stringObjectMap.get("f_value") != null) {
                // System.out.println("属性数据类型：" + list.get(i).get("f_type"));
                colEqVal.append(propertyToField(stringObjectMap.get("f_name"))).append("=");

                boolean isDigit = false;
                if (stringObjectMap.get("f_value") instanceof Integer) {// 处理小数字段类型
                    isDigit = true;
                } else if (stringObjectMap.get("f_value") instanceof Long) {//text
                    isDigit = true;
                } else if (stringObjectMap.get("f_value") instanceof Double) {//text
                    isDigit = true;
                } else if (stringObjectMap.get("f_value") instanceof Float) {//text
                    isDigit = true;
                }

                String v = stringObjectMap.get("f_value").toString();
                if (isDigit) {
                    colEqVal.append(v).append(" ,");
                } else {
                    if (v.contains("'"))
                        v = v.replace("'", "\"");
                    else if (v.contains("&"))
                        v = v.replace("&", "%26");
                    colEqVal.append("'").append(v).append("',");
                }
            }

        }
        sql += colEqVal.substring(0, colEqVal.length() - 1) + " where " + fixSql;

        return sql;
    }

    /**
     * 驼峰算法
     */
    public String propertyToField(Object prop) {
        if (null == prop) {
            return "";
        }
        String property = prop.toString();
        char[] chars = property.toCharArray();
        StringBuilder sb = new StringBuilder();
        for (char c : chars) {
            if (CharUtils.isAsciiAlphaUpper(c)) {
                sb.append("_").append(StringUtils.lowerCase(CharUtils.toString(c)));
            } else {
                sb.append(c);
            }
        }
        return sb.toString();
    }

    /**
     * 根据属性名获取属性值
     */
    protected Object getFieldValueByName(String fieldName, Object o) {
        try {
            String firstLetter = fieldName.substring(0, 1).toUpperCase();
            String getter = "get" + firstLetter + fieldName.substring(1);
            Method method = o.getClass().getMethod(getter, new Class[]{});
            return method.invoke(o, new Object[]{});
        } catch (Exception e) {
            // log.error(e.getMessage(), e);
            return null;
        }
    }

    /**
     * 类名(obj_name)获取属性类型(f_type)，属性名(f_name)，属性值(f_value)的map组成的list
     */
    @SuppressWarnings("unused")
    protected List<Map<String, Object>> getFiledsInfo(Object o) {

        String obj_name = o.getClass().getSimpleName();
        Field[] fields = o.getClass().getDeclaredFields();
        String[] fieldNames = new String[fields.length];
        List<Map<String, Object>> list = new ArrayList<>();
        Map<String, Object> infoMap;
        for (Field field : fields) {
            infoMap = new HashMap<>();
            infoMap.put("obj_name", obj_name);
            infoMap.put("f_type", field.getType().toString());
            infoMap.put("f_name", field.getName());
            infoMap.put("f_value", getFieldValueByName(field.getName(), o));
            list.add(infoMap);
        }
        return list;
    }
}

