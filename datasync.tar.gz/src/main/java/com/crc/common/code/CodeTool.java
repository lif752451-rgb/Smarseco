package com.crc.common.code;

import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.jasypt.encryption.pbe.StandardPBEStringEncryptor;
import org.jasypt.encryption.pbe.config.EnvironmentPBEConfig;

@Slf4j
public class CodeTool {

    public synchronized  static String decrypt(String password, String publicKey) {
        if (StringUtils.isNotBlank(publicKey) && StringUtils.isNotBlank(password)) {
            try {
                StandardPBEStringEncryptor standardPBEStringEncryptor = new StandardPBEStringEncryptor();
                EnvironmentPBEConfig config = new EnvironmentPBEConfig();

                // 加密的算法，这个算法是默认的
                config.setAlgorithm("PBEWithMD5AndDES");
                // 加密的密钥，随便自己填写，很重要千万不要告诉别人
                config.setPassword(publicKey);
                standardPBEStringEncryptor.setConfig(config);
                return standardPBEStringEncryptor.decrypt(password);
            } catch (Exception e) {
                log.error(e.getMessage(), e);
            }
        }
        return password;
    }

    public static String encrypt(String password, String publicKey) {
        try {
            if (StringUtils.isNotBlank(publicKey) && StringUtils.isNotBlank(password)) {
                StandardPBEStringEncryptor standardPBEStringEncryptor = new StandardPBEStringEncryptor();
                EnvironmentPBEConfig config = new EnvironmentPBEConfig();

                // 加密的算法，这个算法是默认的
                config.setAlgorithm("PBEWithMD5AndDES");
                // 加密的密钥，随便自己填写，很重要千万不要告诉别人
                config.setPassword(publicKey);
                standardPBEStringEncryptor.setConfig(config);
                return standardPBEStringEncryptor.encrypt(password);
            }
        } catch (Exception e) {
            log.error(e.getMessage(), e);
        }
        return password;
    }

    public static String encrypt(String pass) {
        String publicKey = "IpTFX6FjYs5zKDG8gjKFh7kTgCFdWWJE";
        return CodeTool.encrypt(pass, publicKey);
    }

    public static String decrypt(String pass) {
        String publicKey = "IpTFX6FjYs5zKDG8gjKFh7kTgCFdWWJE";
        if (StringUtils.isBlank(pass)) {
            return pass;
        }

        if (pass.startsWith("ENC")) {
            pass = pass.replace("ENC(", "").replace(")", "");
            pass = CodeTool.decrypt(pass, publicKey);
        }else {
            pass = CodeTool.decrypt(pass, publicKey);
        }
        return pass;
    }


    public static void main(String[] args) {
        String publicKey = "IpTFX6FjYs5zKDG8gjKFh7kTgCFdWWJE";
        //String encryptedText = encrypt("root", publicKey);
        String decryptText = decrypt("6a9SQtGNEopM+Eg9PYuMGBr1Kk2xj/8andeGiZP2fQwBbV9kiS/Q6Q==", publicKey);
        System.out.println(decryptText);
        System.out.println(decrypt("IuB0hKxuVa/OcQLf9Gwmc9ZOzMdtDcxdij6NVO1iGyWDhQRSgGnuAQ==",publicKey));
        System.out.println(decrypt("MznOlaUt87c8aBjBGeDGjxhbyVdZqeHytCNMZrtS2ZEkMYFXKNYtZZXkB2Bux/5n",publicKey));
        System.out.println(CodeTool.encrypt("UIjdc++cdc%$#D", publicKey));
    }
}
