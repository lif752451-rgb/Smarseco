package com.crc.common.code;

import cn.hutool.core.codec.Base64;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;

import java.nio.charset.StandardCharsets;

@Slf4j
public class SimpleCodeTool {
    private final static String SPIT_KEY = "#####";

    public static String encrypt(String enc) {
        try {
            if (StringUtils.isBlank(enc)) {
                return enc;
            }
            enc = enc + SPIT_KEY + enc;
            return Base64.encode(enc.getBytes(StandardCharsets.UTF_8));
        } catch (Exception e) {
            //log.error(e.getMessage(), e);
        }
        return enc;
    }

    public static String decrypt(String dec) {
        try {
            if (StringUtils.isBlank(dec)) {
                return dec;
            }
            byte[] bytes = Base64.decode(dec.getBytes(StandardCharsets.UTF_8));
            String des = new String(bytes, StandardCharsets.UTF_8);
            return des.split(SPIT_KEY)[0];
        } catch (Exception e) {
            //log.error(e.getMessage(), e);
        }
        return dec;
    }

    public static String encryptBase64(String enc) {
        try {
            if (StringUtils.isBlank(enc)) {
                return enc;
            }
            return Base64.encode(enc.getBytes(StandardCharsets.UTF_8));
        } catch (Exception e) {
            //log.error(e.getMessage(), e);
        }
        return enc;
    }

    public static String decryptBase64(String dec) {
        try {
            if (StringUtils.isBlank(dec)) {
                return dec;
            }
            byte[] bytes = Base64.decode(dec.getBytes(StandardCharsets.UTF_8));
            return new String(bytes, StandardCharsets.UTF_8);
        } catch (Exception e) {
            //log.error(e.getMessage(), e);
        }
        return dec;
    }

    public static void main(String[] args) {
        String s = "112";
        String enc = encryptBase64(s);
        System.out.println(enc);
        String s1 = "TWV0cm9AMTIzIyQlIyMjIyNNZXRyb0AxMjMjJCU=";
        String dec = decrypt(s1);
        System.out.println(dec);
    }
}
