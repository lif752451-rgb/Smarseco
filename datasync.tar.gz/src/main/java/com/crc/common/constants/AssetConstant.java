package com.crc.common.constants;

import java.util.HashMap;
import java.util.Map;

/**
 * @author SONGYIPO
 * @since 2021-09-16
 */
public class AssetConstant {

    /**
     * 清空归属意见
     */
    public static final String OPINION_FIELDS = "opinion";

    /**
     * 关联应用系统字段
     */
    public static final String APP_SYSTEM_FIELDS = "appSystem";

    /**
     * 是否漏洞字段
     */
    public static final String IS_EXIST_VUL_LABEL_FIELDS = "isExistVulLabel";

    /**
     * 内网IP
     */
    public static final String INTERNAL_IP_FIELDS = "internalIp";

    /**
     * 资产删除状态-删除
     */
    public static String ASSET_DEL_FLAG_DELETE = "1";
    /**
     * 资产变更申请状态-待审批
     */
    public static String ASSET_MODIFY_STATE_WAIT_FOR_APPROVAL = "0";
    /**
     * 资产变更申请状态-审批通过
     */
    public static String ASSET_MODIFY_STATE_APPROVAL_PASS = "1";
    /**
     * 资产变更申请状态-审批不通过
     */
    public static String ASSET_MODIFY_STATE_APPROVAL_FAIL = "2";
    /**
     * 审配结果-通过
     */
    public static String ASSET_MODIFY_APPROVAL_RESULT_PASS = "pass";
    /**
     * 待审批状态
     */
    public static String ASSET_MODIFY_DEAL_STATE_WAIT_FOR_HANDLE = "0";
    /**
     * 已完成状态
     */
    public static String ASSET_MODIFY_DEAL_CLOSED = "1";
    /**
     * 待审批状态
     */
    public static String RISK_DELAY_DEAL_FOR_HANDLE = "待审批";
    /**
     * 已完成状态
     */
    public static String RISK_DELAY_DEAL_CLOSED = "已审批";
    /**
     * 管理员角色
     */
    public static String ROLE_ADMIN = "admin";
    /**
     * 资产变更管理员角色
     */
    public static String ROLE_ASSET_MODIFY_MANAGER = "assetModifyManager";
    /**
     * 资产变更管理员角色
     */
    public static String ROLE_ASSET_MANAGER = "assetManger";

    /**
     * 网络区域私有云
     */
    public static String AREA_SIYOUYUN = "私有云";

    /**
     * 网络区域华润云
     */
    public static String AREA_HUARUNYUN = "华润云";

    /**
     * 组件信息
     */
    public static String SOFTWARE_INFO = "组件信息";

    /**
     * 是否为单个资产
     */
    public static String IS_SINGLE = "isSingle";

    /**
     * 待审批默认MAP
     */
    public static Map<String, Object> ASSET_MODIFY_DEAL_STATE_FOR_HANDLE_MAP = new HashMap<String, Object>() {
        {
            put("dealState", "0");
            put("count", 0);
            put("name", "待审批");
        }
    };
    /**
     * 已审批默认MAP
     */
    public static Map<String, Object> ASSET_MODIFY_DEAL_STATE_CLOSED_MAP = new HashMap<String, Object>() {
        {
            put("dealState", "1");
            put("count", 0);
            put("name", "已审批");
        }
    };
    /**
     * 资产对照MAP
     */
    public static Map<String, String> ASSET_MODIFY_FIELD_MAP = new HashMap<String, String>() {
        {
            put("internalIp", "内网IP");
            put("operatingStatus", "资产状态");
            put("companyName", "所属一级单位");
            put("subCompanyName", "所属二级单位");
            put("officeName", "所属部门");
            put("assetUser", "所属责任人");
            put("assetPhone", "所属责任人联系方式");
            put("assetMail", "所属责任人邮箱");
            put("operatingDeptName", "运维部门");
            put("operatingUser", "运维责任人");
            put("operatingPhone", "运维责任人联系方式");
            put("operatingEmail", "运维责任人邮箱");
            put("softVersion", "软件版本");
            put("expirtTime", "维保到期时间");
            put("affiliationDeptName", "所属单位");
        }
    };

    /**
     * 等保定级校验相关字段
     */
    public static class EQUAL_PROTECTION_LEVEL_CHECK_LABEL {
        public static final String CODE_LABEL = "等级备案编号";
        public static final String TEST_CONTENT_LABEL = "等保测评情况";
        public static final String RESULT_LABEL = "等保结论";
        public static final String FIRST_TIME_LABEL = "最近一次等级测评时间";
    }

    /**
     * 等保定级校验相关错误信息
     */
    public static class EQUAL_PROTECTION_LEVEL_CHECK_MSG {
        public static final String AFTER_EQUAL_PROTECTION_LEVEL = "等保定级后";
        public static final String NOT_NULL = "不能为空";
    }

    /**
     * 资产清理权限按钮
     */
    public static class ASSET_CLAIM_BUTTONS {
        public static final String ASSET_MARKER = "标记待清理资产";
    }

    /**
     * 集团资产管理人角色
     */
    public static String ROLE_GROUP_INTERNET_ASSET_MANAGER = "groupAssetManager";

    /**
     * 单位资产管理人角色
     */
    public static String ROLE_UNIT_INTERNET_ASSET_SUBMITTER = "unitAssetSubmitter";

    /**
     * 数据来源字典值
     */
    public static String DICT_DATA_SOURCE = "internet_asset_data_source";

    /**
     * 资产认领消息
     */
    public static final class ASSET_CLAIM_MSG {
        public static final String ASSET_CLAIM_PART = "认领成功%d条资产；%d条资产认领失败，已被其他组织认领";
        public static final String ASSET_CLAIM_FAIL = "资产认领失败，已被其他组织认领";
        public static final Integer ASSET_CLAIM_MSG_CODE = 201;
    }

    /**
     * 资产相关菜单按钮
     */
    public static final class ASSET_MENU_BTN {
        // 资产新增
        public static final String ADD = "add";
        // 资产变更
        public static final String UPDATE = "update";
        // 资产认领
        public static final String CLAIM = "claim";
    }

    /** 无所属组织 */
    public static final String DEPT_VALUE_IS_NULL = "无归属组织";

    /** 无所属组织 */
    public static final String DEPT_VALUE_IS_NULL_PARAM = "无归属组织/1";

    // sql limit 1
    public static String LIMIT_ONE = "limit 1";

    // sql limit 500
    public static String LIMIT_500 = "limit 500";
}