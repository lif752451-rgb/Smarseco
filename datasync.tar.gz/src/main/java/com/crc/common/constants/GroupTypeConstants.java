package com.crc.common.constants;


import org.apache.commons.lang3.StringUtils;

/**
 * @Class: com.crc.ssp.project.big.screen
 * @Desc：
 * @Author: cymiao
 * @Date: 2021/4/19 16:26
 */
public class GroupTypeConstants {

    public static String getOffice(String str) {
        if (str != null) {
            str = str.replace(" ", "");
        }
        if (StringUtils.isNotBlank(str)) {
            if (str.contains("万家") || str.contains("苏果")) {
                return "华润万家";
            } else if (str.contains("守正")) {
                return "华润守正";
            } else if (str.contains("集团总部") || str.contains("系统开发中心") || str.contains("华润学习与创新中心") || str.contains("华润大学") || str.contains("档案管") || str.contains("档案中心")) {
                return "集团总部";
            } else if (str.contains("水泥") || str.contains("封开工控")) {
                return "华润水泥";
            } else if (str.contains("燃气") || str.contains("润智")) {
                return "华润燃气";
            } else if (str.contains("电子") || str.contains("华润上华") || str.contains("华润安盛科技")) {
                return "华润微电子";
            } else if (str.contains("电力") || str.contains("电场") || str.contains("电站") || str.contains("煤") || str.contains("电厂")) {
                return "华润电力";
            } else if (str.contains("置地") || str.contains("万象")) {
                return "华润置地";
            } else if (str.contains("五丰")) {
                return "华润五丰";
            } else if (str.contains("三九") || str.contains("九新药业")) {
                return "华润三九";
            } else if (str.contains("雪花")) {
                return "华润雪花";
            } else if (str.contains("怡宝") || str.contains("饮料")) {
                return "华润怡宝";
            } else if (str.contains("双鹤") || str.contains("湘中制药")) {
                return "华润双鹤";
            } else if (str.contains("江中") || str.contains("济生制药")) {
                return "华润江中";
            } else if (str.contains("健康") || str.contains("维麟")) {
                return "华润健康";
            } else if (str.contains("医疗")) {
                return "华润健康";
            } else if (str.contains("生命")) {
                return "华润生命科学";
            } else if (str.contains("物业")) {
                return "华润物业";
            } else if (str.contains("金融")) {
                return "华润金融";
            } else if (str.contains("保险")) {
                return "华润保险";
            } else if (str.contains("银行")) {
                return "华润银行";
            } else if (str.contains("租赁")) {
                return "华润租赁";
            } else if (str.contains("信托")) {
                return "华润信托";
            } else if (str.contains("华润资产")) {
                return "华润资产";
            } else if (str.contains("资本")) {
                return "华润资本";
            } else if (str.contains("材料") || str.contains("化工")) {
                return "华润化学材料";
            } else if (str.contains("环保") || str.contains("纺织") || str.contains("润薇") || str.contains("圣马可")) {
                return "华润环保";
            } else if (str.contains("网络") || str.contains("华润通") || str.contains("润信")) {
                return "华润网络";
            } else if (str.contains("华润云") || str.contains("润联") || str.contains("耕云") || str.contains("新职场") || str.contains("西安办公网") || str.contains("润工作")) {
                return "华润数科";
            } else if (str.contains("医药商业") || str.contains("医商")) {
                return "华润医商";
            } else if (str.contains("医药") || str.contains("紫竹") || str.contains("东阿")) {
                return "华润医药";
            } else if (str.contains("华润云") || str.contains("IT产品服务") || str.contains("IT运营服务") || str.contains("技术服务部") || str.contains("智慧技术部") || str.contains("科技创新部") || str.contains("管理与发展部") || str.contains("智慧空间组") || str.contains("X-LABS")) {
                return "华润数科";
            } else if (str.contains("华创") || str.contains("创业")) {
                return "华润创业";
            }
        }

        return "";
    }

    public static String getOfficeX(String str) {
        if (str != null) {
            str = str.replace(" ", "");
        }
        if (StringUtils.isNotBlank(str)) {
            if (str.contains("万家") || str.contains("苏果") || str.contains("邓韩贝")) {
                return "华润万家";
            } else if (str.contains("守正")) {
                return "华润守正";
            } else if (str.contains("水泥") || str.contains("封开工控")) {
                return "华润水泥";
            } else if (str.contains("燃气") || str.contains("润智")) {
                return "华润燃气";
            } else if (str.contains("微电子") || str.contains("华润上华") || str.contains("华润安盛科技")) {
                return "华润微电子";
            } else if (str.contains("电力") || str.contains("电场") || str.contains("电站") || str.contains("煤") || str.contains("电厂")) {
                return "华润电力";
            } else if (str.contains("置地") || str.contains("万象")) {
                return "华润置地";
            } else if (str.contains("五丰")) {
                return "华润五丰";
            } else if (str.contains("三九") || str.contains("九新药业")) {
                return "华润三九";
            } else if (str.contains("雪花")) {
                return "华润雪花";
            } else if (str.contains("怡宝") || str.contains("饮料")) {
                return "华润怡宝";
            } else if (str.contains("双鹤") || str.contains("湘中制药")) {
                return "华润双鹤";
            } else if (str.contains("江中") || str.contains("济生制药")) {
                return "华润江中";
            } else if (str.contains("健康") || str.contains("维麟")) {
                return "华润健康";
            } else if (str.contains("医疗")) {
                return "华润健康";
            } else if (str.contains("生命")) {
                return "华润生命科学";
            } else if (str.contains("物业")) {
                return "华润物业";
            } else if (str.contains("金融")) {
                return "华润金融";
            } else if (str.contains("保险")) {
                return "华润保险";
            } else if (str.contains("银行")) {
                return "华润银行";
            } else if (str.contains("租赁")) {
                return "华润租赁";
            } else if (str.contains("信托")) {
                return "华润信托";
            } else if (str.contains("华润资产")) {
                return "华润资产";
            } else if (str.contains("资本")) {
                return "华润资本";
            } else if (str.contains("材料") || str.contains("化工")) {
                return "华润化学材料";
            } else if (str.contains("环保") || str.contains("纺织") || str.contains("润薇") || str.contains("圣马可")) {
                return "华润环保";
            } else if (str.contains("网络") || str.contains("华润通") || str.contains("润信")) {
                return "华润网络";
            } else if (str.contains("医药商业") || str.contains("医商")) {
                return "华润医商";
            } else if (str.contains("医药") || str.contains("紫竹") || str.contains("东阿")) {
                return "华润医药";
            } else if (str.contains("华创") || str.contains("创业")) {
                return "华润创业";
            }
        }

        return "";
    }
}
