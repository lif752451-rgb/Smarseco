package com.crc.common.constants;

public class QingtengConstants {
    public static final String APP = "app";//APP
    public static final String WEB_APP = "webapp";//webapp
    public static final String WEB_SITE = "website";//webapp
    public static final String WEB_FRAME = "webframe";//webframe
    public static final String DB = "db";//db

    public static final String PROCESS = "process";//process
    public static final String PKG = "pkg";//pkg
    public static final String JAR = "jar";//jar
}
