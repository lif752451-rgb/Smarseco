package com.crc.common.constants;

public class BanbooAuthConstants {
    public static final String DEPT_PARENT_ID = "deptParentId";
    public static final String DEPT_NAME = "deptName";
    public static final String USER_Id = "userId";
    public static  final String USER_NAME = "userName";
    public static final String DEPT_ID = "deptId";
    public static final String USER_MAIL = "userMail";
    public static final String USER_PHONE = "userMobile";
    public static final String USER_CN_NAME = "displayName";
}
