package com.crc.common.constants;

public class VulConstants {
    public static String QING_TENG = "1";
    public static String HUA_SHUN_XIN_AN = "2";
    public static String LV_MENG = "3";
    public static String GOBY = "4";
    public static String CHANG_TING = "5";
    public static String AN_HENG = "6";
}
