package com.crc.common.constants;


/**
 * @Author shufengfeng
 * @Description TODO
 * @DateTime 2021/9/17 15:01
 */
public class RedisKeys {

    /**
     * 软件许可reidsKey
     */
    public static final String ASSET_SOFTWARE_LICENSE = "soft:license:%s";
    /**
     * 软件许可剩余可用量
     */
    public static final String ASSET_SOFTWARE_LICENSE_SURPLUS = "soft:license:%s";

    /**
     * 资产软件许可证-授权用户
     */
    public static final String LICENSE_AUTH_USER = "license:auth:user:%s";


    /**
     * 签名
     */
    public static final String LICENSE_AUTH_USER_SIGN = "license:auth:user:sign:%s";


    /**
     * 资产reidsKey
     */
    public static final String ASSET = "asset:%s";

    /**
     * 重点关注问题reidsKey
     */
    public static final String EVENT_ATTENTION = "event:attention:%s";

    /**
     * 研判知识库reidsKey
     */
    public static final String KNOWLEDGE_JUDGE = "knowledge:judge:%s";

    /**
     * IOC情报库reidsKey
     */
    public static final String INTELLGENCE_IOC = "intellgence:ioc:%s";

    /**
     * 知识库：告警处置建议reidsKey
     */
    public static final String KNOWLEDGE_ALARM_HANDLE = "knowledge:alarm:handle:%s";

    /**
     * 风险id
     */
    public static final String RISK_AUTO_ID = "risk:auto:id:%s";

    /**
     * 从漏扫原始数据中定时推送风险自动发现redis key
     */
    public static final String PUSH_RISK_AUTO = "push:risk:auto";

    /**
     * 告警模型 redis key
     */
    public static final String EVENT_MODEL_KEY = "event:model:%s";

    /**
     * 定制解析 redis key
     */
    public static final String EVENT_CUSTOM_RULE_KEY = "event:custom:rule:%s";

    /**
     * 从漏扫重新打开数据中定时推送风险自动发现redis key
     */
    public static final String PUSH_REOPEN_ORIGINAL_RISK_AUTO = "push:reopen:original:risk:auto";

    /**
     * 占位符
     */
    public static final String PLACEHOLDER = ":%s";


    /**
     * 登录用户
     */
    public static final String LOGIN_TYPE_USER = "login:%s:%s";

    /**
     * 拉黑token
     */
    public static final String BLANK_TOKEN = "blank:token:%s";

    /**
     * 风险全部下凡异步处理key
     */
    public static final String RISK_PUSH_ALL = "risk:push";

    /**
     * 回退软件许可证数量锁
     */
    public static final String BLACK_LICENSE = "black:license:lock";

    /**
     * 风险提交批量认证锁
     */
    public static final String RISK_BATCH_LOCK = "risk:batch:lock:%s";


    /**
     * 资产新增或者更新后 更新original数据
     */
    public static final String ASSET_UPDATE_ORIGINAL = "asset:update:original";

    /**
     * 变更的资产数据
     */
    public static final String ASSET_UPDATE_ALARM_REPORT = "asset:update:report";

    /**
     * 资产归属错误同步修改 漏洞、告警资产信息
     */
    public static final String ASSET_BELONG_WRONG_UPDATE = "asset:belong:wrong:update";

    /**
     * 半小时(单位秒)
     */
    public static final Long HALF_AN_HOUR = 1800L;

    /**
     * 1分钟(单位秒)
     */
    public static final Long ONE_MINUTE = 60L;

    /**
     * 30秒
     */
    public static final Long THIRTY = 30L;

    /**
     * 20秒(单位秒)
     */
    public static final Long TWENTY = 20L;

    /**
     * 10秒(单位秒)
     */
    public static final Long TEN = 10L;

    /**
     * 一天(单位秒)
     */
    public static final Long ONE_DAY = 86400L;

    public static final String CRC_CLOUD_HOST_PORT_TOP5 = "crc:cloud:host:post:top5";

    /**
     * 创建风险自增id锁
     */
    public static final String CREATE_RISK_CODE_LOCK = "create:risk:code:lock";

    /**
     * 创建生成风险自动自增id锁
     */
    public static final String CREATE_RISK_AUTO_ID_LOCK = "create:risk:auto:id:lock";


    /**
     * 创建生成告警自增id锁
     */
    public static final String CREATE_ALARM_ID_LOCK = "create:alarm:id:lock";

    /**
     * 创建生成告警策略自增id锁
     */
    public static final String CREATE_SEND_ID_LOCK = "create:send:id:lock";

    /**
     * 创建生成SSP告警白名单ID锁
     */
    public static final String CREATE_ALARM_WHITE_LIST_ID_LOCK = "create:alarm:whiteList:id:lock";

    /**
     * 创建生产漏洞转风险自增id锁
     */
    public static final String CREATE_VULN_TO_RISK_ID_LOCK = "create:vuln:to:risk:id:lock";

    /**
     * 创建生成SCP重点关注问题ID锁
     */
    public static final String CREATE_EVENT_ATTENTION_LIST_ID_LOCK = "create:alarm:eventAttention:id:lock";


    /**
     * 创建生成STP漏洞情报收集ID锁
     */
    public static final String CREATE_VULN_INFORMATION_ID_LOCK = "create:vuln:information:id:lock";
}

