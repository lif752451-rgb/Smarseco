package com.crc.common.constants;


/**
 * 通用常量信息
 *
 * @author wst
 */
public class Constants
{
    public static final String LIMIT_ONE = " limit 1";
    /**
     * UTF-8 字符集
     */
    public static final String UTF8 = "UTF-8";

    /**
     * 通用成功标识
     */
    public static final String SUCCESS = "0";

    /**
     * 通用失败标识
     */
    public static final String FAIL = "1";

    /**
     * 登录成功
     */
    public static final String LOGIN_SUCCESS = "Success";

    /**
     * 注销
     */
    public static final String LOGOUT = "Logout";

    /**
     * 登录失败
     */
    public static final String LOGIN_FAIL = "Error";

    /**
     * 登录异常
     */
    public static final String LOGIN_ERROR = "登录异常";

    /**
     * 验证码 redis key
     */
    public static final String CAPTCHA_CODE_KEY = "captcha_codes:";

    public static final String VERIFY_IMAGE_KEY = "verify_image:";

    /**
     * 登录用户 redis key
     */
    public static final String LOGIN_TOKEN_KEY = "login_tokens:";

    /**
     * 验证码有效期（分钟）
     */
    public static final Integer CAPTCHA_EXPIRATION = 10;

    /**
     * 令牌
     */
    public static final String TOKEN = "token";

    /**
     * 令牌前缀
     */
    public static final String TOKEN_PREFIX = "Bearer ";

    /**
     * 令牌前缀
     */
    public static final String LOGIN_USER_KEY = "login_user_key";

    /**
     * 用户ID
     */
    public static final String JWT_USERID = "userid";

    /**
     * 用户头像
     */
    public static final String JWT_AVATAR = "avatar";

    /**
     * 创建时间
     */
    public static final String JWT_CREATED = "created";

    /**
     * 用户权限
     */
    public static final String JWT_AUTHORITIES = "authorities";

    /**
     * 资源映射路径 前缀
     */
    public static final String RESOURCE_PREFIX = "/profile";

    /**
     * 系统自动生成用户
     */
    public static final String SYSTEM_USER ="system";

    public static final String TAB_LIST_TAG ="rows";

    public static final String DATA_LIST_TAG ="data";

    public static final String TOTAL_TAG ="total";

    public static final String LOG_TIME_TAG ="SparkTime";

    public static final String SRC_IP_TAG ="src_ip";

    public static final String DEST_IP_TAG ="dest_ip";

    public static final String SUPER ="super";

    public static final String AES ="AES";
    public static final String AES_ALGORITHM ="AES/CBC/PKCS5Padding";

    public static final String BLANK_STR ="";


    public static final String DEFAULT_EXPORT_FILR_NAME = "闭环管理风险单列表.xlsx";

    public static final int EXCEL_CELL_MAX_LENGTH = 13;

    public static final String MSG_CREATE_ALARM_SUCCESS = "创建安全告警单成功";

    public static final String DEFAULT_EXPORT_FILR_VULN_NAME = "闭环管理漏洞列表.xlsx";

    /**
     * 资产证书导出文件默认名称
     */
    public static final String DEFAULT_EXPORT_ASSET_DIGITAL_CERTIFICATE_FILE_NAME = "证书列表";
    /**
     * 资产待认领导出文件默认名称
     */
    public static final String DEFAULT_EXPORT_ASSET_TO_BE_CLAIMED_FILE_NAME= "待认领资产列表";
    /**
     * 资产已认领导出文件默认名称
     */
    public static final String DEFAULT_EXPORT_ASSET_ALREADY_CLAIMED_FILE_NAME= "已认领资产列表";
    /**
     * 终端软件导出文件默认名称
     */
    public static final String DEFAULT_EXPORT_ASSET_TERMINAL_SOFTWARE_REPORT_FILE_NAME= "终端软件列表";
    public static final String SYS_WHETHER_NO = "0";
    public static final String NO = "否";
    public static final String SYS_WHETHER_YES = "1";
    public static final String YES = "是";

    /**
     * 已完成
     */
    public static final String FINISHED  = "已完成";

    /**
     * 未完成
     */
    public static final String UNFINISHED  = "未完成";
    /**
     * 符号
     */
    public static final class Symbol {
        public static final String COMMA = ",";
        public static final String NULL_STR = "";
        public static final String ZH_COMMA = "，";
        public static final String LEFT_PARENTHESES = "(";
        public static final String RIGHT_PARENTHESES = ")";
        public static final String ZH_LEFT_PARENTHESES = "（";
        public static final String ZH_RIGHT_PARENTHESES = "）";
        public static final String BLANK = " ";
        public static final String ZH_COLON = "：";
        public static final String MINUS = "-";
        public static final String SLASH = "/";
        public static final String UNDERLINE = "_";
        public static final String ZH_LEFT_BRACKET = "【";
        public static final String EN_LEFT_BRACKET = "[";
        public static final String ZH_RIGHT_BRACKET = "】";
        public static final String EN_RIGHT_BRACKET = "]";
        public static final String SPACE = "&nbsp;";
        public static final String PLACEHOLDER = "PLACEHOLDER";
        public static final String BR = "</br>";
        public static final String NUMBER = "\\d+";
        public static final String ARROW = "->";
        public static final String AND = "&";
        public static final String STR_EMPTY = "";
        public static final String ZH_CAESURA_SIGN = "、";
        public static final String COLON = ":";
        public static final String LINE_FEED = "\n";
        public static final String PLUS = "+";
        public static final String PERCENT = "%";
        public static final String DOT = ".";
        public static final String LESS_THAN = "<";
        public static final String GREATER_THAN = ">";
        public static final String ENTITY_LESS_THAN = "&lt;";
        public static final String ENTITY_GREATER_THAN = "&gt;";
        public static final String TAB = "\t";
        public static final String DOUBLE_SLASH = "//";
        public static final String ZH_QUESTION = "?";
        public static final String EQUAL = "=";
    }

    /**
     * 邮件发送状态
     */
    public static final class Mail {
        public static final String OK = "ok";
        public static final String FAIL = "fail";
        public static final String FROM_IS_NULL = "邮件发件人不能为空";
        public static final String TO_IS_NULL = "邮件收信人不能为空";
        public static final String SUBJECT_IS_NULL = "邮件主题不能为空";
        public static final String TEXT_IS_NULL = "邮件内容不能为空";
    }

    /**
     * 告警角色
     */
    public static final class AlarmRoles {
        //安全处理人
        public static final String SECURE_PROCESSOR_CODE = "anquanchuliren";
    }

    /**
     * 资产类型字典
     */
    public static final class AssetTypeDict{
        public static final String SAFETY_EQUIPMENT = "安全设备";
    }

    /**
     * 告警复核 0 否 1 是
     */
    public static final class AlarmCheck{
        public static final String YES = "1";
        public static final String NO = "0";
    }

    /**
     * 邮件发送开关 1打开 0关闭
     */
    public static final String SEND_SWITCH_OPEN = "1";

    //默认步长
    public static final Long DEFAULT_INCR = 1L;

    /**
     * 邮件发送状态
     */
    public static final class RiskApproveState {
        //工单状态
        public static final String WORK_ORDER_STATE = "workOrderState";
        //数量
        public static final String QUANTITY = "quantity";
        //处置方式
        public static final String RECTIFICATION_TYPE = "rectificationType";
    }

    /**
     * 意见最大长度
     */
    public static Integer OPINION_MAX_LENGTH = 200;

    public static final String STR_VALUE_ZERO = "0";

    public static final String STR_VALUE_ONE = "1";

    public static final String STR_VALUE_TWO = "2";

    /**
     * 使用redis自增业务标识
     */
    public static final class RedisIncrementKeys{
        public static final String EVENT_VULN_INFORMATION_ID = "redis:increment:vuln:information:id";
        public static String ALARM_ID = "redis:increment:alarm:id";
        public static final String RISK_CODE = "redis:increment:risk:code";
        public static final String RISK_AUTO_ID = "redis:increment:risk:auto:id";
    }

    /**
     * 系统名称
     */
    public static final class SystemName{
        public static final String SSP = "SSP";
        public static final String STP = "STP";
    }

    public static final String REDIS_BUSINESS_KEY_NX_VAL = "redis:business:key";

    /**
     * 告警表头筛选-告警来源数据源redisKey
     */
    public static final String ALARM_SOURCE_FILTER_DICT_REDIS_KEY = "alarm_source_filter_redis_key";


    public static final String UN_KNOW = "未知";

    public static final String HTTP = "http://";
    public static final String HTTPS = "https://";
    public static final String FTP = "ftp://";


    /**
     * 导出模板
     */
    public static final class Template{
        //模板地址前缀
        public static final String PREFIX = "/template/";
    }

    /**
     * 默认查询每页行数
     */
    public static final Integer EXPORT_DEFAULT_PAGE_SIZE = 1000;

    /**
     * 开始查询页码
     */
    public static final Integer START_PAGE_NUM = 1;

    /**
     * 列表查询默认每页行数
     */
    public static final Integer PAGE_SIZE = 20;

    /**
     * excel导出内容类型
     */
    public static final String CONTENT_TYPE = "application/vnd.ms-excel";

    /**
     * excel导出内容意向
     */
    public static final String CONTENT_DISPOSITION = "Content-disposition";

    /**
     * 附件
     */
    public static final String ATTACHMENT = "attachment;filename=";



    /**
     * 成功
     */
    public static final String SUCC = "success";

    /**
     * 成功
     */
    public static final String ERR = "error";

    /**
     * 导入最大行数
     */
    public static final Integer IMPORT_MAX_LINE = 2000;

    /**
     * 百分比格式
     */
    public static final String PERCENTAGE_FORMAT = "#.##%";

    /**
     * 一级部门父节点id
     */
    public static final Long FIRST_PARENT_ID = 100L;


    /**
     * 结束时间
     */
    public static final String END_TIME = " 23:59:59";


    /**
     * 数量
     */
    public static final String COUNT = "count";

    /**
     * 订单状态
     */
    public static final String ORDER_STATUS = "orderStatus";

    /**
     * 全部
     */
    public static final String ALL = "全部";

    /**
     * 签名
     */
    public static final String SIGN = "sign";

    /**
     * 时间戳
     */
    public static final String TIMESTAMP = "timestamp";

    /**
     * 已修复
     */
    public static final int FIXED_VULNERABILITY_TYPE = 1;

    /**
     * 待修复
     */
    public static final int VULNERABILITIES_TO_BE_FIXED = 0;

    /**
     * 自动生成id拼接长度
     */
    public static final Integer SPLICING_ID_LENGTH = 6;

    /**
     * 自动发现-默认风险大类
     */
    public static final String BIG_CATEGORY = "漏洞";

    /**
     * 剔除 复查中
     */
    public static final String REVIEW = "（复查中）";
    /**
     * 剔除 待
     */
    public static final String WAIT = "待";

    /**
     * 业务单元
     */
    public static final Long BUSINESS_UNIT_DEPT_ID = 2765L;

    /**
     * 业务单元
     */
    public static final String ORGANIZATION_ID = "organizationId=";

    /**
     * excel单元格最大容量
     */
    public static final Integer EXCEL_CELL_MAXIMUM = 32767;

    /**
     * 机构名称
     */
    public static final class organizationName {
        //润联科技
        public static final String RUN_LINK = "润联科技";
    }

    public static final String PARENT = "parent";
    public static final String CHILDREN = "children";
    /**
     * 格式化 yyyy/MM/dd
     */
    public static final String FORMART = "yyyy/MM/dd";
    /**
     * 简单的正则  yyyy/MM/dd
     */
    public static final String SIMPLE_REGEXP = "^\\d{4}(\\-|\\/|\\.)\\d{1,2}\\1\\d{1,2}$";
    /**
     * ip正则校验
     */
    public static final String IP_REGEXP = "((25[0-5]|2[0-4]\\d|1\\d{2}|[1-9]?\\d)\\.){3}(25[0-5]|2[0-4]\\d|1\\d{2}|[1-9]?\\d)$";

    /**
     * 告警白名单审核状态
     */
    public static final class AlarmWhiteListApproveState {
        //审核状态
        public static final String APPROVE_STATE = "approveState";
        //数量
        public static final String QUANTITY = "quantity";
    }

    public static final String NOT_YET = "暂无";
    public static final String NULL_STR = "null";

    public static final String FILE_NAME = "fileName";
    public static final String SIZE = "size";
    /** 风险自动发现 */
    public static final String RISK_AUTO = "RiskAuto";

    /** 导出支持最大数据量 */
    public static final Long EXPORT_MAXIMUM = 40000L;

    /** 导出数据限制最大数据量提示信息 */
    public static final class EXPORT_MAXIMUM_MSG{
        public static final String EXCEED_FORTY_K_MSG_PART1 = "单次导出支持最多4w条数据，当前超出";
        public static final String EXCEED_FORTY_K_MSG_PART2 = "条，请分多次导出";
        public static final Integer EXCEED_FORTY_K_CODE = 201;
    }

    public static final String ASSET_IMPORT_MSG = "已成功";
    public static final String ASSET_IMPORT_ADD_MSG = "导入%s条新资产";
    public static final String ASSET_IMPORT_UPDATE_MSG = "覆盖%s条原资产";
    /** 分割线 */
    public static final String SPLIT_LINE = "---------";

    /**
     * 查询条数
     */
    public static final String LIMIT = "limit";
    /**
     * 偏移量
     */
    public static final String OFFSET = "offset";
    /**
     * 工作区id
     */
    public static final String PROJECT_ID = "project_id";

    /**
     * 主机信息
     */
    public static final String CONTENT = "content";

    /**
     * 结果集
     */
    public static final String RESULT = "result";

    /**
     * 策略
     */
    public static final String STRATEGY = "strategy";

    /**
     * 是否模糊匹配
     */
    public static final String IS_PARTIAL = "is_partial";

    /**
     * xprocess id
     */
    public static final String XPROCESS_ID = "xprocess_id";

    /**
     * result_type
     */
    public static final String RESULT_TYPE = "result_type";

    /**
     * vuln
     */
    public static final String VULN = "vuln";

    /**
     * 任务实例状态：
     * APPOINT： 等待排期，
     * QUEUING： 等待扫描，
     * WORKING： 正在扫描，
     * FINISHED： 扫描成功，
     * PAUSED： 暂停扫描，
     * PARTIAL_PAUSED： 部分阶段暂停，
     * FAILED： 扫描失败
     */
    public static final String STATUS = "status";

    /**
     * 主机ip
     */
    public static final String ADDRESS = "address";

    public static final String WEBSITE = "WEBSITE";

    public static final String SERVICE = "SERVICE";

    public static class ChangTingApiUrl{
        /**
         * 获取工作区列表
         */
        public static final String WORK_AREA_API_URL = "/api/v2/project/";

        /**
         * 按条件批量获取主机资产
         */
        public static final String HOST_ASSET_API_URL = "/api/v2/ip/filter/";

        /**
         * 获取主机资产详情
         */
        public static final String HOST_ASSET_BY_ID_API_URL = "/api/v2/ip/%s/";

        /**
         * 按条件批量获取Web资产
         */
        public static final String WEB_ASSET_API_URL = "/api/v2/website/filter/";

        /**
         * 获取web资产详情
         */
        public static final String WEB_ASSET_BY_ID_API_URL = "/api/v2/website/%s/";

        /**
         * 按条件批量获取漏洞资产
         */
        public static final String VULN_FILTER_API_URL = "/api/v2/vuln/filter/";
        /**
         * 获取漏洞类型
         */
        public static final String VULN_CATEGORY_API_URL = "/api/v2/vuln_category/";
        /**
         * 获取策略模板列表
         */
        public static final String TEMPLATE_API_URL = "/api/v2/template/";
        /**
         * 创建任务计划
         */
        public static final String PLAN_CREATE_API_URL = "/api/v2/plan/create/";
        /**
         * 获取引擎节点
         */
        public static final String ENGINE_FILTER_API_URL = "/api/v2/engine/filter/";
        /**
         * 按条件获取 XProcess
         */
        public static final String XPROCESS_FILTER_API_URL = "/api/v2/xprocess/filter/";
        /**
         * 获取漏洞扫描结果列表
         */
        public static final String RESULT_FILTER_API_URL = "/api/v2/result/filter/";
    }

    /**
     * 安恒常量类
     */
    public static final class AnHengConstants {
        /**
         * 用户名
         */
        public static final String USERNAME = "userName";

        /**
         * 密码
         */
        public static final String PASSWORD = "password";
        /**
         * Message
         */
        public static final String MESSAGE = "message";

        /**
         * token
         */
        public static final String TOKEN = "token";

        /**
         * 成功
         */
        public static final String SUCCESS = "success";

        /**
         * 类型
         */
        public static final String TYPE = "type";

        /**
         * CONTENT_TYPE
         */
        public static final String CONTENT_TYPE = "Content-Type";

        /**
         * APPLICATION
         */
        public static final String APPLICATION_JSON = "application/json";


        /**
         * API对接
         */
        public static final String OPENAPI = "openApi";

        /**
         * APIKEY
         */
        public static final String APIKEY = "apiKey";

        /**
         * list
         */
        public static final String LIST = "list";

        /**
         * win
         */
        public static final String WIN = "win";

        /**
         * Linux
         */
        public static final String LINUX = "linux";

        /**
         * Other
         */
        public static final String OTHER = "other";

        /**
         * CVE
         */
        public static final String CVE = "cve";

        /**
         * IP
         */
        public static final String IP = "ip";

        /**
         * IDS
         */
        public static final String IDS = "ids";

        /**
         * 未修复
         */
        public static final String UN_REQUIRE = "未修复";

        /**
         * 已修复
         */
        public static final String REQUIRED = "已修复";

        /**
         * 登录安恒 API
         */
        public static final String LOGIN_API_URL = "/service/api/token";

        /**
         * 获取安恒资产列表 API
         */
        public static final String ASSET_API_URL = "/service/api/node/list";

        /**
         * 获取安恒资产详情 API
         */
        public static final String ASSET_DETAIL_API_URL = "/service/api/node/details";

        /**
         * 获取安恒端口信息 API
         */
        public static final String ASSET_PORT_API_URL = "/service/api/node/ports";

        /**
         * 获取安恒软件信息 API
         */
        public static final String ASSET_SOFT_WARE_API_URL = "/service/api/node/software";

        /**
         * 获取安恒win 漏洞列表 API
         */
        public static final String WIN_VUL_LIST_API_URL = "/service/api/vulnerability/win/list";

        /**
         * 获取安恒Linux 或者 other 漏洞列表 API
         */
        public static final String LINUX_VUL_LIST_API_URL = "/service/api/vulnerability/%s/list";

        /**
         * windows某个漏洞关联的资产列表 API
         */
        public static final String WIN_NODES_VUL_LIST_API_URL = "/service/api/vulnerability/win/nodes";

        /**
         * Linux某个漏洞关联的资产列表 API
         */
        public static final String LINUX_NODES_VUL_LIST_API_URL = "/service/api/vulnerability/linux/nodes";

        /**
         * 漏洞管理-Windows按资产批量执行漏洞扫描
         */
        public static final String WIN_SCAN_API_URL = "/service/api/vulnerability/win/scan";

        /**
         * 漏洞管理-Linux按资产批量执行漏洞扫描
         */
        public static final String LINUX_SCAN_API_URL = "/service/api/vulnerability/linux/scan";

        /**
         * 通过nodeId获取对应win资产扫描状态
         */
        public static final String WIN_VUL_MANAGE_API_URL = "/service/api/vul_manage/win/get_node_list";

        /**
         * 通过nodeId获取对应Linux资产扫描状态
         */
        public static final String LINUX_VUL_MANAGE_API_URL = "/service/api/vul_manage/linux/get_node_list";

        /**
         * 根据nodeId刷新win漏洞数据
         */
        public static final String WIN_VUL_API_URL = "/service/api/vulnerability/win/list";

        /**
         * 根据nodeId刷新linux漏洞数据
         */
        public static final String LINUX_VUL_API_URL = "/service/api/vulnerability/linux/list";
    }
}
