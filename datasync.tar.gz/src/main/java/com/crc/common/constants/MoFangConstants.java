package com.crc.common.constants;

/**
 * 魔法对接常量类
 *
 * @Author fuzhuangzhi
 * @Date 2022/9/6 10:14
 * @Version 1.0
 **/
public class MoFangConstants {

    /**
     * 总数量
     */
    public static final String COUNT = "count";

    /**
     * ACCESSKEY
     */
    public static final String ACCESS_KEY = "ACCESSKEY";

    /**
     * SECRET_KEY
     */
    public static final String SECRET_KEY = "SECRETKEY";

    /**
     * 数据结果集
     */
    public static final String INFO = "info";

    /**
     * 魔方对接，api URL
     */
    public static class ApiUrl{

        /**
         * 获取所有ip列表
         */
        public static final String IP_LIST_API_URL = "/api/v1/ip";

        /**
         * 获取所有端口列表
         */
        public static final String PORT_LIST_API_URL = "/api/v1/portserver";

        /**
         * 下发扫描任务
         */
        public static final String TASK_MANAGE_API_URL = "/api/v1/task_manage";

        /**
         * 获取下发任务列表
         */
        public static final String TASK_LIST_API_URL = "/api/v1/task";

        /**
         * 获取所有版本型漏洞列表
         */
        public static final String VUL_LIST_API_URL = "/api/v1/version";
    }
}
