package com.crc.common.constants;

import org.apache.commons.lang3.StringUtils;

public class ChangtingConstants {
    public static String[] EXP_FLAG = "暂无".split(" ");

    public static String[] IMPACT_FLAG = "暂无".split(" ");

    public static String[] POC_FLAG = "暂无".split(" ");


    public static String existImpact(String poc) {
        if (StringUtils.isBlank(poc)) {
            return "0";
        }
        for (String s : IMPACT_FLAG) {
            if (poc.contains(s)) {
                return "1";
            }
        }

        return "0";
    }


    public static String existPoc(String poc) {
        if (StringUtils.isBlank(poc)) {
            return "0";
        }
        for (String s : POC_FLAG) {
            if (poc.contains(s)) {
                return "1";
            }
        }

        return "0";
    }

    public static String existExp(String poc) {
        if (StringUtils.isBlank(poc)) {
            return "0";
        }
        for (String s : EXP_FLAG) {
            if (poc.contains(s)) {
                return "1";
            }
        }

        return "0";
    }
}
