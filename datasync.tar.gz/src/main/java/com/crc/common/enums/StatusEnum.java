package com.crc.common.enums;

import lombok.Data;

/**
 * @Author shufengfeng
 * @Description 状态枚举
 * @DateTime 2021/8/30 16:49
 */
@Data
public class StatusEnum {


    public static StatusEnum AVAILABLE = new StatusEnum(0,"可用");
    public static StatusEnum DISABLE = new StatusEnum(1,"不可用");
    public static StatusEnum WAIT_SEND = new StatusEnum(2,"待下发");

    public static StatusEnum YES = new StatusEnum(1,"是");
    public static StatusEnum NO = new StatusEnum(0,"否");
    /**
     * 待认领
     */
    public static StatusEnum TO_BE_CLAIMED = new StatusEnum(0,"待认领");
    public static StatusEnum CLAIMED = new StatusEnum(1,"已认领");


    /**
     * 更新标记
     */
    public static StatusEnum ADD = new StatusEnum(1,"新增");
    public static StatusEnum UPDATE = new StatusEnum(2,"更新");

    private Integer value;
    private String desc;

    public StatusEnum() {
    }

    public StatusEnum(Integer value, String desc) {
        this.value = value;
        this.desc = desc;
    }

    public Integer getValue() {
        return value;
    }

    public void setValue(Integer value) {
        this.value = value;
    }

    public String getDesc() {
        return desc;
    }

    public void setDesc(String desc) {
        this.desc = desc;
    }

    /**
     * 获取 yes no 的desc
     * 0 否  1 是
     *
     * @param value String
     * @return String
     */
    public static String getYesOrNoDescByValue(String value) {
        return YES.getValue().toString().equals(value) ? YES.getDesc() : NO.getDesc();
    }

    /**
     * 获取 yes no 的value
     * 0 否  1 是
     *
     * @param desc String
     * @return Integer
     */
    public static Integer getYesOrNoValueByDesc(String desc){
        return YES.getDesc().equals(desc) ? YES.getValue() : NO.getValue();
    }

    /**
     * 验证 yes no 的value
     * 0 否  1 是
     *
     * @param desc String
     * @return Boolean 存在 true 不存在 false
     */
    public static Boolean checkYesOrNoByDesc(String desc){
        return YES.getDesc().equals(desc) || NO.getDesc().equals(desc);
    }
}
