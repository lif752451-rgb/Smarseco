package com.crc.common.enums;

import org.apache.commons.lang3.StringUtils;

/**
 * @Author shufengfeng
 * @Description 角色枚举类
 * @DateTime 2021/8/27 17:10
 */
public enum SysRoleEnum {

    /**
     * 安全工程师
     */
    SAFETY_ENGINEER("安全工程师","alarmEngineer"),
    /**
     * 安全接口人
     */
    SECURITY_USER("安全接口人","alarmUnitConnect"),
    /**
     * 安全处理人
     */
    SECURITY_DEAL_USER("安全处理人","alarmUnitHandle"),
    /**
     * 风险管理人
     */
    RISK_MANAGER("风险管理人","riskAdministrator"),
    /**
     * 风险验证人
     */
    RISK_VALIDATE("风险验证人","riskVerifier"),
    /**
     * 超级管理员
     */
    SUPER("超级管理员","super"),
    /**
     * 管理员
     */
    ADMIN("管理员","admin"),
    /**
     * 一级接口人
     */
    FIRST_LEVEL_LIAISON_OFFICER("一级接口人","firstLevelConnect"),
    /**
     * 二级接口人
     */
    SECOND_LEVEL_LIAISON_OFFICER("二级接口人","secondLevelConnect"),
    /**
     *
     * 集团管理员
     */
    GROUP_ADMIN("集团管理员","group_admin"),
    /**
     * 实际处置人
     */
    REAL_HANDLE_PERSON("实际处置人","secondLevelHandle"),
    /**
     * 漏洞白名单审核组
     */
    RISK_LEAK_WHITE_LIST_AUDIT("漏洞白名单审核组","riskLeakWhitelistAudit"),
    /**
     * 风险延期审批人
     */
    RISK_DEFERRED_AUDIT("风险延期审批人","riskDeferredAudit"),

    /**
     * 告警白名单审核组
     */
    ALARM_WHITE_LIST_AUDIT("告警白名单审核组","alarmWhitelistAudit"),

    /**
     * 告警白名单提交人
     */
    ALARM_WHITE_LIST_SUBMIT("告警白名单提交人","alarmWhitelistSubmit"),

    /**
     * 集团资产管理员
     */
    ASSETS_GROUP_ADMIN("集团资产管理员","assetsGroupAdmin"),

    /**
     * 告警集团管理员
     */
    ALARM_GROUP_ADMIN("告警集团管理员","alarmGroupAdmin"),

    /**
     * 告警单位管理员
     */
    ALARM_UNIT_ADMIN("告警单位管理员","alarmUnitAdmin"),

    /**
     * 安全报告接口人
     */
    SEC_REPORT_SET_CONNECT("安全报告接口人","secReportSetConnect"),

    /**
     * 安全报告管理员
     */
    SEC_REPORT_ADMIN("安全报告管理员","secReportAdmin"),

    /**
     * 安全报告查看
     */
    SEC_REPORT_SEE("安全报告查看","secReportSee"),

    /**
     * 告警监控组
     */
    HVV_ALARM_MONITOR("告警监控组","hvvAlarmMonitor"),

    /**
     * 分析研判组
     */
    HVV_ALARM_ANALYSIS_JUDGE("分析研判组","hvvAnalysisJudge"),

    /**
     * 应急处置组
     */
    HVV_ALARM_EMERGE_DISPOSAL("应急处置组","hvvEmergeDisposal"),

    /**
     * 后续跟进组
     */
    HVV_ALARM_FOLLOW_UP("后续跟进组","hvvFollowUp"),

    /**
     * 审核专家组
     */
    HVV_ALARM_AUDIT_EXPERT("审核专家组","hvvAuditExpert"),

    /**
     * 追踪溯源组
     */
    HVV_ALARM_TRACE_SOURCE("追踪溯源组","hvvTraceSource"),

    /**
     * 应用系统责任人
     */
    APP_SYSTEM_DUTY_PRESON("应用系统责任人","systemAssetDuty"),


    /**
     * IP资产责任人
     */
    IP_ASSET_DUTY("IP资产责任人","ipAssetDuty"),


    /**
     * 漏洞处置组
     */
    VULN_HANDLE("漏洞处置组","vulnHandle"),

    /**
     * 漏洞审核组
     */
    VULN_AUDIT("漏洞审核组","vulnAudit"),


    /**
     * 漏洞白名单审核组
     */
    VULN_WHITELIST_AUDIT("漏洞白名单审核组", "vulnWhitelistAudit");


    /**
     * 名称
     */
    private String name;

    /**
     * 描述
     */
    private String key;

    SysRoleEnum(String name, String key){
        this.name = name;
        this.key = key;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getKey() {
        return key;
    }

    public void setKey(String key) {
        this.key = key;
    }


    public static SysRoleEnum findByName(String name){
        if(StringUtils.isEmpty(name)){
            return null;
        }
        SysRoleEnum[] values = SysRoleEnum.values();
        for(SysRoleEnum key : values){
            if(name.equals(key.getName())){
                return key;
            }
        }
        return null;
    }
}
