package com.crc.common.enums;

public enum F5LbTypeEnums {
    VS("VS", "502"),
    POOL("POOL", "504"),
    SID("SID", "507"),
    MEM("MEM", "508"),
    IRULES("irules", "506"),
    DNS("DNS", "511"),
    DATA("DATA", "513"),
    APP("应用", "1211"),
    HOST("主机", "1210"),

    APP_HOST("应用和主机关联信息", "1212"),
    ;

    F5LbTypeEnums(String name, String code) {
        this.name = name;
        this.code = code;
    }

    //自定义列类型名称
    private String name;
    //自定义列类型编码
    private String code;

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getCode() {
        return code;
    }

    public void setCode(String code) {
        this.code = code;
    }
}
