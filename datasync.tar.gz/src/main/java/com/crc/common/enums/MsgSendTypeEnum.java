package com.crc.common.enums;

import lombok.Getter;

/**
 * 消息发送类型枚举
 *
 * @Author fuzhuangzhi
 * @Date 2023/2/10 12:36
 * @Version 1.0
 **/
@Getter
public enum MsgSendTypeEnum {
    FEI_SHU("feishu", "飞书"),
    QYWX("qywx", "企业微信"),
    ;

    private final String type;
    private final String desc;

    MsgSendTypeEnum(String type, String desc) {
        this.type = type;
        this.desc = desc;
    }
}
