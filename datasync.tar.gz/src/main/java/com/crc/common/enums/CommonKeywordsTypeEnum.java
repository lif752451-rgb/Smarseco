package com.crc.common.enums;

import lombok.AllArgsConstructor;
import lombok.Getter;

/**
 * @author fuzhuangzhi
 * @title CommonKeywordsTypeEnum
 * @date 2023/10/9 16:53
 * @description 全文检索枚举
 */
@Getter
@AllArgsConstructor
public enum CommonKeywordsTypeEnum {

    /**
     * 资产
     */
    ASSET("asset","资产"),

    /**
     * 应用系统
     */
    ASSET_APP_SYSTEM("assetAppSystem","应用系统"),

    /**
     * 常态化告警
     */
    ALARM("alarm","常态化告警"),

    /**
     * 实战告警
     */
    ALARM_HVV("alarmHvv","实战告警"),
    ;
    /**
     * 类型
     */
    private String type;

    /**
     * 模块
     */
    private String module;
}
