package com.crc.common.enums;

import cn.hutool.core.util.StrUtil;
import lombok.Getter;

/**
 * 检测结果枚举
 *
 * @Author fuzhuangzhi
 * @Date 2023/1/4 11:48
 * @Version 1.0
 **/
@Getter
public enum CodeCheckResultEnum {
    WAIT("0", "待执行"),
    SUCCESS("1","执行成功"),
    FAIL("2","执行失败"),
    ;
    private final String result;
    private final String desc;

    CodeCheckResultEnum(String result, String desc) {
        this.result = result;
        this.desc = desc;
    }

    public static String getDescByResult(String result) {
        if (StrUtil.isEmpty(result)) {
            return null;
        }
        for (CodeCheckResultEnum resultEnum : CodeCheckResultEnum.values()) {
            if (result.equals(resultEnum.getResult())) {
                return resultEnum.getDesc();
            }
        }
        return null;
    }
}
