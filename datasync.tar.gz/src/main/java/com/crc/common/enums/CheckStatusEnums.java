package com.crc.common.enums;

public enum CheckStatusEnums {
    CHECK_WAIT("等待", "1"),
    UNZIP_ING("解压中", "2"),
    UNZIP_FAIL("解压失败", "3"),
    CHECK_QUEUE("待检测", "4"),
    CHECK_ING("检测中", "5"),
    CHECK_FINISH("检测完成", "6"),
    CHECK_ERROR("检测异常", "7"),
    ;

    CheckStatusEnums(String name, String code) {
        this.name = name;
        this.code = code;
    }

    //自定义列类型名称
    private String name;
    //自定义列类型编码
    private String code;

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getCode() {
        return code;
    }

    public void setCode(String code) {
        this.code = code;
    }
}
