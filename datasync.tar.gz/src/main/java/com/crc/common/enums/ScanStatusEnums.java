package com.crc.common.enums;

public enum ScanStatusEnums {
    SCAN_QUEUE("队列中", 1),
    SCAN_ING("正在执行", 2),
    SCAN_PAUSE("已暂停", 3),
    SCAN_STOP("已停止", 4),
    SCAN_FINISH("已完成", 5),
    SCAN_WAIT("等待", 6),
    SCAN_TIMEOUT("已超时", 7),
    ;

    ScanStatusEnums(String name, int code) {
        this.name = name;
        this.code = code;
    }

    //自定义列类型名称
    private String name;
    //自定义列类型编码
    private int code;

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public int getCode() {
        return code;
    }

    public void setCode(int code) {
        this.code = code;
    }
}
