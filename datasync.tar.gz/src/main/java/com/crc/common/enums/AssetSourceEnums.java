package com.crc.common.enums;

public enum AssetSourceEnums {
    COMMON_CMDB("CMDB", "0"),
    JIAOTU_CMDB("椒图", "1"),
    MO_FANG_CMDB("魔方", "2"),
    QINGTENG_CMDB("青藤云", "3"),
    D01_CMDB("D01", "4"),
    MANUAL_CMDB("人工上报", "5"),
    CHANGTING_CMDB("长亭资产", "6"),
    ANHENG_CMDB("安恒资产", "7"),
    GOBY_CMDB("GOBY资产", "8"),
    LVMENT_CMDB("绿盟资产", "9"),
    TIANRONGXIN_CMDB("天融信", "10"),
    HUAWEI_CMDB("华为", "12"),
    LANJING_CMDB("蓝鲸", "11"),

    SAFEDOG_CMDB("安全狗", "13"),
    TIANYAN_CMDB("天眼", "14"),
    BETA_CMDB("北塔", "15"),
    AA_CMDB("自动化分析平台", "16"),
    SIP_CMDB("深信服SIP", "17"),
    IOT_CMDB("物联网中台", "18"),
    NGSOC_CMDB("奇安信NGSOC", "19"),
    TDHX_LF_CMDB("临汾天地和兴扫描器", "101"),
    TDHX_YT_CMDB("液碳天地和兴扫描器", "102"),
    TDHX_TZ_CMDB("泰州天地和兴扫描器", "103"),
    TDHX_CQ_CMDB("重庆天地和兴扫描器", "104"),
    ;

    AssetSourceEnums(String name, String code) {
        this.name = name;
        this.code = code;
    }

    //自定义列类型名称
    private String name;
    //自定义列类型编码
    private String code;

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getCode() {
        return code;
    }

    public void setCode(String code) {
        this.code = code;
    }
}
