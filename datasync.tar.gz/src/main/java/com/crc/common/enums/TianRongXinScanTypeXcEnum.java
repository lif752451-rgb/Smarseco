package com.crc.common.enums;

import org.apache.commons.lang3.StringUtils;

public enum TianRongXinScanTypeXcEnum {
    /**
     * 主机扫描
     */
    HOST_SCAN("主机扫描","alarmEngineer"),
    /**
     * Web扫描
     */
    WEB_SCAN("主机扫描","alarmUnitConnect"),
    /**
     * 弱口令扫描
     */
    WEAK_SCAN("主机扫描","addWeakTask");
    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getKey() {
        return key;
    }

    public void setKey(String key) {
        this.key = key;
    }
    /**
     * 名称
     */
    private String name;

    /**
     * 描述
     */
    private String key;

    TianRongXinScanTypeXcEnum(String name, String key){
        this.name = name;
        this.key = key;
    }

    public static TianRongXinScanTypeXcEnum findByName(String name){
        if(StringUtils.isEmpty(name)){
            return null;
        }
        TianRongXinScanTypeXcEnum[] values = TianRongXinScanTypeXcEnum.values();
        for(TianRongXinScanTypeXcEnum key : values){
            if(name.equals(key.getName())){
                return key;
            }
        }
        return null;
    }
}
