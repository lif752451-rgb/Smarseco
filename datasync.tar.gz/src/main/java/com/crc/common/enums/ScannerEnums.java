package com.crc.common.enums;

public enum ScannerEnums {
    QINGTENG_SCANNER("青藤主机防护", "1"),
    LVMENG_SCANNER("绿盟扫描器", "2"),
    DCC_SCANNER("DCC扫描器", "3"),
    GOBY_SCANNER("GOBY扫描器", "4"),
    CHANGTING_SCANNER("长亭扫描器", "5"),
    ANHENG_SCANNER("安恒扫描器", "6"),
    D01_SCANNER("D01扫描器", "7"),
    MO_FANG_SCANNER("魔方扫描器", "8"),
    JIAOTU_SCANNER("椒图扫描器", "9"),
    TIANRONGXIN_SCANNER("天融信扫描器", "10"),
    HUAWEI_SCANNER("华为扫描器", "11"),
    SAFEDOG_SCANNER("安全狗", "12"),
    TIANQIN_SCANNER("天擎", "13"),
    SDN_SCANNER("SDN", "14"),
    AA_SCANNER("自动化分析平台", "15"),
    ZHUOMUNIAO_SCANNER("啄木鸟代码扫描器", "20"),
    FORADAR_SCANNER("Foradar攻击面探测", "31"),
    TDHX_LF_SCANNER("临汾天地和兴扫描器", "101"),
    TDHX_YT_SCANNER("液碳天地和兴扫描器", "102"),
    TDHX_TZ_SCANNER("泰州天地和兴扫描器", "103"),
    TDHX_CQ_SCANNER("重庆天地和兴扫描器", "104"),
    ;

    ScannerEnums(String name, String code) {
        this.name = name;
        this.code = code;
    }

    //自定义列类型名称
    private String name;
    //自定义列类型编码
    private String code;

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getCode() {
        return code;
    }

    public void setCode(String code) {
        this.code = code;
    }
}
