package com.crc.common.enums;

import lombok.AllArgsConstructor;
import lombok.Getter;

/**
 * @author fuzhuangzhi
 * @title AlarmIpTypeEnum
 * @date 2023/6/27 17:52
 * @description TODO
 */
@Getter
@AllArgsConstructor
public enum AlarmIpTypeEnum {
    /**
     * 攻击IP
     */
    ATTACK_IP("1","攻击IP"),

    /**
     * 受害IP
     */
    VICTIMIZED_IP("2","攻击IP"),

    /**
     * 攻击IP和受害IP
     */
    ALL("3","攻击IP和攻击IP"),

    ;
    private String value;
    private String desc;
}
