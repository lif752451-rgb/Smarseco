package com.crc.common.enums;

public enum ScanTypeEnums {
    HOST_SCAN("主机漏洞扫描", 1),
    WEB_SCAN("WEB漏洞扫描", 2),
    WEAK_PASS_SCAN("口令猜解任务", 3),
    ;

    ScanTypeEnums(String name, int code) {
        this.name = name;
        this.code = code;
    }

    //自定义列类型名称
    private String name;
    //自定义列类型编码
    private int code;

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public int getCode() {
        return code;
    }

    public void setCode(int code) {
        this.code = code;
    }
}
