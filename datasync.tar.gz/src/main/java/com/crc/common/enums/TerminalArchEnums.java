package com.crc.common.enums;

import com.crc.common.utils.DataUtils;


public enum TerminalArchEnums {
    //UNKNOWN_OS = 0;
    //WINDOWS = 1;
    //LINUX = 2;
    //MACOS = 3;
    //ANDROID = 4;
    //// 泛指苹果移动端系统
    //IOS = 5;
    //// 鸿蒙
    //HARMONYOS = 6;
    UNKNOWN_ARCH("UNKNOWN_ARCH", 0),
    X86("X86", 1),
    X64("X64", 2),
    ARM("ARM", 3),
    AArch64("AArch64", 4),
    MIPS("MIPS", 5),
    MIPS64("MIPS64", 6),
    ;

    TerminalArchEnums(String name, int code) {
        this.name = name;
        this.code = code;
    }

    //自定义列类型名称
    private final String name;
    //自定义列类型编码
    private final int code;

    public static String getArchName(int code) {
        for (int i = 0; i < TerminalArchEnums.values().length; i++) {
            if (code == TerminalArchEnums.values()[i].code) {
                return TerminalArchEnums.values()[i].name;
            }
        }
        return UNKNOWN_ARCH.name;
    }

    public static String getArchName(String code) {
        return getArchName(DataUtils.toInt(code));
    }
}
