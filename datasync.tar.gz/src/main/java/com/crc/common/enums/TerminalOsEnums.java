package com.crc.common.enums;

import com.crc.common.utils.DataUtils;


public enum TerminalOsEnums {
    //UNKNOWN_OS = 0;
    //WINDOWS = 1;
    //LINUX = 2;
    //MACOS = 3;
    //ANDROID = 4;
    //// 泛指苹果移动端系统
    //IOS = 5;
    //// 鸿蒙
    //HARMONYOS = 6;
    UNKNOWN_OS("UNKNOWN_OS", 0),
    WINDOWS("WINDOWS", 1),
    LINUX("LINUX", 2),
    MACOS("MACOS", 3),
    ANDROID("ANDROID", 4),
    IOS("IOS", 5),
    HARMONYOS("HARMONYOS", 6),
    ;

    TerminalOsEnums(String name, int code) {
        this.name = name;
        this.code = code;
    }

    //自定义列类型名称
    private final String name;
    //自定义列类型编码
    private final int code;

    public static String getOsName(int code) {
        for (int i = 0; i < TerminalOsEnums.values().length; i++) {
            if (code == TerminalOsEnums.values()[i].code) {
                return TerminalOsEnums.values()[i].name;
            }
        }
        return UNKNOWN_OS.name;
    }

    public static String getOsName(String code) {
        return getOsName(DataUtils.toInt(code));
    }
}
