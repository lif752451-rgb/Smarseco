package com.crc.common.enums;

public enum TerminalSourceEnums {
    TIANQIN_CMDB("天擎", "1"),
    LIANRUAN_CMDB("联软", "2"),
    TENGXUN_CMDB("腾讯", "3"),
    SDN_CMDB("SDN", "4"),
    ;

    TerminalSourceEnums(String name, String code) {
        this.name = name;
        this.code = code;
    }

    //自定义列类型名称
    private String name;
    //自定义列类型编码
    private String code;

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getCode() {
        return code;
    }

    public void setCode(String code) {
        this.code = code;
    }
}
