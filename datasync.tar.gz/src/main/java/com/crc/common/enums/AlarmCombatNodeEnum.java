package com.crc.common.enums;

import lombok.Getter;
import org.apache.commons.lang3.StringUtils;

/**
 * 实战告警闭环流程节点枚举
 */
@Getter
public enum AlarmCombatNodeEnum {

    /**
     * 创建
     */
    CREATE("创建", "create"),

    /**
     * 研判
     */
    JUDGE("研判", "judge"),

    /**
     * 处置
     */
    DEAL("处置", "deal"),

    /**
     * 后续跟进
     */
    FOLLOW("后续跟进", "follow"),

    /**
     * 审核
     */
    AUDIT("审核", "audit"),

    /**
     * 归档
     */
    COMPLETE("归档", "complete"),

    /**
     * 无需处置
     */
    NO_DEAL("无需处置", "noDeal"),
    ;

    AlarmCombatNodeEnum(String nodeLabel, String nodeKey) {
        this.nodeLabel = nodeLabel;
        this.nodeKey = nodeKey;
    }

    /**
     * nodeName 节点名称
     */
    private final String nodeLabel;

    /**
     * dealUser 处置人
     */
    private final String nodeKey;

    public static AlarmCombatNodeEnum getEnumByNodeKey(String nodeKey) {
        if (StringUtils.isEmpty(nodeKey)) {
            return null;
        }
        AlarmCombatNodeEnum[] values = AlarmCombatNodeEnum.values();
        for (AlarmCombatNodeEnum key : values) {
            if (nodeKey.equals(key.getNodeKey())) {
                return key;
            }
        }
        return null;
    }

    public static String getEnumLabelByNodeKey(String nodeKey) {
        if (StringUtils.isEmpty(nodeKey)) {
            return null;
        }
        AlarmCombatNodeEnum[] values = AlarmCombatNodeEnum.values();
        for (AlarmCombatNodeEnum key : values) {
            if (nodeKey.equals(key.getNodeKey())) {
                return key.getNodeLabel();
            }
        }
        return "";
    }
}