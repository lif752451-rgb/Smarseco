package com.crc.common.gm;

import lombok.extern.slf4j.Slf4j;
import org.bouncycastle.util.encoders.Hex;

@Slf4j
public class GuoMiTools {
    private static final String[] SUPPORT_ARGO = {"SM2", "SM3", "SM4"};

    /**
     * 国密加密算法
     *
     * @param plainText 明文
     * @param key       密钥KEY
     * @param type      加密算法"SM2", "SM3", "SM4"
     * @return 密文
     */
    public static String encryptData(String plainText, String key, String type) {
        try {
            boolean flag = false;
            for (String k : SUPPORT_ARGO) {
                if (k.equalsIgnoreCase(type)) {
                    flag = true;
                    break;
                }
            }
            if (!flag) {
                log.error("算法不支持{}！", type);
                return plainText;
            }
            if ("SM4".equals(type)) {
                SM4Utils sm4 = new SM4Utils();
                sm4.setSecretKey(key);
                sm4.setHexString(false);
                return sm4.encryptData_ECB(plainText);
            } else if ("SM3".equals(type)) {
                byte[] md = new byte[32];
                byte[] msg1 = plainText.getBytes();
                SM3Digest sm3 = new SM3Digest();
                sm3.update(msg1, 0, msg1.length);
                sm3.doFinal(md, 0);
                return new String(Hex.encode(md));
            }

        } catch (Exception e) {
            log.error(e.getMessage(), e);
        }

        return plainText;
    }

    /**
     * 国密解码算法
     *
     * @param cipherText 密文
     * @param key        密钥KEY
     * @param type       解密算法"SM2", "SM3", "SM4"
     * @return 明文
     */
    public static String decryptData(String cipherText, String key, String type) {
        try {
            boolean flag = false;
            for (String k : SUPPORT_ARGO) {
                if (k.equalsIgnoreCase(type)) {
                    flag = true;
                    break;
                }
            }
            if (!flag) {
                log.error("算法不支持{}！", type);
                return cipherText;
            }
            if ("SM4".equals(type)) {
                SM4Utils sm4 = new SM4Utils();
                sm4.setSecretKey(key);
                sm4.setHexString(false);
                return sm4.decryptData_ECB(cipherText);
            } else if ("SM3".equals(type)) {
                log.error("SM3是我国采用的一种密码散列函数标准,不支持解密");
            }

        } catch (Exception e) {
            log.error(e.getMessage(), e);
        }

        return cipherText;
    }


    public static boolean verify(String sign, String plaintext, String key) {
        try {
            return encryptData(plaintext, key, "SM3").equals(sign);
        } catch (Exception e) {
            log.error(e.getMessage(), e);
            return Boolean.FALSE;
        }
    }

}
