/*
 * Copyright 2014 Alexey Plotnik
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package com.crc.common.nginxparser;

/**
 * Describes single line parameter. Examples:
 * user  nginx;
 * worker_processes  2;
 */
public class NgxParam extends NgxAbstractEntry {

    public String toString() {
        String s = super.toString();
        if (s.isEmpty())
            return s;

        return s + ";";
    }

    @Override
    public void write(NgxPrintWriter printWriter) {
        printWriter.appendLine(toString());
    }
}
