package com.crc.common.nginxparser.enity;

import lombok.Data;

import java.util.List;

@Data
public class NginxServer {
    int port;
    String serverName;
    List<Location> locationList;
}
