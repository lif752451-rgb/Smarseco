package com.crc.common.nginxparser.enity;

import lombok.Data;

import java.util.List;

@Data
public class NginxData {
    String fileName;

    List<NginxServer> nginxServerList;

}
