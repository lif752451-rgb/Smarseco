package com.crc.common.nginxparser.enity;

import lombok.Data;

@Data
public class Location {
    String path;
    String root;
    String proxyPass;
}
