package com.crc.common.utils;


import lombok.extern.slf4j.Slf4j;

@Slf4j
public class MyTheadUtils {
    public static void sleepBySec(int sec) {
        if (sec < 0) {
            sec = 1;
        }
        try {

            Thread.sleep(1000L * sec);
        } catch (Exception e) {
            log.error(e.getMessage(),e);
        }
    }

    public static void sleep(int ms) {
        if (ms < 0) {
            ms = 1;
        }
        try {
            Thread.sleep(ms);
        } catch (Exception e) {
            log.error(e.getMessage(),e);
        }
    }
}


