package com.crc.common.utils;

import java.util.Date;
import java.util.concurrent.atomic.AtomicLong;

public class TestUtils {
    static AtomicLong atom = new AtomicLong(0);

    public static void print(String msg) {
        System.out.println(atom.addAndGet(1) + " =>##########> " + DateUtils.getDateTimeString2(new Date()));
        System.out.println(msg);
        System.out.println("###########> " + DateUtils.getDateTimeString2(new Date()));
    }

    public static void print(String... msg) {
        System.out.println(atom.addAndGet(1) + " =>##########> " + DateUtils.getDateTimeString2(new Date()));
        for (String s : msg) {
            System.out.println(s);
        }
        System.out.println("###########> " + DateUtils.getDateTimeString2(new Date()));
    }
}
