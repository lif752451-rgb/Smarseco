package com.crc.common.utils;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.util.Objects;

/**
 * Md5加密方法
 *
 * @author wst
 */
public class Md5Utils {
    private static final Logger log = LoggerFactory.getLogger(Md5Utils.class);

    private static byte[] md5(String s) {
        MessageDigest algorithm;
        try {
            algorithm = MessageDigest.getInstance("MD5");
            algorithm.reset();
            algorithm.update(s.getBytes(StandardCharsets.UTF_8));
            byte[] messageDigest = algorithm.digest();
            return messageDigest;
        } catch (Exception e) {
            log.error("MD5 Error...", e);
        }
        return null;
    }

    private static String toHex(byte[] hash) {
        if (hash == null) {
            return null;
        }
        StringBuffer buf = new StringBuffer(hash.length * 2);
        int i;

        for (i = 0; i < hash.length; i++) {
            if ((hash[i] & 0xff) < 0x10) {
                buf.append("0");
            }
            buf.append(Long.toString(hash[i] & 0xff, 16));
        }
        return buf.toString();
    }

    public static String hash(String s) {
        if (s == null) {
            s = "";
        }
        try {
            return new String(Objects.requireNonNull(toHex(md5(s))).getBytes(StandardCharsets.UTF_8), StandardCharsets.UTF_8);
        } catch (Exception e) {
            log.error("not supported charset...{}", e.getMessage(), e);
            return s;
        }
    }

    public static String hash(Object... ss) {
        if (ss != null) {
            StringBuilder s = new StringBuilder();
            for (Object x : ss) {
                if (x == null) {
                    x = "";
                }
                s.append(x);
            }
            try {
                return new String(Objects.requireNonNull(toHex(md5(s.toString()))).getBytes(StandardCharsets.UTF_8), StandardCharsets.UTF_8);
            } catch (Exception e) {
                log.error("not supported charset...{}", e.getMessage(), e);
                return s.toString();
            }
        }
        return "";
    }

    /**
     * sha256加密
     *
     * @param str 要加密的字符串
     * @return 加密后的字符串
     */
    public static String sha256(String str) {
        MessageDigest messageDigest;
        String encodeStr = "";
        try {
            messageDigest = MessageDigest.getInstance("SHA-256");
            messageDigest.update(str.getBytes(StandardCharsets.UTF_8));
            encodeStr = toHex(messageDigest.digest());
        } catch (Exception e) {
            log.error("not supported charset...{}", e.getMessage(), e);
        }
        return encodeStr;
    }
}
