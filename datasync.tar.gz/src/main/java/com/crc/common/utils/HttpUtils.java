package com.crc.common.utils;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONArray;
import com.alibaba.fastjson.JSONObject;
import com.crc.scanner.tool.LvmengUtils;
import com.crc.secface.config.ElasticsearchProperties;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.codec.binary.Base64;
import org.apache.commons.lang3.StringUtils;
import org.springframework.http.HttpHeaders;

import java.io.*;
import java.net.*;
import java.nio.charset.StandardCharsets;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.TreeMap;

/**
 * 通用http发送方法
 *
 * @author ruoyi
 */
@Slf4j
public class HttpUtils {
    public static final int CONN_TIME_OUT = 60000;
    public static final int READ_TIME_OUT = 60000;

    /**
     * 向指定 URL 发送GET方法的请求
     *
     * @param url   发送请求的 URL
     * @param param 请求参数，请求参数应该是 name1=value1&name2=value2 的形式。
     * @return 所代表远程资源的响应结果
     */
    public static String sendGetProxy(String url, String param, String proxyIp, int proxyPort) {
        if (url != null && url.toLowerCase().startsWith("https")) {
            return HttpsUtils.sendSSLGetProxy(url, param, proxyIp, proxyPort);
        }
        StringBuilder result = new StringBuilder();
        BufferedReader in = null;
        HttpURLConnection connection = null;
        try {
            String urlNameString = url;
            if (StringUtils.isNotBlank(param)) {
                urlNameString = url + "?" + param;
            }
            log.info("sendGetProxy - proxy={}:{} -->" + urlNameString, proxyIp, proxyPort);
            //配置代理类
            Proxy proxy = new Proxy(Proxy.Type.HTTP, new InetSocketAddress(proxyIp, proxyPort));
            URL urlObj = new URL(urlNameString);
            //通过代理类建立连接
            connection = (HttpURLConnection) urlObj.openConnection(proxy);
            connection.setRequestProperty("accept", "*/*");
            connection.setRequestProperty("connection", "Keep-Alive");
            connection.setRequestProperty("user-agent", "Mozilla/4.0 (compatible; MSIE 6.0; Windows NT 5.1;SV1)");
            connection.setRequestProperty("content-type", "application/json");
            connection.setConnectTimeout(CONN_TIME_OUT);
            connection.setReadTimeout(READ_TIME_OUT);
            connection.connect();
            in = new BufferedReader(new InputStreamReader(connection.getInputStream()));
            String line;
            while ((line = in.readLine()) != null) {
                result.append(line);
            }
        } catch (IOException e) {
            log.error(url + " http请求错误 " + e.getMessage(), e);
            if (connection != null) {
                try {
                    in = new BufferedReader(new InputStreamReader(connection.getErrorStream()));
                    String line;
                    while ((line = in.readLine()) != null) {
                        result.append(line);
                    }
                } catch (Exception e1) {
                    //log.error(url + " http请求错误1 " + e1.getMessage(), e1);
                }
            }
        }catch (Exception e) {
            log.error(url + " http请求错误 " + e.getMessage(), e);
        } finally {
            IOUtils.close(in);
            IOUtils.close(connection);
        }
        return result.toString();
    }


    /**
     * 向指定 URL 发送GET方法的请求
     *
     * @param url   发送请求的 URL
     * @param param 请求参数，请求参数应该是 name1=value1&name2=value2 的形式。
     * @return 所代表远程资源的响应结果
     */
    public static String sendGet(String url, String param) {
        if (url != null && url.toLowerCase().startsWith("https")) {
            return HttpsUtils.sendSSLGet(url, param);
        }
        StringBuilder result = new StringBuilder();
        BufferedReader in = null;
        HttpURLConnection connection = null;
        try {
            String urlNameString = url;
            if (StringUtils.isNotBlank(param)) {
                urlNameString = url + "?" + param;
            }
            log.info("sendGet - " + urlNameString);
            URL realUrl = new URL(urlNameString);
            connection = (HttpURLConnection) realUrl.openConnection();
            connection.setRequestProperty("accept", "*/*");
            connection.setRequestProperty("connection", "Keep-Alive");
            connection.setRequestProperty("user-agent", "Mozilla/4.0 (compatible; MSIE 6.0; Windows NT 5.1;SV1)");
            connection.setRequestProperty("content-type", "application/json");
            connection.setConnectTimeout(CONN_TIME_OUT);
            connection.setReadTimeout(READ_TIME_OUT);
            connection.connect();
            in = new BufferedReader(new InputStreamReader(connection.getInputStream()));
            String line;
            while ((line = in.readLine()) != null) {
                result.append(line);
            }
        } catch (IOException e) {
            log.error(url + " http请求错误 " + e.getMessage(), e);
            if (connection != null) {
                try {
                    in = new BufferedReader(new InputStreamReader(connection.getErrorStream()));
                    String line;
                    while ((line = in.readLine()) != null) {
                        result.append(line);
                    }
                } catch (Exception e1) {
                    //log.error(url + " http请求错误1 " + e1.getMessage(), e1);
                }
            }
        } catch (Exception e) {
            log.error(url + " http请求错误 " + e.getMessage(), e);
        } finally {
            IOUtils.close(in);
            IOUtils.close(connection);
        }
        return result.toString();
    }

    /**
     * 向指定 URL 发送GET方法的请求
     *
     * @param url   发送请求的 URL
     * @param param 请求参数，请求参数应该是 name1=value1&name2=value2 的形式。
     * @return 所代表远程资源的响应结果
     */
    public static String sendGet(String url, String param, HashMap<String, String> headerMap) {
        if (url != null && url.toLowerCase().startsWith("https")) {
            return HttpsUtils.sendSSLGet(url, param, headerMap);
        }
        StringBuilder result = new StringBuilder();
        BufferedReader in = null;
        HttpURLConnection connection = null;
        try {
            String urlNameString = url;
            if (StringUtils.isNotBlank(param)) {
                urlNameString = url + "?" + param;
            }
            log.info("sendGet - " + urlNameString);
            URL realUrl = new URL(urlNameString);
            connection = (HttpURLConnection) realUrl.openConnection();
            connection.setRequestProperty("accept", "*/*");
            connection.setRequestProperty("connection", "Keep-Alive");
            connection.setRequestProperty("user-agent", "Mozilla/4.0 (compatible; MSIE 6.0; Windows NT 5.1;SV1)");
            connection.setRequestProperty("content-type", "application/json");
            connection.setConnectTimeout(CONN_TIME_OUT);
            connection.setReadTimeout(READ_TIME_OUT);
            HttpURLConnection finalConnection = connection;
            if (headerMap != null) {
                headerMap.forEach(finalConnection::setRequestProperty);
            }
            connection.connect();
            in = new BufferedReader(new InputStreamReader(connection.getInputStream()));
            String line;
            while ((line = in.readLine()) != null) {
                result.append(line);
            }
        } catch (IOException e) {
            log.error(url + " http请求错误 " + e.getMessage(), e);
            if (connection != null) {
                try {
                    in = new BufferedReader(new InputStreamReader(connection.getErrorStream()));
                    String line;
                    while ((line = in.readLine()) != null) {
                        result.append(line);
                    }
                } catch (Exception e1) {
                    //log.error(url + " http请求错误1 " + e1.getMessage(), e1);
                }
            }
        } catch (Exception e) {
            log.error(url + " http请求错误 " + e.getMessage(), e);
        } finally {
            IOUtils.close(in);
            IOUtils.close(connection);
        }
        return result.toString();
    }

    /**
     * 向指定 URL 发送GET方法的请求
     *
     * @param url   发送请求的 URL
     * @param param 请求参数，请求参数应该是 name1=value1&name2=value2 的形式。
     * @return 所代表远程资源的响应结果
     */
    public static String sendGet(String url, String param, String token) {
        if (url != null && url.startsWith("https")) {
            return HttpsUtils.sendGet(url, param, token);
        }
        StringBuilder result = new StringBuilder();
        BufferedReader in = null;
        HttpURLConnection connection = null;
        try {
            String urlNameString = url + "?" + param;
            if (StringUtils.isBlank(param)) {
                urlNameString = url;
            }
            log.info("sendGet - " + urlNameString);
            URL realUrl = new URL(urlNameString);
            connection = (HttpURLConnection) realUrl.openConnection();
            connection.setRequestProperty("accept", "*/*");
            connection.setRequestProperty("connection", "Keep-Alive");
            connection.setRequestProperty("user-agent", "Mozilla/4.0 (compatible; MSIE 6.0; Windows NT 5.1;SV1)");
            connection.setRequestProperty(org.apache.http.HttpHeaders.AUTHORIZATION, token);
            connection.setRequestProperty("Cookie", "X-Subject-Token=" + token);
            connection.setRequestProperty("content-type", "application/json");
            connection.setConnectTimeout(CONN_TIME_OUT);
            connection.setReadTimeout(READ_TIME_OUT);
            connection.connect();
            in = new BufferedReader(new InputStreamReader(connection.getInputStream()));
            String line;
            while ((line = in.readLine()) != null) {
                result.append(line);
            }
        } catch (IOException e) {
            log.error(url + " http请求错误 " + e.getMessage(), e);
            if (connection != null) {
                try {
                    in = new BufferedReader(new InputStreamReader(connection.getErrorStream()));
                    String line;
                    while ((line = in.readLine()) != null) {
                        result.append(line);
                    }
                } catch (Exception e1) {
                    //log.error(url + " http请求错误1 " + e1.getMessage(), e1);
                }
            }
        } catch (Exception e) {
            log.error(url + " http请求错误 " + e.getMessage(), e);
        } finally {
            IOUtils.close(in);
            IOUtils.close(connection);
        }
        return result.toString();
    }

    /**
     * @param url  对方地址
     * @param json 要传送的数据
     * @return
     */
    public static String sendPost(String url, String json, boolean print) {
        if (url != null && url.startsWith("https")) {
            return HttpsUtils.sendPost(url, json);
        }
        OutputStreamWriter out = null;
        BufferedReader in = null;
        StringBuilder result = new StringBuilder();
        HttpURLConnection connection = null;
        try {
            URL urlObj = new URL(url);
            if (print) {
                log.info("sendPost - " + url + ",JSON参数：" + DataUtils.hidePsw(json));
            } else {
                log.info("sendPost - " + url);
            }
            connection = (HttpURLConnection) urlObj.openConnection();
            // 设置doOutput属性为true表示将使用此connection写入数据
            connection.setDoOutput(true);
            // 定义待写入数据的内容类型，我们设置为application/x-www-form-urlencoded类型
            connection.setRequestProperty("content-type", "application/json");
            connection.setRequestProperty("accept", "*/*");
            connection.setRequestProperty("connection", "Keep-Alive");
            connection.setRequestProperty("user-agent", "Mozilla/4.0 (compatible; MSIE 6.0; Windows NT 5.1;SV1)");
            connection.setConnectTimeout(CONN_TIME_OUT);
            connection.setReadTimeout(READ_TIME_OUT);
//            System.out.println(url);
//            connection.getRequestProperties().forEach((k, v) -> {
//                System.out.println(k + " -> " + v);
//            });

            // 得到请求的输出流对象
            out = new OutputStreamWriter(connection.getOutputStream());
            // 把数据写入请求的Body
            if (StringUtils.isNotBlank(json))
                out.write(json);
            out.flush();
            // 定义BufferedReader输入流来读取URL的响应
            in = new BufferedReader(new InputStreamReader(connection.getInputStream()));
            String line;
            while ((line = in.readLine()) != null) {
                result.append(line);
            }
        } catch (IOException e) {
            log.error(url + " http请求错误 " + e.getMessage(), e);
            if (connection != null) {
                try {
                    in = new BufferedReader(new InputStreamReader(connection.getErrorStream()));
                    String line;
                    while ((line = in.readLine()) != null) {
                        result.append(line);
                    }
                } catch (Exception e1) {
                    //log.error(url + " http请求错误1 " + e1.getMessage(), e1);
                }
            }
        } catch (Exception e) {
            log.error(url + " http请求错误 " + e.getMessage(), e);
            return "";
        }
        // 使用finally块来关闭输出流、输入流
        finally {
            IOUtils.close(in);
            IOUtils.close(out);
            IOUtils.close(connection);
        }
        return result.toString();
    }

    /**
     * @param url  对方地址
     * @param json 要传送的数据
     * @return
     */
    public static String sendPost(String url, String json) {
        if (StringUtils.isBlank(url)) {
            return "";
        }
        if (url.startsWith("https")) {
            return HttpsUtils.sendPost(url, json);
        }
        OutputStreamWriter out = null;
        BufferedReader in = null;
        StringBuilder result = new StringBuilder();
        HttpURLConnection connection = null;
        try {
            URL urlObj = new URL(url);
            log.info("sendPost - " + url + ",JSON参数：" + DataUtils.hidePsw(json));
            connection = (HttpURLConnection) urlObj.openConnection();
            // 设置doOutput属性为true表示将使用此connection写入数据
            connection.setDoOutput(true);
            // 定义待写入数据的内容类型，我们设置为application/x-www-form-urlencoded类型
            connection.setRequestProperty("Content-Type", "application/json");
            connection.setConnectTimeout(CONN_TIME_OUT);
            connection.setReadTimeout(READ_TIME_OUT);

            // 得到请求的输出流对象
            out = new OutputStreamWriter(connection.getOutputStream());
            // 把数据写入请求的Body
            if (StringUtils.isNotBlank(json))
                out.write(json);
            out.flush();
            // 定义BufferedReader输入流来读取URL的响应
            in = new BufferedReader(new InputStreamReader(connection.getInputStream()));
            String line;
            while ((line = in.readLine()) != null) {
                result.append(line);
            }
        } catch (IOException e) {
            log.error(url + " http请求错误 " + e.getMessage(), e);
            if (connection != null) {
                try {
                    in = new BufferedReader(new InputStreamReader(connection.getErrorStream()));
                    String line;
                    while ((line = in.readLine()) != null) {
                        result.append(line);
                    }
                } catch (Exception e1) {
                    //log.error(url + " http请求错误1 " + e1.getMessage(), e1);
                }
            }
        } catch (Exception e) {
            log.error(url + " http请求错误 " + e.getMessage(), e);
            return "";
        }
        // 使用finally块来关闭输出流、输入流
        finally {
            IOUtils.close(in);
            IOUtils.close(out);
            IOUtils.close(connection);
        }
        return result.toString();
    }

    /**
     * 向指定 URL 发送POST方法的请求
     *
     * @param url   发送请求的 URL
     * @param param JSON。
     * @return 所代表远程资源的响应结果
     */
    public static String sendPost(String url, String param, HashMap<String, String> headerMap) {
        PrintWriter out = null;
        BufferedReader in = null;
        StringBuilder result = new StringBuilder();
        HttpURLConnection conn = null;
        try {
            URL realUrl = new URL(url);
            log.info("sendPost - " + url + ",参数：" + DataUtils.hidePsw(param) + ",header=" + JSON.toJSONString(headerMap));
            conn = (HttpURLConnection) realUrl.openConnection();
            conn.setRequestProperty("accept", "*/*");
            conn.setRequestProperty("connection", "Keep-Alive");
            conn.setRequestProperty("user-agent", "Mozilla/4.0 (compatible; MSIE 6.0; Windows NT 5.1;SV1)");
            conn.setRequestProperty("Accept-Charset", "utf-8");
            conn.setRequestProperty("contentType", "utf-8");
            conn.setRequestProperty("content-type", "application/json");
            conn.setConnectTimeout(CONN_TIME_OUT);
            conn.setReadTimeout(READ_TIME_OUT);
            for (String key : headerMap.keySet()) {
                conn.setRequestProperty(key, headerMap.get(key));
            }
            conn.setDoOutput(true);
            conn.setDoInput(true);
            out = new PrintWriter(conn.getOutputStream());
            out.write(param);
            out.flush();
            in = new BufferedReader(new InputStreamReader(conn.getInputStream(), StandardCharsets.UTF_8));
            String line;
            while ((line = in.readLine()) != null) {
                result.append(line);
            }
        } catch (IOException e) {
            log.error(url + " http请求错误 " + e.getMessage(), e);
            if (conn != null) {
                try {
                    in = new BufferedReader(new InputStreamReader(conn.getErrorStream()));
                    String line;
                    while ((line = in.readLine()) != null) {
                        result.append(line);
                    }
                } catch (Exception e1) {
                    //log.error(url + " http请求错误1 " + e1.getMessage(), e1);
                }
            }
        } catch (Exception e) {
            log.error(url + " http请求错误 " + e.getMessage(), e);
        } finally {
            IOUtils.close(in);
            IOUtils.close(out);
            IOUtils.close(conn);
        }
        return result.toString();
    }

    public static String sendEsGet(ElasticsearchProperties esConfig, String index, String json) {
        StringBuilder result = new StringBuilder();
        BufferedReader in = null;
        OutputStreamWriter out = null;
        HttpURLConnection connection = null;
        String url = buildEsSearchUrl(esConfig, index);
        try {
            if (StringUtils.isBlank(url)) {
                return "";
            }
            log.info("sendEsGet - " + url);
            URL urlx = new URL(url);
            connection = (HttpURLConnection) urlx.openConnection();
            // 设置doOutput属性为true表示将使用此connection写入数据
            connection.setDoOutput(true);
            String userName = esConfig.getUserName();
            String password = esConfig.getPassword();
            String auth = userName + ":" + password;
            byte[] encodedAuth = Base64.encodeBase64(auth.getBytes(StandardCharsets.US_ASCII));
            String authHeader = "Basic " + new String(encodedAuth);
            connection.setRequestProperty(HttpHeaders.AUTHORIZATION, authHeader);
            String proxyHeader = esConfig.getProxyHeader();
            connection.setRequestProperty("X-Found-Cluster", proxyHeader);
            connection.setRequestProperty("accept", "*/*");
            connection.setRequestProperty("connection", "Keep-Alive");
            connection.setRequestProperty("Content-Length", "1000");
            System.setProperty("java.net.preferIPv4Stack", "true");
            connection.setRequestProperty("user-agent", "Mozilla/4.0 (compatible; MSIE 6.0; Windows NT 5.1;SV1)");
            connection.setRequestProperty("content-type", "application/json");
            connection.setConnectTimeout(CONN_TIME_OUT);
            connection.setReadTimeout(READ_TIME_OUT);
            // 得到请求的输出流对象
            out = new OutputStreamWriter(connection.getOutputStream());
            // 把数据写入请求的Body
            connection.connect();
            if (StringUtils.isNotBlank(json)) {
                out.write(json);
                out.flush();
            }
            //System.out.println(DateUtils.getDateTimeString2(new Date()));
            in = new BufferedReader(new InputStreamReader(connection.getInputStream(), StandardCharsets.UTF_8));
            String line;
            while ((line = in.readLine()) != null) {
                result.append(line);
            }
            //System.out.println(DateUtils.getDateTimeString2(new Date()));
        } catch (IOException e) {
            log.error(url + " http请求错误 " + e.getMessage(), e);
            if (connection != null) {
                try {
                    in = new BufferedReader(new InputStreamReader(connection.getErrorStream()));
                    String line;
                    while ((line = in.readLine()) != null) {
                        result.append(line);
                    }
                } catch (Exception e1) {
                    //log.error(url + " http请求错误1 " + e1.getMessage(), e1);
                }
            }
        } catch (Exception e) {
            log.error(url + " http请求错误 " + e.getMessage(), e);
        } finally {
            IOUtils.close(in);
            IOUtils.close(out);
            IOUtils.close(connection);
        }
        return result.toString();
    }

    public static String buildEsSearchUrl(ElasticsearchProperties esConfig, String esIndex) {
        if (esConfig == null) {
            return "";
        }
        return String.format("%s/%s/%s", esConfig.getBaseUrl(), esIndex, "_search");
    }

    public static String coverJson2String(JSONObject data, String excludeKey) {
        if (data == null || data.size() < 1) {
            return "";
        }
        TreeMap<String, Object> tree = new TreeMap<>();
        Iterator<Map.Entry<String, Object>> it = data.entrySet().iterator();
        while (it.hasNext()) {
            Map.Entry<String, Object> en = it.next();
            if (excludeKey != null && StringUtils.equals(excludeKey, en.getKey().trim()))
                continue;
            if (null == en.getValue())
                continue;
            tree.put(en.getKey(), en.getValue());
        }
        it = tree.entrySet().iterator();
        StringBuilder sf = new StringBuilder();
        while (it.hasNext()) {
            if (sf.length() > 0)
                sf.append("&");
            Map.Entry<String, Object> en = it.next();
            if (en.getValue() instanceof String || en.getValue() instanceof JSONObject || en.getValue() instanceof JSONArray) {
                String value = en.getValue().toString();
                try {
                    sf.append(en.getKey()).append("=").append(URLEncoder.encode(value, "UTF-8"));
                } catch (Exception e) {
                    sf.append(en.getKey()).append("=").append(en.getValue());
                }
            } else {
                sf.append(en.getKey()).append("=").append(en.getValue());
            }
        }
        return sf.toString();
    }

    /*
      通用HTTP GET请求接口
     */
    public static String sendGet(String url, String param, JSONObject headers) {
        if (StringUtils.isBlank(url)) {
            return "";
        }
        if (url.startsWith("https")) {
            return HttpsUtils.sendGet(url, param, headers);
        }
        StringBuilder result = new StringBuilder();
        BufferedReader in = null;
        HttpURLConnection connection = null;
        try {
            String urlNameString = url + "?" + param;
            if (StringUtils.isBlank(param)) {
                urlNameString = url;
            }
            log.info("sendGet - " + urlNameString + " param=" + headers.toString());
            URL realUrl = new URL(urlNameString);
            connection = (HttpURLConnection) realUrl.openConnection();
            connection.setRequestProperty("accept", "*/*");
            connection.setRequestProperty("connection", "Keep-Alive");
            connection.setRequestProperty("user-agent", "Mozilla/4.0 (compatible; MSIE 6.0; Windows NT 5.1;SV1)");
            connection.setRequestProperty("Content-Type", "application/json");
            if (headers != null) {
                HttpURLConnection finalConnection = connection;
                headers.forEach((k, v) -> {
                    try {
                        if (v != null) {
                            finalConnection.setRequestProperty(k, v.toString());
                        }
                    } catch (Exception e) {
                        log.error(e.getMessage(), e);
                    }
                });
            }

            connection.setConnectTimeout(CONN_TIME_OUT);
            connection.setReadTimeout(READ_TIME_OUT);
            connection.connect();
            in = new BufferedReader(new InputStreamReader(connection.getInputStream()));
            String line;
            while ((line = in.readLine()) != null) {
                result.append(line);
            }
        } catch (IOException e) {
            log.error(url + " http请求错误 " + e.getMessage(), e);
            if (connection != null) {
                try {
                    in = new BufferedReader(new InputStreamReader(connection.getErrorStream()));
                    String line;
                    while ((line = in.readLine()) != null) {
                        result.append(line);
                    }
                } catch (Exception e1) {
                    //log.error(url + " http请求错误1 " + e1.getMessage(), e1);
                }
            }
        } catch (Exception e) {
            log.error(url + " http请求错误 " + e.getMessage(), e);
        } finally {
            IOUtils.close(in);
            IOUtils.close(connection);
        }
        return result.toString();
    }

    /*
      通用HTTP GET请求接口
     */
    public static String sendGetProxy(String url, String param, JSONObject headers, String proxyIp, int proxyPort) {
        if (StringUtils.isBlank(url)) {
            return "";
        }
        if (url.startsWith("https")) {
            return HttpsUtils.sendGetProxy(url, param, headers, proxyIp, proxyPort);
        }
        StringBuilder result = new StringBuilder();
        BufferedReader in = null;
        HttpURLConnection connection = null;
        try {
            String urlNameString = url + "?" + param;
            if (StringUtils.isBlank(param)) {
                urlNameString = url;
            }
            log.info("sendGet - proxy={}:{} -->" + urlNameString, proxyIp, proxyPort);
            URL realUrl = new URL(urlNameString);
            Proxy proxy = new Proxy(Proxy.Type.HTTP, new InetSocketAddress(proxyIp, proxyPort));
            connection = (HttpURLConnection) realUrl.openConnection(proxy);
            connection.setRequestProperty("accept", "*/*");
            connection.setRequestProperty("connection", "Keep-Alive");
            connection.setRequestProperty("user-agent", "Mozilla/4.0 (compatible; MSIE 6.0; Windows NT 5.1;SV1)");
            connection.setRequestProperty("Content-Type", "application/json");
            if (headers != null) {
                HttpURLConnection finalConnection = connection;
                headers.forEach((k, v) -> {
                    try {
                        if (v != null) {
                            finalConnection.setRequestProperty(k, v.toString());
                        }
                    } catch (Exception e) {
                        log.error(e.getMessage(), e);
                    }
                });
            }

            connection.setConnectTimeout(CONN_TIME_OUT);
            connection.setReadTimeout(READ_TIME_OUT);
            connection.connect();
            in = new BufferedReader(new InputStreamReader(connection.getInputStream()));
            String line;
            while ((line = in.readLine()) != null) {
                result.append(line);
            }
        } catch (IOException e) {
            log.error(url + " http请求错误 " + e.getMessage(), e);
            if (connection != null) {
                try {
                    in = new BufferedReader(new InputStreamReader(connection.getErrorStream()));
                    String line;
                    while ((line = in.readLine()) != null) {
                        result.append(line);
                    }
                } catch (Exception e1) {
                    //log.error(url + " http请求错误1 " + e1.getMessage(), e1);
                }
            }
        } catch (Exception e) {
            log.error(url + " http请求错误 " + e.getMessage(), e);
        } finally {
            IOUtils.close(in);
            IOUtils.close(connection);
        }
        return result.toString();
    }

    public static String sendPost(String url, String param, JSONObject headers) {
        if (StringUtils.isBlank(url)) {
            return "";
        }
        if (url.startsWith("https")) {
            return HttpsUtils.sendPost(url, param, headers);
        }
        OutputStreamWriter out = null;
        BufferedReader in = null;
        StringBuilder result = new StringBuilder();
        HttpURLConnection connection = null;
        try {
            URL urlObj = new URL(url);
            log.info("sendPost - " + url + ",JSON参数：" + DataUtils.hidePsw(param) + ",header:" + headers.toJSONString());
            connection = (HttpURLConnection) urlObj.openConnection();
            // 设置doOutput属性为true表示将使用此connection写入数据
            connection.setDoOutput(true);
            // 定义待写入数据的内容类型，我们设置为application/x-www-form-urlencoded类型
            connection.setRequestProperty("Content-Type", "application/json");
            //connection.setRequestProperty("accept", "*/*");
            //connection.setRequestProperty("connection", "Keep-Alive");
            //connection.setRequestProperty("user-agent", "Mozilla/4.0 (compatible; MSIE 6.0; Windows NT 5.1;SV1)");
            if (headers != null) {
                HttpURLConnection finalConnection = connection;
                headers.forEach((k, v) -> {
                    try {
                        if (v != null) {
                            finalConnection.setRequestProperty(k, v.toString());
                        }
                    } catch (Exception e) {
                        log.error(e.getMessage(), e);
                    }
                });
            }
            connection.setConnectTimeout(CONN_TIME_OUT);
            connection.setReadTimeout(READ_TIME_OUT);

            // 得到请求的输出流对象
            out = new OutputStreamWriter(connection.getOutputStream());
            // 把数据写入请求的Body
            if (StringUtils.isNotBlank(param))
                out.write(param);
            out.flush();
            // 定义BufferedReader输入流来读取URL的响应
            in = new BufferedReader(new InputStreamReader(connection.getInputStream()));
            String line;
            while ((line = in.readLine()) != null) {
                result.append(line);
            }
        } catch (IOException e) {
            log.error(url + " http请求错误 " + e.getMessage(), e);
            if (connection != null) {
                try {
                    in = new BufferedReader(new InputStreamReader(connection.getErrorStream()));
                    String line;
                    while ((line = in.readLine()) != null) {
                        result.append(line);
                    }
                } catch (Exception e1) {
                    //log.error(url + " http请求错误1 " + e1.getMessage(), e1);
                }
            }
        } catch (Exception e) {
            log.error(url + " http请求错误 " + e.getMessage(), e);
            return "";
        }
        // 使用finally块来关闭输出流、输入流
        finally {
            IOUtils.close(in);
            IOUtils.close(out);
            IOUtils.close(connection);
        }
        return result.toString();
    }

    public static String sendPostForm(String url, String param, HashMap<String, String> heads) {
        if (StringUtils.isBlank(url)) {
            return null;
        }
        if (url.startsWith("https")) {
            return HttpsUtils.sendPostForm(url, param, heads);
        }
        OutputStream out = null;
        BufferedReader in = null;
        StringBuilder result = new StringBuilder();
        HttpURLConnection connection = null;
        try {
            log.info("sendPost - " + url + ",参数：" + DataUtils.hidePsw(param));
            URL urlObj = new URL(url);
            connection = (HttpURLConnection) urlObj.openConnection();
            // 设置doOutput属性为true表示将使用此connection写入数据
            connection.setDoOutput(true);
            connection.setRequestMethod("POST");
            // 定义待写入数据的内容类型，我们设置为application/x-www-form-urlencoded类型
            connection.setRequestProperty("accept", "*/*");
            connection.setRequestProperty("Connection", "Keep-Alive");
            connection.setRequestProperty("Charset", "UTF-8");
            connection.setRequestProperty("Content-Type", "application/x-www-form-urlencoded; charset=UTF-8");
            connection.setConnectTimeout(CONN_TIME_OUT);
            connection.setReadTimeout(READ_TIME_OUT);
            if (heads != null) {
                for (String key : heads.keySet()) {
                    connection.setRequestProperty(key, heads.get(key));
                }
            }

            // 得到请求的输出流对象
            out = connection.getOutputStream();
            // 把数据写入请求的Body
            if (StringUtils.isNotBlank(param)) {
                out.write(param.getBytes());
            }
            out.flush();
            // 定义BufferedReader输入流来读取URL的响应
            in = new BufferedReader(new InputStreamReader(connection.getInputStream()));
            String line;
            while ((line = in.readLine()) != null) {
                result.append(line);
            }
            return result.toString();
        } catch (IOException e) {
            log.error(url + " http请求错误 " + e.getMessage(), e);
            if (connection != null) {
                try {
                    in = new BufferedReader(new InputStreamReader(connection.getErrorStream()));
                    String line;
                    while ((line = in.readLine()) != null) {
                        result.append(line);
                    }
                } catch (Exception e1) {
                    //log.error(url + " http请求错误1 " + e1.getMessage(), e1);
                }
            }
        } catch (Exception e) {
            log.error(url + " http请求错误 " + e.getMessage(), e);
        }
        // 使用finally块来关闭输出流、输入流
        finally {
            IOUtils.close(in);
            IOUtils.close(out);
            IOUtils.close(connection);
        }
        return null;
    }

    public static String sendPostSession(String urlPath, String json) {
        if (StringUtils.isBlank(urlPath)) {
            return null;
        }
        if (urlPath.startsWith("https")) {
            return HttpsUtils.sendPostSession(urlPath, json);
        }
        OutputStream out = null;
        BufferedReader in = null;
        StringBuilder result = new StringBuilder();
        HttpURLConnection urlConnection = null;
        try {
            try {
                log.info("sendPost - " + urlPath + ",JSON参数：" + URLDecoder.decode(json));
            } catch (Exception ignored) {

            }
            URL url = new URL(urlPath);
            urlConnection = (HttpURLConnection) url.openConnection();
            // 设置doOutput属性为true表示将使用此urlConnection写入数据
            urlConnection.setDoOutput(true);
            urlConnection.setRequestMethod("POST");
            // 定义待写入数据的内容类型，我们设置为application/x-www-form-urlencoded类型
            urlConnection.setRequestProperty("accept", "*/*");
            urlConnection.setRequestProperty("Connection", "Keep-Alive");
            urlConnection.setRequestProperty("Charset", "UTF-8");
            urlConnection.setRequestProperty("Content-Type", "application/x-www-form-urlencoded; charset=UTF-8");
            urlConnection.setConnectTimeout(CONN_TIME_OUT);
            urlConnection.setReadTimeout(READ_TIME_OUT);

            // 得到请求的输出流对象
            out = urlConnection.getOutputStream();
            // 把数据写入请求的Body
            if (StringUtils.isNotBlank(json)) {
                out.write(json.getBytes());
            }
            out.flush();
            // 定义BufferedReader输入流来读取URL的响应
            in = new BufferedReader(new InputStreamReader(urlConnection.getInputStream()));
            String line;
            while ((line = in.readLine()) != null) {
                result.append(line);
            }
            return result.toString();
        } catch (Exception e) {
            log.error(urlPath + " -- " + e.getMessage(), e);
        }
        // 使用finally块来关闭输出流、输入流
        finally {
            IOUtils.close(in);
            IOUtils.close(out);
            IOUtils.close(urlConnection);
        }
        return "";
    }

    public static String curlPost(String apiUrl, String jsonStr) {
        String cmd =  "curl -i -k --request POST" + " --url " + apiUrl +
                " --header 'content-type: application/json'" +
                " --data" +
                " '" +
                jsonStr +
                " '";

        return LvmengUtils.execCurl(cmd);
    }
}
