package com.crc.common.utils;

import com.alibaba.fastjson.JSON;
import lombok.extern.slf4j.Slf4j;

import javax.crypto.Mac;
import javax.crypto.spec.SecretKeySpec;
import java.util.*;

/**
 * @Description: 第三方签名工具类（RSA算法）
 * @author:Wangjf
 * @Date: Created in 9:36 2019/3/20
 */
@Slf4j
public class SafedogThirdSignUtils {

    /**
     * 签名算法
     */
    public static final String HMACSHA1 = "HmacSHA1";
    public static final String HMACSHA128 = "HmacSHA128";
    public static final String HMACSHA256 = "HmacSHA256";

    /**
     * 字符编码
     */
    public static final String CHARSETNAME_UTF_8 = "UTF-8";
    public static final String CHARSETNAME_GBK = "GBK";

    public static final int DEFAULT_LENGTH = 11;

    /**
     * length表示生成字符串的长度
     */
    private static final String BASE = "abcdefghijklmnopqrstuvwxyz0123456789";
    public static final String SIGN_VERSION = "signVersion";

    // 第三方通讯数据标识
    public static final String THIRD_DATA = "data";
    public static final String THIRD_APPID = "appid";
    public static final String THIRD_TIME = "time";
    public static final String THIRD_SIGN = "sign";

    /**
     * 签名sign
     * 
     * @param param     参与加密的参数
     * @param key       加密密钥
     * @param algorithm 算法
     * @param charSet   字符编码
     * @return
     */
    @SuppressWarnings("unchecked")
    public static String createSign(Map<String, Object> param, String key, String algorithm, String charSet) {
        // 签名步骤一：按字典排序参数
        List list = new ArrayList(param.keySet());
        Object[] ary = list.toArray();
        Arrays.sort(ary);
        list = Arrays.asList(ary);
        StringBuilder str = new StringBuilder();
        String signVersion = (String) param.get(SIGN_VERSION);
        if (Objects.isNull(signVersion)) {
            return "signVersion is empty";
        }
        for (int i = 0; i < list.size(); i++) {
            str.append(list.get(i)).append("=").append(JSON.toJSONString(param.get(list.get(i)))).append("&");
        }
        // }
        // 签名步骤二：加上key
        str.append("key=").append(key);
        // 步骤三：使用RSA加密规则加密,算法为algorithm传入的参数
        return encode(str.toString(), key, algorithm, charSet);
    }

    /**
     * 进行签名
     *
     * @param message
     * @return
     */
    public static String encode(String message, String secretkey, String algorithm, String charSet) {
        byte[] hash;
        try {
            Mac shaHMAC = Mac.getInstance(algorithm);
            SecretKeySpec secretKeySpec = new SecretKeySpec(
                    secretkey.getBytes(charSet), algorithm);
            shaHMAC.init(secretKeySpec);
            hash = shaHMAC.doFinal(message.getBytes(charSet));
        }  catch (Exception e) {
            log.error(e.getMessage(),e);
            return null;
        }
        return byteArrayToHexString(hash);
    }

    private static String byteArrayToHexString(byte[] b) {
        StringBuilder resultSb = new StringBuilder();
        for (byte value : b) {
            resultSb.append(byteToHexString(value));
        }
        return resultSb.toString();
    }

    private static String byteToHexString(byte b) {
        int n = b;
        if (n < 0) {
            n += 256;
        }
        int d1 = (n >>> 4) & 0X0f;
        int d2 = n & 0X0F;
        return hexDigits[d1] + hexDigits[d2];
    }

    /**
     * 获取指定才长度的随机字符串(signKey)
     *
     * @param length
     * @return
     */
    public static String getRandomString(Integer length) {
        Random random = new Random();
        StringBuilder sb = new StringBuilder();
        for (int i = 0; i < length; i++) {
            int number = random.nextInt(BASE.length());
            sb.append(BASE.charAt(number));
        }
        return sb.toString();
    }

    private static final String[] hexDigits = { "0", "1", "2", "3", "4", "5",
            "6", "7", "8", "9", "a", "b", "c", "d", "e", "f" };

}
