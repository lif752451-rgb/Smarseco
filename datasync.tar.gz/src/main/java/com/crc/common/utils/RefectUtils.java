package com.crc.common.utils;

import lombok.extern.slf4j.Slf4j;

import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.math.BigDecimal;
import java.sql.Timestamp;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.ZoneId;
import java.time.format.DateTimeFormatter;
import java.util.Date;
import java.util.Map;
@Slf4j
public class RefectUtils {
    /**
     * set bean field value by value map
     * @param bean java bean
     * @param valueMap value map K:field V:value
     */
    public static void setBeanFieldValue(Object bean, Map<String, String> valueMap) {
        Class<?> beanClass = bean.getClass();
        Method[] methods = beanClass.getDeclaredMethods();
        Field[] fields = beanClass.getDeclaredFields();
        for (Field field : fields) {
            try {
                String fieldSetName = spliceSetMethod(field.getName());
                if (!checkPropertyMethodExist(methods, fieldSetName)) continue;
                Method fieldSetMet = beanClass.getMethod(fieldSetName, field.getType());
                String value = valueMap.get(field.getName());
                if (value == null) {
                    continue;
                }
                fieldSetMet.invoke(bean, getFieldTypeValue(field, value));
            } catch (Exception e) {
                log.error("set bean value error" + field, e);
            }
        }
    }

    /**
     * return the corresponding type value according to the field property
     * @param field the field
     * @param value original value
     * @return corresponding type value
     */
    public static Object getFieldTypeValue(Field field, Object value){
        if(null == field || null == value || "".equals(value)) return null;
        String fieldType = field.getType().getSimpleName();
        if ("String".equals(fieldType)) return String.valueOf(value);
        if ("Date".equals(fieldType)) {
            if (String.valueOf(value).indexOf(':') > 0) return Date.from(LocalDateTime.parse(String.valueOf(value), DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss")).atZone(ZoneId.systemDefault()).toInstant());
            return Date.from(LocalDate.parse(String.valueOf(value), DateTimeFormatter.ofPattern("yyyy-MM-dd")).atStartOfDay(ZoneId.systemDefault()).toInstant());
        }
        if ("Integer".equals(fieldType) || "int".equals(fieldType)) return Integer.parseInt(String.valueOf(value));
        if ("Long".equalsIgnoreCase(fieldType)) return Long.parseLong(String.valueOf(value));
        if ("Float".equalsIgnoreCase(fieldType)) return Float.parseFloat(String.valueOf(value));
        if ("Double".equalsIgnoreCase(fieldType)) return Double.parseDouble(String.valueOf(value));
        if ("Short".equalsIgnoreCase(fieldType)) return Short.parseShort(String.valueOf(value));
        if ("Byte".equalsIgnoreCase(fieldType)) return Byte.parseByte(String.valueOf(value));
        if ("BigDecimal".equalsIgnoreCase(fieldType)) return new BigDecimal(String.valueOf(value));
        if ("Character".equals(fieldType) || "char".equals(fieldType)) return String.valueOf(value).charAt(0);
        if ("Boolean".equalsIgnoreCase(fieldType)) return Boolean.parseBoolean(String.valueOf(value));
        if ("TimeStamp".equalsIgnoreCase(fieldType)) return new Timestamp(Long.valueOf(String.valueOf(value)));
        return value;
    }

    /**
     * judge whether it exists method of a property
     * @param methods object property method list
     * @param fieldMethod get or set method
     * @return true: exist, false: not exist
     */
    public static boolean checkPropertyMethodExist(Method[] methods, String fieldMethod) {
        if(null == fieldMethod || "".equals(fieldMethod)) return false;
        for (Method met : methods) {
            if (fieldMethod.equals(met.getName())) return true;
        }
        return false;
    }

    /**
     * splicing property get or set methods
     * @param fieldName property name
     * @param method get or set method
     * @return methods after splicing
     */
    public static String splicePropertyMethod(String fieldName, String method) {
        if (null == fieldName || "".equals(fieldName)) return null;
        return method + fieldName.substring(0, 1).toUpperCase() + fieldName.substring(1);
    }

    /**
     * splicing property get method
     * @param fieldName property
     * @return get method after splicing
     */
    public static String spliceGetMethod(String fieldName) {
        return splicePropertyMethod(fieldName, "get");
    }

    /**
     * splicing property set method
     * @param fieldName property
     * @return set method after splicing
     */
    public static String spliceSetMethod(String fieldName) {
        return splicePropertyMethod(fieldName, "set");
    }
}
