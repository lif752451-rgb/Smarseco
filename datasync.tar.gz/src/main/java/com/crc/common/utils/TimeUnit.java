package com.crc.common.utils;

/**
 * @author simba@onlying.cn
 * @date 2020/8/3 16:23
 */
public enum TimeUnit {
    LAST_MINUTES("1","最近几分钟","resolveTimeByMinusMinutes"),
    LAST_HOURS("2","最近几小时","resolveTimeByMinusHours"),
    LAST_DAYS("3","最近一天","resolveTimeByMinusDays");

    private final String type;

    private final String interval;

    private final String func;

    TimeUnit(String type, String interval, String func){
        this.type = type;
        this.interval = interval;
        this.func = func;
    }

  public static TimeUnit resolveByType(String type){
        for(TimeUnit timeUnit: TimeUnit.values()){
            if(timeUnit.getType().equalsIgnoreCase(type)){
                return timeUnit;
            }
        }
        return null;
  }




    public String getType() {
        return type;
    }

    public String getInterval() {
        return interval;
    }

    public String getFunc() {
        return func;
    }

}
