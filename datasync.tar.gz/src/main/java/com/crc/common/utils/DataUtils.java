package com.crc.common.utils;


import cn.hutool.core.io.IoUtil;
import cn.hutool.core.util.ReflectUtil;
import cn.hutool.core.util.StrUtil;
import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;
import com.crc.common.constants.Constants;
import com.crc.secface.domain.SysDictData;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.apache.http.HttpEntity;
import org.apache.http.util.CharArrayBuffer;

import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.Reader;
import java.lang.reflect.Field;
import java.math.BigDecimal;
import java.math.BigInteger;
import java.nio.charset.Charset;
import java.nio.charset.StandardCharsets;
import java.security.SecureRandom;
import java.sql.ResultSet;
import java.text.SimpleDateFormat;
import java.time.LocalDateTime;
import java.time.ZoneId;
import java.util.*;
import java.util.concurrent.atomic.AtomicReference;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

@Slf4j
public class DataUtils {

    public static String toBodyString(HttpEntity entity, Charset charset) {
        if (entity == null) {
            return "";
        }
        Reader reader = null;
        try (InputStream inStream = entity.getContent()) {
            if (inStream == null) {
                return null;
            }
            reader = new InputStreamReader(inStream, charset);
            CharArrayBuffer buffer = new CharArrayBuffer(100);
            char[] tmp = new char[1024];
            int l;
            while ((l = reader.read(tmp)) != -1) {
                buffer.append(tmp, 0, l);
            }
            return buffer.toString();
        } catch (Exception e) {
            log.error(e.getMessage(), e);
        } finally {
            IoUtil.close(reader);
        }
        //获取一个含有实体信息的流
        return "";

    }

    public static String toBodyString(HttpEntity entity) {
        return toBodyString(entity, StandardCharsets.UTF_8);
    }

    /**
     * 比较 startIp2long<=ip2long && ip2long <=e
     *
     * @param startIp2long 开始 IP
     * @param ip2long      当前 IP
     * @param endIp2long   结束 IP
     * @return t/f
     */
    public static boolean isIpInSegment(BigInteger startIp2long, BigInteger ip2long, BigInteger endIp2long) {
        BigInteger a0 = new BigInteger("0");
        try {
            if (startIp2long == null || ip2long == null || endIp2long == null) {
                return false;
            }
            if (startIp2long.compareTo(a0) > 0 && compareBigInt(ip2long, startIp2long) > -1 && compareBigInt(endIp2long, ip2long) > -1) {
                return true;
            }
        } catch (Exception e) {
            log.error(e.getMessage(), e);
        }
        return false;
    }

    public static boolean bigTo0(BigInteger m1) {
        if (m1 == null) {
            return false;
        }
        try {
            BigInteger a0 = BigInteger.valueOf(0);
            return m1.compareTo(a0) > 0;
        } catch (Exception e) {
            return false;
        }

    }


    public static int compareBigInt(BigInteger m1, BigInteger m2) {
        if (m1 == null || m2 == null) {
            return -2;
        }
        try {
            BigInteger a0 = BigInteger.valueOf(0);
            if (m1.compareTo(a0) > 0 && m2.compareTo(a0) > 0) {
                return m1.compareTo(m2);//小于-1，等于0，大于 1
            } else {
                return -3;
            }
        } catch (Exception e) {
            return -4;
        }

    }

    /**
     * 字符长度不能超过指定长度
     *
     * @param str
     * @param maxLen 最小不能小于10
     * @return
     */
    public static String getShorter(String str, int maxLen) {
        try {
            if (StringUtils.isBlank(str) || maxLen < 10) {
                return str;
            }
            if (str.length() <= maxLen) {
                return str;
            }
            return str.substring(0, maxLen) + "...";
        } catch (Exception ignored) {

        }
        return str;
    }

    public static String hidePsw(String jsonObject) {
        if (jsonObject == null) {
            return "";
        }
        return jsonObject.replace("password", "simple_code").replace("pass", "my_code");
    }

    public static String hidePsw(Map jsonObject) {
        if (jsonObject == null) {
            return "";
        }
        return JSON.toJSONString(jsonObject).replace("password", "simple_code");
    }

    public static String hidePsw(JSONObject jsonObject) {
        if (jsonObject == null) {
            return "";
        }
        return jsonObject.toJSONString().replace("password", "simple_code").replace("pass", "my_code");
    }

    //超长字符串，多余的文字用省略号表示
    public static String processStr(String params, int size) {
        if (params == null) {
            return "";
        }
        if (size < 1) {
            return "";
        }
        if (size > params.length()) {
            return params;
        }
        if (params.length() > size) {
            params = params.substring(0, size - 3) + "...";
        }
        return params;
    }

    /**
     * 字符串只保留数字、字母、中文
     *
     * @param str
     * @return
     */
    public static String cleanStr(String str) {
        if (StringUtils.isEmpty(str)) {
            return str;
        }
        return str.replaceAll("[^0-9a-zA-Z\u4e00-\u9fa5]", "");
    }

    public static String getPercent00(int target, int total) {
        if (total < 1) {
            return "0";
        }
        double perTarget = (target * 100 * 1.0) / total;
        BigDecimal bd = new BigDecimal(perTarget);
        bd = bd.setScale(2, BigDecimal.ROUND_HALF_UP);
        return bd.toString();
    }

    public static String[] getSplit(String str, String symbol) {
        String[] split = {};
        if (StringUtils.isNotBlank(str) && symbol != null) {
            split = str.split(symbol);
        }
        return split;
    }

    /*
      判断数字是否在目标范围之内
     */
    public static boolean dataIn(int src, int... dest) {
        if (dest != null) {
            for (int d : dest) {
                if (src == d) {
                    return true;
                }
            }
        }
        return false;
    }

    /*
      判断数字是否在目标范围之内
     */
    public static boolean dataIn(String src, int... dest) {
        return dataIn(toInt(src), dest);
    }

    public static int roundUp(int size, int total) {
        if (size < 1) {
            return 0;
        }
        int x = (int) (total * 1.0 / size);
        if ((size * x) < total) {
            x = x + 1;
        }
        return x;
    }

    public static int getPercent(long x, long y) {
        if (y < 1) {
            return 0;
        }
        double f = x * 100.0 / y;
        return (int) f;
    }

    public static int getPercent(int x, int y) {
        if (y < 1) {
            return 0;
        }
        double f = x * 100.0 / y;
        return (int) f;
    }

    /**
     * 按字母排序
     *
     * @param str 原始请求参数
     * @return 结果
     */
    public static String parseParam(String str) {
        if (StringUtils.isBlank(str)) {
            return str;
        }
        Map<String, String> map = new TreeMap<String, String>(
                Comparator.naturalOrder());
        if (StringUtils.isBlank(str)) return "";
        Arrays.stream(str.split("&"))
                .filter(kv -> kv.contains("="))
                .map(kv -> kv.split("="))
                .forEach(array -> {
                    //map.put(array[0], array[1]);
                    if (array.length < 2) {
                        map.put(array[0], "");
                    } else {
                        map.put(array[0], array[1]);
                    }
                });
        AtomicReference<String> ret = new AtomicReference<>("");
        map.forEach((k, v) -> {
            if (StringUtils.isBlank(ret.get())) {
                ret.set(k + "=" + v);
            } else {
                ret.set(ret.get() + "&" + k + "=" + v);
            }
        });

        return ret.get();
    }


    /**
     * @param d1：分子；
     * @param zs：分母；
     * @param dot：要保留的小数
     * @return double
     * 计算百分比
     */
    public static double percentage(double d1, double zs, int dot) {
        double bs = Math.pow(10.0, toDouble(dot + 2));
        double cs = Math.pow(10.0, toDouble(dot));
        double num = 0.0;
        if (zs > 0) {
            num = Math.floor(d1 * bs / zs) / cs;
        }
        return num;
    }

    public static double toDouble(Object value) {
        if (null == value) {
            return 0;
        }
        try {
            return Double.parseDouble(value.toString());
        } catch (Exception ignored) {

        }
        return 0;
    }

    /**
     * 获取字符串的长度，如果有中文，则每个中文字符计为2位
     *
     * @param value 指定的字符串
     * @return 字符串的长度
     */
    public static int length(String value) {
        if (StringUtils.isBlank(value)) {
            return 0;
        }
        int valueLength = 0;
        String chinese = "[\u0391-\uFFE5]";
        /* 获取字段值的长度，如果含中文字符，则每个中文字符长度为2，否则为1 */
        for (int i = 0; i < value.length(); i++) {
            /* 获取一个字符 */
            String temp = value.substring(i, i + 1);
            /* 判断是否为中文字符 */
            if (temp.matches(chinese)) {
                /* 中文字符长度为2 */
                valueLength += 2;
            } else {
                /* 其他字符长度为1 */
                valueLength += 1;
            }
        }
        return valueLength;
    }

    public static int length2(String value) {
        if (StringUtils.isBlank(value)) {
            return 0;
        }
        return value.length();
    }

    public static final char UNDERLINE = '_';

    /**
     * 驼峰格式字符串转换为下划线格式字符串
     *
     * @param param
     * @return
     */
    public static String humpToLine(String param) {
        if (param == null || "".equals(param.trim())) {
            return "";
        }
        int len = param.length();
        StringBuilder sb = new StringBuilder(len);
        for (int i = 0; i < len; i++) {
            char c = param.charAt(i);
            if (Character.isUpperCase(c)) {
                sb.append(UNDERLINE);
                sb.append(Character.toLowerCase(c));
            } else {
                sb.append(c);
            }
        }
        return sb.toString();
    }

    /**
     * 根据树路径获取对应节点
     *
     * @param str
     * @param level
     * @return
     */
    public static String getDeptTree(String str, int level) {
        if (StringUtils.isBlank(str)) {
            return str;
        } else {
            String[] tree = str.split("/");
            if (level < 2) {
                return tree[0];
            }
            return getArrayString(tree, level - 1);
        }
    }

    public static String encode(String string) {
        if (StringUtils.isBlank(string)) {
            return "";
        }
        try {
            string = string.replace(" ", "");
        } catch (Exception e) {
            log.error(e.getMessage(), e);
        }
        return string;
    }

    public static String getArrayString(String[] arr, int index) {
        if (arr == null || index < 0 || (arr.length - 1) < index)
            return getArrayString(arr, index - 1);

        return arr[index];
    }

    public static int getIndex(String str, String c) {
        int index = -1;
        if (StringUtils.isNotBlank(str) && c != null) {
            index = str.indexOf(c);
        }
        return index;
    }

    public static int getLastIndex(String str, String c) {
        int index = -1;
        if (StringUtils.isNotBlank(str) && c != null) {
            index = str.lastIndexOf(c);
        }
        return index;
    }

    public static String getSubString(String string, int first) {
        if (StringUtils.isBlank(string)) {
            return "";
        }
        if (string.length() < first) {
            return "";
        }
        if (first < 0) {
            return "";
        }
        return string.substring(first);
    }

    public static boolean equalsAny(Long src, Long... dest) {
        for (Long d : dest) {
            if (Objects.equals(src, d)) {
                return true;
            }
        }

        return false;
    }

    public static boolean equalsAny(String src, String... dest) {
        for (String d : dest) {
            if (Objects.equals(src, d)) {
                return true;
            }
        }

        return false;
    }


    public static String getString(JSONObject json, String filter) {
        if (json == null || StringUtils.isBlank(filter))
            return "";

        if (json.get(filter) == null) {
            return "";
        }

        try {
            String retStr = json.getString(filter);
            if (StringUtils.isNotBlank(retStr)) {
                if ("null".equalsIgnoreCase(retStr)) {
                    return "";
                }
                if ("-".equalsIgnoreCase(retStr)) {
                    return "";
                }
                return retStr.trim();
            }
        } catch (Exception ignored) {

        }

        try {
            String retStr = json.get(filter).toString();
            if (StringUtils.isNotBlank(retStr)) {
                if ("null".equalsIgnoreCase(retStr)) {
                    return "";
                }
                if ("-".equalsIgnoreCase(retStr)) {
                    return "";
                }
                return retStr.trim();
            }
        } catch (Exception ignored) {

        }
        return "";
    }

    public static String getString(Map map, String filter) {
        if (StringUtils.isNotBlank(filter) && map != null) {
            Object o = map.get(filter);
            if (o != null && !"null".equals(o.toString())) {
                return o.toString();
            }
        }
        return "";
    }

    public static long getLong(Map map, String filter) {
        if (StringUtils.isNotBlank(filter) && map != null) {
            Object o = map.get(filter);
            if (o != null) {
                try {
                    return Long.parseLong(o.toString());
                } catch (Exception ignored) {

                }
                return 0;
            }
        }
        return 0;
    }

    public static Date fromISODate(String time) {
        if (!time.matches("\\d{4}-\\d{2}-\\d{2}T\\d{2}:\\d{2}:\\d{2}.\\d{3}Z")) {
            return null;
        }
        time = time.replaceFirst("T", " ").replaceFirst(".\\d{3}Z", "");
        Date date = formatDate(time);
        if (date == null) {
            return null;
        }
        // 1、取得本地时间：
        Calendar cal = Calendar.getInstance();
        cal.setTime(date);

        // 2、取得时间偏移量：
        int zoneOffset = cal.get(Calendar.ZONE_OFFSET);
        // 3、取得夏令时差：
        int dstOffset = cal.get(Calendar.DST_OFFSET);
        // 4、从本地时间里扣除这些差量，即可以取得UTC时间：
        cal.add(Calendar.MILLISECOND, (zoneOffset + dstOffset));
        return cal.getTime();
    }

    public static Date formatDate(String time) {
        SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
        try {
            return sdf.parse(time);
        } catch (Exception e) {
            return null;
        }
    }

    public static Date getDate(Map<String, String> object, String alarm_time) {
        String datestr = getString(object, alarm_time);
        if (datestr.contains("T")) {
            //2021-01-08T05:59:49.000Z
            return fromISODate(datestr);
        }
        Date date = null;
        if (StringUtils.isEmpty(datestr)) {
            date = new Date();
            return date;
        }
        SimpleDateFormat sdf = new SimpleDateFormat(DateUtils.DATE_FORMAT_STRING1);
        try {
            date = sdf.parse(datestr);
        } catch (Exception e) {
            log.error(e.getMessage(), e);
        }
        return date;
    }

    public static String getStr(HashMap<String, Object> rs, String groupKeys2) {
        if (StringUtils.isBlank(groupKeys2) || rs == null)
            return "";
        try {
            Object obj = rs.get(groupKeys2);
            if (obj != null)
                return obj.toString();
        } catch (Exception ignored) {

        }
        return "";
    }

    public static String getStr(JSONObject json, String groupKeys2) {
        return getString(json, groupKeys2);
    }

    public static String getSubString(String string, int first, int end) {
        if (end <= first) {
            return "";
        }
        if (StringUtils.isBlank(string)) {
            return "";
        }
        if (string.length() < end) {
            end = string.length();
        }
        if (first < 0) {
            return "";
        }
        return string.substring(first, end);
    }

    public static int getInt(String str) {
        if (StringUtils.isBlank(str)) {
            return 0;
        }
        if (!isInteger(str)) {
            return 0;
        }
        try {
            return Integer.parseInt(str);
        } catch (Exception ignored) {

        }
        return 0;
    }

    public static int getInt(HashMap<String, Object> rs, String groupKeys2) {
        if (StringUtils.isBlank(groupKeys2) || rs == null)
            return 0;
        try {
            Object obj = rs.get(groupKeys2);
            if (obj != null) {
                if (!isInteger(obj.toString())) {
                    return 0;
                }
                return Integer.parseInt(obj.toString());
            }
        } catch (Exception ignored) {

        }
        return 0;
    }


    public static String getStr(ResultSet rs, String groupKeys2) {
        if (StringUtils.isBlank(groupKeys2) || rs == null)
            return "";
        try {
            return rs.getString(groupKeys2);
        } catch (Exception ignored) {

        }
        return "";
    }

    public static String getInt(JSONObject rs, String count) {
        if (StringUtils.isBlank(count) || rs == null)
            return "0";
        try {
            return rs.getString(count);
        } catch (Exception ignored) {

        }
        return "0";
    }

    public static String getInt(ResultSet rs, String count) {
        if (StringUtils.isBlank(count) || rs == null)
            return "0";
        try {
            return rs.getInt(count) + "";
        } catch (Exception ignored) {

        }
        return "0";
    }

    public static double getDouble(String count) {
        try {
            return Double.parseDouble(count);
        } catch (Exception ignored) {

        }
        return 0;
    }

    public static Long toLong(String count) {
        if (!isInteger(count)) {
            return 0L;
        }
        try {
            return Long.parseLong(count);
        } catch (Exception ignored) {

        }
        return -1L;
    }

    public static Long toLongX(String count) {
        if (!isInteger(count)) {
            return 0L;
        }
        try {
            count = getPureNumber(count);
            return Long.parseLong(count);
        } catch (Exception e) {
            log.error(e.getMessage(), e);
        }
        return -1L;
    }

    public static String getPureNumber(String str) {
        if (str == null) {
            return "";
        }
        StringBuilder sb = new StringBuilder();
        for (int i = 0; i < str.length(); i++) {
            if (str.charAt(i) >= '0' && str.charAt(i) <= '9') {
                sb.append(str.charAt(i));
            }
        }
        return sb.toString();
    }

    public static int toInt(Object count) {
        if (count == null) {
            return 0;
        }
        try {
            return toInt(count.toString());
        } catch (Exception ignored) {

        }
        return 0;
    }

    public static int toInt(String count) {
        if (!isInteger(count)) {
            if (count != null && count.contains(".")) {
                return (int) toDouble(count);
            }
            return 0;
        }
        try {
            return Integer.parseInt(count);
        } catch (Exception ignored) {

        }
        return 0;
    }

    public static int toInt(String count, int def) {
        int v = toInt(count);
        if (v == 0) {
            return def;
        }
        return v;
    }

    /***
     * 判断 String 是否是 int
     *
     * @param str
     * @return
     */
    public static boolean isInteger(String str) {
        if (StringUtils.isBlank(str)) {
            //log.debug("空内容为非数字");
            return false;
        }
        Pattern pattern = Pattern.compile("^[-\\+]?[\\d]*$");
        //log.debug("内容：{},为非数字", str);
        return pattern.matcher(str).matches();
    }

    public static String unicodeToString(String str) {
        Pattern pattern = Pattern.compile("(\\\\u(\\p{XDigit}{4}))");
        Matcher matcher = pattern.matcher(str);
        char ch;
        while (matcher.find()) {
            ch = (char) Integer.parseInt(matcher.group(2), 16);
            str = str.replace(matcher.group(1), String.valueOf(ch));
        }
        return str;
    }

    public static List<String> singleToList(String str) {
        if (StringUtils.isBlank(str))
            return new LinkedList<>();
        List<String> dataList = new LinkedList<>();
        dataList.add(str);
        return dataList;
    }

    public static List<JSONObject> singleToList(JSONObject str) {
        if (str != null)
            return new LinkedList<>();
        List<JSONObject> dataList = new LinkedList<>();
        dataList.add(str);
        return dataList;
    }

    public static String getStrX(Object obj) {
        if (obj == null) {
            return "";
        }
        try {
            if (obj instanceof LocalDateTime) {
                //return DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss").format((LocalDateTime)obj);
                LocalDateTime localDateTime = (LocalDateTime) obj;
                return DateUtils.getDateTimeString1(Date.from(localDateTime.atZone(ZoneId.systemDefault()).toInstant()));
            } else if (obj instanceof Date) {
                return DateUtils.getDateTimeString1((Date) obj);
            } else {
                return obj.toString();
            }
        } catch (Exception ignored) {

        }

        return "";
    }

    public static String[] getIpAndPort(String url) {
        if (StringUtils.isBlank(url)) {
            return new String[]{};
        }
        String host = StrUtil.sub(url, url.indexOf("//") + 2, url.lastIndexOf("/"));
        return host.split(":");
    }

    public static String toLongXX(Long affiliationDeptNodeId) {
        if (affiliationDeptNodeId == null) {
            return "";
        }
        return affiliationDeptNodeId.toString();
    }

    /**
     * 实体类String类型 转换特殊字符 "&lt;"to"<" "&gt;"to">"
     *
     * @param t t
     */
    public static void convertSpecialChar(Object t) {
        Class<?> tClass = t.getClass();
        Field[] fields = ReflectUtil.getFields(tClass);
        Arrays.stream(fields).forEach(field -> {
            if (field.getGenericType().toString().equals("class java.lang.String")) {
                Object obj = ReflectUtil.getFieldValue(t, field);
                if (obj instanceof String) {
                    ReflectUtil.setFieldValue(t, field, convertSpecialChar(obj.toString()));
                }
            }
        });
    }

    /**
     * 转换特殊字符 "&lt;"to"<" "&gt;"to">"
     *
     * @param text
     * @return
     */
    public static String convertSpecialChar(String text) {
        String toStr = "";
        if (StringUtils.isNotEmpty(text)) {
            toStr = text.replaceAll(Constants.Symbol.LESS_THAN, Constants.Symbol.ENTITY_LESS_THAN)
                    .replaceAll(Constants.Symbol.GREATER_THAN, Constants.Symbol.ENTITY_GREATER_THAN);
        }
        return toStr;
    }

    public static int getRandomNumber(int range) {
        SecureRandom r = new SecureRandom();
        return r.nextInt(range);
    }

    /**
     * 获取页数总数
     *
     * @param total    总数
     * @param pageSize 每页数量
     * @return 总数
     */
    public static int getPageCount(int total, int pageSize, int from) {
        if (pageSize < 1) {
            return 0;
        }
        if (total < 1) {
            return 0;
        }
        return (int) (Math.ceil((double) total / pageSize) + 1 + from);
    }

    /**
     * 获取页数总数
     *
     * @param total    总数
     * @param pageSize 每页数量
     * @return 总数
     */
    public static int getPageCount(long total, int pageSize, int from) {
        if (pageSize < 1) {
            return 0;
        }
        if (total < 1) {
            return 0;
        }
        return (int) (Math.ceil((double) total / pageSize) + 1 + from);
    }

    public static String groupData(String name, String user) {
        if (StringUtils.isBlank(user) && StringUtils.isBlank(name)) {
            return "";
        }
        if (StringUtils.isNotBlank(name) && StringUtils.isNotBlank(user)) {
            return String.format("%s(%s)", name, user);
        } else if (StringUtils.isNotBlank(name)) {
            return name;
        } else {
            return user;
        }
    }

    /**
     * 合并数据内容
     *
     * @param symbol
     * @param objects
     * @return
     */
    public static String group(String symbol, Object... objects) {
        if (StringUtils.isBlank(symbol)) {
            symbol = " ";
        }
        if (objects == null) {
            return "";
        }
        StringBuilder sb = new StringBuilder();
        try {
            for (int i = 0; i < objects.length; i++) {
                Object obj = objects[i];
                if (obj != null) {
                    sb.append(obj);
                    if (i != objects.length - 1) {
                        sb.append(symbol);
                    }
                }
            }
        } catch (Exception e) {

        }
        if (sb.toString().endsWith(symbol)) {
            return sb.substring(0, sb.length() - 1);
        }
        return sb.toString();
    }

    public static String urlEncode(String str) {
        if (StringUtils.isBlank(str)) {
            return "";
        }
        cn.hutool.core.net.URLEncoder urlEncoder = new cn.hutool.core.net.URLEncoder();
        return urlEncoder.encode(str, StandardCharsets.UTF_8);
    }

    /**
     * 判断是否为空的字典
     *
     * @param dictData
     * @return
     */
    public static boolean isBlankDict(SysDictData dictData) {
        if (dictData == null) {
            return true;
        }
        return StringUtils.isBlank(dictData.getDictValue()) || dictData.getDictCode() == null;
    }

    public static boolean isNotEmpty(List<Object> ngConfList) {
        return ngConfList != null && ngConfList.size() >= 1;
    }


    public static boolean contains(String str, String key) {
        if (StringUtils.isBlank(str) || StringUtils.isBlank(key)) {
            return false;
        }
        return str.contains(key);
    }

    public static String unicodeToCn(String unicode) {
        try {
            if (StringUtils.isBlank(unicode)) {
                return "";
            }
            StringBuilder returnStr = new StringBuilder();
            /* 以 \ u 分割，因为java注释也能识别unicode，因此中间加了一个空格*/
            String[] strs = unicode.split("\\\\u");

            // 由于unicode字符串以 \ u 开头，因此分割出的第一个字符是""。
            for (String str : strs) {
                returnStr.append((char) Integer.valueOf(str, 16).intValue());
            }
            return returnStr.toString();
        } catch (Exception e) {
            return unicode;
        }
    }
}
