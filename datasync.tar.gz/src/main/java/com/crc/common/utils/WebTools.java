package com.crc.common.utils;

import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.apache.http.*;
import org.apache.http.client.HttpRequestRetryHandler;
import org.apache.http.client.config.RequestConfig;
import org.apache.http.client.entity.UrlEncodedFormEntity;
import org.apache.http.client.methods.CloseableHttpResponse;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.client.protocol.HttpClientContext;
import org.apache.http.conn.ConnectTimeoutException;
import org.apache.http.entity.StringEntity;
import org.apache.http.impl.client.CloseableHttpClient;
import org.apache.http.impl.client.HttpClients;
import org.apache.http.impl.conn.PoolingHttpClientConnectionManager;
import org.apache.http.message.BasicNameValuePair;
import org.apache.http.util.EntityUtils;

import javax.annotation.PostConstruct;
import java.io.IOException;
import java.io.InterruptedIOException;
import java.net.UnknownHostException;
import java.util.*;
import java.util.Map.Entry;

@Slf4j
public class WebTools {

    public static String KEY_STATUS_CODE = "statusCode";
    public static String KEY_CONTENT = "content";

    private static final int TIMEOUT = Integer.MAX_VALUE;

    private static WebTools webTools;  // 静态初使化当前类

    @PostConstruct
    public void init() {
        webTools = this;
    }



    private final static PoolingHttpClientConnectionManager poolConnManager = new PoolingHttpClientConnectionManager();  //连接池管理器
    //retry handler
    private final static HttpRequestRetryHandler httpRequestRetryHandler = (exception, executionCount, context) -> {
        if (executionCount >= 5) {
            return false;
        }
        if (exception instanceof NoHttpResponseException) {
            return true;
        }
        if (exception instanceof InterruptedIOException) {
            return false;
        }
        if (exception instanceof UnknownHostException) {
            return false;
        }
        if (exception instanceof ConnectTimeoutException) {
            return false;
        }
        HttpClientContext clientContext = HttpClientContext
                .adapt(context);
        HttpRequest request = clientContext.getRequest();

        return !(request instanceof HttpEntityEnclosingRequest);
    };

    static {   //类加载的时候 设置最大连接数 和 每个路由的最大连接数
        poolConnManager.setMaxTotal(2000);
        poolConnManager.setDefaultMaxPerRoute(1000);
    }


    /**
     * ########################### core code#######################
     * @return
     */
    private static CloseableHttpClient getCloseableHttpClient() {

        //设置超时时长
        RequestConfig config = RequestConfig.custom().setConnectTimeout(TIMEOUT * 1000).build();

        return HttpClients.custom()
                .setConnectionManager(poolConnManager)
                .setRetryHandler(httpRequestRetryHandler)
                .setDefaultRequestConfig(config)
                .build();
    }

    /**
     * buildResultMap
     *
     * @param response
     * @param entity
     * @return
     * @throws IOException
     */
    private static Map<String, Object> buildResultMap(CloseableHttpResponse response, HttpEntity entity) throws
            IOException {
        Map<String, Object> result;
        result = new HashMap<>(2);
        result.put(KEY_STATUS_CODE, response.getStatusLine().getStatusCode());  //status code
        if (entity != null) {
            result.put(KEY_CONTENT, DataUtils.toBodyString(entity)); //message content
        }
        return result;
    }

    public static String postRequest(String httpUrl, Map<String, Object> args) {

        CloseableHttpClient httpClient = getCloseableHttpClient();
        log.info("httpUrl:" + httpUrl);
        HttpPost httpPost = new HttpPost(httpUrl);
        RequestConfig requestConfig = RequestConfig.custom()
                .setConnectTimeout(45000).setConnectionRequestTimeout(45000)
                .setSocketTimeout(45000).build();
        httpPost.setConfig(requestConfig);
        CloseableHttpResponse response = null;
        try {

            //4、声明存放参数的List集合
            List<NameValuePair> params = new ArrayList<>();
            if (args == null) {
                args = new HashMap<>();
            }
            Set<Entry<String, Object>> entrySet = args.entrySet();
            for (Entry<String, Object> entry : entrySet) {
                if(entry.getValue()!=null) {
                    params.add(new BasicNameValuePair(entry.getKey(), String.valueOf(entry.getValue())));
                }else {
                    params.add(new BasicNameValuePair(entry.getKey(), null));
                }
            }
            //5、创建form表单对象
            UrlEncodedFormEntity formEntity = new UrlEncodedFormEntity(params, "utf-8");
            //6、把表单对象设置到httpPost中
            httpPost.setEntity(formEntity);

            response = httpClient.execute(httpPost);
            return DataUtils.toBodyString(response.getEntity());

        } catch (Exception e) {
            e.printStackTrace();
            return null;
        } finally {
            IOUtils.close(response);
            IOUtils.close(httpClient);
        }

    }

    public static int get(String httpUrl, Map<String, Object> args) {

        CloseableHttpClient httpClient = getCloseableHttpClient();
        log.info("httpUrl:" + httpUrl);
        HttpPost httpPost = new HttpPost(httpUrl);
        RequestConfig requestConfig = RequestConfig.custom()
                .setConnectTimeout(45000).setConnectionRequestTimeout(45000)
                .setSocketTimeout(45000).build();
        httpPost.setConfig(requestConfig);
        CloseableHttpResponse response = null;
        try {

            //4、声明存放参数的List集合
            List<NameValuePair> params = new ArrayList<>();
            if (args == null) {
                args = new HashMap<>();
            }
            Set<Entry<String, Object>> entrySet = args.entrySet();
            for (Entry<String, Object> entry : entrySet) {
                if(entry.getValue()!=null) {
                    params.add(new BasicNameValuePair(entry.getKey(), String.valueOf(entry.getValue())));
                }else {
                    params.add(new BasicNameValuePair(entry.getKey(), null));
                }
            }
            //5、创建form表单对象
            UrlEncodedFormEntity formEntity = new UrlEncodedFormEntity(params, "utf-8");
            //6、把表单对象设置到httpPost中
            httpPost.setEntity(formEntity);

            response = httpClient.execute(httpPost);
            return response.getStatusLine().getStatusCode();

        } catch (Exception e) {
            log.error("链接出错！" + httpUrl);
            log.error(e.getMessage(),e);
            return 500;
        } finally {
            IOUtils.close(response);
            IOUtils.close(httpClient);
        }
    }

    /**
     * send json by post method
     *
     * @param url
     * @param message
     * @return
     * @throws Exception
     */
    public static Map<String, Object> postJson(String url, String message) {

        Map<String, Object> result = null;
        CloseableHttpClient httpClient = getCloseableHttpClient();
        HttpPost httpPost = new HttpPost(url);
        RequestConfig requestConfig = RequestConfig.custom()
                .setConnectTimeout(45000).setConnectionRequestTimeout(45000)
                .setSocketTimeout(45000).build();
        httpPost.setConfig(requestConfig);
        CloseableHttpResponse response = null;
        try {

            httpPost.setHeader("Accept", "application/json;charset=UTF-8");
            httpPost.setHeader("Content-Type", "application/json");

            if (StringUtils.isBlank(message)) {
                message = "";
            }
            StringEntity stringEntity = new StringEntity(message);
            stringEntity.setContentType("application/json;charset=UTF-8");

            httpPost.setEntity(stringEntity);
            response = httpClient.execute(httpPost);
            HttpEntity entity = response.getEntity();
            result = buildResultMap(response, entity);

        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            IOUtils.close(response);
            IOUtils.close(httpClient);
        }
        return result;
    }
}
