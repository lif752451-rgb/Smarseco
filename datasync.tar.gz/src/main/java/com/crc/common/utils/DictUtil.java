package com.crc.common.utils;

import cn.hutool.core.util.ObjectUtil;
import cn.hutool.core.util.StrUtil;
import com.baomidou.mybatisplus.core.conditions.query.LambdaQueryWrapper;
import com.crc.secface.config.GetSpringBean;
import com.crc.secface.domain.SysDictData;
import com.crc.secface.mapper.SysDictDataMapper;
import org.apache.commons.lang3.StringUtils;
import org.springframework.util.CollectionUtils;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

/**
 * 数据字典工具类
 */
public class DictUtil {

    public static List<SysDictData> getDict(String dictType) {
        SysDictDataMapper sysDictDataService = GetSpringBean.getBean(SysDictDataMapper.class);
        LambdaQueryWrapper<SysDictData> query = new LambdaQueryWrapper<>();
        query.eq(SysDictData::getDictType, dictType);
        query.eq(SysDictData::getStatus, "0");
        if (sysDictDataService == null) {
            return new ArrayList<>();
        }
        return sysDictDataService.selectList(query);
    }

    public static List<SysDictData> getDictTypeAndValue(String dictType, String dictValue) {
        SysDictDataMapper sysDictDataService = GetSpringBean.getBean(SysDictDataMapper.class);
        LambdaQueryWrapper<SysDictData> query = new LambdaQueryWrapper<>();
        query.eq(SysDictData::getDictType, dictType);
        query.eq(SysDictData::getDictValue, dictValue);
        query.eq(SysDictData::getStatus, "0");
        if (sysDictDataService == null) {
            return new ArrayList<>();
        }
        return sysDictDataService.selectList(query);
    }

    public static SysDictData getDictTypeAndValueLabel(String dictType, String dictValue, String dictLabel) {
        SysDictDataMapper sysDictDataService = GetSpringBean.getBean(SysDictDataMapper.class);
        LambdaQueryWrapper<SysDictData> query = new LambdaQueryWrapper<>();
        query.eq(SysDictData::getDictType, dictType);
        query.eq(SysDictData::getDictValue, dictValue);
        query.eq(SysDictData::getDictLabel, dictLabel);
        query.eq(SysDictData::getStatus, "0");
        if (sysDictDataService == null) {
            return new SysDictData();
        }
        return sysDictDataService.selectOne(query);
    }

    /**
     * 获取数据字典(Map<value, label>)
     *
     * @param dictType 数据字典类型
     * @return map
     */
    public static Map<String, String> getMapValueLabel(String dictType) {
        List<SysDictData> dataList = getDict(dictType);
        if (dataList == null || dataList.size() < 1) {
            return null;
        }
        return dataList.stream().collect(Collectors.toMap(SysDictData::getDictValue, SysDictData::getDictLabel));
    }

    /**
     * 判断数据字典是否开启
     *
     * @param dictType  数据字典类型
     * @param dictValue 数据字典项value
     * @return true:字典启用 false:字典禁用
     */
    public static Boolean isEnable(String dictType, String dictValue) {
        SysDictData dict = getDictByValue(dictType, dictValue);
        if (ObjectUtil.isNull(dict) || StrUtil.isEmpty(dict.getDictValue())) {
            return Boolean.FALSE;
        }
        return Boolean.TRUE;
    }

    /**
     * 查询数据字典
     *
     * @param dictType  数据字典类型
     * @param dictValue 数据字典项value
     * @return SysDictData
     */
    public static SysDictData getDictByValue(String dictType, String dictValue) {
        List<SysDictData> dataList = getDict(dictType);
        if (dataList == null || dataList.size() < 1) {
            return null;
        }
        return dataList.stream().filter(vo -> vo.getDictValue().equals(dictValue)).findFirst().orElseGet(SysDictData::new);
    }

    public static SysDictData getDictByLabel(String dictType, String dictLabel) {
        List<SysDictData> dataList = getDict(dictType);
        if (dataList == null || dataList.size() < 1) {
            return null;
        }
        return dataList.stream().filter(vo -> vo.getDictLabel().equals(dictLabel)).findFirst().orElseGet(SysDictData::new);
    }


    /**
     * 获取数据字典remark
     *
     * @param dictType  数据字典类型
     * @param dictValue 数据字典项value
     * @return String
     */
    public static String getRemark(String dictType, String dictValue) {
        return getRemark(dictType, dictValue, null);
    }

    /**
     * 获取数据字典remark
     *
     * @param dictType     数据字典类型
     * @param dictValue    数据字典项value
     * @param defaultValue 默认值
     * @return String
     */
    public static String getRemark(String dictType, String dictValue, String defaultValue) {
        SysDictData dictData = getDictByValue(dictType, dictValue);
        if (ObjectUtil.isNull(dictData) || StrUtil.isEmpty(dictData.getRemark())) {
            return defaultValue;
        }
        return dictData.getRemark();
    }

    /**
     * 获取数据字典显示值dictLabel
     *
     * @param dictType  数据字典类型
     * @param dictValue 数据字典项value
     * @return String
     */
    public static String getDictLabel(String dictType, String dictValue) {
        Map<String, String> map = getMapValueLabel(dictType);
        if (map == null) {
            return "";
        }
        return map.get(dictValue);
    }

    /**
     * 获取数据字典显示值dictLabel
     *
     * @param dictType     数据字典类型
     * @param dictValue    数据字典项value
     * @param defaultValue 默认值
     * @return String
     */
    public static String getDictLabel(String dictType, String dictValue, String defaultValue) {
        Map<String, String> map = getMapValueLabel(dictType);
        if (map == null) {
            return defaultValue;
        }
        return map.getOrDefault(dictValue, defaultValue);
    }

    /**
     * 获取数据字典(Map<label, value>)
     *
     * @param dictType 数据字典类型
     * @return map
     */
    public static Map<String, String> getMapLabelValue(String dictType) {
        List<SysDictData> dataList = getDict(dictType);
        if (dataList == null || dataList.size() < 1) {
            return null;
        }
        return dataList.stream().collect(Collectors.toMap(SysDictData::getDictLabel, SysDictData::getDictValue));
    }

    /**
     * 获取数据字典项value
     *
     * @param dictType  数据字典类型
     * @param dictLabel 数据字典项Label
     * @return String
     */
    public static String getDictValue(String dictType, String dictLabel) {
        Map<String, String> map = getMapLabelValue(dictType);
        if (map == null) {
            return "";
        }
        return map.get(dictLabel);
    }

    public static String selectDictValueOrDefault(String dictType, String dictLabel, String defaultValue) {
        SysDictDataMapper sysDictDataService = GetSpringBean.getBean(SysDictDataMapper.class);
        LambdaQueryWrapper<SysDictData> query = new LambdaQueryWrapper<>();
        query.eq(SysDictData::getDictType, dictType);
        query.eq(SysDictData::getDictLabel, dictLabel);
        if (sysDictDataService == null) {
            return defaultValue;
        }
        List<SysDictData> dictDataList = sysDictDataService.selectList(query);
        if (CollectionUtils.isEmpty(dictDataList)) {
            return defaultValue;
        }
        return dictDataList.get(0).getDictValue();
    }

    public static void saveDict(SysDictData dict) {
        try {
            SysDictDataMapper sysDictDataService = GetSpringBean.getBean(SysDictDataMapper.class);
            sysDictDataService.insert(dict);
        } catch (Exception ignored) {

        }
    }


    /**
     * 数据字典取值 如果取不到默认取第一个数据字典
     *
     * @param dictList 数据字典结果集
     * @param label    数据字典显示值
     * @return 数据字典value值
     */
    public static String getDictDataValueOrDefault(List<SysDictData> dictList, String label) {
        if (dictList == null || dictList.size() < 1) {
            return null;
        }
        if (label == null) {
            label = "";
        }
        String finalLabel = label;
        return dictList.stream().filter(dict -> StringUtils.trim(finalLabel).equals(dict.getDictLabel()))
                .map(SysDictData::getDictValue).findFirst()
                .orElse(dictList.stream().map(SysDictData::getDictValue).findFirst().orElseGet(String::new));
    }
}
