package com.crc.common.utils;

import com.crc.common.enums.DatabaseEnums;
import com.crc.secface.config.GetSpringBean;
import lombok.extern.slf4j.Slf4j;
import org.springframework.core.env.Environment;

@Slf4j
public class VersionUtils {
    private static final int VERSION_LONG = 16;

    public static long getVersionValue(String version) {
        if (version == null || version.contains("。") || version.contains("，") ||
                version.contains(",") || version.contains(":")) {
            return 0L;
        }
        String newVersion = version.replace("-", ".").replace("_", ".");
        newVersion = newVersion.replaceAll("[a-zA-Z]", "0");
        String[] versions = newVersion.split("\\.");
        int index = VERSION_LONG;
        long totalVer = 0;
        int first = 1;
        for (String ver : versions) {
            int verInt = DataUtils.getInt(ver);
            if (verInt < 1 && first != 1) {
                verInt = 1;
            }
            int barboo = index - 2;
            totalVer += verInt * getBarboo(barboo);
            index = barboo;
            first++;
        }
        //System.out.println(version);
        return totalVer;
    }

    private static long getBarboo(int barboo) {
        long total = 1;
        for (int i = 0; i < barboo; i++) {
            total *= 10;
        }
        return total;
    }


    public static int getDatabase() {
        try {
            Environment env = GetSpringBean.getBean(Environment.class);
            String driverClassName = env.getProperty("spring.druid.driverClassName");
            if (driverClassName != null && driverClassName.contains("mysql")) {
                return DatabaseEnums.MYSQL.getCode();
            }else if (driverClassName != null && driverClassName.contains("DmDriver")) {
                return DatabaseEnums.DaMeng.getCode();
            }else if (driverClassName != null && driverClassName.contains("yashandb")) {
                return DatabaseEnums.YaShan.getCode();
            }
        } catch (Exception e) {
            log.info(e.getMessage(),e);
        }
        return DatabaseEnums.UNKOWN.getCode();
    }
}
