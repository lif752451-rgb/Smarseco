package com.crc.common.utils;

import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;

import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.*;


/**
 * @author simba@onlying.cn
 * @date 2020/7/23 10:30
 */
@Slf4j
public class DateUtils {

    public static final String DATE_TIME_FORMAT_STRING3 = "yyyy-MM-dd HH:mm:ss:SSS";
    public static final String DATE_TIME_FORMAT_STRING1 = "yyyy-MM-dd HH:mm:ss";
    public static final String YYYY_MM_DD_HH_MM_SS = "yyyy-MM-dd HH:mm:ss";

    public static final String DATE_TIME_FORMAT_STRING2 = "yyyy-MM-dd HH:mm";
    private static final DateUtils instance = new DateUtils();

    public static String ES_TIME_FORMAT = "yyyy-MM-dd'T'HH:mm:ss.SSSZ";
    public static String ES_TIME_FORMAT1 = "yyyy-MM-dd'T'HH:mm:ss";
    private static final String DATE_FORMAT_STRING5 = "yyyy.MM.dd";
    public static final String DATE_FORMAT_STRING6 = "MM.dd";
    public static final String DATE_FORMAT = "yyyy-MM-dd";
    private static final String DATE_FORMAT_HOUR = "yyyy-MM-dd HH";
    public static final String DATE_FORMAT_X = "yyyy年MM月";
    public static final String DATE_FORMAT_HOUR_MINUTE = "HH:mm";

    public static final String DATE_FORMAT_STRING1 = "yyyy-MM-dd HH:mm:ss";

    private static final String[] parsePatterns = {
            "yyyy-MM-dd", "yyyy-MM-dd HH:mm:ss", "yyyy-MM-dd HH:mm", "yyyy-MM",
            "yyyy/MM/dd", "yyyy/MM/dd HH:mm:ss", "yyyy/MM/dd HH:mm", "yyyy/MM",
            "yyyy.MM.dd", "yyyy.MM.dd HH:mm:ss", "yyyy.MM.dd HH:mm", "yyyy.MM"};
    public static String YYYYMMDD = "yyyyMMdd";

    public static String getDate1() {
        return dateTimeNow(YYYYMMDD);
    }

    public static long getInterval(String dateStr) {
        Date begin_date = parseDate(dateStr, "yyyy.MM.dd");
        Date end_date = new Date();
        try {
            return getInterval(begin_date, end_date);
        } catch (Exception e) {
        }
        return 0;
    }


    public static long getInterval(Date begin_date, Date end_date) throws Exception {
        long day = 0;
        SimpleDateFormat sdf = new SimpleDateFormat("yyyyMMdd");
        if (begin_date != null) {
            String begin = sdf.format(begin_date);
            begin_date = sdf.parse(begin);
        }
        if (end_date != null) {
            String end = sdf.format(end_date);
            end_date = sdf.parse(end);
        }
        day = (end_date.getTime() - begin_date.getTime()) / (24 * 60 * 60 * 1000);
        return day;
    }

    public static String dateTimeNow(final String format) {
        return parseDateToStr(format, new Date());
    }

    public static String parseDateToStr(final String format, final Date date) {
        if (date == null) {
            return "";
        }
        return new SimpleDateFormat(format).format(date);
    }

    /**
     * 根据日期字符串获取星期几
     *
     * @return String 周一
     */
    public static String getWeekStr() {
        String[] weekDays = {"周日", "周一", "周二", "周三", "周四", "周五", "周六"};
        Calendar calendar = Calendar.getInstance();
        return weekDays[calendar.get(Calendar.DAY_OF_WEEK) - 1];
    }

    public static long getDiffSec(Date startTime, Date endTime) {
        if (startTime == null || endTime == null) {
            return 0;
        }
        long diff = (endTime.getTime() - startTime.getTime()) / 1000;
        if (diff < 1) {
            diff = 0;
        }
        return diff;
    }

    /**
     * 获取日期格式 yyyy-MM-dd
     *
     * @return 根据天数返回日期
     */
    @SuppressWarnings("deprecation")
    public static String getDate(int day) {
        Date date = new Date();
        if (day != 0) {
            date.setDate(date.getDate() + day);
        }
        return new SimpleDateFormat("yyyy-MM-dd").format(date);
    }

    /**
     * 获取日期格式 yyyy-MM-dd
     *
     * @return 根据天数返回日期
     */
    @SuppressWarnings("deprecation")
    public static String getDateTimeStr(int day) {
        Date date = new Date();
        if (day != 0) {
            date.setDate(date.getDate() + day);
        }
        return new SimpleDateFormat(DATE_FORMAT_STRING1).format(date);
    }

    /**
     * 获取日期格式 yyyy.MM.dd
     *
     * @return 根据天数返回日期
     */
    @SuppressWarnings("deprecation")
    public static String getDate1(int day) {
        Date date = new Date();
        if (day != 0) {
            date.setDate(date.getDate() + day);
        }
        return new SimpleDateFormat("yyyy.MM.dd").format(date);
    }

    /**
     * 获取日期格式 yyyyMMdd
     *
     * @return 根据天数返回日期
     */
    @SuppressWarnings("deprecation")
    public static String getDateX(int day) {
        Date date = new Date();
        if (day != 0) {
            date.setDate(date.getDate() + day);
        }
        return new SimpleDateFormat("yyyyMMdd").format(date);
    }

    public static Date getDateTime(int day) {
        Date date = new Date();
        if (day != 0) {
            date.setDate(date.getDate() + day);
        }
        return date;
    }

    public static Date parseDateTime(String date) {
        if (StringUtils.isBlank(date)) {
            return new Date();
        }
        SimpleDateFormat format = new SimpleDateFormat(DATE_FORMAT_STRING1);
        try {
            return format.parse(date);
        } catch (ParseException e) {
            log.error(e.getMessage(), e);
        }
        return new Date();
    }

    public static Date parseDate(String dateTime, String pattern) {
        if (StringUtils.isBlank(dateTime)) {
            return new Date();
        }
        SimpleDateFormat format = new SimpleDateFormat(pattern);
        try {
            long timeLong = DataUtils.toLong(dateTime);
            if (timeLong > 1) {
                return new Date(timeLong);
            }
            return format.parse(dateTime);
        } catch (ParseException e) {
            log.error(e.getMessage(), e);
        }
        return new Date();
    }

    public static Date parseDate1(String dateTime, String pattern) {
        if (StringUtils.isBlank(dateTime)) {
            return new Date();
        }
        SimpleDateFormat format = new SimpleDateFormat(pattern);
        try {
            return format.parse(dateTime);
        } catch (ParseException e) {
            log.error(e.getMessage(), e);
        }
        return null;
    }

    public static String formatDateTime(Date date, String pattern) {
        if (date == null) {
            return "";
        }
        SimpleDateFormat format = new SimpleDateFormat(pattern);
        return format.format(date);

    }

    public static String getDateTimeString1(Date date) {
        return getDateTimeString(DATE_FORMAT_STRING1, date);
    }

    /**
     * 格式化
     *
     * @param date 日志
     * @return yyyy-MM-dd HH:mm
     */
    public static String getDateTimeString3(Date date) {
        return getDateTimeString(DATE_TIME_FORMAT_STRING2, date);
    }

    public static String getDateTimeString2(Date date) {
        return getDateTimeString(DATE_TIME_FORMAT_STRING3, date);
    }

    /**
     * @param dateTimeFormat
     * @param date
     * @return
     */
    public static String getDateTimeString(String dateTimeFormat, Date date) {
        if (date == null) {
            return "";
        }
        SimpleDateFormat format = new SimpleDateFormat(dateTimeFormat);
        return format.format(date);
    }

    public static String getDate5(int day) {
        Date date = new Date();
        if (day != 0) {
            date.setDate(date.getDate() + day);
        }
        SimpleDateFormat sdf8 = new SimpleDateFormat(DATE_FORMAT_STRING5);
        return sdf8.format(date);
    }

    public static String minusHours(Date date) {
        Date afterDate = new Date(date.getTime() - 60000 * 60);
        SimpleDateFormat sdf8 = new SimpleDateFormat(ES_TIME_FORMAT);
        sdf8.setTimeZone(TimeZone.getTimeZone("GMT+8:00"));
        return sdf8.format(afterDate);
    }

    public static String minusHours(Date date, int hours) {
        Date afterDate = new Date(date.getTime() - 60000 * 60 * hours);
        SimpleDateFormat sdf8 = new SimpleDateFormat(ES_TIME_FORMAT);
        sdf8.setTimeZone(TimeZone.getTimeZone("GMT+8:00"));
        return sdf8.format(afterDate);
    }

    public static Date minusDays(Date date) {
        Calendar calendar = Calendar.getInstance();
        calendar.setTime(date);
        calendar.add(Calendar.DAY_OF_YEAR, -1);
        return calendar.getTime();
    }

    public static Date minusDays(Date date, int offset) {
        Calendar calendar = Calendar.getInstance();
        calendar.setTime(date);
        calendar.add(Calendar.DAY_OF_YEAR, -1 * offset);
        return calendar.getTime();
    }


    public static Date minusHours(int hours) {
        Date afterDate = new Date(System.currentTimeMillis() - 60000 * 60 * hours);
        return afterDate;
    }

    public static String resolveTimeByMinusMinutes(Date date, Integer minutes) {
        Date afterDate = new Date(date.getTime() - 60000 * minutes);
        SimpleDateFormat sdf8 = new SimpleDateFormat(ES_TIME_FORMAT);
        sdf8.setTimeZone(TimeZone.getTimeZone("GMT+8:00"));
        return sdf8.format(afterDate);
    }

    public static String[] resolveTimeByMinusHours(Date date, Integer hours) {
        String[] times = new String[2];
        Date afterDate = new Date(date.getTime() - 60000 * 60 * hours);
        SimpleDateFormat sdf8 = new SimpleDateFormat(ES_TIME_FORMAT);
        sdf8.setTimeZone(TimeZone.getTimeZone("GMT+8:00"));
        times[0] = sdf8.format(date);
        times[1] = sdf8.format(afterDate);
        return times;
    }

    public static String[] resolveTimeByMinusHours2(Date date, Integer hours, String pattern) {
        String[] times = new String[2];
        Date afterDate = new Date(date.getTime() - 60000 * 60 * hours);
        SimpleDateFormat sdf8 = new SimpleDateFormat(pattern);
        times[0] = sdf8.format(date);
        times[1] = sdf8.format(afterDate);
        return times;
    }

    /**
     * 获取统计的开始时间和结束时间
     *
     * @param statTime 统计时长
     * @param size     单位0-分钟；1-小时；2-天；3-周；4-月
     * @param endTime  统计截止时间，如14，
     * @return
     */
    public static String[] getStaticTime(int statTime, int size, int endTime) {
        String[] times = new String[2];
        if (size == 0 || size == 1) {
            Date curTime = new Date();
            long preTimeLong = curTime.getTime() - 1000 * 60 * statTime;
            if (size == 1) {
                preTimeLong = curTime.getTime() - 1000 * 60 * statTime * 60;
            }
            Date preTime = new Date(preTimeLong);
            SimpleDateFormat sdf8 = new SimpleDateFormat(ES_TIME_FORMAT);
            sdf8.setTimeZone(TimeZone.getTimeZone("GMT+8:00"));
            times[1] = sdf8.format(preTime);
            times[0] = sdf8.format(curTime);
        } else if (size == 2) {
            GregorianCalendar calendar = new GregorianCalendar();
            int hour = calendar.get(Calendar.HOUR_OF_DAY);
            if (size < 2)
                endTime = hour;
            String curTimeStr = DateUtils.getDate(0) + String.format(" %02d:00:00", endTime);
            if (hour < endTime) {
                curTimeStr = DateUtils.getDate(-1) + String.format(" %02d:00:00", endTime);
            }
            Date curTime = DateUtils.parseDate(curTimeStr, DATE_FORMAT_STRING1);
            long preTimeLong = curTime.getTime() - 1000 * 60 * statTime * 60 * 24;
            Date preTime = new Date(preTimeLong);

            SimpleDateFormat sdf8 = new SimpleDateFormat(ES_TIME_FORMAT);
            sdf8.setTimeZone(TimeZone.getTimeZone("GMT+8:00"));
            times[1] = sdf8.format(preTime);
            times[0] = sdf8.format(curTime);
        } else if (size == 3) {
            String curTimeStr = getWeekEndDay(statTime);
            Date curTime = DateUtils.parseDate(curTimeStr, DATE_FORMAT_STRING1);
            String preTimeStr = getWeekStartDay(statTime);
            Date preTime = DateUtils.parseDate(preTimeStr, DATE_FORMAT_STRING1);

            SimpleDateFormat sdf8 = new SimpleDateFormat(ES_TIME_FORMAT);
            sdf8.setTimeZone(TimeZone.getTimeZone("GMT+8:00"));
            times[1] = sdf8.format(preTime);
            times[0] = sdf8.format(curTime);
        } else if (size == 4) {
            String curTimeStr = getMonthEndDay(statTime);
            Date curTime = DateUtils.parseDate(curTimeStr, DATE_FORMAT_STRING1);
            String preTimeStr = getMonthStartDay(statTime);
            Date preTime = DateUtils.parseDate(preTimeStr, DATE_FORMAT_STRING1);

            SimpleDateFormat sdf8 = new SimpleDateFormat(ES_TIME_FORMAT);
            sdf8.setTimeZone(TimeZone.getTimeZone("GMT+8:00"));
            times[1] = sdf8.format(preTime);
            times[0] = sdf8.format(curTime);
        }

        return times;
    }

    private static Date minusMonths(Date date, int months) {
        Calendar calendar = Calendar.getInstance();
        calendar.setTime(date);
        calendar.add(Calendar.MONTH, -1 * (months - 1));
        return calendar.getTime();
    }

    private static Date minusWeeks(Date date, int weeks) {
        Calendar calendar = Calendar.getInstance();
        calendar.setTime(date);
        calendar.add(Calendar.DAY_OF_MONTH, -1 * (weeks - 1));
        return calendar.getTime();
    }

    /**
     * 获得上周第一天:yyyy-MM-dd  HH:mm:ss
     */
    public static String getWeekStartDay(int weeks) {
        Calendar c = Calendar.getInstance();
        c.set(Calendar.DAY_OF_WEEK, 2);
        c.add(Calendar.DATE, -7 * weeks);
        SimpleDateFormat startSdf = new SimpleDateFormat("yyyy-MM-dd  00:00:00");
        return startSdf.format(c.getTime());
    }

    /**
     * 获得上周最后一天:yyyy-MM-dd  HH:mm:ss
     */
    public static String getWeekEndDay(int weeks) {
        Calendar c = Calendar.getInstance();
        c.set(Calendar.DAY_OF_WEEK, 2);
        c.add(Calendar.DATE, -1 - (weeks - 1) * 7);
        SimpleDateFormat endSdf = new SimpleDateFormat("yyyy-MM-dd  23:59:59");
        return endSdf.format(c.getTime());
    }

    /**
     * 获得上月最后一天:yyyy-MM-dd  HH:mm:ss
     */
    public static String getMonthEndDay(int months) {
        Calendar c = Calendar.getInstance();
        c.add(Calendar.MONTH, -1 * months);
        c.set(c.get(Calendar.YEAR), c.get(Calendar.MONTH), c.getActualMaximum(Calendar.DAY_OF_MONTH), 23, 59, 59);
        SimpleDateFormat endSdf = new SimpleDateFormat("yyyy-MM-dd  23:59:59");
        return endSdf.format(c.getTime());
    }

    /**
     * 获得上月第一天:yyyy-MM-dd  HH:mm:ss
     */
    public static String getMonthStartDay(int months) {
        Calendar c = Calendar.getInstance();
        c.add(Calendar.MONTH, -1 * months);
        c.set(c.get(Calendar.YEAR), c.get(Calendar.MONTH), c.getActualMaximum(Calendar.DAY_OF_MONTH), 23, 59, 59);
        SimpleDateFormat startSdf = new SimpleDateFormat("yyyy-MM-01  00:00:00");
        return startSdf.format(c.getTime());
    }

    public static String[] formatTimeRange(Date[] timeRanges) {
        String[] times = new String[2];
        SimpleDateFormat sdf8 = new SimpleDateFormat(ES_TIME_FORMAT);
        sdf8.setTimeZone(TimeZone.getTimeZone("GMT+8:00"));
        times[0] = sdf8.format(timeRanges[0]);
        times[1] = sdf8.format(timeRanges[1]);
        return times;
    }

    public static String[] resolveTimeByMinusDays(Date date, Integer days) {
        String[] times = new String[2];
        Calendar calendar = Calendar.getInstance();
        calendar.setTime(date);
        calendar.add(Calendar.DAY_OF_YEAR, (-1) * days);
        SimpleDateFormat sdf8 = new SimpleDateFormat(ES_TIME_FORMAT);
        sdf8.setTimeZone(TimeZone.getTimeZone("GMT+8:00"));
        times[0] = sdf8.format(date);
        times[1] = sdf8.format(calendar.getTime());
        return times;
    }

    public static String[] formatTimeByMinusDays(Date date, Integer days, String pattern) {
        String[] times = new String[2];
        Calendar calendar = Calendar.getInstance();
        calendar.setTime(date);
        calendar.add(Calendar.DAY_OF_YEAR, (-1) * days);
        SimpleDateFormat sdf8 = new SimpleDateFormat(pattern);
        times[0] = sdf8.format(date);
        times[1] = sdf8.format(calendar.getTime());
        return times;
    }


    public static List<String[]> resolveTimeByHisDays(Date date) {
        List<String[]> timeRangeList = new ArrayList<>();
        for (int i = 0; i < 30; i++) {
            // for(int i=0;i<4;i++) {
            String[] times = new String[4];
            Calendar calendar = Calendar.getInstance();
            calendar.setTime(date);
            calendar.add(Calendar.HOUR_OF_DAY, -(i * 6));
            calendar.set(Calendar.MINUTE, 0);
            calendar.set(Calendar.SECOND, 0);
            Calendar calendar2 = Calendar.getInstance();
            calendar2.setTime(date);
            calendar2.add(Calendar.HOUR_OF_DAY, -((i + 1) * 6));
            calendar2.set(Calendar.MINUTE, 0);
            calendar2.set(Calendar.SECOND, 0);
            SimpleDateFormat sdf8 = new SimpleDateFormat(ES_TIME_FORMAT);
            sdf8.setTimeZone(TimeZone.getTimeZone("GMT+8:00"));
            times[0] = sdf8.format(calendar.getTime());
            times[1] = sdf8.format(calendar2.getTime());
            SimpleDateFormat sdf = new SimpleDateFormat(DATE_FORMAT_HOUR_MINUTE);
            //sdf.setTimeZone(TimeZone.getTimeZone("GMT+0:00"));
            times[2] = sdf.format(calendar.getTime());
            times[3] = sdf.format(calendar2.getTime());
            timeRangeList.add(times);
        }
        return timeRangeList;
    }

    public static String[] resolveTimeByMinusWeeks(Date date) {
        String[] times = new String[2];
        Calendar calendar = Calendar.getInstance();
        calendar.setTime(date);
        calendar.add(Calendar.WEEK_OF_YEAR, -1);
        SimpleDateFormat sdf8 = new SimpleDateFormat(ES_TIME_FORMAT);
        sdf8.setTimeZone(TimeZone.getTimeZone("GMT+8:00"));
        times[0] = sdf8.format(date);
        times[1] = sdf8.format(calendar.getTime());
        return times;
    }

    public static String[] resolveTimeByMinusMonths(Date date) {
        String[] times = new String[2];
        Calendar calendar = Calendar.getInstance();
        calendar.setTime(date);
        calendar.add(Calendar.MONTH, -1);
        SimpleDateFormat sdf8 = new SimpleDateFormat(ES_TIME_FORMAT);
        sdf8.setTimeZone(TimeZone.getTimeZone("GMT+8:00"));
        times[0] = sdf8.format(date);
        times[1] = sdf8.format(calendar.getTime());
        return times;
    }

    public static String getCurrentDayFormat5() {
        SimpleDateFormat sdf8 = new SimpleDateFormat(DATE_FORMAT_STRING5);
        return sdf8.format(new Date());
    }

    public static String getHourFormatString(Date date) {
        SimpleDateFormat sdf8 = new SimpleDateFormat(DATE_FORMAT_HOUR);
        return sdf8.format(date);
    }

    public static String getTimeFormatString(Date date) {
        SimpleDateFormat sdf8 = new SimpleDateFormat(DATE_FORMAT_STRING1);
        return sdf8.format(date);
    }

    public static String minusMinute5(Date date) {
        Date afterDate = new Date(date.getTime() - 60000 * 50);
        SimpleDateFormat sdf8 = new SimpleDateFormat(ES_TIME_FORMAT);
        sdf8.setTimeZone(TimeZone.getTimeZone("GMT+8:00"));
        return sdf8.format(afterDate);
    }

    public static String getSparkTime() {
        Date date = new Date();
        SimpleDateFormat sdf8 = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss");
        sdf8.setTimeZone(TimeZone.getTimeZone("GMT+8:00"));
        return sdf8.format(date);
    }

    public static String getSparkTime(Date date) {
        if (date == null) {
            date = new Date();
        }
        SimpleDateFormat sdf8 = new SimpleDateFormat(DATE_FORMAT_STRING1);
        sdf8.setTimeZone(TimeZone.getTimeZone("GMT+8:00"));
        return sdf8.format(date);
    }

    public static String getYear() {
        Date nowDate = new Date();
        Calendar calendar = Calendar.getInstance();
        calendar.setTime(nowDate);
        return String.valueOf(calendar.get(Calendar.YEAR));
    }

    public static Date parseSparkTime(String logTime) {
        SimpleDateFormat format = new SimpleDateFormat(ES_TIME_FORMAT1);
        if (StringUtils.isNotBlank(logTime)) {
            try {
                format.setTimeZone(TimeZone.getTimeZone("GMT+8:00"));
                return format.parse(logTime);
            } catch (Exception e) {
                log.error(e.getMessage(), e);
            }
        }
        return new Date();
    }

    public static String[] parseSparkTimeRange(String[] timeRanges) {
        String[] newTimes = new String[2];
        newTimes[0] = formatDateTime(parseSparkTime(timeRanges[0]), "yyyy-MM-dd HH:mm:ss");
        newTimes[1] = formatDateTime(parseSparkTime(timeRanges[1]), "yyyy-MM-dd HH:mm:ss");
        return newTimes;
    }

    public static Date parseSparkTime2(String logTime) {
        SimpleDateFormat format = new SimpleDateFormat(ES_TIME_FORMAT);
        try {
            format.setTimeZone(TimeZone.getTimeZone("GMT+8:00"));
            return format.parse(logTime);
        } catch (ParseException e) {
            log.error(e.getMessage(), e);
        }
        return new Date();
    }

    public static boolean isDate(String str) {
        boolean result = true;
        SimpleDateFormat format = new SimpleDateFormat(DATE_FORMAT_STRING1);
        try {
            format.setLenient(false);
            format.parse(str);
        } catch (Exception e) {
            log.error(e.getMessage(), e);
            result = false;
        }
        return result;

    }

    public static String getNowDateWithTimeZone(Date date) {
        SimpleDateFormat sdf8 = new SimpleDateFormat(ES_TIME_FORMAT1);
        sdf8.setTimeZone(TimeZone.getTimeZone("GMT+0:00"));
        return sdf8.format(date);

    }

    /**
     * 日期型字符串转化为日期 格式
     */
    public static Date parseDate(Object str) {
        if (str == null) {
            return null;
        }
        try {
            return org.apache.commons.lang3.time.DateUtils.parseDate(str.toString(), parsePatterns);
        } catch (ParseException e) {
            return null;
        }
    }


    /**
     * 日期型字符串转化为日期 格式
     */
    public static Date parseDate1(Object str) {
        if (str == null) {
            return new Date();
        }
        try {
            return org.apache.commons.lang3.time.DateUtils.parseDate(str.toString(), parsePatterns);
        } catch (ParseException e) {
            return new Date();
        }
    }

    /**
     * 获取现在时间
     */
    public static String getTime(String DATE_TIME_FORMAT) {
        TimeZone tz = TimeZone.getTimeZone("Asia/Shanghai");
        TimeZone.setDefault(tz);
        Date date = new Date();
        SimpleDateFormat sdf8 = new SimpleDateFormat(DATE_TIME_FORMAT);
        return sdf8.format(date);
    }

    /**
     * 检测合法时间
     *
     * @param UTCStr
     * @return
     */
    public static String UTCToCSTAndCheck(String UTCStr) {
        if (StringUtils.isBlank(UTCStr)) {
            return null;
        }
        Date date = null;
        SimpleDateFormat sdf = new SimpleDateFormat(ES_TIME_FORMAT1);
        Calendar calendar = Calendar.getInstance();
        if (UTCStr.contains("T")) {
            try {
                if (UTCStr.contains("+0800")) {
                    UTCStr = UTCStr.replace("+0800", "Z");
                }
                date = sdf.parse(UTCStr);
                calendar.setTime(date);

                SimpleDateFormat sdf2 = new SimpleDateFormat(DATE_FORMAT_STRING1);
                return sdf2.format(calendar.getTime());
            } catch (Exception e) {
                log.error(e.getMessage(), e);
            }
        }
        return UTCStr;
    }

    public static Date UTCToCSTAndCheck4Date(String UTCStr) {
        if (StringUtils.isBlank(UTCStr)) {
            return new Date();
        }

        Date date = null;
        SimpleDateFormat sdf = new SimpleDateFormat(ES_TIME_FORMAT1);
        Calendar calendar = Calendar.getInstance();
        if (UTCStr.contains("T")) {
            try {
                if (UTCStr.contains("+0800")) {
                    UTCStr = UTCStr.replace("+0800", "Z");
                }
                date = sdf.parse(UTCStr);
                calendar.setTime(date);

                return calendar.getTime();
            } catch (Exception e) {
                log.error(e.getMessage(), e);
            }
        } else if (UTCStr.contains(",")) {
            return UTCToCSTAndCheck4Date(UTCStr.split(",")[0]);
        }
        return new Date();
    }

    public static Date UTCToCSTAndCheck4DateX(String UTCStr) {
        if (StringUtils.isBlank(UTCStr)) {
            return null;
        }

        Date date = null;
        SimpleDateFormat sdf = new SimpleDateFormat(ES_TIME_FORMAT1);
        Calendar calendar = Calendar.getInstance();
        if (UTCStr.contains("T")) {
            try {
                if (UTCStr.contains("+0800")) {
                    UTCStr = UTCStr.replace("+0800", "Z");
                }
                date = sdf.parse(UTCStr);
                calendar.setTime(date);

                return calendar.getTime();
            } catch (Exception e) {
                log.error(e.getMessage(), e);
            }
        } else if (UTCStr.contains(",")) {
            return UTCToCSTAndCheck4DateX(UTCStr.split(",")[0]);
        }
        return null;
    }

    public static String[] getminuHourTimeRange(int hour) {
        String[] timeRanges = new String[2];
        Date nowDate = new Date();
        Calendar calendar = Calendar.getInstance();
        calendar.setTime(nowDate);
        calendar.add(Calendar.HOUR_OF_DAY, hour);
        timeRanges[0] = getNowDateWithTimeZone(calendar.getTime());
        timeRanges[1] = getNowDateWithTimeZone(nowDate);
        return timeRanges;
    }

    /**
     * 判断当前时间是否在[startTime, endTime]区间，注意时间格式要一致
     *
     * @param nowTime   当前时间
     * @param startTime 开始时间
     * @param endTime   结束时间
     * @return
     * @author jqlin
     */
    public static boolean isEffectiveDate(Date nowTime, Date startTime, Date endTime) {
        if (nowTime.getTime() == startTime.getTime()
                || nowTime.getTime() == endTime.getTime()) {
            return true;
        }
        Calendar date = Calendar.getInstance();
        date.setTime(nowTime);
        Calendar begin = Calendar.getInstance();
        begin.setTime(startTime);
        Calendar end = Calendar.getInstance();
        end.setTime(endTime);
        if (date.after(begin) && date.before(end)) {
            return true;
        } else {
            return false;
        }
    }


    public static String[] resolveTimeIntevalsByType(TimeUnit timeUnit, Date date, Integer taskInteval) throws InvocationTargetException, IllegalAccessException {
        Method[] methods = DateUtils.class.getMethods();
        String[] timeUnits = new String[2];
        if (timeUnit != null) {
            String funcName = timeUnit.getFunc();
            for (Method method : methods) {
                Object[] objectList = new Object[2];
                if (funcName.equalsIgnoreCase(method.getName())) {
                    objectList[0] = date;
                    objectList[1] = taskInteval;
                    timeUnits = (String[]) method.invoke(instance, objectList);
                }
            }
        }
        return timeUnits;
    }

    public static Date parseDateTime(String dateStr, String pattern) {
        if (StringUtils.isBlank(dateStr)) {
            return new Date();
        }
        SimpleDateFormat sdf = new SimpleDateFormat(pattern);
        Date date = null;
        try {
            if (StringUtils.isBlank(dateStr)) {
                return new Date();
            }
            date = sdf.parse(dateStr);
        } catch (Exception e) {
            log.error(e.getMessage(), e);
        }
        return date;
    }

    public static Date parseDateTime1(String dateStr, String pattern) {
        SimpleDateFormat sdf = new SimpleDateFormat(pattern);
        Date date = null;
        try {
            if (StringUtils.isNotBlank(dateStr)) {
                date = sdf.parse(dateStr);
                return date;
            }
        } catch (Exception e) {
            log.error(e.getMessage(), e);
        }
        return null;
    }

    public static Date parseDateForGMT(String dateTime) {
        return UTCToCSTAndCheck4DateX(dateTime);
    }

    public static LocalDateTime parse(String dateStr, String pattern) {
        if (StringUtils.isBlank(dateStr)) {
            return LocalDateTime.now();
        }
        DateTimeFormatter formatter = DateTimeFormatter.ofPattern(pattern);
        return LocalDateTime.parse(dateStr, formatter);
    }

    public static String format(LocalDateTime localDateTime, String pattern) {
        DateTimeFormatter formatter = DateTimeFormatter.ofPattern(pattern);
        return formatter.format(localDateTime);
    }

    public static Date getDay(int day) {
        Date date = new Date();
        if (day != 0) {
            date.setDate(date.getDate() + day);
        }
        return date;
    }

    public static Date parseDateTimeEx(String date) {
        if (StringUtils.isBlank(date))
            return null;
        SimpleDateFormat format = new SimpleDateFormat(DATE_FORMAT_STRING1);
        try {
            return format.parse(date);
        } catch (Exception e) {
        }
        return null;
    }

    public static Date parseDateTimeTx(String date) {
        if (StringUtils.isBlank(date))
            return null;
        SimpleDateFormat format = new SimpleDateFormat(ES_TIME_FORMAT1);
        try {
            return format.parse(date);
        } catch (Exception e) {
        }
        return null;
    }
}
