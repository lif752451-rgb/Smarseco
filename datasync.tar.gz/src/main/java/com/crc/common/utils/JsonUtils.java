package com.crc.common.utils;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONArray;
import com.alibaba.fastjson.JSONObject;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringEscapeUtils;
import org.apache.commons.lang3.StringUtils;

import java.text.SimpleDateFormat;
import java.time.LocalDateTime;
import java.time.ZoneId;
import java.util.Calendar;
import java.util.Date;
import java.util.concurrent.atomic.AtomicReference;

/**
 * JSON工具类
 */
@Slf4j
public class JsonUtils {
    public static JSONObject clone(JSONObject json) {
        if (json == null) {
            return new JSONObject();
        }
        return (JSONObject) json.clone();
    }


    public static void copyField(JSONObject json, String src, String dest) {
        if (isEmpty(json) || StringUtils.isBlank(src))
            return;

        try {
            if (json.get(src) != null)
                json.put(dest, json.get(src));
        } catch (Exception e) {
            log.error(e.getMessage(), e);
        }
    }

    public static JSONArray getJsonArray(JSONObject json, String filter) {
        if (isEmpty(json) || StringUtils.isBlank(filter))
            return createJsonArray();
        try {
            return json.getJSONArray(filter);
        } catch (Exception e) {
            return createJsonArray();
        }
    }

    public static JSONObject getJson(JSONObject json, String filter) {
        if (isEmpty(json) || StringUtils.isBlank(filter))
            return createJson();

        try {
            return json.getJSONObject(filter);
        } catch (Exception e) {
            log.error(e.getMessage(), e);
        }
        return createJson();
    }


    public static int getInt(JSONObject json, String filter) {
        if (isEmpty(json) || StringUtils.isBlank(filter))
            return 0;
        if (json.get(filter) == null) {
            return 0;
        }
        try {
            return json.getIntValue(filter);
        } catch (Exception e) {
            return 0;
        }
    }

    public static int getIntX(JSONObject json, String filter) {
        if (isEmpty(json) || StringUtils.isBlank(filter))
            return -1;
        if (json.get(filter) == null) {
            return -1;
        }
        try {
            return json.getIntValue(filter);
        } catch (Exception e) {
            return -1;
        }
    }

    public static long getLong(JSONObject json, String filter) {
        if (isEmpty(json) || StringUtils.isBlank(filter))
            return 0;
        if (json.get(filter) == null) {
            return 0;
        }
        try {
            return json.getLongValue(filter);
        } catch (Exception e) {
            return 0;
        }
    }

    public static String getStr(JSONObject json, String filter, String defaultVal) {
        String ret = getStr(json, filter);
        if (StringUtils.isBlank(ret))
            return defaultVal;
        return ret;
    }

    public static Date getDateX(JSONObject json, String filter) {
        if (isEmpty(json) || StringUtils.isBlank(filter))
            return null;

        if (json.get(filter) == null) {
            return null;
        }
        try {
            Object obj = json.get(filter);
            if (obj instanceof LocalDateTime) {
                //return DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss").format((LocalDateTime)obj);
                LocalDateTime localDateTime = (LocalDateTime) obj;
                return Date.from(localDateTime.atZone(ZoneId.systemDefault()).toInstant());
            } else if (obj instanceof Date) {
                return (Date) obj;
            }
            String dateStr = getStr(json, filter);
            return DateUtils.parseDate1(dateStr, DateUtils.DATE_FORMAT_STRING1);
        } catch (Exception e) {
            log.error(e.getMessage(), e);
        }
        return null;
    }

    public static Date getDate(JSONObject json, String filter) {
        if (isEmpty(json) || StringUtils.isBlank(filter))
            return new Date();

        if (json.get(filter) == null) {
            return new Date();
        }
        try {
            Object obj = json.get(filter);
            if (obj instanceof LocalDateTime) {
                //return DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss").format((LocalDateTime)obj);
                LocalDateTime localDateTime = (LocalDateTime) obj;
                return Date.from(localDateTime.atZone(ZoneId.systemDefault()).toInstant());
            } else if (obj instanceof Date) {
                return (Date) obj;
            }


            String dateStr = getStr(json, filter);
            if (DataUtils.isInteger(dateStr)) {
                long time = DataUtils.toLong(dateStr);
                if (dateStr.length() == 10) {
                    time = time * 1000;
                }
                dateStr = DateUtils.getDateTimeString1(new Date(time));
            }
            dateStr = UTCToCSTAndCheck(dateStr);
            if (StringUtils.isNotBlank(dateStr))
                return DateUtils.parseDate(dateStr, DateUtils.DATE_FORMAT_STRING1);
        } catch (Exception e) {
            log.error(e.getMessage(), e);
        }
        return new Date();
    }

    public static Date getDateToJiaotu(JSONObject json, String filter) {
        if (isEmpty(json) || StringUtils.isBlank(filter))
            return new Date();

        if (json.get(filter) == null) {
            return new Date();
        }
        try {
            Object obj = json.get(filter);
            if (obj instanceof LocalDateTime) {
                //return DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss").format((LocalDateTime)obj);
                LocalDateTime localDateTime = (LocalDateTime) obj;
                return Date.from(localDateTime.atZone(ZoneId.systemDefault()).toInstant());
            } else if (obj instanceof Date) {
                return (Date) obj;
            }


            String dateStr = getStr(json, filter);
            dateStr = UTCToCSTAndCheck(dateStr);
            if (StringUtils.isNotBlank(dateStr))
                return DateUtils.parseDate(dateStr, DateUtils.DATE_FORMAT);
        } catch (Exception e) {
            log.error(e.getMessage(), e);
        }
        return new Date();
    }

    private static String UTCToCSTAndCheck(String UTCStr) {
        if (StringUtils.isBlank(UTCStr)) {
            return null;
        }
        Date date = null;
        SimpleDateFormat sdf = new SimpleDateFormat(DateUtils.ES_TIME_FORMAT1);
        Calendar calendar = Calendar.getInstance();
        if (UTCStr.contains("T")) {
            try {
                if (UTCStr.contains("+0800")) {
                    UTCStr = UTCStr.replace("+0800", "Z");
                }
                date = sdf.parse(UTCStr);
                calendar.setTime(date);

                SimpleDateFormat sdf2 = new SimpleDateFormat(DateUtils.DATE_FORMAT_STRING1);
                return sdf2.format(calendar.getTime());
            } catch (Exception e) {
                log.error(e.getMessage(), e);
            }
        }
        return UTCStr;
    }

    public static String getDateStr(JSONObject json, String filter) {
        if (isEmpty(json) || StringUtils.isBlank(filter))
            return "";

        if (json.get(filter) == null) {
            return "";
        }
        try {
            Date retStr = json.getDate(filter);
            /** GC日志特殊处理，将传入的时间参数固定+8小时 */
            Calendar cal = Calendar.getInstance();
            cal.setTime(retStr);
//            cal.add(Calendar.HOUR_OF_DAY, 8);
            Date dateStart = cal.getTime();
            return DateUtils.getSparkTime(dateStart);
        } catch (Exception e) {
            log.error(e.getMessage(), e);
        }
        return "";
    }

    public static String getStr(JSONObject json, String filter) {
        if (isEmpty(json) || StringUtils.isBlank(filter))
            return "";

        if (json.get(filter) == null) {
            return "";
        }
        try {
            String retStr = json.getString(filter);
            if (StringUtils.isNotBlank(retStr)) {
                if ("null".equalsIgnoreCase(retStr)) {
                    return "";
                }
                if ("-".equalsIgnoreCase(retStr)) {
                    return "";
                }
                return retStr.trim();
            }
        } catch (Exception e) {
            log.error(e.getMessage(), e);
        }

        try {
            String retStr = json.get(filter).toString();
            if (StringUtils.isNotBlank(retStr)) {
                if ("null".equalsIgnoreCase(retStr)) {
                    return "";
                }
                if ("-".equalsIgnoreCase(retStr)) {
                    return "";
                }
                return retStr.trim();
            }
        } catch (Exception e) {
            log.error(e.getMessage(), e);
        }
        return "";
    }

    //通过点带路径查询
    public static String getStrByPath(JSONObject sourceJson, String sourceKey) {
        if (sourceKey.contains(".")) {
            String[] sourceKeys = sourceKey.split("\\.");
            String sourceKey1 = sourceKeys[0];
            String sourceKey2 = sourceKey.substring(sourceKey1.length() + 1);
            JSONObject insideJson = JsonUtils.getJson(sourceJson, sourceKey1);
            //log.info("{}-{}", insideJson.toJSONString(), sourceKey2);
            return JsonUtils.getStrByPath(insideJson, sourceKey2);
        }
        return JsonUtils.getStr(sourceJson, sourceKey);
    }

    public static void main(String[] args) {
        JSONObject o = new JSONObject();
        o.put("a", "1");
        JSONObject a = new JSONObject();
        a.put("b", "2");
        o.put("b", a);
        System.out.println(o.toJSONString());
        System.out.println(JsonUtils.getStrByPath(o, "b.b"));
    }

    public static boolean containsKey(JSONObject json, String filter) {
        if (isEmpty(json) || StringUtils.isBlank(filter)) {
            return false;
        }
        if (json.containsKey(filter)) {
            return true;
        }
        return false;
    }

    public static boolean isEmpty(JSONObject json) {
        if (json == null)
            return true;
        return json.size() < 1;
    }

    public static JSONObject createJson() {
        return new JSONObject();
    }

    public static JSONObject createJson(String key, String value) {
        JSONObject json = new JSONObject();
        json.put(key, value);
        return json;
    }

    public static JSONArray createJsonArray() {
        return new JSONArray();
    }

    public static JSONObject parse(String json) {
        try {
            if (StringUtils.isBlank(json)) {
                return createJson();
            }
            String v = StringEscapeUtils.unescapeXml(json);
            return JSON.parseObject(v);
        } catch (Exception e) {
            try {
                return parseUnescape(json);
            } catch (Exception ignored) {

            }
        }
        log.error("parse ERROR= " + json);
        return createJson();
    }

    public static JSONObject parseUnescape(String json) {
        try {
            if (StringUtils.isBlank(json)) {
                return createJson();
            }
            json = StringEscapeUtils.unescapeJson(json);
            return JSON.parseObject(json);
        } catch (Exception e) {
            log.error("parse ERROR= " + json);
        }
        return createJson();
    }


    public static String getLongToDate(JSONObject json, String longTime) {
        long time = getLong(json, longTime) * 1000;
        if (time > 0) {
            return DateUtils.getSparkTime(new Date(time));
        }
        return "";
    }

    public static Date getLongToDateX(JSONObject json, String longTime) {
        long time = getLong(json, longTime) * 1000;
        if (time > 0) {
            return new Date(time);
        }
        return new Date();
    }

    public static void print(Object json) {
        System.out.println("#################");
        if (json != null)
            System.out.println(JSON.toJSONString(json));
    }


    public static int getIntN(JSONObject job, String log_count) {
        int ret = getInt(job, log_count);
        return Math.max(ret, 1);
    }

    public static boolean getBoolean(JSONObject json, String filter) {
        if (isEmpty(json) || StringUtils.isBlank(filter))
            return false;

        if (json.get(filter) == null) {
            return false;
        }
        try {
            return json.getBoolean(filter);
        } catch (Exception ignored) {

        }
        return false;
    }

    public static boolean equal(JSONObject json, String filter, String success) {
        return getStr(json, filter).equalsIgnoreCase(success);
    }

    public static String getDateStrX(JSONObject taskJson, String time_start_scan) {
        Date date = getDate(taskJson, time_start_scan);
        if (date == null) {
            date = new Date();
        }
        return DateUtils.getDateTimeString1(date);
    }

    public static double getDouble(JSONObject json, String filter) {
        if (isEmpty(json) || StringUtils.isBlank(filter))
            return 0;

        if (json.get(filter) == null) {
            return 0;
        }
        try {
            return json.getDouble(filter);
        } catch (Exception e) {

        }
        return 0;
    }

    public static String getStrX(JSONObject json, String filter) {
        String ret = getStr(json, filter);
        return ret.replace("'", "‘");
    }

    public static String getListToStr(JSONObject json, String fitler) {
        if (json.containsKey(fitler)) {
            JSONArray jsonArray = json.getJSONArray(fitler);
            if (jsonArray != null && jsonArray.size() > 0) {
                StringBuilder ret = new StringBuilder();
                for (int i = 0; i < jsonArray.size(); i++) {
                    ret.append(jsonArray.getString(i)).append(",");
                }
                String str = ret.toString();
                if (StringUtils.isBlank(ret)) {
                    return str;
                }
                try {
                    return StringUtils.substring(str, 0, str.length() - 1);
                } catch (Exception e) {

                }
            }
        }
        return "";
    }

    public static boolean equalVal(JSONObject json, String src, String val) {
        if (isEmpty(json) || StringUtils.isBlank(src))
            return false;
        if (isEmpty(json) || StringUtils.isBlank(val))
            return false;
        try {
            String sVal = getStr(json, src);
            if (StringUtils.isNotBlank(sVal) && sVal.equals(val))
                return true;
        } catch (Exception e) {

        }
        return false;
    }

    public static JSONArray parseArray(String scanContent) {
        if (StringUtils.isBlank(scanContent)) {
            return null;
        }
        try {
            return JSON.parseArray(scanContent);
        } catch (Exception e) {

        }
        return null;
    }

    public static void setObj(JSONObject param, String filter, Object val) {
        if (param == null) {
            return;
        }
        if (StringUtils.isNotBlank(filter)) {
            param.put(filter, val);
        }
    }

    /**
     * 别名拼装
     *
     * @param json
     * @param filter
     * @param name
     * @return
     */
    public static String getFieldStr(JSONObject json, String filter, String name) {
        String val = JsonUtils.getStr(json, filter);
        if (StringUtils.isNotBlank(val)) {
            return String.format("%s: %s", name, val);
        }
        return null;
    }

    public static String getFieldStr(JSONObject json, String filter, String name, String filter1, String name1) {
        String ret = getFieldStr(json, filter, name);
        String ret2 = getFieldStr(json, filter1, name1);
        if (StringUtils.isNotBlank(ret)) {
            if (StringUtils.isNotBlank(ret2)) {
                return ret + ";" + ret2;
            } else {
                return ret;
            }
        } else {
            if (StringUtils.isNotBlank(ret2)) {
                return ret2;
            }
        }
        return null;
    }

    public static String getFieldStr(JSONObject json, String filter, String name, String filter1, String name1, String filter2, String name2) {
        String ret = getFieldStr(json, filter, name, filter1, name1);
        String ret2 = getFieldStr(json, filter2, name2);
        if (StringUtils.isNotBlank(ret)) {
            if (StringUtils.isNotBlank(ret2)) {
                return ret + ";" + ret2;
            } else {
                return ret;
            }
        } else {
            if (StringUtils.isNotBlank(ret2)) {
                return ret2;
            }
        }
        return null;
    }

    public static String getStrLike(JSONObject data, String host) {
        if (data != null && StringUtils.isNotBlank(host)) {
            AtomicReference<String> ret = new AtomicReference<>("");
            data.forEach((k, v) -> {
                if (k.contains(host)) {
                    try {
                        ret.set(v.toString());
                    } catch (Exception e) {

                    }
                }
            });
            return ret.get();
        }
        return "";
    }

    public static JSONObject error(int code, String msg) {
        JSONObject jsonObject = new JSONObject();
        jsonObject.put("code", code);
        jsonObject.put("msg", msg);
        return jsonObject;
    }

    public static String toJSONString(Object fieldValue) {
        if (fieldValue == null) {
            return "";
        }
        try {
            return JSON.toJSONString(fieldValue);
        } catch (Exception e) {
            log.error(e.getMessage(),e);
        }
        return "";
    }
}
