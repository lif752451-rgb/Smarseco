package com.crc.common.utils;

import org.apache.commons.codec.binary.Base64;
import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import sun.misc.BASE64Decoder;

import javax.crypto.Cipher;
import javax.crypto.KeyGenerator;
import javax.crypto.spec.SecretKeySpec;
import java.nio.charset.StandardCharsets;

public class EncryptUtil {
    private static final String KEY = "e8f5b39451625bdead70d5ccc9250404";
    private static final String ALGORITHMSTR = "AES/ECB/PKCS5Padding";

    public static String base64Encode(byte[] bytes) {
        return Base64.encodeBase64String(bytes);
    }

    public static byte[] base64Decode(String base64Code) throws Exception {
        return new BASE64Decoder().decodeBuffer(base64Code);
    }

    protected static Logger logger = LoggerFactory.getLogger(EncryptUtil.class);

    public static byte[] aesEncryptToBytes(String content, String encryptKey) {
        try {
            KeyGenerator kgen = KeyGenerator.getInstance("AES");
            kgen.init(128);
            Cipher cipher = Cipher.getInstance(ALGORITHMSTR);
            cipher.init(Cipher.ENCRYPT_MODE, new SecretKeySpec(encryptKey.getBytes(), "AES"));

            return cipher.doFinal(content.getBytes(StandardCharsets.UTF_8));
        } catch (Exception e) {
            logger.error("aesEncryptToBytes 出错,content:{}, encryptKey:{}", content, encryptKey, e);
        }
        return content.getBytes(StandardCharsets.UTF_8);
    }

    public static String aesEncrypt(String content, String encryptKey) {
        try {
            if (StringUtils.isBlank(content)) {
                logger.info("试图加密空字符串！");
                return content;
            }
            if (StringUtils.isBlank(encryptKey)) {
                logger.info("试图空KEY加密字符串！");
                return content;
            }
            return base64Encode(aesEncryptToBytes(content, encryptKey));
        } catch (Exception e) {
            logger.error("aesEncrypt 出错,content:{}, encryptKey:{}", content, encryptKey, e);
        }
        return content;
    }

    public static String aesDecryptByBytes(byte[] encryptBytes, String decryptKey) {
        try {
            KeyGenerator kgen = KeyGenerator.getInstance("AES");
            kgen.init(128);

            Cipher cipher = Cipher.getInstance(ALGORITHMSTR);
            cipher.init(Cipher.DECRYPT_MODE, new SecretKeySpec(decryptKey.getBytes(), "AES"));
            byte[] decryptBytes = cipher.doFinal(encryptBytes);

            return new String(decryptBytes);
        } catch (Exception e) {
            logger.error("aesDecryptByBytes 出错,encryptBytes:{}, decryptKey:{}", encryptBytes, decryptKey, e);
        }
        return new String(encryptBytes);
    }

    public static String aesDecrypt(String encryptStr, String decryptKey) {
        try {
            if (StringUtils.isBlank(encryptStr)) {
                logger.info("试图解密空字符串！");
                return encryptStr;
            }
            if (StringUtils.isBlank(decryptKey)) {
                logger.info("试图空KEY解密字符串！");
                return encryptStr;
            }
            return aesDecryptByBytes(base64Decode(encryptStr), decryptKey);
        } catch (Exception e) {
            logger.error("aesDecrypt 出错,encryptStr:{}, decryptKey:{}", encryptStr, decryptKey, e);
        }
        return encryptStr;
    }

    public static String aesEncrypt(String content) {
        try {
            if (StringUtils.isBlank(content)) {
                logger.info("试图加密空字符串！");
                return content;
            }
            return base64Encode(aesEncryptToBytes(content, KEY));
        } catch (Exception e) {
            logger.error("aesEncrypt出错, content:{}", content, e);
        }
        return content;
    }

    public static String aesDecrypt(String encryptStr) {
        try {
            if (StringUtils.isBlank(encryptStr)) {
                logger.info("试图解密空字符串！");
                return encryptStr;
            }
            return aesDecryptByBytes(base64Decode(encryptStr), KEY);
        } catch (Exception e) {
            logger.error("aesDecrypt出错, encryptStr:{}", encryptStr, e);
        }
        return encryptStr;
    }

    /**
     * 测试
     */
    public static void main(String[] args) throws Exception {

        String content = "wwww";  //0gqIDaFNAAmwvv3tKsFOFf9P9m/6MWlmtB8SspgxqpWKYnELb/lXkyXm7P4sMf3e
        System.out.println("加密前：" + content);

        System.out.println("加密密钥和解密密钥：" + KEY);

        String encrypt = aesEncrypt(content, KEY);
        System.out.println(encrypt.length() + ":加密后：" + encrypt);

        String decrypt = aesDecrypt(encrypt, KEY);
        System.out.println("解密后：" + decrypt);
    }
}
