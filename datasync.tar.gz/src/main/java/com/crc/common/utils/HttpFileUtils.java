package com.crc.common.utils;


import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;
import lombok.extern.slf4j.Slf4j;
import org.apache.http.HttpEntity;
import org.apache.http.client.config.RequestConfig;
import org.apache.http.client.methods.CloseableHttpResponse;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.config.Registry;
import org.apache.http.config.RegistryBuilder;
import org.apache.http.conn.socket.ConnectionSocketFactory;
import org.apache.http.conn.socket.PlainConnectionSocketFactory;
import org.apache.http.conn.ssl.NoopHostnameVerifier;
import org.apache.http.conn.ssl.SSLConnectionSocketFactory;
import org.apache.http.conn.ssl.TrustStrategy;
import org.apache.http.entity.ContentType;
import org.apache.http.entity.StringEntity;
import org.apache.http.entity.mime.MultipartEntityBuilder;
import org.apache.http.impl.client.BasicCookieStore;
import org.apache.http.impl.client.CloseableHttpClient;
import org.apache.http.impl.client.HttpClients;
import org.apache.http.impl.conn.PoolingHttpClientConnectionManager;
import org.apache.http.ssl.SSLContextBuilder;
import org.apache.http.util.EntityUtils;

import javax.net.ssl.HostnameVerifier;
import javax.net.ssl.SSLContext;
import java.io.File;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.nio.charset.StandardCharsets;

@Slf4j
public class HttpFileUtils {

    public static CloseableHttpClient getHttpClient() {
        try {
            System.setProperty("jdk.tls.allowUnsafeServerCertChange", "true");
            System.setProperty("sun.security.ssl.allowUnsafeRenegotiation", "true");
            System.setProperty("jdk.tls.client.protocols", "TLSv1,TLSv1.1,TLSv1.2");
            //使用 loadTrustMaterial() 方法实现一个信任策略，信任所有证书
            // 信任所有
            SSLContext sslContext = new SSLContextBuilder().loadTrustMaterial(null, (TrustStrategy) (chain, authType) -> true).build();
            //NoopHostnameVerifier类:  作为主机名验证工具，实质上关闭了主机名验证，它接受任何
            //有效的SSL会话并匹配到目标主机。
            HostnameVerifier hostnameVerifier = NoopHostnameVerifier.INSTANCE;
            SSLConnectionSocketFactory sslsf = new SSLConnectionSocketFactory(sslContext, hostnameVerifier);

            Registry<ConnectionSocketFactory> registry = RegistryBuilder.<ConnectionSocketFactory>create()
                    .register("http", new PlainConnectionSocketFactory())
                    .register("https", sslsf)
                    .build();
            PoolingHttpClientConnectionManager cm = new PoolingHttpClientConnectionManager(registry);
            cm.setMaxTotal(100);
            return HttpClients.custom()
                    .setSSLSocketFactory(sslsf)
                    .setDefaultCookieStore(new BasicCookieStore())
                    .setConnectionManager(cm).build();
        } catch (Exception e) {
            log.error(e.getMessage(), e);
        }
        return HttpClients.createDefault();
    }

    /**
     * 文件上传
     *
     * @param url     接口地址
     * @param param   json参数
     * @param zipFile 文件
     * @return 返回
     */
    public static String sendPostFile(String url, JSONObject param, File zipFile) {
        CloseableHttpClient httpClient = null;
        CloseableHttpResponse response = null;
        try {
            if (!zipFile.exists()) {
                log.info("{},附件为空！{}", url, JSON.toJSONString(param));
                return "";
            }
            httpClient = getHttpClient();

            HttpPost post = new HttpPost(url);
            RequestConfig requestConfig = RequestConfig.custom().setConnectionRequestTimeout(600000)
                    .setConnectTimeout(600000).setSocketTimeout(600000).build();
            post.setConfig(requestConfig);
            if (param == null) {
                param = new JSONObject();
            }
            log.info(url + "参数：{},zipFile=" + zipFile.getAbsolutePath(), param.toJSONString());
            final MultipartEntityBuilder builder = MultipartEntityBuilder.create();
            builder.addBinaryBody("uploadFile", zipFile);
            if (param.size() > 0) {
                JSONObject finalParam = param;
                param.forEach((k, v) -> {
                    builder.addTextBody(k, JsonUtils.getStr(finalParam, k), ContentType.APPLICATION_FORM_URLENCODED);
                });
            }
            builder.setCharset(StandardCharsets.UTF_8);
            builder.setContentType(ContentType.MULTIPART_FORM_DATA);
            HttpEntity multiPartEntity = builder.build();
            post.setEntity(multiPartEntity);

            response = httpClient.execute(post);
            int statusCode = response.getStatusLine().getStatusCode();
            log.info("{} -returncode = {}", url, statusCode);
            return DataUtils.toBodyString(response.getEntity());
        } catch (Exception e) {
            log.error(url + " http错误 " + e.getMessage(), e);
        } finally {
            IOUtils.close(response);
            IOUtils.close(httpClient);
        }
        return "";
    }

    /**
     * 文件上传
     *
     * @param url     接口地址
     * @param param   json参数
     * @param zipFile 文件
     * @return 返回
     */
    public static String sendPostXmlFile(String url, JSONObject param, File zipFile, String fileField) {
        CloseableHttpClient httpClient = null;
        CloseableHttpResponse response = null;
        try {
            if (!zipFile.exists()) {
                log.error("文件不存在");
                return "";
            }
            httpClient = getHttpClient();

            HttpPost post = new HttpPost(url);
            RequestConfig requestConfig = RequestConfig.custom().setConnectionRequestTimeout(600000)
                    .setConnectTimeout(600000).setSocketTimeout(600000).build();
            post.setConfig(requestConfig);
            if (param == null) {
                param = new JSONObject();
            }
            //curl -F "config_xml=@{xml_path}" -F "type={type_value}" -kv " https://{device_ip} /api/{api_name}?username={username}&password={password}&format={ json | xml }"
            log.info(url + "参数：{},zipFile=" + zipFile.getAbsolutePath(), param.toJSONString());
            final MultipartEntityBuilder builder = MultipartEntityBuilder.create();
            builder.addBinaryBody(fileField, zipFile);
            if (param.size() > 0) {
                JSONObject finalParam = param;
                param.forEach((k, v) -> {
                    builder.addTextBody(k, JsonUtils.getStr(finalParam, k), ContentType.APPLICATION_FORM_URLENCODED);
                });
            }
            builder.setCharset(StandardCharsets.UTF_8);
            builder.setContentType(ContentType.MULTIPART_FORM_DATA);
            HttpEntity multiPartEntity = builder.build();
            post.setEntity(multiPartEntity);

            response = httpClient.execute(post);
            int statusCode = response.getStatusLine().getStatusCode();
            String ret = DataUtils.toBodyString(response.getEntity());
            log.info("{} -returncode = {},content = {}", url, statusCode, ret);
            return ret;
        } catch (Exception e) {
            log.error(url + " http错误 " + e.getMessage(), e);
        } finally {
            IOUtils.close(response);
            IOUtils.close(httpClient);
        }
        return "";
    }

    /**
     * POST form-data请求
     *
     * @param url   接口地址
     * @param param json参数
     * @return 返回
     */
    public static String sendPostFormData(String url, JSONObject param) {
        CloseableHttpClient httpClient = null;
        CloseableHttpResponse response = null;
        try {
            httpClient = getHttpClient();

            HttpPost post = new HttpPost(url);
            RequestConfig requestConfig = RequestConfig.custom().setConnectionRequestTimeout(600000)
                    .setConnectTimeout(600000).setSocketTimeout(600000).build();
            post.setConfig(requestConfig);
            if (param == null) {
                param = new JSONObject();
            }
            log.info(url + "参数：{}", param.toJSONString());
            final MultipartEntityBuilder builder = MultipartEntityBuilder.create();
            if (param.size() > 0) {
                JSONObject finalParam = param;
                param.forEach((k, v) -> {
                    builder.addTextBody(k, JsonUtils.getStr(finalParam, k), ContentType.APPLICATION_FORM_URLENCODED);
                });
            }
            builder.setCharset(StandardCharsets.UTF_8);
            builder.setContentType(ContentType.MULTIPART_FORM_DATA);
            HttpEntity multiPartEntity = builder.build();
            post.setEntity(multiPartEntity);

            response = httpClient.execute(post);
            return DataUtils.toBodyString(response.getEntity());
        } catch (Exception e) {
            log.error(e.getMessage(), e);
        } finally {
            IOUtils.close(response);
            IOUtils.close(httpClient);
        }
        return "";
    }

    /**
     * POST form-data请求
     *
     * @param url   接口地址
     * @param param json参数
     * @return 返回
     */
    public static String sendPost(String url, JSONObject param, JSONObject headers) {
        CloseableHttpClient httpClient = null;
        CloseableHttpResponse response = null;
        try {
            httpClient = getHttpClient();

            HttpPost post = new HttpPost(url);
            RequestConfig requestConfig = RequestConfig.custom().setConnectionRequestTimeout(600000)
                    .setConnectTimeout(600000).setSocketTimeout(600000).build();
            post.setConfig(requestConfig);
            if (param == null) {
                param = new JSONObject();
            }
            log.info(url + "参数：{},header:{}", JSON.toJSONString(param), JSON.toJSONString(headers));

            if (headers != null) {
                headers.forEach((k, v) -> {
                    post.setHeader(k, (String) v);
                });
            }

            post.setEntity(new StringEntity(param.toString(), "UTF-8"));

            response = httpClient.execute(post);
            return DataUtils.toBodyString(response.getEntity());
        } catch (Exception e) {
            log.error(url + " - " + e.getMessage(), e);
        } finally {
            IOUtils.close(response);
            IOUtils.close(httpClient);
        }
        return "";
    }


    /**
     * 文件下载
     *
     * @param url   接口地址
     * @param param json参数
     * @return 返回
     */
    public static String sendGetFile(String url, JSONObject param) {
        CloseableHttpClient httpClient = null;
        CloseableHttpResponse response = null;
        try {
            httpClient = getHttpClient();
            HttpPost post = new HttpPost(url);
            RequestConfig requestConfig = RequestConfig.custom().setConnectionRequestTimeout(600000)
                    .setConnectTimeout(600000).setSocketTimeout(600000).build();
            post.setConfig(requestConfig);
            if (param == null) {
                param = new JSONObject();
            }
            log.info(url + "参数：{}", param.toJSONString());
            final MultipartEntityBuilder builder = MultipartEntityBuilder.create();
            if (param.size() > 0) {
                JSONObject finalParam = param;
                param.forEach((k, v) -> {
                    builder.addTextBody(k, JsonUtils.getStr(finalParam, k), ContentType.APPLICATION_FORM_URLENCODED);
                });
            }
            builder.setCharset(StandardCharsets.UTF_8);
            builder.setContentType(ContentType.MULTIPART_FORM_DATA);
            HttpEntity multiPartEntity = builder.build();
            post.setEntity(multiPartEntity);

            response = httpClient.execute(post);
            if (response.getStatusLine().getStatusCode() == 200) {
                // 得到实体
                HttpEntity entity = response.getEntity();
                InputStream in = entity.getContent();
                String filePath = "/tmp/" + IdGen.uuid() + ".pdf";
                File file = new File(filePath);
                FileOutputStream fout = null;
                try {
                    fout = new FileOutputStream(file);
                    int l = -1;
                    byte[] tmp = new byte[1024];
                    while ((l = in.read(tmp)) != -1) {
                        fout.write(tmp, 0, l);
                    }
                    fout.flush();
                    return filePath;
                } catch (Exception e) {
                    log.error(e.getMessage(), e);
                } finally {
                    IOUtils.close(fout);
                    IOUtils.close(in);
                }
            }
        } catch (Exception e) {
            log.error(e.getMessage(), e);
        } finally {
            IOUtils.close(response);
            IOUtils.close(httpClient);
        }
        return "";
    }
}

