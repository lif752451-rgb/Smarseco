package com.crc.common.utils;

import lombok.extern.slf4j.Slf4j;

import javax.servlet.http.HttpServletRequest;
import java.io.BufferedReader;
import java.util.Arrays;
import java.util.Enumeration;

@Slf4j
public class ReqeustUtils {
    public static void printRequest(HttpServletRequest request) {
        log.info("getParameterMap()");
        request.getParameterMap().forEach((k, v) -> {
            log.info("key=" + k + ",val=" + Arrays.toString(v));
        });

        log.info("getHeaderNames()");
        Enumeration<String> headerNames = request.getHeaderNames();
        while (headerNames.hasMoreElements()) {
            String k = headerNames.nextElement();
            String v = request.getHeader(k);
            log.info("key=" + k + ",val=" + v);
        }
    }


    public static String getRequestBody(HttpServletRequest request) {
        BufferedReader br = null;
        StringBuilder sb = new StringBuilder();
        String str = "";
        try {
            br = request.getReader();
            while ((str = br.readLine()) != null) {
                sb.append(str);
            }
        } catch (Exception e) {
            log.error(e.getMessage(),e);
        } finally {
            IOUtils.close(br);
        }
        return sb.toString();
    }
}
