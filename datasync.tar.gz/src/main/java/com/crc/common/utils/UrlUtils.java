package com.crc.common.utils;

import com.crc.secface.domain.vo.IpPortVo;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;

import java.net.URI;
import java.net.URL;
import java.util.ArrayList;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;


@Slf4j
public class UrlUtils {
    public static IpPortVo getIpAndPort(String url) {
        IpPortVo vo = new IpPortVo();
        try {
            if (StringUtils.isNotBlank(url)) {
                URL uvo = new URL(url);
                vo.setPort(uvo.getPort());
                if (vo.getPort() == -1) {
                    if (url.toLowerCase().startsWith("https")) {
                        vo.setPort(443);
                    }else if (url.toLowerCase().startsWith("http")) {
                        vo.setPort(80);
                    }
                }
                vo.setIp(uvo.getHost());
            }
        } catch (Exception ignored) {

        }
        return vo;
    }

    public static String getDomain(String urlStr) {
        String hostName = "";
        if (StringUtils.isBlank(urlStr)) {
            return hostName;
        }
        if (urlStr.startsWith("https://") || urlStr.startsWith("http://")) {

        } else {
            urlStr = "http://" + urlStr;
        }
        try {
            URL url = new URL(urlStr);
            return url.getHost(); // 获取主机名
        } catch (Exception ignored) {

        }
        return urlStr;
    }


    public static List<String> getHosts(String ipString) {
        List<String> hosts = new ArrayList<>();
        if (StringUtils.isBlank(ipString))
            return hosts;
        try {
            //String regex = "((http://)?|(https://)?)([0-9]{1,3}(.[0-9]{1,3}){3}(:(\\d){2,4}))|([a-zA-Z0-9]+(.[a-zA-Z0-9]*){0,2}\\.(com.cn|net.cn|gov.cn|org.nz|org.cn|com|net|org|gov|cc|biz|info|cn|co|com.hk))";
            String regex = "((http://)?|(https://)?)([a-zA-Z0-9]+(.[a-zA-Z0-9]*){0,2}\\.(com.cn|net.cn|gov.cn|org.nz|org.cn|com|net|org|gov|cc|biz|info|cn|co|com.hk))";
            Pattern p = Pattern.compile(regex, Pattern.CASE_INSENSITIVE);
            Matcher matcher = p.matcher(ipString);
            while (matcher.find()) {
                hosts.add(matcher.group());
            }
        } catch (Exception ignored) {

        }
        return hosts;
    }

    /*
    是否合法URL
     */
    public static boolean isValidUrl(String urlString) {
        if (StringUtils.isBlank(urlString)) {
            return false;
        }
        URI uri = null;
        try {
            uri = new URI(urlString);
        } catch (Exception e) {
            return false;
        }
        if (uri.getHost() == null) {
            return false;
        }
        return uri.getScheme().equalsIgnoreCase("http") || uri.getScheme().equalsIgnoreCase("https");
    }
}
