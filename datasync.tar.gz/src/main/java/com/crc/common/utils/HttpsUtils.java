package com.crc.common.utils;

import com.alibaba.fastjson.JSONObject;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.apache.http.HttpHeaders;
import sun.net.www.protocol.https.Handler;

import javax.net.ssl.*;
import java.io.*;
import java.net.InetSocketAddress;
import java.net.Proxy;
import java.net.URL;
import java.net.URLDecoder;
import java.security.cert.X509Certificate;
import java.util.HashMap;

@Slf4j
public class HttpsUtils {
    private static final int CONN_TIME_OUT = 60000;
    private static final int READ_TIME_OUT = 60000;

    /**
     * 向指定 URL 发送GET方法的请求
     *
     * @param url   发送请求的 URL
     * @param param 请求参数，请求参数应该是 name1=value1&name2=value2 的形式。
     * @return 所代表远程资源的响应结果
     */
    public static String sendSSLGet(String url, String param, HashMap<String, String> headerMap) {
        StringBuilder result = new StringBuilder();
        BufferedReader in = null;
        HttpsURLConnection httpsConnection = null;
        try {
            // 创建SSLContext
            SSLContext sslContext = SSLContext.getInstance("SSL");
            sslContext.init(null, new TrustManager[]{new TrustAnyTrustManager()}, new java.security.SecureRandom());
// 获取SSLSocketFactory对象
            SSLSocketFactory ssf = sslContext.getSocketFactory();
            HostnameVerifier HostnameVerifier = (var1, var2) -> true;
            String urlNameString = url + "?" + param;
            if (StringUtils.isBlank(param)) {
                urlNameString = url;
            }
            log.info("sendSSLGet - " + urlNameString);
            URL requestUrl = new URL(null, urlNameString, new Handler());
            httpsConnection = (HttpsURLConnection) requestUrl.openConnection();
            httpsConnection.setDoOutput(false);
            httpsConnection.setDoInput(true);
            httpsConnection.setConnectTimeout(CONN_TIME_OUT);
            httpsConnection.setReadTimeout(READ_TIME_OUT);
            httpsConnection.setRequestProperty("Content-Type", "application/json;charset=UTF-8");
            httpsConnection.setRequestProperty("Charset", "UTF-8");
            httpsConnection.setRequestProperty("User-Agent", "Client identifier");
            httpsConnection.setRequestMethod("GET");
            if (headerMap != null) {
                headerMap.forEach(httpsConnection::setRequestProperty);
            }
// 设置当前实例使用的SSLSoctetFactory
            httpsConnection.setSSLSocketFactory(ssf);
            httpsConnection.setHostnameVerifier(HostnameVerifier);
            httpsConnection.connect();
            in = new BufferedReader(new InputStreamReader(httpsConnection.getInputStream()));
            String line;
            while ((line = in.readLine()) != null) {
                result.append(line);
            }
        } catch (IOException e) {
            log.error(url + " http请求错误 " + e.getMessage(), e);
            if (httpsConnection != null) {
                try {
                    in = new BufferedReader(new InputStreamReader(httpsConnection.getErrorStream()));
                    String line;
                    while ((line = in.readLine()) != null) {
                        result.append(line);
                    }
                } catch (Exception e1) {
                    //log.error(url + " http请求错误1 " + e1.getMessage(), e1);
                }
            }
        } catch (Exception e) {
            log.error(url + " http请求错误 " + e.getMessage(), e);
        } finally {
            IOUtils.close(in);
            IOUtils.close(httpsConnection);
        }
        return result.toString();
    }

    /**
     * 向指定 URL 发送GET方法的请求
     *
     * @param url   发送请求的 URL
     * @param param 请求参数，请求参数应该是 name1=value1&name2=value2 的形式。
     * @return 所代表远程资源的响应结果
     */
    public static String sendSSLGetProxy(String url, String param, String proxyIp, int proxyPort) {
        StringBuilder result = new StringBuilder();
        BufferedReader in = null;
        HttpsURLConnection httpsConnection = null;
        try {
            // 创建SSLContext
            SSLContext sslContext = SSLContext.getInstance("SSL");
            sslContext.init(null, new TrustManager[]{new TrustAnyTrustManager()}, new java.security.SecureRandom());
// 获取SSLSocketFactory对象
            SSLSocketFactory ssf = sslContext.getSocketFactory();
            HostnameVerifier HostnameVerifier = (var1, var2) -> true;
            String urlNameString = url + "?" + param;
            if (StringUtils.isBlank(param)) {
                urlNameString = url;
            }
            log.info("sendSSLGetProxy - proxy={}:{} -->" + urlNameString, proxyIp, proxyPort);
            Proxy proxy = new Proxy(Proxy.Type.HTTP, new InetSocketAddress(proxyIp, proxyPort));
            URL requestUrl = new URL(null, urlNameString, new Handler());
            httpsConnection = (HttpsURLConnection) requestUrl.openConnection(proxy);
            httpsConnection.setDoOutput(false);
            httpsConnection.setDoInput(true);
            httpsConnection.setConnectTimeout(CONN_TIME_OUT);
            httpsConnection.setReadTimeout(READ_TIME_OUT);
            httpsConnection.setRequestProperty("Content-Type", "application/json;charset=UTF-8");
            httpsConnection.setRequestProperty("Charset", "UTF-8");
            httpsConnection.setRequestProperty("User-Agent", "Client identifier");
            httpsConnection.setRequestMethod("GET");
// 设置当前实例使用的SSLSoctetFactory
            httpsConnection.setSSLSocketFactory(ssf);
            httpsConnection.setHostnameVerifier(HostnameVerifier);
            httpsConnection.connect();
            in = new BufferedReader(new InputStreamReader(httpsConnection.getInputStream()));
            String line;
            while ((line = in.readLine()) != null) {
                result.append(line);
            }
        } catch (IOException e) {
            log.error(url + " http请求错误 " + e.getMessage(), e);
            if (httpsConnection != null) {
                try {
                    in = new BufferedReader(new InputStreamReader(httpsConnection.getErrorStream()));
                    String line;
                    while ((line = in.readLine()) != null) {
                        result.append(line);
                    }
                } catch (Exception e1) {
                    //log.error(url + " http请求错误1 " + e1.getMessage(), e1);
                }
            }
        } catch (Exception e) {
            log.error(url + " http请求错误 " + e.getMessage(), e);
        } finally {
            IOUtils.close(in);
            IOUtils.close(httpsConnection);
        }
        return result.toString();
    }


    /**
     * 向指定 URL 发送GET方法的请求
     *
     * @param url   发送请求的 URL
     * @param param 请求参数，请求参数应该是 name1=value1&name2=value2 的形式。
     * @return 所代表远程资源的响应结果
     */
    public static String sendSSLGet(String url, String param) {
        StringBuilder result = new StringBuilder();
        BufferedReader in = null;
        HttpsURLConnection httpsConnection = null;
        try {
            // 创建SSLContext
            SSLContext sslContext = SSLContext.getInstance("SSL");
            sslContext.init(null, new TrustManager[]{new TrustAnyTrustManager()}, new java.security.SecureRandom());
// 获取SSLSocketFactory对象
            SSLSocketFactory ssf = sslContext.getSocketFactory();
            HostnameVerifier HostnameVerifier = (var1, var2) -> true;
            String urlNameString = url + "?" + param;
            if (StringUtils.isBlank(param)) {
                urlNameString = url;
            }
            log.info("sendSSLGet - " + urlNameString);
            URL requestUrl = new URL(null, urlNameString, new Handler());
            httpsConnection = (HttpsURLConnection) requestUrl.openConnection();
            httpsConnection.setDoOutput(false);
            httpsConnection.setDoInput(true);
            httpsConnection.setConnectTimeout(CONN_TIME_OUT);
            httpsConnection.setReadTimeout(READ_TIME_OUT);
            httpsConnection.setRequestProperty("Content-Type", "application/json;charset=UTF-8");
            httpsConnection.setRequestProperty("Charset", "UTF-8");
            httpsConnection.setRequestProperty("User-Agent", "Client identifier");
            httpsConnection.setRequestMethod("GET");
// 设置当前实例使用的SSLSoctetFactory
            httpsConnection.setSSLSocketFactory(ssf);
            httpsConnection.setHostnameVerifier(HostnameVerifier);
            httpsConnection.connect();
            in = new BufferedReader(new InputStreamReader(httpsConnection.getInputStream()));
            String line;
            while ((line = in.readLine()) != null) {
                result.append(line);
            }
        } catch (IOException e) {
            log.error(url + " http请求错误 " + e.getMessage(), e);
            if (httpsConnection != null) {
                try {
                    in = new BufferedReader(new InputStreamReader(httpsConnection.getErrorStream()));
                    String line;
                    while ((line = in.readLine()) != null) {
                        result.append(line);
                    }
                } catch (Exception e1) {
                    //log.error(url + " http请求错误1 " + e1.getMessage(), e1);
                }
            }
        } catch (Exception e) {
            log.error(url + " http请求错误 " + e.getMessage(), e);
        } finally {
            IOUtils.close(in);
            IOUtils.close(httpsConnection);
        }
        return result.toString();
    }

    /**
     * @param url  对方地址
     * @param json 要传送的数据
     * @return
     */
    public static String sendPost(String url, String json) {
        OutputStreamWriter out = null;
        BufferedReader in = null;
        StringBuilder result = new StringBuilder();
        HttpsURLConnection httpsConnection = null;
        try {
            SSLContext sslContext = SSLContext.getInstance("SSL");
            sslContext.init(null, new TrustManager[]{new TrustAnyTrustManager()}, new java.security.SecureRandom());
            log.info("sendPost - " + url + ",JSON参数：" + DataUtils.hidePsw(json));
            // 获取SSLSocketFactory对象
            HostnameVerifier HostnameVerifier = (var1, var2) -> true;
            URL urlObj = new URL(null, url.replace("\n", "").replace(" ", ""), new Handler());
            httpsConnection = (HttpsURLConnection) urlObj.openConnection();
            httpsConnection.setSSLSocketFactory(sslContext.getSocketFactory());
            // 设置doOutput属性为true表示将使用此urlConnection写入数据
            httpsConnection.setDoOutput(true);
            // 定义待写入数据的内容类型，我们设置为application/x-www-form-urlencoded类型
            httpsConnection.setRequestProperty("Content-Type", "application/json");
            httpsConnection.setConnectTimeout(CONN_TIME_OUT);
            httpsConnection.setReadTimeout(READ_TIME_OUT);
            httpsConnection.setHostnameVerifier(HostnameVerifier);
            // 得到请求的输出流对象
            out = new OutputStreamWriter(httpsConnection.getOutputStream());
            // 把数据写入请求的Body
            if (StringUtils.isNotBlank(json))
                out.write(json);
            out.flush();
            // 定义BufferedReader输入流来读取URL的响应
            in = new BufferedReader(new InputStreamReader(httpsConnection.getInputStream()));
            String line;
            while ((line = in.readLine()) != null) {
                result.append(line);
            }
        } catch (IOException e) {
            log.error(url + " https请求错误 " + e.getMessage(), e);
            if (httpsConnection != null) {
                try {
                    in = new BufferedReader(new InputStreamReader(httpsConnection.getErrorStream()));
                    String line;
                    while ((line = in.readLine()) != null) {
                        result.append(line);
                    }
                } catch (Exception e1) {
                    //log.error(url + " http请求错误1 " + e1.getMessage(), e1);
                }
            }
        } catch (Exception e) {
            log.error(url + " http请求错误 " + e.getMessage(), e);
        }
        // 使用finally块来关闭输出流、输入流
        finally {
            IOUtils.close(in);
            IOUtils.close(out);
            IOUtils.close(httpsConnection);
        }
        return result.toString();
    }

    public static String sendGet(String url, String param, String token) {
        StringBuilder result = new StringBuilder();
        BufferedReader in = null;
        HttpsURLConnection httpsConnection = null;
        try {
            // 创建SSLContext
            SSLContext sslContext = SSLContext.getInstance("SSL");
            sslContext.init(null, new TrustManager[]{new TrustAnyTrustManager()}, new java.security.SecureRandom());
            // 获取SSLSocketFactory对象
            SSLSocketFactory ssf = sslContext.getSocketFactory();
            HostnameVerifier HostnameVerifier = (var1, var2) -> true;
            String urlNameString = url + "?" + param;
            if (StringUtils.isBlank(param)) {
                urlNameString = url;
            }
            log.info("sendGet - " + urlNameString + " param=" + param);
            URL requestUrl = new URL(null, urlNameString, new Handler());
            httpsConnection = (HttpsURLConnection) requestUrl.openConnection();
            httpsConnection.setDoOutput(false);
            httpsConnection.setDoInput(true);
            httpsConnection.setConnectTimeout(CONN_TIME_OUT);
            httpsConnection.setReadTimeout(READ_TIME_OUT);
            httpsConnection.setRequestProperty("accept", "*/*");
            httpsConnection.setRequestProperty("connection", "Keep-Alive");
            httpsConnection.setRequestProperty("user-agent", "Mozilla/4.0 (compatible; MSIE 6.0; Windows NT 5.1;SV1)");
            httpsConnection.setRequestProperty(HttpHeaders.AUTHORIZATION, token);
            httpsConnection.setRequestProperty("Cookie", "X-Subject-Token=" + token);
            httpsConnection.setRequestProperty("Content-Type", "application/json");
            httpsConnection.setRequestMethod("GET");
            // 设置当前实例使用的SSLSoctetFactory
            httpsConnection.setSSLSocketFactory(ssf);
            httpsConnection.setHostnameVerifier(HostnameVerifier);
            httpsConnection.connect();
            in = new BufferedReader(new InputStreamReader(httpsConnection.getInputStream()));
            String line;
            while ((line = in.readLine()) != null) {
                result.append(line);
            }
        } catch (IOException e) {
            log.error(url + " http请求错误 " + e.getMessage(), e);
            if (httpsConnection != null) {
                try {
                    in = new BufferedReader(new InputStreamReader(httpsConnection.getErrorStream()));
                    String line;
                    while ((line = in.readLine()) != null) {
                        result.append(line);
                    }
                } catch (Exception e1) {
                    //log.error(url + " http请求错误1 " + e1.getMessage(), e1);
                }
            }
        } catch (Exception e) {
            log.error(url + " http请求错误 " + e.getMessage(), e);
        } finally {
            IOUtils.close(in);
            IOUtils.close(httpsConnection);
        }
        return result.toString();
    }

    public static String sendGet(String url, String param, JSONObject headers) {
        StringBuilder result = new StringBuilder();
        BufferedReader in = null;
        HttpsURLConnection httpsConnection = null;
        try {
            // 创建SSLContext
            SSLContext sslContext = SSLContext.getInstance("SSL");
            sslContext.init(null, new TrustManager[]{new TrustAnyTrustManager()}, new java.security.SecureRandom());
            // 获取SSLSocketFactory对象
            SSLSocketFactory ssf = sslContext.getSocketFactory();
            HostnameVerifier HostnameVerifier = (var1, var2) -> true;
            String urlNameString = url + "?" + param;
            if (StringUtils.isBlank(param)) {
                urlNameString = url;
            }
            log.info("sendGet - " + urlNameString + " param=" + headers.toString());
            URL requestUrl = new URL(null, urlNameString, new Handler());
            httpsConnection = (HttpsURLConnection) requestUrl.openConnection();
            httpsConnection.setDoOutput(false);
            httpsConnection.setDoInput(true);
            httpsConnection.setConnectTimeout(CONN_TIME_OUT);
            httpsConnection.setReadTimeout(READ_TIME_OUT);
            httpsConnection.setRequestProperty("Content-Type", "application/json;charset=UTF-8");
            httpsConnection.setRequestProperty("Charset", "UTF-8");
            httpsConnection.setRequestProperty("user-agent", "Mozilla/4.0 (compatible; MSIE 6.0; Windows NT 5.1;SV1)");
            if (headers != null) {
                HttpsURLConnection finalConnection = httpsConnection;
                headers.forEach((k, v) -> {
                    try {
                        if (v != null) {
                            finalConnection.setRequestProperty(k, v.toString());
                        }
                    } catch (Exception e) {
                        log.error(e.getMessage(), e);
                    }
                });
            }
            httpsConnection.setRequestMethod("GET");
            // 设置当前实例使用的SSLSoctetFactory
            httpsConnection.setSSLSocketFactory(ssf);
            httpsConnection.setHostnameVerifier(HostnameVerifier);
            httpsConnection.connect();
            in = new BufferedReader(new InputStreamReader(httpsConnection.getInputStream()));
            String line;
            while ((line = in.readLine()) != null) {
                result.append(line);
            }
        } catch (IOException e) {
            log.error(url + " http请求错误 " + e.getMessage(), e);
            if (httpsConnection != null) {
                try {
                    in = new BufferedReader(new InputStreamReader(httpsConnection.getErrorStream()));
                    String line;
                    while ((line = in.readLine()) != null) {
                        result.append(line);
                    }
                } catch (Exception e1) {
                    //log.error(url + " http请求错误1 " + e1.getMessage(), e1);
                }
            }
        } catch (Exception e) {
            log.error(url + " http请求错误 " + e.getMessage(), e);
        } finally {
            IOUtils.close(in);
            IOUtils.close(httpsConnection);
        }
        return result.toString();
    }


    public static String sendGetProxy(String url, String param, JSONObject headers, String proxyIp, int proxyPort) {
        StringBuilder result = new StringBuilder();
        BufferedReader in = null;
        HttpsURLConnection httpsConnection = null;
        try {
            // 创建SSLContext
            SSLContext sslContext = SSLContext.getInstance("SSL");
            sslContext.init(null, new TrustManager[]{new TrustAnyTrustManager()}, new java.security.SecureRandom());
            // 获取SSLSocketFactory对象
            SSLSocketFactory ssf = sslContext.getSocketFactory();
            HostnameVerifier HostnameVerifier = (var1, var2) -> true;
            String urlNameString = url + "?" + param;
            if (StringUtils.isBlank(param)) {
                urlNameString = url;
            }
            log.info("sendGetProxy - proxy={}:{} -->" + urlNameString, proxyIp, proxyPort);
            Proxy proxy = new Proxy(Proxy.Type.HTTP, new InetSocketAddress(proxyIp, proxyPort));
            URL requestUrl = new URL(null, urlNameString, new Handler());
            httpsConnection = (HttpsURLConnection) requestUrl.openConnection(proxy);
            httpsConnection.setDoOutput(false);
            httpsConnection.setDoInput(true);
            httpsConnection.setConnectTimeout(CONN_TIME_OUT);
            httpsConnection.setReadTimeout(READ_TIME_OUT);
            httpsConnection.setRequestProperty("Content-Type", "application/json;charset=UTF-8");
            httpsConnection.setRequestProperty("Charset", "UTF-8");
            httpsConnection.setRequestProperty("user-agent", "Mozilla/4.0 (compatible; MSIE 6.0; Windows NT 5.1;SV1)");
            if (headers != null) {
                HttpsURLConnection finalConnection = httpsConnection;
                headers.forEach((k, v) -> {
                    try {
                        if (v != null) {
                            finalConnection.setRequestProperty(k, v.toString());
                        }
                    } catch (Exception e) {
                        log.error(e.getMessage(), e);
                    }
                });
            }
            httpsConnection.setRequestMethod("GET");
            // 设置当前实例使用的SSLSoctetFactory
            httpsConnection.setSSLSocketFactory(ssf);
            httpsConnection.setHostnameVerifier(HostnameVerifier);
            httpsConnection.connect();
            in = new BufferedReader(new InputStreamReader(httpsConnection.getInputStream()));
            String line;
            while ((line = in.readLine()) != null) {
                result.append(line);
            }
        } catch (IOException e) {
            log.error(url + " http请求错误 " + e.getMessage(), e);
            if (httpsConnection != null) {
                try {
                    in = new BufferedReader(new InputStreamReader(httpsConnection.getErrorStream()));
                    String line;
                    while ((line = in.readLine()) != null) {
                        result.append(line);
                    }
                } catch (Exception e1) {
                    //log.error(url + " http请求错误1 " + e1.getMessage(), e1);
                }
            }
        } catch (Exception e) {
            log.error(url + " http请求错误 " + e.getMessage(), e);
        } finally {
            IOUtils.close(in);
            IOUtils.close(httpsConnection);
        }
        return result.toString();
    }

    public static String sendPost(String urlPath, String json, JSONObject headers) {
        OutputStreamWriter out = null;
        BufferedReader in = null;
        StringBuilder result = new StringBuilder();
        HttpsURLConnection httpsConnection = null;
        try {
            SSLContext sslContext = SSLContext.getInstance("SSL");
            sslContext.init(null, new TrustManager[]{new TrustAnyTrustManager()}, new java.security.SecureRandom());
            log.info("sendPost - " + urlPath + ",JSON参数：" + DataUtils.hidePsw(json) + ",header:" + headers.toJSONString());
            // 获取SSLSocketFactory对象
            HostnameVerifier hostnameVerifier = (var1, var2) -> true;
            URL url = new URL(null, urlPath.replace("\n", "").replace(" ", ""), new Handler());
            httpsConnection = (HttpsURLConnection) url.openConnection();
            httpsConnection.setSSLSocketFactory(sslContext.getSocketFactory());
            // 设置doOutput属性为true表示将使用此urlConnection写入数据
            httpsConnection.setDoOutput(true);
            //httpsConnection.setRequestProperty("Content-Type", "application/json;charset=UTF-8");
            //httpsConnection.setRequestProperty("Charset", "UTF-8");
            //httpsConnection.setRequestProperty("user-agent", "Mozilla/4.0 (compatible; MSIE 6.0; Windows NT 5.1;SV1)");
            // 定义待写入数据的内容类型，我们设置为application/x-www-form-urlencoded类型
            httpsConnection.setRequestProperty("Content-Type", "application/json");
            if (headers != null) {
                HttpsURLConnection finalConnection = httpsConnection;
                headers.forEach((k, v) -> {
                    try {
                        if (v != null) {
                            finalConnection.setRequestProperty(k, v.toString());
                        }
                    } catch (Exception e) {
                        log.error(e.getMessage(), e);
                    }
                });
            }
            httpsConnection.setConnectTimeout(CONN_TIME_OUT);
            httpsConnection.setReadTimeout(READ_TIME_OUT);
            httpsConnection.setHostnameVerifier(hostnameVerifier);
            // 得到请求的输出流对象
            out = new OutputStreamWriter(httpsConnection.getOutputStream());
            // 把数据写入请求的Body
            if (StringUtils.isNotBlank(json))
                out.write(json);
            out.flush();
            // 定义BufferedReader输入流来读取URL的响应
            in = new BufferedReader(new InputStreamReader(httpsConnection.getInputStream()));
            String line;
            while ((line = in.readLine()) != null) {
                result.append(line);
            }
        } catch (IOException e) {
            log.error(urlPath + " http请求错误 " + e.getMessage(), e);
            if (httpsConnection != null) {
                try {
                    in = new BufferedReader(new InputStreamReader(httpsConnection.getErrorStream()));
                    String line;
                    while ((line = in.readLine()) != null) {
                        result.append(line);
                    }
                } catch (Exception e1) {
                    //log.error(urlPath + " http请求错误1 " + e1.getMessage(), e1);
                }
            }
        } catch (Exception e) {
            log.info("sendPost - " + urlPath + ",JSON参数：" + json + ",header:" + headers.toJSONString());
            log.error(urlPath + " http请求错误 " + e.getMessage(), e);
        }
        // 使用finally块来关闭输出流、输入流
        finally {
            IOUtils.close(in);
            IOUtils.close(out);
            IOUtils.close(httpsConnection);
        }
        return result.toString();
    }

    /**
     * @param urlPath 对方地址
     * @param param   要传送的数据
     * @param heads
     * @return
     */
    public static String sendPostForm(String urlPath, String param, HashMap<String, String> heads) {
        OutputStream out = null;
        BufferedReader in = null;
        StringBuilder result = new StringBuilder();
        HttpsURLConnection httpsConnection = null;
        try {
            SSLContext sslContext = SSLContext.getInstance("SSL");
            sslContext.init(null, new TrustManager[]{new TrustAnyTrustManager()}, new java.security.SecureRandom());
            log.info("sendPost - " + urlPath + ",参数：" + DataUtils.hidePsw(param));
            // 获取SSLSocketFactory对象
            HostnameVerifier HostnameVerifier = (var1, var2) -> true;
            URL url = new URL(null, urlPath.replace("\n", "").replace(" ", ""), new Handler());
            httpsConnection = (HttpsURLConnection) url.openConnection();
            httpsConnection.setSSLSocketFactory(sslContext.getSocketFactory());
            // 设置doOutput属性为true表示将使用此urlConnection写入数据
            httpsConnection.setDoOutput(true);
            // 定义待写入数据的内容类型，我们设置为application/x-www-form-urlencoded类型
            httpsConnection.setRequestProperty("accept", "*/*");
            httpsConnection.setRequestProperty("Connection", "Keep-Alive");
            httpsConnection.setRequestProperty("Charset", "UTF-8");
            httpsConnection.setRequestProperty("Content-Type", "application/x-www-form-urlencoded; charset=UTF-8");
            httpsConnection.setConnectTimeout(CONN_TIME_OUT);
            httpsConnection.setReadTimeout(READ_TIME_OUT);
            httpsConnection.setHostnameVerifier(HostnameVerifier);
            if (heads != null) {
                for (String key : heads.keySet()) {
                    httpsConnection.setRequestProperty(key, heads.get(key));
                }
            }
            // 得到请求的输出流对象
            out = httpsConnection.getOutputStream();
            // 把数据写入请求的Body
            if (StringUtils.isNotBlank(param)) {
                out.write(param.getBytes());
            }
            out.flush();
            // 定义BufferedReader输入流来读取URL的响应
            in = new BufferedReader(new InputStreamReader(httpsConnection.getInputStream()));
            String line;
            while ((line = in.readLine()) != null) {
                result.append(line);
            }
            return result.toString();
        } catch (IOException e) {
            log.error(urlPath + " http请求错误 " + e.getMessage(), e);
            if (httpsConnection != null) {
                try {
                    in = new BufferedReader(new InputStreamReader(httpsConnection.getErrorStream()));
                    String line;
                    while ((line = in.readLine()) != null) {
                        result.append(line);
                    }
                } catch (Exception e1) {
                    //log.error(urlPath + " http请求错误1 " + e1.getMessage(), e1);
                }
            }
        } catch (Exception e) {
            log.error(urlPath + " http请求错误 " + e.getMessage(), e);
        }
        // 使用finally块来关闭输出流、输入流
        finally {
            IOUtils.close(in);
            IOUtils.close(out);
            IOUtils.close(httpsConnection);
        }
        return null;
    }

    /**
     * @param urlPath 对方地址
     * @param json    要传送的数据
     * @return
     */
    public static String sendPostSession(String urlPath, String json) {
        OutputStream out = null;
        BufferedReader in = null;
        StringBuilder result = new StringBuilder();
        HttpsURLConnection urlConnection = null;
        try {
            SSLContext sslContext = SSLContext.getInstance("SSL");
            sslContext.init(null, new TrustManager[]{new TrustAnyTrustManager()}, new java.security.SecureRandom());
            try {
                log.info("sendPost - " + urlPath + ",JSON参数：" + URLDecoder.decode(json));
            } catch (Exception ignored) {

            }
            // 获取SSLSocketFactory对象
            HostnameVerifier HostnameVerifier = (var1, var2) -> true;
            URL url = new URL(null, urlPath.replace("\n", "").replace(" ", ""), new Handler());
            urlConnection = (HttpsURLConnection) url.openConnection();
            urlConnection.setSSLSocketFactory(sslContext.getSocketFactory());
            // 设置doOutput属性为true表示将使用此urlConnection写入数据
            urlConnection.setDoOutput(true);
            // 定义待写入数据的内容类型，我们设置为application/x-www-form-urlencoded类型
            urlConnection.setRequestProperty("accept", "*/*");
            urlConnection.setRequestProperty("Connection", "Keep-Alive");
            urlConnection.setRequestProperty("Charset", "UTF-8");
            urlConnection.setRequestProperty("Content-Type", "application/x-www-form-urlencoded; charset=UTF-8");
            urlConnection.setConnectTimeout(CONN_TIME_OUT);
            urlConnection.setReadTimeout(READ_TIME_OUT);
            urlConnection.setHostnameVerifier(HostnameVerifier);
            // 得到请求的输出流对象
            out = urlConnection.getOutputStream();
            // 把数据写入请求的Body
            if (StringUtils.isNotBlank(json)) {
                out.write(json.getBytes());
            }
            out.flush();
            // 定义BufferedReader输入流来读取URL的响应
            in = new BufferedReader(new InputStreamReader(urlConnection.getInputStream()));
            String line;
            while ((line = in.readLine()) != null) {
                result.append(line);
            }
            return result.toString();
        } catch (Exception e) {
            log.error(urlPath + " -- " + e.getMessage(), e);
        }
        // 使用finally块来关闭输出流、输入流
        finally {
            IOUtils.close(in);
            IOUtils.close(out);
            IOUtils.close(urlConnection);
        }
        return null;
    }

    public static class TrustAnyTrustManager implements X509TrustManager {
        @Override
        public void checkClientTrusted(X509Certificate[] chain, String authType) {
        }

        @Override
        public void checkServerTrusted(X509Certificate[] chain, String authType) {
        }

        @Override
        public X509Certificate[] getAcceptedIssuers() {
            return new X509Certificate[]{};
        }
    }

    private static class TrustAnyHostnameVerifier implements HostnameVerifier {
        @Override
        public boolean verify(String hostname, SSLSession session) {
            return true;
        }
    }

}
