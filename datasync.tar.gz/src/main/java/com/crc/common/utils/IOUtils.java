package com.crc.common.utils;

import lombok.extern.slf4j.Slf4j;
import org.apache.http.HttpConnection;
import org.apache.http.client.methods.CloseableHttpResponse;
import org.apache.http.impl.client.CloseableHttpClient;
import org.apache.http.util.EntityUtils;

import java.io.*;
import java.net.HttpURLConnection;

@Slf4j
public class IOUtils {
    public static void close(CloseableHttpResponse response) {
        try {
            if (response != null) {
                EntityUtils.consume(response.getEntity());
            }
        } catch (Exception e) {
            log.error(e.getMessage(), e);
        }
        try {
            if (response != null) {
                response.close();
            }
        } catch (Exception e) {
            log.error(e.getMessage(), e);
        }
    }

    public static void close(CloseableHttpClient httpClient) {
        try {
            if (httpClient != null) {
                httpClient.close();
            }
        } catch (Exception e) {
            log.error(e.getMessage(), e);
        }
    }

    public static void close(InputStream in) {
        try {
            if (in != null) {
                in.close();
            }
        } catch (Exception e) {
            log.error(e.getMessage(), e);
        }
    }

    public static void close(OutputStream out) {
        try {
            if (out != null) {
                out.close();
            }
        } catch (Exception e) {
            log.error(e.getMessage(), e);
        }
    }

    public static void close(HttpConnection connection) {
        try {
            if (connection != null) {
                connection.close();
            }
        } catch (Exception e) {
            log.error(e.getMessage(), e);
        }
    }

    public static void close( HttpURLConnection connection) {
        try {
            if (connection != null) {
                connection.disconnect();
            }
        } catch (Exception e) {
            log.error(e.getMessage(), e);
        }
    }

    public static void close( BufferedReader reader) {
        try {
            if (reader != null) {
                reader.close();
            }
        } catch (Exception e) {
            log.error(e.getMessage(), e);
        }
    }


    public static void close(OutputStreamWriter out) {
        try {
            if (out != null) {
                out.close();
            }
        } catch (Exception e) {
            log.error(e.getMessage(), e);
        }
    }

    public static void close(PrintWriter out) {
        try {
            if (out != null) {
                out.close();
            }
        } catch (Exception e) {
            log.error(e.getMessage(), e);
        }
    }
}
