package com.crc.common.utils;

import cn.hutool.core.util.StrUtil;
import com.crc.secface.domain.AssetSegementIp;
import com.googlecode.ipv6.IPv6Network;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import javax.servlet.http.HttpServletRequest;
import java.math.BigInteger;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

@Slf4j
public class IpUtils {
    public static final BigInteger a1 = getIp2long("10.0.0.1");
    public static final BigInteger a2 = getIp2long("10.255.255.254");
    public static final BigInteger b1 = getIp2long("172.16.0.1");
    public static final BigInteger b2 = getIp2long("172.31.255.254");
    public static final BigInteger c1 = getIp2long("192.168.0.1");
    public static final BigInteger c2 = getIp2long("192.168.255.254");
    public static boolean isInnerIP(String ip) {
        if (IpUtils.isIpv6(ip)) {
            return true;
        }
//        long n = getIp2long(ip);
//        if (n >= a1 && n <= a2) {
//            return true;
//        }
//        if (n >= b1 && n <= b2) {
//            return true;
//        }
//        return n >= c1 && n <= c2;
        BigInteger n = getIp2long(ip);
        if (n.compareTo(a1) >=0  && n.compareTo(a2) <= 0) {
            //log.info("{},a:{},{}",n.longValue(),a1.longValue(),a2.longValue());
            return true;
        }
        if (n.compareTo(b1) >=0  && n.compareTo(b2) <= 0) {
            //log.info("{},b:{},{}",n.longValue(),b1.longValue(),b2.longValue());
            return true;
        }
        //og.info("{},c:{},{}",n.longValue(),c1.longValue(),c2.longValue());
        return n.compareTo(c1) >= 0 && n.compareTo(c2) <= 0;
    }

    public static String[] getIpSegment(String segment) {
        if (StringUtils.isBlank(segment)) {
            return null;
        }
        segment = segment.replace(" ", "").replace(",", "\n").replace("\t", "").replaceAll(" ", "\n");
        return segment.split("\n");
    }

    public static String getIpAddr(HttpServletRequest request) {
        if (request == null) {
            return "unknown";
        }
        String ip = request.getHeader("x-forwarded-for");
        if (ip == null || ip.length() == 0 || "unknown".equalsIgnoreCase(ip) || "127.0.0.1".equals(ip)) {
            ip = request.getHeader("Proxy-Client-IP");
        }
        if (ip == null || ip.length() == 0 || "unknown".equalsIgnoreCase(ip) || "127.0.0.1".equals(ip)) {
            ip = request.getHeader("X-Forwarded-For");
        }
        if (ip == null || ip.length() == 0 || "unknown".equalsIgnoreCase(ip) || "127.0.0.1".equals(ip)) {
            ip = request.getHeader("WL-Proxy-Client-IP");
        }
        if (ip == null || ip.length() == 0 || "unknown".equalsIgnoreCase(ip) || "127.0.0.1".equals(ip)) {
            ip = request.getHeader("X-Real-IP");
        }
        if (ip == null || ip.length() == 0 || "unknown".equalsIgnoreCase(ip) || "127.0.0.1".equals(ip)) {
            ip = request.getRemoteAddr();
        }

        return "0:0:0:0:0:0:0:1".equals(ip) ? "127.0.0.1" : ip;
    }

    public static String long2Ip(long n) {
        return (n >> 24 & 0xFF) + "." + (n >> 16 & 0xFF) + "." + (n >> 8 & 0xFF) + "." + (n & 0xFF);
    }

    /**
     * @param ip IP
     * @param segment IP分段，1=A，2=B，3=C，4=D
     * @return long
     */
    public static long getIp2long(String ip, int segment) {
        ip = ip.trim();
        String[] ips = ip.split("\\.");
        long ip2long = 0L;
        for (int i = 0; i < segment; ++i) {
            ip2long = ip2long << 8 | Integer.parseInt(ips[i]);
        }
        return ip2long;
    }


    /**
     * 验证IP是否属于某个IP段
     * <p>
     * ipSection    IP段（以'-'分隔）
     * ip           所验证的IP号码
     */
    public static boolean ipExistsInRange(String ip, String ipSection, int segment) {
        ipSection = ipSection.trim();
        ip = ip.trim();
        int idx = ipSection.indexOf('-');
        if (idx == -1) {
            if (isIp(ipSection)) {
                return ipSection.equals(ip);
            }
            return false;
        }
        String beginIP = DataUtils.getSubString(ipSection, 0, idx);
        //ipSection.substring(0, idx);
        String endIP = DataUtils.getSubString(ipSection, idx + 1);
        //ipSection.substring(idx + 1);
        //System.out.println(ipSection);
        return getIp2long(beginIP, segment) <= getIp2long(ip, segment) && getIp2long(ip, segment) <= getIp2long(endIP, segment);
    }

    public static BigInteger getIp2long(String ipaddress) {
        if (!isIp(ipaddress)) {
            return BigInteger.ZERO;
        }
        try {
            return IpConvert.StringToBigInt(ipaddress);
        } catch (Exception ignored) {

        }
        return BigInteger.ZERO;
    }


    public static boolean isIp(String ipStr) {
        //System.out.print(ipStr + " ");
        if (isIpv4(ipStr)) {
            return true;
        } else {
            return isIpv6(ipStr);
        }
    }

    /**
     * 正则提取字符串中的IP地址
     *
     * @param ipString ip
     * @return list
     */
    public static List<String> getIps(String ipString) {
        String regEx = IP_REG;
        HashMap<String,String> ipMap = new HashMap<>();

        if (StringUtils.isBlank(ipString))
            return new ArrayList<>();
        Pattern p = Pattern.compile(regEx);
        Matcher m = p.matcher(ipString);
        while (m.find()) {
            String result = m.group();
            if (IpUtils.isIp(result.trim()))
                ipMap.put(result.trim(),"1");
        }
        String[] ipsNews0 = DataUtils.getSplit(ipString, " ");
        for (String ip : ipsNews0) {
            if (IpUtils.isIp(ip)) {
                ipMap.put(ip.trim(),"1");
            }
        }
        String[] ipsNews1 = DataUtils.getSplit(ipString, ",");
        for (String ip : ipsNews1) {
            if (IpUtils.isIp(ip)) {
                ipMap.put(ip.trim(),"1");
            }
        }
        String[] ipsNews2 = DataUtils.getSplit(ipString, "，");
        for (String ip : ipsNews2) {
            if (IpUtils.isIp(ip)) {
                ipMap.put(ip.trim(),"1");
            }
        }
        List<String> ips = new ArrayList<>();
        ipMap.forEach((k,v)->{
            ips.add(k);
        });
        return ips;
    }

    static String IP_REG = "((2[0-4]\\d|25[0-5]|[01]?\\d\\d?)\\.){3}(2[0-4]\\d|25[0-5]|[01]?\\d\\d?)";

    public static String getIpsX(String ipString) {
        try {
            Pattern p = Pattern.compile(IP_REG);
            Matcher m = p.matcher(ipString);
            while (m.find()) {
                String ip = m.group();
                if (isIp(ip)) {
                    return ip;
                }
            }
        } catch (Exception e) {
            log.error(e.getMessage(), e);
        }
        return "";
    }


    public static String getStartIp(String segment) {
        StringBuilder startIp = new StringBuilder();
        if (segment == null) {
            return null;
        }
        if(IpUtils.isIp(segment)){
            return segment;
        }
        String[] arr = segment.split("/");
        String ip = arr[0];
        if (arr.length < 2) {
            //log.error("ERROR getStartIp:" + segment);
            return null;
        }
        String maskIndex = arr[1];
        String mask = getNetMask(maskIndex);
        if (4 != ip.split("\\.").length || mask == null) {
            return null;
        }
        int[] ipArray = new int[4];
        int[] netMaskArray = new int[4];
        for (int i = 0; i < 4; i++) {
            try {
                ipArray[i] = Integer.parseInt(ip.split("\\.")[i]);
                netMaskArray[i] = Integer.parseInt(mask.split("\\.")[i]);
                if (ipArray[i] > 255 || ipArray[i] < 0 || netMaskArray[i] > 255 || netMaskArray[i] < 0) {
                    return null;
                }
                ipArray[i] = ipArray[i] & netMaskArray[i];
                if (i == 3) {
                    startIp.append(ipArray[i] + 1);
                } else {
                    startIp.append(ipArray[i]).append(".");
                }
            } catch (Exception e) {
                log.error("有错误网段数据" + e.getMessage(), e);
            }
        }
        return startIp.toString();
    }

    public static String getEndIp(String segment) {
        StringBuilder endIp = new StringBuilder();
        String startIp = getStartIp(segment);
        if (segment == null || startIp == null) {
            return null;
        }
        if(IpUtils.isIp(segment)){
            return segment;
        }
        String[] arr = segment.split("/");
        String maskIndex = arr[1];
        //实际需要的IP个数
        int hostNumber;
        int[] startIpArray = new int[4];
        try {
            hostNumber = 1 << 32 - (Integer.parseInt(maskIndex));
            for (int i = 0; i < 4; i++) {
                startIpArray[i] = Integer.parseInt(startIp.split("\\.")[i]);
                if (i == 3) {
                    startIpArray[i] = startIpArray[i] - 1;
                    break;
                }
            }
            startIpArray[3] = startIpArray[3] + (hostNumber - 1);
        } catch (Exception e) {
            log.error(e.getMessage(), e);
        }

        if (startIpArray[3] > 255) {
            int k = startIpArray[3] / 256;
            startIpArray[3] = startIpArray[3] % 256;
            startIpArray[2] = startIpArray[2] + k;
        }
        if (startIpArray[2] > 255) {
            int j = startIpArray[2] / 256;
            startIpArray[2] = startIpArray[2] % 256;
            startIpArray[1] = startIpArray[1] + j;
            if (startIpArray[1] > 255) {
                int k = startIpArray[1] / 256;
                startIpArray[1] = startIpArray[1] % 256;
                startIpArray[0] = startIpArray[0] + k;
            }
        }
        for (int i = 0; i < 4; i++) {
            if (i == 3) {
                startIpArray[i] = startIpArray[i] - 1;
            }
            if ("".equals(endIp.toString()) || endIp.length() == 0) {
                endIp.append(startIpArray[i]);
            } else {
                endIp.append(".").append(startIpArray[i]);
            }
        }
        return endIp.toString();
    }

    private static String getNetMask(String maskIndex) {
        StringBuilder mask = new StringBuilder();
        int inetMask;
        try {
            inetMask = Integer.parseInt(maskIndex);
        } catch (Exception e) {
            return null;
        }
        if (inetMask > 32) {
            return null;
        }
        // 子网掩码为1占了几个字节
        int num1 = inetMask / 8;
        // 子网掩码的补位位数
        int num2 = inetMask % 8;
        int[] array = new int[4];
        for (int i = 0; i < num1; i++) {
            array[i] = 255;
        }
        for (int i = num1; i < 4; i++) {
            array[i] = 0;
        }
        for (int i = 0; i < num2; num2--) {
            array[num1] += 1 << 8 - num2;
        }
        for (int i = 0; i < 4; i++) {
            if (i == 3) {
                mask.append(array[i]);
            } else {
                mask.append(array[i]).append(".");
            }
        }
        return mask.toString();
    }

    /**
     * Is ipv 4 boolean.
     */
    public static boolean isIpv4(String ipv4) {
        if (StringUtils.isBlank(ipv4)) {
            return false;
        }
        if (!ipv4.contains(".") && !ipv4.contains(":")) {
            return false;
        }
        //如果是IPV4
        if (ipv4.contains(".")) {
            if (ipv4.endsWith(".")) {
                return false;
            }
            String[] arr = ipv4.split("\\.");
            if (arr.length != 4) {
                return false;
            }

            for (int i = 0; i < 4; i++) {
                if (arr[i].length() == 0 || arr[i].length() > 3) {
                    return false;
                }
                for (int j = 0; j < arr[i].length(); j++) {
                    if (arr[i].charAt(j) >= '0' && arr[i].charAt(j) <= '9') {
                        continue;
                    }
                    return false;
                }
                if (Integer.parseInt(arr[i]) > 255 || (arr[i].length() >= 2 && String.valueOf(arr[i]).startsWith("0"))) {
                    return false;
                }
            }
            return true;
        }
        return false;
    }

    /**
     * Is ipv 6 boolean.
     */
    public static boolean isIpv6(String ipv6) {
        if (StringUtils.isBlank(ipv6)) {
            return false;
        }
        // 8*4 位数字，加上七个: ipv6地址长度不可能超过39位
        if (ipv6.length() > 39) {
            return false;
        }
        if (ipv6.endsWith(":") && !ipv6.endsWith("::")) {
            return false;
        }
        //如果包含多个“::”，一个IPv6地址中只能出现一个“::”
        if (ipv6.contains("::") && ipv6.indexOf("::", ipv6.indexOf("::") + 2) != -1) {
            return false;
        }

        //ipv6“::”
        if (ipv6.contains("::")) {
            String[] arr = ipv6.split(":");
            if (arr.length > 7 || arr.length < 1) {//"1::"是最短的字符串
                return false;
            }
            for (String s : arr) {
                if (s.equals("")) {
                    continue;
                }
                if (s.length() > 4) {
                    return false;
                }
                for (int j = 0; j < s.length(); j++) {
                    if ((s.charAt(j) >= '0' && s.charAt(j) <= '9') || (s.charAt(j) >= 'A' && s.charAt(j) <= 'F')
                            || (s.charAt(j) >= 'a' && s.charAt(j) <= 'f')) {
                        continue;
                    }
                    return false;
                }
            }
            return true;
        } else {//如果不含有“::”
            String[] arr = ipv6.split(":");
            if (arr.length != 8) {
                return false;
            }
            for (String s : arr) {
                if (s.length() > 4) {
                    return false;
                }
                for (int j = 0; j < s.length(); j++) {
                    if ((s.charAt(j) >= '0' && s.charAt(j) <= '9') || (s.charAt(j) >= 'A' && s.charAt(j) <= 'F')
                            || (s.charAt(j) >= 'a' && s.charAt(j) <= 'f')) {
                        continue;
                    }
                    return false;
                }
            }
            return true;
        }
    }

    public static String getFormatMac(String mac) {
        //f487c5a0c22b
        if (mac == null || mac.length() < 12) {
            return mac;
        }
        StringBuilder sb = new StringBuilder();
        for (int i = 0; i < 6; i++) {
            sb.append(mac, i*2, i*2 + 2);
            if (i != 5) {
                sb.append("-");
            }
        }
        return sb.toString().toUpperCase();
    }

    /**
     * 获取开始IP和结束IP
     *
     * @param segmentStr 网段
     * @return
     */
    public static List<AssetSegementIp> getSegementIpList(String segmentStr) {
        if (StrUtil.isEmpty(segmentStr)) {
            return Collections.emptyList();
        }
        String ipStr = segmentStr.replace(",", "\n").replace("\t", "").replaceAll("　", "").replaceAll(" ", "");
        String[] ipList = ipStr.split("\n");
        List<AssetSegementIp> list = new ArrayList<>();
        for (String cidr : ipList) {
            AssetSegementIp assetSegementIp = new AssetSegementIp();
            BigInteger []rets = getIpStartAndEnd(cidr);
            if (rets == null || rets.length != 2) {
                continue;
            }
            BigInteger startIp2long = rets[0];
            BigInteger endIp2long = rets[1];
            assetSegementIp.setSlip(startIp2long);
            assetSegementIp.setElip(endIp2long);
            if (DataUtils.bigTo0(assetSegementIp.getSlip()) && DataUtils.compareBigInt(assetSegementIp.getElip(), assetSegementIp.getSlip()) > -1) {
                list.add(assetSegementIp);
            }
        }
        return list;
    }

    /**
     * 获取 IP段的开始 IP 和结束 IP
     * @param cidr
     * @return
     */
    public static BigInteger[] getIpStartAndEnd(String cidr) {
        try {
            if (org.apache.commons.lang3.StringUtils.isBlank(cidr)) {
                return null;
            }
            cidr = cidr.trim();
            BigInteger startIp2long = null;
            BigInteger endIp2long = null;
            if (cidr.contains("-") && cidr.contains("/")) {
                String[] ips = cidr.split("-");
                if (ips.length <= 1) {
                    return null;
                }
                if (ips[0].contains(":")) {
                    if (IpUtils.isIP(ips[0].trim())) {
                        startIp2long = IpUtils.getIp2long(ips[0].trim());
                    } else {
                        try {
                            IPv6Network network = IPv6Network.fromString(ips[0]);
                            startIp2long = IpUtils.getIp2long(network.getFirst().toLongString());
                        } catch (Exception e) {
                            log.error("非法 IPV6掩码{}", ips[0]);
                        }
                    }

                } else {
                    startIp2long = IpUtils.getIp2long(IpUtils.getStartIp(ips[0].trim()));
                }
                if (ips[1].contains(":")) {
                    if (IpUtils.isIP(ips[1].trim())) {
                        endIp2long = IpUtils.getIp2long(ips[1].trim());
                    } else {
                        try {
                            IPv6Network network = IPv6Network.fromString(ips[1]);
                            endIp2long = IpUtils.getIp2long(network.getLast().toLongString());
                        } catch (Exception e) {
                            log.error("非法 IPV6掩码{}", ips[1]);
                        }
                    }
                } else {
                    endIp2long = IpUtils.getIp2long(IpUtils.getEndIp(ips[1].trim()));
                }
            } else if (cidr.contains("-")) {
                String[] ips = cidr.split("-");
                if (ips.length <= 1) {
                    return null;
                }
                if (ips[0].contains(":")) {
                    if (IpUtils.isIP(ips[0].trim())) {
                        startIp2long = IpUtils.getIp2long(ips[0].trim());
                    } else {
                        try {
                            IPv6Network network = IPv6Network.fromString(ips[0]);
                            startIp2long = IpUtils.getIp2long(network.getFirst().toLongString());
                        } catch (Exception e) {
                            log.error("非法 IPV6掩码{}", ips[0]);
                        }
                    }
                } else if (ips[0].contains("/")) {
                    startIp2long = IpUtils.getIp2long(IpUtils.getStartIp(ips[0].trim()));
                } else if (ips[0].contains(".")) {
                    startIp2long = IpUtils.getIp2long(ips[0].trim());
                } else {
                    startIp2long = IpUtils.getIp2long(IpUtils.getStartIp(ips[0].trim()));
                }
                if (ips[1].contains(":")) {
                    if (IpUtils.isIP(ips[1].trim())) {
                        endIp2long = IpUtils.getIp2long(ips[1].trim());
                    } else {
                        try {
                            IPv6Network network = IPv6Network.fromString(ips[1]);
                            endIp2long = IpUtils.getIp2long(network.getLast().toLongString());
                        } catch (Exception e) {
                            log.error("非法 IPV6掩码{}", ips[1]);
                        }
                    }
                } else if (ips[1].contains("/")) {
                    endIp2long = IpUtils.getIp2long(IpUtils.getStartIp(ips[1].trim()));
                } else if (ips[1].contains(".")) {
                    endIp2long = IpUtils.getIp2long(ips[1].trim());
                    //endIp2long = IpUtils.getIp2long(ips[1].trim());
                } else {
                    endIp2long = IpUtils.getIp2long(IpUtils.getEndIp(ips[1].trim()));
                }
            } else if (cidr.contains("/")) {
                if (cidr.contains(":")) {
                    try {
                        IPv6Network network = IPv6Network.fromString(cidr);
                        startIp2long = IpUtils.getIp2long(network.getFirst().toLongString());
                        endIp2long = IpUtils.getIp2long(network.getLast().toLongString());
                    } catch (Exception e) {
                        log.error("非法 IPV6掩码{}", cidr);
                    }
                } else {
                    startIp2long = IpUtils.getIp2long(IpUtils.getStartIp(cidr.trim()));
                    endIp2long = IpUtils.getIp2long(IpUtils.getEndIp(cidr.trim()));
                }
            } else {
                startIp2long = IpUtils.getIp2long(cidr.trim());
                endIp2long = IpUtils.getIp2long(cidr.trim());
            }

            BigInteger[] rets = new BigInteger[2];
            rets[0] = startIp2long;
            rets[1] = endIp2long;
            return rets;
        } catch (Exception e) {
            log.error(e.getMessage(),e);
        }
        return null;
    }

    private static boolean isIP(String trim) {
        return isIp(trim);
    }
}

