package com.crc.common.utils;

import com.google.common.collect.Lists;
import com.google.common.collect.Maps;

import java.util.HashMap;
import java.util.List;

public class SqlUtils {
    public static String getInSql(List<String> taskIdList) {
        List<String> newIdList = Lists.newArrayList();
        HashMap<String,String> tmpMap = Maps.newHashMap();
        for (String id:taskIdList) {
            if(!tmpMap.containsKey(id)){
                tmpMap.put(id, id);
                newIdList.add("'" + id + "'");
            }
        }
        return "(" + String.join(",", newIdList) + ")";
    }
}
