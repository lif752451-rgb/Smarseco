package com.crc.common.utils;

import lombok.extern.slf4j.Slf4j;
import org.apache.commons.io.IOUtils;
import org.apache.commons.lang3.StringUtils;

import java.io.*;
import java.nio.file.Files;
import java.util.LinkedList;
import java.util.List;

@Slf4j
public class FileUtils {

    public static List<String> readFile(String path) {
        InputStreamReader inputReader = null;
        BufferedReader bf = null;
        List<String> arrayList = new LinkedList<>();
        try {
            File file = new File(path);
            inputReader = new InputStreamReader(Files.newInputStream(file.toPath()));
            bf = new BufferedReader(inputReader);
            // 按行读取字符串
            String str;
            while ((str = bf.readLine()) != null) {
                if (StringUtils.isNotBlank(str) && !str.startsWith("#")) {
                    arrayList.add(str);
                }
            }
        } catch (Exception e) {
            log.error(e.getMessage(), e);
        } finally {
            IOUtils.closeQuietly(bf);
            IOUtils.closeQuietly(inputReader);
        }
        return arrayList;
    }

    public static List<String> readFile(File file) {
        InputStreamReader inputReader = null;
        BufferedReader bf = null;
        List<String> arrayList = new LinkedList<>();
        try {
            inputReader = new InputStreamReader(Files.newInputStream(file.toPath()));
            bf = new BufferedReader(inputReader);
            // 按行读取字符串
            String str;
            while ((str = bf.readLine()) != null) {
                if (StringUtils.isNotBlank(str) && !str.startsWith("#")) {
                    arrayList.add(str);
                }
            }
        } catch (Exception e) {
            log.error(e.getMessage(), e);
        } finally {
            IOUtils.closeQuietly(bf);
            IOUtils.closeQuietly(inputReader);
        }
        return arrayList;
    }

    public static String readFileStr(String path) {
        InputStreamReader inputReader = null;
        BufferedReader bf = null;
        StringBuilder sb = new StringBuilder();
        try {
            File file = new File(path);
            inputReader = new InputStreamReader(Files.newInputStream(file.toPath()));
            bf = new BufferedReader(inputReader);
            // 按行读取字符串
            String str;
            while ((str = bf.readLine()) != null) {
                str = str.trim();
                if (str.startsWith("#")) {//去掉#注释
                    continue;
                }
                sb.append(str).append("\n");
            }
        } catch (Exception e) {
            log.error(e.getMessage(), e);
        } finally {
            IOUtils.closeQuietly(bf);
            IOUtils.closeQuietly(inputReader);
        }
        return sb.toString();
    }

    public static String readNginxFileStr(String path) {
        InputStreamReader inputReader = null;
        BufferedReader bf = null;
        StringBuilder sb = new StringBuilder();
        try {
            File file = new File(path);
            inputReader = new InputStreamReader(Files.newInputStream(file.toPath()));
            bf = new BufferedReader(inputReader);
            // 按行读取字符串
            String str;
            while ((str = bf.readLine()) != null) {
                str = str.trim();
                if (str.startsWith("#") || str.startsWith("subs_filter")) {//去掉#注释
                    continue;
                }
                sb.append(str).append("\n");
            }
        } catch (Exception e) {
            log.error(e.getMessage(), e);
        } finally {
            IOUtils.closeQuietly(bf);
            IOUtils.closeQuietly(inputReader);
        }
        return sb.toString();
    }

    public static String readFileXmlStr(String path) {
        InputStreamReader inputReader = null;
        BufferedReader bf = null;
        StringBuilder sb = new StringBuilder();
        try {
            File file = new File(path);
            inputReader = new InputStreamReader(Files.newInputStream(file.toPath()));
            bf = new BufferedReader(inputReader);
            // 按行读取字符串
            String str;
            while ((str = bf.readLine()) != null) {
                str = str.trim();
                //str = str.replaceAll("<!--(.*?)-->", "");
                if (StringUtils.isBlank(str)) {
                    continue;
                }
                sb.append(str).append("\n");
            }
        } catch (Exception e) {
            log.error(e.getMessage(), e);
        } finally {
            IOUtils.closeQuietly(bf);
            IOUtils.closeQuietly(inputReader);
        }
        return sb.toString();
    }

    public static boolean isWindows() {
        String os = System.getProperty("os.name");
        return os.toLowerCase().startsWith("win");
    }

    public static boolean isExists(String filePath) {
        File file = new File(filePath);
        return file.isFile() && file.exists();
    }

    /**
     * 根据文件名创建文件目录所要的路径
     *
     * @param filePath
     */
    public static void createDirectory4FilePath(String filePath) {
        try {
            File file = new File(filePath);
            String strParentDirectory = file.getParent();
            if (!strParentDirectory.endsWith(File.separator)) {
                strParentDirectory = strParentDirectory + File.separator;
            }
            File descDir = new File(strParentDirectory);
            if (descDir.exists()) {
                return;
            }
            // 创建目录
            descDir.mkdirs();
        } catch (Exception e) {
            log.error(e.getMessage(), e);
        }
    }

    public static boolean writeFile(String filePath, String str) {
        FileWriter fw = null;
        BufferedWriter bw = null;
        try {
            fw = new FileWriter(filePath);
            bw = new BufferedWriter(fw);
            //使用缓冲区中的方法将数据写入到缓冲区中。
            bw.write(str);
            //使用缓冲区中的方法，将数据刷新到目的地文件中去。
            bw.flush();
            return true;
        } catch (Exception e) {
            log.error(e.getMessage(), e);
        } finally {
            IOUtils.closeQuietly(bw);
            IOUtils.closeQuietly(fw);
        }
        return false;
    }
}
