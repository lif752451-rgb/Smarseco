package com.crc.common.banboo;

import com.alibaba.fastjson.JSONObject;
import com.crc.common.utils.DataUtils;
import com.crc.common.utils.DictUtil;
import com.crc.common.utils.JsonUtils;
import com.crc.secface.domain.SysDictData;

public class BanbooLoad {
    public static JSONObject getPushConfig(){
        SysDictData dict = DictUtil.getDictByValue("zy_auth_config", "zy_push_auth");
        if (DataUtils.isBlankDict(dict)) {
            return null;
        }
        return JsonUtils.parse(dict.getRemark());
    }

    public static JSONObject getBigDataConfig(){
        SysDictData dict = DictUtil.getDictByValue("zy_auth_config", "big_data_auth");
        if (DataUtils.isBlankDict(dict)) {
            return null;
        }
        return JsonUtils.parse(dict.getRemark());
    }

    public static JSONObject getRqBimDataConfig(){
        SysDictData dict = DictUtil.getDictByValue("zy_auth_config", "bim_data_auth");
        if (DataUtils.isBlankDict(dict)) {
            return null;
        }
        return JsonUtils.parse(dict.getRemark());
    }
}
