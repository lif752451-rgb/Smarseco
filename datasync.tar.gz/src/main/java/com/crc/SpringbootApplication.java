package com.crc;

import com.crc.secface.config.GetSpringBean;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.mybatis.spring.annotation.MapperScan;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.Configuration;
import org.springframework.core.env.Environment;

import java.io.InputStream;
import java.net.InetAddress;
import java.nio.charset.StandardCharsets;
import java.util.Arrays;


@Slf4j
@Configuration
@SpringBootApplication
@MapperScan("com.crc.secface.mapper")
public class SpringbootApplication {
    public static final String LINE_FEED = "\n";
    public static final String TAB = "\t";
    public static final String SPLIT_LINE = "---------";

    public static void main(String[] args) {
        if (Arrays.asList(args).contains("--version")) {
            getVersionInfo();
            System.exit(-1);
        }
        try {
            SpringApplication.run(SpringbootApplication.class, args);
            try {
                Environment env = GetSpringBean.getBean(Environment.class);
                log.info("\n======================================================\n\t" +
                                "标准版 数据同步引擎 SYNC SEC 成功运行!!! \n\t" +
                                "Auth: \tsmartseco\n\t" +
                                "Access URLs:\t http://{}:{}\n" +
                                "======================================================",
                        InetAddress.getLocalHost().getHostAddress(), env.getProperty("server.port")
                );
            } catch (Exception ignored) {

            }
        } catch (Exception e) {
            log.error(e.getMessage(), e);
        }
    }


    /**
     * 获取系统版本信息
     */
    private static void getVersionInfo() {
        try (InputStream in = Thread.currentThread().getContextClassLoader().getResourceAsStream("info/version.txt")) {
            if (in == null) {
                return;
            }
            byte[] buf = new byte[1024];
            in.read(buf);
            in.close();
            String lines = new String(buf, StandardCharsets.UTF_8);
            if (StringUtils.isEmpty(lines)) {
                System.err.println("读取 CRC分析解析引擎 当前版本 异常：版本文件为空");
                return;
            }
            String[] lineLists = lines.split(LINE_FEED);
            System.out.println();
            System.out.println("CRC分析解析引擎 当前版本信息：");
            for (String line : lineLists) {
                if (line.contains(SPLIT_LINE)) {
                    break;
                }
                System.out.println(TAB + line);
            }
            System.out.println();
        } catch (Exception e) {
            System.err.println("读取 CRC分析解析引擎 当前版本 异常：" + e.getMessage());
        }
    }
}

