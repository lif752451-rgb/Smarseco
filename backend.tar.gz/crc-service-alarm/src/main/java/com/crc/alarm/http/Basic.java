package com.crc.alarm.http;

import lombok.Data;

/**
 * @author shufengfeng
 * @Description: 安全洞察-攻击链路-微步接口响应
 * @date 2022/11/21 11:18
 */
@Data
public class Basic {

    private String carrier;
    private Location location;


}