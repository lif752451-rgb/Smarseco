package com.crc.alarm.model.domain;

import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableField;
import com.baomidou.mybatisplus.annotation.TableId;
import com.baomidou.mybatisplus.annotation.TableName;
import com.crc.core.model.BasicPHEntity;
import com.fasterxml.jackson.annotation.JsonFormat;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;
import lombok.EqualsAndHashCode;

import java.util.Date;

/**
 * 告警闭环-告警信息主表(hvv)
 */
@Data
@EqualsAndHashCode(callSuper = true)
@ApiModel(value = "告警闭环-告警信息主表(hvv)")
@TableName(value = "tb_alarm_hvv_report")
public class AlarmHvvReport extends BasicPHEntity {

    private static final long serialVersionUID = 1L;

    /**
     * 唯一主键
     */
    @ApiModelProperty(value = "主键")
    @TableId(value = "id", type = IdType.AUTO)
    private Long id;

    /**
     * 告警id
     */
    @TableField(value = "alarm_id")
    @ApiModelProperty(value = "告警id")
    private String alarmId;

    /**
     * 标题
     */
    @TableField(value = "title")
    @ApiModelProperty(value = "标题")
    private String title;

    /**
     * 漏洞关键字
     */
    @TableField(value = "vul_keyword")
    @ApiModelProperty(value = "漏洞关键字")
    private String vulKeyword;

    /**
     * 攻击ip
     */
    @TableField(value = "attack_ip")
    @ApiModelProperty(value = "攻击ip")
    private String attackIp;

    /**
     * 攻击ip归属信息
     */
    @TableField(value = "attack_ascription")
    @ApiModelProperty(value = "攻击ip归属信息")
    private String attackAscription;

    /**
     * 受害ip/url
     */
    @TableField(value = "victimized_ip")
    @ApiModelProperty(value = "受害ip/url")
    private String victimizedIp;

    /**
     * 受害ip/url归属信息
     */
    @TableField(value = "victimized_ascription")
    @ApiModelProperty(value = "受害ip/url归属信息")
    private String victimizedAscription;

    /**
     * 告警级别
     */
    @TableField(value = "`level`")
    @ApiModelProperty(value = "告警级别")
    private String level;

    /**
     * 告警级别名称
     */
    @TableField(value = "level_label")
    @ApiModelProperty(value = "告警级别名称")
    private String levelLabel;

    /**
     * 攻击结果
     */
    @TableField(value = "attack_result")
    @ApiModelProperty(value = "攻击结果")
    private String attackResult;

    /**
     * 攻击结果名称
     */
    @TableField(value = "attack_result_label")
    @ApiModelProperty(value = "攻击结果名称")
    private String attackResultLabel;

    /**
     * 攻击手段
     */
    @TableField(value = "attack_means")
    @ApiModelProperty(value = "攻击手段")
    private String attackMeans;

    /**
     * 攻击手段名称
     */
    @TableField(value = "attack_means_label")
    @ApiModelProperty(value = "攻击手段名称")
    private String attackMeansLabel;

    /**
     * 行为性质(0 正常 1非正常)
     */
    @TableField(value = "behavior_nature")
    @ApiModelProperty(value = "行为性质(0 正常 1 异常)")
    private String behaviorNature;

    /**
     * 告警来源
     */
    @TableField(value = "alarm_source")
    @ApiModelProperty(value = "告警来源")
    private String alarmSource;

    /**
     * 告警来源名称
     */
    @TableField(value = "alarm_source_label")
    @ApiModelProperty(value = "告警来源名称")
    private String alarmSourceLabel;

    /**
     * 攻击次数
     */
    @TableField(value = "attack_count")
    @ApiModelProperty(value = "攻击次数")
    private Integer attackCount;

    /**
     * 提交人
     */
    @TableField(value = "commit_user_name")
    @ApiModelProperty(value = "提交人")
    private String commitUserName;

    /**
     * 提交人姓名
     */
    @TableField(value = "commit_nick_name")
    @ApiModelProperty(value = "提交人姓名")
    private String commitNickName;

    /**
     * 告警详情
     */
    @TableField(value = "detail")
    @ApiModelProperty(value = "告警详情")
    private String detail;

    /**
     * 告警时间
     */
    @TableField(value = "alarm_time")
    @ApiModelProperty(value = "告警时间")
    @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss", timezone = "GMT+8")
    private Date alarmTime;

    /**
     * 流程处理完成时间
     */
    @TableField(value = "complete_time")
    @ApiModelProperty(value = "流程处理完成时间")
    @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss", timezone = "GMT+8")
    private Date completeTime;

    /**
     * 备注
     */
    @TableField(value = "remark")
    @ApiModelProperty(value = "备注")
    private String remark;

    /**
     * 工单状态
     */
    @TableField(value = "order_status")
    @ApiModelProperty(value = "工单状态")
    private String orderStatus;

    /**
     * 当前处理人
     */
    @TableField(value = "current_deal_user")
    @ApiModelProperty(value = "当前处理人")
    private String currentDealUser;

    /**
     * 当前处理人姓名
     */
    @TableField(value = "current_deal_user_nick_name")
    @ApiModelProperty(value = "当前处理人姓名")
    private String currentDealUserNickName;

    /**
     * 业务key
     */
    @TableField(value = "business_key")
    @ApiModelProperty(value = "业务key")
    private String businessKey;

    /**
     * 节点名称
     */
    @TableField(value = "node_name")
    @ApiModelProperty(value = "节点名称")
    private String nodeName;

    /**
     * 已失陷IP
     */
    @TableField(value = "fallen_ip")
    @ApiModelProperty(value = "已失陷IP")
    private String fallenIp;

    /**
     * 上报类型（0 手动 1 系统自动）
     */
    @TableField(value = "report_type")
    @ApiModelProperty(value = "上报类型（0 手动 1 系统自动）")
    private Integer reportType;

    /**
     * 处理时间
     */
    @TableField(value = "handling_time")
    @ApiModelProperty(value = "处理时间")
    @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss", timezone = "GMT+8")
    private Date handlingTime;

    /**
     * 重点关注标记（0 未重点关注，1 已重点关注）
     */
    @TableField(value = "focus_tag")
    @ApiModelProperty(value = "重点关注标记（0 未重点关注，1 已重点关注）")
    private Integer focusTag;

    /**
     * AI研判值
     */
    @TableField(value = "ai_check")
    @ApiModelProperty(value = "AI研判值")
    private Double aiCheck;

    /**
     * 最后一次溯源状态
     */
    @TableField(value = "traceability_status")
    @ApiModelProperty(value = "最后一次溯源状态")
    private String traceabilityStatus;

    /**
     * 最后一次溯源状态名称
     */
    @TableField(value = "traceability_status_label")
    @ApiModelProperty(value = "最后一次溯源状态名称")
    private String traceabilityStatusLabel;

    /**
     * 告警设备
     */
    @TableField(value = "device")
    @ApiModelProperty(value = "告警设备")
    private String device;

    /**
     * 创建人姓名
     */
    @TableField(value = "create_by_label")
    @ApiModelProperty(value = "创建人姓名")
    private String createByLabel;
}