package com.crc.alarm.model.domain;

import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableField;
import com.baomidou.mybatisplus.annotation.TableId;
import com.baomidou.mybatisplus.annotation.TableName;
import com.crc.core.model.BasicPHEntity;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;
import lombok.EqualsAndHashCode;

/**
 * 告警安全处理人分组
 */
@ApiModel(value = "告警安全处理人分组")
@Data
@EqualsAndHashCode(callSuper = true)
@TableName(value = "tb_alarm_security_handler_grouping")
public class AlarmSecurityHandlerGrouping extends BasicPHEntity {
    /**
     * 主键ID
     */
    @TableId(value = "id", type = IdType.AUTO)
    @ApiModelProperty(value = "主键ID")
    private Long id;

    /**
     * 分组名称
     */
    @TableField(value = "group_name")
    @ApiModelProperty(value = "分组名称")
    private String groupName;

    /**
     * 分组用户
     */
    @TableField(value = "group_users")
    @ApiModelProperty(value = "分组用户")
    private String groupUsers;

    /**
     * 分组用户显示名称
     */
    @TableField(exist = false)
    @ApiModelProperty(value = "分组用户显示名称")
    private String groupUserLabels;

    /**
     * 责任部门ID
     */
    @TableField(value = "duty_dept_id")
    @ApiModelProperty(value = "责任部门ID")
    private Long dutyDeptId;

    /**
     * 租户ID
     */
    @TableField(value = "organization_id")
    @ApiModelProperty(value = "租户ID")
    private Long organizationId;
}
