package com.crc.alarm.model.domain;

import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableId;
import com.baomidou.mybatisplus.annotation.TableName;
import java.util.Date;

import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.experimental.Accessors;

/**
 * <p>
 * 威胁管理-告警表单
 * </p>
 *
 * @author shufengfeng
 * @since 2021-08-31
 */
@Data
@EqualsAndHashCode(callSuper = false)
@Accessors(chain = true)
@TableName("tb_alarm_form")
public class AlarmForm {

    /**
     * 主键
     */
    @TableId(value = "id", type = IdType.AUTO)
    private Long id;

    /**
     * 是否误报(0 不是 1是)
     */
    private Integer misinformation;

    /**
     * 行为性质(0 正常 1非正常)
     */
    private Integer behaviorNature;

    /**
     * 是否转办(0 否 1是)
     */
    private Integer convertStatus;

    /**
     * 是否复核(0 否 1是)
     */
    private Integer checkStatus;

    /**
     * 复核结果(pass 通过 fail 不通过)
     */
    private String checkResult;

    /**
     * 审核结果(pass 通过 fail 不通过)
     */
    private String auditResult;

    /**
     * 处置措施/处置建议/处置驳回原因/复核意见/审核意见
     */
    private String opinion;

    /**
     * 指派处置人
     */
    private String handleUserName;

    /**
     * 责任部门名称
     */
    private String dutyDeptName;

    /**
     * 责任部门id
     */
    private Long dutyDeptId;

    /**
     * 安全接口人
     */
    private String securityUserName;

    /**
     * 安全接口人名称
     */
    private String securityUserNikeName;

    /**
     * 攻击结果
     */
    private String attackResult;

    /**
     * 告警级别
     */
    private String level;

    /**
     * 附件
     */
    private String fileJson;

    /**
     * 创建时间
     */
    private Date createTime;

    /**
     * 修改时间
     */
    private Date updateTime;

    /**
     * 删除标记(0正常 1删除)
     */
    private Integer delFlag;

    /**
     * 业务key
     */
    private String businessKey;

    /**
     * 已失陷IP
     */
    public String fallenIp;
}
