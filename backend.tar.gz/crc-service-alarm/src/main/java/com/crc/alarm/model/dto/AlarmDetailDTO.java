package com.crc.alarm.model.dto;

import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import java.util.Date;

/**
 * 详情
 */
@Data
public class AlarmDetailDTO {
    private Long id;
    /**
     * 告警id
     */
    private String alarmId;

    /**
     * 标题
     */
    private String title;

    /**
     * 攻击ip
     */
    private String attackIp;

    /**
     * 受害ip/url
     */
    private String victimizedIp;

    /**
     * 告警级别
     */
    private String level;

    /**
     * 告警级别名称
     */
    private String levelLabel;

    /**
     * 攻击结果
     */
    private String attackResult;

    /**
     * 攻击结果名称
     */
    private String attackResultLabel;

    /**
     * 攻击手段
     */
    private String attackMeans;

    /**
     * 攻击手段名称
     */
    private String attackMeansLabel;

    /**
     * 行为性质(0 正常 1非正常)
     */
    private Integer behaviorNature;

    /**
     * 告警单位
     */
    private String dept;

    /**
     * 告警单位名称
     */
    private String deptLabel;

    /**
     * 告警设备
     */
    private String device;

    /**
     * 告警设备名称
     */
    private String deviceLabel;

    /**
     * 攻击次数
     */
    private Integer attackCount;

    /**
     * 提交人
     */
    private String commitUserName;

    /**
     * 提交人姓名
     */
    private String commitNickName;

    /**
     * 创建时间
     */
    private Date createTime;

    /**
     * 告警详情
     */
    private String detail;

    /**
     * 告警时间
     */
    private Date alarmTime;

    /**
     * 备注
     */
    private String remark;

    /**
     * 附件
     */
    private String fileJson;
    /**
     * 工单状态
     */
    private String orderStatus;
    /**
     * 删除标记(0正常 1删除)
     */
    private Integer delFlag;
    /**
     * 业务key
     */
    private String businessKey;
    /**
     * 修改人
     */
    private String updateUser;
    /**
     * 当前处理人
     */
    private String currentDealUser;
    /**
     * 当前处理人姓名
     */
    private String currentDealUserNickName;
    /**
     * 节点名称
     */
    private String nodeName;
    /** 已耗时 */
    private String expended;
    /**
     * 告警来源
     */
    private String alarmSource;
    /**
     * 责任部门
     */
    private String dutyDeptName;

    /**
     * 责任部门id
     */
    private Long dutyDeptId;

    /**
     * 已失陷IP
     */
    private String fallenIp;

    /**
     * 上报类型（0 手动 1 系统自动）
     */
    @ApiModelProperty(value = "上报类型（0 手动 1 系统自动）")
    private Integer reportType;

    /**
     * 重点关注标记（0 未重点关注，1 已重点关注）
     */
    private Integer mark;

    /**
     * 所属组织
     */
    private String organization;

    /**
     * 所属组织id
     */
    private Long organizationId;

    /**
     * AI研判值
     */
    private Double aiCheck;

    /**
     * 漏洞关键字
     */
    private String vulKeyword;

    /**
     * 告警模型id
     */
    private String eventModelId;

    /**
     * 上一节点指派人
     */
    private String assignedPerson;
}
