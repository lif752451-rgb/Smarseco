package com.crc.alarm.model.constant;

/**
 * 实战告警闭环-告警常量类
 */
public interface AlarmCombatConstants {

    /**
     * 列表导出文件名称
     */
    String ALARM_EXCEL_NAME = "告警列表";

    /**
     * 列表类型：全部告警列表
     */
    String LIST_TYPE_ALL = "allAlarm";

    /**
     * 列表导出文件名称-前缀
     */
    String ALL_ALARM_EXCEL_NAME = "全部工单";

    /**
     * 列表类型：我的待办列表
     */
    String LIST_TYPE_WAIT = "waitAlarm";

    /**
     * 列表导出文件名称-前缀
     */
    String WAIT_ALARM_EXCEL_NAME = "我的待办";

    /**
     * 列表类型：我的已办列表
     */
    String LIST_TYPE_DONE = "doneAlarm";

    /**
     * 列表导出文件名称-前缀
     */
    String DONE_ALARM_EXCEL_NAME = "我的已办";

    /**
     * 需要后续跟进
     */
    String WHETHER_FOLLOW_YES_OPINION = "需要后续跟进：";

    /**
     * 无需后续跟进
     */
    String WHETHER_FOLLOW_NO_OPINION = "无需后续跟进";

    /**
     * 研判已读
     */
    String JUDGE_READ = "judgeRead";

    /**
     * 研判未读
     */
    String JUDGE_UNREAD = "judgeUnread";

    /**
     * 处置已读
     */
    String DEAL_READ = "dealRead";

    /**
     * 处置未读
     */
    String DEAL_UNREAD = "dealUnread";

    /**
     * 后续跟进已读
     */
    String FOLLOW_READ = "followRead";

    /**
     * 后续跟进未读
     */
    String FOLLOW_UNREAD = "followUnread";

    /**
     * 审核已读
     */
    String AUDIT_READ = "auditRead";

    /**
     * 审核未读
     */
    String AUDIT_UNREAD = "auditUnread";

    /**
     * 归档已读
     */
    String COMPLETE_READ = "completeRead";

    /**
     * 归档未读
     */
    String COMPLETE_UNREAD = "completeUnread";

    /**
     * 无需处置已读
     */
    String NO_DEAL_READ = "noDealRead";

    /**
     * 无需处置未读
     */
    String NO_DEAL_UNREAD = "noDealUnread";
}
