package com.crc.alarm.mapper;

import java.util.List;

import org.apache.ibatis.annotations.Param;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.crc.alarm.model.domain.AlarmReport;
import com.crc.alarm.model.request.AlarmRelOriLogReq;
import com.crc.alarm.model.response.AlarmListResponse;

/**
 * 威胁管理-告警主表(发起表)查询 Mapper 接口
 * 
 * @author zhangbing
 */
public interface AlarmReportQueryMapper extends BaseMapper<AlarmReport> {

    /**
     * ioc情报查询告警信息
     *
     * @param req 入参
     * @return list
     */
    List<AlarmListResponse> findAlarmList(@Param("req") AlarmRelOriLogReq req);
}