package com.crc.alarm.model.dto;

import com.alibaba.fastjson.JSONObject;
import lombok.Data;

import java.util.List;

@Data
public class AlarmDataDTO {
    String evtId;
    /**
     * 源 IP
     */
    String srcIp;
    /**
     * 目标 IP
     */
    String destIp;
    /**
     * 源端口
     */
    String srcPort;
    /**
     * 目标端口
     */
    String destPort;

    /**
     * 详情概述
     */
    String detail;

    /**
     * 数据包
     */
    JSONObject dataPacket;

    /**
     * Json
     */
    String jsonData;

    /**
     * 检测信息
     */
    List<AlarmDataDetectDTO> detectList;
}
