package com.crc.alarm.model.domain;

import com.baomidou.mybatisplus.annotation.TableField;
import com.baomidou.mybatisplus.annotation.TableId;
import com.baomidou.mybatisplus.annotation.TableName;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

/**
 * 告警关联原始日志表
 * 
 * @author zhangbing
 */
@ApiModel(value = "告警关联原始日志表")
@Data
@TableName(value = "tb_alarm_ref_orilog")
public class AlarmRefOrilog {

    /**
     * 主键ID
     */
    @TableId(value = "id")
    @ApiModelProperty(value = "主键ID")
    private Integer id;

    /**
     * 原始日志ID（多个）
     */
    @TableField(value = "ori_ids")
    @ApiModelProperty(value = "原始日志ID（多个）")
    private String oriIds;

    /**
     * 告警ID
     */
    @TableField(value = "alarm_id")
    @ApiModelProperty(value = "告警ID")
    private String alarmId;

    @TableField(value = "index_name")
    @ApiModelProperty(value = "")
    private String indexName;
}