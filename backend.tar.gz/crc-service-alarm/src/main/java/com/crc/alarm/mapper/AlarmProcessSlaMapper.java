package com.crc.alarm.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.crc.alarm.model.domain.AlarmProcessSla;
import com.crc.alarm.model.domain.AlarmReport;
import com.crc.alarm.model.response.AlarmProcessSlaResp;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;

import java.util.List;

/**
 * 告警闭环-流程节点耗时Mapper
 */
@Mapper
public interface AlarmProcessSlaMapper extends BaseMapper<AlarmProcessSla> {

    /**
     * 查询告警闭环流程节点耗时
     *
     * @param alarmReportId 告警主表ID
     * @return AlarmProcessSlaResp
     */
    AlarmProcessSlaResp findProcessSlaByAlarmReportId(@Param("alarmReportId") Long alarmReportId);

    /**
     * 查询未同步告警耗时的信息
     *
     * @param param AlarmReport
     * @return List
     */
    List<AlarmReport> findNotSyncAlarmReport(@Param("param") AlarmProcessSla param);
}