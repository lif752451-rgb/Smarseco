package com.crc.alarm.mapper;

import java.util.List;

import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.crc.alarm.model.domain.AlarmCombatApplyHelpLog;
import com.crc.alarm.model.dto.AlarmCombatReportDTO;
import com.crc.alarm.model.response.AlarmCombatReportResp;

/**
 * 实战告警闭环-申请集团协助记录Mapper
 */
@Mapper
public interface AlarmCombatApplyHelpLogMapper extends BaseMapper<AlarmCombatApplyHelpLog> {

    /**
     * 查询申请集团协助记录统计
     *
     * @return Integer
     */
    Integer findApplyHelpLogCount(@Param("combatDto") AlarmCombatReportDTO combatDto);

    /**
     * 查询申请集团协助记录
     *
     * @param combatDto 入参
     * @return List
     */
    List<AlarmCombatReportResp> findApplyHelpLogPage(@Param("combatDto") AlarmCombatReportDTO combatDto);

    /**
     * 查询上报集团记录
     *
     * @param alarmReportId 实战告警闭环主表ID
     * @return List
     */
    List<AlarmCombatReportResp> findReportGroupList(@Param("alarmReportId") String alarmReportId);
}