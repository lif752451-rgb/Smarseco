package com.crc.alarm.mapper;

import java.util.List;

import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.crc.alarm.model.domain.AlarmCombatReadLog;
import com.crc.alarm.model.response.AlarmCombatReadLogResp;

/**
 * 实战告警闭环-已读日志Mapper
 */
@Mapper
public interface AlarmCombatReadLogMapper extends BaseMapper<AlarmCombatReadLog> {

    /**
     * 查询告警已阅记录日志
     *
     * @param alarmReportId 实战告警闭环主表ID
     * @return List
     */
    List<AlarmCombatReadLogResp> findReadLog(@Param("alarmReportId") String alarmReportId);
}