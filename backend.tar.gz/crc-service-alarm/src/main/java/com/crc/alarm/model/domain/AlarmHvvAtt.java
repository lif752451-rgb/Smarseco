package com.crc.alarm.model.domain;

import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableField;
import com.baomidou.mybatisplus.annotation.TableId;
import com.baomidou.mybatisplus.annotation.TableName;
import com.crc.core.model.BasicPHEntity;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;

import lombok.Data;
import lombok.EqualsAndHashCode;

/**
 * 告警闭环(hvv)-公共附件表
 */
@Data
@ApiModel(value = "告警闭环(hvv)-公共附件表")
@EqualsAndHashCode(callSuper = true)
@TableName(value = "tb_alarm_hvv_att")
public class AlarmHvvAtt extends BasicPHEntity {
    /**
     * 主键ID
     */
    @TableId(value = "id", type = IdType.AUTO)
    @ApiModelProperty(value = "主键ID")
    private Long id;

    /**
     * 业务ID
     */
    @TableField(value = "business_id")
    @ApiModelProperty(value = "业务ID")
    private Long businessId;

    /**
     * 附件业务类型
     */
    @TableField(value = "business_type")
    @ApiModelProperty(value = "附件业务类型")
    private String businessType;

    /**
     * 附件类型
     */
    @TableField(value = "att_type")
    @ApiModelProperty(value = "附件类型")
    private String attType;

    /**
     * 附件名称
     */
    @TableField(value = "file_name")
    @ApiModelProperty(value = "附件名称")
    private String fileName;

    /**
     * 附件链接
     */
    @TableField(value = "url")
    @ApiModelProperty(value = "附件链接")
    private String url;

    /**
     * 记录fast附件上传开关(open 打开, close关闭)
     */
    @TableField(value = "fast_switch")
    @ApiModelProperty(value = "记录fast附件上传开关(open 打开, close关闭)")
    private String fastSwitch;

    /**
     * 创建人姓名
     */
    @TableField(value = "create_by_label")
    @ApiModelProperty(value = "创建人姓名")
    private String createByLabel;
}