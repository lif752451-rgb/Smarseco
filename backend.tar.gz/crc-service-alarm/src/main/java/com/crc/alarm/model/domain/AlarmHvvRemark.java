package com.crc.alarm.model.domain;

import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableField;
import com.baomidou.mybatisplus.annotation.TableId;
import com.baomidou.mybatisplus.annotation.TableName;
import com.crc.core.model.BasicPHEntity;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;
import lombok.EqualsAndHashCode;

/**
 * 告警闭环(hvv)-补充备注表
 */
@Data
@EqualsAndHashCode(callSuper = true)
@ApiModel(value = "告警闭环(hvv)-补充备注表")
@TableName(value = "tb_alarm_hvv_remark")
public class AlarmHvvRemark extends BasicPHEntity {

    private static final long serialVersionUID = 1L;

    /**
     * 唯一主键
     */
    @ApiModelProperty(value = "主键")
    @TableId(value = "id", type = IdType.AUTO)
    private Long id;

    /**
     * 业务标识
     */
    @TableField(value = "business_key")
    @ApiModelProperty(value = "业务标识")
    private String businessKey;

    /**
     * 备注内容
     */
    @TableField(value = "content")
    @ApiModelProperty(value = "备注内容")
    private String content;

    /**
     * 创建人姓名
     */
    @TableField(value = "create_by_label")
    @ApiModelProperty(value = "创建人姓名")
    private String createByLabel;
}