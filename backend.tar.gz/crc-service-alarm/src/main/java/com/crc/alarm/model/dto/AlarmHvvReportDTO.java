package com.crc.alarm.model.dto;

import com.crc.alarm.model.domain.AlarmHvvReport;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;
import lombok.EqualsAndHashCode;

import java.util.List;

/**
 * 告警闭环(hvv)-查询参数
 */
@Data
@EqualsAndHashCode(callSuper = true)
@ApiModel(value = "告警闭环(hvv)-查询参数")
public class AlarmHvvReportDTO extends AlarmHvvReport {

    /**
     * 搜索条件-告警开始时间
     */
    @ApiModelProperty(value = "搜索条件-告警开始时间")
    private String alarmStartTime;

    /**
     * 搜索条件-告警结束时间
     */
    @ApiModelProperty(value = "搜索条件-告警结束时间")
    private String alarmEndTime;

    /**
     * 搜索条件-创建开始时间
     */
    @ApiModelProperty(value = "搜索条件-创建开始时间")
    private String createStartTime;

    /**
     * 搜索条件-创建结束时间
     */
    @ApiModelProperty(value = "搜索条件-创建结束时间")
    private String createEndTime;

    /**
     * 搜索条件-告警级别
     */
    @ApiModelProperty(value = "搜索条件-告警级别")
    private List<String> levelList;

    /**
     * 搜索条件-攻击结果
     */
    @ApiModelProperty(value = "搜索条件-攻击结果")
    private List<String> attackResultList;

    /**
     * 搜索条件-攻击手段
     */
    @ApiModelProperty(value = "搜索条件-攻击手段")
    private List<String> attackMeansList;

    /**
     * 搜索条件-行为性质
     */
    @ApiModelProperty(value = "搜索条件-行为性质")
    private List<String> behaviorNatureList;

    /**
     * 搜索条件-告警来源
     */
    @ApiModelProperty(value = "搜索条件-告警来源")
    private List<String> alarmSourceList;

    /**
     * 搜索条件-最后一次溯源状态
     */
    @ApiModelProperty(value = "搜索条件-最后一次溯源状态")
    private List<String> traceabilityStatusList;

    /**
     * 搜索条件-重点关注标记
     */
    @ApiModelProperty(value = "搜索条件-重点关注标记")
    private List<String> focusTagList;
}