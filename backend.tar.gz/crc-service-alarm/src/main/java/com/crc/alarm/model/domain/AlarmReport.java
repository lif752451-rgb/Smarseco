package com.crc.alarm.model.domain;

import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableField;
import com.baomidou.mybatisplus.annotation.TableId;
import com.baomidou.mybatisplus.annotation.TableName;
import com.fasterxml.jackson.annotation.JsonFormat;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.experimental.Accessors;

import java.util.Date;
import java.util.List;

/**
 * <p>
 * 威胁管理-告警主表(发起表)
 * </p>
 *
 * @author shufengfeng
 * @since 2021-08-31
 */
@Data
@EqualsAndHashCode(callSuper = false)
@Accessors(chain = true)
@TableName("tb_alarm_report")
public class AlarmReport {

    /**
     * 主键
     */
    @TableId(value = "id", type = IdType.AUTO)
    private Long id;

    /**
     * 告警id
     */
    @TableField(value = "alarm_id")
    private String alarmId;

    /**
     * 标题
     */
    @TableField(value = "title")
    private String title;

    /**
     * 攻击ip
     */
    @TableField(value = "attack_ip")
    private String attackIp;

    /**
     * 受害ip/url
     */
    @TableField(value = "victimized_ip")
    private String victimizedIp;

    /**
     * 告警级别
     */
    @TableField(value = "level")
    private String level;

    /**
     * 告警级别名称
     */
    @TableField(value = "level_label")
    private String levelLabel;

    /**
     * 攻击结果
     */
    @TableField(value = "attack_result")
    private String attackResult;

    /**
     * 攻击结果名称
     */
    @TableField(value = "attack_result_label")
    private String attackResultLabel;

    /**
     * 攻击手段
     */
    @TableField(value = "attack_means")
    private String attackMeans;

    /**
     * 攻击手段名称
     */
    @TableField(value = "attack_means_label")
    private String attackMeansLabel;

    /**
     * 行为性质(0 正常 1非正常)
     */
    @TableField(value = "behavior_nature")
    private Integer behaviorNature;

    /**
     * 告警单位
     */
    @TableField(value = "dept")
    private String dept;

    /**
     * 告警单位名称
     */
    @TableField(value = "dept_label")
    private String deptLabel;

    /**
     * 告警设备
     */
    @TableField(value = "device")
    private String device;

    /**
     * 告警设备名称
     */
    @TableField(value = "device_label")
    private String deviceLabel;

    /**
     * 攻击次数
     */
    @TableField(value = "attack_count")
    private Integer attackCount;

    /**
     * 提交人
     */
    @TableField(value = "commit_user_name")
    private String commitUserName;

    /**
     * 提交人姓名
     */
    @TableField(value = "commit_nick_name")
    private String commitNickName;

    /**
     * 创建时间
     */
    @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss", timezone = "GMT+8")
    @TableField(value = "create_time")
    private Date createTime;

    /**
     * 告警详情
     */
    @TableField(value = "detail")
    private String detail;

    /**
     * 告警时间
     */
    @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss", timezone = "GMT+8")
    @TableField(value = "alarm_time")
    private Date alarmTime;

    /**
     * 备注
     */
    @TableField(value = "remark")
    private String remark;

    /**
     * 附件
     */
    @TableField(value = "file_json")
    private String fileJson;

    /**
     * 工单状态
     */
    @TableField(value = "order_status")
    private String orderStatus;

    /**
     * 删除标记(0正常 1删除)
     */
    @TableField(value = "del_flag")
    private Integer delFlag;

    /**
     * 业务key
     */
    @TableField(value = "business_key")
    private String businessKey;

    /**
     * 修改时间
     */
    @TableField(value = "update_time")
    private Date updateTime;

    /**
     * 修改人
     */
    @TableField(value = "update_user")
    private String updateUser;

    /**
     * 当前处理人
     */
    @TableField(value = "current_deal_user")
    private String currentDealUser;

    /**
     * 当前处理人昵称
     */
    @TableField(value = "current_deal_user_nick_name")
    private String currentDealUserNickName;

    /**
     * 节点名称
     */
    @TableField(value = "node_name")
    private String nodeName;

    /**
     * 责任部门id
     */
    @TableField(value = "duty_dept_id")
    private Long dutyDeptId;

    /**
     * 责任部门名称
     */
    @TableField(value = "duty_dept_name")
    private String dutyDeptName;

    /**
     * 完成时间
     */
    @TableField(value = "complete_time")
    private Date completeTime;

    /**
     * 攻击ip归属信息
     */
    @TableField(value = "attack_ascription")
    private String attackAscription;

    /**
     * 受害ip/url归属信息
     */
    @TableField(value = "victimized_ascription")
    private String victimizedAscription;

    /**
     * 已失陷IP
     */
    @TableField(value = "fallen_ip")
    private String fallenIp;

    /**
     * 上报类型（0 手动 1 系统自动）
     */
    @TableField(value = "report_type")
    private int reportType;

    /**
     * 告警来源
     */
    @TableField(value = "alarm_source")
    private String alarmSource;

    /**
     * 处理时间
     */
    @TableField(value = "handling_time")
    private Date handlingTime;

    /**
     * 所属组织
     */
    @TableField(value = "organization")
    private String organization;

    /**
     * 所属组织id
     */
    @TableField(value = "organization_id")
    private Long organizationId;

    /**
     * 重点关注标记（0 未重点关注，1 已重点关注）
     */
    @TableField(value = "focus_tag")
    private Integer focusTag;

    /**
     * 实例名称
     */
    @TableField(exist = false)
    private String instance;

    /**
     * 所属区域
     */
    @TableField(exist = false)
    private String area;

    /**
     * 攻击次数
     */
    @TableField(exist = false)
    private int count;

    /**
     * AI研判值
     */
    @TableField(value = "ai_check")
    private Double aiCheck;

    /**
     * 告警来源部门ID
     */
    @TableField(value = "affiliation_dept_node_id")
    private Long affiliationDeptNodeId;

    /**
     * 告警来源部门名称
     */
    @TableField(value = "affiliation_dept_name")
    private String affiliationDeptName;

    /**
     * 每页大小
     */
    @TableField(exist = false)
    private Integer pageSize;

    /**
     * 当前页
     */
    @TableField(exist = false)
    private Integer pageNum;

    /**
     * 已选中的告警ID-数组
     */
    @TableField(exist = false)
    private List<String> alarmIdList;

    /**
     * 已选中的告警ID-字符串
     */
    @TableField(exist = false)
    private String alarmIds;

    /**
     * 关键字搜索
     */
    @TableField(exist = false)
    private String searchValue;

    /**
     * 漏洞关键字
     */
    private String vulKeyword;

    /**
     * IP
     */
    @TableField(exist = false)
    private String ip;

    /**
     * 颜色
     */
    @TableField(exist = false)
    private String color;
    /**
     * 告警条数
     */
    @TableField(exist = false)
    private Integer alarmCount;

    /**
     * TOP配置id
     */
    @TableField(exist = false)
    private Integer topId;

    /**
     * 知识库告警处置建议知识ID
     */
    @TableField(value = "knowledge_alarm_handle_id")
    public String knowledgeAlarmHandleId;


    /**
     * 告警模型id
     */
    @TableField(value = "event_model_id")
    private String eventModelId;

    /**
     * 指派人
     */
    @TableField(value = "assigned_person")
    private String assignedPerson
    ;
}
