package com.crc.alarm.config;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.PropertySource;

import lombok.Data;

/**
 * 实战告警发送消息配置类
 * 
 * @author zhangbing
 */
@Data
@Configuration
@PropertySource(value = "config/alarmCombatNotice.properties", encoding = "UTF-8")
public class AlarmCombatNoticeConfig {
    /**
     * 实战告警闭环申请集团协助邮件主题
     */
    @Value("${apply.help.subject}")
    private String applyHelpSubject;

    /**
     * 实战告警闭环申请集团协助邮件内容
     */
    @Value("${apply.help.text}")
    private String applyHelpText;

    /**
     * 实战告警闭环申请集团协助润工作内容
     */
    @Value("${apply.help.msg}")
    private String applyHelpMsg;

    /**
     * 实战告警闭环溯源提醒邮件主题
     */
    @Value("${traceability.warn.subject}")
    private String traceabilityWarnSubject;

    /**
     * 实战告警闭环溯源提醒邮件内容
     */
    @Value("${traceability.warn.text}")
    private String traceabilityWarnText;

    /**
     * 实战告警闭环溯源提醒润工作内容
     */
    @Value("${traceability.warn.msg}")
    private String traceabilityWarnMsg;
}