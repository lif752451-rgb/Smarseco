package com.crc.alarm.mapper;

import org.apache.ibatis.annotations.Mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.crc.alarm.model.domain.AlarmCombatForm;
import com.crc.alarm.model.domain.IpPluggingTaskAlarm;

import java.util.List;

@Mapper
public interface AlarmCombatFormMapper extends BaseMapper<AlarmCombatForm> {

    String getUniqueCount(String execDevice, String ip);

    void insertIpPluggingTaskAlarm(IpPluggingTaskAlarm ipPluggingTask);

//    void updateExecCountAndTime(String id);

    void updateExecCountAndTime(String id, String status);

    /**
     * 批量新增表单
     * @param alarmFormList form表单
     * @return 新增条数
     */
    int batchInsert(List<AlarmCombatForm> alarmFormList);
}
