package com.crc.alarm.model.domain;

import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableField;
import com.baomidou.mybatisplus.annotation.TableId;
import com.baomidou.mybatisplus.annotation.TableName;
import com.crc.core.model.BasicPHEntity;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;
import lombok.EqualsAndHashCode;

/**
 * 告警闭环(hvv)-溯源日志表
 */
@Data
@EqualsAndHashCode(callSuper = true)
@ApiModel(value = "告警闭环(hvv)-溯源日志表")
@TableName(value = "tb_alarm_hvv_traceability_log")
public class AlarmHvvTraceabilityLog extends BasicPHEntity {

    private static final long serialVersionUID = 1L;

    /**
     * 唯一主键
     */
    @ApiModelProperty(value = "主键")
    @TableId(value = "id", type = IdType.AUTO)
    private Long id;

    /**
     * 业务ID
     */
    @TableField(value = "business_id")
    @ApiModelProperty(value = "业务ID")
    private Long businessId;

    /**
     * 操作
     */
    @TableField(value = "operation")
    @ApiModelProperty(value = "操作")
    private String operation;

    /**
     * 内容
     */
    @TableField(value = "content")
    @ApiModelProperty(value = "内容")
    private String content;

    /**
     * 创建人姓名
     */
    @TableField(value = "create_by_label")
    @ApiModelProperty(value = "创建人姓名")
    private String createByLabel;
}