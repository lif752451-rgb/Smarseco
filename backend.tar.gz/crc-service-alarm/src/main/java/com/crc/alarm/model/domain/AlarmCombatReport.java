package com.crc.alarm.model.domain;

import java.util.Date;

import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableField;
import com.baomidou.mybatisplus.annotation.TableId;
import com.baomidou.mybatisplus.annotation.TableName;
import com.crc.core.model.BasicPHEntity;
import com.fasterxml.jackson.annotation.JsonFormat;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;
import lombok.EqualsAndHashCode;

/**
 * 实战告警闭环-告警信息主表
 * 
 * @author zhangbing
 */
@ApiModel(value = "实战告警闭环-告警信息主表")
@Data
@EqualsAndHashCode(callSuper = true)
@TableName(value = "tb_alarm_combat_report")
public class AlarmCombatReport extends BasicPHEntity {

    /**
     * 主键
     */
    @TableId(value = "id", type = IdType.ASSIGN_UUID)
    @ApiModelProperty(value = "主键")
    private String id;

    /**
     * 告警id
     */
    @TableField(value = "alarm_id")
    @ApiModelProperty(value = "告警id")
    private String alarmId;

    /**
     * 标题
     */
    @TableField(value = "title")
    @ApiModelProperty(value = "标题")
    private String title;

    /**
     * 漏洞关键字
     */
    @TableField(value = "vul_keyword")
    @ApiModelProperty(value = "漏洞关键字")
    private String vulKeyword;

    /**
     * 攻击ip
     */
    @TableField(value = "attack_ip")
    @ApiModelProperty(value = "攻击ip")
    private String attackIp;

    /**
     * 攻击ip归属信息
     */
    @TableField(value = "attack_ascription")
    @ApiModelProperty(value = "攻击ip归属信息")
    private String attackAscription;

    /**
     * 受害ip/url
     */
    @TableField(value = "victimized_ip")
    @ApiModelProperty(value = "受害ip/url")
    private String victimizedIp;

    /**
     * 受害ip/url归属信息
     */
    @TableField(value = "victimized_ascription")
    @ApiModelProperty(value = "受害ip/url归属信息")
    private String victimizedAscription;

    /**
     * 告警级别
     */
    @TableField(value = "`level`")
    @ApiModelProperty(value = "告警级别")
    private String level;

    /**
     * 告警级别名称
     */
    @TableField(value = "level_label")
    @ApiModelProperty(value = "告警级别名称")
    private String levelLabel;

    /**
     * 攻击结果
     */
    @TableField(value = "attack_result")
    @ApiModelProperty(value = "攻击结果")
    private String attackResult;

    /**
     * 攻击结果名称
     */
    @TableField(value = "attack_result_label")
    @ApiModelProperty(value = "攻击结果名称")
    private String attackResultLabel;

    /**
     * 攻击手段
     */
    @TableField(value = "attack_means")
    @ApiModelProperty(value = "攻击手段")
    private String attackMeans;

    /**
     * 攻击手段名称
     */
    @TableField(value = "attack_means_label")
    @ApiModelProperty(value = "攻击手段名称")
    private String attackMeansLabel;

    /**
     * 行为性质(0 正常 1 异常)
     */
    @TableField(value = "behavior_nature")
    @ApiModelProperty(value = "行为性质(0 正常 1 异常)")
    private String behaviorNature;

    /**
     * 告警来源
     */
    @TableField(value = "alarm_source")
    @ApiModelProperty(value = "告警来源")
    private String alarmSource;

    /**
     * 告警来源名称
     */
    @TableField(value = "alarm_source_label")
    @ApiModelProperty(value = "告警来源名称")
    private String alarmSourceLabel;

    /**
     * 攻击次数
     */
    @TableField(value = "attack_count")
    @ApiModelProperty(value = "攻击次数")
    private Integer attackCount;

    /**
     * 提交人
     */
    @TableField(value = "commit_user_name")
    @ApiModelProperty(value = "提交人")
    private String commitUserName;

    /**
     * 提交人姓名
     */
    @TableField(value = "commit_nick_name")
    @ApiModelProperty(value = "提交人姓名")
    private String commitNickName;

    /**
     * 告警详情
     */
    @TableField(value = "detail")
    @ApiModelProperty(value = "告警详情")
    private String detail;

    /**
     * 告警时间
     */
    @TableField(value = "alarm_time")
    @ApiModelProperty(value = "告警时间")
    @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss", timezone = "GMT+8")
    private Date alarmTime;

    /**
     * 流程处理完成时间
     */
    @TableField(value = "complete_time")
    @ApiModelProperty(value = "流程处理完成时间")
    @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss", timezone = "GMT+8")
    private Date completeTime;

    /**
     * 备注
     */
    @TableField(value = "remark")
    @ApiModelProperty(value = "备注")
    private String remark;

    /**
     * 工单状态 创建 研判 处置 后续跟进 审核 归档 无需处置
     */
    @TableField(value = "order_status")
    @ApiModelProperty(value = "工单状态 创建 研判 处置 后续跟进 审核 归档 无需处置")
    private String orderStatus;

    /**
     * 当前处理人姓名
     */
    @TableField(value = "current_deal_user")
    @ApiModelProperty(value = "当前处理人姓名")
    private String currentDealUser;

    /**
     * 当前处理人姓名
     */
    @TableField(value = "current_deal_user_nick_name")
    @ApiModelProperty(value = "当前处理人姓名")
    private String currentDealUserNickName;

    /**
     * 节点名称
     */
    @TableField(value = "node_key")
    @ApiModelProperty(value = "节点名称")
    private String nodeKey;

    /**
     * 责任部门ID
     */
    @TableField(value = "duty_dept_id")
    @ApiModelProperty(value = "责任部门ID")
    private Long dutyDeptId;

    /**
     * 已失陷IP
     */
    @TableField(value = "fallen_ip")
    @ApiModelProperty(value = "已失陷IP")
    private String fallenIp;

    /**
     * 上报类型（0 手动 1 系统自动）
     */
    @TableField(value = "report_type")
    @ApiModelProperty(value = "上报类型（0 手动 1 系统自动）")
    private Integer reportType;

    /**
     * 处理时间
     */
    @TableField(value = "handling_time")
    @ApiModelProperty(value = "处理时间")
    @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss", timezone = "GMT+8")
    private Date handlingTime;

    /**
     * 重点关注标记（0 未重点关注，1 已重点关注）
     */
    @TableField(value = "focus_tag")
    @ApiModelProperty(value = "重点关注标记（0 未重点关注，1 已重点关注）")
    private Integer focusTag;

    /**
     * AI研判值
     */
    @TableField(value = "ai_check")
    @ApiModelProperty(value = "AI研判值")
    private Double aiCheck;

    /**
     * 最后一次溯源状态(0 无需溯源 1 溯源中 2 溯源完毕)
     */
    @TableField(value = "traceability_status")
    @ApiModelProperty(value = "最后一次溯源状态(0 无需溯源 1 溯源中 2 溯源完毕)")
    private String traceabilityStatus;

    /**
     * 最后一次溯源状态名称
     */
    @TableField(value = "traceability_status_label")
    @ApiModelProperty(value = "最后一次溯源状态名称")
    private String traceabilityStatusLabel;

    /**
     * 告警设备
     */
    @TableField(value = "device")
    @ApiModelProperty(value = "告警设备")
    private String device;

    /**
     * 告警模型ID
     */
    @TableField(value = "event_model_id")
    @ApiModelProperty(value = "告警模型ID")
    private String eventModelId;

    /**
     * 租户ID
     */
    @TableField(value = "organization_id")
    @ApiModelProperty(value = "租户ID")
    private String organizationId;

    /**
     * 作战周期类型
     */
    @TableField(value = "fight_period_type")
    @ApiModelProperty(value = "作战周期类型")
    private String fightPeriodType;

    /**
     * 租户ID 为100 不为空； 非100 为空 流程来源(集团流程、租户流程#租户一层部门名称#)
     */
    @TableField(value = "process_source")
    @ApiModelProperty(value = "流程来源")
    private String processSource;

    /**
     * 知识库告警处置建议知识ID
     */
    @TableField(value = "knowledge_alarm_handle_id")
    @ApiModelProperty(value = "知识库告警处置建议知识ID")
    private String knowledgeAlarmHandleId;

    /**
     * 创建人姓名
     */
    @TableField(value = "create_by_label")
    @ApiModelProperty(value = "创建人姓名")
    private String createByLabel;

    /**
     * 上报集团流程成功租户的告警主表ID
     */
    @TableField(exist = false)
    @ApiModelProperty(value = "上报集团流程成功租户的告警主表ID")
    private String reportGroupReportId;

    /**
     * 是否转风险
     */
    @TableField(exist = false)
    @ApiModelProperty(value = "是否转风险 0 否 1 是")
    private String isTurnRisk;

    /**
     * 申请集团协助 0 否 1 是
     */
    @TableField(exist = false)
    @ApiModelProperty(value = "申请集团协助 0 否  1 是")
    private String applyGroupAssist;

    /**
     * 上报集团流程 0 未上报 1 已上报
     */
    @TableField(exist = false)
    @ApiModelProperty(value = "上报集团流程 0 未上报 1 已上报")
    private String reportGroupProcess;

    /**
     * 节点已读状态
     */
    @TableField(exist = false)
    @ApiModelProperty(value = "节点已读状态")
    private String nodeReadStatus;

    /**
     * 重点关注等级 0-5
     */
    @TableField(exist = false)
    @ApiModelProperty(value = "重点关注等级  0-5")
    private String attentionLevel;

    /**
     * 重点关注说明
     */
    @TableField(exist = false)
    @ApiModelProperty(value = "重点关注说明")
    private String attentionExplain;

    /**
     * 集团下发租户流程成功集团的告警主表ID
     */
    @TableField(exist = false)
    @ApiModelProperty(value = "集团下发租户流程成功集团的告警主表ID")
    private String groupIssueReportId;

    /**
     * 集团下发租户流程 0 未下发 1已下发
     */
    @TableField(exist = false)
    @ApiModelProperty(value = "集团下发租户流程 0 未下发 1已下发")
    private String groupIssueProcess;

    /**
     * 研判标签 多个用,隔开
     */
    @TableField(exist = false)
    @ApiModelProperty(value = "研判标签")
    private String judgeTag;

    /**
     * ip
     */
    @TableField(exist = false)
    @ApiModelProperty(value = "ip")
    private String ip;

    /**
     * 关联系统名称
     */
    @TableField(exist = false)
    @ApiModelProperty(value = "关联系统名称")
    private String name;

    /**
     * 关联IP类型 1：攻击IP 2：受害IP 3：攻击和受害IP
     */
    @TableField(exist = false)
    @ApiModelProperty(value = "相关IP类型 1：攻击IP 2：受害IP 3：攻击和受害IP")
    private String type;
}