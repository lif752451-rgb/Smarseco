package com.crc.alarm.model.dto;

import com.alibaba.excel.annotation.ExcelProperty;
import com.alibaba.excel.annotation.write.style.ColumnWidth;
import com.alibaba.excel.annotation.write.style.HeadRowHeight;
import lombok.Data;


/**
 * 告警闭环(hvv)-导出
 * @author SHUFENGFENG
 */
@Data
@HeadRowHeight(20)
@ColumnWidth(25)
public class AlarmHvvExportDTO {

    /**
     * 告警id
     */
    @ExcelProperty("告警ID")
    private String alarmId;

    /**
     * 标题
     */
    @ExcelProperty("标题")
    private String title;

    /**
     * 攻击ip
     */
    @ExcelProperty("攻击IP")
    private String attackIp;

    /**
     * 攻击ip归属信息
     */
    @ExcelProperty("攻击IP归属")
    private String attackAscription;

    /**
     * 受害ip/url
     */
    @ExcelProperty("受害IP/URL")
    private String victimizedIp;

    /**
     * 受害ip/url归属信息
     */
    @ExcelProperty("受害IP/URL归属")
    private String victimizedAscription;

    /**
     * 告警详情
     */
    @ExcelProperty("告警详情")
    private String detail;

    /**
     * 告警级别名称
     */
    @ExcelProperty("告警级别")
    private String levelLabel;

    /**
     * 攻击结果名称
     */
    @ExcelProperty("攻击结果")
    private String attackResultLabel;

    /**
     * 攻击手段名称
     */
    @ExcelProperty("攻击手段")
    private String attackMeansLabel;

    /**
     * 行为性质(0 正常 1非正常)
     */
    @ExcelProperty("行为性质")
    private String behaviorNature;

    /**
     * 告警来源名称
     */
    @ExcelProperty("告警来源")
    private String alarmSourceLabel;

    /**
     * 攻击次数
     */
    @ExcelProperty("攻击次数")
    private Integer attackCount;

    /**
     * AI研判值
     */
    @ExcelProperty("AI研判值")
    private Double aiCheck;

    /**
     * 提交人名称
     */
    @ExcelProperty("提交人")
    private String createByLabel;

    /**
     * 最后一次溯源状态名称
     */
    @ExcelProperty("溯源状态")
    private String traceabilityStatusLabel;

    /**
     * 告警时间
     */
    @ExcelProperty("告警时间")
    private String alarmTime;

    /**
     * 提交时间
     */
    @ExcelProperty("提交时间")
    private String createTime;

    /**
     * 研判耗时(s)
     */
    @ExcelProperty("研判耗时")
    private String judgeTimeConsuming;

    /**
     * 处置耗时(s)
     */
    @ExcelProperty("处置耗时")
    private String dealTimeConsuming;

    /**
     * 总耗时(s)
     */
    @ExcelProperty("总耗时")
    private String archiveTimeConsuming;

    /**
     * 工单状态
     */
    @ExcelProperty("工单状态")
    private String orderStatus;

    /**
     * 操作日志
     */
    @ExcelProperty("操作日志")
    private String operationLog;

}