package com.crc.alarm.convert;

import org.mapstruct.Mapper;
import org.mapstruct.factory.Mappers;

import com.crc.alarm.model.domain.AlarmCombatRemark;
import com.crc.alarm.model.request.AlarmCombatRemarkReq;
import com.crc.alarm.model.response.AlarmCombatRemarkResp;

/**
 * 实战告警闭环添加备注数据转换
 * 
 * @author zhangbing
 */
@Mapper
public interface AlarmCombatRemarkConvert {

    AlarmCombatRemarkConvert INSTANCE = Mappers.getMapper(AlarmCombatRemarkConvert.class);

    /**
     * 数据转换
     *
     * @param log AlarmCombatRemark
     * @return AlarmCombatRemarkResp
     */
    AlarmCombatRemarkResp convert(AlarmCombatRemark log);

    /**
     * 数据转换
     * 
     * @param resp AlarmCombatRemarkResp
     * @return AlarmCombatRemarkReq
     */
    AlarmCombatRemarkReq convert(AlarmCombatRemarkResp resp);
}
