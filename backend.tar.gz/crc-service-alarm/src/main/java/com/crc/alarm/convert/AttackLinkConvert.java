package com.crc.alarm.convert;

import com.crc.alarm.http.Intelligence;
import com.crc.alarm.model.dto.IntelligenceInfoResultDataDTO;
import com.crc.alarm.model.request.AddNodeRequest;
import com.crc.alarm.model.response.AlarmAttackLinkChartResponse;
import com.crc.alarm.model.response.AlarmAttackLinkNewChartResponse;
import com.crc.alarm.model.response.AlarmAttackLinkNewResponse;
import com.crc.alarm.model.response.AlarmAttackLinkResponse;
import com.crc.worker.TypeConversionWorker;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import org.mapstruct.Mappings;
import org.mapstruct.factory.Mappers;

import java.util.List;

/**
 * 攻击链路转换类
 *
 * @Author fuzhuangzhi
 * @Date 2022/7/5 11:49
 * @Version 1.0
 **/
@Mapper(uses = {TypeConversionWorker.class})
public interface AttackLinkConvert {

    AttackLinkConvert INSTANCE = Mappers.getMapper(AttackLinkConvert.class);


    /**
     * 转换对象
     * @param lists
     * @return
     */
    List<AlarmAttackLinkNewChartResponse.Node> convertNode(List<AlarmAttackLinkChartResponse.Node> lists);

    /**
     * 转换对象
     * @param target
     * @return
     */
    @Mappings({
            @Mapping(source = "ip", target = "id"),
            @Mapping(source = "ip", target = "label"),
            @Mapping(target = "color", expression = "java(com.crc.alarm.model.enums.AttackLinkNodeColor.findColorByAttackResult(target.getAttackResult()))"),
    })
    AlarmAttackLinkNewChartResponse.Node convertNode(AlarmAttackLinkChartResponse.Node target);


    /**
     * 转换对象
     * @param lists
     * @return
     */
    List<AlarmAttackLinkNewResponse> convert(List<AlarmAttackLinkResponse> lists);

    /**
     * 转换对象
     * @param target
     * @return
     */
    @Mappings({
            @Mapping(source = "attackIp", target = "source"),
            @Mapping(source = "victimizedIp", target = "target"),
    })
    AlarmAttackLinkNewResponse convert(AlarmAttackLinkResponse target);

    /**
     * 转换请求结果
     * @param intelligence
     * @return
     */
    @Mappings({
            @Mapping(source = "is_malicious", target = "isMalicious"),
            @Mapping(target = "location", ignore = true),
            @Mapping(source = "confidence_level", target = "confidenceLevel"),
            @Mapping(source = "judgments", target = "judgments", qualifiedByName = "toJsonString"),
            @Mapping(source = "source_name", target = "sourceName"),
            @Mapping(source = "tags_classes", target = "tag", qualifiedByName = "toJsonString"),
    })
    IntelligenceInfoResultDataDTO convertHttpResult(Intelligence intelligence);
}
