package com.crc.alarm.customer;

import cn.hutool.core.collection.CollUtil;
import cn.hutool.core.date.DateUtil;
import cn.hutool.core.util.StrUtil;
import cn.hutool.http.HtmlUtil;
import com.crc.alarm.config.AlarmNoticeConfig;
import com.crc.alarm.model.domain.AlarmCombatReport;
import com.crc.alarm.model.dto.AlarmReportDTO;
import com.crc.alarm.model.enums.AlarmCombatNodeEnum;
import com.crc.alarm.model.enums.AlarmNodeEnum;
import com.crc.alarm.model.request.AlarmCombatFormReq;
import com.crc.alarm.model.response.AlarmCombatRecordResp;
import com.crc.alarm.service.AlarmCombatRecordService;
import com.crc.asset.model.domain.Asset;
import com.crc.asset.service.AssetService;
import com.crc.authentication.mapper.SysDeptMapper;
import com.crc.authentication.model.domain.SysDept;
import com.crc.authentication.model.domain.SysDictData;
import com.crc.authentication.model.vo.SysUserVO;
import com.crc.authentication.services.SysDictDataService;
import com.crc.authentication.services.SysUserService;
import com.crc.authentication.utils.DictUtil;
import com.crc.common.constant.Constants;
import com.crc.common.model.WebsocketSendVo;
import com.crc.common.socket.WebSocket;
import com.crc.common.socket.WebsocketBusinessType;
import com.crc.common.utils.StrFormatter;
import com.crc.common.utils.StringUtils;
import com.crc.config.QywxMsgConfig;
import com.crc.core.dto.MailDTO;
import com.crc.core.dto.MsgSendDTO;
import com.crc.customer.EmailCustomer;
import com.crc.factory.MsgSendFactory;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.util.StopWatch;
import javax.annotation.Resource;
import java.util.*;
import java.util.stream.Collectors;
import static com.crc.alarm.model.constant.AlarmConstant.OPINION;
import static com.crc.alarm.model.enums.AlarmCombatFlowOperationEnum.*;
import static com.crc.alarm.model.enums.AlarmCombatNodeEnum.*;
import static com.crc.common.constant.Constants.Symbol.*;
import static com.crc.common.model.enums.DictTypeEnum.*;
import static com.crc.common.model.enums.DictValueEnum.*;
import static com.crc.qywx.QyweixinSendTypeEnum.TEXT;

/**
 * @Author
 * @Description 实战告警通知消费者
 * @DateTime
 */
@Slf4j
@Component
public class AlarmCombatNoticeCustomer {

    @Autowired
    private SysUserService sysUserService;

    @Autowired
    private AlarmNoticeConfig alarmNoticeConfig;

    @Autowired
    private EmailCustomer emailCustomer;

    @Autowired
    private SysDictDataService sysDictDataService;

    @Autowired
    private QywxMsgConfig qywxMsgConfig;

    @Autowired
    private AssetService assetService;

    @Resource
    private AlarmCombatRecordService alarmCombatRecordService;

    @Autowired
    private SysDeptMapper sysDeptMapper;

    public static void main(String[] args) {
        List<String> list = new ArrayList<>();
        String collect = list.stream().filter(StringUtils::isNotBlank).collect(Collectors
            .joining(Constants.Symbol.ZH_COMMA, Constants.Symbol.EN_LEFT_BRACKET, Constants.Symbol.EN_RIGHT_BRACKET));
        System.out.println(collect);
    }

    public void tack(AlarmCombatReport combatReport,AlarmCombatFormReq formReq) {
        StopWatch stopWatch = new StopWatch("AlarmCombatNoticeCustomer");
        stopWatch.start();
        log.info("准备开始发送通知参数:{}----对应发送人{}", combatReport,formReq);
        List<SysUserVO> sysUserList = sysUserService
            .findHasEmailByUserNames(Arrays.asList(formReq.getCurrentDealUser().split(COMMA)));
        if (combatAlarmMailSwitch() && sysUserList.size()>0) {
            //             runWorkCustomer.task(sysUserList.stream().map(SysUserVO::getUserName).collect(Collectors.toList()),
//             convertToRWorkText(alarmReportDTO));
            emailCustomer.task(convertToMailDTO(combatReport,formReq,sysUserList));
            // 异步发送流程websocket
            this.sendAlarmProcessWebSocket(combatReport , sysUserList);

        }else {
            log.info("实战告警发送EMAIL开关未打开");
        }
        if (combatAlarmIMSwitch() && sysUserList.size()>0) {
            // 异步发送企业微信，有度通知
            this.sendNotice(combatReport,formReq);
        }else {
            log.info("实战告警发送IM开关未打开");
        }
        stopWatch.stop();
        log.info("发送通知耗时:{}", stopWatch.prettyPrint());
    }

    private void sendNotice(AlarmCombatReport alarmReportDTO,AlarmCombatFormReq formReq) {
        List<String> toUser  = Arrays.asList(formReq.getCurrentDealUser().split(COMMA));
        if (CollUtil.isNotEmpty(toUser)) {
            MsgSendDTO msgSendDTO =
                    MsgSendDTO.builder().type(TEXT.getType()).to(toUser).msg(convertToVxMsg(alarmReportDTO,formReq)).build();
            MsgSendFactory.batchSend(Collections.singletonList(msgSendDTO), ALARM_PROCESS.getDictValue());
        }
    }

    /**
     * 构造微信消息
     *
     * @param alarmReport
     * @return
     */
    private String convertToVxMsg(AlarmCombatReport alarmReport,AlarmCombatFormReq formReq) {
        // 跳转url
        String jumpUrl = getJumpUrl(alarmReport);
        Map<String, String> map = new HashMap<>();
        SysDept sysDept = sysDeptMapper.selectDeptById(Long.valueOf(alarmReport.getOrganizationId()));
        // 工单状态
        map.put("workOrderState",  getNodeLabel( formReq.getNextNodeEnum().getNodeKey()));
        //流程来源
        map.put("nodeLabel", alarmReport.getOrganizationId().equals("100") ? "集团流程" : "租户流程 "+ZH_LEFT_PARENTHESES+sysDept.getDeptName()+ZH_RIGHT_PARENTHESES);
        // 作战周期
        map.put("fightPeriod",  DictUtil.getDictLabel(COMBAT_FIGHT_PERIOD.getName(), alarmReport.getFightPeriodType()));
        // 告警ID
        map.put("alarmId", StringUtils.nvlString(alarmReport.getAlarmId()));
        // 跳转链接
        map.put("url", StringUtils.nvlString(jumpUrl));
        // 告警标题
        map.put("title", StringUtils.nvlString(alarmReport.getTitle()));
        // 告警级别
        map.put("levelLabel", formReq.getLevelLabel() !=null ? formReq.getLevelLabel() :alarmReport.getLevelLabel());
        // 攻击结果
        map.put("attackResultLabel",formReq.getAttackResultLabel()  !=null ? formReq.getAttackResultLabel()  :alarmReport.getAttackResultLabel());
        // 攻击IP描述
        map.put("attackIpInfo",alarmReport.getAttackAscription().replaceAll(Constants.Symbol.PLACEHOLDER,LINE_FEED));
        // 受害IP描述
        map.put("victimizedIpDesc",alarmReport.getVictimizedAscription().replaceAll(Constants.Symbol.PLACEHOLDER,LINE_FEED));
        // 告警时间
        map.put("alarmTime", StringUtils.nvlString(DateUtil.formatDateTime(alarmReport.getAlarmTime())));
        // 告警详情
        map.put("detail", HtmlUtil.cleanHtmlTag(StringUtils.nvlString(alarmReport.getDetail())));
        map.put("recordInfo", StringUtils.nvlString(getCombatRecord(alarmReport.getId(),false)));
        return StrFormatter.mailFormat(qywxMsgConfig.getAlarmCombatNodeMsg(), map);
    }

    /**
     * 获取记录数据*
     */
    private String getCombatRecord(String alarmReportId,boolean isMaill) {
        StringBuffer sb = new StringBuffer();
        List<AlarmCombatRecordResp>  recordRespList =  alarmCombatRecordService.findAlarmCombatRecord(alarmReportId);
        if (!recordRespList.isEmpty()) {
            Optional<AlarmCombatRecordResp> judgeCombatRecordResp =  recordRespList.stream()
                    .filter(record -> JUDGE.getNodeKey().equals(record.getNodeKey()) && ACT_JUDGE.getActKey().equals(record.getOperation()))
                    .sorted(Comparator.comparing(AlarmCombatRecordResp::getUpdateTime).reversed())
                    .findFirst();
            if (judgeCombatRecordResp.isPresent()) {
                if (isMaill){
                    sb.append(JUDGE.getNodeLabel())
                            .append(OPINION + Constants.Symbol.COLON + Constants.Symbol.BLANK)
                            .append(StringUtils.nvlString(judgeCombatRecordResp.get().getOpinion())).append(Constants.Symbol.ZH_DOT)
                            .append(Constants.Symbol.JSBR);
                }else {
                    sb.append(JUDGE.getNodeLabel())
                            .append(OPINION + Constants.Symbol.COLON + Constants.Symbol.BLANK)
                            .append(StringUtils.nvlString(judgeCombatRecordResp.get().getOpinion())).append(Constants.Symbol.ZH_DOT)
                            .append(Constants.Symbol.LINE_FEED);

                }

            }
            Optional<AlarmCombatRecordResp> dealCombatRecordResp =  recordRespList.stream()
                    .filter(record -> DEAL.getNodeKey().equals(record.getNodeKey()) &&
                            (ACT_DEAL_PASS.getActKey().equals(record.getOperation())
                                    ||  ACT_DEAL_FORWARD_PASS.getActKey().equals(record.getOperation())) )
                    .sorted(Comparator.comparing(AlarmCombatRecordResp::getUpdateTime).reversed())
                    .findFirst();
            if (dealCombatRecordResp.isPresent() ) {
                if (isMaill){
                    sb.append(DEAL.getNodeLabel())
                            .append(OPINION + Constants.Symbol.COLON + Constants.Symbol.BLANK)
                            .append(StringUtils.nvlString(dealCombatRecordResp.get().getOpinion())).append(Constants.Symbol.ZH_DOT)
                            .append(Constants.Symbol.JSBR);

                }else {
                    sb.append(DEAL.getNodeLabel())
                            .append(OPINION + Constants.Symbol.COLON + Constants.Symbol.BLANK)
                            .append(StringUtils.nvlString(dealCombatRecordResp.get().getOpinion())).append(Constants.Symbol.ZH_DOT)
                            .append(Constants.Symbol.LINE_FEED);

                }

            }
            Optional<AlarmCombatRecordResp> followCombatRecordResp =  recordRespList.stream()
                    .filter(record -> FOLLOW.getNodeKey().equals(record.getNodeKey()) && ACT_FOLLOW_PASS.getActKey().equals(record.getOperation()))
                    .sorted(Comparator.comparing(AlarmCombatRecordResp::getUpdateTime).reversed())
                    .findFirst();
            if (followCombatRecordResp.isPresent() ) {
                if (isMaill){

                    sb.append(FOLLOW.getNodeLabel())
                            .append(OPINION + Constants.Symbol.COLON + Constants.Symbol.BLANK)
                            .append(StringUtils.nvlString(followCombatRecordResp.get().getOpinion())).append(Constants.Symbol.ZH_DOT)
                            .append(Constants.Symbol.JSBR);
                }else {
                    sb.append(FOLLOW.getNodeLabel())
                            .append(OPINION + Constants.Symbol.COLON + Constants.Symbol.BLANK)
                            .append(StringUtils.nvlString(followCombatRecordResp.get().getOpinion())).append(Constants.Symbol.ZH_DOT)
                            .append(Constants.Symbol.LINE_FEED);

                }

            }
            Optional<AlarmCombatRecordResp> auditCombatRecordResp =  recordRespList.stream()
                    .filter(record -> AUDIT.getNodeKey().equals(record.getNodeKey()) && ACT_AUDIT_FAIL.getActKey().equals(record.getOperation()))
                    .sorted(Comparator.comparing(AlarmCombatRecordResp::getUpdateTime).reversed())
                    .findFirst();
            if (auditCombatRecordResp.isPresent()) {
                if (isMaill){

                    sb.append(AUDIT.getNodeLabel())
                            .append(OPINION + Constants.Symbol.COLON + Constants.Symbol.BLANK)
                            .append(StringUtils.nvlString(auditCombatRecordResp.get().getOpinion())).append(Constants.Symbol.ZH_DOT)
                            .append(Constants.Symbol.JSBR);
                }else {
                    sb.append(AUDIT.getNodeLabel())
                            .append(OPINION + Constants.Symbol.COLON + Constants.Symbol.BLANK)
                            .append(StringUtils.nvlString(auditCombatRecordResp.get().getOpinion())).append(Constants.Symbol.ZH_DOT)
                            .append(Constants.Symbol.LINE_FEED);
                }

            }
        }
        return sb.toString();

    }

    /**
     * 获取IP对应的详细信息
     *
     * @param ips 多个IP用英文逗号隔开
     * @return
     */
    private String buildIpInfo(String ips) {
        List<Asset> ipInfoList = assetService.getIpInfo(ips);
        if (CollUtil.isEmpty(ipInfoList)) {
            return null;
        }
        return ipInfoList.stream().map(asset -> {
            StringBuffer sb = new StringBuffer();
            sb.append(StringUtils.nvlString(asset.getInternalIp())).append(Constants.Symbol.BLANK);
            List<String> ipInfoMsgList = Arrays
                .asList(StringUtils.nvlString(asset.getAffiliationDeptName()),
                    StringUtils.nvlString(asset.getAreaName()), StringUtils.nvlString(asset.getInstance()),
                    StringUtils.nvlString(asset.getAssetUser()))
                .stream().filter(StringUtils::isNotBlank).collect(Collectors.toList());
            if (CollUtil.isNotEmpty(ipInfoMsgList)) {
                String ipInfoStr = ipInfoMsgList.stream().collect(Collectors.joining(Constants.Symbol.ZH_COMMA,
                    Constants.Symbol.EN_LEFT_BRACKET, Constants.Symbol.EN_RIGHT_BRACKET));
                return sb.append(Constants.Symbol.BLANK).append(ipInfoStr);
            } else {
                return sb;
            }
        }).collect(Collectors.joining(Constants.Symbol.ZH_COMMA));
    }

    private MailDTO convertToMailDTO(AlarmCombatReport combatReport, AlarmCombatFormReq formReq,List<SysUserVO> sysUserVOList) {
        List<String> emailList = sysUserVOList.stream().map(SysUserVO::getEmail).collect(Collectors.toList());
        return MailDTO.builder().text(convertToMailText(combatReport,formReq))
            .to(CollUtil.join(emailList, COMMA)).subject(alarmNoticeConfig.getCombatSubject()).build();
    }

    /**
     * 发送webSocket
     *
     * @param alarmReport 告警信息
     * @param sysUserVOList 发送用户集合
     */
    private void sendAlarmProcessWebSocket(AlarmCombatReport alarmReport, List<SysUserVO> sysUserVOList) {
        log.info("告警发送WebSocket消息");
        WebsocketSendVo vo = new WebsocketSendVo();
        vo.setBusinessId(alarmReport.getAlarmId());
        vo.setBusinessType(WebsocketBusinessType.ALARM_PROCESS);
        vo.setMessage(alarmNoticeConfig.getCombatSubject());
        vo.setUrl(getJumpUrl(alarmReport));
        List<Long> userIdList = sysUserVOList.stream().map(SysUserVO::getUserId).filter(Objects::nonNull).distinct()
            .collect(Collectors.toList());
        log.info("告警发送WebSocket消息内容{}，接收用户{}", vo.toString(), userIdList.toString());
        WebSocket.batchSendMessageByUser(userIdList, vo);
    }

    private String convertToRWorkText(AlarmReportDTO alarmReport) {
        // 跳转url
        String jumpUrl = StrUtil.format(DictUtil.getJumpUrl(MAIL_URL.getName(), "alarmNoticeEmailUrl"),
            alarmReport.getId(), alarmReport.getOrganizationId());
        return StrUtil.format(alarmNoticeConfig.getMsg(),
            // 工单状态
            AlarmNodeEnum.CHECK.getNodeName().equals(alarmReport.getNodeName()) ? alarmReport.getNodeName()
                : alarmReport.getOrderStatus(),
            // 告警ID
            alarmReport.getAlarmId(),
            // 跳转url
            jumpUrl);
    }

    private String convertToMailText(AlarmCombatReport combatReport,AlarmCombatFormReq formReq) {
        // 默认邮件下文提示
        String defaultEmailContent = getDefaultEmailContent();
        // 跳转url
        String jumpUrl = getJumpUrl(combatReport);
        SysDept sysDept = sysDeptMapper.selectDeptById(Long.valueOf(combatReport.getOrganizationId()));


        return StrUtil.format(alarmNoticeConfig.getCombatText(),
                //工单状态
                getNodeLabel( formReq.getNextNodeEnum().getNodeKey()),
                // 跳转url
                jumpUrl, jumpUrl,
                // 流程来源
                combatReport.getOrganizationId().equals("100") ? "集团流程" : "租户流程 "+ZH_LEFT_PARENTHESES+sysDept.getDeptName()+ZH_RIGHT_PARENTHESES,
                //作战周期
                DictUtil.getDictLabel(COMBAT_FIGHT_PERIOD.getName(), combatReport.getFightPeriodType()),
                // 告警ID
                combatReport.getAlarmId(),
                // 标题
                combatReport.getTitle(),
                // 告警级别
                formReq.getLevelLabel() !=null ? formReq.getLevelLabel() :combatReport.getLevelLabel(),
                // 攻击结果
                formReq.getAttackResultLabel()  !=null ? formReq.getAttackResultLabel()  :combatReport.getAttackResultLabel(),
                // 攻击IP
                combatReport.getAttackAscription().replaceAll(Constants.Symbol.PLACEHOLDER,JSBR),
                // 受害IP/URL
                combatReport.getVictimizedAscription().replaceAll(Constants.Symbol.PLACEHOLDER,JSBR),
                // 告警时间
                DateUtil.formatDateTime(combatReport.getAlarmTime()),
                // 告警详情
                combatReport.getDetail(),
                //意见
                getCombatRecord(combatReport.getId(),true),
                // 邮件默认下文提示
                defaultEmailContent);
    }

    private String getJumpUrl(AlarmCombatReport combatReport) {
        String jumpUrl = "";
        //判断是否集团流程
        if (combatReport.getOrganizationId().equals("100")) {
            jumpUrl = StrUtil.format(DictUtil.getJumpUrl(MAIL_URL.getName(), "combatAlarmGroupUrl"),combatReport.getAlarmId());
        }else {
            jumpUrl = StrUtil.format(DictUtil.getJumpUrl(MAIL_URL.getName(), "combatAlarmTenantUrl"),combatReport.getAlarmId());
        }
        return jumpUrl+combatReport.getId();
    }

    private String getNodeLabel(String key) {
        AlarmCombatNodeEnum nodeEnum = AlarmCombatNodeEnum.getEnumByNodeKey(key);
        String nodeLabel = "";
        if (Objects.nonNull(nodeEnum)) {
            nodeLabel = nodeEnum.getNodeLabel();
        }
        return nodeLabel;
    }



    private String getDefaultEmailContent() {
        List<SysDictData> defaultEmailContents = sysDictDataService.selectDictDataByType("default_email_content");
        String defaultEmailContent = null;
        if (CollUtil.isNotEmpty(defaultEmailContents)) {
            List<String> list =
                defaultEmailContents.stream().map(SysDictData::getDictLabel).collect(Collectors.toList());
            defaultEmailContent = list.get(0);
        } else {
            defaultEmailContent = StringUtils.EMPTY;
        }
        return defaultEmailContent;
    }


    /**
     * 获取实战告警邮件开关
     *
     * @return Boolean true 打开 false 关闭
     */
    private Boolean combatAlarmMailSwitch() {
        // 风险闭环-邮件开关 1 打开 0 关闭
        return Constants.STR_VALUE_ONE.equals(DictUtil.getDictLabel(MAIL_URL.getName(), "combatAlarmMailSwitch"));
    }

    /**
     * 获取实战告警即使通讯开关
     *
     * @return Boolean true 打开 false 关闭
     */
    private Boolean combatAlarmIMSwitch() {
        // 风险闭环-邮件开关 1 打开 0 关闭
        return Constants.STR_VALUE_ONE.equals(DictUtil.getDictLabel(MAIL_URL.getName(), "combatAlarmIMSwitch"));
    }

    private Boolean combatAlarmYDSwitch() {
        // 风险闭环-邮件开关 1 打开 0 关闭
        return Constants.STR_VALUE_ONE.equals(DictUtil.getDictLabel(MAIL_URL.getName(), "combatAlarmYDSwitch"));
    }
}
