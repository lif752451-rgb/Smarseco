package com.crc.alarm.convert;

import com.crc.alarm.model.domain.AttackLinkHistory;
import com.crc.alarm.model.dto.AttackLinkHistoryDTO;
import com.crc.alarm.model.request.AddAttackLinkHistoryRequest;
import com.crc.alarm.model.request.AttackLinKRequest;
import com.crc.alarm.model.request.AttackLinkDetailRequest;
import com.crc.alarm.model.request.AttackLinkHistoryRequest;
import com.crc.worker.TypeConversionWorker;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import org.mapstruct.Mappings;
import org.mapstruct.factory.Mappers;

import java.util.List;

/**
 * 攻击链路转换类
 *
 * @Author fuzhuangzhi
 * @Date 2022/7/5 11:49
 * @Version 1.0
 **/
@Mapper(uses = {TypeConversionWorker.class})
public interface AttackLinkHistoryConvert {

    AttackLinkHistoryConvert INSTANCE = Mappers.getMapper(AttackLinkHistoryConvert.class);

    @Mappings({
            @Mapping(target="attackStartTime", expression = "java(cn.hutool.core.date.DateUtil.parseDateTime(request.getAttackTimeStart()))"),
            @Mapping(target="attackEndTime", expression = "java(cn.hutool.core.date.DateUtil.parseDateTime(request.getAttackTimeEnd()))"),
            @Mapping(target="linkName", expression = "java(com.crc.common.utils.StringUtils.convertHtmlLabel2Flag(request.getLinkName()))"),
    })
    AttackLinkHistory convert(AttackLinkHistoryRequest request);

    @Mappings({
            @Mapping(target="followIp", source = "internalIp"),
    })
    AttackLinKRequest convertDetail(AttackLinkDetailRequest request);


    /**
     * 新版保存
     * @param request
     * @return
     */
    @Mappings({
            @Mapping(target="attackStartTime", expression = "java(cn.hutool.core.date.DateUtil.parseDateTime(request.getAttackTimeStart()))"),
            @Mapping(target="attackEndTime", expression = "java(cn.hutool.core.date.DateUtil.parseDateTime(request.getAttackTimeEnd()))"),
            @Mapping(target="linkName", expression = "java(com.crc.common.utils.StringUtils.convertHtmlLabel2Flag(request.getLinkName()))"),
            @Mapping(target="id", ignore = true),
    })
    AttackLinkHistory convertToModel(AddAttackLinkHistoryRequest request);

    /**
     * 转换dto
     * @param attackLinkHistory
     * @return
     */
    @Mappings({
            @Mapping(source="id", target = "historyId"),
    })
    AttackLinkHistoryDTO convertToDTO(AttackLinkHistory attackLinkHistory);


    /**
     * 转换dto
     * @param attackLinkHistoryies
     * @return
     */
    List<AttackLinkHistoryDTO> convertToDTO(List<AttackLinkHistory> attackLinkHistoryies);
}
