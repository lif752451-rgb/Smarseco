package com.crc.alarm.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.crc.alarm.model.domain.AlarmAreaStat;
import org.apache.ibatis.annotations.Param;

import java.util.List;

public interface AlarmAreaStatMapper extends BaseMapper<AlarmAreaStat> {

    void batchInsert(@Param("list") List<AlarmAreaStat> list);

    List<AlarmAreaStat> selectListByTypeAndAttackDate(@Param("attackDate") String attackDate, @Param("type") String type);

}
