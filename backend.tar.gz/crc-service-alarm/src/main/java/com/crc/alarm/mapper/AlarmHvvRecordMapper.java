package com.crc.alarm.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.crc.alarm.model.domain.AlarmHvvRecord;
import org.apache.ibatis.annotations.Mapper;

/**
 * 告警闭环-流程表Mapper
 */
@Mapper
public interface AlarmHvvRecordMapper extends BaseMapper<AlarmHvvRecord> {
}