package com.crc.alarm.config;

import lombok.Data;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.PropertySource;

/**
 * @author SHUFENGFENG
 * @Description 告警发送邮件配置类
 * @DateTime 2021/9/13 16:34
 */
@Data
@Configuration
@PropertySource(value = "config/alarmNotice.properties", encoding = "UTF-8")
public class AlarmNoticeConfig {
    /**
     * 主题
     */
    @Value("${alarm.notice.subject}")
    private String subject;
    /**
     * 邮件内容
     */
    @Value("${alarm.notice.text}")
    private String text;

    /**
     * 主题
     */
    @Value("${alarm.combat.notice.subject}")
    private String combatSubject;

    /**
     * 邮件内容
     */
    @Value("${alarm.combat.notice.text}")
    private String combatText;


    /**
     * 润工作内容
     */
    @Value("${alarm.notice.msg}")
    private String msg;
}
