package com.crc.alarm.mapper;

import java.util.List;

import com.crc.alarm.model.request.AlarmCombatBatchJudgeSearchReq;
import com.crc.alarm.model.response.CriticalSystemAlarmListResp;
import com.crc.alarm.model.response.CriticalSystemCountResp;
import com.crc.approval.model.response.ProcessRiskListResponse;
import com.crc.asset.model.request.CriticalSystemAlarmListReq;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.crc.alarm.model.domain.AlarmCombatReport;
import com.crc.alarm.model.dto.AlarmCombatReportDTO;
import com.crc.alarm.model.dto.AlarmPriorityDTO;
import com.crc.alarm.model.request.AlarmCombatReportPermissionReq;
import com.crc.alarm.model.response.AlarmCombatReportResp;
import com.crc.alarm.model.response.AlarmCombatTopStateResp;
import com.crc.common.model.response.DictStatResp;

/**
 * 实战告警闭环主表Mapper
 *
 * @author zhangbing
 */
@Mapper
public interface AlarmCombatReportMapper extends BaseMapper<AlarmCombatReport> {

    /**
     * 查询详情
     *
     * @param id 主键ID
     * @return 告警闭环-列表显示
     */
    AlarmCombatReportResp findById(@Param("id") String id);

    /**
     * 节点数据统计-有搜索条件-无数据权限
     *
     * @param combatDto 实战告警闭环-查询参数
     * @return 返回结果
     */
    AlarmCombatTopStateResp findAlarmCombatNodeNameQueryCount(@Param("combatDto") AlarmCombatReportDTO combatDto);

    /**
     * 节点数据统计-无搜索条件-有数据权限
     *
     * @param combatDto 实战告警闭环-查询参数
     * @param dr 实战告警闭环-列表数据权限
     * @return 返回结果
     */
    AlarmCombatTopStateResp findAlarmCombatNodeNameCount(@Param("combatDto") AlarmCombatReportDTO combatDto,
        @Param("dr") AlarmCombatReportPermissionReq dr);

    /**
     * 查询列表
     *
     * @param combatDto 实战告警闭环-查询参数
     * @param dr 实战告警闭环-列表数据权限
     * @return List<实战告警闭环-列表>
     */
    List<AlarmCombatReportResp> findAlarmCombatReportPage(@Param("combatDto") AlarmCombatReportDTO combatDto,
        @Param("dr") AlarmCombatReportPermissionReq dr);


    /**
     * 查询列表
     *
     * @param combatDto 实战告警闭环-查询参数
     * @param dr 实战告警闭环-列表数据权限
     * @return List<实战告警闭环-列表>
     */
    List<AlarmCombatReportResp> findAlarmCombatReportPageCommon(@Param("combatDto") AlarmCombatReportDTO combatDto,
                                                          @Param("dr") AlarmCombatReportPermissionReq dr);


    /**
     * 批量查询详情信息
     *
     * @param ids 主键ID集合
     * @return List
     */
    List<AlarmCombatReportResp> batchFindByIds(@Param("ids") List<String> ids);

    /**
     * 通过alarmId获取AI研判置信度
     *
     * @param alarmId 实战告警闭环告警ID
     * @return AlarmPriorityDTO
     */
    AlarmPriorityDTO priorityById(@Param("alarmId") String alarmId);

    /**
     * 关联告警工单统计
     *
     * @param combatDto 入参
     * @return 数量
     */
    Integer findRelationOrderAllCount(@Param("combatDto") AlarmCombatReportDTO combatDto);

    /**
     * 查询关联工单统计
     *
     * @param combatDto AlarmCombatReportDTO
     * @return List
     */
    AlarmCombatTopStateResp findRelationOrderCount(@Param("combatDto") AlarmCombatReportDTO combatDto);

    /**
     * 查询关联工单统计
     *
     * @param combatDto AlarmCombatReportDTO
     * @return List
     */
    List<AlarmCombatReportResp> findRelationOrder(@Param("combatDto") AlarmCombatReportDTO combatDto);

    /**
     * 查询是否失陷
     *
     * @param ips IP集合
     * @return Integer
     */
    List<String> findFallenIpList(@Param("ips") List<String> ips);

    /**
     * 告警级别分组统计
     *
     * @param combatDto 入参
     * @return List
     */
    List<DictStatResp> findGroupAlarmLevelCount(@Param("combatDto") AlarmCombatReportDTO combatDto);

    /**
     * 攻击手段分组统计
     *
     * @param combatDto 入参
     * @return List
     */
    List<DictStatResp> findGroupAttackMeansCount(@Param("combatDto") AlarmCombatReportDTO combatDto);

    /**
     * 攻击结果分组统计
     *
     * @param combatDto 入参
     * @return List
     */
    List<DictStatResp> findGroupAttackResultCount(@Param("combatDto") AlarmCombatReportDTO combatDto);

    /**
     * 作战周期时间范围分组统计
     *
     * @param combatDto 入参
     * @return List
     */
    List<DictStatResp> findGroupFightPeriodTimeCount(@Param("combatDto") AlarmCombatReportDTO combatDto);

    List<AlarmCombatReport> selectListByCreateTime(@Param("attackDate") String attackDate,
        @Param("combatPeriod") String combatPeriod);

    List<AlarmCombatReport> selectListByCreateTimeV1(@Param("attackDate") String attackDate);

    /**
     * 查询集权系统/等保系统的告警列表
     *
     * @param searchRequest 查询告警参数
     * @return 关联系统告警列表
     */
    List<CriticalSystemAlarmListResp> getCriticalSysAlarmList(@Param("param") CriticalSystemAlarmListReq searchRequest);
    /**
     * 查询实战告警列表
     *
     * @param searchRequest IP查询参数
     * @return 实战告警列表
     */
    List<AlarmCombatReport> selectAlarmListByIp(@Param("param") CriticalSystemAlarmListReq searchRequest);

    /**
     * 查询实战告警列表
     *
     * @param searchRequest 网段查询参数
     * @return 实战告警列表
     */
    List<AlarmCombatReport> selectAlarmListBySegment(@Param("param") CriticalSystemAlarmListReq searchRequest);

    /**
     * 获取转风险记录
     * @param id
     * @return
     */
    List<ProcessRiskListResponse.RiskSubmit> getCombatAlarm(String id);

    /**
     * 批量更新实战告警是否转风险
     */
    void updateAlarmIsTurnRisk(List<String> ids);

    /**
     * 风险残留实战告警列表
     *
     * @param searchRequest 查询参数
     * @return 风险残留实战告警列表
     */
    List<CriticalSystemAlarmListResp> getRiskCriticalSysAlarmList(@Param("param") CriticalSystemAlarmListReq searchRequest);

    /**
     * 互联网暴露实战告警列表
     *
     * @param searchRequest 查询参数
     * @return 互联网暴露实战告警列表
     */
    List<CriticalSystemAlarmListResp> getInternetCriticalSysAlarmList(@Param("param") CriticalSystemAlarmListReq searchRequest);

    /**
     * 靶标/靶标相关/数据风险高资产实战告警列表
     * @param searchRequest 查询参数
     * @return 靶标/靶标相关/数据风险高资产实战告警列表
     */
    List<CriticalSystemAlarmListResp> getCustomCriticalSysAlarmList(@Param("param") CriticalSystemAlarmListReq searchRequest);


    /**
     * 查询集权系统/等保系统/数据风险高的告警结果分组
     *
     * @param searchRequest 查询告警参数
     * @return 关联系统告警结果分组
     */
    List<CriticalSystemCountResp> getCriticalCount(@Param("param") CriticalSystemAlarmListReq searchRequest);

    /**
     * 风险残留告警结果分组
     *
     * @param searchRequest 查询告警参数
     * @return 风险残留告警结果分组
     */
    List<CriticalSystemCountResp> getRiskCriticalCount(@Param("param") CriticalSystemAlarmListReq searchRequest);

    /**
     * 互联网暴露告警结果分组
     *
     * @param searchRequest 查询告警参数
     * @return 互联网暴露告警结果分组
     */
    List<CriticalSystemCountResp> getInternetCriticalCount(@Param("param") CriticalSystemAlarmListReq searchRequest);

    /**
     * 靶标/靶标相关/数据风险高告警结果分组
     *
     * @param searchRequest 查询告警参数
     * @return 靶标/靶标相关/数据风险高告警结果分组
     */
    List<CriticalSystemCountResp> getCustomCriticalCount(@Param("param") CriticalSystemAlarmListReq searchRequest);

    /**
     * 实战告警闭环-查询批量研判列表
     *
     * @param request 批量研判列查询参数
     * @return 实战告警列表
     */
    List<AlarmCombatReportResp> getBatchJudgeList(@Param("param") AlarmCombatBatchJudgeSearchReq request);

    List<AlarmCombatReportResp> selectListByPeriod(@Param("period") String period, @Param("userList") List<String> userList);

}
