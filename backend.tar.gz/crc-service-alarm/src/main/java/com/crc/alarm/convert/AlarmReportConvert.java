package com.crc.alarm.convert;

import com.crc.alarm.model.domain.AlarmReport;
import com.crc.alarm.model.dto.*;
import com.crc.alarm.model.request.*;
import com.crc.alarm.model.response.AlarmDetailResponse;
import com.crc.alarm.model.response.AlarmExportResponse;
import com.crc.alarm.model.response.AlarmIpCorrelationOrderDetail;
import com.crc.alarm.model.response.AlarmListResponse;
import com.crc.authentication.model.request.FindBusinessDeptRequest;
import com.crc.common.model.request.OrganizationBasicRequest;
import com.crc.worker.TypeConversionWorker;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import org.mapstruct.Mappings;
import org.mapstruct.factory.Mappers;

import java.util.List;

/**
 * @Author shufengfeng
 * @Description 告警主表请求转换类
 * @DateTime 2021/8/31 16:54
 */
@Mapper(uses = {TypeConversionWorker.class})
public interface AlarmReportConvert {

    AlarmReportConvert INSTANCE = Mappers.getMapper(AlarmReportConvert.class);


    /**
     * 误报转换主表修改
     * @param request
     * @return
     */
    @Mappings({
            @Mapping(target="orderStatus", expression = "java(com.crc.alarm.model.enums.AlarmNodeEnum.NO_DEAL.getNodeName())"),
            @Mapping(target="updateTime", expression = "java(new java.util.Date())"),
            @Mapping(target="completeTime", expression = "java(new java.util.Date())"),
            @Mapping(target ="handlingTime", expression = "java(new java.util.Date())"),
            @Mapping(target ="assignedPerson", expression = "java(request.getDealNickName() + \"(\" + request.getDealUserName() + \")\")")})
    UpdateAlarmReportByBusinessKeyDTO convertToUpdateDTO(AlarmFormMisinformationRequest request);

    /**
     * 非误报转换主表修改
     * @param request
     * @return
     */
    @Mappings({
            @Mapping(target="orderStatus", expression = "java(com.crc.alarm.model.enums.AlarmNodeEnum.DEAL.getNodeName())"),
            @Mapping(target="nodeName", expression = "java(com.crc.alarm.model.enums.AlarmNodeEnum.DEAL.getNodeName())"),
            @Mapping(target="updateTime", expression = "java(new java.util.Date())"),
            @Mapping(target="updateUser", source = "dealUserName"),
            @Mapping(target="currentDealUser", source = "securityUserName"),
            @Mapping(target="currentDealUserNickName", source = "securityUserNikeName"),
            @Mapping(target ="handlingTime", expression = "java(new java.util.Date())"),
            @Mapping(target ="assignedPerson", expression = "java(request.getDealNickName() + \"(\" + request.getDealUserName() + \")\")"),
    })
    UpdateAlarmReportByBusinessKeyDTO convertToUpdateDTO(AlarmFormJudgeRequest request);

    /**
     * 处置(不转办)转换主表修改
     * @param request
     * @return
     */
    @Mappings({
            @Mapping(target="orderStatus", expression = "java(com.crc.alarm.model.enums.AlarmNodeEnum.AUDIT.getNodeName())"),
            @Mapping(target="nodeName", expression = "java(com.crc.alarm.model.enums.AlarmNodeEnum.AUDIT.getNodeName())"),
            @Mapping(target="updateTime", expression = "java(new java.util.Date())"),
            @Mapping(target="updateUser", source = "dealUserName"),
            @Mapping(target ="handlingTime", expression = "java(new java.util.Date())"),
            @Mapping(target ="assignedPerson", expression = "java(request.getDealNickName() + \"(\" + request.getDealUserName() + \")\")"),
    })
    UpdateAlarmReportByBusinessKeyDTO convertToUpdateDTO(AlarmFormDealRequest request);

    /**
     * 处置(转办)转换主表修改
     * @param request
     * @return
     */
    @Mappings({
            @Mapping(target="orderStatus", expression = "java(com.crc.alarm.model.enums.AlarmNodeEnum.DEAL.getNodeName())"),
            @Mapping(target="nodeName", expression = "java(com.crc.alarm.model.enums.AlarmNodeEnum.CONVERT_DEAL.getNodeName())"),
            @Mapping(target="updateTime", expression = "java(new java.util.Date())"),
            @Mapping(target="updateUser", source = "dealUserName"),
            @Mapping(target ="handlingTime", expression = "java(new java.util.Date())"),
            @Mapping(target ="assignedPerson", expression = "java(request.getDealNickName() + \"(\" + request.getDealUserName() + \")\")"),
    })
    UpdateAlarmReportByBusinessKeyDTO convertToUpdateDTO(AlarmFormDealConvertRequest request);

    /**
     * 处置(驳回)转换主表修改
     * @param request
     * @return
     */
    @Mappings({
            @Mapping(target="orderStatus", expression = "java(com.crc.alarm.model.enums.AlarmNodeEnum.JUDGE.getNodeName())"),
            @Mapping(target="nodeName", expression = "java(com.crc.alarm.model.enums.AlarmNodeEnum.JUDGE.getNodeName())"),
            @Mapping(target="updateTime", expression = "java(new java.util.Date())"),
            @Mapping(target="updateUser", source = "dealUserName"),
            @Mapping(target ="handlingTime", expression = "java(new java.util.Date())"),
            @Mapping(target ="assignedPerson", expression = "java(request.getDealNickName() + \"(\" + request.getDealUserName() + \")\")")
    })
    UpdateAlarmReportByBusinessKeyDTO convertToUpdateDTO(AlarmFormDealRejectRequest request);

    /**
     * 转办处置转换主表修改
     * @param request
     * @return
     */
    @Mappings({
            @Mapping(target="updateTime", expression = "java(new java.util.Date())"),
            @Mapping(target="updateUser", source = "dealUserName"),
            @Mapping(target ="handlingTime", expression = "java(new java.util.Date())"),
            @Mapping(target ="assignedPerson", expression = "java(request.getDealNickName() + \"(\" + request.getDealUserName() + \")\")")
    })
    UpdateAlarmReportByBusinessKeyDTO convertToUpdateDTO(AlarmFormConvertDealRequest request);

    /**
     * 转换处置驳回转换主表修改
     * @param request
     * @return
     */
    @Mappings({
            @Mapping(target="orderStatus", expression = "java(com.crc.alarm.model.enums.AlarmNodeEnum.DEAL.getNodeName())"),
            @Mapping(target="nodeName", expression = "java(com.crc.alarm.model.enums.AlarmNodeEnum.DEAL.getNodeName())"),
            @Mapping(target="updateTime", expression = "java(new java.util.Date())"),
            @Mapping(target="updateUser", source = "dealUserName"),
            @Mapping(target ="handlingTime", expression = "java(new java.util.Date())"),
            @Mapping(target ="assignedPerson", expression = "java(request.getDealNickName() + \"(\" + request.getDealUserName() + \")\")")
    })
    UpdateAlarmReportByBusinessKeyDTO convertToUpdateDTO(AlarmFormConvertDealRejectRequest request);

    /**
     * 转换复核主表修改
     * @param request
     * @return
     */
    @Mappings({
            @Mapping(target="orderStatus", expression = "java(" +
                    " com.crc.common.model.enums.ResultEnum.PASS.equals(request.getCheckResult())  " +
                    " ? com.crc.alarm.model.enums.AlarmNodeEnum.AUDIT.getNodeName()" +
                    " : com.crc.alarm.model.enums.AlarmNodeEnum.DEAL.getNodeName())"),
            @Mapping(target="nodeName", expression = "java(" +
                    " com.crc.common.model.enums.ResultEnum.PASS.equals(request.getCheckResult())  " +
                    " ? com.crc.alarm.model.enums.AlarmNodeEnum.AUDIT.getNodeName()" +
                    " : com.crc.alarm.model.enums.AlarmNodeEnum.CONVERT_DEAL.getNodeName())"),
            @Mapping(target="updateTime", expression = "java(new java.util.Date())"),
            @Mapping(target="updateUser", source = "dealUserName"),
            @Mapping(target="currentDealUser", expression = "java(com.crc.common.constant.Constants.BLANK_STR)"),
            @Mapping(target ="handlingTime", expression = "java(new java.util.Date())"),
            @Mapping(target ="assignedPerson", expression = "java(request.getDealNickName() + \"(\" + request.getDealUserName() + \")\")")
    })
    UpdateAlarmReportByBusinessKeyDTO convertToUpdateDTO(AlarmFormCheckRequest request);

    /**
     * 转换审核主表修改
     * @param request
     * @return
     */
    @Mappings({
            @Mapping(target="updateTime", expression = "java(new java.util.Date())"),
            @Mapping(target="updateUser", source = "dealUserName"),
            @Mapping(target="currentDealUser", expression = "java(com.crc.common.constant.Constants.BLANK_STR)"),
            @Mapping(target ="handlingTime", expression = "java(new java.util.Date())"),
            @Mapping(target ="assignedPerson", expression = "java(request.getDealNickName() + \"(\" + request.getDealUserName() + \")\")")
    })
    UpdateAlarmReportByBusinessKeyDTO convertToUpdateDTO(AlarmFormAuditRequest request);

    /**
     * 转换dto
     * @param byBusinessKey
     * @return
     */
    AlarmReportDTO convertToDTO(AlarmReport byBusinessKey);

    /**
     * 转换详情
     * @param dto
     * @return
     */
    @Mappings({
            @Mapping(source = "createTime" ,target="createTime" ,dateFormat = "yyyy-MM-dd HH:mm:ss"),
            @Mapping(source = "alarmTime" ,target="alarmTime" ,dateFormat = "yyyy-MM-dd HH:mm:ss"),
    })
    AlarmDetailResponse convertToResponse(AlarmDetailDTO dto);

    /**
     * 告警导出转换
     * @param response
     * @return
     */
    @Mappings({
            @Mapping(source = "createTime" ,target="createTime" ,dateFormat = "yyyy-MM-dd HH:mm:ss"),
            @Mapping(source = "alarmTime" ,target="alarmTime" ,dateFormat = "yyyy-MM-dd HH:mm:ss"),
            @Mapping(source = "completeTime" ,target="completeTime" ,dateFormat = "yyyy-MM-dd HH:mm:ss"),
            @Mapping(target = "attackAscription" ,expression = "java(com.crc.alarm.utils.IpUtils.splitIp(response.getAttackIp(),response.getAttackAscription(),com.crc.common.constant.Constants.Symbol.LINE_FEED).replace(com.crc.common.constant.Constants.Symbol.SPACE,com.crc.common.constant.Constants.Symbol.STR_EMPTY))"),
            @Mapping(target = "victimizedAscription" ,expression = "java(com.crc.alarm.utils.IpUtils.splitIp(response.getVictimizedIp(),response.getVictimizedAscription(),com.crc.common.constant.Constants.Symbol.LINE_FEED).replace(com.crc.common.constant.Constants.Symbol.SPACE,com.crc.common.constant.Constants.Symbol.STR_EMPTY))"),
    })
    AlarmExportResponse convertToExportInfo(AlarmListResponse response);

    /**
     * 系统自动上报参数转换
     * @param request
     * @return
     */
    @Mappings({
            @Mapping(target="reportType", expression="java(1)"),
            @Mapping(target = "aiCheck", expression = "java(com.crc.common.utils.StringUtils.isNumeric(request.getAiCheck())?Double.parseDouble(request.getAiCheck()):0)"),
    })
    AlarmReport convert(AlarmReportAutoRequest request);

    /**
     * 转换
     * @param request
     * @return
     */
    @Mappings({
            @Mapping(source="currentUser",target="commitUserName"),
            @Mapping(source="currentUserNickName",target="commitNickName"),
    })
    AlarmReport convert(AlarmReportRequestOrganization request);

    /**
     * 转换请求
     * @param request
     * @return
     */
    FindBusinessDeptRequest convert(OrganizationBasicRequest request);

    /**
     * 转换请求
     * @param alarmSearchRequest
     * @return
     */
    AlarmListTopStateRequestOrganization convertToOrganization(AlarmSearchRequestOrganization alarmSearchRequest);

    /**
     * 转换到攻击链路展示对象
     * @param alarm
     * @return
     */
    List<AttackLinkAlarmReportDTO> convert(List<AlarmReport> alarm);

    /**
     * 告警导出转换
     * @param list
     * @return
     */
    List<AlarmExportDTO> convertToExport(List<AlarmListResponse> list);

    /**
     * 告警导出转换
     * @param response
     * @return
     */
    @Mappings({
            @Mapping(source = "createTime" ,target="createTime" ,qualifiedByName = "doFormatDateTime"),
            @Mapping(source = "alarmTime" ,target="alarmTime" ,qualifiedByName = "doFormatDateTime"),
            @Mapping(target = "attackAscription" ,expression = "java(com.crc.alarm.utils.IpUtils.splitIp(response.getAttackIp(),response.getAttackAscription(),com.crc.common.constant.Constants.Symbol.LINE_FEED).replace(com.crc.common.constant.Constants.Symbol.SPACE,com.crc.common.constant.Constants.Symbol.STR_EMPTY))"),
            //@Mapping(target = "victimizedAscription" ,expression = "java(com.crc.alarm.utils.IpUtils.splitIp(response.getVictimizedIp(),response.getVictimizedAscription(),com.crc.common.constant.Constants.Symbol.LINE_FEED).replace(com.crc.common.constant.Constants.Symbol.SPACE,com.crc.common.constant.Constants.Symbol.STR_EMPTY))"),
            @Mapping(target = "behaviorNature" ,expression = "java(com.crc.common.constant.enums.AlarmBehaviorNatureEnum.getEnum(response.getBehaviorNature()))"),
    })
    AlarmExportDTO convertToExport(AlarmListResponse response);

    /**
     * 转换告警关联工单概览详情
     * @param detailDTO
     * @return
     */
    @Mappings({
        @Mapping(source = "createTime" ,target="createTime" ,dateFormat = "yyyy-MM-dd HH:mm:ss"),
        @Mapping(source = "alarmTime" ,target="alarmTime" ,dateFormat = "yyyy-MM-dd HH:mm:ss"),
    }) AlarmIpCorrelationOrderDetail convert(AlarmDetailDTO detailDTO);

    /**
     * 转换批量研判告警工单列表
     * @param alarmReports
     * @return
     */
    List<AlarmListResponse> convertToJudgeList(List<AlarmReport> alarmReports);

    /**
     * 转换批量研判对象
     * @param request
     * @return
     */
    @Mappings({
            @Mapping(target="orderStatus", expression = "java(request.getMisinformation() == 0 ? com.crc.alarm.model.enums.AlarmNodeEnum.DEAL.getNodeName() : com.crc.alarm.model.enums.AlarmNodeEnum.NO_DEAL.getNodeName())"),
            @Mapping(target="nodeName", expression = "java(request.getMisinformation() == 0 ? com.crc.alarm.model.enums.AlarmNodeEnum.DEAL.getNodeName() : com.crc.alarm.model.enums.AlarmNodeEnum.NO_DEAL.getNodeName())"),
            @Mapping(target="updateTime", expression = "java(new java.util.Date())"),
            @Mapping(target="updateUser", source = "dealUserName"),
            @Mapping(target="currentDealUser", expression = "java(request.getMisinformation() == 0 ? request.getSecurityUserName() : null)"),
            @Mapping(target="currentDealUserNickName", expression = "java(request.getMisinformation() == 0 ? request.getSecurityUserNikeName() : null)"),
            @Mapping(target ="handlingTime", expression = "java(new java.util.Date())"),
            @Mapping(target ="assignedPerson", expression = "java(request.getDealNickName() + \"(\" + request.getDealUserName() + \")\")")
    })
    UpdateAlarmReportByBusinessKeyDTO convertToUpdateDTO(AlarmBatchJudgeRequest request);
}
