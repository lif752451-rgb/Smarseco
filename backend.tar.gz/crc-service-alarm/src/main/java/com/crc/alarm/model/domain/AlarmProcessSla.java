package com.crc.alarm.model.domain;

import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableField;
import com.baomidou.mybatisplus.annotation.TableId;
import com.baomidou.mybatisplus.annotation.TableName;
import com.crc.core.model.BasicPHEntity;
import com.fasterxml.jackson.annotation.JsonFormat;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;
import lombok.EqualsAndHashCode;

import java.util.Date;

/**
 * 告警闭环-流程节点耗时表
 */
@ApiModel(value = "告警闭环-流程节点耗时")
@Data
@EqualsAndHashCode(callSuper = true)
@TableName(value = "tb_alarm_process_sla")
public class AlarmProcessSla extends BasicPHEntity {

    /**
     * 主键ID
     */
    @ApiModelProperty(value = "主键ID")
    @TableId(value = "id", type = IdType.AUTO)
    private Long id;

    /**
     * 告警闭环主表ID
     */
    @ApiModelProperty(value = "告警闭环主表ID")
    @TableField(value = "alarm_report_id")
    private Long alarmReportId;

    /**
     * 最后一次研判时间
     */
    @ApiModelProperty(value = "最后一次研判时间")
    @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss", timezone = "GMT+8")
    @TableField(value = "judge_time")
    private Date judgeTime;

    /**
     * 研判耗时(s)
     */
    @ApiModelProperty(value = "研判耗时(s)")
    @TableField(value = "judge_time_consuming")
    private Long judgeTimeConsuming;

    /**
     * 最后一次处置时间
     */
    @ApiModelProperty(value = "最后一次处置时间")
    @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss", timezone = "GMT+8")
    @TableField(value = "deal_time")
    private Date dealTime;

    /**
     * 处置耗时(s)
     */
    @ApiModelProperty(value = "处置耗时(s)")
    @TableField(value = "deal_time_consuming")
    private Long dealTimeConsuming;

    /**
     * 最后一次审核时间
     */
    @ApiModelProperty(value = "最后一次审核时间")
    @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss", timezone = "GMT+8")
    @TableField(value = "audit_time")
    private Date auditTime;

    /**
     * 审核耗时(s)
     */
    @ApiModelProperty(value = "审核耗时(s)")
    @TableField(value = "audit_time_consuming")
    private Long auditTimeConsuming;

    /**
     * 最后一次归档时间
     */
    @ApiModelProperty(value = "最后一次归档时间")
    @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss", timezone = "GMT+8")
    @TableField(value = "archive_time")
    private Date archiveTime;

    /**
     * 归档耗时/总耗时(s)
     */
    @ApiModelProperty(value = "归档耗时/总耗时(s)")
    @TableField(value = "archive_time_consuming")
    private Long archiveTimeConsuming;
}