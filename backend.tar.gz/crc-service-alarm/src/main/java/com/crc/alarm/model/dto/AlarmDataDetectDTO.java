package com.crc.alarm.model.dto;

import com.alibaba.fastjson.JSONObject;
import lombok.Data;

import java.util.List;

@Data
public class AlarmDataDetectDTO {
    /**
     * type = 1 常规 type=2 源 type=3 目标
     */
    String type;
    List<AlarmDataKvDTO> detectList;
}
