package com.crc.alarm.convert;

import com.crc.alarm.model.dto.AlarmWhiteExportDTO;
import com.crc.alarm.model.dto.AlarmWhiteSspExportDTO;
import com.crc.alarm.model.response.AlarmWhiteListResponse;
import com.crc.worker.TypeConversionWorker;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import org.mapstruct.Mappings;
import org.mapstruct.factory.Mappers;

import java.util.List;

/**
 * @Author shufengfeng
 * @Description 告警白名单请求转换类
 * @DateTime 2021/8/31 16:54
 */
@Mapper(uses = {TypeConversionWorker.class})
public interface AlarmWhiteConvert {
    AlarmWhiteConvert INSTANCE = Mappers.getMapper(AlarmWhiteConvert.class);

    /**
     * 转换导出对象
     * @param list
     * @return
     */
    List<AlarmWhiteExportDTO> convert(List<AlarmWhiteListResponse> list);

    /**
     * 转换导出对象
     * @param source
     * @return
     */
    @Mappings({
            @Mapping(target="effectDate", expression = "java(com.crc.alarm.utils.AlarmWhiteUtils.getEffectDate(source))"),
            @Mapping(target="effectTime", expression = "java(com.crc.alarm.utils.AlarmWhiteUtils.getEffectTime(source))"),
            @Mapping(target="destTypeName", expression = "java(com.crc.alarm.model.enums.AlarmWhiteListDestTypeEnum.getNameByValue(source.getDestType()))"),
            @Mapping(target="businessTermName", expression = "java(com.crc.alarm.model.enums.AlarmWhiteListBusinessTermEnum.getNameByValue(source.getBusinessTerm()))"),
            @Mapping(target="reportReasonName", expression = "java(com.crc.alarm.model.enums.AlarmWhiteListReportReasonEnum.getNameByValue(source.getReportReason()))"),
            @Mapping(target="approveStatusName", expression = "java(com.crc.alarm.utils.AlarmWhiteUtils.getApproveStatus(source.getApproveStatus()))"),

            @Mapping(target="reportDeptName", expression = "java(com.crc.alarm.utils.AlarmWhiteUtils.getReportUnitName(source.getReportDeptNodeId()))"),
            @Mapping(target="isGlobal", expression = "java(com.crc.alarm.utils.AlarmWhiteUtils.getIsGlobal(source.getIsGlobal()))"),
            @Mapping(target="isEnable", expression = "java(com.crc.alarm.utils.AlarmWhiteUtils.getIsEnable(source.getIsEnable()))")
            /*@Mapping(target="approveStatusName", expression = "java(com.crc.alarm.model.enums.AlarmWhiteUtils.getNameByValue(source.getApproveStatus()))"),
            @Mapping(target="approveStatusName", expression = "java(com.crc.alarm.model.enums.AlarmWhiteUtils.getNameByValue(source.getApproveStatus()))"),
            @Mapping(target="approveStatusName", expression = "java(com.crc.alarm.model.enums.AlarmWhiteUtils.getNameByValue(source.getApproveStatus()))"),*/
    })
    AlarmWhiteExportDTO convert(AlarmWhiteListResponse source);

    /**
     * 转换导出对象
     * @param list
     * @return
     */
    List<AlarmWhiteSspExportDTO> convertToSsp(List<AlarmWhiteListResponse> list);



    /**
     * 转换导出对象
     * @param source
     * @return
     */
    @Mappings({
            @Mapping(target="effectDate", expression = "java(com.crc.alarm.utils.AlarmWhiteUtils.getEffectDate(source))"),
            @Mapping(target="effectTime", expression = "java(com.crc.alarm.utils.AlarmWhiteUtils.getEffectTime(source))"),
            @Mapping(target="destTypeName", expression = "java(com.crc.alarm.model.enums.AlarmWhiteListDestTypeEnum.getNameByValue(source.getDestType()))"),
            @Mapping(target="businessTermName", expression = "java(com.crc.alarm.model.enums.AlarmWhiteListBusinessTermEnum.getNameByValue(source.getBusinessTerm()))"),
            @Mapping(target="isGlobal", expression = "java(com.crc.alarm.utils.AlarmWhiteUtils.convertIsGlobalName(source.getIsGlobal()))"),
            @Mapping(target="isEnable", expression = "java(com.crc.alarm.utils.AlarmWhiteUtils.convertIsEnableName(source.getIsEnable()))"),
            @Mapping(target="reportReasonName", expression = "java(com.crc.alarm.model.enums.AlarmWhiteListReportReasonEnum.getNameByValue(source.getReportReason()))"),
    })
    AlarmWhiteSspExportDTO convertToSsp(AlarmWhiteListResponse source);




}
