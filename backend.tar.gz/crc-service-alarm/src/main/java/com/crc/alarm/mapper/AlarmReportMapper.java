package com.crc.alarm.mapper;

import java.util.List;
import java.util.Map;

import com.crc.alarm.model.request.*;
import com.crc.alarm.model.response.*;
import com.crc.asset.model.request.CriticalSystemAlarmListReq;
import com.crc.common.model.response.DictStatResp;
import com.crc.common.utils.ip.TopConfigScreenAlarmSearch;
import org.apache.ibatis.annotations.Param;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.crc.alarm.model.domain.AlarmReport;
import com.crc.alarm.model.dto.AlarmDetailDTO;
import com.crc.alarm.model.dto.AlarmStateCountDTO;
import com.crc.alarm.model.dto.UpdateAlarmReportByBusinessKeyDTO;

/**
 * <p>
 * 威胁管理-告警主表(发起表) Mapper 接口
 * </p>
 *
 * @author shufengfeng
 * @since 2021-08-31
 */
public interface AlarmReportMapper extends BaseMapper<AlarmReport> {

    /**
     * 根据业务key进行更新
     *
     * @param dto
     * @return
     */
    int updateByBusinessKey(UpdateAlarmReportByBusinessKeyDTO dto);

    /**
     * 获取告警ID自增数字
     *
     * @return
     */
    Long getIncrementAlarmIdNumber();

    /**
     * 告警上报列表 title 统计 - 有查询条件
     *
     * @param req 入参
     * @return List
     */
    AlarmListTopStateResponse getAlarmReportQueryPageTitleState(AlarmSearchRequestOrganization req);

    /**
     * 告警上报列表 title 统计
     *
     * @param req 入参
     * @return List
     */
    AlarmListTopStateResponse getAlarmReportPageTitleState(AlarmSearchRequestOrganization req);

    /**
     * 告警上报列表 分页查询 只查询主键ID 加快分页
     *
     * @param req 入参
     * @return List
     */
    List<AlarmListResponse> getAlarmReportPage(AlarmSearchRequestOrganization req);

    /**
     * 告警上报导出列表
     *
     * @param req 入参
     * @return List
     */
    List<AlarmListResponse> getAlarmReportExportList(AlarmSearchRequestOrganization req);

    /**
     * 封堵策略查询告警标题列表
     *
     * @param req 入参
     * @return List
     */
    List<AlarmListSealResponse> getAlarmNameList(AlarmSearchRequestOrganization req);

    /**
     * 根据ids查询告警上报列表
     *
     * @param ids 主键集合
     * @return List
     */
    List<AlarmListResponse> getAlarmInfoByIds(@Param("ids") List<Long> ids);

    /**
     * 告警级别分组统计
     *
     * @param req 入参
     * @return List
     */
    List<DictStatResp> findGroupAlarmLevelCount(AlarmSearchRequestOrganization req);

    /**
     * 攻击手段分组统计
     *
     * @param req 入参
     * @return List
     */
    List<DictStatResp> findGroupAttackMeansCount(AlarmSearchRequestOrganization req);

    /**
     * 攻击结果分组统计
     *
     * @param req 入参
     * @return List
     */
    List<DictStatResp> findGroupAttackResultCount(AlarmSearchRequestOrganization req);

    /**
     * 作战周期时间范围分组统计
     *
     * @param req 入参
     * @return List
     */
    List<DictStatResp> findGroupFightPeriodTimeCount(AlarmSearchRequestOrganization req);

    /**
     * 根据ID获取业务数据
     *
     * @param id
     * @return
     */
    AlarmDetailDTO getDetail(Long id);

    /**
     * 根据业务key查询
     *
     * @param businessKey
     * @return
     */
    AlarmReport findByBusinessKey(String businessKey);

    /**
     * 根据业务key修改订单状态和节点名称
     *
     * @param orderStatus 工单状态
     * @param nodeName 节点名称
     * @param businessKeys 业务key
     * @return
     */
    int updateOrderStatusByBusinessKeys(String orderStatus, String nodeName, List<String> businessKeys);

    /**
     * 根据业务key查询
     *
     * @param businessKeys
     * @return
     */
    List<AlarmReport> findByBusinessKeys(List<String> businessKeys);

    /**
     * 获取告警来源字典
     *
     * @param organizationId 所属组织id
     * @return
     */
    List<String> getAlarmSourceDict(Long organizationId);

    /**
     * 根据IP和业务Key查询关联工单信息
     *
     * @param ip
     * @param businessKey
     * @return
     */
    List<AlarmIpCorrelationOrderResponse> getCorrelationOrdersByIp(String ip, String businessKey, Long organizationId);

    /**
     * 根据业务Key获取处置表单复核状态
     *
     * @param businessKey
     * @return
     */
    String isCheck(String businessKey);

    /**
     * 根据业务Key获取转办指派人
     *
     * @param businessKey
     * @return
     */
    String getHandleUserNameByBusinessKey(String businessKey);

    /**
     * 查询华润云告警工单数
     *
     * @param startTime 开始时间
     * @param endTime 结束时间
     * @param ips ip集合
     * @param domains 域名集合
     * @return 华润云告警工单数
     */
    Long getCrcCloudAlarmReportCount(@Param("startTime") String startTime, @Param("endTime") String endTime,
        @Param("ips") List<String> ips, @Param("domains") List<String> domains);

    /**
     * 查询华润云告警工单数
     *
     * @param startTime 开始时间
     * @param endTime 结束时间
     * @return 华润云告警工单数
     */
    Long getTerminalAlarmReportCount(@Param("startTime") String startTime, @Param("endTime") String endTime);

    /**
     * 查询终端被攻击次数
     *
     * @param startTime 开始时间
     * @param endTime 结束时间
     * @return 终端被攻击次数
     */
    Long getTerminalAttackCount(@Param("startTime") String startTime, @Param("endTime") String endTime);

    /**
     * 获取华润云告警工单信息
     *
     * @param startTime 开始时间
     * @param endTime 结束时间
     * @param ips ip集合
     * @param domains 域名集合
     * @return 华润云告警工单信息
     */
    List<AlarmReport> getCrcCloudAlarmReport(@Param("startTime") String startTime, @Param("endTime") String endTime,
        @Param("ips") List<String> ips, @Param("domains") List<String> domains);

    /**
     * 获取终端告警工单信息
     *
     * @param startTime 开始时间
     * @param endTime 结束时间
     * @return 终端告警工单信息
     */
    List<AlarmReport> getTerminalAlarmReport(@Param("startTime") String startTime, @Param("endTime") String endTime);

    /**
     * 获取华润云告警攻击结果信息
     *
     * @param startTime 开始时间
     * @param endTime 结束时间
     * @param dayType 是否按照日期分组
     * @param ips ip集合
     * @param domains 域名集合
     * @return 华润云告警攻击结果
     */
    List<Map<String, Object>> getCrcCloudAlarmReportAttackResult(@Param("startTime") String startTime,
        @Param("endTime") String endTime, @Param("dayType") Boolean dayType, @Param("ips") List<String> ips,
        @Param("domains") List<String> domains);

    /**
     * 获取终端告警攻击结果信息
     *
     * @param startTime 开始时间
     * @param endTime 结束时间
     * @param dayType 是否按照日期分组
     * @return 终端告警攻击结果
     */
    List<Map<String, Object>> getTerminalAlarmReportAttackResult(@Param("startTime") String startTime,
        @Param("endTime") String endTime, @Param("dayType") Boolean dayType);

    /**
     * 获取华润云告警攻击手段信息
     *
     * @param startTime 开始时间
     * @param endTime 结束时间
     * @param ips ip集合
     * @param domains 域名集合
     * @return 华润云告警攻击手段
     */
    List<Map<String, Object>> getCrcCloudAlarmReportAttackMeans(@Param("startTime") String startTime,
        @Param("endTime") String endTime, @Param("ips") List<String> ips, @Param("domains") List<String> domains);

    /**
     * 获取终端告警攻击手段信息
     *
     * @param startTime 开始时间
     * @param endTime 结束时间
     * @return 终端告警攻击手段
     */
    List<Map<String, Object>> getTerminalAlarmReportAttackMeans(@Param("startTime") String startTime,
        @Param("endTime") String endTime);

    /**
     * 获取华润云告警工单状态信息
     *
     * @param startTime 开始时间
     * @param endTime 结束时间
     * @param ips ip集合
     * @param domains 域名集合
     * @return 华润云告警工单状态信息
     */
    List<Map<String, Object>> getCrcCloudAlarmReportOrderStatus(@Param("startTime") String startTime,
        @Param("endTime") String endTime, @Param("ips") List<String> ips, @Param("domains") List<String> domains);

    /**
     * 获取终端告警工单状态信息
     *
     * @param startTime 开始时间
     * @param endTime 结束时间
     * @return 终端告警工单状态信息
     */
    List<Map<String, Object>> getTerminalAlarmReportOrderStatus(@Param("startTime") String startTime,
        @Param("endTime") String endTime);

    /**
     * 根据id查询告警信息
     *
     * @param id
     * @return
     */
    AlarmReport findById(Long id);

    /**
     * 根据告警id前缀查询最新的告警id
     *
     * @param prefix
     * @return
     */
    String findMaxAlarmIdByPrefix(String prefix);

    /**
     * 全局概况 告警数量
     *
     * @return
     */
    List<AlarmStateCountDTO> getAlarmSurveyCount();

    /**
     * 全局概况 告警数量
     * @return
     */
    AlarmStateCountResp getAlarmCount(@Param("deptIdList") List<Long> deptIdList);

    /**
     * 告警时间条件IP和工单号分组查询告警详情
     *
     * @param startTime
     * @param endTime
     * @return
     */
    List<AlarmStateCountDTO> getAlarmInfoByAlarmTime(@Param("startTime") String startTime,
        @Param("endTime") String endTime);

    /**
     * 告警时间条件IP查询告警
     *
     * @param startTime
     * @param endTime
     * @return
     */
    List<AlarmStateCountDTO> getAlarmIpByTime(@Param("startTime") String startTime, @Param("endTime") String endTime, @Param("deptIdList") List<String> deptIdList);

    /**
     * 通过告警时间查询受害ip
     *
     * @param startTime
     * @param endTime
     * @return
     */
    List<AlarmStateCountDTO> getVictAlarmByAlarmTime(@Param("startTime") String startTime,
                                                     @Param("endTime") String endTime, @Param("deptIdList") List<String> deptIdList);

    /**
     * 通过告警时间查询攻击p
     *
     * @param startTime
     * @param endTime
     * @return
     */
    List<AlarmStateCountDTO> getAttackAlarmByAlarmTime(@Param("startTime") String startTime,
                                                       @Param("endTime") String endTime, @Param("deptIdList") List<String> deptIdList);

    /**
     * 查询告警信息
     *
     * @param internalIp 内网ip
     * @param internetIp 外网ip
     * @return 告警信息
     */
    List<AlarmReport> selectAlarmReportByIp(@Param("internalIp") String internalIp,
        @Param("internetIp") String internetIp);

    /**
     * 批量修改告警信息
     *
     * @param reports 告警信息
     */
    void batchUpdateAlarmReport(List<AlarmReport> reports);

    /**
     * 获取攻击IP，被攻击IP在一段时间内的链路图
     *
     * @param request
     * @return
     */
    List<AlarmAttackLinkResponse> getAttckLinkList(AttackLinKRequest request);

    /**
     * 通过攻击IP获取受害Ip的排名
     *
     * @param request
     * @return
     */
    List<AttackLinkTimeLineChartResponse> getVictimizedIpTop(AttackLinkTimeLineChartRequest request);

    /**
     * 通过受害IP获取攻击Ip的排名
     *
     * @param request
     * @return
     */
    List<AttackLinkTimeLineChartResponse> getattackIpTop(AttackLinkTimeLineChartRequest request);

    /**
     * 最选中的最早的告警时间记录
     *
     * @param alarmReport
     * @return
     */
    AlarmReport getLastAlarmReport(AlarmReport alarmReport);

    /**
     * 查询告警里列表-重点关注问题
     *
     * @param alarmReport
     * @return
     */
    List<AlarmReport> getListAlarmReport(AlarmReport alarmReport);

    /**
     * 查询告警详情
     *
     * @param alarmReport
     * @return
     */
    AlarmReport getDetailAlarmReport(AlarmReport alarmReport);

    /**
     * 通过攻击ip和被攻击ip和攻击手段获取告警id
     *
     * @param attackIp
     * @param victimizedIp
     * @return
     */
    String getAlarmId(@Param("attackIp") String attackIp, @Param("victimizedIp") String victimizedIp,
        @Param("attackMeans") String attackMeans);

    /**
     * 获取告警信息
     *
     * @param request
     * @return
     */
    List<AlarmReport> findAlarm(FindAlarmInfoRequest request);

    /**
     * 根据IP和业务Key查询关联工单信息统计100条
     *
     * @param orderReq 入参
     * @return int
     */
    Integer getOrderAllCountByIp(@Param("req") AlarmIpCorrelationOrderReq orderReq);

    /**
     * 根据IP和业务Key查询关联工单信息
     *
     * @param orderReq
     * @return 关联工单列表
     */
    List<AlarmIpCorrelationOrderResponse> getOrderByIp(@Param("req") AlarmIpCorrelationOrderReq orderReq);

    /**
     * 根据IP和业务Key查询关联工单数量
     *
     * @param orderReq
     * @return
     */
    AlarmIpCorrelationOrderCountResponse getOrderCountByIp(@Param("req") AlarmIpCorrelationOrderReq orderReq);

    /**
     * 获取攻击IP，被攻击IP在一段时间内的链路图
     *
     * @param request
     * @return
     */
    List<AlarmAttackLinkResponse> getAttackLinkList(AttackLinkNewRequest request);

    /**
     * 得到ioc的数量
     *
     * @param attackIp ip
     * @return
     */
    int getRelationIocCount(@Param("attackIp") String attackIp);

    /**
     * 安全处理人统计告警状态报表
     *
     * @param alarmSearchRequest
     * @return
     */
    List<AlarmStatisticReportResponse>
        getOrderStatusReportBySecureProcessor(AlarmSearchRequestOrganization alarmSearchRequest);

    /**
     * 统计告警状态报表
     *
     * @param alarmSearchRequest
     * @return
     */
    List<AlarmStatisticReportResponse> getOrderStatusReport(AlarmSearchRequestOrganization alarmSearchRequest);

    /**
     * 安全处理人统计告警级别报表
     *
     * @param alarmSearchRequest
     * @return
     */
    List<AlarmStatisticReportResponse>
        getLevelReportBySecureProcessor(AlarmSearchRequestOrganization alarmSearchRequest);

    /**
     * 统计告警级别报表
     *
     * @param alarmSearchRequest
     * @return
     */
    List<AlarmStatisticReportResponse> getLevelReport(AlarmSearchRequestOrganization alarmSearchRequest);

    /**
     * 安全处理人统计攻击手段报表
     *
     * @param alarmSearchRequest
     * @return
     */
    List<AlarmStatisticReportResponse>
        getAttackMeanReportBySecureProcessor(AlarmSearchRequestOrganization alarmSearchRequest);

    /**
     * 统计攻击手段报表
     *
     * @param alarmSearchRequest
     * @return
     */
    List<AlarmStatisticReportResponse> getAttackMeanReport(AlarmSearchRequestOrganization alarmSearchRequest);

    /**
     * 安全处理人统计攻击手段报表
     *
     * @param alarmSearchRequest
     * @return
     */
    List<AlarmStatisticReportResponse>
        getAttackResultReportBySecureProcessor(AlarmSearchRequestOrganization alarmSearchRequest);

    /**
     * 统计攻击手段报表
     *
     * @param alarmSearchRequest
     * @return
     */
    List<AlarmStatisticReportResponse> getAttackResultReport(AlarmSearchRequestOrganization alarmSearchRequest);

    /**
     * 安全处理人统计告警发生趋势报表,按天统计
     *
     * @param alarmSearchRequest
     * @return
     */
    List<AlarmStatisticReportResponse>
        getAttackHappenDateReportBySecureProcessor(AlarmSearchRequestOrganization alarmSearchRequest);

    /**
     * 安全处理人统计告警发生趋势报表,按小时统计
     *
     * @param alarmSearchRequest
     * @return
     */
    List<AlarmStatisticReportResponse>
        getAttackHappenHourReportBySecureProcessor(AlarmSearchRequestOrganization alarmSearchRequest);

    /**
     * 统计告警发生趋势报表,按天统计
     *
     * @param alarmSearchRequest
     * @return
     */
    List<AlarmStatisticReportResponse> getAttackHappenDateReport(AlarmSearchRequestOrganization alarmSearchRequest);

    /**
     * 统计告警发生趋势报表,按小时统计
     *
     * @param alarmSearchRequest
     * @return
     */
    List<AlarmStatisticReportResponse> getAttackHappenHourReport(AlarmSearchRequestOrganization alarmSearchRequest);

    /**
     * 安全处理人统计告警发生趋势报表,按月统计
     *
     * @param alarmSearchRequest
     * @return
     */
    List<AlarmStatisticReportResponse>
        getAttackHappenMonthReportBySecureProcessor(AlarmSearchRequestOrganization alarmSearchRequest);

    /**
     * 统计告警发生趋势报表,按月统计
     *
     * @param alarmSearchRequest
     * @return
     */
    List<AlarmStatisticReportResponse> getAttackHappenMonthReport(AlarmSearchRequestOrganization alarmSearchRequest);

    List<AlarmReport> getFallList(AlarmSearchRequestOrganization q);

    List<IpPluggingAlarmRequest> getByAlarmName(IpPluggingAlarmRequest request);

    List<AlarmOriLogResponse> getEsConfigByAlarmId(List<String> alarmId);

    List<IpPluggingAlarmResponse> getIpSealList(IpPluggingAlarmRequest request);

    List<String> getStatusByIp(String ip);

    List<AlarmViewResponse> selectListByAttackMeans(@Param("date") String date, @Param("nowPeriod") String nowPeriod);

    /**
     * 获取TOP配置关联告警数据
     *
     * @param param 告警查询参数
     * @return
     */
    List<AlarmReport> getTopConfig(@Param("param") TopConfigScreenAlarmSearch param);

    /**
     * 获取topp配置关联告警列表
     *
     * @param param
     * @return
     */
    List<AlarmReport> getTopRelAlarm(@Param("param") TopConfigScreenAlarmSearch param);

    List<AlarmReport> selectListByCreateTime(@Param("attackDate") String attackDate);

    /**
     * 查询集权系统/等保系统的告警列表
     *
     * @param searchRequest 查询告警参数
     * @return 关联系统告警列表
     */
    List<CriticalSystemAlarmListResp> getCriticalSysAlarmList(@Param("param") CriticalSystemAlarmListReq searchRequest);

    /**
     * 风险残留告警列表
     *
     * @param searchRequest 参数
     * @return 告警列表
     */
    List<CriticalSystemAlarmListResp> getRiskCriticalSysAlarmList(@Param("param") CriticalSystemAlarmListReq searchRequest);

    /**
     * 互联网暴露资产告警列表
     *
     * @param searchRequest 参数
     * @return 告警列表
     */
    List<CriticalSystemAlarmListResp> getInternetCriticalSysAlarmList(@Param("param") CriticalSystemAlarmListReq searchRequest);

    /**
     * 集权系统/等保系统/公有云资产告警攻击结果分组
     *
     * @param searchRequest 参数
     * @return 集权系统/等保系统/公有云资产告警攻击结果分组
     */
    List<CriticalSystemCountResp> getCriticalSysCount(@Param("param") CriticalSystemAlarmListReq searchRequest);

    /**
     * 风险残留资产告警攻击结果分组
     *
     * @param searchRequest 参数
     * @return 风险残留资产告警攻击结果分组
     */
    List<CriticalSystemCountResp> getRiskCriticalCount(@Param("param") CriticalSystemAlarmListReq searchRequest);

    /**
     * 互联网资产告警攻击结果分组
     *
     * @param searchRequest 参数
     * @return 互联网资产告警攻击结果分组
     */
    List<CriticalSystemCountResp> getInternetCriticalCount(@Param("param") CriticalSystemAlarmListReq searchRequest);

    /**
     * 威胁管理-告警闭环管理-批量研判列表
     *
     * @param request 批量研判列表参数
     * @return
     */
    List<AlarmReport> getBatchJudgeList(@Param("param") AlarmBatchJudgeSearchReq request);

    /**
     * 个人工作台-攻击沦陷-确认失陷资产数
     * @return
     */
    Long getConfirmNun();


    /**
     * 个人工作台-攻击沦陷-可能失陷资产数
     * @return
     */
    Long getSuspectedNun();

    List<AlarmListResponse> getAlarmInfoByAlarmTimeAndDeptIds(@Param("startTime") String startTime, @Param("endTime") String endTime, @Param("deptIdList") List<String> deptIdList);
}
