package com.crc.alarm.model.constant;

/**
 * @Author: WANGLEI
 * @Date: 2021/11/15 14:33
 **/
public class AlarmConstant {
    //IP/URL校验正则
    public static final String IP_URL_REGEX = "^((((\\d{1,2}|1\\d\\d|2[0-4]\\d|25[0-5])\\.(\\d{1,2}|1\\d\\d|2[0-4]\\d|25[0-5])\\.(\\d{1,2}|1\\d\\d|2[0-4]\\d|25[0-5])\\.(\\d{1,2}|1\\d\\d|2[0-4]\\d|25[0-5]))|((http|ftp|https):\\/\\/[\\w\\-_]+(\\.[\\w\\-_]+)+([\\w\\-\\.,@?^=%&amp;:/~\\+#]*[\\w\\-\\@?^=%&amp;/~\\+#])?))(,))*(((\\d{1,2}|1\\d\\d|2[0-4]\\d|25[0-5])\\.(\\d{1,2}|1\\d\\d|2[0-4]\\d|25[0-5])\\.(\\d{1,2}|1\\d\\d|2[0-4]\\d|25[0-5])\\.(\\d{1,2}|1\\d\\d|2[0-4]\\d|25[0-5]))|((http|ftp|https):\\/\\/[\\w\\-_]+(\\.[\\w\\-_]+)+([\\w\\-\\.,@?^=%&amp;:/~\\+#]*[\\w\\-\\@?^=%&amp;/~\\+#])?))$";

    // 默认AI研判置信度
    public static final String DEFAULT_PRIORITY = "49.9";

    // 默认研判意见
    public static final String DEFAULT_SOLUTION = "人工研判（49.99%）";

    // 默认研判分数
    public static final String DEFAULT_SOLUTIONS = "{\"人工研判\":\"49.99%\"}";

    //告警上报成功提示信息
    public static final String ALARM_AUTO_REPORT_SUCCESS_MSG = "上报成功";

    // IP分类
    public static final String IP_TYPE = "ipType";

    // 网络区域
    public static final String AREA = "area";
    // 归属地
    public static final String COUNTRY = "country";
    // 内网IP
    public static final String INTERNAL_IP = "内网";
    // 外网IP
    public static final String OUT_NET_IP = "外网";
    // 未知IP
    public static final String UN_KNOW_IP = "未知";
    // 攻击IP
    public static final String ATTACK_IP = "attackIp";
    // 被攻击IP
    public static final String VICTIMIZED_IP = "victimizedIp";
    // 其他网络区域
    public static final String OTHER_AREA = "其他网络区域";
    // 其他标签
    public static final String OTHER_TAG = "其他标签";
    // 其他资产等级
    public static final String OTHER_ASSET_LEVEL = "其他资产等级";
    // 其他等保定级
    public static final String OTHER_EQUAL_PROTECTION_LEVEL = "其他等保定级";
    // 其他资产归属
    public static final String OTHER_AFFILI_ATION_DEPTNAME = "其他资产归属";

    /**
     * 攻击结果：0 企图
     */
    public static final String ATTACK_RESULT_0 = "0";

    /**
     * 攻击结果：1 疑似成功
     */
    public static final String ATTACK_RESULT_1 = "1";

    /**
     * 攻击结果：2 疑似失陷
     */
    public static final String ATTACK_RESULT_2 = "2";

    /**
     * 攻击结果：3 失败
     */
    public static final String ATTACK_RESULT_3 = "3";

    /**
     * 攻击结果：4 已失陷
     */
    public static final String ATTACK_RESULT_4 = "4";

    /**
     * 攻击结果：5 攻击成功
     */
    public static final String ATTACK_RESULT_5 = "5";

    /**
     * 意见
     */
    public static final String OPINION = "意见";

    // 全部加白申请
    public static final String ALL_ALARM_WHITE = "0";
    // 我申请的
    public static final String ALARM_WHITE_MY_APPLY = "1";
    // 我审核的
    public static final String ALARM_WHITE_MY_CHECK = "2";

    /**
     * 推送成功数据提醒
     */
    public static final String BATCH_INSERT_SUCCESS_MSG = "成功研判 %d 条数据，失败 %d 条";

    /**
     * 推送失败数据提醒
     */
    public static final String BATCH_INSERT_FAIL_MSG = "成功研判 %d 条数据，失败 %d 条，失败原因可能为工单已被操作导致状态改变";

    /**
     * 告警类型：常态化告警
     */
    public static final String ALARM_TYPE_NORMAL = "normal";

    /**
     * 告警类型：实战告警
     */
    public static final String ALARM_TYPE_COMBAT = "combat";
}
