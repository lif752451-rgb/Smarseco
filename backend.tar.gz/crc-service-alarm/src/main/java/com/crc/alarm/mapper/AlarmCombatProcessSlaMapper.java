package com.crc.alarm.mapper;

import java.util.List;

import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.crc.alarm.model.domain.AlarmCombatProcessSla;

/**
 * 实战告警闭环-流程节点耗时Mapper
 * 
 * @author zhangbing
 */
@Mapper
public interface AlarmCombatProcessSlaMapper extends BaseMapper<AlarmCombatProcessSla> {

    /**
     * 批量重置流程耗时
     *
     * @param alarmReportIds 实战告警闭环-主键ID
     */
    void batchRest(@Param("alarmReportIds") List<String> alarmReportIds);

    /**
     * 批量关闭计算耗时
     *
     * @param alarmReportIds 实战告警闭环-主键ID
     */
    void batchClose(@Param("alarmReportIds") List<String> alarmReportIds);
}