package com.crc.alarm.mapper;

import java.util.List;

import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.crc.alarm.model.domain.AlarmCombatReport;
import com.crc.alarm.model.dto.AlarmCombatReportDTO;
import com.crc.alarm.model.response.AlarmCombatReportResp;

/**
 * 实战告警工单查询Mapper
 *
 * @author zhangbing
 * @date 2023/04/20 16:31
 */
@Mapper
public interface AlarmCombatReportQueryMapper extends BaseMapper<AlarmCombatReport> {

    /**
     * 关联告警统计
     * 
     * @param combatDto 入参
     * @return int
     */
    Integer findRelationAlarmCount(@Param("combatDto") AlarmCombatReportDTO combatDto);

    /**
     * 关联告警查询列表
     * 
     * @param combatDto 入参
     * @return List
     */
    List<AlarmCombatReportResp> findRelationAlarmList(@Param("combatDto") AlarmCombatReportDTO combatDto);

    /**
     * 关联告警统计
     *
     * @param combatDto 入参
     * @return int
     */
    Integer findAsmRelationAlarmCount(@Param("combatDto") AlarmCombatReportDTO combatDto);

    /**
     * 关联告警查询列表
     * 
     * @param combatDto 入参
     * @return List
     */
    List<AlarmCombatReportResp> findAsmRelationAlarmPage(@Param("combatDto") AlarmCombatReportDTO combatDto);
}