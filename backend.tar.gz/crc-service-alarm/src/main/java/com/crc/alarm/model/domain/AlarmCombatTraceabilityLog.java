package com.crc.alarm.model.domain;

import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableField;
import com.baomidou.mybatisplus.annotation.TableId;
import com.baomidou.mybatisplus.annotation.TableName;
import com.crc.common.utils.StringUtils;
import com.crc.core.model.BasicPHEntity;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;
import lombok.EqualsAndHashCode;

/**
 * 实战告警闭环-溯源日志表
 *
 * @author zhangbing
 */
@ApiModel(value = "实战告警闭环-溯源日志表")
@Data
@EqualsAndHashCode(callSuper = true)
@TableName(value = "tb_alarm_combat_traceability_log")
public class AlarmCombatTraceabilityLog extends BasicPHEntity {

    /**
     * 主键ID
     */
    @TableId(value = "id", type = IdType.ASSIGN_UUID)
    @ApiModelProperty(value = "主键ID")
    private String id;

    /**
     * 业务ID
     */
    @TableField(value = "business_id")
    @ApiModelProperty(value = "业务ID")
    private String businessId;

    /**
     * 操作
     */
    @TableField(value = "`operation`")
    @ApiModelProperty(value = "操作")
    private String operation;

    /**
     * 内容
     */
    @TableField(value = "content")
    @ApiModelProperty(value = "内容")
    private String content;

    /**
     * 创建人姓名
     */
    @TableField(value = "create_by_label")
    @ApiModelProperty(value = "创建人姓名")
    private String createByLabel;

    public String getContent() {
        return StringUtils.convertSpecialChar(content);
    }

    public void setContent(String content) {
        this.content = StringUtils.convertSpecialChar(content);
    }
}