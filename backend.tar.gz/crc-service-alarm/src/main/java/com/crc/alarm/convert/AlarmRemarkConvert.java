package com.crc.alarm.convert;

import com.crc.alarm.model.domain.AlarmRemark;
import com.crc.alarm.model.request.*;
import com.crc.alarm.model.response.AlarmRemarkResponse;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import org.mapstruct.Mappings;
import org.mapstruct.factory.Mappers;
import java.util.List;

/**
 * @Author shufengfeng
 * @Description 告警-备注表请求转换类
 * @DateTime 2021/8/31 16:54
 */
@Mapper
public interface AlarmRemarkConvert {

    AlarmRemarkConvert INSTANCE = Mappers.getMapper(AlarmRemarkConvert.class);

    /**
     * 处置(转办)转换
     * @param request
     * @return
     */
    @Mappings({
            @Mapping(target="createTime", expression = "java(new java.util.Date())"),
            @Mapping(target="updateTime", expression = "java(new java.util.Date())"),
            @Mapping(target="content", source = "opinion"),
            @Mapping(target="createBy", source = "dealUserName"),
            @Mapping(target="createByLabel", source = "dealNickName")
    })
    AlarmRemark convert(AlarmFormDealConvertRequest request);

    /**
     * 处置(不转办)转换
     * @param request
     * @return
     */
    @Mappings({
            @Mapping(target="createTime", expression = "java(new java.util.Date())"),
            @Mapping(target="updateTime", expression = "java(new java.util.Date())"),
            @Mapping(target="content", source = "opinion"),
            @Mapping(target="createBy", source = "dealUserName"),
            @Mapping(target="createByLabel", source = "dealNickName")
    })
    AlarmRemark convert(AlarmFormDealRequest request);

    /**
     * 研判(误报)转换
     * @param request
     * @return
     */
    @Mappings({
            @Mapping(target="createTime", expression = "java(new java.util.Date())"),
            @Mapping(target="updateTime", expression = "java(new java.util.Date())"),
            @Mapping(target="content", source = "opinion"),
            @Mapping(target="createBy", source = "dealUserName"),
            @Mapping(target="createByLabel", source = "dealNickName")
    })
    AlarmRemark convert(AlarmFormMisinformationRequest request);

    /**
     * 研判(非误报)转换
     * @param request
     * @return
     */
    @Mappings({
            @Mapping(target="createTime", expression = "java(new java.util.Date())"),
            @Mapping(target="updateTime", expression = "java(new java.util.Date())"),
            @Mapping(target="content", source = "opinion"),
            @Mapping(target="createBy", source = "dealUserName"),
            @Mapping(target="createByLabel", source = "dealNickName")
    })
    AlarmRemark convert(AlarmFormJudgeRequest request);

    /**
     * 处置(驳回)转换
     * @param request
     * @return
     */
    @Mappings({
            @Mapping(target="createTime", expression = "java(new java.util.Date())"),
            @Mapping(target="updateTime", expression = "java(new java.util.Date())"),
            @Mapping(target="content", source = "opinion"),
            @Mapping(target="createBy", source = "dealUserName"),
            @Mapping(target="createByLabel", source = "dealNickName")
    })
    AlarmRemark convert(AlarmFormDealRejectRequest request);

    /**
     * 转办处置转换
     * @param request
     * @return
     */
    @Mappings({
            @Mapping(target="createTime", expression = "java(new java.util.Date())"),
            @Mapping(target="updateTime", expression = "java(new java.util.Date())"),
            @Mapping(target="content", source = "opinion"),
            @Mapping(target="createBy", source = "dealUserName"),
            @Mapping(target="createByLabel", source = "dealNickName")
    })
    AlarmRemark convert(AlarmFormConvertDealRequest request);
    /**
     * 转办处置驳回转换
     * @param request
     * @return
     */
    @Mappings({
            @Mapping(target="createTime", expression = "java(new java.util.Date())"),
            @Mapping(target="updateTime", expression = "java(new java.util.Date())"),
            @Mapping(target="content", source = "opinion"),
            @Mapping(target="createBy", source = "dealUserName"),
            @Mapping(target="createByLabel", source = "dealNickName")
    })
    AlarmRemark convert(AlarmFormConvertDealRejectRequest request);

    /**
     * 复核转换
     * @param request
     * @return
     */
    @Mappings({
            @Mapping(target="createTime", expression = "java(new java.util.Date())"),
            @Mapping(target="updateTime", expression = "java(new java.util.Date())"),
            @Mapping(target="content", source = "opinion"),
            @Mapping(target="createBy", source = "dealUserName"),
            @Mapping(target="createByLabel", source = "dealNickName")
    })
    AlarmRemark convert(AlarmFormCheckRequest request);

    /**
     * 审核转换
     * @param request
     * @return
     */
    @Mappings({
            @Mapping(target="createTime", expression = "java(new java.util.Date())"),
            @Mapping(target="updateTime", expression = "java(new java.util.Date())"),
            @Mapping(target="content", source = "opinion"),
            @Mapping(target="createBy", source = "dealUserName"),
            @Mapping(target="createByLabel", source = "dealNickName")
    })
    AlarmRemark convert(AlarmFormAuditRequest request);

    /**
     * 补充备注
     * @param remark
     * @return
     */
    @Mappings({
            @Mapping(source = "createTime" ,target="createTime" ,dateFormat = "yyyy-MM-dd HH:mm:ss")
    })
    AlarmRemarkResponse convertResponse(AlarmRemark remark);

    /**
     * 补充备注list转换
     * @param remarks
     * @return
     */
    List<AlarmRemarkResponse> convertResponses(List<AlarmRemark> remarks);
}

