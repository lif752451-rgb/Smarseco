package com.crc.alarm.customer;

import cn.hutool.core.collection.CollUtil;
import cn.hutool.core.date.DateUtil;
import cn.hutool.core.util.StrUtil;
import cn.hutool.http.HtmlUtil;
import com.alibaba.fastjson.JSONObject;
import com.crc.alarm.config.AlarmNoticeConfig;
import com.crc.alarm.model.domain.AlarmRecord;
import com.crc.alarm.model.dto.AlarmReportDTO;
import com.crc.alarm.model.enums.AlarmNodeEnum;
import com.crc.alarm.service.AlarmRecordService;
import com.crc.asset.model.domain.Asset;
import com.crc.asset.service.AssetQueryService;
import com.crc.asset.service.AssetService;
import com.crc.authentication.model.domain.SysDictData;
import com.crc.authentication.model.vo.SysUserVO;
import com.crc.authentication.services.SysDictDataService;
import com.crc.authentication.services.SysUserService;
import com.crc.authentication.utils.DictUtil;
import com.crc.common.constant.Constants;
import com.crc.common.model.WebsocketSendVo;
import com.crc.common.socket.WebSocket;
import com.crc.common.socket.WebsocketBusinessType;
import com.crc.common.utils.JsonUtils;
import com.crc.common.utils.StrFormatter;
import com.crc.common.utils.StringUtils;
import com.crc.common.utils.ip.IpUtils;
import com.crc.config.QywxMsgConfig;
import com.crc.core.dto.MailDTO;
import com.crc.core.dto.MsgSendDTO;
import com.crc.customer.EmailCustomer;
import com.crc.customer.RunWorkCustomer;
import com.crc.factory.MsgSendFactory;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.util.StopWatch;

import javax.annotation.Resource;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.stream.Collectors;

import static com.crc.alarm.model.constant.AlarmConstant.OPINION;
import static com.crc.common.constant.Constants.Symbol.COMMA;
import static com.crc.common.model.enums.DictTypeEnum.*;
import static com.crc.common.model.enums.DictValueEnum.ALARM_DETAIL_URL;
import static com.crc.common.model.enums.DictValueEnum.ALARM_FILE_WECOM;
import static com.crc.common.model.enums.DictValueEnum.ALARM_PROCESS;
import static com.crc.common.model.enums.DictValueEnum.ALARM_PROCESS_URL;
import static com.crc.common.model.enums.DictValueEnum.ALARM_PROCESS_WECOM;
import static com.crc.common.socket.WebsocketGroup.ALARM_ADD_VIEW_SOCKET_GROUP;
import static com.crc.qywx.QyweixinSendTypeEnum.TEXT;

/**
 * @Author shufengfeng
 * @Description 告警通知消费者
 * @DateTime 2021/9/17 16:29
 */
@Slf4j
@Component
public class AlarmNoticeCustomer {

    @Autowired
    private SysUserService sysUserService;

    @Autowired
    private AlarmNoticeConfig alarmNoticeConfig;

    @Autowired
    private EmailCustomer emailCustomer;

    @Autowired
    private RunWorkCustomer runWorkCustomer;

    @Autowired
    private SysDictDataService sysDictDataService;

    @Autowired
    private QywxMsgConfig qywxMsgConfig;

    @Autowired
    private AssetService assetService;

    @Autowired
    private AlarmRecordService alarmRecordService;

    @Resource
    private AssetQueryService assetQueryService;

    public static void main(String[] args) {
        List<String> list = new ArrayList<>();
        String collect = list.stream().filter(StringUtils::isNotBlank).collect(Collectors
            .joining(Constants.Symbol.ZH_COMMA, Constants.Symbol.EN_LEFT_BRACKET, Constants.Symbol.EN_RIGHT_BRACKET));
        System.out.println(collect);
    }

    public void tack(AlarmReportDTO alarmReportDTO) {
        StopWatch stopWatch = new StopWatch("AlarmNoticeCustomer");
        stopWatch.start();
        log.info("准备开始发送通知参数:{}", alarmReportDTO);
        List<SysUserVO> sysUserList = sysUserService
            .findHasEmailByUserNames(Arrays.asList(alarmReportDTO.getCurrentDealUser().split(COMMA)));
        if (CollUtil.isNotEmpty(sysUserList)) {
            // runWorkCustomer.task(sysUserList.stream().map(SysUserVO::getUserName).collect(Collectors.toList()),
            // convertToRWorkText(alarmReportDTO));
            emailCustomer.task(convertToMailDTO(alarmReportDTO, sysUserList));
            // 异步发送流程websocket
            this.sendAlarmProcessWebSocket(alarmReportDTO, sysUserList);
        }
        // 异步发送企业微信通知
        this.sendVxNotice(alarmReportDTO);
        stopWatch.stop();
        log.info("发送通知耗时:{}", stopWatch.prettyPrint());
    }

    private void sendVxNotice(AlarmReportDTO alarmReportDTO) {
        // 发送企业微信字典开关
        String sendVxSwitch = null;
        if (AlarmNodeEnum.COMPLETE.getNodeName().equals(alarmReportDTO.getNodeName())) {
            // 闭环节点字典
            sendVxSwitch = DictUtil.getDictValue(LOOP_WECOM_NOTICE.getName(), ALARM_FILE_WECOM.getDictValue());
        } else {
            // 流程节点字典
            sendVxSwitch = DictUtil.getDictValue(LOOP_WECOM_NOTICE.getName(), ALARM_PROCESS_WECOM.getDictValue());
        }
        if (Constants.STR_VALUE_ONE.equals(sendVxSwitch)) {
            List<String> toUser = null;
            if (AlarmNodeEnum.COMPLETE.getNodeName().equals(alarmReportDTO.getNodeName())) {
                List<AlarmRecord> alarmRecordList = alarmRecordService
                    .findAlarmRecordByBusinessKey(Collections.singletonList(alarmReportDTO.getBusinessKey()));
                if (CollUtil.isEmpty(alarmRecordList)) {
                    return;
                }
                toUser = alarmRecordList.stream().filter(r -> StrUtil.isNotEmpty(r.getDealUserName()))
                    .map(AlarmRecord::getDealUserName).collect(Collectors.toList());
            } else {
                toUser = Arrays.asList(alarmReportDTO.getCurrentDealUser().split(COMMA));
            }
            if (CollUtil.isNotEmpty(toUser)) {
                MsgSendDTO msgSendDTO =
                    MsgSendDTO.builder().type(TEXT.getType()).to(toUser).msg(convertToVxMsg(alarmReportDTO)).build();
                MsgSendFactory.batchSend(Collections.singletonList(msgSendDTO), ALARM_PROCESS.getDictValue());
            }
        } else {
            log.info("告警发送企业微信开关未打开");
        }
    }

    /**
     * 构造微信消息
     *
     * @param alarmReport
     * @return
     */
    private String convertToVxMsg(AlarmReportDTO alarmReport) {
        // 跳转url
        String jumpUrl = DictUtil.getJumpUrl(ALARM_WECOM_URL.getName(), ALARM_PROCESS_URL.getDictValue());
        Map<String, String> map = new HashMap<>(5);
        // 工单状态
        String workOrderState = AlarmNodeEnum.CHECK.getNodeName().equals(alarmReport.getNodeName())
            ? alarmReport.getNodeName() : alarmReport.getOrderStatus();
        map.put("workOrderState", StringUtils.nvlString(workOrderState));
        // 告警ID
        map.put("alarmId", StringUtils.nvlString(alarmReport.getAlarmId()));
        // 跳转链接
        map.put("url", StringUtils.nvlString(jumpUrl));
        // 告警标题
        map.put("title", StringUtils.nvlString(alarmReport.getTitle()));
        // 告警级别
        map.put("levelLabel", StringUtils.nvlString(alarmReport.getLevelLabel()));
        // 攻击结果
        map.put("attackResultLabel", StringUtils.nvlString(alarmReport.getAttackResultLabel()));
        // 攻击IP描述
        map.put("attackIpInfo", StringUtils.nvlString(buildIpInfo(alarmReport.getAttackIp())));
        // 受害IP描述
        map.put("victimizedIpDesc", StringUtils.nvlString(buildIpInfo(alarmReport.getVictimizedIp())));
        // 告警时间
        map.put("alarmTime", StringUtils.nvlString(DateUtil.formatDateTime(alarmReport.getAlarmTime())));
        // 告警详情
        map.put("detail", HtmlUtil.cleanHtmlTag(StringUtils.nvlString(alarmReport.getDetail())));
        List<AlarmRecord> alarmRecordList =
            alarmRecordService.findAlarmRecordByBusinessKey(Collections.singletonList(alarmReport.getBusinessKey()));
        if (CollUtil.isEmpty(alarmRecordList)) {
            return StrFormatter.mailFormat(qywxMsgConfig.getAlarmNodeMsg(), map);
        }
        // 告警记录信息
        String recordInfo = alarmRecordList.stream()
            .filter(t -> !AlarmNodeEnum.CREATE.getNodeName().equals(t.getNodeName())).map(record -> {
                StringBuffer sb = new StringBuffer();
                return sb.append(StringUtils.nvlString(record.getNodeName()))
                    .append(OPINION + Constants.Symbol.COLON + Constants.Symbol.BLANK)
                    .append(StringUtils.nvlString(record.getOpinion())).append(Constants.Symbol.ZH_DOT);
            }).collect(Collectors.joining(Constants.Symbol.LINE_FEED));
        map.put("recordInfo", StringUtils.nvlString(recordInfo));
        return StrFormatter.mailFormat(qywxMsgConfig.getAlarmNodeMsg(), map);
    }

    /**
     * 获取IP对应的详细信息
     *
     * @param ips 多个IP用英文逗号隔开
     * @return
     */
    private String buildIpInfo(String ips) {
        List<Asset> ipInfoList = assetService.getIpInfo(ips);
        if (CollUtil.isEmpty(ipInfoList)) {
            return null;
        }
        return ipInfoList.stream().map(asset -> {
            StringBuffer sb = new StringBuffer();
            sb.append(StringUtils.nvlString(asset.getInternalIp())).append(Constants.Symbol.BLANK);
            List<String> ipInfoMsgList = Arrays
                .asList(StringUtils.nvlString(asset.getAffiliationDeptName()),
                    StringUtils.nvlString(asset.getAreaName()), StringUtils.nvlString(asset.getInstance()),
                    StringUtils.nvlString(asset.getAssetUser()))
                .stream().filter(StringUtils::isNotBlank).collect(Collectors.toList());
            if (CollUtil.isNotEmpty(ipInfoMsgList)) {
                String ipInfoStr = ipInfoMsgList.stream().collect(Collectors.joining(Constants.Symbol.ZH_COMMA,
                    Constants.Symbol.EN_LEFT_BRACKET, Constants.Symbol.EN_RIGHT_BRACKET));
                return sb.append(Constants.Symbol.BLANK).append(ipInfoStr);
            } else {
                return sb;
            }
        }).collect(Collectors.joining(Constants.Symbol.ZH_COMMA));
    }

    private MailDTO convertToMailDTO(AlarmReportDTO alarmReport, List<SysUserVO> sysUserVOList) {
        List<String> emailList = sysUserVOList.stream().map(SysUserVO::getEmail).collect(Collectors.toList());
        return MailDTO.builder().text(convertToMailText(alarmReport))
            .to(CollUtil.join(emailList, COMMA)).subject(alarmNoticeConfig.getSubject()).build();
    }

    /**
     * 发送webSocket
     *
     * @param alarmReport 告警信息
     * @param sysUserVOList 发送用户集合
     */
    private void sendAlarmProcessWebSocket(AlarmReportDTO alarmReport, List<SysUserVO> sysUserVOList) {
        log.info("告警发送WebSocket消息");
        WebsocketSendVo vo = new WebsocketSendVo();
        vo.setBusinessId(alarmReport.getAlarmId());
        vo.setBusinessType(WebsocketBusinessType.ALARM_PROCESS);
        vo.setMessage(alarmNoticeConfig.getSubject());
        String dictLabel = DictUtil.getJumpUrl(ALARM_WECOM_URL.getName(), ALARM_DETAIL_URL.getDictValue());
        if (StrUtil.isNotEmpty(dictLabel)) {
            String url = StrUtil.format(dictLabel, alarmReport.getId(), alarmReport.getOrganizationId());
            vo.setUrl(url);
        } else {
            log.info("告警详情跳转URL字典未设置");
        }
        List<Long> userIdList = sysUserVOList.stream().map(SysUserVO::getUserId).filter(Objects::nonNull).distinct()
            .collect(Collectors.toList());
        log.info("告警发送WebSocket消息内容{}，接收用户{}", vo.toString(), userIdList.toString());
        WebSocket.batchSendMessageByUser(userIdList, vo);
    }

    private String convertToRWorkText(AlarmReportDTO alarmReport) {
        // 跳转url
        String jumpUrl = StrUtil.format(DictUtil.getJumpUrl(MAIL_URL.getName(), "alarmNoticeEmailUrl"),
            alarmReport.getId(), alarmReport.getOrganizationId());
        return StrUtil.format(alarmNoticeConfig.getMsg(),
            // 工单状态
            AlarmNodeEnum.CHECK.getNodeName().equals(alarmReport.getNodeName()) ? alarmReport.getNodeName()
                : alarmReport.getOrderStatus(),
            // 告警ID
            alarmReport.getAlarmId(),
            // 跳转url
            jumpUrl);
    }

    private String convertToMailText(AlarmReportDTO alarmReport) {
        // 默认邮件下文提示
        String defaultEmailContent = getDefaultEmailContent();
        // 跳转url
        String jumpUrl = StrUtil.format(DictUtil.getJumpUrl(MAIL_URL.getName(), "alarmNoticeEmailUrl"),
            alarmReport.getId(), alarmReport.getOrganizationId());
        return StrUtil.format(alarmNoticeConfig.getText(),
            // 工单状态
            AlarmNodeEnum.CHECK.getNodeName().equals(alarmReport.getNodeName()) ? alarmReport.getNodeName()
                : alarmReport.getOrderStatus(),
            // 告警ID
            alarmReport.getAlarmId(),
            // 跳转url
            jumpUrl, jumpUrl,
            // 标题
            alarmReport.getTitle(),
            // 告警级别
            alarmReport.getLevelLabel(),
            // 攻击结果
            alarmReport.getAttackResultLabel(),
            // 攻击IP
            IpUtils.splitIp(alarmReport.getAttackIp(), alarmReport.getAttackAscription(), Constants.Symbol.SPACE),
            // 受害IP/URL
            IpUtils.splitIp(alarmReport.getVictimizedIp(), alarmReport.getVictimizedAscription(),
                Constants.Symbol.SPACE),
            // 告警时间
            DateUtil.formatDateTime(alarmReport.getAlarmTime()),
            // 告警详情
            alarmReport.getDetail(),
            // 邮件默认下文提示
            defaultEmailContent);
    }

    private String getDefaultEmailContent() {
        List<SysDictData> defaultEmailContents = sysDictDataService.selectDictDataByType("default_email_content");
        String defaultEmailContent = null;
        if (CollUtil.isNotEmpty(defaultEmailContents)) {
            List<String> list =
                defaultEmailContents.stream().map(SysDictData::getDictLabel).collect(Collectors.toList());
            defaultEmailContent = list.get(0);
        } else {
            defaultEmailContent = StringUtils.EMPTY;
        }
        return defaultEmailContent;
    }


    /**
     * 发送webSocket
     *
     * @param alarmReport 告警信息
     */
    public void sendAddAlarmViewWebSocket(AlarmReportDTO alarmReport) {
        log.info("新增告警发送大屏显示WebSocket消息");
        JSONObject json = JsonUtils.createJson();
        json.put("id", alarmReport.getId());
        json.put("attackIp", alarmReport.getAttackIp());
        List<String> ips = IpUtils.analysisIp(alarmReport.getVictimizedIp());
        List<Asset> ipAssetList = assetQueryService.findInternalIpAsset(ips);
        String victimizedAsset =
            ips.stream().map(ip -> ipAssetList.stream().filter(asset -> ip.equals(asset.getInternalIp())).findFirst()
                .map(Asset::getInstance).orElse(ip)).collect(Collectors.joining(COMMA));
        json.put("victimizedAsset", victimizedAsset);
        json.put("alarmTime", DateUtil.formatDateTime(alarmReport.getAlarmTime()));
        List<SysDictData> dictList = DictUtil.getDict(ATTACK_TYPE.getName());
        String alarmTypeLabel = dictList.stream().filter(dict -> dict.getDictValue().equals(alarmReport.getAttackMeans()))
            .findFirst().map(SysDictData::getRemark).orElse(null);
        json.put("alarmTypeLabel", alarmTypeLabel);
        json.put("level", alarmReport.getLevel());
        json.put("levelLabel", alarmReport.getLevelLabel());
        WebsocketSendVo vo = new WebsocketSendVo();
        vo.setBusinessId(alarmReport.getAlarmId());
        vo.setBusinessType(WebsocketBusinessType.ADD_ALARM_VIEW);
        vo.setMessage(JsonUtils.toJSONString(json));
        WebSocket.sendGroupMessage(ALARM_ADD_VIEW_SOCKET_GROUP, vo);
    }

}
