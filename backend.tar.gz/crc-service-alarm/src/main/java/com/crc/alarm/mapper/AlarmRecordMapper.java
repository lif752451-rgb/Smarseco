package com.crc.alarm.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.crc.alarm.model.domain.AlarmRecord;
import com.crc.alarm.model.dto.AlarmPriorityDTO;
import com.crc.alarm.model.response.AlarmProgressChartResponse;
import com.crc.alarm.model.response.AlarmRecordResponse;
import org.apache.ibatis.annotations.Param;

import java.util.List;

/**
 * <p>
 * 威胁管理-告警流程记录表 Mapper 接口
 * </p>
 *
 * @author shufengfeng
 * @since 2021-08-31
 */
public interface AlarmRecordMapper extends BaseMapper<AlarmRecord> {

    /**
     * 根据业务key查询记录信息
     *
     * @param businessKeys
     * @return
     */
    List<AlarmRecord> findByBusinessKeys(List<String> businessKeys);

    /**
     * 根据业务key查询操作记录信息
     *
     * @param businessKey
     * @return
     */
    List<AlarmRecordResponse> getFormInfo(String businessKey);

    /**
     * 批量插入
     *
     * @param alarmRecordList
     * @return
     */
    int batchInsert(List<AlarmRecord> alarmRecordList);

    /**
     * 获取流程图
     *
     * @param businessKey
     * @return
     */
    List<AlarmProgressChartResponse> getProgressChart(String businessKey);

    /**
     * 根据业务key修改流程标记
     *
     * @param businessKey 业务key
     * @param nodeName    节点
     * @param updateUser  更新人
     * @return
     */
    int updateDisableFlowFlagByBusinessKey(String businessKey, String nodeName, String updateUser);

    /**
     * 获取选择的安全接口人
     *
     * @param businessKey 业务key
     * @return 安全接口人
     */
    String selectChooseSecurityUser(String businessKey);
}