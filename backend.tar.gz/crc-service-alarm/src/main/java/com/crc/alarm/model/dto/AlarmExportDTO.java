package com.crc.alarm.model.dto;

import com.alibaba.excel.annotation.ExcelProperty;
import com.alibaba.excel.annotation.write.style.ColumnWidth;
import com.alibaba.excel.annotation.write.style.HeadRowHeight;
import lombok.Data;

/**
 * @author WANGLEI
 * @DateTime 2021/9/1 14:55
 */
@Data
@HeadRowHeight(20)
@ColumnWidth(18)
public class AlarmExportDTO {

    /**
     * 告警id
     */
    @ExcelProperty("告警ID")
    private String alarmId;

    /**
     * 标题
     */
    @ExcelProperty("标题")
    private String title;

    /**
     * 攻击ip
     */
    @ExcelProperty("攻击IP")
    private String attackIp;

    /**
     * 攻击源资产
     */
    @ExcelProperty("攻击源资产")
    private String attackAssetName;

    /**
     * 攻击IP归属信息
     */
    @ExcelProperty("攻击IP归属")
    private String attackAscription;

    /**
     * 受害ip/url
     */
    @ExcelProperty("受害IP/URL")
    private String victimizedIp;

    /**
     * 受害资产
     */
    @ExcelProperty("受害资产")
    private String victimizedAssetName;

    /**
     * 受害IP归属信息
     */
    @ExcelProperty("受害IP/URL归属")
    private String victimizedAscription;

    /**
     * 告警详情
     */
    @ExcelProperty("告警详情")
    private String detail;

    /**
     * 告警级别名称
     */
    @ExcelProperty("告警级别")
    private String levelLabel;

    /**
     * 攻击结果名称
     */
    @ExcelProperty("攻击结果")
    private String attackResultLabel;

    /**
     * 攻击手段名称
     */
    @ExcelProperty("攻击手段")
    private String attackMeansLabel;

    /**
     * 行为性质(0 正常 1非正常)
     */
    @ExcelProperty(value = "行为性质")
    private String behaviorNature;

    /**
     * 告警来源
     */
    @ExcelProperty("告警来源")
    private String alarmSource;

    /**
     * 攻击次数
     */
    @ExcelProperty("攻击次数")
    private String attackCount;

    /**
     * AI研判值
     */
    @ExcelProperty("AI研判值")
    private String aiCheck;

    /**
     * 提交人姓名
     */
    @ExcelProperty("提交人")
    private String commitNickName;

    /**
     * 告警时间
     */
    @ExcelProperty("告警时间")
    private String alarmTime;

    /**
     * 创建时间
     */
    @ExcelProperty("提交时间")
    private String createTime;

    /**
     * 责任部门
     */
    @ExcelProperty("责任部门")
    private String dutyDeptName;

    /**
     * 当前处理人姓名
     */
    @ExcelProperty("当前处理人")
    private String currentDealUserNickName;

    /**
     * 处置耗时
     */
    @ExcelProperty("处置耗时")
    private String dealTimeStr;

    /**
     * 总耗时
     */
    @ExcelProperty("总耗时")
    private String archiveTimeStr;

    /**
     * 工单状态
     */
    @ExcelProperty("工单状态")
    private String orderStatus;

    /**
     * 操作日志
     */
    @ExcelProperty("操作日志")
    private String operationLog;
}