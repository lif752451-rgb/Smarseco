package com.crc.alarm.model.domain;

import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableField;
import com.baomidou.mybatisplus.annotation.TableId;
import com.baomidou.mybatisplus.annotation.TableName;
import com.crc.core.model.BasicPHEntity;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;
import lombok.EqualsAndHashCode;

/**
 * 实战告警闭环-告警表单
 */
@ApiModel(value = "实战告警闭环-告警表单")
@Data
@EqualsAndHashCode(callSuper = true)
@TableName(value = "tb_alarm_combat_form")
public class AlarmCombatForm extends BasicPHEntity {
    /**
     * 主键
     */
    @TableId(value = "id", type = IdType.ASSIGN_UUID)
    @ApiModelProperty(value = "主键")
    private String id;

    /**
     * 实战告警闭环主表ID
     */
    @TableField(value = "alarm_report_id")
    @ApiModelProperty(value = "实战告警闭环主表ID")
    private String alarmReportId;

    /**
     * 是否误报(0 不是 1是)
     */
    @TableField(value = "misinformation")
    @ApiModelProperty(value = "是否误报(0 不是 1是)")
    private Integer misinformation;

    /**
     * 处置结果(pass 通过 reject 驳回)
     */
    @TableField(value = "deal_result")
    @ApiModelProperty(value = "处置结果(pass 通过 reject 驳回)")
    private String dealResult;

    /**
     * 是否封堵IP(1 是 0 否)
     */
    @TableField(value = "whether_block_ip")
    @ApiModelProperty(value = "是否封堵IP(1 是 0 否)")
    private String whetherBlockIp;


    /**
     * 是否转办(1 是 0 否)
     */
    @TableField(value = "whether_forward")
    @ApiModelProperty(value = "是否转办(1 是 0 否)")
    private String whetherForward;
    /**
     * 后续跟进结果(pass 通过 reject 驳回)
     */
    @TableField(value = "follow_up_result")
    @ApiModelProperty(value = "后续跟进结果(pass 通过 reject 驳回)")
    private String followUpResult;

    /**
     * 是否跟进(1 是 0 否)
     */
    @TableField(value = "whether_follow_up")
    @ApiModelProperty(value = "是否跟进(1 是 0 否)")
    private String whetherFollowUp;

    /**
     * 审核结果(pass 通过 fail 不通过)
     */
    @TableField(value = "audit_result")
    @ApiModelProperty(value = "审核结果(pass 通过 fail 不通过)")
    private String auditResult;

    /**
     * 研判意见/处置措施/跟进意见/审核意见/驳回原因
     */
    @TableField(value = "opinion")
    @ApiModelProperty(value = "研判意见/处置措施/跟进意见/审核意见/驳回原因")
    private String opinion;

    /**
     * 行为性质(0 正常 1 异常)
     */
    @TableField(value = "behavior_nature")
    @ApiModelProperty(value = "行为性质(0 正常 1 异常)")
    private Integer behaviorNature;

    /**
     * 已失陷IP
     */
    @TableField(value = "fallen_ip")
    @ApiModelProperty(value = "已失陷IP")
    private String fallenIp;

    /**
     * 攻击结果
     */
    @TableField(value = "attack_result")
    @ApiModelProperty(value = "攻击结果")
    private String attackResult;

    /**
     * 告警级别
     */
    @TableField(value = "`level`")
    @ApiModelProperty(value = "告警级别")
    private String level;

    /**
     * 创建人姓名
     */
    @TableField(value = "create_by_label")
    @ApiModelProperty(value = "创建人姓名")
    private String createByLabel;
}