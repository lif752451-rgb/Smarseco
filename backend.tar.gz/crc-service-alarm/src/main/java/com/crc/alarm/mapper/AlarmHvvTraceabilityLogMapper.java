package com.crc.alarm.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.crc.alarm.model.domain.AlarmHvvTraceabilityLog;
import org.apache.ibatis.annotations.Mapper;

/**
 * 告警闭环-溯源日志表Mapper
 */
@Mapper
public interface AlarmHvvTraceabilityLogMapper extends BaseMapper<AlarmHvvTraceabilityLog> {
}