package com.crc.alarm.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.crc.alarm.model.domain.AlarmRefOrilog;
import com.crc.alarm.model.request.IpPluggingAlarmRequest;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;

import java.util.List;

/**
 * 告警关联原始日志Mapper
 *
 * @author zhangbing
 */
@Mapper
public interface AlarmRefOrilogMapper extends BaseMapper<AlarmRefOrilog> {

    /**
     * 查询多引擎推送告警ID
     *
     * @param oriIds es索引ID集合
     * @return List
     */
    List<String> findAlarmRelOriLogAlarmId(@Param("oriIds") List<String> oriIds);

    List<IpPluggingAlarmRequest> getOriLogByModelId(IpPluggingAlarmRequest request);
}
