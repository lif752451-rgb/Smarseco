package com.crc.alarm.model.domain;

import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableField;
import com.baomidou.mybatisplus.annotation.TableId;
import com.baomidou.mybatisplus.annotation.TableName;

import java.util.Date;

import com.fasterxml.jackson.annotation.JsonFormat;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.experimental.Accessors;

/**
 * <p>
 * 威胁管理-告警流程记录表
 * </p>
 *
 * @author shufengfeng
 * @since 2021-08-31
 */
@Data
@EqualsAndHashCode(callSuper = false)
@Accessors(chain = true)
@TableName("tb_alarm_record")
public class AlarmRecord {

    /**
     * 主键
     */
    @TableId(value = "id", type = IdType.AUTO)
    private Long id;

    /**
     * 业务key
     */
    private String businessKey;

    /**
     * 告警表单id
     */
    private Long alarmFormId;

    /**
     * 节点名称
     */
    private String nodeName;

    /**
     * 处理人
     */
    private String dealUserName;

    /**
     * 处理人姓名
     */
    private String dealNickName;

    /**
     * 创建时间
     */
    @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss", timezone = "GMT+8")
    private Date createTime;

    /**
     * 流程标记(0可用 1不可用)
     */
    private Integer flowFlag;

    /**
     * 下一个节点名称
     */
    private String nextNodeName;

    /**
     * 下一个节点处理人
     */
    private String nextDealUserName;

    /**
     * 意见
     */
    private String opinion;

    /**
     * 更新时间
     */
    private Date updateTime;

    /**
     * 更新人
     */
    private String updateUser;

    /**
     * 操作
     */
    private String operation;

    /**
     * 知识库告警处置反馈指南知识ID
     */
    @TableField(value = "knowledge_alarm_feedback_id")
    private String knowledgeAlarmFeedbackId;
}
