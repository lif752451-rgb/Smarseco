package com.crc.alarm.model.dto;

import lombok.Data;

/**
 * @Author shufengfeng
 * @Description 用户按钮权限DTO
 * @DateTime 2021/8/30 15:44
 */
@Data
public class AlarmBtnAuthDTO {

    /**
     * 批量关闭按钮权限  false没有 true为有
     */
    private Boolean batchClose;
}
