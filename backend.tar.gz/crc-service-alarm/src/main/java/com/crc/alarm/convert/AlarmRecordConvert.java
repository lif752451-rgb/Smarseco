package com.crc.alarm.convert;

import com.crc.alarm.model.domain.AlarmRecord;
import com.crc.alarm.model.request.*;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import org.mapstruct.Mappings;
import org.mapstruct.factory.Mappers;

/**
 * @Author shufengfeng
 * @Description 告警流程记录请求转换类
 * @DateTime 2021/8/31 16:54
 */
@Mapper
public interface AlarmRecordConvert {

    AlarmRecordConvert INSTANCE = Mappers.getMapper(AlarmRecordConvert.class);

    /**
     * 研判请求转换
     * @param request
     * @return
     */
    @Mappings({
            @Mapping(target="createTime", expression = "java(new java.util.Date())"),
            @Mapping(target="flowFlag", expression = "java(com.crc.common.model.enums.StatusEnum.AVAILABLE.getValue())"),
            @Mapping(target="nextNodeName", expression = "java(com.crc.alarm.model.enums.AlarmNodeEnum.DEAL.getNodeName())"),
            @Mapping(target="nextDealUserName", source = "securityUserName"),
    })
    AlarmRecord convert(AlarmFormJudgeRequest request);
    /**
     * 研判误报请求转换
     * @param request
     * @return
     */
    @Mappings({
            @Mapping(target="createTime", expression = "java(new java.util.Date())"),
            @Mapping(target="flowFlag", expression = "java(com.crc.common.model.enums.StatusEnum.AVAILABLE.getValue())"),
            @Mapping(target="nodeName", expression = "java(com.crc.common.model.enums.SwitchEnum.CLOSE.getDesc())"),
    })
    AlarmRecord convert(AlarmFormMisinformationRequest request);

    /**
     * 处置(不转办)转换
     * @param request
     * @return
     */
    @Mappings({
            @Mapping(target="createTime", expression = "java(new java.util.Date())"),
            @Mapping(target="flowFlag", expression = "java(com.crc.common.model.enums.StatusEnum.AVAILABLE.getValue())"),
            @Mapping(target="nextNodeName", expression = "java(com.crc.alarm.model.enums.AlarmNodeEnum.AUDIT.getNodeName())"),
    })
    AlarmRecord convert(AlarmFormDealRequest request);

    /**
     * 处置(转办)转换
     * @param request
     * @return
     */
    @Mappings({
            @Mapping(target="createTime", expression = "java(new java.util.Date())"),
            @Mapping(target="flowFlag", expression = "java(com.crc.common.model.enums.StatusEnum.AVAILABLE.getValue())"),
            @Mapping(target="nextNodeName", expression = "java(com.crc.alarm.model.enums.AlarmNodeEnum.CONVERT_DEAL.getNodeName())"),
            @Mapping(target="nextDealUserName", source = "handleUserName"),

    })
    AlarmRecord convert(AlarmFormDealConvertRequest request);

    /**
     * 处置(驳回)转换
     * @param request
     * @return
     */
    @Mappings({
            @Mapping(target="createTime", expression = "java(new java.util.Date())"),
            @Mapping(target="flowFlag", expression = "java(com.crc.common.model.enums.StatusEnum.DISABLE.getValue())"),
            @Mapping(target="nextNodeName", expression = "java(com.crc.alarm.model.enums.AlarmNodeEnum.JUDGE.getNodeName())"),
    })
    AlarmRecord convert(AlarmFormDealRejectRequest request);


    /**
     * 转办处置转换
     * @param request
     * @return
     */
    @Mappings({
            @Mapping(target="createTime", expression = "java(new java.util.Date())"),
            @Mapping(target="flowFlag", expression = "java(com.crc.common.model.enums.StatusEnum.AVAILABLE.getValue())"),
    })
    AlarmRecord convert(AlarmFormConvertDealRequest request);

    /**
     * 转办处置(驳回)转换
     * @param request
     * @return
     */
    @Mappings({
            @Mapping(target="createTime", expression = "java(new java.util.Date())"),
            @Mapping(target="flowFlag", expression = "java(com.crc.common.model.enums.StatusEnum.DISABLE.getValue())"),
            @Mapping(target="nextNodeName", expression = "java(com.crc.alarm.model.enums.AlarmNodeEnum.DEAL.getNodeName())"),
    })
    AlarmRecord convert(AlarmFormConvertDealRejectRequest request);

    /**
     * 复核转换
     * @param request
     * @return
     */
    @Mappings({
            @Mapping(target="createTime", expression = "java(new java.util.Date())"),
            @Mapping(target="flowFlag", expression = "java(" +
                    " com.crc.common.model.enums.ResultEnum.PASS.equals(request.getCheckResult())  " +
                    " ? com.crc.common.model.enums.StatusEnum.AVAILABLE.getValue()" +
                    " : com.crc.common.model.enums.StatusEnum.DISABLE.getValue())"),
            @Mapping(target="nextNodeName", expression = "java(" +
                    " com.crc.common.model.enums.ResultEnum.PASS.equals(request.getCheckResult())  " +
                    " ? com.crc.alarm.model.enums.AlarmNodeEnum.AUDIT.getNodeName()" +
                    " : com.crc.alarm.model.enums.AlarmNodeEnum.CONVERT_DEAL.getNodeName())"),
    })
    AlarmRecord convert(AlarmFormCheckRequest request);

    /**
     * 审核转换
     * @param request
     * @return
     */
    @Mappings({
            @Mapping(target="createTime", expression = "java(new java.util.Date())"),
            @Mapping(target="flowFlag", expression = "java(" +
                    " com.crc.common.model.enums.ResultEnum.PASS.equals(request.getAuditResult())  " +
                    " ? com.crc.common.model.enums.StatusEnum.AVAILABLE.getValue()" +
                    " : com.crc.common.model.enums.StatusEnum.DISABLE.getValue())"),
    })
    AlarmRecord convert(AlarmFormAuditRequest request);

    /**
     * 批量研判转换
     * @param request
     * @return
     */
    @Mappings({
            @Mapping(target="createTime", expression = "java(new java.util.Date())"),
            @Mapping(target="flowFlag", expression = "java(com.crc.common.model.enums.StatusEnum.AVAILABLE.getValue())"),
            @Mapping(target="nextNodeName", expression = "java(request.getMisinformation() == 0 ? com.crc.alarm.model.enums.AlarmNodeEnum.DEAL.getNodeName() : com.crc.alarm.model.enums.AlarmNodeEnum.NO_DEAL.getNodeName())"),
            @Mapping(target="nextDealUserName", expression = "java(request.getMisinformation() == 0 ? request.getSecurityUserName() : null)"),
    })
    AlarmRecord convert(AlarmBatchJudgeRequest request);
}
