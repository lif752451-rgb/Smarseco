package com.crc.alarm.model.domain;

import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableId;
import com.baomidou.mybatisplus.annotation.TableName;
import java.util.Date;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.experimental.Accessors;

/**
 * <p>
 * 告警-备注表单
 * </p>
 *
 * @author shufengfeng
 * @since 2021-08-31
 */
@Data
@EqualsAndHashCode(callSuper = false)
@Accessors(chain = true)
@TableName("tb_alarm_remark")
public class AlarmRemark {
    /**
     * 主键
     */
    @TableId(value = "id", type = IdType.AUTO)
    private Long id;

    /**
     * 业务标识
     */
    private String businessKey;

    /**
     * 备注内容
     */
    private String content;

    /**
     * 附件
     */
    private String fileJson;

    /**
     * 创建人
     */
    private String createBy;

    /**
     * 创建人
     */
    private String createByLabel;

    /**
     * 创建时间
     */
    private Date createTime;

    /**
     * 修改人
     */
    private String updateBy;

    /**
     * 修改时间
     */
    private Date updateTime;


}
