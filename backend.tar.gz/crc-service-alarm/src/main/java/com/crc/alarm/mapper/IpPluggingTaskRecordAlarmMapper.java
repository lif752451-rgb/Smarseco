package com.crc.alarm.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.crc.alarm.model.domain.IpPluggingTaskRecordAlarm;
import org.apache.ibatis.annotations.Mapper;

/**
 * @author jixiangqi
 * @date 2023/1/17
 */
@Mapper
public interface IpPluggingTaskRecordAlarmMapper extends BaseMapper<IpPluggingTaskRecordAlarm> {

    void updateData(IpPluggingTaskRecordAlarm record);
}