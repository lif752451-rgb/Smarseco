package com.crc.alarm.model.constant;

import io.swagger.annotations.ApiModel;

/**
 * 告警白名单来源类型
 *
 * @author zhangbing
 * @since 2023/4/13 18:25
 */
@ApiModel(value = "告警白名单来源类型")
public interface WhiteSourceTypeConstants {

    /**
     * ssp管理新增
     */
    String STP_ADD = "stpAdd";

    /**
     * 常态化告警
     */
    String NORM_ALARM = "normAlarm";

    /**
     * 实战告警
     */
    String COMBAT_ALARM = "combatAlarm";
}
