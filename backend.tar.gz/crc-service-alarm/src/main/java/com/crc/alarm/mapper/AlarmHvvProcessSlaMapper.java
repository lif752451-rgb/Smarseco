package com.crc.alarm.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.crc.alarm.model.domain.AlarmHvvProcessSla;
import com.crc.alarm.model.response.AlarmHvvMessageResponse;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;

import java.util.List;

/**
 * 告警闭环-流程节点耗时表Mapper
 */
@Mapper
public interface AlarmHvvProcessSlaMapper extends BaseMapper<AlarmHvvProcessSla> {

    /**
     * 查询当前节点超时数据
     *
     * @param pageSize      最大数据量
     * @param judgeOvertime 研判超时阈值(s)
     * @param dealOvertime  处置超时阈值(s)
     * @return list
     */
    List<AlarmHvvMessageResponse> findAlarmHvvOvertime(@Param("pageSize") Integer pageSize,
                                                       @Param("judgeOvertime") Long judgeOvertime,
                                                       @Param("dealOvertime") Long dealOvertime);

    void batchClose(@Param("alarmReportIds") List<String> alarmReportIds);
}