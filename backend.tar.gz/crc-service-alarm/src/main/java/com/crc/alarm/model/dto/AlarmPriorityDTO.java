package com.crc.alarm.model.dto;

import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

/**
 * 描述：告警研判度DTO
 * 
 * @author fuzhuangzhi
 */
@Data
public class AlarmPriorityDTO {
    /**
     * AI研判置信度
     */
    @ApiModelProperty(value = "AI研判置信度")
    private String priority;

    /**
     * 研判意见
     */
    @ApiModelProperty(value = "研判意见")
    private String solution;

    /**
     * 研判分数
     */
    @ApiModelProperty(value = "研判分数")
    private String solutions;

    /**
     * AI研判置信度
     */
    @ApiModelProperty(value = "AI研判置信度")
    private String aiCheck;

    /**
     * 告警模型ID
     */
    @ApiModelProperty(value = "告警模型ID")
    private String busModel;
}
