package com.crc.alarm.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.crc.alarm.model.domain.AlarmSecurityHandlerGrouping;
import org.apache.ibatis.annotations.Mapper;

/**
 * 告警安全处理人分组Mapper
 */
@Mapper
public interface AlarmSecurityHandlerGroupingMapper extends BaseMapper<AlarmSecurityHandlerGrouping> {
}
