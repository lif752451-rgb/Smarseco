package com.crc.alarm.convert;

import java.util.List;

import org.mapstruct.Mapper;
import org.mapstruct.factory.Mappers;

import com.crc.alarm.model.domain.AlarmCombatTraceabilityLog;
import com.crc.alarm.model.response.AlarmCombatTraceabilityLogResp;

/**
 * 实战告警闭环-溯源日志转换
 *
 * @author zhangbing
 */
@Mapper
public interface AlarmCombatTraceabilityLogConvert {

    AlarmCombatTraceabilityLogConvert INSTANCE = Mappers.getMapper(AlarmCombatTraceabilityLogConvert.class);

    /**
     * 数据转换
     *
     * @param log AlarmCombatTraceabilityLog
     * @return AlarmCombatTraceabilityLogResp
     */
    AlarmCombatTraceabilityLogResp convert(AlarmCombatTraceabilityLog log);

    /**
     * 数据转换
     *
     * @param logList AlarmCombatTraceabilityLog
     * @return AlarmCombatTraceabilityLogResp
     */
    List<AlarmCombatTraceabilityLogResp> convert(List<AlarmCombatTraceabilityLog> logList);
}
