package com.crc.alarm.model.dto;

import lombok.Data;
import lombok.ToString;

/**
 * 告警关联原始日志DTO
 */
@Data
@ToString
public class AlarmAssociatedRelationLogDTO {

    /**
     * 攻击ip
     */
    private String attackIp;

    /**
     * 受害ip/url
     */
    private String victimizedIp;
}
