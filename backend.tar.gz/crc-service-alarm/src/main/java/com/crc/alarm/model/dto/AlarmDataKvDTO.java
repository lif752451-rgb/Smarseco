package com.crc.alarm.model.dto;

import lombok.Data;

@Data
public class AlarmDataKvDTO {
    String label;
    String value;
}
