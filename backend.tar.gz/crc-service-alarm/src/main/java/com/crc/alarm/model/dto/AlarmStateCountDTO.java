package com.crc.alarm.model.dto;

import lombok.Data;

/**
 * 描述：全局概况 告警状态数量
 *
 * @Author: fuzhuangzhi
 * @Date: 2021/12/29 19:39
 */
@Data
public class AlarmStateCountDTO {

    /**
     * ip
     */
    private String ip;

    /**
     * 工单状态
     */
    private String orderStatus;

    /**
     * 告警等级
     */
    private String levelLabel;

    /**
     * 攻击结果
     */
    private String attackResultLabel;

    /**
     * 告警时间
     */
    private String alarmTime;

    /**
     * 攻击手段
     */
    private String attackMeansLabel;

    /**
     * 实例
     */
    private String instance;

    /**
     * 一级单位
     */
    private String firstUnit;

    /**
     * 二级单位
     */
    private String  secondUnit;

    /**
     * 告警数量
     */
    private String alarmCount;

    /**
     * 序号
     */
    private String no;

}
