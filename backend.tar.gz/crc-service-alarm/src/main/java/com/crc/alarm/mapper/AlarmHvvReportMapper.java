package com.crc.alarm.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.crc.alarm.model.domain.AlarmHvvReport;
import com.crc.alarm.model.dto.AlarmHvvReportDTO;
import com.crc.alarm.model.request.AlarmHvvReportPermissionRequest;
import com.crc.alarm.model.response.AlarmHvvExportResponse;
import com.crc.alarm.model.response.AlarmHvvReportResponse;
import com.crc.alarm.model.response.AlarmHvvTopStateResponse;
import com.crc.alarm.model.response.AlarmIpCorrelationOrderResponse;
import com.crc.alarm.model.response.AlarmProgressChartResponse;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;

import java.util.List;

/**
 * 告警闭环-告警信息主表Mapper
 */
@Mapper
public interface AlarmHvvReportMapper extends BaseMapper<AlarmHvvReport> {

    /**
     * 查询详情
     *
     * @param id 主键ID
     * @return 告警闭环(hvv)-列表显示
     */
    AlarmHvvReportResponse findById(@Param("id") Long id);

    /**
     * 查询已审批节点(取节点最后审批人)
     *
     * @param businessKey 业务key
     * @return list
     */
    List<AlarmProgressChartResponse> findAlarmProgress(@Param("businessKey") String businessKey);

    /**
     * 根据IP和业务Key查询关联工单信息
     *
     * @param ip          ip地址
     * @param businessKey 业务key
     * @return list
     */
    List<AlarmIpCorrelationOrderResponse> getCorrelationOrdersByIp(@Param("ip") String ip, @Param("businessKey") String businessKey);

    /**
     * 节点数据统计
     *
     * @param dr 告警闭环(hvv)-列表数据权限
     * @return AlarmHvvTopStateResponse
     */
    AlarmHvvTopStateResponse findAlarmHvvNodeNameCount(@Param("dr") AlarmHvvReportPermissionRequest dr);

    /**
     * 列表导出
     *
     * @param hvvDto 告警闭环-告警信息主表(hvv)
     * @param dr     告警闭环(hvv)-列表数据权限
     * @return List<告警闭环-告警信息主表 ( hvv )>
     */
    List<AlarmHvvExportResponse> findAlarmHvvReportExport(@Param("hvvDto") AlarmHvvReportDTO hvvDto,
                                                          @Param("dr") AlarmHvvReportPermissionRequest dr);



    /**
     * 列表导出没有操作日志字段
     *
     * @param hvvDto 告警闭环-告警信息主表(hvv)
     * @param dr     告警闭环(hvv)-列表数据权限
     * @return List<告警闭环-告警信息主表 ( hvv )>
     */
    List<AlarmHvvExportResponse> findAlarmHvvReportExportNoLog(@Param("hvvDto") AlarmHvvReportDTO hvvDto,
                                                          @Param("dr") AlarmHvvReportPermissionRequest dr);

    /**
     * 查询列表
     *
     * @param hvvDto 告警闭环-告警信息主表(hvv)
     * @param dr     告警闭环(hvv)-列表数据权限
     * @return List<告警闭环-告警信息主表 ( hvv )>
     */
    List<AlarmHvvReportResponse> findAlarmHvvReportPage(@Param("hvvDto") AlarmHvvReportDTO hvvDto,
                                                        @Param("dr") AlarmHvvReportPermissionRequest dr);

    /**
     * 查最新的告警ID
     *
     * @param prefix 告警ID前缀
     * @return String
     */
    int findMaxAlarmIdByPrefix(String prefix);
}