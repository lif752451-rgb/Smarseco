package com.crc.alarm.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.crc.alarm.model.domain.AlarmHvvRemark;
import org.apache.ibatis.annotations.Mapper;

/**
 * 告警闭环-补充备注表Mapper
 */
@Mapper
public interface AlarmHvvRemarkMapper extends BaseMapper<AlarmHvvRemark> {
}