package com.crc.alarm.mapper;

import org.apache.ibatis.annotations.Mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.crc.alarm.model.domain.AlarmCombatTraceabilityLog;

@Mapper
public interface AlarmCombatTraceabilityLogMapper extends BaseMapper<AlarmCombatTraceabilityLog> {
}