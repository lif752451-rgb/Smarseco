package com.crc.alarm.convert;

import org.mapstruct.Mapper;
import org.mapstruct.factory.Mappers;

import com.crc.alarm.model.request.AlarmCombatBatchJudgeRequest;
import com.crc.alarm.model.request.AlarmCombatFormReq;

/**
 * @author fuzhuangzhi
 * @title AlarmCombatFormConvert
 * @date 2023/7/13 15:41
 * @description TODO
 */
@Mapper
public interface AlarmCombatFormConvert {

    AlarmCombatFormConvert INSTANCE = Mappers.getMapper(AlarmCombatFormConvert.class);

    /**
     * 批量研判转换
     * @param judgeReq 研判表单请求
     * @return 研判form
     */
    AlarmCombatFormReq convert(AlarmCombatBatchJudgeRequest judgeReq);
}
