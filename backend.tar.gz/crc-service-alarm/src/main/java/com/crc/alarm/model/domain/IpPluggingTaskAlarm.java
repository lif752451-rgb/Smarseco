package com.crc.alarm.model.domain;

import java.util.Date;

import com.baomidou.mybatisplus.annotation.TableField;
import com.baomidou.mybatisplus.annotation.TableLogic;
import com.crc.core.model.BasicEntity;
import com.fasterxml.jackson.annotation.JsonFormat;

import lombok.Data;
import lombok.EqualsAndHashCode;

/**
 * IP封堵任务
 * 
 * @author jixiangqi
 * @date 2023/1/16
 */
@EqualsAndHashCode(callSuper = true)
@Data
public class IpPluggingTaskAlarm extends BasicEntity {

    /**
     * 封堵IP
     */
    @TableField("ip")
    private String ip;

    /**
     * 执行设备
     */
    @TableField("exec_device")
    private String execDevice;

    /**
     * 截至时间
     */
    @TableField("deadline_time")
    // @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss",timezone="GMT+8")
    private String deadlineTime;

    /**
     * 封堵原因
     */
    @TableField("reason")
    private String reason;

    /**
     * 创建人姓名
     */
    @TableField("create_by_label")
    private String createByLabel;

    /**
     * 封堵次数
     */
    @TableField("exec_count")
    private Long execCount;

    /**
     * IP归属地
     */
    @TableField("ip_home")
    private String ipHome;

    /**
     * 安全设备IP
     */
    @TableField("device_ip")
    private String deviceIp;

    /**
     * 策略组
     */
    @TableField("strategy_name")
    private String strategyName;

    /**
     * 状态 1 已解封 2 已封堵
     */
    @TableField("status")
    private int status;

    /**
     * 最近封堵时间
     */
    @TableField("plugging_time")
    @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss", timezone = "GMT+8")
    private Date pluggingTime;

    @TableField("unseal_time")
    @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss", timezone = "GMT+8")
    private Date unsealTime;

    @TableField(exist = false)
    private String statusLabel;

    /**
     * 删除标识(0 未删除 1 已删除)
     */
    @TableLogic
    @TableField(value = "del_flag")
    private String delFlag;
}
