package com.crc.alarm.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.crc.alarm.model.domain.AlarmHvvAtt;
import org.apache.ibatis.annotations.Mapper;

/**
 * 告警闭环(hvv)-公共附件表
 */
@Mapper
public interface AlarmHvvAttMapper extends BaseMapper<AlarmHvvAtt> {
}