package com.crc.alarm.convert;

import java.util.List;
import java.util.Map;

import com.crc.alarm.model.response.CriticalSystemAlarmListResp;
import org.mapstruct.Context;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import org.mapstruct.Mappings;
import org.mapstruct.factory.Mappers;

import com.crc.alarm.model.domain.AlarmCombatReport;
import com.crc.alarm.model.request.AlarmCombatReportReq;
import com.crc.alarm.model.response.AlarmCombatReportExportResp;
import com.crc.alarm.model.response.AlarmCombatReportResp;
import com.crc.worker.TypeConversionWorker;

/**
 * 数据转换
 * 
 * @author zhangbing
 */
@Mapper(uses = {TypeConversionWorker.class})
public interface AlarmCombatReportConvert {

    AlarmCombatReportConvert INSTANCE = Mappers.getMapper(AlarmCombatReportConvert.class);

    /**
     * 数据转换
     *
     * @param report AlarmCombatReport
     * @return AlarmCombatReportReq
     */
    AlarmCombatReportReq convert(AlarmCombatReport report);

    /**
     * 数据转换
     *
     * @param report AlarmCombatReport
     * @return AlarmCombatReportReq
     */
    AlarmCombatReportReq convert(AlarmCombatReportResp report);

    /**
     * 导出数据转换
     *
     * @param resp AlarmCombatReportResp
     * @param logMap Map
     * @return AlarmCombatReportExportResp
     */
    @Mappings({@Mapping(target = "createTime", source = "resp.createTime", qualifiedByName = "doFormatDateTime"),
        @Mapping(target = "alarmTime", source = "resp.alarmTime", qualifiedByName = "doFormatDateTime"),
        @Mapping(target = "attackAscription",
            expression = "java(com.crc.alarm.utils.IpUtils.splitIp(resp.getAttackIp(),resp.getAttackAscription(),com.crc.common.constant.Constants.Symbol.LINE_FEED).replace(com.crc.common.constant.Constants.Symbol.SPACE,com.crc.common.constant.Constants.Symbol.STR_EMPTY))"),
        @Mapping(target = "victimizedAscription",
            expression = "java(com.crc.alarm.utils.IpUtils.splitIp(resp.getVictimizedIp(),resp.getVictimizedAscription(),com.crc.common.constant.Constants.Symbol.LINE_FEED).replace(com.crc.common.constant.Constants.Symbol.SPACE,com.crc.common.constant.Constants.Symbol.STR_EMPTY))"),
        @Mapping(target = "behaviorNature",
            expression = "java(com.crc.alarm.model.enums.AlarmBehaviorNatureEnum.getEnum(resp.getBehaviorNature()))"),
        @Mapping(target = "judgeTimeConsuming",
            expression = "java(com.crc.common.utils.DateUtils.getUsedTime(resp.getJudgeTimeConsuming()))"),
        @Mapping(target = "dealTimeConsuming",
            expression = "java(com.crc.common.utils.DateUtils.getUsedTime(resp.getDealTimeConsuming()))"),
        @Mapping(target = "archiveTimeConsuming",
            expression = "java(com.crc.common.utils.DateUtils.getUsedTime(resp.getArchiveTimeConsuming()))"),
        @Mapping(target = "orderStatusLabel",
            expression = "java(com.crc.alarm.model.enums.AlarmCombatNodeEnum.getEnumLabelByNodeKey(resp.getOrderStatus()))"),
        @Mapping(target = "isTurnRisk",
            expression = "java(com.crc.common.model.enums.StatusEnum.getYesOrNoDescByValue(resp.getIsTurnRisk()))"),
        @Mapping(target = "applyGroupAssist",
            expression = "java(com.crc.common.model.enums.StatusEnum.getYesOrNoDescByValue(resp.getApplyGroupAssist()))"),
        @Mapping(target = "reportGroupProcess",
            expression = "java(com.crc.alarm.utils.AlarmCombatUtils.getReportGroupProcess(resp.getReportGroupProcess()))"),
        @Mapping(target = "groupIssueProcess",
            expression = "java(com.crc.alarm.utils.AlarmCombatUtils.getGroupIssueProcess(resp.getGroupIssueProcess(), resp.getIssueCount()))"),
        @Mapping(target = "operationLog", expression = "java(logMap.getOrDefault(resp.getId(), \"\"))"),})
    AlarmCombatReportExportResp convertExport(AlarmCombatReportResp resp, @Context Map<String, String> logMap);

    /**
     * 实战告警转换关键系统告警
     *
     * @param dataList 实战告警数据
     * @return 关键系统告警信息
     */
    List<CriticalSystemAlarmListResp> convertToCritical(List<AlarmCombatReport> dataList);

    @Mappings({
            @Mapping(target = "alarmTime", source = "alarmTime", dateFormat = "yyyy-MM-dd HH:mm:ss"),
            @Mapping(target = "createTime", source = "createTime", dateFormat = "yyyy-MM-dd HH:mm:ss"),})
    CriticalSystemAlarmListResp convertToCritical(AlarmCombatReport data);

    List<AlarmCombatReportResp> convertToJudgeList(List<AlarmCombatReport> alarmCombatReports);
}
