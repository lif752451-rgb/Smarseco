package com.crc.alarm.model.domain;

import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableField;
import com.baomidou.mybatisplus.annotation.TableId;
import com.baomidou.mybatisplus.annotation.TableName;
import com.crc.core.model.BasicPHEntity;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;
import lombok.EqualsAndHashCode;

import java.util.Date;

/**
 * 告警闭环-流程节点耗时表(hvv)
 */
@Data
@EqualsAndHashCode(callSuper = true)
@ApiModel(value = "告警闭环-流程节点耗时表(hvv)")
@TableName(value = "tb_alarm_hvv_process_sla")
public class AlarmHvvProcessSla extends BasicPHEntity {

    private static final long serialVersionUID = 1L;

    /**
     * 唯一主键
     */
    @ApiModelProperty(value = "主键")
    @TableId(value = "id", type = IdType.AUTO)
    private Long id;

    /**
     * 告警闭环(hvv)主表ID
     */
    @TableField(value = "alarm_report_id")
    @ApiModelProperty(value = "告警闭环(hvv)主表ID")
    private Long alarmReportId;

    /**
     * 最后一次研判时间
     */
    @TableField(value = "judge_time")
    @ApiModelProperty(value = "最后一次研判时间")
    private Date judgeTime;

    /**
     * 研判耗时(ms)
     */
    @TableField(value = "judge_time_consuming")
    @ApiModelProperty(value = "研判耗时(s)")
    private Long judgeTimeConsuming;

    /**
     * 研判超时消息发送标识(0:未发送;1:已发送;)
     */
    @TableField(value = "judge_timeout_msg")
    @ApiModelProperty(value = "研判超时消息发送标识(0:未发送;1:已发送;)")
    private Long judgeTimeoutMsg;

    /**
     * 最后一次处置时间
     */
    @TableField(value = "deal_time")
    @ApiModelProperty(value = "最后一次处置时间")
    private Date dealTime;

    /**
     * 处置耗时(ms)
     */
    @TableField(value = "deal_time_consuming")
    @ApiModelProperty(value = "处置耗时(s)")
    private Long dealTimeConsuming;

    /**
     * 处置超时消息发送标识(0:未发送;1:已发送;)
     */
    @TableField(value = "deal_timeout_msg")
    @ApiModelProperty(value = "处置超时消息发送标识(0:未发送;1:已发送;)")
    private Long dealTimeoutMsg;

    /**
     * 最后一次后续跟进时间
     */
    @TableField(value = "follow_up_time")
    @ApiModelProperty(value = "最后一次后续跟进时间")
    private Date followUpTime;

    /**
     * 后续跟进耗时(ms)
     */
    @TableField(value = "follow_up_time_consuming")
    @ApiModelProperty(value = "后续跟进耗时(s)")
    private Long followUpTimeConsuming;

    /**
     * 最后一次审核时间
     */
    @TableField(value = "audit_time")
    @ApiModelProperty(value = "最后一次审核时间")
    private Date auditTime;

    /**
     * 审核耗时(ms)
     */
    @TableField(value = "audit_time_consuming")
    @ApiModelProperty(value = "审核耗时(s)")
    private Long auditTimeConsuming;

    /**
     * 最后一次归档时间
     */
    @TableField(value = "archive_time")
    @ApiModelProperty(value = "最后一次归档时间")
    private Date archiveTime;

    /**
     * 归档耗时(ms)
     */
    @TableField(value = "archive_time_consuming")
    @ApiModelProperty(value = "归档耗时(s)")
    private Long archiveTimeConsuming;
}