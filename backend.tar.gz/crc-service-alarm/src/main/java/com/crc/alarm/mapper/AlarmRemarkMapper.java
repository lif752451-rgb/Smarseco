package com.crc.alarm.mapper;

import com.crc.alarm.model.domain.AlarmRemark;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;

/**
 * <p>
 * 告警-备注表单 Mapper 接口
 * </p>
 *
 * @author shufengfeng
 * @since 2021-08-31
 */
public interface AlarmRemarkMapper extends BaseMapper<AlarmRemark> {

    //int batchInsert(List<AlarmRemark> alarmRemarks);
}
