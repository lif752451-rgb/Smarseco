package com.crc.alarm.model.domain;

import java.util.Date;

import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableField;
import com.baomidou.mybatisplus.annotation.TableId;
import com.baomidou.mybatisplus.annotation.TableName;
import com.crc.core.model.BasicPHEntity;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;
import lombok.EqualsAndHashCode;

/**
 * 实战告警闭环-流程节点耗时表
 */
@ApiModel(value = "实战告警闭环-流程节点耗时表")
@Data
@EqualsAndHashCode(callSuper = true)
@TableName(value = "tb_alarm_combat_process_sla")
public class AlarmCombatProcessSla extends BasicPHEntity {
    /**
     * 主键ID
     */
    @TableId(value = "id", type = IdType.ASSIGN_UUID)
    @ApiModelProperty(value = "主键ID")
    private String id;

    /**
     * 实战告警闭环主表ID
     */
    @TableField(value = "alarm_report_id")
    @ApiModelProperty(value = "实战告警闭环主表ID")
    private String alarmReportId;

    /**
     * 最后一次研判时间
     */
    @TableField(value = "judge_time")
    @ApiModelProperty(value = "最后一次研判时间")
    private Date judgeTime;

    /**
     * 研判耗时(s)
     */
    @TableField(value = "judge_time_consuming")
    @ApiModelProperty(value = "研判耗时(s)")
    private Long judgeTimeConsuming;

    /**
     * 研判超时消息发送标识(0:未发送;1:已发送;)
     */
    @TableField(value = "judge_timeout_msg")
    @ApiModelProperty(value = "研判超时消息发送标识(0:未发送;1:已发送;)")
    private String judgeTimeoutMsg;

    /**
     * 最后一次处置时间
     */
    @TableField(value = "deal_time")
    @ApiModelProperty(value = "最后一次处置时间")
    private Date dealTime;

    /**
     * 处置耗时(s)
     */
    @TableField(value = "deal_time_consuming")
    @ApiModelProperty(value = "处置耗时(s)")
    private Long dealTimeConsuming;

    /**
     * 处置超时消息发送标识(0:未发送;1:已发送;)
     */
    @TableField(value = "deal_timeout_msg")
    @ApiModelProperty(value = "处置超时消息发送标识(0:未发送;1:已发送;)")
    private String dealTimeoutMsg;

    /**
     * 最后一次后续跟进时间
     */
    @TableField(value = "follow_up_time")
    @ApiModelProperty(value = "最后一次后续跟进时间")
    private Date followUpTime;

    /**
     * 后续跟进耗时(s)
     */
    @TableField(value = "follow_up_time_consuming")
    @ApiModelProperty(value = "后续跟进耗时(s)")
    private Long followUpTimeConsuming;

    /**
     * 最后一次审核时间
     */
    @TableField(value = "audit_time")
    @ApiModelProperty(value = "最后一次审核时间")
    private Date auditTime;

    /**
     * 审核耗时(s)
     */
    @TableField(value = "audit_time_consuming")
    @ApiModelProperty(value = "审核耗时(s)")
    private Long auditTimeConsuming;

    /**
     * 最后一次归档时间
     */
    @TableField(value = "archive_time")
    @ApiModelProperty(value = "最后一次归档时间")
    private Date archiveTime;

    /**
     * 归档耗时(s)
     */
    @TableField(value = "archive_time_consuming")
    @ApiModelProperty(value = "归档耗时(s)")
    private Long archiveTimeConsuming;
}