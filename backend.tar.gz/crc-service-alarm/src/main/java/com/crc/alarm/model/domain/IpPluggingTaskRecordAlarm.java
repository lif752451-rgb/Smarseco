package com.crc.alarm.model.domain;

import java.util.Date;

import com.baomidou.mybatisplus.annotation.TableName;
import com.fasterxml.jackson.annotation.JsonFormat;

import lombok.Data;
import lombok.experimental.Accessors;

/**
 * @author jixiangqi
 * @date 2023/1/17
 * 封堵记录表
 */
@Data
@Accessors(chain = true)
@TableName(value = "tb_ip_plugging_task_record", autoResultMap = true)
public class IpPluggingTaskRecordAlarm {

    private String id;

    private String taskId;

    private int actionType;

    private int operationType;

    private String operationUser;

    private int actionResult;

    private String actionReason;

    private String msg;

    private String deadlineTime;

    @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss",timezone="GMT+8")
    private Date actionTime;

    /**
     * 是否需要定时任务获取结果
     * 1 不需要
     * 2 需要
     */
    private Integer resultFlag;

}
