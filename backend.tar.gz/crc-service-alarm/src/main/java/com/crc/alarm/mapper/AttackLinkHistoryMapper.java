package com.crc.alarm.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.crc.alarm.model.domain.AttackLinkHistory;

/**
 * 攻击链路历史链路mapper
 *
 * @Author fuzhuangzhi
 * @Date 2022/6/29 18:47
 * @Version 1.0
 **/
public interface AttackLinkHistoryMapper extends BaseMapper<AttackLinkHistory> {
}
