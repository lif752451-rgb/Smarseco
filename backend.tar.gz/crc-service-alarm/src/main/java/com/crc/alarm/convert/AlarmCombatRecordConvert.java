package com.crc.alarm.convert;

import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import org.mapstruct.Mappings;
import org.mapstruct.factory.Mappers;

import com.crc.alarm.model.domain.AlarmCombatRecord;
import com.crc.alarm.model.response.AlarmCombatRecordResp;

@Mapper
public interface AlarmCombatRecordConvert {

    AlarmCombatRecordConvert INSTANCE = Mappers.getMapper(AlarmCombatRecordConvert.class);

    /**
     * 数据转换
     *
     * @param record
     * @return
     */
    @Mappings({
            @Mapping(target = "operationLabel", expression = "java(com.crc.alarm.model.enums.AlarmCombatFlowOperationEnum.getActNameByActKey(record.getOperation()))"),
    })
    AlarmCombatRecordResp convert(AlarmCombatRecord record);
}
