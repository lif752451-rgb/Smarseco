package com.crc.alarm.mapper;

import java.util.List;

import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.crc.alarm.model.domain.AlarmCombatReportSub;
import com.crc.alarm.model.dto.AlarmCombatReportDTO;
import com.crc.alarm.model.request.AlarmCombatReportPermissionReq;
import com.crc.alarm.model.response.AlarmCombatReportResp;
import com.crc.common.model.response.DictStatResp;

/**
 * 实战告警闭环-告警表单副表Mapper
 * 
 * @author zhangbing
 */
@Mapper
public interface AlarmCombatReportSubMapper extends BaseMapper<AlarmCombatReportSub> {

    /**
     * 查询列表
     *
     * @param combatDto 实战告警闭环-查询参数
     * @param dr 实战告警闭环-列表数据权限
     * @return List<实战告警闭环-列表>
     */
    List<AlarmCombatReportResp> findAlarmCombatReportExport(@Param("combatDto") AlarmCombatReportDTO combatDto,
        @Param("dr") AlarmCombatReportPermissionReq dr);

    /**
     * 重点关注等级分组统计
     * 
     * @param combatDto 实战告警闭环-查询参数
     * @return List
     */
    List<DictStatResp> findGroupAttentionLevelCount(@Param("combatDto") AlarmCombatReportDTO combatDto);

    /**
     * 重点关注查询详情
     *
     * @param combatDto 实战告警闭环-查询参数
     * @param attentionLevel 重点关注等级
     * @return list
     */
    List<AlarmCombatReportResp> findReportByAttentionLevelList(@Param("combatDto") AlarmCombatReportDTO combatDto,
        @Param("attentionLevel") String attentionLevel);

    /**
     * 查询集团下发记录
     *
     * @param alarmReportId 实战告警闭环主表ID
     * @return list
     */
    List<AlarmCombatReportResp> findGroupIssueList(@Param("alarmReportId") String alarmReportId);
}
