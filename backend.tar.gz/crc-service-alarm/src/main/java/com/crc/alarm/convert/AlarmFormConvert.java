package com.crc.alarm.convert;

import com.crc.alarm.model.domain.AlarmForm;
import com.crc.alarm.model.request.*;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import org.mapstruct.Mappings;
import org.mapstruct.factory.Mappers;

/**
 * @Author shufengfeng
 * @Description 告警表单请求转换类
 * @DateTime 2021/8/31 16:54
 */
@Mapper
public interface AlarmFormConvert {

    AlarmFormConvert INSTANCE = Mappers.getMapper(AlarmFormConvert.class);

    /**
     * 研判请求转换
     * @param request
     * @return
     */
    @Mappings({
           @Mapping(target="createTime", expression = "java(new java.util.Date())"),
           @Mapping(target="updateTime", expression = "java(new java.util.Date())")
    })
    AlarmForm convert(AlarmFormJudgeRequest request);

    /**
     * 研判误报请求转换
     * @param request
     * @return
     */
    @Mappings({
            @Mapping(target="createTime", expression = "java(new java.util.Date())"),
            @Mapping(target="updateTime", expression = "java(new java.util.Date())")
    })
    AlarmForm convert(AlarmFormMisinformationRequest request);

    /**
     * 处置(不转办)转换
     * @param request
     * @return
     */
    @Mappings({
            @Mapping(target="createTime", expression = "java(new java.util.Date())"),
            @Mapping(target="updateTime", expression = "java(new java.util.Date())")
    })
    AlarmForm convert(AlarmFormDealRequest request);

    /**
     * 处置(转办)转换
     * @param request
     * @return
     */
    @Mappings({
            @Mapping(target="createTime", expression = "java(new java.util.Date())"),
            @Mapping(target="updateTime", expression = "java(new java.util.Date())")
    })
    AlarmForm convert(AlarmFormDealConvertRequest request);

    /**
     * 处置(驳回)转换
     * @param request
     * @return
     */
    @Mappings({
            @Mapping(target="createTime", expression = "java(new java.util.Date())"),
            @Mapping(target="updateTime", expression = "java(new java.util.Date())")
    })
    AlarmForm convert(AlarmFormDealRejectRequest request);

    /**
     * 转办处置转换
     * @param request
     * @return
     */
    @Mappings({
            @Mapping(target="createTime", expression = "java(new java.util.Date())"),
            @Mapping(target="updateTime", expression = "java(new java.util.Date())")
    })
    AlarmForm convert(AlarmFormConvertDealRequest request);

    /**
     * 转办处置驳回转换
     * @param request
     * @return
     */
    @Mappings({
            @Mapping(target="createTime", expression = "java(new java.util.Date())"),
            @Mapping(target="updateTime", expression = "java(new java.util.Date())")
    })
    AlarmForm convert(AlarmFormConvertDealRejectRequest request);

    /**
     * 转办复核转换
     * @param request
     * @return
     */
    @Mappings({
            @Mapping(target="createTime", expression = "java(new java.util.Date())"),
            @Mapping(target="updateTime", expression = "java(new java.util.Date())"),
            @Mapping(target="checkResult", expression = "java(request.getCheckResult().getName())")
    })
    AlarmForm convert(AlarmFormCheckRequest request);

    /**
     * 审核转换
     * @param request
     * @return
     */
    @Mappings({
            @Mapping(target="createTime", expression = "java(new java.util.Date())"),
            @Mapping(target="updateTime", expression = "java(new java.util.Date())"),
            @Mapping(target="auditResult", expression = "java(request.getAuditResult().getName())")
    })
    AlarmForm convert(AlarmFormAuditRequest request);

    /**
     * 批量研判转换
     * @param request
     * @return
     */
    @Mappings({
            @Mapping(target="createTime", expression = "java(new java.util.Date())"),
            @Mapping(target="updateTime", expression = "java(new java.util.Date())")
    })
    AlarmForm convert(AlarmBatchJudgeRequest request);
}
