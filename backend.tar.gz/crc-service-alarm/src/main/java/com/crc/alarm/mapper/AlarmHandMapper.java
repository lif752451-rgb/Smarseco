package com.crc.alarm.mapper;

import java.util.List;

import com.crc.alarm.model.dto.AlarmPriorityDTO;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;

/**
 * 告警公共服务类（常态化告警闭环、实战告警闭环、HVV告警闭环）
 *
 * @author zhangbing
 * @since 2023/4/13 16:58
 */
@Mapper
public interface AlarmHandMapper {

    /**
     * 通过alarmId获取AI研判置信度
     *
     * @param alarmId
     * @return
     */
    AlarmPriorityDTO priorityById(@Param("alarmId") String alarmId);

    /**
     * IP查询漏洞
     *
     * @param ips IP集合
     * @param vulKeyword 漏洞关键字
     * @return int
     */
    List<String> getRelationVulStr(@Param("ips") List<String> ips, @Param("vulKeyword") String vulKeyword);

    /**
     * 得到ioc的数量
     *
     * @param ips ip
     * @return int
     */
    List<String> getRelationIocStr(@Param("ips") List<String> ips);

    /**
     * 查询封堵任务里面
     *
     * @param ip IP
     * @return List
     */
    List<String> getStatusByIp(String ip);
}