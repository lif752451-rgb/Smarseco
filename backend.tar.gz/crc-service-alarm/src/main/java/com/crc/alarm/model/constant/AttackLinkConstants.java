package com.crc.alarm.model.constant;

public class AttackLinkConstants {
    /**
     * 常态化流程
     */
    public static String NORMAL_ALARM_FLOW = "0";//常态化流程
    /**
     * HVV流程
     */
    public static String HVV_ALARM_FLOW = "1";//HVV
}
