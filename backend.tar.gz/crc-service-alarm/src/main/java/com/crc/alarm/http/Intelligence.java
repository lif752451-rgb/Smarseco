package com.crc.alarm.http;
import lombok.Data;

import java.util.List;

/**
 * @author shufengfeng
 * @Description: 安全洞察-攻击链路-微步接口响应
 * @date 2022/11/21 11:18
 */
@Data
public class Intelligence {

    private String ioc_type;
    private String confidence_level;
    private Boolean is_malicious;
    private List<String> judgments;
    private String severity;
    private Long update_time;
    private Ban ban;
    private Basic basic;
    private Asn asn;
    private String source_name;
    private String scene;
    private Object tags_classes;



}