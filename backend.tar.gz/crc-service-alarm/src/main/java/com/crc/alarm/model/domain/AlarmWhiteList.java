package com.crc.alarm.model.domain;

import com.baomidou.mybatisplus.annotation.*;
import com.fasterxml.jackson.annotation.JsonFormat;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.experimental.Accessors;

import java.util.Date;
import java.util.List;

/**
 * 描述：告警白名单
 *
 * @Author: fuzhuangzhi
 * @Date: 2021/11/11 16:33
 */
@Data
@EqualsAndHashCode(callSuper = false)
@Accessors(chain = true)
@TableName("tb_alarm_whitelist")
public class AlarmWhiteList {
    /**
     * 主键
     */
    @TableId(value = "id", type = IdType.AUTO)
    private Long id;

    /**
     * 告警白名单业务ID
     */
    @TableField(value = "whitelist_id")
    private String whitelistId;

    /**
     * 标题
     */
    @TableField("title")
    private String title;

    /**
     * 上报单位
     */
    @TableField("report_unit")
    private String reportUnit;

    /**
     * 报备原因 0:渗透测试 1：风险评估 2：安全设备 3：其他测试
     */
    @TableField("report_reason")
    private String reportReason;

    /**
     * 源IP
     */
    @TableField("src_ip")
    private String srcIp;

    /**
     * 目的类型 0:目的IP 1：目的组织
     */
    @TableField("dest_type")
    private String destType;

    /**
     * 目的内容
     */
    @TableField("dest_content")
    private String destContent;

    /**
     * 目的组织id
     */
    @TableField("dest_dept_id")
    private String destDeptId;

    /**
     * 目的组织id
     */
    @TableField("dest_dept_id_and_name")
    private String destDeptIdAndName;

    /**
     * 目的url
     */
    @TableField("dest_url")
    private String destUrl;

    /**
     * 业务期限 0：有限期限 1：永久
     */
    @TableField("business_term")
    private String businessTerm;

    /**
     * 生效开始日期，格式：yyyy-MM-dd
     */
    @TableField(value = "effect_date_start", updateStrategy = FieldStrategy.IGNORED)
    @JsonFormat(pattern = "yyyy-MM-dd")
    private Date effectDateStart;

    @TableField(exist = false)
    private String effectDateStartStr;

    /**
     * 生效结束日期，格式：yyyy-MM-dd
     */
    @TableField(value = "effect_date_end", updateStrategy = FieldStrategy.IGNORED)
    @JsonFormat(pattern = "yyyy-MM-dd")
    private Date effectDateEnd;

    @TableField(exist = false)
    private String effectDateEndStr;

    /**
     * 生效开始时间，格式：hh:mm:ss
     */
    @TableField(value = "effect_time_start")
    @JsonFormat(pattern = "hh:mm:ss")
    private Date effectTimeStart;

    @TableField(exist = false)
    private String effectTimeStartStr;

    /**
     * 生效结束时间，格式：hh:mm:ss
     */
    @TableField(value = "effect_time_end")
    @JsonFormat(pattern = "hh:mm:ss")
    private Date effectTimeEnd;

    @TableField(exist = false)
    private String effectTimeEndStr;

    /**
     * 备注
     */
    @TableField("remark")
    private String remark;

    /**
     * 业务模型
     */
    @TableField("bus_model")
    private String busModel;

    /**
     * 是否启用(0.启用,1.禁用)
     */
    @TableField("is_enable")
    private String isEnable;

    /**
     * 申请人
     */
    @TableField("create_by")
    private String createBy;

    /**
     * 申请人label
     */
    @TableField("create_by_label")
    private String createByLabel;

    /**
     * 申请时间
     */
    @TableField("create_time")
    @JsonFormat(pattern = "yyyy-MM-dd hh:mm:ss")
    private Date createTime;

    /**
     * 审核人
     */
    @TableField("approve_by")
    private String approveBy;

    /**
     * 审核人label
     */
    @TableField("approve_by_label")
    private String approveByLabel;

    /**
     * 审核时间
     */
    @TableField("approve_time")
    @JsonFormat(pattern = "yyyy-MM-dd hh:mm:ss")
    private Date approveTime;

    @TableField(exist = false)
    private String approveTimeStr;

    /**
     * 审批状态，0待审核，1通过，2，不通过
     */
    @TableField("approve_status")
    private String approveStatus;

    /**
     * 删除标志(0:正常;1.删除)
     */
    @TableField("del_flag")
    private String delFlag;

    /**
     * 是否全局:1.是,0.不是
     */
    @TableField("is_global")
    private String isGlobal;

    /**
     * 审批意见
     */
    @TableField("approve_desc")
    private String approveDesc;

    /**
     * 修改人
     */
    @TableField("update_by")
    private String updateBy;

    /**
     * 修改时间
     */
    @TableField("update_time")
    @JsonFormat(pattern = "yyyy-MM-dd hh:mm:ss")
    private Date updateTime;

    /**
     * 来源: ssp,stp
     */
    @TableField("source")
    private String source;

    /**
     * 用户组织id
     */
    @TableField("dept_id")
    private String deptId;

    /**
     * 告警主表ID
     */
    @TableField("alarm_report_id")
    private String alarmReportId;

    /**
     * 告警白名单来源类型 sspAdd ssp管理新增(默认)、 normAlarm 常态化告警、 combatAlarm 实战告警
     */
    @TableField("white_source_type")
    private String whiteSourceType;


    /**
     * 上报单位叶子节点ID
     */
    @ApiModelProperty("上报单位叶子节点ID")
    private Long reportDeptNodeId;

    /**
     * 上报单位
     */
    @ApiModelProperty("上报单位")
    private String reportDeptName;

    /**
     * 目的组织id列表
     */
    @ApiModelProperty("目的组织id列表")
    private String destId;

    @TableField(exist = false)
    private List<String> ids;
}
