package com.crc.alarm.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.crc.alarm.model.domain.AlarmWhiteList;
import com.crc.alarm.model.request.AlarmWhiteListSearchRequest;
import com.crc.alarm.model.response.AlarmWhiteListResponse;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;

import java.util.List;
import java.util.Map;

/**
 * 描述：告警白名单 mapper
 *
 * @Author: fuzhuangzhi
 * @Date: 2021/11/11 17:15
 */
@Mapper
public interface AlarmWhiteListMapper extends BaseMapper<AlarmWhiteList> {
    /**
     * 告警白名单列表
     *
     * @param request 列表查询参数
     * @return 告警白名单列表
     */
    List<AlarmWhiteListResponse> getList(AlarmWhiteListSearchRequest request);

    /**
     * 查看sbp个人工作台数据
     * @param request
     * @return
     */
    List<AlarmWhiteListResponse> getSbpList(AlarmWhiteListSearchRequest request);

    List<AlarmWhiteListResponse> getAuditList(AlarmWhiteListSearchRequest request);


    List<AlarmWhiteListResponse> getAuditIds(AlarmWhiteListSearchRequest request);

    /**
     * 告警闭环查询快捷加白记录
     *
     * @param request 列表查询参数
     * @return 告警白名单列表
     */
    List<AlarmWhiteListResponse> findWhitelistListByAlarmReportId(AlarmWhiteListSearchRequest request);

    /**
     * 告警白名单审批状态数量
     *
     * @param request 告警白名单菜单参数
     * @return 告警白名单审批状态数量
     */
    List<Map<String, String>> getAllStateCount(AlarmWhiteListSearchRequest request);

    /**
     * 获取所有的模型
     *
     * @return
     */
    public List<String> getModelNameList(Map<String, Object> map);

    int getCopyTitle(String title);


    /**
     * 查询当前前缀最大的ID
     *
     * @param prefix 前缀
     * @return 当前最大的事件ID
     */
    String getMaxWhitelistIdByPrefix(@Param("prefix") String prefix);

    /**
     * 根据id集合查询数据
     * @param ids
     * @return
     */
    List<AlarmWhiteListResponse> getByIds(List<String> ids);

    AlarmWhiteListResponse getByWhiteListId(String whiteListId);
}
