package com.crc.alarm.model.dto;

import com.alibaba.excel.annotation.ExcelProperty;
import com.alibaba.excel.annotation.write.style.ColumnWidth;
import com.alibaba.excel.annotation.write.style.HeadRowHeight;
import lombok.Data;

/**
 * 描述：告警白名单导出返回类
 *
 * @Author: shufengfeng
 * @Date: 2022/09/02 16:41
 */
@Data
@ColumnWidth(20)
public class AlarmWhiteExportDTO {
    /**
     *  标题
     */
    @ExcelProperty("白名单ID")
    private String whitelistId;

    /**
     *  标题
     */
    @ExcelProperty("报备标题")
    private String title;

    /**
     *  源IP
     */
    @ExcelProperty("源IP")
    private String srcIp;


    /**
     *  目的类型 0:目的IP 1：目的组织
     */
    @ExcelProperty("目的类型")
    private String destTypeName;

    /**
     * 目的内容
     */
    @ExcelProperty("目的内容")
    private String destContent;

    /**
     * 目的url
     */
    @ExcelProperty("目的URL")
    private String destUrl;

    /**
     * 业务期限 0：有限期限 1：永久
     */
    @ExcelProperty("生效期限")
    private String businessTermName;


    /**
     * 生效开始日期，格式：yyyy-MM-dd
     */
    @ExcelProperty("生效日期")
    private String effectDate;

    /**
     * 生效开始时间，格式：hh:mm:ss
     */
    @ExcelProperty("生效时间段")
    private String effectTime;

    /**
     *  上报单位
     */
    @ExcelProperty("上报单位")
    private String reportDeptName;

    /**
     *  报备原因 0:渗透测试 1：风险评估 2：安全设备 3：其他测试
     */
    @ExcelProperty("加白原因")
    private String reportReasonName;

    @ExcelProperty("备注")
    private String remark;

    @ExcelProperty("申请人")
    private String createByLabel;

    @ExcelProperty("申请时间")
    private String createTime;

    @ExcelProperty("审核结果")
    private String approveStatusName;

    @ExcelProperty("审核人")
    private String approveByLabel;

    @ExcelProperty("审核时间")
    private String approveTime;

    @ExcelProperty("是否全局")
    private String isGlobal;

    @ExcelProperty("业务模型")
    private String busModel;

    @ExcelProperty("生效状态")
    private String isEnable;
}
