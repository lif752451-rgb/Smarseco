package com.crc.alarm.model.domain;

import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableField;
import com.baomidou.mybatisplus.annotation.TableId;
import com.baomidou.mybatisplus.annotation.TableName;
import com.crc.core.model.BasicPHEntity;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;
import lombok.EqualsAndHashCode;

/**
 * 实战告警闭环-补充备注表
 */
@ApiModel(value = "实战告警闭环-补充备注表")
@Data
@EqualsAndHashCode(callSuper = true)
@TableName(value = "tb_alarm_combat_remark")
public class AlarmCombatRemark extends BasicPHEntity {
    /**
     * 主键
     */
    @TableId(value = "id", type = IdType.ASSIGN_UUID)
    @ApiModelProperty(value = "主键")
    private String id;

    /**
     * 实战告警闭环主表ID
     */
    @TableField(value = "alarm_report_id")
    @ApiModelProperty(value = "实战告警闭环主表ID")
    private String alarmReportId;

    /**
     * 备注内容
     */
    @TableField(value = "content")
    @ApiModelProperty(value = "备注内容")
    private String content;

    /**
     * 创建人姓名
     */
    @TableField(value = "create_by_label")
    @ApiModelProperty(value = "创建人姓名")
    private String createByLabel;
}