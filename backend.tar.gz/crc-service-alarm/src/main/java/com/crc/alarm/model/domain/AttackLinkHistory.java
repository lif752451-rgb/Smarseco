package com.crc.alarm.model.domain;

import com.baomidou.mybatisplus.annotation.TableField;
import com.baomidou.mybatisplus.annotation.TableName;
import com.crc.core.model.BasicEntity;
import com.fasterxml.jackson.annotation.JsonFormat;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;
import lombok.EqualsAndHashCode;

import javax.validation.constraints.NotBlank;
import java.util.Date;

/**
 * 攻击链路历史链路表
 *
 * @Author fuzhuangzhi
 * @Date 2022/6/29 18:39
 * @Version 1.0
 **/
@Data
@EqualsAndHashCode(callSuper = true)
@ApiModel(value = "攻击链路-历史链路表")
@TableName(value = "tb_attack_link_history")
public class AttackLinkHistory extends BasicEntity {

    @NotBlank(message = "关注IP不能为空")
    @ApiModelProperty(value = "关注IP")
    @TableField(value = "follow_ip")
    private String followIp;

    @NotBlank(message = "攻击链路开始时间不能为空")
    @ApiModelProperty(value = "攻击链路开始时间")
    @TableField(value = "attack_start_time")
    @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss",timezone="GMT+8")
    private Date attackStartTime;

    @NotBlank(message = "攻击链路结束时间不能为空")
    @ApiModelProperty(value = "攻击链路结束时间")
    @TableField(value = "attack_end_time")
    @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss",timezone="GMT+8")
    private Date attackEndTime;

    @NotBlank(message = "链路名称不能为空")
    @ApiModelProperty(value = "攻击链路名称")
    @TableField(value = "link_name")
    private String linkName;

    @ApiModelProperty(value = "删除标识")
    @TableField(value = "del_flag")
    private String delFlag;

    @ApiModelProperty(value = "是否为新版（0代表旧版 1代表新版）")
    @TableField(value = "is_new")
    private Integer isNew;


    @ApiModelProperty(value = "新版详情信息")
    @TableField(value = "detail")
    private String detail;
}
