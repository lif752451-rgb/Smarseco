package com.crc.alarm.http;

/**
 * @author shufengfeng
 * @Description: 安全洞察-攻击链路-微步接口响应
 * @date 2022/11/21 11:18
 */
public class Location {

    private String country;
    private String country_code;
    private String province;
    private String city;
    private Double lng;
    private Double lat;
    public void setCountry(String country) {
         this.country = country;
     }
     public String getCountry() {
         return country;
     }

    public void setCountry_code(String country_code) {
         this.country_code = country_code;
     }
     public String getCountry_code() {
         return country_code;
     }

    public void setProvince(String province) {
         this.province = province;
     }
     public String getProvince() {
         return province;
     }

    public void setCity(String city) {
         this.city = city;
     }
     public String getCity() {
         return city;
     }

    public void setLng(double lng) {
         this.lng = lng;
     }
     public Double getLng() {
         return lng;
     }

    public void setLat(double lat) {
         this.lat = lat;
     }
     public Double getLat() {
         return lat;
     }

}