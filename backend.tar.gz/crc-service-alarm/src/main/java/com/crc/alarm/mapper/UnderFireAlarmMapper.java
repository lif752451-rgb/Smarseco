package com.crc.alarm.mapper;

import com.crc.alarm.model.request.UnderFireReq;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;

import java.util.List;
import java.util.Map;

/**
 * 受攻击概览-告警信息
 *
 * @author zhangbing
 * @date 2023/08/02 15:36
 */
@Mapper
public interface UnderFireAlarmMapper {

    /**
     * 分组统计受害IP关联 部门 每日实战告警数量
     * 
     * @param req 入参
     * @return List
     */
    List<Map<String, String>> findVictimizedIpDeptDailyCombaAlarmGroup(@Param("req") UnderFireReq req);

    /**
     * 分组统计受害IP关联 标靶系统、标靶相关系统、数据风险高 每日实战告警数量
     *
     * @param req 入参
     * @return List
     */
    List<Map<String, String>> findVictimizedIpCustomCriticalDailyCombaAlarmGroup(@Param("req") UnderFireReq req);

    /**
     * 分组统计受害IP关联 集权系统、等保系统、公有云资产 每日实战告警数量
     *
     * @param req 入参
     * @param sysType 所属系统 3:集权系统 4：等保系统 8：公有云资产
     * @return List
     */
    List<Map<String, String>> findVictimizedIpCriticalDailyCombaAlarmGroup(@Param("req") UnderFireReq req,
        @Param("sysType") Integer sysType);

    /**
     * 分组统计受害IP关联 风险残留资产 每日实战告警数量
     *
     * @param req 入参
     * @return List
     */
    List<Map<String, String>> findVictimizedIpRiskDailyCombaAlarmGroup(@Param("req") UnderFireReq req);

    /**
     * 分组统计受害IP关联 互联网暴露资产 每日实战告警数量
     *
     * @param req 入参
     * @return List
     */
    List<Map<String, String>> findVictimizedIpInternetDailyCombaAlarmGroup(@Param("req") UnderFireReq req);

    /**
     * 分组统计受害IP关联 网络区域 每日实战告警数量
     *
     * @param req 入参
     * @return List
     */
    List<Map<String, String>> findVictimizedIpAreaDailyCombatAlarmGroup(@Param("req") UnderFireReq req);
}
