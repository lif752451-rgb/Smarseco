package com.crc.alarm.http;
import java.util.List;

/**
 * @author shufengfeng
 * @Description: 安全洞察-攻击链路-微步接口响应
 * @date 2022/11/21 11:18
 */
@lombok.Data
public class Data {

    private String ioc;
    private String host;
    private List<Intelligence> intelligence;


}