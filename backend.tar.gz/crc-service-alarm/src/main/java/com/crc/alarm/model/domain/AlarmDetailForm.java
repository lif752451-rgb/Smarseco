package com.crc.alarm.model.domain;

import lombok.Data;

@Data
public class AlarmDetailForm {
    /**
     * 1-常态化，2-实战
     */
    String type;
    String alarmId;
    String evtId;
}
