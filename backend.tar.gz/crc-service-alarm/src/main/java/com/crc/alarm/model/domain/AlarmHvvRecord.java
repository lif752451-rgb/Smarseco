package com.crc.alarm.model.domain;

import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableField;
import com.baomidou.mybatisplus.annotation.TableId;
import com.baomidou.mybatisplus.annotation.TableName;
import com.crc.core.model.BasicPHEntity;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;
import lombok.EqualsAndHashCode;

/**
 * 告警闭环-流程表(hvv)
 */
@Data
@EqualsAndHashCode(callSuper = true)
@ApiModel(value = "告警闭环-流程表(hvv)")
@TableName(value = "tb_alarm_hvv_record")
public class AlarmHvvRecord extends BasicPHEntity {

    private static final long serialVersionUID = 1L;

    /**
     * 唯一主键
     */
    @ApiModelProperty(value = "主键")
    @TableId(value = "id", type = IdType.AUTO)
    private Long id;

    /**
     * 业务key
     */
    @TableField(value = "business_key")
    @ApiModelProperty(value = "业务key")
    private String businessKey;

    /**
     * 告警表单id
     */
    @TableField(value = "alarm_form_id")
    @ApiModelProperty(value = "告警表单id")
    private Long alarmFormId;

    /**
     * 节点名称
     */
    @TableField(value = "node_name")
    @ApiModelProperty(value = "节点名称")
    private String nodeName;

    /**
     * 处理人
     */
    @TableField(value = "deal_user_name")
    @ApiModelProperty(value = "处理人")
    private String dealUserName;

    /**
     * 处理人姓名
     */
    @TableField(value = "deal_nick_name")
    @ApiModelProperty(value = "处理人姓名")
    private String dealNickName;

    /**
     * 流程标记(0可用 1不可用)
     */
    @TableField(value = "flow_flag")
    @ApiModelProperty(value = "流程标记(0可用 1不可用)")
    private Integer flowFlag;

    /**
     * 下一个节点名称
     */
    @TableField(value = "next_node_name")
    @ApiModelProperty(value = "下一个节点名称")
    private String nextNodeName;

    /**
     * 下一个节点处理人
     */
    @TableField(value = "next_deal_user_name")
    @ApiModelProperty(value = "下一个节点处理人")
    private String nextDealUserName;

    /**
     * 操作
     */
    @TableField(value = "`operation`")
    @ApiModelProperty(value = "操作")
    private String operation;

    /**
     * 意见
     */
    @TableField(value = "opinion")
    @ApiModelProperty(value = "意见")
    private String opinion;

    /**
     * 创建人姓名
     */
    @TableField(value = "create_by_label")
    @ApiModelProperty(value = "创建人姓名")
    private String createByLabel;
}