package com.crc.alarm.mapper;

import com.crc.alarm.model.domain.AlarmForm;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;

import java.util.List;

/**
 * <p>
 * 威胁管理-告警表单 Mapper 接口
 * </p>
 *
 * @author shufengfeng
 * @since 2021-08-31
 */
public interface AlarmFormMapper extends BaseMapper<AlarmForm> {

    /**
     * 根据业务key和是否转办不为空表单信息,获取最后的处置人信息
     * @param businessKey
     * @return
     */
    AlarmForm findByBusinessKeyHasConvertStatusLatest(String businessKey);


    /**
     * 根据业务key和是否复核不为空表单信息
     * @param businessKey
     * @return
     */
    AlarmForm findByBusinessKeyHasCheckStatus(String businessKey);

    /**
     * 根据业务key和是否转办不为空表单信息
     * @param businessKey
     * @return
     */
    AlarmForm findByBusinessKeyHasConvertStatus(String businessKey);

    /**
     * 根据业务key和安全接口人不为空表单信息
     * @param businessKey
     * @return
     */
    AlarmForm findByBusinessKeyHasSecurityUser(String businessKey);


    /**
     * 根据业务key和是否转办不为空表单信息
     * @param businessKey
     * @return
     */
    List<AlarmForm> findByBusinessKey(String businessKey);

    /**
     * 批量插入表单数据
     * @param alarmFormList
     * @return
     */
    int batchInsert(List<AlarmForm> alarmFormList);
}
