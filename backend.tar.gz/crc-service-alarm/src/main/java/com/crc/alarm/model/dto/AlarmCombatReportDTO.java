package com.crc.alarm.model.dto;

import java.math.BigInteger;
import java.util.List;

import com.crc.alarm.model.domain.AlarmCombatReport;

import com.crc.common.utils.ip.AssetSegementIp;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;
import lombok.EqualsAndHashCode;

/**
 * 实战告警闭环-查询参数
 * 
 * @author zhangbing
 */
@ApiModel(value = "实战告警闭环-查询参数")
@Data
@EqualsAndHashCode(callSuper = true)
public class AlarmCombatReportDTO extends AlarmCombatReport {

    /**
     * 列表类型 allAlarm(全部告警列表) waitAlarm(我的待办列表) doneAlarm(我的已办列表)
     */
    @ApiModelProperty(value = "列表类型")
    private String listType;

    /**
     * 告警ID 多个用英文逗号隔开
     */
    @ApiModelProperty(value = "告警ID")
    private String alarmIds;

    /**
     * 搜索条件-IP
     */
    @ApiModelProperty(value = "搜索条件-IP")
    private String ip;

    /**
     * 攻击源资产
     */
    @ApiModelProperty(value = "攻击源资产")
    private String attackAssetName;

    /**
     * 攻击源应用系统IP集合
     */
    @ApiModelProperty(value = "攻击源应用系统IP集合")
    private List<String> attackAssetIpList;

    /**
     * 受害资产
     */
    @ApiModelProperty(value = "受害资产")
    private String victimizedAssetName;

    /**
     * 受害应用系统IP集合
     */
    @ApiModelProperty(value = "受害应用系统IP集合")
    private List<String> victimizedAssetIpList;

    /**
     * 搜索条件-告警开始时间
     */
    @ApiModelProperty(value = "搜索条件-告警开始时间")
    private String alarmStartTime;

    /**
     * 搜索条件-告警结束时间
     */
    @ApiModelProperty(value = "搜索条件-告警结束时间")
    private String alarmEndTime;

    /**
     * 搜索条件-作战周期开始时间
     */
    @ApiModelProperty(value = "搜索条件-告警开始时间")
    private String fightPeriodStartTime;

    /**
     * 搜索条件-作战周期结束时间
     */
    @ApiModelProperty(value = "搜索条件-告警结束时间")
    private String fightPeriodEndTime;

    /**
     * 搜索条件-创建开始时间
     */
    @ApiModelProperty(value = "搜索条件-创建开始时间")
    private String createStartTime;

    /**
     * 搜索条件-创建结束时间
     */
    @ApiModelProperty(value = "搜索条件-创建结束时间")
    private String createEndTime;

    /**
     * 全局搜索
     */
    @ApiModelProperty(value = "全局搜索")
    private String searchAll;

    /**
     * 搜索条件-告警级别
     */
    @ApiModelProperty(value = "搜索条件-告警级别")
    private List<String> levelList;

    /**
     * 搜索条件-重点关注等级
     */
    @ApiModelProperty(value = "搜索条件-重点关注等级")
    private List<String> attentionLevelList;

    /**
     * 搜索条件-工单状态
     */
    @ApiModelProperty(value = "搜索条件-工单状态")
    private List<String> orderStatusList;

    /**
     * 搜索条件-攻击结果
     */
    @ApiModelProperty(value = "搜索条件-攻击结果")
    private List<String> attackResultList;

    /**
     * 搜索条件-攻击手段
     */
    @ApiModelProperty(value = "搜索条件-攻击手段")
    private List<String> attackMeansList;

    /**
     * 搜索条件-行为性质
     */
    @ApiModelProperty(value = "搜索条件-行为性质")
    private List<String> behaviorNatureList;

    /**
     * 搜索条件-告警来源
     */
    @ApiModelProperty(value = "搜索条件-告警来源")
    private List<String> alarmSourceList;

    /**
     * 搜索条件-最后一次溯源状态
     */
    @ApiModelProperty(value = "搜索条件-最后一次溯源状态")
    private List<String> traceabilityStatusList;

    /**
     * 搜索条件-重点关注标记
     */
    @ApiModelProperty(value = "搜索条件-重点关注标记")
    private List<String> focusTagList;

    /**
     * 搜索条件-是否转风险
     */
    @ApiModelProperty(value = "搜索条件-是否转风险")
    private List<String> isTurnRiskList;

    /**
     * 搜索条件-流程来源
     */
    @ApiModelProperty(value = "搜索条件-流程来源")
    private List<String> processSourceList;

    /**
     * 搜索条件-申请集团协助
     */
    @ApiModelProperty(value = "搜索条件-申请集团协助")
    private List<String> applyGroupAssistList;

    /**
     * 搜索条件-上报集团流程
     */
    @ApiModelProperty(value = "搜索条件-上报集团流程")
    private List<String> reportGroupProcessList;

    /**
     * 搜索条件-集团下发流程
     */
    @ApiModelProperty(value = "搜索条件-集团下发流程")
    private List<String> groupIssueProcessList;

    /**
     * 搜索条件-研判标签
     */
    @ApiModelProperty(value = "搜索条件-研判标签")
    private List<String> judgeTagList;

    /**
     * 搜索条件-研判耗时
     */
    @ApiModelProperty(value = "搜索条件-研判耗时")
    private List<String> judgeSlaStatusList;

    /**
     * 研判超时条件
     */
    @ApiModelProperty(value = "搜索条件-研判超时条件")
    private Integer judgeSlaTime;

    /**
     * 搜索条件-处置耗时
     */
    @ApiModelProperty(value = "搜索条件-处置耗时")
    private List<String> dealSlaStatusList;

    /**
     * 处置超时条件
     */
    @ApiModelProperty(value = "搜索条件-处置超时条件")
    private Integer dealSlaTime;

    /**
     * 责任部门名称
     */
    @ApiModelProperty(value = "搜索条件-责任部门名称")
    private String dutyDeptName;

    /**
     * 责任部门ID集合
     */
    @ApiModelProperty(value = "搜索条件-责任部门ID集合")
    private List<Long> dutyDeptIdList;

    /**
     * 关联告警ID集合
     */
    @ApiModelProperty(value = "搜索条件-关联告警ID集合")
    private List<String> relationAlarmIdList;

    /**
     * 关联告警IP集合 匹配攻击IP以及受害IP
     */
    @ApiModelProperty(value = "搜索条件-关联告警IP集合")
    private List<String> relationAlarmIpList;

    /**
     * 关联告警攻击IP集合 匹配攻击IP
     */
    @ApiModelProperty(value = "搜索条件-关联告警攻击IP集合")
    private List<String> relationAlarmAttackIpList;

    /**
     * 排除告警ID集合
     */
    @ApiModelProperty(value = "搜索条件-排除告警ID集合")
    private List<String> excludeAlarmIdList;

    /**
     * 攻击IP或受害IP所属的网段范围
     */
    private String segment;

    /**
     * 开始ip十进制,long
     */
    private BigInteger startLongIp;

    /**
     * 结束ip十进制 ，long
     */
    private BigInteger endLongIp;

    /**
     * 菜单id
     */
    private String menuId;

    /**
     * 是否全部数据
     */
    private Boolean isAllDupt =false;

    /**
     * 是否溯源和包含当前用户数据
     */
    private  String traceability ;
}