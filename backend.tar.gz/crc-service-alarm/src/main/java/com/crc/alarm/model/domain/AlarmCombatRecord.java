package com.crc.alarm.model.domain;

import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableField;
import com.baomidou.mybatisplus.annotation.TableId;
import com.baomidou.mybatisplus.annotation.TableName;
import com.crc.core.model.BasicPHEntity;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;
import lombok.EqualsAndHashCode;

/**
 * 实战告警闭环-流程表
 */
@ApiModel(value = "实战告警闭环-流程表")
@Data
@EqualsAndHashCode(callSuper = true)
@TableName(value = "tb_alarm_combat_record")
public class AlarmCombatRecord extends BasicPHEntity {
    /**
     * 主键
     */
    @TableId(value = "id", type = IdType.ASSIGN_UUID)
    @ApiModelProperty(value = "主键")
    private String id;

    /**
     * 实战告警闭环主表ID
     */
    @TableField(value = "alarm_report_id")
    @ApiModelProperty(value = "实战告警闭环主表ID")
    private String alarmReportId;

    /**
     * 告警表单id
     */
    @TableField(value = "alarm_form_id")
    @ApiModelProperty(value = "告警表单id")
    private String alarmFormId;

    /**
     * 节点key
     */
    @TableField(value = "node_key")
    @ApiModelProperty(value = "节点key")
    private String nodeKey;

    /**
     * 处理人
     */
    @TableField(value = "deal_user_name")
    @ApiModelProperty(value = "处理人")
    private String dealUserName;

    /**
     * 处理人姓名
     */
    @TableField(value = "deal_nick_name")
    @ApiModelProperty(value = "处理人姓名")
    private String dealNickName;

    /**
     * 流程标记(0可用 1不可用)
     */
    @TableField(value = "flow_flag")
    @ApiModelProperty(value = "流程标记(0可用 1不可用)")
    private Integer flowFlag;

    /**
     * 下一个节点名称
     */
    @TableField(value = "next_node_key")
    @ApiModelProperty(value = "下一个节点名称")
    private String nextNodeKey;

    /**
     * 下一个节点处理人
     */
    @TableField(value = "next_deal_user_name")
    @ApiModelProperty(value = "下一个节点处理人")
    private String nextDealUserName;

    /**
     * 操作
     */
    @TableField(value = "`operation`")
    @ApiModelProperty(value = "操作")
    private String operation;

    /**
     * 意见
     */
    @TableField(value = "opinion")
    @ApiModelProperty(value = "意见")
    private String opinion;

    /**
     * 知识库告警处置反馈指南知识ID
     */
    @TableField(value = "knowledge_alarm_feedback_id")
    @ApiModelProperty(value = "知识库告警处置反馈指南知识ID")
    private String knowledgeAlarmFeedbackId;

    /**
     * 创建人姓名
     */
    @TableField(value = "create_by_label")
    @ApiModelProperty(value = "创建人姓名")
    private String createByLabel;
}