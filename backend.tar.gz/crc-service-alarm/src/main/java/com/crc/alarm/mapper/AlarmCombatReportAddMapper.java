package com.crc.alarm.mapper;

import java.util.List;

import org.apache.ibatis.annotations.Param;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.crc.alarm.model.domain.AlarmCombatReport;

/**
 * 实战告警闭环主表添加Mapper
 */
public interface AlarmCombatReportAddMapper extends BaseMapper<AlarmCombatReport> {

    /**
     * 查最新的告警ID
     *
     * @param prefix 告警ID前缀
     * @return String
     */
    Integer findMaxAlarmIdByPrefix(String prefix);

    /**
     * 查询告警信息
     * @param internalIp 内网ip
     * @param internetIp 外网ip
     * @return 告警信息
     */
    List<AlarmCombatReport> selectAlarmReportByIp(@Param("internalIp") String internalIp, @Param("internetIp") String internetIp);

    /**
     * 批量修改告警信息
     * @param reports 告警信息
     */
    void batchUpdateAlarmReport(List<AlarmCombatReport> reports);

}