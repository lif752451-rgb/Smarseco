package com.crc.alarm.model.constant;

/**
 * 告警闭环(hvv)-告警常量类
 */
public interface AlarmHvvConstants {

    /**
     * 列表导出文件名称
     */
    String ALARM_EXCEL_NAME = "告警列表";

    /**
     * 列表类型：全部告警列表
     */
    String LIST_TYPE_ALL = "allAlarm";

    /**
     * 列表导出文件名称-前缀
     */
    String ALL_ALARM_EXCEL_NAME = "全部告警";

    /**
     * 列表类型：我的待办列表
     */
    String LIST_TYPE_WAIT = "waitAlarm";

    /**
     * 列表导出文件名称-前缀
     */
    String WAIT_ALARM_EXCEL_NAME = "我的待办";

    /**
     * 列表类型：我的已办列表
     */
    String LIST_TYPE_DONE = "doneAlarm";

    /**
     * 列表导出文件名称-前缀
     */
    String DONE_ALARM_EXCEL_NAME = "我的已办";

    /**
     * 上报告警附件类型
     */
    String REPORT_ALARM_ATT = "reportAlarm";

    /**
     * 告警审批流程附件类型
     */
    String ALARM_APPROVAL_ATT = "alarmApproval";

    /**
     * 告警溯源附件类型
     */
    String ALARM_TRACEABILITY_ATT = "alarmTraceability";

    /**
     * 告警补充备注附件类型
     */
    String ALARM_REMARK_ATT = "alarmRemark";

    /**
     * 需要后续跟进
     */
    String WHETHER_FOLLOW_UP_YES_OPINION = "需要后续跟进：";

    /**
     * 无需后续跟进
     */
    String WHETHER_FOLLOW_UP_NO_OPINION = "无需后续跟进";
}