package com.crc.alarm.model.domain;

import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableField;
import com.baomidou.mybatisplus.annotation.TableId;
import com.baomidou.mybatisplus.annotation.TableName;
import com.crc.core.model.BasicPHEntity;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;
import lombok.EqualsAndHashCode;

/**
 * 实战告警闭环-申请集团协助记录表
 */
@ApiModel(value = "实战告警闭环-申请集团协助记录表")
@Data
@EqualsAndHashCode(callSuper = true)
@TableName(value = "tb_alarm_combat_apply_help_log")
public class AlarmCombatApplyHelpLog extends BasicPHEntity {

    /**
     * 主键ID
     */
    @TableId(value = "id", type = IdType.ASSIGN_UUID)
    @ApiModelProperty(value = "主键ID")
    private String id;

    /**
     * 实战告警闭环主表ID
     */
    @TableField(value = "alarm_report_id")
    @ApiModelProperty(value = "实战告警闭环主表ID")
    private String alarmReportId;

    /**
     * 申请原因
     */
    @TableField(value = "opinion")
    @ApiModelProperty(value = "申请原因")
    private String opinion;

    /**
     * 创建人姓名
     */
    @TableField(value = "create_by_label")
    @ApiModelProperty(value = "创建人姓名")
    private String createByLabel;
}