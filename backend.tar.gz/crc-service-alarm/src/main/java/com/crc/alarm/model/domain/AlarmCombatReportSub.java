package com.crc.alarm.model.domain;

import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableField;
import com.baomidou.mybatisplus.annotation.TableId;
import com.baomidou.mybatisplus.annotation.TableName;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

/**
 * 实战告警闭环-告警表单副表
 */
@ApiModel(value = "实战告警闭环-告警表单副表")
@Data
@TableName(value = "tb_alarm_combat_report_sub")
public class AlarmCombatReportSub {
    /**
     * 主键
     */
    @TableId(value = "id", type = IdType.ASSIGN_UUID)
    @ApiModelProperty(value = "主键")
    private String id;

    /**
     * 实战告警闭环主表ID
     */
    @TableField(value = "alarm_report_id")
    @ApiModelProperty(value = "实战告警闭环主表ID")
    private String alarmReportId;

    /**
     * 上报集团流程成功租户的告警主表ID
     */
    @TableField(value = "report_group_report_id")
    @ApiModelProperty(value = "上报集团流程成功租户的告警主表ID")
    private String reportGroupReportId;

    /**
     * 是否转风险
     */
    @TableField(value = "is_turn_risk")
    @ApiModelProperty(value = "是否转风险")
    private String isTurnRisk;

    /**
     * 申请集团协助 0 否 1 是
     */
    @TableField(value = "apply_group_assist")
    @ApiModelProperty(value = "申请集团协助 0 否  1 是")
    private String applyGroupAssist;

    /**
     * 上报集团流程 0 未上报 1 已上报
     */
    @TableField(value = "report_group_process")
    @ApiModelProperty(value = "上报集团流程 0 未上报 1 已上报")
    private String reportGroupProcess;

    /**
     * 节点已读状态
     */
    @TableField(value = "node_read_status")
    @ApiModelProperty(value = "节点已读状态")
    private String nodeReadStatus;

    /**
     * 集团申请 已读状态 0 未读、1 已读
     */
    @TableField(value = "apply_help_read_status")
    @ApiModelProperty(value = "集团申请 已读状态")
    private String applyHelpReadStatus;

    /**
     * 重点关注等级 0-5
     */
    @TableField(value = "attention_level")
    @ApiModelProperty(value = "重点关注等级  0-5")
    private String attentionLevel;

    /**
     * 重点关注说明
     */
    @TableField(value = "attention_explain")
    @ApiModelProperty(value = "重点关注说明")
    private String attentionExplain;

    /**
     * 集团下发租户流程成功集团的告警主表ID
     */
    @TableField(value = "group_issue_report_id")
    @ApiModelProperty(value = "集团下发租户流程成功集团的告警主表ID")
    private String groupIssueReportId;

    /**
     * 集团下发租户流程 0 未下发 1 已下发
     */
    @TableField(value = "group_issue_process")
    @ApiModelProperty(value = "集团下发租户流程 0 未下发 1 已下发")
    private String groupIssueProcess;

    /**
     * 研判标签 多个用,隔开
     */
    @TableField(value = "judge_tag")
    @ApiModelProperty(value = "研判标签")
    private String judgeTag;

    /**
     * 处置后续流程节点 默认all 全部流程; follow 后续跟进; audit 审核; 多个节点可以用,隔开
     */
    @TableField(value = "deal_sub_node")
    @ApiModelProperty(value = "处置后续流程节点")
    private String dealSubNode;
}