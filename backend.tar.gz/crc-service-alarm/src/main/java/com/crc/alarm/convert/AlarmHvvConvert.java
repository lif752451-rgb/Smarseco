package com.crc.alarm.convert;

import com.crc.alarm.model.dto.AlarmHvvExportDTO;
import com.crc.alarm.model.response.AlarmHvvExportResponse;
import com.crc.worker.TypeConversionWorker;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import org.mapstruct.Mappings;
import org.mapstruct.factory.Mappers;

import java.util.List;

/**
 * @Author shufengfeng
 * @Description 告警请求转换类
 * @DateTime 2022/09/05 16:54
 */
@Mapper(uses = {TypeConversionWorker.class})
public interface AlarmHvvConvert {
    AlarmHvvConvert INSTANCE = Mappers.getMapper(AlarmHvvConvert.class);

    /**
     * 转换导出对象
     * @param list
     * @return
     */
    List<AlarmHvvExportDTO> convert(List<AlarmHvvExportResponse> list);


    /**
     * 转换导出对象
     * @param source
     * @return
     */
    @Mappings({
            @Mapping(target = "behaviorNature", expression = "java(com.crc.common.constant.enums.AlarmBehaviorNatureEnum.getEnum(source.getBehaviorNature()))"),
            @Mapping(target = "judgeTimeConsuming", expression = "java(com.crc.common.utils.DateUtils.getUsedTime(source.getJudgeTimeConsuming()))"),
            @Mapping(target = "dealTimeConsuming", expression = "java(com.crc.common.utils.DateUtils.getUsedTime(source.getDealTimeConsuming()))"),
            @Mapping(target = "archiveTimeConsuming", expression = "java(com.crc.common.utils.DateUtils.getUsedTime(source.getArchiveTimeConsuming()))"),
            @Mapping(target = "operationLog", expression = "java(com.crc.alarm.utils.AlarmHvvExportUtils.convertOperationLog(source))"),
            @Mapping(target = "createTime", source = "createTime", qualifiedByName = "doFormatDateTime"),
            @Mapping(target = "alarmTime", source = "alarmTime", qualifiedByName = "doFormatDateTime"),
    })
    AlarmHvvExportDTO convert(AlarmHvvExportResponse source);
}
