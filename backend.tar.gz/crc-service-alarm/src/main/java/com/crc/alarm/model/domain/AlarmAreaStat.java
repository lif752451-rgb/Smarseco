package com.crc.alarm.model.domain;

import com.baomidou.mybatisplus.annotation.TableField;
import com.baomidou.mybatisplus.annotation.TableName;
import com.crc.core.model.BasicEntity;
import io.swagger.annotations.ApiModel;
import lombok.Data;
import lombok.EqualsAndHashCode;

@ApiModel(value = "每日告警信息汇总")
@Data
@EqualsAndHashCode(callSuper = true)
@TableName(value = "tb_alarm_area_stat")
public class AlarmAreaStat extends BasicEntity {

    /**
     * 常态化告警数据(normal)/攻防演练数据(作战周期名称)
     */
    @TableField(value = "type")
    private String type;

    /**
     * 攻击日期：格式yyyy-MM-dd
     */
    @TableField(value = "attack_date")
    private String attackDate;

    /**
     * 被攻击区域
     */
    @TableField(value = "area_name")
    private String areaName;

    /**
     * 被攻击子区域
     */
    @TableField(value = "sub_area_name")
    private String subAreaName;

    /**
     * 被攻击ip总数
     */
    @TableField(value = "ip_num")
    private Integer ipNum;
}
