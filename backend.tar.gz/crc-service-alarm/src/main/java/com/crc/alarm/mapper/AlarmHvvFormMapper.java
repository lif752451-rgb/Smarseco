package com.crc.alarm.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.crc.alarm.model.domain.AlarmHvvForm;
import com.crc.alarm.model.response.AlarmHvvFormResponse;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;

/**
 * 告警闭环-告警表单(hvv)Mapper
 */
@Mapper
public interface AlarmHvvFormMapper extends BaseMapper<AlarmHvvForm> {

    /**
     * 查询已审批记录
     *
     * @param businessKey 业务key
     * @param nodeName    节点名称
     * @return 告警闭环-告警表单
     */
    AlarmHvvFormResponse findAlarmHvvFormByKey(@Param("businessKey") String businessKey, @Param("nodeName") String nodeName);
}