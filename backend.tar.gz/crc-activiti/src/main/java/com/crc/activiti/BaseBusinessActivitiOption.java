package com.crc.activiti;

import cn.hutool.core.collection.CollUtil;
import com.crc.activiti.constant.VariableExpression;
import com.crc.activiti.domain.ApplyDomain;
import com.crc.activiti.domain.BusinessDealResultDomain;
import com.crc.activiti.enums.TaskExaminationExpression;
import com.crc.common.exception.CustomException;
import org.activiti.engine.task.Task;
import org.springframework.beans.factory.annotation.Autowired;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.atomic.AtomicInteger;

/**
 * Classname: BaseBusinessActivitiOption
 * Description:业务基类
 * Author: cymiao
 * Date: 2021/5/24 19:57
 **/
public abstract class BaseBusinessActivitiOption <T extends ApplyDomain>{

    @Autowired(required = false)
    protected BaseActivitiOption activitiOption;

    /**
     *发起一个流程
     * @param businessKey
     * @param variables
     * @return
     */
    public String startProcess(String businessKey,String processKey,Map<String, Object> variables){
        return activitiOption.startProcessInstance(processKey,businessKey,variables);
    }


    /**
     *发起一个流程
     * @param businessKeys
     * @param variables
     * @return
     */
    public void startProcess(List<String> businessKeys,String processKey,Map<String, Object> variables){
        for (String businessKey : businessKeys) {
            activitiOption.startProcessInstance(processKey,businessKey,variables);
        }
    }

    /**
     * 查询用户代办任务
     * @param userName
     * @return
     */
    public List<Task> findUserTask(String userName){
        List<Task> userTasks = activitiOption.findUserTasks(userName);
        return userTasks;
    }

    /**
     * 根据任务ID和userName在任务中移除
     * @param taskId
     * @param userName
     */
    public void removeCandidateUser(String taskId,String userName){
        activitiOption.removeCandidateUser(taskId,userName);
    }

    /**
     * 根据任务ID添加候选人
     * @param taskId
     * @param userName
     */
    public void addCandidateUser(String taskId,String userName){
        activitiOption.addCandidateUser(taskId,userName);
    }

    /**
     * 查询任务列表
     * @param businessKey
     * @return
     */
    public List<Task> findTaskByBusinessKey(String businessKey){
        List<Task> task = activitiOption.findTaskByBusinessKey(businessKey);
        return task;
    }

    /**
     * 查询用户代办任务
     * @param userName
     * @return
     */
    public List<Task> findUserTask(String processKey, String userName){
        //查询候选人和受让人时当前用户的任务
        List<Task> userTasks = activitiOption.findUserTasks(processKey,userName);

        //查询当前用户所归属的用户组的任务
        List<String> rolesAndGroups = new ArrayList<>();
        rolesAndGroups.addAll(queryUserBelongUserGroups(userName));
        rolesAndGroups.addAll(queryUserRoles(userName));
        List<Task> roleAndPeopleGroupTasks = activitiOption.findRoleAndPeopleGroupTasks(processKey, rolesAndGroups);
        userTasks.addAll(roleAndPeopleGroupTasks);
        return userTasks;
    }

    /**
     * 根据taskId获取Task
     * @param taskId
     * @return
     */
    public List<Task> findUserTaskByTaskId(String taskId){
        return activitiOption.findUserTaskByTaskId(taskId);
    }

    /**
     * 发起人撤回流程
     * @param businessKey
     */
    public void startUserBackUp(String businessKey,String userName){
        List<Task> taskList = activitiOption.findTaskByBusinessKey(businessKey);
        if(null != taskList && !taskList.isEmpty()){
            String processDefinitionId = taskList.get(0).getProcessInstanceId();
            activitiOption.startUserBackUp(processDefinitionId,userName,"撤回已推送但还未操作的风险单");
        }
    }


    /**
     * 发起人撤回流程
     * @param taskList 任务集合
     * @param userName 用户名
     * @param reason 原因
     */
    public int startUserBackUp(List<Task> taskList,String userName, String reason){
        AtomicInteger count = new AtomicInteger(0);
        if(CollUtil.isNotEmpty(taskList)){
            taskList.forEach(task -> {
                String processDefinitionId = task.getProcessInstanceId();
                activitiOption.startUserBackUp(processDefinitionId,userName,reason);
                count.getAndIncrement();
            });
        }
        return count.get();
    }

    /**
     * 根据业务key查找任务
     * @param businessKeys
     * @return
     */
    public List<Task> findByBusinessKeys(List<String> businessKeys){
        return activitiOption.findTaskByBusinessKey(businessKeys);
    }

    /**
     * 处理节点任务
     * @param taskId
     * @param dealResultDomain
     * @return
     */
    public String dealApply(String taskId,BusinessDealResultDomain dealResultDomain,Map<String,Object> variables){
        String processInstanceId = "";
        try {
            processInstanceId = activitiOption.findProcessInstanceIdByTaskId(taskId);
        }catch (Exception e){
            throw new CustomException("任务已被处理或不存在",20017);
        }
        String businesskey = activitiOption.findBusinesskeyByProcessInstanceId(processInstanceId);
        String dealResult = dealResultDomain.getDealResult();
        if(null == dealResult || "".equals(dealResult) ||
                (!TaskExaminationExpression.DEAL_RESULT_RETURN_PREVIOUS_NODE.getValue().equals(dealResult) &&
                        !TaskExaminationExpression.DEAL_RESULT_RETURN_HISTORY_NODE.getValue().equals(dealResult) &&
                        !TaskExaminationExpression.DEAL_RESULT_RETURN_START.getValue().equals(dealResult) &&
                        !TaskExaminationExpression.DEAL_RESULT_PASS.getValue().equals(dealResult) &&
                        !TaskExaminationExpression.DEAL_RESULT_FAIL.getValue().equals(dealResult) &&
                        !TaskExaminationExpression.DEAL_RESULT_BACK_UP.getValue().equals(dealResult))){
            throw new CustomException("业务处理参数错误",20009);
        }
        if(null == variables){
            variables = new HashMap<>();
        }
        variables.put("dealResult",dealResult);

        if(TaskExaminationExpression.DEAL_RESULT_RETURN_HISTORY_NODE.getValue().equals(dealResult)){
            String returnNodeCode = dealResultDomain.getReturnHistoryNodeCode();
            if(null == returnNodeCode || "".equals(returnNodeCode)){
                throw new CustomException("业务处理参数错误",20009);
            }
            variables.put(VariableExpression.RETURN_HISTORY_NODE_CONDITION,returnNodeCode);
        }

        activitiOption.taskComplete(taskId,dealResultDomain.getDealUser(),variables);
        return businesskey;
    }

    public void claim(String taskId, String examineUser) {
        activitiOption.claim(taskId, examineUser);
    }

    public void taskComplete(String taskId, String examineUser, Map<String,Object> variables){
        activitiOption.taskComplete(taskId, examineUser, variables);
    }

    /**
     * 查询businessKey
     * @param taskId
     * @return
     */
    public String findBusinessKey(String taskId){
        String processInstanceId = activitiOption.findProcessInstanceIdByTaskId(taskId);
        return activitiOption.findBusinesskeyByProcessInstanceId(processInstanceId);
    }

    /**
     * 查询用户归属的所有用户组
     * @param userName
     * @return
     */
    protected abstract List<String> queryUserBelongUserGroups(String userName);

    /**
     * 查询用户角色
     * @param userName
     * @return
     */
    protected abstract List<String> queryUserRoles(String userName);

    /**
     * 通过用户组编号，查询用户组成员
     * @param peopleGroupCode
     * @return
     */
    protected abstract List<String> queryPeopleGroupInfo(String peopleGroupCode);



    /**
     * 查询转办任务
     * @param businessKey
     * @param transferUser
     * @return
     */
    protected abstract List<String> queryTransferTask(String businessKey,String transferUser);
}
