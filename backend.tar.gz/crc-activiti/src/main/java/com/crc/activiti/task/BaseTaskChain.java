package com.crc.activiti.task;

import com.crc.activiti.entry.TaskNodeEntity;
import com.crc.activiti.enums.TaskExaminationExpression;
import com.crc.activiti.enums.TaskNodeOperationModeType;
import com.crc.activiti.listener.ActivitiListenerFactory;
import lombok.Setter;
import org.activiti.bpmn.model.CustomProperty;
import org.activiti.bpmn.model.MultiInstanceLoopCharacteristics;
import org.activiti.bpmn.model.UserTask;

import java.util.ArrayList;
import java.util.List;

/**
 * Classname:BaseTaskChain
 * Description:
 * Author: cymiao
 * Date: 2021/6/7 10:52
 **/
@Setter
public abstract class BaseTaskChain implements ITaskChain{

    protected ITaskChain nextTaskChain;

    protected ActivitiListenerFactory listenerFactory;

    @Override
    public void decorateUserTask(UserTask task, TaskNodeEntity taskNode) {
        if(null != nextTaskChain){
            this.nextTaskChain.decorateUserTask(task, taskNode);
        }else{
            throw new RuntimeException("任务节点类型错误");
        }
    }

    /**
     * 责任链下一个节点
     * @param taskChainImpl
     */
    public void setNextTaskChain(ITaskChain taskChainImpl) {
        this.nextTaskChain = taskChainImpl;
    }

    /**
     * 节点任务审核类型处理
     * @param task
     * @param taskNode
     */
    protected void decorateUserTaskOperationModeType(UserTask task, TaskNodeEntity taskNode){
        if(TaskNodeOperationModeType.JOINTLY.getType().equals(taskNode.getOperationMode())){
            createCustomProperty(task,"jointlyRatio",String.valueOf(taskNode.getJointlyRatio()));

            task.setTaskListeners(listenerFactory.findJointlySingTaskListeners());
            task.setLoopCharacteristics(createLoopCharacteristics());
        }else if (TaskNodeOperationModeType.OR.getType().equals(taskNode.getOperationMode())){
            task.setTaskListeners(listenerFactory.findOrSingTaskListeners());
        }else {
            throw new RuntimeException("任务节点操作模型错误");
        }
    }

    /**
     * 节点任务设置扩展属性
     * @param task
     * @param name
     * @param value
     */
    protected void createCustomProperty(UserTask task,String name,String value){
        List<CustomProperty> customProperties = task.getCustomProperties();
        if(null == customProperties){
            customProperties = new ArrayList<>();
        }

        CustomProperty customProperty = new CustomProperty();
        customProperty.setName(name);
        customProperty.setSimpleValue(value);
        customProperties.add(customProperty);
        task.setCustomProperties(customProperties);
    }

    private MultiInstanceLoopCharacteristics createLoopCharacteristics(){
        MultiInstanceLoopCharacteristics loopCharacteristics = new MultiInstanceLoopCharacteristics();
        loopCharacteristics.setSequential(false);
        loopCharacteristics.setElementVariable("signer");
        loopCharacteristics.setInputDataItem("signList");
        loopCharacteristics.setCompletionCondition(TaskExaminationExpression.DEAL_RESULT_FAIL.getExpression());
        return loopCharacteristics;
    }
}
