package com.crc.activiti;

import com.crc.activiti.entry.ProcessEntity;

/**
 * Classname: IActivitiOption
 * Description:
 * Author: cymiao
 * Date: 2021/5/31 14:51
 **/
public interface IActivitiOption {
    /**
     * 发布一个流程
     * @param processInfo
     */
    void deployProcess(ProcessEntity processInfo);
}
