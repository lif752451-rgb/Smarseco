package com.crc.activiti.enums;

/**
 * Classname: EndEventId
 * Description: 结束事件类型
 * Author: cymiao
 * Date: 2021/5/26 16:04
 **/
public enum EndEventId {
    /**
     * 正常结束事件Id
     */
    NORMAL_END("normalEnd"),

    /**
     * 异常结束事件Id
     */
    ABNORMAL_END("abnormalEnd");
    private String id;
    EndEventId(String id){
        this.id = id;
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }
}
