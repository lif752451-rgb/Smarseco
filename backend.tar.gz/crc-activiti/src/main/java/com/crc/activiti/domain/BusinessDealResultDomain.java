package com.crc.activiti.domain;

import com.baomidou.mybatisplus.annotation.TableField;
import lombok.Data;

import java.util.List;

/**
 * Classname: BusinessDealResultDomain
 * Description:
 * Author: cymiao
 * Date: 2021/5/27 19:49
 **/
@Data
public class BusinessDealResultDomain {

    /**
     * 节点处理结果：pass-通过，fail-不通过
     */
    @TableField("deal_result")
    private String dealResult;

    /**
     * 指定下一个节点处理人
     */
    @TableField(exist = false)
    private List<String> nextTaskNodeDealPerson;

    /**
     * 处理人
     */
    @TableField("deal_user")
    private String dealUser;

    @TableField(exist = false)
    private String returnHistoryNodeCode;
}
