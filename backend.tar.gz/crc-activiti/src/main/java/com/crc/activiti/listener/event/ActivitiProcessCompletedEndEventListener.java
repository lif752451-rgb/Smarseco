package com.crc.activiti.listener.event;

import com.crc.activiti.enums.TaskExaminationExpression;
import com.crc.activiti.message.ActivitiProcessCompletedMessage;
import com.google.common.eventbus.EventBus;
import lombok.Setter;
import org.activiti.engine.RuntimeService;
import org.activiti.engine.delegate.event.ActivitiEvent;
import org.activiti.engine.delegate.event.ActivitiEventListener;
import org.activiti.engine.delegate.event.ActivitiEventType;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

/**
 * Classname: ActivitiEndEventListener
 * Description:流程结束事件监听
 * Author: cymiao
 * Date: 2021/5/24 19:33
 **/
@Setter
@Component("processCompletedEndEventListener")
public class ActivitiProcessCompletedEndEventListener implements ActivitiEventListener {

    /*@Autowired(required = false)
    private IBusinessActivitiOption businessActivitiOption;*/

    private RuntimeService runtimeService;

    @Autowired
    private EventBus eventBus;

    @Override
    public void onEvent(ActivitiEvent activitiEvent) {
        //流程结束更新业务状态
        if(activitiEvent.getType() == ActivitiEventType.PROCESS_COMPLETED){
            String processInstanceId = activitiEvent.getProcessInstanceId();
            String taskResult = (String) runtimeService.getVariable(activitiEvent.getExecutionId(), TaskExaminationExpression.EXAMINATION_PASS.getKey());

            ActivitiProcessCompletedMessage message = new ActivitiProcessCompletedMessage();
            message.setProcessInstanceId(processInstanceId);
            message.setRuntimeService(runtimeService);
            message.setDealResult(taskResult);
            eventBus.post(message);
        }
    }

    @Override
    public boolean isFailOnException() {
        return false;
    }
}
