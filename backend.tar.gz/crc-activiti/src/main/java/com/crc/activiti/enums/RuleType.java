package com.crc.activiti.enums;

/**
 * Classname: RuleType
 * Description:节点规则类型
 * Author: cymiao
 * Date: 2021/5/26 11:35
 **/
public enum RuleType {
    /**
     * 默认分支
     */
    DEFAULT("default"),

    /**
     * 条件分支
     */
    CONDITION("condition"),

    /**
     * 正常任务节点
     */
    NORMAL("normal");

    private String type;

    RuleType(String type){
        this.type = type;
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }
}
