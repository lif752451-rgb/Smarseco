package com.crc.activiti.listener.or;

import com.crc.activiti.enums.TaskExaminationExpression;
import org.activiti.engine.ProcessEngine;
import org.activiti.engine.ProcessEngines;
import org.activiti.engine.RuntimeService;
import org.activiti.engine.delegate.DelegateTask;
import org.activiti.engine.delegate.TaskListener;

/**
 * Classname: OrSingTaskListener
 * Description:
 * Author: cymiao
 * Date: 2021/5/25 17:24
 **/
public class OrSingTaskListener implements TaskListener{
    @Override
    public void notify(DelegateTask delegateTask) {
        //获取流程id
        String exId = delegateTask.getExecutionId();

        //获取流程参数dealResult，会签人员完成自己的审批任务时会添加流程参数pass，false为拒绝，true为同意
        ProcessEngine engine = ProcessEngines.getDefaultProcessEngine();
        RuntimeService runtimeService = engine.getRuntimeService();
        String dealResult = (String)runtimeService.getVariable(exId, TaskExaminationExpression.DEAL_RESULT_PASS.getKey());

        runtimeService.setVariable(exId, TaskExaminationExpression.EXAMINATION_PASS.getKey(), dealResult);
        runtimeService.setVariable(exId, delegateTask.getExecution().getCurrentActivityId(),dealResult);
    }
}
