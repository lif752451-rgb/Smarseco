package com.crc.activiti.listener.jointly;

import org.activiti.bpmn.model.ActivitiListener;
import org.activiti.bpmn.model.ImplementationType;
import org.activiti.engine.delegate.TaskListener;
import org.springframework.stereotype.Component;

import javax.annotation.PostConstruct;

/**
 * Classname: JointlySingActivitiListenner
 * Description:任务节点complete事件监听
 * Author: cymiao
 * Date: 2021/5/25 23:52
 **/
@Component("jointlySingCompleteActivitiListener")
public class JointlySingCompleteActivitiListener extends ActivitiListener {

    @PostConstruct
    private void init(){
        //设置事件类型
        this.setEvent(TaskListener.EVENTNAME_COMPLETE);

        this.setImplementationType(ImplementationType.IMPLEMENTATION_TYPE_CLASS);

        this.setImplementation("com.crc.activiti.listener.jointly.JointlySingTaskListener");
    }
}
