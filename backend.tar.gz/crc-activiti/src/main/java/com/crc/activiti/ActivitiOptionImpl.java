package com.crc.activiti;

import cn.hutool.core.collection.CollUtil;
import com.crc.activiti.constant.VariableExpression;
import com.crc.activiti.entry.ProcessEntity;
import com.crc.activiti.entry.TaskNodeEntity;
import com.crc.activiti.enums.EndEventId;
import com.crc.activiti.enums.RuleType;
import com.crc.activiti.enums.TaskExaminationExpression;
import com.crc.activiti.enums.TaskNodeType;
import com.crc.activiti.listener.ActivitiListenerFactory;
import com.crc.activiti.task.ITaskChain;
import lombok.extern.slf4j.Slf4j;
import org.activiti.bpmn.converter.BpmnXMLConverter;
import org.activiti.bpmn.model.Process;
import org.activiti.bpmn.model.*;
import org.activiti.engine.*;
import org.activiti.engine.repository.ProcessDefinition;
import org.activiti.engine.runtime.ProcessInstance;
import org.activiti.engine.task.Task;
import org.activiti.validation.ProcessValidator;
import org.activiti.validation.ProcessValidatorFactory;
import org.activiti.validation.ValidationError;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;

import java.io.UnsupportedEncodingException;
import java.util.*;
import java.util.stream.Collectors;

/**
 * Classname: ActivitiOption
 * Description:activiti操作实现
 * Author: cymiao
 * Date: 2021/5/24 19:35
 **/
@Slf4j
public class ActivitiOptionImpl extends BaseActivitiOption implements IActivitiOption{

    @Autowired
    private RepositoryService repositoryService;

    @Autowired
    private RuntimeService runtimeService;

    @Autowired
    private HistoryService historyService;

    @Autowired
    private TaskService taskService;

    @Autowired
    private ITaskChain taskChain;

    /**
     * 发布流程
     * @param processInfo
     */
    @Override
    public void deployProcess(ProcessEntity processInfo) {
        BpmnModel bpmnModel = new BpmnModel();
        bpmnModel.addProcess(createProcess(processInfo));

        //验证Bpmn文件的可用性
        ProcessValidatorFactory processValidatorFactory = new ProcessValidatorFactory();
        ProcessValidator processValidator = processValidatorFactory.createDefaultProcessValidator();
        List<ValidationError> validate = processValidator.validate(bpmnModel);
        if(validate.size()>=1){
            throw new RuntimeException("流程配置项错误，审核流不可用");
        }

        BpmnXMLConverter bpmnXMLConverter = new BpmnXMLConverter();
        try {
            String e = new String(bpmnXMLConverter.convertToXML(bpmnModel), "UTF-8");
            System.out.println(e);
        } catch (UnsupportedEncodingException var5) {
            throw new ActivitiException("Error while transforming BPMN model to xml: not UTF-8 encoded", var5);
        }

        //创建一个部署对象
        repositoryService.createDeployment()
                .addBpmnModel(processInfo.getProcessKey() + ".bpmn",bpmnModel)
                .name(processInfo.getProcessName())
                .deploy();
    }

    /**
     * 查询工作流程的具体配置
     * @param processKey
     * @return
     */
    @Override
    public ProcessEntity findProcess(String processKey){
        //通过流程Key获取流程定义对象
        ProcessDefinition definition = repositoryService
                .createProcessDefinitionQuery()
                .processDefinitionKey(processKey)
                .latestVersion()
                .singleResult();

        if(null == definition){
            throw new RuntimeException("未找到可使用的流程");
        }

        //获取流程下的所有节点
        List<FlowElement> flowElements = (List<FlowElement>) repositoryService
                .getBpmnModel(definition.getId())
                .getProcesses()
                .get(0)
                .getFlowElements();

        //反向解析
        ProcessEntity processInfo = new ProcessEntity();
        bpmnBackwardAnalysis(flowElements,processInfo);
        return processInfo;
    }

    /**
     * 创建一个流程实例
     * @param processKey
     * @param businessKey
     * @param variables
     * @return
     */
    @Override
    public String startProcessInstance(String processKey, String businessKey, Map<String,Object> variables){
        ProcessInstance pi = runtimeService
                .startProcessInstanceByKey(processKey,businessKey,variables);
        return pi.getProcessInstanceId();
    }

    /**
     * 查询用户待办任务
     * @param processKey
     * @param userName
     * @return
     */
    @Override
    protected List<Task> findUserTasks(String processKey, String userName){
        if(null == userName || "".equals(userName)){
            return Collections.EMPTY_LIST;
        }
        List<Task> tasks = taskService
                .createTaskQuery()
                .processDefinitionKey(processKey)
                .taskCandidateOrAssigned(userName)
                .list();
        return tasks;
    }

    /**
     * 根据业务key查询task任务
     * @param businessKey
     * @return
     */
    @Override
    protected List<Task> findTaskByBusinessKey(String businessKey){
        return taskService
            .createTaskQuery()
            .processInstanceBusinessKey(businessKey)
            .list();
    }

    /**
     * 根据业务key查询task任务
     * @param businessKeys
     * @return
     */
    @Override
    protected List<Task> findTaskByBusinessKey(List<String> businessKeys){
        if(CollUtil.isEmpty(businessKeys)){
            return null;
        }
        String str = "'"+ CollUtil.join(businessKeys,"','")+"'";
        String sql = "select * from ACT_RU_TASK where business_key_ in ("+str+")";
        return taskService
                .createNativeTaskQuery().sql(sql).list();
    }

    /**
     * 发起人撤回流程
     * @param processDefinitionId
     */
    @Override
    protected void startUserBackUp(String processDefinitionId, String userName, String reason) {
        StringBuilder builder = new StringBuilder();
        builder.append(userName)
                .append("_")
                .append(reason);
        runtimeService.deleteProcessInstance(processDefinitionId,builder.toString());
    }

    /**
     * 通过任务ID查询任务信息
     * @param taskId
     * @return
     */
    @Override
    protected List<Task> findUserTaskByTaskId(String taskId){
        return taskService
            .createTaskQuery()
            .taskId(taskId)
            .list();
    }

    /**
     * 查询用户待办任务
     * @param userName
     * @return
     */
    @Override
    protected List<Task> findUserTasks(String userName){
        if(null == userName || "".equals(userName)){
            return Collections.EMPTY_LIST;
        }
        List<Task> tasks = taskService
            .createTaskQuery()
            .taskCandidateOrAssigned(userName)
            .list();
        return tasks;
    }

    /**
     * 查询当前用户角色和归属用户组的所有任务
     * @param processKey
     * @param codes
     * @return
     */
    @Override
    protected List<Task> findRoleAndPeopleGroupTasks(String processKey, List<String> codes){
        if(null == codes || codes.isEmpty()){
            return Collections.EMPTY_LIST;
        }
        List<Task> tasks = taskService
                .createTaskQuery()
                .processDefinitionKey(processKey)
                .taskCandidateGroupIn(codes)
                .list();
        return tasks;
    }

    @Override
    protected void claim(String taskId, String examineUser) {
        taskService.claim(taskId, examineUser);
    }

    /**
     * 节点任务处理完成
     * @param taskId
     * @param examineUser
     * @param variables
     */
    @Override
    protected void taskComplete(String taskId, String examineUser, Map<String,Object> variables){
        try {
            taskService.claim(taskId, examineUser);
        } catch (Exception e) {
            log.error(e.getMessage(),e);
        }
        taskService.complete(taskId, variables);
    }

    /**
     * 通过任务taskId获取流程实例ID
     * @param taskId 节点任务ID
     * @return
     */
    @Override
    protected String findProcessInstanceIdByTaskId(String taskId){
        String processInstanceId = taskService
                .createTaskQuery()
                .taskId(taskId)
                .singleResult()
                .getProcessInstanceId();
        return processInstanceId;
    }

    /**
     * 通过工作流实例ID获取业务主键
     * @param processInstanceId
     * @return
     */
    @Override
    protected String findBusinesskeyByProcessInstanceId(String processInstanceId){
        String businesskey = runtimeService.
                createProcessInstanceQuery()
                .processInstanceId(processInstanceId)
                .singleResult()
                .getBusinessKey();
        return businesskey;
    }

    /**
     * 根据任务ID和userName在任务中移除
     * @param taskId
     * @param userName
     */
    @Override
    protected void removeCandidateUser(String taskId, String userName){
        taskService.deleteCandidateUser(taskId,userName);
    }

    /**
     * 根据任务ID添加候选人
     * @param taskId
     * @param userName
     */
    @Override
    protected void addCandidateUser(String taskId, String userName){
        taskService.addCandidateUser(taskId,userName);
    }

    /**
     * 创建Process:自定义数据结构向activiti数据结构转换
     * @param processInfo
     * @return
     */
    private Process createProcess(ProcessEntity processInfo){
        /**
         * 基本业务校验
         */
        if(processInfo.getTaskNodes() == null || processInfo.getTaskNodes().isEmpty()){
            throw new RuntimeException("发布流程必须包含任务节点");
        }

        Process process = new Process();

        //设置流程唯一标识
        process.setId(processInfo.getProcessKey());

        //设置流程名称
        process.setName(processInfo.getProcessName());

        //添加开始事件
        FlowElement startEvent = createStartEvent();
        process.addFlowElement(startEvent);

        //添加正常结束事件
        FlowElement endEvent = createEndEvent(EndEventId.NORMAL_END.getId(),"结束");
        process.addFlowElement(endEvent);

        //添加审核不通过结束事件
        FlowElement abnormalEndEvent = createEndEvent(EndEventId.ABNORMAL_END.getId(),"异常结束");
        process.addFlowElement(abnormalEndEvent);

        //创建条件网关
        String exclusiveGateGatewayId = createExclusiveGatewayId(startEvent.getId());
        ExclusiveGateway conditionExclusiveGateway = createExclusiveGateway("条件判断网关",exclusiveGateGatewayId);

        ParallelGateway parallelGateway = null;

        /**
         * 从第一个任务节点开始处理
         */
        List<TaskNodeEntity> firstTaskNodes = findFirstTaskNode(processInfo.getTaskNodes());
        if(null == firstTaskNodes || firstTaskNodes.isEmpty()){
            throw new RuntimeException("流程任务节点配置异常");
        }
        //检查是否走条件分支，是：创建java任务节点计算网关条件
        if(checkIsCondition(firstTaskNodes)){
            process.addFlowElement(conditionExclusiveGateway);
            createCalculationConditionTask(process,conditionExclusiveGateway,startEvent,firstTaskNodes,"");
        }
        else if (firstTaskNodes.size() > 1){
            //创建并行网关
            String parallelGatewayId = createParallelGatewayId(startEvent.getId());
            parallelGateway = createParallelGateway("并行网关", parallelGatewayId);
            process.addFlowElement(parallelGateway);
            //创建连线：流程开始节点到并行网关的连线
            String flowId = createFlowId(startEvent.getId(), parallelGatewayId);
            genarateSequenceFlow(process,flowId,"网关",startEvent.getId(),parallelGatewayId,"");
        } else {
            process.addFlowElement(conditionExclusiveGateway);
            //创建连线:流程开始节点到条件网关的连线
            String flowId = createFlowId(startEvent.getId(),conditionExclusiveGateway.getId());
            genarateSequenceFlow(process,flowId,"网关",startEvent.getId(),conditionExclusiveGateway.getId(),"");
        }

        ParallelGateway finalParallelGateway = parallelGateway;
        firstTaskNodes.forEach(firstTaskNode -> {
            if(TaskNodeType.NODE_OPERATIONS.getType().equals(firstTaskNode.getTaskNodeType())){
                throw new RuntimeException("首节点配置异常");
            }

            //创建所有分支
            List<String> previousNodeCodes = new ArrayList<>();
            previousNodeCodes.add(VariableExpression.START_NODE_CODE);
            if (checkIsCondition(firstTaskNodes) || firstTaskNodes.size() == 1) {
                relationTaskAndFlow(process,conditionExclusiveGateway,firstTaskNode,processInfo.getTaskNodes(),new ArrayList<>(),null,previousNodeCodes);
            } else {
                relationTaskAndFlow(process, finalParallelGateway,firstTaskNode,processInfo.getTaskNodes(),new ArrayList(){{
                    add(startEvent);}},null,previousNodeCodes);
            }
        });

        return process;
    }

    /**
     * 关联任务节点
     * @param currentTaskNode
     * @param taskNodes
     */
    private void relationTaskAndFlow(Process process,Gateway previousGateway,TaskNodeEntity currentTaskNode,
        List<TaskNodeEntity> taskNodes,List<TaskNodeEntity> parallelTaskNodes,String previousNodesConditionValue,List<String> previousNodeCodes){
        String flowId = "";
        SequenceFlow sequenceFlow = null;
        Boolean isParallelEnd = Boolean.FALSE;
        //与当前节点平行的节点
        List<TaskNodeEntity> currentTaskNodes = null;
        //当前节点的前序节点
        List<TaskNodeEntity> currentPreviousNodes = new ArrayList<>();
        Map<List<String>, List<TaskNodeEntity>> currentPreviousNodesMap = new HashMap<>();

        /**
         * 当前节点为invented虚拟节点,则后续节点为条件节点或者空分支
         * 当前虚拟节点按照条件网关处理
         */
        if(TaskNodeType.INVENTED.getType().equals(currentTaskNode.getTaskNodeType())){
            //处理后续节点
            relationTaskAndFlowNext(process,previousGateway,currentTaskNode,taskNodes,parallelTaskNodes,previousNodesConditionValue,previousNodeCodes);
            return;
        }
        //查找与当前节点平行的节点
        currentTaskNodes = findNextTaskNodes(currentTaskNode.getPreviousTaskNode().get(0), taskNodes);
        /**
         * 当前节点是一个normal节点
         * 当前节点有多个前序节点时,并且并行节点集合parallelTaskNodes不为空
         * 当前节点的多个前序节点有共同的前序节点
         * 则当前节点为并行分支的结束节点，并行节点前需要添加一个并行网关
         */
        if (!currentTaskNode.getPreviousTaskNode().contains(VariableExpression.START_NODE_CODE)) {
            for (String taskNode : currentTaskNode.getPreviousTaskNode()) {
                currentPreviousNodes.add(findTaskNode(taskNode, taskNodes));
            }
            currentPreviousNodesMap = currentPreviousNodes.stream().collect(Collectors.groupingBy(TaskNodeEntity::getPreviousTaskNode));
        }
        if(null != currentTaskNode.getPreviousTaskNode() &&
                currentTaskNode.getPreviousTaskNode().size()>1 &&
                currentPreviousNodes.size() > 0 &&
                currentPreviousNodesMap.size() == 1 &&
            !parallelTaskNodes.isEmpty()){
            isParallelEnd = Boolean.TRUE;
            String gatewayId = createParallelGatewayId(currentTaskNode.getPreviousTaskNode().toArray(new String[0]));
            FlowElement flowElement = process.getFlowElement(gatewayId);
            ParallelGateway parallelGateway = null;

            if(null == flowElement){
                parallelGateway = createParallelGateway("合并并行网关",gatewayId);
                process.addFlowElement(parallelGateway);
            } else {
                parallelGateway = (ParallelGateway) flowElement;
            }
            //根据当前节点类型进行不同的处理方案
            //当前节点是并行节点的处理：
            if (RuleType.NORMAL.getType().equals(currentTaskNode.getRuleType()) && currentTaskNodes.size() > 1) {
                //移除当前已经处理的并行分支节点
                parallelTaskNodes.remove(parallelTaskNodes.size() - 1);
                //创建接下来的并行网关
                gatewayId = createParallelGatewayId(parallelGateway.getId());
                FlowElement nextFlowElement = process.getFlowElement(gatewayId);
                ParallelGateway nextParallelGateway = null;
                if (null == nextFlowElement) {
                    nextParallelGateway = createParallelGateway("分发并行网关", createParallelGatewayId(parallelGateway.getId()));
                    //连接并行结束网关到当前并行网关
                    flowId = createParallelGatewayId(parallelGateway.getId(), nextParallelGateway.getId());
                    if (null == process.getFlowElement(flowId)) {
                        genarateSequenceFlow(process,flowId,"",
                                parallelGateway.getId(),nextParallelGateway.getId(),"");
                    }
                    process.addFlowElement(nextParallelGateway);
                } else {
                    nextParallelGateway = (ParallelGateway) nextFlowElement;
                }
                //连接并行网关到当前节点
                flowId = createParallelGatewayId(nextParallelGateway.getId(), currentTaskNode.getTaskNodeCode());
                if (null == process.getFlowElement(flowId)) {
                    genarateSequenceFlow(process,flowId,"",
                            nextParallelGateway.getId(),currentTaskNode.createTaskId(),"");
                }
                parallelTaskNodes.add(currentTaskNode);
            } else {
                //当前节点是条件节点的处理
                if (RuleType.CONDITION.getType().equals(currentTaskNode.getRuleType()) || RuleType.DEFAULT.getType().equals(currentTaskNode.getRuleType())) {
                    //创建条件网关
                    ExclusiveGateway conditionExclusiveGateway = null;
                    String id = createConditionExclusiveGatewayId(currentTaskNodes.stream().map(TaskNodeEntity::getTaskNodeCode).collect(Collectors.toList()));
                    FlowElement exclusiveFlowElement = process.getFlowElement(id);
                    //flowElement为null表示当前条件分支是第一次到达
                    if(null == exclusiveFlowElement){
                        conditionExclusiveGateway = createExclusiveGateway("条件判断网关",id);
                        process.addFlowElement(conditionExclusiveGateway);
                    }else{
                        conditionExclusiveGateway = (ExclusiveGateway) exclusiveFlowElement;
                    }
                    //1.创建serviceTask
                    //2.连接并行节点到serviceTask
                    //3.连接serviceTask到条件网关
                    createCalculationConditionTask(process,conditionExclusiveGateway,parallelGateway,currentTaskNodes,"");
                    //4.连接条件网关到当前节点
                    flowId = createFlowId(conditionExclusiveGateway.getId(),currentTaskNode.getTaskNodeCode());
                    if (null == process.getFlowElement(flowId)) {
                        sequenceFlow = genarateSequenceFlow(process,flowId,"",
                                conditionExclusiveGateway.getId(),currentTaskNode.createTaskId(),currentTaskNode.conditionExpression(previousNodesConditionValue));
                        conditionExclusiveGateway.getOutgoingFlows().add(sequenceFlow);
                    }
                }
                //当前节点是普通节点的处理：关联并行网关到当前节点
                else {
                    flowId = createFlowId(parallelGateway.getId(),currentTaskNode.getTaskNodeCode());
                    if (null == process.getFlowElement(flowId)) {
                        genarateSequenceFlow(process,flowId,"",
                                parallelGateway.getId(),currentTaskNode.createTaskId(),"");
                    }
                }
            }

            //关联前序条件网关到并行网关:审核通过时到达
            flowId = createFlowId(previousGateway.getId(),parallelGateway.getId());
            if (null == process.getFlowElement(flowId)) {
                sequenceFlow = genarateSequenceFlow(process, flowId, "",
                        previousGateway.getId(), parallelGateway.getId(), TaskExaminationExpression.EXAMINATION_PASS.getExpression());
                previousGateway.getOutgoingFlows().add(sequenceFlow);
                //如果是条件网关添加default
                if(null == sequenceFlow.getConditionExpression() && previousGateway instanceof ExclusiveGateway){
                    previousGateway.setDefaultFlow(flowId);
                }
            }
            if (!RuleType.NORMAL.getType().equals(currentTaskNode.getRuleType()) || currentTaskNodes.size() == 1) {
                //移除当前已经处理的并行分支节点
                parallelTaskNodes.remove(parallelTaskNodes.size() - 1);
            }
        }
        /**
         * 处理上一个网关节点到当前任务节点的关联
         * 关联上一个网关到当前节点：创建网关到节点的条件连线
         */
        else{
            //关联前序条件网关到当前节点
            flowId = createFlowId(previousGateway.getId(),currentTaskNode.createTaskId());
            FlowElement flowElement = process.getFlowElement(flowId);
            if(null == flowElement){
                if (previousGateway instanceof ParallelGateway) {
                    genarateSequenceFlow(process, flowId, "",
                            previousGateway.getId(), currentTaskNode.createTaskId(), "");
                } else {
                    sequenceFlow = genarateSequenceFlow(process, flowId, "",
                            previousGateway.getId(), currentTaskNode.createTaskId(), currentTaskNode.conditionExpression(previousNodesConditionValue));
                    previousGateway.getOutgoingFlows().add(sequenceFlow);
                    //如果是条件网关添加default
                    if(null == sequenceFlow.getConditionExpression() && previousGateway instanceof ExclusiveGateway){
                        previousGateway.setDefaultFlow(flowId);
                    }
                }
            }else{
                //当前节点有多个有条件的上节点时，当前条件节点的条件需要对多个条件做或处理
                if(RuleType.CONDITION.getType().equals(currentTaskNode.getRuleType()) ||
                    RuleType.DEFAULT.getType().equals(currentTaskNode.getRuleType())){
                    sequenceFlow = (SequenceFlow) flowElement;
                    String newExpression = createNewConditionExpression(sequenceFlow.getConditionExpression(),currentTaskNode.conditionValue(previousNodesConditionValue));
                    sequenceFlow.setConditionExpression(newExpression);
                }
            }
        }

        //创建任务处理结束网关
        Gateway exclusiveGateway = null;
        if (isParallelEnd && (currentTaskNodes.size() == 1 || !RuleType.NORMAL.getType().equals(currentTaskNode.getRuleType()))) {
            String gateGatewayId = createInclusiveGatewayId(currentTaskNode.getTaskNodeCode());
            FlowElement flowElement = process.getFlowElement(gateGatewayId);
            if(null == flowElement){
                exclusiveGateway = createInclusiveGateway("包容网关", gateGatewayId);
                process.addFlowElement(exclusiveGateway);
            }else{
                exclusiveGateway = (InclusiveGateway) flowElement;
            }
        } else {
            String gateGatewayId = createExclusiveGatewayId(currentTaskNode.getTaskNodeCode());
            FlowElement flowElement = process.getFlowElement(gateGatewayId);
            if(null == flowElement){
                exclusiveGateway = createExclusiveGateway("条件网关", gateGatewayId);
                process.addFlowElement(exclusiveGateway);
            }else{
                exclusiveGateway = (ExclusiveGateway) flowElement;
            }
        }

        //节点处理结果类型为返回上一个节点
        dealCurrentNodeReturnPreviousNode(process,exclusiveGateway,currentTaskNode,taskNodes,previousNodesConditionValue,previousNodeCodes);

        //节点处理结果类型为返回自选上节点
        dealCurrentNodeReturnHistoryNode(process,exclusiveGateway,currentTaskNode,taskNodes,previousNodesConditionValue,previousNodeCodes);
        /**
         * 创建当前节点Task任务
         * 当前节点存在，则当前节点为并行任务结束节点或者多条件分支的合并节点
         * 当前节点以后任务节点相同
         */
        UserTask userTask = (UserTask) process.getFlowElement(currentTaskNode.createTaskId());
        if(null == userTask){
            userTask = createUserTask(currentTaskNode);
            process.addFlowElement(userTask);

            //关联当前节点到条件网关：创建当前节点到条件网关的连线
            flowId = createFlowId(currentTaskNode.getTaskNodeCode(),exclusiveGateway.getId());
            genarateSequenceFlow(process,flowId,"到达分支",currentTaskNode.createTaskId(),exclusiveGateway.getId(),"");

            //关联条件网关到异常结束事件节点:节点处理审核不通过
            flowId = createFlowId(exclusiveGateway.getId(),EndEventId.ABNORMAL_END.getId(),TaskExaminationExpression.EXAMINATION_FAIL.getValue());
            sequenceFlow = genarateSequenceFlow(process,flowId,"异常结束",exclusiveGateway.getId(),EndEventId.ABNORMAL_END.getId(), TaskExaminationExpression.EXAMINATION_FAIL.getExpression());
            exclusiveGateway.getOutgoingFlows().add(sequenceFlow);

            //关联条件网关到异常结束事件节点:节点返回发起者操作
            flowId = createFlowId(exclusiveGateway.getId(),EndEventId.ABNORMAL_END.getId(),TaskExaminationExpression.EXAMINATION_RETURN_START.getValue());
            sequenceFlow = genarateSequenceFlow(process,flowId,"异常结束",exclusiveGateway.getId(),EndEventId.ABNORMAL_END.getId(), TaskExaminationExpression.EXAMINATION_RETURN_START.getExpression());
            exclusiveGateway.getOutgoingFlows().add(sequenceFlow);
        }

        relationTaskAndFlowNext(process, exclusiveGateway,currentTaskNode, taskNodes,parallelTaskNodes,previousNodesConditionValue,previousNodeCodes);
    }

    /**
     * 节点处理结果类型为返回上一个节点
     * 1、有前序节点返回上一个节点
     * 2、没有前序接节点流程结束，更新业务状态
     */
    private void dealCurrentNodeReturnPreviousNode(Process process,Gateway exclusiveGateway,TaskNodeEntity currentTaskNode,
        List<TaskNodeEntity> taskNodes,String previousNodesConditionValue,List<String> previousTaskNodeCodes){
        String previousTaskNodeCode = null;
        String returnedConditionValue = previousNodesConditionValue;
        for(int size=previousTaskNodeCodes.size(),i=size-1; i > -1;i--){
            String nodeCode = previousTaskNodeCodes.get(i);

            //上一个节点是开始节点
            if(VariableExpression.START_NODE_CODE.equals(nodeCode)){
                previousTaskNodeCode = nodeCode;
                break;
            }
            TaskNodeEntity taskNode = findTaskNode(nodeCode,taskNodes);

            //上一个节点是虚拟节点
            if(TaskNodeType.INVENTED.getType().equals(taskNode.getTaskNodeType())){
                //当前节点经过多个条件分支
                returnedConditionValue = calculationConditionValue(taskNode,returnedConditionValue);
                continue;
            }else{
                previousTaskNodeCode = nodeCode;
                break;
            }
        }

        dealReturnNode(process,exclusiveGateway,taskNodes,currentTaskNode.getTaskNodeCode(),
            currentTaskNode.returnPreviousConditionExpression(previousNodesConditionValue),previousTaskNodeCode,returnedConditionValue);
    }

    /**
     * 返回指定的历史节点
     * @param process
     * @param exclusiveGateway
     * @param currentTaskNode
     * @param taskNodes
     * @param previousNodesConditionValue
     * @param previousTaskNodeCodes
     */
    private void dealCurrentNodeReturnHistoryNode(Process process,Gateway exclusiveGateway,TaskNodeEntity currentTaskNode,
        List<TaskNodeEntity> taskNodes,String previousNodesConditionValue,List<String> previousTaskNodeCodes){

        String returnedConditionValue = previousNodesConditionValue;
        for(int size=previousTaskNodeCodes.size(),i=size-1; i > -1;i--){
            String nodeCode = previousTaskNodeCodes.get(i);
            if(VariableExpression.START_NODE_CODE.equals(nodeCode)){
                dealReturnNode(process,exclusiveGateway,taskNodes,currentTaskNode.getTaskNodeCode(),
                    returnHistoryConditionExpression(nodeCode),nodeCode,returnedConditionValue);
                continue;
            }

            TaskNodeEntity taskNode = findTaskNode(nodeCode,taskNodes);
            if(TaskNodeType.INVENTED.getType().equals(taskNode.getTaskNodeType())){
                returnedConditionValue = calculationConditionValue(taskNode,returnedConditionValue);
                continue;
            }

            dealReturnNode(process,exclusiveGateway,taskNodes,currentTaskNode.getTaskNodeCode(),
                returnHistoryConditionExpression(nodeCode),nodeCode,returnedConditionValue);

            if(!RuleType.NORMAL.getType().equals(taskNode.getRuleType())){
                returnedConditionValue = calculationConditionValue(taskNode,returnedConditionValue);
            }
        }
    }

    /**
     * 返回历时审核节点
     * @param retuenTaskNodeId
     * @return
     */
    private String returnHistoryConditionExpression(String retuenTaskNodeId){
        StringBuilder expression = new StringBuilder();
        expression.append("${")
                .append(TaskExaminationExpression.EXAMINATION_RETURN_HISTORY_NODE.getExpressionValue())
                .append(" && ")
                .append(VariableExpression.RETURN_HISTORY_NODE_CONDITION)
                .append(" == '")
                .append(retuenTaskNodeId)
                .append("'}");
        return expression.toString();
    }

    /**
     * 计算返回上一个节点的条件值
     * @param taskNode
     * @param returnedConditionValue
     * @return
     */
    private String calculationConditionValue(TaskNodeEntity taskNode,String returnedConditionValue){
        if(!RuleType.NORMAL.getType().equals(taskNode.getRuleType())){
            if(returnedConditionValue.indexOf("#") > 0){
                int num = returnedConditionValue.lastIndexOf("#" + taskNode.getCondition().getPriority());
                returnedConditionValue = returnedConditionValue.substring(0,num);
            }else{
                returnedConditionValue = "";
            }
        }
        return returnedConditionValue;
    }

    /**
     * 处理返回节点
     * @param process
     * @param exclusiveGateway
     * @param taskNodes
     * @param currentTaskNodeCode
     * @param returnConditionExpression
     * @param previousTaskNodeCode
     * @param previousNodesConditionValue
     */
    private void dealReturnNode(Process process,Gateway exclusiveGateway,List<TaskNodeEntity> taskNodes,String currentTaskNodeCode,
        String returnConditionExpression,String previousTaskNodeCode,String previousNodesConditionValue){
        if(null == previousTaskNodeCode){
            throw new RuntimeException("数据配置异常");
        }

        //有效返回节点是开始节点
        if(VariableExpression.START_NODE_CODE.equals(previousTaskNodeCode)){
            dealFirstNodeReturnPreviousNode(process, exclusiveGateway,returnConditionExpression);
        }
        //中间节点返回上一个节点
        else{
            //创建还原条件表达式值的Java任务
            ServiceTask task = createReturnPreviousServiceTask(process,currentTaskNodeCode,previousTaskNodeCode,previousNodesConditionValue);

            String flowId = createFlowId(exclusiveGateway.getId(),previousTaskNodeCode);
            SequenceFlow sequenceFlow = (SequenceFlow) process.getFlowElement(flowId);
            if(null == sequenceFlow){
                //关联当前节点的条件网关到java任务节点
                sequenceFlow = genarateSequenceFlow(process,flowId,"返回上一个节点",exclusiveGateway.getId(),
                        task.getId(),returnConditionExpression);
                exclusiveGateway.getOutgoingFlows().add(sequenceFlow);

                //关联java任务节点到返回的节点
                TaskNodeEntity previousTaskNode = findTaskNode(previousTaskNodeCode, taskNodes);
                flowId = createFlowId(task.getId(),previousTaskNode.getTaskNodeCode());
                genarateSequenceFlow(process,flowId,"还原表达式值",task.getId(),previousTaskNode.createTaskId(),"");
            }else{
                String conditionExpression = sequenceFlow.getConditionExpression();
                String returnConditionExpressionValue = returnConditionExpression.substring(2,returnConditionExpression.length() - 1);
                if(conditionExpression.indexOf(returnConditionExpressionValue) < 0){
                    conditionExpression = newExpression(conditionExpression,returnConditionExpressionValue);
                    sequenceFlow.setConditionExpression(conditionExpression);
                }
            }
        }
    }

    /**
     * 计算新表达式
     * @param oldExpression
     * @param newValue
     * @return
     */
    private String newExpression(String oldExpression,String newValue){
        StringBuffer expression = new StringBuffer();
        expression.append(oldExpression);
        expression.deleteCharAt(oldExpression.length() - 1);
        expression.append(" || ")
            .append(newValue)
            .append("}");
        return expression.toString();
    }

    /**
     * 返回首节点
     * @param process
     * @param exclusiveGateway
     */
    private void dealFirstNodeReturnPreviousNode(Process process,Gateway exclusiveGateway,String expression){
        //关联第一个任务节点到异常结束节点:首节点返回上一个节点操作
        String flowId = createFlowId(exclusiveGateway.getId(),EndEventId.ABNORMAL_END.getId(),VariableExpression.START_NODE_CODE);
        FlowElement flowElement = process.getFlowElement(flowId);
        if(null == flowElement){
            SequenceFlow sequenceFlow = genarateSequenceFlow(process,flowId,"异常结束",exclusiveGateway.getId(),EndEventId.ABNORMAL_END.getId(), expression);
            exclusiveGateway.getOutgoingFlows().add(sequenceFlow);
        }else{
            SequenceFlow sequenceFlow = (SequenceFlow) flowElement;
            String conditionExpression = sequenceFlow.getConditionExpression();
            String conditionExpressionValue = expression.substring(2,expression.length() - 1);
            if(conditionExpression.indexOf(conditionExpressionValue) < 0){
                conditionExpression = newExpression(conditionExpression,conditionExpressionValue);
                sequenceFlow.setConditionExpression(conditionExpression);
            }
        }

        //关联第一个任务节点到异常结束节点：首节点撤回操作
        flowId = createFlowId(exclusiveGateway.getId(),EndEventId.ABNORMAL_END.getId(),TaskExaminationExpression.EXAMINATION_BACK_UP.getValue());
        flowElement = process.getFlowElement(flowId);
        if(null == flowElement){
            SequenceFlow sequenceFlow = genarateSequenceFlow(process,flowId,"异常结束",exclusiveGateway.getId(),EndEventId.ABNORMAL_END.getId(), TaskExaminationExpression.EXAMINATION_BACK_UP.getExpression());
            exclusiveGateway.getOutgoingFlows().add(sequenceFlow);
        }
    }

    /**
     * 关联当前节点后续任务节点
     * @param process
     * @param exclusiveGateway
     * @param currentTaskNode
     * @param taskNodes
     */
    private void relationTaskAndFlowNext(Process process,Gateway exclusiveGateway,TaskNodeEntity currentTaskNode,
        List<TaskNodeEntity> taskNodes,List<TaskNodeEntity> parallelTaskNodes,String previousNodesConditionValue,List<String> previousNodeCodes){
        String flowId = null;
        SequenceFlow sequenceFlow = null;
        List<TaskNodeEntity> nextTaskNodes = findNextTaskNodes(currentTaskNode.getTaskNodeCode(), taskNodes);
        List<TaskNodeEntity> currentTaskNodes = findNextTaskNodes(currentTaskNode.getPreviousTaskNode().get(0), taskNodes);
        //有后续节点则为中间节点
        if(nextTaskNodes != null && !nextTaskNodes.isEmpty()){
            Gateway currentGateway = exclusiveGateway;
            List<String> newPreviousNodeCodes = null;
            List<TaskNodeEntity> nextParallelTaskNodes = null;
            //如果当前节点不是并行节点的结束节点
            if (!(RuleType.NORMAL.getType().equals(currentTaskNode.getRuleType()) &&
                    currentTaskNodes.size() > 1 &&
                    parallelTaskNodes.size() > 0
                    )
            ) {
                /**
                 * 后续节点为条件节点
                 */
                if(checkIsCondition(nextTaskNodes)){
                    ExclusiveGateway conditionExclusiveGateway = null;

                    //创建条件网关
                    String id = createConditionExclusiveGatewayId(nextTaskNodes.get(0).getPreviousTaskNode());
                    FlowElement flowElement = process.getFlowElement(id);

                    //flowElement为null表示当前条件分支是第一次到达
                    if(null == flowElement){
                        conditionExclusiveGateway = createExclusiveGateway("条件判断网关",id);
                        process.addFlowElement(conditionExclusiveGateway);
                    }else{
                        conditionExclusiveGateway = (ExclusiveGateway) flowElement;
                    }

                    if(TaskNodeType.INVENTED.getType().equals(currentTaskNode.getTaskNodeType())){
                        //当前节点是虚拟节点，实际流程中不需要审核，所以当前网关到下一个节点（java任务节点）不需要添加条件
                        createCalculationConditionTask(process,conditionExclusiveGateway,currentGateway,nextTaskNodes,currentTaskNode.conditionExpression(previousNodesConditionValue));
                    }else{
                        //当前节点是正常节点，当前网关到下一个节点（java任务节点）需要添加审核通过条件
                        createCalculationConditionTask(process,conditionExclusiveGateway,currentGateway,nextTaskNodes,TaskExaminationExpression.EXAMINATION_PASS.getExpression());
                    }

                    //当前条件网关变更为条件分支网关
                    currentGateway = conditionExclusiveGateway;
                }
                /**
                 * 后续节点有多个并且后续节点不是条件节点时
                 * 则当前节点为并行分支节点
                 * 需要在当前节点的条件网关后添加一个并行网关
                 */
                else if(nextTaskNodes.size() > 1){
                    exclusiveGateway = currentGateway;
                    String gatewayId = createParallelGatewayId(exclusiveGateway.getId());
                    FlowElement flowElement = process.getFlowElement(gatewayId);
                    //创建并行网关
                    ParallelGateway parallelGateway = null;
                    if (null == flowElement) {
                        parallelGateway = createParallelGateway("分发并行网关", createParallelGatewayId(exclusiveGateway.getId()));
                        process.addFlowElement(parallelGateway);
                    } else {
                        parallelGateway = (ParallelGateway) flowElement;
                    }
                    currentGateway = parallelGateway;

                    //关联条件网关到并行网关
                    flowId = createFlowId(exclusiveGateway.getId(),parallelGateway.getId());

                    if (null == process.getFlowElement(flowId)) {
                        sequenceFlow = genarateSequenceFlow(process, flowId, "", exclusiveGateway.getId(), parallelGateway.getId(), currentTaskNode.conditionExpression(previousNodesConditionValue));
                        exclusiveGateway.getOutgoingFlows().add(sequenceFlow);
                        //如果是条件网关添加default
                        if(null == sequenceFlow.getConditionExpression() && exclusiveGateway instanceof ExclusiveGateway){
                            exclusiveGateway.setDefaultFlow(flowId);
                        }
                    }
                    parallelTaskNodes.add(currentTaskNode);
                }else if(TaskNodeType.INVENTED.getType().equals(currentTaskNode.getTaskNodeType())){
                    TaskNodeEntity taskNode = nextTaskNodes.get(0);
                    flowId = createFlowId(exclusiveGateway.getId(),taskNode.createTaskId());
                    FlowElement flowElement = process.getFlowElement(flowId);
                    if(null == flowElement){
                        sequenceFlow = genarateSequenceFlow(process,flowId,"",exclusiveGateway.getId(),taskNode.createTaskId(),currentTaskNode.conditionExpression(previousNodesConditionValue));
                        exclusiveGateway.getOutgoingFlows().add(sequenceFlow);
                    }else{
                        sequenceFlow = (SequenceFlow) flowElement;
                        String newExpression = createNewConditionExpression(sequenceFlow.getConditionExpression(),currentTaskNode.conditionValue(previousNodesConditionValue));
                        sequenceFlow.setConditionExpression(newExpression);
                    }

                    newPreviousNodeCodes = new ArrayList<>(previousNodeCodes);
                    newPreviousNodeCodes.add(currentTaskNode.getTaskNodeCode());
                    nextParallelTaskNodes = new ArrayList<>(parallelTaskNodes);

                    relationTaskAndFlow(process,exclusiveGateway,taskNode,taskNodes,nextParallelTaskNodes,
                            currentTaskNode.conditionValue(previousNodesConditionValue),newPreviousNodeCodes);
                    return;
                }
            }

            for(TaskNodeEntity taskNode : nextTaskNodes){
                //每个分支维护自己的并行分支节点集合
                newPreviousNodeCodes = new ArrayList<>(previousNodeCodes);
                newPreviousNodeCodes.add(currentTaskNode.getTaskNodeCode());

                nextParallelTaskNodes = new ArrayList<>(parallelTaskNodes);
                relationTaskAndFlow(process, currentGateway, taskNode, taskNodes,nextParallelTaskNodes,
                    currentTaskNode.conditionValue(previousNodesConditionValue),newPreviousNodeCodes);
            }
        }
        //当前节点没有后续节点，则当前节点latest节点
        else{
            //关联条件网关到正常结束事件节点
            flowId = createFlowId(exclusiveGateway.getId(),EndEventId.NORMAL_END.getId());
            FlowElement flowElement = process.getFlowElement(flowId);
            if(null == flowElement && !TaskNodeType.INVENTED.getType().equals(currentTaskNode.getTaskNodeType())){
                sequenceFlow = genarateSequenceFlow(process, flowId, "正常结束", exclusiveGateway.getId(), EndEventId.NORMAL_END.getId(), TaskExaminationExpression.EXAMINATION_PASS.getExpression());
                exclusiveGateway.getOutgoingFlows().add(sequenceFlow);
            }else if(null == flowElement && TaskNodeType.INVENTED.getType().equals(currentTaskNode.getTaskNodeType())){
                sequenceFlow = genarateSequenceFlow(process, flowId, "正常结束", exclusiveGateway.getId(), EndEventId.NORMAL_END.getId(), currentTaskNode.conditionExpression(previousNodesConditionValue));
                exclusiveGateway.getOutgoingFlows().add(sequenceFlow);
            }else if(null != flowElement && TaskNodeType.INVENTED.getType().equals(currentTaskNode.getTaskNodeType())){
                sequenceFlow = (SequenceFlow) flowElement;
                String newConditionExpression = createNewConditionExpression(sequenceFlow.getConditionExpression(), currentTaskNode.conditionValue(previousNodesConditionValue));
                sequenceFlow.setConditionExpression(newConditionExpression);
            }
        }
    }

    /**
     * 筛选当前节点的所有后续节点
     * @param taskNodecode
     * @param taskNodes
     * @return
     */
    private List<TaskNodeEntity> findNextTaskNodes(String taskNodecode,List<TaskNodeEntity> taskNodes){
        return taskNodes.parallelStream().filter(taskNode -> {
            if(taskNode.getPreviousTaskNode() != null && taskNode.getPreviousTaskNode().contains(taskNodecode)){
                return true;
            }

            return false;
        }).collect(Collectors.toList());
    }

    /**
     * 发现流程中的开始任务节点
     * @param taskNodes
     * @return
     */
    private List<TaskNodeEntity> findFirstTaskNode(List<TaskNodeEntity> taskNodes){
        if(null == taskNodes || taskNodes.isEmpty()){
            throw new RuntimeException("发布流程必须包含任务节点");
        }

        List<TaskNodeEntity> firstTaskNode = taskNodes.parallelStream().filter(taskNodeEntity -> {
            List<String> previousTaskNode = taskNodeEntity.getPreviousTaskNode();
            if (null != previousTaskNode &&
                previousTaskNode.size() == 1 &&
                VariableExpression.START_NODE_CODE.equals(previousTaskNode.get(0))) {
                return true;
            }
            return false;
        }).collect(Collectors.toList());

        if(null == firstTaskNode || firstTaskNode.isEmpty()){
            throw new RuntimeException("发布流程任务节点信息异常");
        }

        return firstTaskNode;
    }

    /**
     * 发现子流程中的第后一个任务节点
     * @param taskNodes
     * @return
     */
    private TaskNodeEntity findLastTaskNode(List<TaskNodeEntity> taskNodes){
        if(null == taskNodes || taskNodes.isEmpty()){
            throw new RuntimeException("发布流程必须包含任务节点");
        }

        List<TaskNodeEntity> lastTaskNode = taskNodes.parallelStream().filter(taskNodeEntity -> {
            List<TaskNodeEntity> nextTaskNodes = findNextTaskNodes(taskNodeEntity.getTaskNodeCode(), taskNodes);
            if (null == nextTaskNodes || nextTaskNodes.isEmpty()) {
                return true;
            }
            return false;
        }).collect(Collectors.toList());

        if(null == lastTaskNode || lastTaskNode.isEmpty() || lastTaskNode.size() != 1){
            throw new RuntimeException("发布流程任务节点信息异常");
        }

        return lastTaskNode.get(0);
    }

    /**
     * 根据节点code查询节点
     * @param taskNodeCode
     * @param taskNodes
     * @return
     */
    private TaskNodeEntity findTaskNode(String taskNodeCode,List<TaskNodeEntity> taskNodes){
        if(null == taskNodes || taskNodes.isEmpty()){
            throw new RuntimeException("发布流程必须包含任务节点");
        }
        TaskNodeEntity taskNodeEntity = taskNodes.stream().filter(taskNode -> {
            if (taskNodeCode.equals(taskNode.getTaskNodeCode())) {
                return true;
            }
            return false;
        }).findFirst().get();
        return taskNodeEntity;
    }

    /**
     * 反向解析bpmn文件：将activiti数据结构转换为自定义数据结构
     * @param flowElements
     * @param processInfo
     */
    private void bpmnBackwardAnalysis(List<FlowElement> flowElements,ProcessEntity processInfo){
        throw new RuntimeException("暂未实现");
    }

    /**
     * 开始任务节点
     * @return
     */
    private StartEvent createStartEvent(){
        StartEvent startEvent = new StartEvent();
        startEvent.setName(VariableExpression.START_NODE_NAME);
        startEvent.setId(VariableExpression.START_NODE_CODE);
        return startEvent;
    }

    /**
     * 结束任务节点
     * @param id
     * @param name
     * @param
     * @return
     */
    private EndEvent createEndEvent(String id, String name){
        EndEvent endEvent = new EndEvent();
        endEvent.setName(name);
        endEvent.setId(id);
        return  endEvent;
    }

    /**
     * 创建条件网关
     * @param name
     * @param id
     * @return
     */
    private ExclusiveGateway createExclusiveGateway(String name, String id){
        ExclusiveGateway exclusiveGateway = new ExclusiveGateway();
        exclusiveGateway.setName(name);
        exclusiveGateway.setId(id);
        return exclusiveGateway;
    }

    /**
     * 创建平行网关
     * @param name
     * @param id
     * @return
     */
    private ParallelGateway createParallelGateway(String name, String id){
        ParallelGateway parallelGateway = new ParallelGateway();
        parallelGateway.setName(name);
        parallelGateway.setId(id);
        return parallelGateway;
    }

    private InclusiveGateway createInclusiveGateway(String name, String id){
        InclusiveGateway inclusiveGateway = new InclusiveGateway();
        inclusiveGateway.setName(name);
        inclusiveGateway.setId(id);
        return inclusiveGateway;
    }

    /**
     * 节点间连线
     * @param id
     * @param name
     * @param sourceRef
     * @param tartgetRef
     * @param conditionExpression
     * @param process
     * @return
     */
    private SequenceFlow genarateSequenceFlow(Process process, String id, String name, String sourceRef, String tartgetRef, String conditionExpression) {
        SequenceFlow sequenceFlow = new SequenceFlow(sourceRef,tartgetRef);
        sequenceFlow.setId(id);
        if(name != null && !name.equals("")){
            sequenceFlow.setName(name);
        }
        sequenceFlow.setSourceFlowElement(process.getFlowElement(sourceRef));
        sequenceFlow.setTargetFlowElement(process.getFlowElement(tartgetRef));
        if(conditionExpression !=null && !conditionExpression.equals("")){
            sequenceFlow.setConditionExpression(conditionExpression);
        }

        process.addFlowElement(sequenceFlow);
        return sequenceFlow;
    }

    @Autowired
    ActivitiListenerFactory listenerFactory;

    /**
     * 创建任务节点
     * @param taskNode
     * @return
     */
    private UserTask createUserTask(TaskNodeEntity taskNode){
        UserTask task = new UserTask();
        taskChain.decorateUserTask(task,taskNode);
        return task;
    }

    /**
     * 创建连线Id
     * @param previousNodeCode
     * @param nextNodeCode
     * @return
     */
    private String createFlowId(String previousNodeCode,String nextNodeCode,String ... classifications){
        StringBuilder builder = new StringBuilder();
        builder.append("FlowFrom_")
            .append(previousNodeCode)
            .append("_To_")
            .append(nextNodeCode);

        if(null != classifications && classifications.length > 0){
            for(String str : classifications){
                builder.append("_")
                    .append(str);
            }
        }
        return builder.toString();
    }

    /**
     * 创建条件网关Id
     * @param fromTaskNodeCode
     * @return
     */
    private String createExclusiveGatewayId(String fromTaskNodeCode){
        StringBuilder builder = new StringBuilder();
        builder.append(fromTaskNodeCode)
            .append(VariableExpression.GATEWAY_ID_SUFFIX);
        return builder.toString();
    }

    /**
     * 创建并行网关id
     * @param fromGateWayId
     * @return
     */
    private String createParallelGatewayId(String ...fromGateWayId){
        StringBuilder builder = new StringBuilder();
        for(String id : fromGateWayId){
            builder.append(id);
        }

        builder.append(VariableExpression.PARALLEL_GATEWAY_ID_SUFFIX);
        return builder.toString();
    }

    /**
     * 创建包容网关Id
     * @param fromTaskNodeCode
     * @return
     */
    private String createInclusiveGatewayId(String fromTaskNodeCode){
        StringBuilder builder = new StringBuilder();
        builder.append(fromTaskNodeCode)
                .append(VariableExpression.INCLUSIVE_GATEWAY_ID_SUFFIX);
        return builder.toString();
    }

    /**
     * 检查同级节点是否是条件分支
     */
    private boolean checkIsCondition(List<TaskNodeEntity> taskNodes){
        if(null == taskNodes || taskNodes.isEmpty()){
            return false;
        }
        int conditionNum = 0;
        int normalNum = 0;
        boolean hasDefaultCondition = false;
        for(TaskNodeEntity taskNode : taskNodes){
            if(RuleType.NORMAL.getType().equals(taskNode.getRuleType())){
                normalNum++;
            }else if(RuleType.CONDITION.getType().equals(taskNode.getRuleType())){
                conditionNum++;
            }else if(RuleType.DEFAULT.getType().equals(taskNode.getRuleType())){
                conditionNum++;
                hasDefaultCondition = true;
            }
        }

        /**
         * 条件任务节点和正常任务节点不能同时存在同级任务中
         */
        if(conditionNum > 0 && normalNum > 0){
            throw new RuntimeException("流程任务节点配置异常");
        }else if(conditionNum > 0 && conditionNum < taskNodes.size()){
            throw new RuntimeException("流程任务节点配置异常");
        }else if(conditionNum > 0 && !hasDefaultCondition){
            throw new RuntimeException("流程任务节点配置异常");
        }else if(conditionNum > 0){
            return true;
        }

        return false;
    }

    /**
     * 流程中添加java任务节点
     * @param process
     * @param gateway
     * @param taskNodes
     * @param sourceFlowElement
     * @param conditionExpression
     */
    private void createCalculationConditionTask(Process process,Gateway gateway,FlowElement sourceFlowElement,List<TaskNodeEntity> taskNodes, String conditionExpression){
        ServiceTask serviceTask = createServiceTask(taskNodes);
        FlowElement flowElement = process.getFlowElement(serviceTask.getId());
        if(null == flowElement){
            process.addFlowElement(serviceTask);
        }

        //创建连线:流程当前节点到serviceTask的连线
        String flowId = createFlowId(sourceFlowElement.getId(),serviceTask.getId());
        flowElement = process.getFlowElement(flowId);
        if(null == flowElement){
            SequenceFlow sequenceFlow = genarateSequenceFlow(process, flowId, "条件表达式", sourceFlowElement.getId(), serviceTask.getId(), conditionExpression);
            if(sourceFlowElement instanceof Gateway){
                ((Gateway) sourceFlowElement).getOutgoingFlows().add(sequenceFlow);
            }
        }else{
            if (sourceFlowElement instanceof ParallelGateway || sourceFlowElement instanceof InclusiveGateway) {
                return;
            }
            SequenceFlow sequenceFlow = (SequenceFlow) flowElement;
            String oldExpression = sequenceFlow.getConditionExpression();
            String newConditionExpression = createNewConditionExpression2(oldExpression, conditionExpression);
            sequenceFlow.setConditionExpression(newConditionExpression);
        }


        //创建连线：serviceTask节点到条件网关的连线
        flowId = createFlowId(serviceTask.getId(),gateway.getId());
        flowElement = process.getFlowElement(flowId);
        if(null == flowElement){
            genarateSequenceFlow(process, flowId, "分支网关", serviceTask.getId(), gateway.getId(), "");
        }
    }

    /**
     * 创建java任务
     * @param taskNodes
     * @return
     */
    private ServiceTask createServiceTask(List<TaskNodeEntity> taskNodes){
        if(null == taskNodes || taskNodes.isEmpty()){
            throw new RuntimeException("创建java任务失败");
        }

        //按节点条件表达式优先级排序
        taskNodes.sort(new Comparator<TaskNodeEntity>() {
            @Override
            public int compare(TaskNodeEntity o1, TaskNodeEntity o2) {
                int priority1 = o1.getCondition().getPriority();
                int priority2 = o2.getCondition().getPriority();
                if(priority1 == priority2){
                    throw new RuntimeException("同级节点优先级相同");
                }else if(priority1 > priority2){
                    return 1;
                }
                return -1;
            }
        });
        List<CustomProperty> customProperties = new ArrayList<>();
        StringBuffer taskId = new StringBuffer();
        StringBuffer key = new StringBuffer();
        StringBuffer value = new StringBuffer();
        taskNodes.forEach(taskNode->{
            taskId.append(taskNode.getTaskNodeCode()).append(VariableExpression.CONDITION_GATEWAY_ID_CONNECTOR);
            key.append(taskNode.conditionKey()).append(VariableExpression.CONDITION_GATEWAY_ID_CONNECTOR);
            value.append(taskNode.calculationExpression()).append("else ");
        });

        CustomProperty expression = new CustomProperty();
        expression.setName("expression");
        expression.setSimpleValue(value.delete(value.length()-5,value.length()).toString());
        customProperties.add(expression);

        CustomProperty ConditionKey = new CustomProperty();
        ConditionKey.setName("conditionKey");
        ConditionKey.setSimpleValue(key.delete(key.length()-3,key.length()).toString());
        customProperties.add(ConditionKey);

        ServiceTask task = new ServiceTask();
        task.setImplementation(VariableExpression.CONDITION_JAVA_NODE_CLASS);
        task.setImplementationType("class");
        task.setName("计算条件表达式");
        task.setId(taskId.delete(taskId.length()-3,taskId.length()).toString());
        task.setCustomProperties(customProperties);
        return task;
    }

    /**
     *
     * @param fromNodeCode
     * @param returnNodeCode
     * @param previousNodesConditionValue
     * @return
     */
    private ServiceTask createReturnPreviousServiceTask(Process process,String fromNodeCode,String returnNodeCode,String previousNodesConditionValue){
        StringBuilder id = new StringBuilder();
        id.append(fromNodeCode).append("Return").append(returnNodeCode);
        FlowElement flowElement = process.getFlowElement(id.toString());
        ServiceTask serviceTask = null;
        List<CustomProperty> customProperties = null;
        if(null == flowElement){
            serviceTask = new ServiceTask();
            serviceTask.setId(id.toString());
            serviceTask.setImplementation(VariableExpression.RETURN_PREVIOUSCon_JAVA_NODE_CLASS);
            serviceTask.setImplementationType("class");
            process.addFlowElement(serviceTask);

            customProperties = new ArrayList<>();
            CustomProperty expression = new CustomProperty();
            expression.setName("previousNodesConditionValue");
            expression.setSimpleValue(null == previousNodesConditionValue ? "" : previousNodesConditionValue);
            customProperties.add(expression);
            serviceTask.setCustomProperties(customProperties);
        }else{
            serviceTask = (ServiceTask) flowElement;
            customProperties = serviceTask.getCustomProperties();
            CustomProperty customProperty = customProperties.get(0);
            String oldValue = customProperty.getSimpleValue();
            if(previousNodesConditionValue != null && (null == oldValue || oldValue.indexOf(previousNodesConditionValue) < 0)){
                customProperty.setSimpleValue(customProperty.getSimpleValue() + "," + previousNodesConditionValue);
            }
        }

        return serviceTask;
    }

    /**
     * 获取可有效返回的节点code
     * @param previousTaskNodeCodes
     * @param taskNodes
     * @return
     */
    private String findEffectiveReturnNode(List<String> previousTaskNodeCodes,List<TaskNodeEntity> taskNodes){

        for(int size=previousTaskNodeCodes.size(),i=size-1; i > -1;i--){
            String nodeCode = previousTaskNodeCodes.get(i);

            //上一个节点是开始节点
            if(VariableExpression.START_NODE_CODE.equals(nodeCode)){
                return nodeCode;
            }
            TaskNodeEntity taskNode = findTaskNode(nodeCode,taskNodes);

            //上一个节点是虚拟节点
            if(TaskNodeType.INVENTED.getType().equals(taskNode.getTaskNodeType())){
                continue;
            }else{
                return nodeCode;
            }
        }

        throw new RuntimeException("数据配置异常");
    }

    /**
     * 创建条件分支条件网关Id
     * @param taskNodeCodes
     * @return
     */
    private String createConditionExclusiveGatewayId(List<String> taskNodeCodes){
        StringBuffer builder = new StringBuffer();
        builder.append(StringUtils.join(taskNodeCodes,VariableExpression.CONDITION_GATEWAY_ID_CONNECTOR))
                .append(VariableExpression.CONDITION_GATEWAY_ID_SUFFIX);
        return builder.toString();
    }

    /**
     * 条件合并生产新的条件表达式
     * @param oldExpression
     * @param currentConditionValue
     * @return
     */
    private String createNewConditionExpression(String oldExpression,String currentConditionValue){
        StringBuffer newExpression = new StringBuffer();
        if(null != oldExpression && !"".equals(oldExpression)){
            newExpression
                .append(oldExpression)
                .deleteCharAt(newExpression.length() - 1).append(" || ");
        }else{
            newExpression.append("${");
        }
        newExpression
            .append(VariableExpression.CONDITION_CALCULATION_RESULT)
            .append(" == '")
            .append(currentConditionValue)
            .append("'}");
        return newExpression.toString();
    }

    /**
     * 条件合并生产新的条件表达式
     * @param oldExpression
     * @param currentConditionExpression
     * @return
     */
    private String createNewConditionExpression2(String oldExpression,String currentConditionExpression){
        StringBuffer newExpression = new StringBuffer();
        if(null != oldExpression && !"".equals(oldExpression)){
            newExpression
                    .append(oldExpression)
                    .deleteCharAt(newExpression.length() - 1).append(" || ");
        }else{
            newExpression.append("${");
        }
        newExpression.append(currentConditionExpression.substring(2));
        return newExpression.toString();
    }
}
