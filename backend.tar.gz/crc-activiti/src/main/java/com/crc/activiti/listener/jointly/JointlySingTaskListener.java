package com.crc.activiti.listener.jointly;

import com.crc.activiti.enums.TaskExaminationExpression;
import org.activiti.bpmn.model.ExtensionElement;
import org.activiti.engine.*;
import org.activiti.engine.delegate.DelegateTask;
import org.activiti.engine.delegate.TaskListener;

import java.util.List;
import java.util.Map;

/**
 * Classname: JointlySingTaskListener
 * Description:节点会签处理监听
 * Author: cymiao
 * Date: 2021/5/25 17:22
 **/
public class JointlySingTaskListener implements TaskListener {

    @Override
    public void notify(DelegateTask delegateTask) {
        //获取流程id
        String exId = delegateTask.getExecutionId();

        //
        ProcessEngine engine = ProcessEngines.getDefaultProcessEngine();
        RuntimeService runtimeService = engine.getRuntimeService();
        RepositoryService repositoryService = engine.getRepositoryService();

        //获取流程参数dealResult，会签人员完成自己的审批任务时会添加流程参数dealResult，false为拒绝，true为同意
        String dealResult = (String)runtimeService.getVariable(exId, TaskExaminationExpression.DEAL_RESULT_PASS.getKey());

        //获取当前节点会签比率
        String currentActivityId = delegateTask.getExecution().getCurrentActivityId();
        Map<String, List<ExtensionElement>> extensionElements = repositoryService.getBpmnModel(delegateTask.getProcessDefinitionId()).getFlowElement(currentActivityId).getExtensionElements();

        if(TaskExaminationExpression.DEAL_RESULT_FAIL.getValue().equals(dealResult)){
            //设置节点向下流转参数
            runtimeService.setVariable(exId, TaskExaminationExpression.EXAMINATION_FAIL.getKey(), TaskExaminationExpression.EXAMINATION_FAIL.getValue());
            runtimeService.setVariable(exId,currentActivityId,TaskExaminationExpression.EXAMINATION_FAIL.getValue());
        }else{
            Integer complete = (Integer) runtimeService.getVariable(exId, "nrOfCompletedInstances");
            Integer all = (Integer) runtimeService.getVariable(exId, "nrOfInstances");
            if((complete + 1) / all == 1){
                runtimeService.setVariable(exId, TaskExaminationExpression.EXAMINATION_PASS.getKey(), TaskExaminationExpression.EXAMINATION_PASS.getValue());
                runtimeService.setVariable(exId,currentActivityId,TaskExaminationExpression.EXAMINATION_PASS.getValue());
            }
        }
    }
}
