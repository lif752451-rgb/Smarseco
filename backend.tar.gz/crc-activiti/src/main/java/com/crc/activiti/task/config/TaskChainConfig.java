package com.crc.activiti.task.config;

import com.crc.activiti.listener.ActivitiListenerFactory;
import com.crc.activiti.task.ITaskChain;
import com.crc.activiti.task.TaskChainFactory;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

/**
 * Classname:TaskChainConfig
 * Description:
 * Author: cymiao
 * Date: 2021/6/7 16:27
 **/
@Configuration
public class TaskChainConfig {

    @Bean
    public ITaskChain createTaskChainRoleImpl(ActivitiListenerFactory listenerFactory){
        return new TaskChainFactory().getTaskChainInstance(listenerFactory);
    }
}
