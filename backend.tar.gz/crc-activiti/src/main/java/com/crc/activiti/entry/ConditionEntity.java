package com.crc.activiti.entry;

import lombok.Data;

/**
 * Classname: NumrangeEntity
 * Description:条件表达式
 * Author: cymiao
 * Date: 2021/5/24 16:35
 **/
@Data
public class ConditionEntity {

    /**
     * 操作类型：1-等于；2-大于；3-小于；4-大于等于；5-小于等于；6-介于
     */
    private String op;

    /**
     * 条件变量
     */
    private String variable;

    /**
     * 属性值
     */
    private String[] value;

    /**
     * 下限值
     */
    private String minValue;

    /**
     * 上限值
     */
    private String maxValue;

    /**
     * 计算表达式，java任务节点调用，生成分支表达式变量值
     * @return
     */
    public String calculationExpression(){
        StringBuffer builder = new StringBuffer();
        for(String val : value){
            builder.append(variable)
                    .append(".equals(\"")
                    .append(val)
                    .append("\") || ");
        }
        return builder.substring(0,builder.lastIndexOf("||"));
    }
}
