package com.crc.activiti.enums;

/**
 * Classname: JointlySignType
 * Description:会签类型
 * Author: cymiao
 * Date: 2021/5/25 17:03
 **/
public enum JointlySignType {
    /**
     * 顺序会签
     */
    ORDER("order"),

    /**
     * 任意顺序
     */
    ANY("any");
    private String type;
    JointlySignType(String type){
        this.type = type;
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }
}
