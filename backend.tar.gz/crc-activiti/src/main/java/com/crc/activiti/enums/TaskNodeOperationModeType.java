package com.crc.activiti.enums;

/**
 * Classname: TaskNodeOperationModeType
 * Description:任务节点操作模型类型
 * Author: cymiao
 * Date: 2021/5/25 17:38
 **/
public enum TaskNodeOperationModeType {
    /**
     * 会签
     */
    JOINTLY("jointly"),

    /**
     * 或签
     */
    OR("or");
    private String type;
    TaskNodeOperationModeType(String type){
        this.type = type;
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }
}
