package com.crc.activiti.enums;

/**
 * Classname: ProcessType
 * Description: 流程类型枚举
 * Author: cymiao
 * Date: 2021/5/24 18:41
 **/
public enum ProcessType {
    /**
     * 默认类型：在没有创建流程类型之前，为保证结构完整性使用default类型
     */
    DEFAULT("default"),

    /**
     * 漏洞
     */
    LOOPHOLE("loophole"),

    /**
     * 风险
     */
    RISK("risk"),

    /**
     * 威胁
     */
    THREATEN("threaten");

    String type;

    ProcessType(String type){
        this.type = type;
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }
}
