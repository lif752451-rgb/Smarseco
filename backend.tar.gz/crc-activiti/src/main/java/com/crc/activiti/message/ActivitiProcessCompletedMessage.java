package com.crc.activiti.message;

import lombok.Data;

/**
 * Classname:ActivitiProcessCompletedMessage
 * Description:流程完成的消息
 * Author: cymiao
 * Date: 2021/6/17 15:30
 **/
@Data
public class ActivitiProcessCompletedMessage extends BaseMessage{
}
