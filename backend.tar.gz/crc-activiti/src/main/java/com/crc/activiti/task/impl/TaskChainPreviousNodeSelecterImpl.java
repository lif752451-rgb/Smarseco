package com.crc.activiti.task.impl;

import com.crc.activiti.entry.TaskNodeEntity;
import com.crc.activiti.enums.TaskNodeType;
import com.crc.activiti.task.BaseTaskChain;
import com.crc.common.exception.CustomException;
import lombok.Setter;
import org.activiti.bpmn.model.UserTask;

import java.util.List;

/**
 * Classname:TaskChainPreviousNodeSelecterImpl
 * Description:节点类型为上一个节点自选的任务装饰类
 * Author: cymiao
 * Date: 2021/6/7 11:28
 **/
@Setter
public class TaskChainPreviousNodeSelecterImpl extends BaseTaskChain {

    @Override
    public void decorateUserTask(UserTask task, TaskNodeEntity taskNode) {
        if(TaskNodeType.PREVIOUS_NODE_SELECTER.getType().equals(taskNode.getTaskNodeType())){
            task.setCandidateGroups(taskNode.getPreviousTaskNode());
            decorateUserTaskOperationModeType(task, taskNode);
            List<String> taskNodeOperations = taskNode.getPreviousTaskNode();
            if(null == taskNodeOperations || taskNodeOperations.isEmpty()){
                throw new CustomException("流程节点信息异常");
            }
            for(String code : taskNodeOperations){
                createCustomProperty(task,TaskNodeType.PREVIOUS_NODE_SELECTER.getType(), code);
            }
        }else{
            super.decorateUserTask(task, taskNode);
        }
    }
}
