package com.crc.activiti.listener.or;

import org.activiti.bpmn.model.ActivitiListener;
import org.activiti.bpmn.model.ImplementationType;
import org.activiti.engine.delegate.TaskListener;
import org.springframework.stereotype.Component;

import javax.annotation.PostConstruct;

/**
 * Classname: OrSingCompleteActivitiListener
 * Description:
 * Author: cymiao
 * Date: 2021/5/26 10:00
 **/
@Component("orSingCompleteActivitiListener")
public class OrSingCompleteActivitiListener extends ActivitiListener {

    @PostConstruct
    private void init(){
        //设置事件类型
        this.setEvent(TaskListener.EVENTNAME_COMPLETE);

        this.setImplementationType(ImplementationType.IMPLEMENTATION_TYPE_CLASS);

        this.setImplementation("com.crc.activiti.listener.or.OrSingTaskListener");
    }
}
