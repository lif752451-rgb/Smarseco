package com.crc.activiti.enums;

/**
 * Classname: TaskNodeType
 * Description:任务节点操作归属类型枚举
 * Author: cymiao
 * Dae: 2021/5/24 15:49
 **/
public enum TaskNodeType {
    /**
     * 角色
     */
    ROLE("role"),

    /**
     * 具体用户
     */
    PEOPLE("people"),

    /**
     * 用户组
     */
    PEOPLE_GROUP("peopleGroup"),

    /**
     * 节点审批人
     */
    NODE_OPERATIONS("nodeOperations"),

    /**
     * 上一个节点自选
     */
    PREVIOUS_NODE_SELECTER("previousNodeSelecter"),

    /**
     * 虚拟节点
     */
    INVENTED("invented");

    String type;
    TaskNodeType(String type){
        this.type = type;
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }
}
