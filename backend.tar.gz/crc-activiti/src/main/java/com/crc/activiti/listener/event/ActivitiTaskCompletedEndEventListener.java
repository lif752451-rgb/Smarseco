package com.crc.activiti.listener.event;

import com.crc.activiti.message.ActivitiTaskCompletedMessage;
import com.google.common.eventbus.EventBus;
import lombok.Setter;
import org.activiti.engine.RuntimeService;
import org.activiti.engine.delegate.event.ActivitiEvent;
import org.activiti.engine.delegate.event.ActivitiEventListener;
import org.activiti.engine.delegate.event.ActivitiEventType;
import org.activiti.engine.delegate.event.impl.ActivitiActivityEventImpl;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

/**
 * Classname: ActivitiTaskCompletedEndEventListener
 * Description:任务节点处理完成监听
 * Author: cymiao
 * Date: 2021/6/8 9:25
 **/
@Setter
@Component("taskCompletedEndEventListener")
public class ActivitiTaskCompletedEndEventListener implements ActivitiEventListener {

    private RuntimeService runtimeService;

    @Autowired
    private EventBus eventBus;

    @Override
    public void onEvent(ActivitiEvent activitiEvent) {
        //节点结束更新节点业务状态
        if (activitiEvent.getType() == ActivitiEventType.ACTIVITY_COMPLETED) {
            ActivitiActivityEventImpl event = (ActivitiActivityEventImpl) activitiEvent;
            if ("userTask".equals(event.getActivityType())) {
                String processInstanceId = activitiEvent.getProcessInstanceId();
                String taskId = event.getActivityId();
                Object taskResult = runtimeService.getVariable(activitiEvent.getExecutionId(), taskId);

                //当前节点处理完成
                if (taskResult != null) {
                    ActivitiTaskCompletedMessage message = new ActivitiTaskCompletedMessage();
                    message.setTaskCode(findTaskNodeCode(taskId));
                    message.setProcessInstanceId(processInstanceId);
                    message.setDealResult(String.valueOf(taskResult));
                    message.setRuntimeService(runtimeService);
                    eventBus.post(message);
                }
            }
        }
    }

    @Override
    public boolean isFailOnException() {
        return false;
    }

    private String findTaskNodeCode(String taskId){
        return taskId.substring(taskId.lastIndexOf("_") + 1);
    }
}
