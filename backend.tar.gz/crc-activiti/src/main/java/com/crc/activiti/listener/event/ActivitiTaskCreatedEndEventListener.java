package com.crc.activiti.listener.event;

import com.crc.activiti.IBusinessQueryActivitiOption;
import com.crc.activiti.enums.TaskNodeType;
import com.crc.activiti.message.ActivitiTaskCreateMessage;
import com.google.common.eventbus.EventBus;
import lombok.Setter;
import org.activiti.bpmn.model.ExtensionElement;
import org.activiti.engine.RepositoryService;
import org.activiti.engine.TaskService;
import org.activiti.engine.delegate.event.ActivitiEvent;
import org.activiti.engine.delegate.event.ActivitiEventListener;
import org.activiti.engine.delegate.event.ActivitiEventType;
import org.activiti.engine.delegate.event.impl.ActivitiEntityEventImpl;
import org.activiti.engine.impl.persistence.entity.TaskEntityImpl;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

/**
 * Classname:ActivitiTaskCreatedEndEventListener
 * Description:节点被创建事件监听
 * Author: cymiao
 * Date: 2021/6/8 9:22
 **/
@Setter
@Component("taskCreatedEndEventListener")
public class ActivitiTaskCreatedEndEventListener implements ActivitiEventListener {

    private RepositoryService repositoryService;

    private TaskService taskService;

    @Autowired(required = false)
    private IBusinessQueryActivitiOption businessQueryActivitiOption;

    @Autowired
    private EventBus eventBus;

    @Override
    public void onEvent(ActivitiEvent activitiEvent) {
        if(activitiEvent.getType() == ActivitiEventType.TASK_CREATED){
            ActivitiEntityEventImpl event = (ActivitiEntityEventImpl) activitiEvent;
            TaskEntityImpl entity = (TaskEntityImpl) event.getEntity();
            Map<String, List<ExtensionElement>> extensionElements =
                repositoryService
                    .getBpmnModel(entity.getProcessDefinitionId())
                    .getFlowElement(entity.getTaskDefinitionKey())
                    .getExtensionElements();
            if(null != extensionElements && !extensionElements.isEmpty()){
                //设置上节点自选为当前节点候选人
                setUpCandidateUser(entity.getBusinessKey(),entity.getId(),TaskNodeType.PREVIOUS_NODE_SELECTER.getType(),extensionElements.get(TaskNodeType.PREVIOUS_NODE_SELECTER.getType()));

                //设置节点审核人为当前节点候选人
                setUpCandidateUser(entity.getBusinessKey(),entity.getId(),TaskNodeType.NODE_OPERATIONS.getType(),extensionElements.get(TaskNodeType.NODE_OPERATIONS.getType()));
            }

            String taskId = entity.getTaskDefinitionKey();
            ActivitiTaskCreateMessage message = new ActivitiTaskCreateMessage();
            message.setTaskCode(taskId.substring(taskId.lastIndexOf("_") + 1));
            message.setBusinessKey(entity.getBusinessKey());
            eventBus.post(message);
        }
    }

    @Override
    public boolean isFailOnException() {
        return false;
    }

    /**
     * 设置当前节点候选人
     * @param businessKey
     * @param taskId
     * @param type
     * @param extensionElements
     */
    private void setUpCandidateUser(String businessKey,String taskId,String type,List<ExtensionElement> extensionElements){
        if(null == extensionElements || extensionElements.isEmpty()){
            return;
        }
        List<String> codes = extensionElements.stream().map(extensionElement -> {
            return extensionElement.getElementText();
        }).collect(Collectors.toList());

        List<String> candidateUsers = null;
        if(TaskNodeType.PREVIOUS_NODE_SELECTER.getType().equals(type)){
            candidateUsers = businessQueryActivitiOption.querypreviousNodeSelecter(businessKey,codes);
        }else if(TaskNodeType.NODE_OPERATIONS.getType().equals(type)){
            candidateUsers = businessQueryActivitiOption.queryPreviousNodeOperations(businessKey,codes);
        }

        if(null != candidateUsers && !candidateUsers.isEmpty()){
            candidateUsers.forEach(userName->{
                taskService.addCandidateUser(taskId,userName);
            });
        }
    }
}
