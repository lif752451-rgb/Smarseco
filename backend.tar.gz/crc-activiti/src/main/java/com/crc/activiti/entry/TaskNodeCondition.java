package com.crc.activiti.entry;

import com.crc.activiti.constant.VariableExpression;
import lombok.Data;

import java.util.List;

/**
 * Classname:TaskNodeCondition
 * Description: 节点条件
 * Author: cymiao
 * Date: 2021/6/22 13:58
 **/
@Data
public class TaskNodeCondition {

    /**
     * 优先级
     */
    private int priority;

    /**
     * 条件分组
     */
    private List<ConditionGroup> conditionGroups;

    /**
     * 条件网关分支表达式
     * @return
     */
    public String getConditionExpression(String previousNodesConditionValue){
        StringBuilder expression = new StringBuilder();
        expression.append("${")
            .append(VariableExpression.CONDITION_CALCULATION_RESULT)
            .append(" == '")
            .append(currentConditionValue(previousNodesConditionValue))
            .append("'}");

        return expression.toString();
    }

    /**
     * 条件计算表达式
     * @return
     */
    public String calculationExpression(){
        if(null == conditionGroups || conditionGroups.isEmpty()){
            throw new RuntimeException("节点条件配置异常");
        }

        StringBuffer builder = new StringBuffer();
        builder.append("if(");

        if(conditionGroups.size() == 1){
            builder.append(conditionGroups.get(0).getCalculationExpression());
        }else {
            for(ConditionGroup group : conditionGroups){
                builder.append("(")
                        .append(group.getCalculationExpression())
                        .append(")||");
            }

            //删除最后一个||条件
            builder.delete(builder.length()-2,builder.length());
        }

        builder.append("){")
            .append(" return ")
            .append(priority)
            .append(";}");
        return builder.toString();
    }

    /**
     * 节点条件唯一标识
     * @return
     */
    public String conditionKey(){
        StringBuffer builder = new StringBuffer();
        if(null != conditionGroups && !conditionGroups.isEmpty()){
            for(ConditionGroup group : conditionGroups){
                builder.append(group.getConditionGroupKey())
                        .append("And");
            }
        }else {
            throw new RuntimeException("节点条件配置异常");
        }
        builder.delete(builder.length()-3,builder.length());
        return builder.toString();
    }

    /**
     * 当前节点条件表达式值
     * @param previousNodesConditionValue
     * @return
     */
    public String currentConditionValue(String previousNodesConditionValue){
        StringBuilder value = new StringBuilder();
        if(null != previousNodesConditionValue && !"".equals(previousNodesConditionValue)){
            value.append(previousNodesConditionValue)
                    .append("#");
        }
        value.append(priority);
        return value.toString();
    }
}
