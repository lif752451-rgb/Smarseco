package com.crc.activiti.listener;

import com.crc.activiti.listener.event.ActivitiProcessCompletedEndEventListener;
import com.crc.activiti.listener.event.ActivitiTaskCompletedEndEventListener;
import com.crc.activiti.listener.event.ActivitiTaskCreatedEndEventListener;
import org.activiti.bpmn.model.ActivitiListener;
import org.activiti.engine.RepositoryService;
import org.activiti.engine.RuntimeService;
import org.activiti.engine.TaskService;
import org.activiti.engine.delegate.event.ActivitiEventListener;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import javax.annotation.PostConstruct;
import java.util.ArrayList;
import java.util.List;

/**
 * Classname: TaskListenerFactory
 * Description:节点任务处理监听类工程
 * Author: cymiao
 * Date: 2021/5/25 17:25
 **/
@Component("activitiListenerFactory")
public class ActivitiListenerFactory {

    @Autowired
    private ActivitiListener jointlySingCompleteActivitiListener;

    @Autowired
    private ActivitiListener orSingCompleteActivitiListener;

    @Autowired
    private ActivitiProcessCompletedEndEventListener processCompletedEndEventListener;

    @Autowired
    private ActivitiTaskCompletedEndEventListener taskCompletedEndEventListener;

    @Autowired
    private ActivitiTaskCreatedEndEventListener taskCreatedEndEventListener;

    private List<ActivitiListener> jointlySingList = null;

    private List<ActivitiListener> orSingList = null;

    private List<ActivitiEventListener> eventListeners = null;

    @PostConstruct
    private void init(){
        //初始化会签监听集合
        jointlySingList = new ArrayList<>();
        jointlySingList.add(jointlySingCompleteActivitiListener);

        //初始化或签监听集合
        orSingList = new ArrayList<>();
        orSingList.add(orSingCompleteActivitiListener);

        //流程事件监听集合
        eventListeners = new ArrayList<>();
        eventListeners.add(processCompletedEndEventListener);
        eventListeners.add(taskCompletedEndEventListener);
        eventListeners.add(taskCreatedEndEventListener);
    }

    public List<ActivitiListener> findJointlySingTaskListeners(){
        return this.jointlySingList;
    }

    public List<ActivitiListener> findOrSingTaskListeners(){
        return this.orSingList;
    }

    public List<ActivitiEventListener> findEventListeners(){
        return eventListeners;
    }

    public void setRuntimeService(RuntimeService runtimeService){
        processCompletedEndEventListener.setRuntimeService(runtimeService);
        taskCompletedEndEventListener.setRuntimeService(runtimeService);
    }

    public void setRepositoryService(RepositoryService repositoryService){
        taskCreatedEndEventListener.setRepositoryService(repositoryService);
    }

    public void setTaskService(TaskService taskService){
        taskCreatedEndEventListener.setTaskService(taskService);
    }
}
