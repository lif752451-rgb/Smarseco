package com.crc.activiti.config;

import com.crc.activiti.ActivitiOptionImpl;
import com.crc.activiti.listener.ActivitiListenerFactory;
import com.crc.core.datasource.DynamicDataSource;
import org.activiti.engine.*;
import org.activiti.engine.impl.cfg.StandaloneProcessEngineConfiguration;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

/**
 * Classname: ActivitiConfig
 * Description: 工作流引擎配置类
 * Author: cymiao
 * Date: 2021/5/24 19:31
 **/
@Configuration
public class ActivitiConfig {

    @Autowired
    @Qualifier("dynamicDataSource")
    private DynamicDataSource dynamicDataSource;

    @Autowired
    private ActivitiListenerFactory activitiListenerFactory;

    @Bean
    public ProcessEngine processEngine(){
        StandaloneProcessEngineConfiguration configuration = (StandaloneProcessEngineConfiguration) ProcessEngineConfiguration.createStandaloneProcessEngineConfiguration();
        configuration.setDataSource(dynamicDataSource);
        configuration.setDatabaseSchemaUpdate(ProcessEngineConfiguration.DB_SCHEMA_UPDATE_TRUE);

        //添加监听
        configuration.setEventListeners(activitiListenerFactory.findEventListeners());
        ProcessEngine processEngine = configuration.buildProcessEngine();
        return processEngine;
    }

    @Bean
    public RepositoryService repositoryService(@Autowired ProcessEngine processEngine){
        RepositoryService repositoryService = processEngine.getRepositoryService();
        activitiListenerFactory.setRepositoryService(repositoryService);
        return repositoryService;
    }

    @Bean
    public RuntimeService runtimeService(@Autowired ProcessEngine processEngine){
        RuntimeService runtimeService = processEngine.getRuntimeService();
        activitiListenerFactory.setRuntimeService(runtimeService);
        return runtimeService;
    }

    @Bean
    public TaskService taskService(@Autowired ProcessEngine processEngine){
        TaskService taskService = processEngine.getTaskService();
        activitiListenerFactory.setTaskService(taskService);
        return taskService;
    }

    @Bean
    public HistoryService historyService(@Autowired ProcessEngine processEngine){
        HistoryService historyService = processEngine.getHistoryService();
        return historyService;
    }

    @Bean
    public ActivitiOptionImpl activitiOption(){
        return new ActivitiOptionImpl();
    }

}
