package com.crc.activiti.entry;

import com.crc.activiti.constant.VariableExpression;
import com.crc.activiti.enums.RuleType;
import com.crc.activiti.enums.TaskExaminationExpression;
import lombok.Data;

import java.util.List;

/**
 * Classname: TaskNodeEntity
 * Description: 任务节点描述实体
 * Author: cymiao
 * Date: 2021/5/24 15:07
 **/
@Data
public class TaskNodeEntity {

    /**
     * 节点模式：artificial-人工；system-系统；
     */
    private String taskNodeMode;

    /**
     * 任务节点类型：role-角色；
     * people-具体人;
     * peopleGroup-用户组;
     * nodeOperations-节点审批人;
     * previousNodeSelecter-上一个节点自选;
     * invented:虚拟节点
     */
    private String taskNodeType;

    /**
     * 节点操作归属
     * role:角色code集合
     * people：userName集合
     * peopleGroup：用户组code集合
     * nodeOperations：节点taskNodeCode集合
     * previousNodeSelecter：上一个节点taskNodeCode集合
     */
    private List<String> taskNodeOperations;

    /**
     *
     */
    private List<String> taskNodeShowOperations;

    /**
     * 表单编号
     */
    private String formCode;

    /**
     * 节点操作类型：jointly-会签、or-或签
     */
    private String operationMode;

    /**
     * 会签类型
     */
    private String jointlySignType;

    /**
     * 会签通过比率
     */
    private int jointlyRatio = 1;

    /**
     * 节点操作权限
     */
    private List<String> operationFunctions;

    /**
     * 节点编码
     */
    private String taskNodeCode;

    /**
     * 上一个任务节点
     */
    private List<String> previousTaskNode;

    /**
     * 节点名称
     */
    private String taskNodeName;

    /**
     * 规则类型：default-默认分支；condition-条件分支；normal-正常任务节点
     */
    private String ruleType = "normal";

    /**
     * 节点条件
     */
    private TaskNodeCondition condition;

    /**
     * 创建任务节点id
     * @return
     */
    public String createTaskId(){
        StringBuilder builder = new StringBuilder();
        builder.append("task")
/*            .append(upperFirstLatter(this.taskNodeMode))
            .append(upperFirstLatter(this.taskNodeType))*/
            .append(upperFirstLatter(this.taskNodeCode));
        return builder.toString();
    }

    /**
     * 首字母大写
     * @param letter
     * @return
     */
    private String upperFirstLatter(String letter){
        return letter.substring(0, 1).toUpperCase()+letter.substring(1).toLowerCase();
    }

    /**
     * 节点条件表达式
     * @return
     */
    public String conditionExpression(String previousNodesConditionValue){
        if(RuleType.NORMAL.getType().equals(this.ruleType)){
            if(this.getPreviousTaskNode().size() == 1 &&
                VariableExpression.START_NODE_CODE.equals(this.getPreviousTaskNode().get(0))){
                return "";
            }
            return TaskExaminationExpression.EXAMINATION_PASS.getExpression();
        }else if(RuleType.DEFAULT.getType().equals(this.ruleType) ||
            RuleType.CONDITION.getType().equals(this.ruleType)){
            return this.condition.getConditionExpression(previousNodesConditionValue);
        }else {
            throw new RuntimeException("节点规则类型错误");
        }
    }

    /**
     * 当前节点条件表达式值
     * @param previousNodesConditionValue
     * @return
     */
    public String conditionValue(String previousNodesConditionValue){
        if(RuleType.NORMAL.getType().equals(this.ruleType)){
            return previousNodesConditionValue;
        }else if(RuleType.DEFAULT.getType().equals(this.ruleType) ||
                RuleType.CONDITION.getType().equals(this.ruleType)){
            return this.condition.currentConditionValue(previousNodesConditionValue);
        }else {
            throw new RuntimeException("节点规则类型错误");
        }
    }

    /**
     * 当前节点返回上一个节点表达式
     * @param previousNodesConditionValue
     * @return
     */
    public String returnPreviousConditionExpression(String previousNodesConditionValue){
        String currentNodeConditionValue = conditionValue(previousNodesConditionValue);
        if(null == currentNodeConditionValue || "".equals(currentNodeConditionValue)){
            return TaskExaminationExpression.EXAMINATION_RETURN_PREVIOUS_NODE.getExpression();
        }
        else{
            StringBuilder expression = new StringBuilder();
            expression.append("${")
                    .append(returnPreviousConditionValue(previousNodesConditionValue))
                    .append("}");
            return expression.toString();
        }
    }

    /**
     * 当前节点返回上一个节点表达式值
     * @param previousNodesConditionValue
     * @return
     */
    public String returnPreviousConditionValue(String previousNodesConditionValue){
        StringBuilder value = new StringBuilder();
        value.append(TaskExaminationExpression.EXAMINATION_RETURN_PREVIOUS_NODE.getExpressionValue())
            .append("  && ")
            .append(VariableExpression.CONDITION_CALCULATION_RESULT)
            .append(" == '")
            .append(conditionValue(previousNodesConditionValue))
            .append("'");
        return value.toString();
    }

    /**
     * 当前节点在java任务节点计算表达式
     * @return
     */
    public String calculationExpression(){
        if(RuleType.DEFAULT.getType().equals(this.getRuleType())){
            StringBuilder expression = new StringBuilder();
            expression.append("if(1==1){ return ")
                .append(this.condition.getPriority())
                .append(";}");
            return expression.toString();
        }else {
            return this.condition.calculationExpression();
        }
    }

    /**
     * 计算条件表达式变量
     * @return
     */
    public String conditionKey(){
        if(RuleType.DEFAULT.getType().equals(this.getRuleType())){
            StringBuilder expression = new StringBuilder();
            expression.append(this.getTaskNodeCode())
                    .append("Default");
            return expression.toString();
        }else {
            return this.condition.conditionKey();
        }
    }
}
