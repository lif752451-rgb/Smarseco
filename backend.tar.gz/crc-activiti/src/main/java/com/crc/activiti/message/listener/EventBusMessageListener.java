package com.crc.activiti.message.listener;

import com.crc.activiti.IBusinessActivitiOption;
import com.crc.activiti.message.ActivitiProcessCompletedMessage;
import com.crc.activiti.message.ActivitiTaskCompletedMessage;
import com.crc.activiti.message.ActivitiTaskCreateMessage;
import com.crc.activiti.message.BaseMessage;
import com.google.common.eventbus.Subscribe;
import org.springframework.beans.factory.annotation.Autowired;

/**
 * Classname: EventBusMessageListener
 * Description:消息监听
 * Author: cymiao
 * Date: 2021/6/17 15:02
 **/
public class EventBusMessageListener {

    @Autowired(required = false)
    private IBusinessActivitiOption businessActivitiOption;

    @Subscribe
    public void dealActivitiTaskCompletedMessage(ActivitiTaskCompletedMessage message){
        businessActivitiOption.saveTaskNodeDealCompleteResult(getBusinessKey(message), message.getDealResult(), message.getTaskCode());
    }

    @Subscribe
    public void dealActivitiProcessCompletedMessage(ActivitiProcessCompletedMessage message){
        businessActivitiOption.saveProcessDealCompleteResult(getBusinessKey(message),message.getDealResult());
    }

    @Subscribe
    public void dealActivitiTaskCreateMessage(ActivitiTaskCreateMessage message){
        businessActivitiOption.saveCurrentTaskNodeStatus(message.getBusinessKey(),message.getTaskCode());
    }

    private String getBusinessKey(BaseMessage message){
        String businessKey =
            message.getRuntimeService()
                .createProcessInstanceQuery()
                .processInstanceId(message.getProcessInstanceId())
                .singleResult()
                .getBusinessKey();
        return businessKey;
    }
}
