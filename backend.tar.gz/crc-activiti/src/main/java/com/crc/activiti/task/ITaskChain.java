package com.crc.activiti.task;

import com.crc.activiti.entry.TaskNodeEntity;
import org.activiti.bpmn.model.UserTask;

/**
 * Classname:
 * Description:
 * Author: cymiao
 * Date: 2021/6/7 10:22
 **/
public interface ITaskChain {

    /**
     * 创建用户任务
     * @param taskNode
     * @return
     */
    void decorateUserTask(UserTask task,TaskNodeEntity taskNode);
}
