package com.crc.activiti.delegate;

import com.crc.activiti.constant.VariableExpression;
import org.activiti.engine.delegate.DelegateExecution;
import org.activiti.engine.delegate.Expression;
import org.activiti.engine.delegate.JavaDelegate;

/**
 * Classname:ReturnPreviousNodeExpression
 * Description:
 * Author: cymiao
 * Date: 2021/7/4 14:58
 **/
public class ReturnPreviousNodeExpression implements JavaDelegate {
    /**
     * 上节点条件表达式值的拼接字符串
     */
    private Expression previousNodesConditionValue;

    @Override
    public void execute(DelegateExecution execution) {
        if(null == previousNodesConditionValue){
            execution.setVariable(VariableExpression.CONDITION_CALCULATION_RESULT,null);
        }else{
            String expressionText = previousNodesConditionValue.getExpressionText();
            Object variable = execution.getVariable(VariableExpression.CONDITION_CALCULATION_RESULT);

            if(null != variable){
                String currentConditionValue = String.valueOf(variable);

                String[] previousConditionValues = expressionText.split(",");

                for(String conditionValue : previousConditionValues){
                    if(currentConditionValue.indexOf(conditionValue) > -1){
                        execution.setVariable(VariableExpression.CONDITION_CALCULATION_RESULT,conditionValue);
                        break;
                    }
                }
            }
        }
    }
}
