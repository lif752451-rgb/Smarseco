package com.crc.activiti.message;

import lombok.Data;
import org.activiti.engine.RuntimeService;

/**
 * Classname:BaseMessage
 * Description: 基础消息
 * Author: cymiao
 * Date: 2021/6/17 14:57
 **/
@Data
public class BaseMessage {
    /**
     * 流程实例ID
     */
    private String processInstanceId;

    /**
     * 处理结果
     */
    private String dealResult;

    private RuntimeService runtimeService;

    private String businessKey;
}
