package com.crc.activiti.task;

import com.crc.activiti.listener.ActivitiListenerFactory;
import com.crc.activiti.task.impl.*;

/**
 * Classname:TaskChainFactory
 * Description:
 * Author: cymiao
 * Date: 2021/6/7 16:30
 **/
public class TaskChainFactory {

    public ITaskChain getTaskChainInstance(ActivitiListenerFactory listenerFactory){
        TaskChainPreviousNodeSelecterImpl taskChainPreviousNodeSelecter = new TaskChainPreviousNodeSelecterImpl();
        taskChainPreviousNodeSelecter.setNextTaskChain(null);
        taskChainPreviousNodeSelecter.setListenerFactory(listenerFactory);

        TaskChainNodeOperationsImpl taskChainNodeOperations = new TaskChainNodeOperationsImpl();
        taskChainNodeOperations.setNextTaskChain(taskChainPreviousNodeSelecter);
        taskChainNodeOperations.setListenerFactory(listenerFactory);

        TaskChainPeopleGroupImpl taskChainPeopleGroup = new TaskChainPeopleGroupImpl();
        taskChainPeopleGroup.setNextTaskChain(taskChainNodeOperations);
        taskChainPeopleGroup.setListenerFactory(listenerFactory);

        TaskChainPeopleImpl taskChainPeople = new TaskChainPeopleImpl();
        taskChainPeople.setNextTaskChain(taskChainPeopleGroup);
        taskChainPeople.setListenerFactory(listenerFactory);

        TaskChainRoleImpl taskChainRole = new TaskChainRoleImpl();
        taskChainRole.setNextTaskChain(taskChainPeople);
        taskChainRole.setListenerFactory(listenerFactory);

        TaskChainDefaultImpl taskChainDefault = new TaskChainDefaultImpl();
        taskChainDefault.setNextTaskChain(taskChainRole);
        taskChainRole.setListenerFactory(listenerFactory);
        return taskChainDefault;
    }
}
