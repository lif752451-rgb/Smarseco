package com.crc.activiti.message;

import lombok.Data;

/**
 * Classname:ActivitiTaskCompletedMessage
 * Description:任务节点完成的消息
 * Author: cymiao
 * Date: 2021/6/17 14:56
 **/
@Data
public class ActivitiTaskCompletedMessage extends BaseMessage{

    /**
     * 任务节点code
     */
    private String taskCode;
}
