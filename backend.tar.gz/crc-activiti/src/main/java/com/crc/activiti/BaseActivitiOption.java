package com.crc.activiti;

import com.crc.activiti.entry.ProcessEntity;
import org.activiti.engine.task.Task;

import java.util.List;
import java.util.Map;

/**
 * Classname: IActivitiOption
 * Description:
 * Author: cymiao
 * Date: 2021/5/24 19:45
 **/
public abstract class BaseActivitiOption {

    /**
     * 查询工作流程的具体配置
     * @param processKey
     * @return
     */
    protected abstract ProcessEntity findProcess(String processKey);

    /**
     * 创建一个流程实例
     * @param processKey
     * @param businessKey
     * @param variables
     * @return
     */
    protected abstract String startProcessInstance(String processKey, String businessKey, Map<String,Object> variables);

    /**
     * 通过任务taskid获取流程实例ID
     * @param taskid
     * @return
     */
    protected abstract String findProcessInstanceIdByTaskId(String taskid);

    /**
     * 通过工作流实例ID获取业务主键
     * @param processInstanceId
     * @return
     */
    protected abstract String findBusinesskeyByProcessInstanceId(String processInstanceId);

    /**
     * 认领
     * @param taskId 节点任务ID
     * @param examineUser 处理人
     */
    protected abstract void claim(String taskId,String examineUser);

    /**
     * 更新节点处理结果
     * @param taskId 节点任务ID
     * @param examineUser 处理人
     * @param variables 条件参数
     */
    protected abstract void taskComplete(String taskId,String examineUser, Map<String,Object> variables);

    /**
     * 查询用户待办
     * @param userName
     * @return
     */
    protected abstract List<Task> findUserTasks(String userName);

    /**
     * 查询用户待办
     * @param processKey
     * @param userName
     * @return
     */
    protected abstract List<Task> findUserTasks(String processKey, String userName);

    /**
     * 根据任务ID和userName在任务中移除
     * @param taskId
     * @param userName
     */
    protected abstract void removeCandidateUser(String taskId,String userName);

    /**
     * 根据任务ID添加候选人
     * @param taskId
     * @param userName
     */
    protected abstract void addCandidateUser(String taskId,String userName);

    /**
     * 查询当前用户角色和归属用户组的所有任务
     * @param processKey
     * @param Codes
     * @return
     */
    protected abstract List<Task> findRoleAndPeopleGroupTasks(String processKey,List<String> Codes);

    /**
     * 通过任务ID查询任务信息
     * @param taskId
     * @return
     */
    protected abstract List<Task> findUserTaskByTaskId(String taskId);

    /**
     * 根据业务key查询task任务
     * @param businessKey
     * @return
     */
    protected abstract List<Task> findTaskByBusinessKey(String businessKey);


    /**
     * 根据业务key查询task任务
     * @param businessKeys
     * @return
     */
    protected abstract List<Task> findTaskByBusinessKey(List<String> businessKeys);

    /**
     * 发起人撤回流程
     * @param processDefinitionId
     * @param userName
     * @param reason
     */
    protected abstract void startUserBackUp(String processDefinitionId,String userName,String reason);
}
