package com.crc.activiti.enums;

/**
 * Classname: TaskExaminationExpression
 * Description:节点处理结果枚举
 * Author: cymiao
 * Date: 2021/5/28 9:57
 **/
public enum TaskExaminationExpression {

    /**
     * 同意
     */
    EXAMINATION_PASS("examinationStatus","pass"),

    /**
     * 驳回
     */
    EXAMINATION_FAIL("examinationStatus","fail"),

    /**
     * 撤回
     */
    EXAMINATION_BACK_UP("examinationStatus","retract"),

    /**
     * 返回上一个节点
     */
    EXAMINATION_RETURN_PREVIOUS_NODE("examinationStatus","returnPreviousNode"),

    /**
     * 返回上一个节点
     */
    EXAMINATION_RETURN_HISTORY_NODE("examinationStatus","returnHistoryNode"),

    /**
     * 返回到发起人
     */
    EXAMINATION_RETURN_START("examinationStatus","returnStart"),

    /**
     * 同意
     */
    DEAL_RESULT_PASS("dealResult","pass"),

    /**
     * 驳回
     */
    DEAL_RESULT_FAIL("dealResult","fail"),

    /**
     * 撤回
     */
    DEAL_RESULT_BACK_UP("dealResult","backUp"),

    /**
     * 返回上一个节点
     */
    DEAL_RESULT_RETURN_PREVIOUS_NODE("dealResult","returnPreviousNode"),

    /**
     * 返回到发起人
     */
    DEAL_RESULT_RETURN_START("dealResult","returnStart"),

    /**
     * 返回自选节点
     */
    DEAL_RESULT_RETURN_HISTORY_NODE("dealResult","returnHistoryNode"),

    ;

    private String key;

    private String value;

    TaskExaminationExpression(String key,String value){
        this.key = key;
        this.value = value;
    }

    public String getExpression(){
        StringBuilder builder = new StringBuilder();
        builder.append("${")
            .append(getExpressionValue())
            .append("}");
        return builder.toString();
    }

    public String getExpressionValue(){
        StringBuilder builder = new StringBuilder();
        builder.append(this.key)
                .append(" == '")
                .append(this.value)
                .append("'");
        return builder.toString();
    }

    public String getKey() {
        return key;
    }

    public void setKey(String key) {
        this.key = key;
    }

    public String getValue() {
        return value;
    }

    public void setValue(String value) {
        this.value = value;
    }
}
