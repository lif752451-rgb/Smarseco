package com.crc.activiti.message;

import lombok.Data;

/**
 * Classname:ActivitiTaskCreateMessage
 * Description: 节点任务被创建
 * Author: cymiao
 * Date: 2021/7/5 19:46
 **/
@Data
public class ActivitiTaskCreateMessage  extends BaseMessage{
    /**
     * 任务节点code
     */
    private String taskCode;
}
