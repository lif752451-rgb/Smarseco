package com.crc.activiti.task.impl;

import com.crc.activiti.entry.TaskNodeEntity;
import com.crc.activiti.task.BaseTaskChain;
import org.activiti.bpmn.model.UserTask;

/**
 * Classname:TaskChainDefaultImpl
 * Description:默认实现做基础业务
 * Author: cymiao
 * Date: 2021/6/9 17:20
 **/
public class TaskChainDefaultImpl extends BaseTaskChain {

    @Override
    public void decorateUserTask(UserTask task, TaskNodeEntity taskNode) {
        task.setName(taskNode.getTaskNodeName());
        task.setId(taskNode.createTaskId());

//        if(null == taskNode.getPreviousTaskNode() || taskNode.getPreviousTaskNode().isEmpty()){
//            throw new RuntimeException("节点信息配置错误");
//        }
        super.decorateUserTask(task, taskNode);
    }
}
