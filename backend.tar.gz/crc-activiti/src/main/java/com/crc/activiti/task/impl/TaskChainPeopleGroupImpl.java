package com.crc.activiti.task.impl;

import com.crc.activiti.entry.TaskNodeEntity;
import com.crc.activiti.enums.TaskNodeType;
import com.crc.activiti.task.BaseTaskChain;
import lombok.Setter;
import org.activiti.bpmn.model.UserTask;

/**
 * Classname:TaskChainPeopleGroupImpl
 * Description:节点类型为用户组的任务装饰类
 * Author: cymiao
 * Date: 2021/6/7 11:06
 **/
@Setter
public class TaskChainPeopleGroupImpl extends BaseTaskChain {

    @Override
    public void decorateUserTask(UserTask task, TaskNodeEntity taskNode) {
        if(TaskNodeType.PEOPLE_GROUP.getType().equals(taskNode.getTaskNodeType())){
            task.setCandidateGroups(taskNode.getTaskNodeOperations());
            decorateUserTaskOperationModeType(task, taskNode);
        }else{
            super.decorateUserTask(task, taskNode);
        }
    }
}
