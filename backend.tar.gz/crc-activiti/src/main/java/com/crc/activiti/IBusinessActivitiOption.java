package com.crc.activiti;

/**
 * Classname: IBusinessActivitiOption
 * Description:流程回调业务接口
 * Author: cymiao
 * Date: 2021/5/25 15:01
 **/
public interface IBusinessActivitiOption {

    /**
     * 整个流程处理结束，业务数据保存
     * @param businessKey
     * @param result
     */
    void saveProcessDealCompleteResult(String businessKey,String result);

    /**
     * 节点处理完成，业务数据保存
     * @param businessKey
     */
    void saveTaskNodeDealCompleteResult(String businessKey, String result,String taskCode);

    /**
     * 保存当前正在处理的节点状态
     */
    default void saveCurrentTaskNodeStatus(String businessKey,String taskCode){};
}
