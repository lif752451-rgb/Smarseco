package com.crc.activiti.domain;

import lombok.Data;

/**
 * Classname: ApplyDomain
 * Description:
 * Author: cymiao
 * Date: 2021/5/24 19:53
 **/
@Data
public class ApplyDomain {
    /**
     * 业务唯一标识
     */
    private String businessKey;
}
