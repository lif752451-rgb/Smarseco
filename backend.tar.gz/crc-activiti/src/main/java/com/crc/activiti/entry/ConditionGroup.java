package com.crc.activiti.entry;

import lombok.Data;

import java.util.List;

/**
 * Classname:ConditionGroup
 * Description:条件分组
 * Author: cymiao
 * Date: 2021/6/22 10:15
 **/
@Data
public class ConditionGroup {
    /**
     * 分组内条件组合
     */
    private List<ConditionEntity> conditions;

    /**
     * 条件计算表达式
     * @return
     */
    public String getCalculationExpression(){
        if(null == conditions || conditions.isEmpty()){
            throw new RuntimeException("节点条件配置异常");
        }

        if(conditions.size() == 1){
            return conditions.get(0).calculationExpression();
        }

        StringBuffer builder = new StringBuffer();
        for(ConditionEntity condition : conditions){
            builder.append("(")
                    .append(condition.calculationExpression())
                    .append(")&&");
        }
        int length = builder.length();
        builder.delete(length - 2,length);
        return builder.toString();
    }

    /**
     * 分组唯一标识key
     * @return
     */
    public String getConditionGroupKey(){
        StringBuffer builder = new StringBuffer();
        if(null != conditions && !conditions.isEmpty()){
            for(ConditionEntity condition : conditions){
                builder.append(condition.getVariable())
                        .append("And");
            }
        }else {
            throw new RuntimeException("节点条件配置异常");
        }

        builder.delete(builder.length() - 3,builder.length());
        return builder.toString();
    }
}
