package com.crc.activiti.entry;

import lombok.Data;

import java.util.List;

/**
 * Classname: RuleEntity
 * Description:
 * Author: cymiao
 * Date: 2021/5/24 16:36
 **/
@Data
public class RuleEntity {
    /**
     * 任务节点
     */
    private List<TaskNodeEntity> taskNodes;

    /**
     * 规则名称名称
     */
    private String ruleName;

    /**
     * 规则类型：default-默认；condition-条件
     */
    private String ruleType;

    /**
     * 条件参数
     */
    private ConditionEntity numrangeitem;
}
