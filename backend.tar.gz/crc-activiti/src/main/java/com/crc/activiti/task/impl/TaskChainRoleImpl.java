package com.crc.activiti.task.impl;

import com.crc.activiti.entry.TaskNodeEntity;
import com.crc.activiti.enums.TaskNodeType;
import com.crc.activiti.task.BaseTaskChain;
import lombok.Setter;
import org.activiti.bpmn.model.UserTask;

/**
 * Classname: TaskChainRoleImpl
 * Description:节点类型为角色的任务装饰类
 * Author: cymiao
 * Date: 2021/6/7 11:12
 **/
@Setter
public class TaskChainRoleImpl extends BaseTaskChain {
    @Override
    public void decorateUserTask(UserTask task, TaskNodeEntity taskNode) {
        if(TaskNodeType.ROLE.getType().equals(taskNode.getTaskNodeType())){
            task.setCandidateGroups(taskNode.getTaskNodeOperations());
            decorateUserTaskOperationModeType(task, taskNode);
        }else{
            super.decorateUserTask(task, taskNode);
        }
    }
}
