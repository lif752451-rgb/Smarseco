package com.crc.activiti.message.config;

import com.crc.activiti.message.listener.EventBusMessageListener;
import com.google.common.eventbus.AsyncEventBus;
import lombok.extern.slf4j.Slf4j;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import java.util.concurrent.LinkedBlockingQueue;
import java.util.concurrent.RejectedExecutionHandler;
import java.util.concurrent.ThreadFactory;
import java.util.concurrent.ThreadPoolExecutor;
import java.util.concurrent.TimeUnit;

/**
 * Classname:EventBusConfig
 * Description:eventbus装载类
 * Author: cymiao
 * Date: 2021/6/17 15:03
 **/
@Slf4j
@Configuration
public class EventBusConfig {

    @Bean
    public EventBusMessageListener createMessageListener() {
        return new EventBusMessageListener();
    }

    @Bean
    public AsyncEventBus createEventBus(EventBusMessageListener eventBusMessageListener) {
        AsyncEventBus eventBus = new AsyncEventBus("", new ThreadPoolExecutor(
                4,
                4,
                60,
                TimeUnit.SECONDS,
                new LinkedBlockingQueue<Runnable>(200),
                new ThreadFactory() {
                    // 线程工厂
                    private int threadId = 1;

                    @Override
                    public Thread newThread(Runnable r) {
                        Thread thread = new Thread(r);
                        thread.setName("EventBus Thread-" + threadId++);
                        return thread;
                    }
                },
                new RejectedExecutionHandler() {
                    // 处理任务被拒绝的情况
                    @Override
                    public void rejectedExecution(Runnable r, ThreadPoolExecutor executor) {
                        log.error("Task :{} ; rejected from :{}", r.toString(), executor.toString());
                    }
                }));
        eventBus.register(eventBusMessageListener);
        return eventBus;
    }
}
