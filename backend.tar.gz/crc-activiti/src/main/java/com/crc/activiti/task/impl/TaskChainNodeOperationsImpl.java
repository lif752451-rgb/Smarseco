package com.crc.activiti.task.impl;

import com.crc.activiti.entry.TaskNodeEntity;
import com.crc.activiti.enums.TaskNodeType;
import com.crc.activiti.task.BaseTaskChain;
import lombok.Setter;
import org.activiti.bpmn.model.UserTask;

import java.util.List;

/**
 * Classname:TaskChainNodeOperationsImpl
 * Description:节点类型为节点审批人的任务装饰类
 * Author: cymiao
 * Date: 2021/6/7 11:27
 **/
@Setter
public class TaskChainNodeOperationsImpl extends BaseTaskChain {

    @Override
    public void decorateUserTask(UserTask task, TaskNodeEntity taskNode) {
        if(TaskNodeType.NODE_OPERATIONS.getType().equals(taskNode.getTaskNodeType())){
            task.setCandidateGroups(taskNode.getTaskNodeOperations());
            decorateUserTaskOperationModeType(task, taskNode);
            List<String> taskNodeOperations = taskNode.getTaskNodeOperations();
            if(null == taskNodeOperations || taskNodeOperations.isEmpty()){
                throw new RuntimeException("流程节点信息异常");
            }
            for(String code : taskNodeOperations){
                createCustomProperty(task,TaskNodeType.NODE_OPERATIONS.getType(), code);
            }
            decorateUserTaskOperationModeType(task, taskNode);
        }else{
            super.decorateUserTask(task, taskNode);
        }
    }
}
