package com.crc.activiti.entry;

import lombok.Data;

import java.util.List;

/**
 * Classname: ProcessEntity
 * Description:
 * Author: cymiao
 * Date: 2021/5/24 16:50
 **/
@Data
public class ProcessEntity {
    /**
     * 任务节点
     */
    private List<TaskNodeEntity> taskNodes;

    /**
     * 流程类型：漏洞、风险、威胁
     */
    private String processType;

    /**
     * 流程类型名称
     */
    private String processTypeName;

    /**
     * 流程归属
     */
    private String processOwner;

    /**
     * 流程名称
     */
    private String processName;

    /**
     * 流程描述
     */
    private String processDesc;

    /**
     * 流程唯一标识
     */
    private String processKey;

   /**
     * 创建流程唯一标识key
     * @param
     * @return
     */
    public String createProcessKey(){
        StringBuilder builder = new StringBuilder();
        builder.append(this.getProcessOwner())
                .append("_")
                .append(this.getProcessType());
        return builder.toString();
    }
}
