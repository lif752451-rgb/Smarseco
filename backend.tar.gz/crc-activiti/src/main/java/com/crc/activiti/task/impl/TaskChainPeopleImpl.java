package com.crc.activiti.task.impl;

import com.crc.activiti.entry.TaskNodeEntity;
import com.crc.activiti.enums.TaskNodeType;
import com.crc.activiti.task.BaseTaskChain;
import lombok.Setter;
import org.activiti.bpmn.model.UserTask;

/**
 * Classname:ITaskChain
 * Description: 节点类型为具体人的任务装饰类
 * Author: cymiao
 * Date: 2021/6/7 10:26
 **/
@Setter
public class TaskChainPeopleImpl extends BaseTaskChain {

    @Override
    public void decorateUserTask(UserTask task,TaskNodeEntity taskNode) {
        if(TaskNodeType.PEOPLE.getType().equals(taskNode.getTaskNodeType())){
            task.setCandidateUsers(taskNode.getTaskNodeOperations());
            decorateUserTaskOperationModeType(task, taskNode);
        }else{
            super.decorateUserTask(task, taskNode);
        }
    }
}
