package com.crc.activiti.delegate;

import com.crc.activiti.constant.VariableExpression;
import org.activiti.engine.delegate.DelegateExecution;
import org.activiti.engine.delegate.Expression;
import org.activiti.engine.delegate.JavaDelegate;
import org.apache.commons.jexl3.*;

/**
 * Classname: CalculationConditionExpression
 * Description:计算条件网关条件表达式
 * Author: cymiao
 * Date: 2021/6/21 14:56
 **/
public class CalculationConditionExpression implements JavaDelegate {

    /**
     * 条件表达式
     */
    private Expression expression;

    /**
     * 条件变量
     */
    private Expression conditionKey;

    @Override
    public void execute(DelegateExecution execution) {

        String expressionText = conditionKey.getExpressionText();
        String[] conditionKeys = expressionText.split("And");

        //组装执行变量
        JexlContext jexlContext = new MapContext();
        for(String key : conditionKeys){
            jexlContext.set(key,execution.getVariable(key));
        }

        expressionText = expression.getExpressionText();

        // 初始化Jexl构造器
        JexlBuilder jexlBuilder = new JexlBuilder();

        // 创建Jexl表达式引擎
        JexlEngine jexlEngine = jexlBuilder.create();

        // 创建Jexl表达式解析器
        JexlScript jexlScript = jexlEngine.createScript(expressionText);

        // 执行Jexl表达式，得到结果
        Object execute = jexlScript.execute(jexlContext);
        /**
         * 设置TaskExaminationExpression.CONDITION_CALCULATION_RESULT.getExpression()
         *  历史计算值拼接起来
         */
        Object variable = execution.getVariable(VariableExpression.CONDITION_CALCULATION_RESULT);

        if(variable == null || "".equals(variable)){
            execution.setVariable(VariableExpression.CONDITION_CALCULATION_RESULT,execute);
        }else{
            execution.setVariable(VariableExpression.CONDITION_CALCULATION_RESULT,variable + "#" + execute);
        }
    }
}
