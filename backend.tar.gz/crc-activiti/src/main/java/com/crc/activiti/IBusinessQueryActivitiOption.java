package com.crc.activiti;

import java.util.List;

/**
 * Classname: IBusinessActivitiOption
 * Description:流程回调查询业务接口
 * Author: cymiao
 * Date: 2021/5/25 15:01
 **/
public interface IBusinessQueryActivitiOption {

    /**
     * 通过业务标识和节点code查询已处理节点的处理人信息
     * @param businessKey
     * @param taskNodeCodes
     * @return
     */
    List<String> queryPreviousNodeOperations(String businessKey,List<String> taskNodeCodes);

    /**
     * 通过业务标识和节点code查询上一个节点选择的当前节点处理人信息
     * @param businessKey
     * @param taskNodeCodes
     * @return
     */
    List<String> querypreviousNodeSelecter(String businessKey,List<String> taskNodeCodes);
}
