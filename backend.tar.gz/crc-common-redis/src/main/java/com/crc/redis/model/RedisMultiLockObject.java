package com.crc.redis.model;

import org.redisson.RedissonMultiLock;

public class RedisMultiLockObject {
    private RedissonMultiLock multiLock;

    public RedisMultiLockObject(RedissonMultiLock multiLock) {
        this.multiLock = multiLock;
    }

    public void unlock() {
        if (multiLock != null) {
            multiLock.unlock();
        }
    }

}
