package com.crc.redis.config;

import lombok.AllArgsConstructor;
import lombok.Getter;

import java.util.concurrent.TimeUnit;

/**
 * @ClassName RedisSurviveStrategy
 * @Description: redis存活策略
 **/
@Getter
@AllArgsConstructor
public class RedisSurviveStrategy {

    private Long surviveTime;

    private TimeUnit surviveTimeUnit;

    /*
      缓存默认存活时间
     */
    private static final Long DEFAULT_SURVIVE_TIME = 2L;

    /*
      缓存默认存活时间单位
     */
    private static final TimeUnit DEFAULT_SURVIVE_TIMEUNIT = TimeUnit.HOURS;

    public static RedisSurviveStrategy defaultStrategy(){
        return new RedisSurviveStrategy(DEFAULT_SURVIVE_TIME, DEFAULT_SURVIVE_TIMEUNIT);
    }

}
