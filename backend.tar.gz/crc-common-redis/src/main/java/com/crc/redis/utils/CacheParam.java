package com.crc.redis.utils;

import java.lang.annotation.*;

/**
 * @author SHUFENGFENG
 */
@Target({ElementType.METHOD,ElementType.PARAMETER,ElementType.FIELD})
@Retention(RetentionPolicy.RUNTIME)
@Documented
@Inherited
public @interface CacheParam {
    String name() default "";
}