package com.crc.redis.utils;

import cn.hutool.core.collection.CollUtil;
import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;
import com.crc.common.model.dto.MySqlInfoDTO;
import com.crc.common.utils.DataUtils;
import com.crc.common.utils.JsonUtils;
import com.crc.redis.config.RedisSurviveStrategy;
import lombok.extern.slf4j.Slf4j;
import org.springframework.dao.DataAccessException;
import org.springframework.data.redis.connection.RedisConnection;
import org.springframework.data.redis.connection.ReturnType;
import org.springframework.data.redis.core.*;
import org.springframework.data.redis.core.script.DefaultRedisScript;
import org.springframework.stereotype.Component;

import javax.annotation.Resource;
import java.text.DecimalFormat;
import java.time.LocalDateTime;
import java.time.ZoneOffset;
import java.time.format.DateTimeFormatter;
import java.util.*;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.atomic.AtomicLong;
import java.util.stream.Collectors;

@Slf4j
@Component
@SuppressWarnings("unchecked")
public class RedisUtil {

    @Resource
    private RedisTemplate<String, Object> redisTemplate;

    public void setValue(String key, Object value){
        ValueOperations<String, Object> valueOperations = redisTemplate.opsForValue();
        valueOperations.set(key, value);
    }

    /**
     * @MethodName: setValue
     * @Description:  写入缓存
     * @param key 键
     * @param value 值
     * @param expireTime key/value的有效期
     * @param timeUnit 时间类型（时、分、秒 等）
     * @Return: void
    **/
    public void setValue(String key, Object value, Long expireTime, TimeUnit timeUnit) {
        ValueOperations<String, Object> operations = redisTemplate.opsForValue();
        operations.set(key, value, expireTime, timeUnit);
    }

    /**
     * @MethodName: setValue
     * @Description:  写入缓存
     * @param key 键
     * @param value 值
     * @param strategy 生存策略
     * @Return: void
    **/
    public void setValue(String key, Object value, RedisSurviveStrategy strategy){
        if (strategy.getSurviveTime() == null || strategy.getSurviveTime() == 0){
            throw new NullPointerException("RedisUtil.setValue : strategy.surviveTime can not be null");
        }

        if (strategy.getSurviveTimeUnit() == null){
            throw new NullPointerException("RedisUtil.setValue : strategy.surviveTimeUnit can not be null");
        }

        setValue(key, value, strategy.getSurviveTime(), strategy.getSurviveTimeUnit());
    }

    /**
     * @MethodName: setPipelineValue
     * @Description:  写入管道缓存
     * @param key
     * @param values
     * @Return: void
    **/
    public void setPipelineValue(String key, Map<String, Object> values){
        redisTemplate.executePipelined(new SessionCallback<Object>() {
            @Override
            public <K, V> Object execute(RedisOperations<K, V> redisOperations) throws DataAccessException {
                values.forEach((k ,v) -> setValue(key + k, v));
                return null;
            }
        });
    }

    /**
     * @MethodName: setList
     * @Description:  写入List类型缓存
     * @param key 键
     * @param values List
     * @Return: void
    **/
    public void setList(String key, List<Object> values){
        ListOperations<String, Object> operations = redisTemplate.opsForList();
        operations.leftPushAll(key, values);
    }

    /**
     * @MethodName: setList
     * @Description:  写入List类型缓存
     * @param key 键
     * @param values List
     * @Return: void
     **/
    public void setListNew(String key, List<Map<String, Map<String, List<MySqlInfoDTO>>>> values){
        ListOperations<String, Object> operations = redisTemplate.opsForList();
        operations.leftPushAll(key, values);
    }


    /**
     * @MethodName: setList
     * @Description:  写入List类型缓存
     * @param key 键
     * @param value 对象
     * @Return: void
    **/
    public void setList(String key, Object value){
        ListOperations<String, Object> operations = redisTemplate.opsForList();
        operations.leftPush(key, value);
    }

    /**
     * @MethodName: setSet
     * @Description:  写入Set类型缓存
     * @param key 键
     * @param value 对象
     * @Return: void
     **/
    public void setSet(String key, Object value){
        SetOperations<String, Object> operations = redisTemplate.opsForSet();
        operations.add(key, value);
    }


    /**
     * @MethodName: setSet
     * @Description:  写入Set类型缓存
     * @param key 键
     * @param value 对象
     * @Return: void
     **/
    public void setSet(String key, Set<Map<String, Map<String, List<MySqlInfoDTO>>>> value){
        SetOperations<String, Object> operations = redisTemplate.opsForSet();
        operations.add(key, value.toArray());
    }

    /**
     * @MethodName: getSetLength
     * @Description:  获取set 集合长度
     * @param key 键
     * @Return: void
     **/
    public Long getSetLength(String key){
        Set<Object> set = getSet(key);
        if (CollUtil.isEmpty(set)) {
            return 0L;
        }
        Long size = redisTemplate.opsForSet().size(key);
        return size;
    }

    /**
     * @MethodName: getSetLength
     * @Description:  获取set 集合长度
     * @param key 键
     * @Return: void
     **/
    public void removeFirstElement(String key){
        redisTemplate.opsForSet().remove(key, 0);
    }



    /**
     * @MethodName: expire
     * @Description:  重新设置key的ttl
     * @param key 键
     * @Return: void
     **/
    public void expire(String key, RedisSurviveStrategy strategy) {
        redisTemplate.expire(key, strategy.getSurviveTime(), strategy.getSurviveTimeUnit());
    }

    /**
     * @MethodName: getList
     * @Description:  获取List缓存
     * @param key 键
     * @Return: java.util.List<java.lang.Object>
     **/
    public <T> Set<T> getSet(String key){
        SetOperations<String, Object> operations = redisTemplate.opsForSet();
        return (Set<T>)operations.members(key);
    }

    /**
     * @MethodName: removeSetValue
     * @Description:  删除Set缓存
     * @param key 键
     * @param value 值
     * @Return: void
     **/
    public void removeSetValue(String key, Object value){
        SetOperations<String, Object> operations = redisTemplate.opsForSet();
        operations.remove(key, value);
    }

    /**
     * @MethodName: deleteKey
     * @Description:  删除key
     * @param key 键
     * @Return: void
     **/
    public void deleteKey(String key){
        redisTemplate.delete(key);
    }

    /**
     * @MethodName: getList
     * @Description:  获取List缓存
     * @param key 键
     * @Return: java.util.List<java.lang.Object>
    **/
    public <T> List<T> getList(String key){
        ListOperations<String, Object> operations = redisTemplate.opsForList();
        return (List<T>) operations.range(key, 0 ,-1);
    }

    /**
     * @MethodName: removeListValue
     * @Description:  删除List缓存
     * @param key 键
     * @param value 值
     * @Return: void
    **/
    public void removeListValue(String key, Object value){
        ListOperations<String, Object> operations = redisTemplate.opsForList();
        operations.remove(key, 1, value);
    }

    /**
     * @MethodName: removeValue
     * @Description:  删除缓存
     * @param key 键
     * @Return: void
    **/
    public void removeValue(String key){
        redisTemplate.delete(key);
    }

    /**
     * @MethodName: getValue
     * @Description:  获取缓存
     * @param key 键
     * @Return: java.lang.Object
    **/
    public Object getValue(String key){
        ValueOperations<String, Object> valueOperations = redisTemplate.opsForValue();
        return valueOperations.get(key);
    }

    public void setHashFieldValue(String key, String field, Object value){
        HashOperations<String, String, Object> operations = redisTemplate.opsForHash();
        operations.put(key, field, value);
    }

    public Object getHashFieldValue(String key, String field){
        HashOperations<String, String, Object> operations = redisTemplate.opsForHash();
        return operations.get(key, field);
    }

    /**
     * 自增长
     *
     * @param key
     * @return
     */
    public Long incr(String key) {
        return redisTemplate.opsForValue().increment(key);
    }

    /**
     * 方法说明: 原子性自增
     * @param key 自增的key
     * @param value 每次自增的值
     * @time: 2017年3月9日 下午4:28:21
     * @return: Long
     */
    public Long incr(String key, long value) {
        return redisTemplate.opsForValue().increment(key, value);
    }

    /**
     * 指定缓存失效时间单位(秒)
     *
     * @param key  键
     * @param time 时间
     */
    public boolean expire(String key, Long time) {
        try{
            if (time > 0L){
                redisTemplate.expire(key, time, TimeUnit.SECONDS);
            }
            return true;
        }catch (Exception e){
            log.error("指定缓存失效时间单位(秒)出错,{}",e.getMessage(),e);
            return false;
        }
    }

    /**
     * setNx
     * @param key
     * @param value
     * @return
     */
    public boolean setNx(String key,String value){
        BoundValueOperations boundValueOperations = redisTemplate.boundValueOps(key);
        return boundValueOperations.setIfAbsent(value);
    }


    /**
     * setNx
     * @param key
     * @param value
     * @return
     */
    public boolean setNx(String key,String value, long timeout, TimeUnit timeUnit){
        BoundValueOperations boundValueOperations = redisTemplate.boundValueOps(key);
        return boundValueOperations.setIfAbsent(value, timeout, timeUnit);
    }


    /**
     * 往List中存入数据
     *
     * @param key Redis键
     * @param value 数据
     * @return 存入的个数
     */
    public long lPush(final String key, final Object value) {
        Long count = redisTemplate.opsForList().leftPush(key, value);
        return count == null ? 0 : count;
    }

    /**
     * 往List中存入多个数据
     *
     * @param key Redis键
     * @param values 多个数据
     * @return 存入的个数
     */
    public long lPushAll(final String key, final Collection<Object> values) {
        Long count = redisTemplate.opsForList().leftPushAll(key, values);
        return count == null ? 0 : count;
    }

    /**
     * 往List中存入多个数据
     *
     * @param key Redis键
     * @param values 多个数据
     * @return 存入的个数
     */
    public long lPushAll(final String key, final Object... values) {
        Long count = redisTemplate.opsForList().leftPushAll(key, values);
        return count == null ? 0 : count;
    }

    /**
     * 往List中从右开始获取数据
     *
     * @param key Redis键
     * @return 数据
     */
    public Object rpop(final String key) {
        return redisTemplate.opsForList().rightPop(key);
    }


    /**
     * 获取列表长度
     *
     * @param key
     * @return
     */
    public Long lLen(String key) {
        return redisTemplate.opsForList().size(key);
    }

    /**
     * 实现命令：TTL key，以秒为单位，返回给定 key的剩余生存时间(TTL, time to live)。
     *
     * @param key
     * @return
     */
    public Long ttl(String key){
        return redisTemplate.getExpire(key);
    }


    /**
     * 模糊匹配key前缀
     * @param key 键，用于模糊查询
     * @return 符合条件的key列表
     */
    public List<String> getKeyByPrefix(String key){
        Set<String> keys = redisTemplate.keys(key + "*");
        if (keys != null && keys.size() > 0){
            return keys.stream().collect(Collectors.toList());
        }
        return new ArrayList<>();
    }

    /**
     * 获取key的过期时间
     * @param key
     * @return
     */
    public long getExpireByKey(String key) {
        ValueOperations operations = redisTemplate.opsForValue();
        long expire = operations.getOperations().getExpire(key);
        return expire;
    }

    /**
     * 获取redis内存使用情况
     */
    public String getRedisMemoryInfo() {
        Properties memoryInfo = redisTemplate.execute(new RedisCallback<Properties>() {
            @Override
            public Properties doInRedis(RedisConnection connection) throws DataAccessException {
                Properties memory = connection.info("memory");
                return memory;
            }
        });
        String s = JSON.toJSONString(memoryInfo);
        JSONObject parse = JsonUtils.parse(s);
        String usedMemory = JsonUtils.getStr(parse, "used_memory");
        DecimalFormat format = new DecimalFormat("#.00");
        double v = DataUtils.toDouble(usedMemory);
        String format1 = format.format(v / 1024);
        return format1;
    }

    public Integer getRedisKey() {
        Set<String> keys = redisTemplate.keys("*");
        return keys != null ? keys.size() : 0;
    }



    /**
     * 模糊删除key
     * @param key
     */
    public void deleteFuzzy(String key) {
        Set<String> keys = redisTemplate.keys(key);
        redisTemplate.delete(keys);
    }


}
