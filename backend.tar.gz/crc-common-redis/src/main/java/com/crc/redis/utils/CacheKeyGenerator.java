package com.crc.redis.utils;

import org.aspectj.lang.ProceedingJoinPoint;

/**
 * @author SHUFENGFENG
 */
public interface CacheKeyGenerator {
    /**
     * 获取AOP参数,生成指定缓存Key
     * @param joinPoint
     * @return
     */
    String getLockKey(ProceedingJoinPoint joinPoint);
}