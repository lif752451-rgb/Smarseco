package com.crc.redis.utils;

import lombok.extern.slf4j.Slf4j;
import org.aspectj.lang.ProceedingJoinPoint;
import org.aspectj.lang.annotation.Around;
import org.aspectj.lang.annotation.Aspect;
import org.aspectj.lang.reflect.MethodSignature;
import org.springframework.context.annotation.Configuration;
import org.springframework.web.context.request.RequestContextHolder;
import org.springframework.web.context.request.ServletRequestAttributes;

import javax.servlet.http.HttpServletRequest;
import java.lang.reflect.Method;

@Aspect
@Configuration
@Slf4j
public class CostTimeAspect {

    @Around("execution(public * * (..)) && @annotation(com.crc.redis.utils.CostTime)")
    public Object around(ProceedingJoinPoint joinPoint) throws Throwable {
        long startTime = System.currentTimeMillis();
        MethodSignature methodSignature = (MethodSignature) joinPoint.getSignature();
        Method method = methodSignature.getMethod();
        CostTime cacheLock = method.getAnnotation(CostTime.class);
        String name = cacheLock.name();
        ServletRequestAttributes requestAttributes = (ServletRequestAttributes) RequestContextHolder.getRequestAttributes();
        HttpServletRequest httpServletRequest = requestAttributes.getRequest();
        String url = httpServletRequest.getRequestURI();
        String methodName = joinPoint.getSignature().getDeclaringTypeName() + "." + joinPoint.getSignature().getName();
        Object obj = joinPoint.proceed();
        long endTime = System.currentTimeMillis();
        long offset = endTime - startTime;
        log.info(name + ",请求" + url + ",执行 " + methodName + " 耗时为：" + String.format("%d-%d=%d",endTime,startTime,offset) + "ms");
        return obj;
    }
}
