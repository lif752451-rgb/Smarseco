package com.crc.security.lic;

import com.alibaba.fastjson.JSON;
import com.crc.common.utils.DateUtils;
import com.crc.common.utils.FileUtils;
import com.crc.common.utils.StringUtils;
import com.crc.core.dto.LicenseVo;
import com.crc.core.utils.CodeTool;
import com.crc.core.utils.CpuTool;
import lombok.extern.slf4j.Slf4j;

import java.util.Date;
import java.util.HashMap;

@Slf4j
public class LicenseTool {

    /*
      解析授权文件
     */
    public static LicenseVo parseLicenseDat(String fileName) {
        String json = FileUtils.readFileStr(fileName);
        if (StringUtils.isBlank(json)) {
            log.error("{},内容为空！", fileName);
            return null;
        }
        String codeStr = CodeTool.decrypt(json);
        if (StringUtils.isBlank(json)) {
            log.error("{},内容解析失败！", fileName);
            return null;
        }
        try {
            return JSON.parseObject(codeStr, LicenseVo.class);
        } catch (Exception e) {
            log.error(e.getMessage(), e);
        }
        return null;
    }


    /**
     * 检测授权
     *
     * @param vo
     * @return
     */
    public static HashMap<String, String> check(LicenseVo vo) {
        HashMap<String, String> resultMap = new HashMap<>();
        String cpuSerial = CpuTool.getCpuId();
        String mac = CpuTool.getMac();
        try {
            if (vo == null || (mac != null && !mac.equals(vo.getMac())) ||
                    (cpuSerial != null && !cpuSerial.equals(vo.getCpuId()))) {
                resultMap.put("code", "10001");
                resultMap.put("msg", "认证失败,授权有误");
            } else {
                Date date = new Date();
                Date currentDate = null;
                try {
                    currentDate = DateUtils.parseDate(vo.getCreateTime(), DateUtils.YYYY_MM_DD_HH_MM_SS);
                } catch (Exception e) {
                    log.error(e.getMessage(), e);
                }
                if (currentDate == null) {
                    resultMap.put("code", "10002");
                    resultMap.put("msg", "认证失败,授权过期");
                } else if (date.before(currentDate)) {//机器修改了时间
                    resultMap.put("code", "10003");
                    resultMap.put("msg", "认证失败,授权过期");
                } else {
                    if ("2".equals(vo.getLicType())) {
                        //永久
                        resultMap.put("code", "200");
                        resultMap.put("msg", "认证成功，授权有效");
                    } else {
                        //有限
                        Date endTime = null;
                        Date startTime = null;
                        try {
                            startTime = DateUtils.parseDate(vo.getStartTime(), DateUtils.YYYY_MM_DD_HH_MM_SS);
                            endTime = DateUtils.parseDate(vo.getEndTime(), DateUtils.YYYY_MM_DD_HH_MM_SS);
                        } catch (Exception e) {
                            log.error(e.getMessage(), e);
                        }
                        if (startTime == null || endTime == null) {
                            resultMap.put("code", "10004");
                            resultMap.put("msg", "认证失败,授权过期");
                        } else {
                            if (date.before(startTime)) {
                                resultMap.put("code", "10000");
                                resultMap.put("msg", "认证失败,授权未开始");
                            } else if (date.after(endTime)) {//授权过期
                                resultMap.put("code", "10005");
                                resultMap.put("msg", "认证失败,授权过期");
                            } else {
                                resultMap.put("code", "200");
                                resultMap.put("msg", "认证成功，授权有效");
                            }
                        }

                    }
                }
            }
        } catch (Exception e) {
            log.error(e.getMessage(), e);
            resultMap.put("code", "500");
            resultMap.put("msg", "认证失败,授权失败");
        }


        return resultMap;
    }
}
