package com.crc.security.handle;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;
import com.crc.common.constant.Constants;
import com.crc.common.constant.LoginConstants;
import com.crc.common.constant.RedisKeys;
import com.crc.common.model.AjaxResult;
import com.crc.common.utils.ServletUtils;
import com.crc.common.utils.StrFormatter;
import com.crc.common.utils.StringUtils;
import com.crc.redis.utils.RedisUtil;
import com.crc.security.LoginUser;
import com.crc.security.service.TokenService;
import com.crc.security.utils.DictAuthorityUtils;
import lombok.extern.slf4j.Slf4j;
import org.springframework.context.annotation.Configuration;
import org.springframework.security.core.Authentication;
import org.springframework.security.web.authentication.logout.LogoutSuccessHandler;

import javax.annotation.Resource;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.util.Map;

/**
 * 自定义退出处理类 返回成功
 *
 * @author wst
 */
@Slf4j
@Configuration
public class LogoutSuccessHandlerImpl implements LogoutSuccessHandler {

    @Resource
    private TokenService tokenService;

    @Resource
    private RedisUtil redisUtil;

    /**
     * 退出处理
     *
     * @return
     */
    @Override
    public void onLogoutSuccess(HttpServletRequest request, HttpServletResponse response, Authentication authentication)
            throws IOException, ServletException {
        LoginUser loginUser = tokenService.getLoginUser(request);
        log.info("loginUser:{}", JSON.toJSONString(loginUser));
        log.info("sysType:{}", JSON.toJSONString(loginUser));
        if (StringUtils.isNotNull(loginUser)) {
            String sysType = request.getParameter("sysType");
            log.info("sysType:{}", sysType);
            String token = tokenService.getToken(request);
            String userName = loginUser.getUsername();
            String redisKey = String.format(RedisKeys.LOGIN_TYPE_USER, sysType, userName);
            String oldToken = String.valueOf(redisUtil.getValue(redisKey));
            if (StringUtils.isNotEmpty(token) && StringUtils.isNotEmpty(oldToken) && token.equals(oldToken)) {
                redisUtil.deleteKey(redisKey);
            }
            // 删除用户缓存记录
            tokenService.delLoginUser(loginUser.getToken());
        }
        ServletUtils.renderString(response, JSON.toJSONString(AjaxResult.success("退出成功", this.getLogoutPage())));
    }

    private JSONObject getLogoutPage() {
        Map<String, String> loginMap = DictAuthorityUtils.findLdapLogin(LoginConstants.ZY_DICT_TYPE);
        // 大地统一认证
        Map<String, String> continentLoginMap = DictAuthorityUtils.findLdapLogin(LoginConstants.CONTINENT_DICT_TYPE);
        JSONObject json = new JSONObject();
        // 默认密码模式
        String grantType;
        if (Constants.STR_VALUE_ONE.equals(loginMap.get(LoginConstants.AUTH_SWITCH))
                && StringUtils.isNotEmpty(loginMap.get(LoginConstants.CLIENT_ID))
                && StringUtils.isNotEmpty(loginMap.get(LoginConstants.CLIENT_SECRET))) {
            String logoutUrl = loginMap.get(LoginConstants.LOGOUT_URL);
            json.put(LoginConstants.LOGOUT_URL, StrFormatter.format(logoutUrl, loginMap));
            // 竹云统一登录
            grantType = LoginConstants.LDAP_UNIFIED_LOGIN;
        } else if (Constants.STR_VALUE_ONE.equals(continentLoginMap.get(LoginConstants.AUTH_SWITCH))) {
            String logoutUrl = continentLoginMap.get(LoginConstants.LOGOUT_URL);
            json.put(LoginConstants.LOGOUT_URL, StrFormatter.format(logoutUrl, continentLoginMap));
            // 大地统一认证
            grantType = LoginConstants.CONTINENT_UNIFIED_LOGIN;
        } else {
            grantType = LoginConstants.PASSWORD;
        }
        json.put(LoginConstants.GRANT_TYPE, grantType);
        return json;
    }
}
