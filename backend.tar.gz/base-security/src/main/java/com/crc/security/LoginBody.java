package com.crc.security;

import com.crc.common.constant.LoginConstants;
import com.crc.common.utils.StringUtils;
import lombok.Data;

import java.util.Map;

/**
 * 用户登录对象
 *
 * @author wst
 */
@Data
public class LoginBody {
    /**
     * 用户名
     */
    private String username;

    /**
     * 用户密码
     */
    private String password;

    /**
     * 验证码Id
     */
    private String verifyId;

    /**
     * 唯一标识
     */
    private String uuid = "";


    private int isLdap;

    private String sysType;

    /**
     * 登录模式
     */
    private String grantType;

    /**
     * 授权码
     */
    private String code;
    /**
     *有度单点登录Token
     */
    private String youDuToken;

    /**
     * 竹云统一认证
     */
    private Map<String, String> loginMap;

    public String getGrantType() {
        // 默认用户使用密码登录模式
        return StringUtils.isEmpty(this.grantType) ? LoginConstants.PASSWORD : this.grantType;
    }

    public enum LoginType {
        IS_LDAP(1, "ldap登录"),
        IS_LOCAL(2, "本地用户");

        private int type;
        private String desc;

        LoginType(int type, String desc) {
            this.type = type;
            this.desc = desc;
        }

        public int getType() {
            return type;
        }

        public String getDesc() {
            return desc;
        }

    }
}