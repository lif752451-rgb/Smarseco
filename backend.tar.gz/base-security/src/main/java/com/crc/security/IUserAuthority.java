package com.crc.security;

import org.springframework.stereotype.Component;

import java.util.List;
import java.util.Map;

@Component
public interface IUserAuthority {

	Map<String,Object> getUserInfoByName(String userName);

	List<String> getUserRoles(Map<String, Object> userInfo);

	List<String> getPermissions(Map<String, Object> userInfo);
}
