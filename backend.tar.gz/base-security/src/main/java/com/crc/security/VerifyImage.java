package com.crc.security;

/**
 * @author simba@onlying.cn
 * @date 2020/7/13 15:36
 */
public class VerifyImage {

    //X坐标
    private int xPosition;
    //Y坐标
    private int yPosition;
    //校验次数
    private int imgNum;
    //验证Id
    private String verifyId;

    private String uuid;

    public VerifyImage(){

    }

    public VerifyImage(int xPosition,int yPosition,int imgNum,String uuid){
        this.xPosition =xPosition;
        this.yPosition =yPosition;
        this.imgNum = imgNum;
        this.uuid =uuid;
    }

    public int getxPosition() {
        return xPosition;
    }

    public int getyPosition() {
        return yPosition;
    }

    public int getImgNum() {
        return imgNum;
    }

    public String getVerifyId() {
        return verifyId;
    }

    public void setxPosition(int xPosition) {
        this.xPosition = xPosition;
    }

    public void setyPosition(int yPosition) {
        this.yPosition = yPosition;
    }

    public void setImgNum(int imgNum) {
        this.imgNum = imgNum;
    }

    public void setVerifyId(String verifyId) {
        this.verifyId = verifyId;
    }

    public String getUuid() {
        return uuid;
    }

    public void setUuid(String uuid) {
        this.uuid = uuid;
    }


}
