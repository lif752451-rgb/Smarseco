package com.crc.security.utils;

import com.crc.common.constant.Constants;
import com.crc.common.constant.LoginConstants;
import com.crc.common.utils.ServletUtils;
import com.crc.core.bean.GetSpringBean;
import com.crc.security.IDictAuthority;
import com.crc.security.model.vo.DictAuthorityVO;
import org.apache.commons.text.StringEscapeUtils;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Objects;

/**
 * 登录数据字典配置信息
 * 
 * @author zhangbing
 */
public class DictAuthorityUtils {

    public static Map<String, String> findLdapLogin(String dictType) {
        IDictAuthority dictAuthority = GetSpringBean.getBean(IDictAuthority.class);
        List<DictAuthorityVO> list = dictAuthority.findDictType(dictType);
        Map<String, String> authMap = new HashMap<>(10);

        authMap.put(LoginConstants.CLIENT_ID, getSysNameTypeRemark(LoginConstants.CLIENT_ID, list));
        authMap.put(LoginConstants.CLIENT_SECRET, getSysNameTypeRemark(LoginConstants.CLIENT_SECRET, list));
        authMap.put(LoginConstants.REDIRECT_URI, getSysNameTypeRemark(LoginConstants.REDIRECT_URI, list));

        authMap.put(LoginConstants.AUTH_SWITCH, getRemark(LoginConstants.AUTH_SWITCH, list));
        authMap.put(LoginConstants.LOGIN_URL, getRemark(LoginConstants.LOGIN_URL, list));
        authMap.put(LoginConstants.LOGOUT_URL, getRemark(LoginConstants.LOGOUT_URL, list));
        authMap.put(LoginConstants.TOKEN_URL, getRemark(LoginConstants.TOKEN_URL, list));
        authMap.put(LoginConstants.USER_INFO_URL, getRemark(LoginConstants.USER_INFO_URL, list));
        authMap.put(LoginConstants.REFRESH_TOKEN_URL, getRemark(LoginConstants.REFRESH_TOKEN_URL, list));
        authMap.put(LoginConstants.USER_NAME_FIELD, getRemark(LoginConstants.USER_NAME_FIELD, list));

        return authMap;
    }

    private static String getSysNameTypeRemark(String str, List<DictAuthorityVO> list) {
        String sysNameType = ServletUtils.getRequest().getHeader(LoginConstants.SYS_NAME_TYPE);
        String dictValue = sysNameType + Constants.Symbol.UNDERLINE + str;
        return getRemark(dictValue, list);
    }

    private static String getRemark(String dictValue, List<DictAuthorityVO> list) {
        String str = list.stream().filter(vo -> Objects.nonNull(vo) && dictValue.equals(vo.getDictValue()))
            .map(DictAuthorityVO::getRemark).findFirst().orElse("");
        return StringEscapeUtils.unescapeHtml4(str);
    }
}
