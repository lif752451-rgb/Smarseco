package com.crc.security.utils;

import com.alibaba.fastjson.JSONObject;
import com.crc.common.utils.DateUtils;
import com.crc.common.utils.JsonUtils;
import com.crc.common.utils.StringUtils;
import com.crc.core.utils.CodeTool;
import com.crc.core.utils.HardWareUtils;
import lombok.extern.slf4j.Slf4j;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.util.Date;
import java.util.HashMap;

/*
Lic控制
 */
@Slf4j
public class SysMangerUtils {

    public static HashMap<String, String> check(String msgCode) {
        /*
        {
            "limitAsset":30,
            "limitPath":"/usr/local/share/info/sys/",
            "publicKey":"IpTFX6FjYs5zKDG8gjKFh7kTgCFdWWJE"
        }
         */

        HashMap<String, String> resultMap = new HashMap<>();
        JSONObject json = JsonUtils.parse(msgCode);
        int limitAsset = JsonUtils.getInt(json, "limitAsset");
        String limitPath = JsonUtils.getStr(json, "limitPath");
        String publicKey = JsonUtils.getStr(json, "publicKey");
        if (!StringUtils.isBlank(limitPath)) {
            File file = new File(limitPath + "/xx.dat");
            if (file.exists()) {
                try (BufferedReader bf = new BufferedReader(new FileReader(file));) {
                    StringBuilder buffer = new StringBuilder();
                    String s;
                    while ((s = bf.readLine()) != null) {
                        buffer.append(s.trim());
                    }
                    String content = buffer.toString();
                    content = CodeTool.decrypt(content, publicKey);

                    JSONObject obj = JsonUtils.parse(content);
                    String motherboard = JsonUtils.getStr(obj, "motherboard");
                    String cpuSerial = JsonUtils.getStr(obj, "cpuSerial");
                    motherboard = CodeTool.decrypt(motherboard, publicKey);
                    cpuSerial = CodeTool.decrypt(cpuSerial, publicKey);
                    if (!motherboard.equals(HardWareUtils.getMotherboardSN()) ||
                            !cpuSerial.equals(HardWareUtils.getCPUSerial())) {
                        resultMap.put("code", "11");
                        resultMap.put("msg", "认证失败,授权有误");
                    } else {
                        Date date = new Date();
                        String newCurrentTimeStr = JsonUtils.getStr(obj, "newCurrentTime");//证书生产时间
                        String newExpireTimeStr = JsonUtils.getStr(obj, "newExpireTime");//证书过期时间
                        String newCurrentTime = CodeTool.decrypt(newCurrentTimeStr, publicKey);
                        String newExpireTime = CodeTool.decrypt(newExpireTimeStr, publicKey);
                        Date currentDate = DateUtils.parseDateTimeX(newCurrentTime, "yyyy-MM-dd");
                        Date expireTime = DateUtils.parseDateTimeX(newExpireTime, "yyyy-MM-dd");

//                        resultMap.put("motherboard", motherboard);
//                        resultMap.put("cpuSerial", cpuSerial);
//                        resultMap.put("newCurrentTime", newCurrentTime);
//                        resultMap.put("newExpireTime", newExpireTime);
//                        JsonUtils.print(resultMap);


                        if (currentDate == null || expireTime == null) {
                            resultMap.put("code", "20");
                            resultMap.put("msg", "认证失败,授权过期");
                        } else if (date.before(currentDate)) {//机器修改了时间
                            resultMap.put("code", "21");
                            resultMap.put("msg", "认证失败,授权过期");
                        } else {
                            if (date.after(expireTime)) {//授权过期
                                resultMap.put("code", "22");
                                resultMap.put("msg", "认证失败,授权过期");
                            } else {
                                resultMap.put("code", "1");
                                resultMap.put("msg", "认证成功，授权有效");
                            }
                        }
                    }
                } catch (Exception e) {
                    resultMap.put("code", "12");
                    resultMap.put("msg", "认证失败,授权有误");
                    log.error(e.getMessage(), e);
                }
            } else {
                resultMap.put("code", "03");
                resultMap.put("msg", "认证失败,授权有误");
            }
        } else {
            resultMap.put("code", "04");
            resultMap.put("msg", "认证失败,授权有误");
        }


        return resultMap;
    }
}
