package com.crc.security.model.vo;

import lombok.Data;

/**
 * 数据字典
 */
@Data
public class DictAuthorityVO {

    /**
     * 字典编码
     */
    private Long dictCode;

    /**
     * 字典类型
     */
    private String dictType;

    /**
     * 字典标签
     */
    private String dictLabel;

    /**
     * 字典键值
     */
    private String dictValue;

    /**
     * 字典排序
     */
    private Long dictSort;

    /**
     * 是否默认（Y是 N否）
     */
    private String isDefault;

    /**
     * 状态（0正常 1启用）
     */
    private String status;

    /**
     * 配置信息
     */
    private String remark;
}
