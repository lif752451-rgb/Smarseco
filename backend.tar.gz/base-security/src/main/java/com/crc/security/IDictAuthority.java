package com.crc.security;

import com.crc.security.model.vo.DictAuthorityVO;
import org.springframework.stereotype.Component;

import java.util.List;

/**
 * 登录查询数据字典
 */
@Component
public interface IDictAuthority {

    List<DictAuthorityVO> findDictType(String dictType);
}
