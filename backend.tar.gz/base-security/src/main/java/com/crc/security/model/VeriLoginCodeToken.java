package com.crc.security.model;

import javax.validation.constraints.NotEmpty;
import javax.validation.constraints.Pattern;
import javax.validation.constraints.Size;

public class VeriLoginCodeToken {
    @NotEmpty(message = "id错误.3")
    @Size(min = 63, max = 65, message = "id错误.2")
    @Pattern(regexp = "^[A-Za-z0-9]+$", message = "id错误.1")
    private String id;
    public String getId() {
        return id;
    }
    public void setId(String id) {
        this.id = id;
    }
}
