package com.crc.security.utils;

import com.crc.common.constant.Constants;
import com.crc.common.constant.HttpStatus;
import com.crc.common.exception.CustomException;
import com.crc.common.model.enums.SysRoleEnum;
import com.crc.security.LoginUser;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.testng.collections.Lists;

import java.util.List;

/**
 * 安全服务工具类
 *
 * @author wst
 */
public class SecurityUtils {

    /**
     * 获取用户账户
     **/
    public static String getUsername() {
        try {
            return getLoginUser().getUsername();
        } catch (Exception e) {
            throw new CustomException("获取用户账户异常", HttpStatus.UNAUTHORIZED);
        }
    }

    /**
     * 获取用户账户显示名称
     **/
    public static String getUserNameLabel() {
        try {
            return getLoginUser().getUserNameLabel();
        } catch (Exception e) {
            throw new CustomException("获取用户账户异常", HttpStatus.UNAUTHORIZED);
        }
    }

    /**
     * 获取用户
     **/
    public static LoginUser getLoginUser() {
        try {
            return (LoginUser)getAuthentication().getPrincipal();
        } catch (Exception e) {
            throw new CustomException("获取用户信息异常", HttpStatus.UNAUTHORIZED);
        }
    }

    /**
     * 获取Authentication
     */
    public static Authentication getAuthentication() {
        return SecurityContextHolder.getContext().getAuthentication();
    }

    /**
     * 生成BCryptPasswordEncoder密码
     *
     * @param password 密码
     * @return 加密字符串
     */
    public static String encryptPassword(String password) {
        BCryptPasswordEncoder passwordEncoder = new BCryptPasswordEncoder();
        return passwordEncoder.encode(password);
    }

    public static void main(String[] args) {
        String encryptPassword = encryptPassword("admin123");
        System.out.println("encryptPass:" + encryptPassword);
        System.out.println("matchesPassword:" + matchesPassword("admin123", encryptPassword));
    }

    /**
     * 判断密码是否相同
     *
     * @param rawPassword 真实密码
     * @param encodedPassword 加密后字符
     * @return 结果
     */
    public static boolean matchesPassword(String rawPassword, String encodedPassword) {
        BCryptPasswordEncoder passwordEncoder = new BCryptPasswordEncoder();
        return passwordEncoder.matches(rawPassword, encodedPassword);
    }

    public static boolean isAdmin(String userName) {
        return Constants.SUPER.equals(userName);
    }

    /**
     * 是否为管理员
     *
     * @param userId 用户ID
     * @return 结果
     */
    public static boolean isAdmin(Long userId) {
        return userId != null && 1L == userId;
    }

    /**
     * 是否有管理员权限
     *
     * @return 结果
     */
    public static boolean isAdminRole() {
        return getLoginUser().getRoles().stream().anyMatch(str -> SysRoleEnum.ADMIN.getKey().equals(str));
    }

    /**
     * 是否有超级管理员权限
     *
     * @return 结果
     */
    public static boolean isSuperRole() {
        return getLoginUser().getRoles().stream().anyMatch(str -> SysRoleEnum.SUPER.getKey().equals(str));
    }

    /**
     * 是否有指定角色权限
     * 
     * @param roleKey 角色key
     * @return
     */
    public static Boolean isAppointRole(String roleKey) {
        return getLoginUser().getRoles().stream().anyMatch(roleKey::equals);
    }

    /**
     * 是否有指定权限点
     *
     * @param perms 权限点
     * @return Boolean
     */
    public static Boolean isAppointPerms(String perms) {
        return isAppointPerms(getLoginUser().getPermissions(), perms);
    }

    /**
     * 是否有指定权限点
     *
     * @param permsList 权限集合
     * @param perms 权限点
     * @return Boolean
     */
    public static Boolean isAppointPerms(List<String> permsList, String perms) {
        List<String> newPermsList = Lists.newArrayList(permsList);
        return newPermsList.stream().anyMatch(str -> "*:*:*".equals(str) || str.equals(perms));
    }
}
