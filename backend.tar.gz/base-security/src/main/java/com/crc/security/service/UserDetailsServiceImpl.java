package com.crc.security.service;

import com.crc.common.utils.StringUtils;
import com.crc.security.IUserAuthority;
import com.crc.security.LoginUser;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.stereotype.Service;

import java.util.Map;

/**
 * 用户验证处理
 *
 * @author wst
 */
@Service
public class UserDetailsServiceImpl implements UserDetailsService
{
    private static final Logger log = LoggerFactory.getLogger(UserDetailsServiceImpl.class);

    @Autowired
    private IUserAuthority userAuthority;

    @Override
    public UserDetails loadUserByUsername(String username) throws UsernameNotFoundException
    {
        Map<String, Object> userInfo = userAuthority.getUserInfoByName(username);
        if (StringUtils.isNull(userInfo)){
            log.info("登录用户：{} 不存在.", username);
            throw new UsernameNotFoundException("登录用户：" + username + " 不存在");
        }

        return new LoginUser(userInfo, userAuthority.getPermissions(userInfo),userAuthority.getUserRoles(userInfo));
    }
}
