package com.crc.security.utils;

import cn.hutool.core.util.ReflectUtil;
import com.crc.common.constant.Constants;
import com.crc.security.LoginUser;

import java.util.Date;
import java.util.Objects;

/**
 * 通过属 set方法进行赋值
 * 
 * @author zhangbing
 */
public class CommonSetValue {

    private static final String DEL_FLAG = "delFlag";
    private static final String CREATE_BY = "createBy";
    private static final String CREATE_BY_LABEL = "createByLabel";
    private static final String CREATE_TIME = "createTime";
    private static final String UPDATE_BY = "updateBy";
    private static final String UPDATE_BY_LABEL = "updateByLabel";
    private static final String UPDATE_TIME = "updateTime";

    /**
     * 反射注入值-通过属 set方法进行赋值 <T> T 表示返回值是一个泛型 T 用于限制传递的数据类型（编译时才需要去确定的具体类型）
     *
     * @param t 对象
     */
    public static <T> T insertSetVal(T t) {
        LoginUser loginUser = null;
        try {
            loginUser = SecurityUtils.getLoginUser();
        } catch (Exception ignored) {
        }
        return insertSetVal(t, loginUser);
    }

    /**
     * 反射注入值-通过属 set方法进行赋值 <T> T 表示返回值是一个泛型 T 用于限制传递的数据类型（编译时才需要去确定的具体类型）
     *
     * @param t 对象
     * @param loginUser 当前登陆人信息
     */
    public static <T> T insertSetVal(T t, LoginUser loginUser) {
        Class<?> tClass = t.getClass();
        if (ReflectUtil.hasField(tClass, DEL_FLAG)) {
            ReflectUtil.setFieldValue(t, DEL_FLAG, Constants.DEL_FLAG_EFF);
        }
        if (Objects.nonNull(loginUser)) {
            if (ReflectUtil.hasField(tClass, CREATE_BY_LABEL)) {
                ReflectUtil.setFieldValue(t, CREATE_BY_LABEL, loginUser.getUserNameLabel());
            }
            if (ReflectUtil.hasField(tClass, CREATE_BY)) {
                ReflectUtil.setFieldValue(t, CREATE_BY, loginUser.getUsername());
            }
            if (ReflectUtil.hasField(tClass, UPDATE_BY_LABEL)) {
                ReflectUtil.setFieldValue(t, UPDATE_BY_LABEL, loginUser.getUserNameLabel());
            }
            if (ReflectUtil.hasField(tClass, UPDATE_BY)) {
                ReflectUtil.setFieldValue(t, UPDATE_BY, loginUser.getUsername());
            }
        }
        Date date = new Date();
        if (ReflectUtil.hasField(tClass, CREATE_TIME)) {
            ReflectUtil.setFieldValue(t, CREATE_TIME, date);
        }
        if (ReflectUtil.hasField(tClass, UPDATE_TIME)) {
            ReflectUtil.setFieldValue(t, UPDATE_TIME, date);
        }
        return t;
    }

    /**
     * 反射注入值-通过属 set方法进行赋值 <T> T 表示返回值是一个泛型 T 用于限制传递的数据类型（编译时才需要去确定的具体类型）
     *
     * @param t 对象
     */
    public static <T> T updateSetVal(T t) {
        LoginUser loginUser = null;
        try {
            loginUser = SecurityUtils.getLoginUser();
        } catch (Exception ignored) {
        }
        return updateSetVal(t, loginUser);
    }

    /**
     * 反射注入值-通过属 set方法进行赋值 <T> T 表示返回值是一个泛型 T 用于限制传递的数据类型（编译时才需要去确定的具体类型）
     *
     * @param t 对象
     */
    public static <T> T updateSetVal(T t, LoginUser loginUser) {
        Class<?> tClass = t.getClass();
        try {
            if (ReflectUtil.hasField(tClass, UPDATE_BY)) {
                ReflectUtil.setFieldValue(t, UPDATE_BY, loginUser.getUsername());
            }
            if (ReflectUtil.hasField(tClass, UPDATE_BY_LABEL)) {
                ReflectUtil.setFieldValue(t, UPDATE_BY_LABEL, loginUser.getUserNameLabel());
            }
        } catch (Exception ignored) {
        }
        if (ReflectUtil.hasField(tClass, UPDATE_TIME)) {
            ReflectUtil.setFieldValue(t, UPDATE_TIME, new Date());
        }
        return t;
    }
}