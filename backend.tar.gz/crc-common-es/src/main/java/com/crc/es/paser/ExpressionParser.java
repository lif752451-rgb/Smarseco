package com.crc.es.paser;

import com.crc.common.utils.DataUtils;
import org.apache.commons.lang3.StringUtils;

import java.util.HashMap;
import java.util.Map;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * 负责读取表达式生成ExpressionNode对象的类
 *
 * @项目名称: secface
 * @类名称: ExpressionParser
 * @类描述:
 * @创建人: 何景生
 * @创建时间: 2017年12月15日 上午9:52:59
 * @修改人: 何景生
 * @修改时间: 2017年12月15日 上午9:52:59
 * @修改备注:
 * @version: 1.0
 */
public class ExpressionParser {

    // 当前分析的表达式
    private String expression;

    private Map<String, String> dataMap;
    public HashMap<String, String> tmpMap = new HashMap<>();

    // 当前读取的位置
    private int position;

    public String getExpression() {
        return expression;
    }

    public void setExpression(String expression) {
        this.expression = expression;
    }

    public int getPosition() {
        return position;
    }

    public void setPosition(int position) {
        this.position = position;
    }

    public ExpressionParser(String expression) {
        String tempX = expression.replace("\\\"", "@@");
        String regex = "\"(.*?)\"";

        Pattern pattern = Pattern.compile(regex);
        Matcher matcher = pattern.matcher(tempX);
        int index = 0;
        while (matcher.find()) {
            String key = String.format("#%d#", index++);
            String data = matcher.group(1);
            tmpMap.put(key, data);
            tempX = tempX.replace(data, key);
        }
        String tempStr = tempX.replace(":", " ").replace("(", "").replace(")", "");
        dataMap = new HashMap<>();
        for (String data : tempStr.split(" ")) {
            if (StringUtils.isNotBlank(data)) {
                if (">=".equals(data) || "<=".equals(data) || ">".equals(data) || "<".equals(data)) {
                    continue;
                }
                dataMap.put(data.toLowerCase(), data);
            }
        }
        this.expression = tempX;
        position = 0;
    }

    public ExpressionParser(int position) {
        this.position = position;
    }

    /**
     * 读取下一个表达式节点,如果读取失败则返回null
     *
     * @return
     */
    public ExpressionNode readNode() {

        boolean specialChar = false;

        ExpressionNode s = new ExpressionNode(null);
        // 空格的位置
        int whileSpacePos = -1;
        boolean flag = false;
        StringBuffer buffer = new StringBuffer();
        boolean fullKey = false;
        while (this.position < this.expression.length()) {
            char c = this.expression.charAt(this.position);

            char lastChar = DataUtils.getCharAt(this.expression, this.position - 1);
            if (c == '"' && lastChar != '\\') { //并且不是转义
                flag = !flag;
                if (!flag) {
                    this.position++;
                    buffer.append(c);
                    break;
                }
                if (buffer.length() != 0) {
                    break;
                }
            }
            if (flag) {
                this.position++;
                buffer.append(c);
            } else {
                if (s.IsWhileSpace(c)) {
                    if ((whileSpacePos >= 0) && ((this.position - whileSpacePos) > 1)) {
                        //throw new ExpressionException(
                        //        String.format("表达式\"%s\"在位置(%s)上的字符非法!", this.getExpression(), this.getPosition()));
                    }
                    if (buffer.length() == 0) {
                        whileSpacePos = -1;
                    } else {
                        whileSpacePos = this.position;
                    }
                    this.position++;
                    specialChar = true;
                    continue;
                }
                if (c == ':') {
                    specialChar = true;
                }
                if (dataMap.containsKey(buffer.toString().toLowerCase()) && specialChar) {
                    fullKey = true;
                    /**
                     * 这里加specialChar原因为：
                     * 如果kql为：src_ip:"10.0.197.177" and src_ip_type:"内网"
                     * 那么后面的src_ip_type由于包含了src_ip，那么导致了当遍历至src_ip时，
                     * 会因为dataMap包含了src_ip而跳出循环
                     * 一开始想直接用map移除key的方式，结果发现如果kql里面有多个相同运算符
                     * 那么会一次性讲相同的key全部移除，导致kql解析错误，所以暂用specialChar判断
                     */
                    //dataMap.remove(buffer.toString().toLowerCase());
                    break;//获取完整了一个字段Key 或 Value
                }

                /**
                 * 修改原因：
                 * 或条件后面的语句是为了：not age >= 10 这种情况出现bug，但是同时会影响到
                 * 类似：qw5abc.keyword : "123456" 这种格式
                 * 解决方案是：需要判断中间是否出现过空格，
                 * 如果没有：那么说明是同一个字符串
                 * 如果有：说明是两个字符串
                 */
                if (this.position > 0) {
                    char spaceChar = this.expression.charAt(this.position - 1);
                    if (buffer.length() == 0) {
                        this.position++;
                        buffer.append(c);
                    } else {
                        if (!s.IsCongener(c, buffer.charAt(buffer.length() - 1))) {
                            /**
                             * 如果是括号或者引号，则直接break
                             */
                            break;
                        }
                        if (!s.isAllNum(c, buffer.charAt(buffer.length() - 1))) {
                            if (spaceChar == ' ') {
                                break;
                            } else {
                                this.position++;
                                buffer.append(c);
                            }
                        } else {
                            this.position++;
                            buffer.append(c);
                        }
                    }
                } else {
                    this.position++;
                    buffer.append(c);
                }
            }
        }
        if (buffer.length() == 0) {
            return null;
        }
        //System.out.println(buffer);
        String nodeValue = buffer.toString();
        ExpressionNode node = new ExpressionNode(nodeValue);
        if (fullKey) {
            if ("not".equalsIgnoreCase(buffer.toString())) {
                node.setType(ExpressionNodeType.Not);
            } else if ("and".equalsIgnoreCase(buffer.toString())) {
                node.setType(ExpressionNodeType.And);
            } else if ("or".equalsIgnoreCase(buffer.toString())) {
                node.setType(ExpressionNodeType.Or);
            } else if (">=".equalsIgnoreCase(buffer.toString())) {
                node.setType(ExpressionNodeType.GTOrEqual);
            } else if ("<=".equalsIgnoreCase(buffer.toString())) {
                node.setType(ExpressionNodeType.LTOrEqual);
            } else if (">".equalsIgnoreCase(buffer.toString())) {
                node.setType(ExpressionNodeType.GT);
            } else if ("<".equalsIgnoreCase(buffer.toString())) {
                node.setType(ExpressionNodeType.LT);
            } else {
                if (node.isNumerics(buffer.toString())) {
                    node.setType(ExpressionNodeType.Numeric);
                } else
                    node.setType(ExpressionNodeType.String);
            }
        }
        if (node.getType() == ExpressionNodeType.Unknown) {
            throw new ExpressionException(String.format("表达式\"%s\"在位置%s上的字符\"%s\"非法!,buffer=%s", this.getExpression(),
                    this.getPosition() - node.getValue().length(), node.getValue(), buffer.toString()));
        }
        if (node.getValue().startsWith("\"")) {
            nodeValue = DataUtils.getSubString(nodeValue, 1, nodeValue.length() - 1);
            if (StringUtils.isNotBlank(nodeValue))
                node.setValue(nodeValue);
        }
        return node;
    }

}
