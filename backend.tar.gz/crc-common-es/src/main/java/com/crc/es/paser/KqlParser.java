package com.crc.es.paser;

import com.alibaba.fastjson.JSON;
import org.apache.commons.lang3.StringUtils;
import org.apache.commons.text.StringEscapeUtils;
import org.elasticsearch.index.query.BoolQueryBuilder;
import org.elasticsearch.index.query.QueryBuilders;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.ArrayList;
import java.util.List;
import java.util.Stack;
import java.util.regex.Pattern;

/*
 *  负责解析KQL，转换为DSL
 *  何景生
 *  2022-02-25
 */
public class KqlParser {
    private static Logger logger = LoggerFactory.getLogger(KqlParser.class);

    public String clean(String kql) {
        if (StringUtils.isBlank(kql))
            return "";
        try {
            Object k = JSON.parse(kql);
            return k.toString();
        } catch (Exception e) {
            kql = kql.replace(":", " : ").replace("  ", " ").replace("\" \"", "\"\"").replace(") \"", ")\"");
            String newKQL = kql;//StringEscapeUtils.unescapeJava(kql);
            //System.out.println(kql);
            if (newKQL.startsWith("\"") && newKQL.endsWith("\"\"")) {
                newKQL = newKQL.substring(1, newKQL.length() - 1);
            } else if (newKQL.startsWith("\"") && newKQL.endsWith(")\"")) {
                newKQL = newKQL.substring(1, newKQL.length() - 1);
            }
            kql = StringEscapeUtils.unescapeHtml4(newKQL);
            return kql;
        }
    }

    /**
     * 解析KQL
     *
     * @param kql
     */
    private NodeMap parseExpression(String kql) {
        NodeMap nodeMap = new NodeMap();
        if (StringUtils.isEmpty(kql)) {
            return nodeMap;
        }

        kql = clean(kql);//KQL清洗下

        List<ExpressionNode> listOperator = new ArrayList<>();
        Stack<ExpressionNode> stackOperator = new Stack<>();

        ExpressionParser expParser = new ExpressionParser(kql);
        expParser.setPosition(0);
        System.out.println(expParser.getPosition());
        ExpressionNode beforeExpNode = null; // 前一个节点
        ExpressionNode unitaryNode = null; // 一元操作符
        ExpressionNode expNode;
        // 是否需要操作数
        boolean requireOperand = false;

        while ((expNode = expParser.readNode()) != null) {
            if ((expNode.getType() == ExpressionNodeType.Numeric)
                    || (expNode.getType() == ExpressionNodeType.String)) {
                // 操作数， 直接加入后缀表达式中
                if (unitaryNode != null) {
                    // 设置一元操作符节点
                    expNode.setUnitaryNode(unitaryNode);
                    unitaryNode = null;
                }

                listOperator.add(expNode);
                requireOperand = false;
                continue;
            } else if (expNode.getType() == ExpressionNodeType.LParentheses) {
                // 左括号， 直接加入操作符栈
                stackOperator.push(expNode);
                continue;
            } else if (expNode.getType() == ExpressionNodeType.RParentheses) {
                // 右括号则在操作符栈中反向搜索，直到遇到匹配的左括号为止，将中间的操作符依次加到后缀表达式中。
                ExpressionNode lpNode = null;
                while (stackOperator.size() > 0) {
                    lpNode = stackOperator.pop();
                    if (lpNode.getType() == ExpressionNodeType.LParentheses)
                        break;
                    listOperator.add(lpNode);
                }
                if (lpNode == null || lpNode.getType() != ExpressionNodeType.LParentheses) {
                    throw new ExpressionException(String.format("在表达式\"%s\"中没有与在位置(%s)上\")\"匹配的\"(%s)\"字符!", expParser.getExpression(), expParser.getPosition()));
                }
            } else {
                //System.out.println("$$$"+JSON.toJSONString(stackOperator));
                if (stackOperator.size() == 0) {
                    // 第一个节点则判断此节点是否是一元操作符"+,-,!,("中的一个,否则其它都非法
                    if (listOperator.size() == 0 && !(expNode.getType() == ExpressionNodeType.LParentheses
                            || expNode.getType() == ExpressionNodeType.Not)) {
                        // 后缀表达式没有任何数据则判断是否是一元操作数
                        // 丢失操作数
                        throw new ExpressionException(String.format("表达式\"%s\"在位置(%s)上缺少操作数!",
                                expParser.getExpression(), expParser.getPosition()));
                    } else {
                        // 直接压入操作符栈
                        stackOperator.push(expNode);
                    }
                    requireOperand = true; // 下一个节点需要操作数
                    continue;
                } else {
                    if (requireOperand) {
                        //增加NOT操作判断
                        if (expNode.getType() != ExpressionNodeType.Not) {
                            // 如果需要操作数则判断当前的是否是"+","-"号(一元操作符),如果是则继续
                            throw new ExpressionException(String.format("表达式\"%s\"在位置(%d)上缺少操作数!%s",
                                    expParser.getExpression(), expParser.getPosition(), JSON.toJSONString(expNode)));
                        } else {
                            // 直接压入操作符栈
                            stackOperator.push(expNode);
                        }
                    } else {
                        // 对前面的所有操作符进行优先级比较
                        do {
                            // 取得上一次的操作符
                            beforeExpNode = stackOperator.peek();

                            // 如果前一个操作符优先级较高，则将前一个操作符加入后缀表达式中，增加NOT操作判断
                            if (beforeExpNode.getType() != ExpressionNodeType.LParentheses
                                    && (beforeExpNode.getPri() - expNode.getPri()) >= 0 && (beforeExpNode.getType() != ExpressionNodeType.Not)) {
                                listOperator.add(stackOperator.pop());
                            } else {
                                break;
                            }

                        } while (stackOperator.size() > 0);

                        // 将操作符压入操作符栈
                        stackOperator.push(expNode);
                        requireOperand = true;
                    }
                }
            }
        }

        if (requireOperand) {
            // 丢失操作数
            throw new ExpressionException(
                    String.format("表达式\"%s\"在位置({1})上缺少操作数!", expParser.getExpression(), expParser.getPosition()));
        }
        // 清空堆栈
        while (stackOperator.size() > 0) {
            // 取得操作符
            beforeExpNode = stackOperator.pop();
            if (beforeExpNode.getType() == ExpressionNodeType.LParentheses) {
                throw new ExpressionException(String.format("表达式\"%s\"中括号不匹配,丢失右括号!", expParser.getExpression(),
                        expParser.getPosition()));
            }
            listOperator.add(beforeExpNode);
        }
        nodeMap.setNodes(listOperator);
        nodeMap.setKeyMap(expParser.tmpMap);
        return nodeMap;
    }


    /**
     * @param expression 要计算的表达式,如"1+2+3+4"
     * @return 返回计算结果, 如果带有逻辑运算符则返回true/false,否则返回数值
     */
    public KqlResult parse(String expression) {
        boolean flag = false;
        KqlResult kqlResult = new KqlResult();
        kqlResult.setKql(clean(expression));
        try {
            NodeMap nodeMap = parseExpression(expression);

            BoolQueryBuilder query = toDsl(nodeMap);
            if (query != null) {
                kqlResult.setQuery(query);
            }

            flag = nodeMap.getNodes().size() > 0;
        } catch (Exception e) {
            logger.error(e.getMessage(), e);
        }
        if (!flag) {
            kqlResult.setMessage("解析KQL失败，请检查语句是否合法！");
            kqlResult.setCode(0);
        }
        return kqlResult;
    }


    /**
     * 对逆波兰表达式进行计算
     *
     * @param nodeMap
     * @return
     */
    @SuppressWarnings({"rawtypes", "unchecked", "incomplete-switch"})
    private BoolQueryBuilder toDsl(NodeMap nodeMap) {
        if (nodeMap == null || nodeMap.getNodes().size() == 0)
            return null;


        for (ExpressionNode node : nodeMap.getNodes()) {
            if (nodeMap.getKeyMap() != null) {
                nodeMap.getKeyMap().forEach((k, v) -> {
                    if (node.getValue().contains(k)) {
                        node.setValue(node.getValue().replace(k, v));
                    }
                });
            }
            String value = node.getValue();
            if (value != null) {
                if (value.contains("@@")) {
                    value = value.replace("@@", "\\\"");
                    node.setValue(value);
                }
            }
        }

        ArrayList<DslNode> dslNodes = new ArrayList<>();
        int index = 0;
        List<ExpressionNode> nodes = nodeMap.getNodes();
        for (ExpressionNode node : nodes) {
            if (node.getType() == ExpressionNodeType.Equal) {
                //等于 key与value合并
                String value = nodes.get(index - 1).getValue();
                String newKey = value.replace("\"", "");
                if (nodeMap.getKeyMap() != null && nodeMap.getKeyMap().containsKey(newKey)) {
                    value = nodeMap.getKeyMap().get(newKey);
                    if (value != null) {
                        value = value.replace("@@", "\\\"");
                    }
                }
                KqlResult ret = DslNode.createShouldQuery(nodes.get(index - 2).getValue(), value);
                if (value != null && value.contains("*")) {
                    String tempKey = nodes.get(index - 2).getValue();
                    if (hasChinese(value) && !tempKey.contains(".keyword")) {
                        ret = DslNode.createWildQuery(nodes.get(index - 2).getValue() + ".keyword", value);
                    } else {
                        ret = DslNode.createWildQuery(nodes.get(index - 2).getValue(), value);
                    }
                }
                if (ret.getCode() > 0)
                    dslNodes.add(DslNode.createNode(ExpressionNodeType.String, ret.getQuery()));
            } else if (node.getPri() == 3) {
                //> >= <= < 范围比较
                String value = nodes.get(index - 1).getValue();
                if (node.isNumerics(value)) {
                    KqlResult ret = DslNode.createRangeQuery(nodes.get(index - 2).getValue(), value, node.getType());
                    if (ret.getCode() > 0)
                        dslNodes.add(DslNode.createNode(ExpressionNodeType.String, ret.getQuery()));
                }

            } else if (node.getPri() > 0) {
                //非比较
                dslNodes.add(DslNode.createNode(node.getType(), null));
            }
            index++;
        }

        BoolQueryBuilder boolBuilder = QueryBuilders.boolQuery();
        if (dslNodes.size() > 0) {
            BoolQueryBuilder notQueryList = QueryBuilders.boolQuery();
            List<DslNode> newNodes = subDsl(dslNodes, notQueryList);
            int count = 0;
            while (newNodes.size() > 1 && count < 50) {
                count++;
                newNodes = subDsl(newNodes, notQueryList);
            }
            if (newNodes.size() > 0) {
                boolBuilder.filter(newNodes.get(0).getQuery());
            }
            if(!isBlankQuery(notQueryList))
                boolBuilder.mustNot().add(notQueryList);
        }
        return boolBuilder;
    }

    private List<DslNode> subDsl(List<DslNode> dslNodes, BoolQueryBuilder notQueryList) {

        int index = 0;
        //ExpressionNodeType beforeType = ExpressionNodeType.Unknown;
        List<DslNode> newDslNodes = new ArrayList<>();
        if (dslNodes.size() == 1) {
            return dslNodes;
        }
        BoolQueryBuilder lastQuery = QueryBuilders.boolQuery();
        //逐个合并DSL
        for (DslNode dslNode : dslNodes) {

            if (dslNode.getType() == ExpressionNodeType.And) {
                dslNode.setStatus(1);
                dslNodes.get(index - 2).setStatus(1);
                dslNodes.get(index - 1).setStatus(1);
                lastQuery.filter(dslNodes.get(index - 2).getQuery());
                lastQuery.filter(dslNodes.get(index - 1).getQuery());
                break;
            } else if (dslNode.getType() == ExpressionNodeType.Or) {
                dslNode.setStatus(1);
                dslNodes.get(index - 2).setStatus(1);
                dslNodes.get(index - 1).setStatus(1);
                lastQuery.should(dslNodes.get(index - 2).getQuery()).minimumShouldMatch(1);
                lastQuery.should(dslNodes.get(index - 1).getQuery()).minimumShouldMatch(1);
                break;
            } else if (dslNode.getType() == ExpressionNodeType.Not) {
                dslNode.setStatus(1);
                dslNodes.get(index - 1).setStatus(1);
                notQueryList.should(dslNodes.get(index - 1).getQuery()).minimumShouldMatch(1);
                break;
            }
            index++;
        }

        boolean flag = false;
        for (DslNode dslNode : dslNodes) {
            if (dslNode.getStatus() != 1) {
                newDslNodes.add(dslNode);
            } else {
                if (!flag) {
                    DslNode node = DslNode.createNode(ExpressionNodeType.String, lastQuery);
                    newDslNodes.add(node);
                }
                flag = true;
            }
        }

        return newDslNodes;
    }

    public static boolean isBlankQuery(BoolQueryBuilder queryBuilder) {
        if (queryBuilder == null) {
            return true;
        }
        if(queryBuilder.should().size() < 1 && queryBuilder.filter().size() < 1 && queryBuilder.mustNot().size() < 1 && queryBuilder.must().size() < 1)
            return true;

        return false;
    }

    public static boolean hasChinese(CharSequence content) {
        if (null == content) {
            return false;
        }
        String regex = "[\u2E80-\u2EFF\u2F00-\u2FDF\u31C0-\u31EF\u3400-\u4DBF\u4E00-\u9FFF\uF900-\uFAFF\uD840\uDC00-\uD869\uDEDF\uD869\uDF00-\uD86D\uDF3F\uD86D\uDF40-\uD86E\uDC1F\uD86E\uDC20-\uD873\uDEAF\uD87E\uDC00-\uD87E\uDE1F]+";
        Pattern pattern = Pattern.compile(regex);
        return pattern.matcher(content).find();
    }

    public static void main(String[] args) {
        ExpressionParser expressionParser = new ExpressionParser(0);
        System.out.println("======");
        System.out.println(expressionParser.getPosition());
    }

}
