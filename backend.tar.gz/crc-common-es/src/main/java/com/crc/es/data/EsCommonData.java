package com.crc.es.data;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;
import com.crc.es.pool.EsSingleFactory;
import com.crc.es.utils.EsUtils;
import com.crc.es.vo.EsDataSource;
import lombok.extern.slf4j.Slf4j;
import org.elasticsearch.client.RequestOptions;
import org.elasticsearch.client.RestHighLevelClient;
import org.elasticsearch.client.indices.GetMappingsRequest;
import org.elasticsearch.client.indices.GetMappingsResponse;
import org.elasticsearch.cluster.metadata.MappingMetadata;

import java.util.LinkedHashMap;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.atomic.AtomicBoolean;
import java.util.concurrent.atomic.AtomicReference;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

@Slf4j
public class EsCommonData {
    /**
     * SSP告警日志查询表头缓存
     */
    public static ConcurrentHashMap<String, JSONObject> advSearchHeads = new ConcurrentHashMap<>();

    /**
     * ES 索引mapping查询
     *
     * @param indexAndSource 条件
     * @return 结果
     */
    public static JSONObject getAdvHeader(Map<String, String> indexAndSource) {
        EsDataSource esDataSource = EsUtils.logSourceCheck(indexAndSource);
        return getAdvHeader(esDataSource);
    }


    /**
     * ES 索引mapping查询
     *
     * @param esDataSource 条件
     * @return 结果
     */
    public static JSONObject getAdvHeader(EsDataSource esDataSource) {
        RestHighLevelClient client = null;
        try {
            if (esDataSource == null) {
                log.warn("数据源配置有误");
                return null;
            }
            client = EsSingleFactory.getInstance().getHighLevelClientHigh(esDataSource);
            if (client == null) {
//                log.warn("数据源配置有误：{}", JSON.toJSONString(esDataSource));
                return null;
            }
            GetMappingsRequest request = new GetMappingsRequest();
            String index = esDataSource.getIndexRule();
            request.indices(index);
            GetMappingsResponse response = client.indices().getMapping(request, RequestOptions.DEFAULT);
            Map<String, MappingMetadata> mappings = response.mappings();
            AtomicReference<JSONObject> propertiesJson = new AtomicReference<>();
            if (index.contains("*")) {
                index = index.replaceAll("\\*", "[\\\\w-\\.]+");
                Pattern pattern = Pattern.compile(index);
                AtomicBoolean flag = new AtomicBoolean(true);
                mappings.forEach((k, v) -> {
                    Matcher matcher = pattern.matcher(k);
                    if (matcher.matches() && flag.get()) {
                        JSONObject jsonObject = new JSONObject(v.sourceAsMap());
                        propertiesJson.set(jsonObject);
                        flag.set(false);
                    }
                });
            } else {
                Map<String, Object> stringObjectMap = mappings.get(index).sourceAsMap();
                JSONObject jsonObject = new JSONObject(stringObjectMap);
                propertiesJson.set(jsonObject);
            }
            if (propertiesJson.get() != null) {
                JSONObject properties = propertiesJson.get().getJSONObject("properties");
                if (properties != null) {
                    properties.forEach((k, v) -> {
                        if (v instanceof JSONObject) {
                            JSONObject jsonObject = (JSONObject) v;
                            jsonObject.remove("fields");
                        } else if (v instanceof LinkedHashMap) {
                            LinkedHashMap jsonObject = (LinkedHashMap) v;
                            jsonObject.remove("fields");
                        }
                    });
                    return properties;
                }
            }
        } catch (Exception ignored) {
            log.error("查询ES mappings失败：{}", ignored);
        } finally {
            EsSingleFactory.getInstance().close(client);
        }
        return null;
    }
}
