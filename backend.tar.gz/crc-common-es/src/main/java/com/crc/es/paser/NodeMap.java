package com.crc.es.paser;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

public class NodeMap {
    List<ExpressionNode> nodes;
    HashMap<String, String> keyMap;


    public List<ExpressionNode> getNodes() {
        if(nodes == null){
            return new ArrayList<>();
        }
        return nodes;
    }

    public void setNodes(List<ExpressionNode> nodes) {
        this.nodes = nodes;
    }

    public HashMap<String, String> getKeyMap() {
        return keyMap;
    }

    public void setKeyMap(HashMap<String, String> keyMap) {
        this.keyMap = keyMap;
    }
}
