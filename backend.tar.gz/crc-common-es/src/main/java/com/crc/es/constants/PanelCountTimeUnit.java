package com.crc.es.constants;

/**
 * @author simba@onlying.cn
 * @date 2020/8/3 16:23
 */
public enum PanelCountTimeUnit {
    LAST_HOURS("1","最近一小时","resolveTimeByMinusHour"),
    LAST_DAYS("2","最近一天","resolveTimeByMinusDays"),
    LAST_WEEKS("3","最近一周","resolveTimeByMinusWeeks"),
    LAST_MONTHS("4","最近一个月","resolveTimeByMinusMonths"),
    LAST_YEARS("5","最近一年","func5");

    private String type;

    private String interval;

    private String func;

    PanelCountTimeUnit(String type, String interval, String func){
        this.type = type;
        this.interval = interval;
        this.func = func;
    }

  public static PanelCountTimeUnit resolveByType(String type){
        for(PanelCountTimeUnit timeUnit:PanelCountTimeUnit.values()){
            if(timeUnit.getType().equalsIgnoreCase(type)){
                return timeUnit;
            }
        }
        return null;
  }




    public String getType() {
        return type;
    }

    public String getInterval() {
        return interval;
    }

    public String getFunc() {
        return func;
    }

}
