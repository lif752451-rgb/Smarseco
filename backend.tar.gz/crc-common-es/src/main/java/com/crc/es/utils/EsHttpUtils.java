package com.crc.es.utils;

import com.crc.common.utils.StringUtils;
import com.crc.common.utils.http.HttpUtils;
import com.crc.es.config.ElasticsearchProperties;
import org.apache.commons.codec.binary.Base64;
import org.apache.commons.io.IOUtils;
import org.apache.http.HttpHeaders;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import javax.net.ssl.*;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.net.ConnectException;
import java.net.HttpURLConnection;
import java.net.SocketTimeoutException;
import java.net.URL;
import java.nio.charset.Charset;
import java.nio.charset.StandardCharsets;
import java.security.cert.X509Certificate;
import java.util.Map;

/**
 * @author SHUFENGFENG
 */
public class EsHttpUtils {
    private static final Logger log = LoggerFactory.getLogger(HttpUtils.class);
    private static int CONN_TIME_OUT = 60000;
    private static int READ_TIME_OUT = 60000;

    public static String sendSSLGet(ElasticsearchProperties elasticsearchProperties, String url)  {
        StringBuilder result = new StringBuilder();
        BufferedReader in = null;
        OutputStreamWriter out = null;
        HttpURLConnection connection = null;
        try {
            URL urlx = new URL(url);
            connection = (HttpURLConnection) urlx.openConnection();
            // 设置doOutput属性为true表示将使用此urlConnection写入数据
            connection.setDoOutput(true);
            if (!"simple".equals(elasticsearchProperties.getMode())) {
                String userName = elasticsearchProperties.getUserName();
                String password = elasticsearchProperties.getPassword();
                String auth = userName + ":" + password;
                byte[] encodedAuth = Base64.encodeBase64(auth.getBytes(StandardCharsets.US_ASCII));
                String authHeader = "Basic " + new String(encodedAuth);
                connection.setRequestProperty(HttpHeaders.AUTHORIZATION, authHeader);
                String proxyHeader = elasticsearchProperties.getProxyHeader();
                connection.setRequestProperty("X-Found-Cluster", proxyHeader);
            }
            connection.setRequestProperty("accept", "*/*");
            connection.setRequestProperty("connection", "Keep-Alive");
            connection.setRequestProperty("user-agent", "Mozilla/4.0 (compatible; MSIE 6.0; Windows NT 5.1;SV1)");
            connection.setRequestMethod("GET");
            connection.setRequestProperty("content-type", "application/json");
            connection.setConnectTimeout(CONN_TIME_OUT);
            connection.setReadTimeout(READ_TIME_OUT);
            connection.connect();
            in = new BufferedReader(new InputStreamReader(connection.getInputStream(), StandardCharsets.UTF_8));
            String line;
            while ((line = in.readLine()) != null) {
                result.append(line + "\r");
            }
        } catch (ConnectException e) {
            log.error("调用HttpUtils.sendGet ConnectException, url=" + url + e);
        } catch (SocketTimeoutException e) {
            log.error("调用HttpUtils.sendGet SocketTimeoutException, url=" + url + e);
        } catch (IOException e) {
            log.error("调用HttpUtils.sendGet IOException, url=" + url + e);
        } catch (Exception e) {
            log.error("调用HttpsUtil.sendGet Exception, url=" + url + e);
        } finally {
            IOUtils.closeQuietly(in);
            IOUtils.closeQuietly(out);
            try {
                if (connection != null)
                    connection.disconnect();
            } catch (Exception e) {

            }
        }
        return result.toString();
    }

    /**
     * 向指定 URL 发送GET方法的请求
     *
     * @param url   发送请求的 URL
     * @param param 请求参数，请求参数应该是 name1=value1&name2=value2 的形式。
     * @return 所代表远程资源的响应结果
     */
    public static String sendSSLGet(ElasticsearchProperties esConfig, String url, String param, Map<String, String> headerMap) {
        StringBuilder result = new StringBuilder();
        BufferedReader in = null;
        HttpsURLConnection connection = null;
        try {
            String urlNameString = url + "?" + param;
            if (StringUtils.isBlank(param)) {
                urlNameString = url;
            }
            log.info("sendGet - {}", urlNameString);
            SSLContext sc = SSLContext.getInstance("SSL");
            sc.init(null, new TrustManager[]{new TrustAnyTrustManager()}, new java.security.SecureRandom());
            URL console = new URL(urlNameString);
            connection = (HttpsURLConnection) console.openConnection();
            connection.setRequestProperty("accept", "*/*");
            connection.setRequestProperty("connection", "Keep-Alive");
            connection.setRequestProperty("user-agent", "Mozilla/4.0 (compatible; MSIE 6.0; Windows NT 5.1;SV1)");
            for (String key : headerMap.keySet()) {
                connection.setRequestProperty(key, headerMap.get(key));
            }
            String userName = esConfig.getUserName();
            String password = esConfig.getPassword();
            String auth = userName + ":" + password;
            byte[] encodedAuth = Base64.encodeBase64(auth.getBytes(StandardCharsets.US_ASCII));
            String authHeader = "Basic " + new String(encodedAuth);
            connection.setRequestProperty(HttpHeaders.AUTHORIZATION, authHeader);
            String proxyHeader = esConfig.getProxyHeader();
            connection.setRequestProperty("X-Found-Cluster", proxyHeader);
            connection.setRequestProperty("content-type", "application/json");
            connection.setConnectTimeout(CONN_TIME_OUT);
            connection.setReadTimeout(READ_TIME_OUT);
            connection.connect();
            in = new BufferedReader(new InputStreamReader(connection.getInputStream()));
            String line;
            while ((line = in.readLine()) != null) {
                result.append(line);
            }
            log.info("recv - {}", result);
        } catch (ConnectException e) {
            log.error("调用HttpUtils.sendGet ConnectException, url=" + url + ",param=" + param, e);
        } catch (SocketTimeoutException e) {
            log.error("调用HttpUtils.sendGet SocketTimeoutException, url=" + url + ",param=" + param, e);
        } catch (IOException e) {
            log.error("调用HttpUtils.sendGet IOException, url=" + url + ",param=" + param, e);
        } catch (Exception e) {
            log.error("调用HttpsUtil.sendGet Exception, url=" + url + ",param=" + param, e);
        } finally {
            IOUtils.closeQuietly(in);
            try {
                connection.disconnect();
            } catch (Exception ignored) {

            }
        }
        return result.toString();
    }

    private static class TrustAnyTrustManager implements X509TrustManager {
        @Override
        public void checkClientTrusted(X509Certificate[] chain, String authType) {
        }

        @Override
        public void checkServerTrusted(X509Certificate[] chain, String authType) {
        }

        @Override
        public X509Certificate[] getAcceptedIssuers() {
            return new X509Certificate[]{};
        }
    }

    private static class TrustAnyHostnameVerifier implements HostnameVerifier {
        @Override
        public boolean verify(String hostname, SSLSession session) {
            return true;
        }
    }

    /**
     * 向指定 URL 发送GET方法的请求
     *
     * @param url 发送请求的 URL
     * @return 所代表远程资源的响应结果
     */
    public static String sendSSLGet(String url, String json) {
        StringBuilder result = new StringBuilder();
        BufferedReader in = null;
        OutputStreamWriter out = null;
        HttpURLConnection connection = null;
        try {
            URL urlx = new URL(url);
            connection = (HttpURLConnection) urlx.openConnection();
            // 设置doOutput属性为true表示将使用此urlConnection写入数据
            connection.setDoOutput(true);
            String userName = "readonly";
            String password = "V31l9G9ku8nY2876Kq9RmlGZ";
            String auth = userName + ":" + password;
            byte[] encodedAuth = Base64.encodeBase64(auth.getBytes(Charset.forName("US-ASCII")));
            String authHeader = "Basic " + new String(encodedAuth);
            connection.setRequestProperty(HttpHeaders.AUTHORIZATION, authHeader);
            String proxyHeader = "8994b14fd0ba4c5fabef5e6851a38c56";
            connection.setRequestProperty("X-Found-Cluster", proxyHeader);
            connection.setRequestProperty("accept", "*/*");
            connection.setRequestProperty("connection", "Keep-Alive");
            connection.setRequestProperty("Content-Length", "1000");
            System.setProperty("java.net.preferIPv4Stack" , "true");
            connection.setRequestProperty("user-agent", "Mozilla/4.0 (compatible; MSIE 6.0; Windows NT 5.1;SV1)");
            connection.setRequestProperty("content-type", "application/json");
            connection.setConnectTimeout(CONN_TIME_OUT);
            connection.setReadTimeout(READ_TIME_OUT);
            // 得到请求的输出流对象
            out = new OutputStreamWriter(connection.getOutputStream());
            // 把数据写入请求的Body
            connection.connect();
            if (StringUtils.isNotBlank(json)) {
                out.write(json);
                out.flush();
            }
            //System.out.println(DateUtils.getDateTimeString2(new Date()));
            in = new BufferedReader(new InputStreamReader(connection.getInputStream(), StandardCharsets.UTF_8));
            String line;
            while ((line = in.readLine()) != null) {
                result.append(line);
            }
            //System.out.println(DateUtils.getDateTimeString2(new Date()));
        } catch (ConnectException e) {
            log.error("调用HttpUtils.sendGet ConnectException, url=" + url, e);
        } catch (SocketTimeoutException e) {
            log.error("调用HttpUtils.sendGet SocketTimeoutException, url=" + url, e);
        } catch (IOException e) {
            log.error("调用HttpUtils.sendGet IOException, url=" + url, e);
        } catch (Exception e) {
            log.error("调用HttpsUtil.sendGet Exception, url=" + url, e);
        } finally {
            IOUtils.closeQuietly(in);
            IOUtils.closeQuietly(out);
            try {
                if (connection != null) {
                    connection.disconnect();
                }
            } catch (Exception e) {

            }
        }
        return result.toString();
    }

    /**
     * 向指定 URL 发送GET方法的请求
     *
     * @param url 发送请求的 URL
     * @return 所代表远程资源的响应结果
     */
    public static String sendSSLGet(ElasticsearchProperties esConfig, String url, String json) {
        //System.out.println(url);
        StringBuilder result = new StringBuilder();
        BufferedReader in = null;
        OutputStreamWriter out = null;
        HttpURLConnection connection = null;
        try {
            URL urlx = new URL(url);
            connection = (HttpURLConnection) urlx.openConnection();
            // 设置doOutput属性为true表示将使用此urlConnection写入数据
            connection.setDoOutput(true);
            String userName = esConfig.getUserName();
            String password = esConfig.getPassword();
            String auth = userName + ":" + password;
            byte[] encodedAuth = Base64.encodeBase64(auth.getBytes(StandardCharsets.US_ASCII));
            String authHeader = "Basic " + new String(encodedAuth);
            connection.setRequestProperty(HttpHeaders.AUTHORIZATION, authHeader);
            String proxyHeader = esConfig.getProxyHeader();
            connection.setRequestProperty("X-Found-Cluster", proxyHeader);
            connection.setRequestProperty("accept", "*/*");
            connection.setRequestProperty("connection", "Keep-Alive");
            connection.setRequestProperty("Content-Length", "1000");
            System.setProperty("java.net.preferIPv4Stack", "true");
            connection.setRequestProperty("user-agent", "Mozilla/4.0 (compatible; MSIE 6.0; Windows NT 5.1;SV1)");
            connection.setRequestProperty("content-type", "application/json");
            connection.setConnectTimeout(CONN_TIME_OUT);
            connection.setReadTimeout(READ_TIME_OUT);
            // 得到请求的输出流对象
            out = new OutputStreamWriter(connection.getOutputStream());
            // 把数据写入请求的Body
            connection.connect();
            if (StringUtils.isNotBlank(json)) {
                out.write(json);
                out.flush();
            }
            //System.out.println(DateUtils.getDateTimeString2(new Date()));
            in = new BufferedReader(new InputStreamReader(connection.getInputStream(), StandardCharsets.UTF_8));
            String line;
            while ((line = in.readLine()) != null) {
                result.append(line);
            }
            //System.out.println(DateUtils.getDateTimeString2(new Date()));
        } catch (ConnectException e) {
            log.error("调用HttpUtils.sendGet ConnectException, url=" + url, e);
        } catch (SocketTimeoutException e) {
            log.error("调用HttpUtils.sendGet SocketTimeoutException, url=" + url, e);
        } catch (IOException e) {
            log.error("调用HttpUtils.sendGet IOException, url=" + url, e);
        } catch (Exception e) {
            log.error("调用HttpsUtil.sendGet Exception, url=" + url, e);
        } finally {
            IOUtils.closeQuietly(in);
            IOUtils.closeQuietly(out);
            try {
                if (connection != null) {
                    connection.disconnect();
                }
            } catch (Exception e) {

            }
        }
        return result.toString();
    }


    /**
     * 向指定 URL 发送GET方法的请求
     *
     * @param url 发送请求的 URL
     * @return 所代表远程资源的响应结果
     */
    public static String sendSSLGet(String userName, String password, String proxyHeader, String url, String json) {
        StringBuilder result = new StringBuilder();
        BufferedReader in = null;
        OutputStreamWriter out = null;
        HttpURLConnection connection = null;
        try {
            URL urlx = new URL(url);
            connection = (HttpURLConnection) urlx.openConnection();
            // 设置doOutput属性为true表示将使用此urlConnection写入数据
            connection.setDoOutput(true);
            String auth = userName + ":" + password;
            byte[] encodedAuth = Base64.encodeBase64(auth.getBytes(StandardCharsets.US_ASCII));
            String authHeader = "Basic " + new String(encodedAuth);
            connection.setRequestProperty(HttpHeaders.AUTHORIZATION, authHeader);
            connection.setRequestProperty("X-Found-Cluster", proxyHeader);
            connection.setRequestProperty("accept", "*/*");
            connection.setRequestProperty("connection", "Keep-Alive");
            connection.setRequestProperty("Content-Length", "1000");
            System.setProperty("java.net.preferIPv4Stack", "true");
            connection.setRequestProperty("user-agent", "Mozilla/4.0 (compatible; MSIE 6.0; Windows NT 5.1;SV1)");
            connection.setRequestProperty("content-type", "application/json");
            connection.setConnectTimeout(CONN_TIME_OUT);
            connection.setReadTimeout(READ_TIME_OUT);
            // 得到请求的输出流对象
            out = new OutputStreamWriter(connection.getOutputStream());
            // 把数据写入请求的Body
            connection.connect();
            if (StringUtils.isNotBlank(json)) {
                out.write(json);
                out.flush();
            }
            in = new BufferedReader(new InputStreamReader(connection.getInputStream(), StandardCharsets.UTF_8));
            String line;
            while ((line = in.readLine()) != null) {
                result.append(line);
            }
        } catch (ConnectException e) {
            log.error("调用HttpUtils.sendGet ConnectException, url=" + url, e);
        } catch (SocketTimeoutException e) {
            log.error("调用HttpUtils.sendGet SocketTimeoutException, url=" + url, e);
        } catch (IOException e) {
            log.error("调用HttpUtils.sendGet IOException, url=" + url, e);
        } catch (Exception e) {
            log.error("调用HttpsUtil.sendGet Exception, url=" + url, e);
        } finally {
            IOUtils.closeQuietly(in);
            IOUtils.closeQuietly(out);
            try {
                if (connection != null) {
                    connection.disconnect();
                }
            } catch (Exception e) {

            }
        }
        return result.toString();
    }
}
