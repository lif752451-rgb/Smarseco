package com.crc.es.pool;

import com.crc.common.utils.DataUtils;
import com.crc.es.config.ElasticsearchProperties;
import com.crc.es.utils.SslUtils;
import com.crc.es.vo.EsDataSource;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.io.IOUtils;
import org.apache.commons.lang3.StringUtils;
import org.apache.http.Header;
import org.apache.http.HttpHost;
import org.apache.http.HttpResponse;
import org.apache.http.auth.AuthScope;
import org.apache.http.auth.UsernamePasswordCredentials;
import org.apache.http.client.CredentialsProvider;
import org.apache.http.conn.ConnectionKeepAliveStrategy;
import org.apache.http.impl.client.BasicCredentialsProvider;
import org.apache.http.impl.client.DefaultConnectionKeepAliveStrategy;
import org.apache.http.impl.nio.reactor.IOReactorConfig;
import org.apache.http.message.BasicHeader;
import org.apache.http.protocol.HttpContext;
import org.elasticsearch.client.RequestOptions;
import org.elasticsearch.client.RestClient;
import org.elasticsearch.client.RestClientBuilder;
import org.elasticsearch.client.RestHighLevelClient;

import java.net.InetSocketAddress;
import java.net.Socket;
import java.util.ArrayList;
import java.util.List;

@Slf4j
// Java客户端生成工厂
public class EsSingleFactory {

    private static final int CONNECTION_REQUEST_TIME_OUT = 3000;
    private static final int CONNECT_TIME_OUT = 30000;
    private static final int SOCKET_TIME_OUT = 60000;


    public RestHighLevelClient getHighLevelClient(ElasticsearchProperties esConfig) {
        String hosts = esConfig.getHost();
        List<HttpHost> httpHosts = new ArrayList<>();
        int port = esConfig.getPort();
        if (hosts != null && hosts.contains(",")) {
            String[] eshostArr = hosts.split(",");
            for (String s : eshostArr) {
                if (s.contains(":")) {
                    String host = s.split(":")[0];
                    String portStr = s.split(":")[1];
                    port = DataUtils.toInt(portStr);
                    if (port < 1) {
                        log.error("es配置错误->{}", s);
                        continue;
                    }
                    String mode = "http";
                    if ("https".equalsIgnoreCase(esConfig.getSchema())) {
                        mode = "https";
                    }
                    esConfig.setSchema(mode);
                    HttpHost httpHost = new HttpHost(host, port, mode);
                    httpHosts.add(httpHost);
                }
            }
        } else if (hosts != null) {
            if (port < 1) {
                log.error("es配置错误->{}:{}", hosts, port);
                return null;
            }
            String mode = "http";
            if ("https".equalsIgnoreCase(esConfig.getSchema())) {
                mode = "https";
            }
            esConfig.setSchema(mode);
            HttpHost httpHost = new HttpHost(hosts, port, mode);
            httpHosts.add(httpHost);
        }
        if (httpHosts.size() < 1) {
            log.error("ES配置的主机IP或端口为空,请检查模型的数据源配置！");
            return null;
        }
        //System.out.println("es 服务：" + JSON.toJSONString(httpHosts));
        String username = esConfig.getUserName();
        String password = esConfig.getPassword();
        String schema = esConfig.getSchema();
        String proxyHeader = esConfig.getProxyHeader();
        try {
            RestClientBuilder builder = RestClient.builder(httpHosts.toArray(new HttpHost[0]))
                    .setRequestConfigCallback(
                            config -> config.setConnectTimeout(CONNECT_TIME_OUT)
                                    .setConnectionRequestTimeout(CONNECTION_REQUEST_TIME_OUT)
                                    .setSocketTimeout(SOCKET_TIME_OUT))
                    .setHttpClientConfigCallback(
                            httpClientBuilder -> {
                                if (StringUtils.isNotBlank(username) && StringUtils.isNotBlank(password)) {
                                    final CredentialsProvider credentialsProvider = new BasicCredentialsProvider();
                                    credentialsProvider.setCredentials(AuthScope.ANY,
                                            new UsernamePasswordCredentials(username, password));
                                    httpClientBuilder.setDefaultCredentialsProvider(credentialsProvider);
                                }
                                httpClientBuilder.setMaxConnTotal(100);
                                httpClientBuilder.setMaxConnPerRoute(50);
                                List<Header> headers = new ArrayList<>();
                                headers.add(new BasicHeader("Connection", "keep-alive"));
                                headers.add(new BasicHeader("Keep-Alive", "720"));
                                headers.add(new BasicHeader("X-Found-Cluster", proxyHeader));
                                httpClientBuilder.setDefaultHeaders(headers);
                                ConnectionKeepAliveStrategy keepAliveStrategy = new DefaultConnectionKeepAliveStrategy() {
                                    @Override
                                    public long getKeepAliveDuration(final HttpResponse response, final HttpContext context) {
                                        long keepAlive = super.getKeepAliveDuration(response, context);
                                        if (keepAlive == -1) {
                                            keepAlive = 5000;
                                        }
                                        return keepAlive;
                                    }
                                };
                                httpClientBuilder.setKeepAliveStrategy(keepAliveStrategy);
                                if ("https".equals(schema)) {
                                    try {
                                        httpClientBuilder.setConnectionManager(SslUtils.getConnectionManager());
                                    } catch (Exception e) {
                                        log.error(e.getMessage(), e);
                                    }
                                    System.out.println("启用ES https链接模式");
                                }
                                return httpClientBuilder.setDefaultIOReactorConfig(
                                        IOReactorConfig.custom().setIoThreadCount(10).build());//设置线程数量;
                            }
                    );

            return new RestHighLevelClient(builder);
        } catch (Exception e) {
            log.error("{}-{},{},{}", hosts, port, e.getMessage(), e);
        }
        return null;
    }

    private static class SingletonHolder {
        private static final EsSingleFactory INSTANCE = new EsSingleFactory();
    }

    private EsSingleFactory() {
    }

    public static EsSingleFactory getInstance() {
        return SingletonHolder.INSTANCE;
    }

    public static RequestOptions getRequestOptions() {
        RequestOptions.Builder builder = RequestOptions.DEFAULT.toBuilder();
        return builder.build();
    }

    /**
     * 测试telnet 机器端口的连通性
     * @param hostname
     * @param port
     * @param timeout
     * @return
     */
    public static boolean telnet(String hostname, int port, int timeout){
        Socket socket = new Socket();
        boolean isConnected = false;
        try {
            socket.connect(new InetSocketAddress(hostname, port), timeout); // 建立连接
            isConnected = socket.isConnected(); // 通过现有方法查看连通状态
//            System.out.println(isConnected);    // true为连通
        } catch (Exception e) {
                   // 当连不通时，直接抛异常，异常捕获即可
        }finally{
            try {
                socket.close();   // 关闭连接
            } catch (Exception ignored) {

            }
        }
        return isConnected;
    }



    public RestHighLevelClient getHighLevelClientHigh(EsDataSource esDataSource) {
        if (telnet(esDataSource.getHost(), esDataSource.getPort(), 2000)) {
            ElasticsearchProperties elasticsearchProperties = new ElasticsearchProperties();
            elasticsearchProperties.setHost(esDataSource.getHost());
            elasticsearchProperties.setPassword(esDataSource.getPassword());
            elasticsearchProperties.setUserName(esDataSource.getUserName());
            elasticsearchProperties.setPort(esDataSource.getPort());
            elasticsearchProperties.setSchema(esDataSource.getSchema());
            return getHighLevelClient(elasticsearchProperties);
        }else {
            log.error("端口不同,ip={},port={}",esDataSource.getHost(),esDataSource.getPort());
        }
        return null;
    }

    public void close(RestHighLevelClient client) {
        if (client != null) {
            IOUtils.closeQuietly(client);
        }
    }
}
