package com.crc.es.config;

import com.crc.common.exception.CustomException;
import com.crc.common.utils.DataUtils;
import com.crc.es.utils.SslUtils;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.apache.http.Header;
import org.apache.http.HttpHost;
import org.apache.http.HttpResponse;
import org.apache.http.auth.AuthScope;
import org.apache.http.auth.UsernamePasswordCredentials;
import org.apache.http.client.CredentialsProvider;
import org.apache.http.conn.ConnectionKeepAliveStrategy;
import org.apache.http.impl.client.BasicCredentialsProvider;
import org.apache.http.impl.client.DefaultConnectionKeepAliveStrategy;
import org.apache.http.impl.nio.reactor.IOReactorConfig;
import org.apache.http.message.BasicHeader;
import org.apache.http.protocol.HttpContext;
import org.elasticsearch.client.RestClient;
import org.elasticsearch.client.RestClientBuilder;
import org.elasticsearch.client.RestHighLevelClient;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.autoconfigure.condition.ConditionalOnMissingBean;
import org.springframework.boot.context.properties.EnableConfigurationProperties;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import java.util.ArrayList;
import java.util.List;

/**
 * @author simba@onlying.cn
 * @date 2020/7/21 14:07
 */
@Slf4j
@Configuration
@EnableConfigurationProperties(ElasticsearchProperties.class)
public class ElasticsearchConfig {
    private static final int CONNECTION_REQUEST_TIME_OUT = 3000;
    private static final int CONNECT_TIME_OUT = 30000;
    private static final int SOCKET_TIME_OUT = 60000;
    @Autowired
    private ElasticsearchProperties elasticsearchProperties;


    @Bean
    @ConditionalOnMissingBean
    public RestHighLevelClient restHighLevelClient() {
        List<HttpHost> httpHosts = new ArrayList<>();
        String hosts = elasticsearchProperties.getHost();
        int port = elasticsearchProperties.getPort();
        if (hosts != null && hosts.contains(",")) {
            String[] eshostArr = hosts.split(",");
            for (String s : eshostArr) {
                if (s.contains(":")) {
                    String host = s.split(":")[0];
                    String portStr = s.split(":")[1];
                    port = DataUtils.toInt(portStr);
                    if (port < 1) {
                        log.error("es配置错误->{}", s);
                    }
                    String mode = "http";
                    if ("https".equalsIgnoreCase(elasticsearchProperties.getSchema())) {
                        mode = "https";
                    }
                    elasticsearchProperties.setSchema(mode);
                    HttpHost httpHost = new HttpHost(host, port, mode);
                    httpHosts.add(httpHost);
                }
            }
        } else if (hosts != null) {
            if (port < 1) {
                log.error("es配置错误->{}:{}", hosts, port);
            }
            String mode = "http";
            if ("https".equalsIgnoreCase(elasticsearchProperties.getSchema())) {
                mode = "https";
            }
            elasticsearchProperties.setSchema(mode);
            HttpHost httpHost = new HttpHost(hosts, port, mode);
            httpHosts.add(httpHost);
        }
        if (httpHosts.size() < 1) {
            throw new CustomException("ES配置的主机IP或端口为空,请检查模型的数据源配置！", 601);
        }
        String username = elasticsearchProperties.getUserName();
        String password = elasticsearchProperties.getPassword();
        String schema = elasticsearchProperties.getSchema();
        String proxyHeader = elasticsearchProperties.getProxyHeader();
        try {
            RestClientBuilder builder = RestClient.builder(httpHosts.toArray(new HttpHost[0]))
                    .setRequestConfigCallback(
                            config -> config.setConnectTimeout(CONNECT_TIME_OUT)
                                    .setConnectionRequestTimeout(CONNECTION_REQUEST_TIME_OUT)
                                    .setSocketTimeout(SOCKET_TIME_OUT))
                    .setHttpClientConfigCallback(
                            httpClientBuilder -> {
                                if (StringUtils.isNotBlank(username) && StringUtils.isNotBlank(password)) {
                                    final CredentialsProvider credentialsProvider = new BasicCredentialsProvider();
                                    credentialsProvider.setCredentials(AuthScope.ANY,
                                            new UsernamePasswordCredentials(username, password));
                                    httpClientBuilder.setDefaultCredentialsProvider(credentialsProvider);
                                }
                                httpClientBuilder.setMaxConnTotal(100);
                                httpClientBuilder.setMaxConnPerRoute(50);
                                List<Header> headers = new ArrayList<>();
                                headers.add(new BasicHeader("Connection", "keep-alive"));
                                headers.add(new BasicHeader("Keep-Alive", "720"));
                                headers.add(new BasicHeader("X-Found-Cluster", proxyHeader));
                                httpClientBuilder.setDefaultHeaders(headers);
                                ConnectionKeepAliveStrategy keepAliveStrategy = new DefaultConnectionKeepAliveStrategy() {
                                    @Override
                                    public long getKeepAliveDuration(final HttpResponse response, final HttpContext context) {
                                        long keepAlive = super.getKeepAliveDuration(response, context);
                                        if (keepAlive == -1) {
                                            keepAlive = 5000;
                                        }
                                        return keepAlive;
                                    }
                                };
                                httpClientBuilder.setKeepAliveStrategy(keepAliveStrategy);
                                if ("https".equals(schema)) {
                                    try {
                                        httpClientBuilder.setConnectionManager(SslUtils.getConnectionManager());
                                    } catch (Exception e) {
                                        log.error(e.getMessage(), e);
                                    }
                                    System.out.println("启用ES https链接模式");
                                }
                                return httpClientBuilder.setDefaultIOReactorConfig(
                                        IOReactorConfig.custom().setIoThreadCount(10).build());//设置线程数量;
                            }
                    );

            return new RestHighLevelClient(builder);
        } catch (Exception e) {
            log.error("{}-{},{},{}", hosts, port, e.getMessage(), e);
        }
        return null;
    }
}
