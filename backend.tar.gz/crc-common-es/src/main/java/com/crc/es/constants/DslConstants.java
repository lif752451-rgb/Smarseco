package com.crc.es.constants;

/**
 * @author simba@onlying.cn
 * @date 2020/9/3 18:07
 */
public class DslConstants {

    public static final String ES_STATIC_TYPE ="es";

    public static final String DB_STATIC_TYPE ="db";

    public static final String MID_STATIC_TYPE ="mid";

    public static final String DSL_RANGE_TYPE ="range";

    public static final String DSL_MATCH_TYPE ="match_parchas";

    public static final String SHOULD_LIST_TYPE ="shoulds";

    public static final String FIELD_TAG ="field";

    public static final String TERM_QUERY_TYPE ="term";

    public static final String MULTI_MATCH_TYPE ="multi_match";

    public static final String VALUE_TAG="value";

    public static String SPARK_TIME_TAG ="SparkTime";

    public static String FLOW_TIME ="flow_time";

    public static String REPORT_TIME ="report_time";

    public static String EVENT_SEVERITY ="event_severity";

    public static String EVENT_RESULT ="event_result";

    public static String EVENT_TYPEA ="event_typeA";

    public static String EVENT_PHASE ="event_phase";

    public static String VENDOR_NAME ="vendor_name";


}
