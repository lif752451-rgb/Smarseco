package com.crc.es.constants;

import java.util.Arrays;
import java.util.List;

/**
 * @author simba@onlying.cn
 * @date 2020/9/29 15:29
 */
public class AttackStatConstants {

    public static final List<String> K01_ATTACK_STATS = Arrays.asList(new String[]{"外网攻击数","拦截数","拦截率"});

    public static final List<String> ATTACK_DEFENDS = Arrays.asList(new String[]{"绿盟IPS","长亭Waf","Imperva WAF","K01"});

    public static final List<String> ATTACK_MONITOR = Arrays.asList(new String[]{"奇安信天眼","青藤","深信服SIP","长亭蜜罐"});

    public static final String SUMMARY_TAG="全部";

    public static final String STAT_ORDER_FIELD="attack_ip";

    public static final String SELECT_FROM_PATTERN="(?<=select).*?(?=from)";

    public static final String AS ="as";

    public static final String GROUP_BY ="group by";

    public static final String COUNT ="count";

    public static final String TYPE_TAG ="type";

    public static final String BETWEEN_TAG ="between";

    public static final String AND_TAG ="and";

    public static final String ES_STATIC_TYPE ="es";

    public static final String DB_STATIC_TYPE ="db";

    public static final String MID_STATIC_TYPE ="mid";

    public static final String ES_BUCKET_TAG="buckets";






}
