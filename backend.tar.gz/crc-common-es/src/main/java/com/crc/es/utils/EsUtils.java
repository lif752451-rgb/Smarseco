package com.crc.es.utils;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;
import com.crc.common.utils.*;
import com.crc.core.utils.SimpleCodeTool;
import com.crc.es.config.ElasticsearchProperties;
import com.crc.es.constants.LogConstants;
import com.crc.es.pool.EsSingleFactory;
import com.crc.es.vo.EsDataSource;
import lombok.extern.slf4j.Slf4j;
import org.elasticsearch.action.search.ClearScrollRequest;
import org.elasticsearch.action.search.ClearScrollResponse;
import org.elasticsearch.action.search.SearchRequest;
import org.elasticsearch.action.search.SearchResponse;
import org.elasticsearch.client.RequestOptions;
import org.elasticsearch.client.RestHighLevelClient;
import org.elasticsearch.client.core.CountRequest;
import org.elasticsearch.client.core.CountResponse;
import org.elasticsearch.common.settings.Settings;
import org.elasticsearch.common.xcontent.LoggingDeprecationHandler;
import org.elasticsearch.common.xcontent.NamedXContentRegistry;
import org.elasticsearch.common.xcontent.XContentParser;
import org.elasticsearch.common.xcontent.XContentType;
import org.elasticsearch.index.query.BoolQueryBuilder;
import org.elasticsearch.index.query.QueryBuilders;
import org.elasticsearch.index.query.RangeQueryBuilder;
import org.elasticsearch.search.SearchModule;
import org.elasticsearch.search.builder.SearchSourceBuilder;

import java.util.*;

@Slf4j
public class EsUtils {
    private static final NamedXContentRegistry xContentRegistry;

    static {
        SearchModule searchModule =
                new SearchModule(Settings.EMPTY, false, Collections.emptyList());

        xContentRegistry =
                new NamedXContentRegistry(searchModule.getNamedXContents());
    }

    public static SearchSourceBuilder strToDsl(String str) {
        if (StringUtils.isBlank(str)) {
            return null;
        }
        try (XContentParser parser = XContentType.JSON.xContent().createParser(xContentRegistry,
                LoggingDeprecationHandler.INSTANCE,
                str)) {
            return SearchSourceBuilder.fromXContent(parser);
        } catch (Exception e) {
            log.error(e.getMessage(), e);
        }
        return null;
    }

    public static EsDataSource logSourceCheck(Map<String, String> indexAndSource) {
        if (indexAndSource == null) {
            log.error("数据库来源出错=NULL");
            return null;
        }
        try {
            String password = EncryptUtil.aesDecrypt(indexAndSource.get("password"));
            EsDataSource esConfig = new EsDataSource();
            esConfig.setMode(DataUtils.getString(indexAndSource, "proto"));
            esConfig.setTimeField(DataUtils.getString(indexAndSource, "timeField"));
            esConfig.setIndexRule(DataUtils.getString(indexAndSource, "indexRule"));
            esConfig.setDataIndexName(DataUtils.getString(indexAndSource, "dataIndexName"));
            esConfig.setGroupName(DataUtils.getString(indexAndSource, "groupName"));
            esConfig.setUserName(DataUtils.getString(indexAndSource, "userName"));
            esConfig.setPassword(password);
            String host = DataUtils.getString(indexAndSource, "host");
            if (StringUtils.isBlank(host)) {
                host = DataUtils.getString(indexAndSource, "ip");
            }
            esConfig.setHost(host);
            esConfig.setPort(DataUtils.toInt(DataUtils.getString(indexAndSource, "port")));
            String ip = DataUtils.getString(indexAndSource, "ip");
            //esConfig.setProxyHeader("8994b14fd0ba4c5fabef5e6851a38c56");
            EsUtils.esHostAndIp(ip, host, esConfig);
            if (indexAndSource.containsKey("remark")) {
                String remark = indexAndSource.get("remark");
                JSONObject parse = JsonUtils.parse(remark);
                if (parse.containsKey("X-Found-Cluster")) {
                    esConfig.setProxyHeader(JsonUtils.getStr(parse, "X-Found-Cluster"));
                }
            }
            return esConfig;
        } catch (Exception e) {
            log.error("数据库来源出错：{}", e.getMessage(), e);
            return null;
        }
    }

    public static boolean isBlankQuery(BoolQueryBuilder queryBuilder) {
        if (queryBuilder == null) {
            return true;
        }
        return queryBuilder.should().size() < 1 && queryBuilder.filter().size() < 1 && queryBuilder.mustNot().size() < 1 && queryBuilder.must().size() < 1;
    }


    public static void esHostAndIp(String ip, String host, EsDataSource esConfig) {
        if (StringUtils.isNotBlank(host)) {
            esConfig.setHost(host);
        } else {
            esConfig.setHost(ip);
        }
    }

    private static void extracted(String host, EsDataSource esConfig) {
        String hostPort;
        String newHost;
        if (host.contains(":")) {
            newHost = host.split(":")[0];
            hostPort = host.split(":")[1];
        } else {
            return;
        }
        esConfig.setHost(newHost);
        if (esConfig.getMode().toLowerCase().startsWith("https")) {
            int port = DataUtils.toInt(hostPort);
            if (port < 0) {
                esConfig.setPort(443);
            } else {
                esConfig.setPort(port);
            }
        } else {
            int port = DataUtils.toInt(hostPort);
            if (port < 0) {
                esConfig.setPort(80);
            } else {
                esConfig.setPort(port);
            }
        }
    }

    public static RangeQueryBuilder getSparkTimeHourByDay(Integer day) {
        Calendar ca = Calendar.getInstance();
        ca.set(Calendar.MINUTE, 0);
        ca.set(Calendar.SECOND, 0);
        ca.set(Calendar.MILLISECOND, 0);
        RangeQueryBuilder rangeQueryBuilder = QueryBuilders.rangeQuery(LogConstants.SPARK_TIME_TAG);
        String[] timeValues = DateUtils.resolveTimeByMinusDays(ca.getTime(), day);
        rangeQueryBuilder.gt(timeValues[1]);
        rangeQueryBuilder.lte(timeValues[0]);
        return rangeQueryBuilder;
    }

    public static RangeQueryBuilder getSparkTimeDay(Integer day) {
        RangeQueryBuilder rangeQueryBuilder = QueryBuilders.rangeQuery(LogConstants.SPARK_TIME_TAG);
        String[] timeValues = DateUtils.resolveTimeRangeByType("3", day, new Date());
        if (Objects.nonNull(timeValues)) {
            rangeQueryBuilder.gt(timeValues[1]);
            rangeQueryBuilder.lte(timeValues[0]);
        }
        return rangeQueryBuilder;
    }

    public static void cleanScrollId(RestHighLevelClient client, String scrollId) {
        try {
            //清除滚动，否则影响下次查询
            ClearScrollRequest clearScrollRequest = new ClearScrollRequest();
            clearScrollRequest.addScrollId(scrollId);
            ClearScrollResponse clearScrollResponse = null;
            clearScrollResponse = client.clearScroll(clearScrollRequest, RequestOptions.DEFAULT);
            System.out.println("滚动查询删除=" + clearScrollResponse.isSucceeded());
        } catch (Exception e) {
            System.out.println("滚动查询删除失败");
        }
    }

    public static Object[] getSearchAfter(String scrollId) {
        if (StringUtils.isBlank(scrollId)) {
            return null;
        }
        try {
            List<Object> list = JSON.parseArray(SimpleCodeTool.decryptBase64(scrollId), Object.class);
            return list.toArray();
        } catch (Exception e) {
            log.error(e.getMessage(), e);
        }
        return null;
    }

    public static String getSearchAfter(Object[] sortValues) {
        if (sortValues == null) {
            return "";
        }
        return SimpleCodeTool.encryptBase64(JSON.toJSONString(sortValues));
    }


    /**
     * 根据DSL查询ES
     *
     * @param elasticsearchProperties 配置
     * @param dsl                     DSL
     * @return 数据String
     */
    public static JSONObject getQueryJson(ElasticsearchProperties elasticsearchProperties, String indexName, String dsl) {
        String str = getQueryStr(elasticsearchProperties, indexName, dsl);
        if (StringUtils.isNotBlank(str)) {
            return JsonUtils.parse(str);
        }
        return null;
    }

    /**
     * 根据DSL查询ES
     *
     * @param elasticsearchProperties 配置
     * @param dsl                     DSL
     * @return 数据String
     */
    public static String getQueryStr(ElasticsearchProperties elasticsearchProperties, String indexName, String dsl) {
        EsSingleFactory factory = EsSingleFactory.getInstance();
        RestHighLevelClient restHighLevelClient = factory.getHighLevelClient(elasticsearchProperties);
        try {
            JSONObject jsonObject = JsonUtils.parse(dsl);
            jsonObject.remove("fields");
            jsonObject.remove("script_fields");
            jsonObject.remove("stored_fields");
            jsonObject.remove("runtime_mappings");
            jsonObject.remove("docvalue_fields");
            XContentParser parser =
                    XContentType.JSON.xContent().createParser(xContentRegistry,
                            LoggingDeprecationHandler.INSTANCE,
                            jsonObject.toJSONString());

            SearchSourceBuilder sourceBuilder = SearchSourceBuilder.fromXContent(parser);
            System.out.println(sourceBuilder);
            SearchRequest searchRequest = new SearchRequest(indexName);
            searchRequest.source(sourceBuilder);
            SearchResponse response = restHighLevelClient.search(searchRequest, RequestOptions.DEFAULT);
            return response.toString();
        } catch (Exception e) {
            log.error(e.getMessage(), e);
        } finally {
            factory.close(restHighLevelClient);
        }
        return "";
    }

    /**
     * 根据DSL查询ES
     *
     * @param elasticsearchProperties 配置
     * @param dsl                     DSL
     * @return 数据String
     */
    public static String getQueryCountStr(ElasticsearchProperties elasticsearchProperties, String indexName, String dsl) {
        EsSingleFactory factory = EsSingleFactory.getInstance();
        RestHighLevelClient restHighLevelClient = factory.getHighLevelClient(elasticsearchProperties);
        try {
            JSONObject jsonObject = JsonUtils.parse(dsl);
            jsonObject.remove("fields");
            jsonObject.remove("script_fields");
            jsonObject.remove("stored_fields");
            jsonObject.remove("runtime_mappings");
            jsonObject.remove("docvalue_fields");
            XContentParser parser =
                    XContentType.JSON.xContent().createParser(xContentRegistry,
                            LoggingDeprecationHandler.INSTANCE,
                            jsonObject.toJSONString());

            SearchSourceBuilder sourceBuilder = SearchSourceBuilder.fromXContent(parser);
            System.out.println(sourceBuilder);
            CountRequest searchRequest = new CountRequest(indexName);
            searchRequest.query(sourceBuilder.query());
            CountResponse response = restHighLevelClient.count(searchRequest, RequestOptions.DEFAULT);
            long count = response.getCount();
            JSONObject retJson =  new JSONObject();
            retJson.put("count", count);
            return retJson.toJSONString();
        } catch (Exception e) {
            log.error(e.getMessage(), e);
        } finally {
            factory.close(restHighLevelClient);
        }
        return "";
    }
}
