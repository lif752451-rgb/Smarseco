package com.crc.es.pool;

import com.crc.es.constants.LogConstants;
import org.apache.commons.lang3.StringUtils;
import org.elasticsearch.action.admin.indices.alias.get.GetAliasesRequest;
import org.elasticsearch.action.search.SearchRequest;
import org.elasticsearch.action.search.SearchResponse;
import org.elasticsearch.client.GetAliasesResponse;
import org.elasticsearch.client.HttpAsyncResponseConsumerFactory;
import org.elasticsearch.client.RequestOptions;
import org.elasticsearch.client.RestHighLevelClient;
import org.elasticsearch.client.core.CountRequest;
import org.elasticsearch.client.core.CountResponse;
import org.elasticsearch.index.query.BoolQueryBuilder;
import org.elasticsearch.search.SearchHit;
import org.elasticsearch.search.builder.SearchSourceBuilder;
import org.elasticsearch.search.sort.FieldSortBuilder;
import org.elasticsearch.search.sort.SortOrder;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Service;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Map;

@Service
public class EsPoolFactory {
    private static final Logger logger = LoggerFactory.getLogger(EsPoolFactory.class);
    protected static final RequestOptions COMMON_OPTIONS;
    @Qualifier("restHighLevelClient")
    @Autowired
    public RestHighLevelClient client;

    static {

        RequestOptions.Builder builder = RequestOptions.DEFAULT.toBuilder();
        // 默认缓冲限制为100MB，此处修改为30MB。
        builder.setHttpAsyncResponseConsumerFactory(new HttpAsyncResponseConsumerFactory.HeapBufferedResponseConsumerFactory(30 * 1024 * 1024));
        COMMON_OPTIONS = builder.build();
    }

    public List<Map<String, Object>> searchList(String index, SearchSourceBuilder searchSourceBuilder) {
        SearchRequest searchRequest = new SearchRequest(index);
        searchRequest.source(searchSourceBuilder);
        List<Map<String, Object>> lolList = new ArrayList<>();
        try {
            SearchResponse searchResponse = client.search(searchRequest, COMMON_OPTIONS);
            SearchHit[] hits = searchResponse.getHits().getHits();
            Arrays.stream(hits).forEach(hit -> {
                Map<String, Object> sourceAsMap = hit.getSourceAsMap();
                lolList.add(sourceAsMap);
            });
        } catch (Exception e) {
            logger.error(e.getMessage(),e);
        }
        return lolList;
    }

    public SearchResponse search(String index, SearchSourceBuilder searchSourceBuilder) {
        SearchRequest searchRequest = new SearchRequest(index);
        searchRequest.source(searchSourceBuilder);
        try {
            return client.search(searchRequest, COMMON_OPTIONS);
        } catch (Exception e) {
            logger.error(e.getMessage(),e);
        }
        return null;
    }

    /**
     * 将异常向上抛出，以便捕获输出到前台
     * @param index
     * @param searchSourceBuilder
     * @return
     * @throws IOException
     */
    public SearchResponse searchEs(String index, SearchSourceBuilder searchSourceBuilder) throws IOException {
        SearchRequest searchRequest = new SearchRequest(index);
        searchRequest.source(searchSourceBuilder);
        return client.search(searchRequest, COMMON_OPTIONS);
    }


    public SearchResponse doEsSearchAfterPage(SearchSourceBuilder sourceBuilder, BoolQueryBuilder boolQueryBuilder, String esIndex, String lastId) {
        SearchResponse response = null;
        try {
            //sourceBuilder;

            sourceBuilder.sort(new FieldSortBuilder(LogConstants.SPARK_TIME_TAG).order(SortOrder.DESC));
                    /*.sort(new FieldSortBuilder(LogConstants.LOG_START_TIME).order(SortOrder.DESC))
                    .sort(new FieldSortBuilder(LogConstants.LOG_REV_TIME).order(SortOrder.DESC));*/
            sourceBuilder.query(boolQueryBuilder);
            if (!StringUtils.isEmpty(lastId)) {
                Object[] skip = lastId.split("@");
                sourceBuilder.searchAfter(skip);
            }

            SearchRequest searchRequest = new SearchRequest(esIndex);
            searchRequest.source(sourceBuilder);

            response = client.search(searchRequest, COMMON_OPTIONS);
        } catch (Exception e) {
            logger.error(e.getMessage(),e);
        }
        return response;
    }

    public SearchResponse doEsSearchAfterPage(SearchSourceBuilder sourceBuilder, BoolQueryBuilder boolQueryBuilder, String esIndex) {
        SearchResponse response = null;
        try {
            //sourceBuilder;

            sourceBuilder.sort(new FieldSortBuilder(LogConstants.SPARK_TIME_TAG).order(SortOrder.DESC));
                    /*.sort(new FieldSortBuilder(LogConstants.LOG_START_TIME).order(SortOrder.DESC))
                    .sort(new FieldSortBuilder(LogConstants.LOG_REV_TIME).order(SortOrder.DESC));*/
            sourceBuilder.query(boolQueryBuilder);
            SearchRequest searchRequest = new SearchRequest(esIndex);
            searchRequest.source(sourceBuilder);

            response = client.search(searchRequest, COMMON_OPTIONS);
        } catch (Exception e) {
            logger.error(e.getMessage(),e);
        }
        return response;
    }

    public GetAliasesResponse indices() {
        try {
            GetAliasesRequest request = new GetAliasesRequest();
            return client.indices().getAlias(request, COMMON_OPTIONS);
        } catch (Exception e) {
            logger.error(e.getMessage(),e);
        }
        return null;
    }

    public long count(CountRequest request) {
        CountResponse response = null;
        try {
            response = client.count(request, COMMON_OPTIONS);
            return response.getCount();
        } catch (Exception e) {
            logger.error(e.getMessage(),e);
        }
        return 0L;
    }
}
