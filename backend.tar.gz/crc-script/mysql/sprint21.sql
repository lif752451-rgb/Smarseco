CREATE TABLE tb_patrol_inspection_task (
  id bigint(20) NOT NULL AUTO_INCREMENT COMMENT '主键id',
  task_id varchar(64) DEFAULT NULL COMMENT '任务id',
  name varchar(128) DEFAULT NULL COMMENT '名称',
  start_time datetime DEFAULT NULL COMMENT '巡检日期开始时间',
  end_time datetime DEFAULT NULL COMMENT '巡检日期结束时间',
  frequency varchar(32) DEFAULT NULL COMMENT '巡检频率',
  frequency_concrete varchar(128) DEFAULT NULL COMMENT '巡检频率具体是哪一天或者周几',
  status tinyint(1) DEFAULT NULL COMMENT '任务状态(0启用，1停用)',
  scope_type tinyint(1) DEFAULT NULL COMMENT '范围类型(0ip资产，1应用系统)',
  create_by varchar(64) DEFAULT '' COMMENT '创建者',
  create_by_label varchar(64) DEFAULT '' COMMENT '创建者昵称',
  create_time datetime DEFAULT NULL COMMENT '创建时间',
  update_by varchar(64) DEFAULT '' COMMENT '更新者',
  update_by_label varchar(64) DEFAULT '' COMMENT '更新者昵称',
  update_time datetime DEFAULT NULL COMMENT '更新时间',
  remark varchar(2048) DEFAULT NULL COMMENT '备注',
  del_flag tinyint(1) DEFAULT '0' COMMENT '删除标记(0正常 1删除)',
  PRIMARY KEY (id),
  UNIQUE KEY un_task_id (task_id) USING BTREE,
  KEY idx_id_name_create_update (task_id,name,create_by,create_time,update_time) USING BTREE,
  KEY idx_status_time (status,start_time,end_time)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='巡检任务表';

create table tb_patrol_inspection_task_asset_rel(
	 id bigint(20) not null auto_increment comment '主键id',
	 task_id bigint(20) comment '巡检任务主键id',
	 asset_id bigint(20) comment '资产主键id',
	 primary key (id),
	 unique key un_task_item (task_id, asset_id) using btree
) engine=innodb default charset=utf8 comment='巡检任务和资产关联表';

CREATE TABLE tb_patrol_inspection_task_app_system_rel (
  id bigint(20) NOT NULL AUTO_INCREMENT COMMENT '主键ID',
  task_id bigint(20) DEFAULT NULL COMMENT '巡检任务主键ID',
  app_system_id varchar(64) DEFAULT NULL COMMENT '应用系统主键ID',
  PRIMARY KEY (id),
  UNIQUE KEY un_task_item (task_id,app_system_id) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='巡检任务和应用系统关联表';

CREATE TABLE tb_patrol_inspection_item (
  id bigint(20) NOT NULL AUTO_INCREMENT COMMENT '主键id',
  patrol_item varchar(64) DEFAULT NULL COMMENT '巡检项',
  patrol_type varchar(64) DEFAULT NULL COMMENT '巡检类型',
  description varchar(1000) DEFAULT NULL COMMENT '巡检描述',
  feedback_field varchar(1000) DEFAULT NULL COMMENT '反馈字段,多个的按照,分割',
  create_by varchar(64) DEFAULT '' COMMENT '创建者',
  create_by_label varchar(64) DEFAULT '' COMMENT '创建者昵称',
  create_time datetime DEFAULT NULL COMMENT '创建时间',
  update_by varchar(64) DEFAULT '' COMMENT '更新者',
  update_by_label varchar(64) DEFAULT '' COMMENT '更新者昵称',
  update_time datetime DEFAULT NULL COMMENT '更新时间',
  del_flag tinyint(1) DEFAULT '0' COMMENT '删除标记(0正常 1删除)',
  PRIMARY KEY (id),
  KEY idx_item_type_desc (patrol_item) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='巡检项表';

CREATE TABLE tb_patrol_inspection_push_record (
  id bigint(20) NOT NULL AUTO_INCREMENT COMMENT '主键id',
  task_id bigint(20) NOT NULL COMMENT '关联巡检任务主键',
  recipient varchar(1024) DEFAULT NULL COMMENT '推送接收人',
  push_time datetime DEFAULT NULL COMMENT '推送时间',
  PRIMARY KEY (id),
  KEY idx_task_rel (task_id) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='巡检任务-推送记录表';

CREATE TABLE tb_patrol_inspection_feedback_result (
  id bigint(20) NOT NULL AUTO_INCREMENT COMMENT '主键id',
  task_id bigint(20) NOT NULL COMMENT '巡检任务主键',
  scope_type tinyint(1) DEFAULT NULL COMMENT '范围类型(0ip资产，1应用系统)',
  rel_id varchar(64) DEFAULT NULL COMMENT '根据巡检任务中范围类型关联对应id(如果范围类型为0 则关联资产表id,1关联应用系统id)',
  internal_ip varchar(128) DEFAULT NULL COMMENT '内网ip',
  affiliation_dept_name varchar(1024) DEFAULT NULL COMMENT '所属组织名称',
  instance varchar(128) DEFAULT NULL COMMENT '实例名称',
  sys_zh_name varchar(200) DEFAULT NULL COMMENT '系统中文名称',
  domain text COMMENT '域名',
  sys_type_label varchar(255) DEFAULT NULL COMMENT '系统类型-中文名',
  is_feedback tinyint(1) DEFAULT '0' COMMENT '是否反馈(0未反馈，1反馈中，2已反馈)',
  result tinyint(1) DEFAULT NULL COMMENT '反馈结果(0为正常，1异常)',
  batch int(11) DEFAULT NULL COMMENT '批次',
  operating_user_label varchar(1024) DEFAULT NULL COMMENT '运维人(显示用)',
  operating_user varchar(1024) DEFAULT NULL COMMENT '运维人',
  push_time datetime DEFAULT NULL COMMENT '推送时间',
  feedback_user varchar(128) DEFAULT '' COMMENT '反馈人',
  feedback_time datetime DEFAULT NULL COMMENT '反馈时间',
  feedback_end_time datetime DEFAULT NULL COMMENT '反馈截至时间',
  del_flag varchar(2) DEFAULT '0' COMMENT '删除标记(0正常 1删除)',
  work_points varchar(100) DEFAULT NULL COMMENT '工点',
  line varchar(255) DEFAULT NULL COMMENT '线路',
  PRIMARY KEY (id),
  KEY idx_task (task_id) USING BTREE,
  KEY idx_task_scope_rel (task_id,scope_type,rel_id),
  KEY idx_pis (task_id,operating_user,work_points),
  KEY idx_pis_batch (task_id,batch,push_time),
  KEY idx_del_flag (del_flag)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='巡检任务-反馈结果表';

CREATE TABLE tb_patrol_inspection_push_item (
  id bigint(20) NOT NULL AUTO_INCREMENT COMMENT '主键id',
  task_id bigint(20) NOT NULL COMMENT '巡检任务主键',
  batch int(11) DEFAULT NULL COMMENT '批次',
  patrol_item varchar(64) DEFAULT NULL COMMENT '巡检项',
  patrol_type varchar(64) DEFAULT NULL COMMENT '巡检类型',
  description varchar(1000) DEFAULT NULL COMMENT '巡检描述',
  feedback_field json DEFAULT NULL COMMENT '反馈字段',
  push_time datetime DEFAULT NULL COMMENT '推送时间',
  feedback_result_id bigint(20) DEFAULT NULL COMMENT '巡检任务-反馈结果主键id',
  PRIMARY KEY (id),
  KEY idx_task_batch (task_id,batch) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='巡检任务-推送-巡检项表';


CREATE TABLE tb_patrol_inspection_task_item_rel (
  id bigint(20) NOT NULL AUTO_INCREMENT COMMENT '主键ID',
  task_id bigint(20) DEFAULT NULL COMMENT '巡检任务主键ID',
  item_id bigint(20) DEFAULT NULL COMMENT '巡检项主键ID',
  PRIMARY KEY (id),
  UNIQUE KEY un_task_item (task_id,item_id) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='巡检任务和巡检项关联表';


