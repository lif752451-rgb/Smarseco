
alter table tb_asset_software add soft_version_num bigint(15) DEFAULT NULL COMMENT '组件版本转换后数据';

INSERT INTO sys_dict_type(dict_name, dict_type, status, create_by, create_time, update_by, update_time, remark) VALUES ('比较类型', 'compare', '0', 'super', '2022-03-16 15:53:20', '', NULL, '比较类型，包含精准匹配，模糊匹配，大于，大于等于，小于，小于等于');

INSERT INTO sys_dict_data(dict_sort, dict_label, dict_value, dict_type, css_class, list_class, is_default, status, create_by, create_time, update_by, update_time, remark) VALUES (1, '模糊匹配', 'LIKE', 'compare', NULL, NULL, 'N', '0', 'super', '2022-03-16 15:54:10', '', NULL, '模糊匹配');
INSERT INTO sys_dict_data(dict_sort, dict_label, dict_value, dict_type, css_class, list_class, is_default, status, create_by, create_time, update_by, update_time, remark) VALUES (2, '精准匹配', 'EQUAL', 'compare', NULL, NULL, 'N', '0', 'super', '2022-03-16 15:53:59', '', NULL, '精准匹配');
INSERT INTO sys_dict_data(dict_sort, dict_label, dict_value, dict_type, css_class, list_class, is_default, status, create_by, create_time, update_by, update_time, remark) VALUES (3, '大于', 'GREATER', 'compare', NULL, NULL, 'N', '0', 'super', '2022-03-16 15:54:22', '', NULL, '大于');
INSERT INTO sys_dict_data(dict_sort, dict_label, dict_value, dict_type, css_class, list_class, is_default, status, create_by, create_time, update_by, update_time, remark) VALUES (4, '大于等于', 'GREATER_OR_EQUAL', 'compare', NULL, NULL, 'N', '0', 'super', '2022-03-16 15:54:33', '', NULL, '大于等于');
INSERT INTO sys_dict_data(dict_sort, dict_label, dict_value, dict_type, css_class, list_class, is_default, status, create_by, create_time, update_by, update_time, remark) VALUES (5, '小于', 'LESS', 'compare', NULL, NULL, 'N', '0', 'super', '2022-03-16 15:54:42', '', NULL, '小于');
INSERT INTO sys_dict_data(dict_sort, dict_label, dict_value, dict_type, css_class, list_class, is_default, status, create_by, create_time, update_by, update_time, remark) VALUES (6, '小于等于', 'LESS_OR_EQUAL', 'compare', NULL, NULL, 'N', '0', 'super', '2022-03-16 15:54:52', '', NULL, '小于等于');
