ALTER TABLE tb_risk_auto_original ADD affiliation_dept_name varchar(200) NULL COMMENT '附属部门名称';
ALTER TABLE tb_risk_auto_original ADD affiliation_dept_node_id BIGINT(20) NULL COMMENT '附属部门叶子节点';

-- 资产表 缺省值0置为NULL
ALTER TABLE tb_asset MODIFY COLUMN internet_public int(11) NULL COMMENT '是否发布互联网';
ALTER TABLE tb_asset MODIFY COLUMN transformation_completed int(11) NULL COMMENT '是否完成国密改造0否1是';
ALTER TABLE tb_asset MODIFY COLUMN asset_power int(11) NULL COMMENT '是否为关键基础设施 0否1是';