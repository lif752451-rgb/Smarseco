-- 更新表 tb_high_export_record;
alter table tb_high_export_record add column filename varchar(255);
-- 更新表 tb_high_query_header;
CREATE INDEX data_index_id ON tb_high_query_header (data_index_id);
-- 更新表 tb_high_query_history;
CREATE INDEX type ON tb_high_query_history (type);

alter table tb_database_index modify column group_name varchar(255);
CREATE INDEX del_flag ON tb_database_index (data_source_id);
alter table tb_event_calculation modify column company varchar(255);

alter table tb_vuln_data add column white_list_id bigint(20) COMMENT '白名单ID';
CREATE INDEX idx_vuln_white_list_id ON tb_vuln_data (white_list_id);

drop index tb_process_vuln_handle_business_create_time_IDX on tb_process_vuln_handle_business;
create index form_type_index on tb_process_vuln_handle_business (form_type);