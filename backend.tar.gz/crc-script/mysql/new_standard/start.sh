#!/bin/bash

cd /app/smartseco/back/all
nohup java  -XX:+UseG1GC -Xms8192m -Xmx8192m -Dloader.path=/app/smartseco/back/all/lib -jar /app/smartseco/back/all/out-smartseco-1.0.0.jar --spring.config.location=/app/smartseco/back/all/config/ --logging.config=/app/smartseco/back/all/config/log4j2.xml &