--1.数据同步引擎存在新增钓鱼系统数据逻辑，判断是否需求启用：状态 status 0：启用；1：禁用：
UPDATE sys_dict_data SET status = '1' WHERE dict_type = 'sync_sec_config' and dict_value = 'qt_standard_sync_enable';
UPDATE sys_dict_data SET status = '1' WHERE dict_type = 'sync_sec_config' and dict_value = 'fish_db_config';
UPDATE sys_dict_data SET status = '1' WHERE dict_type = 'sync_sec_config' and dict_value = 'fish_sync_enable';

--查询语句（钓鱼字典、钓鱼分析）：
SELECT dict_label,`status` FROM sys_dict_data WHERE dict_type = 'sync_sec_config' and dict_value = 'fish_db_config';
SELECT dict_label,`status` FROM sys_dict_data WHERE dict_type = 'sync_sec_config' and dict_value = 'fish_sync_enable';

--2.stp新增调用接口：/vuln/process/loop/callback

--3.判断引擎是否存在青藤 表名：tb_engine_equipment_management
SELECT * FROM  tb_engine_equipment_management where equipment_manufacture = '1';
--控制返回和有效数据sql:
SELECT equipment_address,equipment_name,equipment_version FROM  tb_engine_equipment_management where equipment_manufacture = '1' and del_flag = '0';

--4.查询漏洞表中，无对应青藤agent的数据和青藤Agent根据ip分组重复的数据
SELECT count(1) FROM tb_vuln_process_form tvpfc left join tb_qingteng_agent tg ON tvpfc.ip = tg.ip WHERE tvpfc.del_flag='0' and tvpfc.`status`='0' and tvpfc.source = '1' and tg.ip is null;
SELECT ip,COUNT(1) AS num FROM tb_qingteng_agent GROUP BY ip HAVING  num > 1;

--手动数据处理，分析漏洞无青藤数据的原因，删除重复的青藤Agent数据(需要结合生产数据分析);
DELETE FROM tb_qingteng_agent where agent_status = '1' and online_status = '0';
DELETE FROM tb_qingteng_agent where agent_status = '1';

--5.新增字段
ALTER TABLE tb_vuln_scan_task ADD reviews text COMMENT '实际复查下发漏洞code';
ALTER TABLE tb_vuln_scan_task_record ADD reviews text COMMENT '实际复查下发漏洞code';
ALTER TABLE tb_vuln_scan_task_record_log ADD reviews text COMMENT '实际复查下发漏洞code';
ALTER TABLE tb_vuln_process_form ADD agent_id varchar(64) DEFAULT NULL COMMENT 'AgentID';
ALTER TABLE tb_qingteng_agent ADD local_ip varchar(32) DEFAULT NULL COMMENT '私网ip';
ALTER TABLE tb_vuln_scan_task_record_log ADD index idx_agent_id (uuid(32));
ALTER TABLE tb_vuln_process_form ADD index idx_agent_id(agent_id);

--6.漏洞主表关联tb_qingteng_agent表增加AgentID数据
UPDATE tb_vuln_process_form tvpf
JOIN (
    SELECT tg.ip, tg.id
    FROM tb_qingteng_agent tg
                where agent_status = '0'
    GROUP BY tg.ip, tg.id
) tg_unique_ip ON tvpf.ip = tg_unique_ip.ip
SET tvpf.agent_id = tg_unique_ip.id;


--普通更新，无青藤引擎，执行新增字段即可
ALTER TABLE tb_vuln_scan_task ADD reviews text COMMENT '实际复查下发漏洞code';
ALTER TABLE tb_vuln_scan_task_record ADD reviews text COMMENT '实际复查下发漏洞code';
ALTER TABLE tb_vuln_scan_task_record_log ADD reviews text COMMENT '实际复查下发漏洞code';
ALTER TABLE tb_vuln_process_form ADD agent_id varchar(64) DEFAULT NULL COMMENT 'AgentID';
ALTER TABLE tb_qingteng_agent ADD local_ip varchar(32) DEFAULT NULL COMMENT '私网ip';
ALTER TABLE tb_vuln_scan_task_record_log ADD index idx_agent_id (uuid(32));
ALTER TABLE tb_vuln_process_form ADD index idx_agent_id(agent_id);