--Sprint 8版本sql

-- 终端软件详情设备详情导出字典
DELETE FROM sys_dict_data WHERE dict_value IN (
                                               'reportIp',
                                               'computerName',
                                               'osAccount',
                                               'organization',
                                               'macAddress',
                                               'dutyBod',
                                               'useBod',
                                               'groupName',
                                               'onlineStatus',
                                               'ip',
                                               'osVersion',
                                               'serialNumber',
                                               'lastTime',
                                               'dataSourceLabel',
                                               'lastRetrievalTime'
    ) and dict_type = 'terminal_software_equipment_export_excel';



REPLACE INTO sys_dict_data
(dict_sort, dict_label, dict_value, dict_type, css_class, list_class, is_default, status, create_by, create_time, update_by, update_time, remark)
VALUES(1, 'IP地址', 'reportIp', 'terminal_software_equipment_export_excel', NULL, NULL, 'N', '0', 'super', '2023-03-22 15:15:35', '', NULL, '{ "isDefault": true, "isMust": true }');
REPLACE INTO sys_dict_data
(dict_sort, dict_label, dict_value, dict_type, css_class, list_class, is_default, status, create_by, create_time, update_by, update_time, remark)
VALUES(2, '计算机名称', 'computerName', 'terminal_software_equipment_export_excel', NULL, NULL, 'N', '0', 'super', '2023-03-22 15:16:02', '', NULL, '{ "isDefault": true, "isMust": true }');
REPLACE INTO sys_dict_data
(dict_sort, dict_label, dict_value, dict_type, css_class, list_class, is_default, status, create_by, create_time, update_by, update_time, remark)
VALUES(3, '系统账号', 'osAccount', 'terminal_software_equipment_export_excel', NULL, NULL, 'N', '0', 'super', '2023-03-22 15:22:40', '', NULL, '{ "isDefault": false, "isMust": false }');
REPLACE INTO sys_dict_data
(dict_sort, dict_label, dict_value, dict_type, css_class, list_class, is_default, status, create_by, create_time, update_by, update_time, remark)
VALUES(4, '所属组织', 'organization', 'terminal_software_equipment_export_excel', NULL, NULL, 'N', '0', 'super', '2023-03-22 15:19:19', '', NULL, '{ "isDefault": true, "isMust": false }');
REPLACE INTO sys_dict_data
(dict_sort, dict_label, dict_value, dict_type, css_class, list_class, is_default, status, create_by, create_time, update_by, update_time, remark)
VALUES(5, 'MAC地址', 'macAddress', 'terminal_software_equipment_export_excel', NULL, NULL, 'N', '0', 'super', '2023-03-22 15:16:27', '', NULL, '{ "isDefault": true, "isMust": true }');
REPLACE INTO sys_dict_data
(dict_sort, dict_label, dict_value, dict_type, css_class, list_class, is_default, status, create_by, create_time, update_by, update_time, remark)
VALUES(6, '责任人', 'dutyBod', 'terminal_software_equipment_export_excel', NULL, NULL, 'N', '0', 'super', '2023-03-22 15:19:39', '', NULL, '{ "isDefault": true, "isMust": false }');
REPLACE INTO sys_dict_data
(dict_sort, dict_label, dict_value, dict_type, css_class, list_class, is_default, status, create_by, create_time, update_by, update_time, remark)
VALUES(7, '使用人', 'useBod', 'terminal_software_equipment_export_excel', NULL, NULL, 'N', '0', 'super', '2023-03-22 15:20:05', '', NULL, '{ "isDefault": true, "isMust": false }');

REPLACE INTO sys_dict_data
(dict_sort, dict_label, dict_value, dict_type, css_class, list_class, is_default, status, create_by, create_time, update_by, update_time, remark)
VALUES(8, '终端分组', 'groupName', 'terminal_software_equipment_export_excel', NULL, NULL, 'N', '0', 'super', '2023-03-22 15:18:36', '', NULL, '{ "isDefault": true, "isMust": false }');

REPLACE INTO sys_dict_data
(dict_sort, dict_label, dict_value, dict_type, css_class, list_class, is_default, status, create_by, create_time, update_by, update_time, remark)
VALUES(9, '在线状态', 'onlineStatus', 'terminal_software_equipment_export_excel', NULL, NULL, 'N', '0', 'super', '2023-03-22 15:21:19', '', NULL, '{ "isDefault": true, "isMust": false }');

REPLACE INTO sys_dict_data
(dict_sort, dict_label, dict_value, dict_type, css_class, list_class, is_default, status, create_by, create_time, update_by, update_time, remark)
VALUES(10, '通信IP地址', 'ip', 'terminal_software_equipment_export_excel', NULL, NULL, 'N', '0', 'super', '2023-03-22 15:18:56', '', NULL, '{ "isDefault": false, "isMust": false }');

REPLACE INTO sys_dict_data
(dict_sort, dict_label, dict_value, dict_type, css_class, list_class, is_default, status, create_by, create_time, update_by, update_time, remark)
VALUES(11, '操作系统', 'osVersion', 'terminal_software_equipment_export_excel', NULL, NULL, 'N', '0', 'super', '2023-03-22 15:21:55', '', NULL, '{ "isDefault": false, "isMust": false }');

REPLACE INTO sys_dict_data
(dict_sort, dict_label, dict_value, dict_type, css_class, list_class, is_default, status, create_by, create_time, update_by, update_time, remark)
VALUES(12, 'SN序列号', 'serialNumber', 'terminal_software_equipment_export_excel', NULL, NULL, 'N', '0', 'super', '2023-03-22 15:22:58', '', NULL, '{ "isDefault": false, "isMust": false }');

REPLACE INTO sys_dict_data
(dict_sort, dict_label, dict_value, dict_type, css_class, list_class, is_default, status, create_by, create_time, update_by, update_time, remark)
VALUES(13, '最后在线时间', 'lastTime', 'terminal_software_equipment_export_excel', NULL, NULL, 'N', '0', 'super', '2023-03-22 15:21:37', '', NULL, '{ "isDefault": true, "isMust": false }');

REPLACE INTO sys_dict_data
(dict_sort, dict_label, dict_value, dict_type, css_class, list_class, is_default, status, create_by, create_time, update_by, update_time, remark)
VALUES(14, '数据来源', 'dataSourceLabel', 'terminal_software_equipment_export_excel', NULL, NULL, 'N', '0', 'super', '2023-03-22 15:23:17', '', NULL, '{ "isDefault": true, "isMust": false }');


REPLACE INTO sys_dict_data
(dict_sort, dict_label, dict_value, dict_type, css_class, list_class, is_default, status, create_by, create_time, update_by, update_time, remark)
VALUES(15, '最近检测时间', 'lastRetrievalTime', 'terminal_software_equipment_export_excel', NULL, NULL, 'N', '0', 'super', '2023-03-22 15:23:34', '', NULL, '{ "isDefault": true, "isMust": false }');


DELETE FROM sys_dict_data WHERE dict_value IN (
    'softwareCorp'
    ) and dict_type = 'terminal_software_export_excel';
-- 导入软件厂商新增字段
REPLACE INTO sys_dict_data
(dict_sort, dict_label, dict_value, dict_type, css_class, list_class, is_default, status, create_by, create_time, update_by, update_time, remark)
VALUES(4, '软件厂商', 'softwareCorp', 'terminal_software_export_excel', NULL, NULL, 'N', '0', 'super', '2024-05-10 09:57:25', '', NULL, NULL);


DELETE FROM sys_dict_type WHERE dict_type IN (
    'terminal_software_equipment_export_excel'
    );
-- 终端软件_终端设备_导出字段
REPLACE INTO sys_dict_type
(dict_name, dict_type, status, group_ids, create_by, create_time, update_by, update_time, remark, layout)
VALUES('终端软件_终端设备_导出字段', 'terminal_software_equipment_export_excel', '0', '600', 'super', '2023-03-22 09:49:16', '', NULL, NULL, '2');


-- 终端设备导出自动变更
UPDATE sys_dict_data
SET  dict_label='系统账号1'
WHERE dict_value='osAccount' and dict_type='terminal_equipment_export_excel';

UPDATE sys_dict_data
SET dict_label='计算机名称'
WHERE dict_value='computerName' and  dict_type='terminal_equipment_export_excel';


UPDATE sys_dict_data
SET  dict_label='SN序列号'
WHERE dict_value='serialNumber' and  dict_type='terminal_equipment_export_excel';



DELETE FROM sys_dict_data WHERE dict_value IN (
    'uniqueCode'
    ) and dict_type = 'terminal_equipment_export_excel';

REPLACE INTO sys_dict_data
(dict_sort, dict_label, dict_value, dict_type, css_class, list_class, is_default, status, create_by, create_time, update_by, update_time, remark)
VALUES(18, '设备唯一标识码', 'uniqueCode', 'terminal_equipment_export_excel', NULL, NULL, 'N', '0', 'super', '2024-05-17 15:02:00', 'super', '2024-05-17 15:09:34', '{ "isDefault": false , "isMust": false }');





-- 终端设备新增字段
-- 基本信息
ALTER table `tb_asset_terminal_equipment` add `unique_code` varchar(255) DEFAULT NULL COMMENT '唯一标识码';

ALTER table `tb_asset_terminal_equipment` add `host_compute` varchar(255) DEFAULT NULL COMMENT '宿主机';
-- 硬件信息
ALTER table `tb_asset_terminal_equipment` add `main_board` varchar(255) DEFAULT NULL COMMENT '主板';
ALTER table `tb_asset_terminal_equipment` add `network_card` varchar(255) DEFAULT NULL COMMENT '网卡';
ALTER table `tb_asset_terminal_equipment` add `sound_card` varchar(255) DEFAULT NULL COMMENT '声卡';
ALTER table `tb_asset_terminal_equipment` add `computer_model` varchar(255) DEFAULT NULL COMMENT '计算机型号';
ALTER table `tb_asset_terminal_equipment` add `cpu` varchar(255) DEFAULT NULL COMMENT 'CPU';
ALTER table `tb_asset_terminal_equipment` add `memory` varchar(255) DEFAULT NULL COMMENT '内存';
ALTER table `tb_asset_terminal_equipment` add `hard_risk` varchar(255) DEFAULT NULL COMMENT '硬盘';
ALTER table `tb_asset_terminal_equipment` add `graphics_card` varchar(255) DEFAULT NULL COMMENT '显卡';
ALTER table `tb_asset_terminal_equipment` add `display_device` varchar(255) DEFAULT NULL COMMENT '显示器';
ALTER table `tb_asset_terminal_equipment` add `mainboard_serial_num` varchar(255) DEFAULT NULL COMMENT '主板序列号';
-- 防护信息
ALTER table `tb_asset_terminal_equipment` add `terminal_version` varchar(255) DEFAULT NULL COMMENT '防护终端版本';
ALTER table `tb_asset_terminal_equipment` add `terminal_name` varchar(255) DEFAULT NULL COMMENT '防护终端名称';
ALTER table `tb_asset_terminal_equipment` add `vul_versoin` varchar(255) DEFAULT NULL COMMENT '漏洞库版本';
ALTER table `tb_asset_terminal_equipment` add `manufacturer` varchar(255) DEFAULT NULL COMMENT '原厂商';
ALTER table `tb_asset_terminal_equipment` add `engine_version` varchar(255) DEFAULT NULL COMMENT '修复引擎版本';
ALTER table `tb_asset_terminal_equipment` add `firewall_status` varchar(255) DEFAULT NULL COMMENT '防火墙状态';
ALTER table `tb_asset_terminal_equipment` add `real_firewall_status` varchar(255) DEFAULT NULL COMMENT '实时防护状态';
-- 变更记录
ALTER table `tb_asset_terminal_equipment` add `change_record` varchar(255) DEFAULT NULL COMMENT '变更记录';
-- 系统信息

ALTER table `tb_asset_terminal_equipment` add `system_version` varchar(255) DEFAULT NULL COMMENT '系统版本';
ALTER table `tb_asset_terminal_equipment` add `operate_system` varchar(255) DEFAULT NULL COMMENT '操作系统';
ALTER table `tb_asset_terminal_equipment` add `system_language` varchar(255) DEFAULT NULL COMMENT '系统语言';
ALTER table `tb_asset_terminal_equipment` add `install_date` datetime DEFAULT NULL COMMENT '安装日期';


-- 更新钓鱼状态字段类型，修复无法同时支持多个状态的问题
alter  table target_emplorees  modify status  varchar(255) DEFAULT NULL COMMENT ' 1邮件链接  2邮件附件  3邮件输入敏感信息  4短信链接 5扫描二维码';


-- 新增同步ues基础配置地址
DELETE FROM sys_dict_data WHERE dict_value IN (
    'ues_base_path'
    ) and dict_type = 'base_path';
INSERT INTO sys_dict_data
(dict_sort, dict_label, dict_value, dict_type, css_class, list_class, is_default, status, create_by, create_time, update_by, update_time, remark)
VALUES(2, 'https://ues_ssp_dev.crc.com.cn', 'ues_base_path', 'base_path', NULL, NULL, 'N', '0', 'super', '2024-06-04 16:28:41', '', NULL, NULL);



-- 新增同步USE管理端基础字段配置
DELETE FROM sys_dict_data WHERE dict_value IN (
    'ioa'
    ) and dict_type = 'tencent_cloud_api';
INSERT INTO sys_dict_data
(dict_sort, dict_label, dict_value, dict_type, css_class, list_class, is_default, status, create_by, create_time, update_by, update_time, remark)
VALUES(0, '腾讯ioa接口信息', 'ioa', 'tencent_cloud_api', NULL, NULL, 'N', '0', 'super', '2022-08-01 16:18:44', '', NULL, '{
	"secretId" : "4c23f9804cf411ecb2b84fc73a7861ed",
	"secretKey" : "$2a$10$S4p.EMDlxGpqt/d.a6P6QuFbAXSZp6dRjNbn7Bj/9yGjfmrRmQwUO",
	"hostAndPort" : "10.200.10.20:8443",
	"model" : "https",
        "version" : "2022-06-01"
}');

DELETE FROM sys_dict_type WHERE dict_type IN (
    'tencent_cloud_api'
    );
INSERT INTO sys_dict_type
(dict_name, dict_type, status, create_by, create_time, update_by, update_time, remark, layout)
VALUES('腾讯IOA', 'tencent_cloud_api', '0', 'super', '2022-08-01 16:18:26', '', NULL, NULL,1);


-- 润工作同步钓鱼系统需要的配置
DELETE FROM sys_dict_data WHERE dict_value IN (
    'fish_rwork_token'
    ) and dict_type = 'sync_sec_config';
INSERT INTO sys_dict_data
(dict_sort, dict_label, dict_value, dict_type, css_class, list_class, is_default, status, create_by, create_time, update_by, update_time, remark)
VALUES(9888, '润工作写三慧配置token', 'fish_rwork_token', 'sync_sec_config', NULL, NULL, 'N', '0', 'super', '2024-02-28 11:01:59', '', NULL, 'eyJhbGciOiJIUzUxMiIsInR5cCI6IkpXVCJ9.eyJuYW1lIjoic3VwZXIiLCJhZG1pbiI6dHJ1ZX0.aJEJcp8Ryu1SLUPWDLj16CY__GB7nEGIIk072ZWGfwbO_pULN9d_Pe-eMdhtjccsju2cVWA02cbyPjrluYvCgw');

DELETE FROM sys_dict_data WHERE dict_value IN (
    'ca9d1eef4d894f558b6ff834c9d72bd9'
    ) and dict_type = 'udc_api_key';
INSERT INTO sys_dict_data
(dict_sort, dict_label, dict_value, dict_type, css_class, list_class, is_default, status, create_by, create_time, update_by, update_time, remark)
VALUES(0, 'UES', 'ca9d1eef4d894f558b6ff834c9d72bd9', 'udc_api_key', NULL, NULL, 'N', '0', 'super', '2023-05-23 17:25:42', '', NULL, NULL);

DELETE FROM sys_dict_data WHERE dict_value IN (
    'os'
    ) and dict_type = 'udc_api_list';
INSERT INTO sys_dict_data
(dict_sort, dict_label, dict_value, dict_type, css_class, list_class, is_default, status, create_by, create_time, update_by, update_time, remark)
VALUES(0, 'os', 'os', 'udc_api_list', NULL, NULL, 'N', '0', 'super', '2023-08-31 17:27:16', '', NULL, NULL);


-- 钓鱼邮件管理需要的表
CREATE TABLE `tb_fish_mail` (
                                `mail_attached` text COMMENT '邮件附件名称',
                                `id` varchar(64) NOT NULL COMMENT '主键',
                                `send_to_mail` varchar(64) NOT NULL COMMENT '发件人邮箱地址',
                                `send_to` varchar(64) DEFAULT NULL COMMENT '发件人名称',
                                `mail_text` text COMMENT '邮件内容',
                                `mail_subject` varchar(255) NOT NULL COMMENT '邮件主题',
                                `email_send_time` datetime DEFAULT NULL COMMENT '邮件发送时间',
                                `report_to_mail` varchar(64) NOT NULL COMMENT '举报人邮箱地址',
                                `report_to` varchar(64) DEFAULT NULL COMMENT '举报人名称',
                                `report_time` datetime DEFAULT NULL COMMENT '举报时间',
                                `addressee_mail` text COMMENT '收件人邮箱地址',
                                `addressee` text COMMENT '收件人名称',
                                `confirm_status` tinyint(4) NOT NULL DEFAULT '0' COMMENT '确认状态 0未确认 1确认',
                                `confirm_result` tinyint(4) NOT NULL DEFAULT '0' COMMENT '确认结果  1 误报 2 钓鱼邮件',
                                `confirm_name` varchar(64) DEFAULT NULL COMMENT '确认人名称',
                                `confirm_time` datetime DEFAULT NULL COMMENT '确认时间',
                                `create_by` varchar(64) DEFAULT NULL COMMENT '创建者',
                                `create_time` datetime DEFAULT NULL COMMENT '创建时间',
                                `update_by` varchar(64) DEFAULT NULL COMMENT '修改者',
                                `update_time` datetime DEFAULT NULL COMMENT '修改时间',
                                `del_flag` char(1) DEFAULT '0' COMMENT '删除标识，0未删除，1已删除',
                                PRIMARY KEY (`id`),
                                UNIQUE KEY `UNIQUE(send-report)` (`send_to_mail`,`report_to_mail`,`mail_subject`) USING BTREE COMMENT '举报人、发件人、邮件主题相同'
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='钓鱼邮件管理表';




-- 终端设备导出字段配置更新   2024-0613 新增sql
DELETE FROM sys_dict_data WHERE  dict_type = 'terminal_equipment_export_excel' and status = '0';

INSERT INTO sys_dict_data
(dict_sort, dict_label, dict_value, dict_type, css_class, list_class, is_default, status, create_by, create_time, update_by, update_time, remark)
VALUES(1, 'IP地址', 'reportIp', 'terminal_equipment_export_excel', NULL, NULL, 'N', '0', 'super', '2023-03-22 15:15:35', '', NULL, '{ "isDefault": true, "isMust": true }');
INSERT INTO sys_dict_data
(dict_sort, dict_label, dict_value, dict_type, css_class, list_class, is_default, status, create_by, create_time, update_by, update_time, remark)
VALUES(2, '计算机名称', 'computerName', 'terminal_equipment_export_excel', NULL, NULL, 'N', '0', 'super', '2023-03-22 15:16:02', 'super', '2024-05-17 15:00:50', '{ "isDefault": true, "isMust": true }');
INSERT INTO sys_dict_data
(dict_sort, dict_label, dict_value, dict_type, css_class, list_class, is_default, status, create_by, create_time, update_by, update_time, remark)
VALUES(3, '系统账号', 'osAccount', 'terminal_equipment_export_excel', NULL, NULL, 'N', '0', 'super', '2023-03-22 15:22:40', 'super', '2024-05-17 15:01:02', '{ "isDefault": false, "isMust": false }');
INSERT INTO sys_dict_data
(dict_sort, dict_label, dict_value, dict_type, css_class, list_class, is_default, status, create_by, create_time, update_by, update_time, remark)
VALUES(4, '设备唯一标识码', 'uniqueCode', 'terminal_equipment_export_excel', NULL, NULL, 'N', '0', 'super', '2024-05-17 15:02:00', 'super', '2024-05-17 15:09:34', '{ "isDefault": false , "isMust": false }');
INSERT INTO sys_dict_data
(dict_sort, dict_label, dict_value, dict_type, css_class, list_class, is_default, status, create_by, create_time, update_by, update_time, remark)
VALUES(5, 'MAC地址', 'macAddress', 'terminal_equipment_export_excel', NULL, NULL, 'N', '0', 'super', '2023-03-22 15:16:27', '', NULL, '{ "isDefault": true, "isMust": true }');
INSERT INTO sys_dict_data
(dict_sort, dict_label, dict_value, dict_type, css_class, list_class, is_default, status, create_by, create_time, update_by, update_time, remark)
VALUES(6, '所属组织', 'organization', 'terminal_equipment_export_excel', NULL, NULL, 'N', '0', 'super', '2023-03-22 15:19:19', '', NULL, '{ "isDefault": true, "isMust": false }');
INSERT INTO sys_dict_data
(dict_sort, dict_label, dict_value, dict_type, css_class, list_class, is_default, status, create_by, create_time, update_by, update_time, remark)
VALUES(7, '责任人', 'dutyBod', 'terminal_equipment_export_excel', NULL, NULL, 'N', '0', 'super', '2023-03-22 15:19:39', '', NULL, '{ "isDefault": true, "isMust": false }');
INSERT INTO sys_dict_data
(dict_sort, dict_label, dict_value, dict_type, css_class, list_class, is_default, status, create_by, create_time, update_by, update_time, remark)
VALUES(8, '使用人', 'useBod', 'terminal_equipment_export_excel', NULL, NULL, 'N', '0', 'super', '2023-03-22 15:20:05', '', NULL, '{ "isDefault": true, "isMust": false }');
INSERT INTO sys_dict_data
(dict_sort, dict_label, dict_value, dict_type, css_class, list_class, is_default, status, create_by, create_time, update_by, update_time, remark)
VALUES(9, '终端分组', 'groupName', 'terminal_equipment_export_excel', NULL, NULL, 'N', '0', 'super', '2023-03-22 15:18:36', '', NULL, '{ "isDefault": true, "isMust": false }');
INSERT INTO sys_dict_data
(dict_sort, dict_label, dict_value, dict_type, css_class, list_class, is_default, status, create_by, create_time, update_by, update_time, remark)
VALUES(10, '在线状态', 'onlineStatus', 'terminal_equipment_export_excel', NULL, NULL, 'N', '0', 'super', '2023-03-22 15:21:19', '', NULL, '{ "isDefault": true, "isMust": false }');
INSERT INTO sys_dict_data
(dict_sort, dict_label, dict_value, dict_type, css_class, list_class, is_default, status, create_by, create_time, update_by, update_time, remark)
VALUES(11, '通信IP地址', 'ip', 'terminal_equipment_export_excel', NULL, NULL, 'N', '0', 'super', '2023-03-22 15:18:56', '', NULL, '{ "isDefault": false, "isMust": false }');
INSERT INTO sys_dict_data
(dict_sort, dict_label, dict_value, dict_type, css_class, list_class, is_default, status, create_by, create_time, update_by, update_time, remark)
VALUES(12, '操作系统', 'osVersion', 'terminal_equipment_export_excel', NULL, NULL, 'N', '0', 'super', '2023-03-22 15:21:55', '', NULL, '{ "isDefault": false, "isMust": false }');
INSERT INTO sys_dict_data
(dict_sort, dict_label, dict_value, dict_type, css_class, list_class, is_default, status, create_by, create_time, update_by, update_time, remark)
VALUES(13, 'SN序列号', 'serialNumber', 'terminal_equipment_export_excel', NULL, NULL, 'N', '0', 'super', '2023-03-22 15:22:58', 'super', '2024-05-17 15:07:50', '{ "isDefault": false, "isMust": false }');
INSERT INTO sys_dict_data
(dict_sort, dict_label, dict_value, dict_type, css_class, list_class, is_default, status, create_by, create_time, update_by, update_time, remark)
VALUES(14, '最后在线时间', 'lastTime', 'terminal_equipment_export_excel', NULL, NULL, 'N', '0', 'super', '2023-03-22 15:21:37', '', NULL, '{ "isDefault": true, "isMust": false }');
INSERT INTO sys_dict_data
(dict_sort, dict_label, dict_value, dict_type, css_class, list_class, is_default, status, create_by, create_time, update_by, update_time, remark)
VALUES(15, '数据来源', 'dataSourceLabel', 'terminal_equipment_export_excel', NULL, NULL, 'N', '0', 'super', '2023-03-22 15:23:17', '', NULL, '{ "isDefault": true, "isMust": false }');
INSERT INTO sys_dict_data
(dict_sort, dict_label, dict_value, dict_type, css_class, list_class, is_default, status, create_by, create_time, update_by, update_time, remark)
VALUES(16, '最近检测时间', 'lastRetrievalTime', 'terminal_equipment_export_excel', NULL, NULL, 'N', '0', 'super', '2023-03-22 15:23:34', '', NULL, '{ "isDefault": true, "isMust": false }');

UPDATE sys_dict_data set dict_sort  = 4 WHERE  dict_type = 'terminal_software_export_excel'and dict_value = 'installCount' and status = '0';
UPDATE sys_dict_data set dict_sort  = 3 WHERE  dict_type = 'terminal_software_export_excel'and dict_value = 'softwareCorp' and status = '0';
UPDATE sys_dict_data set dict_sort  = 5 WHERE  dict_type = 'terminal_software_equipment_export_excel'and dict_value = 'organization' and status = '0';
UPDATE sys_dict_data set dict_sort  = 4 WHERE  dict_type = 'terminal_software_equipment_export_excel'and dict_value = 'macAddress' and status = '0';


-- 钓鱼邮件可视化脚本

DELETE FROM tb_visual_chart WHERE id IN ('202306151703067180000','202306151708099430001','202306151718365360003','202306151734111520004','202306151734509600005'
,'202405231434047380011', '202306151711104890002', '202306151806126770010', '202306151742045170006', '202306151748282070008','202306151746283910007','202405241620217270001');

DELETE FROM tb_visual_chart WHERE id IN ('20240527100801790002','20240527100801900003','20240527100801950004','202405271008011000005','202405271008011050006','202405271008011090007',
'202405271008011130008','202405271008011400010','202405271008011430011','202405271008011470012');

DELETE FROM tb_visual_panel WHERE id IN ('202405241733053430002', '202405271008011550014');

insert into `tb_visual_chart` (`id`, `code`, `name`, `type`, `data_type`, `source`, `json_data`, `data_property`, `json_param`, `json_property`, `theme`, `number`, `min_width`, `min_height`, `default_width`, `default_height`, `background`, `cache`, `es_index`, `json_tab`, `memo`, `create_by`, `create_by_label`, `create_time`, `update_by`, `update_time`, `group_id`, `status`, `group_path`, `relation_type`, `relation_content`, `relation_open`, `relation_params`, `relation_way`) values('202306151703067180000','S-000028','发送数和送达数','text-progress','sql','','SELECT SUM(total) AS 发送数 , IFNULL( SUM(num_of_send), 0) AS 送达数 , IFNULL( SUM(num_of_send)/SUM(total)*100 , 0 ) AS 送达率  \nFROM task_info WHERE task_id = \"${taskId<202111151>}\"',NULL,'{\"timeType\":\"0\",\"dateStart\":\"\",\"dateEnd\":\"\",\"recentlyTime\":\"\"}','{\"dataHeader\":[{\"key\":\"发送数\",\"num\":1},{\"key\":\"送达数\",\"num\":2},{\"key\":\"送达率\",\"num\":3}]}','singleGreen','','1','1','1','1',NULL,'0','',NULL,NULL,'super','管理员','2023-06-15 17:03:07','super','2024-06-06 17:31:33','100','1','100',NULL,'','0',NULL,'0');
insert into `tb_visual_chart` (`id`, `code`, `name`, `type`, `data_type`, `source`, `json_data`, `data_property`, `json_param`, `json_property`, `theme`, `number`, `min_width`, `min_height`, `default_width`, `default_height`, `background`, `cache`, `es_index`, `json_tab`, `memo`, `create_by`, `create_by_label`, `create_time`, `update_by`, `update_time`, `group_id`, `status`, `group_path`, `relation_type`, `relation_content`, `relation_open`, `relation_params`, `relation_way`) values('202306151708099430001','S-000029','中招人数','text-progress','sql','','SELECT \n    COUNT(DISTINCT (e.email)) AS \'中招数\',\n    IFNULL(\n      COUNT(DISTINCT (e.email)) / (\n        SELECT SUM(num_of_send) FROM task_info WHERE task_id = \"${taskId<202111151>}\"\n      ) * 100,\n      0\n    ) AS \'中招率\' \n  FROM\n    target_emplorees e \n  WHERE e.task_id = \"${taskId<202111151>}\"',NULL,'{\"timeType\":\"0\",\"dateStart\":\"\",\"dateEnd\":\"\",\"recentlyTime\":\"\"}','{\"dataHeader\":[{\"key\":\"中招数\",\"num\":1},{\"key\":\"中招率\",\"num\":2}]}','singleRed','','1','1','1','1',NULL,'0','',NULL,NULL,'super','管理员','2023-06-15 17:08:10','super','2024-06-06 17:31:26','100','1','100',NULL,'','0',NULL,'0');
insert into `tb_visual_chart` (`id`, `code`, `name`, `type`, `data_type`, `source`, `json_data`, `data_property`, `json_param`, `json_property`, `theme`, `number`, `min_width`, `min_height`, `default_width`, `default_height`, `background`, `cache`, `es_index`, `json_tab`, `memo`, `create_by`, `create_by_label`, `create_time`, `update_by`, `update_time`, `group_id`, `status`, `group_path`, `relation_type`, `relation_content`, `relation_open`, `relation_params`, `relation_way`) values('202306151711104890002','S-000030','打开附件人数','text-progress','sql','','SELECT COUNT( DISTINCT(e.email) ) AS 打开附件人数 , IFNULL( COUNT( DISTINCT(e.email) ) / (SELECT \n        SUM(num_of_send) \n      FROM\n        task_info \n      WHERE task_id = \"${taskId<202111151>}\") * 100 , 0 ) AS 打开率 \nFROM target_emplorees e \nWHERE e.task_id = \"${taskId<202111151>}\" AND FIND_IN_SET(\'2\', e.status) > 0',NULL,'{\"timeType\":\"0\",\"dateStart\":\"\",\"dateEnd\":\"\",\"recentlyTime\":\"\"}','{\"dataHeader\":[{\"key\":\"打开附件人数\",\"num\":1},{\"key\":\"打开率\",\"num\":2}]}','singleYellow','','1','1','1','1',NULL,'0','',NULL,NULL,'super','管理员','2023-06-15 17:11:10','super','2024-06-06 17:31:20','100','1','100',NULL,'','0',NULL,'0');
insert into `tb_visual_chart` (`id`, `code`, `name`, `type`, `data_type`, `source`, `json_data`, `data_property`, `json_param`, `json_property`, `theme`, `number`, `min_width`, `min_height`, `default_width`, `default_height`, `background`, `cache`, `es_index`, `json_tab`, `memo`, `create_by`, `create_by_label`, `create_time`, `update_by`, `update_time`, `group_id`, `status`, `group_path`, `relation_type`, `relation_content`, `relation_open`, `relation_params`, `relation_way`) values('202306151718365360003','S-000031','点击链接人数','text-progress','sql','','SELECT \n  COUNT(DISTINCT (e.email)) AS 点击邮件链接人数,\n  IFNULL(\n    COUNT(DISTINCT (e.email)) / \n    (SELECT \n      SUM(num_of_send) \n    FROM\n      task_info \n    WHERE task_id = \"${taskId<202111151>}\") * 100,\n    0\n  ) AS 点击率 \nFROM\n  target_emplorees e \nWHERE e.task_id = \"${taskId<202111151>}\" \n  AND (FIND_IN_SET(\'1\', e.status) > 0 OR FIND_IN_SET(\'3\', e.status))',NULL,'{\"timeType\":\"0\",\"dateStart\":\"\",\"dateEnd\":\"\",\"recentlyTime\":\"\"}','{\"dataHeader\":[{\"key\":\"点击邮件链接人数\",\"num\":1},{\"key\":\"点击率\",\"num\":2}]}','singleBlue','','1','1','1','1',NULL,'0','',NULL,NULL,'super','管理员','2023-06-15 17:18:37','super','2024-06-06 17:31:13','100','1','100',NULL,'','0',NULL,'0');
insert into `tb_visual_chart` (`id`, `code`, `name`, `type`, `data_type`, `source`, `json_data`, `data_property`, `json_param`, `json_property`, `theme`, `number`, `min_width`, `min_height`, `default_width`, `default_height`, `background`, `cache`, `es_index`, `json_tab`, `memo`, `create_by`, `create_by_label`, `create_time`, `update_by`, `update_time`, `group_id`, `status`, `group_path`, `relation_type`, `relation_content`, `relation_open`, `relation_params`, `relation_way`) values('202306151734111520004','S-000031','输入敏感信息人数','text-progress','sql','','SELECT COUNT( DISTINCT(e.email) ) AS 输入敏感信息人数, IFNULL( COUNT( DISTINCT(e.email) ) / (SELECT \n        SUM(num_of_send) \n      FROM\n        task_info \n      WHERE task_id = \"${taskId<202111151>}\")  * 100, 0) AS 点击率 \nFROM target_emplorees e \nWHERE e.task_id = \"${taskId<202111151>}\" and FIND_IN_SET(\'3\', e.status) > 0',NULL,'{\"timeType\":\"0\",\"dateStart\":\"\",\"dateEnd\":\"\",\"recentlyTime\":\"\"}','{\"dataHeader\":[{\"key\":\"输入敏感信息人数\",\"num\":1},{\"key\":\"点击率\",\"num\":2}]}','singleBlue','','1','1','1','1',NULL,'0','',NULL,NULL,'super','管理员','2023-06-15 17:34:11','super','2024-06-06 17:31:05','100','1','100',NULL,'','0',NULL,'0');
insert into `tb_visual_chart` (`id`, `code`, `name`, `type`, `data_type`, `source`, `json_data`, `data_property`, `json_param`, `json_property`, `theme`, `number`, `min_width`, `min_height`, `default_width`, `default_height`, `background`, `cache`, `es_index`, `json_tab`, `memo`, `create_by`, `create_by_label`, `create_time`, `update_by`, `update_time`, `group_id`, `status`, `group_path`, `relation_type`, `relation_content`, `relation_open`, `relation_params`, `relation_way`) values('202306151734509600005','S-000031','点击短信链接人数','text-progress','sql','','SELECT COUNT( DISTINCT(e.email) ) AS 点击短信链接人数 , IFNULL( COUNT( DISTINCT(e.email) ) / (SELECT \n        SUM(num_of_send) \n      FROM\n        task_info \n      WHERE task_id = \"${taskId<202111151>}\") * 100, 0) AS 点击率 \nFROM target_emplorees e \nWHERE e.task_id = \"${taskId<202111151>}\"  AND FIND_IN_SET(\'4\', e.status) > 0',NULL,'{\"timeType\":\"0\",\"dateStart\":\"\",\"dateEnd\":\"\",\"recentlyTime\":\"\"}','{\"dataHeader\":[{\"key\":\"点击短信链接人数\",\"num\":1},{\"key\":\"点击率\",\"num\":2}]}','singleBlue','','1','1','1','1',NULL,'0','',NULL,NULL,'super','管理员','2023-06-15 17:34:51','super','2024-06-06 17:30:56','100','1','100',NULL,'','0',NULL,'0');
insert into `tb_visual_chart` (`id`, `code`, `name`, `type`, `data_type`, `source`, `json_data`, `data_property`, `json_param`, `json_property`, `theme`, `number`, `min_width`, `min_height`, `default_width`, `default_height`, `background`, `cache`, `es_index`, `json_tab`, `memo`, `create_by`, `create_by_label`, `create_time`, `update_by`, `update_time`, `group_id`, `status`, `group_path`, `relation_type`, `relation_content`, `relation_open`, `relation_params`, `relation_way`) values('202306151742045170006','S-000033','中招高峰时间分布','area','sql','','( \nSELECT COUNT( DISTINCT(e.email) ) AS COUNT , \'点击邮件链接人数\' AS child, DATE_FORMAT(cap_time, \'%H:00\') AS NAME \nFROM target_emplorees e \nWHERE e.task_id = \"${taskId<202111151>}\"  AND FIND_IN_SET(\'1\', e.status) > 0 GROUP BY DATE_FORMAT(cap_time, \'%H:00\') \n)\nUNION\n(   SELECT COUNT( DISTINCT(e.email) ) AS COUNT , \'打开附件人数\' AS child, DATE_FORMAT(e.cap_time, \'%H:00\') AS NAME \nFROM target_emplorees e \nWHERE e.task_id = \"${taskId<202111151>}\"  AND FIND_IN_SET(\'2\', e.status) > 0 GROUP BY DATE_FORMAT(e.cap_time, \'%H:00\') )\nUNION\n(   SELECT COUNT( DISTINCT(e.email) ) AS COUNT , \'输入敏感信息人数\' AS child, DATE_FORMAT(e.cap_time, \'%H:00\') AS NAME \nFROM target_emplorees e \nWHERE e.task_id = \"${taskId<202111151>}\"  AND FIND_IN_SET(\'3\', e.status) > 0 GROUP BY DATE_FORMAT(e.cap_time, \'%H:00\') )\nUNION\n(   SELECT COUNT( DISTINCT(e.email) ) AS COUNT , \'扫描二维码人数\' AS child, DATE_FORMAT(e.cap_time, \'%H:00\') AS NAME \nFROM target_emplorees e \nWHERE e.task_id = \"${taskId<202111151>}\"  AND FIND_IN_SET(\'5\', e.status) > 0 GROUP BY DATE_FORMAT(e.cap_time, \'%H:00\') )\nUNION\n(   SELECT COUNT( DISTINCT(e.email) ) AS COUNT , \'点击短信链接人数\' AS child, DATE_FORMAT(e.cap_time, \'%H:00\') AS NAME \nFROM target_emplorees e \nWHERE e.task_id = \"${taskId<202111151>}\"  AND FIND_IN_SET(\'4\', e.status) > 0 GROUP BY DATE_FORMAT(e.cap_time, \'%H:00\') )\nORDER BY NAME ASC',NULL,'{\"timeType\":\"0\",\"dateStart\":\"\",\"dateEnd\":\"\",\"recentlyTime\":\"\"}','{\"legendData\":[\"点击邮件链接人数\",\"打开附件人数\",\"输入敏感信息人数\",\"扫描二维码人数\",\"点击短信链接人数\"]}','colorgroup15','','4','3','4','3',NULL,'0','',NULL,NULL,'super','管理员','2023-06-15 17:42:05','super','2024-06-06 17:30:49','100','1','100',NULL,'','0',NULL,'0');
insert into `tb_visual_chart` (`id`, `code`, `name`, `type`, `data_type`, `source`, `json_data`, `data_property`, `json_param`, `json_property`, `theme`, `number`, `min_width`, `min_height`, `default_width`, `default_height`, `background`, `cache`, `es_index`, `json_tab`, `memo`, `create_by`, `create_by_label`, `create_time`, `update_by`, `update_time`, `group_id`, `status`, `group_path`, `relation_type`, `relation_content`, `relation_open`, `relation_params`, `relation_way`) values('202306151746283910007','S-000034','中招率趋势','line','sql','','select * from (\nSELECT cap_rate AS COUNT, cap_name AS NAME FROM task_cap \n ORDER BY cap_start desc LIMIT 0,5 ) t ORDER BY NAME  asc',NULL,'{\"timeType\":\"0\",\"dateStart\":\"\",\"dateEnd\":\"\",\"recentlyTime\":\"\"}','{\"legendData\":\"中招率\",\"yAxisUnit\":\"%\",\"xaxisLabelRotate\":30}','singleBlue','','','','','',NULL,'0','',NULL,NULL,'super','管理员','2023-06-15 17:46:28','super','2024-06-06 17:30:37','100','1','100',NULL,'','0',NULL,'0');
insert into `tb_visual_chart` (`id`, `code`, `name`, `type`, `data_type`, `source`, `json_data`, `data_property`, `json_param`, `json_property`, `theme`, `number`, `min_width`, `min_height`, `default_width`, `default_height`, `background`, `cache`, `es_index`, `json_tab`, `memo`, `create_by`, `create_by_label`, `create_time`, `update_by`, `update_time`, `group_id`, `status`, `group_path`, `relation_type`, `relation_content`, `relation_open`, `relation_params`, `relation_way`) values('202306151748282070008','S-000036','中招详情(按中招时间倒序排序)','table','sql','','SELECT depend1 AS \'单位\', depend2 AS \'部门\', NAME AS \'姓名\', email AS \'邮箱\',  IF(MAX(isFile),\'是\',\'否\') AS \'是否打开邮件附件\' ,\n      IF(MAX(isLink),\'是\',\'否\') AS \'是否点击邮件链接\'  , IF(MAX(isQRCode),\'是\',\'否\') AS \'是否扫描二维码\' , IF(MAX(isInput),\'是\',\'否\') AS \'是否输入敏感信息\' ,\n      IF(MAX(isNote),\'是\',\'否\') AS \'是否点击短信链接\'  ,  min(cap_time) AS \'中招时间\'\n   FROM ( \n	SELECT depend1, depend2 , NAME, email ,IF(STATUS=2, 1, 0) AS isFile, IF(STATUS=1,1,IF(STATUS =3, 1, 0)) AS isLink ,IF(STATUS=5, 1, 0) AS isQRCode,IF(STATUS=3, 1, 0) AS isInput, IF(STATUS=4,1,0) AS isNote , cap_time\n	FROM target_emplorees WHERE task_id = \"${taskId<202111151>}\" ORDER BY cap_time DESC LIMIT 0,10000000 \n   ) a GROUP BY email ORDER BY MIN(cap_time) DESC',NULL,'{\"timeType\":\"0\",\"dateStart\":\"\",\"dateEnd\":\"\",\"recentlyTime\":\"\"}','{\"tableHeader\":[{\"name\":\"单位\",\"field\":\"单位\"},{\"name\":\"部门\",\"field\":\"部门\"},{\"name\":\"姓名\",\"field\":\"姓名\"},{\"name\":\"邮箱\",\"field\":\"邮箱\"},{\"name\":\"是否打开邮件附件\",\"field\":\"是否打开邮件附件\"},{\"name\":\"是否点击邮件链接\",\"field\":\"是否点击邮件链接\"},{\"name\":\"是否扫描二维码\",\"field\":\"是否扫描二维码\"},{\"name\":\"是否输入敏感信息\",\"field\":\"是否输入敏感信息\"},{\"name\":\"是否点击短信链接\",\"field\":\"是否点击短信链接\"},{\"name\":\"中招时间\",\"field\":\"中招时间\"}]}','blue','','4','3','6','5',NULL,'0','',NULL,NULL,'super','管理员','2023-06-15 17:48:28','super','2024-06-06 17:30:24','100','1','100',NULL,'','0',NULL,'0');
insert into `tb_visual_chart` (`id`, `code`, `name`, `type`, `data_type`, `source`, `json_data`, `data_property`, `json_param`, `json_property`, `theme`, `number`, `min_width`, `min_height`, `default_width`, `default_height`, `background`, `cache`, `es_index`, `json_tab`, `memo`, `create_by`, `create_by_label`, `create_time`, `update_by`, `update_time`, `group_id`, `status`, `group_path`, `relation_type`, `relation_content`, `relation_open`, `relation_params`, `relation_way`) values('202306151806126770010','S-000032','各单位中招情况(按中招率由高到低排序)','bar','sql','','( SELECT t.bu_name AS NAME , IFNULL(capCount, 0)/t.num_of_send * 100 AS COUNT,  \'中招率\' AS CHILD \n FROM task_info t\n   LEFT JOIN ( SELECT COUNT( DISTINCT(e.email) ) AS capCount, e.depend2, e.task_id FROM target_emplorees e WHERE e.task_id = \'${taskId<202111151>}\'   GROUP BY e.depend2 ) a \n     on t.bu_name = a.depend2\n  where t.task_id = \"${taskId<202111151>}\"   ORDER BY COUNT DESC \n) UNION (\n SELECT t.bu_name AS NAME , IFNULL(capCount, 0 ) AS COUNT, \'中招人数\' AS CHILD\n FROM task_info t\n   LEFT JOIN ( SELECT COUNT( DISTINCT(e.email) ) AS capCount, e.depend2, e.task_id FROM target_emplorees e WHERE e.task_id = \'${taskId<202111151>}\'   GROUP BY e.depend2 ) a \n     on t.bu_name = a.depend2\n  where t.task_id = \"${taskId<202111151>}\"   ORDER BY COUNT DESC\n  )',NULL,'{\"timeType\":\"0\",\"dateStart\":\"\",\"dateEnd\":\"\",\"recentlyTime\":\"\"}','{legendData:[\"中招人数\",\"中招率\"],\"yTwoAxisUnit\":\"%\",\"yTwoAxisLegend\":\"中招率\",\"labelPosition\":\"top\",\"labelFontSize\":11,\"legendDataColor\":{\"中招人数\":\"#71a3f3\",\"中招率\":\"#ffc836\"},\"barGap\":\"100%\",\"dataFormat\":[{\"field\":\"中招率\",\"type\":\"decimal\",\"point\":2}],\"dataOrder\":{\"field\":\"中招率\",\"sort\":\"desc\"}}','blueYellow','','4','3','6','5',NULL,'0','',NULL,NULL,'super','管理员','2023-06-15 18:06:13','super','2024-06-06 17:29:41','100','1','100',NULL,'','0',NULL,'0');
insert into `tb_visual_chart` (`id`, `code`, `name`, `type`, `data_type`, `source`, `json_data`, `data_property`, `json_param`, `json_property`, `theme`, `number`, `min_width`, `min_height`, `default_width`, `default_height`, `background`, `cache`, `es_index`, `json_tab`, `memo`, `create_by`, `create_by_label`, `create_time`, `update_by`, `update_time`, `group_id`, `status`, `group_path`, `relation_type`, `relation_content`, `relation_open`, `relation_params`, `relation_way`) values('202405231434047380011','S-000709','扫描二维码','text-progress','sql','','SELECT \n  COUNT(DISTINCT (e.email)) AS 扫描二维码人数,\n  IFNULL(\n    COUNT(DISTINCT (e.email)) / (SELECT \n        SUM(num_of_send) \n      FROM\n        task_info \n      WHERE task_id = \"${taskId<202111151>}\") * 100,\n    0\n  ) AS 扫描率 \nFROM\n  target_emplorees e \nWHERE e.task_id = \"${taskId<202111151>}\" \n  AND FIND_IN_SET(\'5\', e.status) > 0',NULL,'{\"timeType\":\"0\",\"dateStart\":\"\",\"dateEnd\":\"\",\"recentlyTime\":\"\"}','{\"dataHeader\":[{\"key\":\"扫描二维码人数\",\"num\":1},{\"key\":\"扫描率\",\"num\":2}]}','colorgroup16','','1','1','4','3',NULL,'0','',NULL,NULL,'super','管理员','2024-05-23 14:34:05','super','2024-06-06 17:28:41','100','1','100','','','1',NULL,'0');
insert into `tb_visual_chart` (`id`, `code`, `name`, `type`, `data_type`, `source`, `json_data`, `data_property`, `json_param`, `json_property`, `theme`, `number`, `min_width`, `min_height`, `default_width`, `default_height`, `background`, `cache`, `es_index`, `json_tab`, `memo`, `create_by`, `create_by_label`, `create_time`, `update_by`, `update_time`, `group_id`, `status`, `group_path`, `relation_type`, `relation_content`, `relation_open`, `relation_params`, `relation_way`) values('202405241620217270001','S-000046','各单位中招数据(按中招率由高到低排序)','table','sql','','(\nSELECT @rownum:=@rownum+1 AS \'排名\' , t.* FROM ( SELECT t.bu_name AS \'单位\' , IFNULL( t.total, 0 ) AS \'发送数\', \nIFNULL( t.num_of_send, 0 ) AS \'送达数\', IFNULL(capCount, 0 ) AS \'中招人数\', \nIFNULL(capCount, 0)/t.num_of_send * 100 AS \'中招率\', \nIFNULL(openCount, 0) AS \'打开邮件附件人数\', \nIFNULL(openCount, 0)/t.num_of_send * 100 AS \'邮件附件打开率\',\nIFNULL(linkCount, 0) AS \'点击邮件链接人数\',\nIFNULL(linkCount, 0)/t.num_of_send * 100 AS \'邮件链接点击率\',\nIFNULL(qrCodeCount, 0) AS \'扫描二维码\',\nIFNULL(qrCodeCount, 0)/t.num_of_send * 100 AS \'二维码扫描率\',\nIFNULL(inputCount, 0) AS \'输入敏感信息人数\', \nIFNULL(inputCount, 0)/t.num_of_send * 100 AS \'敏感信息输入率\',\nIFNULL(noteCount, 0) AS \'点击短信链接人数\', \nIFNULL(noteCount, 0)/t.num_of_send * 100 AS \'短信链接点击率\'\n\n FROM \ntask_info t\n LEFT JOIN ( SELECT COUNT( DISTINCT(e.email) ) AS capCount, e.depend2, e.task_id FROM target_emplorees e WHERE e.task_id = \'${taskId<202111151>}\'   GROUP BY e.depend2 ) a \n  ON t.bu_name = a.depend2\nLEFT JOIN ( SELECT COUNT( DISTINCT(e.email) ) AS openCount, e.depend2 FROM target_emplorees e WHERE e.task_id = \'${taskId<202111151>}\' AND FIND_IN_SET(\'2\', e.status) > 0 GROUP BY e.depend2 ) b \n  ON t.bu_name = b.depend2 \nLEFT JOIN ( SELECT COUNT( DISTINCT(e.email) ) AS linkCount, e.depend2 FROM target_emplorees e WHERE e.task_id = \'${taskId<202111151>}\'  AND FIND_IN_SET(\'1\', e.status) > 0 GROUP BY e.depend2 ) c \n  ON t.bu_name = c.depend2 \nLEFT JOIN ( SELECT COUNT( DISTINCT(e.email) ) AS qrCodeCount, e.depend2 FROM target_emplorees e WHERE e.task_id = \'${taskId<202111151>}\'  AND FIND_IN_SET(\'5\', e.status) > 0 GROUP BY e.depend2 ) g \n  ON t.bu_name = g.depend2 \nLEFT JOIN ( SELECT COUNT( DISTINCT(e.email) ) AS inputCount, e.depend2 FROM target_emplorees e WHERE e.task_id = \'${taskId<202111151>}\'   AND FIND_IN_SET(\'3\', e.status) > 0 GROUP BY e.depend2 ) d \n  ON t.bu_name = d.depend2 \nLEFT JOIN ( SELECT COUNT( DISTINCT(e.email) ) AS noteCount, e.depend2 FROM target_emplorees e WHERE e.task_id = \'${taskId<202111151>}\'  AND FIND_IN_SET(\'4\', e.status) > 0 GROUP BY e.depend2 ) f \n  ON t.bu_name = f.depend2 \n  \n  WHERE t.task_id = \"${taskId<202111151>}\"    ORDER BY 中招率 DESC ) t, (SELECT @rownum:=0) r \n)\nUNION\n(\nSELECT \'总计\' AS \'排名\',  \'\' AS \'单位\',\n(SELECT SUM(total)  FROM task_info WHERE task_id = \"${taskId<202111151>}\"   ) AS \'发送数\',\n(SELECT IFNULL( SUM(num_of_send), 0)  FROM task_info WHERE task_id = \"${taskId<202111151>}\"   ) AS \'送达数\',\n(SELECT COUNT( DISTINCT(e.email) )  \nFROM target_emplorees e INNER JOIN task_info t ON e.task_id = t.task_id AND e.depend1 = t.bu_name\nWHERE t.task_id = \"${taskId<202111151>}\"  ) AS  \'中招人数\',\n(SELECT IFNULL( COUNT( DISTINCT(e.email) ) / (SELECT IFNULL( SUM(num_of_send), 0)  FROM task_info WHERE task_id = \"${taskId<202111151>}\"   ) * 100 , 0)  \nFROM target_emplorees e INNER JOIN task_info t ON e.task_id = t.task_id AND e.depend1 = t.bu_name\nWHERE t.task_id = \"${taskId<202111151>}\"  ) AS \'中招率\',\n( SELECT COUNT( DISTINCT(e.email) ) \nFROM target_emplorees e INNER JOIN task_info t ON e.task_id = t.task_id AND e.depend1 = t.bu_name\nWHERE t.task_id = \"${taskId<202111151>}\"   AND FIND_IN_SET(\'2\', e.status) > 0  ) AS \'打开邮件附件人数\', \n(SELECT IFNULL( COUNT( DISTINCT(e.email) ) / (SELECT IFNULL( SUM(num_of_send), 0)  FROM task_info WHERE task_id = \"${taskId<202111151>}\"   ) * 100 , 0 )\nFROM target_emplorees e INNER JOIN task_info t ON e.task_id = t.task_id AND e.depend1 = t.bu_name\nWHERE t.task_id = \"${taskId<202111151>}\"   AND FIND_IN_SET(\'2\', e.status) > 0 ) AS \'邮件附件打开率\',\n(SELECT COUNT( DISTINCT(e.email) ) \nFROM target_emplorees e INNER JOIN task_info t ON e.task_id = t.task_id AND e.depend1 = t.bu_name\nWHERE t.task_id = \"${taskId<202111151>}\"   AND FIND_IN_SET(\'1\', e.status) > 0) AS \'点击邮件链接人数\',\n(SELECT IFNULL( COUNT( DISTINCT(e.email) ) / (SELECT IFNULL( SUM(num_of_send), 0)  FROM task_info WHERE task_id = \"${taskId<202111151>}\"   ) * 100 , 0 )\nFROM target_emplorees e INNER JOIN task_info t ON e.task_id = t.task_id AND e.depend1 = t.bu_name\nWHERE t.task_id = \"${taskId<202111151>}\"   AND FIND_IN_SET(\'1\', e.status) > 0) AS \'邮件链接点击率\',\n(SELECT COUNT( DISTINCT(e.email) ) \nFROM target_emplorees e INNER JOIN task_info t ON e.task_id = t.task_id AND e.depend1 = t.bu_name\nWHERE t.task_id = \"${taskId<202111151>}\"   AND FIND_IN_SET(\'5\', e.status) > 0) AS \'扫描二维码\',\n(SELECT IFNULL( COUNT( DISTINCT(e.email) ) / (SELECT IFNULL( SUM(num_of_send), 0)  FROM task_info WHERE task_id = \"${taskId<202111151>}\"   ) * 100 , 0 )\nFROM target_emplorees e INNER JOIN task_info t ON e.task_id = t.task_id AND e.depend1 = t.bu_name\nWHERE t.task_id = \"${taskId<202111151>}\"   AND FIND_IN_SET(\'5\', e.status) > 0) AS \'二维码扫描率\',\n(SELECT COUNT( DISTINCT(e.email) ) \nFROM target_emplorees e INNER JOIN task_info t ON e.task_id = t.task_id AND e.depend1 = t.bu_name\nWHERE t.task_id = \"${taskId<202111151>}\"   AND FIND_IN_SET(\'3\', e.status) > 0) AS \'输入敏感信息人数\',\n(SELECT IFNULL( COUNT( DISTINCT(e.email) ) / (SELECT IFNULL( SUM(num_of_send), 0)  FROM task_info WHERE task_id = \"${taskId<202111151>}\"   ) * 100 , 0 )\nFROM target_emplorees e INNER JOIN task_info t ON e.task_id = t.task_id AND e.depend1 = t.bu_name\nWHERE t.task_id = \"${taskId<202111151>}\"   AND FIND_IN_SET(\'3\', e.status) > 0) AS \'敏感信息输入率\',\n\n(SELECT COUNT( DISTINCT(e.email) ) \nFROM target_emplorees e INNER JOIN task_info t ON e.task_id = t.task_id AND e.depend1 = t.bu_name\nWHERE t.task_id = \"${taskId<202111151>}\"   AND FIND_IN_SET(\'4\', e.status) > 0) AS \'点击短信链接人数\',\n(SELECT IFNULL( COUNT( DISTINCT(e.email) ) / (SELECT IFNULL( SUM(num_of_send), 0)  FROM task_info WHERE task_id = \"${taskId<202111151>}\"   ) * 100 , 0 )\nFROM target_emplorees e INNER JOIN task_info t ON e.task_id = t.task_id AND e.depend1 = t.bu_name\nWHERE t.task_id = \"${taskId<202111151>}\"   AND FIND_IN_SET(\'4\', e.status) > 0) AS \'短信链接点击率\'\n)',NULL,'{\"timeType\":\"0\",\"dateStart\":\"\",\"dateEnd\":\"\",\"recentlyTime\":\"\"}','{\"tableHeader\":[{\"name\":\"排名\",\"field\":\"排名\"},{\"name\":\"单位\",\"field\":\"单位\"},{\"name\":\"发送数\",\"field\":\"发送数\"},{\"name\":\"送达数\",\"field\":\"送达数\"},{\"name\":\"中招人数\",\"field\":\"中招人数\"},{\"name\":\"中招率\",\"field\":\"中招率\"},{\"name\":\"打开邮件附件人数\",\"field\":\"打开邮件附件人数\"},{\"name\":\"邮件附件打开率\",\"field\":\"邮件附件打开率\"},{\"name\":\"点击邮件链接人数\",\"field\":\"点击邮件链接人数\"},{\"name\":\"邮件链接点击率\",\"field\":\"邮件链接点击率\"},{\"name\":\"扫描二维码\",\"field\":\"扫描二维码\"},{\"name\":\"二维码扫描率\",\"field\":\"二维码扫描率\"},{\"name\":\"输入敏感信息人数\",\"field\":\"输入敏感信息人数\"},{\"name\":\"敏感信息输入率\",\"field\":\"敏感信息输入率\"},{\"name\":\"点击短信链接人数\",\"field\":\"点击短信链接人数\"},{\"name\":\"短信链接点击率\",\"field\":\"短信链接点击率\"}],\"dataFormat\":[{\"field\":\"中招率\",\"type\":\"decimal\",\"point\":2,\"unit\":\"%\"},{\"field\":\"邮件附件打开率\",\"type\":\"decimal\",\"point\":2,\"unit\":\"%\"},{\"field\":\"邮件链接点击率\",\"type\":\"decimal\",\"point\":2,\"unit\":\"%\"},{\"field\":\"二维码扫描率\",\"type\":\"decimal\",\"point\":2,\"unit\":\"%\"},{\"field\":\"敏感信息输入率\",\"type\":\"decimal\",\"point\":2,\"unit\":\"%\"},{\"field\":\"短信链接点击率\",\"type\":\"decimal\",\"point\":2,\"unit\":\"%\"}]}','blue','','4','4','4','4',NULL,'0','',NULL,NULL,'super','管理员','2024-05-24 16:20:22','super','2024-06-06 17:28:34','100','1','100',NULL,'','0',NULL,'0');

insert into `tb_visual_chart` (`id`, `code`, `name`, `type`, `data_type`, `source`, `json_data`, `data_property`, `json_param`, `json_property`, `theme`, `number`, `min_width`, `min_height`, `default_width`, `default_height`, `background`, `cache`, `es_index`, `json_tab`, `memo`, `create_by`, `create_by_label`, `create_time`, `update_by`, `update_time`, `group_id`, `status`, `group_path`, `relation_type`, `relation_content`, `relation_open`, `relation_params`, `relation_way`) values('202405271008011000005','S-000031','输入敏感信息人数','text-progress','sql','','SELECT COUNT( DISTINCT(e.email) ) AS 输入敏感信息人数 , IFNULL( COUNT( DISTINCT(e.email) ) / (SELECT \n        SUM(num_of_send) \n      FROM\n        task_info \n      WHERE task_id = \"${taskId<202111151>}\" AND (bu_name = \"${buName<润联科技>}\" OR bu_parent = \"${buName<润联科技>}\" )) * 100, 0) AS 点击率 \nFROM target_emplorees e \nWHERE e.task_id = \"${taskId<202111151>}\" AND ( e.depend1 = \"${buName<润联科技>}\" OR e.depend2 = \"${buName<润联科技>}\") AND FIND_IN_SET(\'3\', e.status) > 0',NULL,'{\"timeType\":\"0\",\"dateStart\":\"\",\"dateEnd\":\"\",\"recentlyTime\":\"\"}','{\"dataHeader\":[{\"key\":\"输入敏感信息人数\",\"num\":1},{\"key\":\"点击率\",\"num\":2}]}','singleBlue','','1','1','1','1',NULL,'0','',NULL,NULL,'super','管理员','2024-05-27 10:08:01','super','2024-06-06 17:23:59','100','1','100',NULL,'','0',NULL,'0');
insert into `tb_visual_chart` (`id`, `code`, `name`, `type`, `data_type`, `source`, `json_data`, `data_property`, `json_param`, `json_property`, `theme`, `number`, `min_width`, `min_height`, `default_width`, `default_height`, `background`, `cache`, `es_index`, `json_tab`, `memo`, `create_by`, `create_by_label`, `create_time`, `update_by`, `update_time`, `group_id`, `status`, `group_path`, `relation_type`, `relation_content`, `relation_open`, `relation_params`, `relation_way`) values('202405271008011050006','S-000031','点击短信链接人数','text-progress','sql','','SELECT COUNT( DISTINCT(e.email) ) AS 点击短信链接人数 , IFNULL( COUNT( DISTINCT(e.email) ) / (SELECT \n        SUM(num_of_send) \n      FROM\n        task_info \n      WHERE task_id = \"${taskId<202111151>}\" AND (bu_name = \"${buName<润联科技>}\" OR bu_parent = \"${buName<润联科技>}\" )) * 100, 0) AS  点击率   \nFROM target_emplorees e \nWHERE e.task_id = \"${taskId<202111151>}\" AND ( e.depend1 = \"${buName<润联科技>}\" OR e.depend2 = \"${buName<润联科技>}\") AND FIND_IN_SET(\'4\', e.status) > 0',NULL,'{\"timeType\":\"0\",\"dateStart\":\"\",\"dateEnd\":\"\",\"recentlyTime\":\"\"}','{\"dataHeader\":[{\"key\":\"点击短信链接人数\",\"num\":1},{\"key\":\"点击率\",\"num\":2}]}','singleBlue','','1','1','1','1',NULL,'0','',NULL,NULL,'super','管理员','2024-05-27 10:08:01','super','2024-06-06 17:24:07','100','1','100',NULL,'','0',NULL,'0');
insert into `tb_visual_chart` (`id`, `code`, `name`, `type`, `data_type`, `source`, `json_data`, `data_property`, `json_param`, `json_property`, `theme`, `number`, `min_width`, `min_height`, `default_width`, `default_height`, `background`, `cache`, `es_index`, `json_tab`, `memo`, `create_by`, `create_by_label`, `create_time`, `update_by`, `update_time`, `group_id`, `status`, `group_path`, `relation_type`, `relation_content`, `relation_open`, `relation_params`, `relation_way`) values('202405271008011090007','S-000709','扫描二维码','text-progress','sql','','SELECT COUNT( DISTINCT(e.email) ) AS 扫描二维码人数 , IFNULL( COUNT( DISTINCT(e.email) ) / (SELECT \n        SUM(num_of_send) \n      FROM\n        task_info \n      WHERE task_id = \"${taskId<202111151>}\" AND (bu_name = \"${buName<润联科技>}\" OR bu_parent = \"${buName<润联科技>}\" )) * 100, 0) AS 扫描率 \nFROM target_emplorees e \nWHERE e.task_id = \"${taskId<202111151>}\" AND ( e.depend1 = \"${buName<润联科技>}\" OR e.depend2 = \"${buName<润联科技>}\") AND FIND_IN_SET(\'5\', e.status) > 0',NULL,'{\"timeType\":\"0\",\"dateStart\":\"\",\"dateEnd\":\"\",\"recentlyTime\":\"\"}','{\"dataHeader\":[{\"key\":\"扫描二维码人数\",\"num\":1},{\"key\":\"扫描率\",\"num\":2}]}','colorgroup16','','1','1','4','3',NULL,'0','',NULL,NULL,'super','管理员','2024-05-27 10:08:01','super','2024-06-06 17:24:14','100','1','100','','','1',NULL,'0');
insert into `tb_visual_chart` (`id`, `code`, `name`, `type`, `data_type`, `source`, `json_data`, `data_property`, `json_param`, `json_property`, `theme`, `number`, `min_width`, `min_height`, `default_width`, `default_height`, `background`, `cache`, `es_index`, `json_tab`, `memo`, `create_by`, `create_by_label`, `create_time`, `update_by`, `update_time`, `group_id`, `status`, `group_path`, `relation_type`, `relation_content`, `relation_open`, `relation_params`, `relation_way`) values('202405271008011130008','S-000030','打开附件人数','text-progress','sql','','SELECT COUNT( DISTINCT(e.email) ) AS 打开附件人数 , IFNULL( COUNT( DISTINCT(e.email) ) / (SELECT \n        SUM(num_of_send) \n      FROM\n        task_info \n      WHERE task_id = \"${taskId<202111151>}\" AND (bu_name = \"${buName<润联科技>}\" OR bu_parent = \"${buName<润联科技>}\" )) * 100, 0) AS  打开率  \nFROM target_emplorees e \nWHERE e.task_id = \"${taskId<202111151>}\" AND ( e.depend1 = \"${buName<润联科技>}\" OR e.depend2 = \"${buName<润联科技>}\") AND FIND_IN_SET(\'2\', e.status) > 0',NULL,'{\"timeType\":\"0\",\"dateStart\":\"\",\"dateEnd\":\"\",\"recentlyTime\":\"\"}','{\"dataHeader\":[{\"key\":\"打开附件人数\",\"num\":1},{\"key\":\"打开率\",\"num\":2}]}','singleYellow','','1','1','1','1',NULL,'0','',NULL,NULL,'super','管理员','2024-05-27 10:08:01','super','2024-06-06 17:24:22','100','1','100',NULL,'','0',NULL,'0');
insert into `tb_visual_chart` (`id`, `code`, `name`, `type`, `data_type`, `source`, `json_data`, `data_property`, `json_param`, `json_property`, `theme`, `number`, `min_width`, `min_height`, `default_width`, `default_height`, `background`, `cache`, `es_index`, `json_tab`, `memo`, `create_by`, `create_by_label`, `create_time`, `update_by`, `update_time`, `group_id`, `status`, `group_path`, `relation_type`, `relation_content`, `relation_open`, `relation_params`, `relation_way`) values('202405271008011400010','S-000033','中招高峰时间分布','area','sql','','( \nSELECT COUNT( DISTINCT(e.email) ) AS COUNT , \'点击邮件链接人数\' AS child, DATE_FORMAT(cap_time, \'%H:00\') AS NAME \nFROM target_emplorees e \nWHERE e.task_id = \"${taskId<202111151>}\" AND e.depend1 = \"${buName<润联科技>}\" AND FIND_IN_SET(\'1\', e.status) > 0 GROUP BY DATE_FORMAT(cap_time, \'%H:00\') \n)\nUNION\n(   SELECT COUNT( DISTINCT(e.email) ) AS COUNT , \'打开附件人数\' AS child, DATE_FORMAT(e.cap_time, \'%H:00\') AS NAME \nFROM target_emplorees e \nWHERE e.task_id = \"${taskId<202111151>}\" AND e.depend1 = \"${buName<润联科技>}\" AND FIND_IN_SET(\'2\', e.status) > 0 GROUP BY DATE_FORMAT(e.cap_time, \'%H:00\') )\nUNION\n(   SELECT COUNT( DISTINCT(e.email) ) AS COUNT , \'输入敏感信息人数\' AS child, DATE_FORMAT(e.cap_time, \'%H:00\') AS NAME \nFROM target_emplorees e \nWHERE e.task_id = \"${taskId<202111151>}\" AND e.depend1 = \"${buName<润联科技>}\" AND FIND_IN_SET(\'3\', e.status) > 0 GROUP BY DATE_FORMAT(e.cap_time, \'%H:00\') )\nUNION\n(   SELECT COUNT( DISTINCT(e.email) ) AS COUNT , \'扫描二维码人数\' AS child, DATE_FORMAT(e.cap_time, \'%H:00\') AS NAME \nFROM target_emplorees e \nWHERE e.task_id = \"${taskId<202111151>}\" AND e.depend1 = \"${buName<润联科技>}\" AND FIND_IN_SET(\'5\', e.status) > 0 GROUP BY DATE_FORMAT(e.cap_time, \'%H:00\') )\nUNION\n(   SELECT COUNT( DISTINCT(e.email) ) AS COUNT , \'点击短信链接人数\' AS child, DATE_FORMAT(e.cap_time, \'%H:00\') AS NAME \nFROM target_emplorees e \nWHERE e.task_id = \"${taskId<202111151>}\" AND e.depend1 = \"${buName<润联科技>}\" AND FIND_IN_SET(\'4\', e.status) > 0 GROUP BY DATE_FORMAT(e.cap_time, \'%H:00\') )\nORDER BY NAME ASC',NULL,'{\"timeType\":\"0\",\"dateStart\":\"\",\"dateEnd\":\"\",\"recentlyTime\":\"\"}','{\"legendData\":[\"点击邮件链接人数\",\"打开附件人数\",\"输入敏感信息人数\",\"扫描二维码人数\",\"点击短信链接人数\"]}','colorgroup15','','4','3','4','3',NULL,'0','',NULL,NULL,'super','管理员','2024-05-27 10:08:01','super','2024-06-06 17:25:39','100','1','100',NULL,'','0',NULL,'0');
insert into `tb_visual_chart` (`id`, `code`, `name`, `type`, `data_type`, `source`, `json_data`, `data_property`, `json_param`, `json_property`, `theme`, `number`, `min_width`, `min_height`, `default_width`, `default_height`, `background`, `cache`, `es_index`, `json_tab`, `memo`, `create_by`, `create_by_label`, `create_time`, `update_by`, `update_time`, `group_id`, `status`, `group_path`, `relation_type`, `relation_content`, `relation_open`, `relation_params`, `relation_way`) values('202405271008011430011','S-000036','中招详情(按中招时间倒叙排序)','table','sql','','SELECT depend1 AS \'单位\', depend2 AS \'部门\', NAME AS \'姓名\', email AS \'邮箱\',  IF(MAX(isFile),\'是\',\'否\') AS \'是否打开邮件附件\' ,\n      IF(MAX(isLink),\'是\',\'否\') AS \'是否点击邮件链接\'  , IF(MAX(isQRCode),\'是\',\'否\') AS \'是否扫描二维码\' , IF(MAX(isInput),\'是\',\'否\') AS \'是否输入敏感信息\' ,\n      IF(MAX(isNote),\'是\',\'否\') AS \'是否点击短信链接\'  ,  min(cap_time) AS \'中招时间\'\n   FROM ( \n	SELECT depend1, depend2 , NAME, email ,IF(FIND_IN_SET(\'2\', status) > 0, 1, 0) AS isFile, IF(FIND_IN_SET(\'1\', status) > 0,1,IF(FIND_IN_SET(\'3\', status) > 0, 1, 0)) AS isLink ,IF(FIND_IN_SET(\'5\', status) > 0, 1, 0) AS isQRCode,IF(FIND_IN_SET(\'3\', status) > 0, 1, 0) AS isInput, IF(FIND_IN_SET(\'4\', status) > 0,1,0) AS isNote , cap_time\n	FROM target_emplorees WHERE task_id = \"${taskId<202111151>}\" AND depend1=\"${buName<润联科技>}\" ORDER BY cap_time DESC LIMIT 0,10000000 \n   ) a GROUP BY email ORDER BY MIN(cap_time) DESC',NULL,'{\"timeType\":\"0\",\"dateStart\":\"\",\"dateEnd\":\"\",\"recentlyTime\":\"\"}','{\"tableHeader\":[{\"name\":\"单位\",\"field\":\"单位\"},{\"name\":\"部门\",\"field\":\"部门\"},{\"name\":\"姓名\",\"field\":\"姓名\"},{\"name\":\"邮箱\",\"field\":\"邮箱\"},{\"name\":\"是否打开邮件附件\",\"field\":\"是否打开邮件附件\"},{\"name\":\"是否点击邮件链接\",\"field\":\"是否点击邮件链接\"},{\"name\":\"是否扫描二维码\",\"field\":\"是否扫描二维码\"},{\"name\":\"是否输入敏感信息\",\"field\":\"是否输入敏感信息\"},{\"name\":\"是否点击短信链接\",\"field\":\"是否点击短信链接\"},{\"name\":\"中招时间\",\"field\":\"中招时间\"}]}','blue','','4','3','6','5',NULL,'0','',NULL,NULL,'super','管理员','2024-05-27 10:08:01','super','2024-06-06 17:26:28','100','1','100',NULL,'','0',NULL,'0');
insert into `tb_visual_chart` (`id`, `code`, `name`, `type`, `data_type`, `source`, `json_data`, `data_property`, `json_param`, `json_property`, `theme`, `number`, `min_width`, `min_height`, `default_width`, `default_height`, `background`, `cache`, `es_index`, `json_tab`, `memo`, `create_by`, `create_by_label`, `create_time`, `update_by`, `update_time`, `group_id`, `status`, `group_path`, `relation_type`, `relation_content`, `relation_open`, `relation_params`, `relation_way`) values('202405271008011470012','S-000034','中招率趋势','line','sql','','select * from (\nSELECT cap_rate AS COUNT, cap_name AS NAME FROM task_cap WHERE bu_name = \"${buName<润联科技>}\"\n ORDER BY cap_start DESC LIMIT 0,5) t  ORDER BY NAME asc',NULL,'{\"timeType\":\"0\",\"dateStart\":\"\",\"dateEnd\":\"\",\"recentlyTime\":\"\"}','{\"legendData\":\"中招率\",\"yAxisUnit\":\"%\",\"xaxisLabelRotate\":30}','singleBlue','','','','','',NULL,'0','',NULL,NULL,'super','管理员','2024-05-27 10:08:01','super','2024-06-06 17:26:45','100','1','100',NULL,'','0',NULL,'0');
insert into `tb_visual_chart` (`id`, `code`, `name`, `type`, `data_type`, `source`, `json_data`, `data_property`, `json_param`, `json_property`, `theme`, `number`, `min_width`, `min_height`, `default_width`, `default_height`, `background`, `cache`, `es_index`, `json_tab`, `memo`, `create_by`, `create_by_label`, `create_time`, `update_by`, `update_time`, `group_id`, `status`, `group_path`, `relation_type`, `relation_content`, `relation_open`, `relation_params`, `relation_way`) values('20240527100801790002','S-000028','发送数和送达数','text-progress','sql','','SELECT sum(total) AS 发送数 , IFNULL( sum(num_of_send), 0) AS 送达数 , IFNULL( sum(num_of_send)/sum(total)*100 , 0 ) AS 送达率  \nFROM task_info WHERE task_id = \"${taskId<202111151>}\" AND (bu_name = \"${buName<润联科技>}\" OR bu_parent =  \"${buName<润联科技>}\")',NULL,'{\"timeType\":\"0\",\"dateStart\":\"\",\"dateEnd\":\"\",\"recentlyTime\":\"\"}','{\"dataHeader\":[{\"key\":\"发送数\",\"num\":1},{\"key\":\"送达数\",\"num\":2},{\"key\":\"送达率\",\"num\":3}]}','singleGreen','','1','1','1','1',NULL,'0','',NULL,NULL,'super','管理员','2024-05-27 10:08:01','super','2024-06-06 17:23:32','100','1','100',NULL,'','0',NULL,'0');
insert into `tb_visual_chart` (`id`, `code`, `name`, `type`, `data_type`, `source`, `json_data`, `data_property`, `json_param`, `json_property`, `theme`, `number`, `min_width`, `min_height`, `default_width`, `default_height`, `background`, `cache`, `es_index`, `json_tab`, `memo`, `create_by`, `create_by_label`, `create_time`, `update_by`, `update_time`, `group_id`, `status`, `group_path`, `relation_type`, `relation_content`, `relation_open`, `relation_params`, `relation_way`) values('20240527100801900003','S-000029','中招人数','text-progress','sql','','SELECT COUNT( DISTINCT(e.email) ) AS \'中招数\', IFNULL( COUNT( DISTINCT(e.email) ) / (SELECT \n        SUM(num_of_send) \n      FROM\n        task_info \n      WHERE task_id = \"${taskId<202111151>}\" AND (bu_name = \"${buName<润联科技>}\" OR bu_parent = \"${buName<润联科技>}\" )) * 100 , 0)  AS \'中招率\' \nFROM target_emplorees e \nWHERE e.task_id = \"${taskId<202111151>}\" AND ( e.depend1 = \"${buName<润联科技>}\" OR e.depend2 = \"${buName<润联科技>}\")',NULL,'{\"timeType\":\"0\",\"dateStart\":\"\",\"dateEnd\":\"\",\"recentlyTime\":\"\"}','{\"dataHeader\":[{\"key\":\"中招数\",\"num\":1},{\"key\":\"中招率\",\"num\":2}]}','singleRed','','1','1','1','1',NULL,'0','',NULL,NULL,'super','管理员','2024-05-27 10:08:01','super','2024-06-06 17:23:42','100','1','100',NULL,'','0',NULL,'0');
insert into `tb_visual_chart` (`id`, `code`, `name`, `type`, `data_type`, `source`, `json_data`, `data_property`, `json_param`, `json_property`, `theme`, `number`, `min_width`, `min_height`, `default_width`, `default_height`, `background`, `cache`, `es_index`, `json_tab`, `memo`, `create_by`, `create_by_label`, `create_time`, `update_by`, `update_time`, `group_id`, `status`, `group_path`, `relation_type`, `relation_content`, `relation_open`, `relation_params`, `relation_way`) values('20240527100801950004','S-000031','点击链接人数','text-progress','sql','','SELECT COUNT( DISTINCT(e.email) ) AS 点击邮件链接人数 , IFNULL( COUNT( DISTINCT(e.email) ) / (SELECT \n        SUM(num_of_send) \n      FROM\n        task_info \n      WHERE task_id = \"${taskId<202111151>}\" AND (bu_name = \"${buName<润联科技>}\" OR bu_parent = \"${buName<润联科技>}\" )) * 100, 0) AS 点击率 \nFROM target_emplorees e \nWHERE e.task_id = \"${taskId<202111151>}\" AND ( e.depend1 = \"${buName<润联科技>}\" OR e.depend2 = \"${buName<润联科技>}\") AND (FIND_IN_SET(\'1\', e.status) > 0 OR FIND_IN_SET(\'3\', e.status))',NULL,'{\"timeType\":\"0\",\"dateStart\":\"\",\"dateEnd\":\"\",\"recentlyTime\":\"\"}','{\"dataHeader\":[{\"key\":\"点击邮件链接人数\",\"num\":1},{\"key\":\"点击率\",\"num\":2}]}','singleBlue','','1','1','1','1',NULL,'0','',NULL,NULL,'super','管理员','2024-05-27 10:08:01','super','2024-06-06 17:23:51','100','1','100',NULL,'','0',NULL,'0');


insert into `tb_visual_panel` (`id`, `code`, `name`, `json_data`, `background`, `refresh`, `memo`, `create_by`, `create_by_label`, `create_time`, `update_by`, `update_time`, `platform_type`, `status`, `scope`, `share_scope`, `tag`, `role_id`, `role_name`, `user_id`, `user_name`, `style_type`, `image_path`, `snapshot`) values('202405241733053430002','P-000185','钓鱼报告-全集团','[{\"x\":0,\"y\":0,\"w\":4,\"h\":3,\"i\":\"Eihb5xf8202306151703067180000\",\"code\":\"202306151703067180000\",\"minW\":1,\"minH\":1,\"name\":\"发送数和送达数\",\"moved\":false},{\"x\":4,\"y\":0,\"w\":4,\"h\":3,\"i\":\"wBGtTKQP202306151708099430001\",\"code\":\"202306151708099430001\",\"minW\":1,\"minH\":1,\"name\":\"中招人数\",\"moved\":false},{\"x\":8,\"y\":0,\"w\":4,\"h\":3,\"i\":\"w4Ab6AXN202306151718365360003\",\"code\":\"202306151718365360003\",\"minW\":1,\"minH\":1,\"name\":\"点击链接人数\",\"moved\":false},{\"x\":3,\"y\":3,\"w\":3,\"h\":3,\"i\":\"rCWbxBKe202306151734111520004\",\"code\":\"202306151734111520004\",\"minW\":1,\"minH\":1,\"name\":\"输入敏感信息人数\",\"moved\":false},{\"x\":9,\"y\":3,\"w\":3,\"h\":3,\"i\":\"FYfTce2Z202306151734509600005\",\"code\":\"202306151734509600005\",\"minW\":1,\"minH\":1,\"name\":\"点击短信链接人数\",\"moved\":false},{\"x\":0,\"y\":3,\"w\":3,\"h\":3,\"i\":\"Jdkz8QJn202405231434047380011\",\"code\":\"202405231434047380011\",\"minW\":1,\"minH\":1,\"name\":\"扫描二维码\",\"moved\":false},{\"x\":6,\"y\":3,\"w\":3,\"h\":3,\"i\":\"Ex8YfNaE202306151711104890002\",\"code\":\"202306151711104890002\",\"minW\":1,\"minH\":1,\"name\":\"打开附件人数\",\"moved\":false},{\"x\":0,\"y\":6,\"w\":12,\"h\":9,\"i\":\"QFeAbs8m202306151806126770010\",\"code\":\"202306151806126770010\",\"minW\":4,\"minH\":3,\"name\":\"各单位中招情况(按中招率由高到低排序)\",\"moved\":false},{\"x\":0,\"y\":15,\"w\":6,\"h\":8,\"i\":\"hFjDxhXe202306151742045170006\",\"code\":\"202306151742045170006\",\"minW\":4,\"minH\":3,\"name\":\"中招高峰时间分布\",\"moved\":false},{\"x\":0,\"y\":33,\"w\":12,\"h\":7,\"i\":\"W8F3YTJS202306151748282070008\",\"code\":\"202306151748282070008\",\"minW\":4,\"minH\":3,\"name\":\"中招详情(按中招时间倒叙排序)\",\"moved\":false},{\"x\":6,\"y\":15,\"w\":6,\"h\":8,\"i\":\"h8xb6QHc202306151746283910007\",\"code\":\"202306151746283910007\",\"minW\":2,\"minH\":2,\"name\":\"中招率趋势\",\"moved\":false},{\"x\":0,\"y\":23,\"w\":12,\"h\":10,\"i\":\"JZRmCPpS202405241620217270001\",\"code\":\"202405241620217270001\",\"minW\":4,\"minH\":4,\"name\":\"各单位中招数据(按中招率由高到低排序)\",\"moved\":false}]',NULL,'0','','super','管理员','2024-05-24 17:33:05','super','2024-05-27 10:07:40','','1','0',NULL,'',NULL,NULL,NULL,NULL,'0',NULL,NULL);

insert into `tb_visual_panel` (`id`, `code`, `name`, `json_data`, `background`, `refresh`, `memo`, `create_by`, `create_by_label`, `create_time`, `update_by`, `update_time`, `platform_type`, `status`, `scope`, `share_scope`, `tag`, `role_id`, `role_name`, `user_id`, `user_name`, `style_type`, `image_path`, `snapshot`) values('202405271008011550014','P-000185','钓鱼报告-各单位','[{\"code\":\"20240527100801790002\",\"minH\":1,\"minW\":1,\"w\":4,\"moved\":false,\"x\":0,\"h\":3,\"name\":\"发送数和送达数\",\"y\":0,\"i\":\"Eihb5xf8202306151703067180000\"},{\"code\":\"20240527100801900003\",\"minH\":1,\"minW\":1,\"w\":4,\"moved\":false,\"x\":4,\"h\":3,\"name\":\"中招人数\",\"y\":0,\"i\":\"wBGtTKQP202306151708099430001\"},{\"code\":\"20240527100801950004\",\"minH\":1,\"minW\":1,\"w\":4,\"moved\":false,\"x\":8,\"h\":3,\"name\":\"点击链接人数\",\"y\":0,\"i\":\"w4Ab6AXN202306151718365360003\"},{\"code\":\"202405271008011000005\",\"minH\":1,\"minW\":1,\"w\":3,\"moved\":false,\"x\":3,\"h\":3,\"name\":\"输入敏感信息人数\",\"y\":3,\"i\":\"rCWbxBKe202306151734111520004\"},{\"code\":\"202405271008011050006\",\"minH\":1,\"minW\":1,\"w\":3,\"moved\":false,\"x\":9,\"h\":3,\"name\":\"点击短信链接人数\",\"y\":3,\"i\":\"FYfTce2Z202306151734509600005\"},{\"code\":\"202405271008011090007\",\"minH\":1,\"minW\":1,\"w\":3,\"moved\":false,\"x\":0,\"h\":3,\"name\":\"扫描二维码\",\"y\":3,\"i\":\"Jdkz8QJn202405231434047380011\"},{\"code\":\"202405271008011130008\",\"minH\":1,\"minW\":1,\"w\":3,\"moved\":false,\"x\":6,\"h\":3,\"name\":\"打开附件人数\",\"y\":3,\"i\":\"Ex8YfNaE202306151711104890002\"},{\"code\":\"202405271008011400010\",\"minH\":3,\"minW\":4,\"w\":6,\"moved\":false,\"x\":0,\"h\":11,\"name\":\"中招高峰时间分布\",\"y\":6,\"i\":\"hFjDxhXe202306151742045170006\"},{\"code\":\"202405271008011430011\",\"minH\":3,\"minW\":4,\"w\":12,\"moved\":false,\"x\":0,\"h\":14,\"name\":\"中招详情(按中招时间倒叙排序)\",\"y\":17,\"i\":\"W8F3YTJS202306151748282070008\"},{\"code\":\"202405271008011470012\",\"minH\":2,\"minW\":2,\"w\":6,\"moved\":false,\"x\":6,\"h\":11,\"name\":\"中招率趋势\",\"y\":6,\"i\":\"h8xb6QHc202306151746283910007\"}]',NULL,'0','','super','管理员','2024-05-27 10:08:01','super','2024-05-27 10:39:57','','1','0',NULL,'',NULL,NULL,NULL,NULL,'0',NULL,NULL);


-- 资产表设置唯一联合主建
DELETE tb_asset FROM tb_asset, (SELECT MAX(id) id ,internal_ip FROM tb_asset  WHERE del_flag = '1' GROUP BY internal_ip HAVING COUNT(*) > 1) t2
WHERE tb_asset.internal_ip =  t2.internal_ip AND tb_asset.id < t2.id;

ALTER TABLE tb_asset ADD UNIQUE KEY(internal_ip, del_flag);

-- 软件台账脚本

ALTER TABLE `tb_asset_software_license`
  ADD COLUMN `manufacturer` VARCHAR(100) NULL  COMMENT '厂商' AFTER `del_flag`,
  ADD COLUMN `soft_acquisition_method` VARCHAR(1000) NULL  COMMENT '软件获取方式' AFTER `manufacturer`,
  ADD COLUMN `dept_id` BIGINT(20) NULL  COMMENT '所属组织id' AFTER `soft_acquisition_method`,
  ADD COLUMN `dept_name` VARCHAR(1024) NULL  COMMENT '所属组织名称' AFTER `dept_id`,
  ADD COLUMN `dept_path` VARCHAR(1000) NULL  COMMENT '所属组织全路径' AFTER `dept_name`,
  ADD COLUMN `project` VARCHAR(100) NULL  COMMENT '所属项目' AFTER `dept_path`,
  ADD COLUMN `asset_manage_id` BIGINT(20) NULL  COMMENT '资产管理员的用户id' AFTER `project`,
  ADD  INDEX `idx_user_id` (`asset_manage_id`),
  ADD  INDEX `idx_dept_id` (`dept_id`);


ALTER TABLE `tb_asset_software_license`
  ADD COLUMN `create_user_label` VARCHAR(128) NULL  COMMENT '创建人label' AFTER `create_user`,
  ADD COLUMN `update_user_label` VARCHAR(128) NULL  COMMENT '修改人label' AFTER `update_user`;

DROP TABLE if exists tb_software_serial_number;

CREATE TABLE `tb_software_serial_number`(
  `id` BIGINT(20) NOT NULL AUTO_INCREMENT COMMENT '主键id',
  `licensee` VARCHAR(128) COMMENT 'licensee',
  `key` VARCHAR(512) COMMENT 'key',
  `permission_total` INT(100) COMMENT '许可数量',
  `permission_date` VARCHAR(16) COMMENT '许可截至日期',
  `license_id` BIGINT(20) COMMENT '关联软件台账主键id',
  PRIMARY KEY (`id`),
  INDEX `idx_key` (`key`),
  INDEX `idx_licensee` (`licensee`),
  INDEX `idx_license_id` (`license_id`)
);


DELETE FROM sys_dict_data WHERE dict_type = 'software_license_type';

insert into `sys_dict_data` ( `dict_sort`, `dict_label`, `dict_value`, `dict_type`, `css_class`, `list_class`, `is_default`, `status`, `create_by`, `create_time`, `update_by`, `update_time`, `remark`) values('1','一对一','1to1','software_license_type',NULL,NULL,'N','0','super','2021-09-16 14:50:24','',NULL,NULL);
insert into `sys_dict_data` ( `dict_sort`, `dict_label`, `dict_value`, `dict_type`, `css_class`, `list_class`, `is_default`, `status`, `create_by`, `create_time`, `update_by`, `update_time`, `remark`) values('0','一对多','1toN','software_license_type',NULL,NULL,'N','0','super','2021-09-16 14:51:16','super','2021-09-22 16:29:58',NULL);
insert into `sys_dict_data` ( `dict_sort`, `dict_label`, `dict_value`, `dict_type`, `css_class`, `list_class`, `is_default`, `status`, `create_by`, `create_time`, `update_by`, `update_time`, `remark`) values('3','对区域授权','3','software_license_type',NULL,NULL,'N','0','super','2024-05-14 17:04:34','',NULL,NULL);


-- 软件申请授权表
CREATE TABLE `tb_asset_software_apply` (
                                           `id` varchar(64) NOT NULL COMMENT '主键',
                                           `create_by` varchar(64) DEFAULT NULL COMMENT '创建者',
                                           `create_time` datetime DEFAULT NULL COMMENT '创建时间',
                                           `update_by` varchar(64) DEFAULT NULL COMMENT '修改者',
                                           `update_time` datetime DEFAULT NULL COMMENT '修改时间',
                                           `del_flag` char(1) DEFAULT '0' COMMENT '删除标志（0代表存在 1代表删除）',
                                           `create_by_label` varchar(128) DEFAULT '' COMMENT '提单人label',
                                           `code` varchar(64) DEFAULT NULL COMMENT '申请ID',
                                           `software_name` varchar(255) DEFAULT NULL COMMENT '软件名称',
                                           `software_version` varchar(50) DEFAULT NULL COMMENT '软件版本',
                                           `software_achieve` text COMMENT '软件获取',
                                           `computer_name` varchar(255) DEFAULT NULL COMMENT '计算机名称',
                                           `device_unique_identification_code` varchar(128) DEFAULT NULL COMMENT '设备唯一识别码',
                                           `order_status` char(1) DEFAULT '2' COMMENT '工单状态（0待提交 1待审核 2：已完成）',
                                           `apply_user_name` varchar(64) DEFAULT '' COMMENT '申请人',
                                           `apply_user_email` varchar(128) DEFAULT '' COMMENT '申请人邮箱',
                                           `apply_user_label` varchar(64) DEFAULT '' COMMENT '申请人label',
                                           `apply_user_full_dept_name` varchar(255) DEFAULT '' COMMENT '申请人部门名称',
                                           `affiliation_dept_node_id` bigint(20) DEFAULT NULL COMMENT '所属组织ID',
                                           `affiliation_dept_name` varchar(255) DEFAULT NULL COMMENT '所属组织名称',
                                           `mac_address` varchar(50) DEFAULT NULL COMMENT 'mac地址',
                                           `reason` varchar(1000) DEFAULT NULL COMMENT '申请原因',
                                           `start_date` date DEFAULT NULL COMMENT '访问开始日期',
                                           `end_date` date DEFAULT NULL COMMENT '访问结束日期',
                                           `is_import` int(1) DEFAULT '0' COMMENT '是否导入 0 否(默认) 1 是',
                                           `attach_file` varchar(255) DEFAULT NULL COMMENT '附件',
                                           `file_name` varchar(255) DEFAULT NULL COMMENT '附件名称',
                                           `submit_user_full_dept_name` varchar(255) DEFAULT '' COMMENT '提单人部门名称',
                                           `licensee` varchar(512) DEFAULT NULL COMMENT 'licensee',
                                           `apply_key` varchar(512) DEFAULT NULL COMMENT 'Key',
                                           `is_sync_ues` int(11) NOT NULL DEFAULT '0' COMMENT '是否下发策略成功标识 0 未下发  1 已下发',
                                           PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='软件申请授权';


-- 软件申请授权记录表
CREATE TABLE `tb_asset_software_apply_record` (
                                                  `id` varchar(64) NOT NULL COMMENT '主键',
                                                  `apply_id` varchar(64) DEFAULT NULL COMMENT '软件申请id',
                                                  `create_by` varchar(64) DEFAULT NULL COMMENT '创建者',
                                                  `create_by_label` varchar(128) DEFAULT '' COMMENT '提单人label',
                                                  `create_time` datetime DEFAULT NULL COMMENT '创建时间',
                                                  `update_by` varchar(64) DEFAULT NULL COMMENT '修改者',
                                                  `update_time` datetime DEFAULT NULL COMMENT '修改时间',
                                                  `opinion` varchar(1000) DEFAULT NULL COMMENT '审批意见',
                                                  `operation` varchar(255) DEFAULT NULL COMMENT '操作',
                                                  `result` text COMMENT '审批结果 pass通过 fail不通过',
                                                  `del_flag` char(1) DEFAULT '0' COMMENT '删除标识，0未删除，1已删除',
                                                  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='软件申请授权记录表';


-- 新增终端设备-硬件变更记录
CREATE TABLE `tb_asset_terminal_equipment_record` (
                                                      `id` varchar(255) NOT NULL,
                                                      `change_item` varchar(255) DEFAULT NULL COMMENT '变更项',
                                                      `before_change` varchar(255) DEFAULT NULL COMMENT '变更前',
                                                      `after_change` varchar(255) DEFAULT NULL COMMENT '变更后',
                                                      `update_time` datetime DEFAULT NULL COMMENT '变更时间',
                                                      `bussiness_id` varchar(255) DEFAULT NULL COMMENT '终端设备ID',
                                                      PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='终端设备-硬件变更记录';

-- 终端资产-资源申请记录
DROP TABLE IF EXISTS `tb_asset_terminal_resource_apply`;
CREATE TABLE `tb_asset_terminal_resource_apply` (
  `id` varchar(64) NOT NULL COMMENT '主键',
  `resource_id` varchar(64) DEFAULT NULL COMMENT '资源ID，类似于SA-2022060100001',
  `resource_envir` varchar(64) DEFAULT NULL COMMENT '资源访问环境,内网，外网，内网+外网',
  `vaild_time` datetime DEFAULT NULL COMMENT '有效开始时间',
  `reason` text COMMENT '申请原因',
  `status` char(1) DEFAULT NULL COMMENT '工单状态;1，待提交，2提交，3，待审批，4，待复合，5驳回，6，撤回，7,完成',
  `create_by` varchar(64) DEFAULT NULL COMMENT '创建人',
  `create_by_label` varchar(255) DEFAULT NULL COMMENT '创建人（全称）',
  `submit_user_full_dept_name` varchar(255) DEFAULT '' COMMENT '提单人部门名称',
  `create_time` datetime DEFAULT NULL COMMENT '创建时间',
  `update_by` varchar(64) DEFAULT NULL COMMENT '修改人',
  `update_time` datetime DEFAULT NULL COMMENT '修改时间',
  `remark` text COMMENT '备注',
  `del_flag` char(1) DEFAULT '0' COMMENT '删除标识，0未删除，1已删除',
  `current_handler` varchar(64) DEFAULT NULL COMMENT '当前处理人',
  `current_handler_label` varchar(255) DEFAULT NULL COMMENT '当前处理人（全称）',
  `resource_url` text COMMENT '资源访问地址',
  `vaild_end_time` datetime DEFAULT NULL COMMENT '有效截至时间',
  `approve_result` varchar(64) DEFAULT NULL COMMENT '审批结果,pass 通过，reject 不通过',
  `approve_person` varchar(255) DEFAULT NULL COMMENT '审批人',
  `compound_person` varchar(255) DEFAULT NULL COMMENT '复核人',
  `model_type` char(1) DEFAULT NULL COMMENT '模式，1 普通；2 高级',
  `history_deal_user` text COMMENT '历史处理人',
  `process_state` varchar(10) DEFAULT NULL COMMENT '进度条状态',
  `apply_user_name` varchar(64) DEFAULT '' COMMENT '申请人',
  `apply_user_full_dept_name` varchar(255) DEFAULT '' COMMENT '申请人部门名称',
  `affiliation_dept_node_id` bigint(20) DEFAULT NULL COMMENT '所属组织ID',
  `affiliation_dept_name` varchar(255) DEFAULT NULL COMMENT '所属组织名称',
  `apply_user_label` varchar(64) DEFAULT '' COMMENT '申请人label',
  `attach_file` varchar(255) DEFAULT NULL COMMENT '附件地址',
  `file_name` varchar(255) DEFAULT NULL COMMENT '附件名称',
  `is_sync_ues` int(11) NOT NULL DEFAULT '0' COMMENT '是否下发策略成功标识 0 未下发  1 已下发',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='资源申请记录表';

DROP TABLE IF EXISTS `tb_asset_terminal_resource_apply_detail`;
CREATE TABLE `tb_asset_terminal_resource_apply_detail` (
  `id` varchar(64) NOT NULL COMMENT '主键',
  `resource_apply_id` varchar(64) DEFAULT NULL COMMENT '资源申请ID',
  `resource_type` varchar(64) DEFAULT NULL COMMENT '资源类型，1，域名类，2，IP类',
  `resource_content` varchar(1000) DEFAULT NULL COMMENT '资源内容',
  `port` varchar(8) DEFAULT NULL COMMENT '端口',
  `protocol` varchar(32) DEFAULT NULL COMMENT '协议',
  `remark` text COMMENT '备注',
  `del_flag` char(1) DEFAULT '0' COMMENT '删除标识，0未删除，1已删除',
  `create_by` varchar(64) DEFAULT NULL COMMENT '创建人',
  `create_by_label` varchar(255) DEFAULT NULL COMMENT '创建人（全称）',
  `create_time` datetime DEFAULT NULL COMMENT '创建时间',
  `update_by` varchar(64) DEFAULT NULL COMMENT '修改人',
  `update_time` datetime DEFAULT NULL COMMENT '修改时间',
  `url` varchar(255) DEFAULT NULL COMMENT 'URL',
  PRIMARY KEY (`id`),
  KEY `content_index` (`resource_content`),
  KEY `port_index` (`port`),
  KEY `resource_apply_id_index` (`resource_apply_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='资源申请记录详情表';

DROP TABLE IF EXISTS `tb_asset_terminal_resource_apply_log`;
CREATE TABLE `tb_asset_terminal_resource_apply_log` (
  `id` varchar(64) DEFAULT NULL COMMENT '主键',
  `resource_apply_id` varchar(64) DEFAULT NULL COMMENT '资源申请ID',
  `operation_type` varchar(64) DEFAULT NULL COMMENT '操作类型，例如：创建申请，提交申请，上级审批，管理员复合',
  `result` varchar(64) DEFAULT NULL COMMENT '审批结果,pass,通过;reject,不通过',
  `opinion` varchar(1000) DEFAULT NULL COMMENT '审批意见',
  `remark` text COMMENT '备注',
  `create_by` varchar(64) DEFAULT NULL COMMENT '创建人',
  `create_by_label` varchar(255) DEFAULT NULL COMMENT '创建人（全称）',
  `create_time` datetime DEFAULT NULL COMMENT '创建时间',
  `update_by` varchar(64) DEFAULT NULL COMMENT '修改人',
  `update_time` datetime DEFAULT NULL COMMENT '修改时间',
  `del_flag` char(1) DEFAULT '0' COMMENT '删除标识，0未删除，1已删除',
  `state` varchar(10) DEFAULT NULL COMMENT '状态'
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='资源申请记录日志表';

-- 插入字典数据（授权申请记录）
delete from sys_dict_type where dict_type = 'terminal_software_apply_order_status';
delete from sys_dict_data where dict_type = 'terminal_software_apply_order_status';
insert into `sys_dict_type` (`dict_name`, `dict_type`, `status`, `create_by`, `create_time`, `update_by`, `update_time`, `remark`) values('授权申请记录工单状态','terminal_software_apply_order_status','0','super','2024-05-09 15:38:32','',NULL,NULL);
INSERT INTO `sys_dict_data` (`dict_sort`, `dict_label`, `dict_value`, `dict_type`, `css_class`, `list_class`, `is_default`, `status`, `create_by`, `create_time`, `update_by`, `update_time`, `remark`) VALUES ( 1, '已完成', '2', 'terminal_software_apply_order_status', NULL, NULL, 'N', '0', 'super', '2024-05-09 15:38:32', 'super', '2024-05-09 15:38:32', NULL);
INSERT INTO `sys_dict_data` (`dict_sort`, `dict_label`, `dict_value`, `dict_type`, `css_class`, `list_class`, `is_default`, `status`, `create_by`, `create_time`, `update_by`, `update_time`, `remark`) VALUES ( 2, '已回收', '0', 'terminal_software_apply_order_status', NULL, NULL, 'N', '0', 'super', '2024-05-09 15:38:32', 'super', '2024-05-09 15:38:32', NULL);
INSERT INTO `sys_dict_data` (`dict_sort`, `dict_label`, `dict_value`, `dict_type`, `css_class`, `list_class`, `is_default`, `status`, `create_by`, `create_time`, `update_by`, `update_time`, `remark`) VALUES ( 3, '回收中', '1', 'terminal_software_apply_order_status', NULL, NULL, 'N', '0', 'super', '2024-05-09 15:38:32', 'super', '2024-05-09 15:38:32', NULL);
INSERT INTO `sys_dict_data` (`dict_sort`, `dict_label`, `dict_value`, `dict_type`, `css_class`, `list_class`, `is_default`, `status`, `create_by`, `create_time`, `update_by`, `update_time`, `remark`) VALUES ( 4, '回收异常', '3', 'terminal_software_apply_order_status', NULL, NULL, 'N', '0', 'super', '2024-05-09 15:38:32', 'super', '2024-05-09 15:38:32', NULL);

delete from sys_dict_type where dict_type = 'terminal_software_apply_export_excel';
delete from sys_dict_data where dict_type = 'terminal_software_apply_export_excel';
insert into `sys_dict_type` (`dict_name`, `dict_type`, `status`, `create_by`, `create_time`, `update_by`, `update_time`, `remark`) values('授权申请记录_导出字段','terminal_software_apply_export_excel','0','super','2024-05-09 15:38:32','',NULL,NULL);
INSERT INTO `sys_dict_data` (`dict_sort`, `dict_label`, `dict_value`, `dict_type`, `css_class`, `list_class`, `is_default`, `status`, `create_by`, `create_time`, `update_by`, `update_time`, `remark`) VALUES ( 1, '申请ID', 'code', 'terminal_software_apply_export_excel', NULL, NULL, 'N', '0', 'super', '2024-05-09 15:38:32', 'super', '2024-05-09 15:38:32', NULL);
INSERT INTO `sys_dict_data` (`dict_sort`, `dict_label`, `dict_value`, `dict_type`, `css_class`, `list_class`, `is_default`, `status`, `create_by`, `create_time`, `update_by`, `update_time`, `remark`) VALUES ( 2, '软件名称', 'softwareName', 'terminal_software_apply_export_excel', NULL, NULL, 'N', '0', 'super', '2024-05-09 15:38:32', 'super', '2024-05-09 15:38:32', NULL);
INSERT INTO `sys_dict_data` (`dict_sort`, `dict_label`, `dict_value`, `dict_type`, `css_class`, `list_class`, `is_default`, `status`, `create_by`, `create_time`, `update_by`, `update_time`, `remark`) VALUES ( 3, '软件版本', 'softwareVersion', 'terminal_software_apply_export_excel', NULL, NULL, 'N', '0', 'super', '2024-05-09 15:38:32', 'super', '2024-05-09 15:38:32', NULL);
INSERT INTO `sys_dict_data` (`dict_sort`, `dict_label`, `dict_value`, `dict_type`, `css_class`, `list_class`, `is_default`, `status`, `create_by`, `create_time`, `update_by`, `update_time`, `remark`) VALUES ( 4, '软件获取', 'softwareAchieve', 'terminal_software_apply_export_excel', NULL, NULL, 'N', '0', 'super', '2024-05-09 15:38:32', 'super', '2024-05-09 15:38:32', NULL);
INSERT INTO `sys_dict_data` (`dict_sort`, `dict_label`, `dict_value`, `dict_type`, `css_class`, `list_class`, `is_default`, `status`, `create_by`, `create_time`, `update_by`, `update_time`, `remark`) VALUES ( 5, '计算机名称', 'computerName', 'terminal_software_apply_export_excel', NULL, NULL, 'N', '0', 'super', '2024-05-09 15:38:32', 'super', '2024-05-09 15:38:32', NULL);
INSERT INTO `sys_dict_data` (`dict_sort`, `dict_label`, `dict_value`, `dict_type`, `css_class`, `list_class`, `is_default`, `status`, `create_by`, `create_time`, `update_by`, `update_time`, `remark`) VALUES ( 6, '设备唯一识别码', 'deviceUniqueIdentificationCode', 'terminal_software_apply_export_excel', NULL, NULL, 'N', '0', 'super', '2024-05-09 15:38:32', 'super', '2024-05-09 15:38:32', NULL);
INSERT INTO `sys_dict_data` (`dict_sort`, `dict_label`, `dict_value`, `dict_type`, `css_class`, `list_class`, `is_default`, `status`, `create_by`, `create_time`, `update_by`, `update_time`, `remark`) VALUES ( 7, '使用截止时间', 'endDate', 'terminal_software_apply_export_excel', NULL, NULL, 'N', '0', 'super', '2024-05-09 15:38:32', 'super', '2024-05-09 15:38:32', NULL);
INSERT INTO `sys_dict_data` (`dict_sort`, `dict_label`, `dict_value`, `dict_type`, `css_class`, `list_class`, `is_default`, `status`, `create_by`, `create_time`, `update_by`, `update_time`, `remark`) VALUES ( 8, '申请原因', 'reason', 'terminal_software_apply_export_excel', NULL, NULL, 'N', '0', 'super', '2024-05-09 15:38:32', 'super', '2024-05-09 15:38:32', NULL);
INSERT INTO `sys_dict_data` (`dict_sort`, `dict_label`, `dict_value`, `dict_type`, `css_class`, `list_class`, `is_default`, `status`, `create_by`, `create_time`, `update_by`, `update_time`, `remark`) VALUES ( 9, '工单状态', 'orderStatusLabel', 'terminal_software_apply_export_excel', NULL, NULL, 'N', '0', 'super', '2024-05-09 15:38:32', 'super', '2024-05-09 15:38:32', NULL);
INSERT INTO `sys_dict_data` (`dict_sort`, `dict_label`, `dict_value`, `dict_type`, `css_class`, `list_class`, `is_default`, `status`, `create_by`, `create_time`, `update_by`, `update_time`, `remark`) VALUES ( 10, '申请人', 'applyUserLabel', 'terminal_software_apply_export_excel', NULL, NULL, 'N', '0', 'super', '2024-05-09 15:38:32', 'super', '2024-05-09 15:38:32', NULL);
INSERT INTO `sys_dict_data` (`dict_sort`, `dict_label`, `dict_value`, `dict_type`, `css_class`, `list_class`, `is_default`, `status`, `create_by`, `create_time`, `update_by`, `update_time`, `remark`) VALUES ( 11, '申请人部门', 'applyUserFullDeptName', 'terminal_software_apply_export_excel', NULL, NULL, 'N', '0', 'super', '2024-05-09 15:38:32', 'super', '2024-05-09 15:38:32', NULL);
INSERT INTO `sys_dict_data` (`dict_sort`, `dict_label`, `dict_value`, `dict_type`, `css_class`, `list_class`, `is_default`, `status`, `create_by`, `create_time`, `update_by`, `update_time`, `remark`) VALUES ( 12, '所属组织', 'affiliationDeptName', 'terminal_software_apply_export_excel', NULL, NULL, 'N', '0', 'super', '2024-05-09 15:38:32', 'super', '2024-05-09 15:38:32', NULL);
INSERT INTO `sys_dict_data` (`dict_sort`, `dict_label`, `dict_value`, `dict_type`, `css_class`, `list_class`, `is_default`, `status`, `create_by`, `create_time`, `update_by`, `update_time`, `remark`) VALUES ( 13, '提单人', 'createByLabel', 'terminal_software_apply_export_excel', NULL, NULL, 'N', '0', 'super', '2024-05-09 15:38:32', 'super', '2024-05-09 15:38:32', NULL);
INSERT INTO `sys_dict_data` (`dict_sort`, `dict_label`, `dict_value`, `dict_type`, `css_class`, `list_class`, `is_default`, `status`, `create_by`, `create_time`, `update_by`, `update_time`, `remark`) VALUES ( 14, '提单时间', 'createTime', 'terminal_software_apply_export_excel', NULL, NULL, 'N', '0', 'super', '2024-05-09 15:38:32', 'super', '2024-05-09 15:38:32', NULL);

-- 插入字典数据（资源申请记录）
delete from sys_dict_type where dict_type = 'terminal_resource_apply_export_excel';
delete from sys_dict_data where dict_type = 'terminal_resource_apply_export_excel';
INSERT INTO `sys_dict_type` (`dict_name`, `dict_type`, `status`, `create_by`, `create_time`, `update_by`, `update_time`, `remark`) values('资源申请记录_导出字段','terminal_resource_apply_export_excel','0','super','2024-05-09 15:38:32','',NULL,NULL);
INSERT INTO `sys_dict_data` (`dict_sort`, `dict_label`, `dict_value`, `dict_type`, `css_class`, `list_class`, `is_default`, `status`, `create_by`, `create_time`, `update_by`, `update_time`, `remark`) VALUES ( 1, '申请ID', 'resourceId', 'terminal_resource_apply_export_excel', NULL, NULL, 'N', '0', 'super', '2024-05-09 15:38:32', 'super', '2024-05-09 15:38:32', NULL);
INSERT INTO `sys_dict_data` (`dict_sort`, `dict_label`, `dict_value`, `dict_type`, `css_class`, `list_class`, `is_default`, `status`, `create_by`, `create_time`, `update_by`, `update_time`, `remark`) VALUES ( 2, '资源访问地址', 'resourceUrl', 'terminal_resource_apply_export_excel', NULL, NULL, 'N', '0', 'super', '2024-05-09 15:38:32', 'super', '2024-05-09 15:38:32', NULL);
INSERT INTO `sys_dict_data` (`dict_sort`, `dict_label`, `dict_value`, `dict_type`, `css_class`, `list_class`, `is_default`, `status`, `create_by`, `create_time`, `update_by`, `update_time`, `remark`) VALUES ( 3, '资源访问环境', 'resourceEnvir', 'terminal_resource_apply_export_excel', NULL, NULL, 'N', '0', 'super', '2024-05-09 15:38:32', 'super', '2024-05-09 15:38:32', NULL);
INSERT INTO `sys_dict_data` (`dict_sort`, `dict_label`, `dict_value`, `dict_type`, `css_class`, `list_class`, `is_default`, `status`, `create_by`, `create_time`, `update_by`, `update_time`, `remark`) VALUES ( 4, '访问截止时间', 'vaildEndTime', 'terminal_resource_apply_export_excel', NULL, NULL, 'N', '0', 'super', '2024-05-09 15:38:32', 'super', '2024-05-09 15:38:32', NULL);
INSERT INTO `sys_dict_data` (`dict_sort`, `dict_label`, `dict_value`, `dict_type`, `css_class`, `list_class`, `is_default`, `status`, `create_by`, `create_time`, `update_by`, `update_time`, `remark`) VALUES ( 5, '申请原因', 'reason', 'terminal_software_apply_export_excel', NULL, NULL, 'N', '0', 'super', '2024-05-09 15:38:32', 'super', '2024-05-09 15:38:32', NULL);
INSERT INTO `sys_dict_data` (`dict_sort`, `dict_label`, `dict_value`, `dict_type`, `css_class`, `list_class`, `is_default`, `status`, `create_by`, `create_time`, `update_by`, `update_time`, `remark`) VALUES ( 6, '工单状态', 'status', 'terminal_resource_apply_export_excel', NULL, NULL, 'N', '0', 'super', '2024-05-09 15:38:32', 'super', '2024-05-09 15:38:32', NULL);
INSERT INTO `sys_dict_data` (`dict_sort`, `dict_label`, `dict_value`, `dict_type`, `css_class`, `list_class`, `is_default`, `status`, `create_by`, `create_time`, `update_by`, `update_time`, `remark`) VALUES ( 7, '申请人', 'applyUserLabel', 'terminal_resource_apply_export_excel', NULL, NULL, 'N', '0', 'super', '2024-05-09 15:38:32', 'super', '2024-05-09 15:38:32', NULL);
INSERT INTO `sys_dict_data` (`dict_sort`, `dict_label`, `dict_value`, `dict_type`, `css_class`, `list_class`, `is_default`, `status`, `create_by`, `create_time`, `update_by`, `update_time`, `remark`) VALUES ( 8, '申请人部门', 'applyUserFullDeptName', 'terminal_resource_apply_export_excel', NULL, NULL, 'N', '0', 'super', '2024-05-09 15:38:32', 'super', '2024-05-09 15:38:32', NULL);
INSERT INTO `sys_dict_data` (`dict_sort`, `dict_label`, `dict_value`, `dict_type`, `css_class`, `list_class`, `is_default`, `status`, `create_by`, `create_time`, `update_by`, `update_time`, `remark`) VALUES ( 9, '所属组织', 'affiliationDeptName', 'terminal_resource_apply_export_excel', NULL, NULL, 'N', '0', 'super', '2024-05-09 15:38:32', 'super', '2024-05-09 15:38:32', NULL);
INSERT INTO `sys_dict_data` (`dict_sort`, `dict_label`, `dict_value`, `dict_type`, `css_class`, `list_class`, `is_default`, `status`, `create_by`, `create_time`, `update_by`, `update_time`, `remark`) VALUES ( 10, '提单人', 'createByLabel', 'terminal_resource_apply_export_excel', NULL, NULL, 'N', '0', 'super', '2024-05-09 15:38:32', 'super', '2024-05-09 15:38:32', NULL);
INSERT INTO `sys_dict_data` (`dict_sort`, `dict_label`, `dict_value`, `dict_type`, `css_class`, `list_class`, `is_default`, `status`, `create_by`, `create_time`, `update_by`, `update_time`, `remark`) VALUES ( 11, '提单时间', 'createTime', 'terminal_resource_apply_export_excel', NULL, NULL, 'N', '0', 'super', '2024-05-09 15:38:32', 'super', '2024-05-09 15:38:32', NULL);

-- 软件台账邮件通知路径
DELETE FROM sys_dict_data WHERE dict_type = 'mail_url' AND dict_value = 'softwareLicenseUrl';
INSERT INTO `sys_dict_data` ( `dict_sort`, `dict_label`, `dict_value`, `dict_type`, `css_class`, `list_class`, `is_default`, `status`, `create_by`, `create_time`, `update_by`, `update_time`, `remark`) VALUES('25','/stp/asset/software/ledger','softwareLicenseUrl','mail_url',NULL,NULL,'N','0','super','2024-05-21 10:34:25','super','2024-05-21 10:35:50','三慧平台软件台账URL地址');




ALTER TABLE tb_asset_terminal_equipment  ADD  `affiliation_dept_node_id` bigint(20) DEFAULT NULL COMMENT '所属组织ID';
ALTER TABLE tb_asset_terminal_equipment  ADD   `affiliation_dept_name` varchar(255) DEFAULT NULL COMMENT '所属组织名称';


delete from sys_dict_type where dict_type = 'terminal_firewall_status';
INSERT INTO sys_dict_type
(dict_name, dict_type, status, group_ids, create_by, create_time, update_by, update_time, remark, layout)
VALUES('终端设备_防火墙状态', 'terminal_firewall_status', '0', '600', 'super', '2023-03-20 10:34:46', '', NULL, NULL, '1');

DELETE FROM sys_dict_data WHERE  dict_type = 'terminal_firewall_status' and status = '0';
INSERT INTO sys_dict_data
(dict_sort, dict_label, dict_value, dict_type, css_class, list_class, is_default, status, create_by, create_time, update_by, update_time, remark)
VALUES(1, '未开启', '0', 'terminal_firewall_status', NULL, NULL, 'N', '0', 'super', '2023-03-20 10:35:00', '', NULL, NULL);
INSERT INTO sys_dict_data
(dict_sort, dict_label, dict_value, dict_type, css_class, list_class, is_default, status, create_by, create_time, update_by, update_time, remark)
VALUES(2, '已开启', '1', 'terminal_firewall_status', NULL, NULL, 'N', '0', 'super', '2023-03-20 10:35:08', '', NULL, NULL);


delete from sys_dict_type where dict_type = 'terminal_real_firewall_status';
INSERT INTO sys_dict_type
(dict_name, dict_type, status, group_ids, create_by, create_time, update_by, update_time, remark, layout)
VALUES('终端设备_实时防护状态', 'terminal_real_firewall_status', '0', '600', 'super', '2023-03-20 10:34:46', '', NULL, NULL, '1');

DELETE FROM sys_dict_data WHERE  dict_type = 'terminal_real_firewall_status' and status = '0';
INSERT INTO sys_dict_data
(dict_sort, dict_label, dict_value, dict_type, css_class, list_class, is_default, status, create_by, create_time, update_by, update_time, remark)
VALUES(1, '未开启', '0', 'terminal_real_firewall_status', NULL, NULL, 'N', '0', 'super', '2023-03-20 10:35:00', '', NULL, NULL);
INSERT INTO sys_dict_data
(dict_sort, dict_label, dict_value, dict_type, css_class, list_class, is_default, status, create_by, create_time, update_by, update_time, remark)
VALUES(2, '部分开启', '1', 'terminal_real_firewall_status', NULL, NULL, 'N', '0', 'super', '2023-03-20 10:35:08', '', NULL, NULL);
INSERT INTO sys_dict_data
(dict_sort, dict_label, dict_value, dict_type, css_class, list_class, is_default, status, create_by, create_time, update_by, update_time, remark)
VALUES(3, '全部开启', '2', 'terminal_real_firewall_status', NULL, NULL, 'N', '0', 'super', '2023-03-20 10:35:08', '', NULL, NULL);


-- UDC服务白名单添加ecsb线上对应ip配置
DELETE FROM sys_dict_data WHERE  dict_type = 'udc_ip_list' and status = '0'
                            and dict_value in
                                ('10.200.3.42','10.200.3.35','10.200.3.32','10.200.3.44','10.200.5.126',
                                 '10.200.5.128','10.200.5.113','10.200.5.115','10.200.5.132','10.200.5.124',
                                 '10.200.5.129','10.200.2.141','10.200.2.83','10.200.2.136','10.200.3.55',
                                 '10.200.3.66','10.200.3.78','10.200.3.77','10.200.5.120','10.200.2.118');

INSERT INTO sys_dict_data
(dict_sort, dict_label, dict_value, dict_type, css_class, list_class, is_default, status, create_by, create_time, update_by, update_time, remark)
VALUES(0, 'ecsb1', '10.200.3.42', 'udc_ip_list', NULL, NULL, 'N', '0', 'super', '2024-06-23 17:26:47', '', NULL, NULL);
INSERT INTO sys_dict_data
(dict_sort, dict_label, dict_value, dict_type, css_class, list_class, is_default, status, create_by, create_time, update_by, update_time, remark)
VALUES(0, 'ecsb2', '10.200.3.35', 'udc_ip_list', NULL, NULL, 'N', '0', 'super', '2024-06-23 17:26:47', '', NULL, NULL);
INSERT INTO sys_dict_data
(dict_sort, dict_label, dict_value, dict_type, css_class, list_class, is_default, status, create_by, create_time, update_by, update_time, remark)
VALUES(0, 'ecsb3', '10.200.3.32', 'udc_ip_list', NULL, NULL, 'N', '0', 'super', '2024-06-23 17:26:47', '', NULL, NULL);
INSERT INTO sys_dict_data
(dict_sort, dict_label, dict_value, dict_type, css_class, list_class, is_default, status, create_by, create_time, update_by, update_time, remark)
VALUES(0, 'ecsb4', '10.200.3.44', 'udc_ip_list', NULL, NULL, 'N', '0', 'super', '2024-06-23 17:26:47', '', NULL, NULL);
INSERT INTO sys_dict_data
(dict_sort, dict_label, dict_value, dict_type, css_class, list_class, is_default, status, create_by, create_time, update_by, update_time, remark)
VALUES(0, 'ecsb5', '10.200.5.126', 'udc_ip_list', NULL, NULL, 'N', '0', 'super', '2024-06-23 17:26:47', '', NULL, NULL);
INSERT INTO sys_dict_data
(dict_sort, dict_label, dict_value, dict_type, css_class, list_class, is_default, status, create_by, create_time, update_by, update_time, remark)
VALUES(0, 'ecsb6', '10.200.5.128', 'udc_ip_list', NULL, NULL, 'N', '0', 'super', '2024-06-23 17:26:47', '', NULL, NULL);
INSERT INTO sys_dict_data
(dict_sort, dict_label, dict_value, dict_type, css_class, list_class, is_default, status, create_by, create_time, update_by, update_time, remark)
VALUES(0, 'ecsb7', '10.200.5.113', 'udc_ip_list', NULL, NULL, 'N', '0', 'super', '2024-06-23 17:26:47', '', NULL, NULL);
INSERT INTO sys_dict_data
(dict_sort, dict_label, dict_value, dict_type, css_class, list_class, is_default, status, create_by, create_time, update_by, update_time, remark)
VALUES(0, 'ecsb8', '10.200.5.115', 'udc_ip_list', NULL, NULL, 'N', '0', 'super', '2024-06-23 17:26:47', '', NULL, NULL);
INSERT INTO sys_dict_data
(dict_sort, dict_label, dict_value, dict_type, css_class, list_class, is_default, status, create_by, create_time, update_by, update_time, remark)
VALUES(0, 'ecsb9', '10.200.5.132', 'udc_ip_list', NULL, NULL, 'N', '0', 'super', '2024-06-23 17:26:47', '', NULL, NULL);
INSERT INTO sys_dict_data
(dict_sort, dict_label, dict_value, dict_type, css_class, list_class, is_default, status, create_by, create_time, update_by, update_time, remark)
VALUES(0, 'ecsb10', '10.200.5.124', 'udc_ip_list', NULL, NULL, 'N', '0', 'super', '2024-06-23 17:26:47', '', NULL, NULL);
INSERT INTO sys_dict_data
(dict_sort, dict_label, dict_value, dict_type, css_class, list_class, is_default, status, create_by, create_time, update_by, update_time, remark)
VALUES(0, 'ecsb11', '10.200.5.129', 'udc_ip_list', NULL, NULL, 'N', '0', 'super', '2024-06-23 17:26:47', '', NULL, NULL);
INSERT INTO sys_dict_data
(dict_sort, dict_label, dict_value, dict_type, css_class, list_class, is_default, status, create_by, create_time, update_by, update_time, remark)
VALUES(0, 'ecsb12', '10.200.2.141', 'udc_ip_list', NULL, NULL, 'N', '0', 'super', '2024-06-23 17:26:47', '', NULL, NULL);
INSERT INTO sys_dict_data
(dict_sort, dict_label, dict_value, dict_type, css_class, list_class, is_default, status, create_by, create_time, update_by, update_time, remark)
VALUES(0, 'ecsb13', '10.200.2.83', 'udc_ip_list', NULL, NULL, 'N', '0', 'super', '2024-06-23 17:26:47', '', NULL, NULL);
INSERT INTO sys_dict_data
(dict_sort, dict_label, dict_value, dict_type, css_class, list_class, is_default, status, create_by, create_time, update_by, update_time, remark)
VALUES(0, 'ecsb14', '10.200.2.136', 'udc_ip_list', NULL, NULL, 'N', '0', 'super', '2024-06-23 17:26:47', '', NULL, NULL);
INSERT INTO sys_dict_data
(dict_sort, dict_label, dict_value, dict_type, css_class, list_class, is_default, status, create_by, create_time, update_by, update_time, remark)
VALUES(0, 'ecsb15', '10.200.3.55', 'udc_ip_list', NULL, NULL, 'N', '0', 'super', '2024-06-23 17:26:47', '', NULL, NULL);
INSERT INTO sys_dict_data
(dict_sort, dict_label, dict_value, dict_type, css_class, list_class, is_default, status, create_by, create_time, update_by, update_time, remark)
VALUES(0, 'ecsb16', '10.200.3.66', 'udc_ip_list', NULL, NULL, 'N', '0', 'super', '2024-06-23 17:26:47', '', NULL, NULL);
INSERT INTO sys_dict_data
(dict_sort, dict_label, dict_value, dict_type, css_class, list_class, is_default, status, create_by, create_time, update_by, update_time, remark)
VALUES(0, 'ecsb17', '10.200.3.77', 'udc_ip_list', NULL, NULL, 'N', '0', 'super', '2024-06-23 17:26:47', '', NULL, NULL);
INSERT INTO sys_dict_data
(dict_sort, dict_label, dict_value, dict_type, css_class, list_class, is_default, status, create_by, create_time, update_by, update_time, remark)
VALUES(0, 'ecsb18', '10.200.3.78', 'udc_ip_list', NULL, NULL, 'N', '0', 'super', '2024-06-23 17:26:47', '', NULL, NULL);
INSERT INTO sys_dict_data
(dict_sort, dict_label, dict_value, dict_type, css_class, list_class, is_default, status, create_by, create_time, update_by, update_time, remark)
VALUES(0, 'ecsb19', '10.200.5.120', 'udc_ip_list', NULL, NULL, 'N', '0', 'super', '2024-06-23 17:26:47', '', NULL, NULL);
INSERT INTO sys_dict_data
(dict_sort, dict_label, dict_value, dict_type, css_class, list_class, is_default, status, create_by, create_time, update_by, update_time, remark)
VALUES(0, 'ecsb20', '10.200.2.118', 'udc_ip_list', NULL, NULL, 'N', '0', 'super', '2024-06-23 17:26:47', '', NULL, NULL);


-- 字典中相关udc服务配置type
delete from sys_dict_type where dict_type = 'udc_api_key' and status = '0';
INSERT INTO sys_dict_type
(dict_name, dict_type, status, group_ids, create_by, create_time, update_by, update_time, remark, layout)
VALUES('UDC KEY清单', 'udc_api_key', '0', '202402041016597920002', 'super', '2023-02-03 17:05:52', 'super', '2024-02-04 10:27:43', NULL, '1');


delete from sys_dict_type where dict_type = 'udc_ip_list' and status = '0';
INSERT INTO sys_dict_type
(dict_name, dict_type, status, group_ids, create_by, create_time, update_by, update_time, remark, layout)
VALUES('UDC IP白名单', 'udc_ip_list', '0', '202402041016597920002', 'super', '2023-05-22 14:22:44', 'super', '2024-02-04 10:28:05', NULL, '1');


delete from sys_dict_type where dict_type = 'udc_api_list' and status = '0';
INSERT INTO sys_dict_type
(dict_name, dict_type, status, group_ids, create_by, create_time, update_by, update_time, remark, layout)
VALUES('API授权接口清单', 'udc_api_list', '0', '202402041016597920002', 'super', '2023-02-03 17:10:13', 'super', '2024-02-04 10:27:55', NULL, '1');


---- 624 日期以后新增得sql

-- udc服务解析润工作token得私钥
DELETE FROM sys_dict_data WHERE  dict_type = 'sync_sec_config' and status = '0'
                            and dict_value ='fish_rwork_private_key';
INSERT INTO sys_dict_data
(dict_sort, dict_label, dict_value, dict_type, css_class, list_class, is_default, status, create_by, create_time, update_by, update_time, remark)
VALUES(9888, 'udc服务解析润工作token得私钥', 'fish_rwork_private_key', 'sync_sec_config', NULL, NULL, 'N', '0', 'super', '2024-02-28 11:01:59', '', NULL, 'MIICdwIBADANBgkqhkiG9w0BAQEFAASCAmEwggJdAgEAAoGBAKhedMNbuJjkmhJTIlBJieOXfa12YrvTFewHNV/r70nncC9jI3IItiRW05KmRnOsDAIulJtdd0bb3R/hR4hl3UPVilUfSncXAI0WjKF0MFitrAtlDzWQ3AF821SmpUU4GC6To//3+ZPfSJAe5UZ35ekoCvDE0mCX8Q6XqIvLRxqhAgMBAAECgYB87RDv/zdZ4ozbOeoE7nusbjQnJ+ccfAQRDEwzLwluqZXY41Nigko7bl0vu8Ycf7StTcif+trMrchFpk8ASqzAOtVE1UJxRUFqXZbxO7Qtipw/+a4zIGXW4tp29TgOauFVDxAbtqujH3HzzLQ+fP0L5jtPHi8XNe223ckxZ+6rAQJBANoBGZxhyK5rWK3pu4bGkJ15qQI5IIzaoOnOWiEqlbYvKrPHVMzKJQkYKkuqZ4XI1fOYIekMs+XSFHdHhvXQWlECQQDFtrsIOjCTlIcP+AmiL4h2kpivZzYcXrYSk+JSZafST90u3yeZDLV/SrANUaZO74Fqxb0oC0kt+xbv0tZ32VdRAkAHk942B1gYZ/bPJL618pT4RFBRmXa+LqNFPTz4xigqCv2q/hS+gZBD/qkJtESg69gz/WfAWAawyFqZwsy4IqPhAkEApMFE0fJLkG9wrSnwPSqG+OfoPCIxwSpbZte8/RSg6GyM0AY9JRimFdDTLAYiJB0JJ0Rn//qHnL1ju61h8rU2QQJBALxeZpPMmQH1izjoCNYYMao7tL94TOPYhn620nFe+HsOrlu9g29hm9AW67n3cD4Nl6M+dLUZQEnuRe3YRVdbBDM=');

-- UDC服务白名单添加ecsb测试对应ip配置
DELETE FROM sys_dict_data WHERE  dict_type = 'udc_ip_list' and status = '0'
                            and dict_value in
                                ('10.133.77.225','10.133.77.60','10.133.77.202','10.133.77.29','10.133.77.218','10.133.77.107','10.133.77.98','10.133.77.128','10.133.77.249','10.133.77.242','10.133.77.71');


INSERT INTO sys_dict_data
(dict_sort, dict_label, dict_value, dict_type, css_class, list_class, is_default, status, create_by, create_time, update_by, update_time, remark)
VALUES(0, 'ecsb1', '10.133.77.225', 'udc_ip_list', NULL, NULL, 'N', '0', 'super', '2024-06-23 17:26:47', '', NULL, NULL);
INSERT INTO sys_dict_data
(dict_sort, dict_label, dict_value, dict_type, css_class, list_class, is_default, status, create_by, create_time, update_by, update_time, remark)
VALUES(0, 'ecsb2', '10.133.77.60', 'udc_ip_list', NULL, NULL, 'N', '0', 'super', '2024-06-23 17:26:47', '', NULL, NULL);
INSERT INTO sys_dict_data
(dict_sort, dict_label, dict_value, dict_type, css_class, list_class, is_default, status, create_by, create_time, update_by, update_time, remark)
VALUES(0, 'ecsb3', '10.133.77.202', 'udc_ip_list', NULL, NULL, 'N', '0', 'super', '2024-06-23 17:26:47', '', NULL, NULL);
INSERT INTO sys_dict_data
(dict_sort, dict_label, dict_value, dict_type, css_class, list_class, is_default, status, create_by, create_time, update_by, update_time, remark)
VALUES(0, 'ecsb4', '10.133.77.29', 'udc_ip_list', NULL, NULL, 'N', '0', 'super', '2024-06-23 17:26:47', '', NULL, NULL);
INSERT INTO sys_dict_data
(dict_sort, dict_label, dict_value, dict_type, css_class, list_class, is_default, status, create_by, create_time, update_by, update_time, remark)
VALUES(0, 'ecsb5', '10.133.77.218', 'udc_ip_list', NULL, NULL, 'N', '0', 'super', '2024-06-23 17:26:47', '', NULL, NULL);
INSERT INTO sys_dict_data
(dict_sort, dict_label, dict_value, dict_type, css_class, list_class, is_default, status, create_by, create_time, update_by, update_time, remark)
VALUES(0, 'ecsb6', '10.133.77.107', 'udc_ip_list', NULL, NULL, 'N', '0', 'super', '2024-06-23 17:26:47', '', NULL, NULL);
INSERT INTO sys_dict_data
(dict_sort, dict_label, dict_value, dict_type, css_class, list_class, is_default, status, create_by, create_time, update_by, update_time, remark)
VALUES(0, 'ecsb7', '10.133.77.98', 'udc_ip_list', NULL, NULL, 'N', '0', 'super', '2024-06-23 17:26:47', '', NULL, NULL);
INSERT INTO sys_dict_data
(dict_sort, dict_label, dict_value, dict_type, css_class, list_class, is_default, status, create_by, create_time, update_by, update_time, remark)
VALUES(0, 'ecsb8', '10.133.77.128', 'udc_ip_list', NULL, NULL, 'N', '0', 'super', '2024-06-23 17:26:47', '', NULL, NULL);
INSERT INTO sys_dict_data
(dict_sort, dict_label, dict_value, dict_type, css_class, list_class, is_default, status, create_by, create_time, update_by, update_time, remark)
VALUES(0, 'ecsb9', '10.133.77.249', 'udc_ip_list', NULL, NULL, 'N', '0', 'super', '2024-06-23 17:26:47', '', NULL, NULL);
INSERT INTO sys_dict_data
(dict_sort, dict_label, dict_value, dict_type, css_class, list_class, is_default, status, create_by, create_time, update_by, update_time, remark)
VALUES(0, 'ecsb10', '10.133.77.242', 'udc_ip_list', NULL, NULL, 'N', '0', 'super', '2024-06-23 17:26:47', '', NULL, NULL);
INSERT INTO sys_dict_data
(dict_sort, dict_label, dict_value, dict_type, css_class, list_class, is_default, status, create_by, create_time, update_by, update_time, remark)
VALUES(0, 'ecsb11', '10.133.77.71', 'udc_ip_list', NULL, NULL, 'N', '0', 'super', '2024-06-23 17:26:47', '', NULL, NULL);



ALTER TABLE tb_asset_terminal_equipment ADD system_type varchar(255) NULL COMMENT '系统类型';
ALTER TABLE tb_asset_terminal_equipment CHANGE system_type system_type varchar(255) NULL COMMENT '系统类型' AFTER system_version;
ALTER TABLE tb_asset_terminal_equipment MODIFY COLUMN sound_card varchar(1000) CHARACTER SET utf8 COLLATE utf8_general_ci NULL COMMENT '声卡';
