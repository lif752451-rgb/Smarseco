-- 集团漏洞复查: 20240612
-- 更新Agent表异常数据
UPDATE tb_qingteng_agent a,(SELECT ip,COUNT(1) AS num FROM tb_qingteng_agent where agent_status = '0' GROUP BY ip HAVING  num > 1) t set a.agent_status = '1',a.online_status = '0'  where t.ip = a.ip ;

-- 修改正常数据（非集团环境可不执行）
UPDATE tb_qingteng_agent SET agent_status = '0',online_status = '1' WHERE id = '665fc74b26d2083a';
UPDATE tb_qingteng_agent SET agent_status = '0',online_status = '1' WHERE id = '665ed0825e86b9d6';
UPDATE tb_qingteng_agent SET agent_status = '0',online_status = '1' WHERE id = '665c86f426d2081c';
UPDATE tb_qingteng_agent SET agent_status = '0',online_status = '1' WHERE id = '665d6d8526d20829';
UPDATE tb_qingteng_agent SET agent_status = '0',online_status = '1' WHERE id = '665ed5a35e86b9d7';
UPDATE tb_qingteng_agent SET agent_status = '0',online_status = '1' WHERE id = '665ede81bc28a3de';
UPDATE tb_qingteng_agent SET agent_status = '0',online_status = '1' WHERE id = '666016a15e86b9de';
UPDATE tb_qingteng_agent SET agent_status = '0',online_status = '1' WHERE id = '644487a636df4850';

-- 新增字段
alter table tb_vuln_process_form add agent_id varchar(64) DEFAULT NULL COMMENT 'AgentID';
alter table tb_qingteng_agent add local_ip varchar(32) DEFAULT NULL COMMENT '私网ip';

-- 添加索引
alter table tb_vuln_scan_task_record_log add index idx_agent_id (uuid(32));
alter table tb_vuln_process_form add index idx_agent_id(agent_id);

-- 漏洞主表关联tb_qingteng_agent表增加AgentID数据
UPDATE tb_vuln_process_form tvpf
JOIN (
    SELECT tg.ip, tg.id
    FROM tb_qingteng_agent tg
                where agent_status = '0'
    GROUP BY tg.ip, tg.id
) tg_unique_ip ON tvpf.ip = tg_unique_ip.ip
SET tvpf.agent_id = tg_unique_ip.id;