-- 集团升级: 20240408
/*
 1.组件查询
 */
alter table tb_asset_software add index idx_soft_name_version(soft_name,soft_version);
set @@global.query_cache_size= 283886080;
/*
 2.tb_asset_person新增索引脚本
 */
ALTER TABLE `tb_asset_person`
    ADD  INDEX `idx_user_id` (`user_id`);
/*
 3.集团环境资产关联责任人表字段长度修改脚本
 */
ALTER TABLE `tb_asset_person`
    CHANGE `id` `id` VARCHAR(200) NOT NULL  COMMENT '主键Id';
/*
 4.漏洞白名单不显示漏洞概述
 */
UPDATE tb_vul_white_list SET vul_content = vul_name;
/*
 5.删除组件数据中的脏数据
 */
DELETE  FROM  tb_asset_software  WHERE CHAR_LENGTH(soft_name)=32;

-- 集团升级：20240422

/*
  1.首页个人工作台字典控制显示隐藏
 */
DELETE FROM sys_dict_type WHERE dict_type = 'menu_open_close';
INSERT INTO `sys_dict_type` (`dict_id`, `dict_name`, `dict_type`, `status`, `group_ids`, `create_by`, `create_time`, `update_by`, `update_time`, `remark`, `layout`) VALUES (null, '菜单显隐-控制开关', 'menu_open_close', '0', '600', 'super', '2024-04-09 14:43:26', '', NULL, '菜单显隐-控制开关', '1');
DELETE FROM sys_dict_data WHERE dict_value = 'menu_open_close';
INSERT INTO `sys_dict_data` (`dict_code`, `dict_sort`, `dict_label`, `dict_value`, `dict_type`, `css_class`, `list_class`, `is_default`, `status`, `create_by`, `create_time`, `update_by`, `update_time`, `remark`) VALUES (null, 0, '个人工作台_统计分析报表', 'menu_personal_statistics_open_close', 'menu_open_close', NULL, NULL, 'N', '0', 'super', '2024-04-09 14:58:23', 'super', '2024-04-09 15:47:33', '{\n\"open\":false\n}');
/*
  2.终端资产Bug修复
 */
alter table tb_asset_terminal_equipment modify id varchar(64) NOT NULL COMMENT '主键';
alter table tb_asset_baseline modify result MEDIUMTEXT;
ALTER TABLE tb_asset_terminal_equipment MODIFY COLUMN computer_name VARCHAR(500) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT NULL COMMENT '计算机名';
/*
  3.同步告警bug
 */
ALTER TABLE tb_event MODIFY `attack_ip` varchar(2048) DEFAULT NULL COMMENT '攻击ip';