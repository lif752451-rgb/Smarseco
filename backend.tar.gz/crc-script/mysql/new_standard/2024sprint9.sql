-- 资产管理-应用系统 新增字段和字典新增导出字段
UPDATE tb_asset_app_system SET is_waf = '1';
alter table tb_asset_app_system add `is_waf` char(1) DEFAULT '0' COMMENT '是否有添加WAF防护 0：是 1：否';
INSERT INTO `sys_dict_data`(`dict_sort`, `dict_label`, `dict_value`, `dict_type`, `css_class`, `list_class`, `is_default`, `status`, `create_by`, `create_time`, `update_by`, `update_time`, `remark`) VALUES (16, '是否有添加WAF防护', 'isWaf', 'asset_system_export_excel', NULL, NULL, 'N', '0', 'super', '2024-07-04 15:14:50', 'super', '2024-07-04 15:14:50', '{ \"isDefault\": true, \"isMust\": false }');