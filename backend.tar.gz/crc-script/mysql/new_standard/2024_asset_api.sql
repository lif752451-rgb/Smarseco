--启用同步资产API
ALTER TABLE tb_asset ADD `application_type` varchar(50) DEFAULT NULL COMMENT '应用类别 选项取字典:asset_application_type';
ALTER TABLE tb_asset ADD `device_type` varchar(20) DEFAULT NULL COMMENT '设备类型(软件、硬件、其他)';
ALTER TABLE tb_asset ADD `server_chip` varchar(100) DEFAULT NULL COMMENT '服务器芯片';
ALTER TABLE tb_asset ADD `is_reliability` varchar(10) DEFAULT '0' COMMENT '是否符合可靠性要求 0否  1是';
ALTER TABLE tb_asset ADD `purchase_time` datetime DEFAULT NULL COMMENT '采购时间(yyyyMMdd)';
ALTER TABLE tb_asset ADD `storage_system` varchar(20) DEFAULT NULL COMMENT '存储系统（套数）';
ALTER TABLE tb_asset ADD `capacity` varchar(20) DEFAULT NULL COMMENT '容量（T）';
ALTER TABLE tb_asset ADD `equipment_brand` varchar(4) DEFAULT NULL COMMENT '设备品牌';
ALTER TABLE tb_asset ADD `equipment_type` varchar(50) DEFAULT NULL COMMENT '设备型号';
delete from `sys_dict_type` where dict_type = 'asset_application_type';
delete from `sys_dict_data` where dict_type = 'asset_application_type';
INSERT INTO `sys_dict_type`(`dict_name`, `dict_type`, `status`, `create_by`, `create_time`, `update_by`, `update_time`, `remark`) VALUES ('资产_应用系统_应用类别', 'asset_application_type', '0', 'super', '2024-07-17 16:58:28', '', NULL, NULL);
INSERT INTO `sys_dict_data`(`dict_sort`, `dict_label`, `dict_value`, `dict_type`, `css_class`, `list_class`, `is_default`, `status`, `create_by`, `create_time`, `update_by`, `update_time`, `remark`) VALUES (1, '综合办公', '1', 'asset_application_type', NULL, NULL, NULL, '0', 'super', '2024-07-17 16:59:07', NULL, NULL, NULL);
INSERT INTO `sys_dict_data`(`dict_sort`, `dict_label`, `dict_value`, `dict_type`, `css_class`, `list_class`, `is_default`, `status`, `create_by`, `create_time`, `update_by`, `update_time`, `remark`) VALUES (2, '经营管理', '2', 'asset_application_type', NULL, NULL, NULL, '0', 'super', '2024-07-17 16:59:17', NULL, NULL, NULL);
INSERT INTO `sys_dict_data`(`dict_sort`, `dict_label`, `dict_value`, `dict_type`, `css_class`, `list_class`, `is_default`, `status`, `create_by`, `create_time`, `update_by`, `update_time`, `remark`) VALUES (3, '生产运营', '3', 'asset_application_type', NULL, NULL, NULL, '0', 'super', '2024-07-17 16:59:28', NULL, NULL, NULL);
INSERT INTO `sys_dict_data`(`dict_sort`, `dict_label`, `dict_value`, `dict_type`, `css_class`, `list_class`, `is_default`, `status`, `create_by`, `create_time`, `update_by`, `update_time`, `remark`) VALUES (0, '是否启用同步资产API', 'asset_api_enable', 'sync_sec_config', NULL, NULL, NULL, '0', 'super', '2024-08-22 14:05:19', NULL, NULL, '数据同步服务资产API');