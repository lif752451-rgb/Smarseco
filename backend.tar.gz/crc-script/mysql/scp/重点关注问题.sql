DROP TABLE IF EXISTS tb_event_attention;
CREATE TABLE tb_event_attention (
 id varchar(64) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
 event_id varchar(64) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL COMMENT '重点关注ID',
 title varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL COMMENT '标题',
 duty_dept_name varchar(1000) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL COMMENT '责任单位，多个,号分隔',
 duty_dept_id varchar(1000) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL COMMENT '责任部门ID，多个,号分隔',
 problem_desc_rich longtext CHARACTER SET utf8 COLLATE utf8_general_ci NULL COMMENT '问题描述（富文本内容)',
 problem_desc_text longtext CHARACTER SET utf8 COLLATE utf8_general_ci NULL COMMENT '问题描述（纯文本)',
 first_alarm_time datetime NULL DEFAULT NULL COMMENT '首次告警时间',
 relation_alarm text CHARACTER SET utf8 COLLATE utf8_general_ci NULL COMMENT '关联告警',
 relation_risk text CHARACTER SET utf8 COLLATE utf8_general_ci NULL COMMENT '关联风险',
 status char(1) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL COMMENT '状态，0:进行中 1:已完成\n',
 remark varchar(512) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL COMMENT '备注',
 file_json text CHARACTER SET utf8 COLLATE utf8_general_ci NULL COMMENT '附件',
 del_flag varchar(2) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL COMMENT '删除标识，1-删除，0-未删除',
 create_by varchar(128) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL COMMENT '提交人',
 create_by_label varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL COMMENT '提交人(全称)',
 create_time datetime NULL DEFAULT NULL COMMENT '提交时间',
 update_by varchar(128) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL COMMENT '修改人',
 update_time datetime NULL DEFAULT NULL COMMENT '修改时间',
 PRIMARY KEY (id) USING BTREE
) ENGINE = InnoDB CHARACTER SET = utf8 COLLATE = utf8_general_ci ROW_FORMAT = DYNAMIC;


DROP TABLE IF EXISTS tb_event_attention_record;
CREATE TABLE tb_event_attention_record (
 id varchar(64) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL COMMENT '主键',
 item varchar(128) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL COMMENT '变更内容概要',
 event_id varchar(40) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL COMMENT '重点关注问题ID',
 update_by varchar(64) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL COMMENT '更新者',
 update_by_label varchar(64) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL COMMENT '更新者',
 update_time datetime NULL DEFAULT NULL COMMENT '更新时间',
 PRIMARY KEY (id) USING BTREE
) ENGINE = InnoDB CHARACTER SET = utf8 COLLATE = utf8_general_ci COMMENT = '重点关注问题变更记录' ROW_FORMAT = DYNAMIC;

DROP TABLE IF EXISTS tb_event_attention_record_detail;
CREATE TABLE tb_event_attention_record_detail (
 id varchar(64) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL COMMENT '主键',
 item varchar(64) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL COMMENT '变更内容概要',
 update_by varchar(64) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL COMMENT '更新者',
 update_by_label varchar(64) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL COMMENT '更新者',
 update_time datetime NULL DEFAULT NULL COMMENT '更新时间',
 status int(1) NULL DEFAULT 0 COMMENT '状态',
 before_change longtext CHARACTER SET utf8 COLLATE utf8_general_ci NULL COMMENT '变更前',
 after_change longtext CHARACTER SET utf8 COLLATE utf8_general_ci NULL COMMENT '变更后',
 change_id varchar(64) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL COMMENT '变更记录ID',
 PRIMARY KEY (id) USING BTREE
) ENGINE = InnoDB CHARACTER SET = utf8 COLLATE = utf8_general_ci COMMENT = '重点关注问题变更记录记录详情' ROW_FORMAT = DYNAMIC;