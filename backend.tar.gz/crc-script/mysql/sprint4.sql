
-- 区域管理表结构
CREATE TABLE `tb_asset_area` (
     `id` bigint(20) NOT NULL AUTO_INCREMENT COMMENT 'ID',
     `create_by` varchar(64) DEFAULT NULL COMMENT '创建者',
     `create_time` datetime DEFAULT NULL COMMENT '创建时间',
     `update_by` varchar(64) DEFAULT NULL COMMENT '修改者',
     `update_time` datetime DEFAULT NULL COMMENT '修改时间',

     `custom_uuid` varchar(64) NOT NULL COMMENT '自定义UUID',
     `ancestors` varchar(1024) DEFAULT NULL COMMENT '路径',
     `del_flag` int(11) default 0 comment '删除标识',

     `area_name` varchar(128) NOT NULL COMMENT '区域名称',
     `sort_current_level` int(11) default 0 NOT NULL COMMENT '同级排序',
     `longitude` decimal(10,7) default NULL COMMENT '经度',
     `latitude` decimal(10,7) default NULL COMMENT '纬度',
     `altitude` decimal(10,7) default NULL COMMENT '海拔',
     `parent_custom_uuid` varchar(64) default '0' NOT NULL COMMENT '父节点uuid',
     `leaf_flag` int(11) default 0 NOT NULL COMMENT '是否是叶子节点',

     `remark` varchar(1024) DEFAULT NULL COMMENT '备注',
     PRIMARY KEY (`id`) USING BTREE,
     unique KEY `idx_custom_uuid` (`custom_uuid`) USING BTREE,
     KEY `idx_parent_uuid` (`parent_custom_uuid`) USING BTREE,
     KEY `idx_area_name` (`area_name`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC COMMENT='区域管理';

alter table tb_asset_area add column `ancestors` varchar(1024) DEFAULT NULL COMMENT '路径' after `custom_uuid`;

-- 漏洞流程运行中，角色添加用户可以处置/查看正在流转工单，需添加如下字段
ALTER TABLE tb_process_vuln_handle_business ADD current_deal_user varchar(2000) NULL COMMENT '当前处理人';
ALTER TABLE tb_process_vuln_handle_business ADD current_deal_user_nick_name varchar(2000) NULL COMMENT '当前处理人昵称';

-- 漏洞业务表加字段
ALTER TABLE tb_process_vuln_handle_business ADD alarm_id varchar(50) NULL COMMENT '告警转漏洞，告警ID';

-- 资产表增加字段
ALTER TABLE tb_asset ADD area_custom_uuid varchar(64) NULL COMMENT '网络区域自定义UUID';
ALTER TABLE tb_asset ADD area_name varchar(1024) NULL COMMENT '网络区域名称';

-- 网段表增加字段
ALTER TABLE tb_asset_segement ADD area_custom_uuid varchar(64) NULL COMMENT '网络区域自定义UUID';
ALTER TABLE tb_asset_segement MODIFY COLUMN area_name varchar(1024) CHARACTER SET utf8 COLLATE utf8_general_ci NULL;

-- 更新历史处于处置节点的数据
update
	tb_process_vuln_handle_business bu
set
	current_deal_user = (
        SELECT v.security_user
        from tb_vuln_data v
        where v.id = bu.form_id ),
	current_deal_user_nick_name = (
        SELECT u.nick_name
        from tb_vuln_data v
        inner join sys_user u on v.security_user = u.user_name
	    where v.id = bu.form_id )
where
	bu.id in (
        select a.id from (
        SELECT b.id from tb_process_vuln_handle_business b
        inner join tb_vuln_data v on b.form_id = v.id
        where b.work_order_state in ('2', '7')and current_deal_user is null) a)