-- 新增表：自定义常用功能
CREATE TABLE custom_business_module (
 id bigint(20) NOT NULL AUTO_INCREMENT COMMENT 'ID',
 user_id bigint(20) NOT NULL COMMENT '用户ID',
 menu_id bigint(20) NOT NULL COMMENT '菜单ID',
 app_label varchar(64) NOT NULL COMMENT '应用标识，主要用于取根路径',
 module_name varchar(128) DEFAULT NULL COMMENT '模块名称',
 module_path varchar(256) DEFAULT NULL COMMENT '模块路径',
 sort int(11) NOT NULL DEFAULT '0' COMMENT '排序',
 create_by varchar(64) DEFAULT NULL COMMENT '创建者',
 create_time datetime DEFAULT NULL COMMENT '创建时间',
 update_by varchar(64) DEFAULT NULL COMMENT '修改者',
 update_time datetime DEFAULT NULL COMMENT '修改时间',
 del_flag tinyint DEFAULT 0 COMMENT '删除标志(0:未删除，1:已删除)',
 icon varchar(128) DEFAULT '#' COMMENT '菜单图标',
PRIMARY KEY (id) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=100 DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC COMMENT='自定义常用功能';

-- 新增字典：base_path
INSERT INTO sys_dict_type
(dict_name, dict_type, status, create_by, create_time, update_by, update_time, remark)
VALUES('基础路径', 'base_path', '0', 'super', '2022-03-17 13:47:54', '', NULL, NULL);

INSERT INTO sys_dict_data
(dict_sort, dict_label, dict_value, dict_type, css_class, list_class, is_default, status, create_by, create_time, update_by, update_time, remark)
VALUES(1, 'stp_base_path', 'https://10.200.197.19:10001', 'base_path', NULL, NULL, 'N', '0', 'super', '2022-03-17 13:49:24', '', NULL, NULL);
INSERT INTO sys_dict_data
(dict_sort, dict_label, dict_value, dict_type, css_class, list_class, is_default, status, create_by, create_time, update_by, update_time, remark)
VALUES(2, 'ssp_base_path', 'https://10.200.197.19:10003', 'base_path', NULL, NULL, 'N', '0', 'super', '2022-03-17 13:52:52', '', NULL, NULL);
INSERT INTO sys_dict_data
(dict_sort, dict_label, dict_value, dict_type, css_class, list_class, is_default, status, create_by, create_time, update_by, update_time, remark)
VALUES(3, 'scp_base_path', 'https://10.200.197.19:10002', 'base_path', NULL, NULL, 'N', '0', 'super', '2022-03-17 13:56:26', '', NULL, NULL);


-- 个人工作台-风险状态下拉框
INSERT INTO sys_dict_type
(dict_name, dict_type, status, create_by, create_time, update_by, update_time, remark)
VALUES('风险工单状态', 'risk_work_status', '0', 'super', '2022-03-21 16:58:39', '', NULL, NULL);

INSERT INTO sys_dict_data
(dict_sort, dict_label, dict_value, dict_type, css_class, list_class, is_default, status, create_by, create_time, update_by, update_time, remark)
VALUES
(1, '待推送', '1', 'risk_work_status', NULL, NULL, 'N', '0', '', NULL, '', NULL, NULL),
(2, '待下发', '2', 'risk_work_status', NULL, NULL, 'N', '0', '', NULL, '', NULL, NULL),
(3, '待认领', '3', 'risk_work_status', NULL, NULL, 'N', '0', '', NULL, '', NULL, NULL),
(4, '处置', '4', 'risk_work_status', NULL, NULL, 'N', '0', '', NULL, '', NULL, NULL),
(5, '风险审核', '5', 'risk_work_status', NULL, NULL, 'N', '0', '', NULL, '', NULL, NULL),
(6, '集团验证', '6', 'risk_work_status', NULL, NULL, 'N', '0', '', NULL, '', NULL, NULL),
(7, '残余风险', '7', 'risk_work_status', NULL, NULL, 'N', '0', '', NULL, '', NULL, NULL),
(9, '已关闭', '9', 'risk_work_status', NULL, NULL, 'N', '0', '', NULL, '', NULL, NULL);

-- 引擎管理附件相关表结构
CREATE TABLE `tb_engine_equipment_management` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT COMMENT 'ID',
  `create_by` varchar(64) DEFAULT NULL COMMENT '创建者',
  `create_time` datetime DEFAULT NULL COMMENT '创建时间',
  `update_by` varchar(64) DEFAULT NULL COMMENT '修改者',
  `update_time` datetime DEFAULT NULL COMMENT '修改时间',
  `custom_uuid` varchar(64) NOT NULL COMMENT '自定义UUID',
  `del_flag` int(11) default 0 comment '删除标识(0否1是)',


  `equipment_address` text COMMENT '设备地址',
  `equipment_name` varchar(100) DEFAULT NULL COMMENT '设备名称',
  `scan_type` varchar(500) DEFAULT NULL COMMENT '扫描类型',
  `equipment_version` varchar(100) DEFAULT NULL COMMENT '设备版本',
  `equipment_manufacture` varchar(500) DEFAULT NULL COMMENT '设备厂商',
  `equipment_capabilities` varchar(1000) DEFAULT NULL COMMENT '设备功能',
  `setup_time` datetime DEFAULT NULL COMMENT '配置时间',

  `login_user` varchar(128) DEFAULT NULL COMMENT '登录用户',
  `password` text COMMENT '密码',
  `rule` text COMMENT '配置规则',

  `connected` int(11) NULL DEFAULT '0' COMMENT '是否联通(0否1是)',
  `enabled` int(11) NOT NULL DEFAULT '1' COMMENT '是否启用(0否1是)',

  `node_desc` text  COMMENT '节点信息',
  `remark` varchar(512) DEFAULT NULL COMMENT '备注',

  PRIMARY KEY (`id`) USING BTREE,
  UNIQUE KEY `idx_custom_uuid` (`custom_uuid`) USING BTREE,
  key `idx_enabled` (`enabled`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=1 DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC COMMENT='引擎管理';

CREATE TABLE `tb_engine_equipment_node` (
    `id` bigint(20) NOT NULL AUTO_INCREMENT COMMENT 'ID',
    `create_by` varchar(64) DEFAULT NULL COMMENT '创建者',
    `create_time` datetime DEFAULT NULL COMMENT '创建时间',
    `update_by` varchar(64) DEFAULT NULL COMMENT '修改者',
    `update_time` datetime DEFAULT NULL COMMENT '修改时间',
    `custom_uuid` varchar(64) NOT NULL COMMENT '自定义UUID',
    `del_flag` int(11) default 0 comment '删除标识(0否1是)',

    `equipment_management_uuid` varchar(64) DEFAULT NULL COMMENT '引擎管理id',
    `node_address` text  COMMENT '节点地址',
    `node_name` varchar(512) DEFAULT NULL COMMENT '节点名称',

    `remark` varchar(1024) DEFAULT NULL COMMENT '备注',

    PRIMARY KEY (`id`) USING BTREE,
    UNIQUE KEY `idx_custom_uuid` (`custom_uuid`) USING BTREE,
    KEY `idx_management_uuid` (`equipment_management_uuid`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=1 DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC COMMENT='引擎管理-节点信息';

CREATE TABLE `tb_engine_equipment_authorization_file` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT COMMENT 'ID',
  `create_by` varchar(64) DEFAULT NULL COMMENT '创建者',
  `create_time` datetime DEFAULT NULL COMMENT '创建时间',
  `update_by` varchar(64) DEFAULT NULL COMMENT '修改者',
  `update_time` datetime DEFAULT NULL COMMENT '修改时间',
  `custom_uuid` varchar(64) NOT NULL COMMENT '自定义UUID',
  `del_flag` int(11) default 0 comment '删除标识(0否1是)',

  `equipment_management_uuid` varchar(64) DEFAULT NULL COMMENT '引擎管理id',
  `authorization_deadline` datetime DEFAULT NULL COMMENT '授权截止时间',

  `file_json` text DEFAULT NULL COMMENT '文件信息',

  `remark` varchar(1024) DEFAULT NULL COMMENT '备注',

  PRIMARY KEY (`id`) USING BTREE,
  UNIQUE KEY `idx_custom_uuid` (`custom_uuid`) USING BTREE,
  KEY `idx_management_uuid` (`equipment_management_uuid`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=1 DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC COMMENT='引擎管理-授权文件附件';

CREATE TABLE `tb_engine_equipment_upgrade_file` (
    `id` bigint(20) NOT NULL AUTO_INCREMENT COMMENT 'ID',
    `create_by` varchar(64) DEFAULT NULL COMMENT '创建者',
    `create_time` datetime DEFAULT NULL COMMENT '创建时间',
    `update_by` varchar(64) DEFAULT NULL COMMENT '修改者',
    `update_time` datetime DEFAULT NULL COMMENT '修改时间',
    `custom_uuid` varchar(64) NOT NULL COMMENT '自定义UUID',
    `del_flag` int(11) default 0 comment '删除标识(0否1是)',

    `equipment_management_uuid` varchar(64) DEFAULT NULL COMMENT '引擎管理id',
    `upgrade_version` varchar(128) DEFAULT NULL COMMENT '升级包版本',
    `file_json` text DEFAULT NULL COMMENT '文件信息',

    `remark` varchar(1024) DEFAULT NULL COMMENT '备注',

    PRIMARY KEY (`id`) USING BTREE,
    UNIQUE KEY `idx_custom_uuid` (`custom_uuid`) USING BTREE,
    KEY `idx_management_uuid` (`equipment_management_uuid`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=1 DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC COMMENT='引擎管理-升级包附件';

INSERT INTO sys_dict_type(dict_name, dict_type, status, create_by, create_time, update_by, update_time, remark) VALUES ('告警关联日志风险等级', 'log_risk_level', '0', 'super', '2022-03-16 15:53:20', '', NULL, '告警关联日志风险等级，包含高风险，中风险，低风险，信息');

INSERT INTO sys_dict_data(dict_sort, dict_label, dict_value, dict_type, css_class, list_class, is_default, status, create_by, create_time, update_by, update_time, remark) VALUES (1, '高风险', 'HIGH_RISK', 'log_risk_level', NULL, NULL, 'N', '0', 'super', '2022-03-16 15:54:10', '', NULL, '高风险');
INSERT INTO sys_dict_data(dict_sort, dict_label, dict_value, dict_type, css_class, list_class, is_default, status, create_by, create_time, update_by, update_time, remark) VALUES (2, '中风险', 'MEDIUM_RISK', 'log_risk_level', NULL, NULL, 'N', '0', 'super', '2022-03-16 15:53:59', '', NULL, '中风险');
INSERT INTO sys_dict_data(dict_sort, dict_label, dict_value, dict_type, css_class, list_class, is_default, status, create_by, create_time, update_by, update_time, remark) VALUES (3, '低风险', 'LOW_RISK', 'log_risk_level', NULL, NULL, 'N', '0', 'super', '2022-03-16 15:54:22', '', NULL, '低风险');
INSERT INTO sys_dict_data(dict_sort, dict_label, dict_value, dict_type, css_class, list_class, is_default, status, create_by, create_time, update_by, update_time, remark) VALUES (4, '信息', 'INFORMATION', 'log_risk_level', NULL, NULL, 'N', '0', 'super', '2022-03-16 15:54:33', '', NULL, '信息');

-- 无流程角色配置
INSERT INTO sys_dict_type(dict_name, dict_type, status, create_by, create_time, update_by, update_time, remark)VALUES('无流程角色配置信息', 'no_process_roles', '0', 'super', '2022-03-21 16:58:39', '', NULL, NULL);

INSERT INTO sys_dict_data(dict_code, dict_sort, dict_label, dict_value, dict_type, css_class, list_class, is_default, status, create_by, create_time, update_by, update_time, remark)VALUES
(1, 'asset_modify', 'assetsChangeApproval', 'no_process_roles', NULL, NULL, 'N', '0', '', NULL, '', NULL, '资产变更角色配置'),
(2, 'alarm_whitelist', 'alarmWhitelistAudit', 'no_process_roles', NULL, NULL, 'N', '0', '', NULL, '', NULL, '告警白名单审核组'),
(3, 'vuln_whitelist', 'riskLeakWhitelistAudit', 'no_process_roles', NULL, NULL, 'N', '0', '', NULL, '', NULL, '漏洞白名单审核组');


INSERT INTO sys_dict_type(dict_name, dict_type, status, create_by, create_time, update_by, update_time, remark) VALUES ('引擎管理远程URL', 'engine_management_telnet_config', '0', 'super', '2022-03-16 15:53:20', '', NULL, '引擎管理连通性测试URL');

INSERT INTO sys_dict_data(dict_sort, dict_label, dict_value, dict_type, css_class, list_class, is_default, status, create_by, create_time, update_by, update_time, remark) VALUES
(1, 'ENGINE_URL', 'http://localhost', 'engine_management_telnet_config', NULL, NULL, 'N', '0', 'super', '2022-03-16 15:54:10', '', NULL, '');

