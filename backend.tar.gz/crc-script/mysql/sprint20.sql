--资产专属网
create table tb_asset_private_net(
  id bigint(20) not null auto_increment comment '主键id',
  dept_id bigint(20) default null comment '所属组织id',
  name varchar(64) comment '名称',
  sort_current_level int(11) not null default '0' comment '同级排序',
  remarks varchar(256) comment '备注',
  parent_id bigint(20) default 0 comment '父节点id',
  create_by varchar(64) default null comment '创建者',
  create_time datetime default null comment '创建时间',
  update_by varchar(64) default null comment '修改者',
  update_time datetime default null comment '修改时间',
  ancestors varchar(1024) default null comment '路径',
  del_flag tinyint(1) default '0' comment '删除标记(0正常 1删除)',
  primary key (id) using btree,
  key idx_dept_id (dept_id) using btree
) engine=innodb default charset=utf8 comment='资产专属网表';

--内置数据
insert into tb_asset_private_net(id, name, sort_current_level, parent_id, create_by, create_time, update_time)
values(1, '内网', 0 ,0, 'super', '2022-10-18 00:00:00', '2022-10-18 00:00:00');

--资产分组表
create table tb_asset_group(
  id bigint(20) not null auto_increment comment '主键id',
  dept_id bigint(20) not null comment '所属组织id',
  name varchar(64) comment '名称',
  sort_current_level int(11) not null default '0' comment '同级排序',
  remarks varchar(256) comment '备注',
  parent_id bigint(20) default 0 comment '父节点id',
  create_by varchar(64) default null comment '创建者',
  create_time datetime default null comment '创建时间',
  update_by varchar(64) default null comment '修改者',
  update_time datetime default null comment '修改时间',
  ancestors varchar(1024) default null comment '路径',
  del_flag tinyint(1) default '0' comment '删除标记(0正常 1删除)',
  primary key (id) using btree,
  key idx_dept_id (dept_id) using btree
) engine=innodb default charset=utf8 comment='资产分组表';