--菜单id修改为uuid
alter table sys_menu modify column menu_id varchar(32);
alter table sys_menu modify column parent_id varchar(32);
alter table sys_role_menu modify column menu_id varchar(32);
alter table custom_business_module modify column menu_id varchar(32);

--数据字典表新增字段
alter table sys_dict_type add column layout  varchar(100) COMMENT '字典形式，1 内置；2 扩展';
update sys_dict_type set layout='1';