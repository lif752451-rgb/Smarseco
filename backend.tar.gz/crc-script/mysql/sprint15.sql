--菜单增加删除标记
alter table sys_menu add del_flag char(1) DEFAULT '0' COMMENT '删除标志（0代表存在 2代表删除）';