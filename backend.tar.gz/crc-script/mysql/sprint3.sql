
-- 告警表添加所属单位相关字段
ALTER TABLE tb_alarm_report ADD affiliation_dept_node_id BIGINT NULL COMMENT '告警来源部门ID';
ALTER TABLE tb_alarm_report ADD affiliation_dept_name varchar(1024) NULL COMMENT '告警来源部门名称';
-- 告警白名单表新增所属单位相关字段
ALTER TABLE tb_alarm_whitelist ADD report_dept_node_id BIGINT NULL COMMENT '上报单位叶子节点ID';
ALTER TABLE tb_alarm_whitelist ADD report_dept_name varchar(1024) NULL COMMENT '上报单位';
-- 告警白名单表新增目的组织Id列表
ALTER TABLE tb_alarm_whitelist ADD dest_id varchar(512) NULL COMMENT '目的组织id列表';
-- 漏洞扫描任务表相关字段
ALTER TABLE tb_asset_vul_task ADD affiliation_dept_name varchar(1024) CHARACTER SET utf8 COLLATE utf8_general_ci NULL COMMENT '所属单位名称';
-- 漏洞闭环发起表单相关字段
ALTER TABLE tb_vuln_data ADD affiliation_dept_name varchar(1024) CHARACTER SET utf8 COLLATE utf8_general_ci NULL COMMENT '所属单位名称';
-- 统一修改组织结构名称字段长度
ALTER TABLE tb_asset MODIFY COLUMN affiliation_dept_name varchar(1024) CHARACTER SET utf8 COLLATE utf8_general_ci NULL COMMENT '所属单位名称';
ALTER TABLE tb_asset_segement MODIFY COLUMN affiliation_dept_name varchar(1024) CHARACTER SET utf8 COLLATE utf8_general_ci DEFAULT '' NULL COMMENT '所属单位名称';

-- AI研判字典值补充
INSERT INTO sys_dict_data (dict_sort,dict_label,dict_value,dict_type,css_class,list_class,is_default,status,create_by,create_time,update_by,update_time,remark) VALUES
	 (0,'一级','1','aicheck_risk_level',NULL,NULL,'N','0','super','2021-01-06 10:00:15','super','2021-12-30 15:10:48','{"aicheck":"75-100","等级":"一级","文字颜色":"#ED4014","背景颜色":"#FFF1F0"}'),
	 (1,'二级','2','aicheck_risk_level',NULL,NULL,'N','0','super','2021-01-06 10:00:15','super','2021-12-30 15:09:07','{"aicheck":"50-75","等级":"二级","文字颜色":"#FFA500","背景颜色":"#FFF6EC"}'),
	 (2,'三级','3','aicheck_risk_level',NULL,NULL,'N','0','super','2021-01-06 10:00:15','super','2021-02-19 15:43:26','{"aicheck":"25-50","等级":"三级","文字颜色":"#8074FF","背景颜色":"#F4F3FF"}'),
	 (3,'四级','4','aicheck_risk_level',NULL,NULL,'N','0','super','2021-01-06 10:00:15','super','2021-02-19 15:43:26','{"aicheck":"0-25","等级":"四级","文字颜色":"#267EE5","背景颜色":"#E6F7FF"}'),
	 (4,'未知','0','aicheck_risk_level',NULL,NULL,'N','0','super','2021-01-06 10:00:15','super','2021-12-29 17:45:07','{"aicheck":null,"等级":"未知","文字颜色":"#808695","背景颜色":"#F1F3F9"}');

-- 告警记录表添加索引
CREATE INDEX tb_alarm_record_business_key_IDX USING BTREE ON tb_alarm_record (business_key);

INSERT INTO sys_dict_type (dict_name,dict_type,status,create_by,create_time,update_by,update_time,remark) VALUES
	 ('告警来源IP匹配规则','user_ip_rule','0','super','2022-01-07 18:09:33','super','2022-01-07 18:13:29','告警来源IP匹配规则');

INSERT INTO sys_dict_data (dict_sort,dict_label,dict_value,dict_type,css_class,list_class,is_default,status,create_by,create_time,update_by,update_time,remark) VALUES
	 (1,'ip过滤规则1','10.','user_ip_rule',NULL,NULL,'N','0','super','2021-01-06 10:00:15','super','2021-12-29 17:45:07','ip过滤规则1'),
	 (2,'ip过滤规则2','192.168.','user_ip_rule',NULL,NULL,'N','0','super','2021-01-06 10:00:15','super','2021-12-29 17:45:07','ip过滤规则2');