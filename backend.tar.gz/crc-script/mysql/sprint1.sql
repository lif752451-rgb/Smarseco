alter table sys_dept modify column ancestors varchar(500);

alter table tb_asset add affiliation_dept_name varchar(200) COMMENT '附属部门名称';
alter table tb_asset add affiliation_dept_node_id bigint(20) COMMENT '附属部门叶子节点id';

ALTER TABLE tb_asset_segement ADD affiliation_dept_name varchar(200) CHARACTER SET utf8 COLLATE utf8_general_ci DEFAULT '' NULL COMMENT '所属单位名称';
ALTER TABLE tb_asset_segement ADD affiliation_dept_node_id bigint(20) NULL COMMENT '所属单位叶子节点id';
