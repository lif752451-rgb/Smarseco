#20220125 付壮志 tb_send_policy新增policy_code
ALTER TABLE tb_send_policy ADD COLUMN policy_code varchar(60) default null comment '策略code';
update tb_send_policy set policy_code = concat('SSP-A-P',id);
