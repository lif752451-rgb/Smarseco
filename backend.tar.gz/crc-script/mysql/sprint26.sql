#地铁漏洞
DROP TABLE IF EXISTS `tb_vuln_process_form`;
CREATE TABLE `tb_vuln_process_form` (
  `id` varchar(32) NOT NULL,
  `code` varchar(50) DEFAULT NULL COMMENT '漏洞编号',
  `category` char(1) DEFAULT NULL COMMENT '漏洞类别 1:主机漏洞 2：WEB漏洞 3：弱口令',
  `ip` varchar(256) DEFAULT NULL COMMENT 'IP/域名',
  `asset_name` varchar(1024) DEFAULT NULL COMMENT '资产名称',
  `affiliation_dept_name` varchar(1024) DEFAULT NULL COMMENT '所属单位名称',
  `affiliation_dept_node_id` bigint(20) DEFAULT NULL COMMENT '所属组织ID',
  `vuln_name` varchar(256) DEFAULT NULL COMMENT '漏洞名称',
  `description` text COMMENT '漏洞描述',
  `solution` text COMMENT '解决方案',
  `source` varchar(10) DEFAULT NULL COMMENT '漏洞来源 字典：vul_data_source 1-人工渗透',
  `level` varchar(5) DEFAULT '0' COMMENT '漏洞等级 字典：vul_level 0:低危, 漏洞等级 1:中危, 2:⾼危, 3:严重',
  `vuln_type` varchar(128) DEFAULT NULL COMMENT '漏洞类型',
  `cve_code` varchar(64) DEFAULT NULL COMMENT 'CVE编号',
  `first_time` datetime DEFAULT NULL COMMENT '首次发现时间',
  `recently_time` datetime DEFAULT NULL COMMENT '最近发现时间',
  `cnnvd` varchar(64) DEFAULT NULL COMMENT 'cnnvd',
  `cvss` varchar(64) DEFAULT NULL COMMENT 'cvss',
  `status` char(1) DEFAULT NULL COMMENT '状态 0：未修复 1：已修复',
  `is_push_status` char(1) DEFAULT '0' COMMENT '推送状态 0：未推送 1：已推送',
  `push_time` datetime DEFAULT NULL COMMENT '推送时间',
  `vul_features` varchar(16) DEFAULT NULL COMMENT '漏洞特征 1：存在EXP 2：存在POC 3：远程执行 4：本地提权 5：内核漏洞',
  `file_json` text COMMENT '附件',
  `publish_time` datetime DEFAULT NULL COMMENT '漏洞发布时间',
  `vul_host_influence` char(1) DEFAULT NULL COMMENT '漏洞修复影响 0:未知 1：无需重启 2：服务重启 3：系统重启',
  `available_condition` text COMMENT '利用条件',
  `affect_application` text COMMENT '影响应用',
  `valid_info` text COMMENT '验证信息',
  `ref_link` text COMMENT '参考链接',
  `create_by` varchar(64) DEFAULT NULL COMMENT '创建人',
  `create_by_label` varchar(64) DEFAULT NULL COMMENT '创建人Label',
  `create_time` datetime DEFAULT NULL COMMENT '创建时间',
  `update_by` varchar(64) DEFAULT NULL COMMENT '最后更新人',
  `update_time` datetime DEFAULT NULL COMMENT '最后更新时间',
  `del_flag` char(1) NOT NULL DEFAULT '0' COMMENT '删除标识(0 未删除 1 已删除)',
  `white_list_id` bigint(20) DEFAULT NULL COMMENT '白名单ID',
  `white_status` char(1) NOT NULL DEFAULT '0' COMMENT '漏洞加白状态 默认未加白 0：未加白 1：审核中 2：已加白',
  `repair_time` datetime DEFAULT NULL COMMENT '修复截止时间',
  `handle_person` varchar(32) DEFAULT NULL COMMENT '处置人',
  `handle_person_label` varchar(64) DEFAULT NULL COMMENT '处置人label',
  `is_send` char(1) DEFAULT '0' COMMENT '是否发送邮件 0：是 1：否',
  `cc_person` text COMMENT '抄送人',
  `engine_id` varchar(10) DEFAULT NULL COMMENT '引擎ID',
  PRIMARY KEY (`id`) USING BTREE,
  KEY `code` (`code`) USING BTREE,
  KEY `ip` (`ip`) USING BTREE,
  KEY `tb_dt_vuln_data_create_time_IDX` (`create_time`,`code`) USING BTREE,
  KEY `idx_vuln_white_list_id` (`white_list_id`),
  KEY `idx_handle_person` (`handle_person`,`handle_person_label`),
  KEY `idx_is_push_status` (`is_push_status`),
  KEY `idx_engine_id` (`engine_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC COMMENT='漏洞主表';

DROP TABLE IF EXISTS `tb_vuln_process_handle_business`;
CREATE TABLE `tb_vuln_process_handle_business` (
  `id` varchar(32) NOT NULL COMMENT '主键',
  `vuln_code` varchar(50) DEFAULT NULL COMMENT '漏洞编码',
  `last_start_user` varchar(50) DEFAULT NULL COMMENT '最近发起人',
  `last_start_user_label` varchar(64) DEFAULT NULL COMMENT '最近发起人label',
  `last_start_time` datetime DEFAULT NULL COMMENT '最近发起时间',
  `work_order_state` varchar(10) DEFAULT NULL COMMENT '工单状态（1.待处置，2.待审核，3.已归档，4.复查中）',
  `current_node_type` varchar(200) DEFAULT NULL COMMENT '当前进行节点类型',
  `current_node_operations` varchar(200) DEFAULT NULL COMMENT '当前进行节点处理人的角色',
  `current_deal_user` varchar(2048) DEFAULT NULL COMMENT '当前处理人',
  `current_deal_user_nick_name` varchar(2000) DEFAULT NULL COMMENT '当前处理人昵称',
  `vuln_repair_measures` varchar(2000) DEFAULT NULL COMMENT '漏洞修复措施',
  `skip_node` varchar(100) DEFAULT NULL COMMENT '跳过节点(多个用,分割)',
  `del_flag` varchar(1) NOT NULL DEFAULT '0' COMMENT '删除标识(0 未删除 1 已删除)',
  `create_by` varchar(64) DEFAULT NULL COMMENT '创建人',
  `create_by_label` varchar(64) DEFAULT NULL COMMENT '创建人label',
  `create_time` datetime DEFAULT NULL COMMENT '创建时间',
  `update_by` varchar(64) DEFAULT NULL COMMENT '最后更新人',
  `update_time` datetime DEFAULT NULL COMMENT '最后更新时间',
  PRIMARY KEY (`id`) USING BTREE,
  KEY `start_user` (`last_start_user`) USING BTREE,
  KEY `vuln_code` (`vuln_code`) USING BTREE,
  KEY `create_time` (`create_time`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC COMMENT='漏洞处置流程业务';

#domain字段和索引
ALTER TABLE tb_vuln_process_form ADD COLUMN `domain` VARCHAR(64) DEFAULT NULL COMMENT '漏洞是否修复的集合key';
ALTER TABLE `tb_vuln_process_form` ADD INDEX idx_domain ( `domain` );
ALTER TABLE tb_vuln_process_form ADD COLUMN `user_name` VARCHAR(128) DEFAULT NULL COMMENT '用户名';
ALTER TABLE tb_vuln_process_form ADD COLUMN `password` VARCHAR(512) DEFAULT NULL COMMENT '密码';
ALTER TABLE tb_vuln_process_form ADD COLUMN `port` VARCHAR(128) DEFAULT NULL COMMENT '端口';
ALTER TABLE tb_vuln_process_form ADD COLUMN `service` VARCHAR(128) DEFAULT NULL COMMENT '服务';


DROP TABLE IF EXISTS `tb_vuln_process_review_task`;
CREATE TABLE `tb_vuln_process_review_task` (
  `id` int(11) NOT NULL AUTO_INCREMENT COMMENT '主键',
  `vuln_code` varchar(50) DEFAULT NULL COMMENT '漏洞ID',
  `status` varchar(1) DEFAULT '0' COMMENT '待复查中默认0，开始复查1，复查完成2，复查失败3',
  `del_flag` varchar(1) DEFAULT '0' COMMENT '删除标识(0 未删除 1 已删除)',
  `create_by` varchar(64) DEFAULT NULL COMMENT '创建人(下发复查指令的账号)',
  `create_time` datetime DEFAULT NULL COMMENT '创建时间',
  `update_by` varchar(64) DEFAULT NULL COMMENT '修改人',
  `update_time` datetime DEFAULT NULL COMMENT '修改时间',
  PRIMARY KEY (`id`) USING BTREE,
  KEY `status` (`status`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC COMMENT='漏洞下发复查任务表';

DROP TABLE IF EXISTS `tb_vuln_process_handle_record`;
CREATE TABLE `tb_vuln_process_handle_record` (
  `id` int(11) NOT NULL AUTO_INCREMENT COMMENT '主键ID',
  `vuln_code` varchar(50) DEFAULT NULL COMMENT '漏洞编码',
  `node_type` varchar(32) DEFAULT NULL COMMENT '节点类型',
  `action_type` varchar(50) DEFAULT NULL COMMENT '动作',
  `deal_user` varchar(50) DEFAULT NULL COMMENT '处理人',
  `deal_user_label` varchar(50) DEFAULT NULL COMMENT '处理人label',
  `deal_time` datetime NOT NULL COMMENT '处理时间',
  `transfer_user` varchar(50) DEFAULT NULL COMMENT '转办人',
  `opinion` varchar(2000) DEFAULT NULL COMMENT '处置措施/审核意见/原因',
  `del_flag` varchar(1) DEFAULT '0' COMMENT '删除标识(0 未删除 1 已删除)',
  PRIMARY KEY (`id`) USING BTREE,
  KEY `deal_user` (`deal_user`) USING BTREE,
  KEY `code` (`vuln_code`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC COMMENT='漏洞操作记录表';

#主机漏洞去重规则字典

delete from `sys_dict_type` where `dict_type` = 'vul_de_duplication_host';
delete from `sys_dict_data` where `dict_type` = 'vul_de_duplication_host';
insert into `sys_dict_data` (`dict_code`, `dict_sort`, `dict_label`, `dict_value`, `dict_type`, `css_class`, `list_class`, `is_default`, `status`, `create_by`, `create_time`, `update_by`, `update_time`, `remark`) values(NULL,'1','IP/域名','ip','vul_de_duplication_host',NULL,NULL,NULL,'0','super',now(),'super',now(),'{\n    \"isDefault\": true,\n    \"isMust\": true\n}');
insert into `sys_dict_data` (`dict_code`, `dict_sort`, `dict_label`, `dict_value`, `dict_type`, `css_class`, `list_class`, `is_default`, `status`, `create_by`, `create_time`, `update_by`, `update_time`, `remark`) values(NULL,'2','漏洞名称','vulnName','vul_de_duplication_host',NULL,NULL,NULL,'0','super',now(),'super',now(),'{\n    \"isDefault\": true,\n    \"isMust\": true\n}');
insert into `sys_dict_data` (`dict_code`, `dict_sort`, `dict_label`, `dict_value`, `dict_type`, `css_class`, `list_class`, `is_default`, `status`, `create_by`, `create_time`, `update_by`, `update_time`, `remark`) values(NULL,'3','CVE','cveCode','vul_de_duplication_host',NULL,NULL,NULL,'0','super',now(),'super',now(),'{\n    \"isDefault\": true,\n    \"isMust\": false\n}');
insert into `sys_dict_data` (`dict_code`, `dict_sort`, `dict_label`, `dict_value`, `dict_type`, `css_class`, `list_class`, `is_default`, `status`, `create_by`, `create_time`, `update_by`, `update_time`, `remark`) values(NULL,'4','漏洞等级','level','vul_de_duplication_host',NULL,NULL,NULL,'0','super',now(),'super',now(),'{\n    \"isDefault\": true,\n    \"isMust\": false\n}');
insert into `sys_dict_data` (`dict_code`, `dict_sort`, `dict_label`, `dict_value`, `dict_type`, `css_class`, `list_class`, `is_default`, `status`, `create_by`, `create_time`, `update_by`, `update_time`, `remark`) values(NULL,'5','漏洞类型','vulnType','vul_de_duplication_host',NULL,NULL,NULL,'0','super',now(),'super',now(),'{\n    \"isDefault\": true,\n    \"isMust\": false\n}');

#WEB漏洞去重规则字典
delete from `sys_dict_type` where `dict_type` = 'vul_de_duplication_web';
delete from `sys_dict_data` where `dict_type` = 'vul_de_duplication_web';
insert into `sys_dict_data` (`dict_code`, `dict_sort`, `dict_label`, `dict_value`, `dict_type`, `css_class`, `list_class`, `is_default`, `status`, `create_by`, `create_time`, `update_by`, `update_time`, `remark`) values(NULL,'1','IP/域名','ip','vul_de_duplication_web',NULL,NULL,NULL,'0','super',now(),'super',now(),'{\n    \"isDefault\": true,\n    \"isMust\": true\n}');
insert into `sys_dict_data` (`dict_code`, `dict_sort`, `dict_label`, `dict_value`, `dict_type`, `css_class`, `list_class`, `is_default`, `status`, `create_by`, `create_time`, `update_by`, `update_time`, `remark`) values(NULL,'2','漏洞名称','vulnName','vul_de_duplication_web',NULL,NULL,NULL,'0','super',now(),'super',now(),'{\n    \"isDefault\": true,\n    \"isMust\": true\n}');
insert into `sys_dict_data` (`dict_code`, `dict_sort`, `dict_label`, `dict_value`, `dict_type`, `css_class`, `list_class`, `is_default`, `status`, `create_by`, `create_time`, `update_by`, `update_time`, `remark`) values(NULL,'3','漏洞等级','level','vul_de_duplication_web',NULL,NULL,NULL,'0','super',now(),'super',now(),'{\n    \"isDefault\": true,\n    \"isMust\": false\n}');
insert into `sys_dict_data` (`dict_code`, `dict_sort`, `dict_label`, `dict_value`, `dict_type`, `css_class`, `list_class`, `is_default`, `status`, `create_by`, `create_time`, `update_by`, `update_time`, `remark`) values(NULL,'4','漏洞类型','vulnType','vul_de_duplication_web',NULL,NULL,NULL,'0','super',now(),'super',now(),'{\n    \"isDefault\": true,\n    \"isMust\": false\n}');

#弱口令去重规则字典
delete from `sys_dict_type` where `dict_type` = 'vul_de_duplication_code';
delete from `sys_dict_data` where `dict_type` = 'vul_de_duplication_code';
insert into `sys_dict_data` (`dict_code`, `dict_sort`, `dict_label`, `dict_value`, `dict_type`, `css_class`, `list_class`, `is_default`, `status`, `create_by`, `create_time`, `update_by`, `update_time`, `remark`) values(NULL,'1','IP/域名','ip','vul_de_duplication_code',NULL,NULL,NULL,'0','super',now(),'super',now(),'{\n    \"isDefault\": true,\n    \"isMust\": true\n}');
insert into `sys_dict_data` (`dict_code`, `dict_sort`, `dict_label`, `dict_value`, `dict_type`, `css_class`, `list_class`, `is_default`, `status`, `create_by`, `create_time`, `update_by`, `update_time`, `remark`) values(NULL,'2','用户名','userName','vul_de_duplication_code',NULL,NULL,NULL,'0','super',now(),'super',now(),'{\n    \"isDefault\": true,\n    \"isMust\": true\n}');
insert into `sys_dict_data` (`dict_code`, `dict_sort`, `dict_label`, `dict_value`, `dict_type`, `css_class`, `list_class`, `is_default`, `status`, `create_by`, `create_time`, `update_by`, `update_time`, `remark`) values(NULL,'3','密码','password','vul_de_duplication_code',NULL,NULL,NULL,'0','super',now(),'super',now(),'{\n    \"isDefault\": true,\n    \"isMust\": false\n}');
insert into `sys_dict_data` (`dict_code`, `dict_sort`, `dict_label`, `dict_value`, `dict_type`, `css_class`, `list_class`, `is_default`, `status`, `create_by`, `create_time`, `update_by`, `update_time`, `remark`) values(NULL,'4','服务','service','vul_de_duplication_code',NULL,NULL,NULL,'0','super',now(),'super',now(),'{\n    \"isDefault\": true,\n    \"isMust\": false\n}');
insert into `sys_dict_data` (`dict_code`, `dict_sort`, `dict_label`, `dict_value`, `dict_type`, `css_class`, `list_class`, `is_default`, `status`, `create_by`, `create_time`, `update_by`, `update_time`, `remark`) values(NULL,'5','端口','port','vul_de_duplication_code',NULL,NULL,NULL,'0','super',now(),'super',now(),'{\n    \"isDefault\": true,\n    \"isMust\": false\n}');

DROP TABLE IF EXISTS `tb_vuln_process_distinct_rule`;
CREATE TABLE `tb_vuln_process_distinct_rule` (
  `id` int(11) NOT NULL AUTO_INCREMENT COMMENT '主键ID',
  `category` char(1) DEFAULT '1' COMMENT '漏洞类别 1:主机漏洞 2：WEB漏洞 3：弱口令',
  `fields` varchar(128) DEFAULT NULL COMMENT '去重字段',
  `create_by` varchar(64) DEFAULT NULL COMMENT '创建人',
  `create_time` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
  `update_by` varchar(64) DEFAULT NULL COMMENT '修改人',
  `update_time` datetime DEFAULT NULL ON UPDATE CURRENT_TIMESTAMP COMMENT '修改时间',
  `del_flag` char(1) NOT NULL DEFAULT '0' COMMENT '删除标识 0:未删除 1：已删除',
  PRIMARY KEY (`id`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC COMMENT='漏洞去重规则表';

#漏洞去重规则内置数据
delete from `tb_vuln_process_distinct_rule`;
insert into `tb_vuln_process_distinct_rule` (`id`, `category`, `fields`, `create_by`, `create_time`, `update_by`, `update_time`) values(NULL,'1','ip,vulnName,cveCode','super',now(),'(NULL)',NULL);
insert into `tb_vuln_process_distinct_rule` (`id`, `category`, `fields`, `create_by`, `create_time`, `update_by`, `update_time`) values(NULL,'2','ip,vulnName','super',now(),NULL,NULL);
insert into `tb_vuln_process_distinct_rule` (`id`, `category`, `fields`, `create_by`, `create_time`, `update_by`, `update_time`) values(NULL,'3','ip,userName,password,service','super',now(),NULL,NULL);

DROP TABLE IF EXISTS `tb_vuln_process_repair_cycle`;
CREATE TABLE `tb_vuln_process_repair_cycle` (
  `id` int(11) NOT NULL AUTO_INCREMENT COMMENT '主键ID',
  `category` char(1) NOT NULL DEFAULT '1' COMMENT '漏洞类别 1:主机漏洞 2：WEB漏洞 3：弱口令',
  `vul_level` char(1) DEFAULT NULL COMMENT '漏洞等级 字典：vul_level 0:低危, 漏洞等级 1:中危, 2:⾼危, 3:严重',
  `asset_level` char(1) DEFAULT NULL COMMENT '资产等级 1：普通 2：重要 3：核心',
  `day` int(11) DEFAULT NULL COMMENT '天数',
  `create_by` varchar(64) DEFAULT NULL COMMENT '创建人',
  `create_time` datetime DEFAULT NULL COMMENT '创建时间',
  `update_by` varchar(64) DEFAULT NULL COMMENT '修改人',
  `update_time` datetime DEFAULT NULL COMMENT '修改时间',
  `del_flag` char(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC COMMENT='漏洞修复周期表';

DROP TABLE IF EXISTS `tb_common_attachment`;
CREATE TABLE `tb_common_attachment` (
  `att_id` bigint(20) NOT NULL AUTO_INCREMENT COMMENT '主键ID',
  `business_id` varchar(100) DEFAULT NULL COMMENT '业务ID',
  `business_type` varchar(100) DEFAULT NULL COMMENT '业务类型',
  `file_name` varchar(1000) DEFAULT NULL COMMENT '附件名称',
  `url` varchar(1000) DEFAULT NULL COMMENT '附件链接',
  `del_flag` varchar(2) DEFAULT '0' COMMENT '删除标记(0正常 1删除)',
  `create_by` varchar(50) DEFAULT NULL COMMENT '创建人',
  `create_time` datetime DEFAULT NULL COMMENT '创建时间',
  `update_by` varchar(50) DEFAULT NULL COMMENT '修改人',
  `update_time` datetime DEFAULT NULL COMMENT '修改时间',
  PRIMARY KEY (`att_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='公共附件表';


#漏洞修复周期内置数据
delete from `tb_vuln_process_repair_cycle`;
insert into `tb_vuln_process_repair_cycle` (`category`, `vul_level`, `asset_level`, `day`, `create_by`, `create_time`, `update_by`, `update_time`, `del_flag`) values('1','0','1','90','super',now(),'super',now(),'0');
insert into `tb_vuln_process_repair_cycle` (`category`, `vul_level`, `asset_level`, `day`, `create_by`, `create_time`, `update_by`, `update_time`, `del_flag`) values('1','0','2','90','super',now(),'super',now(),'0');
insert into `tb_vuln_process_repair_cycle` (`category`, `vul_level`, `asset_level`, `day`, `create_by`, `create_time`, `update_by`, `update_time`, `del_flag`) values('1','0','3','60','super',now(),'super',now(),'0');
insert into `tb_vuln_process_repair_cycle` (`category`, `vul_level`, `asset_level`, `day`, `create_by`, `create_time`, `update_by`, `update_time`, `del_flag`) values('1','1','1','60','super',now(),'super',now(),'0');
insert into `tb_vuln_process_repair_cycle` (`category`, `vul_level`, `asset_level`, `day`, `create_by`, `create_time`, `update_by`, `update_time`, `del_flag`) values('1','1','2','60','super',now(),'super',now(),'0');
insert into `tb_vuln_process_repair_cycle` (`category`, `vul_level`, `asset_level`, `day`, `create_by`, `create_time`, `update_by`, `update_time`, `del_flag`) values('1','1','3','60','super',now(),'super',now(),'0');
insert into `tb_vuln_process_repair_cycle` (`category`, `vul_level`, `asset_level`, `day`, `create_by`, `create_time`, `update_by`, `update_time`, `del_flag`) values('1','2','1','14','super',now(),'super',now(),'0');
insert into `tb_vuln_process_repair_cycle` (`category`, `vul_level`, `asset_level`, `day`, `create_by`, `create_time`, `update_by`, `update_time`, `del_flag`) values('1','2','2','14','super',now(),'super',now(),'0');
insert into `tb_vuln_process_repair_cycle` (`category`, `vul_level`, `asset_level`, `day`, `create_by`, `create_time`, `update_by`, `update_time`, `del_flag`) values('1','2','3','14','super',now(),'super',now(),'0');
insert into `tb_vuln_process_repair_cycle` (`category`, `vul_level`, `asset_level`, `day`, `create_by`, `create_time`, `update_by`, `update_time`, `del_flag`) values('1','3','1','7','super',now(),'super',now(),'0');
insert into `tb_vuln_process_repair_cycle` (`category`, `vul_level`, `asset_level`, `day`, `create_by`, `create_time`, `update_by`, `update_time`, `del_flag`) values('1','3','2','7','super',now(),'super',now(),'0');
insert into `tb_vuln_process_repair_cycle` (`category`, `vul_level`, `asset_level`, `day`, `create_by`, `create_time`, `update_by`, `update_time`, `del_flag`) values('1','3','3','7','super',now(),'super',now(),'0');

insert into `tb_vuln_process_repair_cycle` (`category`, `vul_level`, `asset_level`, `day`, `create_by`, `create_time`, `update_by`, `update_time`, `del_flag`) values('2','0','1','90','super',now(),'super',now(),'0');
insert into `tb_vuln_process_repair_cycle` (`category`, `vul_level`, `asset_level`, `day`, `create_by`, `create_time`, `update_by`, `update_time`, `del_flag`) values('2','0','2','90','super',now(),'super',now(),'0');
insert into `tb_vuln_process_repair_cycle` (`category`, `vul_level`, `asset_level`, `day`, `create_by`, `create_time`, `update_by`, `update_time`, `del_flag`) values('2','0','3','60','super',now(),'super',now(),'0');
insert into `tb_vuln_process_repair_cycle` (`category`, `vul_level`, `asset_level`, `day`, `create_by`, `create_time`, `update_by`, `update_time`, `del_flag`) values('2','1','1','60','super',now(),'super',now(),'0');
insert into `tb_vuln_process_repair_cycle` (`category`, `vul_level`, `asset_level`, `day`, `create_by`, `create_time`, `update_by`, `update_time`, `del_flag`) values('2','1','2','60','super',now(),'super',now(),'0');
insert into `tb_vuln_process_repair_cycle` (`category`, `vul_level`, `asset_level`, `day`, `create_by`, `create_time`, `update_by`, `update_time`, `del_flag`) values('2','1','3','60','super',now(),'super',now(),'0');
insert into `tb_vuln_process_repair_cycle` (`category`, `vul_level`, `asset_level`, `day`, `create_by`, `create_time`, `update_by`, `update_time`, `del_flag`) values('2','2','1','14','super',now(),'super',now(),'0');
insert into `tb_vuln_process_repair_cycle` (`category`, `vul_level`, `asset_level`, `day`, `create_by`, `create_time`, `update_by`, `update_time`, `del_flag`) values('2','2','2','14','super',now(),'super',now(),'0');
insert into `tb_vuln_process_repair_cycle` (`category`, `vul_level`, `asset_level`, `day`, `create_by`, `create_time`, `update_by`, `update_time`, `del_flag`) values('2','2','3','14','super',now(),'super',now(),'0');
insert into `tb_vuln_process_repair_cycle` (`category`, `vul_level`, `asset_level`, `day`, `create_by`, `create_time`, `update_by`, `update_time`, `del_flag`) values('2','3','1','7','super',now(),'super',now(),'0');
insert into `tb_vuln_process_repair_cycle` (`category`, `vul_level`, `asset_level`, `day`, `create_by`, `create_time`, `update_by`, `update_time`, `del_flag`) values('2','3','2','7','super',now(),'super',now(),'0');
insert into `tb_vuln_process_repair_cycle` (`category`, `vul_level`, `asset_level`, `day`, `create_by`, `create_time`, `update_by`, `update_time`, `del_flag`) values('2','3','3','7','super',now(),'super',now(),'0');

INSERT INTO `tb_vuln_process_repair_cycle` (`category`, `vul_level`, `asset_level`, `day`, `create_by`, `create_time`, `update_by`, `update_time`, `del_flag`) VALUES('3',NULL,'1','7','super',NOW(),'super',NOW(),'0');
INSERT INTO `tb_vuln_process_repair_cycle` (`category`, `vul_level`, `asset_level`, `day`, `create_by`, `create_time`, `update_by`, `update_time`, `del_flag`) VALUES('3',NULL,'2','7','super',NOW(),'super',NOW(),'0');
INSERT INTO `tb_vuln_process_repair_cycle` (`category`, `vul_level`, `asset_level`, `day`, `create_by`, `create_time`, `update_by`, `update_time`, `del_flag`) VALUES('3',NULL,'3','7','super',NOW(),'super',NOW(),'0');

#主机漏洞导出字典
#未推送
delete from `sys_dict_type` where `dict_type` = 'vul_all_host_wait_export_excel';
delete from `sys_dict_data` where `dict_type` = 'vul_all_host_wait_export_excel';
insert into `sys_dict_type` (`dict_name`, `dict_type`, `status`, `create_by`, `create_time`, `update_by`, `update_time`, `remark`) values('主机漏洞待推送导出字典','vul_all_host_wait_export_excel','0','super',now(),'',NULL,NULL);

insert into `sys_dict_data` (`dict_sort`, `dict_label`, `dict_value`, `dict_type`, `css_class`, `list_class`, `is_default`, `status`, `create_by`, `create_time`, `update_by`, `update_time`, `remark`) values('1','漏洞ID','code','vul_all_host_wait_export_excel',NULL,NULL,'N','0','super',now(),'super',now(),'{ \"isDefault\": true, \"isMust\": false }');
insert into `sys_dict_data` (`dict_sort`, `dict_label`, `dict_value`, `dict_type`, `css_class`, `list_class`, `is_default`, `status`, `create_by`, `create_time`, `update_by`, `update_time`, `remark`) values('2','IP/域名','ip','vul_all_host_wait_export_excel',NULL,NULL,'N','0','super',now(),'super',now(),'{ \"isDefault\": true, \"isMust\": true }');
insert into `sys_dict_data` (`dict_sort`, `dict_label`, `dict_value`, `dict_type`, `css_class`, `list_class`, `is_default`, `status`, `create_by`, `create_time`, `update_by`, `update_time`, `remark`) values('3','所属组织','affiliationDeptName','vul_all_host_wait_export_excel',NULL,NULL,'N','0','super',now(),'super',now(),'{ \"isDefault\": true, \"isMust\": false }');
insert into `sys_dict_data` (`dict_sort`, `dict_label`, `dict_value`, `dict_type`, `css_class`, `list_class`, `is_default`, `status`, `create_by`, `create_time`, `update_by`, `update_time`, `remark`) values('4','资产名称','assetName','vul_all_host_wait_export_excel',NULL,NULL,'N','0','super',now(),'super',now(),'{ \"isDefault\": true, \"isMust\": false }');
insert into `sys_dict_data` (`dict_sort`, `dict_label`, `dict_value`, `dict_type`, `css_class`, `list_class`, `is_default`, `status`, `create_by`, `create_time`, `update_by`, `update_time`, `remark`) values('5','发布互联网','internetPublic','vul_all_host_wait_export_excel',NULL,NULL,'N','0','super',now(),'super',now(),'{ \"isDefault\": true, \"isMust\": false }');
insert into `sys_dict_data` (`dict_sort`, `dict_label`, `dict_value`, `dict_type`, `css_class`, `list_class`, `is_default`, `status`, `create_by`, `create_time`, `update_by`, `update_time`, `remark`) values('6','漏洞名称','vulnName','vul_all_host_wait_export_excel',NULL,NULL,'N','0','super',now(),'super',now(),'{ \"isDefault\": true, \"isMust\": true }');
insert into `sys_dict_data` (`dict_sort`, `dict_label`, `dict_value`, `dict_type`, `css_class`, `list_class`, `is_default`, `status`, `create_by`, `create_time`, `update_by`, `update_time`, `remark`) values('7','漏洞描述','description','vul_all_host_wait_export_excel',NULL,NULL,'N','0','super',now(),'super',now(),'{ \"isDefault\": false, \"isMust\": false }');
insert into `sys_dict_data` (`dict_sort`, `dict_label`, `dict_value`, `dict_type`, `css_class`, `list_class`, `is_default`, `status`, `create_by`, `create_time`, `update_by`, `update_time`, `remark`) values('8','解决方案','solution','vul_all_host_wait_export_excel',NULL,NULL,'N','0','super',now(),'super',now(),'{ \"isDefault\": false, \"isMust\": false }');
insert into `sys_dict_data` (`dict_sort`, `dict_label`, `dict_value`, `dict_type`, `css_class`, `list_class`, `is_default`, `status`, `create_by`, `create_time`, `update_by`, `update_time`, `remark`) values('9','来源','sourceLabel','vul_all_host_wait_export_excel',NULL,NULL,'N','0','super',now(),'super',now(),'{ \"isDefault\": true, \"isMust\": false }');
insert into `sys_dict_data` (`dict_sort`, `dict_label`, `dict_value`, `dict_type`, `css_class`, `list_class`, `is_default`, `status`, `create_by`, `create_time`, `update_by`, `update_time`, `remark`) values('10','漏洞等级','levelLabel','vul_all_host_wait_export_excel',NULL,NULL,'N','0','super',now(),'super',now(),'{ \"isDefault\": true, \"isMust\": false }');
insert into `sys_dict_data` (`dict_sort`, `dict_label`, `dict_value`, `dict_type`, `css_class`, `list_class`, `is_default`, `status`, `create_by`, `create_time`, `update_by`, `update_time`, `remark`) values('11','漏洞类型','vulnType','vul_all_host_wait_export_excel',NULL,NULL,'N','0','super',now(),'super',now(),'{ \"isDefault\": true, \"isMust\": false }');
insert into `sys_dict_data` (`dict_sort`, `dict_label`, `dict_value`, `dict_type`, `css_class`, `list_class`, `is_default`, `status`, `create_by`, `create_time`, `update_by`, `update_time`, `remark`) values('12','CVE','cveCode','vul_all_host_wait_export_excel',NULL,NULL,'N','0','super',now(),'super',now(),'{ \"isDefault\": true, \"isMust\": false }');
insert into `sys_dict_data` (`dict_sort`, `dict_label`, `dict_value`, `dict_type`, `css_class`, `list_class`, `is_default`, `status`, `create_by`, `create_time`, `update_by`, `update_time`, `remark`) values('13','CNNVD','cnnvd','vul_all_host_wait_export_excel',NULL,NULL,'N','0','super',now(),'super',now(),'{ \"isDefault\": false, \"isMust\": false }');
insert into `sys_dict_data` (`dict_sort`, `dict_label`, `dict_value`, `dict_type`, `css_class`, `list_class`, `is_default`, `status`, `create_by`, `create_time`, `update_by`, `update_time`, `remark`) values('14','CVSS','cvss','vul_all_host_wait_export_excel',NULL,NULL,'N','0','super',now(),'super',now(),'{ \"isDefault\": false, \"isMust\": false }');
insert into `sys_dict_data` (`dict_sort`, `dict_label`, `dict_value`, `dict_type`, `css_class`, `list_class`, `is_default`, `status`, `create_by`, `create_time`, `update_by`, `update_time`, `remark`) values('15','首次发现时间','firstTime','vul_all_host_wait_export_excel',NULL,NULL,'N','0','super',now(),'super',now(),'{ \"isDefault\": false, \"isMust\": false }');
insert into `sys_dict_data` (`dict_sort`, `dict_label`, `dict_value`, `dict_type`, `css_class`, `list_class`, `is_default`, `status`, `create_by`, `create_time`, `update_by`, `update_time`, `remark`) values('16','最近发现时间','recentlyTime','vul_all_host_wait_export_excel',NULL,NULL,'N','0','super',now(),'super',now(),'{ \"isDefault\": true, \"isMust\": false }');
insert into `sys_dict_data` (`dict_sort`, `dict_label`, `dict_value`, `dict_type`, `css_class`, `list_class`, `is_default`, `status`, `create_by`, `create_time`, `update_by`, `update_time`, `remark`) values('17','漏洞特征','vulFeaturesLabel','vul_all_host_wait_export_excel',NULL,NULL,'N','0','super',now(),'super',now(),'{ \"isDefault\": false, \"isMust\": false }');
insert into `sys_dict_data` (`dict_sort`, `dict_label`, `dict_value`, `dict_type`, `css_class`, `list_class`, `is_default`, `status`, `create_by`, `create_time`, `update_by`, `update_time`, `remark`) values('18','漏洞发布时间','publishTime','vul_all_host_wait_export_excel',NULL,NULL,'N','0','super',now(),'super',now(),'{ \"isDefault\": false, \"isMust\": false }');
insert into `sys_dict_data` (`dict_sort`, `dict_label`, `dict_value`, `dict_type`, `css_class`, `list_class`, `is_default`, `status`, `create_by`, `create_time`, `update_by`, `update_time`, `remark`) values('19','修复影响','vulHostInfluenceLabel','vul_all_host_wait_export_excel',NULL,NULL,'N','0','super',now(),'super',now(),'{ \"isDefault\": false, \"isMust\": false }');
insert into `sys_dict_data` (`dict_sort`, `dict_label`, `dict_value`, `dict_type`, `css_class`, `list_class`, `is_default`, `status`, `create_by`, `create_time`, `update_by`, `update_time`, `remark`) values('20','影响应用','affectApplication','vul_all_host_wait_export_excel',NULL,NULL,'N','0','super',now(),'super',now(),'{ \"isDefault\": false, \"isMust\": false }');
insert into `sys_dict_data` (`dict_sort`, `dict_label`, `dict_value`, `dict_type`, `css_class`, `list_class`, `is_default`, `status`, `create_by`, `create_time`, `update_by`, `update_time`, `remark`) values('21','利用条件','availableCondition','vul_all_host_wait_export_excel',NULL,NULL,'N','0','super',now(),'super',now(),'{ \"isDefault\": false, \"isMust\": false }');
insert into `sys_dict_data` (`dict_sort`, `dict_label`, `dict_value`, `dict_type`, `css_class`, `list_class`, `is_default`, `status`, `create_by`, `create_time`, `update_by`, `update_time`, `remark`) values('22','验证信息','validInfo','vul_all_host_wait_export_excel',NULL,NULL,'N','0','super',now(),'super',now(),'{ \"isDefault\": false, \"isMust\": false }');
insert into `sys_dict_data` (`dict_sort`, `dict_label`, `dict_value`, `dict_type`, `css_class`, `list_class`, `is_default`, `status`, `create_by`, `create_time`, `update_by`, `update_time`, `remark`) values('23','参考链接','refLink','vul_all_host_wait_export_excel',NULL,NULL,'N','0','super',now(),'super',now(),'{ \"isDefault\": false, \"isMust\": false }');
insert into `sys_dict_data` (`dict_sort`, `dict_label`, `dict_value`, `dict_type`, `css_class`, `list_class`, `is_default`, `status`, `create_by`, `create_time`, `update_by`, `update_time`, `remark`) values('24','处置人','handlePersonLabel','vul_all_host_wait_export_excel',NULL,NULL,'N','0','super',now(),'super',now(),'{ \"isDefault\": true, \"isMust\": false }');
insert into `sys_dict_data` (`dict_sort`, `dict_label`, `dict_value`, `dict_type`, `css_class`, `list_class`, `is_default`, `status`, `create_by`, `create_time`, `update_by`, `update_time`, `remark`) values('25','修复截止时间','repairTime','vul_all_host_wait_export_excel',NULL,NULL,'N','0','super',now(),'super',now(),'{ \"isDefault\": true, \"isMust\": false }');
insert into `sys_dict_data` (`dict_sort`, `dict_label`, `dict_value`, `dict_type`, `css_class`, `list_class`, `is_default`, `status`, `create_by`, `create_time`, `update_by`, `update_time`, `remark`) values('26','抄送人','ccPerson','vul_all_host_wait_export_excel',NULL,NULL,'N','0','super',now(),'super',now(),'{ \"isDefault\": false, \"isMust\": false }');
insert into `sys_dict_data` (`dict_sort`, `dict_label`, `dict_value`, `dict_type`, `css_class`, `list_class`, `is_default`, `status`, `create_by`, `create_time`, `update_by`, `update_time`, `remark`) values('27','提交人','createByLabel','vul_all_host_wait_export_excel',NULL,NULL,'N','0','super',now(),'super',now(),'{ \"isDefault\": true, \"isMust\": false }');
insert into `sys_dict_data` (`dict_sort`, `dict_label`, `dict_value`, `dict_type`, `css_class`, `list_class`, `is_default`, `status`, `create_by`, `create_time`, `update_by`, `update_time`, `remark`) values('28','提交时间','createTime','vul_all_host_wait_export_excel',NULL,NULL,'N','0','super',now(),'super',now(),'{ \"isDefault\": true, \"isMust\": false }');

#已推送
delete from `sys_dict_type` where `dict_type` = 'vul_all_host_done_export_excel';
delete from `sys_dict_data` where `dict_type` = 'vul_all_host_done_export_excel';
insert into `sys_dict_type` (`dict_name`, `dict_type`, `status`, `create_by`, `create_time`, `update_by`, `update_time`, `remark`) values('主机漏洞已推送导出字典','vul_all_host_done_export_excel','0','super',now(),'',NULL,NULL);

insert into `sys_dict_data` (`dict_sort`, `dict_label`, `dict_value`, `dict_type`, `css_class`, `list_class`, `is_default`, `status`, `create_by`, `create_time`, `update_by`, `update_time`, `remark`) values('1','漏洞ID','code','vul_all_host_done_export_excel',NULL,NULL,'N','0','super',now(),'super',now(),'{ \"isDefault\": true, \"isMust\": false }');
insert into `sys_dict_data` (`dict_sort`, `dict_label`, `dict_value`, `dict_type`, `css_class`, `list_class`, `is_default`, `status`, `create_by`, `create_time`, `update_by`, `update_time`, `remark`) values('2','IP/域名','ip','vul_all_host_done_export_excel',NULL,NULL,'N','0','super',now(),'super',now(),'{ \"isDefault\": true, \"isMust\": true }');
insert into `sys_dict_data` (`dict_sort`, `dict_label`, `dict_value`, `dict_type`, `css_class`, `list_class`, `is_default`, `status`, `create_by`, `create_time`, `update_by`, `update_time`, `remark`) values('3','所属组织','affiliationDeptName','vul_all_host_done_export_excel',NULL,NULL,'N','0','super',now(),'super',now(),'{ \"isDefault\": true, \"isMust\": false }');
insert into `sys_dict_data` (`dict_sort`, `dict_label`, `dict_value`, `dict_type`, `css_class`, `list_class`, `is_default`, `status`, `create_by`, `create_time`, `update_by`, `update_time`, `remark`) values('4','资产名称','assetName','vul_all_host_done_export_excel',NULL,NULL,'N','0','super',now(),'super',now(),'{ \"isDefault\": true, \"isMust\": false }');
insert into `sys_dict_data` (`dict_sort`, `dict_label`, `dict_value`, `dict_type`, `css_class`, `list_class`, `is_default`, `status`, `create_by`, `create_time`, `update_by`, `update_time`, `remark`) values('5','发布互联网','internetPublic','vul_all_host_done_export_excel',NULL,NULL,'N','0','super',now(),'super',now(),'{ \"isDefault\": true, \"isMust\": false }');
insert into `sys_dict_data` (`dict_sort`, `dict_label`, `dict_value`, `dict_type`, `css_class`, `list_class`, `is_default`, `status`, `create_by`, `create_time`, `update_by`, `update_time`, `remark`) values('6','漏洞名称','vulnName','vul_all_host_done_export_excel',NULL,NULL,'N','0','super',now(),'super',now(),'{ \"isDefault\": true, \"isMust\": true }');
insert into `sys_dict_data` (`dict_sort`, `dict_label`, `dict_value`, `dict_type`, `css_class`, `list_class`, `is_default`, `status`, `create_by`, `create_time`, `update_by`, `update_time`, `remark`) values('7','漏洞描述','description','vul_all_host_done_export_excel',NULL,NULL,'N','0','super',now(),'super',now(),'{ \"isDefault\": false, \"isMust\": false }');
insert into `sys_dict_data` (`dict_sort`, `dict_label`, `dict_value`, `dict_type`, `css_class`, `list_class`, `is_default`, `status`, `create_by`, `create_time`, `update_by`, `update_time`, `remark`) values('8','解决方案','solution','vul_all_host_done_export_excel',NULL,NULL,'N','0','super',now(),'super',now(),'{ \"isDefault\": false, \"isMust\": false }');
insert into `sys_dict_data` (`dict_sort`, `dict_label`, `dict_value`, `dict_type`, `css_class`, `list_class`, `is_default`, `status`, `create_by`, `create_time`, `update_by`, `update_time`, `remark`) values('9','来源','sourceLabel','vul_all_host_done_export_excel',NULL,NULL,'N','0','super',now(),'super',now(),'{ \"isDefault\": true, \"isMust\": false }');
insert into `sys_dict_data` (`dict_sort`, `dict_label`, `dict_value`, `dict_type`, `css_class`, `list_class`, `is_default`, `status`, `create_by`, `create_time`, `update_by`, `update_time`, `remark`) values('10','漏洞等级','levelLabel','vul_all_host_done_export_excel',NULL,NULL,'N','0','super',now(),'super',now(),'{ \"isDefault\": true, \"isMust\": false }');
insert into `sys_dict_data` (`dict_sort`, `dict_label`, `dict_value`, `dict_type`, `css_class`, `list_class`, `is_default`, `status`, `create_by`, `create_time`, `update_by`, `update_time`, `remark`) values('11','漏洞类型','vulnType','vul_all_host_done_export_excel',NULL,NULL,'N','0','super',now(),'super',now(),'{ \"isDefault\": true, \"isMust\": false }');
insert into `sys_dict_data` (`dict_sort`, `dict_label`, `dict_value`, `dict_type`, `css_class`, `list_class`, `is_default`, `status`, `create_by`, `create_time`, `update_by`, `update_time`, `remark`) values('12','CVE','cveCode','vul_all_host_done_export_excel',NULL,NULL,'N','0','super',now(),'super',now(),'{ \"isDefault\": true, \"isMust\": false }');
insert into `sys_dict_data` (`dict_sort`, `dict_label`, `dict_value`, `dict_type`, `css_class`, `list_class`, `is_default`, `status`, `create_by`, `create_time`, `update_by`, `update_time`, `remark`) values('13','CNNVD','cnnvd','vul_all_host_done_export_excel',NULL,NULL,'N','0','super',now(),'super',now(),'{ \"isDefault\": false, \"isMust\": false }');
insert into `sys_dict_data` (`dict_sort`, `dict_label`, `dict_value`, `dict_type`, `css_class`, `list_class`, `is_default`, `status`, `create_by`, `create_time`, `update_by`, `update_time`, `remark`) values('14','CVSS','cvss','vul_all_host_done_export_excel',NULL,NULL,'N','0','super',now(),'super',now(),'{ \"isDefault\": false, \"isMust\": false }');
insert into `sys_dict_data` (`dict_sort`, `dict_label`, `dict_value`, `dict_type`, `css_class`, `list_class`, `is_default`, `status`, `create_by`, `create_time`, `update_by`, `update_time`, `remark`) values('15','首次发现时间','firstTime','vul_all_host_done_export_excel',NULL,NULL,'N','0','super',now(),'super',now(),'{ \"isDefault\": false, \"isMust\": false }');
insert into `sys_dict_data` (`dict_sort`, `dict_label`, `dict_value`, `dict_type`, `css_class`, `list_class`, `is_default`, `status`, `create_by`, `create_time`, `update_by`, `update_time`, `remark`) values('16','最近发现时间','recentlyTime','vul_all_host_done_export_excel',NULL,NULL,'N','0','super',now(),'super',now(),'{ \"isDefault\": true, \"isMust\": false }');
insert into `sys_dict_data` (`dict_sort`, `dict_label`, `dict_value`, `dict_type`, `css_class`, `list_class`, `is_default`, `status`, `create_by`, `create_time`, `update_by`, `update_time`, `remark`) values('17','漏洞特征','vulFeaturesLabel','vul_all_host_done_export_excel',NULL,NULL,'N','0','super',now(),'super',now(),'{ \"isDefault\": false, \"isMust\": false }');
insert into `sys_dict_data` (`dict_sort`, `dict_label`, `dict_value`, `dict_type`, `css_class`, `list_class`, `is_default`, `status`, `create_by`, `create_time`, `update_by`, `update_time`, `remark`) values('18','漏洞发布时间','publishTime','vul_all_host_done_export_excel',NULL,NULL,'N','0','super',now(),'super',now(),'{ \"isDefault\": false, \"isMust\": false }');
insert into `sys_dict_data` (`dict_sort`, `dict_label`, `dict_value`, `dict_type`, `css_class`, `list_class`, `is_default`, `status`, `create_by`, `create_time`, `update_by`, `update_time`, `remark`) values('19','修复影响','vulHostInfluenceLabel','vul_all_host_done_export_excel',NULL,NULL,'N','0','super',now(),'super',now(),'{ \"isDefault\": false, \"isMust\": false }');
insert into `sys_dict_data` (`dict_sort`, `dict_label`, `dict_value`, `dict_type`, `css_class`, `list_class`, `is_default`, `status`, `create_by`, `create_time`, `update_by`, `update_time`, `remark`) values('20','影响应用','affectApplication','vul_all_host_done_export_excel',NULL,NULL,'N','0','super',now(),'super',now(),'{ \"isDefault\": false, \"isMust\": false }');
insert into `sys_dict_data` (`dict_sort`, `dict_label`, `dict_value`, `dict_type`, `css_class`, `list_class`, `is_default`, `status`, `create_by`, `create_time`, `update_by`, `update_time`, `remark`) values('21','利用条件','availableCondition','vul_all_host_done_export_excel',NULL,NULL,'N','0','super',now(),'super',now(),'{ \"isDefault\": false, \"isMust\": false }');
insert into `sys_dict_data` (`dict_sort`, `dict_label`, `dict_value`, `dict_type`, `css_class`, `list_class`, `is_default`, `status`, `create_by`, `create_time`, `update_by`, `update_time`, `remark`) values('22','验证信息','validInfo','vul_all_host_done_export_excel',NULL,NULL,'N','0','super',now(),'super',now(),'{ \"isDefault\": false, \"isMust\": false }');
insert into `sys_dict_data` (`dict_sort`, `dict_label`, `dict_value`, `dict_type`, `css_class`, `list_class`, `is_default`, `status`, `create_by`, `create_time`, `update_by`, `update_time`, `remark`) values('23','参考链接','refLink','vul_all_host_done_export_excel',NULL,NULL,'N','0','super',now(),'super',now(),'{ \"isDefault\": false, \"isMust\": false }');
insert into `sys_dict_data` (`dict_sort`, `dict_label`, `dict_value`, `dict_type`, `css_class`, `list_class`, `is_default`, `status`, `create_by`, `create_time`, `update_by`, `update_time`, `remark`) values('24','处置人','handlePersonLabel','vul_all_host_done_export_excel',NULL,NULL,'N','0','super',now(),'super',now(),'{ \"isDefault\": true, \"isMust\": false }');
insert into `sys_dict_data` (`dict_sort`, `dict_label`, `dict_value`, `dict_type`, `css_class`, `list_class`, `is_default`, `status`, `create_by`, `create_time`, `update_by`, `update_time`, `remark`) values('25','修复截止时间','repairTime','vul_all_host_done_export_excel',NULL,NULL,'N','0','super',now(),'super',now(),'{ \"isDefault\": true, \"isMust\": false }');
insert into `sys_dict_data` (`dict_sort`, `dict_label`, `dict_value`, `dict_type`, `css_class`, `list_class`, `is_default`, `status`, `create_by`, `create_time`, `update_by`, `update_time`, `remark`) values('26','抄送人','ccPerson','vul_all_host_done_export_excel',NULL,NULL,'N','0','super',now(),'super',now(),'{ \"isDefault\": false, \"isMust\": false }');
insert into `sys_dict_data` (`dict_sort`, `dict_label`, `dict_value`, `dict_type`, `css_class`, `list_class`, `is_default`, `status`, `create_by`, `create_time`, `update_by`, `update_time`, `remark`) values('27','提交人','createByLabel','vul_all_host_done_export_excel',NULL,NULL,'N','0','super',now(),'super',now(),'{ \"isDefault\": false, \"isMust\": false }');
insert into `sys_dict_data` (`dict_sort`, `dict_label`, `dict_value`, `dict_type`, `css_class`, `list_class`, `is_default`, `status`, `create_by`, `create_time`, `update_by`, `update_time`, `remark`) values('28','提交时间','createTime','vul_all_host_done_export_excel',NULL,NULL,'N','0','super',now(),'super',now(),'{ \"isDefault\": false, \"isMust\": false }');
insert into `sys_dict_data` (`dict_sort`, `dict_label`, `dict_value`, `dict_type`, `css_class`, `list_class`, `is_default`, `status`, `create_by`, `create_time`, `update_by`, `update_time`, `remark`) values('29','推送时间','pushTime','vul_all_host_done_export_excel',NULL,NULL,'N','0','super',now(),'super',now(),'{ \"isDefault\": true, \"isMust\": false }');
insert into `sys_dict_data` (`dict_sort`, `dict_label`, `dict_value`, `dict_type`, `css_class`, `list_class`, `is_default`, `status`, `create_by`, `create_time`, `update_by`, `update_time`, `remark`) values('30','工单状态','workOrderStateLabel','vul_all_host_done_export_excel',NULL,NULL,'N','0','super',now(),'super',now(),'{ \"isDefault\": true, \"isMust\": false }');

#漏洞类型字典
delete from `sys_dict_type` where `dict_type` = 'vul_host_type';
delete from `sys_dict_data` where `dict_type` = 'vul_host_type';
insert into `sys_dict_type` (`dict_name`, `dict_type`, `status`, `create_by`, `create_time`, `update_by`, `update_time`, `remark`) values('漏洞类型','vul_host_type','0','super',now(),'',NULL,NULL);

insert into `sys_dict_data` (`dict_sort`, `dict_label`, `dict_value`, `dict_type`, `css_class`, `list_class`, `is_default`, `status`, `create_by`, `create_time`, `update_by`, `update_time`, `remark`) values('0','SQL注入','0','vul_host_type',NULL,NULL,'N','0','super',now(),'',NULL,NULL);
insert into `sys_dict_data` (`dict_sort`, `dict_label`, `dict_value`, `dict_type`, `css_class`, `list_class`, `is_default`, `status`, `create_by`, `create_time`, `update_by`, `update_time`, `remark`) values('1','未授权访问','1','vul_host_type',NULL,NULL,'N','0','super',now(),'',NULL,NULL);
insert into `sys_dict_data` (`dict_sort`, `dict_label`, `dict_value`, `dict_type`, `css_class`, `list_class`, `is_default`, `status`, `create_by`, `create_time`, `update_by`, `update_time`, `remark`) values('2','敏感信息泄露','2','vul_host_type',NULL,NULL,'N','0','super',now(),'',NULL,NULL);
insert into `sys_dict_data` (`dict_sort`, `dict_label`, `dict_value`, `dict_type`, `css_class`, `list_class`, `is_default`, `status`, `create_by`, `create_time`, `update_by`, `update_time`, `remark`) values('3','XML外部实体注入','3','vul_host_type',NULL,NULL,'N','0','super',now(),'super',now(),NULL);
insert into `sys_dict_data` (`dict_sort`, `dict_label`, `dict_value`, `dict_type`, `css_class`, `list_class`, `is_default`, `status`, `create_by`, `create_time`, `update_by`, `update_time`, `remark`) values('4','跨站脚本攻击','4','vul_host_type',NULL,NULL,'N','0','super',now(),'super',now(),NULL);
insert into `sys_dict_data` (`dict_sort`, `dict_label`, `dict_value`, `dict_type`, `css_class`, `list_class`, `is_default`, `status`, `create_by`, `create_time`, `update_by`, `update_time`, `remark`) values('5','不安全的反序列','5','vul_host_type',NULL,NULL,'N','0','super',now(),'',NULL,NULL);
insert into `sys_dict_data` (`dict_sort`, `dict_label`, `dict_value`, `dict_type`, `css_class`, `list_class`, `is_default`, `status`, `create_by`, `create_time`, `update_by`, `update_time`, `remark`) values('6','客户端请求伪造','6','vul_host_type',NULL,NULL,'N','0','super',now(),'',NULL,NULL);
insert into `sys_dict_data` (`dict_sort`, `dict_label`, `dict_value`, `dict_type`, `css_class`, `list_class`, `is_default`, `status`, `create_by`, `create_time`, `update_by`, `update_time`, `remark`) values('7','服务端请求伪造','7','vul_host_type',NULL,NULL,'N','0','super',now(),'',NULL,NULL);
insert into `sys_dict_data` (`dict_sort`, `dict_label`, `dict_value`, `dict_type`, `css_class`, `list_class`, `is_default`, `status`, `create_by`, `create_time`, `update_by`, `update_time`, `remark`) values('8','命令执行','8','vul_host_type',NULL,NULL,'N','0','super',now(),'',NULL,NULL);
insert into `sys_dict_data` (`dict_sort`, `dict_label`, `dict_value`, `dict_type`, `css_class`, `list_class`, `is_default`, `status`, `create_by`, `create_time`, `update_by`, `update_time`, `remark`) values('9','代码执行','9','vul_host_type',NULL,NULL,'N','0','super',now(),'',NULL,NULL);
insert into `sys_dict_data` (`dict_sort`, `dict_label`, `dict_value`, `dict_type`, `css_class`, `list_class`, `is_default`, `status`, `create_by`, `create_time`, `update_by`, `update_time`, `remark`) values('10','任意文件上传','10','vul_host_type',NULL,NULL,'N','0','super',now(),'',NULL,NULL);
insert into `sys_dict_data` (`dict_sort`, `dict_label`, `dict_value`, `dict_type`, `css_class`, `list_class`, `is_default`, `status`, `create_by`, `create_time`, `update_by`, `update_time`, `remark`) values('11','任意文件读取','11','vul_host_type',NULL,NULL,'N','0','super',now(),'',NULL,NULL);
insert into `sys_dict_data` (`dict_sort`, `dict_label`, `dict_value`, `dict_type`, `css_class`, `list_class`, `is_default`, `status`, `create_by`, `create_time`, `update_by`, `update_time`, `remark`) values('12','拒绝服务攻击','12','vul_host_type',NULL,NULL,'N','0','super',now(),'',NULL,NULL);
insert into `sys_dict_data` (`dict_sort`, `dict_label`, `dict_value`, `dict_type`, `css_class`, `list_class`, `is_default`, `status`, `create_by`, `create_time`, `update_by`, `update_time`, `remark`) values('13','目录遍历','13','vul_host_type',NULL,NULL,'N','0','super',now(),'',NULL,NULL);
insert into `sys_dict_data` (`dict_sort`, `dict_label`, `dict_value`, `dict_type`, `css_class`, `list_class`, `is_default`, `status`, `create_by`, `create_time`, `update_by`, `update_time`, `remark`) values('14','恶意后门','14','vul_host_type',NULL,NULL,'N','0','super',now(),'',NULL,NULL);
insert into `sys_dict_data` (`dict_sort`, `dict_label`, `dict_value`, `dict_type`, `css_class`, `list_class`, `is_default`, `status`, `create_by`, `create_time`, `update_by`, `update_time`, `remark`) values('15','本地提权','15','vul_host_type',NULL,NULL,'N','0','super',now(),'',NULL,NULL);
insert into `sys_dict_data` (`dict_sort`, `dict_label`, `dict_value`, `dict_type`, `css_class`, `list_class`, `is_default`, `status`, `create_by`, `create_time`, `update_by`, `update_time`, `remark`) values('16','注入漏洞','16','vul_host_type',NULL,NULL,'N','0','super',now(),'',NULL,NULL);

#漏洞特征
delete from `sys_dict_type` where `dict_type` = 'vul_host_features';
delete from `sys_dict_data` where `dict_type` = 'vul_host_features';
insert into `sys_dict_type` (`dict_name`, `dict_type`, `status`, `create_by`, `create_time`, `update_by`, `update_time`, `remark`) values('漏洞特征','vul_host_features','0','super',now(),'',NULL,NULL);

insert into `sys_dict_data` (`dict_sort`, `dict_label`, `dict_value`, `dict_type`, `css_class`, `list_class`, `is_default`, `status`, `create_by`, `create_time`, `update_by`, `update_time`, `remark`) values('1','存在EXP','1','vul_host_features',NULL,NULL,'N','0','super',now(),'',NULL,NULL);
insert into `sys_dict_data` (`dict_sort`, `dict_label`, `dict_value`, `dict_type`, `css_class`, `list_class`, `is_default`, `status`, `create_by`, `create_time`, `update_by`, `update_time`, `remark`) values('2','存在POC','2','vul_host_features',NULL,NULL,'N','0','super',now(),'',NULL,NULL);
insert into `sys_dict_data` (`dict_sort`, `dict_label`, `dict_value`, `dict_type`, `css_class`, `list_class`, `is_default`, `status`, `create_by`, `create_time`, `update_by`, `update_time`, `remark`) values('3','远程执行','3','vul_host_features',NULL,NULL,'N','0','super',now(),'',NULL,NULL);
insert into `sys_dict_data` (`dict_sort`, `dict_label`, `dict_value`, `dict_type`, `css_class`, `list_class`, `is_default`, `status`, `create_by`, `create_time`, `update_by`, `update_time`, `remark`) values('4','本地提权','4','vul_host_features',NULL,NULL,'N','0','super',now(),'',NULL,NULL);
insert into `sys_dict_data` (`dict_sort`, `dict_label`, `dict_value`, `dict_type`, `css_class`, `list_class`, `is_default`, `status`, `create_by`, `create_time`, `update_by`, `update_time`, `remark`) values('5','内核漏洞','5','vul_host_features',NULL,NULL,'N','0','super',now(),'',NULL,NULL);

#漏洞修复影响
delete from `sys_dict_type` where `dict_type` = 'vul_host_influence';
delete from `sys_dict_data` where `dict_type` = 'vul_host_influence';
insert into `sys_dict_type` (`dict_name`, `dict_type`, `status`, `create_by`, `create_time`, `update_by`, `update_time`, `remark`) values('漏洞修复影响','vul_host_influence','0','super',now(),'',NULL,NULL);

insert into `sys_dict_data` (`dict_sort`, `dict_label`, `dict_value`, `dict_type`, `css_class`, `list_class`, `is_default`, `status`, `create_by`, `create_time`, `update_by`, `update_time`, `remark`) values('0','未知','0','vul_host_influence',NULL,NULL,'N','0','super',now(),'',NULL,NULL);
insert into `sys_dict_data` (`dict_sort`, `dict_label`, `dict_value`, `dict_type`, `css_class`, `list_class`, `is_default`, `status`, `create_by`, `create_time`, `update_by`, `update_time`, `remark`) values('1','无需重启','1','vul_host_influence',NULL,NULL,'N','0','super',now(),'',NULL,NULL);
insert into `sys_dict_data` (`dict_sort`, `dict_label`, `dict_value`, `dict_type`, `css_class`, `list_class`, `is_default`, `status`, `create_by`, `create_time`, `update_by`, `update_time`, `remark`) values('2','服务重启','2','vul_host_influence',NULL,NULL,'N','0','super',now(),'',NULL,NULL);
insert into `sys_dict_data` (`dict_sort`, `dict_label`, `dict_value`, `dict_type`, `css_class`, `list_class`, `is_default`, `status`, `create_by`, `create_time`, `update_by`, `update_time`, `remark`) values('3','系统重启','3','vul_host_influence',NULL,NULL,'N','0','super',now(),'',NULL,NULL);

#WEB漏洞导出
#待推送
delete from `sys_dict_type` where `dict_type` = 'vul_all_web_wait_export_excel';
delete from `sys_dict_data` where `dict_type` = 'vul_all_web_wait_export_excel';
insert into `sys_dict_type` (`dict_name`, `dict_type`, `status`, `create_by`, `create_time`, `update_by`, `update_time`, `remark`) values('漏洞_WEB漏洞_待推送导出','vul_all_web_wait_export_excel','0','super','2022-12-05 10:57:07','',NULL,NULL);

insert into `sys_dict_data` (`dict_sort`, `dict_label`, `dict_value`, `dict_type`, `css_class`, `list_class`, `is_default`, `status`, `create_by`, `create_time`, `update_by`, `update_time`, `remark`) values('1','漏洞ID','code','vul_all_web_wait_export_excel',NULL,NULL,NULL,'0','super',now(),'super',now(),'{ \"isDefault\": true, \"isMust\": false }');
insert into `sys_dict_data` (`dict_sort`, `dict_label`, `dict_value`, `dict_type`, `css_class`, `list_class`, `is_default`, `status`, `create_by`, `create_time`, `update_by`, `update_time`, `remark`) values('2','IP/域名','ip','vul_all_web_wait_export_excel',NULL,NULL,NULL,'0','super',now(),'super',now(),'{ \"isDefault\": true, \"isMust\": true }');
insert into `sys_dict_data` (`dict_sort`, `dict_label`, `dict_value`, `dict_type`, `css_class`, `list_class`, `is_default`, `status`, `create_by`, `create_time`, `update_by`, `update_time`, `remark`) values('3','所属组织','affiliationDeptName','vul_all_web_wait_export_excel',NULL,NULL,NULL,'0','super',now(),'super',now(),'{ \"isDefault\": true, \"isMust\": false }');
insert into `sys_dict_data` (`dict_sort`, `dict_label`, `dict_value`, `dict_type`, `css_class`, `list_class`, `is_default`, `status`, `create_by`, `create_time`, `update_by`, `update_time`, `remark`) values('4','资产名称','assetName','vul_all_web_wait_export_excel',NULL,NULL,NULL,'0','super',now(),'super',now(),'{ \"isDefault\": true, \"isMust\": false }');
insert into `sys_dict_data` (`dict_sort`, `dict_label`, `dict_value`, `dict_type`, `css_class`, `list_class`, `is_default`, `status`, `create_by`, `create_time`, `update_by`, `update_time`, `remark`) values('5','发布互联网','internetPublic','vul_all_web_wait_export_excel',NULL,NULL,NULL,'0','super',now(),'super',now(),'{ \"isDefault\": true, \"isMust\": false }');
insert into `sys_dict_data` (`dict_sort`, `dict_label`, `dict_value`, `dict_type`, `css_class`, `list_class`, `is_default`, `status`, `create_by`, `create_time`, `update_by`, `update_time`, `remark`) values('6','漏洞名称','vulnName','vul_all_web_wait_export_excel',NULL,NULL,NULL,'0','super',now(),'super',now(),'{ \"isDefault\": true, \"isMust\": true }');
insert into `sys_dict_data` (`dict_sort`, `dict_label`, `dict_value`, `dict_type`, `css_class`, `list_class`, `is_default`, `status`, `create_by`, `create_time`, `update_by`, `update_time`, `remark`) values('7','漏洞描述','description','vul_all_web_wait_export_excel',NULL,NULL,NULL,'0','super',now(),'super',now(),'{ \"isDefault\": false, \"isMust\": false }');
insert into `sys_dict_data` (`dict_sort`, `dict_label`, `dict_value`, `dict_type`, `css_class`, `list_class`, `is_default`, `status`, `create_by`, `create_time`, `update_by`, `update_time`, `remark`) values('8','解决方案','solution','vul_all_web_wait_export_excel',NULL,NULL,NULL,'0','super',now(),'super',now(),'{ \"isDefault\": false, \"isMust\": false }');
insert into `sys_dict_data` (`dict_sort`, `dict_label`, `dict_value`, `dict_type`, `css_class`, `list_class`, `is_default`, `status`, `create_by`, `create_time`, `update_by`, `update_time`, `remark`) values('9','来源','sourceLabel','vul_all_web_wait_export_excel',NULL,NULL,NULL,'0','super',now(),'super',now(),'{ \"isDefault\": true, \"isMust\": false }');
insert into `sys_dict_data` (`dict_sort`, `dict_label`, `dict_value`, `dict_type`, `css_class`, `list_class`, `is_default`, `status`, `create_by`, `create_time`, `update_by`, `update_time`, `remark`) values('10','漏洞等级','levelLabel','vul_all_web_wait_export_excel',NULL,NULL,NULL,'0','super',now(),'super',now(),'{ \"isDefault\": true, \"isMust\": false }');
insert into `sys_dict_data` (`dict_sort`, `dict_label`, `dict_value`, `dict_type`, `css_class`, `list_class`, `is_default`, `status`, `create_by`, `create_time`, `update_by`, `update_time`, `remark`) values('11','漏洞类型','vulnType','vul_all_web_wait_export_excel',NULL,NULL,NULL,'0','super',now(),'super',now(),'{ \"isDefault\": true, \"isMust\": false }');
insert into `sys_dict_data` (`dict_sort`, `dict_label`, `dict_value`, `dict_type`, `css_class`, `list_class`, `is_default`, `status`, `create_by`, `create_time`, `update_by`, `update_time`, `remark`) values('12','首次发现时间','firstTime','vul_all_web_wait_export_excel',NULL,NULL,NULL,'0','super',now(),'super',now(),'{ \"isDefault\": false, \"isMust\": false }');
insert into `sys_dict_data` (`dict_sort`, `dict_label`, `dict_value`, `dict_type`, `css_class`, `list_class`, `is_default`, `status`, `create_by`, `create_time`, `update_by`, `update_time`, `remark`) values('13','最近发现时间','recentlyTime','vul_all_web_wait_export_excel',NULL,NULL,NULL,'0','super',now(),'super',now(),'{ \"isDefault\": true, \"isMust\": false }');
insert into `sys_dict_data` (`dict_sort`, `dict_label`, `dict_value`, `dict_type`, `css_class`, `list_class`, `is_default`, `status`, `create_by`, `create_time`, `update_by`, `update_time`, `remark`) values('14','处置人','handlePersonLabel','vul_all_web_wait_export_excel',NULL,NULL,NULL,'0','super',now(),'super',now(),'{ \"isDefault\": true, \"isMust\": false }');
insert into `sys_dict_data` (`dict_sort`, `dict_label`, `dict_value`, `dict_type`, `css_class`, `list_class`, `is_default`, `status`, `create_by`, `create_time`, `update_by`, `update_time`, `remark`) values('15','修复截止时间','repairTime','vul_all_web_wait_export_excel',NULL,NULL,NULL,'0','super',now(),'super',now(),'{ \"isDefault\": true, \"isMust\": false }');
insert into `sys_dict_data` (`dict_sort`, `dict_label`, `dict_value`, `dict_type`, `css_class`, `list_class`, `is_default`, `status`, `create_by`, `create_time`, `update_by`, `update_time`, `remark`) values('16','抄送人','ccPerson','vul_all_web_wait_export_excel',NULL,NULL,NULL,'0','super',now(),'super',now(),'{ \"isDefault\": false, \"isMust\": false }');
insert into `sys_dict_data` (`dict_sort`, `dict_label`, `dict_value`, `dict_type`, `css_class`, `list_class`, `is_default`, `status`, `create_by`, `create_time`, `update_by`, `update_time`, `remark`) values('17','提交人','createByLabel','vul_all_web_wait_export_excel',NULL,NULL,NULL,'0','super',now(),'super',now(),'{ \"isDefault\": true, \"isMust\": false }');
insert into `sys_dict_data` (`dict_sort`, `dict_label`, `dict_value`, `dict_type`, `css_class`, `list_class`, `is_default`, `status`, `create_by`, `create_time`, `update_by`, `update_time`, `remark`) values('18','提交时间','createTime','vul_all_web_wait_export_excel',NULL,NULL,NULL,'0','super',now(),'super',now(),'{ \"isDefault\": true, \"isMust\": false }');

#已推送
delete from `sys_dict_type` where `dict_type` = 'vul_all_web_done_export_excel';
delete from `sys_dict_data` where `dict_type` = 'vul_all_web_done_export_excel';
insert into `sys_dict_type` (`dict_name`, `dict_type`, `status`, `create_by`, `create_time`, `update_by`, `update_time`, `remark`) values('漏洞_WEB漏洞_已推送导出','vul_all_web_done_export_excel','0','super','2022-12-05 10:57:07','',NULL,NULL);

insert into `sys_dict_data` (`dict_sort`, `dict_label`, `dict_value`, `dict_type`, `css_class`, `list_class`, `is_default`, `status`, `create_by`, `create_time`, `update_by`, `update_time`, `remark`) values('1','漏洞ID','code','vul_all_web_done_export_excel',NULL,NULL,NULL,'0','super',now(),'super',now(),'{ \"isDefault\": true, \"isMust\": false }');
insert into `sys_dict_data` (`dict_sort`, `dict_label`, `dict_value`, `dict_type`, `css_class`, `list_class`, `is_default`, `status`, `create_by`, `create_time`, `update_by`, `update_time`, `remark`) values('2','IP/域名','ip','vul_all_web_done_export_excel',NULL,NULL,NULL,'0','super',now(),'super',now(),'{ \"isDefault\": true, \"isMust\": true }');
insert into `sys_dict_data` (`dict_sort`, `dict_label`, `dict_value`, `dict_type`, `css_class`, `list_class`, `is_default`, `status`, `create_by`, `create_time`, `update_by`, `update_time`, `remark`) values('3','所属组织','affiliationDeptName','vul_all_web_done_export_excel',NULL,NULL,NULL,'0','super',now(),'super',now(),'{ \"isDefault\": true, \"isMust\": false }');
insert into `sys_dict_data` (`dict_sort`, `dict_label`, `dict_value`, `dict_type`, `css_class`, `list_class`, `is_default`, `status`, `create_by`, `create_time`, `update_by`, `update_time`, `remark`) values('4','资产名称','assetName','vul_all_web_done_export_excel',NULL,NULL,NULL,'0','super',now(),'super',now(),'{ \"isDefault\": true, \"isMust\": false }');
insert into `sys_dict_data` (`dict_sort`, `dict_label`, `dict_value`, `dict_type`, `css_class`, `list_class`, `is_default`, `status`, `create_by`, `create_time`, `update_by`, `update_time`, `remark`) values('5','发布互联网','internetPublic','vul_all_web_done_export_excel',NULL,NULL,NULL,'0','super',now(),'super',now(),'{ \"isDefault\": true, \"isMust\": false }');
insert into `sys_dict_data` (`dict_sort`, `dict_label`, `dict_value`, `dict_type`, `css_class`, `list_class`, `is_default`, `status`, `create_by`, `create_time`, `update_by`, `update_time`, `remark`) values('6','漏洞名称','vulnName','vul_all_web_done_export_excel',NULL,NULL,NULL,'0','super',now(),'super',now(),'{ \"isDefault\": true, \"isMust\": true }');
insert into `sys_dict_data` (`dict_sort`, `dict_label`, `dict_value`, `dict_type`, `css_class`, `list_class`, `is_default`, `status`, `create_by`, `create_time`, `update_by`, `update_time`, `remark`) values('7','漏洞描述','description','vul_all_web_done_export_excel',NULL,NULL,NULL,'0','super',now(),'super',now(),'{ \"isDefault\": false, \"isMust\": false }');
insert into `sys_dict_data` (`dict_sort`, `dict_label`, `dict_value`, `dict_type`, `css_class`, `list_class`, `is_default`, `status`, `create_by`, `create_time`, `update_by`, `update_time`, `remark`) values('8','解决方案','solution','vul_all_web_done_export_excel',NULL,NULL,NULL,'0','super',now(),'super',now(),'{ \"isDefault\": false, \"isMust\": false }');
insert into `sys_dict_data` (`dict_sort`, `dict_label`, `dict_value`, `dict_type`, `css_class`, `list_class`, `is_default`, `status`, `create_by`, `create_time`, `update_by`, `update_time`, `remark`) values('9','来源','sourceLabel','vul_all_web_done_export_excel',NULL,NULL,NULL,'0','super',now(),'super',now(),'{ \"isDefault\": true, \"isMust\": false }');
insert into `sys_dict_data` (`dict_sort`, `dict_label`, `dict_value`, `dict_type`, `css_class`, `list_class`, `is_default`, `status`, `create_by`, `create_time`, `update_by`, `update_time`, `remark`) values('10','漏洞等级','levelLabel','vul_all_web_done_export_excel',NULL,NULL,NULL,'0','super',now(),'super',now(),'{ \"isDefault\": true, \"isMust\": false }');
insert into `sys_dict_data` (`dict_sort`, `dict_label`, `dict_value`, `dict_type`, `css_class`, `list_class`, `is_default`, `status`, `create_by`, `create_time`, `update_by`, `update_time`, `remark`) values('11','漏洞类型','vulnType','vul_all_web_done_export_excel',NULL,NULL,NULL,'0','super',now(),'super',now(),'{ \"isDefault\": true, \"isMust\": false }');
insert into `sys_dict_data` (`dict_sort`, `dict_label`, `dict_value`, `dict_type`, `css_class`, `list_class`, `is_default`, `status`, `create_by`, `create_time`, `update_by`, `update_time`, `remark`) values('12','首次发现时间','firstTime','vul_all_web_done_export_excel',NULL,NULL,NULL,'0','super',now(),'super',now(),'{ \"isDefault\": false, \"isMust\": false }');
insert into `sys_dict_data` (`dict_sort`, `dict_label`, `dict_value`, `dict_type`, `css_class`, `list_class`, `is_default`, `status`, `create_by`, `create_time`, `update_by`, `update_time`, `remark`) values('13','最近发现时间','recentlyTime','vul_all_web_done_export_excel',NULL,NULL,NULL,'0','super',now(),'super',now(),'{ \"isDefault\": true, \"isMust\": false }');
insert into `sys_dict_data` (`dict_sort`, `dict_label`, `dict_value`, `dict_type`, `css_class`, `list_class`, `is_default`, `status`, `create_by`, `create_time`, `update_by`, `update_time`, `remark`) values('14','处置人','handlePersonLabel','vul_all_web_done_export_excel',NULL,NULL,NULL,'0','super',now(),'super',now(),'{ \"isDefault\": true, \"isMust\": false }');
insert into `sys_dict_data` (`dict_sort`, `dict_label`, `dict_value`, `dict_type`, `css_class`, `list_class`, `is_default`, `status`, `create_by`, `create_time`, `update_by`, `update_time`, `remark`) values('15','修复截止时间','repairTime','vul_all_web_done_export_excel',NULL,NULL,NULL,'0','super',now(),'super',now(),'{ \"isDefault\": true, \"isMust\": false }');
insert into `sys_dict_data` (`dict_sort`, `dict_label`, `dict_value`, `dict_type`, `css_class`, `list_class`, `is_default`, `status`, `create_by`, `create_time`, `update_by`, `update_time`, `remark`) values('16','抄送人','ccPerson','vul_all_web_done_export_excel',NULL,NULL,NULL,'0','super',now(),'super',now(),'{ \"isDefault\": false, \"isMust\": false }');
insert into `sys_dict_data` (`dict_sort`, `dict_label`, `dict_value`, `dict_type`, `css_class`, `list_class`, `is_default`, `status`, `create_by`, `create_time`, `update_by`, `update_time`, `remark`) values('17','提交人','createByLabel','vul_all_web_done_export_excel',NULL,NULL,NULL,'0','super',now(),'super',now(),'{ \"isDefault\": true, \"isMust\": false }');
insert into `sys_dict_data` (`dict_sort`, `dict_label`, `dict_value`, `dict_type`, `css_class`, `list_class`, `is_default`, `status`, `create_by`, `create_time`, `update_by`, `update_time`, `remark`) values('18','提交时间','createTime','vul_all_web_done_export_excel',NULL,NULL,NULL,'0','super',now(),'super',now(),'{ \"isDefault\": true, \"isMust\": false }');
insert into `sys_dict_data` (`dict_sort`, `dict_label`, `dict_value`, `dict_type`, `css_class`, `list_class`, `is_default`, `status`, `create_by`, `create_time`, `update_by`, `update_time`, `remark`) values('19','推送时间','pushTime','vul_all_web_done_export_excel',NULL,NULL,'N','0','super',now(),'super',now(),'{ \"isDefault\": true, \"isMust\": false }');
insert into `sys_dict_data` (`dict_sort`, `dict_label`, `dict_value`, `dict_type`, `css_class`, `list_class`, `is_default`, `status`, `create_by`, `create_time`, `update_by`, `update_time`, `remark`) values('20','工单状态','workOrderStateLabel','vul_all_web_done_export_excel',NULL,NULL,'N','0','super',now(),'super',now(),'{ \"isDefault\": true, \"isMust\": false }');

#来源字典
insert into `sys_dict_data` (`dict_sort`, `dict_label`, `dict_value`, `dict_type`, `css_class`, `list_class`, `is_default`, `status`, `create_by`, `create_time`, `update_by`, `update_time`, `remark`) values('99','告警发现','99','vul_data_source',NULL,NULL,'N','0','super',now(),'super',now(),NULL);
insert into `sys_dict_data` (`dict_sort`, `dict_label`, `dict_value`, `dict_type`, `css_class`, `list_class`, `is_default`, `status`, `create_by`, `create_time`, `update_by`, `update_time`, `remark`) values('100','人工渗透','100','vul_data_source',NULL,NULL,'N','0','super',now(),'super',now(),NULL);
insert into `sys_dict_data` (`dict_sort`, `dict_label`, `dict_value`, `dict_type`, `css_class`, `list_class`, `is_default`, `status`, `create_by`, `create_time`, `update_by`, `update_time`, `remark`) values('2','绿盟扫描器','2','vul_data_source',NULL,NULL,'N','0','super',now(),'',NULL,NULL);
insert into `sys_dict_data` (`dict_sort`, `dict_label`, `dict_value`, `dict_type`, `css_class`, `list_class`, `is_default`, `status`, `create_by`, `create_time`, `update_by`, `update_time`, `remark`) values('3','天融信扫描器','10','vul_data_source',NULL,NULL,'N','0','super',now(),'',NULL,NULL);
insert into `sys_dict_data` (`dict_sort`, `dict_label`, `dict_value`, `dict_type`, `css_class`, `list_class`, `is_default`, `status`, `create_by`, `create_time`, `update_by`, `update_time`, `remark`) values('4','华为扫描器','4','vul_data_source',NULL,NULL,'N','0','super',now(),'',NULL,NULL);

#字典：漏洞_漏洞闭环_时限通知配置：vul_loop_time_notice
delete from `sys_dict_type` where `dict_type` = 'vul_loop_time_notice';
delete from `sys_dict_data` where `dict_type` = 'vul_loop_time_notice';
insert into `sys_dict_type` (`dict_name`, `dict_type`, `status`, `create_by`, `create_time`, `update_by`, `update_time`, `remark`) values('漏洞_漏洞闭环_时限通知配置','vul_loop_time_notice','0','super','2022-12-05 10:57:07','',NULL,NULL);

insert into `sys_dict_data` (`dict_sort`, `dict_label`, `dict_value`, `dict_type`, `css_class`, `list_class`, `is_default`, `status`, `create_by`, `create_time`, `update_by`, `update_time`, `remark`) values('0','nearMailSwitch','1','vul_loop_time_notice',NULL,NULL,'N','0','super',now(),'',NULL,'临近提醒邮件通知开关 (0-关闭,1-开启)');
insert into `sys_dict_data` (`dict_sort`, `dict_label`, `dict_value`, `dict_type`, `css_class`, `list_class`, `is_default`, `status`, `create_by`, `create_time`, `update_by`, `update_time`, `remark`) values('0','nearNoticeTime','24','vul_loop_time_notice',NULL,NULL,'N','0','super',now(),'',NULL,'倒计时多长时间开始提醒 (单位为小时/h)');
insert into `sys_dict_data` (`dict_sort`, `dict_label`, `dict_value`, `dict_type`, `css_class`, `list_class`, `is_default`, `status`, `create_by`, `create_time`, `update_by`, `update_time`, `remark`) values('0','nearNoticeFrequency','12','vul_loop_time_notice',NULL,NULL,'N','0','super',now(),'',NULL,'临近截止时间提醒频率 (每*小时提醒一次)');
insert into `sys_dict_data` (`dict_sort`, `dict_label`, `dict_value`, `dict_type`, `css_class`, `list_class`, `is_default`, `status`, `create_by`, `create_time`, `update_by`, `update_time`, `remark`) values('0','overMailSwitch','1','vul_loop_time_notice',NULL,NULL,'N','0','super',now(),'',NULL,'超时提醒邮件通知开关 (0-关闭,1-开启)');
insert into `sys_dict_data` (`dict_sort`, `dict_label`, `dict_value`, `dict_type`, `css_class`, `list_class`, `is_default`, `status`, `create_by`, `create_time`, `update_by`, `update_time`, `remark`) values('0','overNoticeTime','24','vul_loop_time_notice',NULL,NULL,'N','0','super',now(),'',NULL,'超时多长时间开始提醒 (单位为小时/h)');
insert into `sys_dict_data` (`dict_sort`, `dict_label`, `dict_value`, `dict_type`, `css_class`, `list_class`, `is_default`, `status`, `create_by`, `create_time`, `update_by`, `update_time`, `remark`) values('0','overNoticeFrequency','12','vul_loop_time_notice',NULL,NULL,'N','0','super',now(),'',NULL,'超时提醒频率 (每*小时提醒一次)');

#字典：漏洞_WEB漏洞_漏洞类型：vul_web_type
delete from `sys_dict_type` where `dict_type` = 'vul_web_type';
delete from `sys_dict_data` where `dict_type` = 'vul_web_type';
insert into `sys_dict_type` (`dict_name`, `dict_type`, `status`, `create_by`, `create_time`, `update_by`, `update_time`, `remark`) values('漏洞_WEB漏洞_漏洞类型','vul_web_type','0','super',now(),'',NULL,NULL);

insert into `sys_dict_data` (`dict_sort`, `dict_label`, `dict_value`, `dict_type`, `css_class`, `list_class`, `is_default`, `status`, `create_by`, `create_time`, `update_by`, `update_time`, `remark`) values('0','失效的访问控制','0','vul_web_type',NULL,NULL,NULL,'0','super',now(),NULL,NULL,NULL);
insert into `sys_dict_data` (`dict_sort`, `dict_label`, `dict_value`, `dict_type`, `css_class`, `list_class`, `is_default`, `status`, `create_by`, `create_time`, `update_by`, `update_time`, `remark`) values('1','加密机制失效','1','vul_web_type',NULL,NULL,NULL,'0','super',now(),NULL,NULL,NULL);
insert into `sys_dict_data` (`dict_sort`, `dict_label`, `dict_value`, `dict_type`, `css_class`, `list_class`, `is_default`, `status`, `create_by`, `create_time`, `update_by`, `update_time`, `remark`) values('2','注入','2','vul_web_type',NULL,NULL,NULL,'0','super',now(),NULL,NULL,NULL);
insert into `sys_dict_data` (`dict_sort`, `dict_label`, `dict_value`, `dict_type`, `css_class`, `list_class`, `is_default`, `status`, `create_by`, `create_time`, `update_by`, `update_time`, `remark`) values('3','不安全设计','3','vul_web_type',NULL,NULL,NULL,'0','super',now(),NULL,NULL,NULL);
insert into `sys_dict_data` (`dict_sort`, `dict_label`, `dict_value`, `dict_type`, `css_class`, `list_class`, `is_default`, `status`, `create_by`, `create_time`, `update_by`, `update_time`, `remark`) values('4','安全配置错误','4','vul_web_type',NULL,NULL,NULL,'0','super',now(),NULL,NULL,NULL);
insert into `sys_dict_data` (`dict_sort`, `dict_label`, `dict_value`, `dict_type`, `css_class`, `list_class`, `is_default`, `status`, `create_by`, `create_time`, `update_by`, `update_time`, `remark`) values('5','自带缺陷和过时的组件','5','vul_web_type',NULL,NULL,NULL,'0','super',now(),NULL,NULL,NULL);
insert into `sys_dict_data` (`dict_sort`, `dict_label`, `dict_value`, `dict_type`, `css_class`, `list_class`, `is_default`, `status`, `create_by`, `create_time`, `update_by`, `update_time`, `remark`) values('6','身份识别和身份验证错误','6','vul_web_type',NULL,NULL,NULL,'0','super',now(),NULL,NULL,NULL);
insert into `sys_dict_data` (`dict_sort`, `dict_label`, `dict_value`, `dict_type`, `css_class`, `list_class`, `is_default`, `status`, `create_by`, `create_time`, `update_by`, `update_time`, `remark`) values('7','软件和数据完整性故障','7','vul_web_type',NULL,NULL,NULL,'0','super',now(),NULL,NULL,NULL);
insert into `sys_dict_data` (`dict_sort`, `dict_label`, `dict_value`, `dict_type`, `css_class`, `list_class`, `is_default`, `status`, `create_by`, `create_time`, `update_by`, `update_time`, `remark`) values('8','安全日志记录和监控失败','8','vul_web_type',NULL,NULL,NULL,'0','super',now(),NULL,NULL,NULL);
insert into `sys_dict_data` (`dict_sort`, `dict_label`, `dict_value`, `dict_type`, `css_class`, `list_class`, `is_default`, `status`, `create_by`, `create_time`, `update_by`, `update_time`, `remark`) values('9','服务器端请求伪造','9','vul_web_type',NULL,NULL,NULL,'0','super',now(),NULL,NULL,NULL);

#弱口令导出字典
#未推送
delete from `sys_dict_type` where `dict_type` = 'vul_all_code_wait_export_excel';
delete from `sys_dict_data` where `dict_type` = 'vul_all_code_wait_export_excel';
insert into `sys_dict_type` (`dict_name`, `dict_type`, `status`, `create_by`, `create_time`, `update_by`, `update_time`, `remark`) values('弱口令待推送导出字典','vul_all_code_wait_export_excel','0','super',now(),'',NULL,NULL);

insert into `sys_dict_data` (`dict_sort`, `dict_label`, `dict_value`, `dict_type`, `css_class`, `list_class`, `is_default`, `status`, `create_by`, `create_time`, `update_by`, `update_time`, `remark`) values('1','漏洞ID','code','vul_all_code_wait_export_excel',NULL,NULL,NULL,'0','super',now(),'super',now(),'{ \"isDefault\": true, \"isMust\": false }');
insert into `sys_dict_data` (`dict_sort`, `dict_label`, `dict_value`, `dict_type`, `css_class`, `list_class`, `is_default`, `status`, `create_by`, `create_time`, `update_by`, `update_time`, `remark`) values('2','IP/域名','ip','vul_all_code_wait_export_excel',NULL,NULL,NULL,'0','super',now(),'super',now(),'{ \"isDefault\": true, \"isMust\": true }');
insert into `sys_dict_data` (`dict_sort`, `dict_label`, `dict_value`, `dict_type`, `css_class`, `list_class`, `is_default`, `status`, `create_by`, `create_time`, `update_by`, `update_time`, `remark`) values('3','所属组织','affiliationDeptName','vul_all_code_wait_export_excel',NULL,NULL,NULL,'0','super',now(),'super',now(),'{ \"isDefault\": true, \"isMust\": false }');
insert into `sys_dict_data` (`dict_sort`, `dict_label`, `dict_value`, `dict_type`, `css_class`, `list_class`, `is_default`, `status`, `create_by`, `create_time`, `update_by`, `update_time`, `remark`) values('4','资产名称','assetName','vul_all_code_wait_export_excel',NULL,NULL,NULL,'0','super',now(),'super',now(),'{ \"isDefault\": true, \"isMust\": false }');
insert into `sys_dict_data` (`dict_sort`, `dict_label`, `dict_value`, `dict_type`, `css_class`, `list_class`, `is_default`, `status`, `create_by`, `create_time`, `update_by`, `update_time`, `remark`) values('5','发布互联网','internetPublic','vul_all_code_wait_export_excel',NULL,NULL,NULL,'0','super',now(),'super',now(),'{ \"isDefault\": true, \"isMust\": false }');
insert into `sys_dict_data` (`dict_sort`, `dict_label`, `dict_value`, `dict_type`, `css_class`, `list_class`, `is_default`, `status`, `create_by`, `create_time`, `update_by`, `update_time`, `remark`) values('6','来源','sourceLabel','vul_all_code_wait_export_excel',NULL,NULL,NULL,'0','super',now(),'super',now(),'{ \"isDefault\": true, \"isMust\": false }');
insert into `sys_dict_data` (`dict_sort`, `dict_label`, `dict_value`, `dict_type`, `css_class`, `list_class`, `is_default`, `status`, `create_by`, `create_time`, `update_by`, `update_time`, `remark`) values('7','用户名','userName','vul_all_code_wait_export_excel',NULL,NULL,NULL,'0','super',now(),'super',now(),'{ \"isDefault\": true, \"isMust\": false }');
insert into `sys_dict_data` (`dict_sort`, `dict_label`, `dict_value`, `dict_type`, `css_class`, `list_class`, `is_default`, `status`, `create_by`, `create_time`, `update_by`, `update_time`, `remark`) values('8','密码','password','vul_all_code_wait_export_excel',NULL,NULL,NULL,'0','super',now(),'super',now(),'{ \"isDefault\": false, \"isMust\": false }');
insert into `sys_dict_data` (`dict_sort`, `dict_label`, `dict_value`, `dict_type`, `css_class`, `list_class`, `is_default`, `status`, `create_by`, `create_time`, `update_by`, `update_time`, `remark`) values('9','端口','port','vul_all_code_wait_export_excel',NULL,NULL,NULL,'0','super',now(),'super',now(),'{ \"isDefault\": true, \"isMust\": false }');
insert into `sys_dict_data` (`dict_sort`, `dict_label`, `dict_value`, `dict_type`, `css_class`, `list_class`, `is_default`, `status`, `create_by`, `create_time`, `update_by`, `update_time`, `remark`) values('10','服务','service','vul_all_code_wait_export_excel',NULL,NULL,NULL,'0','super',now(),'super',now(),'{ \"isDefault\": true, \"isMust\": false }');
insert into `sys_dict_data` (`dict_sort`, `dict_label`, `dict_value`, `dict_type`, `css_class`, `list_class`, `is_default`, `status`, `create_by`, `create_time`, `update_by`, `update_time`, `remark`) values('11','首次发现时间','firstTime','vul_all_code_wait_export_excel',NULL,NULL,NULL,'0','super',now(),'super',now(),'{ \"isDefault\": false, \"isMust\": false }');
insert into `sys_dict_data` (`dict_sort`, `dict_label`, `dict_value`, `dict_type`, `css_class`, `list_class`, `is_default`, `status`, `create_by`, `create_time`, `update_by`, `update_time`, `remark`) values('12','最近发现时间','recentlyTime','vul_all_code_wait_export_excel',NULL,NULL,NULL,'0','super',now(),'super',now(),'{ \"isDefault\": true, \"isMust\": false }');
insert into `sys_dict_data` (`dict_sort`, `dict_label`, `dict_value`, `dict_type`, `css_class`, `list_class`, `is_default`, `status`, `create_by`, `create_time`, `update_by`, `update_time`, `remark`) values('13','漏洞描述','description','vul_all_code_wait_export_excel',NULL,NULL,NULL,'0','super',now(),'super',now(),'{ \"isDefault\": false, \"isMust\": false }');
insert into `sys_dict_data` (`dict_sort`, `dict_label`, `dict_value`, `dict_type`, `css_class`, `list_class`, `is_default`, `status`, `create_by`, `create_time`, `update_by`, `update_time`, `remark`) values('14','解决方案','solution','vul_all_code_wait_export_excel',NULL,NULL,NULL,'0','super',now(),'super',now(),'{ \"isDefault\": false, \"isMust\": false }');
insert into `sys_dict_data` (`dict_sort`, `dict_label`, `dict_value`, `dict_type`, `css_class`, `list_class`, `is_default`, `status`, `create_by`, `create_time`, `update_by`, `update_time`, `remark`) values('15','处置人','handlePersonLabel','vul_all_code_wait_export_excel',NULL,NULL,NULL,'0','super',now(),'super',now(),'{ \"isDefault\": true, \"isMust\": false }');
insert into `sys_dict_data` (`dict_sort`, `dict_label`, `dict_value`, `dict_type`, `css_class`, `list_class`, `is_default`, `status`, `create_by`, `create_time`, `update_by`, `update_time`, `remark`) values('16','修复截止时间','repairTime','vul_all_code_wait_export_excel',NULL,NULL,NULL,'0','super',now(),'super',now(),'{ \"isDefault\": true, \"isMust\": false }');
insert into `sys_dict_data` (`dict_sort`, `dict_label`, `dict_value`, `dict_type`, `css_class`, `list_class`, `is_default`, `status`, `create_by`, `create_time`, `update_by`, `update_time`, `remark`) values('17','抄送人','ccPerson','vul_all_code_wait_export_excel',NULL,NULL,NULL,'0','super',now(),'super',now(),'{ \"isDefault\": false, \"isMust\": false }');
insert into `sys_dict_data` (`dict_sort`, `dict_label`, `dict_value`, `dict_type`, `css_class`, `list_class`, `is_default`, `status`, `create_by`, `create_time`, `update_by`, `update_time`, `remark`) values('18','提交人','createByLabel','vul_all_code_wait_export_excel',NULL,NULL,NULL,'0','super',now(),'super',now(),'{ \"isDefault\": true, \"isMust\": false }');
insert into `sys_dict_data` (`dict_sort`, `dict_label`, `dict_value`, `dict_type`, `css_class`, `list_class`, `is_default`, `status`, `create_by`, `create_time`, `update_by`, `update_time`, `remark`) values('19','提交时间','createTime','vul_all_code_wait_export_excel',NULL,NULL,NULL,'0','super',now(),'super',now(),'{ \"isDefault\": true, \"isMust\": false }');

#已推送
delete from `sys_dict_type` where `dict_type` = 'vul_all_code_done_export_excel';
delete from `sys_dict_data` where `dict_type` = 'vul_all_code_done_export_excel';
insert into `sys_dict_type` (`dict_name`, `dict_type`, `status`, `create_by`, `create_time`, `update_by`, `update_time`, `remark`) values('弱口令已推送导出字典','vul_all_code_done_export_excel','0','super',now(),'',NULL,NULL);

insert into `sys_dict_data` (`dict_sort`, `dict_label`, `dict_value`, `dict_type`, `css_class`, `list_class`, `is_default`, `status`, `create_by`, `create_time`, `update_by`, `update_time`, `remark`) values('1','漏洞ID','code','vul_all_code_done_export_excel',NULL,NULL,NULL,'0','super',now(),'super',now(),'{ \"isDefault\": true, \"isMust\": false }');
insert into `sys_dict_data` (`dict_sort`, `dict_label`, `dict_value`, `dict_type`, `css_class`, `list_class`, `is_default`, `status`, `create_by`, `create_time`, `update_by`, `update_time`, `remark`) values('2','IP/域名','ip','vul_all_code_done_export_excel',NULL,NULL,NULL,'0','super',now(),'super',now(),'{ \"isDefault\": true, \"isMust\": true }');
insert into `sys_dict_data` (`dict_sort`, `dict_label`, `dict_value`, `dict_type`, `css_class`, `list_class`, `is_default`, `status`, `create_by`, `create_time`, `update_by`, `update_time`, `remark`) values('3','所属组织','affiliationDeptName','vul_all_code_done_export_excel',NULL,NULL,NULL,'0','super',now(),'super',now(),'{ \"isDefault\": true, \"isMust\": false }');
insert into `sys_dict_data` (`dict_sort`, `dict_label`, `dict_value`, `dict_type`, `css_class`, `list_class`, `is_default`, `status`, `create_by`, `create_time`, `update_by`, `update_time`, `remark`) values('4','资产名称','assetName','vul_all_code_done_export_excel',NULL,NULL,NULL,'0','super',now(),'super',now(),'{ \"isDefault\": true, \"isMust\": false }');
insert into `sys_dict_data` (`dict_sort`, `dict_label`, `dict_value`, `dict_type`, `css_class`, `list_class`, `is_default`, `status`, `create_by`, `create_time`, `update_by`, `update_time`, `remark`) values('5','发布互联网','internetPublic','vul_all_code_done_export_excel',NULL,NULL,NULL,'0','super',now(),'super',now(),'{ \"isDefault\": true, \"isMust\": false }');
insert into `sys_dict_data` (`dict_sort`, `dict_label`, `dict_value`, `dict_type`, `css_class`, `list_class`, `is_default`, `status`, `create_by`, `create_time`, `update_by`, `update_time`, `remark`) values('6','来源','sourceLabel','vul_all_code_done_export_excel',NULL,NULL,NULL,'0','super',now(),'super',now(),'{ \"isDefault\": true, \"isMust\": false }');
insert into `sys_dict_data` (`dict_sort`, `dict_label`, `dict_value`, `dict_type`, `css_class`, `list_class`, `is_default`, `status`, `create_by`, `create_time`, `update_by`, `update_time`, `remark`) values('7','用户名','userName','vul_all_code_done_export_excel',NULL,NULL,NULL,'0','super',now(),'super',now(),'{ \"isDefault\": true, \"isMust\": false }');
insert into `sys_dict_data` (`dict_sort`, `dict_label`, `dict_value`, `dict_type`, `css_class`, `list_class`, `is_default`, `status`, `create_by`, `create_time`, `update_by`, `update_time`, `remark`) values('8','密码','password','vul_all_code_done_export_excel',NULL,NULL,NULL,'0','super',now(),'super',now(),'{ \"isDefault\": false, \"isMust\": false }');
insert into `sys_dict_data` (`dict_sort`, `dict_label`, `dict_value`, `dict_type`, `css_class`, `list_class`, `is_default`, `status`, `create_by`, `create_time`, `update_by`, `update_time`, `remark`) values('9','端口','port','vul_all_code_done_export_excel',NULL,NULL,NULL,'0','super',now(),'super',now(),'{ \"isDefault\": true, \"isMust\": false }');
insert into `sys_dict_data` (`dict_sort`, `dict_label`, `dict_value`, `dict_type`, `css_class`, `list_class`, `is_default`, `status`, `create_by`, `create_time`, `update_by`, `update_time`, `remark`) values('10','服务','service','vul_all_code_done_export_excel',NULL,NULL,NULL,'0','super',now(),'super',now(),'{ \"isDefault\": true, \"isMust\": false }');
insert into `sys_dict_data` (`dict_sort`, `dict_label`, `dict_value`, `dict_type`, `css_class`, `list_class`, `is_default`, `status`, `create_by`, `create_time`, `update_by`, `update_time`, `remark`) values('11','首次发现时间','firstTime','vul_all_code_done_export_excel',NULL,NULL,NULL,'0','super',now(),'super',now(),'{ \"isDefault\": false, \"isMust\": false }');
insert into `sys_dict_data` (`dict_sort`, `dict_label`, `dict_value`, `dict_type`, `css_class`, `list_class`, `is_default`, `status`, `create_by`, `create_time`, `update_by`, `update_time`, `remark`) values('12','最近发现时间','recentlyTime','vul_all_code_done_export_excel',NULL,NULL,NULL,'0','super',now(),'super',now(),'{ \"isDefault\": true, \"isMust\": false }');
insert into `sys_dict_data` (`dict_sort`, `dict_label`, `dict_value`, `dict_type`, `css_class`, `list_class`, `is_default`, `status`, `create_by`, `create_time`, `update_by`, `update_time`, `remark`) values('13','漏洞描述','description','vul_all_code_done_export_excel',NULL,NULL,NULL,'0','super',now(),'super',now(),'{ \"isDefault\": false, \"isMust\": false }');
insert into `sys_dict_data` (`dict_sort`, `dict_label`, `dict_value`, `dict_type`, `css_class`, `list_class`, `is_default`, `status`, `create_by`, `create_time`, `update_by`, `update_time`, `remark`) values('14','解决方案','solution','vul_all_code_done_export_excel',NULL,NULL,NULL,'0','super',now(),'super',now(),'{ \"isDefault\": false, \"isMust\": false }');
insert into `sys_dict_data` (`dict_sort`, `dict_label`, `dict_value`, `dict_type`, `css_class`, `list_class`, `is_default`, `status`, `create_by`, `create_time`, `update_by`, `update_time`, `remark`) values('15','处置人','handlePersonLabel','vul_all_code_done_export_excel',NULL,NULL,NULL,'0','super',now(),'super',now(),'{ \"isDefault\": true, \"isMust\": false }');
insert into `sys_dict_data` (`dict_sort`, `dict_label`, `dict_value`, `dict_type`, `css_class`, `list_class`, `is_default`, `status`, `create_by`, `create_time`, `update_by`, `update_time`, `remark`) values('16','修复截止时间','repairTime','vul_all_code_done_export_excel',NULL,NULL,NULL,'0','super',now(),'super',now(),'{ \"isDefault\": true, \"isMust\": false }');
insert into `sys_dict_data` (`dict_sort`, `dict_label`, `dict_value`, `dict_type`, `css_class`, `list_class`, `is_default`, `status`, `create_by`, `create_time`, `update_by`, `update_time`, `remark`) values('17','抄送人','ccPerson','vul_all_code_done_export_excel',NULL,NULL,NULL,'0','super',now(),'super',now(),'{ \"isDefault\": false, \"isMust\": false }');
insert into `sys_dict_data` (`dict_sort`, `dict_label`, `dict_value`, `dict_type`, `css_class`, `list_class`, `is_default`, `status`, `create_by`, `create_time`, `update_by`, `update_time`, `remark`) values('18','提交人','createByLabel','vul_all_code_done_export_excel',NULL,NULL,NULL,'0','super',now(),'super',now(),'{ \"isDefault\": true, \"isMust\": false }');
insert into `sys_dict_data` (`dict_sort`, `dict_label`, `dict_value`, `dict_type`, `css_class`, `list_class`, `is_default`, `status`, `create_by`, `create_time`, `update_by`, `update_time`, `remark`) values('19','提交时间','createTime','vul_all_code_done_export_excel',NULL,NULL,NULL,'0','super',now(),'super',now(),'{ \"isDefault\": true, \"isMust\": false }');
insert into `sys_dict_data` (`dict_sort`, `dict_label`, `dict_value`, `dict_type`, `css_class`, `list_class`, `is_default`, `status`, `create_by`, `create_time`, `update_by`, `update_time`, `remark`) values('20','推送时间','pushTime','vul_all_code_done_export_excel',NULL,NULL,'N','0','super',now(),'super',now(),'{ \"isDefault\": true, \"isMust\": false }');
insert into `sys_dict_data` (`dict_sort`, `dict_label`, `dict_value`, `dict_type`, `css_class`, `list_class`, `is_default`, `status`, `create_by`, `create_time`, `update_by`, `update_time`, `remark`) values('21','工单状态','workOrderStateLabel','vul_all_code_done_export_excel',NULL,NULL,'N','0','super',now(),'super',now(),'{ \"isDefault\": true, \"isMust\": false }');

DROP TABLE IF EXISTS `tb_vul_white_list`;
CREATE TABLE `tb_vul_white_list` (
 `id` int(100) NOT NULL AUTO_INCREMENT COMMENT '主键',
 `ip` varchar(256) DEFAULT NULL COMMENT 'IP',
 `vul_name` varchar(256) DEFAULT NULL COMMENT '漏洞名称',
 `reason` text COMMENT '加白原因',
 `apply_user_name` varchar(50) DEFAULT NULL COMMENT '申请人',
 `apply_nick_name` varchar(50) DEFAULT NULL COMMENT '申请人姓名',
 `apply_user_dept` bigint(20) DEFAULT NULL COMMENT '申请人所属部门ID',
 `apply_time` datetime DEFAULT NULL COMMENT '申请时间',
 `json_file` text COMMENT '附件',
 `status` int(11) DEFAULT NULL COMMENT '审批状态（0 待审批，1 通过，2 不通过）',
 `approval_user_name` varchar(50) DEFAULT NULL COMMENT '审批人',
 `approval_nick_name` varchar(50) DEFAULT NULL COMMENT '审批人姓名',
 `approval_time` datetime DEFAULT NULL COMMENT '审批时间',
 `approval_comment` varchar(1000) DEFAULT NULL COMMENT '审批意见',
 `vul_id` varchar(100) DEFAULT NULL COMMENT '漏洞id',
 `category` varchar(1) DEFAULT NULL COMMENT '漏洞大类  1 主机漏洞  2 web漏洞  3  弱口令',
 `vul_content` text COMMENT '漏洞概述',
 `apply_id` varchar(100) DEFAULT NULL COMMENT '申请ID',
 `del_flag` tinyint(1) DEFAULT '0' COMMENT '删除标记 0 正常  1删除',
 `update_by` varchar(100) DEFAULT NULL COMMENT '更新人',
 `update_time` datetime DEFAULT NULL COMMENT '更新时间',
 PRIMARY KEY (`id`),
 KEY `ip` (`status`)
) ENGINE=InnoDB AUTO_INCREMENT=1 DEFAULT CHARSET=utf8 COMMENT='漏洞白名单'

#白名单导出字典
insert into `sys_dict_type` (`dict_name`, `dict_type`, `status`, `create_by`, `create_time`, `update_by`, `update_time`, `remark`, `layout`) values('漏洞_白名单_待审核_导出字段','vuln_whitelist_wait_export_excel','0','super','2022-12-05 10:38:45','',NULL,NULL,NULL);
insert into `sys_dict_type` (`dict_name`, `dict_type`, `status`, `create_by`, `create_time`, `update_by`, `update_time`, `remark`, `layout`) values('漏洞_白名单_已审核_导出字段','vuln_whitelist_done_export_excel','0','super','2022-12-05 10:38:52','',NULL,NULL,NULL);

insert into `sys_dict_data` (`dict_sort`, `dict_label`, `dict_value`, `dict_type`, `css_class`, `list_class`, `is_default`, `status`, `create_by`, `create_time`, `update_by`, `update_time`, `remark`) values('1','申请ID','applyId','vuln_whitelist_wait_export_excel',NULL,NULL,'N','0','super','2022-12-05 10:39:30','super','2022-12-09 15:40:54','{ \"isDefault\": true, \"isMust\": true }');
insert into `sys_dict_data` (`dict_sort`, `dict_label`, `dict_value`, `dict_type`, `css_class`, `list_class`, `is_default`, `status`, `create_by`, `create_time`, `update_by`, `update_time`, `remark`) values('2','漏洞ID','code','vuln_whitelist_wait_export_excel',NULL,NULL,'N','0','super','2022-12-05 10:39:36','super','2022-12-09 15:41:00','{ \"isDefault\": true, \"isMust\": false }');
insert into `sys_dict_data` (`dict_sort`, `dict_label`, `dict_value`, `dict_type`, `css_class`, `list_class`, `is_default`, `status`, `create_by`, `create_time`, `update_by`, `update_time`, `remark`) values('3','IP/域名','ip','vuln_whitelist_wait_export_excel',NULL,NULL,'N','0','super','2022-12-05 10:39:42','super','2022-12-12 19:41:25','{ \"isDefault\": true, \"isMust\": false }');
insert into `sys_dict_data` (`dict_sort`, `dict_label`, `dict_value`, `dict_type`, `css_class`, `list_class`, `is_default`, `status`, `create_by`, `create_time`, `update_by`, `update_time`, `remark`) values('4','所属组织','affiliationDeptName','vuln_whitelist_wait_export_excel',NULL,NULL,'N','0','super','2022-12-05 10:39:47','super','2022-12-09 15:41:11','{ \"isDefault\": false, \"isMust\": false }');
insert into `sys_dict_data` (`dict_sort`, `dict_label`, `dict_value`, `dict_type`, `css_class`, `list_class`, `is_default`, `status`, `create_by`, `create_time`, `update_by`, `update_time`, `remark`) values('5','资产名称','instance','vuln_whitelist_wait_export_excel',NULL,NULL,'N','0','super','2022-12-05 10:39:53','super','2022-12-09 15:41:16','{ \"isDefault\": false, \"isMust\": false }');
insert into `sys_dict_data` (`dict_sort`, `dict_label`, `dict_value`, `dict_type`, `css_class`, `list_class`, `is_default`, `status`, `create_by`, `create_time`, `update_by`, `update_time`, `remark`) values('6','漏洞大类','category','vuln_whitelist_wait_export_excel',NULL,NULL,'N','0','super','2022-12-05 10:40:00','super','2022-12-16 16:56:56','{ \"isDefault\": true, \"isMust\": false }');
insert into `sys_dict_data` (`dict_sort`, `dict_label`, `dict_value`, `dict_type`, `css_class`, `list_class`, `is_default`, `status`, `create_by`, `create_time`, `update_by`, `update_time`, `remark`) values('7','漏洞概述','vulContent','vuln_whitelist_wait_export_excel',NULL,NULL,'N','0','super','2022-12-05 10:40:06','super','2022-12-09 15:41:28','{ \"isDefault\": true, \"isMust\": false }');
insert into `sys_dict_data` (`dict_sort`, `dict_label`, `dict_value`, `dict_type`, `css_class`, `list_class`, `is_default`, `status`, `create_by`, `create_time`, `update_by`, `update_time`, `remark`) values('8','加白原因','reason','vuln_whitelist_wait_export_excel',NULL,NULL,'N','0','super','2022-12-05 10:40:14','super','2022-12-09 15:41:34','{ \"isDefault\": true, \"isMust\": false }');
insert into `sys_dict_data` (`dict_sort`, `dict_label`, `dict_value`, `dict_type`, `css_class`, `list_class`, `is_default`, `status`, `create_by`, `create_time`, `update_by`, `update_time`, `remark`) values('9','申请人','applyUserName','vuln_whitelist_wait_export_excel',NULL,NULL,'N','0','super','2022-12-05 10:40:20','super','2022-12-09 15:41:39','{ \"isDefault\": true, \"isMust\": false }');
insert into `sys_dict_data` (`dict_sort`, `dict_label`, `dict_value`, `dict_type`, `css_class`, `list_class`, `is_default`, `status`, `create_by`, `create_time`, `update_by`, `update_time`, `remark`) values('10','申请时间','applyTime','vuln_whitelist_wait_export_excel',NULL,NULL,'N','0','super','2022-12-05 10:40:26','super','2022-12-09 15:41:44','{ \"isDefault\": true, \"isMust\": false }');

insert into `sys_dict_data` (`dict_sort`, `dict_label`, `dict_value`, `dict_type`, `css_class`, `list_class`, `is_default`, `status`, `create_by`, `create_time`, `update_by`, `update_time`, `remark`) values('1','申请ID','applyId','vuln_whitelist_done_export_excel',NULL,NULL,'N','0','super','2022-12-05 10:41:35','super','2022-12-09 15:38:53','{ \"isDefault\": true, \"isMust\": true }');
insert into `sys_dict_data` (`dict_sort`, `dict_label`, `dict_value`, `dict_type`, `css_class`, `list_class`, `is_default`, `status`, `create_by`, `create_time`, `update_by`, `update_time`, `remark`) values('2','漏洞ID','code','vuln_whitelist_done_export_excel',NULL,NULL,'N','0','super','2022-12-05 10:41:42','super','2022-12-09 15:38:59','{ \"isDefault\": true, \"isMust\": false }');
insert into `sys_dict_data` (`dict_sort`, `dict_label`, `dict_value`, `dict_type`, `css_class`, `list_class`, `is_default`, `status`, `create_by`, `create_time`, `update_by`, `update_time`, `remark`) values('3','IP/域名','ip','vuln_whitelist_done_export_excel',NULL,NULL,'N','0','super','2022-12-05 10:41:48','super','2022-12-12 19:41:40','{ \"isDefault\": true, \"isMust\": false }');
insert into `sys_dict_data` (`dict_sort`, `dict_label`, `dict_value`, `dict_type`, `css_class`, `list_class`, `is_default`, `status`, `create_by`, `create_time`, `update_by`, `update_time`, `remark`) values('4','所属组织','affiliationDeptName','vuln_whitelist_done_export_excel',NULL,NULL,'N','0','super','2022-12-05 10:41:53','super','2022-12-09 15:39:12','{ \"isDefault\": false, \"isMust\": false }');
insert into `sys_dict_data` (`dict_sort`, `dict_label`, `dict_value`, `dict_type`, `css_class`, `list_class`, `is_default`, `status`, `create_by`, `create_time`, `update_by`, `update_time`, `remark`) values('5','资产名称','instance','vuln_whitelist_done_export_excel',NULL,NULL,'N','0','super','2022-12-05 10:41:59','super','2022-12-09 15:39:18','{ \"isDefault\": false, \"isMust\": false }');
insert into `sys_dict_data` (`dict_sort`, `dict_label`, `dict_value`, `dict_type`, `css_class`, `list_class`, `is_default`, `status`, `create_by`, `create_time`, `update_by`, `update_time`, `remark`) values('6','漏洞大类','category','vuln_whitelist_done_export_excel',NULL,NULL,'N','0','super','2022-12-05 10:42:06','super','2022-12-16 16:57:21','{ \"isDefault\": true, \"isMust\": false }');
insert into `sys_dict_data` (`dict_sort`, `dict_label`, `dict_value`, `dict_type`, `css_class`, `list_class`, `is_default`, `status`, `create_by`, `create_time`, `update_by`, `update_time`, `remark`) values('7','漏洞概述','vulContent','vuln_whitelist_done_export_excel',NULL,NULL,'N','0','super','2022-12-05 10:42:14','super','2022-12-09 15:39:29','{ \"isDefault\": true, \"isMust\": false }');
insert into `sys_dict_data` (`dict_sort`, `dict_label`, `dict_value`, `dict_type`, `css_class`, `list_class`, `is_default`, `status`, `create_by`, `create_time`, `update_by`, `update_time`, `remark`) values('8','加白原因','reason','vuln_whitelist_done_export_excel',NULL,NULL,'N','0','super','2022-12-05 10:42:20','super','2022-12-09 15:39:37','{ \"isDefault\": true, \"isMust\": false }');
insert into `sys_dict_data` (`dict_sort`, `dict_label`, `dict_value`, `dict_type`, `css_class`, `list_class`, `is_default`, `status`, `create_by`, `create_time`, `update_by`, `update_time`, `remark`) values('9','申请人','applyUserName','vuln_whitelist_done_export_excel',NULL,NULL,'N','0','super','2022-12-05 10:42:29','super','2022-12-09 15:39:43','{ \"isDefault\": true, \"isMust\": false }');
insert into `sys_dict_data` (`dict_sort`, `dict_label`, `dict_value`, `dict_type`, `css_class`, `list_class`, `is_default`, `status`, `create_by`, `create_time`, `update_by`, `update_time`, `remark`) values('10','申请时间','applyTime','vuln_whitelist_done_export_excel',NULL,NULL,'N','0','super','2022-12-05 10:42:35','super','2022-12-09 15:39:49','{ \"isDefault\": false, \"isMust\": false }');
insert into `sys_dict_data` (`dict_sort`, `dict_label`, `dict_value`, `dict_type`, `css_class`, `list_class`, `is_default`, `status`, `create_by`, `create_time`, `update_by`, `update_time`, `remark`) values('11','审核结果','status','vuln_whitelist_done_export_excel',NULL,NULL,'N','0','super','2022-12-05 10:42:40','super','2022-12-09 15:40:22','{ \"isDefault\": true, \"isMust\": false }');
insert into `sys_dict_data` (`dict_sort`, `dict_label`, `dict_value`, `dict_type`, `css_class`, `list_class`, `is_default`, `status`, `create_by`, `create_time`, `update_by`, `update_time`, `remark`) values('12','审核人','approvalNickName','vuln_whitelist_done_export_excel',NULL,NULL,'N','0','super','2022-12-05 10:42:46','super','2022-12-09 15:40:06','{ \"isDefault\": false, \"isMust\": false }');
insert into `sys_dict_data` (`dict_sort`, `dict_label`, `dict_value`, `dict_type`, `css_class`, `list_class`, `is_default`, `status`, `create_by`, `create_time`, `update_by`, `update_time`, `remark`) values('13','审核时间','approvalTime','vuln_whitelist_done_export_excel',NULL,NULL,'N','0','super','2022-12-05 10:42:52','super','2022-12-09 15:40:11','{ \"isDefault\": false, \"isMust\": false }');
insert into `sys_dict_data` (`dict_sort`, `dict_label`, `dict_value`, `dict_type`, `css_class`, `list_class`, `is_default`, `status`, `create_by`, `create_time`, `update_by`, `update_time`, `remark`) values('14','审核意见','approvalComment','vuln_whitelist_done_export_excel',NULL,NULL,'N','0','super','2022-12-05 10:42:57','super','2022-12-09 15:40:16','{ \"isDefault\": false, \"isMust\": false }');

#延期管理

DROP TABLE IF EXISTS `tb_vul_delay`;
CREATE TABLE `tb_vul_delay` (
`id` bigint(20) NOT NULL AUTO_INCREMENT COMMENT '主键',
`apply_id` varchar(11) DEFAULT NULL COMMENT '申请ID',
`loophole_id` varchar(100) DEFAULT NULL COMMENT '漏洞id',
`ip` varchar(255) DEFAULT NULL COMMENT 'IP',
`category` tinyint(1) DEFAULT NULL COMMENT '漏洞大类',
`vul_content` text COMMENT '漏洞概述',
`original_repair_time` datetime DEFAULT NULL COMMENT '原始修复时间',
`plan_repair_time` datetime DEFAULT NULL COMMENT '预计修复时间',
`reason` text COMMENT '申请原因',
`apply_user_name` varchar(255) DEFAULT NULL COMMENT '申请人  姓名 +  账号',
`apply_user_dept` int(100) DEFAULT NULL COMMENT '申请人所属部门ID',
`apply_time` datetime DEFAULT NULL COMMENT '申请时间',
`status` tinyint(1) DEFAULT '0' COMMENT '审批状态（0 待审批，1 通过，2 不通过）',
`approval_user_name` varchar(255) DEFAULT NULL COMMENT '审批人   姓名 +  账号',
`approval_time` datetime DEFAULT NULL COMMENT '审批时间',
`approval_comment` text COMMENT '审批意见',
`del_flag` tinyint(1) DEFAULT '0' COMMENT '删除标记 0 正常 1删除',
`update_by` varchar(100) DEFAULT NULL COMMENT '更新人',
`update_time` datetime DEFAULT NULL COMMENT '更新时间',
PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=1 DEFAULT CHARSET=utf8
#导出字典
insert into `sys_dict_type` (`dict_name`, `dict_type`, `status`, `create_by`, `create_time`, `update_by`, `update_time`, `remark`, `layout`) values('漏洞_延期_待审批_导出字段','vuln_delay_wait_export_excel','0','super','2022-12-26 15:36:16','super','2022-12-28 16:29:15',NULL,NULL);
insert into `sys_dict_data` (`dict_sort`, `dict_label`, `dict_value`, `dict_type`, `css_class`, `list_class`, `is_default`, `status`, `create_by`, `create_time`, `update_by`, `update_time`, `remark`) values(NULL,'申请ID','applyId','vuln_delay_wait_export_excel',NULL,NULL,NULL,'0','super','2022-12-26 15:37:21','super','2022-12-26 15:37:30','{ \"isDefault\": true, \"isMust\": true}');
insert into `sys_dict_data` (`dict_sort`, `dict_label`, `dict_value`, `dict_type`, `css_class`, `list_class`, `is_default`, `status`, `create_by`, `create_time`, `update_by`, `update_time`, `remark`) values('2','漏洞ID','code','vuln_delay_wait_export_excel',NULL,NULL,NULL,'0','super','2022-12-26 15:39:39','super','2022-12-28 16:32:15','{ \"isDefault\": true, \"isMust\": false}');
insert into `sys_dict_data` (`dict_sort`, `dict_label`, `dict_value`, `dict_type`, `css_class`, `list_class`, `is_default`, `status`, `create_by`, `create_time`, `update_by`, `update_time`, `remark`) values('3','IP/域名','ip','vuln_delay_wait_export_excel',NULL,NULL,NULL,'0','super','2022-12-26 15:43:23','super','2022-12-28 16:32:17','{ \"isDefault\": true, \"isMust\": false}');
insert into `sys_dict_data` (`dict_sort`, `dict_label`, `dict_value`, `dict_type`, `css_class`, `list_class`, `is_default`, `status`, `create_by`, `create_time`, `update_by`, `update_time`, `remark`) values('4','所属组织','affiliationDeptName','vuln_delay_wait_export_excel',NULL,NULL,NULL,'0','super','2022-12-26 15:44:15','super','2022-12-28 16:32:26','{ \"isDefault\": false, \"isMust\": false}');
insert into `sys_dict_data` (`dict_sort`, `dict_label`, `dict_value`, `dict_type`, `css_class`, `list_class`, `is_default`, `status`, `create_by`, `create_time`, `update_by`, `update_time`, `remark`) values('5','资产名称','instance','vuln_delay_wait_export_excel',NULL,NULL,NULL,'0','super','2022-12-26 15:44:38','super','2022-12-28 16:32:29','{ \"isDefault\": false, \"isMust\": false}');
insert into `sys_dict_data` (`dict_sort`, `dict_label`, `dict_value`, `dict_type`, `css_class`, `list_class`, `is_default`, `status`, `create_by`, `create_time`, `update_by`, `update_time`, `remark`) values('6','漏洞大类','category','vuln_delay_wait_export_excel',NULL,NULL,NULL,'0','super','2022-12-26 15:46:14','super','2022-12-28 16:32:35','{ \"isDefault\": true, \"isMust\": false}');
insert into `sys_dict_data` (`dict_sort`, `dict_label`, `dict_value`, `dict_type`, `css_class`, `list_class`, `is_default`, `status`, `create_by`, `create_time`, `update_by`, `update_time`, `remark`) values('7','漏洞概述','vulContent','vuln_delay_wait_export_excel',NULL,NULL,NULL,'0','super','2022-12-26 15:46:29','super','2022-12-28 16:32:37','{ \"isDefault\": true, \"isMust\": false}');
insert into `sys_dict_data` (`dict_sort`, `dict_label`, `dict_value`, `dict_type`, `css_class`, `list_class`, `is_default`, `status`, `create_by`, `create_time`, `update_by`, `update_time`, `remark`) values('8','原始截止时间','originalRepairTime','vuln_delay_wait_export_excel',NULL,NULL,NULL,'0','super','2022-12-26 15:46:49','super','2022-12-28 16:32:40','{ \"isDefault\": true, \"isMust\": false}');
insert into `sys_dict_data` (`dict_sort`, `dict_label`, `dict_value`, `dict_type`, `css_class`, `list_class`, `is_default`, `status`, `create_by`, `create_time`, `update_by`, `update_time`, `remark`) values('9','预期修复时间','planRepairTime','vuln_delay_wait_export_excel',NULL,NULL,NULL,'0','super','2022-12-26 15:47:01','super','2022-12-28 16:32:42','{ \"isDefault\": true, \"isMust\": false}');
insert into `sys_dict_data` (`dict_sort`, `dict_label`, `dict_value`, `dict_type`, `css_class`, `list_class`, `is_default`, `status`, `create_by`, `create_time`, `update_by`, `update_time`, `remark`) values('10','申请原因','reason','vuln_delay_wait_export_excel',NULL,NULL,NULL,'0','super','2022-12-26 15:47:23','super','2022-12-28 16:32:45','{ \"isDefault\": true, \"isMust\": false}');
insert into `sys_dict_data` (`dict_sort`, `dict_label`, `dict_value`, `dict_type`, `css_class`, `list_class`, `is_default`, `status`, `create_by`, `create_time`, `update_by`, `update_time`, `remark`) values('11','申请人','applyUserName','vuln_delay_wait_export_excel',NULL,NULL,NULL,'0','super','2022-12-26 15:47:33','super','2022-12-28 16:32:49','{ \"isDefault\": true, \"isMust\": false}');
insert into `sys_dict_data` (`dict_sort`, `dict_label`, `dict_value`, `dict_type`, `css_class`, `list_class`, `is_default`, `status`, `create_by`, `create_time`, `update_by`, `update_time`, `remark`) values('12','申请时间','applyTime','vuln_delay_wait_export_excel',NULL,NULL,NULL,'0','super','2022-12-26 15:47:43','super','2022-12-28 16:32:51','{ \"isDefault\": true, \"isMust\": false}');
insert into `sys_dict_type` (`dict_name`, `dict_type`, `status`, `create_by`, `create_time`, `update_by`, `update_time`, `remark`, `layout`) values('漏洞_延期_已审批_导出字段','vuln_delay_done_export_excel','0','super','2022-12-26 15:48:12','super','2022-12-28 16:29:22',NULL,NULL);
insert into `sys_dict_data` (`dict_sort`, `dict_label`, `dict_value`, `dict_type`, `css_class`, `list_class`, `is_default`, `status`, `create_by`, `create_time`, `update_by`, `update_time`, `remark`) values(NULL,'申请ID','applyId','vuln_delay_done_export_excel',NULL,NULL,NULL,'0','super','2022-12-26 15:37:21','super','2022-12-26 15:37:30','{ \"isDefault\": true, \"isMust\": true}');
insert into `sys_dict_data` (`dict_sort`, `dict_label`, `dict_value`, `dict_type`, `css_class`, `list_class`, `is_default`, `status`, `create_by`, `create_time`, `update_by`, `update_time`, `remark`) values('2','漏洞ID','code','vuln_delay_done_export_excel',NULL,NULL,NULL,'0','super','2022-12-26 15:39:39','super','2022-12-28 16:30:49','{ \"isDefault\": true, \"isMust\": false}');
insert into `sys_dict_data` (`dict_sort`, `dict_label`, `dict_value`, `dict_type`, `css_class`, `list_class`, `is_default`, `status`, `create_by`, `create_time`, `update_by`, `update_time`, `remark`) values('3','IP/域名','ip','vuln_delay_done_export_excel',NULL,NULL,NULL,'0','super','2022-12-26 15:43:23','super','2022-12-28 16:30:54','{ \"isDefault\": true, \"isMust\": false}');
insert into `sys_dict_data` (`dict_sort`, `dict_label`, `dict_value`, `dict_type`, `css_class`, `list_class`, `is_default`, `status`, `create_by`, `create_time`, `update_by`, `update_time`, `remark`) values('4','所属组织','affiliationDeptName','vuln_delay_done_export_excel',NULL,NULL,NULL,'0','super','2022-12-26 15:44:15','super','2022-12-28 16:30:30','{ \"isDefault\": false, \"isMust\": false}');
insert into `sys_dict_data` (`dict_sort`, `dict_label`, `dict_value`, `dict_type`, `css_class`, `list_class`, `is_default`, `status`, `create_by`, `create_time`, `update_by`, `update_time`, `remark`) values('5','资产名称','instance','vuln_delay_done_export_excel',NULL,NULL,NULL,'0','super','2022-12-26 15:44:38','super','2022-12-28 16:30:35','{ \"isDefault\": false, \"isMust\": false}');
insert into `sys_dict_data` (`dict_sort`, `dict_label`, `dict_value`, `dict_type`, `css_class`, `list_class`, `is_default`, `status`, `create_by`, `create_time`, `update_by`, `update_time`, `remark`) values('6','漏洞大类','category','vuln_delay_done_export_excel',NULL,NULL,NULL,'0','super','2022-12-26 15:46:14','super','2022-12-28 16:31:01','{ \"isDefault\": true, \"isMust\": false}');
insert into `sys_dict_data` (`dict_sort`, `dict_label`, `dict_value`, `dict_type`, `css_class`, `list_class`, `is_default`, `status`, `create_by`, `create_time`, `update_by`, `update_time`, `remark`) values('7','漏洞概述','vulContent','vuln_delay_done_export_excel',NULL,NULL,NULL,'0','super','2022-12-26 15:46:29','super','2022-12-28 16:31:05','{ \"isDefault\": true, \"isMust\": false}');
insert into `sys_dict_data` (`dict_sort`, `dict_label`, `dict_value`, `dict_type`, `css_class`, `list_class`, `is_default`, `status`, `create_by`, `create_time`, `update_by`, `update_time`, `remark`) values('8','原始截止时间','originalRepairTime','vuln_delay_done_export_excel',NULL,NULL,NULL,'0','super','2022-12-26 15:46:49','super','2022-12-28 16:31:08','{ \"isDefault\": true, \"isMust\": false}');
insert into `sys_dict_data` (`dict_sort`, `dict_label`, `dict_value`, `dict_type`, `css_class`, `list_class`, `is_default`, `status`, `create_by`, `create_time`, `update_by`, `update_time`, `remark`) values('9','预期修复时间','planRepairTime','vuln_delay_done_export_excel',NULL,NULL,NULL,'0','super','2022-12-26 15:47:01','super','2022-12-28 16:31:14','{ \"isDefault\": true, \"isMust\": false}');
insert into `sys_dict_data` (`dict_sort`, `dict_label`, `dict_value`, `dict_type`, `css_class`, `list_class`, `is_default`, `status`, `create_by`, `create_time`, `update_by`, `update_time`, `remark`) values('10','申请原因','reason','vuln_delay_done_export_excel',NULL,NULL,NULL,'0','super','2022-12-26 15:47:23','super','2022-12-28 16:31:19','{ \"isDefault\": true, \"isMust\": false}');
insert into `sys_dict_data` (`dict_sort`, `dict_label`, `dict_value`, `dict_type`, `css_class`, `list_class`, `is_default`, `status`, `create_by`, `create_time`, `update_by`, `update_time`, `remark`) values('11','申请人','applyUserName','vuln_delay_done_export_excel',NULL,NULL,NULL,'0','super','2022-12-26 15:47:33','super','2022-12-28 16:31:25','{ \"isDefault\": true, \"isMust\": false}');
insert into `sys_dict_data` (`dict_sort`, `dict_label`, `dict_value`, `dict_type`, `css_class`, `list_class`, `is_default`, `status`, `create_by`, `create_time`, `update_by`, `update_time`, `remark`) values('12','申请时间','applyTime','vuln_delay_done_export_excel',NULL,NULL,NULL,'0','super','2022-12-26 15:47:43','super','2022-12-28 16:31:31','{ \"isDefault\": false, \"isMust\": false}');
insert into `sys_dict_data` (`dict_sort`, `dict_label`, `dict_value`, `dict_type`, `css_class`, `list_class`, `is_default`, `status`, `create_by`, `create_time`, `update_by`, `update_time`, `remark`) values('13','审批结果','status','vuln_delay_done_export_excel',NULL,NULL,NULL,'0','super','2022-12-26 15:50:47','super','2022-12-28 16:31:38','{ \"isDefault\": true, \"isMust\": false}');
insert into `sys_dict_data` (`dict_sort`, `dict_label`, `dict_value`, `dict_type`, `css_class`, `list_class`, `is_default`, `status`, `create_by`, `create_time`, `update_by`, `update_time`, `remark`) values('14','审批人','approvalUserName','vuln_delay_done_export_excel',NULL,NULL,NULL,'0','super','2022-12-26 15:51:14','super','2022-12-28 16:31:41','{ \"isDefault\": false, \"isMust\": false}');
insert into `sys_dict_data` (`dict_sort`, `dict_label`, `dict_value`, `dict_type`, `css_class`, `list_class`, `is_default`, `status`, `create_by`, `create_time`, `update_by`, `update_time`, `remark`) values('15','审批时间','approvalTime','vuln_delay_done_export_excel',NULL,NULL,NULL,'0','super','2022-12-26 15:51:32','super','2022-12-28 16:31:46','{ \"isDefault\": false, \"isMust\": false}');
insert into `sys_dict_data` (`dict_sort`, `dict_label`, `dict_value`, `dict_type`, `css_class`, `list_class`, `is_default`, `status`, `create_by`, `create_time`, `update_by`, `update_time`, `remark`) values('16','审批意见','approvalComment','vuln_delay_done_export_excel',NULL,NULL,NULL,'0','super','2022-12-26 15:51:51','super','2022-12-28 16:31:48','{ \"isDefault\": false, \"isMust\": false}');
#代码审计缺陷上报
DROP TABLE IF EXISTS `tb_code_audit_defect`;
CREATE TABLE `tb_code_audit_defect` (
`id` int(11) NOT NULL AUTO_INCREMENT,
`app_id` int(11) DEFAULT NULL COMMENT '应用名称主键id',
`serious_num` int(11) DEFAULT '0' COMMENT '严重缺陷数',
`high_risk_num` int(11) DEFAULT '0' COMMENT '高危缺陷数',
`mid_risk_num` int(11) DEFAULT '0' COMMENT '中危缺陷数',
`low_risk_num` int(11) DEFAULT '0' COMMENT '低危缺陷数',
`info_risk_num` int(11) DEFAULT '0' COMMENT '信息缺陷数',
`source` tinyint(10) DEFAULT NULL COMMENT '来源',
`create_time` datetime DEFAULT NULL COMMENT '创建时间',
`create_by` varchar(1024) DEFAULT NULL COMMENT '创建人',
`update_time` datetime DEFAULT NULL COMMENT '更新时间',
`update_by` varchar(11) DEFAULT NULL COMMENT '更新人',
`del_flag` tinyint(1) DEFAULT '0' COMMENT '删除标记 0 正常  1删除',
`total_num` int(11) DEFAULT '0' COMMENT '总数',
`code_id` varchar(32) DEFAULT NULL,
`status` tinyint(1) DEFAULT '0' COMMENT '推送状态，0 未推送  1已推送',
`push_person` varchar(1024) DEFAULT NULL COMMENT '推送人',
`push_time` datetime DEFAULT NULL COMMENT '推送时间',
`create_by_label` varchar(1024) DEFAULT NULL COMMENT '创建人label',
`project_duty` varchar(11) DEFAULT NULL COMMENT '项目负责人',
`project_duty_label` varchar(32) DEFAULT NULL COMMENT '项目负责人label',
`affiliation_dept_node_id` bigint(20) DEFAULT NULL COMMENT '所属组织ID',
`affiliation_dept_name` varchar(1024) DEFAULT NULL COMMENT '所属组织名称',
`app_name` varchar(128) DEFAULT NULL COMMENT '应用名称',
`project_name` varchar(128) DEFAULT NULL COMMENT '项目名称',
PRIMARY KEY (`id`),
KEY `app_id` (`app_id`),
KEY `push_time` (`push_time`),
KEY `create_time` (`create_time`)
) ENGINE=InnoDB AUTO_INCREMENT=1 DEFAULT CHARSET=utf8 COMMENT='代码审计上报缺陷表'
#代码是审计缺陷上报导出字典
insert into `sys_dict_type` (`dict_name`, `dict_type`, `status`, `create_by`, `create_time`, `update_by`, `update_time`, `remark`) values('代码审计_全部_待推送_导出字段','codereview_all_wait_export_excel','0','super','2023-01-06 15:19:51','',NULL,NULL);
insert into `sys_dict_data` (`dict_sort`, `dict_label`, `dict_value`, `dict_type`, `css_class`, `list_class`, `is_default`, `status`, `create_by`, `create_time`, `update_by`, `update_time`, `remark`) values('1','缺陷ID','codeId','codereview_all_wait_export_excel',NULL,NULL,'N','0','super','2023-01-07 21:29:38','super','2023-01-07 21:29:38','{ \"isDefault\": true, \"isMust\": true }');
insert into `sys_dict_data` (`dict_sort`, `dict_label`, `dict_value`, `dict_type`, `css_class`, `list_class`, `is_default`, `status`, `create_by`, `create_time`, `update_by`, `update_time`, `remark`) values('2','应用名称','appName','codereview_all_wait_export_excel',NULL,NULL,'N','0','super','2023-01-07 21:29:47','super','2023-01-07 21:29:47','{ \"isDefault\": true, \"isMust\": true }');
insert into `sys_dict_data` (`dict_sort`, `dict_label`, `dict_value`, `dict_type`, `css_class`, `list_class`, `is_default`, `status`, `create_by`, `create_time`, `update_by`, `update_time`, `remark`) values('3','所属组织','deptName','codereview_all_wait_export_excel',NULL,NULL,'N','0','super','2023-01-07 21:29:47','super','2023-01-07 21:29:47','{ \"isDefault\": true, \"isMust\": false }');
insert into `sys_dict_data` (`dict_sort`, `dict_label`, `dict_value`, `dict_type`, `css_class`, `list_class`, `is_default`, `status`, `create_by`, `create_time`, `update_by`, `update_time`, `remark`) values('4','处置人','dutyNameLabel','codereview_all_wait_export_excel',NULL,NULL,'N','0','super','2023-01-07 21:29:47','super','2023-01-07 21:29:47','{ \"isDefault\": true, \"isMust\": false }');
insert into `sys_dict_data` (`dict_sort`, `dict_label`, `dict_value`, `dict_type`, `css_class`, `list_class`, `is_default`, `status`, `create_by`, `create_time`, `update_by`, `update_time`, `remark`) values('5','缺陷总数','totalNum','codereview_all_wait_export_excel',NULL,NULL,'N','0','super','2023-01-07 21:29:47','super','2023-01-07 21:29:47','{ \"isDefault\": true, \"isMust\": false }');
insert into `sys_dict_data` (`dict_sort`, `dict_label`, `dict_value`, `dict_type`, `css_class`, `list_class`, `is_default`, `status`, `create_by`, `create_time`, `update_by`, `update_time`, `remark`) values('6','严重缺陷数','seriousNum','codereview_all_wait_export_excel',NULL,NULL,'N','0','super','2023-01-07 21:29:47','super','2023-01-07 21:29:47','{ \"isDefault\": true, \"isMust\": false }');
insert into `sys_dict_data` (`dict_sort`, `dict_label`, `dict_value`, `dict_type`, `css_class`, `list_class`, `is_default`, `status`, `create_by`, `create_time`, `update_by`, `update_time`, `remark`) values('7','高危缺陷数','highRiskNum','codereview_all_wait_export_excel',NULL,NULL,'N','0','super','2023-01-07 21:29:48','super','2023-01-07 21:29:48','{ \"isDefault\": true, \"isMust\": false }');
insert into `sys_dict_data` (`dict_sort`, `dict_label`, `dict_value`, `dict_type`, `css_class`, `list_class`, `is_default`, `status`, `create_by`, `create_time`, `update_by`, `update_time`, `remark`) values('8','中危缺陷数','midRiskNum','codereview_all_wait_export_excel',NULL,NULL,'N','0','super','2023-01-07 21:29:48','super','2023-01-07 21:29:48','{ \"isDefault\": false, \"isMust\": false }');
insert into `sys_dict_data` (`dict_sort`, `dict_label`, `dict_value`, `dict_type`, `css_class`, `list_class`, `is_default`, `status`, `create_by`, `create_time`, `update_by`, `update_time`, `remark`) values('9','低危缺陷数','lowRiskNum','codereview_all_wait_export_excel',NULL,NULL,'N','0','super','2023-01-07 21:29:48','super','2023-01-07 21:29:48','{ \"isDefault\": false, \"isMust\": false }');
insert into `sys_dict_data` (`dict_sort`, `dict_label`, `dict_value`, `dict_type`, `css_class`, `list_class`, `is_default`, `status`, `create_by`, `create_time`, `update_by`, `update_time`, `remark`) values('10','信息缺陷数','infoRiskNum','codereview_all_wait_export_excel',NULL,NULL,'N','0','super','2023-01-07 21:29:48','super','2023-01-07 21:29:48','{ \"isDefault\": false, \"isMust\": false }');
insert into `sys_dict_data` (`dict_sort`, `dict_label`, `dict_value`, `dict_type`, `css_class`, `list_class`, `is_default`, `status`, `create_by`, `create_time`, `update_by`, `update_time`, `remark`) values('11','来源','sourceLabel','codereview_all_wait_export_excel',NULL,NULL,'N','0','super','2023-01-07 21:29:48','super','2023-01-08 15:46:11','{ \"isDefault\": true, \"isMust\": false }');
insert into `sys_dict_data` (`dict_sort`, `dict_label`, `dict_value`, `dict_type`, `css_class`, `list_class`, `is_default`, `status`, `create_by`, `create_time`, `update_by`, `update_time`, `remark`) values('12','提交人','createByLabel','codereview_all_wait_export_excel',NULL,NULL,'N','0','super','2023-01-07 21:29:48','super','2023-01-08 15:46:16','{ \"isDefault\": true, \"isMust\": false }');
insert into `sys_dict_data` (`dict_sort`, `dict_label`, `dict_value`, `dict_type`, `css_class`, `list_class`, `is_default`, `status`, `create_by`, `create_time`, `update_by`, `update_time`, `remark`) values('13','提交时间','createTime','codereview_all_wait_export_excel',NULL,NULL,'N','0','super','2023-01-07 21:29:48','super','2023-01-12 14:50:01','{ \"isDefault\": true, \"isMust\": false}');
insert into `sys_dict_type` (`dict_name`, `dict_type`, `status`, `create_by`, `create_time`, `update_by`, `update_time`, `remark`) values('代码审计_全部_待推送_导出字段','codereview_all_done_export_excel','0','super','2023-01-06 15:19:51','',NULL,NULL);
insert into `sys_dict_data` (`dict_sort`, `dict_label`, `dict_value`, `dict_type`, `css_class`, `list_class`, `is_default`, `status`, `create_by`, `create_time`, `update_by`, `update_time`, `remark`) values('1','缺陷ID','codeId','codereview_all_done_export_excel',NULL,NULL,'N','0','super','2023-01-07 21:29:38','super','2023-01-07 21:29:38','{ \"isDefault\": true, \"isMust\": true }');
insert into `sys_dict_data` (`dict_sort`, `dict_label`, `dict_value`, `dict_type`, `css_class`, `list_class`, `is_default`, `status`, `create_by`, `create_time`, `update_by`, `update_time`, `remark`) values('2','应用名称','appName','codereview_all_done_export_excel',NULL,NULL,'N','0','super','2023-01-07 21:29:47','super','2023-01-07 21:29:47','{ \"isDefault\": true, \"isMust\": true }');
insert into `sys_dict_data` (`dict_sort`, `dict_label`, `dict_value`, `dict_type`, `css_class`, `list_class`, `is_default`, `status`, `create_by`, `create_time`, `update_by`, `update_time`, `remark`) values('3','所属组织','deptName','codereview_all_done_export_excel',NULL,NULL,'N','0','super','2023-01-07 21:29:47','super','2023-01-07 21:29:47','{ \"isDefault\": true, \"isMust\": false }');
insert into `sys_dict_data` (`dict_sort`, `dict_label`, `dict_value`, `dict_type`, `css_class`, `list_class`, `is_default`, `status`, `create_by`, `create_time`, `update_by`, `update_time`, `remark`) values('4','处置人','dutyNameLabel','codereview_all_done_export_excel',NULL,NULL,'N','0','super','2023-01-07 21:29:47','super','2023-01-07 21:29:47','{ \"isDefault\": true, \"isMust\": false }');
insert into `sys_dict_data` (`dict_sort`, `dict_label`, `dict_value`, `dict_type`, `css_class`, `list_class`, `is_default`, `status`, `create_by`, `create_time`, `update_by`, `update_time`, `remark`) values('5','缺陷总数','totalNum','codereview_all_done_export_excel',NULL,NULL,'N','0','super','2023-01-07 21:29:47','super','2023-01-07 21:29:47','{ \"isDefault\": true, \"isMust\": false }');
insert into `sys_dict_data` (`dict_sort`, `dict_label`, `dict_value`, `dict_type`, `css_class`, `list_class`, `is_default`, `status`, `create_by`, `create_time`, `update_by`, `update_time`, `remark`) values('6','严重缺陷数','seriousNum','codereview_all_done_export_excel',NULL,NULL,'N','0','super','2023-01-07 21:29:47','super','2023-01-07 21:29:47','{ \"isDefault\": true, \"isMust\": false }');
insert into `sys_dict_data` (`dict_sort`, `dict_label`, `dict_value`, `dict_type`, `css_class`, `list_class`, `is_default`, `status`, `create_by`, `create_time`, `update_by`, `update_time`, `remark`) values('7','高危缺陷数','highRiskNum','codereview_all_done_export_excel',NULL,NULL,'N','0','super','2023-01-07 21:29:48','super','2023-01-07 21:29:48','{ \"isDefault\": true, \"isMust\": false }');
insert into `sys_dict_data` (`dict_sort`, `dict_label`, `dict_value`, `dict_type`, `css_class`, `list_class`, `is_default`, `status`, `create_by`, `create_time`, `update_by`, `update_time`, `remark`) values('8','中危缺陷数','midRiskNum','codereview_all_done_export_excel',NULL,NULL,'N','0','super','2023-01-07 21:29:48','super','2023-01-07 21:29:48','{ \"isDefault\": false, \"isMust\": false }');
insert into `sys_dict_data` (`dict_sort`, `dict_label`, `dict_value`, `dict_type`, `css_class`, `list_class`, `is_default`, `status`, `create_by`, `create_time`, `update_by`, `update_time`, `remark`) values('9','低危缺陷数','lowRiskNum','codereview_all_done_export_excel',NULL,NULL,'N','0','super','2023-01-07 21:29:48','super','2023-01-07 21:29:48','{ \"isDefault\": false, \"isMust\": false }');
insert into `sys_dict_data` (`dict_sort`, `dict_label`, `dict_value`, `dict_type`, `css_class`, `list_class`, `is_default`, `status`, `create_by`, `create_time`, `update_by`, `update_time`, `remark`) values('10','信息缺陷数','infoRiskNum','codereview_all_done_export_excel',NULL,NULL,'N','0','super','2023-01-07 21:29:48','super','2023-01-07 21:29:48','{ \"isDefault\": false, \"isMust\": false }');
insert into `sys_dict_data` (`dict_sort`, `dict_label`, `dict_value`, `dict_type`, `css_class`, `list_class`, `is_default`, `status`, `create_by`, `create_time`, `update_by`, `update_time`, `remark`) values('11','来源','sourceLabel','codereview_all_done_export_excel',NULL,NULL,'N','0','super','2023-01-07 21:29:48','super','2023-01-08 15:46:38','{ \"isDefault\": true, \"isMust\": false }');
insert into `sys_dict_data` (`dict_sort`, `dict_label`, `dict_value`, `dict_type`, `css_class`, `list_class`, `is_default`, `status`, `create_by`, `create_time`, `update_by`, `update_time`, `remark`) values('12','提交人','createByLabel','codereview_all_done_export_excel',NULL,NULL,'N','0','super','2023-01-07 21:29:48','super','2023-01-08 15:46:45','{ \"isDefault\": true, \"isMust\": false }');
insert into `sys_dict_data` (`dict_sort`, `dict_label`, `dict_value`, `dict_type`, `css_class`, `list_class`, `is_default`, `status`, `create_by`, `create_time`, `update_by`, `update_time`, `remark`) values('13','提交时间','createTime','codereview_all_done_export_excel',NULL,NULL,'N','0','super','2023-01-07 21:29:48','super','2023-01-07 21:29:48','{ \"isDefault\": false, \"isMust\": false }');
insert into `sys_dict_data` (`dict_sort`, `dict_label`, `dict_value`, `dict_type`, `css_class`, `list_class`, `is_default`, `status`, `create_by`, `create_time`, `update_by`, `update_time`, `remark`) values('20','推送时间','pushTime','codereview_all_done_export_excel',NULL,NULL,NULL,'0','super','2023-01-08 15:08:07',NULL,NULL,'{ \"isDefault\": true, \"isMust\": false }');
insert into `sys_dict_data` (`dict_sort`, `dict_label`, `dict_value`, `dict_type`, `css_class`, `list_class`, `is_default`, `status`, `create_by`, `create_time`, `update_by`, `update_time`, `remark`) values('21','工单状态','workOrderState','codereview_all_done_export_excel',NULL,NULL,NULL,'0','super','2023-01-08 15:08:30',NULL,NULL,'{ \"isDefault\": true, \"isMust\": false }');
#代码审计_缺陷数据来源
insert into `sys_dict_type` (`dict_name`, `dict_type`, `status`, `create_by`, `create_time`, `update_by`, `update_time`, `remark`) values('代码审计_缺陷数据来源','codereview_data_source','0','super','2023-01-04 16:07:37','',NULL,NULL);
insert into `sys_dict_data` (`dict_sort`, `dict_label`, `dict_value`, `dict_type`, `css_class`, `list_class`, `is_default`, `status`, `create_by`, `create_time`, `update_by`, `update_time`, `remark`) values(NULL,'系统','0','codereview_data_source',NULL,NULL,NULL,'0','super','2023-01-04 16:07:55','super','2023-01-04 16:08:10',NULL);
insert into `sys_dict_data` (`dict_sort`, `dict_label`, `dict_value`, `dict_type`, `css_class`, `list_class`, `is_default`, `status`, `create_by`, `create_time`, `update_by`, `update_time`, `remark`) values('1','人工上报','100','codereview_data_source',NULL,NULL,NULL,'0','super','2023-01-04 16:08:07',NULL,NULL,NULL);

#代码审计
DROP TABLE IF EXISTS `tb_code_audit_project`;
CREATE TABLE `tb_code_audit_project` (
  `id` varchar(32) NOT NULL COMMENT '主键',
  `project_name` varchar(128) DEFAULT NULL COMMENT '项目名称',
  `project_duty` varchar(64) DEFAULT NULL COMMENT '项目负责人',
  `project_duty_label` varchar(64) DEFAULT NULL COMMENT '项目负责人label',
  `affiliation_dept_name` varchar(1024) DEFAULT NULL COMMENT '所属组织名称',
  `affiliation_dept_node_id` bigint(20) DEFAULT NULL COMMENT '所属组织ID',
  `description` varchar(1024) DEFAULT NULL COMMENT '项目描述',
  `recent_check_time` datetime DEFAULT NULL COMMENT '最近检测时间',
  `count` int(11) DEFAULT NULL COMMENT '代码检测次数',
  `application_num` int(11) DEFAULT '0' COMMENT '应用个数',
  `del_flag` varchar(1) NOT NULL DEFAULT '0' COMMENT '删除标识(0 未删除 1 已删除)',
  `create_by` varchar(64) DEFAULT NULL COMMENT '创建人',
  `create_by_label` varchar(64) DEFAULT NULL COMMENT '创建人label',
  `create_time` datetime DEFAULT NULL COMMENT '创建时间',
  `update_by` varchar(64) DEFAULT NULL COMMENT '最后更新人',
  `update_time` datetime DEFAULT NULL COMMENT '最后更新时间',
  PRIMARY KEY (`id`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC COMMENT='代码审计项目表';

DROP TABLE IF EXISTS `tb_code_audit_application`;
CREATE TABLE `tb_code_audit_application` (
  `id` int(11) NOT NULL AUTO_INCREMENT COMMENT '主键',
  `project_id` varchar(128) DEFAULT NULL COMMENT '项目id',
  `application_name` varchar(128) DEFAULT NULL COMMENT '应用名称',
  `application_duty` varchar(64) DEFAULT NULL COMMENT '应用负责人',
  `application_duty_label` varchar(64) DEFAULT NULL COMMENT '应用负责人label',
  `description` varchar(1024) DEFAULT NULL COMMENT '应用描述',
  `source` char(1) DEFAULT NULL COMMENT '代码来源 1：git 2：SVN',
  `address` varchar(512) DEFAULT NULL COMMENT '仓库地址',
  `login_type` char(1) DEFAULT NULL COMMENT '登录方式 1：账号登录 2：Token登录',
  `user_name` varchar(128) DEFAULT NULL COMMENT '用户名',
  `pass_word` varchar(256) DEFAULT NULL COMMENT '密码',
  `token` varchar(256) DEFAULT NULL COMMENT 'token',
  `branch` varchar(256) DEFAULT NULL COMMENT '代码分支',
  `recent_check_time` datetime DEFAULT NULL COMMENT '最近检测时间',
  `count` int(11) DEFAULT NULL COMMENT '代码检测次数',
  `del_flag` varchar(1) NOT NULL DEFAULT '0' COMMENT '删除标识(0 未删除 1 已删除)',
  `create_by` varchar(64) DEFAULT NULL COMMENT '创建人',
  `create_by_label` varchar(64) DEFAULT NULL COMMENT '创建人label',
  `create_time` datetime DEFAULT NULL COMMENT '创建时间',
  `update_by` varchar(64) DEFAULT NULL COMMENT '最后更新人',
  `update_time` datetime DEFAULT NULL COMMENT '最后更新时间',
  `maven_url` varchar(256) DEFAULT NULL COMMENT 'maven地址',
  PRIMARY KEY (`id`) USING BTREE,
  KEY `project_id` (`project_id`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC COMMENT='代码审计应用表';

#字典：代码审计_应用_代码来源：codereview_app_code_source
delete from `sys_dict_type` where `dict_type` = 'codereview_app_code_source';
delete from `sys_dict_data` where `dict_type` = 'codereview_app_code_source';
insert into `sys_dict_type` (`dict_name`, `dict_type`, `status`, `create_by`, `create_time`, `update_by`, `update_time`, `remark`) values('代码审计_应用_代码来源','codereview_app_code_source','0','super',now(),'',NULL,NULL);

insert into `sys_dict_data` (`dict_sort`, `dict_label`, `dict_value`, `dict_type`, `css_class`, `list_class`, `is_default`, `status`, `create_by`, `create_time`, `update_by`, `update_time`, `remark`) values('0','GIT','1','codereview_app_code_source',NULL,NULL,'N','0','super',now(),'',NULL,NULL);
insert into `sys_dict_data` (`dict_sort`, `dict_label`, `dict_value`, `dict_type`, `css_class`, `list_class`, `is_default`, `status`, `create_by`, `create_time`, `update_by`, `update_time`, `remark`) values('1','SVN','2','codereview_app_code_source',NULL,NULL,'N','0','super',now(),'',NULL,NULL);

#字典：代码审计_应用_登录方式：codereview_app_login_method
delete from `sys_dict_type` where `dict_type` = 'codereview_app_login_method';
delete from `sys_dict_data` where `dict_type` = 'codereview_app_login_method';
insert into `sys_dict_type` (`dict_name`, `dict_type`, `status`, `create_by`, `create_time`, `update_by`, `update_time`, `remark`) values('代码审计_应用_登录方式','codereview_app_login_method','0','super',now(),'',NULL,NULL);

insert into `sys_dict_data` (`dict_sort`, `dict_label`, `dict_value`, `dict_type`, `css_class`, `list_class`, `is_default`, `status`, `create_by`, `create_time`, `update_by`, `update_time`, `remark`) values('0','账号登录','1','codereview_app_login_method',NULL,NULL,'N','0','super',now(),'',NULL,NULL);
insert into `sys_dict_data` (`dict_sort`, `dict_label`, `dict_value`, `dict_type`, `css_class`, `list_class`, `is_default`, `status`, `create_by`, `create_time`, `update_by`, `update_time`, `remark`) values('1','Token登录','2','codereview_app_login_method',NULL,NULL,'N','0','super',now(),'',NULL,NULL);


DROP TABLE IF EXISTS `tb_code_check_record`;
CREATE TABLE `tb_code_check_record` (
  `id` int(11) NOT NULL AUTO_INCREMENT COMMENT '主键ID',
  `task_id` varchar(32) DEFAULT NULL COMMENT '任务id',
  `defect_id` int(11) DEFAULT NULL COMMENT '缺陷id',
  `check_start_time` datetime DEFAULT NULL COMMENT '检测开始时间',
  `check_end_time` datetime DEFAULT NULL COMMENT '检测结束时间',
  `check_consuming` int(11) DEFAULT NULL COMMENT '检测耗时',
  `result` char(1) DEFAULT '1' COMMENT '执行结果 0 未开始 1 执行成功 2 执行失败',
  `del_flag` varchar(1) DEFAULT '0' COMMENT '删除标识(0 未删除 1 已删除)',
  `progress` int(11) DEFAULT '0' COMMENT '进度',
  PRIMARY KEY (`id`) USING BTREE,
  KEY `task_id` (`task_id`) USING BTREE,
  KEY `defect_id` (`defect_id`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC COMMENT='代码检测记录表';


DROP TABLE IF EXISTS `tb_code_check_task`;
CREATE TABLE `tb_code_check_task` (
  `id` varchar(32) NOT NULL COMMENT '主键ID，自动生成，格式：时间戳',
  `task_name` varchar(200) DEFAULT NULL COMMENT '任务名称',
  `app_id` int(11) DEFAULT NULL COMMENT '应用id',
  `exec_period` char(1) DEFAULT NULL COMMENT '执行周期 1：立即执行 2：定时执行',
  `source` char(1) DEFAULT NULL COMMENT '代码来源 1：git 2：SVN 3：上传源码',
  `lang` char(1) DEFAULT NULL COMMENT '语言类型 1：Java 2：C 3:PHP 4:Python',
  `safety_level` char(1) DEFAULT NULL COMMENT '检测安全级别 1：默认 2：高危 3:自定义',
  `status` char(1) DEFAULT NULL COMMENT '任务状态 1：等待 2：解压中 3:解压失败 4：待检测 5：检测中 6：检测完成 7：检测异常',
  `ruleId` varchar(32) DEFAULT NULL COMMENT '缺陷模板id',
  `defectType` varchar(32) DEFAULT NULL COMMENT '缺陷类型',
  `del_flag` char(1) DEFAULT '0' COMMENT '删除标识(0 未删除 1 已删除)',
  `create_by` varchar(64) DEFAULT NULL COMMENT '创建人',
  `create_by_label` varchar(64) DEFAULT NULL COMMENT '创建人label',
  `create_time` datetime DEFAULT NULL COMMENT '创建时间',
  `update_by` varchar(64) DEFAULT NULL COMMENT '最后更新人',
  `update_time` datetime DEFAULT NULL COMMENT '最后更新时间',
  `exec_time` datetime DEFAULT NULL COMMENT '定时执行时间',
  `file_json` varchar(1024) DEFAULT NULL COMMENT '附件',
  PRIMARY KEY (`id`) USING BTREE,
  KEY `app_id` (`app_id`) USING BTREE,
  KEY `exec_period_index` (`exec_period`),
  KEY `exec_source_index` (`source`),
  KEY `exec_lang_index` (`lang`),
  KEY `exec_status_index` (`status`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC COMMENT='代码检测任务表';

#漏洞修复案例表
DROP TABLE IF EXISTS `tb_vuln_knowledge`;
CREATE TABLE `tb_vuln_knowledge` (
`id` int(11) NOT NULL AUTO_INCREMENT,
`name` varchar(256) DEFAULT NULL COMMENT '案例标题',
`cve_code` varchar(100) DEFAULT NULL COMMENT 'CVE编号',
`detail` longtext COMMENT '详情',
`create_by` varchar(64) DEFAULT NULL,
`create_by_label` varchar(64) DEFAULT NULL,
`create_time` datetime DEFAULT NULL,
`update_by` varchar(64) DEFAULT NULL,
`update_time` datetime DEFAULT NULL,
`loophole_type` varchar(100) DEFAULT NULL COMMENT '漏洞大类',
`loophole_sub_type` varchar(50) DEFAULT NULL COMMENT '漏洞小类',
`influential_app` varchar(200) DEFAULT NULL COMMENT '影响应用',
`detail_html` longtext COMMENT '详情富文本',
`delete_flag` tinyint(1) DEFAULT '0' COMMENT '删除标记 0 正常  1 删除',
`vuln_id` varchar(11) DEFAULT NULL COMMENT '案例ID',
`vul_form_id` varchar(32) DEFAULT NULL COMMENT '漏洞主表ID',
PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=1 DEFAULT CHARSET=utf8 COMMENT='漏洞的脆弱性知识库'
#漏洞修复案例导出字典
insert into `sys_dict_type` (`dict_name`, `dict_type`, `status`, `create_by`, `create_time`, `update_by`, `update_time`, `remark`) values('漏洞修复案例_导出字段','knowledge_vuln_export_excel','0','super','2022-12-05 10:35:03','',NULL,NULL);
insert into `sys_dict_type` (`dict_name`, `dict_type`, `status`, `create_by`, `create_time`, `update_by`, `update_time`, `remark`) values('漏洞修复案例_导出字段','knowledge_vuln_export_excel','0','super','2022-12-05 10:35:03','',NULL,NULL);
insert into `sys_dict_data` (`dict_sort`, `dict_label`, `dict_value`, `dict_type`, `css_class`, `list_class`, `is_default`, `status`, `create_by`, `create_time`, `update_by`, `update_time`, `remark`) values('1','案例ID','vulnId','knowledge_vuln_export_excel',NULL,NULL,'N','0','super','2022-12-05 10:35:32','super','2022-12-08 15:35:25','{ \"isDefault\": true, \"isMust\": false }');
insert into `sys_dict_data` (`dict_sort`, `dict_label`, `dict_value`, `dict_type`, `css_class`, `list_class`, `is_default`, `status`, `create_by`, `create_time`, `update_by`, `update_time`, `remark`) values('2','案例标题','name','knowledge_vuln_export_excel',NULL,NULL,'N','0','super','2022-12-05 10:35:38','super','2022-12-08 15:36:26','{ \"isDefault\": true, \"isMust\": true }');
insert into `sys_dict_data` (`dict_sort`, `dict_label`, `dict_value`, `dict_type`, `css_class`, `list_class`, `is_default`, `status`, `create_by`, `create_time`, `update_by`, `update_time`, `remark`) values('3','漏洞大类','loopholeType','knowledge_vuln_export_excel',NULL,NULL,'N','0','super','2022-12-05 10:35:44','super','2022-12-09 18:08:01','{ \"isDefault\": true, \"isMust\": false }');
insert into `sys_dict_data` (`dict_sort`, `dict_label`, `dict_value`, `dict_type`, `css_class`, `list_class`, `is_default`, `status`, `create_by`, `create_time`, `update_by`, `update_time`, `remark`) values('4','漏洞小类','loopholeSubType','knowledge_vuln_export_excel',NULL,NULL,'N','0','super','2022-12-05 10:35:50','super','2022-12-08 15:36:42','{ \"isDefault\": true, \"isMust\": false }');
insert into `sys_dict_data` (`dict_sort`, `dict_label`, `dict_value`, `dict_type`, `css_class`, `list_class`, `is_default`, `status`, `create_by`, `create_time`, `update_by`, `update_time`, `remark`) values('5','CVE','cveCode','knowledge_vuln_export_excel',NULL,NULL,'N','0','super','2022-12-05 10:35:56','super','2022-12-08 15:36:51','{ \"isDefault\": false, \"isMust\": false }');
insert into `sys_dict_data` (`dict_sort`, `dict_label`, `dict_value`, `dict_type`, `css_class`, `list_class`, `is_default`, `status`, `create_by`, `create_time`, `update_by`, `update_time`, `remark`) values('6','影响应用','influentialApp','knowledge_vuln_export_excel',NULL,NULL,'N','0','super','2022-12-05 10:36:03','super','2022-12-08 15:38:03','{ \"isDefault\": false, \"isMust\": false }');
insert into `sys_dict_data` (`dict_sort`, `dict_label`, `dict_value`, `dict_type`, `css_class`, `list_class`, `is_default`, `status`, `create_by`, `create_time`, `update_by`, `update_time`, `remark`) values('7','案例详情','detail','knowledge_vuln_export_excel',NULL,NULL,'N','0','super','2022-12-05 10:36:09','super','2022-12-08 15:36:58','{ \"isDefault\": true, \"isMust\": false }');
insert into `sys_dict_data` (`dict_sort`, `dict_label`, `dict_value`, `dict_type`, `css_class`, `list_class`, `is_default`, `status`, `create_by`, `create_time`, `update_by`, `update_time`, `remark`) values('8','提交人','createByLabel','knowledge_vuln_export_excel',NULL,NULL,'N','0','super','2022-12-05 10:36:18','super','2022-12-08 15:38:09','{ \"isDefault\": false, \"isMust\": false }');
insert into `sys_dict_data` (`dict_sort`, `dict_label`, `dict_value`, `dict_type`, `css_class`, `list_class`, `is_default`, `status`, `create_by`, `create_time`, `update_by`, `update_time`, `remark`) values('9','提交时间','createTime','knowledge_vuln_export_excel',NULL,NULL,'N','0','super','2022-12-05 10:36:25','super','2022-12-08 15:38:14','{ \"isDefault\": false, \"isMust\": false }');
insert into `sys_dict_data` (`dict_sort`, `dict_label`, `dict_value`, `dict_type`, `css_class`, `list_class`, `is_default`, `status`, `create_by`, `create_time`, `update_by`, `update_time`, `remark`) values('10','最近更新时间','updateTime','knowledge_vuln_export_excel',NULL,NULL,'N','0','super','2022-12-05 10:36:32','super','2022-12-08 15:38:19','{ \"isDefault\": false, \"isMust\": false }');
#漏洞修复案例漏洞大类
insert into `sys_dict_type` (`dict_name`, `dict_type`, `status`, `create_by`, `create_time`, `update_by`, `update_time`, `remark`) values('漏洞修复案例_漏洞大类','knowledge_vuln_category','0','super','2022-12-06 10:46:04','',NULL,NULL);
insert into `sys_dict_data` (`dict_sort`, `dict_label`, `dict_value`, `dict_type`, `css_class`, `list_class`, `is_default`, `status`, `create_by`, `create_time`, `update_by`, `update_time`, `remark`) values('1','主机漏洞','1','knowledge_vuln_category',NULL,NULL,'N','0','super','2022-12-06 10:46:10','',NULL,NULL);
insert into `sys_dict_data` (`dict_sort`, `dict_label`, `dict_value`, `dict_type`, `css_class`, `list_class`, `is_default`, `status`, `create_by`, `create_time`, `update_by`, `update_time`, `remark`) values('2','WEB漏洞','2','knowledge_vuln_category',NULL,NULL,'N','0','super','2022-12-06 10:46:15','',NULL,NULL);
insert into `sys_dict_data` (`dict_sort`, `dict_label`, `dict_value`, `dict_type`, `css_class`, `list_class`, `is_default`, `status`, `create_by`, `create_time`, `update_by`, `update_time`, `remark`) values('3','其它','3','knowledge_vuln_category',NULL,NULL,'N','0','super','2022-12-06 10:46:20','',NULL,NULL);

#修改字典名称
UPDATE sys_dict_type SET dict_name = '漏洞闭环_处置时限及提醒配置' WHERE dict_type = 'vuln_close_time_limit';
UPDATE sys_dict_type SET dict_name = '漏洞_主机漏洞_漏洞类型' WHERE dict_type = 'vul_host_type';
UPDATE sys_dict_type SET dict_name = '漏洞_主机漏洞_漏洞特征' WHERE dict_type = 'vul_host_features';
UPDATE sys_dict_type SET dict_name = '漏洞_主机漏洞_漏洞修复影响' WHERE dict_type = 'vul_host_influence';
UPDATE sys_dict_type SET dict_name = '漏洞_全部漏洞_主机漏洞_待推送_导出字段' WHERE dict_type = 'vul_all_host_wait_export_excel';
UPDATE sys_dict_type SET dict_name = '漏洞_全部漏洞_主机漏洞_已推送_导出字段' WHERE dict_type = 'vul_all_host_done_export_excel';
UPDATE sys_dict_type SET dict_name = '漏洞_全部漏洞_WEB漏洞_待推送_导出字段' WHERE dict_type = 'vul_all_web_wait_export_excel';
UPDATE sys_dict_type SET dict_name = '漏洞_全部漏洞_WEB漏洞_已推送_导出字段' WHERE dict_type = 'vul_all_web_done_export_excel';
UPDATE sys_dict_type SET dict_name = '漏洞_全部漏洞_弱口令_待推送_导出字段' WHERE dict_type = 'vul_all_code_wait_export_excel';
UPDATE sys_dict_type SET dict_name = '漏洞_全部漏洞_弱口令_已推送_导出字段' WHERE dict_type = 'vul_all_code_done_export_excel';

#代码扫描sql
DROP TABLE IF EXISTS `tb_code_check_record_log`;
CREATE TABLE `tb_code_check_record_log` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `record_id` int(11) DEFAULT NULL,
  `app_id` int(11) DEFAULT NULL COMMENT '应用ID信息',
  `result` tinytext COMMENT '扫描结果',
  `create_time` timestamp NULL DEFAULT NULL,
  `update_time` timestamp NULL DEFAULT NULL,
  `job_id` varchar(32) DEFAULT NULL COMMENT '执行ID （扫描器执行的任务ID）',
  `scan_status` int(11) DEFAULT '0' COMMENT '任务状态(0 未开始 1 执行中 2 执行完成 3 执行失败)',
  `task_id` varchar(32) DEFAULT NULL COMMENT '下发扫描任务ID',
  `engine_id` int(11) DEFAULT NULL COMMENT '引擎ID',
  `progress` int(11) DEFAULT '0' COMMENT '进度',
  PRIMARY KEY (`id`),
  KEY `record_id` (`record_id`),
  KEY `scan_status` (`scan_status`),
  KEY `app_id` (`app_id`),
  KEY `job_id` (`job_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='任务执行记录表';

DROP TABLE IF EXISTS `tb_code_check_rule`;
CREATE TABLE `tb_code_check_rule` (
  `id` varchar(32) NOT NULL DEFAULT '' COMMENT 'ID',
  `name` varchar(64) DEFAULT NULL COMMENT '规则名称',
  `extra_list` varchar(1024) DEFAULT NULL COMMENT '检测类型列表',
  `lang` varchar(32) DEFAULT NULL COMMENT '支持语言',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='检测规则列表';

DROP TABLE IF EXISTS `tb_code_check_task`;
CREATE TABLE `tb_code_check_task` (
  `id` varchar(32) NOT NULL COMMENT '主键ID，自动生成，格式：时间戳',
  `task_name` varchar(200) DEFAULT NULL COMMENT '任务名称',
  `app_id` int(11) DEFAULT NULL COMMENT '应用id',
  `exec_period` char(1) DEFAULT NULL COMMENT '执行周期 1：立即执行 2：定时执行',
  `source` char(1) DEFAULT NULL COMMENT '代码来源 1：git 2：SVN 3：上传源码',
  `lang` char(1) DEFAULT NULL COMMENT '语言类型 1：Java 2：C 3:PHP 4:Python',
  `safety_level` char(1) DEFAULT NULL COMMENT '检测安全级别 1：默认 2：高危 3:自定义',
  `status` char(1) DEFAULT NULL COMMENT '任务状态 1：等待 2：解压中 3:解压失败 4：待检测 5：检测中 6：检测完成 7：检测异常',
  `ruleId` varchar(32) DEFAULT NULL COMMENT '缺陷模板id',
  `defectType` varchar(32) DEFAULT NULL COMMENT '缺陷类型',
  `del_flag` char(1) DEFAULT '0' COMMENT '删除标识(0 未删除 1 已删除)',
  `create_by` varchar(64) DEFAULT NULL COMMENT '创建人',
  `create_by_label` varchar(64) DEFAULT NULL COMMENT '创建人label',
  `create_time` datetime DEFAULT NULL COMMENT '创建时间',
  `update_by` varchar(64) DEFAULT NULL COMMENT '最后更新人',
  `update_time` datetime DEFAULT NULL COMMENT '最后更新时间',
  `exec_time` datetime DEFAULT NULL COMMENT '定时执行时间',
  `file_json` varchar(1024) DEFAULT NULL COMMENT '附件',
  PRIMARY KEY (`id`) USING BTREE,
  KEY `app_id` (`app_id`) USING BTREE,
  KEY `exec_period_index` (`exec_period`),
  KEY `exec_source_index` (`source`),
  KEY `exec_lang_index` (`lang`),
  KEY `exec_status_index` (`status`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC COMMENT='代码检测任务表';

DROP TABLE IF EXISTS `tb_code_jar_data`;
CREATE TABLE `tb_code_jar_data` (
  `id` bigint(11) unsigned NOT NULL AUTO_INCREMENT,
  `app_id` bigint(11) DEFAULT NULL COMMENT '应用ID',
  `source` int(11) DEFAULT NULL COMMENT '来源',
  `task_id` varchar(32) DEFAULT NULL COMMENT '任务ID',
  `cve_code` varchar(32) DEFAULT NULL COMMENT 'CVE编号',
  `cnnvd_code` varchar(32) DEFAULT NULL COMMENT 'CNNVD编号',
  `cwe_code` varchar(32) DEFAULT NULL COMMENT 'CWE编号',
  `jar_file` varchar(64) DEFAULT NULL COMMENT '开源组件名称',
  `cvss` varchar(32) DEFAULT NULL COMMENT 'CVSS评分',
  `create_by` varchar(32) DEFAULT NULL,
  `update_by` varchar(32) DEFAULT NULL,
  `create_time` timestamp NULL DEFAULT NULL,
  `update_time` timestamp NULL DEFAULT NULL,
  `del_flag` int(11) DEFAULT '0',
  `vuln_code` varchar(32) DEFAULT NULL COMMENT '缺陷编号',
  `record_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `app_id` (`app_id`),
  KEY `source` (`source`),
  KEY `task_id` (`task_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='代码开源组件缺陷主表';

DROP TABLE IF EXISTS `tb_code_vuln_data`;
CREATE TABLE `tb_code_vuln_data` (
  `id` bigint(11) unsigned NOT NULL AUTO_INCREMENT,
  `app_id` bigint(11) DEFAULT NULL COMMENT '应用ID',
  `source` int(11) DEFAULT NULL COMMENT '来源',
  `task_id` varchar(32) DEFAULT NULL COMMENT '任务ID',
  `vuln_file_path` varchar(256) DEFAULT NULL COMMENT '缺陷代码路径',
  `vuln_function` varchar(128) DEFAULT NULL COMMENT '缺陷方法名称',
  `vuln_line` int(11) DEFAULT NULL COMMENT '缺陷行数',
  `vuln_col` int(11) DEFAULT NULL COMMENT '缺陷列数',
  `error_code` varchar(128) DEFAULT NULL COMMENT '缺陷代码',
  `vuln_name` varchar(64) DEFAULT NULL COMMENT '缺陷名称',
  `meessage` text COMMENT '缺陷详情',
  `vuln_level` int(11) DEFAULT NULL COMMENT '缺陷级别',
  `create_by` varchar(32) DEFAULT NULL,
  `update_by` varchar(32) DEFAULT NULL,
  `create_time` timestamp NULL DEFAULT NULL,
  `update_time` timestamp NULL DEFAULT NULL,
  `del_flag` int(11) DEFAULT '0',
  `vuln_code` varchar(32) DEFAULT NULL COMMENT '缺陷编号',
  `record_id` int(11) DEFAULT NULL COMMENT '缺陷扫描批次ID',
  PRIMARY KEY (`id`),
  KEY `app_id` (`app_id`),
  KEY `source` (`source`),
  KEY `task_id` (`task_id`),
  KEY `vuln_name` (`vuln_name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='代码缺陷主表';

#资产表和漏洞表添加索引
ALTER TABLE `tb_vuln_process_form` DROP INDEX idx_category;
ALTER TABLE `tb_asset` DROP INDEX idx_internal_ip;
ALTER TABLE `tb_vuln_process_form` ADD INDEX idx_category (`category` );
ALTER TABLE `tb_asset` ADD INDEX idx_internal_ip (`internal_ip` );

#新版攻击链路
alter table tb_attack_link_history add is_new tinyint(1) DEFAULT 0 COMMENT '是否为新版（0代表旧版 1代表新版）';
alter table tb_attack_link_history add detail json DEFAULT null COMMENT '新版详情信息';

delete from `sys_dict_type` where `dict_type` = 'intelligence_info';
INSERT INTO sys_dict_type
(dict_name, dict_type, status, create_by, create_time, update_by, update_time, remark, layout)
VALUES('威胁情报信息', 'intelligence_info', '0', 'super', '2022-11-24 11:23:28', 'super', '2022-11-28 14:18:29', '{”apiKey“:"ca9dleef4d894f558b6ff834c9d72bd9","salt":"doCfa6","url":"http://10.0.14.124:8090/tip_api/v4/ip","timeout":10000}', '1');

delete from `sys_dict_type` where `dict_type` = 'alarm_attack_link_configure';
delete from `sys_dict_data` where `dict_type` = 'alarm_attack_link_configure';
INSERT INTO sys_dict_type
(dict_name, dict_type, status, create_by, create_time, update_by, update_time, remark)
VALUES('告警闭环_攻击链路图标显示开关', 'alarm_attack_link_configure', '0', 'super', '2022-09-26 11:02:52', 'super', '2022-10-14 14:31:34', NULL);
INSERT INTO sys_dict_data
(dict_sort, dict_label, dict_value, dict_type, css_class, list_class, is_default, status, create_by, create_time, update_by, update_time, remark)
VALUES(NULL, '1', 'old', 'alarm_attack_link_configure', NULL, NULL, 'N', '0', 'super', '2022-11-30 19:00:26', 'super', '2022-11-30 19:39:49', NULL);
INSERT INTO sys_dict_data
(dict_sort, dict_label, dict_value, dict_type, css_class, list_class, is_default, status, create_by, create_time, update_by, update_time, remark)
VALUES(1, '2', 'new', 'alarm_attack_link_configure', NULL, NULL, 'N', '0', 'super', '2022-11-30 19:00:26', 'super', '2022-11-30 19:00:26', NULL);
