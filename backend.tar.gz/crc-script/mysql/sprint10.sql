CREATE INDEX idx_ec_event_id ON tb_event_calculation (event_id);
CREATE INDEX idx_ass_internet_ip ON tb_asset (internet_ip);
CREATE INDEX idx_ass_del_flag ON tb_asset (del_flag);
CREATE INDEX idx_ass_update_time ON tb_asset (update_time);
CREATE INDEX idx_mt_run_status ON tb_message_template (run_status);

CREATE INDEX idx_aw_source ON tb_alarm_whitelist (source);
CREATE INDEX idx_aw_approve_status ON tb_alarm_whitelist (approve_status);

CREATE TABLE `tb_alarm_ref_orilog` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `ori_ids` text COMMENT '原始日志ID（多个）',
  `alarm_id` varchar(32) DEFAULT NULL COMMENT '告警ID',
  `create_time` timestamp NULL DEFAULT NULL COMMENT '创建时间',
  `index_name` varchar(64) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=455 DEFAULT CHARSET=utf8;

alter table tb_event modify reg_area varchar(255);
alter table tb_event_calculation modify company varchar(255);


CREATE TABLE `tb_changting_scan_log` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `target` text COMMENT '扫描目标',
  `create_time` datetime DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
  `task_id` varchar(32) DEFAULT NULL COMMENT '任务ID',
  `status` int(11) DEFAULT NULL COMMENT '状态0-成功，1-失败',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
