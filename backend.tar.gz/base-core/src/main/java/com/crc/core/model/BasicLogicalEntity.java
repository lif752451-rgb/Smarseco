package com.crc.core.model;


import com.baomidou.mybatisplus.annotation.TableField;
import com.baomidou.mybatisplus.annotation.TableLogic;
import lombok.Data;
import lombok.EqualsAndHashCode;

@EqualsAndHashCode(callSuper = true)
@Data
public class BasicLogicalEntity extends BasicEntity{

    /**
     * 删除标识
     */
    @TableLogic
    @TableField("del_flag")
    private Integer delFlag;

}
