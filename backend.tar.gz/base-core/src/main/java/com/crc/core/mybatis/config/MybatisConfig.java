package com.crc.core.mybatis.config;

import com.baomidou.mybatisplus.extension.spring.MybatisSqlSessionFactoryBean;
import com.crc.core.mybatis.PackagesSqlSessionFactoryBean;
import org.apache.ibatis.session.SqlSessionFactory;
import org.mybatis.spring.SqlSessionTemplate;
import org.mybatis.spring.boot.autoconfigure.SpringBootVFS;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.autoconfigure.AutoConfigureOrder;
import org.springframework.boot.autoconfigure.condition.ConditionalOnMissingBean;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.support.PropertySourcesPlaceholderConfigurer;
import org.springframework.core.env.Environment;
import org.springframework.core.io.DefaultResourceLoader;
import org.springframework.core.io.support.PathMatchingResourcePatternResolver;
import org.springframework.core.io.support.ResourcePatternResolver;

import javax.sql.DataSource;

/**
 * @classname: MybatisConfig
 * @description: Mybatis配置
 * @author: cymiao
 * @create: 2018-08-16 10:24
 **/
@Configuration
@AutoConfigureOrder
public class MybatisConfig {

    @Autowired
    private Environment env;

    @Bean("sqlSessionFactory")
    @ConditionalOnMissingBean
    public SqlSessionFactory sqlSessionFactoryBean(DataSource dataSource){
        String typeAliasesPackage = env.getProperty("mybatis.typeAliasesPackage");
        String mapperLocations = env.getProperty("mybatis.mapperLocations");
        String configLocation = env.getProperty("mybatis.configLocation");

        MybatisSqlSessionFactoryBean factoryBean = new PackagesSqlSessionFactoryBean();

        factoryBean.setDataSource(dataSource);
        factoryBean.setVfs(SpringBootVFS.class);

        //添加别名
        factoryBean.setTypeAliasesPackage(typeAliasesPackage);

        /*//分页插件
        PaginationInterceptor paginationInterceptor = new PaginationInterceptor();

        //添加插件
        factoryBean.setPlugins(new Interceptor[]{paginationInterceptor});*/

        //添加mapper.xml目录
        ResourcePatternResolver resolver = new PathMatchingResourcePatternResolver();

        factoryBean.setConfigLocation(new DefaultResourceLoader().getResource(configLocation));
        try {
            factoryBean.setMapperLocations(resolver.getResources(mapperLocations));
            return  factoryBean.getObject();
        } catch (Exception e) {
            e.printStackTrace();
            throw new RuntimeException("SqlSessionFactory加载失败");
        }
    }

    @Bean
    @ConditionalOnMissingBean
    public SqlSessionTemplate sqlSessionTemplate(SqlSessionFactory sqlSessionFactory){
        return new SqlSessionTemplate(sqlSessionFactory);
    }

    @Bean
    public static PropertySourcesPlaceholderConfigurer propertySourcesPlaceholderConfigurer() {
        return new PropertySourcesPlaceholderConfigurer();
    }
}
