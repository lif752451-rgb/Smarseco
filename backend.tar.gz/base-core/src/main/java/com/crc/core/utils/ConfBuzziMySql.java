package com.crc.core.utils;


import cn.hutool.db.DbUtil;
import com.alibaba.druid.filter.config.ConfigTools;
import com.alibaba.fastjson.JSONObject;
import com.crc.common.utils.StringUtils;
import com.crc.core.bean.GetSpringBean;
import lombok.extern.slf4j.Slf4j;
import org.springframework.core.env.Environment;

import java.sql.*;
import java.util.LinkedList;
import java.util.List;

/**
 * @author simba@onlying.cn
 * @date 2020/8/26 20:35
 */
@Slf4j
public class ConfBuzziMySql {
    private static String DRIVER_CLASS_NAME = null;
    private static String URL = null;
    private static String USERNAME = null;
    private static String PASSWORD = null;

    static {
        Environment env = GetSpringBean.getBean(Environment.class);
        DRIVER_CLASS_NAME = env.getProperty("spring.datasource.driverClassName");
        URL = env.getProperty("spring.datasource.druid.master.url");
        USERNAME = env.getProperty("spring.datasource.druid.master.username");

        String publickey = env.getProperty("spring.datasource.druid.master.publickey");
        if (StringUtils.isBlank(publickey)) {
            PASSWORD = CodeTool.decryptX(env.getProperty("spring.datasource.druid.master.password"));
        } else {
            //数据库密码解密
            try {
                PASSWORD = ConfigTools.decrypt(publickey, env.getProperty("spring.datasource.druid.master.password"));
            } catch (Exception e) {
                log.error("密码解密失败，password：{}，publickey：{}", env.getProperty("spring.datasource.druid.master.password"), publickey);
            }
        }

    }

    public static int TIME_OUT_SEC = 60;

    public static Connection getConnection(String url, String username, String password, String pk) {
        try {
            if (StringUtils.isBlank(pk)) {
                pk = "IpTFX6FjYs5zKDG8gjKFh7kTgCFdWWJE";
            }
            // 注册 JDBC 驱动
            String driverName = "com.mysql.cj.jdbc.Driver";
            if (StringUtils.isNotBlank(url) && url.contains("jdbc:dm")) {
                driverName = "dm.jdbc.driver.DmDriver";
            }
            Class.forName(driverName);
            if (StringUtils.isNotEmpty(url)) {
                url = url.replace(",", "").replace("\t", "").replaceAll("&amp;", "&");
            }
            return DriverManager.getConnection(url, username, CodeTool.decrypt(password, pk));
        } catch (Exception e) {
            e.printStackTrace();
            log.error("连接数据库失败");
        }
        return null;
    }


    public static Connection getConnection() {
        try {
            // 注册 JDBC 驱动
            if (StringUtils.isBlank(DRIVER_CLASS_NAME)) {
                DRIVER_CLASS_NAME = "com.mysql.cj.jdbc.Driver";
            }
            Class.forName(DRIVER_CLASS_NAME);
            if (StringUtils.isNotEmpty(URL)) {
                URL = URL.replace(",", "").replace("\t", "").replaceAll("&amp;", "&");
            }
            return DriverManager.getConnection(URL, USERNAME, PASSWORD);
        } catch (Exception e) {
            e.printStackTrace();
            log.error("连接数据库失败");
        }
        return null;
    }

    /**
     * 执行查询SQL语句
     *
     * @param sql
     * @param params
     * @param callback
     */
    public static void executeQuery(String url, String userName, String password, String publickey, String sql, Object[] params,
                                    QueryCallback callback) {
        Connection conn = null;
        PreparedStatement pstmt = null;
        ResultSet rs = null;
        try {
            conn = getConnection(url, userName, password, publickey);
            if (conn != null) {
                pstmt = conn.prepareStatement(sql);
                pstmt.setQueryTimeout(TIME_OUT_SEC);
                if (params != null && params.length > 0) {
                    for (int i = 0; i < params.length; i++) {
                        pstmt.setObject(i + 1, params[i]);
                    }
                }
                pstmt.setQueryTimeout(ConfBuzziMySql.TIME_OUT_SEC);
                rs = pstmt.executeQuery();
                callback.process(rs);
            }
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            if (conn != null) {
                DbUtil.close(rs, pstmt, conn);
            }
        }
    }

    /**
     * 执行查询SQL语句
     *
     * @param sql
     * @param params
     * @param callback
     */
    public static void executeQuery(String sql, Object[] params, QueryCallback callback) {
        Connection conn = null;
        PreparedStatement pstmt = null;
        ResultSet rs = null;
        try {
            conn = getConnection();
            if (conn != null) {
                pstmt = conn.prepareStatement(sql);
                pstmt.setQueryTimeout(TIME_OUT_SEC);
                if (params != null && params.length > 0) {
                    for (int i = 0; i < params.length; i++) {
                        pstmt.setObject(i + 1, params[i]);
                    }
                }
                pstmt.setQueryTimeout(ConfBuzziMySql.TIME_OUT_SEC);
                rs = pstmt.executeQuery();
                callback.process(rs);
            }
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            if (conn != null) {
                DbUtil.close(rs, pstmt, conn);
            }
        }
    }


    public static interface QueryCallback {

        /**
         * 处理查询结果
         *
         * @param rs
         * @throws Exception
         */
        void process(ResultSet rs) throws Exception;

    }

    public static int getCount(String sql) {

        Connection conn = null;
        PreparedStatement pstmt = null;
        ResultSet rs = null;
        try {
            conn = getConnection();
            if (conn == null)
                return 0;
            pstmt = conn.prepareStatement(sql);
            pstmt.setQueryTimeout(ConfBuzziMySql.TIME_OUT_SEC);
            rs = pstmt.executeQuery();
            if (rs.next()) {
                return rs.getInt(1);
            }

        } catch (Exception se) {
            log.error(sql + "\n" + se.getMessage(), se);
        } finally {
            DbUtil.close(rs, pstmt, conn);
        }
        return 0;

    }


    public static void exeSQL(String sql) {
        Connection conn = null;
        PreparedStatement pstmt = null;
        try {
            conn = getConnection();
            if (conn != null) {
                pstmt = conn.prepareStatement(sql);
                pstmt.execute();
            }
        } catch (Exception se) {
            // 处理 JDBC 错误
            log.error(se.getMessage(), se);
        } finally {
            DbUtil.close(pstmt, conn);
        }
    }


    public static List<JSONObject> query(String sql) {
        List<JSONObject> jsonList = new LinkedList<>();
        Connection conn = null;
        PreparedStatement ps = null;
        ResultSet rs = null;
        try {
            conn = getConnection();
            if (conn == null)
                return jsonList;
            ps = conn.prepareStatement(sql);
            ps.setQueryTimeout(ConfBuzziMySql.TIME_OUT_SEC);
            rs = ps.executeQuery();
            while (rs.next()) {
                ResultSetMetaData rsmd = rs.getMetaData();
                JSONObject jsonObject = new JSONObject();
                for (int i = 1; i <= rsmd.getColumnCount(); i++) {
                    String col = rsmd.getColumnLabel(i);
                    jsonObject.put(col, getStr(rs, col));
                }
                jsonList.add(jsonObject);
            }
        } catch (Exception se) {
            // 处理 JDBC 错误
            log.error(se.getMessage(), se);
        } finally {
            DbUtil.close(rs, ps, conn);
        }
        return jsonList;
    }

    public static String getStr(ResultSet rs, String filter) {
        try {
            return rs.getString(filter);
        } catch (Exception e) {
            return "";
        }
    }
}
