package com.crc.core.datasource.enums;

/**
 * 数据源
 *
 * @author wst
 */
public enum DataSourceType
{
    /**
     * 主库
     */
    MASTER,

    /**
     * 从库
     */
    SLAVE
}
