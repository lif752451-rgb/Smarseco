package com.crc.core.datasource;

import cn.hutool.db.DbUtil;
import com.alibaba.druid.pool.DruidDataSource;
import com.crc.core.utils.ConfBuzziMySql;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.List;

/**
 * @author simba@onlying.cn
 * @date 2020/8/26 20:35
 */
public class ConfMySqlHelper {

    public static boolean testMode = false;

    private static ConfMySqlHelper instance = null;

    public static ConfMySqlHelper getInstance() {
        if (instance == null) {
            synchronized (ConfMySqlHelper.class) {
                if (instance == null) {
                    instance = new ConfMySqlHelper();
                }
            }
        }
        return instance;
    }


    public static Connection getConnection(DruidDataSource druidDataSource) {
        Connection conn = null;
        try {
            // 注册 JDBC 驱动
            Class.forName("com.mysql.cj.jdbc.Driver");
            return DriverManager.getConnection(druidDataSource.getUrl(), druidDataSource.getUsername(), druidDataSource.getPassword());
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
        }
        return null;
    }


    /**
     * 执行查询SQL语句
     *
     * @param sql
     * @param params
     * @param callback
     */
    public void executeQuery(DruidDataSource druidDataSource, String sql, Object[] params,
                             QueryCallback callback) {
        Connection conn = null;
        PreparedStatement pstmt = null;
        ResultSet rs = null;

        try {
            conn = getConnection(druidDataSource);
            pstmt = conn.prepareStatement(sql);

            if (params != null && params.length > 0) {
                for (int i = 0; i < params.length; i++) {
                    pstmt.setObject(i + 1, params[i]);
                }
            }
            pstmt.setQueryTimeout(ConfBuzziMySql.TIME_OUT_SEC);
            rs = pstmt.executeQuery();

            callback.process(rs);
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            if (conn != null) {
                close(rs, pstmt, conn);
            }
        }
    }

    public static void close(ResultSet rs, PreparedStatement ps, Connection conn) {
        // 关闭资源
        DbUtil.close(rs,ps,conn);
    }

    /**
     * 批量执行SQL语句
     * <p>
     * 批量执行SQL语句，是JDBC中的一个高级功能
     * 默认情况下，每次执行一条SQL语句，就会通过网络连接，向MySQL发送一次请求
     * <p>
     * 但是，如果在短时间内要执行多条结构完全一模一样的SQL，只是参数不同
     * 虽然使用PreparedStatement这种方式，可以只编译一次SQL，提高性能，但是，还是对于每次SQL
     * 都要向MySQL发送一次网络请求
     * <p>
     * 可以通过批量执行SQL语句的功能优化这个性能
     * 一次性通过PreparedStatement发送多条SQL语句，比如100条、1000条，甚至上万条
     * 执行的时候，也仅仅编译一次就可以
     * 这种批量执行SQL语句的方式，可以大大提升性能
     *
     * @param sql
     * @param paramsList
     * @return 每条SQL语句影响的行数
     */
    public int[] executeBatch(DruidDataSource druidDataSource, String sql, List<Object[]> paramsList) {
        int[] rtn = null;
        Connection conn = null;
        PreparedStatement pstmt = null;

        try {
            conn = getConnection(druidDataSource);

            // 第一步：使用Connection对象，取消自动提交
            conn.setAutoCommit(false);

            pstmt = conn.prepareStatement(sql);

            // 第二步：使用PreparedStatement.addBatch()方法加入批量的SQL参数
            if (paramsList != null && paramsList.size() > 0) {
                for (Object[] params : paramsList) {
                    for (int i = 0; i < params.length; i++) {
                        pstmt.setObject(i + 1, params[i]);
                    }
                    pstmt.addBatch();
                }
            }

            // 第三步：使用PreparedStatement.executeBatch()方法，执行批量的SQL语句
            rtn = pstmt.executeBatch();

            // 最后一步：使用Connection对象，提交批量的SQL语句
            conn.commit();
            System.out.println("sql commit");
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            if (conn != null) {
                close(null, pstmt, conn);
            }
        }

        return rtn;
    }

    public static void setTestMode(boolean testMode) {
        ConfMySqlHelper.testMode = testMode;
    }


    public static interface QueryCallback {

        /**
         * 处理查询结果
         *
         * @param rs
         * @throws Exception
         */
        void process(ResultSet rs) throws Exception;

    }
}
