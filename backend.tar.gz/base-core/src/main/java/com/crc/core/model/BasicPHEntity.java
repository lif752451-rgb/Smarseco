package com.crc.core.model;

import com.baomidou.mybatisplus.annotation.TableField;
import com.baomidou.mybatisplus.annotation.TableLogic;
import com.crc.common.utils.StringUtils;
import com.fasterxml.jackson.annotation.JsonFormat;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import java.io.Serializable;
import java.util.Date;
import java.util.List;

/**
 * 公共基础类
 */
@Data
public class BasicPHEntity implements Serializable {

    private static final long serialVersionUID = 1L;

    /**
     * id集合
     */
    @ApiModelProperty(value = "主键集合")
    @TableField(exist = false)
    private List<String> ids;

    /**
     * 删除标识(0 未删除 1 已删除)
     */
    @TableLogic
    @TableField("del_flag")
    private String delFlag;

    /**
     * 创建人
     */
    @ApiModelProperty(value = "创建人")
    @TableField(value = "create_by")
    private String createBy;

    /**
     * 创建时间
     */
    @ApiModelProperty(value = "创建时间")
    @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss", timezone = "GMT+8")
    @TableField(value = "create_time")
    private Date createTime;

    /**
     * 最后更新人
     */
    @ApiModelProperty(value = "最后更新人")
    @TableField(value = "update_by")
    private String updateBy;

    /**
     * 最后更新时间
     */
    @ApiModelProperty(value = "最后更新时间")
    @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss", timezone = "GMT+8")
    @TableField(value = "update_time")
    private Date updateTime;

    @ApiModelProperty(value = "页码")
    @TableField(exist = false)
    private Integer pageNum;

    @ApiModelProperty(value = "每页容量")
    @TableField(exist = false)
    private Integer pageSize;

    /**
     * 关键字搜索
     */
    @TableField(exist = false)
    private String searchValue;

    /**
     * 关键字搜索
     */
    @TableField(exist = false)
    private String keyword;

    @TableField(exist = false)
    private String orderByColumn;

    /**
     * 排序的方向 "desc" 或者 "asc".
     */
    @TableField(exist = false)
    private String isAsc;

    public String getOrderBy() {
        if (StringUtils.isEmpty(orderByColumn)) {
            return "";
        }
        return StringUtils.toUnderScoreCase(orderByColumn) + " " + isAsc;
    }
}