package com.crc.core.utils;

import com.crc.common.utils.http.HttpUtils;
import org.apache.commons.io.IOUtils;
import org.springframework.web.multipart.MultipartFile;

import java.io.*;
import java.net.URL;
import java.net.URLConnection;
import java.text.DecimalFormat;

/**
 * @author SHUFENGFENG
 */
public class FileUtil {
    private static final String TAG= FileUtil.class.getSimpleName();

    /**
     * 获取文件大小单位为B的double值
     */
    public static final int SIZE_TYPE_B = 1;
    /**
     * 获取文件大小单位为KB的double值
     */
    public static final int SIZE_TYPE_KB = 2;
    /**
     * 转换kb分母
     */
    public static final Integer SIZE_TYPE_KB_SIZE = 1024;
    /**
     * 获取文件大小单位为MB的double值
     */
    public static final int SIZE_TYPE_MB = 3;
    /**
     * 转换MB分母
     */
    public static final Integer SIZE_TYPE_MB_SIZE = 1024 * 1024;
    /**
     * 20MB
     */
    public static final Integer TWENTY_MB_SIZE = 20 * 1024 * 1024;
    /**
     * 200MB
     */
    public static final Integer TWO_HUNDRED_MB_SIZE = 200 * 1024 * 1024;
    /**
     * 获取文件大小单位为GB的double值
     */
    public static final int SIZE_TYPE_GB = 4;
    /**
     * 转换GB分母
     */
    public static final Integer SIZE_TYPE_GB_SIZE = 1024 * 1024 * 1024 ;




    /**
     * 获取文件指定文件的指定单位的大小
     *
     * @param filePath 文件路径
     * @param sizeType 获取大小的类型1为B、2为KB、3为MB、4为GB
     * @return double值的大小
     */
    public static double getFileOrFilesSize(String filePath, int sizeType) {
        File file = new File(filePath);
        long blockSize = 0;
        try {
            if (file.isDirectory()) {
                blockSize = getFileSizes(file);
            } else {
                blockSize = getFileSize(file);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return formetFileSize(blockSize, sizeType);
    }

    /**
     * 调用此方法自动计算指定文件或指定文件夹的大小
     *
     * @param filePath 文件路径
     * @return 计算好的带B、KB、MB、GB的字符串
     */
    public static String getAutoFileOrFilesSize(String filePath) {
        File file = new File(filePath);
        long blockSize = 0;
        try {
            if (file.isDirectory()) {
                blockSize = getFileSizes(file);
            } else {
                blockSize = getFileSize(file);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return formatFileSize(blockSize);
    }

    /**
     * 获取指定文件大小
     */
    private static long getFileSize(File file) throws Exception {
        long size = 0;
        if (file.exists()) {
            FileInputStream fis = new FileInputStream(file);
            size = fis.available();
        } else {
            file.createNewFile();
        }
        return size;
    }

    /**
     * 获取指定文件夹
     */
    private static long getFileSizes(File f) throws Exception {
        long size = 0;
        File[] list = f.listFiles();
        assert list != null;
        for (File file : list) {
            if (file.isDirectory()) {
                size = size + getFileSizes(file);
            } else {
                size = size + getFileSize(file);
            }
        }
        return size;
    }

    /**
     * 转换文件大小
     */
    public static String formatFileSize(long fileS) {
        DecimalFormat df = new DecimalFormat("#.00");
        String fileSizeString = "";
        String wrongSize = "0B";
        if (fileS == 0) {
            return wrongSize;
        }
        if (fileS < SIZE_TYPE_KB_SIZE) {
            fileSizeString = df.format((double) fileS) + "B";
        } else if (fileS < SIZE_TYPE_MB_SIZE) {
            fileSizeString = df.format((double) fileS / SIZE_TYPE_KB_SIZE) + "KB";
        } else if (fileS < SIZE_TYPE_GB_SIZE) {
            fileSizeString = df.format((double) fileS / SIZE_TYPE_MB_SIZE) + "MB";
        } else {
            fileSizeString = df.format((double) fileS / SIZE_TYPE_GB_SIZE) + "GB";
        }
        return fileSizeString;
    }

    /**
     * 转换文件大小,指定转换的类型
     */
    private static double formetFileSize(long fileS, int sizeType) {
        DecimalFormat df = new DecimalFormat("#.00");
        double fileSizeLong = 0;
        switch (sizeType) {
            case SIZE_TYPE_B:
                fileSizeLong = Double.valueOf(df.format((double) fileS));
                break;
            case SIZE_TYPE_KB:
                fileSizeLong = Double.valueOf(df.format((double) fileS / SIZE_TYPE_KB_SIZE));
                break;
            case SIZE_TYPE_MB:
                fileSizeLong = Double.valueOf(df.format((double) fileS / SIZE_TYPE_MB_SIZE));
                break;
            case SIZE_TYPE_GB:
                fileSizeLong = Double.valueOf(df.format((double) fileS / SIZE_TYPE_GB_SIZE));
                break;
            default:
                break;
        }
        return fileSizeLong;
    }


    /**
     * 校验文件大小
     * @param file
     * @return 如果当前文件大于20MB 返回ture 否则返回false
     */
    public static boolean greaterThanTwenty(MultipartFile file){
        return file.getSize() > TWENTY_MB_SIZE;
    }

    /**
     * 校验文件大小
     * @param file
     * @return 如果当前文件大于200MB 返回ture 否则返回false
     */
    public static boolean greaterThanTwoHundred(MultipartFile file){
        return file.getSize() > TWO_HUNDRED_MB_SIZE;
    }



    /**
     * url资源转化为file流
     *
     * @param url
     * @return
     */
    public static File urlToFile(URL url) {
        InputStream is = null;
        File file = null;
        FileOutputStream fos = null;
        try {
            file = File.createTempFile("tmp", null);
            HttpUtils.trustAllHttpsCertificates();
            URLConnection urlConn = url.openConnection();
            is = urlConn.getInputStream();
            fos = new FileOutputStream(file);
            byte[] buffer = new byte[4096];
            int length;
            while ((length = is.read(buffer)) > 0) {
                fos.write(buffer, 0, length);
            }
            return file;
        } catch (Exception e) {
            return null;
        } finally {
            IOUtils.closeQuietly(is);
            IOUtils.closeQuietly(fos);
        }
    }

}