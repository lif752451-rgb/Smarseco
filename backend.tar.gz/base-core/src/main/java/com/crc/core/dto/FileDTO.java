package com.crc.core.dto;

import lombok.Builder;
import lombok.Data;

import java.io.Serializable;

/**
 * @Author shufengfeng
 * @Description 文件传输对象
 * @DateTime 2022/3/14 10:33
 */
@Data
@Builder
public class FileDTO implements Serializable {

    private static final long serialVersionUID = 8253238405474564869L;

    /**
     * 文件的访问路径
     */
    private String url;

    /**
     * 文件名称
     */
    private String fileName;

    /**
     * 名称
     */
    private String name;

    /**
     * 创建时间
     */
    private String createTime;

    /**
     * 创建人
     */
    private String createBy;
}
