package com.crc.core.dto;

import lombok.Data;

@Data
public class LicenseVo {
    
    private String cpuId;
    private String mac;
    
    /*
      客户名称
     */
    private String clientName;
    /*
      项目名称
     */
    private String projName;
    /*
      项目类型
     */
    private String projType;
    /*
      项目范围
     */
    private String projScope;
    
    /*
      开始时间
     */
    private String startTime;
    
    /*
      结束时间
     */
    private String endTime;
    
    /**
     授权时效类型  1 有限期限 2 永久
     */
    private String licType;
    /*
     创建时间
     */
    private String createTime;
    
    /*
      备注
     */
    private String remark;
}
