package com.crc.core.dto;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.ToString;

import java.util.List;

/**
 * 企业微信DTO
 *
 * @Author fuzhuangzhi
 * @Date 2023/2/9 16:19
 * @Version 1.0
 **/
@Data
@Builder
@ToString
@AllArgsConstructor
public class MsgSendDTO {
    /**
     * to 消息接收人
     */
    private List<String> to;

    /**
     * msg 消息内容
     */
    private String msg;

    /**
     * 企业微信：text 文本 file：文件
     * 飞书： text：文本 文件格式 image 文件格式 post
     */
    private String type;

    /**
     * 标题
     */
    private String title;

    /**
     * 文件路径
     */
    private String imgPath;

}
