package com.crc.core.properties;

import lombok.Data;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.context.annotation.Configuration;

/**
 * druid 配置属性
 *
 * @author wst
 */
@Data
@Configuration
@ConfigurationProperties(prefix = "spring.datasource.druid.master")
public class DruidJdbcProperties {
    private String url;

    private String username;

    private String password;
}
