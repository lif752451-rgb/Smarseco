package com.crc.core.utils;

import com.baomidou.mybatisplus.core.enums.SqlMethod;
import com.baomidou.mybatisplus.core.toolkit.ReflectionKit;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.baomidou.mybatisplus.extension.toolkit.SqlHelper;
import com.crc.common.utils.SqlUtil;
import lombok.experimental.UtilityClass;
import org.apache.ibatis.logging.Log;
import org.apache.ibatis.logging.LogFactory;

import java.util.Collection;
import java.util.HashMap;
import java.util.Map;

import static com.baomidou.mybatisplus.core.toolkit.Constants.WRAPPER;

/**
 * Mybatis工具类
 *
 * @author zhangbing
 */
@UtilityClass
public class MyBatisUtil {

    /**
     * 批量更新自定义更新条件
     * 
     * @param serviceImplClass serviceImplClass
     * @param list update数据源
     * @param <E> entity
     * @return boolean
     */
    public <E> boolean batchUpdateWrapper(Class<?> serviceImplClass, Collection<E> list) {
        Log log = LogFactory.getLog(serviceImplClass);
        Class<?> mapperClass = ReflectionKit.getSuperClassGenericType(serviceImplClass, ServiceImpl.class, 0);
        String sqlStatement = SqlHelper.getSqlStatement(mapperClass, SqlMethod.UPDATE);
        Class<?> entityClass = ReflectionKit.getSuperClassGenericType(serviceImplClass, ServiceImpl.class, 1);
        return SqlHelper.executeBatch(entityClass, log, list, SqlUtil.DEFAULT_BATCH_SIZE, (sqlSession, entity) -> {
            Map<String, Object> map = new HashMap<>(1);
            map.put(WRAPPER, entity);
            sqlSession.update(sqlStatement, map);
        });
    }
}
