package com.crc.core.dto;

import com.alibaba.fastjson.annotation.JSONField;
import io.swagger.annotations.ApiModelProperty;
import lombok.Builder;
import lombok.Data;
import lombok.ToString;

import java.util.List;

/**
 * 华为OA待办DTO
 *
 * @Author fuzhuangzhi
 * @Date 2023/1/29 17:53
 * @Version 1.0
 **/
@Data
@Builder
@ToString
public class HwOaWaitDTO {

    /**
     * 标识待办来源的系统
     * 注：未设置该参数的情况下，无法识别待办的来源，待办来源将默认为当前提供服务的系统
     * 建议第三方系统调用接口时设置该参数，以便当前提供服务的系统能够区分待办的来源
     */
    @ApiModelProperty(value = "标识待办来源的系统")
    private String appName;

    /**
     * 标识待办来源的模块
     */
    @ApiModelProperty(value = "标识待办来源的模块")
    private String modelName;

    /**
     * 标识待办在原系统唯一标识
     */
    @ApiModelProperty(value = "标识待办在原系统唯一标识")
    private String modelId;

    /**
     * 操作类型 1:表示设待办为已办操作
     * 2:表示设置目标待办所属人为已办操作
     */
    @ApiModelProperty(value = "操作类型")
    private Integer optType;

    /**
     * 待办标题
     */
    @ApiModelProperty(value = "待办标题")
    private String subject;

    /**
     * 对应待办的链接地址(全路径)
     */
    @ApiModelProperty(value = "对应待办的链接地址(全路径)")
    private String link;

    /**
     * 收件人信息
     */
    @ApiModelProperty(value = "收件人信息")
    private String targets;

    /**
     * 创建时间
     */
    @ApiModelProperty(value = "创建时间")
    private String createTime;

    /**
     * 待办创建者
     */
    @ApiModelProperty(value = "待办创建者")
    private String docCreator;

    /**
     * 待办类型，1:表示审批类待办
     * 2:表示为通知类待办
     */
    @ApiModelProperty(value = "待办类型")
    private Integer type;

    /**
     * 待办优先级。如：按紧急（1）、急（2）、一般（3）。
     */
    @ApiModelProperty(value = "待办优先级")
    private Integer level;

    /**
     * 测试接收用户
     */
    @ApiModelProperty(value = "测试接收用户")
    private List<String> testUser;

    /**
     * 发送API地址
     */
    @ApiModelProperty(value = "发送API地址")
    @JSONField(serialize = false)
    private String sendUrl;

    /**
     * 是否为更新待办提醒 true 属于 false 不属于，主要用于设置测试收件对象
     */
    @ApiModelProperty(value = "是否属于更新操作")
    @JSONField(serialize = false)
    private Boolean updateFlag;

    @Data
    @Builder
    @ToString
   public static class TargetPerson {
        /**
         * EKP系统组织架构唯一标识
         */
        @ApiModelProperty(value = "EKP系统组织架构唯一标识")
        @JSONField(name = "Id")
        private String id;

        /**
         * EKP系统组织架构个人编号
         */
        @ApiModelProperty(value = "EKP系统组织架构个人编号")
        @JSONField(name = "PersonNo")
        private String personNo;

        /**
         * EKP系统组织架构部门编号
         */
        @ApiModelProperty(value = "EKP系统组织架构部门编号")
        @JSONField(name = "DeptNo")
        private String deptNo;

        /**
         * EKP系统组织架构岗位编号
         */
        @ApiModelProperty(value = "EKP系统组织架构岗位编号")
        @JSONField(name = "PostNo")
        private String postNo;

        /**
         * EKP系统组织架构常用群组编号
         */
        @ApiModelProperty(value = "EKP系统组织架构常用群组编号")
        @JSONField(name = "GroupNo")
        private String groupNo;

        /**
         * EKP系统组织架构个人登录名
         */
        @ApiModelProperty(value = "EKP系统组织架构个人登录名")
        @JSONField(name = "LoginName")
        private String loginName;

        /**
         * EKP系统组织架构关键字
         */
        @ApiModelProperty(value = "EKP系统组织架构关键字")
        @JSONField(name = "Keyword")
        private String keyword;

        /**
         * 和LDAP集成时LDAP中DN值
         */
        @ApiModelProperty(value = "和LDAP集成时LDAP中DN值")
        @JSONField(name = "LdapDN")
        private String ldapDN;
    }
}
