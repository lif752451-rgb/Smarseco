package com.crc.core.transaction.config;

import com.crc.core.datasource.DynamicDataSource;
import com.crc.core.mybatis.config.MyBatisMapperScannerConfig;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.boot.autoconfigure.AutoConfigureAfter;
import org.springframework.boot.autoconfigure.condition.ConditionalOnMissingBean;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.jdbc.datasource.DataSourceTransactionManager;
import org.springframework.transaction.PlatformTransactionManager;

/**
 * @classname: TransactionManagementConfig
 * @description: 事物类配置
 * @author: cymiao
 * @create: 2021-05-12 18:08
 **/
@Configuration
@AutoConfigureAfter(MyBatisMapperScannerConfig.class)
public class TransactionManagementConfig {

    @Autowired
    @Qualifier("dynamicDataSource")
    private DynamicDataSource dynamicDataSource;

    @Bean(name = "transactionManager")
    @ConditionalOnMissingBean
    public PlatformTransactionManager transactionManager() {
        return new DataSourceTransactionManager(dynamicDataSource);
    }
}
