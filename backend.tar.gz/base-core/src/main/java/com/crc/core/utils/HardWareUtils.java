package com.crc.core.utils;

import lombok.extern.slf4j.Slf4j;
import org.apache.commons.io.IOUtils;
import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import oshi.SystemInfo;
import oshi.hardware.CentralProcessor;
import oshi.hardware.ComputerSystem;
import oshi.hardware.HardwareAbstractionLayer;

import java.io.InputStream;

/**
 * Created by JAVA on 2018/7/26.
 * 本来写的是一个获取本机一些参数，作为源来进行加密的类，
 * 项目里只用到了硬盘编号，就没有用到这个类
 */
@Slf4j
public class HardWareUtils {

    /**
     * 获取主板序列号
     *
     * @return
     */
    public static String getMotherboardSN() {
        SystemInfo systemInfo = new SystemInfo();
        HardwareAbstractionLayer hardwareAbstractionLayer = systemInfo.getHardware();
        ComputerSystem computerSystem = hardwareAbstractionLayer.getComputerSystem();
        return computerSystem.getSerialNumber();
    }

    /**
     * 获取CPU序列号
     *
     * @return
     */
    public static String getCPUSerial() {
        SystemInfo systemInfo = new SystemInfo();
        HardwareAbstractionLayer hardwareAbstractionLayer = systemInfo.getHardware();
        CentralProcessor centralProcessor = hardwareAbstractionLayer.getProcessor();
        return centralProcessor.getProcessorIdentifier().getProcessorID();
    }

}
