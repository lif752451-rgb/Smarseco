package com.crc.core.utils;

import cn.hutool.core.codec.Base64;
import org.apache.commons.lang3.StringUtils;

import java.nio.charset.StandardCharsets;

public class SimpleCodeTool {

    private final static String SPIT_KEY = "#####";

    public static String encrypt(String enc) {
        if (org.apache.commons.lang3.StringUtils.isBlank(enc)) {
            return enc;
        }
        enc = enc + SPIT_KEY + enc;
        return Base64.encode(enc.getBytes(StandardCharsets.UTF_8));
    }

    public static String encryptBase64(String enc) {
        if (org.apache.commons.lang3.StringUtils.isBlank(enc)) {
            return enc;
        }
        return Base64.encode(enc.getBytes(StandardCharsets.UTF_8));
    }

    public static String decrypt(String dec) {
        if (StringUtils.isBlank(dec)) {
            return dec;
        }
        byte[] bytes = Base64.decode(dec.getBytes(StandardCharsets.UTF_8));
        String des = new String(bytes, StandardCharsets.UTF_8);
        return des.split(SPIT_KEY)[0];
    }

    public static String decryptBase64(String dec) {
        if (StringUtils.isBlank(dec)) {
            return dec;
        }
        byte[] bytes = Base64.decode(dec.getBytes(StandardCharsets.UTF_8));
        return new String(bytes, StandardCharsets.UTF_8);
    }

    public static void main(String[] args) {
        String s="you are right";
        String enc = encrypt(s);
        String dec = decrypt(enc);
        System.out.println(enc);
        System.out.println(dec);
    }
}
