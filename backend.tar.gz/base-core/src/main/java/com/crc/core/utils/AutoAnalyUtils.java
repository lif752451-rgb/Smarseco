package com.crc.core.utils;


import cn.hutool.core.net.URLEncodeUtil;
import com.alibaba.fastjson.JSONArray;
import com.alibaba.fastjson.JSONObject;
import com.crc.common.utils.DataUtils;
import com.crc.common.utils.JsonUtils;
import com.crc.common.utils.http.HttpClientUtils;
import com.crc.core.config.AutoAnalyConfig;
import lombok.extern.slf4j.Slf4j;
import org.apache.http.client.config.RequestConfig;
import org.apache.http.client.methods.CloseableHttpResponse;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.impl.client.CloseableHttpClient;

/**
 * 自动化分析平台
 */

@Slf4j
public class AutoAnalyUtils {
    private static String getToken(AutoAnalyConfig config) {
        String url = config.getAddress();
        String prefix = "/api/token/login?key=%s&name=%s";
        //获取扫描器信息
        String newUrl = url + String.format(prefix,config.getKey(),config.getUserName());
        log.info(newUrl);
        HttpPost httpRequest = new HttpPost(newUrl);
        RequestConfig requestConfig = RequestConfig.custom()
                .setConnectTimeout(45000).setConnectionRequestTimeout(45000)
                .setSocketTimeout(45000).build();
        /*
        {
            "msg": "success",
            "result": {
                "login_time": "2024-01-25 14:50:25",
                "failure_time": "2024-01-25 17:50:25",
                "token": "token:c10c1a9457014bfb8822c3765e0b783a17061654523360"
            },
            "retCode": "1"
        }
         */
        httpRequest.setConfig(requestConfig);
        try (CloseableHttpClient httpClient = HttpClientUtils.getHttpClient();
             CloseableHttpResponse response = httpClient.execute(httpRequest)) {
            int code = response.getStatusLine().getStatusCode();
            if (code == 200) {
                String ret = DataUtils.toBodyString(response.getEntity());
                JSONObject result = JsonUtils.parse(ret);
                if (JsonUtils.equalVal(result, "msg", "success")) {
                    //重新登录获取session
                    return JsonUtils.getStr(result.getJSONObject("result"), "token");
                } else {
                    log.error("自动化分析平台登录错误！" + ret);
                }
            } else {
                String ret = DataUtils.toBodyString(response.getEntity());
                log.error("自动化分析平台登录错误！" + ret);
            }
        } catch (Exception e) {
            log.error(e.getMessage(), e);
        }
        return null;
    }

    public static JSONArray getThreatInfo(AutoAnalyConfig config,String value) {
        String url = config.getAddress();
        //http://10.9.0.165:8060/api/security/scan/search?taskId=59
        String prefix = "/api/security/intelligence/search?search_key=%s";
        //获取扫描器信息
        String newUrl = url + String.format(prefix, URLEncodeUtil.encode(value));
        log.info(newUrl);
        HttpPost httpRequest = new HttpPost(newUrl);
        RequestConfig requestConfig = RequestConfig.custom()
                .setConnectTimeout(45000).setConnectionRequestTimeout(45000)
                .setSocketTimeout(45000).build();
        /*
        {
            "msg": "success",
            "result": {
                "openvasTaskId": "557a5696-c554-4bec-a77a-ce621aa29be7",
                "vulnCount": 25,
                "endDate": "2024-01-25 14:39:30.0",
                "scanId": 9329103,
                "ip": "10.9.254.170",
                "updateTime": "2024-01-25 14:39:30.0",
                "openvasReportContent": null,
                "loadReportStatus": null,
                "openvasProgress": -1,
                "openvasTaskStatus": "2",
                "openvasReportId": "c52568cf-9bef-46bc-be93-9af811316a8a",
                "openvasTargetId": "cc70feb4-cec8-45bf-a151-79ad92b554ae",
                "taskId": 59,
                "startDate": "2024-01-25 14:28:19.0"
            },
            "retCode": "1"
        }
         */
        httpRequest.setConfig(requestConfig);
        httpRequest.setHeader("token",getToken(config));
        try (CloseableHttpClient httpClient = HttpClientUtils.getHttpClient();
             CloseableHttpResponse response = httpClient.execute(httpRequest)) {
            int code = response.getStatusLine().getStatusCode();
            if (code == 200) {
                String ret = DataUtils.toBodyString(response.getEntity());
                JSONObject result = JsonUtils.parse(ret);
                if (JsonUtils.equalVal(result, "msg", "success")) {
                    //重新登录获取session
                    return result.getJSONArray("result");
                } else {
                    log.error("自动化分析平台获取任务错误！" + ret);
                }
            } else {
                String ret = DataUtils.toBodyString(response.getEntity());
                log.error("自动化分析平台获取任务错误！" + ret);
            }
        } catch (Exception e) {
            log.error(e.getMessage(), e);
        }
        return null;
    }

    public static void main(String[] args) {
        AutoAnalyConfig config = new AutoAnalyConfig();
        config.setAddress("http://10.9.0.165:8060");
        config.setKey("7c91cc5e-7507-8b66-a01d-71b77327af8c");
        config.setUserName("api_user");


        JsonUtils.print(getThreatInfo(config,"127.0.0.1"));
    }
}
