package com.crc.core.config;

import lombok.Data;
import org.springframework.boot.context.properties.ConfigurationProperties;

/**
 * 限流配置类
 */
@Data
@ConfigurationProperties(prefix = "limit")
public class RateLimiterProperties {

    /**
     * 漏洞管理-漏洞闭环-自动提交漏洞数据处理限流数
     */
    private Integer vulnAutoStartNum;

    /**
     * 漏洞管理-漏洞闭环-复查已修复漏洞数据处理限流数
     */
    private Integer vulnAutoReviewPassNum;

    /**
     * 漏洞管理-漏洞闭环-复查未修复漏洞数据处理限流数
     */
    private Integer vulnAutoReviewRejectNum;

    /**
     * 漏洞管理-漏洞闭环-全量漏洞已修复漏洞数据处理限流数
     */
    private Integer vulAutoAllReviewPassNum;

    /**
     * 漏洞管理-漏洞闭环-全量漏洞未修复漏洞数据处理限流数
     */
    private Integer vulAutoAllReviewRejectNum;

}