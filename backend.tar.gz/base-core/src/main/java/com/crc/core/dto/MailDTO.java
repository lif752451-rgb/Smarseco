package com.crc.core.dto;

import com.crc.core.model.FileVO;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.ToString;

import java.util.Date;
import java.util.List;
import java.util.Map;

@Data
@Builder
@ToString
@AllArgsConstructor
public class MailDTO {
    /**
     * from 邮件发送人
     */
    private String from;
    /**
     * to 邮件接收人
     */
    private String to;
    /**
     * subject 邮件主题
     */
    private String subject;
    /**
     * text 邮件内容
     */
    private String text;
    /**
     * inLine 内联资源
     */
    private Map<String,String> inLine;
    /**
     * sentDate 发送时间
     */
    private Date sentDate;
    /**
     * cc 密送
     */
    private String cc;
    /**
     * bcc 密送
     */
    private String bcc;
    /**
     * status 状态
     */
    private String status;
    /**
     * error 报错信息
     */
    private String error;
    /**
     * files 邮件附件
     */
    private List<FileVO> files;

}
