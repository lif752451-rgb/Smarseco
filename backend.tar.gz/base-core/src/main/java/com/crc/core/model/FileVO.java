package com.crc.core.model;

import lombok.Data;

/**
 * 附件公共类
 */
@Data
public class FileVO {

    /**
     * 文件的访问路径
     */
    private String url;

    /**
     * 文件名称
     */
    private String fileName;

    /**
     * 名称
     */
    private String name;
}