package com.crc.core.model;

import com.baomidou.mybatisplus.annotation.TableField;
import com.baomidou.mybatisplus.annotation.TableId;
import com.crc.common.utils.StringUtils;
import com.fasterxml.jackson.annotation.JsonFormat;
import lombok.Data;

import java.io.Serializable;
import java.util.Date;
import java.util.List;

/**
 * @ClassName BasicEntity
 * @Description: 基类
 **/
@Data
public class BasicStringEntity implements Serializable {

    private static final long serialVersionUID = 1L;

    /**
     * 唯一主键
     */
    @TableId(value = "id")
    private String id;

    /**
     * id集合
     */
    @TableField(exist = false)
    private List<String> ids;

    /**
     * 角色名称集合
     */
    @TableField(exist = false)
    private List<String> roleNames;

    /**
     * type集合
     */
    @TableField(exist = false)
    private List<String> types;

    /**
     * 搜素-开始时间(按创建时间)
     */
    @TableField(exist = false)
    private String startDate;

    /**
     * 搜素-结束时间(按创建时间)
     */
    @TableField(exist = false)
    private String endDate;

    /**
     * 搜素-开始日期(按修改时间)
     */
    @TableField(exist = false)
    private String startTime;

    /**
     * 搜素-结束日期(按修改时间)
     */
    @TableField(exist = false)
    private String endTime;

    /**
     * 创建者
     */
    @TableField(value = "create_by")
    private String createBy;

    /** 创建时间 */
    @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss", timezone = "GMT+8")
    @TableField(value = "create_time")
    private Date createTime;

    /** 更新者 */
    @TableField(value = "update_by")
    private String updateBy;

    /** 更新时间 */
    @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss", timezone = "GMT+8")
    @TableField(value = "update_time")
    private Date updateTime;

    @TableField(exist = false)
    private Integer pageNum;

    @TableField(exist = false)
    private Integer pageSize;

    @TableField(exist = false)
    private String searchValue;

    @TableField(exist = false)
    private String keyword;

    @TableField(exist = false)
    private String orderByColumn;

    /** 排序的方向 "desc" 或者 "asc". */
    @TableField(exist = false)
    private String isAsc;

    public String getOrderBy() {
        if (StringUtils.isEmpty(orderByColumn)) {
            return "";
        }
        return StringUtils.toUnderScoreCase(orderByColumn) + " " + isAsc;
    }
}
