package com.crc.core.utils;

import cn.hutool.system.oshi.OshiUtil;
import com.crc.common.utils.IpUtil;
import lombok.extern.slf4j.Slf4j;
import oshi.SystemInfo;
import oshi.hardware.CentralProcessor;
import oshi.hardware.HardwareAbstractionLayer;
import oshi.hardware.NetworkIF;

import java.net.Inet4Address;
import java.net.InetAddress;
import java.net.NetworkInterface;
import java.util.ArrayList;
import java.util.Enumeration;
import java.util.List;

/**
 * @author jixiangqi
 * @date 2023/11/13
 */
@Slf4j
public class CpuTool {

    /**
     * 获取当前系统CPU序列，可区分linux系统和windows系统
     */
    public static String getCpuId() {
        SystemInfo systemInfo = new SystemInfo();
        HardwareAbstractionLayer hardwareAbstractionLayer = systemInfo.getHardware();
        CentralProcessor centralProcessor = hardwareAbstractionLayer.getProcessor();
        return centralProcessor.getProcessorIdentifier().getProcessorID().toUpperCase();
    }

    /**
     * MAC
     * 通过jdk自带的方法,先获取本机所有的ip,然后通过NetworkInterface获取mac地址
     *
     * @return
     */
    public static String getMac() {
        StringBuilder resultStr = new StringBuilder();
        try {
            List<NetworkIF> nets = OshiUtil.getNetworkIFs();
            if (nets != null) {
                for (NetworkIF nif : nets) {
                    if (nif.getIPv4addr() == null || nif.getMacaddr() == null) {
                        continue;
                    }
                    List<String> ipList = new ArrayList<>();
                    for (String ip : nif.getIPv4addr()) {
                        if (!"127.0.0.1".equals(ip) && IpUtil.isIP(ip)) {
                            ipList.add(ip);
                        }
                    }
                    if (ipList.size() > 0) {
                        String mac = nif.getMacaddr().replace(":","-").toUpperCase();
                        resultStr.append(mac).append(",");
                    }
                }
                return resultStr.toString().replace(",", "");
            }
        } catch (Exception e) {
            log.error(e.getMessage(), e);
        }
        try {

            List<String> ls = getLocalHostLANAddress();
            for (String str : ls) {
                InetAddress ia = InetAddress.getByName(str);// 获取本地IP对象
                // 获得网络接口对象（即网卡），并得到mac地址，mac地址存在于一个byte数组中。
                byte[] mac = NetworkInterface.getByInetAddress(ia)
                        .getHardwareAddress();
                if (mac == null) {
                    log.error("MAC NUll");
                    return "";
                }
                // 下面代码是把mac地址拼装成String
                StringBuilder sb = new StringBuilder();
                for (int i = 0; i < mac.length; i++) {
                    if (i != 0) {
                        sb.append("-");
                    }
                    // mac[i] & 0xFF 是为了把byte转化为正整数
                    String s = Integer.toHexString(mac[i] & 0xFF);
                    sb.append(s.length() == 1 ? 0 + s : s);
                }
                // 把字符串所有小写字母改为大写成为正规的mac地址并返回
                resultStr.append(sb.toString().toUpperCase()).append(",");
            }
            return resultStr.toString().replace(",", "");
        } catch (Exception e) {
            log.error(e.getMessage(), e);
        }
        return null;
    }

    private static List<String> getLocalHostLANAddress() throws Exception {
        List<String> ips = new ArrayList<>();
        Enumeration<NetworkInterface> interfs = NetworkInterface.getNetworkInterfaces();
        while (interfs.hasMoreElements()) {
            NetworkInterface interf = interfs.nextElement();
            Enumeration<InetAddress> addres = interf.getInetAddresses();
            while (addres.hasMoreElements()) {
                InetAddress in = addres.nextElement();
                if (in instanceof Inet4Address) {
                    //System.out.println("v4:" + in.getHostAddress());
                    if (!"127.0.0.1".equals(in.getHostAddress()) && IpUtil.isIP(in.getHostAddress())) {
                        ips.add(in.getHostAddress());
                    }
                }
            }
        }
        return ips;
    }

    public static String getClientCode() {
        String cpuId = getCpuId();
        String mac = getMac();
        String code = cpuId + "##" + mac;
        log.info("**data**:{}",code);
        return CodeTool.encrypt(code);
    }

    public static void main(String[] args) throws Exception {
        System.out.println(CpuTool.getClientCode());
    }
}
