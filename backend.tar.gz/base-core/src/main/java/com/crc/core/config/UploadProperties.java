package com.crc.core.config;

import lombok.Data;
import org.springframework.boot.context.properties.ConfigurationProperties;

import java.util.List;

/**
 * @Author shufengfeng
 * @Description 上传文件常量
 * @DateTime 2022/3/14 10:29
 */
@ConfigurationProperties(prefix = "upload")
@Data
public class UploadProperties {

    /**
     * 返回文件上传路径前缀
     */
    private String baseUrl;

    /**
     * 上传文件格式限制
     */
    private List<String> allowTypes;


    /**
     * 历史数据迁移后路径前缀
     */
    private String historyUrl;



}