package com.crc.core;

import cn.hutool.core.util.IdUtil;
import com.crc.common.utils.IdGen;
import com.crc.common.utils.IdUtils;
import com.crc.common.utils.UUID;
import org.jasypt.encryption.pbe.StandardPBEStringEncryptor;
import org.jasypt.encryption.pbe.config.EnvironmentPBEConfig;
import org.junit.Assert;
import org.junit.Test;

public class JasyptTest {

    @Test
    public void testEncryptAndDecrypt() throws Exception {
        StandardPBEStringEncryptor standardPBEStringEncryptor = new StandardPBEStringEncryptor();
        EnvironmentPBEConfig config = new EnvironmentPBEConfig();

        // 加密的算法，这个算法是默认的
        config.setAlgorithm("PBEWithMD5AndDES");
        // 加密的密钥，随便自己填写，很重要千万不要告诉别人
        config.setPassword("IpTFX6FjYs5zKDG8gjKFh7kTgCFdWWJE");
        standardPBEStringEncryptor.setConfig(config);
        String plainText = "BU@15bn4";         //自己的密码
        String encryptedText = standardPBEStringEncryptor.encrypt(plainText);
        String decryptText = standardPBEStringEncryptor.decrypt(encryptedText);
        System.out.println(encryptedText);
        Assert.assertEquals(plainText, decryptText);
    }

    @Test
    public void testEncrypt() throws Exception {
        StandardPBEStringEncryptor standardPBEStringEncryptor = new StandardPBEStringEncryptor();
        EnvironmentPBEConfig config = new EnvironmentPBEConfig();

        config.setAlgorithm("PBEWithMD5AndDES");          // 加密的算法，这个算法是默认的
        config.setPassword("IpTFX6FjYs5zKDG8gjKFh7kTgCFdWWJE");                        // 加密的密钥，随便自己填写，很重要千万不要告诉别人
        standardPBEStringEncryptor.setConfig(config);
        String plainText = "123456";         //自己的密码
        String encryptedText = standardPBEStringEncryptor.encrypt(plainText);
        System.out.println(encryptedText);
    }


    @Test
    public void testDecrypt() throws Exception {
        StandardPBEStringEncryptor standardPBEStringEncryptor = new StandardPBEStringEncryptor();
        EnvironmentPBEConfig config = new EnvironmentPBEConfig();

        config.setAlgorithm("PBEWithMD5AndDES");
        config.setPassword("IpTFX6FjYs5zKDG8gjKFh7kTgCFdWWJE");
        standardPBEStringEncryptor.setConfig(config);
        String encryptedText = "KaHHHgEG6tuav+iUtFtAgk3+9fknlQuHBxjIeBHUwgTsTSXBTIKxKkIjmJdZpiR8lJ+XIC1q2jc=";   //加密后的密码
        String plainText = standardPBEStringEncryptor.decrypt(encryptedText);
        System.out.println(plainText);
    }

    public static void main(String[] args) {
        for(int i=0; i<20000; i++) {
            System.out.println(IdGen.uuid());
        }
    }
}
