package com.crc.common.utils;

import java.text.NumberFormat;

/**
 * @author simba@onlying.cn
 * @date 2020/9/3 20:24
 */
public class MathUtil {

    public static String percent(Long num1, Long num2) {
        NumberFormat numberFormat = NumberFormat.getInstance();
        numberFormat.setMaximumFractionDigits(2);
        if (num1 == 0) {
            return "0%";
        }
        return numberFormat.format((float)num1 / (float)num2 * 100) + "%";
    }
}
