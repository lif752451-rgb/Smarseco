package com.crc.common.utils.youdu;


public class AESCryptoException extends GeneralEntAppException {

    public AESCryptoException(String message, Throwable cause) {
        super(message, cause);
    }
}
