package com.crc.common.model.enums;

import lombok.Getter;
import org.apache.commons.lang3.StringUtils;

/**
 * @Author shufengfeng
 * @Description 角色枚举类
 * @DateTime 2021/8/27 17:10
 */
@Getter
public enum SysRoleEnum {
    /**
     * 普通角色
     */
    COMMON("普通角色", "common"),
    /**
     * 安全工程师
     */
    SAFETY_ENGINEER("安全工程师", "alarmEngineer"),
    /**
     * 安全接口人
     */
    SECURITY_USER("安全接口人", "alarmUnitConnect"),
    /**
     * 安全处理人
     */
    SECURITY_DEAL_USER("安全处理人", "alarmUnitHandle"),
    /**
     * 风险管理人
     */
    RISK_MANAGER("风险管理人", "riskAdministrator"),
    /**
     * 风险验证人
     */
    RISK_VALIDATE("风险验证人", "riskVerifier"),
    /**
     * 超级管理员
     */
    SUPER("超级管理员", "super"),
    /**
     * 管理员
     */
    ADMIN("管理员", "admin"),
    /**
     * 一级接口人
     */
    FIRST_LEVEL_LIAISON_OFFICER("一级接口人", "firstLevelConnect"),
    /**
     * 二级接口人
     */
    SECOND_LEVEL_LIAISON_OFFICER("二级接口人", "secondLevelConnect"),
    /**
     * 集团管理员
     */
    GROUP_ADMIN("集团管理员", "group_admin"),
    /**
     * 实际处置人
     */
    REAL_HANDLE_PERSON("实际处置人", "secondLevelHandle"),
    /**
     * 漏洞白名单审核组
     */
    RISK_LEAK_WHITE_LIST_AUDIT("漏洞白名单审核组", "riskLeakWhitelistAudit"),
    /**
     * 风险延期审批人
     */
    RISK_DEFERRED_AUDIT("风险延期审批人", "riskDeferredAudit"),

    /**
     * 告警白名单审核组
     */
    ALARM_WHITE_LIST_AUDIT("告警白名单审核组", "alarmWhitelistAudit"),

    /**
     * 告警白名单提交人
     */
    ALARM_WHITE_LIST_SUBMIT("告警白名单提交人", "alarmWhitelistSubmit"),

    /**
     * 集团资产管理员
     */
    ASSETS_GROUP_ADMIN("集团资产管理员", "assetsGroupAdmin"),

    /**
     * 告警集团管理员
     */
    ALARM_GROUP_ADMIN("告警集团管理员", "alarmGroupAdmin"),

    /**
     * 告警单位管理员
     */
    ALARM_UNIT_ADMIN("告警单位管理员", "alarmUnitAdmin"),

    /**
     * 安全报告接口人
     */
    SEC_REPORT_SET_CONNECT("安全报告接口人", "secReportSetConnect"),

    /**
     * 安全报告管理员
     */
    SEC_REPORT_ADMIN("安全报告管理员", "secReportAdmin"),

    /**
     * 安全报告查看
     */
    SEC_REPORT_SEE("安全报告查看", "secReportSee"),

    /**
     * 告警监控组
     */
    HVV_ALARM_MONITOR("告警监控组", "hvvAlarmMonitor"),

    /**
     * 分析研判组
     */
    HVV_ALARM_ANALYSIS_JUDGE("分析研判组", "hvvAnalysisJudge"),

    /**
     * 应急处置组
     */
    HVV_ALARM_EMERGE_DISPOSAL("应急处置组", "hvvEmergeDisposal"),

    /**
     * 后续跟进组
     */
    HVV_ALARM_FOLLOW_UP("后续跟进组", "hvvFollowUp"),

    /**
     * 审核专家组
     */
    HVV_ALARM_AUDIT_EXPERT("审核专家组", "hvvAuditExpert"),

    /**
     * 审核专家
     */
    AUDIT_EXPERT("审核专家", "auditExpert"),

    /**
     * 追踪溯源组
     */
    HVV_ALARM_TRACE_SOURCE("追踪溯源组", "hvvTraceSource"),

    /**
     * IP资产责任人
     */
    IP_ASSET_DUTY("IP资产责任人", "ipAssetDuty"),

    /**
     * 漏洞处置组
     */
    VULN_HANDLE("漏洞处置组", "vulnHandle"),

    /**
     * 漏洞审核组
     */
    VULN_AUDIT("漏洞审核组", "vulnAudit"),

    /**
     * 漏洞管理组
     */
    VULN_ADMIN("漏洞管理组", "vulnAdmin"),

    /**
     * 漏洞延期审批组
     */
    VULN_DELAY_AUDIT("漏洞延期审批组", "vulnDelayAudit"),

    /**
     * 漏洞部门负责人
     */
    VULN_DEPT_DUTY("漏洞部门负责人", "vulnDeptDuty"),

    /**
     * 漏洞白名单审核组
     */
    VULN_WHITELIST_AUDIT("漏洞白名单审核组", "vulnWhitelistAudit"),

    /**
     * 漏洞白名单审核组
     */
    VULN_WHITELIST_SEE("漏洞白名单查看测试", "vulnWhiteSee"),

    /**
     * 漏洞白名单审核组
     */
    VULN_WHITELIST_AUDIT_TEST("漏洞白名单审核测试", "vulnWhiteAuditTest"),

    /**
     * 漏洞白名单审核组
     */
    VULN_WHITELIST_DELETE("漏洞白名单删除测试", "vulnWhiteDelTest"),

    /**
     * 代码审计处置组
     */
    CODE_REVIEW_HANDLE("代码审计处置组", "codeReviewHandle"),

    /**
     * 代码审计处置组
     */
    CODE_HANDLE("代码审计处置组", "codeReviewHandle"),

    /**
     * 代码审计管理组
     */
    CODE_ADMIN("代码审计管理组", "codeReviewAdmin"),

    /**
     * 代码审计管理组
     */
    CODE_REVIEW_ADMIN("代码审计管理组", "codeReviewAdmin"),

    /**
     * 代码审计查询组
     */
    CODE_RESEARCH("代码审计查询组", "codeReviewResearch"),

    /**
     * 封堵任务管理组
     */
    BLOCK_TASK_ADMIN("封堵任务管理组", "blocktaskAdmin"),

    /**
     * 告警监控组(集团)
     */
    COMBAT_GROUP_MONITOR("告警监控组(集团)", "combatGroupMonitor"),

    /**
     * 分析研判组(集团)
     */
    COMBAT_GROUP_JUDGE("分析研判组(集团)", "combatGroupJudge"),

    /**
     * 应急处置组(集团)
     */
    COMBAT_GROUP_HANDLE("应急处置组(集团)", "combatGroupHandle"),

    /**
     * 后续跟进组(集团)
     */
    COMBAT_GROUP_FOLLOW("后续跟进组(集团)", "combatGroupFollow"),

    /**
     * 审核专家组(集团)
     */
    COMBAT_GROUP_AUDIT("审核专家组(集团)", "combatGroupAudit"),

    /**
     * 追踪溯源组(集团)
     */
    COMBAT_GROUP_TRACE("追踪溯源组(集团)", "combatGroupTrace"),

    /**
     * 实战指挥组(集团)
     */
    COMBAT_GROUP_COMMAND("实战指挥组(集团)", "combatGroupCommand"),

    /**
     * 告警监控组(租户)
     */
    COMBAT_TENANT_MONITOR("告警监控组(租户)", "combatTenantMonitor"),

    /**
     * 分析研判组(租户)
     */
    COMBAT_TENANT_JUDGE("分析研判组(租户)", "combatTenantJudge"),

    /**
     * 应急处置组(租户)
     */
    COMBAT_TENANT_HANDLE("应急处置组(租户)", "combatTenantHandle"),

    /**
     * 后续跟进组(租户)
     */
    COMBAT_TENANT_FOLLOW("后续跟进组(租户)", "combatTenantFollow"),

    /**
     * 审核专家组(租户)
     */
    COMBAT_TENANT_AUDIT("审核专家组(租户)", "combatTenantAudit"),

    /**
     * 追踪溯源组(租户)
     */
    COMBAT_TENANT_TRACE("追踪溯源组(租户)", "combatTenantTrace"),

    /**
     * 实战指挥组(租户)
     */
    COMBAT_TENANT_COMMAND("实战指挥组(租户)", "combatTenantCommand"),

    /**
     * 单位协调组(租户)
     */
    COMBAT_TENANT_COORDINATOR("单位协调组(租户)", "combatTenantCoordinator"),

    /**
     * 实战任务跟进组
     */
    COMBAT_TASK_FOLLOW("实战任务跟进组", "combatTaskFollow"),

    /**
     * 实战任务管理组
     */
    COMBAT_TASK_ADMIN("实战任务管理组", "combatTaskAdmin"),

    /**
     * 基线管理组
     */
    BASELINE_ADMIN("基线管理组", "baselineAdmin"),

    /**
     * 基线处置组
     */
    BASELINE_HANDLE("基线处置组", "baselineHandle"),

    /**
     * 基线审核组
     */
    BASELINE_AUDIT("基线审核组", "baselineAudit"),

    /**
     * 基线部门负责人
     */
    BASELINE_DEPT_DUTY("基线部门负责人", "baselineDeptDuty"),

    /**
     * 任务单位执行人
     */
    TASK_UNIT_EXEC("任务单位执行人", "taskUnitExec"),

    /**
     * 签订进度查看组
     */
    SIGN_SCHEDULE_CHECK("签订进度查看组", "signScheduleCheck"),

    /**
     * 资产管理员
     */
    SOFTWARE_ASSET_ADMIN("资产管理员", "softwareAssetAdmin"),

    /**
     * 应用系统管理员
     */
    ASSET_APP_SYSTEM_ADMIN("应用系统管理员", "systemAssetAdmin"),

    /**
     * 应用系统责任人
     */
    ASSET_APP_SYSTEM_DUTY("应用系统责任人", "systemAssetDuty"),
    ;


    /**
     * 名称
     */
    private final String name;

    /**
     * 描述
     */
    private final String key;

    SysRoleEnum(String name, String key) {
        this.name = name;
        this.key = key;
    }

    public static SysRoleEnum findByName(String name) {
        if (StringUtils.isEmpty(name)) {
            return null;
        }
        SysRoleEnum[] values = SysRoleEnum.values();
        for (SysRoleEnum key : values) {
            if (name.equals(key.getName())) {
                return key;
            }
        }
        return null;
    }
}
