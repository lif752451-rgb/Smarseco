package com.crc.common.model.dto;

import lombok.Data;

/**
 * @author jixiangqi
 * @date 2023/9/13
 */
@Data
public class SysDiskInfoDTO {

    /**
     * 文件系统
     */
    private String fileSys;

    /**
     * IP端口
     */
    private String ipPort;

    /**
     * 分区
     */
    private String partition;

    /**
     * 可用空间
     */
    private String available;

    /**
     * 使用率
     */
    private String usageRate;

}
