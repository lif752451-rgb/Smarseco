package com.crc.common.constant;


import java.util.Arrays;
import java.util.List;

/**
 * 通用常量信息
 *
 * @author wst
 */
public class Constants {
    /** 资产导入excel正版标记 */
    public static final String IDENTITY = "Swcf2FY@8517!";
    /** 资产导入excel正版标记sheet */
    public static final String IDENTITY_SHEET = "SysUser";
    public static final String IDENTITY_VULN_SHEET = "identify";
    public static final List<String> USER_TITLE = Arrays.asList("姓名（必填）", "账号（必填）", "归属部门（必填）", "邮箱（必填）", "联系电话（选填）",
            "用户类型（必填）","是否LDAP账号（必填）","状态（必填）");

    public static final String USER_TYPE = "userType";

    public static final String LDAP_MAP = "ldapMap";
    /**
     * UTF-8 字符集
     */
    public static final String UTF8 = "UTF-8";

    /**
     * 通用成功标识
     */
    public static final String SUCCESS = "0";

    /**
     * 通用失败标识
     */
    public static final String FAIL = "1";

    /**
     * 删除标识-0 未删除
     */
    public static final String DEL_FLAG_EFF = "0";

    /**
     * 删除标识-1 已删除
     */
    public static final String DEL_FLAG_INV = "1";

    /**
     * 登录成功
     */
    public static final String LOGIN_SUCCESS = "Success";

    /**
     * 注销
     */
    public static final String LOGOUT = "Logout";

    public static final String CRON ="cron";

    /**
     * 类型
     */
    public static final String TYPE = "type";

    /**
     * 登录失败
     */
    public static final String LOGIN_FAIL = "Error";

    /**
     * 登录异常
     */
    public static final String LOGIN_ERROR = "登录异常";

    /**
     * 验证码 redis key
     */
    public static final String CAPTCHA_CODE_KEY = "captcha_codes:";

    public static final String VERIFY_IMAGE_KEY = "verify_image:";

    /**
     * 登录用户 redis key
     */
    public static final String LOGIN_TOKEN_KEY = "login_tokens:";

    /**
     * 登录用户 redis key
     */
    public static final String LOGIN_TOKEN = "login:token:%s:%s";

    /**
     * 登录类型
     */
    public static final String LOGIN_TOKEN_TYPE = "login:token:type:%s";

    public static final String ADMIN = "ADMIN";

    /**
     * 验证码有效期（分钟）
     */
    public static final Integer CAPTCHA_EXPIRATION = 10;

    /**
     * 令牌
     */
    public static final String TOKEN = "token";

    /**
     * 令牌前缀
     */
    public static final String TOKEN_PREFIX = "Bearer ";

    /**
     * 令牌前缀
     */
    public static final String LOGIN_USER_KEY = "login_user_key";

    /**
     * 用户ID
     */
    public static final String JWT_USERID = "userid";

    /**
     * 数据字典类型
     */
    public static final String DICT_TYPE = "dictType";

    /**
     * 用户头像
     */
    public static final String JWT_AVATAR = "avatar";

    /**
     * 创建时间
     */
    public static final String JWT_CREATED = "created";

    /**
     * 用户权限
     */
    public static final String JWT_AUTHORITIES = "authorities";

    /**
     * 资源映射路径 前缀
     */
    public static final String RESOURCE_PREFIX = "/profile";

    /**
     * 资源映射路径 前缀（新版上传）
     */
    public static final String RESOURCE_FILE = "/file";

    /**
     * 空的上传json
     */
    public static final String EMPTY_FILE_JSON = "[]";

    /**
     * 系统自动生成用户
     */
    public static final String SYSTEM_USER = "system";

    public static final String TAB_LIST_TAG = "rows";

    public static final String DATA_LIST_TAG = "data";

    public static final String TOTAL_TAG = "total";

    public static final String LOG_TIME_TAG = "SparkTime";

    public static final String SRC_IP_TAG = "src_ip";

    public static final String DEST_IP_TAG = "dest_ip";

    public static final String SUPER = "super";

    public static final String AES = "AES";
    public static final String AES_ALGORITHM = "AES/CBC/PKCS5Padding";

    public static final String BLANK_STR = "";

    /**
     * 排序字段
     */
    public static final String SORT_CREATE_TIME = "createTime";

    /**
     * 排序方式-升序
     */
    public static final String SORT_TYPE_ASC = "asc";

    /**
     * 排序方式-降序
     */
    public static final String SORT_TYPE_DESC = "desc";

    public static final String DEFAULT_EXPORT_FILR_NAME = "闭环管理风险单列表.xlsx";

    public static final int EXCEL_CELL_MAX_LENGTH = 13;

    /**
     * 最大端口号
     */
    public static final int MAX_PORT = 65535;

    public static final String MSG_CREATE_ALARM_SUCCESS = "创建安全告警单成功";

    public static final String DEFAULT_EXPORT_FILR_VULN_NAME = "闭环管理漏洞列表.xlsx";

    /**
     * 资产证书导出文件默认名称
     */
    public static final String DEFAULT_EXPORT_ASSET_DIGITAL_CERTIFICATE_FILE_NAME = "证书列表";
    /**
     * 资产待认领导出文件默认名称
     */
    public static final String DEFAULT_EXPORT_ASSET_TO_BE_CLAIMED_FILE_NAME = "待认领资产列表";
    /**
     * 资产已认领导出文件默认名称
     */
    public static final String DEFAULT_EXPORT_ASSET_ALREADY_CLAIMED_FILE_NAME = "已认领资产列表";
    /**
     * 互联网资产待认领导出文件默认名称
     */
    public static final String DEFAULT_EXPORT_ASSET_ASM_INTERNET_TO_BE_CLAIMED_FILE_NAME = "待认领互联网资产列表";
    /**
     * 互联网资产待认领导出文件默认名称
     */
    public static final String DEFAULT_EXPORT_ASSET_ASM_INTERNET_ALREADY_CLAIMED_FILE_NAME = "已认领互联网资产列表";
    /**
     * 终端软件导出文件默认名称
     */
    public static final String DEFAULT_EXPORT_ASSET_TERMINAL_SOFTWARE_REPORT_FILE_NAME = "终端软件列表";
    public static final String IMPORT_ASSET_MSG = "经去重处理后，成功导入%s条数据，其中新增%s条数据，覆盖%s条原数据";
    /**
     * 导出字段
     */
    public static final String EXPORT_ATTRIBUTE = "exportAttribute";

    /**
     * 导出参数
     */
    public static final String FILTER_PARAM = "filterParam";
    /**
     * 递增编号初始位置
     */
    public static final Integer NUMBER_START = 0;
    /**
     * 单次资产导入最大条数
     */
    public static final Integer IMPORT_ONCE_MAX = 500;


    public static final String NULL_VALUE = "无";


    public static final class AutoIncrementId {
        public static final String W = "W";
    }

    /**
     * 谷歌双因子校验
     */
    public static final String GOOGLE_AUTH = "google_auth";
    public static final String GOOGLE_REGISTER = "google_register";
    /**
     * 符号
     */
    public static final class Symbol {
        public static final String COMMA = ",";
        public static final String ZH_COMMA = "，";
        public static final String LEFT_PARENTHESES = "(";
        public static final String SPLIT_LEFT_PARENTHESES = "\\(";
        public static final String RIGHT_PARENTHESES = ")";
        public static final String ZH_LEFT_PARENTHESES = "（";
        public static final String ZH_RIGHT_PARENTHESES = "）";
        public static final String BLANK = " ";
        public static final String NULL_STR = "";
        public static final String ZH_COLON = "：";
        public static final String MINUS = "-";
        public static final String SLASH = "/";
        public static final String VERTICAL_BAR = "|";
        public static final String UNDERLINE = "_";
        public static final String ZH_LEFT_BRACKET = "【";
        public static final String EN_LEFT_BRACKET = "[";
        public static final String ZH_RIGHT_BRACKET = "】";
        public static final String EN_RIGHT_BRACKET = "]";
        public static final String SPACE = "&nbsp;";
        public static final String SEMICOLON = ";";
        public static final String QUESTION = "?";
        public static final String PLACEHOLDER = "PLACEHOLDER";
        public static final String BR = "</br>";
        public static final String NUMBER = "\\d+";
        public static final String ARROW = "->";
        public static final String AND = "&";
        public static final String AND_AMP = "&amp;";
        public static final String STR_EMPTY = "";
        public static final String STR_SINGLE = "'";
        public static final String ZH_CAESURA_SIGN = "、";
        public static final String COLON = ":";
        public static final String LINE_FEED = "\n";
        public static final String PLUS = "+";
        public static final String PERCENT = "%";
        public static final String DOT = ".";
        public static final String ZH_DOT = "。";
        public static final String LESS_THAN = "<";
        public static final String GREATER_THAN = ">";
        public static final String ENTITY_LESS_THAN = "&lt;";
        public static final String ENTITY_GREATER_THAN = "&gt;";
        public static final String TAB = "\t";
        public static final String LINE = "\r";
        public static final String SPLIT_DOT = "\\.";
        public static final String DOUBLE_QUOTATION_MARK = "\"";
        public static final String BACK_SLASH = "\\";
        public static final String ZH_SEMICOLON = "；";
        public static final String BACK_SLASH_LEFT = "//";
        public static final String JSBR = "<br/>";
    }

    /**
     * 邮件发送状态
     */
    public static final class Mail {
        public static final String OK = "ok";
        public static final String FAIL = "fail";
        public static final String TO_IS_NULL = "邮件收信人不能为空";
        public static final String SUBJECT_IS_NULL = "邮件主题不能为空";
        public static final String TEXT_IS_NULL = "邮件内容不能为空";
    }

    /**
     * 告警角色
     */
    public static final class AlarmRoles {
        //安全处理人
        public static final String SECURE_PROCESSOR_CODE = "anquanchuliren";
    }

    /**
     * 资产类型字典
     */
    public static final class AssetTypeDict {
        public static final String SAFETY_EQUIPMENT = "安全设备";
    }

    /**
     * 告警复核 0 否 1 是
     */
    public static final class AlarmCheck {
        public static final String YES = "1";
        public static final String NO = "0";
    }

    /**
     * 邮件发送开关 1打开 0关闭
     */
    public static final String SEND_SWITCH_OPEN = "1";

    //默认步长
    public static final Long DEFAULT_INCR = 1L;

    public static final Integer VALUE_ONE_THOUSAND = 1000;

    /**
     * 邮件发送状态
     */
    public static final class RiskApproveState {
        //工单状态
        public static final String WORK_ORDER_STATE = "workOrderState";
        //数量
        public static final String QUANTITY = "quantity";
        //处置方式
        public static final String RECTIFICATION_TYPE = "rectificationType";
    }

    /**
     * 意见最大长度
     */
    public static Integer OPINION_MAX_LENGTH = 200;

    public static final String STR_VALUE_ZERO = "0";

    public static final String STR_VALUE_MINUS_ONE = "-1";

    public static final String STR_VALUE_ONE = "1";

    public static final String STR_VALUE_TWO = "2";

    public static final String STR_VALUE_THREE = "3";

    public static final String STR_VALUE_FIVE = "5";

    public static final String ONE_HUNDRED = "100";

    public static final Integer INT_VALUE_ZERO = 0;

    public static final Integer INT_VALUE_ONE = 1;

    public static final Integer INT_VALUE_TWO = 2;

    public static final Integer INT_VALUE_THREE = 3;

    /**
     * 使用redis自增业务标识
     */
    public static final class RedisIncrementKeys {
        public static String ALARM_ID = "redis:increment:alarm:id";
        public static String ALARM_HVV_ID = "redis:increment:alarm:hvv:id";
        public static final String RISK_CODE = "redis:increment:risk:code";
        public static final String RISK_AUTO_ID = "redis:increment:risk:auto:id";
        public static final String POLICY_CODE = "redis:increment:policy:code";
        public static final String LOOPHOLE_CODE = "redis:increment:loophole:start:code";
        public static final String ANALYSIS_CODE = "redis:increment:analysis:code";
        public static final String EVENT_ATTENTION_LIST_ID = "redis:increment:alarm:eventAttention:id";
        public static final String EVENT_VULN_INFORMATION_ID = "redis:increment:vuln:information:id";

        public static final String MAJOR_ATTENTION_INFO_ID = "redis:increment:major:attention:info:id";
        public static final String COMMAND_SCREEN_CONFIG_INIT = "redis:command:screen:config:init";
        public static final String ALARM_COMBAT_ID = "redis:increment:alarm:combat:id";
        public static final String ALARM_WHITE_LIST_ID = "redis:increment:alarm:whiteList:id";
    }

    /**
     * 系统名称
     */
    public static final class SystemName {
        public static final String SSP = "SSP";
        public static final String STP = "STP";
        public static final String SBP = "SBP";
        public static final String QT = "QT";
        public static final String AW = "AW";
    }

    public static final String REDIS_BUSINESS_KEY_NX_VAL = "redis:business:key";

    /**
     * 告警表头筛选-告警来源数据源redisKey
     */
    public static final String ALARM_SOURCE_FILTER_DICT_REDIS_KEY = "alarm_source_filter_redis_key";


    public static final String COMMAND_SCREEN_CONFIG_INIT = "redis:command:screen:config:init";

    public static final String UN_KNOW = "未知";

    public static final String HTTP = "http://";
    public static final String HTTPS = "https://";
    public static final String FTP = "ftp://";


    /**
     * 导出模板
     */
    public static final class Template {
        //模板地址前缀
        public static final String PREFIX = "/template/";
    }

    /**
     * 默认查询每页行数
     */
    public static final Integer EXPORT_DEFAULT_PAGE_SIZE = 1000;

    /**
     * 开始查询页码
     */
    public static final Integer START_PAGE_NUM = 1;

    /**
     * 列表查询默认每页行数
     */
    public static final Integer PAGE_SIZE = 20;

    /**
     * 列表查询默认每页行数
     */
    public static final Integer DEFAULT_PAGE_SIZE = 5000;

    /**
     * 导出excel文件名称
     */
    public static final String FILE_NAME = "fileName";

    /**
     * 导出excel文件sheet名称
     */
    public static final String SHEET_NAME = "sheetName";

    /**
     * excel后缀名
     */
    public static final String EXCEL_XLSX = ".xlsx";

    /**
     * 成功
     */
    public static final String SUCC = "success";

    /**
     * 成功
     */
    public static final String ERR = "error";

    /**
     * 导入最大行数
     */
    public static final Integer IMPORT_MAX_LINE = 2000;

    /**
     * 百分比格式
     */
    public static final String PERCENTAGE_FORMAT = "#.##%";

    /**
     * 一级部门父节点id
     */
    public static final Long FIRST_PARENT_ID = 100L;

    /**
     * 是
     */
    public static final String YES = "是";
    public static final String SYS_YES = "Y";
    public static final String SYS_WHETHER_YES = "1";

    /**
     * 否
     */
    public static final String NO = "否";
    public static final String SYS_NO = "N";
    public static final String SYS_WHETHER_NO = "0";

    /**
     * 结束时间
     */
    public static final String END_TIME = " 23:59:59";


    /**
     * 数量
     */
    public static final String COUNT = "count";

    /**
     * 全部
     */
    public static final String ALL = "全部";

    /**
     * 签名
     */
    public static final String SIGN = "sign";

    /**
     * 时间戳
     */
    public static final String TIMESTAMP = "timestamp";

    /**
     * 已修复
     */
    public static final int FIXED_VULNERABILITY_TYPE = 1;

    /**
     * 待修复
     */
    public static final int VULNERABILITIES_TO_BE_FIXED = 0;

    /**
     * 自动生成id拼接长度
     */
    public static final Integer SPLICING_ID_LENGTH = 6;

    /**
     * 自动发现-默认风险大类
     */
    public static final String BIG_CATEGORY = "漏洞";

    /**
     * 剔除 复查中
     */
    public static final String REVIEW = "（复查中）";
    /**
     * 剔除 待
     */
    public static final String WAIT = "待";

    /**
     * 业务单元
     */
    public static final Long BUSINESS_UNIT_DEPT_ID = 2765L;

    /**
     * 业务单元
     */
    public static final String ORGANIZATION_ID = "organizationId=";

    /**
     * excel单元格最大容量
     */
    public static final Integer EXCEL_CELL_MAXIMUM = 32767;

    /**
     * 数据超限提醒
     */
    public static final String OPERATE_MORE_SIZE = "单次操作最多支持%d条数据，当前已选择的您可处理的数据共%d条，请重新选择";

    /**
     * 机构名称
     */
    public static final class organizationName {
        //润联科技
        public static final String RUN_LINK = "润联科技";
    }

    public static final String PARENT = "parent";
    public static final String CHILDREN = "children";
    /**
     * 格式化 yyyy/MM/dd
     */
    public static final String FORMART = "yyyy/MM/dd";
    /**
     * 简单的正则  yyyy/MM/dd
     */
    public static final String SIMPLE_REGEXP = "^\\d{4}(\\-|\\/|\\.)\\d{1,2}\\1\\d{1,2}$";

    /**
     * 简单的正则  yyyy/MM/dd
     */
    public static final String SIMPLE_REGEXP_V1 = "^\\d{4}(\\-|\\/)\\d{1,2}\\1\\d{1,2}$";
    /**
     * ip正则校验
     */
    public static final String IP_REGEXP = "((25[0-5]|2[0-4]\\d|1\\d{2}|[1-9]?\\d)\\.){3}(25[0-5]|2[0-4]\\d|1\\d{2}|[1-9]?\\d)$";

    /**
     * 告警白名单审核状态
     */
    public static final class AlarmWhiteListApproveState {
        //审核状态
        public static final String APPROVE_STATE = "approveState";
        //数量
        public static final String QUANTITY = "quantity";
    }

    public static final String NOT_YET = "暂无";
    public static final String NULL_STR = "null";

    public static final String SIZE = "size";
    /**
     * 风险自动发现
     */
    public static final String RISK_AUTO = "RiskAuto";

    /**
     * 导出支持最大数据量
     */
    public static final Long EXPORT_MAXIMUM = 40000L;

    /**
     * 导出数据限制最大数据量提示信息
     */
    public static final class EXPORT_MAXIMUM_MSG {
        public static final String EXCEED_FORTY_K_MSG = "最多支持导出4w条数据";
        public static final String EXCEED_FORTY_K_MSG_PART1 = "单次导出支持最多4w条数据，当前超出";
        public static final String EXCEED_FORTY_K_MSG_PART2 = "条，请分多次导出";
        public static final Integer EXCEED_FORTY_K_CODE = 201;
    }

    public static final String ASSET_IMPORT_MSG = "经去重处理后，成功导入%s条数据，其中新增%s条数据，覆盖%s条原数据";
    public static final String ASSET_IMPORT_ADD_MSG = "导入%s条新资产";
    public static final String ASSET_IMPORT_UPDATE_MSG = "覆盖%s条原资产";

    public static final String NO_AFFILIATION_DEPT_NAME = "无归属组织";

    public static final String NONE_DEPT_NAME = "暂无";
    public static final Long NONE_DEPT_ID = -1L;

    /**
     * 分割线
     */
    public static final String SPLIT_LINE = "---------";

    /**
     * 管理员权限标识
     */
    public static String ROLE_ADMIN_FLAG = "admin";


    /**
     * 数据字典状态有效标识
     */
    public static String STATUS_VALID = "0";

    /**
     * 数据字典扩展字典形式标识
     */
    public static String LAYOUT_EXTEND = "2";

    public static final class WORK_STATUS_SIMPLE {
        public static final String STATUS_WAIT = "待审核";
        public static final Integer STATUS_WAIT_SIGN = 0;
        public static final String STATUS_DONE = "已审核";
        public static final Integer STATUS_DONE_SIGN = 1;
        public static final String STATUS_ING = "未完成";
        public static final String STATUS_FINISH = "已完成";
    }

    public static final class WORK_STATION {
        public static final String DEAL_STATUS_STR = "dealState";

        public static final String COUNT_STR = "count";

        public static final String SOURCE_STP = "stp";

        public static final String DEAL_STATUS_WAIT = "0";

        public static final String DEAL_STATUS_DONE = "1";
    }

    public static final String EXPORT_DICT_TYPE_NAME="用户字典列表";

    public static final String EXPORT_DICT_DATA_NAME="用户字典子项列表";


    /**
     * RMI 远程方法调用
     */
    public static final String LOOKUP_RMI = "rmi:";

    /**
     * LDAP 远程方法调用
     */
    public static final String LOOKUP_LDAP = "ldap:";

    /**
     * LDAPS 远程方法调用
     */
    public static final String LOOKUP_LDAPS = "ldaps:";

    /**
     * 定时任务白名单配置（仅允许访问的包名，如其他需要可以自行添加）
     */
    public static final String[] JOB_WHITELIST_STR = { "com.ruoyi" };

    /**
     * 定时任务违规的字符
     */
    public static final String[] JOB_ERROR_STR = { "java.net.URL", "javax.naming.InitialContext", "org.yaml.snakeyaml",
            "org.springframework", "org.apache", "com.ruoyi.common.utils.file" };

    /**
     * IOC情报
     */
    public static final String MANUAL_CODE="0";

    public static final String MANUAL_NAME="人工录入";

    public static final String UNKOWN="未知";

    /**
     * 系统应用
     */
    public static final String OPERTOR_TYPE_SEARCH = "search";
    public static final String OPERTOR_TYPE_EXPORT = "export";

    /**
     * 漏洞闭环
     */
    public static final String EXIST="存在";

    public static final String NO_EXIST="不存在";

    public static final String VUL_YES="可以";

    public static final String VUL_NO="不可以";

    /**
     * 资产协同
     */
    public static final String TYPE_DUTY="1";

    public static final String TYPE_OPER="2";

    public static final String TYPE_USER="3";

    /**
     * 数字正则
     */
    public static final String NUMBER_REGEX ="\\d+(\\.\\d+)?";

    /**
     * 已完成
     */
    public static final String FINISHED  = "已完成";

    /**
     * 未完成
     */
    public static final String UNFINISHED  = "未完成";

    /**
     * 资产导入最大行数
     */
    public static final Integer ASSET_IMPORT_MAX_LINE = 50000;


    /**
     * 巡检任务-时间间隔的执行频率前缀
     */
    public static final String TASK_TIME_PREFIX = "每隔";


    public static final String MINUTE = "分钟";


    public static final String HOUR = "小时";

    /**
     * 起始ip
     */
    public static final String START_IP = "0.0.0.0";

    /**
     * 本地ip
     */
    public static final String LOCAL_IP = "127.0.0.1";

    public static final String SYSTEM_USER_LABEL = "系统";

    public static final String SYSTEM_PROJECT_NAME = "SmartSeco网络安全数智化平台";

}
