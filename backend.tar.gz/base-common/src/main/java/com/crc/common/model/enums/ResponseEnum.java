package com.crc.common.model.enums;

import lombok.Getter;

import static org.checkerframework.checker.units.UnitsTools.s;

/**
 * @Author shufengfeng
 * @Description TODO
 * @DateTime 2021/8/30 16:49
 */
@Getter
public class ResponseEnum {

    public static ResponseEnum SUCCESS = new ResponseEnum(200, "成功");
    public static ResponseEnum BUSINESS_PARAM_ERR = new ResponseEnum(20009, "业务处理参数错误");
    public static ResponseEnum USER_NOT_EXISTENCE = new ResponseEnum(530,"用户不存在，请联系安全组授权");
    public static ResponseEnum NO_BATCH_CLOSE_AUTH = new ResponseEnum(600, "没有批量关闭权限");
    public static ResponseEnum JUDGE_RECORD_NOT_EXIST = new ResponseEnum(601, "研判的告警流程记录不存在");
    public static ResponseEnum DEPT_NOT_EXIST = new ResponseEnum(602, "部门不存在");
    public static ResponseEnum JUDGE_USER_NOT_EXIST = new ResponseEnum(603, "安全接口人不存在");
    public static ResponseEnum TASK_NOT_EXIST = new ResponseEnum(604, "当前节点已经被处理或者无处理权限");
    public static ResponseEnum USER_NOT_EXIST = new ResponseEnum(605, "用户不存在");
    public static ResponseEnum CHECK_OPINION_NOT_EXIST = new ResponseEnum(606, "复核意见不能为空");
    public static ResponseEnum CHECK_OPINION_TOO_LONG = new ResponseEnum(607, "复核意见最大为200字符");
    public static ResponseEnum AUDIT_OPINION_NOT_EXIST = new ResponseEnum(608, "审核意见不能为空");
    public static ResponseEnum AUDIT_OPINION_TOO_LONG = new ResponseEnum(609, "审核意见最大为200字符");
    public static ResponseEnum DATA_NOT_EXIST = new ResponseEnum(610, "数据不存在");
    public static ResponseEnum ORDER_STATUS_NOT_MATCH = new ResponseEnum(611, "工单状态不匹配");
    public static ResponseEnum TASK_NOT_MATCH = new ResponseEnum(612, "业务数据%s不存在");
    public static ResponseEnum DEAL_DATA_NOT_EXIST = new ResponseEnum(613, "处置数据不存在");
    public static ResponseEnum CHECK_DATA_NOT_EXIST = new ResponseEnum(614, "复核数据不存在");
    public static ResponseEnum NEXT_NODE_DEAL_USER_IS_NULL = new ResponseEnum(615, "下一节点处理人为空");
    public static ResponseEnum HANDLE_USER_ERROR = new ResponseEnum(616, "指派处置人数据有误");
    public static ResponseEnum HEADER_SHOW_TYPE_IS_NULL = new ResponseEnum(616, "类型参数为空");
    public static ResponseEnum HEADER_SHOW_TYPE_ERROR = new ResponseEnum(616, "类型参数错误");
    public static ResponseEnum ALARM_LEVEL_ERROR = new ResponseEnum(617, "告警级别数据有误");
    public static ResponseEnum ATTACK_RESULT_ERROR = new ResponseEnum(618, "攻击结果数据有误");
    public static ResponseEnum ATTACK_MEANS_ERROR = new ResponseEnum(619, "攻击手段数据有误");
    public static ResponseEnum SAFETY_ENGINEER_NOT_EXIST = new ResponseEnum(620, "安全工程师不存在");
    public static ResponseEnum CURRENT_USER_NO_VIEW_PERMISSION = new ResponseEnum(621, "当前用户无权限查看");
    public static ResponseEnum SERIAL_NUMBER_EXIST = new ResponseEnum(622, "序列号已存在");
    public static ResponseEnum UN_KNOW = new ResponseEnum(623, "未知错误:%s");
    public static ResponseEnum UPLOAD_FILE_IS_NULL = new ResponseEnum(624, "不允许导入空文件");
    public static ResponseEnum FILE_TYPE_NOT_MATCH = new ResponseEnum(625, "文件类型不匹配");
    public static ResponseEnum NOT_EXCEL_FILE = new ResponseEnum(626, "只允许上传.xlsx的文件！");
    public static ResponseEnum UPLOAD_FILE_TO_MAX = new ResponseEnum(627, "导入文件太大");
    public static ResponseEnum TYPE_LABEL_ERROR = new ResponseEnum(628, "软件类型错误");
    public static ResponseEnum OWNER_LABEL_ERROR = new ResponseEnum(629, "知识产权所属国错误");
    public static ResponseEnum LICENSE_TYPE_LABEL_ERROR = new ResponseEnum(630, "软件授权类型错误");
    public static ResponseEnum ERROR_DATA_IS_NULL = new ResponseEnum(631, "错误数据为空");
    public static ResponseEnum USED_GREATER_TOTAL = new ResponseEnum(632, "已使用许可数量大于许可总数量");
    public static ResponseEnum SUCCESS_DATA_IS_NULL = new ResponseEnum(633, "成功数据为空");
    public static ResponseEnum DICT_IS_NOT_EXIST = new ResponseEnum(634, "字典不存在");
    public static ResponseEnum IMPORT_LINE_TOO_MAX = new ResponseEnum(635, "导入行数最大%s");
    public static ResponseEnum RATE_LIMIT = new ResponseEnum(636, "限流中");
    public static ResponseEnum SIGN_ERROR = new ResponseEnum(637, "签名错误");
    public static ResponseEnum CURRENT_TIME_NOT_MATCH = new ResponseEnum(638, "与当前时间不匹配");
    public static ResponseEnum SURPLUS_IS_ZERO = new ResponseEnum(639, "没有剩余量");
    public static ResponseEnum UPDATE_FAIL = new ResponseEnum(640, "更新失败");
    public static ResponseEnum DATA_IS_EXIST = new ResponseEnum(641, "数据已经存在");
    public static ResponseEnum APPLY_DATE_GREATER_AUTH_DEAD_LINE = new ResponseEnum(642, "申请许可时间大于授权截止日期");
    public static ResponseEnum AUTH_DEAD_LINE_TO_MAX = new ResponseEnum(643, "授权截止日期太大");
    public static ResponseEnum AUTH_DEAD_LINE_LESS_CURRENT_DATE = new ResponseEnum(644, "授权截止日期小于当前日期");
    public static ResponseEnum KEY_ASSET_ERROR = new ResponseEnum(645, "资产等级错误");
    public static ResponseEnum ENVIRONMENT_TYPE_ERROR = new ResponseEnum(646, "环境类型错误");
    public static ResponseEnum OPERATING_STATUS_ERROR = new ResponseEnum(647, "资产状态错误");
    public static ResponseEnum EQUAL_PROTECTION_LEVEL_ERROR = new ResponseEnum(648, "等保定级不在选项中");
    public static ResponseEnum SOURCE_TYPE_ERROR = new ResponseEnum(649, "资源类型错误");
    public static ResponseEnum EQUAL_PROTECTION_CODE_IS_NULL = new ResponseEnum(650, "等保定级后，等级备案编号不能为空");
    public static ResponseEnum EQUAL_PROTECTION_RESULT_IS_NULL = new ResponseEnum(651, "等保定级后，等保结论不能为空");
    public static ResponseEnum EQUAL_PROTECTION_TEST_CONTENT_IS_NULL = new ResponseEnum(652, "等保定级后，等保测评情况不能为空");
    public static ResponseEnum EQUAL_PROTECTION_FIRST_TIME_IS_NULL = new ResponseEnum(653, "等保定级后，最近一次等级测评时间不能为空");
    public static ResponseEnum COMPANY_ERROR = new ResponseEnum(654, "所属一级单位错误");
    public static ResponseEnum SUB_COMPANY_ERROR = new ResponseEnum(655, "所属二级单位错误");
    public static ResponseEnum OFFICE_NAME_ERROR = new ResponseEnum(656, "所属部门错误");
    public static ResponseEnum OPERATING_DEPT_NAME_ERROR = new ResponseEnum(657, "运维部门错误");
    public static ResponseEnum WORK_TYPE_ERROR = new ResponseEnum(658, "工作项类型错误，请下载导入模板");
    public static ResponseEnum EXPORT_TYPE_ERROR = new ResponseEnum(659, "导出类型错误");
    public static ResponseEnum SERIAL_NUMBER_IS_EXIST = new ResponseEnum(660, "该序列号%s已经申请过");
    public static ResponseEnum ID_IS_NULL = new ResponseEnum(661, "ID不能为空");
    public static ResponseEnum END_DATE_LESS_START_DATE = new ResponseEnum(662, "开始时间大于结束时间");
    public static ResponseEnum ALARM_FOCUS_TAG_ERROR = new ResponseEnum(663, "重点关注标记参数错误");
    public static ResponseEnum NO_AUTH = new ResponseEnum(664, "暂无权限");
    public static ResponseEnum RISK_DATA_NO_VIEW_PERMISSION = new ResponseEnum(665, "没有当前风险单查看权限");
    public static ResponseEnum LOGIN_AGAIN = new ResponseEnum(403, "重新登录");
    public static ResponseEnum GROUP_TYPE_NAME_IS_EXIST = new ResponseEnum(666, "分组名称已经存在");
    public static ResponseEnum GROUP_TYPE_NAME_IS_NULL = new ResponseEnum(667, "分组名称为空");
    public static ResponseEnum GROUP_TYPE_CAN_NOT_DELETE = new ResponseEnum(668, "该分组名称不可被删除");
    public static ResponseEnum ORGANIZATION_ID_IS_NULL = new ResponseEnum(669, "所属组织id不能为空");
    public static ResponseEnum ATTACK_IP_ERROR = new ResponseEnum(670, "攻击IP格式不正确");
    public static ResponseEnum VICTIMIZED_IP_ERROR = new ResponseEnum(671, "受害IP/URL格式不正确");
    public static ResponseEnum PURCHASE_DATE_FORMAT_ERROR = new ResponseEnum(672, "采购日期格式不正确yyyy-MM-dd");
    public static ResponseEnum AUTH_DEAD_LINE_FORMAT_ERROR = new ResponseEnum(673, "授权截止时间格式不正确yyyy-MM-dd");
    public static ResponseEnum EXPIRATION_TIME_FORMAT_ERROR = new ResponseEnum(674, "维保到期时间格式错误");
    public static ResponseEnum EQUAL_PROTECTION_FIRST_TIME_FORMAT_ERROR = new ResponseEnum(675, "最近一次等级测评时间格式不正确yyyy/MM/dd");
    public static ResponseEnum VIRTUAL_IP_ERROR = new ResponseEnum(676, "虚IP格式不正确");
    public static ResponseEnum LOCAL_IP_ERROR = new ResponseEnum(677, "IP/域名格式错误");
    public static ResponseEnum EQUAL_PROTECTION_FIRST_TIME_ERROR = new ResponseEnum(678, "最近一次等级测评时间格式不正确");
    public static ResponseEnum ASSET_TYPE_ERROR = new ResponseEnum(679, "资产大类错误");
    public static ResponseEnum ASSET_SUB_TYPE_ERROR = new ResponseEnum(679, "资产小类错误");
    public static ResponseEnum ASSET_AREA_ERROR = new ResponseEnum(680, "网络区域错误");
    public static ResponseEnum ASSET_POWER_ERROR = new ResponseEnum(681, "是否关基错误");
    public static ResponseEnum ASSET_TRANSFORMATION_COMPLETED_ERROR = new ResponseEnum(682, "是否完成国密改造错误");
    public static ResponseEnum ASSET_INTERNET_PUBLISH_ERROR = new ResponseEnum(683, "是否发布互联网错误");
    public static ResponseEnum EXPIRATION_TIME_FORMAT_IS_NULL = new ResponseEnum(684, "维保到期时间不能为空");
    public static ResponseEnum EXPORT_PARAM_ERROR = new ResponseEnum(685, "导出参数错误");
    public static ResponseEnum EXPORT_MENU_TYPE_PARAM_ERROR = new ResponseEnum(686, "菜单类型参数错误");
    public static ResponseEnum EXPORT_FAIL = new ResponseEnum(687, "导出失败");
    public static ResponseEnum VUL_WHITED = new ResponseEnum(688, "当前漏洞已被加白，请刷新页面");
    public static ResponseEnum ASSET_DATA_IS_EXISTS = new ResponseEnum(689, "该资产已存在且不属于本组织，请找管理员确认或变更资产归属");
    public static ResponseEnum ASSET_CLAIM_NO_ACCESS = new ResponseEnum(690, "禁止认领超过数据权限范围外的资产");
    public static ResponseEnum TEXT_TO_LONG = new ResponseEnum(691, "富文本限制输入6w个字符，当前字符数为%s，请修改内容");
    public static ResponseEnum RELATED_PROJECT_NOT_EXISTS = new ResponseEnum(692, "关联项目不在选项范围内");
    public static ResponseEnum AFFILIATION_DEPT_NAME_NO_AUTH = new ResponseEnum(693, "没有所属单位权限");
    public static ResponseEnum IMPORT_AFFILIATION_DEPT_NAME_NO_AUTH = new ResponseEnum(694, "所属三级及以下单位没有填写单位的资产管理权限");
    public static ResponseEnum IMPORT_AFFILIATION_DEPT_NAME_ERROR = new ResponseEnum(695, "所属三级及以下单位填写错误");
    public static ResponseEnum ASSET_CLAIM_NO_AUTH = new ResponseEnum(696, "没有资产认领权限");

    public static ResponseEnum ASSET_CLAIM_NO_DATA = new ResponseEnum(500, "没有指定数据进行领用");
    public static ResponseEnum RISK_LEVEL_ERROR = new ResponseEnum(697, "风险等级填写错误");
    public static ResponseEnum RISK_SOURCE_ERROR = new ResponseEnum(698, "风险来源填写错误");
    public static ResponseEnum COMPANY_NO_AUTH = new ResponseEnum(699, "所属一级单位没有填写单位的资产管理权限");
    public static ResponseEnum SUB_COMPANY_NO_AUTH = new ResponseEnum(700, "所属二级单位没有填写单位的资产管理权限");
    public static ResponseEnum PARAM_AES_DECRYPT_ERROR = new ResponseEnum(701, "参数解密失败");
    public static ResponseEnum NO_VIEW_PERMISSION = new ResponseEnum(702, "暂无权限");
    public static ResponseEnum AREA_DELETE_ERROR = new ResponseEnum(703, "该区域或其下级子区域存在资产/网段，禁止删除，请先修改该区域内资产/网段归属");
    public static ResponseEnum EQUIPMENT_ADDRESS_DUP = new ResponseEnum(704, "已存在，请勿重复添加");
    public static ResponseEnum ALARM_REPORT_NOT_EXISTS = new ResponseEnum(705, "告警不存在");
    public static ResponseEnum ATTACK_IP_NOT_EXISTS = new ResponseEnum(706, "攻击ip不存在");
    public static ResponseEnum VICTIMIZED_IP_NOT_EXISTS = new ResponseEnum(707, "受害ip不存在");
    public static ResponseEnum EQUIPMENT_TELNET_ADDRESS_ERROR = new ResponseEnum(708, "连通性测试参数错误，请检查");
    public static ResponseEnum SOFT_VERSION_TO_MORE = new ResponseEnum(709, "多个组件版本无法比较");
    public static ResponseEnum RISK_AUTO_ORDER_STATUS_CLOSE = new ResponseEnum(710, "工单状态已关闭");
    public static ResponseEnum TIME_INVALID = new ResponseEnum(711, "时间已失效");
    public static ResponseEnum EMAIL_ERROR = new ResponseEnum(712, "邮箱格式错误");
    public static ResponseEnum INTERNAL_IP_INCORRECT_ERROR = new ResponseEnum(713, "内网IP格式错误");
    public static ResponseEnum INTERNET_IP_INCORRECT_ERROR = new ResponseEnum(714, "互联网IP格式错误");
    public static ResponseEnum DATA_SOURCE_IS_NULL = new ResponseEnum(715, "数据来源为空");
    public static ResponseEnum APPROVAL_ORDER_STATUS_ERROR = new ResponseEnum(716, "当前工单已经被操作,请刷新");
    public static ResponseEnum WHITE_APPLY_ERROR = new ResponseEnum(716, "IP或漏洞名称为空");

    public static ResponseEnum ALARM_ERROR = new ResponseEnum(717,"关联告警不存在");
    public static ResponseEnum RISK_ERROR = new ResponseEnum(718,"关联风险不存在");
    public static ResponseEnum STATUS_ERROR = new ResponseEnum(719,"状态不在选项中");
    public static ResponseEnum DUTY_DEPT_ERROR = new ResponseEnum(720,"责任单位不存在");
    public static ResponseEnum VISUAL_CONFIG_ERROR = new ResponseEnum(721,"配置语句或报表属性有误,请检查");
    public static ResponseEnum GROUP_ERROR = new ResponseEnum(722,"请输入完整分组路径");
    public static ResponseEnum GROUP_FULL_NAME_ERROR = new ResponseEnum(723,"分组不存在");
    public static ResponseEnum EMAIL_INVALID = new ResponseEnum(716, "邮件地址无效，必须为华润内部邮箱");
    public static ResponseEnum IOC_TYPE_INVALID = new ResponseEnum(717, "IOC类型不在选项中");
    public static ResponseEnum THREATHEN_LEVEL_INVALID = new ResponseEnum(718, "威胁等级不在选项中");
    public static ResponseEnum THREATHEN_TYPE_INVALID = new ResponseEnum(719, "威胁类型不在选项中");


    public static ResponseEnum DEPT_NAME_ERROR = new ResponseEnum(723,"所属组织不存在");
    public static ResponseEnum DUTY_PERSON_ERROR = new ResponseEnum(724,"使用/责任人不存在或无权限");
    public static ResponseEnum SYSTEM_TYPE_ERROR = new ResponseEnum(725,"系统类型不在选项中");
    public static ResponseEnum SYSTEM_LEVEL_ERROR = new ResponseEnum(726,"系统等级不在选项中");
    public static ResponseEnum SYSTEM_STATUS_ERROR = new ResponseEnum(727,"系统状态不在选项中");
    public static ResponseEnum SYSTEM_FIELD_ERROR = new ResponseEnum(728,"个人信息字段不存在");

    public static ResponseEnum IS_GJ_ERROR = new ResponseEnum(729,"是否关基不在选项中");
    public static ResponseEnum IS_GMGZ_ERROR = new ResponseEnum(730,"国密改造状态不在选项中");
    public static ResponseEnum IS_FBHLW_ERROR = new ResponseEnum(731,"发布互联网不在选项中");

    public static ResponseEnum SYSTEM_IP_ERROR = new ResponseEnum(732,"关联资产IP地址不存在");

    public static ResponseEnum IS_SJGRXX_ERROR = new ResponseEnum(733,"收集个人信息不在选项中");
    public static ResponseEnum IS_WAF_ERROR = new ResponseEnum(733,"收集是否有添加WAF防护不在选项中");

    public static ResponseEnum IP_ERROR = new ResponseEnum(734,"IP格式错误");
    public static ResponseEnum VULN_TYPE_ERROR = new ResponseEnum(735,"漏洞类型不在选项中");
    public static ResponseEnum VULN_LEVEL_ERROR = new ResponseEnum(736,"漏洞等级不在选项中");

    public static ResponseEnum EXP_ERROR = new ResponseEnum(737,"是否存在EXP不在选项中");
    public static ResponseEnum POC_ERROR = new ResponseEnum(738,"是否存在POC不在选项中");
    public static ResponseEnum REMOTE_ERROR = new ResponseEnum(739,"是否可远程执行不在选项中");

    public static ResponseEnum FIRST_TIME_ERROR = new ResponseEnum(740,"首次发现时间格式错误");
    public static ResponseEnum RECENTLY_TIME_ERROR = new ResponseEnum(741,"最近发现时间格式错误");
    public static ResponseEnum PUBLISH_ERROR = new ResponseEnum(742,"漏洞发布时间格式错误");
    public static ResponseEnum ASSET_PRIVATE_NET_DEPT_NO_AUTH = new ResponseEnum(743,"所属组织没有权限");
    public static ResponseEnum ASSET_PRIVATE_NET_NAME_IS_EXISTS = new ResponseEnum(744,"该专属网已存在，请勿重复添加");

    public static ResponseEnum PARENT_NODE_IS_NOT_EXISTS = new ResponseEnum(745,"上级节点不存在");
    public static ResponseEnum HAS_CHILD = new ResponseEnum(746,"存在下级节点，无法删除");

    public static ResponseEnum OPER_PERSON_ERROR = new ResponseEnum(735,"运维人不存在");
    public static ResponseEnum USE_PERSON_ERROR = new ResponseEnum(735,"使用人不存在");

    public static ResponseEnum PATAL_ITEM_TYPE_ERROR = new ResponseEnum(736,"巡检类型不存在");
    public static ResponseEnum AFFILIATION_DEPT_NAME_NO_EXISTS = new ResponseEnum(737,"所属组织不存在");
    public static ResponseEnum ASSET_USER_ERROR = new ResponseEnum(738,"责任人不存在");
    public static ResponseEnum KEY_ASSET_NOT_EXISTS = new ResponseEnum(739, "资产等级不在选项中");
    public static ResponseEnum ASSET_TYPE_NOT_EXISTS = new ResponseEnum(740, "资产类型不存在");

    public static ResponseEnum ASSET_GROUP_NOT_EXISTS = new ResponseEnum(740, "资产分组不存在");
    public static ResponseEnum ASSET_IP_STATUS_NOT_EXISTS = new ResponseEnum(741, "资产状态不在选项中");
    public static ResponseEnum ASSET_IP_ENVIRONMENT_TYPE_NOT_EXISTS = new ResponseEnum(742, "环境类型不在选项中");
    public static ResponseEnum SEGMENT_IS_INVALID = new ResponseEnum(743, "网段不合法");
    public static ResponseEnum ASSET_IP_SOURCE_TYPE_NOT_EXISTS = new ResponseEnum(743, "资源类型不在选项中");
    public static ResponseEnum ASSET_POWER_NOT_EXISTS = new ResponseEnum(744, "是否关基不在选项中");
    public static ResponseEnum ASSET_TRANSFORMATION_COMPLETED_NOT_EXISTS = new ResponseEnum(745, "国密改造状态不在选项中");
    public static ResponseEnum ASSET_INTERNET_PUBLISH_NOT_EXISTS = new ResponseEnum(746, "发布互联网不在选项中");
    public static ResponseEnum ASSET_CENTRALIZED_SYSTEM_NOT_EXISTS = new ResponseEnum(748, "是否集权系统不在选项中");
    public static ResponseEnum MAC_ERROR = new ResponseEnum(747, "请输入正确的MAC地址格式");

    public static ResponseEnum ASSET_AREA_NOT_EXIST = new ResponseEnum(680, "网络区域不存在");
    public static ResponseEnum IP_EXISTS_ERROR = new ResponseEnum(743,"内网IP已经存在，请勿重复添加");
    public static ResponseEnum VUL_EXISTS = new ResponseEnum(745,"漏洞已存在，请勿重复添加");
    public static ResponseEnum VUL_REPAIR_CYCLE_NOT_CONFIG = new ResponseEnum(746,"漏洞修复周期未配置");
    public static ResponseEnum VULN_DATA_NOT_EXIST = new ResponseEnum(747,"漏洞数据不存在");
    public static ResponseEnum ASSET_GROUP_NAME_IS_EXISTS = new ResponseEnum(748,"该分组已存在，请勿重复添加");
    public static ResponseEnum DEFAULT_PRIVATE_NET_CAN_NOT_DEL = new ResponseEnum(749,"内网不允许删除");
    public static ResponseEnum DEFAULT_PRIVATE_NET_CAN_NOT_UPDATE = new ResponseEnum(750,"内网不允许修改");
    public static ResponseEnum DEFAULT_PRIVATE_NET_CAN_NOT_ADD_CHILD = new ResponseEnum(751,"内网不允许添加子节点");
    public static ResponseEnum PRIVATE_NET_NAME_IS_NULL = new ResponseEnum(752,"专属网名称不能为空");
    public static ResponseEnum GROUP_NAME_IS_NULL = new ResponseEnum(753,"分组名称不能为空");


    public static ResponseEnum PATROL_INSPECTION_TASK_NAME_IS_NULL = new ResponseEnum(754,"任务名称不能为空");
    public static ResponseEnum PATROL_INSPECTION_TASK_NAME_TO_LONG = new ResponseEnum(755,"任务名称最大长度为50字符");
    public static ResponseEnum PATROL_INSPECTION_REMARK_TO_LONG = new ResponseEnum(756,"备注最大长度为1000字符");
    public static ResponseEnum LINE_TYPE_ERROR = new ResponseEnum(759,"线路不在选项中");
    public static ResponseEnum CODE_REVIEW_HANDLE = new ResponseEnum(760,"项目负责人不具有代码审计处置组角色");
    public static ResponseEnum DEPT_NAME_TYPE_ERROR = new ResponseEnum(760,"所属组织不存在");
    public static ResponseEnum IP_ASSET_IS_NULL = new ResponseEnum(761, "IP资产不能为空");
    public static ResponseEnum APP_SYSTEM_IS_NULL = new ResponseEnum(762, "应用系统不能为空");
    public static ResponseEnum END_TIME_TO_SMALL = new ResponseEnum(763, "结束时间应大于开始时间");
    public static ResponseEnum FREQUENCY_CONCRETE_IS_NULL = new ResponseEnum(764, "巡检频率具体是哪一天或者周几不能为空");

    public static ResponseEnum APP_SYSTEM_NOT_EXIST  = new ResponseEnum(765, "应用系统不存在");
    public static ResponseEnum KEY_EQUAL_GRADE_LEVEL_ERROR  = new ResponseEnum(766, "等保定级不在选项中");
    public static ResponseEnum KEY_EQUAL_GRADE_CONCLUSION_ERROR  = new ResponseEnum(767, "等保结论不在选项中");
    public static ResponseEnum KEY_PENETRATION_TEST_RESULT_EVALUATE_ERROR  = new ResponseEnum(768, "结果评定不在选项中");
    public static ResponseEnum APPLICATION_IS_EXIST = new ResponseEnum(763,"%s下已存在该应用名称，请勿重复添加");
    public static ResponseEnum PASS_WORD_IS_NOT_EMPTY = new ResponseEnum(761,"密码不能为空");
    public static ResponseEnum TOKEN_IS_NOT_EMPTY = new ResponseEnum(761,"Token不能为空");
    public static ResponseEnum APPLICATION_IS_NOT_EXIST = new ResponseEnum(765,"应用名称不存在");
    public static ResponseEnum PROJECT_IS_NOT_EXIST = new ResponseEnum(764,"项目名称不存在");
    public static ResponseEnum DUTY_ROLE_ERROR = new ResponseEnum(760,"项目负责人不具有代码审计管理组角色");
    public static ResponseEnum PROJECT_IS_EXIST = new ResponseEnum(762,"项目名称已存在，请勿重复创建");
    public static ResponseEnum PARAM_AES_ENCRYPT_ERROR = new ResponseEnum(767, "参数加密失败");
    public static ResponseEnum REPAIR_ERROR = new ResponseEnum(770,"修复截止时间格式错误");

    public static ResponseEnum LOCAL_ERROR = new ResponseEnum(771,"是否本地提权不在选项中");

    public static ResponseEnum CORE_ERROR = new ResponseEnum(772,"是否内核漏洞不在选项中");
    public static ResponseEnum IS_SEND_ERROR = new ResponseEnum(773,"是否发送邮件通知不在选项中");
    public static ResponseEnum VULN_HANDLE_PERSON_EMPTY = new ResponseEnum(774,"处置人不存在或无权限");
    public static ResponseEnum VULN_EMAIL_ERROR = new ResponseEnum(775,"邮件抄送人格式错误");

    public static ResponseEnum VUL_HOST_INFLUENCE_ERROR = new ResponseEnum(776,"修复影响不在选项中");
    public static ResponseEnum USER_NAME_IS_NOT_EMPTY = new ResponseEnum(777,"用户名不能为空");
    public static ResponseEnum VULN_NAME_IS_NOT_EMPTY = new ResponseEnum(778,"漏洞名称不能为空");
    public static ResponseEnum DEPT_NAME_IS_NOT_EMPTY = new ResponseEnum(779,"所属组织不能为空");
    public static ResponseEnum IP_IS_NOT_EMPTY = new ResponseEnum(780,"IP/域名不能为空");
    public static ResponseEnum ASSET_NAME_SIZE_ERROR = new ResponseEnum(781,"资产名称最多可输入100个字符");
    public static ResponseEnum USER_NAME_SIZE_ERROR = new ResponseEnum(782,"用户名最多可输入100个字符");
    public static ResponseEnum PASS_WORD_SIZE_ERROR = new ResponseEnum(783,"密码最多可输入100个字符");
    public static ResponseEnum PORT_SIZE_ERROR = new ResponseEnum(784,"端口最多可输入100个字符");
    public static ResponseEnum SERVICE_SIZE_ERROR = new ResponseEnum(785,"服务最多可输入100个字符");
    public static ResponseEnum DESCRIPTION_SIZE_ERROR = new ResponseEnum(786,"漏洞描述最多可输入2000个字符");
    public static ResponseEnum SOLUTION_SIZE_ERROR = new ResponseEnum(787,"解决方案最多可输入2000个字符");
    public static ResponseEnum VULN_DATA_IS_IN_BUSINESS = new ResponseEnum(788,"漏洞数据不存在或已在流程中，请刷新页面");
    public static ResponseEnum VULN_HANDLE_PERSON_IS_EMPTY = new ResponseEnum(789,"漏洞实际处置人为空，不能推送");
    public static ResponseEnum SELECTED_IS_EMPTY_NOT_UPDATE = new ResponseEnum(790,"已选列表为空，不能修改漏洞");
    public static ResponseEnum SELECTED_IS_EMPTY_NOT_PUSH = new ResponseEnum(791,"已选列表为空，不能推送漏洞");
    public static ResponseEnum SELECTED_IS_NULL_ERROR = new ResponseEnum(792,"已选数据为空，请重新选择");
    public static ResponseEnum VUL_TASK_IS_NOT_EXIST = new ResponseEnum(793,"漏洞节点不正确");
    public static ResponseEnum VUL_CATEGORY_ERROR = new ResponseEnum(744,"漏洞大类不在选项中");
    public static ResponseEnum RISK_INDEX_ERROR = new ResponseEnum(724,"风险指数格式错误");
    public static ResponseEnum PORT_ERROR = new ResponseEnum(726,"端口不合法");
    public static ResponseEnum SRC_IP_ERROR = new ResponseEnum(720,"源地址格式错误");
    public static ResponseEnum DEST_IP_ERROR = new ResponseEnum(721,"目的地址格式错误");
    public static ResponseEnum SRC_PORT_ERROR = new ResponseEnum(722,"源端口不合法");
    public static ResponseEnum DEST_PORT_ERROR = new ResponseEnum(723,"目的端口不合法");
    public static ResponseEnum PORT_IS_ERROR = new ResponseEnum(724,"存在端口号不合法，请检查");
    public static ResponseEnum ASSET_PORT_IS_ERROR = new ResponseEnum(725,"关联资产端口号不合法");
    public static ResponseEnum TOP_CONFIG_AREA_IS_NOT_ADD = new ResponseEnum(726,"区域无法添加");
    public static ResponseEnum TOP_APPLICATION_IS_EXIST = new ResponseEnum(727,"应用已存在，请勿重复添加");
    public static ResponseEnum TOP_CONFIG_IS_NOT_EXIST = new ResponseEnum(728,"TOP配置信息不存在");
    public static ResponseEnum TOP_CONFIG_ID_IS_NOT_EMPTY = new ResponseEnum(729,"TOP配置id不能为空");

    // 基线
    public static ResponseEnum BASELINE_NOT_EXISTS = new ResponseEnum(724,"基线数据不存在");
    public static ResponseEnum DATA_ERROR = new ResponseEnum(725,"数据异常");
    public static ResponseEnum CURRENT_NODE_IS_USE = new ResponseEnum(726,"当前节点已被操作，请刷新页面");
    public static ResponseEnum BASELINE_TASK_IS_NOT_EXIST = new ResponseEnum(727,"基线节点不正确");
    public static ResponseEnum BASELINE_DELAY_NOT_EXISTS = new ResponseEnum(728,"基线延期申请数据不存在");

    public static ResponseEnum IP_INCORRECT_ERROR = new ResponseEnum(713, "IP格式错误");
    public static ResponseEnum LEVEL_CATEGORY_ERROR = new ResponseEnum(753,"风险等级不在选项中");
    public static ResponseEnum BASELINE_HANDLE_PERSON_EMPTY = new ResponseEnum(774,"处置人不存在或无权限");
    public static ResponseEnum BASELINE_REPAIR_CYCLE_NOT_CONFIG = new ResponseEnum(746,"基线问题修复周期未配置");
    public static ResponseEnum REPAIR_TIME_ERROR = new ResponseEnum(740,"修复截止时间格式错误");

    public static ResponseEnum SELECT_IS_NULL_ERROR = new ResponseEnum(752,"所选数据中不存在待处置的基线问题，请重新选择");
    public static ResponseEnum BASELINE_DATA_NOT_EXIST = new ResponseEnum(747,"基线问题数据不存在");
    public static ResponseEnum BASELINE_DATA_IS_IN_BUSINESS = new ResponseEnum(748,"基线问题数据不存在或已在流程中，请刷新页面");
    public static ResponseEnum BASELINE_HANDLE_PERSON_IS_EMPTY = new ResponseEnum(749,"基线问题实际处置人为空，不能推送");
    public static ResponseEnum BASELINE_SELECTED_IS_EMPTY_NOT_PUSH = new ResponseEnum(751,"已选列表为空，不能推送基线问题");
    public static ResponseEnum CRITICAL_SYSTEM_IS_NOT_EXIST = new ResponseEnum(772,"关键系统不存在");
    public static ResponseEnum CRITICAL_SYSTEM_PARAM_ERROR = new ResponseEnum(773,"关联系统参数不正确");
    public static ResponseEnum CRITICAL_SYSTEM_IS_EXIST = new ResponseEnum(774,"系统名称已存在，请勿重复添加");
    public static ResponseEnum SEGMENT_IS_ERROR = new ResponseEnum(774,"存在非法网段或IP");
    public static ResponseEnum RISK_DATA_IS_NOT_EXIST = new ResponseEnum(775,"风险数据不存在");
    public static ResponseEnum RISK_SOURCE_IS_NOT_OPTION = new ResponseEnum(776,"风险来源不在选项中");
    public static ResponseEnum RISK_TYPE_IS_NOT_OPTION = new ResponseEnum(777,"风险类型不在选项中");
    public static ResponseEnum RISK_LEVEL_IS_NOT_OPTION = new ResponseEnum(778,"风险等级不在选项中");
    public static ResponseEnum RISK_RELATE_PROJECT_IS_NOT_OPTION = new ResponseEnum(779,"关联项目不在选项中");
    public static ResponseEnum RISK_RECTIFY_PRIORITY_IS_NOT_OPTION = new ResponseEnum(780,"整改优先级不在选项中");
    public static ResponseEnum RISK_RELATE_OBJECT_IS_NOT_OPTION = new ResponseEnum(781,"关联对象不在选项中");
    public static ResponseEnum RISK_IP_FORMAT_ERROR = new ResponseEnum(782,"风险IP格式错误");
    public static ResponseEnum RISK_RELATE_APP_SYSTEM_IS_NOT_EMPTY = new ResponseEnum(783,"风险应用系统不能为空");
    public static ResponseEnum RISK_IP_IS_NOT_EMPTY = new ResponseEnum(784,"风险IP不能为空");
    public static ResponseEnum RISK_APP_SYSTEM_IS_NOT_EXIST = new ResponseEnum(785,"风险应用系统不存在");
    public static ResponseEnum RISK_HANDLE_PERSON_IS_NOT_EXIST = new ResponseEnum(786,"处置人不存在");
    public static ResponseEnum RISK_RECTIFY_CUTOFF_TIME_FROMAT_ERROR = new ResponseEnum(787,"整改截止时间格式错误");
    public static ResponseEnum SYS_DATA_SCOPE_IS_NOT_OPTION = new ResponseEnum(788,"数据权限不在选项中");
    public static ResponseEnum SYS_USER_IS_NOT_EXIST = new ResponseEnum(789,"用户账号不存在");
    public static ResponseEnum SYS_USER_ROLE_IS_NOT_EXIST = new ResponseEnum(790,"角色权限字符不存在");
    public static ResponseEnum SYS_CUSTOM_IS_NOT_EMPTY = new ResponseEnum(791,"自定义权限范围不能为空");
    public static ResponseEnum SYS_SUPER_IS_NOT_OPTION = new ResponseEnum(792,"不允许操作super用户");
    public static ResponseEnum SYS_SUPER_IS_NOT_IMPORT = new ResponseEnum(793,"不允许导入super角色");
    public static ResponseEnum SYS_CUSTOM_DEPT_IS_NOT_EXIST = new ResponseEnum(794,"自定义权限范围部门ID均不存在");
    public static ResponseEnum EMPOWER_CONFIG_PARSE_ERROR = new ResponseEnum(795,"文件内容解析失败");
    public static ResponseEnum ASSERT_SEGMENT_IS_NOT_EXIST = new ResponseEnum(796,"网段不存在");
    public static ResponseEnum ASSERT_INFO_IS_NOT_EXIST = new ResponseEnum(797,"资产信息不能为空");
    public static ResponseEnum TASK_IS_NOT_EXIST = new ResponseEnum(798,"任务不存在");
    public static ResponseEnum RECORD_IS_NOT_EXIST = new ResponseEnum(799,"待办不存在");
    public static ResponseEnum TASK_TYPE_PLAN  = new ResponseEnum(800, "当前任务上传的共享文档数据为空");
    public static ResponseEnum TASK_FEED_BACK_ERROR  = new ResponseEnum(801, "任务待办不存在");
    public static ResponseEnum DEPT_IS_NOT_DISTINCT = new ResponseEnum(802,"所选组织不能重复");
    public static ResponseEnum USER_IS_NOT_DISTINCT = new ResponseEnum(803,"所选执行人不能重复");
    public static ResponseEnum TASK_ORG_IS_NOT_EMPTY = new ResponseEnum(804,"下发组织不能为空");


    private final Integer code;
    private final String msg;

    private ResponseEnum(Integer code, String msg) {
        this.code = code;
        this.msg = msg;
    }
    public static ResponseEnum KEY_USER_SEX_ERROR  = new ResponseEnum(408,"性别不在选项中");
    public static ResponseEnum KEY_USER_TYPE_ERROR  = new ResponseEnum(409,"用户类型不在选项中");
    public static ResponseEnum KEY_USER_POST_NAME_ERROR  = new ResponseEnum(410,"岗位不在选项中");
    public static ResponseEnum KEY_LDAP_NAME_ERROR  = new ResponseEnum(411,"是否LDAP账号不在选项中");
    public static ResponseEnum KEY_STATUS_ERROR  = new ResponseEnum(412,"状态不在选项中");
    public static ResponseEnum COMPANY_IS_NOT_EXIST  = new ResponseEnum(413,"归属部门不存在");
    public static ResponseEnum USER_NAME_IS_EXIST  = new ResponseEnum(414,"账号已在系统中存在");
    public static ResponseEnum IMPORT_COLUMN_TYPE_ERROR = new ResponseEnum(619,"工作项类型错误，请下载导入模板");
    public static ResponseEnum GOOGLE_IS_BIND = new ResponseEnum(620,"已绑定，不能重复绑定");
    public static ResponseEnum GOOGLE_NOT_BIND = new ResponseEnum(621,"未绑定，请先进行绑定");
    public static ResponseEnum GOOGLE_CODE_NOT_MATCH = new ResponseEnum(622,"动态验证码不匹配");
    public static ResponseEnum GOOGLE_AUTHENTICATOR_401001 = new ResponseEnum(623,"登录权限校验失败");

    public static ResponseEnum HAS_NOT_IP_IMPORT_AUTH = new ResponseEnum(739,"没有该内网IP的变更权限");
    public static ResponseEnum INTERNAL_IP_IS_NOT_EXIST = new ResponseEnum(740,"内网IP不存在");
    public static ResponseEnum INTERNAL_IP_IS_NOT_EMPTY = new ResponseEnum(741,"内网IP不能为空");

    public static ResponseEnum ASSET_SEGEMENT_DEPT_NAME_ERROR = new ResponseEnum(734, "所属组织不在选项中");

    public static ResponseEnum ASSET_SEGEMENT_AREA_ERROR = new ResponseEnum(735, "网络区域不在选项中");

    public static ResponseEnum ASSET_SEGEMENT_ENV_ERROR = new ResponseEnum(735, "环境类型不在选项中");
    public static ResponseEnum VULN_PROJECT_SIZE_ERROR = new ResponseEnum(736,"所属项目最多可输入200个字符");
    public static ResponseEnum DEPT_IS_NOT_EMPTY = new ResponseEnum(737,"部门不能为空");
    public static ResponseEnum TASK_SIGN_CONTENT_ERROR = new ResponseEnum(738,"签字内容不正确");
    public static ResponseEnum CHECK_SECOND_METRIC_IS_EXIST = new ResponseEnum(739,"该考核模板的\"%s\"一级指标下\"%s\"二级指标已存在，请勿重复创建");
    public static ResponseEnum CHECK_FIRST_METRIC_IS_EXIST = new ResponseEnum(740,"该考核模板下一级指标名称已存在，请勿重复创建");
    public static ResponseEnum CHECK_TEMPLATE_IS_NOT_EXIST = new ResponseEnum(741,"模板不存在");
    public static ResponseEnum CHECK_METRIC_IS_NOT_EMPTY = new ResponseEnum(742,"指标id不能为空");
    public static ResponseEnum CHECK_METRIC_IS_NOT_EXIST = new ResponseEnum(743,"指标不存在");
    public static ResponseEnum CHECK_METRIC_IS_NOT_EXIST_REFRESH = new ResponseEnum(744,"指标不存在或已被删除，请刷新页面");
    public static ResponseEnum CHECK_TEMPLATE_APPLICATION_DELETE = new ResponseEnum(745,"考核模板正在被项目应用中，无法删除");
    public static ResponseEnum CHECK_METRIC_SECOND_DELETE = new ResponseEnum(746,"存在二级指标，无法删除");
    public static ResponseEnum CHECK_PROJECT_IS_NOT_EXIST = new ResponseEnum(747,"项目不存在");
    public static ResponseEnum CHECK_PROJECT_IS_START = new ResponseEnum(748,"项目已启动，请刷新页面");
    public static ResponseEnum CHECK_TEMPLATE_APPLICATION_UPDATE = new ResponseEnum(749,"考核模板正在被项目应用中，无法修改");
    public static ResponseEnum CHECK_METRIC_RECORD_IS_NOT_EXIST = new ResponseEnum(750,"待办不存在");
    public static ResponseEnum CHECK_PROJECT_IS_EXPIRED = new ResponseEnum(751,"项目已过期");
    public static ResponseEnum CHECK_METRIC_RECORD_IS_FEEDBACK = new ResponseEnum(752,"项目已反馈，请刷新页面");
    public static ResponseEnum CHECK_FEEDBACK_IS_NOT_ROLE = new ResponseEnum(753,"该用户没有反馈权限");
    public static ResponseEnum CHECK_FEEDBACK_DESCRIPTION = new ResponseEnum(754,"说明不能为空");
    public static ResponseEnum CHECK_ASSIGN_IS_NOT_ROLE = new ResponseEnum(755,"该用户没有分配权限");
    public static ResponseEnum CHECK_SCORE_IS_NOT_ROLE = new ResponseEnum(756,"该用户没有评分权限");
    public static ResponseEnum CHECK_SCORE_IS_ERROR = new ResponseEnum(757,"仅允许输入大于等于0、小于等于该二级指标分值的整数");
    public static ResponseEnum CHECK_SCORE_IS_NOT_COMPLETE = new ResponseEnum(758,"存在考核指标未完成评分，请检查");
    public static ResponseEnum CHECK_PROJECT_STATUS_ERROR = new ResponseEnum(759,"当前项目状态不允许确认");
    public static ResponseEnum CHECK_CONFIRM_IS_NOT_ROLE  = new ResponseEnum(760,"该用户没有确认权限");
    public static ResponseEnum CHECK_SCORE_APPEAL_IS_NOT_EXIST  = new ResponseEnum(761,"申诉不存在");
    public static ResponseEnum CHECK_SCORE_IS_APPEALING  = new ResponseEnum(761,"申诉正在审核中，请刷新页面");
    public static ResponseEnum CHECK_SCORE_APPEAL_IS_NOT_ROLE  = new ResponseEnum(762,"该用户没有审核权限");
    public static ResponseEnum CHECK_APPEAL_SCORE_IS_ERROR  = new ResponseEnum(763,"更新得分请输入大于等于0且小于等于满分(%s)的整数");
    public static ResponseEnum CHECK_DUTY_ID_IS_EXIST  = new ResponseEnum(764,"当前搜索部门不是当前用户的所属组织部门");

    public static ResponseEnum CHECK_NAME_VERSION_IS_EXIST  = new ResponseEnum(764,"软件版本不存在");

    public static ResponseEnum PERMISSION_DATE_FORMAT_ERROR  = new ResponseEnum(764,"许可截止日期格式错误");

    public static ResponseEnum ASSET_MANAGER_USER_ERROR  = new ResponseEnum(764,"资产管理员不存在");

    public static ResponseEnum ASSET_MANAGER_USER_ROLE_ERROR  = new ResponseEnum(764,"该用户没有资产管理员角色");

    public static ResponseEnum ASSET_MANAGER_USER_DEPT_ERROR  = new ResponseEnum(764,"该用户没有软件台账所属组织数据权限");

    public static ResponseEnum IOA_ERROR = new ResponseEnum(766,"调用腾讯新增资源接口失败");

    public static ResponseEnum ASSET_SPFTWARE_APPL_YLINCES_ERROR = new ResponseEnum(767, "软件名称和软件版本未在软件台账中维护");

    public static ResponseEnum ASSET_SPFTWARE_APPL_MACNOTFOUND_ERROR = new ResponseEnum(768, "Mac地址在终端设备里未找到");

    public static ResponseEnum ASSET_SPFTWARE_APPL_NOT_ONLY_ERROR = new ResponseEnum(769, "Mac地址在终端设备里存在多条数据");

    public static ResponseEnum ASSET_SPFTWARE_APPL_NOT_ONLY_UNCODE_ERROR = new ResponseEnum(780, "设备唯一识别码在终端设备里未找到");

    public static ResponseEnum ASSET_SPFTWARE_APPL_NOT_UNCODE_ONLY_ERROR = new ResponseEnum(781, "设备唯一识别码在终端设备里存在多条数据");

    public static ResponseEnum IOT_ASSET_DEVICE_TYPE_IS_NOT_EXIST = new ResponseEnum(782,"设备类型不在选项中");
    public static ResponseEnum IOT_ASSET_DEVICE_STATUS_IS_NOT_EXIST = new ResponseEnum(783,"设备状态不在选项中");
    public static ResponseEnum IOT_ASSET_DEVICE_TIME_FORMAT_ERROR = new ResponseEnum(784,"设备时间格式错误");
    public static ResponseEnum IOT_ASSET_DEVICE_ENABLE_IS_NOT_EXIST = new ResponseEnum(785,"设备是否停用不在选项中");

    public static ResponseEnum APP_SYSTEM_ASSET_TYPE_IS_NOT_EXIST = new ResponseEnum(786,"资产分类不在选项中");
    public static ResponseEnum APP_SYSTEM_CONSTRUCTION_TYPE_IS_NOT_EXIST = new ResponseEnum(786,"建设类型不在选项中");
    public static ResponseEnum APP_SYSTEM_PAST_YEAR_IS_NOT_EXIST = new ResponseEnum(786,"近一年上线/验收不在选项中");
    public static ResponseEnum APP_SYSTEM_PAST_YEAR_TYPE_IS_NOT_EXIST = new ResponseEnum(786,"近一年上线/验收类型不在选项中");
    public static ResponseEnum APP_SYSTEM_IS_IAM_IS_NOT_EXIST = new ResponseEnum(786,"与统一身份集成不在选项中");
    public static ResponseEnum APP_SYSTEM_IS_IAM_ACCOUNT_IS_NOT_EXIST = new ResponseEnum(786,"与统一身份进行账户集成不在选项中");
    public static ResponseEnum APP_SYSTEM_IS_SINOPEC_AD_IS_NOT_EXIST = new ResponseEnum(786,"与中国石化AD域集成不在选项中");
    public static ResponseEnum APP_SYSTEM_LOCAL_AUTH_IS_NOT_EXIST = new ResponseEnum(786,"本地认证方式不在选项中");
    public static ResponseEnum APP_SYSTEM_APP_ARCHITECTURE_IS_NOT_EXIST = new ResponseEnum(786,"应用架构不在选项中");
    public static ResponseEnum APP_SYSTEM_IS_INSTALL_G_IS_NOT_EXIST = new ResponseEnum(786,"安装G01不在选项中");
    public static ResponseEnum APP_SYSTEM_EQUAL_PROTECTION_LEVEL_IS_NOT_EXIST = new ResponseEnum(786,"等保级别不在选项中");
    public static ResponseEnum APP_SYSTEM_EQUAL_PROTECTION_STATUS_IS_NOT_EXIST = new ResponseEnum(786,"定级备案状态不在选项中");
    public static ResponseEnum APP_SYSTEM_IS_RANK_INFO_REPORT_SMCC_IS_NOT_EXIST = new ResponseEnum(786,"定级信息上报至SMCC不在选项中");
    public static ResponseEnum APP_SYSTEM_IS_INTERNET_PUBLIC_IS_NOT_EXIST = new ResponseEnum(786,"发布互联网不在选项中");
    public static ResponseEnum APP_SYSTEM_IS_ICP_IS_NOT_EXIST = new ResponseEnum(786,"ICP备案不在选项中");
    public static ResponseEnum APP_SYSTEM_IS_PUBLIC_NETWORK_SECURITY_IS_NOT_EXIST = new ResponseEnum(786,"公网安备案不在选项中");
    public static ResponseEnum APP_SYSTEM_EQUAL_PROTECTION_RANK_TIME_FORMAT_ERROR = new ResponseEnum(786,"等保定级时间时间格式错误");
    public static ResponseEnum APP_SYSTEM_EQUAL_PROTECTION_RECORD_TIME_FORMAT_ERROR = new ResponseEnum(786,"等保备案时间时间格式错误");
    public static ResponseEnum APP_SYSTEM_SIGN_TIME_FORMAT_ERROR = new ResponseEnum(786,"签订日期时间格式错误");
    public static ResponseEnum APP_SYSTEM_COMMITMENT_PERIOD_TIME_FORMAT_ERROR = new ResponseEnum(786,"承诺期限（起止时间）时间格式错误");
    public static ResponseEnum APP_SYSTEM_BUSINESS_DEPARTMENT_CONTACT_IS_NOT_EXIST = new ResponseEnum(786,"业务主管部门联系人不存在");


}
