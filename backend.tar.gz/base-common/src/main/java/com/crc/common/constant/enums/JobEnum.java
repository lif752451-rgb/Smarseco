package com.crc.common.constant.enums;

import lombok.Getter;

@Getter
public enum JobEnum {

    /**
     * 默认分组  任务名称自定义
     */
    DEFAULT("", "DEFAULT", ""),

    CHECK_PROJECT_JOB("checkProjectJob", "考核反馈通知", "checkProjectJob.push"),

    ;

    private final String jobName;

    private final String jobGroup;

    private final String invokeTarget;

    JobEnum(String jobName, String jobGroup, String invokeTarget) {
        this.jobName = jobName;
        this.jobGroup = jobGroup;
        this.invokeTarget = invokeTarget;
    }
}
