package com.crc.common.model;

import lombok.Data;

@Data
public class HwVo {
    String elemId;
    String elemValue;
}
