package com.crc.common.model.enums;

/**
 * @Author shufengfeng
 * @Description 菜单枚举类
 * @DateTime 2021/8/27 17:10
 */
public enum SysMenuEnum {

    /**
     * 二级菜单
     */
    ASSET_CHANGE_MANAGER("资产变更管理", "asset:change:manager"), ASSET_NET_SEGMENT("资产网段", "asset:segment:add"),
    ASSET_SYNERGY("资产协同", "asset:cooperation"), ASSET_NET_AREA("区域管理", "asset:net:area"),

    /**
     * 三级菜单
     */
    ALARM_CLOSED_LOOP_MANAGEMENT("告警闭环管理-%s", "alarm:closed:loop:management"),
    RISK_CLOSED_LOOP_MANAGEMENT("风险闭环管理-%s", "risk:closedManage"), RISK_DELAY_MANAGEMENT("风险延期审批", "risk:delayManage"),

    /**
     * 四级菜单
     */
    ASSET_PANORAMA("资产全景", "asset:panorama"), ASSET_SELECT("全部资产", "asset:serverip"),
    ASSET_MANAGER("资产管理", "asset:manager"), TERMINAL_EQUIPMENT("终端资产-终端设备", "terminal:equipment"),
    TERMINAL_SOFTWARE("终端资产-终端软件", "terminal:software"),

    ASSET_TO_BE_CLAIMED("待认领资产", ""), CLAIMED_ASSET("已认领资产", "asset:claim:done:see"),

    RISK_AUTO("全部风险单-自动发现", "auto:discovery:all"), RISK_AUTO_MY_TODO("我的待办—自动发现", "auto:discovery:my:todo"),

    VULNERABILITIES_TO_BE_FIXED("待修复漏洞", "vulnerabilities:to:be:fixed"),
    FIXED_VULNERABILITY("已修复漏洞", "fixed:vulnerability"),

    VUL_WHITE_LIST_ALL("全部加白申请", "vul:white:list:all"), VUL_WHITE_LIST_SELF_APPLY("我申请的", "vul:white:list:apply:self"),
    VUL_WHITE_LIST_SELF_APPROVE("我申请的", "vul:white:list:approve:self"),

    /**
     * 资产协同--资产协同--资产认领--待认领资产--认领资产
     */
    ASSET_TO_BE_CLAIMED_CLAIM("认领资产", "asset:claim:wait:claim"),

    /**
     * 资产协同--攻击面--互联网资产认领--待认领资产--认领资产
     */
    ASSET_ASM_IAM_CLAIM_WAIT_CLAIM("认领资产", "asset:asm:iamClaim:wait:claim"),

    /**
     * 资产协同--攻击面--互联网资产认领--待认领资产--批量认领资产
     */
    ASSET_ASM_IAM_CLAIM_WAIT_BATCH_CLAIM("批量认领资产", "asset:asm:iamClaim:wait:batchClaim"),

    /**
     * 风险上报-待推送Tab-新增
     */
    RISK_PROCESS_FORM_ADD("风险上报新增", "risk:submit:nopush:add"),

    /**
     * 风险上报-待推送Tab-修改
     */
    RISK_PROCESS_FORM_UPDATE("风险上报新增", "risk:submit:nopush:update"),

    /**
     * 资产协同--资产协同--资产信息--服务器资产--新增
     */
    SERVER_ASSET_SELECT_ADD("新增", "asset:serverip:add"),

    /**
     * 导入
     */
    ASSET_SERVERIP_IMPORT("导入", "asset:serverip:import"),

    /**
     * 资产协同--资产协同--资产信息--服务器资产--变更
     */
    SERVER_ASSET_SELECT_UPDATE("变更", "asset:serverip:update"),
    /**
     * 资产协同--资产协同--资产信息--服务器资产--删除
     */
    SERVER_ASSET_SELECT_DELETE("删除", "asset:serverip:delete"),

    /**
     * 资产协同--资产协同--资产信息--服务器资产--查看
     */
    SERVER_ASSET_SELECT_SEE("查看", "asset:serverip:see"),

    /**
     * 资产网段--变更
     */
    ASSET_SEGMENT_UPDATE("变更", "asset:segment:update"),
    /**
     * 资产网段--删除
     */
    ASSET_SEGMENT_DELETE("删除", "asset:segment:delete"),

    /**
     * 资产网段--查看
     */
    ASSET_SEGMENT_SEE("查看", "asset:segment:see"),

    /**
     * 应用系统
     */
    ASSET_APP_SYSTEM("应用系统信息", "asset:system"),

    /**
     * 在建应用系统信息
     */
    BUILD_ASSET_APP_SYSTEM("在建应用系统信息", "asset:buildingSystem"),

    /**
     * 应用系统--变更
     */
    ASSET_APPSYSTEM_UPDATE("变更", "asset:system:update"),
    /**
     * 应用系统--删除
     */
    ASSET_APPSYSTEM_DELETE("删除", "asset:system:delete"),

    /**
     * 应用系统--查看
     */
    ASSET_APPSYSTEM_SEE("查看", "asset:system:see"),

    /**
     * 威胁管理--告警闭环管理（集团常态化）--全部安全告警
     */
    GROUP_ALARM_CLOSED_LOOP_ALL("全部安全告警", "alarm:closed:loop:all", "2716"),

    /**
     * 告警转漏洞-提交漏洞
     */
    ALARM_MANAGE_SUBMIT_LOOPHOLE("提交漏洞", "alarm:manage:submit:loophole"),

    /**
     * 威胁管理--告警闭环管理（业务单元常态化）
     */
    BUSINESS_ALARM_CLOSED_LOOP_ALL("全部安全告警", "alarm:closed:loop:all", "2766"),

    SEC_REPORT_SECTRAGE_CONFIG("推送策略配置", "risk:secreport:manage:set"),
    SEC_REPORT_SECTRAGE_CONFIG_ADD("推送策略配置-新增", "risk:secreport:manage:set:add"),
    SEC_REPORT_SECTRAGE_CONFIG_UPDATE("推送策略配置-修改", "risk:secreport:manage:set:update"),
    SEC_REPORT_SECTRAGE_CONFIG_LOOK("推送策略配置-查看", "risk:secreport:manage:set:look"),
    SEC_REPORT_SECTRAGE_CONFIG_DELETE("推送策略配置-删除", "risk:secreport:manage:set:delete"),
    SEC_REPORT_SECTRAGE_CONFIG_STATUS("推送策略配置-状态切换", "risk:secreport:manage:set:status"),
    REPORT_SEND_RECORD("报告推送记录", "risk:secreport:manage:pushrecord"),

    /**
     * 漏洞管理-漏洞扫描-任务管理
     */
    RISK_LOOP_VUL_SCAN_CRON_ALL("任务管理", "risk:loop:vulscan:cron:all"),
    /**
     * 漏洞管理-漏洞扫描-任务管理-添加任务
     */
    RISK_LOOP_VUL_SCAN_CRON_ADD("添加任务", "risk:loop:vulscan:cron:add"),

    /**
     * 漏洞管理-漏洞闭环-全部漏洞
     */
    RISK_LOOP_CLOSED_MANAGE_ALL("全部漏洞", "risk:loop:closed:manage:all"),
    /**
     * 漏洞管理-漏洞闭环-我的待办
     */
    RISK_LOOP_CLOSED_MANAGE_WAIT("我的待办", "risk:loop:closed:manage:wait"),
    /**
     * 漏洞管理-漏洞闭环-我的已办
     */
    RISK_LOOP_CLOSED_MANAGE_DONE("我的已办", "risk:loop:closed:manage:done"),
    /**
     * 威胁管理-常态化告警闭环-全部漏洞
     */
    ALARM_CLOSED_LOOP_ALL("全部漏洞", "alarm:closed:loop:all"),
    /**
     * 威胁管理-常态化告警闭环-我的待办
     */
    ALARM_CLOSED_LOOP_WAIT("我的待办", "alarm:closed:loop:wait"),
    /**
     * 威胁管理-常态化告警闭环-我的已办
     */
    ALARM_CLOSED_LOOP_DONE("我的已办", "alarm:done"),
    /**
     * 漏洞管理-漏洞闭环-全部漏洞-提交漏洞
     */
    RISK_LOOP_CLOSED_MANAGE_ALL_SUBMIT("提交漏洞", "risk:loop:closed:manage:all:submit"),
    /**
     * 告警白名单-全部申请
     */
    ALARM_WHITELIST("告警白名单-全部申请", "alarm:whitelist:push:all"),
    /**
     * 漏洞白名单-全部加白申请
     */
    VUL_WHITELIST("漏洞白名单-全部加白申请", "risk:loop:whitelistManage:all"),
    /**
     * 威胁管理-告警闭环-全部告警-列表
     */
    ALARM_HVV_CLOSED_LOOP_ALL("全部告警", "alarm:hvv:closed:loop:all"),
    /**
     * 威胁管理-告警闭环-全部告警-上报告警
     */
    ALARM_HVV_CLOSED_LOOP_ALL_SUBMIT("上报告警", "alarm:hvv:closed:loop:all:submit"),
    /**
     * 威胁管理-告警闭环-全部告警-研判
     */
    ALARM_HVV_CLOSED_LOOP_ALL_JUDGE("研判", "alarm:hvv:closed:loop:all:judge"),
    /**
     * 威胁管理-告警闭环-全部告警-处置
     */
    ALARM_HVV_CLOSED_LOOP_ALL_HANDLE("处置", "alarm:hvv:closed:loop:all:handle"),
    /**
     * 威胁管理-告警闭环-全部告警-后续跟进
     */
    ALARM_HVV_CLOSED_LOOP_ALL_FOLLOW("后续跟进", "alarm:hvv:closed:loop:all:follow"),
    /**
     * 威胁管理-告警闭环-全部告警-审核
     */
    ALARM_HVV_CLOSED_LOOP_ALL_AUDIT("审核", "alarm:hvv:closed:loop:all:audit"),
    /**
     * 威胁管理-告警闭环-全部告警-归档
     */
    ALARM_HVV_CLOSED_LOOP_ALL_COMPLETE("归档", "alarm:hvv:closed:loop:all:complete"),
    /**
     * 威胁管理-告警闭环-全部告警-无需处置
     */
    ALARM_HVV_CLOSED_LOOP_ALL_IGNORE("无需处置", "alarm:hvv:closed:loop:all:ignore"),
    /**
     * 威胁管理-告警闭环-溯源
     */
    ALARM_HVV_CLOSED_LOOP_TRACE("溯源", "alarm:hvv:closed:loop:trace"),
    /**
     * 威胁管理-告警闭环-标记
     */
    ALARM_HVV_CLOSED_LOOP_PIN("标记", "alarm:hvv:closed:loop:pin"),
    /**
     * 威胁管理-告警闭环-我的待办
     */
    ALARM_HVV_CLOSED_LOOP_WAIT("我的待办", "alarm:hvv:closed:loop:wait"),
    /**
     * 威胁管理-告警闭环-我的已办
     */
    ALARM_HVV_CLOSED_LOOP_DONE("我的已办", "alarm:hvv:closed:loop:done"),
    /**
     * 威胁管理-告警闭环-我的待办-研判
     */
    ALARM_HVV_CLOSED_LOOP_WAIT_JUDGE("研判", "alarm:hvv:closed:loop:wait:judge"),
    /**
     * 威胁管理-告警闭环-我的待办-处置
     */
    ALARM_HVV_CLOSED_LOOP_WAIT_HANDLE("处置", "alarm:hvv:closed:loop:wait:handle"),
    /**
     * 威胁管理-告警闭环-我的待办-后续跟进
     */
    ALARM_HVV_CLOSED_LOOP_WAIT_FOLLOW("后续跟进", "alarm:hvv:closed:loop:wait:follow"),
    /**
     * 威胁管理-告警闭环-我的待办-审核
     */
    ALARM_HVV_CLOSED_LOOP_WAIT_AUDIT("审核", "alarm:hvv:closed:loop:wait:audit"),
    /**
     * 威胁管理-告警闭环-我的待办-归档
     */
    ALARM_HVV_CLOSED_LOOP_WAIT_COMPLETE("归档", "alarm:hvv:closed:loop:wait:complete"),
    /**
     * 威胁管理-告警闭环-我的待办-无需处置
     */
    ALARM_HVV_CLOSED_LOOP_WAIT_IGNORE("无需处置", "alarm:hvv:closed:loop:wait:ignore"),
    /**
     * 资产标签维护
     */
    ASSET_TAG_MANAGE("资产标签维护", "alarm:manage:tag"),
    /**
     * 攻击链路分析
     */
    ATTACK_LINK_ANALYSE("攻击链路分析", "attacklink:analyse"),
    ATTACK_LINK_ANALYSE_NEW("攻击链路分析（新版）", "attacklink:analyse:new"),
    /**
     * 漏洞管理-全部漏洞-主机漏洞
     */
    VULN_HOST("漏洞管理-全部漏洞-主机漏洞", "vuln:host"), VULN_WEB("漏洞管理-全部漏洞-WEB漏洞", "vuln:web"),
    VULN_CODE("漏洞管理-全部漏洞-弱口令", "vuln:code"),

    /**
     * 漏洞闭环-主机漏洞
     */
    VULN_LOOP_HOST("漏洞闭环-主机漏洞", "vuln:loop:host"),

    /**
     * 漏洞闭环-主机漏洞-全部工单
     */
    VULN_LOOP_HOST_ALL("漏洞闭环-主机漏洞-全部工单", "vuln:loop:host:all"),

    /**
     * 漏洞闭环-主机漏洞-我的待办
     */
    VULN_LOOP_HOST_WAIT("漏洞闭环-主机漏洞-我的待办", "vuln:loop:host:wait"),

    /**
     * 漏洞闭环-主机漏洞-我的已办
     */
    VULN_LOOP_HOST_DONE("漏洞闭环-主机漏洞-我的已办", "vuln:loop:host:done"),

    /**
     * 漏洞闭环-主机漏洞
     */
    VULN_LOOP_WEB("漏洞闭环-主机漏洞", "vuln:loop:web"),

    /**
     * 漏洞闭环-WEB漏洞-全部工单
     */
    VULN_LOOP_WEB_ALL("漏洞闭环-WEB漏洞-全部工单", "vuln:loop:web:all"),

    /**
     * 漏洞闭环-WEB漏洞-我的待办
     */
    VULN_LOOP_WEB_WAIT("漏洞闭环-WEB漏洞-我的待办", "vuln:loop:web:wait"),

    /**
     * 漏洞闭环-WEB漏洞-我的已办
     */
    VULN_LOOP_WEB_DONE("漏洞闭环-WEB漏洞-我的已办", "vuln:loop:web:done"),

    /**
     * 漏洞闭环-主机漏洞
     */
    VULN_LOOP_CODE("漏洞闭环-主机漏洞", "vuln:loop:code"),

    /**
     * 漏洞闭环-弱口令漏洞-全部工单
     */
    VULN_LOOP_CODE_ALL("漏洞闭环-弱口令漏洞-全部工单", "vuln:loop:code:all"),

    /**
     * 漏洞闭环-弱口令漏洞-我的待办
     */
    VULN_LOOP_CODE_WAIT("漏洞闭环-弱口令漏洞-我的待办", "vuln:loop:code:wait"),

    /**
     * 漏洞闭环-弱口令漏洞-我的已办
     */
    VULN_LOOP_CODE_DONE("漏洞闭环-弱口令漏洞-我的已办", "vuln:loop:code:done"),

    /**
     * 漏洞延期待审批-查看
     */
    VUL_DELAY_SEE("漏洞延期待审批-查看", "vuln:delay:wait:see"),

    /**
     * 漏洞延期已审批-查看
     */
    VUL_DELAY_DONE_SEE("漏洞延期已审批-查看", "vuln:delay:done:see"),

    /**
     * 漏洞延期待审批-审批
     */
    VUL_DELAY_AUDIT("漏洞延期待审批-审批", "vuln:delay:wait:audit"),

    /**
     * 漏洞延期-导出
     */
    VUL_DELAY_EXPORT("漏洞延期-导出", "vuln:delay:wait:export"),

    /**
     * 漏洞延期已审批-导出
     */
    VUL_DELAY_DONE_EXPORT("漏洞延期已审批-导出", "vuln:delay:done:export"),

    /**
     * 漏洞白名单待审批-查看
     */
    VUL_WHITE_WAIT_SEE("漏洞白名单待审批-查看", "vuln:whitelist:wait:see"),

    /**
     * 漏洞白名单已审批-查看
     */
    VUL_WHITE_DONE_SEE("漏洞白名单已审批-查看", "vuln:whitelist:done:see"),

    /**
     * 漏洞白名单待审批-审批
     */
    VUL_WHITE_AUDIT("漏洞白名单待审批-审批", "vuln:whitelist:wait:audit"),

    /**
     * 漏洞白名单待审批-删除
     */
    VUL_WHITE_WAIT_DELETE("漏洞白名单待审批-删除", "vuln:whitelist:wait:delete"),

    /**
     * 漏洞白名单已审批-删除
     */
    VUL_WHITE_DONE_DELETE("漏洞白名单已审批-删除", "vuln:whitelist:done:delete"),

    /**
     * 漏洞白名单待审批-导出
     */
    VUL_WHITE_WAIT_EXPORT("漏洞白名单待审批-导出", "vuln:whitelist:export"),

    /**
     * 漏洞白名单已审批-导出
     */
    VUL_WHITE_DONE_EXPORT("漏洞白名单已审批-导出", "vuln:whitelist:done:export"),

    /**
     * 代码审计-项目管理
     */
    CODE_REVIEW_PROJECT("代码审计-项目管理", "codereview:project"),

    /**
     * 代码缺陷闭环-全部工单
     */
    CODE_LOOP_ALL("代码缺陷闭环-全部工单", "codereview:defect:loop:all"),

    /**
     * 代码缺陷闭环-我的待办
     */
    CODE_LOOP_WAIT("代码缺陷闭环-我的待办", "codereview:defect:loop:wait"),

    /**
     * 代码缺陷闭环-我的已办
     */
    CODE_LOOP_DONE("代码缺陷闭环-我的已办", "codereview:defect:loop:done"),

    ASSET_ASM_DNS_SEE("攻击面管理-域名管理-查看", "asset:asm:dns:see"),
    ASSET_ASM_DNS_UPDATE("攻击面管理-域名管理-变更", "asset:asm:dns:update"),
    ASSET_ASM_DNS_DELETE("攻击面管理-域名管理-删除", "asset:asm:dns:delete"),
    ASSET_ASM_IAM_SEE("攻击面管理-互联网管理-查看", "asset:asm:iam:see"),
    ASSET_ASM_IAM_UPDATE("攻击面管理-互联网管理-变更", "asset:asm:iam:update"),
    ASSET_ASM_IAM_DELETE("攻击面管理-互联网管理-删除", "asset:asm:iam:delete"),

    ASSET_ASM_INFO_LEAK_SEE("攻击面管理-信息泄露-查看", "asset:asm:ilm:see"),
    ASSET_ASM_INFO_LEAK_DELETE("攻击面管理-信息泄露-删除", "asset:asm:ilm:delete"),
    ASSET_ASM_INFO_LEAK_RISK("攻击面管理-信息泄露-转风险", "asset:asm:ilm:risk"),

    /**
     * 实战告警闭环-集团流程
     */
    COMBAT_GROUP("集团流程", "combat:group"),

    /**
     * 实战告警闭环-集团-全部工单
     */
    COMBAT_GROUP_ALL("全部工单", "combat:group:all"),

    /**
     * 实战告警闭环-租户流程
     */
    COMBAT_TENANT("租户流程", "combat:tenant"),

    /**
     * 实战告警闭环-租户-全部工单
     */
    COMBAT_TENANT_ALL("全部工单", "combat:tenant:all"),

    /**
     * 实战告警闭环-集团-研判
     */
    COMBAT_GROUP_ALL_JUDGE("研判", "combat:group:all:judge"),

    /**
     * 实战告警闭环-租户-研判
     */
    COMBAT_TENANT_ALL_JUDGE("研判", "combat:tenant:all:judge"),

    /**
     * 实战告警闭环-集团-处置
     */
    COMBAT_GROUP_ALL_DEAL("处置", "combat:group:all:deal"),

    /**
     * 实战告警闭环-租户-处置
     */
    COMBAT_TENANT_ALL_DEAL("处置", "combat:tenant:all:deal"),

    /**
     * 实战告警闭环-集团-后续跟进
     */
    COMBAT_GROUP_ALL_FOLLOW("后续跟进", "combat:group:all:follow"),

    /**
     * 实战告警闭环-租户-后续跟进
     */
    COMBAT_TENANT_ALL_FOLLOW("后续跟进", "combat:tenant:all:follow"),

    /**
     * 实战告警闭环-集团-审核
     */
    COMBAT_GROUP_ALL_AUDIT("审核", "combat:group:all:audit"),

    /**
     * 实战告警闭环-租户-审核
     */
    COMBAT_TENANT_ALL_AUDIT("审核", "combat:tenant:all:audit"),

    /**
     * 实战告警闭环-集团-归档
     */
    COMBAT_GROUP_ALL_COMPLETE("归档", "combat:group:all:complete"),

    /**
     * 实战告警闭环-租户-归档
     */
    COMBAT_TENANT_ALL_COMPLETE("归档", "combat:tenant:all:complete"),

    /**
     * 实战告警闭环-集团-无需处置
     */
    COMBAT_GROUP_ALL_NO_DEAL("无需处置", "combat:group:all:noDeal"),

    /**
     * 实战告警闭环-租户-无需处置
     */
    COMBAT_TENANT_ALL_NO_DEAL("无需处置", "combat:tenant:all:noDeal"),

    /**
     * 实战告警闭环-集团-上报告警
     */
    COMBAT_GROUP_SUBMIT("上报告警", "combat:group:submit"),

    /**
     * 实战告警闭环-租户-上报告警
     */
    COMBAT_TENANT_SUBMIT("上报告警", "combat:tenant:submit"),

    /**
     * 实战告警闭环-集团-批量关闭
     */
    COMBAT_GROUP_BATCH_CLOSE("批量关闭", "combat:group:batch:close"),

    /**
     * 实战告警闭环-租户-批量关闭
     */
    COMBAT_TENANT_BATCH_CLOSE("批量关闭", "combat:tenant:batch:close"),

    /**
     * 实战告警闭环-集团-标记
     */
    COMBAT_GROUP_PIN("标记", "combat:group:pin"),

    /**
     * 实战告警闭环-租户-标记
     */
    COMBAT_TENANT_PIN("标记", "combat:tenant:pin"),

    /**
     * 实战告警闭环-集团-溯源
     */
    COMBAT_GROUP_TRACE("溯源", "combat:group:trace"),

    /**
     * 实战告警闭环-租户-溯源
     */
    COMBAT_TENANT_TRACE("溯源", "combat:tenant:trace"),

    /**
     * 实战告警闭环-集团-快捷加白
     */
    COMBAT_GROUP_ADD_WHITELIST("快捷加白", "combat:group:add:whitelist"),

    /**
     * 实战告警闭环-租户-快捷加白
     */
    COMBAT_TENANT_ADD_WHITELIST("快捷加白", "combat:tenant:add:whitelist"),

    /**
     * 实战告警闭环-集团-转风险
     */
    COMBAT_GROUP_SWITCH_RISK("转风险", "combat:group:switch:risk"),

    /**
     * 实战告警闭环-集团-转关注
     */
    COMBAT_GROUP_SWITCH_KEY("转关注", "combat:group:switch:key"),

    /**
     * 实战告警闭环-租户-转关注
     */
    COMBAT_TENANT_SWITCH_KEY("转关注", "combat:tenant:switch:key"),

    /**
     * 实战告警闭环-集团-资产标签维护
     */
    COMBAT_GROUP_ASSET_TAG("资产标签维护", "combat:group:asset:tag"),

    /**
     * 实战告警闭环-租户-资产标签维护
     */
    COMBAT_TENANT_ASSET_TAG("资产标签维护", "combat:tenant:asset:tag"),

    /**
     * 实战告警闭环-集团-攻击链路
     */
    COMBAT_GROUP_ATTACK_LINK("攻击链路", "combat:group:attack:link"),

    /**
     * 实战告警闭环-租户-攻击链路
     */
    COMBAT_TENANT_ATTACK_LINK("攻击链路", "combat:tenant:attack:link"),

    /**
     * 实战告警闭环-集团-我的待办
     */
    COMBAT_GROUP_WAIT("我的待办", "combat:group:wait"),

    /**
     * 实战告警闭环-租户-我的待办
     */
    COMBAT_TENANT_WAIT("我的待办", "combat:tenant:wait"),

    /**
     * 实战告警闭环-集团-我的待办-研判
     */
    COMBAT_GROUP_WAIT_JUDGE("研判", "combat:group:wait:judge"),

    /**
     * 实战告警闭环-租户-我的待办-研判
     */
    COMBAT_TENANT_WAIT_JUDGE("研判", "combat:tenant:wait:judge"),

    /**
     * 实战告警闭环-集团-我的待办-处置
     */
    COMBAT_GROUP_WAIT_DEAL("处置", "combat:group:wait:deal"),

    /**
     * 实战告警闭环-租户-我的待办-处置
     */
    COMBAT_TENANT_WAIT_DEAL("处置", "combat:tenant:wait:deal"),

    /**
     * 实战告警闭环-集团-我的待办-后续跟进
     */
    COMBAT_GROUP_WAIT_FOLLOW("后续跟进", "combat:group:wait:follow"),

    /**
     * 实战告警闭环-租户-我的待办-后续跟进
     */
    COMBAT_TENANT_WAIT_FOLLOW("后续跟进", "combat:tenant:wait:follow"),

    /**
     * 实战告警闭环-集团-我的待办-审核
     */
    COMBAT_GROUP_WAIT_AUDIT("审核", "combat:group:wait:audit"),

    /**
     * 实战告警闭环-租户-我的待办-审核
     */
    COMBAT_TENANT_WAIT_AUDIT("审核", "combat:tenant:wait:audit"),

    /**
     * 实战告警闭环-集团-我的待办-归档
     */
    COMBAT_GROUP_WAIT_COMPLETE("归档", "combat:group:wait:complete"),

    /**
     * 实战告警闭环-租户-我的待办-归档
     */
    COMBAT_TENANT_WAIT_COMPLETE("归档", "combat:tenant:wait:complete"),

    /**
     * 实战告警闭环-集团-我的待办-无需处置
     */
    COMBAT_GROUP_WAIT_NO_DEAL("无需处置", "combat:group:wait:noDeal"),

    /**
     * 实战告警闭环-租户-我的待办-无需处置
     */
    COMBAT_TENANT_WAIT_NO_DEAL("无需处置", "combat:tenant:wait:noDeal"),

    /**
     * 实战告警闭环-集团-我的已办
     */
    COMBAT_GROUP_DONE("我的已办", "combat:group:done"),

    /**
     * 实战告警闭环-租户-我的已办
     */
    COMBAT_TENANT_DONE("我的已办", "combat:tenant:done"),

    /**
     * 实战告警闭环-租户-申请协助工单
     */
    COMBAT_TENANT_HELP_ALARM("申请协助工单", "combat:tenant:help:alarm"),

    /**
     * 实战告警闭环-租户-申请集团协助
     */
    COMBAT_TENANT_APPLY_HELP("申请集团协助", "combat:tenant:apply:help"),

    /**
     * 实战告警闭环-租户-上报集团流程
     */
    COMBAT_TENANT_ADD_GROUP("上报集团流程", "combat:tenant:add:group"),

    /**
     * 实战告警闭环-集团-重新发起
     */
    COMBAT_GROUP_REISSUE("重新发起", "combat:group:reissue"),

    /**
     * 实战告警闭环-租户-重新发起
     */
    COMBAT_TENANT_REISSUE("重新发起", "combat:tenant:reissue"),

    /**
     * 威胁管理-告警白名单申请(已弃用)
     */
    @Deprecated
    ALARM_WHITE_LIST_APPLY("告警白名单申请", "alarm:closed:loop:management"),

    /**
     * 威胁管理-告警白名单申请-全部加白申请
     */
    ALARM_WHITE_LIST_ALL("全部加白申请", "alarm:whitelist:push:all"),

    /**
     * 威胁管理-告警白名单申请-全部加白申请-待申请-提交申请
     */
    ALARM_WHITE_LIST_WAIT_APPLY("提交申请", "alarm:whitelist:push:all:wait:apply"),

    /**
     * 威胁管理-告警白名单申请-我申请的
     */
    ALARM_WHITE_LIST_MY_SUBMIT("我申请的", "alarm:whitelist:push:mysubmit"),

    /**
     * 威胁管理-告警白名单申请-我申请的
     */
    ALARM_WHITE_LIST_MY_CHECK("我审核的", "alarm:whitelist:push:mycheck"),

    /**
     * 脆弱性管理-基线管理-基线闭环-全部工单
     */
    BASELINE_LOOP_ALL("全部工单", "baseline:loop:all"),

    /**
     * 脆弱性管理-基线管理-基线闭环-我的待办
     */
    BASELINE_LOOP_WAIT("我的待办", "baseline:loop:wait"),

    /**
     * 脆弱性管理-基线管理-基线闭环-我的已办
     */
    BASELINE_LOOP_DONE("我的已办", "baseline:loop:done"),

    /**
     * 脆弱性管理-基线延期管理-查看
     */
    BASELINE_DELAY_SEE("基线延期管理查看", "baseline:delay:wait:see"),

    /**
     * 脆弱性管理-基线延期管理-审批
     */
    BASELINE_DELAY_AUDIT("基线延期管理审批", "baseline:delay:wait:audit"),

    /**
     * 脆弱性管理-基线问题发线
     */
    BASELINE_DISCOVER("基线问题发现", "baseline:discover"),

    /**
     * 脆弱性管理-基线问题发线
     */
    ALARM_WHITE_LIST_ADD("告警白名单新增", "alarm:whitelist:wait:submit"),


    /**
     * 告警白名单审核
     */
    ALARM_WHITE_WAIT_AUDIT("告警白名单审核", "alarm:whitelist:wait:audit"),

    /**
     * 告警白名单查看
     */
    ALARM_WHITE_WAIT_SEE("告警白名单查看", "alarm:whitelist:wait:see"),


    /**
     * 告警白名单删除
     */
    ALARM_WHITE_WAIT_DELETE("告警白名单删除", "alarm:whitelist:wait:delete"),


    /**
     * 告警白名单复制
     */
    ALARM_WHITE_DONE_COPY("告警白名单复制", "alarm:whitelist:done:copy"),

    /**
     * 告警白名单查看
     */
    ALARM_WHITE_DONE_SEE("告警白名单查看", "alarm:whitelist:done:see"),


    /**
     * 告警白名单删除
     */
    ALARM_WHITE_DONE_DELETE("告警白名单删除", "alarm:whitelist:done:delete"),

    /**
     * 资产网段
     */
    ASSET_SEGMENT_IMPORT("资产网段导出", "asset:segment:import"),

    /**
     * 风险整改延期-待审批-审批
     */
    RISK_DELAY_WAIT_AUDIT("风险延期管理-待审批-审批", "risk:delay:wait:audit"),

    /**
     * 风险整改延期-待审批-审批
     */
    RISK_DELAY_WAIT_SEE("风险延期管理-待审批-查看", "risk:delay:wait:see"),


    /**
     * 风险整改延期-待审批-审批
     */
    RISK_DELAY_DONE_SEE("风险延期管理-已审批-查看", "risk:delay:done:see"),

    /**
     * 风险上报
     */
    RISK_SUBMIT("风险上报","risk:submit"),

    /**
     * 风险上报-待推送
     */
    RISK_SUBMIT_NOPUSH("待推送","risk:submit:nopush"),

    /**
     * 风险上报-待推送-推送按钮
     */
    RISK_SUBMIT_NOPUSH_PUSH("推送","risk:submit:nopush:push"),

    /**
     * 风险上报-待推送-新增风险
     */
    RISK_SUBMIT_NOPUSH_ADD("新增","risk:submit:nopush:add"),

    /**
     * 风险上报-待推送-查看风险
     */
    RISK_SUBMIT_NOPUSH_SEE("查看","risk:submit:nopush:see"),

    /**
     * 风险上报-待推送-修改风险
     */
    RISK_SUBMIT_NOPUSH_UPDATE("修改","risk:submit:nopush:update"),

    /**
     * 风险上报-待推送-删除风险
     */
    RISK_SUBMIT_NOPUSH_DELETE("删除","risk:submit:nopush:delete"),

    /**
     * 风险上报-已推送
     */
    RISK_SUBMIT_ISPUSH("已推送","risk:submit:ispush"),

    /**
     * 风险上报-已推送-撤回
     */
    RISK_SUBMIT_ISPUSH_RETURN("撤回","risk:submit:ispush:return"),

    /**
     * 风险上报-已推送-查看
     */
    RISK_SUBMIT_ISPUSH_SEE("查看","risk:submit:ispush:see"),

    /**
     * 风险整改闭环
     */
    RISK_LOOP("risk:loop","risk:loop"),

    /**
     * 风险上报-全部工单
     */
    RISK_LOOP_ALL("全部工单","risk:loop:all"),

    /**
     * 风险上报-全部工单-待分配Tab
     */
    RISK_LOOP_ALL_DIVIDE("待分配Tab","risk:loop:all:divide"),

    /**
     * 风险上报-全部工单-待处置Tab
     */
    RISK_LOOP_ALL_DEAL("待处置Tab", "risk:loop:all:deal"),

    /**
     * 风险上报-全部工单-部门审核Tab
     */
    RISK_LOOP_ALL_AUDIT("部门审核Tab", "risk:loop:all:audit"),

    /**
     * 风险上报-全部工单-残余风险Tab
     */
    RISK_LOOP_ALL_REMAIN("残余风险Tab", "risk:loop:all:remain"),

    /**
     * 风险上报-全部工单-整改验证Tab
     */
    RISK_LOOP_ALL_VERIFY("整改验证Tab", "risk:loop:all:verify"),

    /**
     * 风险上报-全部工单-已关闭Tab
     */
    RISK_LOOP_ALL_CLOSE("已关闭Tab", "risk:loop:all:close"),

    /**
     * 风险上报-全部工单-查看详情
     */
    RISK_LOOP_ALL_SEE("查看详情", "risk:loop:all:see"),

    /**
     * 风险上报-我的待办
     */
    RISK_LOOP_WAIT("我的待办", "risk:loop:wait"),

    /**
     * 风险上报-我的待办-待分配Tab
     */
    RISK_LOOP_WAIT_DIVIDE("待分配Tab","risk:loop:wait:divide"),

    /**
     * 风险上报-我的待办-待处置Tab
     */
    RISK_LOOP_WAIT_DEAL("待处置Tab","risk:loop:wait:deal"),

    /**
     * 风险上报-我的待办-部门审核Tab
     */
    RISK_LOOP_WAIT_AUDIT("部门审核Tab","risk:loop:wait:audit"),

    /**
     * 风险上报-我的待办-残余风险Tab
     */
    RISK_LOOP_WAIT_REMAIN("残余风险Tab","risk:loop:wait:remain"),

    /**
     * 风险上报-我的待办-整改验证Tab
     */
    RISK_LOOP_WAIT_VERIFY("整改验证Tab","risk:loop:wait:verify"),

    /**
     * 风险上报-我的待办-查看详情
     */
    RISK_LOOP_WAIT_SEE("查看详情","risk:loop:wait:see"),

    /**
     * 风险上报-我的已办
     */
    RISK_LOOP_DONE("我的已办","risk:loop:done"),

    /**
     * 风险上报-我的已办-查看详情
     */
    RISK_LOOP_DONE_SEE("查看详情","risk:loop:done:see"),

    /**
     * 风险整改-分配节点操作(分配/驳回)
     */
    RISK_LOOP_NODE_DIVIDE("分配节点操作按钮","risk:loop:node:divide"),

    /**
     * 风险整改-处置/残余处置节点操作(处置/转办/驳回/申请延期)
     */
    RISK_LOOP_NODE_DEAL("处置/残余处置节点操作按钮","risk:loop:node:deal"),

    /**
     * 风险整改-部门审核节点操作(审核)
     */
    RISK_LOOP_NODE_AUDIT("部门审核节点操作按钮","risk:loop:node:audit"),

    /**
     * 风险整改-整改验证节点操作(验证)
     */
    RISK_LOOP_NODE_VERIFY("整改验证节点操作按钮","risk:loop:node:verify"),

    /**
     * 风险整改-全流程添加备注
     */
    RISK_LOOP_NODE_REMARK("全流程添加备注","risk:loop:node:remark"),

    /**
     * 告警模型-通用模型
     */
    STRATEGY_ALARMMODEL_STANDARD_PROVE("通用模型", "strategy:alarmmodel:standard:prove"),

    /**
     * 告警模型-自定义模型
     */
    STRATEGY_ALARMMODEL_CUSTOM_PROVE("通用模型", "strategy:alarmmodel:custom:prove"),

    /**
     * 知识管理-制度库-制度管理-列表
     */
    KNOWLEDGE_INSTITUTION_MANAGE("制度管理-列表", "institution:manage"),

    /**
     * 知识管理-制度库-制度管理-审核权限
     */
    KNOWLEDGE_INSTITUTION_MANAGE_APPROVE("制度管理-审核", "institution:manage:wait:audit"),

    /**
     * 知识管理-制度库-制度管理-待审批-查看权限
     */
    KNOWLEDGE_INSTITUTION_MANAGE_WAIT_SEE("制度管理-审核", "institution:manage:wait:see"),

    /**
     * 知识管理-制度库-制度管理-已审批-查看权限
     */
    KNOWLEDGE_INSTITUTION_MANAGE_DONE_SEE("制度管理-审核", "institution:manage:done:see"),


    /**
     * 知识管理-制度库-制度管理-待审批-删除权限
     */
    KNOWLEDGE_INSTITUTION_MANAGE_WAIT_DELETE("制度管理-审核", "institution:manage:wait:delete"),


    /**
     * 知识管理-制度库-制度管理-待审批-修改权限
     */
    KNOWLEDGE_INSTITUTION_MANAGE_WAIT_UPDATE("制度管理-审核", "institution:manage:wait:update"),

    /**
     * 合规管理-安全考核-项目管理
     */
    CHECK_PROJECT_MANAGER("合规管理-安全考核-项目管理", "check:project"),

    /**
     * 合规管理-安全考核-项目管理-查看
     */
    CHECK_PROJECT_MANAGER_SEE("合规管理-安全考核-项目管理-查看", "check:project:see"),

    /**
     * 合规管理-安全考核-项目管理-修改
     */
    CHECK_PROJECT_MANAGER_UPDATE("合规管理-安全考核-项目管理-修改", "check:project:update"),

    /**
     * 合规管理-安全考核-项目管理-删除
     */
    CHECK_PROJECT_MANAGER_DELETE("合规管理-安全考核-项目管理-删除", "check:project:delete"),

    /**
     * 合规管理-安全考核-项目管理-启动
     */
    CHECK_PROJECT_MANAGER_BEGIN("合规管理-安全考核-项目管理-启动", "check:project:begin"),

    /**
     * 合规管理-安全考核-考核反馈
     */
    CHECK_FEEDBACK("合规管理-安全考核-考核反馈", "check:feedback"),

    /**
     * 合规管理-安全考核-专家分配
     */
    CHECK_EXPERT("合规管理-安全考核-专家分配", "check:expert"),

    /**
     * 合规管理-安全考核-考核评分
     */
    CHECK_SCORE("合规管理-安全考核-考核评分", "check:score"),

    NOTIFICATION_MANAGE("安全通报-审核列表", "notification:manage"),

    NOTIFICATION_MANAGE_WAIT("安全通报-待审核列表", "notification:manage:wait"),

    NOTIFICATION_MANAGE_DONE("安全通报-已审核列表", "notification:manage:done"),
    NOTIFICATION_MANAGE_WAIT_AUDIT("安全通报-审核权限", "notification:manage:wait:audit"),

    SYSTEM_USER_LIST("用户管理列表","system:user:list"),

    NOTIFICATION_MANAGE_WAIT_SEE("安全通报-待审核详情","notification:manage:wait:see"),

    NOTIFICATION_WARNING("通报预警-我的代办","notification:warning"),

    SOFTWARE_LEDGER("软件台账管理列表","software:ledger"),


    SOFTWARE_EQUIPMENT("终端设备列表","terminal:equipment"),

    TERMINA_SOFTWARE("终端软件列表","terminal:software"),


    ;

    /**
     * 名称
     */
    private String name;

    /**
     * 权限
     */
    private String perms;

    /**
     * 菜单id
     */
    private String menuId;

    SysMenuEnum(String name, String perms) {
        this.name = name;
        this.perms = perms;
    }

    SysMenuEnum(String name, String perms, String menuId) {
        this.name = name;
        this.perms = perms;
        this.menuId = menuId;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getPerms() {
        return perms;
    }

    public void setPerms(String perms) {
        this.perms = perms;
    }

    public String getMenuId() {
        return menuId;
    }

    public void setMenuId(String menuId) {
        this.menuId = menuId;
    }
}
