package com.crc.common.utils.http;

import com.crc.common.utils.StringUtils;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.io.IOUtils;

import java.io.IOException;
import java.net.InetSocketAddress;
import java.net.Socket;

/**
 * @author jixiangqi
 * @date 2022/5/23
 */
@Slf4j
public class TelnetUtils {

    public static boolean telnetport(String ip, Integer port){
        Socket connect = new Socket();
        boolean res = false;
        try {
            if (StringUtils.isEmpty(String.valueOf(port))) {
                port = 80;
            }
            connect.connect(new InetSocketAddress(ip, port), 1000);//建立连接
            //能telnet通返回true，否则返回false
            res = connect.isConnected();//通过现有方法查看连通状态
        } catch (IOException e) {
            e.printStackTrace();
            log.error("telnet失败,IP为：{}，端口为：{}",ip, port);
        } finally {
            IOUtils.closeQuietly(connect);
        }
        return res;
    }

}
