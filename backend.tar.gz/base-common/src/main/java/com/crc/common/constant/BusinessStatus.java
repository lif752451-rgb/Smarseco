package com.crc.common.constant;

public enum BusinessStatus {

    /**
     * 成功
     */
    SUCCESS,

    /**
     * 失败
     */
    FAIL,
}
