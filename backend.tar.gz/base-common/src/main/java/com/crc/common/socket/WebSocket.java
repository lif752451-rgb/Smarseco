package com.crc.common.socket;

import cn.hutool.core.collection.CollUtil;
import cn.hutool.core.collection.ConcurrentHashSet;
import com.alibaba.fastjson.JSON;
import com.crc.common.model.WebsocketSendVo;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Component;

import javax.websocket.OnClose;
import javax.websocket.OnError;
import javax.websocket.OnMessage;
import javax.websocket.OnOpen;
import javax.websocket.Session;
import javax.websocket.server.PathParam;
import javax.websocket.server.ServerEndpoint;
import java.io.IOException;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.Set;
import java.util.stream.Collectors;

import static com.crc.common.socket.WebsocketGroup.COMMON_SOCKET_GROUP;
import static com.crc.common.socket.WebsocketGroup.SOCKET_GROUP_FIELD;

/**
 * WebSocket工具类
 *
 * @author zhangbing
 */
@Slf4j
@Component
@ServerEndpoint("/websocket/{userId}")
public class WebSocket {

    public static final Set<WebSocket> WEB_SOCKET_SET = new ConcurrentHashSet<>();


    private Long userId;

    private String socketGroup;

    private Session session;

    /**
     * 批量推送消息到指定用户
     *
     * @param userIdList 用户userId集合
     * @param vo 消息内容
     */
    public static void batchSendMessageByUser(List<Long> userIdList, WebsocketSendVo vo) {
        log.info("WebSocket建立了连接的用户：{}", WEB_SOCKET_SET.size());
        Set<Session> sessionSet = WEB_SOCKET_SET.stream()
            .filter(socket -> COMMON_SOCKET_GROUP.equals(socket.socketGroup) && userIdList.contains(socket.userId))
            .map(socket -> socket.session).collect(Collectors.toSet());
        sendMessage(vo, sessionSet);
        log.info("批量推送消息到指定用户 end");
    }

    /**
     * 推送消息到指定用户
     *
     * @param userId 用户ID
     * @param vo 发送的消息
     */
    public static void sendMessageByUser(Long userId, WebsocketSendVo vo) {
        log.info("WebSocket建立了连接的用户：{}", WEB_SOCKET_SET.size());
        log.info("指定WebSocket用户ID：" + userId);
        Set<Session> sessionSet = WEB_SOCKET_SET.stream()
            .filter(socket -> COMMON_SOCKET_GROUP.equals(socket.socketGroup) && socket.userId.equals(userId))
            .map(socket -> socket.session).collect(Collectors.toSet());
        sendMessage(vo, sessionSet);
    }


    /**
     * 推送消息
     *
     * @param sessionSet 用户session集合
     * @param vo 发送的消息
     */
    private static void sendMessage(WebsocketSendVo vo, Set<Session> sessionSet) {
        if (CollUtil.isEmpty(sessionSet) || Objects.isNull(vo)) {
            return;
        }
        String message = JSON.toJSONString(vo);
        log.info("推送WebSocket消息内容：" + message);
        sessionSet.forEach(session -> {
            try {
                session.getBasicRemote().sendText(message);
            } catch (IOException e) {
                log.error("推送消息发生错误：" + e.getMessage(), e);
            }
        });
    }

    public static void sendGroupMessage(String socketGroup, WebsocketSendVo vo) {
        if (Objects.isNull(vo)) {
            return;
        }
        String message = JSON.toJSONString(vo);
        log.info("发送消息：{}", message);
        WEB_SOCKET_SET.stream().filter(webSocket -> webSocket.getSocketGroupStr().equals(socketGroup))
            .forEach(webSocket -> {
                try {
                    webSocket.session.getBasicRemote().sendText(message);
                } catch (Exception e) {
                    log.error("群发消息发生错误：" + e.getMessage(), e);
                }
            });
    }

    /**
     * 群发消息 发送 socketGroup common
     *
     * @param vo 发送的消息
     */
    public static void sendAllMessage(WebsocketSendVo vo) {
        sendGroupMessage(COMMON_SOCKET_GROUP, vo);
    }

    /**
     * 获取分组
     *
     * @return 分组
     */
    private String getSocketGroupStr() {
        // 获取URL中的参数
        Map<String, List<String>> params = session.getRequestParameterMap();
        List<String> groupList = params.get(SOCKET_GROUP_FIELD);
        return CollUtil.isEmpty(groupList) ? COMMON_SOCKET_GROUP : groupList.get(0);
    }

    /**
     * 建立WebSocket连接
     *
     * @param userId 用户ID
     * @param session Session
     */
    @OnOpen
    public void onOpen(@PathParam(value = "userId") Long userId, Session session) {
        log.info("WebSocket建立连接中,连接用户ID：{}", userId);
        this.userId = userId;
        this.session = session;
        this.socketGroup = this.getSocketGroupStr();
        try {
            WEB_SOCKET_SET.add(this);
            session.getBasicRemote().sendText("WebSocket链接成功");
        } catch (Exception e) {
            log.error("重复登录异常,错误信息：" + e.getMessage(), e);
        }
        log.info("建立连接完成,当前在线人数为：{}", WEB_SOCKET_SET.size());
    }

    /**
     * 发生错误
     *
     * @param e e
     */
    @OnError
    public void onError(Throwable e) {
        log.error("异常,错误信息：" + e.getMessage(), e);
    }

    /**
     * 连接关闭
     *
     * @param userId 用户ID
     */
    @OnClose
    public void onClose(@PathParam(value = "userId") Long userId) {
        this.socketGroup = this.getSocketGroupStr();
        WEB_SOCKET_SET.remove(this);
        log.info("{},连接断开,当前在线人数为：{}", userId, WEB_SOCKET_SET.size());
    }

    /**
     * 接收客户端消息
     *
     * @param message 接收的消息
     */
    @OnMessage
    public void onMessage(String message) {
        log.info("收到客户端发来的消息：{}", message);
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) {
            return true;
        }
        if (o == null || getClass() != o.getClass()) {
            return false;
        }
        WebSocket webSocket = (WebSocket)o;
        return userId.equals(webSocket.userId) && session.equals(webSocket.session);
    }

    @Override
    public int hashCode() {
        return Objects.hash(userId, session);
    }
}
