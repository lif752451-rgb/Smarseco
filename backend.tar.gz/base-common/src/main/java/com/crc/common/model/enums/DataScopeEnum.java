package com.crc.common.model.enums;

import java.util.Arrays;

public enum DataScopeEnum {
    ALL("1","全部数据权限"),
    CUSTOM("2","自定数据权限"),
    DEPARTMENT("3","本部门数据权限"),
    DEPARTMENT_AND_CHILD("4","本部门及以下数据权限"),
    SELF("5","本人数据权限"),

    ;

    private String value;
    private String desc;

    DataScopeEnum(String value, String desc) {
        this.value = value;
        this.desc = desc;
    }

    public static String findDescByValue(String dataScope) {
        return Arrays.stream(DataScopeEnum.values()).filter(dataScopeEnum -> dataScopeEnum.getValue().equals(dataScope)).findFirst().get().getDesc();
    }
    public String getValue() {
        return value;
    }

    public void setValue(String value) {
        this.value = value;
    }

    public String getDesc() {
        return desc;
    }

    public void setDesc(String desc) {
        this.desc = desc;
    }

}
