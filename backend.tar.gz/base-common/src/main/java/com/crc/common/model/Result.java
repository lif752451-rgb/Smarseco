package com.crc.common.model;

import com.crc.common.model.enums.ResponseEnum;
import com.crc.common.utils.Convert;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.io.Serializable;

/**
 * 返回结果
 *
 * @author SHUFENGFENG
 * @date 2022/3/28 10:20
 */
@Data
@ApiModel(value = "返回结果")
@NoArgsConstructor
@AllArgsConstructor
public class Result<T> implements Serializable {

    private static final long serialVersionUID = -2078409108054493704L;

    /**
     * 返回的状态码
     */
    @ApiModelProperty(value = "返回的状态码")
    private Integer code;

    /**
     * 返回的信息提示
     */
    @ApiModelProperty(value = "返回的信息提示")
    private String msg;

    /**
     * 返回的数据
     */
    @ApiModelProperty(value = "返回的数据")
    private T data;

    private Result(int code, String msg) {
        this.code = code;
        this.msg = msg;
    }

    /**
     * 返回成功消息
     *
     * @return 成功消息
     */
    public static Result<String> successful(String data) {
        return successful(ResponseEnum.SUCCESS.getCode(), data);
    }

    /**
     * 返回成功消息
     *
     * @return 成功消息
     */
    public static Result<String> successful(Integer code, String data) {
        return success(Convert.toInt(code, ResponseEnum.SUCCESS.getCode()), "", data);
    }

    /**
     * 返回成功消息
     *
     * @param code 状态码
     * @param msg 提示语
     * @param data 返回对象
     * @param <T> 泛型
     * @return 成功消息
     */
    public static <T> Result<T> success(Integer code, String msg, T data) {
        return new Result<>(Convert.toInt(code, ResponseEnum.SUCCESS.getCode()), msg, data);
    }

    /**
     * 返回成功消息
     *
     * @param code 状态码
     * @param msg 提示语
     * @param <T> 泛型
     * @return 成功消息
     */
    public static <T> Result<T> success(Integer code, String msg) {
        return new Result<>(Convert.toInt(code, ResponseEnum.SUCCESS.getCode()), msg, null);
    }

    /**
     * 返回成功消息
     *
     * @return 成功消息
     */
    public static <T> Result<T> success() {
        return success(ResponseEnum.SUCCESS.getCode(), ResponseEnum.SUCCESS.getMsg());
    }

    /**
     * 返回成功消息
     *
     * @return 成功消息
     */
    public static <T> Result<T> success(T data) {
        return success(ResponseEnum.SUCCESS.getCode(), ResponseEnum.SUCCESS.getMsg(), data);
    }

    /**
     * 返回成功消息
     *
     * @return 成功消息
     */
    public static <T> Result<T> success(ResponseEnum response) {
        return success(response.getCode(), response.getMsg());
    }

    /**
     * 返回成功消息
     *
     * @return 成功消息
     */
    public static <T> Result<T> success(ResponseEnum response, Object msg) {
        return success(response.getCode(), String.format(response.getMsg(), msg.toString()));
    }

    /**
     * 返回错误消息
     *
     * @return 错误消息
     */
    public static <T> Result<T> error(Integer code, String msg, T data) {
        return new Result<>(Convert.toInt(code, ResponseEnum.UN_KNOW.getCode()), msg, data);
    }

    /**
     * 返回错误消息
     *
     * @return 错误消息
     */
    public static <T> Result<T> error(Integer code, String msg) {
        return new Result<>(Convert.toInt(code, ResponseEnum.UN_KNOW.getCode()), msg);
    }

    /**
     * 返回错误消息
     *
     * @return 成功消息
     */
    public static <T> Result<T> error() {
        return error(ResponseEnum.UN_KNOW.getCode(), ResponseEnum.UN_KNOW.getMsg());
    }

    /**
     * 返回错误消息
     *
     * @return 成功消息
     */
    public static <T> Result<T> error(T data) {
        return error(ResponseEnum.UN_KNOW.getCode(), ResponseEnum.UN_KNOW.getMsg(), data);
    }

    /**
     * 返回错误消息
     *
     * @return 成功消息
     */
    public static <T> Result<T> error(ResponseEnum response) {
        return error(response.getCode(), response.getMsg());
    }
}