package com.crc.common.utils;

import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.Reader;
import java.math.BigInteger;
import java.nio.charset.Charset;
import java.nio.charset.StandardCharsets;
import java.security.SecureRandom;
import java.text.DecimalFormat;
import java.text.NumberFormat;
import java.util.HashSet;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.Set;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import cn.hutool.core.io.IoUtil;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;

import com.crc.common.constant.enums.TransCodeEnum;
import com.crc.common.model.request.TransCodeRequest;
import com.crc.common.utils.ip.IpUtils;

import cn.hutool.core.collection.CollUtil;
import cn.hutool.core.text.UnicodeUtil;
import cn.hutool.core.util.HexUtil;
import cn.hutool.core.util.NumberUtil;
import cn.hutool.core.util.StrUtil;
import org.apache.http.HttpEntity;
import org.apache.http.util.CharArrayBuffer;

@Slf4j
public class DataUtils {
    /**
     * 比较 startIp2long<=ip2long && ip2long <=e
     *
     * @param startIp2long 开始 IP
     * @param ip2long      当前 IP
     * @param endIp2long   结束 IP
     * @return t/f
     */
    public static boolean isIpInSegment(BigInteger startIp2long, BigInteger ip2long, BigInteger endIp2long) {
        BigInteger a0 = new BigInteger("0");
        try {
            if (startIp2long == null || ip2long == null || endIp2long == null) {
                return false;
            }
            if (startIp2long.compareTo(a0) >= 0 && compareBigInt(ip2long, startIp2long) > -1 && compareBigInt(endIp2long, ip2long) > -1) {
                return true;
            }
        } catch (Exception e) {
            log.error(e.getMessage(), e);
        }
        return false;
    }

    public static boolean bigTo0(BigInteger m1) {
        if (m1 == null) {
            return false;
        }
        try {
            BigInteger a0 = BigInteger.valueOf(0);
            return m1.compareTo(a0) >= 0;
        } catch (Exception e) {
            return false;
        }

    }


    public static int compareBigInt(BigInteger m1, BigInteger m2) {
        if (m1 == null || m2 == null) {
            return -2;
        }
        try {
            BigInteger a0 = BigInteger.valueOf(0);
            if (m1.compareTo(a0) >= 0 && m2.compareTo(a0) >= 0) {
                return m1.compareTo(m2);//小于-1，等于0，大于 1
            } else {
                return -3;
            }
        } catch (Exception e) {
            return -4;
        }

    }

    /**
     * 根据树路径获取对应节点
     *
     * @param str
     * @param level
     * @return
     */
    public static String getDeptTree(String str, int level) {
        if (StringUtils.isBlank(str)) {
            return str;
        } else {
            String[] tree = str.split("/");
            if (level < 2) {
                return tree[0];
            }
            return getArrayString(tree, level - 1);
        }
    }

    public static String getArrayString(String[] arr, int index) {
        if (arr == null || index < 0 || (arr.length - 1) < index)
            return getArrayString(arr, index - 1);

        return arr[index];
    }

    public static char getCharAt(String string, int index) {
        if (index < 0) {
            return '\u0000';
        } else if (index > string.length()) {
            return '\u0000';
        }
        return string.charAt(index);
    }

    /**
     * 判断是否含有中文
     *
     * @param str
     * @return
     */
    public static boolean isContainChinese(String str) {
        if (str == null)
            return false;
        Pattern p = Pattern.compile("[\u4e00-\u9fa5]");
        Matcher m = p.matcher(str);
        return m.find();
    }

    public static boolean isContainChinese(Object str) {
        if (str == null) {
            return false;
        }
        return isContainChinese(str.toString());
    }

    public static String numberWithDelimiter(long num) {
        StringBuilder accum = new StringBuilder();
        int len = accum.append(num).length();
        if (len <= 3)
            return accum.toString(); // 如果长度小于等于3不做处理
        while ((len -= 3) > 0) { // 从个位开始倒序插入
            accum.insert(len, ",");
        }
        return accum.toString();
    }

    public static String getString(Map map, String filter) {
        if (StringUtils.isNotBlank(filter) && map != null) {
            Object o = map.get(filter);
            if (o != null) {
                return o.toString().trim();
            }
        }
        return "";
    }

    public static long toLong(Integer strInt) {
        return toLong(String.valueOf(strInt));
    }

    public static long toLong(String strInt) {
        if (com.crc.common.utils.StringUtils.isBlank(strInt)) {
            return 0;
        }
        strInt = strInt.trim();
        try {
            return Long.parseLong(strInt);
        } catch (Exception ignored) {

        }
        return 0;
    }

    /***
     * 判断 String 是否是 int
     *
     * @param str
     * @return
     */
    public static boolean isInteger(String str) {
        if (StringUtils.isBlank(str)) {
            //log.debug("空内容为非数字");
            return false;
        }
        Pattern pattern = Pattern.compile("^[-\\+]?[\\d]*$");
        //log.debug("内容：{},为非数字", str);
        return pattern.matcher(str).matches();
    }

    public static int toInt(Long strInt) {
        return toInt(String.valueOf(strInt));
    }

    public static int toInt(String strInt) {
        if (com.crc.common.utils.StringUtils.isBlank(strInt)) {
            return 0;
        }
        if (!isInteger(strInt)) {
            return 0;
        }
        strInt = strInt.trim();
        try {
            return Integer.parseInt(strInt);
        } catch (Exception ignored) {

        }
        return 0;
    }

    public static String toStr(Long strInt) {
        try {
            if (strInt == null) {
                return null;
            }
            return String.valueOf(strInt);
        } catch (Exception ignored) {

        }
        return null;
    }

    public static double toDouble(String strInt) {
        if (com.crc.common.utils.StringUtils.isBlank(strInt)) {
            return 0;
        }
        strInt = strInt.trim();
        try {
            return Double.parseDouble(strInt);
        } catch (Exception ignored) {

        }
        return 0;
    }

    /**
     * 精确1位数
     *
     * @return
     */
    public static String getPrec(double d) {
        NumberFormat numberFormat = NumberFormat.getInstance();
        // 设置精确到整数位
        numberFormat.setMaximumFractionDigits(-1);
        return numberFormat.format(d);
    }

    /**
     * 通过除数和被除数返回百分比 例如 a = 2 b = 3 返回：66.67%
     * @param a 除数
     * @param b 被除数
     * @return 百分比，保留两位小数
     */
    public static String getPrec(long a, long b) {
        if (b == 0) {
            return "100%";
        }
        double div = NumberUtil.div(a, b);
        NumberFormat percentInstance = NumberFormat.getPercentInstance();
        percentInstance.setMinimumFractionDigits(2);
        return percentInstance.format(div);
    }

    public static int getPercent(int maxAssetUsing, String dictValue) {
        String result = getPrec((float) toInt(dictValue) / (float) maxAssetUsing * 100);
        return toInt(result);
    }

    public static String getPercent(int maxAssetUsing, int dictValue) {
        // 创建一个数值格式化对象
        double total = (float) dictValue / (float) maxAssetUsing * 100;
        return NumberUtil.decimalFormat("#.##", total);
    }

    /**
     * 不够位数的在前面补0，保留num的长度位数字
     *
     * @param code
     * @return
     */
    public static String autoGenericCode(String code, int num) {
        String result = "";
        // 保留num的位数
        // 0 代表前面补充0
        // num 代表长度为4
        // d 代表参数为正数型
        result = String.format("%0" + num + "d", Integer.parseInt(code) + 1);

        return result;
    }

    /**
     * 获取自增编号
     *
     * @param code   前一个编号 例如：A-02021
     * @param subNum 需要截取的位数 2
     * @return 新的编号 A-02022
     */
    public synchronized static String getGenerCode(String code, int subNum) {
        String initValue = "000000";
        if (StringUtils.isNotBlank(code)) {
            String subStr = code.substring(subNum);
            DecimalFormat format = new DecimalFormat(initValue);
            return code.substring(0, subNum) + format.format(Integer.parseInt(subStr) + 1);
        }
        return "";
    }

    public static int getRandomNumberInRange(int min, int max) {
        if (min >= max) {
            return max;
        }
        SecureRandom r = new SecureRandom();
        return r.nextInt((max - min) + 1) + min;
    }

    public static int getRandomNumber(int range) {
        SecureRandom r = new SecureRandom();
        return r.nextInt(range);
    }

    public static boolean isFullBlank(String kql) {
        if (com.crc.common.utils.StringUtils.isBlank(kql)) {
            return true;
        }
        String s = kql.replaceAll("\\s*", "");
        return com.crc.common.utils.StringUtils.isBlank(s);
    }

    public static String getSubString(String string, int first, int end) {
        if (end <= first) {
            return "";
        }
        if (StringUtils.isBlank(string)) {
            return "";
        }
        if (string.length() < end) {
            end = string.length();
        }
        if (first < 0) {
            return "";
        }
        return string.substring(first, end);
    }

    public static String getSubString(String string, int first) {
        if (StringUtils.isBlank(string)) {
            return "";
        }
        if (string.length() < first) {
            return "";
        }
        if (first < 0) {
            return "";
        }
        return string.substring(first);
    }

    public static String[] getSplit(String str, String symbol) {
        String[] split = {};
        if (StringUtils.isNotBlank(str) && symbol != null) {
            split = str.split(symbol);
        }
        return split;
    }

    public static Long toLongX(String count) {
        if (com.crc.common.utils.StringUtils.isBlank(count)) {
            return -1L;
        }
        count = count.trim();
        try {
            count = getPureNumber(count);
            return Long.parseLong(count);
        } catch (Exception ignored) {
        }
        return -1L;
    }

    public static String getPureNumber(String str) {
        if (str == null) {
            return "";
        }
        StringBuilder sb = new StringBuilder();
        for (int i = 0; i < str.length(); i++) {
            if (str.charAt(i) >= '0' && str.charAt(i) <= '9') {
                sb.append(str.charAt(i));
            }
        }
        return sb.toString();
    }

    public static int getLastIndex(String str, String c) {
        int index = -1;
        if (StringUtils.isNotBlank(str) && c != null) {
            index = str.lastIndexOf(c);
        }
        return index;
    }

    public static int getIndex(String str, String c) {
        int index = -1;
        if (StringUtils.isNotBlank(str) && c != null) {
            index = str.indexOf(c);
        }
        return index;
    }

    public static Set<String> getStrSet(Set<String> strSet) {
        if (CollUtil.isEmpty(strSet)) {
            return new LinkedHashSet<>();
        }
        HashSet<String> data = new LinkedHashSet<>();
        strSet.forEach(t -> {
            List<String> list = IpUtils.getIps(t);
            data.addAll(list);
        });
        return data;
    }

    public static boolean isNum(Object obj) {
        if (obj == null) {
            return false;
        }
        String regExp = "\\d+";
        Pattern pattern = Pattern.compile(regExp);
        Matcher matcher = pattern.matcher(String.valueOf(obj));
        return matcher.matches();
    }

    public static int getInt(String str) {
        if (StringUtils.isBlank(str)) {
            return 0;
        }
        try {
            return Integer.parseInt(str);
        } catch (Exception ignored) {

        }
        return 0;
    }

    public static String getReplaceAll(String str1, String str2, String str3) {
        if (com.crc.common.utils.StringUtils.isBlank(str1) || com.crc.common.utils.StringUtils.isBlank(str2)) {
            return str1;
        }
        str3 = str3.replaceAll("\\$", "RDS_CHAR_DOLLAR");
        String s = "";
        if (StringUtils.isEmpty(str3) || "null".equals(str3)) {
            s = str1.replaceAll(str2, "");
        } else {
            if (str3.contains("\\")) {
                str3 = str3.replaceAll("\\\\", "\\\\\\\\");
            }
            s = str1.replaceAll(str2, str3);
        }
        s = s.replaceAll("RDS_CHAR_DOLLAR", "\\$");
        return s;
    }

    public static String getStr(Map<String, String> map, String filter) {
        if (com.crc.common.utils.StringUtils.isNotBlank(filter)) {
            return map.get(filter);
        }
        return "";
    }

    public static final char UNDERLINE = '_';

    public static String humpToLine(String param) {
        if (param == null || "".equals(param.trim())) {
            return "";
        }
        int len = param.length();
        StringBuilder sb = new StringBuilder(len);
        for (int i = 0; i < len; i++) {
            char c = param.charAt(i);
            if (Character.isUpperCase(c)) {
                sb.append(UNDERLINE);
                sb.append(Character.toLowerCase(c));
            } else {
                sb.append(c);
            }
        }
        return sb.toString();
    }

    /**
     * 转码
     *
     * @param transCodeRequest
     * @return
     */
    public static String transcode(TransCodeRequest transCodeRequest) {
        if (Objects.isNull(transCodeRequest) || StrUtil.isEmpty(transCodeRequest.getType())
                || StrUtil.isEmpty(transCodeRequest.getStr())) {
            return StrUtil.EMPTY;
        }
        return transcode(transCodeRequest.getStr(), transCodeRequest.getType());
    }

    private static String transcode(String str, String type) {
        String data = null;
        try {
            if (TransCodeEnum.UNICODE.getType().equalsIgnoreCase(type)) {
                data = UnicodeUtil.toString(str);
            } else if (TransCodeEnum.HEX.getType().equalsIgnoreCase(type)) {
                data = HexUtil.decodeHexStr(str);
            } else {
                data = StrUtil.EMPTY;
            }
        } catch (Exception e) {
            data = StrUtil.EMPTY;
        }
        return data;
    }

    public static void main(String[] args) {
        String a = "http://www.baidu.com";
        int index = DataUtils.getIndex(a, "http");
        System.out.println(DataUtils.getSubString(a, index + 7));
    }

    public static String toBodyString(HttpEntity entity, Charset charset) {
        if (entity == null) {
            return "";
        }
        Reader reader = null;
        try (InputStream inStream = entity.getContent()) {
            if (inStream == null) {
                return null;
            }
            reader = new InputStreamReader(inStream, charset);
            CharArrayBuffer buffer = new CharArrayBuffer(100);
            char[] tmp = new char[1024];
            int l;
            while ((l = reader.read(tmp)) != -1) {
                buffer.append(tmp, 0, l);
            }
            return buffer.toString();
        } catch (Exception e) {
            log.error(e.getMessage(), e);
        } finally {
            IoUtil.close(reader);
        }
        //获取一个含有实体信息的流
        return "";

    }

    public static String toBodyString(HttpEntity entity) {
        return toBodyString(entity, StandardCharsets.UTF_8);
    }
}
