package com.crc.common.model.request;

import com.alibaba.fastjson.JSONArray;
import com.alibaba.fastjson.JSONObject;
import com.crc.common.easyexcel.utils.EasyExcelUtils;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import java.io.InputStream;
import java.util.List;
import java.util.Map;

/**
 * 导出导入公共类
 * 
 * @author zhangbing
 */
@ApiModel(value = "导出导入公共类")
@Data
public class EasyExcelReq {

    /**
     * 模板路径
     */
    @ApiModelProperty(value = "模板路径")
    private String tempPath;

    /**
     * 导出导出文件名称
     */
    @ApiModelProperty(value = "导出导出文件名称")
    private String fileName;

    /**
     * 导出导出表名
     */
    @ApiModelProperty(value = "导出导出表名")
    private String sheetName = EasyExcelUtils.SHEET1;

    /**
     * 是否打印表头,默认false不打印表头（false 不打印 true 打印）
     */
    @ApiModelProperty(value = "是否打印表头")
    private Boolean needHead = Boolean.FALSE;

    /**
     * 填充模板内容(主要用于下拉框选择) key为需要下拉框的 列数-1 value为下拉值
     */
    @ApiModelProperty(value = "填充模板内容")
    private Map<Integer, String[]> mackMap;

    /**
     * 填充模板内容(主要用于下拉框选择) k 为存在下拉数据集的实体类映射属性名称 v为下拉数据集
     */
    @ApiModelProperty(value = "填充模板内容")
    private Map<String, String[]> headNameMackMap;

    /**
     * 导出数据字典
     */
    @ApiModelProperty(value = "导出数据字典")
    private List<JSONObject> dictList;

    /**
     * 自定义导出字段(为空时导出全部字段) 内容是导出字段的中文名称
     */
    @ApiModelProperty(value = "自定义导出字段")
    private JSONArray exportAttributeJson;

    /**
     * 输出自定义列(为空时，全部字段) 内容是导入、导出字段的名称，(下载导入错误信息特殊处理)
     */
    private List<String> includeColumnFieldNames;

    /**
     * 忽略自定义列 内容是导入、导出字段的名称
     */
    private List<String> excludeColumnFieldNames;

    public EasyExcelReq() {}

    public EasyExcelReq(String fileName, String sheetName) {
        this.fileName = fileName;
        this.sheetName = sheetName;
    }

    /**
     * 获取模板文件流
     *
     * @return InputStream
     */
    public InputStream getTempInputStream() {
        return this.getClass().getResourceAsStream(this.tempPath);
    }
}
