package com.crc.common.utils;

import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

/**
 * @ClassName ClassUtil
 * @Description: class工具类
 * @Author bgg
 **/
public class ClassUtil {

    /**
     * @param obj
     * @MethodName: isJavaType
     * @Description: 判断是否是基本类型
     * @Return: boolean
     **/
    public static boolean isJavaType(Object obj) {
        //判断是否是基本类型
        if (obj.getClass().isPrimitive()) {
            return true;
        }

        return obj instanceof String || obj instanceof Integer || obj instanceof Long ||
                obj instanceof Double || obj instanceof Float || obj instanceof Boolean ||
                obj instanceof Byte || obj instanceof Character;
    }

    /**
     * @MethodName: isSuperClass
     * @Description:  判断class的父类是否包含packageName
     * @param clazz
     * @param packageName 包名称
     * @Return: boolean
    **/
    public static boolean isSuperClass(Class clazz, String packageName){
        Class superclass = clazz.getSuperclass();
        if (superclass == null || superclass.isAssignableFrom(Object.class)){
            return false;
        }

        if (superclass.getName().equals(packageName)){
            return true;
        } else
            return isSuperClass(superclass, packageName);
    }

    /**
     * @MethodName: getSuperClass
     * @Description:  获取指定父类Class对象
     * @param clazz
     * @param packageName 包名称
     * @Return: java.lang.Class
    **/
    public static Class getSuperClass(Class clazz, String packageName){
        Class superclass = clazz.getSuperclass();
        if (superclass == null){
            return clazz;
        }

        if (superclass.getName().equals(packageName)){
            return superclass;
        } else
            return getSuperClass(superclass, packageName);
    }

    /**
     * @MethodName: getAllFields
     * @Description:  获取class所有字段
     * @param clazz
     * @Return: java.util.List<java.lang.reflect.Field>
    **/
    public static List<Field> getAllFields(Class clazz){
        List<Field> fields = new ArrayList<>(Arrays.asList(clazz.getDeclaredFields()));
        recursiveGetFields(fields, clazz);
        return fields;
    }

    private static void recursiveGetFields(List<Field> fields, Class clazz){
        Class superclass = clazz.getSuperclass();
        if (superclass == null || superclass.isAssignableFrom(Object.class)){
            return;
        }
        fields.addAll(Arrays.asList(superclass.getDeclaredFields()));
        recursiveGetFields(fields, superclass);
    }

    /**
     * 根据属性，拿到set方法，并把值set到对象中
     * @param obj 对象
     * @param clazz 对象的class
     * @param typeClass
     * @param value
     */
    public static void setValue(Object obj,Class<?> clazz,String filedName,Class<?> typeClass,Object value){
        filedName = removeLine(filedName);
        String methodName = "set" + filedName.substring(0,1).toUpperCase() + filedName.substring(1);
        try{
            Method method =  clazz.getDeclaredMethod(methodName, new Class[]{typeClass});
            method.invoke(obj, new Object[]{getClassTypeValue(typeClass, value)});
        }catch(Exception ex){
            ex.printStackTrace();
        }
    }

    /**
     * 通过class类型获取获取对应类型的值
     * @param typeClass class类型
     * @param value 值
     * @return Object
     */
    private static Object getClassTypeValue(Class<?> typeClass, Object value){
        if(typeClass == int.class  || value instanceof Integer){
            if(null == value){
                return 0;
            }
            return value;
        }else if(typeClass == short.class){
            if(null == value){
                return 0;
            }
            return value;
        }else if(typeClass == byte.class){
            if(null == value){
                return 0;
            }
            return value;
        }else if(typeClass == double.class){
            if(null == value){
                return 0;
            }
            return value;
        }else if(typeClass == long.class){
            if(null == value){
                return 0;
            }
            return value;
        }else if(typeClass == String.class){
            if(null == value){
                return "";
            }
            return value;
        }else if(typeClass == boolean.class){
            if(null == value){
                return true;
            }
            return value;
        }else if(typeClass == BigDecimal.class){
            if(null == value){
                return new BigDecimal(0);
            }
            return new BigDecimal(value+"");
        }else {
            return typeClass.cast(value);
        }
    }

    /**
     * 处理字符串  如：  abc_dex ---> abcDex
     * @param str
     * @return
     */
    public static  String removeLine(String str){
        if(null != str && str.contains("_")){
            int i = str.indexOf("_");
            char ch = str.charAt(i+1);
            char newCh = (ch+"").substring(0, 1).toUpperCase().toCharArray()[0];
            String newStr = str.replace(str.charAt(i+1), newCh);
            String newStr2 = newStr.replace("_", "");
            return newStr2;
        }
        return str;
    }


}
