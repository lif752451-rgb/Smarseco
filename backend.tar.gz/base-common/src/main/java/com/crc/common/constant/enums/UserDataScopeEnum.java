package com.crc.common.constant.enums;

/**
 * @author SONGYIPO
 */

public enum UserDataScopeEnum {

    NO_DATA_PERMISSION("无数据权限", "0"),
    ALL_DATA_PERMISSION("全部数据权限", "1"),
    USER_DATA_PERMISSION("仅本人", "2"),
    DEPT_DATA_SCOPE("部门数据权限", "3"),
    DEPT_AND_USER_DATA_SCOPE("部门数据和用户数据权限", "4"),
    ;

    UserDataScopeEnum(String desc, String value) {
        this.desc = desc;
        this.value = value;
    }

    private String desc;

    private String value;

    public String getDesc() {
        return desc;
    }

    public void setDesc(String desc) {
        this.desc = desc;
    }

    public String getValue() {
        return value;
    }

    public void setValue(String value) {
        this.value = value;
    }
}
