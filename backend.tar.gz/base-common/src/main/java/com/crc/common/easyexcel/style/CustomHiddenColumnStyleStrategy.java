package com.crc.common.easyexcel.style;

import com.alibaba.excel.metadata.Head;
import com.alibaba.excel.metadata.data.WriteCellData;
import com.alibaba.excel.write.metadata.holder.WriteSheetHolder;
import com.alibaba.excel.write.style.column.AbstractColumnWidthStyleStrategy;
import org.apache.poi.ss.usermodel.Cell;

import java.util.List;

/**
 * 设置隐藏列
 * @author SHUFENGFENG
 */
public class CustomHiddenColumnStyleStrategy extends AbstractColumnWidthStyleStrategy {

    /**
     * 设置需要隐藏的列号
     */
    Integer columnNum;

    /**
     *
     * @param columnNum 需要隐藏的列序号,从0开始
     */
    public CustomHiddenColumnStyleStrategy(Integer columnNum){
        this.columnNum = columnNum;
    }


    @Override
    public void setColumnWidth(WriteSheetHolder writeSheetHolder, List<WriteCellData<?>> cellDataList, Cell cell, Head head, Integer relativeRowIndex, Boolean isHead) {
        if(columnNum.equals(cell.getColumnIndex())){
            writeSheetHolder.getSheet().setColumnWidth(cell.getColumnIndex(), 0);
        }

    }



}