package com.crc.common.utils;

import com.alibaba.fastjson.JSONObject;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.util.Iterator;
import java.util.Map;
import java.util.TreeMap;

/**
 * Md5加密方法
 *
 * @author wst
 */
public class Md5Utils {
    private static final Logger log = LoggerFactory.getLogger(Md5Utils.class);

    private static char hexDigits[] = {'0', '1', '2', '3', '4', '5', '6', '7', '8', '9', 'A', 'B', 'C', 'D', 'E', 'F'};

    /**
     * 加签方式：MD5
     */
    private static String MD5 = "MD5";

    private static byte[] md5(String s) {
        MessageDigest algorithm;
        try {
            algorithm = MessageDigest.getInstance("MD5");
            algorithm.reset();
            algorithm.update(s.getBytes(StandardCharsets.UTF_8));
            return algorithm.digest();
        } catch (Exception e) {
            log.error("MD5 Error...{}", e.getMessage(), e);
        }
        return null;
    }

    private static String toHex(byte[] hash) {
        if (hash == null) {
            return null;
        }
        StringBuilder buf = new StringBuilder(hash.length * 2);
        int i;

        for (i = 0; i < hash.length; i++) {
            if ((hash[i] & 0xff) < 0x10) {
                buf.append("0");
            }
            buf.append(Long.toString(hash[i] & 0xff, 16));
        }
        return buf.toString();
    }

    public static String hash(String s) {
        try {
            return new String(toHex(md5(s)).getBytes(StandardCharsets.UTF_8), StandardCharsets.UTF_8);
        } catch (Exception e) {
            log.error("not supported charset...{}",e.getMessage(), e);
            return s;
        }
    }

    /**
     * 验签
     *
     * @param data 明文数据
     * @param key  签名key
     * @param sign 接收到的签名
     * @return
     * @throws Exception
     */
    public static boolean verifySign(String data, String key, String sign) throws Exception {
        //调用加签方法，看加签后的签名是否和接收到的一致
        String encryptData = sign(data, key);
        if (encryptData.equals(sign)) {
            return true;
        } else {
            return false;
        }
    }

    /**
     * 生成签名
     *
     * @param data 明文数据
     * @param key  签名key
     * @return
     * @throws Exception
     */
    public static String sign(String data, String key) throws Exception {
        //得到明文的字节数组
        byte[] btInput = (data + key).getBytes();
        // 创建一个提供信息摘要算法的对象(MD5摘要算法)
        MessageDigest messageDigest = MessageDigest.getInstance(MD5);
        // 使用指定的字节更新摘要
        messageDigest.update(btInput);
        // 得到二进制的密文
        byte[] encryptData = messageDigest.digest();
        // 把密文转换成十六进制的字符串形式
        String encryptDataStr = bytesToHex(encryptData);
        return encryptDataStr;

    }

    /**
     * 将Map中的数据转换成key1=value1&key2=value2的形式 不包含签名域 同时进行排序
     *
     * @param data 待拼接的Map数据
     * @return 拼接好后的字符串
     */
    public static String coverMap2String(final Map<String, Object> data, final String excludeKey) {
        final TreeMap<String, Object> tree = new TreeMap<String, Object>();
        Iterator<Map.Entry<String, Object>> it = data.entrySet().iterator();
        while (it.hasNext()) {
            final Map.Entry<String, Object> en = it.next();
            if (com.crc.common.utils.StringUtils.equals(excludeKey, en.getKey().trim())) {
                continue;
            }
            if (null == en.getValue()) {
                continue;
            }
            tree.put(en.getKey(), en.getValue());
        }
        it = tree.entrySet().iterator();
        final StringBuilder sf = new StringBuilder();
        while (it.hasNext()) {
            if (sf.length() > 0) {
                sf.append("&");
            }
            final Map.Entry<String, Object> en = it.next();
            sf.append(en.getKey()).append("=").append(en.getValue());
        }
        return sf.toString();
    }

    /**
     * 将Object对象里面的属性和值转化成Map对象
     *
     * @param obj
     * @return
     */
    public static Map<String, Object> objectToMap(Object obj) {
        String jsonStr = JSONObject.toJSONString(obj);
        return JSONObject.parseObject(jsonStr);
    }

    /**
     * 将byte数组转化为16进制字符串
     *
     * @param bytes
     * @return
     */
    public static String bytesToHex(byte[] bytes) {
        int k = 0;
        char[] hexChars = new char[bytes.length * 2];
        for (byte byte0 : bytes) {
            hexChars[k++] = hexDigits[byte0 >>> 4 & 0xf];
            hexChars[k++] = hexDigits[byte0 & 0xf];
        }
        return new String(hexChars);
    }
}
