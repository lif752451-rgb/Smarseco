package com.crc.common.model.enums;

import lombok.Getter;

/**
 * 消息发送类型枚举
 *
 * @Author fuzhuangzhi
 * @Date 2023/2/10 12:36
 * @Version 1.0
 **/
@Getter
public enum MsgSendCategoryEnum {
    FEI_SHU("feishu", "飞书"),
    QYWX("qywx", "企业微信"),
    YOUDU("youdu", "有度")
    ;

    private String type;
    private String desc;

    MsgSendCategoryEnum(String type, String desc) {
        this.type = type;
        this.desc = desc;
    }
}
