package com.crc.common.constant;

/**
 * 审批常量类
 * 
 * @author zhangbing
 */
public interface ApprovalConstants {

    /**
     * 通过
     */
    String PASS = "pass";

    /**
     * 不通过
     */
    String FAIL = "fail";

    /**
     * 驳回
     */
    String REJECT = "reject";

    /**
     * 转办
     */
    String TRANSFER = "transfer";

    /**
     * 终止
     */
    String STOP = "stop";

    /**
     * 暂存
     */
    String STAGING = "staging";

    /**
     * 推送
     */
    String PUSH = "push";
}
