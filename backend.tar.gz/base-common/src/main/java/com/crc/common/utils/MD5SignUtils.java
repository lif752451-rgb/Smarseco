package com.crc.common.utils;

import com.alibaba.fastjson.JSONObject;

import java.security.MessageDigest;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.TreeMap;

/**
 * @ClassName MD5Utils
 * @Description md5加密
 * @Author shufengfeng
 * @Date 2019/8/30 8:29 PM
 */
public class MD5SignUtils {
    private static char hexDigits[] = {'0', '1', '2', '3', '4', '5', '6', '7', '8', '9', 'A', 'B', 'C', 'D', 'E', 'F'};
    /**
     * 加签方式：MD5
     */
    private static String MD5 = "MD5";

    /**
     * 生成签名
     * @param data 明文数据
     * @param key 签名key
     * @return
     * @throws Exception
     */
    public static String sign(String data, String key) throws Exception {
        //得到明文的字节数组
        byte[] btInput = (data + key).getBytes();
        // 创建一个提供信息摘要算法的对象(MD5摘要算法)
        MessageDigest messageDigest = MessageDigest.getInstance(MD5);
        // 使用指定的字节更新摘要
        messageDigest.update(btInput);
        // 得到二进制的密文
        byte[] encryptData = messageDigest.digest();
        // 把密文转换成十六进制的字符串形式
        return bytesToHex(encryptData);
    }

    /**
     * 验签
     * @param data 明文数据
     * @param key 签名key
     * @param sign 接收到的签名
     * @return
     * @throws Exception
     */
    public static boolean verifySign(String data, String key, String sign) throws Exception {
        //调用加签方法，看加签后的签名是否和接收到的一致
        String encryptData = sign(data, key);
        if (encryptData.equals(sign)) {
            return true;
        } else {
            return false;
        }
    }

    /**
     * 将byte数组转化为16进制字符串
     * @param bytes
     * @return
     */
    public static String bytesToHex(byte[] bytes) {
        int k = 0;
        char[] hexChars = new char[bytes.length * 2];
        for (int i = 0; i < bytes.length; i++) {
            byte byte0 = bytes[i];
            hexChars[k++] = hexDigits[byte0 >>> 4 & 0xf];
            hexChars[k++] = hexDigits[byte0 & 0xf];
        }
        return new String(hexChars);
    }


    /**
     * 将Map中的数据转换成key1=value1&key2=value2的形式 不包含签名域 同时进行排序
     *
     * @param data
     *           待拼接的Map数据
     * @return 拼接好后的字符串
     */
    public static String coverMap2String(final Map<String, Object> data, final String excludeKey)
    {
        final TreeMap<String, Object> tree = new TreeMap<String, Object>();
        Iterator<Map.Entry<String, Object>> it = data.entrySet().iterator();
        while (it.hasNext())
        {
            final Map.Entry<String, Object> en = it.next();
            if (StringUtils.equals(excludeKey, en.getKey().trim()))
            {
                continue;
            }
            if (null == en.getValue())
            {
                continue;
            }
            tree.put(en.getKey(), en.getValue());
        }
        it = tree.entrySet().iterator();
        final StringBuffer sf = new StringBuffer();
        while (it.hasNext())
        {
            if (sf.length() > 0)
            {
                sf.append("&");
            }
            final Map.Entry<String, Object> en = it.next();
            sf.append(en.getKey() + "=" + en.getValue());
        }
        return sf.toString();
    }

    /**
     * 将Object对象里面的属性和值转化成Map对象
     *
     * @param obj
     * @return
     */
    public static Map<String, Object> objectToMap(Object obj) {
        String jsonStr = JSONObject.toJSONString(obj);
        return JSONObject.parseObject(jsonStr);
    }

    public static void main(String[] args) throws Exception {
        Map<String, String> hashMap = new HashMap<>();
        String data = "你好！MD5!";
        String key = "1234567890abcdef";
        String dataSign = MD5SignUtils.sign(data, key);
        hashMap.put("data", data);
        hashMap.put("dataSign", dataSign);
        System.out.println("明文:" + hashMap.get("data"));
        System.out.println("签名：" + hashMap.get("dataSign"));
        System.out.println("验签结果：" + MD5SignUtils.verifySign(data, key, dataSign));
    }



}
