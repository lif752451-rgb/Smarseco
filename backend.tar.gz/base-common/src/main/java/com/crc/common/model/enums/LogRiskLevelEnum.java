package com.crc.common.model.enums;

/**
 * @Author SHUFENGFENG
 * @Description 告警关联日志信息风险级别
 * @DateTime 2022/3/21 15:41
 */
public enum LogRiskLevelEnum {

    /**
     * 高风险
     */
    HIGH_RISK("HIGH_RISK", "高风险"),
    /**
     * 中风险
     */
    MEDIUM_RISK("MEDIUM_RISK", "中风险"),
    /**
     * 低风险
     */
    LOW_RISK("LOW_RISK", "低风险"),

    /**
     * 信息
     */
    INFORMATION("INFORMATION", "信息"),


    ;

    private String value;

    private String desc;

    LogRiskLevelEnum(String value, String desc) {
        this.value = value;
        this.desc = desc;
    }

    public String getValue() {
        return value;
    }

    public void setValue(String value) {
        this.value = value;
    }

    public String getDesc() {
        return desc;
    }

    public void setDesc(String desc) {
        this.desc = desc;
    }
}
