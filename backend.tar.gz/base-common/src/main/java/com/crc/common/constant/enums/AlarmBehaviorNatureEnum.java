package com.crc.common.constant.enums;

import com.crc.common.constant.Constants;

/**
 * 告警-行为性质属性枚举
 * @author SHUFENGFENG
 */
public enum AlarmBehaviorNatureEnum {
    NORMAL("正常","0"),
    ABNORMAL("异常","1"),
    ;

    AlarmBehaviorNatureEnum(String label, String code){
        this.label = label;
        this.code = code;
    }

    private String label;
    private String code;

    public static String getEnum(String code) {
        for (AlarmBehaviorNatureEnum behaviorNatureEnum : AlarmBehaviorNatureEnum.values()) {
            if(behaviorNatureEnum.getCode().equals(code)){
                return behaviorNatureEnum.getLabel();
            }
        }
        return Constants.BLANK_STR;
    }

    public static String getEnum(Integer code) {
        for (AlarmBehaviorNatureEnum behaviorNatureEnum : AlarmBehaviorNatureEnum.values()) {
            if(null != code && behaviorNatureEnum.getCode().equals(code.toString())){
                return behaviorNatureEnum.getLabel();
            }
        }
        return Constants.BLANK_STR;
    }


    public String getLabel() {
        return label;
    }

    public void setLabel(String label) {
        this.label = label;
    }

    public String getCode() {
        return code;
    }

    public void setCode(String code) {
        this.code = code;
    }
}
