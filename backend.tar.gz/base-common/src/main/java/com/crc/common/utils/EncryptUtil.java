package com.crc.common.utils;

import org.apache.commons.codec.binary.Base64;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import sun.misc.BASE64Decoder;

import javax.crypto.Cipher;
import javax.crypto.KeyGenerator;
import javax.crypto.spec.SecretKeySpec;
import java.nio.charset.StandardCharsets;
import java.util.Objects;

/**
 * 字符串加密工具类
 *
 * @author BAIGANGGANG
 */
public class EncryptUtil {

    private static final String KEY = "e8f5b39451625bdead70d5ccc9250404";

    private static final String ALGORITHMSTR = "AES/ECB/PKCS5Padding";

    protected static Logger logger = LoggerFactory.getLogger(EncryptUtil.class);

    private static String base64Encode(byte[] bytes) {
        return Base64.encodeBase64String(bytes);
    }

    private static byte[] base64Decode(String base64Code) throws Exception {
        return new BASE64Decoder().decodeBuffer(base64Code);
    }

    private static byte[] aesEncryptToBytes(String content, String encryptKey) throws Exception {
        KeyGenerator kgen = KeyGenerator.getInstance("AES");
        kgen.init(128);
        Cipher cipher = Cipher.getInstance(ALGORITHMSTR);
        cipher.init(Cipher.ENCRYPT_MODE, new SecretKeySpec(encryptKey.getBytes(), "AES"));

        return cipher.doFinal(content.getBytes(StandardCharsets.UTF_8));
    }

    public static String aesEncrypt(String content, String encryptKey) {
        try {
            if (StringUtils.isBlank(content)) {
                logger.info("试图加密空字符串！");
                return content;
            }
            return base64Encode(aesEncryptToBytes(content, encryptKey));
        } catch (Exception e) {
            logger.error("aesEncrypt出错, content:{}", content, e);
        }
        return content;
    }

    private static String aesDecryptByBytes(byte[] encryptBytes, String decryptKey) throws Exception {
        KeyGenerator kgen = KeyGenerator.getInstance("AES");
        kgen.init(128);

        Cipher cipher = Cipher.getInstance(ALGORITHMSTR);
        cipher.init(Cipher.DECRYPT_MODE, new SecretKeySpec(decryptKey.getBytes(), "AES"));
        byte[] decryptBytes = cipher.doFinal(encryptBytes);

        return new String(decryptBytes);
    }

    public static String aesDecrypt(String encryptStr, String decryptKey) {
        try {
            if (StringUtils.isBlank(encryptStr)) {
                logger.info("试图解密空字符串！");
                return encryptStr;
            }
            // 进行base64解码
            byte[] decode = base64Decode(encryptStr);
            if (Objects.isNull(decode) || decode.length == 0) {
                logger.info("base64 解码为空！");
                return encryptStr;
            }
            return aesDecryptByBytes(decode, decryptKey);
        } catch (Exception e) {
            logger.error("aesDecrypt出错, encryptStr:{}", encryptStr, e);
        }
        return encryptStr;
    }

    /**
     * 加密
     *
     * @param content String
     * @return 加密字符串
     */
    public static String aesEncrypt(String content) {
        return aesEncrypt(content, KEY);
    }

    /**
     * 解密
     *
     * @param encryptStr 加密字符串
     * @return String
     */
    public static String aesDecrypt(String encryptStr) {
        return aesDecrypt(encryptStr, KEY);
    }

    /**
     * 测试
     */
    public static void main(String[] args) throws Exception {

        String content = "Super!@#$1234"; // 0gqIDaFNAAmwvv3tKsFOFf9P9m/6MWlmtB8SspgxqpWKYnELb/lXkyXm7P4sMf3e
        System.out.println("加密前：" + content);

        System.out.println("加密密钥和解密密钥：" + KEY);

        String encrypt = aesEncrypt(content, KEY);
        System.out.println(encrypt.length() + ":加密后：" + encrypt);

        String decrypt = aesDecrypt(encrypt, KEY);
        System.out.println("解密后：" + decrypt);
    }
}
