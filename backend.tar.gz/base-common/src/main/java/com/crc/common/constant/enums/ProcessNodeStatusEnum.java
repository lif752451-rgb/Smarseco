package com.crc.common.constant.enums;

import lombok.AllArgsConstructor;
import lombok.Getter;

/**
 * @author fuzhuangzhi
 * @title ProcessNodeStatusEnum
 * @date 2023/6/9 18:26
 * @description 流程节点状态枚举
 */
@Getter
@AllArgsConstructor
public enum ProcessNodeStatusEnum {

    /**
     * 已完成
     */
    COMPLETED("completed","已完成"),

    /**
     * 处理中
     */
    PROCESSING("processing","处理中"),

    /**
     * 等待中
     */
    WAITING("waiting","等待中"),
    ;
    /**
     * 节点状态value
     */
    private String nodeStatusValue;

    /**
     * 节点状态描述
     */
    private String nodeStatusName;
}
