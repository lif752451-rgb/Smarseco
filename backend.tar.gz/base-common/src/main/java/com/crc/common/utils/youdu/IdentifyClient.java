package com.crc.common.utils.youdu;

import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import lombok.extern.slf4j.Slf4j;
import org.apache.http.HttpEntity;
import org.apache.http.client.methods.CloseableHttpResponse;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.impl.client.CloseableHttpClient;
import org.apache.http.impl.client.HttpClients;

import java.io.IOException;

@Slf4j
public class IdentifyClient {
    private final String host;

    public IdentifyClient(String host) {
        this.host = host;
    }

    public String idetify(String ydToken) throws HttpRequestException, ParamParserException, ServiceException {
        log.info("原始token：" + ydToken);
        if (ydToken.endsWith(";")) {
            ydToken = ydToken.substring(0, ydToken.length() - 1);
        }
        log.info("处理后token：" + ydToken);
        String url = this.uriIdentify(ydToken);
        HttpGet httpGet = new HttpGet(url);
        CloseableHttpClient httpClient = HttpClients.createDefault();
        CloseableHttpResponse httpRsp = null;
        try {
            httpRsp = httpClient.execute(httpGet);
            HttpEntity entity = httpRsp.getEntity();
            entity.getContent();
            JsonObject getResult = Helper.readHttpResponse(httpRsp);
            JsonElement status = getResult.get("status");
            if (!status.isJsonObject()) {
                throw new ParamParserException("找不到返回结果状态字段", null);
            }
            JsonObject statusObj = status.getAsJsonObject();
            int code = statusObj.get("code").getAsInt();
            this.parseStatusCode(code, statusObj.get("message").getAsString());

            JsonElement jUserElement = getResult.get("userInfo");
            if (!jUserElement.isJsonObject()) {
                throw new ParamParserException("找不到返回结果用户字段", null);
            }
            JsonObject jUserObj = jUserElement.getAsJsonObject();
            String userName = jUserObj.get("account").getAsString();
            return userName;
        } catch (IOException e) {
            throw new HttpRequestException(0, e.getMessage(), e);
        } finally {
            Helper.close(httpRsp);
            Helper.close(httpClient);
        }
    }

    private void parseStatusCode(int code, String msg) throws ServiceException {
        if (code == 0) {
            return;
        }
        switch (code) {
            case 1:
                throw new ServiceException("查找不到token对应的用户", null);
            case 10:
                throw new ServiceException("身份校验失败：错误的token或者token已过期", null);
            default:
                throw new ServiceException("其他错误：" + msg, null);
        }
    }

    private String uriIdentify(String token) {
        return String.format("%s%s%s?token=%s", "http://", this.host, "/cgi/identify", token);
    }
}
