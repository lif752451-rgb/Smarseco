package com.crc.common.convert;


import com.alibaba.excel.converters.Converter;
import com.alibaba.excel.converters.ReadConverterContext;
import com.alibaba.excel.converters.WriteConverterContext;
import com.alibaba.excel.enums.CellDataTypeEnum;
import com.alibaba.excel.metadata.data.WriteCellData;
import com.crc.common.constant.Constants;
import org.apache.commons.lang3.StringUtils;

/**
 * <p>
 * easy excel 转换String默认值，如果值为空则返回 - 否则返回原值
 * </p>
 *
 * @author shufengfeng
 * @since 2022-08-31
 */
public class CustomStringDefaultConverter implements Converter<String> {

    @Override
    public Class<?> supportJavaTypeKey() {
        return String.class;
    }

    @Override
    public CellDataTypeEnum supportExcelTypeKey() {
        return CellDataTypeEnum.STRING;
    }

    /**
     * 这里读的时候会调用
     *
     * @param context
     * @return
     */
    @Override
    public String convertToJavaData(ReadConverterContext<?> context) {
        if(StringUtils.isEmpty(context.getReadCellData().getStringValue())){
            return Constants.Symbol.MINUS;
        }
        return context.getReadCellData().getStringValue();
    }

    /**
     * 这里是写的时候会调用 不用管
     *
     * @return
     */
    @Override
    public WriteCellData<?> convertToExcelData(WriteConverterContext<String> context) {
        return new WriteCellData<>(context.getValue());
    }
}
