package com.crc.common.model.enums;

import lombok.AllArgsConstructor;
import lombok.Getter;

/**
 * @author fuzhuangzhi
 * @title ProcessMenuTypeEnum
 * @date 2023/9/26 11:42
 * @description 流程中菜单类型枚举
 */
@Getter
@AllArgsConstructor
public enum ProcessMenuTypeEnum {

    /**
     * 全部工单
     */
    LOOP_ALL("loopAll", "全部工单"),

    /**
     * 我的待办工单
     */
    LOOP_TO_DO("loopToDo", "我的待办工单"),

    /**
     * 我的已办工单
     */
    LOOP_DONE("loopDone", "我的已办工单"),;

    /**
     * 菜单类型
     */
    private String menuType;

    /**
     * 描述
     */
    private String desc;
}
