package com.crc.common.model.enums;

import lombok.Data;

/**
 * @Author shufengfeng
 * @Description 删除标记
 * @DateTime 2021/8/30 16:49
 */
@Data
public class DelFlagEnum {

    public static DelFlagEnum AVAILABLE = new DelFlagEnum(0,"可用");
    public static DelFlagEnum DISABLE = new DelFlagEnum(1,"不可用");


    private Integer value;
    private String desc;

    public DelFlagEnum() {
    }

    public DelFlagEnum(Integer value, String desc) {
        this.value = value;
        this.desc = desc;
    }

    public Integer getValue() {
        return value;
    }

    public void setValue(Integer value) {
        this.value = value;
    }

    public String getDesc() {
        return desc;
    }

    public void setDesc(String desc) {
        this.desc = desc;
    }
}
