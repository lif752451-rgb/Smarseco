package com.crc.common.utils;

/**
 * 邮件工具类
 */
public class MailUtils {

    /**
     * 显示
     */
    public static final String DISPLAY_BLOCK = "block";

    /**
     * 隐藏
     */
    public static final String DISPLAY_NONE = "none";

    /**
     * 是否有数据显示 隐藏
     *
     * @param str 字符传
     * @return String
     */
    public static String getDisplayNvlString(String str) {
        return getDisplay(StringUtils.isEmpty(str));
    }

    /**
     * 根据条件 true 隐藏 false 显示
     *
     * @param idDisplay boolean
     * @return String
     */
    public static String getDisplay(boolean idDisplay) {
        return idDisplay ? DISPLAY_NONE : DISPLAY_BLOCK;
    }
}