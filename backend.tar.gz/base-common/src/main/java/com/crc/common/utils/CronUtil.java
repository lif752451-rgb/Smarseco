package com.crc.common.utils;

import java.text.SimpleDateFormat;
import java.util.Date;

/**
 * 描述：cron工具类
 *
 * @Author: fuzhuangzhi
 * @Date: 2021/12/13 16:52
 */
public class CronUtil {

    /**
     * 方法摘要：构建Cron表达式
     * 注意：按每周执行时，选择的周一 需要传2,周二-3，周三-4，周四-5，周五-6，周六-7，周日-1，按照该对应关系才可
     *
     * @param type   类型 0：每天一次；1：每周一次；2：每月一次
     * @param param1 下拉列表，根据type进行变换， type=0时，param1=0；type=1时，param1从1-7选；type=2时，param1从1-28选
     * @param param2 小时 0-23
     * @param param3 分钟 0-59
     * @return
     */
    public static String createLoopCronExpression(int type, int param1, int param2, int param3,int param4) {
        String cron = "";
        switch (type) {
            case 0:// 每天的param2时，param3分，param4秒执行
                cron = param4 + " " + param3 + " " + param2 + " * * ? ";
                break;
            case 1:// 每周的param1的param2时，param3分，param4秒执行
                cron = param4 + " " + param3 + " " + param2 + " ? * " + param1 ;
                break;
            case 2:// 每月的param1号的param2时，param3分，param4秒执行
                cron = param4 + " " + param3 + " " + param2 + " " + param1 + " * ? ";
                break;
        }
        return cron;
    }

    /**
     * 方法摘要：构建Cron描述
     *
     * @param type   类型 0：每天一次；1：每周一次；2：每月一次
     * @param param1 下拉列表，根据type进行变换， type=0时，param1=0；type=1时，param1从1-7选；type=2时，param1从1-28选
     * @param param2 小时 0-23
     * @param param3 分钟 0-59
     * @return
     */
    public static String createLoopCronDescription(int type, int param1, int param2, int param3) {
        String desc = "";
        switch (type) {
            case 0:// 每天的param2时，param3分执行
                desc = "每天" + param2 + "点" + param3;
                break;
            case 1:// 每周的param1的param2时，param3分执行
                desc = "每周" + param1;
                break;
            case 2:// 每月的param1号的param2时，param3分执行
                desc = "每月" + param1 + "号";
                break;
        }
        return desc;
    }

    /**
     * 通过输入指定日期时间生成cron表达式
     *
     * @param date
     * @return cron表达式
     */
    public static String getCron(Date date) {
        String dateFormat = "ss mm HH dd MM ? *";
        SimpleDateFormat sdf = new SimpleDateFormat(dateFormat);
        String formatTimeStr = null;
        if (date != null) {
            formatTimeStr = sdf.format(date);
        }

        return formatTimeStr;
    }

    // 参考例子
    public static void main(String[] args) {

        System.out.println(CronUtil.createLoopCronExpression(0, 0, 10, 50,20));
        System.out.println(CronUtil.createLoopCronDescription(0, 0, 10, 50));

        System.out.println(CronUtil.createLoopCronExpression(1, 2, 12, 40,20));
        System.out.println(CronUtil.createLoopCronDescription(1, 2, 12, 40));

        System.out.println(CronUtil.createLoopCronExpression(2, 28, 07, 30,20));
        System.out.println(CronUtil.createLoopCronDescription(2, 28, 07, 30));

    }
}
