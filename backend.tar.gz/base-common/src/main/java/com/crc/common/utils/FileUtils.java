package com.crc.common.utils;

import lombok.extern.slf4j.Slf4j;
import org.apache.commons.io.IOUtils;

import java.io.*;
import java.nio.file.Files;

@Slf4j
public class FileUtils {
    /**
     * 根据文件名创建文件目录所要的路径
     *
     * @param filePath
     */
    public static void createDirectory4FilePath(String filePath) {
        try {
            File file = new File(filePath);
            String strParentDirectory = file.getParent();
            if (!strParentDirectory.endsWith(File.separator)) {
                strParentDirectory = strParentDirectory + File.separator;
            }
            File descDir = new File(strParentDirectory);
            if (descDir.exists()) {
                return;
            }
            // 创建目录
            descDir.mkdirs();
        } catch (Exception e) {
            log.error(e.getMessage(), e);
        }
    }

    public static String readFileStr(String path) {
        InputStreamReader inputReader = null;
        BufferedReader bf = null;
        StringBuilder sb = new StringBuilder();
        try {
            File file = new File(path);
            if (!file.exists()) {
                return "";
            }
            inputReader = new InputStreamReader(Files.newInputStream(file.toPath()));
            bf = new BufferedReader(inputReader);
            // 按行读取字符串
            String str;
            while ((str = bf.readLine()) != null) {
                str = str.trim();
                sb.append(str).append("\n");
            }
        } catch (Exception e) {
            log.error(e.getMessage(), e);
        } finally {
            IOUtils.closeQuietly(bf);
            IOUtils.closeQuietly(inputReader);
        }
        return sb.toString();
    }

    public static boolean writeFile(String filePath, String str) {
        FileWriter fw = null;
        BufferedWriter bw = null;
        try {
            fw = new FileWriter(filePath);
            bw = new BufferedWriter(fw);
            //使用缓冲区中的方法将数据写入到缓冲区中。
            bw.write(str);
            //使用缓冲区中的方法，将数据刷新到目的地文件中去。
            bw.flush();
            return true;
        } catch (Exception e) {
            log.error(e.getMessage(), e);
        } finally {
            IOUtils.closeQuietly(bw);
            IOUtils.closeQuietly(fw);
        }
        return false;
    }
}
