package com.crc.common.utils;

import com.crc.common.exception.CustomException;
import com.github.pagehelper.PageHelper;
import com.github.pagehelper.PageInfo;

import java.util.LinkedList;
import java.util.List;

/**
 * @author fuzhuangzhi
 * @title PageUtils
 * @date 2023/6/26 15:55
 * @description 分页工具类
 */
public class PageUtils {

    public static <T> PageInfo<T> initPageInfoObj(int currentPage, int total, int pageSize, PageInfo<T> pageInfo, List<T> list) {
        pageInfo.setNextPage(currentPage < ((total + pageSize - 1) / pageSize) ? currentPage + 1 : currentPage);
        pageInfo.setTotal(total);
        pageInfo.setPageSize(pageSize);
        pageInfo.setPageNum(currentPage);
        pageInfo.setPages((total + pageSize - 1) / pageSize);
        pageInfo.setPrePage(currentPage > 1 ? currentPage - 1 : currentPage);
        pageInfo.setIsFirstPage(currentPage == 1 ? true : false);
        pageInfo.setIsLastPage(currentPage == (total + pageSize - 1) / pageSize ? true : false);
        pageInfo.setHasPreviousPage(currentPage == 1 ? false : true);
        pageInfo.setHasNextPage(currentPage == (total + pageSize - 1) / pageSize ? false : true);
        pageInfo.setNavigatePages((total + pageSize - 1) / pageSize);
        int start = 0;
        int end = 0;
        if(pageInfo.getPageNum() == 1){
            start = 0;
            pageInfo.setStartRow(0);
            pageInfo.setHasPreviousPage(false);
            pageInfo.setPrePage(0);
            pageInfo.setIsFirstPage(true);
        }else{
            start = pageInfo.getPageSize()*(pageInfo.getPageNum()-1);
            pageInfo.setStartRow(pageInfo.getPageSize()*(pageInfo.getPageNum()-1));
            pageInfo.setHasPreviousPage(true);
            pageInfo.setPrePage(pageInfo.getPageNum()-1);
            pageInfo.setIsFirstPage(false);
        }
        if((pageInfo.getStartRow()+pageInfo.getPageSize() > pageInfo.getTotal())){
            end = (int) pageInfo.getTotal();
            pageInfo.setEndRow((int) pageInfo.getTotal());
            pageInfo.setHasNextPage(false);
            pageInfo.setIsLastPage(true);
        }else {
            end  = start + pageInfo.getPageSize();
            pageInfo.setEndRow(pageInfo.getStartRow() + pageInfo.getPageSize());
            pageInfo.setHasNextPage(true);
            pageInfo.setNextPage(pageInfo.getPageNum() + 1);
            pageInfo.setIsLastPage(false);
            pageInfo.setEndRow((pageInfo.getPageNum())*pageSize);
        }
        return calcNavigatepageNums(pageInfo,start,end,list);
    }

    private static <T> PageInfo<T> calcNavigatepageNums(PageInfo<T> pageInfo,int start,int end,List<T> list) {
        //当总页数小于或等于导航页码数时
        if (pageInfo.getPages() <= pageInfo.getNavigatePages()) {
            pageInfo.setNavigatepageNums(new int[pageInfo.getPages()]);
            for (int i = 0; i < pageInfo.getPages(); i++) {
                pageInfo.getNavigatepageNums()[i] = i + 1;
            }
        } else { //当总页数大于导航页码数时
            pageInfo.setNavigatepageNums(new int[pageInfo.getNavigatePages()]);
            int startNum = pageInfo.getPageNum() - pageInfo.getNavigatePages() / 2;
            int endNum = pageInfo.getPageNum() + pageInfo.getNavigatePages() / 2;

            if (startNum < 1) {
                startNum = 1;
                //(最前navigatePages页
                for (int i = 0; i < pageInfo.getNavigatePages(); i++) {
                    pageInfo.getNavigatepageNums()[i] = startNum++;
                }
            } else if (endNum > pageInfo.getPages()) {
                endNum = pageInfo.getPages();
                //最后navigatePages页
                for (int i = pageInfo.getNavigatePages() - 1; i >= 0; i--) {
                    pageInfo.getNavigatepageNums()[i] = endNum--;
                }
            } else {
                //所有中间页
                for (int i = 0; i < pageInfo.getNavigatePages(); i++) {
                    pageInfo.getNavigatepageNums()[i] = startNum++;
                }
            }
        }
        if (start < end && end <= pageInfo.getTotal()){
            pageInfo.setList(list.subList(start,end));
        }
        if(pageInfo.getSize() == 0) {
            pageInfo.setStartRow(0);
            pageInfo.setEndRow(0);
        } else {
            pageInfo.setStartRow(pageInfo.getStartRow() + 1);
            pageInfo.setEndRow(pageInfo.getStartRow()-1+pageInfo.getPageSize());
        }
        return pageInfo;
    }

    /**
     * 手动分页
     *
     * @param dataList 所有数据
     * @param pageNum  当前页
     * @param pageSize 页容量
     * @param <T>
     * @return 分页后的集合
     */
    public static <T> PageInfo subList(List<T> dataList, Integer pageNum, Integer pageSize) {
        List<T> subList = null;
        if (dataList.size() >= pageNum * pageSize) {
            subList = dataList.subList((pageNum - 1) * pageSize,pageNum * pageSize);
        } else if (dataList.size() < pageNum * pageSize && dataList.size() >= (pageNum - 1) * pageSize) {
            subList = dataList.subList((pageNum - 1) * pageSize, dataList.size());
        } else {
            throw new CustomException("分页参数有误");
        }
        PageInfo<T> pageInfo = new PageInfo<>(subList);
        pageInfo.setTotal(dataList.size());
        return pageInfo;
    }
}
