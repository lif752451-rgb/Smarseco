package com.crc.common.utils.http;

import com.alibaba.fastjson.JSON;
import com.crc.common.model.HwVo;
import com.crc.common.utils.AESUtils;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.io.IOUtils;
import org.apache.commons.lang3.StringUtils;
import org.apache.http.HttpEntity;
import org.apache.http.client.config.RequestConfig;
import org.apache.http.client.methods.*;
import org.apache.http.entity.StringEntity;
import org.apache.http.impl.client.BasicResponseHandler;
import org.apache.http.impl.client.CloseableHttpClient;
import org.apache.http.message.BasicHeader;
import org.apache.http.protocol.HTTP;
import org.apache.http.util.EntityUtils;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.NodeList;
import org.xml.sax.InputSource;

import javax.net.ssl.*;
import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import java.io.*;
import java.net.*;
import java.nio.charset.StandardCharsets;
import java.security.cert.X509Certificate;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;

/**
 * 通用http发送方法
 *
 * @author wst
 */
@Slf4j
public class HttpUtils {

    private static final int CONN_TIME_OUT = 20000;
    private static final int READ_TIME_OUT = 20000;

    /**
     * 向指定 URL 发送GET方法的请求
     *
     * @param url   发送请求的 URL
     * @param param 请求参数，请求参数应该是 name1=value1&name2=value2 的形式。
     * @return 所代表远程资源的响应结果
     */
    public static String sendGet(String url, String param) {
        if (url != null && url.toLowerCase().startsWith("https")) {
            return sendSSLGet(url, param);
        }
        StringBuilder result = new StringBuilder();
        BufferedReader in = null;
        try {
            String urlNameString = url;
            if (StringUtils.isNotEmpty(param)) {
                urlNameString = url + "?" + param;
            }
            log.info("sendGet - {}", urlNameString);
            URL realUrl = new URL(urlNameString);
            URLConnection connection = realUrl.openConnection();
            connection.setRequestProperty("accept", "*/*");
            connection.setRequestProperty("connection", "Keep-Alive");
            connection.setRequestProperty("user-agent", "Mozilla/4.0 (compatible; MSIE 6.0; Windows NT 5.1;SV1)");
            connection.connect();
            in = new BufferedReader(new InputStreamReader(connection.getInputStream()));
            String line;
            while ((line = in.readLine()) != null) {
                result.append(line);
            }
            log.info("recv - {}", result);
        } catch (ConnectException e) {
            log.error("调用HttpUtils.sendGet ConnectException, url=" + url + ",param=" + param, e);
        } catch (SocketTimeoutException e) {
            log.error("调用HttpUtils.sendGet SocketTimeoutException, url=" + url + ",param=" + param, e);
        } catch (IOException e) {
            log.error("调用HttpUtils.sendGet IOException, url=" + url + ",param=" + param, e);
        } catch (Exception e) {
            log.error("调用HttpsUtil.sendGet Exception, url=" + url + ",param=" + param, e);
        } finally {
            IOUtils.closeQuietly(in);
        }
        return result.toString();
    }

    public static String sendGet(String url, String param, String token) {
        StringBuilder result = new StringBuilder();
        BufferedReader in = null;
        try {
            String urlNameString = url;
            if (StringUtils.isNotEmpty(param)) {
                urlNameString = url + "?" + param;
            }
            log.info("sendGet - {}", urlNameString);
            URL realUrl = new URL(urlNameString);
            URLConnection connection = realUrl.openConnection();
            connection.setRequestProperty("accept", "*/*");
            connection.setRequestProperty("connection", "Keep-Alive");
            connection.setRequestProperty("user-agent", "Mozilla/4.0 (compatible; MSIE 6.0; Windows NT 5.1;SV1)");
            connection.addRequestProperty("authToken", token);
            connection.connect();
            in = new BufferedReader(new InputStreamReader(connection.getInputStream()));
            String line;
            while ((line = in.readLine()) != null) {
                result.append(line);
            }
            log.info("recv - {}", result);
        } catch (ConnectException e) {
            log.error("调用HttpUtils.sendGet ConnectException, url=" + url + ",param=" + param, e);
        } catch (SocketTimeoutException e) {
            log.error("调用HttpUtils.sendGet SocketTimeoutException, url=" + url + ",param=" + param, e);
        } catch (IOException e) {
            log.error("调用HttpUtils.sendGet IOException, url=" + url + ",param=" + param, e);
        } catch (Exception e) {
            log.error("调用HttpsUtil.sendGet Exception, url=" + url + ",param=" + param, e);
        } finally {
            IOUtils.closeQuietly(in);
        }
        return result.toString();
    }

    /**
     * 向指定 URL 发送POST方法的请求
     *
     * @param urlPath 发送请求的 URL
     * @param param   请求参数，请求参数应该是 name1=value1&name2=value2 的形式。
     * @return 所代表远程资源的响应结果
     */
    public static String sendPost(String urlPath, String param) {
        if (urlPath != null && urlPath.startsWith("https")) {
            return sendSSLPost(urlPath, param, null);
        }
        PrintWriter out = null;
        BufferedReader in = null;
        StringBuilder result = new StringBuilder();
        try {
            log.info("sendPost - {}", urlPath);
            URL realUrl = new URL(urlPath);
            URLConnection conn = realUrl.openConnection();
            conn.setRequestProperty("accept", "*/*");
            conn.setRequestProperty("connection", "Keep-Alive");
            conn.setRequestProperty("user-agent", "Mozilla/4.0 (compatible; MSIE 6.0; Windows NT 5.1;SV1)");
            conn.setRequestProperty("Accept-Charset", "utf-8");
            conn.setRequestProperty("contentType", "utf-8");
            conn.setDoOutput(true);
            conn.setDoInput(true);
            out = new PrintWriter(conn.getOutputStream());
            if (StringUtils.isNotBlank(param))
                out.print(param);
            out.flush();
            in = new BufferedReader(new InputStreamReader(conn.getInputStream(), StandardCharsets.UTF_8));
            String line;
            while ((line = in.readLine()) != null) {
                result.append(line);
            }
            log.info("recv - {}", result);
        } catch (ConnectException e) {
            log.error("调用HttpUtils.sendPost ConnectException, url=" + urlPath + ",param=" + param, e);
        } catch (SocketTimeoutException e) {
            log.error("调用HttpUtils.sendPost SocketTimeoutException, url=" + urlPath + ",param=" + param, e);
        } catch (IOException e) {
            log.error("调用HttpUtils.sendPost IOException, url=" + urlPath + ",param=" + param, e);
        } catch (Exception e) {
            log.error("调用HttpsUtil.sendPost Exception, url=" + urlPath + ",param=" + param, e);
        } finally {
            IOUtils.closeQuietly(out);
            IOUtils.closeQuietly(in);
        }
        return result.toString();
    }

    public static String sendPost(String url, String params, String encoding, String token) {
        String body = "";

        // 创建httpclient对象
        CloseableHttpClient client = HttpClientUtils.getHttpClient();
        log.info(url + ",token:{}", token);
        // 创建post方式请求对象
        HttpPost httpPost = new HttpPost(url);
        // 设置连接超时时间2秒
        RequestConfig requestConfig = RequestConfig.custom().setSocketTimeout(5000)
                .setConnectTimeout(5000)
                .build();
        httpPost.setConfig(requestConfig);
        // 装填参数
        StringEntity s = new StringEntity(params, "utf-8");
        s.setContentEncoding(new BasicHeader(HTTP.CONTENT_TYPE, "application/json"));
        // 设置参数到请求对象中
        httpPost.setEntity(s);
        if (com.crc.common.utils.StringUtils.isNotEmpty(token)) {
            httpPost.setHeader("token", token);
        }
        httpPost.setHeader("Content-type", "application/json");
        httpPost.setHeader("User-Agent", "Mozilla/4.0 (compatible; MSIE 5.0; Windows NT; DigExt)");
        // 执行请求操作，并拿到结果（同步阻塞）
        CloseableHttpResponse response = null;
        try {
            response = client.execute(httpPost);
            // 获取结果实体
            HttpEntity entity = response.getEntity();
            if (entity != null) {
                // 按指定编码转换结果实体为String类型
                body = EntityUtils.toString(entity, encoding);
            }
            EntityUtils.consume(entity);
            log.info("block:{}", body);
            // 释放链接
            return body;
        } catch (Exception e) {
            log.error("调用post请求失败,原因为:{}", e.getMessage(), e);
        } finally {
            IOUtils.closeQuietly(response);
        }
        return null;
    }

    /**
     * 向指定 URL 发送POST方法的请求
     *
     * @param url   发送请求的 URL
     * @param param 请求参数，请求参数应该是 name1=value1&name2=value2 的形式。
     * @return 所代表远程资源的响应结果
     */
    public static String sendPost(String url, String param, HashMap<String, String> headerMap) {
        PrintWriter out = null;
        BufferedReader in = null;
        StringBuilder result = new StringBuilder();
        try {
            String urlNameString = url;
            if (StringUtils.isNotEmpty(param)) {
                urlNameString = url + "?" + param;
            }
            log.info("sendPost - {}", urlNameString);
            URL realUrl = new URL(urlNameString);
            URLConnection conn = realUrl.openConnection();
            conn.setRequestProperty("accept", "*/*");
            conn.setRequestProperty("connection", "Keep-Alive");
            conn.setRequestProperty("user-agent", "Mozilla/4.0 (compatible; MSIE 6.0; Windows NT 5.1;SV1)");
            conn.setRequestProperty("Accept-Charset", "utf-8");
            conn.setRequestProperty("contentType", "utf-8");
            for (String key : headerMap.keySet()) {
                conn.setRequestProperty(key, headerMap.get(key));
            }
            conn.setDoOutput(true);
            conn.setDoInput(true);
            out = new PrintWriter(conn.getOutputStream());
            out.print(param);
            out.flush();
            in = new BufferedReader(new InputStreamReader(conn.getInputStream(), "utf-8"));
            String line;
            while ((line = in.readLine()) != null) {
                result.append(line);
            }
            log.info("recv - {}", result);
        } catch (ConnectException e) {
            log.error("调用HttpUtils.sendPost ConnectException, url=" + url + ",param=" + param, e);
        } catch (SocketTimeoutException e) {
            log.error("调用HttpUtils.sendPost SocketTimeoutException, url=" + url + ",param=" + param, e);
        } catch (IOException e) {
            log.error("调用HttpUtils.sendPost IOException, url=" + url + ",param=" + param, e);
        } catch (Exception e) {
            log.error("调用HttpsUtil.sendPost Exception, url=" + url + ",param=" + param, e);
        } finally {
            IOUtils.closeQuietly(out);
            IOUtils.closeQuietly(in);
        }
        return result.toString();
    }

    public static String sendPost(String url, String params, String token) {
        String body = "";

        // 创建httpclient对象
        CloseableHttpClient client = HttpClientUtils.getHttpClient();
        // 创建post方式请求对象
        HttpPost httpPost = new HttpPost(url);
        // 设置连接超时时间2秒
        RequestConfig requestConfig = RequestConfig.custom().setSocketTimeout(500000)
                .setConnectTimeout(500000)
                .build();
        httpPost.setConfig(requestConfig);
        // 装填参数
        StringEntity s = new StringEntity(params, "utf-8");
        s.setContentEncoding(new BasicHeader(HTTP.CONTENT_TYPE, "application/json"));
        // 设置参数到请求对象中
        httpPost.setEntity(s);
        httpPost.setHeader("accept", "*/*");
        httpPost.setHeader("connection", "Keep-Alive");
        httpPost.setHeader("user-agent", "Mozilla/4.0 (compatible; MSIE 6.0; Windows NT 5.1;SV1)");
        httpPost.setHeader("Content-type", "application/json;charset=utf-8");
        // httpPost.setHeader("Authorization", "Bearer " + token);//如果需要token请修改传入自己的token以及Authorization
        httpPost.setHeader("contentType", "utf-8");
        httpPost.setHeader("Accept-Charset", "utf-8");
        httpPost.setHeader("cookie", "access_token=" + token);
        // httpPost.setHeader();
        // 执行请求操作，并拿到结果（同步阻塞）
        try (CloseableHttpResponse response = client.execute(httpPost)) {

            // 获取结果实体
            HttpEntity entity = response.getEntity();
            if (entity != null) {
                // 按指定编码转换结果实体为String类型
                body = EntityUtils.toString(entity, "utf-8");
            }
            EntityUtils.consume(entity);
            return body;
        } catch (Exception e) {
            log.error("调用post请求失败,原因为:{}", e.getMessage(), e);
        }
        return null;
    }


    public static String sendPostNew(String url, String params, String token) {
        String body = "";

        // 创建httpclient对象
        CloseableHttpClient client = HttpClientUtils.getHttpClient();
        // 创建post方式请求对象
        HttpPost httpPost = new HttpPost(url);
        // 设置连接超时时间2秒
        RequestConfig requestConfig = RequestConfig.custom().setSocketTimeout(500000)
                .setConnectTimeout(500000)
                .build();
        httpPost.setConfig(requestConfig);
        // 装填参数
        StringEntity s = new StringEntity(params, "utf-8");
        s.setContentEncoding(new BasicHeader(HTTP.CONTENT_TYPE, "application/json"));
        // 设置参数到请求对象中
        httpPost.setEntity(s);
        httpPost.setHeader("accept", "*/*");
        httpPost.setHeader("connection", "Keep-Alive");
        httpPost.setHeader("user-agent", "Mozilla/4.0 (compatible; MSIE 6.0; Windows NT 5.1;SV1)");
        httpPost.setHeader("Content-type", "application/json;charset=utf-8");
        httpPost.setHeader("Authorization", "Bearer " + token);//如果需要token请修改传入自己的token以及Authorization
        httpPost.setHeader("contentType", "utf-8");
        httpPost.setHeader("Accept-Charset", "utf-8");
        //httpPost.setHeader("cookie", "access_token=" + token);
        // httpPost.setHeader();
        // 执行请求操作，并拿到结果（同步阻塞）
        try (CloseableHttpResponse response = client.execute(httpPost)) {

            // 获取结果实体
            HttpEntity entity = response.getEntity();
            if (entity != null) {
                // 按指定编码转换结果实体为String类型
                body = EntityUtils.toString(entity, "utf-8");
            }
            EntityUtils.consume(entity);
            return body;
        } catch (Exception e) {
            log.error("调用post请求失败,原因为:{}", e.getMessage(), e);
        }
        return null;
    }


    public static int sendPostXml(String url, String params, String token) {
        String body = "";

        // 创建httpclient对象
        CloseableHttpClient client = HttpClientUtils.getHttpClient();
        // 创建post方式请求对象
        HttpPost httpPost = new HttpPost(url);
        // 设置连接超时时间2秒
        RequestConfig requestConfig = RequestConfig.custom().setSocketTimeout(5000)
                .setConnectTimeout(5000)
                .build();
        httpPost.setConfig(requestConfig);
        // 装填参数
        StringEntity s = new StringEntity(params, "utf-8");
        // 设置参数到请求对象中
        httpPost.setEntity(s);
        httpPost.setHeader("Accept", "*/*");
        httpPost.setHeader("Connection", "Keep-Alive");
        httpPost.setHeader("Content-Type", "application/yang-data+xml");
        httpPost.setHeader("Authorization", token);//如果需要token请修改传入自己的token以及Authorization
        log.info("sendPost - " + url + ",JSON参数：" + params + ",token=" + token);
        // 执行请求操作，并拿到结果（同步阻塞）
        int statusCode = -1;
        try (CloseableHttpResponse response = client.execute(httpPost)) {
            statusCode = response.getStatusLine().getStatusCode();
            HttpEntity entity = response.getEntity();
            if (entity != null) {
                // 按指定编码转换结果实体为String类型
                body = EntityUtils.toString(entity, "utf-8");
            }
            EntityUtils.consume(entity);
            log.info("获取到的状态码为:{},ret={}", statusCode, body);
            return statusCode;
        } catch (Exception e) {
            log.error("调用post请求失败,原因为:{}", e.getMessage(), e);
        }
        return statusCode;
    }


    public static int sendDeleteXml(String url, String token) {
        String body = "";

        // 创建httpclient对象
        CloseableHttpClient client = HttpClientUtils.getHttpClient();
        // 创建post方式请求对象
        HttpDelete httpPost = new HttpDelete(url);
        // 设置连接超时时间2秒
        RequestConfig requestConfig = RequestConfig.custom().setSocketTimeout(5000)
                .setConnectTimeout(5000)
                .build();
        httpPost.setConfig(requestConfig);
        httpPost.setHeader("accept", "*/*");
        httpPost.setHeader("connection", "Keep-Alive");
        httpPost.setHeader("user-agent", "Mozilla/4.0 (compatible; MSIE 6.0; Windows NT 5.1;SV1)");
        httpPost.setHeader("Content-Type", "application/yang-data+xml");
        // httpPost.setHeader("Authorization", "Bearer " + token);//如果需要token请修改传入自己的token以及Authorization
        httpPost.setHeader("contentType", "utf-8");
        httpPost.setHeader("Accept-Charset", "utf-8");
        httpPost.setHeader("cookie", "access_token=" + token);
        // httpPost.setHeader();
        // 执行请求操作，并拿到结果（同步阻塞）
        try (CloseableHttpResponse response = client.execute(httpPost)) {
            int statusCode = response.getStatusLine().getStatusCode();
            log.info("获取到的状态码为:{}", statusCode);
            return statusCode;
        } catch (Exception e) {
            log.error("调用post请求失败,原因为:{}", e.getMessage(), e);
        }
        return -1;
    }


    /**
     * 向指定 URL 发送GET方法的请求
     *
     * @param url   发送请求的 URL
     * @param param 请求参数，请求参数应该是 name1=value1&name2=value2 的形式。
     * @return 所代表远程资源的响应结果
     */
    public static String sendSSLGet(String url, String param) {
        StringBuilder result = new StringBuilder();
        BufferedReader in = null;
        HttpsURLConnection httpsConnection = null;
        try {
            // 创建SSLContext
            SSLContext sslContext = SSLContext.getInstance("SSL");
            sslContext.init(null, new TrustManager[]{new TrustAnyTrustManager()}, new java.security.SecureRandom());

            // 获取SSLSocketFactory对象
            SSLSocketFactory ssf = sslContext.getSocketFactory();
            HostnameVerifier HostnameVerifier = (var1, var2) -> true;
            String urlNameString = url;
            if (StringUtils.isNotEmpty(param)) {
                urlNameString = url + "?" + param;
            }
            URL requestUrl = new URL(urlNameString);
            httpsConnection = (HttpsURLConnection) requestUrl.openConnection();
            httpsConnection.setDoOutput(false);
            httpsConnection.setDoInput(true);
            httpsConnection.setConnectTimeout(CONN_TIME_OUT);
            httpsConnection.setReadTimeout(READ_TIME_OUT);
            httpsConnection.setRequestProperty("Content-Type", "application/json;charset=UTF-8");
            httpsConnection.setRequestProperty("Charset", "UTF-8");
            httpsConnection.setRequestProperty("User-Agent", "Client identifier");
            httpsConnection.setRequestMethod("GET");
            // 设置当前实例使用的SSLSoctetFactory
            httpsConnection.setSSLSocketFactory(ssf);
            httpsConnection.setHostnameVerifier(HostnameVerifier);
            httpsConnection.connect();
            in = new BufferedReader(new InputStreamReader(httpsConnection.getInputStream()));
            String line;
            while ((line = in.readLine()) != null) {
                result.append(line);
            }
        } catch (ConnectException e) {
            log.error("调用HttpUtils.sendGet ConnectException, url=" + url, e);
        } catch (SocketTimeoutException e) {
            log.error("调用HttpUtils.sendGet SocketTimeoutException, url=" + url, e);
        } catch (IOException e) {
            log.error("调用HttpUtils.sendGet IOException, url=" + url, e);
        } catch (Exception e) {
            log.error("调用HttpsUtil.sendGet Exception, url=" + url, e);
        } finally {
            IOUtils.closeQuietly(in);
            try {
                if (httpsConnection != null) {
                    httpsConnection.disconnect();
                }
            } catch (Exception e) {
                log.error(e.getMessage(), e);
            }
        }
        return result.toString();
    }

    /**
     * @param urlPath   对方地址
     * @param json      要传送的数据
     * @param headerMap
     * @return
     */
    public static String sendSSLPost(String urlPath, String json, Map<String, String> headerMap) {
        String result = "";
        //创建post方式请求对象
        HttpPost httpPost = new HttpPost(urlPath);
        log.info(urlPath);
        //创建httpclient对象
        try (CloseableHttpClient httpClient = HttpClientUtils.getHttpClient()) {
            // 设置连接超时时间2秒
            RequestConfig requestConfig = RequestConfig.custom().setSocketTimeout(44000)
                    .setConnectTimeout(44000)
                    .build();
            if (headerMap != null) {
                headerMap.forEach(httpPost::setHeader);
            }
            httpPost.setConfig(requestConfig);
            BasicResponseHandler handler = new BasicResponseHandler();
            //设置请求格式
            StringEntity entity = new StringEntity(json, "utf-8");//解决中文乱码问题
            entity.setContentEncoding("UTF-8");
            entity.setContentType("application/json");
            httpPost.setEntity(entity);
            //执行POST请求
            result = httpClient.execute(httpPost, handler);
            return result;
        } catch (Exception e) {
            log.error(e.getMessage(), e);
        }
        //释放连接
        return result;
    }

    public static String sendPost(String urlPath, Map<String, Object> params) {
        if (urlPath.startsWith("https")) {
            return sendSSLPost(urlPath, JSON.toJSONString(params), null);
        }
        OutputStreamWriter out = null;
        BufferedReader in = null;
        HttpURLConnection urlConnection = null;
        StringBuilder result = new StringBuilder();
        try {
            URL url = new URL(urlPath);
            log.info(urlPath);
            urlConnection = (HttpURLConnection) url.openConnection();
            // 设置doOutput属性为true表示将使用此urlConnection写入数据
            urlConnection.setDoOutput(true);
            // 默认是 GET方式
            urlConnection.setRequestMethod("POST");
            // Post 请求不能使用缓存
            urlConnection.setUseCaches(false);
            urlConnection.setInstanceFollowRedirects(true);
            // 定义待写入数据的内容类型，我们设置为application/x-www-form-urlencoded类型
            urlConnection.setRequestProperty("content-type", "application/x-www-form-urlencoded");
            // 得到请求的输出流对象
            out = new OutputStreamWriter(urlConnection.getOutputStream());
            // 把数据写入请求的Body
            String paras = JSON.toJSONString(params);
            System.out.println(url + "?" + paras);
            if (params != null && params.size() > 0) {
                out.write(paras);
            }
            out.flush();
            // 定义BufferedReader输入流来读取URL的响应
            in = new BufferedReader(new InputStreamReader(urlConnection.getInputStream()));
            String line;
            while ((line = in.readLine()) != null) {
                result.append(line);
            }
        } catch (Exception e) {
            System.out.println("发送 POST 请求出现异常！" + urlPath);
            log.error(e.getMessage(), e);
            return "ERROR";
        }
        // 使用finally块来关闭输出流、输入流
        finally {
            IOUtils.closeQuietly(out);
            IOUtils.closeQuietly(in);
            try {
                urlConnection.disconnect();
            } catch (Exception e) {

            }
        }
        return result.toString();
    }

    /**
     * @param urlPath 对方地址
     * @param json    要传送的数据
     * @return
     */
    public static String sendPostTota(String urlPath, String json, String authorization, String aes) {
        OutputStreamWriter out = null;
        BufferedReader in = null;
        String result = "";
        HttpURLConnection urlConnection = null;
        try {
            URL url = new URL(urlPath);
            urlConnection = (HttpURLConnection) url.openConnection();
            // 设置doOutput属性为true表示将使用此urlConnection写入数据
            urlConnection.setDoOutput(true);
            // 定义待写入数据的内容类型，我们设置为application/x-www-form-urlencoded类型

            // urlConnection.setRequestProperty("Authorization", "safety-9drabz06sj5l248evh7mopc3in1fxkyw");
            urlConnection.setRequestProperty("Authorization", authorization);

            Date date = new Date();
            DateFormat df = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");

            // urlConnection.setRequestProperty("tota", AESUtils.Encrypt(df.format(date),
            // "qd9bxweyv40s6jlrczhopmfu1gn83i7a"));
            urlConnection.setRequestProperty("tota", AESUtils.Encrypt(df.format(date), aes));

            urlConnection.setRequestProperty("content-type", "application/json");
            // 得到请求的输出流对象
            out = new OutputStreamWriter(urlConnection.getOutputStream());
            // 把数据写入请求的Body
            out.write(json);
            out.flush();
            // 定义BufferedReader输入流来读取URL的响应
            in = new BufferedReader(new InputStreamReader(urlConnection.getInputStream()));
            String line;
            while ((line = in.readLine()) != null) {
                result += line;
            }
        } catch (Exception e) {
            System.out.println("发送 POST 请求出现异常！" + urlPath);
            e.printStackTrace();
            return "ERROR";
        }
        // 使用finally块来关闭输出流、输入流
        finally {
            IOUtils.closeQuietly(in);
            IOUtils.closeQuietly(out);
            try {
                if (urlConnection != null) {
                    urlConnection.disconnect();
                }
            } catch (Exception e) {

            }
        }
        return result;
    }

    /**
     * @param urlPath 对方地址
     * @param json    要传送的数据
     * @return
     */
    public static String sendPostBlock(String urlPath, String json) {
        OutputStreamWriter out = null;
        BufferedReader in = null;
        String result = "";
        HttpURLConnection urlConnection = null;
        try {
            URL url = new URL(urlPath);
            urlConnection = (HttpURLConnection) url.openConnection();
            // 设置doOutput属性为true表示将使用此urlConnection写入数据
            urlConnection.setDoOutput(true);
            // 定义待写入数据的内容类型，我们设置为application/x-www-form-urlencoded类型
            urlConnection.setRequestProperty("content-type", "application/json");
            // 得到请求的输出流对象
            out = new OutputStreamWriter(urlConnection.getOutputStream());
            // 把数据写入请求的Body
            if (StringUtils.isNotBlank(json)) {
                out.write(json);
            }
            out.flush();
            // 定义BufferedReader输入流来读取URL的响应
            in = new BufferedReader(new InputStreamReader(urlConnection.getInputStream()));
            String line;
            while ((line = in.readLine()) != null) {
                result += line;
            }
        } catch (Exception e) {
            log.error(e.getMessage(), e);
            return "";
        }
        // 使用finally块来关闭输出流、输入流
        finally {
            IOUtils.closeQuietly(in);
            IOUtils.closeQuietly(out);
            try {
                urlConnection.disconnect();
            } catch (Exception e) {

            }
        }
        return result;
    }

    /**
     * @param urlPath 对方地址
     * @param json    要传送的数据
     * @return
     */
    public static String sendPostTotaSafe(String urlPath, String json, String authorization, String aes) {
        OutputStreamWriter out = null;
        BufferedReader in = null;
        String result = "";
        HttpURLConnection urlConnection = null;
        try {
            URL url = new URL(urlPath);
            urlConnection = (HttpURLConnection) url.openConnection();
            // 设置doOutput属性为true表示将使用此urlConnection写入数据
            urlConnection.setDoOutput(true);
            // 定义待写入数据的内容类型，我们设置为application/x-www-form-urlencoded类型

            // urlConnection.setRequestProperty("Authorization", "safety-9drabz06sj5l248evh7mopc3in1fxkyw");
            urlConnection.setRequestProperty("AuthorizationSafe", authorization);

            Date date = new Date();
            DateFormat df = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");

            // urlConnection.setRequestProperty("tota", AESUtils.Encrypt(df.format(date),
            // "qd9bxweyv40s6jlrczhopmfu1gn83i7a"));
            urlConnection.setRequestProperty("tota", AESUtils.Encrypt(df.format(date), aes));

            urlConnection.setRequestProperty("content-type", "application/json");
            // 得到请求的输出流对象
            out = new OutputStreamWriter(urlConnection.getOutputStream());
            // 把数据写入请求的Body
            out.write(json);
            out.flush();
            // 定义BufferedReader输入流来读取URL的响应
            in = new BufferedReader(new InputStreamReader(urlConnection.getInputStream()));
            String line;
            while ((line = in.readLine()) != null) {
                result += line;
            }
        } catch (Exception e) {
            System.out.println("发送 POST 请求出现异常！" + urlPath);
            e.printStackTrace();
            return "ERROR";
        }
        // 使用finally块来关闭输出流、输入流
        finally {
            IOUtils.closeQuietly(in);
            IOUtils.closeQuietly(out);
            try {
                if (urlConnection != null) {
                    urlConnection.disconnect();
                }
            } catch (Exception e) {

            }
        }
        return result;
    }

    public static String sendSSLPost(String url, String param) {
        StringBuilder result = new StringBuilder();
        String urlNameString = url;
        if (StringUtils.isNotEmpty(param)) {
            urlNameString = url + "?" + param;
        }
        BufferedReader br = null;
        InputStream is = null;
        try {
            log.info("sendSSLPost - {}", urlNameString);
            SSLContext sc = SSLContext.getInstance("SSL");
            sc.init(null, new TrustManager[]{new TrustAnyTrustManager()}, new java.security.SecureRandom());
            URL console = new URL(urlNameString);
            HttpsURLConnection conn = (HttpsURLConnection) console.openConnection();
            conn.setRequestProperty("accept", "*/*");
            conn.setRequestProperty("connection", "Keep-Alive");
            conn.setRequestProperty("user-agent", "Mozilla/4.0 (compatible; MSIE 6.0; Windows NT 5.1;SV1)");
            conn.setRequestProperty("Accept-Charset", "utf-8");
            conn.setRequestProperty("contentType", "utf-8");
            conn.setDoOutput(true);
            conn.setDoInput(true);

            conn.setSSLSocketFactory(sc.getSocketFactory());
            conn.setHostnameVerifier(new TrustAnyHostnameVerifier());
            conn.connect();
            is = conn.getInputStream();
            br = new BufferedReader(new InputStreamReader(is));
            String ret = "";
            while ((ret = br.readLine()) != null) {
                if (!ret.trim().equals("")) {
                    result.append(new String(ret.getBytes(StandardCharsets.ISO_8859_1), StandardCharsets.UTF_8));
                }
            }
            log.info("recv - {}", result);
            conn.disconnect();
        } catch (ConnectException e) {
            log.error("调用HttpUtils.sendSSLPost ConnectException, url=" + url + ",param=" + param, e);
        } catch (SocketTimeoutException e) {
            log.error("调用HttpUtils.sendSSLPost SocketTimeoutException, url=" + url + ",param=" + param, e);
        } catch (IOException e) {
            log.error("调用HttpUtils.sendSSLPost IOException, url=" + url + ",param=" + param, e);
        } catch (Exception e) {
            log.error("调用HttpsUtil.sendSSLPost Exception, url=" + url + ",param=" + param, e);
        } finally {
            IOUtils.closeQuietly(br);
            IOUtils.closeQuietly(is);
        }
        return result.toString();
    }

    public static int sendPutXml(String url, String params, String token) {
        String body = "";
        // 创建httpclient对象
        CloseableHttpClient client = HttpClientUtils.getHttpClient();
        // 创建post方式请求对象
        HttpPut httpPost = new HttpPut(url);
        // 设置连接超时时间2秒
        RequestConfig requestConfig = RequestConfig.custom().setSocketTimeout(50000)
                .setConnectTimeout(50000)
                .build();
        httpPost.setConfig(requestConfig);
        // 装填参数
        StringEntity s = new StringEntity(params, "utf-8");
        // 设置参数到请求对象中
        httpPost.setEntity(s);
        httpPost.setHeader("accept", "*/*");
        httpPost.setHeader("connection", "Keep-Alive");
        httpPost.setHeader("Content-Type", "application/yang-data+xml");
        httpPost.setHeader("Authorization", token);//如果需要token请修改传入自己的token以及Authorization
        httpPost.setHeader("Accept-Charset", "utf-8");
        log.info("sendPost - " + url + ",JSON参数：" + params + ",token=" + token);
        // 执行请求操作，并拿到结果（同步阻塞）
        int statusCode = -1;
        try (CloseableHttpResponse response = client.execute(httpPost)) {
            log.debug("获取到的报文为:{}", response);
            HttpEntity entity = response.getEntity();
            if (entity != null) {
                // 按指定编码转换结果实体为String类型
                body = EntityUtils.toString(entity, "utf-8");
            }
            EntityUtils.consume(entity);
            log.info("获取到的返回值为:{}", body);
            statusCode = response.getStatusLine().getStatusCode();
            log.info("获取到的状态码为:{}", statusCode);
            return statusCode;
        } catch (Exception e) {
            log.error("调用post请求失败,原因为:{}", e.getMessage(), e);
        }
        return statusCode;
    }

    public static String sendGetXml(String url, String token) {
        // 创建httpclient对象
        CloseableHttpClient client = HttpClientUtils.getHttpClient();
        // 创建post方式请求对象
        HttpGet httpPost = new HttpGet(url);
        // 设置连接超时时间2秒
        RequestConfig requestConfig = RequestConfig.custom().setSocketTimeout(5000)
                .setConnectTimeout(5000)
                .build();
        httpPost.setConfig(requestConfig);
        httpPost.setHeader("Accept", "*/*");
        httpPost.setHeader("Connection", "Keep-Alive");
        httpPost.setHeader("Content-Type", "application/yang-data+xml");
        httpPost.setHeader("Authorization", token);//如果需要token请修改传入自己的token以及Authorization
        log.info("sendGet - " + url + ",token=" + token);
        // 执行请求操作，并拿到结果（同步阻塞）
        try (CloseableHttpResponse response = client.execute(httpPost)) {
            HttpEntity entity = response.getEntity();
            String xml = "";
            if (entity != null) {
                // 按指定编码转换结果实体为String类型
                xml = EntityUtils.toString(entity, "utf-8");
            }
            EntityUtils.consume(entity);
            return xml;
        } catch (Exception e) {
            log.error("调用get请求失败,原因为:{}", e.getMessage(), e);
        }
        return null;
    }


    public static HashMap<String, HwVo> sendSSLGetXml(String url, String param, String token) {
        StringBuilder result = new StringBuilder();
        HashMap<String, HwVo> dataList = new HashMap<>();
        BufferedReader in = null;
        HttpsURLConnection httpsConnection = null;
        try {
            // 创建SSLContext
            SSLContext sslContext = SSLContext.getInstance("SSL");
            sslContext.init(null, new TrustManager[]{new TrustAnyTrustManager()}, new java.security.SecureRandom());

            // 获取SSLSocketFactory对象
            SSLSocketFactory ssf = sslContext.getSocketFactory();
            HostnameVerifier HostnameVerifier = (var1, var2) -> true;
            String urlNameString = url;
            if (StringUtils.isNotEmpty(param)) {
                urlNameString = url + "?" + param;
            }
            URL requestUrl = new URL(urlNameString);
            httpsConnection = (HttpsURLConnection) requestUrl.openConnection();
            httpsConnection.setDoOutput(false);
            httpsConnection.setDoInput(true);
            httpsConnection.setConnectTimeout(CONN_TIME_OUT);
            httpsConnection.setReadTimeout(READ_TIME_OUT);
            httpsConnection.setRequestProperty("Content-Type", "application/yang-data+xml");
            httpsConnection.setRequestProperty("Charset", "UTF-8");
            httpsConnection.setRequestProperty("Authorization", token);
            httpsConnection.setRequestProperty("accept", "*/*");
            httpsConnection.setRequestMethod("GET");
            // 设置当前实例使用的SSLSoctetFactory
            httpsConnection.setSSLSocketFactory(ssf);
            httpsConnection.setHostnameVerifier(HostnameVerifier);
            httpsConnection.connect();
            in = new BufferedReader(new InputStreamReader(httpsConnection.getInputStream()));
            String line;
            while ((line = in.readLine()) != null) {
                result.append(line);
            }
            try {
                DocumentBuilderFactory factory = DocumentBuilderFactory.newInstance();
                factory.setFeature("http://apache.org/xml/features/disallow-doctype-decl", true);
                DocumentBuilder builder = factory.newDocumentBuilder();
                InputSource source = new InputSource(new StringReader(result.toString()));
                Document document = builder.parse(source);

                Element root = document.getDocumentElement();
                NodeList elements = root.getElementsByTagName("elements");
                if (elements.getLength() > 0) {
                    for (int i = 0; i < elements.getLength(); i++) {
                        Element element = (Element) elements.item(i);
                        NodeList childs = element.getChildNodes();
                        HwVo vo = new HwVo();
                        boolean flag = false;
                        for (int j = 0; j < childs.getLength(); j++) {
                            if ("elem-id".equalsIgnoreCase(childs.item(j).getNodeName())) {
                                vo.setElemId(childs.item(j).getTextContent());
                            } else if ("address-ipv4".equalsIgnoreCase(childs.item(j).getNodeName()) || "address-ipv6".equalsIgnoreCase(childs.item(j).getNodeName())) {
                                vo.setElemValue(childs.item(j).getTextContent());
                                flag = true;
                            }
                        }
                        if (flag) {
                            dataList.put(vo.getElemId(), vo);
                        }
                    }
                }
            } catch (Exception e) {
                log.error(e.getMessage(), e);
            }
        } catch (ConnectException e) {
            log.error("调用HttpUtils.sendGet ConnectException, url=" + url, e);
        } catch (SocketTimeoutException e) {
            log.error("调用HttpUtils.sendGet SocketTimeoutException, url=" + url, e);
        } catch (IOException e) {
            log.error("调用HttpUtils.sendGet IOException, url=" + url, e);
        } catch (Exception e) {
            log.error("调用HttpsUtil.sendGet Exception, url=" + url, e);
        } finally {
            org.apache.commons.io.IOUtils.closeQuietly(in);
            try {
                if (httpsConnection != null)
                    httpsConnection.disconnect();
            } catch (Exception e) {
                log.error(e.getMessage(), e);
            }
        }
        return dataList;
    }

    public static class TrustAnyTrustManager implements X509TrustManager {
        @Override
        public void checkClientTrusted(X509Certificate[] chain, String authType) {
        }

        @Override
        public void checkServerTrusted(X509Certificate[] chain, String authType) {
        }

        @Override
        public X509Certificate[] getAcceptedIssuers() {
            return new X509Certificate[]{};
        }
    }

    private static class TrustAnyHostnameVerifier implements HostnameVerifier {
        @Override
        public boolean verify(String hostname, SSLSession session) {
            return true;
        }
    }

    /**
     * IP封堵专门方法
     * @param url
     * @param param
     * @return
     */
    public static String sendGetMarvalnet(String url, String param, String token){
        if (url != null && url.toLowerCase().startsWith("https")) {
            return sendSSLGetMarvalnet(url, param, token);
        }
        StringBuilder result = new StringBuilder();
        BufferedReader in = null;
        HttpURLConnection connection = null;
        try {
            String urlNameString = url;
            if (StringUtils.isNotBlank(param)) {
                urlNameString = url + "?" + param;
            }
            log.info("sendGet - {}", urlNameString);
            URL realUrl = new URL(urlNameString);
            connection = (HttpURLConnection) realUrl.openConnection();
            connection.setRequestProperty("accept", "*/*");
            connection.setRequestProperty("connection", "Keep-Alive");
            connection.setRequestProperty("user-agent", "Mozilla/4.0 (compatible; MSIE 6.0; Windows NT 5.1;SV1)");
            connection.setRequestProperty("content-type", "application/json");
            connection.setRequestProperty("Cookie", token);
            connection.setRequestProperty("Referer", param);
            connection.setConnectTimeout(CONN_TIME_OUT);
            connection.setReadTimeout(READ_TIME_OUT);
            connection.connect();
            in = new BufferedReader(new InputStreamReader(connection.getInputStream()));
            String line;
            while ((line = in.readLine()) != null) {
                result.append(line);
            }
        } catch (Exception e) {
            log.info("调用接口失败:{},{}",url, param);
        } finally {
            IOUtils.closeQuietly(in);
            try {
                connection.disconnect();
            } catch (Exception e) {
                log.error(e.getMessage(), e);
            }
        }
        return result.toString();
    }


    public static String sendSSLGetMarvalnet(String url, String param, String token) {
        StringBuilder result = new StringBuilder();
        BufferedReader in = null;
        HttpsURLConnection httpsConnection = null;
        try {
            // 创建SSLContext
            SSLContext sslContext = SSLContext.getInstance("SSL");
            sslContext.init(null, new TrustManager[]{new TrustAnyTrustManager()}, new java.security.SecureRandom());

            // 获取SSLSocketFactory对象
            SSLSocketFactory ssf = sslContext.getSocketFactory();
            HostnameVerifier HostnameVerifier = (var1, var2) -> true;
            String urlNameString = url + "?" + param;
            if (StringUtils.isBlank(param)) {
                urlNameString = url;
            }
            URL requestUrl = new URL(urlNameString);
            httpsConnection = (HttpsURLConnection) requestUrl.openConnection();
            httpsConnection.setDoOutput(false);
            httpsConnection.setDoInput(true);
            httpsConnection.setConnectTimeout(CONN_TIME_OUT);
            httpsConnection.setReadTimeout(READ_TIME_OUT);
            httpsConnection.setRequestProperty("Content-Type", "application/json;charset=UTF-8");
            httpsConnection.setRequestProperty("Charset", "UTF-8");
            httpsConnection.setRequestProperty("User-Agent", "Client identifier");
            httpsConnection.setRequestProperty("Cookie", token);
            httpsConnection.setRequestProperty("Referer", param);
            httpsConnection.setRequestMethod("GET");
            // 设置当前实例使用的SSLSoctetFactory
            httpsConnection.setSSLSocketFactory(ssf);
            httpsConnection.setHostnameVerifier(HostnameVerifier);
            httpsConnection.connect();
            in = new BufferedReader(new InputStreamReader(httpsConnection.getInputStream()));
            String line;
            while ((line = in.readLine()) != null) {
                result.append(line);
            }
        } catch (ConnectException e) {
            log.error("调用HttpUtils.sendGet ConnectException, url=" + url, e);
        } catch (SocketTimeoutException e) {
            log.error("调用HttpUtils.sendGet SocketTimeoutException, url=" + url, e);
        } catch (IOException e) {
            log.error("调用HttpUtils.sendGet IOException, url=" + url, e);
        } catch (Exception e) {
            log.error("调用HttpsUtil.sendGet Exception, url=" + url, e);
        } finally {
            try {
                if (in != null) {
                    in.close();
                }
            } catch (Exception ex) {
                log.error("调用in.close Exception, url=" + url, ex);
            }
            try {
                httpsConnection.disconnect();
            } catch (Exception e) {
                log.error(e.getMessage(), e);
            }
        }
        return result.toString();
    }


    public static String sendPostMarvalnet(String urlPath, String json, String token, String localIp) {
        String body = "";

        // 创建httpclient对象
        CloseableHttpClient httpClient = HttpClientUtils.getHttpClient();
        // 创建post方式请求对象
        HttpPost httpPost = new HttpPost(urlPath);
        // 设置连接超时时间2秒
        RequestConfig requestConfig = RequestConfig.custom().setSocketTimeout(30000)
                .setConnectTimeout(30000)
                .build();
        httpPost.setConfig(requestConfig);
        // 装填参数
        StringEntity s = new StringEntity(json, "utf-8");
        s.setContentEncoding(new BasicHeader(HTTP.CONTENT_TYPE, "application/json"));
        // 设置参数到请求对象中
        httpPost.setEntity(s);
        httpPost.setHeader("accept", "*/*");
        httpPost.setHeader("connection", "Keep-Alive");
        httpPost.setHeader("user-agent", "Mozilla/4.0 (compatible; MSIE 6.0; Windows NT 5.1;SV1)");
        httpPost.setHeader("Content-type", "application/json;charset=utf-8");
        // httpPost.setHeader("Authorization", "Bearer " + token);//如果需要token请修改传入自己的token以及Authorization
        httpPost.setHeader("contentType", "utf-8");
        httpPost.setHeader("Accept-Charset", "utf-8");
        httpPost.setHeader("Cookie", token);
        httpPost.setHeader("Referer", localIp);
        // httpPost.setHeader();
        // 执行请求操作，并拿到结果（同步阻塞）
        try (CloseableHttpResponse response = httpClient.execute(httpPost)) {

            // 获取结果实体
            HttpEntity entity = response.getEntity();
            if (entity != null) {
                // 按指定编码转换结果实体为String类型
                body = EntityUtils.toString(entity, "utf-8");
            }
            EntityUtils.consume(entity);
            return body;
        } catch (Exception e) {
            log.error("调用post请求失败,原因为:{}", e.getMessage(), e);
        }
        return null;
    }

    /**
     * 设置 https 请求 忽略ssl认证
     *
     * @throws Exception
     */
    public static void trustAllHttpsCertificates() throws Exception {
        HttpsURLConnection.setDefaultHostnameVerifier(new HostnameVerifier() {
            public boolean verify(String str, SSLSession session) {
                return true;
            }
        });
        javax.net.ssl.TrustManager[] trustAllCerts = new javax.net.ssl.TrustManager[1];
        javax.net.ssl.TrustManager tm = new miTM();
        trustAllCerts[0] = tm;
        javax.net.ssl.SSLContext sc = javax.net.ssl.SSLContext.getInstance("SSL");
        sc.init(null, trustAllCerts, null);
        javax.net.ssl.HttpsURLConnection.setDefaultSSLSocketFactory(sc.getSocketFactory());
    }

    // 设置 https 请求证书
    public static class miTM implements javax.net.ssl.TrustManager, javax.net.ssl.X509TrustManager {
        public java.security.cert.X509Certificate[] getAcceptedIssuers() {
            return null;
        }

        public boolean isServerTrusted(java.security.cert.X509Certificate[] certs) {
            return true;
        }

        public boolean isClientTrusted(java.security.cert.X509Certificate[] certs) {
            return true;
        }

        public void checkServerTrusted(java.security.cert.X509Certificate[] certs, String authType)
                throws java.security.cert.CertificateException {
            return;
        }

        public void checkClientTrusted(java.security.cert.X509Certificate[] certs, String authType)
                throws java.security.cert.CertificateException {
            return;
        }
    }
}
