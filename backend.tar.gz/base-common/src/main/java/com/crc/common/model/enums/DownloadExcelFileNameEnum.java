package com.crc.common.model.enums;

/**
 * @Author shufengfeng
 * @Description 下载excel文件名枚举
 * @DateTime 2021/9/15 16:35
 */
public enum DownloadExcelFileNameEnum {
    /**
     * 自残导入读取sheet名称
     */
    IMPORT_DATA_SHEET("填写模板","填写模板"),
    /**
     * 通用导入sheet名称
     */
    COMMON_SHEET("填写模板", "填写模板"),

    ASSET_SOFTWARE_LICENSE("软件正版化管理台账", "下载软件许可证列表文件名"),
    /**
     * 软件许可导入读取sheet名称
     */
    ASSET_SOFTWARE_LICENSE_SHEET("填写模板", "填写模板"),

    /**
     * 自残导入读取sheet名称
     */
    ASSET_SHEET("填写模板", "填写模板"),

    /**
     * 风险自动发现导出
     */
    RISK_AUTO_REPORT("风险自动发现", "风险自动发现"),

    /**
     * 互联网资产导入读取sheet名称
     */
    INTERNET_ASSET_SHEET("填写模板", "填写模板"),

    /**
     * 重点关注问题导入读取sheet名称
     */
    EVNET_ATTENTION_SHEET("填写模板", "填写模板"),

    /**
     * 应用系统导入读取sheet名称
     */
    APP_SYSTEM_SHEET("填写模板", "填写模板"),

    /**
     * 漏洞信息读取sheet名称
     */
    CLIENT_VULN_SHEET("填写模板", "填写模板"),

    /**
     * 研判知识库导入读取sheet名称
     */
    KNOWLEDGE_JUDGE_SHEET("填写模板","填写模板"),

    /**
     * IOC情报库导入读取sheet名称
     */
    INTELLGENCE_IOC_SHEET("填写模板","填写模板"),

    /**
     * 导入读取sheet名称
     */
    PATRAL_ITEM_SHEET("填写模板", "填写模板"),

    ;

    /**
     * 文件名
     */
    private String name;

    /**
     * 后缀
     */
    private String desc;

    DownloadExcelFileNameEnum(String name, String desc) {
        this.name = name;
        this.desc = desc;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getDesc() {
        return desc;
    }

    public void setDesc(String desc) {
        this.desc = desc;
    }
}
