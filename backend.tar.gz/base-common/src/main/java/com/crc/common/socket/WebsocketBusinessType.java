package com.crc.common.socket;

/**
 * websocket业务消息类型常量类
 * 
 * @author zhangbing
 */
public interface WebsocketBusinessType {

    /**
     * 告警流程消息提醒
     */
    String ALARM_PROCESS = "alarm_process";

    /**
     * 新增告警大屏显示消息提醒
     */
    String ADD_ALARM_VIEW = "add_alarm_view";
}
