package com.crc.common.model.enums;

/**
 * @Author shufengfeng
 * @Description 菜单类型枚举
 * @DateTime 2021/8/27 17:10
 */
public enum MenuTypeEnum {

    /**
     * M 目录
     */
    CATALOGUE("M", "目录"),

    /**
     * C 菜单
     */
    MENU("C", "菜单"),

    /**
     * F 按钮
     */
    BUTTON("F", "按钮"),

    ;

    /**
     * 类型
     */
    private String type;

    /**
     * 描述
     */
    private String desc;

    MenuTypeEnum(String type, String desc) {
        this.type = type;
        this.desc = desc;
    }

    /**
     * 获取菜单类型描述
     *
     * @param type 菜单类型
     * @return 菜单类型描述
     */
    public static String getMenuTypeDesc(String type) {
        String desc = "";
        for (MenuTypeEnum typeEnum : MenuTypeEnum.values()) {
            if (typeEnum.getType().equals(type)) {
                desc = typeEnum.getDesc();
                break;
            }
        }
        return desc;
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }

    public String getDesc() {
        return desc;
    }

    public void setDesc(String desc) {
        this.desc = desc;
    }
}
