package com.crc.common.constant;

/**
 * 消息枚举
 * @author WANGLEI
 * @date 2021/5/25 15:50
 */
public enum DataTypeEnum {

    INT(0, "INT"),
    BIGINT(1, "BIGINT"),//整型
    FLOAT(2, "FLOAT"),
    DOUBLE(3, "DOUBLE"),
    VARCHAR(4, "VARCHAR"),
    DATE(5, "DATE"),
    TIMESTAMP(6, "TIMESTAMP"),
    TEXT(7, "TEXT"),
    ;

    // 枚举名称
    private Integer key;

    // 枚举类型
    private String value;

    DataTypeEnum(Integer key, String value) {
        this.key = key;
        this.value = value;
    }

    public Integer getKey() {
        return key;
    }

    public void setKey(Integer key) {
        this.key = key;
    }

    public String getValue() {
        return value;
    }

    public void setValue(String value) {
        this.value = value;
    }
}
