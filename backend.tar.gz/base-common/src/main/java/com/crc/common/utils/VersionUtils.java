package com.crc.common.utils;

/**
 * @author hejingsheng
 */

public class VersionUtils {
    private static final int VERSION_LONG = 16;

    public static long getVersionValue(String version) {
        if (version == null || version.contains("。") || version.contains("，") ||
                version.contains(",")) {
            return 0L;
        }
        String newVersion = version.replace("-", ".").replace("_", ".");
        newVersion = newVersion.replaceAll("[a-zA-Z]", "0");
        String[] versions = newVersion.split("\\.");
        int index = VERSION_LONG;
        long totalVer = 0;
        int first = 1;
        for (String ver : versions) {
            int verInt = DataUtils.getInt(ver);
            if (verInt < 1 && first != 1) {
                verInt = 1;
            }
            int barboo = index - 2;
            totalVer += verInt * getBarboo(barboo);
            index = barboo;
            first++;
        }
        //System.out.println(version);
        return totalVer;
    }

    private static long getBarboo(int barboo) {
        long total = 1;
        for (int i = 0; i < barboo; i++) {
            total *= 10;
        }
        return total;
    }
}
