package com.crc.common.constant.enums;

import lombok.AllArgsConstructor;
import lombok.Getter;

/**
 * 导出类型枚举类
 *
 * @author zhangbing
 */
@Getter
@AllArgsConstructor
public enum ExportTypeEnum {

    /**
     * 导出Json格式
     */
    JSON("json", "1"),

    /**
     * 导出excel格式
     */
    EXCEL("excel", "2"),

    /**
     * 导出word格式
     */
    WORD("word", "3"),;

    /**
     * 格式名称
     */
    private final String name;

    /**
     * 格式类型
     */
    private final String type;

    /**
     * 根据类型判断是否正确
     *
     * @param type 类型
     * @param typeEnum 类型枚举
     * @return boolean true 正确 false 错误
     */
    public static Boolean equalsByType(String type, ExportTypeEnum typeEnum) {
        return typeEnum.getType().equals(type);
    }
}