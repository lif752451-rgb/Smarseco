package com.crc.common.utils;

import cn.hutool.core.io.IoUtil;
import lombok.extern.slf4j.Slf4j;
import org.mapstruct.ap.shaded.freemarker.template.Configuration;
import org.mapstruct.ap.shaded.freemarker.template.Template;

import java.io.*;
import java.util.Map;

/**
 * 描述：生成word 文件
 *
 * @Author: fuzhuangzhi
 * @Date: 2021/12/3 10:07
 */
@Slf4j
public class WordUtil {
    /**
     * 生成word文件
     *
     * @param dataMap      word中需要展示的动态数据，用map集合来保存
     * @param templateName word模板名称，例如：test.ftl
     * @param fileName     生成的文件名称，例如：test.doc
     */
    public static void createWord(Map dataMap, String templateName, String filePath, String fileName) {
        Writer out = null;
        try {
            //创建配置实例
            Configuration configuration = new Configuration();

            //设置编码
            configuration.setDefaultEncoding("UTF-8");

            //ftl模板文件
            configuration.setClassForTemplateLoading(WordUtil.class, "/template/");

            //获取模板
            Template template = configuration.getTemplate(templateName);

            //输出文件
            File outFile = new File(filePath + File.separator + fileName);

            //如果输出目标文件夹不存在，则创建
            if (!outFile.getParentFile().exists()) {
                outFile.getParentFile().mkdirs();
            }

            //将模板和数据模型合并生成文件
            out = new BufferedWriter(new OutputStreamWriter(new FileOutputStream(outFile), "UTF-8"));

            //生成文件
            template.process(dataMap, out);
            log.info("生成word成功！filePath:{},fileName:{}", filePath, fileName);
        } catch (Exception e) {
            e.printStackTrace();
            log.error("生成word失败！");
        } finally {
            IoUtil.flush(out);
            IoUtil.close(out);
        }
    }
}
