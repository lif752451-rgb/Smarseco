package com.crc.common.model;

public class YouduAppClient {

}
