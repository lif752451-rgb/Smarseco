package com.crc.common.easyexcel.listener;

import com.alibaba.excel.annotation.ExcelProperty;
import com.alibaba.excel.context.AnalysisContext;
import com.alibaba.excel.event.AnalysisEventListener;
import com.crc.common.exception.CustomException;
import com.crc.common.model.enums.ResponseEnum;

import java.lang.reflect.Field;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Map;
import java.util.Objects;

/**
 * 导入模板验证数据读取
 *
 * @author zhangbing
 */
public abstract class CheckTemplateListener<T> extends AnalysisEventListener<T> {

    private final List<T> list = new ArrayList<>(100);

    public static <T> CheckTemplateListener<T> build(Class<T> tClass) {
        return new CheckTemplateListener<T>() {

            @Override
            public void invokeHeadMap(Map<Integer, String> headMap, AnalysisContext context) {
                // count 记录模板表头有几个，用以判断用户导入的表格是否和模板完全一致
                // 如果用户导入表格较模板的表头多，但其余符合模板，这样不影响则不需要
                // 获取数据实体的字段列表
                Field[] fields = tClass.getDeclaredFields();
                long checkCount = Arrays.stream(fields)
                    .filter(field -> Objects.nonNull(field.getAnnotation(ExcelProperty.class))).count();
                long count =
                    Arrays.stream(fields).filter(field -> Objects.nonNull(field.getAnnotation(ExcelProperty.class)))
                        .map(field -> field.getAnnotation(ExcelProperty.class).value()[0])
                        .filter(headName -> headMap.values().stream().anyMatch(headName::equals)).count();
                // 判断用户导入表格的标题头是否完全符合模板
                if (count != checkCount) {
                    throw new CustomException(ResponseEnum.WORK_TYPE_ERROR.getMsg());
                }
            }

            @Override
            public void doAfterAllAnalysed(AnalysisContext analysisContext) {}
        };
    }

    public List<T> getList() {
        return this.list;
    }

    @Override
    public abstract void invokeHeadMap(Map<Integer, String> headMap, AnalysisContext context);

    @Override
    public void invoke(T t, AnalysisContext analysisContext) {
        this.list.add(t);
    }

    @Override
    public abstract void doAfterAllAnalysed(AnalysisContext analysisContext);
}