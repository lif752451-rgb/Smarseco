package com.crc.common.constant;

/**
 * @author fuzhuangzhi
 * @title CommonIpSegmentType
 * @date 2023/8/2 17:35
 * @description 公共IP/网段类型
 */
public interface CommonIpSegmentType {

    /**
     * 关键系统类型
     */
    String CRITICAL = "critical";
}
