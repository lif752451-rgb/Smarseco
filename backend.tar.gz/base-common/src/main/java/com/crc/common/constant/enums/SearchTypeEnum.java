package com.crc.common.constant.enums;

import lombok.AllArgsConstructor;
import lombok.Getter;

/**
 * @author fuzhuangzhi
 * @title SearchTypeEnum
 * @date 2023/6/7 15:25
 * @description 搜索类型枚举
 */
@Getter
@AllArgsConstructor
public enum SearchTypeEnum {

    SELECTED("0","按勾选项"),
    SEARCH("1","按搜索条件"),
    ALL("2","全部"),
    ;
    private String value;
    private String desc;
}
