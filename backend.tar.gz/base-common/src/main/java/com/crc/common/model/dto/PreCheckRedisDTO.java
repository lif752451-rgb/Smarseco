package com.crc.common.model.dto;

import com.alibaba.fastjson.JSONObject;
import io.swagger.annotations.ApiModel;
import lombok.Data;
import lombok.ToString;

import java.util.List;

/**
 * 导入验证数据
 */
@Data
@ToString
@ApiModel(value = "导入验证数据")
public class PreCheckRedisDTO {

    /**
     * 成功数据
     */
    private Object successData;

    /**
     * 失败数据
     */
    private Object errorData;

    public <T> List<T> getSuccessDataArray(Class<T> clazz) {
        return JSONObject.parseArray(String.valueOf(this.successData), clazz);
    }

    public <T> List<T> getErrorDataArray(Class<T> clazz) {
        return JSONObject.parseArray(String.valueOf(this.errorData), clazz);
    }
}