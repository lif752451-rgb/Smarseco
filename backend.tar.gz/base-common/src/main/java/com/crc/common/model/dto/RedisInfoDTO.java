package com.crc.common.model.dto;

import lombok.Data;

/**
 * @author jixiangqi
 * @date 2023/9/14
 */
@Data
public class RedisInfoDTO {

    private Integer keys;

    private String mem;
}
