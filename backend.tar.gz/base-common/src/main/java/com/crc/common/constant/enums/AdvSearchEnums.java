//package com.crc.common.constant.enums;
//
//import com.crc.common.constant.Constants;
//import com.crc.common.utils.StringUtils;
//
//public enum AdvSearchEnums {
//    SRC_IP("源IP","src_ip"),
//    DEST_IP("目标IP","dest_ip"),
//    LOG_TIME("入库时间","SparkTime"),
//    ALERT_NAME("日志概要","alert_name"),
//    ;
//
//    AdvSearchEnums(String label, String code){
//        this.label = label;
//        this.code = code;
//    }
//
//    private String label;
//    private String code;
//
//    public static String getEnum(String code) {
//        if (StringUtils.isNotBlank(code)) {
//            code = code.trim();
//        }else {
//            return Constants.BLANK_STR;
//        }
//        for (AdvSearchEnums behaviorNatureEnum : AdvSearchEnums.values()) {
//            if(behaviorNatureEnum.getCode().equals(code)){
//                return behaviorNatureEnum.getLabel();
//            }
//        }
//        return Constants.BLANK_STR;
//    }
//
//    public String getLabel() {
//        return label;
//    }
//
//    public void setLabel(String label) {
//        this.label = label;
//    }
//
//    public String getCode() {
//        return code;
//    }
//
//    public void setCode(String code) {
//        this.code = code;
//    }
//}
