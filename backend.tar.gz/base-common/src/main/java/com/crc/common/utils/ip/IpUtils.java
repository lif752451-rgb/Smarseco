package com.crc.common.utils.ip;

import cn.hutool.core.collection.CollUtil;
import cn.hutool.core.util.ObjectUtil;
import cn.hutool.core.util.StrUtil;
import com.crc.common.constant.Constants;
import com.crc.common.utils.DataUtils;
import com.crc.common.utils.StringUtils;
import com.googlecode.ipv6.IPv6Network;
import lombok.extern.slf4j.Slf4j;

import javax.servlet.http.HttpServletRequest;
import java.math.BigInteger;
import java.net.Inet4Address;
import java.net.InetAddress;
import java.net.NetworkInterface;
import java.net.URL;
import java.util.*;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import java.util.stream.Collectors;

/**
 * 获取IP方法
 *
 * @author wst
 */
@Slf4j
public class IpUtils {
    private static final String IP_REGX = "\\d{1,3}.\\d{1,3}.\\d{1,3}.\\d{1,3}";
    private static final String regEx = "((2[0-4]\\d|25[0-5]|[01]?\\d\\d?)\\.){3}(2[0-4]\\d|25[0-5]|[01]?\\d\\d?)";
    private static Pattern P = Pattern.compile(regEx);

    public static final BigInteger a1 = getIp2long("10.0.0.1");
    public static final BigInteger a2 = getIp2long("10.255.255.254");
    public static final BigInteger b1 = getIp2long("172.16.0.1");
    public static final BigInteger b2 = getIp2long("172.31.255.254");
    public static final BigInteger c1 = getIp2long("192.168.0.1");
    public static final BigInteger c2 = getIp2long("192.168.255.254");

    public static String[] getIpSegment(String segment) {
        if (StringUtils.isBlank(segment)) {
            return null;
        }
        segment = segment.replace(" ", "").replace(",", "\n").replace("\t", "").replaceAll(" ", "\n");
        return segment.split("\n");
    }

    public static String getLocalIp(String prefix) {
        try {
            Enumeration<NetworkInterface> enumeration = NetworkInterface.getNetworkInterfaces();
            while (enumeration.hasMoreElements()) {
                NetworkInterface network = enumeration.nextElement();
                Enumeration<InetAddress> addresses = network.getInetAddresses();
                while (addresses.hasMoreElements()) {
                    InetAddress address = addresses.nextElement();
                    if ((address instanceof Inet4Address)) {
                        if (org.apache.commons.lang3.StringUtils.isBlank(prefix)
                                && address.getHostAddress().startsWith("10.")) {
                            return address.getHostAddress();
                        } else if (address.getHostAddress().startsWith(prefix)) {
                            return address.getHostAddress();
                        }
                    }
                }
            }
        } catch (Exception e) {
            log.error(e.getMessage(), e);
        }
        return "127.0.0.1";
    }

    public static String getIpAddr(HttpServletRequest request) {
        if (request == null) {
            return "unknown";
        }
        String ip = request.getHeader("x-forwarded-for");
        if (ip == null || ip.length() == 0 || "unknown".equalsIgnoreCase(ip) || "127.0.0.1".equals(ip)) {
            ip = request.getHeader("Proxy-Client-IP");
        }
        if (ip == null || ip.length() == 0 || "unknown".equalsIgnoreCase(ip) || "127.0.0.1".equals(ip)) {
            ip = request.getHeader("X-Forwarded-For");
        }
        if (ip == null || ip.length() == 0 || "unknown".equalsIgnoreCase(ip) || "127.0.0.1".equals(ip)) {
            ip = request.getHeader("WL-Proxy-Client-IP");
        }
        if (ip == null || ip.length() == 0 || "unknown".equalsIgnoreCase(ip) || "127.0.0.1".equals(ip)) {
            ip = request.getHeader("X-Real-IP");
        }
        if (ip == null || ip.length() == 0 || "unknown".equalsIgnoreCase(ip) || "127.0.0.1".equals(ip)) {
            ip = request.getRemoteAddr();
        }

        return "0:0:0:0:0:0:0:1".equals(ip) ? "127.0.0.1" : ip;
    }

    public static boolean internalIp(String ip) {
        byte[] addr = textToNumericFormatV4(ip);
        return internalIp(addr) || "127.0.0.1".equals(ip);
    }

    private static boolean internalIp(byte[] addr) {
        if (StringUtils.isNull(addr) || addr.length < 2) {
            return true;
        }
        final byte b0 = addr[0];
        final byte b1 = addr[1];
        // 10.x.x.x/8
        final byte SECTION_1 = 0x0A;
        // 172.16.x.x/12
        final byte SECTION_2 = (byte) 0xAC;
        final byte SECTION_3 = (byte) 0x10;
        final byte SECTION_4 = (byte) 0x1F;
        // 192.168.x.x/16
        final byte SECTION_5 = (byte) 0xC0;
        final byte SECTION_6 = (byte) 0xA8;
        switch (b0) {
            case SECTION_1:
                return true;
            case SECTION_2:
                if (b1 >= SECTION_3 && b1 <= SECTION_4) {
                    return true;
                }
            case SECTION_5:
                switch (b1) {
                    case SECTION_6:
                        return true;
                }
            default:
                return false;
        }
    }

    /**
     * 将IPv4地址转换成字节
     *
     * @param text IPv4地址
     * @return byte 字节
     */
    public static byte[] textToNumericFormatV4(String text) {
        if (text.length() == 0) {
            return null;
        }

        byte[] bytes = new byte[4];
        String[] elements = text.split("\\.", -1);
        try {
            long l;
            int i;
            switch (elements.length) {
                case 1:
                    l = Long.parseLong(elements[0]);
                    if ((l < 0L) || (l > 4294967295L)) {
                        return null;
                    }
                    bytes[0] = (byte) (int) (l >> 24 & 0xFF);
                    bytes[1] = (byte) (int) ((l & 0xFFFFFF) >> 16 & 0xFF);
                    bytes[2] = (byte) (int) ((l & 0xFFFF) >> 8 & 0xFF);
                    bytes[3] = (byte) (int) (l & 0xFF);
                    break;
                case 2:
                    l = Integer.parseInt(elements[0]);
                    if ((l < 0L) || (l > 255L))
                        return null;
                    bytes[0] = (byte) (int) (l & 0xFF);
                    l = Integer.parseInt(elements[1]);
                    if ((l < 0L) || (l > 16777215L))
                        return null;
                    bytes[1] = (byte) (int) (l >> 16 & 0xFF);
                    bytes[2] = (byte) (int) ((l & 0xFFFF) >> 8 & 0xFF);
                    bytes[3] = (byte) (int) (l & 0xFF);
                    break;
                case 3:
                    for (i = 0; i < 2; ++i) {
                        l = Integer.parseInt(elements[i]);
                        if ((l < 0L) || (l > 255L))
                            return null;
                        bytes[i] = (byte) (int) (l & 0xFF);
                    }
                    l = Integer.parseInt(elements[2]);
                    if ((l < 0L) || (l > 65535L))
                        return null;
                    bytes[2] = (byte) (int) (l >> 8 & 0xFF);
                    bytes[3] = (byte) (int) (l & 0xFF);
                    break;
                case 4:
                    for (i = 0; i < 4; ++i) {
                        l = Integer.parseInt(elements[i]);
                        if ((l < 0L) || (l > 255L))
                            return null;
                        bytes[i] = (byte) (int) (l & 0xFF);
                    }
                    break;
                default:
                    return null;
            }
        } catch (NumberFormatException e) {
            return null;
        }
        return bytes;
    }

    public static String getHostIp() {
        try {
            return InetAddress.getLocalHost().getHostAddress();
        } catch (Exception ignored) {
        }
        return "127.0.0.1";
    }

    public static String getHostName() {
        try {
            return InetAddress.getLocalHost().getHostName();
        } catch (Exception ignored) {
        }
        return "未知";
    }

    public static boolean isMatchIp(String ip) {
        Pattern pattern = Pattern.compile(IP_REGX);
        Matcher matcher = pattern.matcher(ip);
        return matcher.matches();
    }

    public static boolean isMatchDomain(String domainName) {
        Pattern pattern = Pattern.compile(IP_REGX);
        Matcher matcher = pattern.matcher(domainName);
        return matcher.matches();
    }

    public static BigInteger getIp2long(String ipaddress) {
        if (!isIp(ipaddress)) {
            return BigInteger.valueOf(0);
        }
        try {
            return IpConvert.StringToBigInt(ipaddress);
        } catch (Exception ignored) {

        }
        return BigInteger.valueOf(0);
    }

    public static boolean isInnerIP(String ip) {
        if (IpUtils.isIpv6(ip)) {
            return true;
        }
//        long n = getIp2long(ip);
//        if (n >= a1 && n <= a2) {
//            return true;
//        }
//        if (n >= b1 && n <= b2) {
//            return true;
//        }
//        return n >= c1 && n <= c2;
        BigInteger n = getIp2long(ip);
        if (n.compareTo(a1) >= 0 && n.compareTo(a2) <= 0) {
            return true;
        }
        if (n.compareTo(b1) >= 0 && n.compareTo(b2) <= 0) {
            return true;
        }
        return n.compareTo(c1) >= 0 && n.compareTo(c2) <= 0;
    }

    public static boolean isIP(String str) {
        return isValidIp(str);
    }

    /**
     * 通过完整网段获取网段对应的开始IP和结束IP的十进制
     *
     * @param segments 网段地址
     * @return 网段对应的开始IP和结束IP的十进制
     */
    public static List<AssetSegementIp> getLongIpListBySegmentList(List<String> segments) {
        if (CollUtil.isEmpty(segments)) {
            return Collections.emptyList();
        }
        List<AssetSegementIp> longIpList = segments.stream().map(segment -> {
            List<AssetSegementIp> list = getSegementIpList(segment).stream()
                    .filter(t -> ObjectUtil.isAllNotEmpty(t, t.getStartLongIp(), t.getEndLongIp()))
                    .collect(Collectors.toList());
            return list;
        }).filter(CollUtil::isNotEmpty).flatMap(Collection::stream).distinct().collect(Collectors.toList());
        return longIpList;
    }

    /**
     * 获取开始IP和结束IP
     *
     * @param segmentStr 网段
     * @return
     */
    public static List<AssetSegementIp> getSegementIpList(String segmentStr) {
        if (StrUtil.isEmpty(segmentStr)) {
            return Collections.emptyList();
        }
        String[] ipList = IpUtils.getIpSegment(segmentStr);
        List<AssetSegementIp> list = new ArrayList<>();
        for (String cidr : ipList) {
            AssetSegementIp assetSegementIp = new AssetSegementIp();
            BigInteger[] rets = IpUtils.getIpStartAndEnd(cidr);
            if (rets == null || rets.length != 2) {
                continue;
            }
            BigInteger startIp2long = rets[0];
            BigInteger endIp2long = rets[1];
            assetSegementIp.setStartLongIp(startIp2long);
            assetSegementIp.setEndLongIp(endIp2long);
            if (DataUtils.bigTo0(assetSegementIp.getStartLongIp()) && DataUtils.compareBigInt(assetSegementIp.getEndLongIp(), assetSegementIp.getStartLongIp()) >= 0) {
                list.add(assetSegementIp);
            }
        }

        return list;
    }

    public static boolean isBelongThisSegment(String segmentStr, String targetIpStr) {
        if (StringUtils.isEmpty(segmentStr) || StringUtils.isEmpty(targetIpStr)) {
            return false;
        }
        BigInteger ip2long = IpUtils.getIp2long(targetIpStr.trim());
        if (!DataUtils.bigTo0(ip2long)) {
            return false;
        }
        String[] ipList = IpUtils.getIpSegment(segmentStr);
        for (String cidr : ipList) {
            BigInteger startIp2long = null;
            BigInteger endIp2long = null;
            if (cidr.contains("-") && cidr.contains("/")) {
                String[] ips = cidr.split("-");
                if (ips.length <= 1) {
                    continue;
                }
                if (ips[0].contains(":")) {
                    try {
                        IPv6Network network = IPv6Network.fromString(ips[0]);
                        startIp2long = IpUtils.getIp2long(network.getFirst().toLongString());
                    } catch (Exception e) {
                        log.error("非法 IPV6掩码{}",ips[0]);
                    }
                }else {
                    startIp2long = IpUtils.getIp2long(IpUtils.getStartIp(ips[0].trim()));
                }
                if (ips[1].contains(":")) {
                    try {
                        IPv6Network network = IPv6Network.fromString(ips[1]);
                        endIp2long = IpUtils.getIp2long(network.getLast().toLongString());
                    } catch (Exception e) {
                        log.error("非法 IPV6掩码{}",ips[1]);
                    }
                }else {
                    endIp2long = IpUtils.getIp2long(IpUtils.getEndIp(ips[1].trim()));
                }
            } else if (cidr.contains("-")) {
                String[] ips = cidr.split("-");
                if (ips.length <= 1) {
                    continue;
                }
                if (ips[0].contains(":")) {
                    try {
                        IPv6Network network = IPv6Network.fromString(ips[0]);
                        startIp2long = IpUtils.getIp2long(network.getFirst().toLongString());
                    } catch (Exception e) {
                        log.error("非法 IPV6掩码{}",ips[0]);
                    }
                }else {
                    startIp2long = IpUtils.getIp2long(IpUtils.getStartIp(ips[0].trim()));
                }
                if (ips[1].contains(":")) {
                    try {
                        IPv6Network network = IPv6Network.fromString(ips[1]);
                        endIp2long = IpUtils.getIp2long(network.getLast().toLongString());
                    } catch (Exception e) {
                        log.error("非法 IPV6掩码{}",ips[1]);
                    }
                }else {
                    endIp2long = IpUtils.getIp2long(IpUtils.getEndIp(ips[1].trim()));
                }
            } else if (cidr.contains("/")) {
                if (cidr.contains(":")) {
                    try {
                        IPv6Network network = IPv6Network.fromString(cidr);
                        startIp2long = IpUtils.getIp2long(network.getFirst().toLongString());
                        endIp2long = IpUtils.getIp2long(network.getLast().toLongString());
                    } catch (Exception e) {
                        log.error("非法 IPV6掩码{}",cidr);
                    }
                }else {
                    startIp2long = IpUtils.getIp2long(IpUtils.getStartIp(cidr.trim()));
                    endIp2long = IpUtils.getIp2long(IpUtils.getEndIp(cidr.trim()));
                }
            } else {
                startIp2long = IpUtils.getIp2long(cidr.trim());
                endIp2long = IpUtils.getIp2long(cidr.trim());
            }
            if (DataUtils.isIpInSegment(startIp2long,ip2long,endIp2long)) {
                return true;
            }
        }
        return false;
    }

    public static String getStartIp(String segment) {
        StringBuilder startIp = new StringBuilder();
        if (segment == null) {
            return null;
        }
        if (IpUtils.isIp(segment)) {
            return segment;
        }
        String[] arr = segment.split("/");
        String ip = arr[0];
        if (arr.length < 2) {
            return null;
        }
        String maskIndex = arr[1];
        String mask = getNetMask(maskIndex);
        if (4 != ip.split("\\.").length || mask == null) {
            return null;
        }
        int[] ipArray = new int[4];
        int[] netMaskArray = new int[4];
        for (int i = 0; i < 4; i++) {
            try {
                ipArray[i] = Integer.parseInt(ip.split("\\.")[i]);
                netMaskArray[i] = Integer.parseInt(mask.split("\\.")[i]);
                if (ipArray[i] > 255 || ipArray[i] < 0 || netMaskArray[i] > 255 || netMaskArray[i] < 0) {
                    return null;
                }
                ipArray[i] = ipArray[i] & netMaskArray[i];
                if (i == 3) {
                    startIp.append(ipArray[i] + 1);
                } else {
                    startIp.append(ipArray[i]).append(".");
                }
            } catch (Exception e) {
                log.error(segment + e.getMessage(),e);
            }
        }
        return startIp.toString();
    }

    public static String getEndIp(String segment) {
        StringBuilder endIp = new StringBuilder();
        String startIp = getStartIp(segment);
        if (segment == null || startIp == null) {
            return null;
        }
        if (IpUtils.isIp(segment)) {
            return segment;
        }
        String[] arr = segment.split("/");
        String maskIndex = arr[1];
        // 实际需要的IP个数
        int hostNumber = 0;
        int[] startIpArray = new int[4];
        try {
            hostNumber = 1 << 32 - (Integer.parseInt(maskIndex));
            for (int i = 0; i < 4; i++) {
                startIpArray[i] = Integer.parseInt(startIp.split("\\.")[i]);
                if (i == 3) {
                    startIpArray[i] = startIpArray[i] - 1;
                    break;
                }
            }
            startIpArray[3] = startIpArray[3] + (hostNumber - 1);
        } catch (Exception e) {
            System.out.println("getEndIp=" + segment);
            System.out.println(e.getMessage());
        }

        if (startIpArray[3] > 255) {
            int k = startIpArray[3] / 256;
            startIpArray[3] = startIpArray[3] % 256;
            startIpArray[2] = startIpArray[2] + k;
        }
        if (startIpArray[2] > 255) {
            int j = startIpArray[2] / 256;
            startIpArray[2] = startIpArray[2] % 256;
            startIpArray[1] = startIpArray[1] + j;
            if (startIpArray[1] > 255) {
                int k = startIpArray[1] / 256;
                startIpArray[1] = startIpArray[1] % 256;
                startIpArray[0] = startIpArray[0] + k;
            }
        }
        for (int i = 0; i < 4; i++) {
            if (i == 3) {
                startIpArray[i] = startIpArray[i] - 1;
            }
            if ("".contentEquals(endIp) || endIp.length() == 0) {
                endIp.append(startIpArray[i]);
            } else {
                endIp.append(".").append(startIpArray[i]);
            }
        }
        return endIp.toString();
    }

    public static String getNetMask(String maskIndex) {
        StringBuilder mask = new StringBuilder();
        int inetMask = 0;
        try {
            inetMask = Integer.parseInt(maskIndex);
        } catch (NumberFormatException e) {
            System.out.println(e.getMessage());
            return null;
        }
        if (inetMask > 32) {
            return null;
        }
        // 子网掩码为1占了几个字节
        int num1 = inetMask / 8;
        // 子网掩码的补位位数
        int num2 = inetMask % 8;
        int[] array = new int[4];
        for (int i = 0; i < num1; i++) {
            array[i] = 255;
        }
        for (int i = num1; i < 4; i++) {
            array[i] = 0;
        }
        for (int i = 0; i < num2; num2--) {
            array[num1] += 1 << 8 - num2;
        }
        for (int i = 0; i < 4; i++) {
            if (i == 3) {
                mask.append(array[i]);
            } else {
                mask.append(array[i]).append(".");
            }
        }
        return mask.toString();
    }

    public static boolean isIp(String addr) {
        if (org.apache.commons.lang3.StringUtils.isBlank(addr)) {
            return false;
        }
        return isValidIp(addr);
    }

    /**
     * 正则提取字符串中的IP地址 并且将url中的ip地址提取出来
     *
     * @param ips ip
     * @return list
     */
    /**
     * 正则提取字符串中的IP地址 并且将url中的ip地址提取出来
     *
     * @param segment ip
     * @return list
     */
    public static List<String> analysisIp(String segment) {
        List<String> dataList = new ArrayList<>();
        String[] segs = IpUtils.getIpSegment(segment);
        HashMap<String, String> ipMap = new HashMap<>();
        if (segs != null) {
            for (String ips : segs) {
                if (org.apache.commons.lang3.StringUtils.isBlank(ips)) {
                    continue;
                }
                List<String> ipList = IpUtils.getIps(ips);
                if (ipList.size() < 1) {
                    if (IpUtils.isIpv6(ips)) {
                        ipList.add(ips);
                    }
                }
                try {
                    List<String> dataListTmp = ipList.stream().map(IpUtils::getHostInUrl).collect(Collectors.toList());
                    if (CollUtil.isEmpty(dataListTmp)) {
                        continue;
                    }

                    for (String ip : dataListTmp) {
                        BigInteger iplong = IpUtils.getIp2long(ip);
                        if (DataUtils.bigTo0(iplong)) {
                            ipMap.put(String.valueOf(iplong.longValue()), ip);
                        }
                    }
                } catch (Exception e) {
                    log.error(e.getMessage(), e);
                }
            }
        }
        ipMap.forEach((k, v) -> {
            dataList.add(v);
        });
        return dataList;
    }

    /**
     * 正则提前字符串中的IP地址
     *
     * @param ipString
     * @return
     */
    public static List<String> getIps(String ipString) {
        if (StringUtils.isBlank(ipString)) {
            return new ArrayList<>();
        }
        HashMap<String, String> ipMap = new HashMap<>();

        if (StringUtils.isBlank(ipString))
            return new ArrayList<>();
        Pattern p = Pattern.compile(regEx);
        Matcher m = p.matcher(ipString);
        while (m.find()) {
            String result = m.group();
            if (IpUtils.isIp(result.trim()))
                ipMap.put(result.trim(), "1");
        }
        String[] ipsNews0 = DataUtils.getSplit(ipString, " ");
        for (String ip : ipsNews0) {
            if (IpUtils.isIp(ip)) {
                ipMap.put(ip.trim(), "1");
            }
        }

        String[] ipsNews1 = DataUtils.getSplit(ipString, ",");
        for (String ip : ipsNews1) {
            if (IpUtils.isIp(ip)) {
                ipMap.put(ip.trim(), "1");
            }
        }
        String[] ipsNews2 = DataUtils.getSplit(ipString, "，");
        for (String ip : ipsNews2) {
            if (IpUtils.isIp(ip)) {
                ipMap.put(ip.trim(), "1");
            }
        }
        List<String> ips = new ArrayList<>();
        ipMap.forEach((k, v) -> {
            ips.add(k);
        });
        return ips;
    }

    /**
     * 获取url中的host 非url返回原本字符串 如 http://www.baidu.con/index -> www.baidu.com; https://193.20.51.36:8080/index ->
     * 193.20.51.36
     *
     * @param urlStr url
     * @return hostStr
     */
    public static String getHostInUrl(String urlStr) {
        String hostStr;
        try {
            URL url = new URL(urlStr);
            // 获取主机名
            hostStr = url.getHost();
        } catch (Exception ignored) {
            hostStr = urlStr;
        }
        return hostStr;
    }

    public static Set<String> getIpSet(String ipString) {
        if (StringUtils.isBlank(ipString) || ipString.trim().equals("127.0.0.1")) {
            return new HashSet<>();
        }

        Set<String> ips = new HashSet<>();
        try {
            if (null == P) {
                P = Pattern.compile(regEx);
            }
            Matcher m = P.matcher(ipString);
            while (m.find()) {
                String result = m.group();
                if (isIp(result)) {
                    ips.add(result);
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return ips;
    }

    /**
     * Is ipv 4 boolean.
     */
    public static boolean isIpv4(String ipv4) {
        if (org.apache.commons.lang3.StringUtils.isBlank(ipv4)) {
            return false;
        }
        if (!ipv4.contains(".") && !ipv4.contains(":")) {
            return false;
        }
        //如果是IPV4
        if (ipv4.contains(".")) {
            if (ipv4.endsWith(".")) {
                return false;
            }
            String[] arr = ipv4.split("\\.");
            if (arr.length != 4) {
                return false;
            }

            for (int i = 0; i < 4; i++) {
                if (arr[i].length() == 0 || arr[i].length() > 3) {
                    return false;
                }
                for (int j = 0; j < arr[i].length(); j++) {
                    if (arr[i].charAt(j) >= '0' && arr[i].charAt(j) <= '9') {
                        continue;
                    }
                    return false;
                }
                if (Integer.parseInt(arr[i]) > 255 || (arr[i].length() >= 2 && String.valueOf(arr[i]).startsWith("0"))) {
                    return false;
                }
            }
            return true;
        }
        return false;
    }

    /**
     * Is ipv 6 boolean.
     */
    public static boolean isIpv6(String ipv6) {
        if (org.apache.commons.lang3.StringUtils.isBlank(ipv6)) {
            return false;
        }
        // 8*4 位数字，加上七个: ipv6地址长度不可能超过39位
        if (ipv6.length() > 39) {
            return false;
        }
        if (ipv6.endsWith(":") && !ipv6.endsWith("::")) {
            return false;
        }
        // 如果包含多个“::”，一个IPv6地址中只能出现一个“::”
        if (ipv6.contains("::") && ipv6.indexOf("::", ipv6.indexOf("::") + 2) != -1) {
            return false;
        }

        // ipv6“::”
        if (ipv6.contains("::")) {
            String[] arr = ipv6.split(":");
            if (arr.length > 7 || arr.length < 1) {// "1::"是最短的字符串
                return false;
            }
            for (String s : arr) {
                if (s.equals("")) {
                    continue;
                }
                if (s.length() > 4) {
                    return false;
                }
                for (int j = 0; j < s.length(); j++) {
                    if ((s.charAt(j) >= '0' && s.charAt(j) <= '9') || (s.charAt(j) >= 'A' && s.charAt(j) <= 'F')
                            || (s.charAt(j) >= 'a' && s.charAt(j) <= 'f')) {
                        continue;
                    }
                    return false;
                }
            }
            return true;
        } else {// 如果不含有“::”
            String[] arr = ipv6.split(":");
            if (arr.length != 8) {
                return false;
            }
            for (String s : arr) {
                if (s.length() > 4) {
                    return false;
                }
                for (int j = 0; j < s.length(); j++) {
                    if ((s.charAt(j) >= '0' && s.charAt(j) <= '9') || (s.charAt(j) >= 'A' && s.charAt(j) <= 'F')
                            || (s.charAt(j) >= 'a' && s.charAt(j) <= 'f')) {
                        continue;
                    }
                    return false;
                }
            }
            return true;
        }
    }

    /**
     * 校验MAC地址格式
     *
     * @param macAddr
     * @return
     */
    public static Boolean isMac(String macAddr) {
        String patternMac = "^[a-fA-F0-9]{2}(-[a-fA-F0-9]{2}){5}$";
        String patternMac1 = "^[a-fA-F0-9]{2}(:[a-fA-F0-9]{2}){5}$";
        return Pattern.compile(patternMac).matcher(macAddr).find()
                || Pattern.compile(patternMac1).matcher(macAddr).find();
    }

    /**
     * 校验IP是否符合IPV4或者IPV6格式
     *
     * @param ip ip
     * @return true 符合格式 false 不符合格式
     */
    public static Boolean isIpV4OrIpV6(String ip) {
        return IpUtils.isValidIp(ip) || ip.startsWith(Constants.HTTP) || ip.startsWith(Constants.HTTPS);
    }

    public static boolean isValidIp(String addr) {
        if (isIpv4(addr)) {
            return true;
        } else {
            return isIpv6(addr);
        }
    }

    /**
     * 判断多个 IP，以逗号 空格分开是否有合法 IP，所有都合法才行,0.0.0.0也是合法
     * @param addr
     * @return
     */
    public static boolean isValidMoreIp(String addr) {
        if (StringUtils.isBlank(addr)) {
            return false;
        }
        addr = addr.replace(" ", "").replace(",", "\n").replace("\t", "").replaceAll(" ", "\n");
        String []ips =  addr.split("\n");
        if (ips.length < 1) {
            return false;
        }
        for (String ip : ips) {
            if (!isValidIp(ip) && !"0.0.0.0".equals(ip)) {
                return false;
            }
        }
        return true;
    }

    public static List<String> getHosts(String ipString) {
        List<String> hosts = new ArrayList<>();
        if (StringUtils.isBlank(ipString))
            return hosts;
        try {
            // String regex =
            // "((http://)?|(https://)?)([0-9]{1,3}(.[0-9]{1,3}){3}(:(\\d){2,4}))|([a-zA-Z0-9]+(.[a-zA-Z0-9]*){0,2}\\.(com.cn|net.cn|gov.cn|org.nz|org.cn|com|net|org|gov|cc|biz|info|cn|co|com.hk))";
            String regex =
                    "((http://)?|(https://)?)([a-zA-Z0-9]+(.[a-zA-Z0-9]*){0,2}\\.(com.cn|net.cn|gov.cn|org.nz|org.cn|com|net|org|gov|cc|biz|info|cn|co|com.hk))";
            Pattern p = Pattern.compile(regex, Pattern.CASE_INSENSITIVE);
            Matcher matcher = p.matcher(ipString);
            while (matcher.find()) {
                hosts.add(matcher.group());
            }
        } catch (Exception ignored) {

        }
        return hosts;
    }

    public static Boolean isIpOrHost(String ip) {
        return IpUtils.isIp(ip) || ip.startsWith(Constants.HTTP) || ip.startsWith(Constants.HTTPS);
    }

    /**
     * 分割ip
     *
     * @param ipStr
     * @param ascriptionStr
     * @return
     */
    public static String splitIp(String ipStr, String ascriptionStr, String separator) {
        if (StringUtils.isNotEmpty(ascriptionStr)) {
            if (ipStr.contains(Constants.Symbol.COMMA)) {
                List<String> ips = Arrays.asList(ipStr.split(Constants.Symbol.COMMA));
                List<String> ascriptionList = Arrays.asList(ascriptionStr.split(Constants.Symbol.PLACEHOLDER));
                List<String> result = new ArrayList<>();
                for (int i = 0; i < ips.size() && i < ascriptionList.size(); i++) {
                    String sb = ips.get(i) +
                            Constants.Symbol.SPACE + Constants.Symbol.EN_LEFT_BRACKET + ascriptionList.get(i)
                            + Constants.Symbol.EN_RIGHT_BRACKET;
                    result.add(sb);
                }
                return CollUtil.join(result, separator);
            } else {
                return ipStr + Constants.Symbol.SPACE + Constants.Symbol.EN_LEFT_BRACKET + ascriptionStr
                        + Constants.Symbol.EN_RIGHT_BRACKET;
            }
        }
        return ipStr;
    }

    /**
     * 获取 IP段的开始 IP 和结束 IP
     * @param cidr
     * @return
     */
    public static BigInteger[] getIpStartAndEnd(String cidr) {
        try {
            if (org.apache.commons.lang3.StringUtils.isBlank(cidr)) {
                return null;
            }
            cidr = cidr.trim();
            BigInteger startIp2long = null;
            BigInteger endIp2long = null;
            if (cidr.contains("-") && cidr.contains("/")) {
                String[] ips = cidr.split("-");
                if (ips.length <= 1) {
                    return null;
                }
                if (ips[0].contains(":")) {
                    if (IpUtils.isIP(ips[0].trim())) {
                        startIp2long = IpUtils.getIp2long(ips[0].trim());
                    } else {
                        try {
                            IPv6Network network = IPv6Network.fromString(ips[0]);
                            startIp2long = IpUtils.getIp2long(network.getFirst().toLongString());
                        } catch (Exception e) {
                            log.error("非法 IPV6掩码{}", ips[0]);
                        }
                    }

                } else {
                    startIp2long = IpUtils.getIp2long(IpUtils.getStartIp(ips[0].trim()));
                }
                if (ips[1].contains(":")) {
                    if (IpUtils.isIP(ips[1].trim())) {
                        endIp2long = IpUtils.getIp2long(ips[1].trim());
                    } else {
                        try {
                            IPv6Network network = IPv6Network.fromString(ips[1]);
                            endIp2long = IpUtils.getIp2long(network.getLast().toLongString());
                        } catch (Exception e) {
                            log.error("非法 IPV6掩码{}", ips[1]);
                        }
                    }
                } else {
                    endIp2long = IpUtils.getIp2long(IpUtils.getEndIp(ips[1].trim()));
                }
            } else if (cidr.contains("-")) {
                String[] ips = cidr.split("-");
                if (ips.length <= 1) {
                    return null;
                }
                if (ips[0].contains(":")) {
                    if (IpUtils.isIP(ips[0].trim())) {
                        startIp2long = IpUtils.getIp2long(ips[0].trim());
                    } else {
                        try {
                            IPv6Network network = IPv6Network.fromString(ips[0]);
                            startIp2long = IpUtils.getIp2long(network.getFirst().toLongString());
                        } catch (Exception e) {
                            log.error("非法 IPV6掩码{}", ips[0]);
                        }
                    }
                } else if (ips[0].contains("/")) {
                    startIp2long = IpUtils.getIp2long(IpUtils.getStartIp(ips[0].trim()));
                } else if (ips[0].contains(".")) {
                    startIp2long = IpUtils.getIp2long(ips[0].trim());
                } else {
                    startIp2long = IpUtils.getIp2long(IpUtils.getStartIp(ips[0].trim()));
                }
                if (ips[1].contains(":")) {
                    if (IpUtils.isIP(ips[1].trim())) {
                        endIp2long = IpUtils.getIp2long(ips[1].trim());
                    } else {
                        try {
                            IPv6Network network = IPv6Network.fromString(ips[1]);
                            endIp2long = IpUtils.getIp2long(network.getLast().toLongString());
                        } catch (Exception e) {
                            log.error("非法 IPV6掩码{}", ips[1]);
                        }
                    }
                } else if (ips[1].contains("/")) {
                    endIp2long = IpUtils.getIp2long(IpUtils.getStartIp(ips[1].trim()));
                } else if (ips[1].contains(".")) {
                    endIp2long = IpUtils.getIp2long(ips[1].trim());
                    //endIp2long = IpUtils.getIp2long(ips[1].trim());
                } else {
                    endIp2long = IpUtils.getIp2long(IpUtils.getEndIp(ips[1].trim()));
                }
            } else if (cidr.contains("/")) {
                if (cidr.contains(":")) {
                    try {
                        IPv6Network network = IPv6Network.fromString(cidr);
                        startIp2long = IpUtils.getIp2long(network.getFirst().toLongString());
                        endIp2long = IpUtils.getIp2long(network.getLast().toLongString());
                    } catch (Exception e) {
                        log.error("非法 IPV6掩码{}", cidr);
                    }
                } else {
                    startIp2long = IpUtils.getIp2long(IpUtils.getStartIp(cidr.trim()));
                    endIp2long = IpUtils.getIp2long(IpUtils.getEndIp(cidr.trim()));
                }
            } else {
                startIp2long = IpUtils.getIp2long(cidr.trim());
                endIp2long = IpUtils.getIp2long(cidr.trim());
            }

            BigInteger[] rets = new BigInteger[2];
            rets[0] = startIp2long;
            rets[1] = endIp2long;
            return rets;
        } catch (Exception e) {
            log.error(e.getMessage(),e);
        }
        return null;
    }

    /**
     * 校验IP格式为：10.200.0.1/16 或者  10.200.0.1-10.200.0.10
     * @param ip
     * @return
     */
    public static boolean isValidIP(String ip) {
        String regex = "^((25[0-5]|2[0-4]\\d|[01]?\\d\\d?)\\.){3}(25[0-5]|2[0-4]\\d|[01]?\\d\\d?)(/(\\d{1,2}))?$|^((25[0-5]|2[0-4]\\d|[01]?\\d\\d?)\\.){3}(25[0-5]|2[0-4]\\d|[01]?\\d\\d?)-((25[0-5]|2[0-4]\\d|[01]?\\d\\d?)\\.){3}(25[0-5]|2[0-4]\\d|[01]?\\d\\d?)$";
        Pattern pattern = Pattern.compile(regex);
        Matcher matcher = pattern.matcher(ip);
        return matcher.matches();
    }

}
