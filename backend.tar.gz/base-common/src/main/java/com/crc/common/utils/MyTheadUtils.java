package com.crc.common.utils;

/**
 * 睡眠工具类
 */
public class MyTheadUtils {
    /**
     * 按秒睡眠
     * @param sec
     */
    public static void sleepBySec(int sec) {
        if (sec < 0) {
            sec = 1;
        }
        try {

            Thread.sleep(1000L * sec);
        } catch (Exception e) {

        }
    }

    /**
     * 按毫米睡眠
     * @param ms
     */
    public static void sleep(int ms) {
        if (ms < 0) {
            ms = 1;
        }
        try {
            Thread.sleep(ms);
        } catch (Exception e) {

        }
    }
}


