package com.crc.common.model.response;

import io.swagger.annotations.ApiModel;
import lombok.Builder;
import lombok.Data;
import lombok.ToString;

/**
 * 导入验证返回
 */
@Data
@Builder
@ToString
@ApiModel(value = "导入验证返回")
public class PreCheckResponse {

    /**
     * 总数量
     */
    private Integer total;

    /**
     * 去重后数量
     */
    private Integer distinctCount;

    /**
     * 可用数量
     */
    private Integer availableCount;

    /**
     * 不可用数量
     */
    private Integer disabledCount;
}
