package com.crc.common.model.enums;

/**
 * @Author shufengfeng
 * @Description 漏洞危害级别
 * @DateTime 2021/10/13 10:35
 */
public enum VulLevelEnum {

    CRITICAL("危急", "3"),
    HIGH_RISK("高危", "2"),
    MEDIUM_RISK("中危", "1"),
    LOW_RISK("低危", "0"),


    ;


    /**
     * 名称
     */
    private String label;

    /**
     * 字典键值
     */
    private String value;

    VulLevelEnum(String label, String value){
        this.label = label;
        this.value = value;
    }


    public String getLabel() {
        return label;
    }

    public void setLabel(String label) {
        this.label = label;
    }

    public String getValue() {
        return value;
    }

    public void setValue(String value) {
        this.value = value;
    }


    public static VulLevelEnum findByValue(String value) {
        for (VulLevelEnum vulLevelEnum : VulLevelEnum.values()) {
            if(vulLevelEnum.getValue().equals(value)){
                return vulLevelEnum;
            }
        }
        return null;
    }

    public static String findNameByValue(String value) {
        VulLevelEnum levelEnum = findByValue(value);
        if (levelEnum == null) {
            return null;
        }
        return levelEnum.getLabel();
    }
}
