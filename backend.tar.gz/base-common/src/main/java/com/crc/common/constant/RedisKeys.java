package com.crc.common.constant;

/**
 * @Author shufengfeng
 * @Description TODO
 * @DateTime 2021/9/17 15:01
 */
public class RedisKeys {

    /**
     * 1小时(单位秒)
     */
    public static final Long ONE_HOUR = 3600L;

    /**
     * 4小时(单位秒)
     */
    public static final Long FOUR_HOUR = 4 * 3600L;

    /**
     * 半小时(单位秒)
     */
    public static final Long HALF_AN_HOUR = 1800L;

    /**
     * 1分钟(单位秒)
     */
    public static final Long ONE_MINUTE = 60L;

    /**
     * 30秒
     */
    public static final Long THIRTY = 30L;

    /**
     * 20秒(单位秒)
     */
    public static final Long TWENTY = 20L;

    /**
     * 10秒(单位秒)
     */
    public static final Long TEN = 10L;

    /**
     * 一天(单位秒)
     */
    public static final Long ONE_DAY = 86400L;

    /**
     * 资产网段
     */
    public static final String ASSET_SEGEMENT = "asset:segement:%s";

    /**
     * 用户导入key
     */
    public static final String SYS_USER = "sys:user:%s";
    /**
     * 软件许可redisKey
     */
    public static final String ASSET_SOFTWARE_LICENSE = "soft:license:%s";
    /**
     * 软件许可剩余可用量
     */
    public static final String ASSET_SOFTWARE_LICENSE_SURPLUS = "soft:license:%s";

    /**
     * 资产软件许可证-授权用户
     */
    public static final String LICENSE_AUTH_USER = "license:auth:user:%s";

    /**
     * 重点区域告警统计计算
     */
    public static final String MAJOR_AREA_ALARM_LOCK = "major:area:alarm:lock";


    /**
     * 签名
     */
    public static final String LICENSE_AUTH_USER_SIGN = "license:auth:user:sign:%s";


    /**
     * 资产redisKey
     */
    public static final String ASSET = "asset:%s";

    /**
     * 互联网资产redisKey
     */
    public static final String INTERNET_ASSET = "internet:asset:%s";

    /**
     * 漏洞导入redisKey
     */
    public static final String CLIENT_VULN_IMPORT = "client:vuln:%s:%s";

    /**
     * 重点关注问题redisKey
     */
    public static final String EVENT_ATTENTION = "event:attention:%s";

    /**
     * 应用系统redisKey
     */
    public static final String APP_SYSTEM = "app:system:%s";

    /**
     * 应用系统redisKey
     */
    public static final String CLIENT_VULN = "client:vuln:%s";

    /**
     * 研判知识库redisKey
     */
    public static final String KNOWLEDGE_JUDGE = "knowledge:judge:%s";

    /**
     * IOC情报库redisKey
     */
    public static final String INTELLGENCE_IOC = "intellgence:ioc:%s";

    /**
     * 知识库：告警处置建议redisKey
     */
    public static final String KNOWLEDGE_ALARM_HANDLE = "knowledge:alarm:handle:%s";

    /**
     * 漏洞情报redisKey
     */
    public static final String VULN_INFORMATION = "vuln:information:%s";

    /**
     * 应用系统-等保定级 redisKey
     */
    public static final String EQUAL_GRADE = "equal:grade:%s";

    /**
     * 应用系统-渗透测试 redisKey
     */
    public static final String PENETRATION_TEST = "penetration:test:%s";

    /**
     * 风险id
     */
    public static final String RISK_AUTO_ID = "risk:auto:id:%s";

    /**
     * 从漏扫原始数据中定时推送风险自动发现redis key
     */
    public static final String PUSH_RISK_AUTO = "push:risk:auto";

    /**
     * 推送告警研判过期，处置过期消息key
     */
    public static final String PUSH_ALARM_MESSAGE_AUTO = "push:alarm:message:auto";

    /**
     * 告警模型 redis key
     */
    public static final String EVENT_MODEL_KEY = "event:model:%s";

    /**
     * 定制解析 redis key
     */
    public static final String EVENT_CUSTOM_RULE_KEY = "event:custom:rule:%s";

    /**
     * 从漏扫重新打开数据中定时推送风险自动发现redis key
     */
    public static final String PUSH_REOPEN_ORIGINAL_RISK_AUTO = "push:reopen:original:risk:auto";

    /**
     * 占位符
     */
    public static final String PLACEHOLDER = ":%s";


    /**
     * 登录用户
     */
    public static final String LOGIN_TYPE_USER = "login:%s:%s";

    /**
     * 竹云
     */
    public static final String ZHU_YUN_LOGIN_TYPE_USER = "zhuyun:login:%s";

    /**
     * 拉黑token
     */
    public static final String BLANK_TOKEN = "blank:token:%s";

    /**
     * 风险全部下凡异步处理key
     */
    public static final String RISK_PUSH_ALL = "risk:push";

    /**
     * 回退软件许可证数量锁
     */
    public static final String BLACK_LICENSE = "black:license:lock";

    /**
     * 风险提交批量认证锁
     */
    public static final String RISK_BATCH_LOCK = "risk:batch:lock:%s";


    /**
     * 资产新增或者更新后 更新original数据
     */
    public static final String ASSET_UPDATE_ORIGINAL = "asset:update:original";

    /**
     * 变更的资产数据
     */
    public static final String ASSET_UPDATE_ALARM_REPORT = "asset:update:report";

    /**
     * 资产归属错误同步修改 漏洞、告警资产信息
     */
    public static final String ASSET_BELONG_WRONG_UPDATE = "asset:belong:wrong:update";

    /**
     * 告警转漏洞异步处理key
     */
    public static final String ALARM_CONVERT_LOOPHOLE = "alarm:convert:loophole";

    /**
     * 告警闭环管理，websocket通知
     */
    public static final String WEBSOCKET_ALARM_USER_ID = "websocket:alarm:%s";

    public static final String CRC_CLOUD_HOST_PORT_TOP5 = "crc:cloud:host:post:top5";

    /**
     * 创建风险自增id锁
     */
    public static final String CREATE_RISK_CODE_LOCK = "create:risk:code:lock";

    /**
     * 创建生成风险自动自增id锁
     */
    public static final String CREATE_RISK_AUTO_ID_LOCK = "create:risk:auto:id:lock";

    /**
     * 创建生成SCP重点关注情报ID锁
     */
    public static final String CREATE_MAJOR_ATTENTION_INFO_ID_LOCK = "create:major:attention:info:id:lock";

    /**
     * 创建生成告警自增id锁
     */
    public static final String CREATE_ALARM_ID_LOCK = "create:alarm:id:lock";

    /**
     * 创建生成告警HVV自增id锁
     */
    public static final String CREATE_ALARM_HVV_ID_LOCK = "create:alarm:hvv:id:lock";

    /**
     * 创建生成实战告警自增id锁
     */
    public static final String CREATE_ALARM_COMBAT_ID_LOCK = "create:alarm:combat:id:lock";

    /**
     * 创建生成告警策略自增id锁
     */
    public static final String CREATE_SEND_ID_LOCK = "create:send:id:lock";

    /**
     * 创建生成漏洞自增id锁
     */
    public static final String CREATE_VULN_ID_LOCK = "create:vuln:id:lock";

    /**
     * 创建生成SCP重点关注问题ID锁
     */
    public static final String CREATE_EVENT_ATTENTION_LIST_ID_LOCK = "create:alarm:eventAttention:id:lock";

    /**
     * 组织架构层级变更，更新资产与网段相关信息
     */
    public static final String ASSET_UPDATE_DEPT_NAME = "asset:update:dept:name";


    /**
     * 自定义解析规则id锁
     */
    public static final String CREATE_ANALYSIS_ID_LOCK = "asset:analysis:id:name";

    /**
     * 攻击链路图
     */
    public static final String ATTACK_LINK_CHART = "attack:link:%s:%s:%s";

    /**
     * 创建生成STP漏洞情报收集ID锁
     */
    public static final String CREATE_VULN_INFORMATION_ID_LOCK = "create:vuln:information:id:lock";


    /**
     * 巡检任务-生成批次号id
     */
    public static final String PATROL_ITEM = "patrol:item:%s";


    /**
     * 巡检任务-生成批次号id
     */
    public static final String PATROL_TASK_BATCH = "patrol:task:batch:%s";


    /**
     * 巡检任务-巡检任务-推送时间锁
     */
    public static final String PATROL_TASK_TIME_PUSH_LOCK = "patrol:task:time:push:lock";

    /**
     * 巡检任务-凌晨推送时间锁
     */
    public static final String PATROL_TASK_ZERO_POINT_PUSH_LOCK = "patrol:task:zero:point:push:lock";

    /**
     * 巡检任务-凌晨推送时间锁
     */
    public static final String ASSET_CHANGE_TREND_LOCK = "asset:change:trend:lock";

    /**
     * 巡检任务-推送倒计时
     */
    public static final String PATROL_TASK_PUSH_TIME = "patrol:task:push:time:%s";

    /**
     * 生成资产扩展属性资产编码
     */
    public static final String ASSET_DATA_REFRESH = "asset:data:refresh";

    /**
     * 生成资产扩展属性资产编码
     */
    public static final String ASSET_EXT_ASSET_NUMBER = "asset:ext:asset:num:%s";

    /**
     * 重点区域告警统计计算
     */
    public static final String IMPR_AREA_ALARM_LOCK = "impr:area:alarm:lock";
    /**
     * 各单位安全运营评分
     */
    public static final String IMPR_AREA_ALARM_ID = "impr:area:alarm:%s";

    /**
     * 漏洞待推送列表
     */
    public static final String VUL_WAI_PUSH_TABLE = "vul:wait:push:table:%s";

    /**
     * 漏洞闭环提醒邮件发送频率
     */
    public static final String VUL_LOOP_NEAR_NOTICE_TIME = "vul:loop:near:notice:time:%s";

    /**
     * 漏洞闭环超时提醒邮件发送频率
     */
    public static final String VUL_LOOP_OVER_NOTICE_TIME = "vul:loop:over:notice:time:%s";

    /**
     * 风险闭环提醒邮件发送频率
     */
    public static final String RISK_LOOP_NEAR_NOTICE_TIME = "risk:loop:near:notice:time:%s";

    /**
     * 风险闭环超时提醒邮件发送频率
     */
    public static final String RISK_LOOP_OVER_NOTICE_TIME = "risk:loop:over:notice:time:%s";

    /**
     * 应用系统redisKey
     */
    public static final String VUL_KNOWLEDGE = "vul:knowledge:%s";

    /**
     * 攻击链路-攻击链路分析-时间轴缓存
     */
    public static final String ATTACK_LINE_NEW_CHART = "attack:line:new:chart:%s";

    /**
     * ip威胁情报信息
     */
    public static final String IP_INTELLIGENCE_INFO = "ip:intelligence:info:%s";


    /**
     * 攻击面：域名管理redisKey
     */
    public static final String ASSET_ASM_DOMAIN = "asset:asm:domain:%s";


    /**
     * 攻击面-信息泄漏redisKey
     */
    public static final String ASSET_ASM_INFO_LEAK = "asset:asm:info:leak:%s";

    /**
     * 风险管理-风险导入redisKey
     */
    public static final String RISK_IMPORT = "risk:import:%s";

    /**
     * 系统管理-用户管理-导入用户角色-导入redisKey
     */
    public static final String SYS_USER_ROLE_IMPORT = "sys:user:role:import:%s";


    /**
     * 攻击面：互联网资产redisKey
     */
    public static final String INTERNET_ASSETS = "internet:assets:%s";

    /**
     * 端口映射redisKey
     */
    public static final String ASSET_ASM_PORT_JUDGE = "asset:asm:port:%s";

    /**
     * 创建生成SCP重点关注情报ID锁
     */
    public static final String CREATE_COMMAND_SCREEN_CONFIG_INIT_LOCK = "redis:command:screen:config:init";

    /**
     * 各单位安全运营评分
     */
    public static final String VISUAL_CHART_ID = "visual:chart:%s";

    /**
     * 创建生成SSP告警白名单ID锁
     */
    public static final String CREATE_ALARM_WHITE_LIST_ID_LOCK = "create:alarm:whiteList:id:lock";

    /**
     * 数据解析 redis key
     */
    public static final String LOG_PARSE_KEY = "log:parse:%s";

    /**
     * 极限问题-待推送列表
     */
    public static final String BASELINE_WAI_PUSH_TABLE = "baseline:wait:push:table:%s";

    /**
     * 基线问题导入redisKey
     */
    public static final String CLIENT_BASELINE_IMPORT = "client:baseline:%s";

    /**
     * 资产组件单个导入redisKey
     */
    public static final String ASSET_SOFT_WARE_SIGNAL_IMPORT = "asset:software:signal:%s:%s:%s";

    /**
     * 资产组件批量导入redisKey
     */
    public static final String ASSET_SOFT_WARE_BATCH_IMPORT = "asset:software:batch:%s:%s";

    /**
     * 法规标准redisKey
     */
    public static final String SUPER_VERSION_RULE_IMPORT = "super:version:rule:%s";

    /**
     * 法规标准条目redisKey
     */
    public static final String SUPER_VERSION_RULE_ITEM_IMPORT = "super:version:rule:item:%s";

    /**
     * 法规标准redisKey
     */
    public static final String SUPER_VERSION_CASE_IMPORT = "super:version:case:%s";

    /**
     * 同步关键漏洞redisKey
     */
    public static final String SYNC_KEY_VULN_LOCK = "sync:key:vuln:lock";

    /**
     * 同步关键漏洞redisKey
     */
    public static final String SOFTWARE_SERIAL_NUMBER_ITEM = "software:serial:number:%s";

    /**
     * 授权申请记录rediskey
     */
    public static final String SOFTWARE_SOFEWARE_APPLY_ITEM = "software:serial:apply:%s";

    /**
     * 授权申请记录rediskey
     */
    public static final String SOFTWARE_LICENSE_LOCK = "software:license:lock";


    /**
     * 授权申请记录rediskey
     */
    public static final String ASSET_APPLY_LOCK = "asset:apply:lock";

    public static final String ASSET_APPLY_MANCUL = "asset:apply:mancul";

    public static final String ASSET_RESOURCE_MANCUL = "resource:apply:mancul";

    public static final String ASSET_SOFTWARE_MANCUL = "softeware:apply:mancul";

    /**
     * 物联网资产导入
     */
    public static final String IOT_ASSET_UPLOAD = "iotAsset:upload:%s";
}


