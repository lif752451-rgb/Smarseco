package com.crc.common.utils.jfreechart;

import com.alibaba.fastjson.JSONArray;
import com.alibaba.fastjson.JSONObject;
import org.jfree.chart.ChartColor;
import org.jfree.chart.ChartFactory;
import org.jfree.chart.JFreeChart;
import org.jfree.chart.axis.CategoryAxis;
import org.jfree.chart.axis.CategoryLabelPositions;
import org.jfree.chart.axis.NumberAxis;
import org.jfree.chart.axis.ValueAxis;
import org.jfree.chart.block.BlockBorder;
import org.jfree.chart.labels.StandardCategoryItemLabelGenerator;
import org.jfree.chart.plot.CategoryPlot;
import org.jfree.chart.plot.PlotOrientation;
import org.jfree.chart.renderer.category.BarRenderer;
import org.jfree.chart.renderer.category.StandardBarPainter;
import org.jfree.chart.title.LegendTitle;
import org.jfree.chart.title.TextTitle;
import org.jfree.data.category.DefaultCategoryDataset;
import org.jfree.ui.RectangleEdge;

import java.awt.*;
import java.io.IOException;
import java.io.InputStream;
import java.util.Iterator;
import java.util.Map;

public class JFreeBarChart  implements JFreeCommonChart {

    public JFreeChart createChart(JSONArray resultData, Map<String, Object> jsonProperty){
        return createBarChart(resultData, jsonProperty);
    }

    /**
     * [{"COUNT":2,"dept":"205","child":"未完成","NAME":"润联科技"},{"COUNT":206,"dept":"205","child":"已完成","NAME":"润联科技"},{"COUNT":1,"dept":"208","child":"已完成","NAME":"华润万家"},{"COUNT":1,"dept":"211","child":"已完成","NAME":"华润三九"},{"COUNT":4,"dept":"241","child":"未完成","NAME":"华润医药"},{"COUNT":7,"dept":"241","child":"已完成","NAME":"华润医药"},{"COUNT":14,"dept":"253","child":"未完成","NAME":"华润微电子"},{"COUNT":19,"dept":"253","child":"已完成","NAME":"华润微电子"},{"COUNT":16,"dept":"256","child":"已完成","NAME":"华润水泥"},{"COUNT":1,"dept":"280","child":"已完成","NAME":"华润置地"},{"COUNT":2,"dept":"314","child":"未完成","NAME":"华润江中"}]
     * {"legendDataColor":{"已完成":"#71a3f3","未完成":"#ffc836"}}
     * @param resultData
     * @param jsonProperty
     * @return
     */
    private JFreeChart createBarChart(JSONArray resultData, Map<String, Object> jsonProperty){
        if(resultData != null && resultData.size() > 0){
            //X轴和Y轴翻转
            PlotOrientation orientation = PlotOrientation.VERTICAL;
            if(jsonProperty.containsKey("axisTransform")){
                orientation = PlotOrientation.HORIZONTAL;
            }
            //标题
            String title = "";
            if(jsonProperty.containsKey("title")){
                title = (String) jsonProperty.get("title");
            }
            //组装数据
            DefaultCategoryDataset data = new DefaultCategoryDataset();
            if(resultData.getJSONObject(0).containsKey("child") ||resultData.getJSONObject(0).containsKey("CHILD")) {
                resultData.stream().forEach(object ->
                    data.setValue(((JSONObject) object).containsKey("COUNT") ? ((JSONObject) object).getDouble("COUNT") : ((JSONObject) object).getDouble("count"),
                                ((JSONObject) object).containsKey("CHILD") ? ((JSONObject) object).getString("CHILD") : ((JSONObject) object).getString("child"),
                                ((JSONObject) object).containsKey("NAME") ? ((JSONObject) object).getString("NAME") : ((JSONObject) object).getString("name"))
                );
            }else{
                resultData.stream().forEach(object ->
                    data.setValue(((JSONObject) object).containsKey("COUNT") ? ((JSONObject) object).getDouble("COUNT") : ((JSONObject) object).getDouble("count"),
                                jsonProperty.containsKey("legendData") ? (String) jsonProperty.get("legendData") : "",
                                ((JSONObject) object).containsKey("NAME") ? ((JSONObject) object).getString("NAME") : ((JSONObject) object).getString("name"))
                );
            }
            //生成图表
            JFreeChart chart = ChartFactory.createBarChart(title, "统计单位", "数量", data, orientation, true, true, true);
            chart.setBorderVisible(false);
            //报表主配置
            CategoryPlot plot = (CategoryPlot) chart.getCategoryPlot();
            plot.setBackgroundPaint(ChartColor.WHITE);
            plot.setOutlinePaint(null);
            plot.setRangeGridlinePaint(Color.decode("#e6ebf3"));
            plot.setRangeGridlinesVisible(true);
            BarRenderer renderer = (BarRenderer) plot.getRenderer();
            //颜色
            if(jsonProperty.containsKey("legendDataColor")){
                if(resultData.getJSONObject(0).containsKey("child") ||resultData.getJSONObject(0).containsKey("CHILD")){
                    JSONObject color = (JSONObject) jsonProperty.get("legendDataColor");
                    Iterator iter = color.entrySet().iterator();
                    int index = 0;
                    while (iter.hasNext()) {
                        Map.Entry entry = (Map.Entry) iter.next();
                        renderer.setSeriesPaint(index, Color.decode(entry.getValue().toString()));
                        renderer.setSeriesOutlinePaint(index, Color.decode(entry.getValue().toString()));
                        index++;
                    }
                }else{
                    String color = (String) jsonProperty.get("legendDataColor");
                    renderer.setSeriesPaint(0, Color.decode(color));
                    renderer.setSeriesOutlinePaint(0, Color.decode(color));
                }
            }
            renderer.setBaseItemLabelGenerator(new StandardCategoryItemLabelGenerator());
            renderer.setBaseItemLabelsVisible(true);
            renderer.setBaseItemLabelPaint(Color.decode("#575757"));
            renderer.setShadowVisible(false);
            renderer.setBarPainter(new StandardBarPainter());
            renderer.setItemMargin(0.1);
            renderer.setMaximumBarWidth(0.02);
            plot.setRenderer(renderer);
            //设置没有小数点
            if(jsonProperty.containsKey("dataNumber")){
                NumberAxis numberaxis = (NumberAxis)plot.getRangeAxis();
                numberaxis.setStandardTickUnits(NumberAxis.createIntegerTickUnits());
            }
            chart.getRenderingHints().put(RenderingHints.KEY_TEXT_ANTIALIASING, RenderingHints.VALUE_TEXT_ANTIALIAS_OFF);
            chart.getLegend().setItemFont(new Font("宋体", Font.PLAIN, 14));
            //X轴配置
            CategoryAxis domainAxis = plot.getDomainAxis();
//            domainAxis.setTickLabelFont(new Font("sans-serif", Font.PLAIN, 14));//设置x轴坐标上的字体
            domainAxis.setTickLabelFont(createFont(14));//设置x轴坐标上的字体
            domainAxis.setTickLabelsVisible(true);
//            domainAxis.setLabelFont(new Font("黑体", Font.PLAIN, 14));//设置x轴上的标题的字体
            domainAxis.setLabelFont(createFont(14));//设置x轴上的标题的字体
            domainAxis.setCategoryLabelPositions(CategoryLabelPositions.UP_45);
            domainAxis.setMaximumCategoryLabelWidthRatio(0.6f);

            //Y轴配置
            ValueAxis valueAxis = plot.getRangeAxis();//(柱状图的y轴)
            valueAxis.setTickLabelFont(createFont(14));//设置y轴坐标上的字体
            valueAxis.setLabelFont(createFont(14));//设置y轴坐标上的标题的字体
            //实例配置
            LegendTitle legend = chart.getLegend();
            legend.setPosition(RectangleEdge.TOP);
            legend.setFrame(new BlockBorder(Color.white));
            legend.setBackgroundPaint(null);
            legend.setItemFont(createFont(14));
            //标题样式配置
            TextTitle textTitle = chart.getTitle();
            textTitle.setFont(createFont(16));
            return chart;
        }else{
            return null;
        }
    }

    /**
     * 自定义字体
     * @return
     * @throws IOException
     * @throws FontFormatException
     */
    public Font createFont(float size){
        String fontPath = "static/" + "simsun.ttf";
        InputStream is = this.getClass().getClassLoader().getResourceAsStream(fontPath);
        Font ft = null;
        try {
            ft = Font.createFont(Font.TRUETYPE_FONT, is);
        } catch (FontFormatException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }
        ft = ft.deriveFont(Font.PLAIN,size);
        return ft;
    }
}
