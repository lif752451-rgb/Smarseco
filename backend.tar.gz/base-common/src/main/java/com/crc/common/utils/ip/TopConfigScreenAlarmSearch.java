package com.crc.common.utils.ip;

import java.util.List;

import com.crc.common.model.request.PageRequest;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

/**
 * @author fuzhuangzhi
 * @title AssetSegementRequest
 * @date 2023/6/15 18:59
 * @description TODO
 */
@Data
@ApiModel(value = "资产网段请求")
public class TopConfigScreenAlarmSearch extends PageRequest {

    /**
     * 开始时间
     */
    @ApiModelProperty(value = "告警开始时间")
    private String startTime;

    /**
     * 结束时间
     */
    @ApiModelProperty(value = "告警结束时间")
    private String endTime;

    /**
     * 配置id
     */
    @ApiModelProperty(value = "配置id", required = true)
    private Long topId;

    /**
     * topIds
     */
    @ApiModelProperty(value = "topIds")
    private List<Long> topIds;

    /**
     * 网段起始数据
     */
    private List<AssetSegementIp> segementIpList;
}
