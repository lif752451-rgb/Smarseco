package com.crc.common.utils;

import lombok.extern.slf4j.Slf4j;
import org.springframework.web.context.request.RequestContextHolder;
import org.springframework.web.context.request.ServletRequestAttributes;

import javax.servlet.ServletContext;
import javax.servlet.http.HttpServletRequest;
import java.io.File;

/**
 * 创建临时附件目录
 */
@Slf4j
public class TmpFileDirCheck {
    private static final TmpFileDirCheck myObject = new TmpFileDirCheck();

    private TmpFileDirCheck() {
    }

    public static TmpFileDirCheck getInstance() {
        return myObject;
    }


    public void changeTempFileDir() {
        try {
            HttpServletRequest request = getHttpServletRequest();
            if (request == null) {
                log.warn("未获取到用户回话");
                return;
            }
            changeTempFileDir(request);
        } catch (Exception e) {
            log.error(e.getMessage(), e);
        }
    }

    public void changeTempFileDir(HttpServletRequest request) {
        try {
            ServletContext servletContext = request.getSession().getServletContext();
            String temporaryDirectory = servletContext.getAttribute("javax.servlet.context.tempdir").toString();
            File tmpFile = new File(temporaryDirectory);
            if (!tmpFile.exists()) {
                log.info("目录被删除重新创建:" + temporaryDirectory);
                tmpFile.mkdirs();
            }
        } catch (Exception e) {
            log.error(e.getMessage(), e);
        }
    }

    /**
     * 获取request
     *
     * @return
     */
    private HttpServletRequest getHttpServletRequest() {
        ServletRequestAttributes attr = ((ServletRequestAttributes) RequestContextHolder.getRequestAttributes());
        if (attr == null) {
            return null;
        }
        return attr.getRequest();
    }
}
