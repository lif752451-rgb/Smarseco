package com.crc.common.model.dto;

import lombok.Data;

/**
 * @author jixiangqi
 * @date 2023/9/13
 */
@Data
public class MySqlInfoDTO {
    /**
     * 值类型
     */
    private String name;

    /**
     * 值
     */
    private Long value;

}
