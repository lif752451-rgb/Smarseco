package com.crc.common.easyexcel.style;

import com.alibaba.excel.metadata.Head;
import com.alibaba.excel.write.style.HorizontalCellStyleStrategy;
import com.crc.common.utils.poi.ExcelUtil;
import org.apache.poi.ss.usermodel.*;

/**
 * 导出excel格式策略
 *
 * @Author fuzhuangzhi
 * @Date 2022/11/2 17:33
 * @Version 1.0
 **/
public class CustomCellWriteHandler extends HorizontalCellStyleStrategy {

    @Override
    protected void setHeadCellStyle(Cell cell, Head head, Integer relativeRowIndex) {
        Workbook workbook = cell.getSheet().getWorkbook();
        cell.setCellStyle(ExcelUtil.getHeaderStyle(workbook));
    }

    @Override
    protected void setContentCellStyle(Cell cell, Head head, Integer relativeRowIndex) {
        Workbook workbook = cell.getSheet().getWorkbook();
        cell.setCellStyle(ExcelUtil.getDataStyle(workbook));
    }

}
