package com.crc.common.easyexcel.utils;

import cn.hutool.core.collection.CollUtil;
import com.alibaba.excel.EasyExcel;
import com.alibaba.excel.ExcelReader;
import com.alibaba.excel.ExcelWriter;
import com.alibaba.excel.annotation.ExcelProperty;
import com.alibaba.excel.read.builder.ExcelReaderBuilder;
import com.alibaba.excel.read.metadata.ReadSheet;
import com.alibaba.excel.support.ExcelTypeEnum;
import com.alibaba.excel.write.builder.ExcelWriterBuilder;
import com.alibaba.excel.write.handler.WriteHandler;
import com.alibaba.excel.write.metadata.WriteSheet;
import com.alibaba.excel.write.metadata.WriteTable;
import com.alibaba.excel.write.metadata.style.WriteCellStyle;
import com.alibaba.excel.write.metadata.style.WriteFont;
import com.alibaba.excel.write.style.HorizontalCellStyleStrategy;
import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONArray;
import com.alibaba.fastjson.JSONObject;
import com.crc.common.constant.Constants;
import com.crc.common.easyexcel.listener.CheckTemplateListener;
import com.crc.common.easyexcel.listener.ProductCellWriteHandler;
import com.crc.common.easyexcel.listener.SortRowWriteHandler;
import com.crc.common.easyexcel.style.CustomColumnColorStrategy;
import com.crc.common.easyexcel.style.CustomHiddenRowStyleStrategy;
import com.crc.common.exception.CustomException;
import com.crc.common.model.enums.FileTypeEnum;
import com.crc.common.model.enums.ResponseEnum;
import com.crc.common.model.request.EasyExcelReq;
import com.crc.common.utils.DateUtils;
import com.crc.common.utils.JsonUtils;
import com.crc.common.utils.StringUtils;
import com.crc.common.utils.UrlEncoderUtils;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.collections4.CollectionUtils;
import org.apache.commons.collections4.MapUtils;
import org.apache.commons.io.IOUtils;
import org.apache.poi.ss.usermodel.FillPatternType;
import org.apache.poi.ss.usermodel.HorizontalAlignment;
import org.apache.poi.ss.usermodel.IndexedColors;
import org.apache.poi.ss.usermodel.VerticalAlignment;
import org.springframework.web.multipart.MultipartFile;

import javax.servlet.ServletOutputStream;
import javax.servlet.http.HttpServletResponse;
import java.io.*;
import java.lang.annotation.Annotation;
import java.lang.reflect.Field;
import java.lang.reflect.InvocationHandler;
import java.lang.reflect.Proxy;
import java.net.URLEncoder;
import java.util.*;
import java.util.stream.Collectors;

/**
 * easyexcel 导出工具类
 *
 * @author shufengfeng
 * @date 2022/9/6 10:13
 */
@Slf4j
public class EasyExcelUtils {

    public static final String SHEET1 = "sheet1";

    public static final String ERROR_MSG_FIELDS = "errorMsg";

    /**
     * 判断导出字段是否存在
     *
     * @param fields 字段名
     * @param req    入参
     * @return true 存在 false 不存在
     */
    public static Boolean isExportFields(String fields, EasyExcelReq req) {
        List<JSONObject> dictList = req.getDictList();
        JSONArray exportAttributeJson = req.getExportAttributeJson();
        if (Objects.isNull(exportAttributeJson)) {
            return Boolean.TRUE;
        }
        // 过滤自定导出字段
        List<String> exportAtt = JSONArray.parseArray(exportAttributeJson.toJSONString(), String.class);
        return dictList.stream().filter(dict -> exportAtt.contains(JsonUtils.getStr(dict, "dictLabel")))
                .anyMatch(dict -> JsonUtils.getStr(dict, "dictValue").equals(fields));
    }

    /**
     * 导出字典配置导出
     *
     * @param response HttpServletResponse
     * @param data     导出内容
     * @param target   导出模板类
     * @param req      EasyExcelReq
     * @throws IOException Exception
     */
    public static void dictExport(HttpServletResponse response, List<?> data, Class<?> target, EasyExcelReq req)
            throws Exception {
        setHead(response, exportFileName(req.getFileName()), data.size());
        // 自定义导出配置转换
        getIncludeColumnFieldNames(target, req);
        ExcelWriterBuilder writerBuilder =
                EasyExcel.write(response.getOutputStream(), target).registerWriteHandler(getHorizontalCellStyleStrategy());
        // 自定义排除列
        if (CollUtil.isNotEmpty(req.getExcludeColumnFieldNames())) {
            writerBuilder.excludeColumnFieldNames(req.getExcludeColumnFieldNames());
        }
        // 自定义输出列
        if (CollUtil.isNotEmpty(req.getIncludeColumnFieldNames())) {
            writerBuilder.includeColumnFieldNames(req.getIncludeColumnFieldNames())
                    .registerWriteHandler(new SortRowWriteHandler());
        }
        writerBuilder.sheet(req.getSheetName()).doWrite(data);
    }

    /**
     * 导出字典配置导出
     *
     * @param response       HttpServletResponse
     * @param data           导出内容
     * @param target         导出模板类
     * @param req            EasyExcelReq
     * @param mergeCellIndex 需要自动合并的列，从0开始算第一列
     * @throws IOException Exception
     */
    public static void dictExport(HttpServletResponse response, List<?> data, Class<?> target, EasyExcelReq req,
                                  int... mergeCellIndex) throws Exception {
        setHead(response, exportFileName(req.getFileName()), data.size());
        getIncludeColumnFieldNames(target, req);
        ExcelWriterBuilder writerBuilder =
                EasyExcel.write(response.getOutputStream(), target).registerWriteHandler(getHorizontalCellStyleStrategy())
                        .registerWriteHandler(new MergeStrategy(data.size(), mergeCellIndex));
        // 自定义排除列
        if (CollUtil.isNotEmpty(req.getExcludeColumnFieldNames())) {
            writerBuilder.excludeColumnFieldNames(req.getExcludeColumnFieldNames());
        }
        // 自定义输出列
        if (CollUtil.isNotEmpty(req.getIncludeColumnFieldNames())) {
            writerBuilder.includeColumnFieldNames(req.getIncludeColumnFieldNames())
                    .registerWriteHandler(new SortRowWriteHandler());
        }
        writerBuilder.sheet(req.getSheetName()).doWrite(data);
    }

    /**
     * 多table导出
     *
     * @param response 响应流
     * @param dataList 多个数据集的集合
     * @param fileName 文件名
     * @throws Exception
     */
    public static void exportByTable(HttpServletResponse response, List<List<?>> dataList, String fileName)
            throws Exception {
        if (CollUtil.isEmpty(dataList)) {
            throw new CustomException("数据为空，无须导出");
        }
        setHead(response, exportFileName(fileName));
        try (ServletOutputStream out = response.getOutputStream(); ExcelWriter excelWriter =
                EasyExcel.write(out).registerWriteHandler(getHorizontalCellStyleStrategy()).build()) {
            WriteSheet writeSheet = EasyExcel.writerSheet(SHEET1).build();
            for (int i = 0; i < dataList.size(); i++) {
                List<?> targetList = dataList.get(i);
                if (CollUtil.isNotEmpty(targetList)) {
                    WriteTable writeTable =
                            EasyExcel.writerTable(i).head(getActualType(targetList)).needHead(true).build();
                    excelWriter.write(JSON.parseArray(JSON.toJSONString(targetList), getActualType(targetList)),
                            writeSheet, writeTable);
                }
            }
            excelWriter.finish();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    public static Class<?> getActualType(List list) {
        Object obj = list.get(0);
        return obj.getClass();
    }

    public static void getIncludeColumnFieldNames(Class<?> target, EasyExcelReq req) throws Exception {
        List<JSONObject> dictList = req.getDictList();
        JSONArray exportAttributeJson = req.getExportAttributeJson();
        if (CollUtil.isEmpty(dictList)) {
            return;
        }
        Field[] fields = target.getDeclaredFields();
        // 修改导出表头名称
        for (Field field : fields) {
            JSONObject dictData = dictList.stream()
                    .filter(dict -> JsonUtils.getStr(dict, "dictValue").equals(field.getName())).findFirst().orElse(null);
            if (field.isAnnotationPresent(ExcelProperty.class)) {
                ExcelProperty excel = field.getAnnotation(ExcelProperty.class);
                InvocationHandler handler = Proxy.getInvocationHandler(excel);
                Field memberValues = handler.getClass().getDeclaredField("memberValues");
                memberValues.setAccessible(true);
                Map<String, Object> obj = (Map<String, Object>) memberValues.get(handler);
                String[] value;
                if (Objects.isNull(dictData)) {
                    value = excel.value();
                } else {
                    value = new String[]{JsonUtils.getStr(dictData, "dictLabel")};
                }
                obj.put("value", value);
            }
        }
        List<String> exportList;
        if (Objects.isNull(exportAttributeJson)) {
            exportList =
                    dictList.stream().map(dict -> JsonUtils.getStr(dict, "dictValue")).collect(Collectors.toList());
        } else {
            // 过滤自定导出字段
            List<String> exportAtt = JSONArray.parseArray(exportAttributeJson.toJSONString(), String.class);
            exportList = dictList.stream().filter(dict -> exportAtt.contains(JsonUtils.getStr(dict, "dictLabel")))
                    .map(dict -> JsonUtils.getStr(dict, "dictValue")).collect(Collectors.toList());
        }
        List<String> fieldNameList = Arrays.stream(fields).map(Field::getName).collect(Collectors.toList());
        req.setIncludeColumnFieldNames(exportList.stream().filter(fieldNameList::contains).collect(Collectors.toList()));
    }

    /**
     * 导出文件
     *
     * @param response  请求相应
     * @param fileName  文件名称
     * @param sheetName 表名
     * @param data      导出数据
     * @param target    导出数据类型
     * @throws IOException
     */
    public static void export(HttpServletResponse response, String fileName, String sheetName, List<?> data,
                              Class<?> target) throws IOException {
        setHead(response, fileName, data.size());
        final ExcelWriter writer =
                EasyExcel.write(response.getOutputStream(), target).registerWriteHandler(getHorizontalCellStyleStrategy())
                        .registerWriteHandler(new CustomHiddenRowStyleStrategy(0, 15)).build();
        final WriteSheet sheet = EasyExcel.writerSheet(sheetName).build();
        writer.write(data, sheet);
        writer.finish();
    }

    /**
     * 导出文件
     *
     * @param response                请求相应
     * @param fileName                文件名称
     * @param sheetName               表名
     * @param data                    导出数据
     * @param target                  导出数据类型
     * @param includeColumnFieldNames 导出字段
     * @throws IOException
     */
    public static void export(HttpServletResponse response, String fileName, String sheetName, List<?> data,
                              Class<?> target, Collection<String> includeColumnFieldNames) throws IOException {
        setHead(response, fileName, data.size());
        final ExcelWriter writer =
                EasyExcel.write(response.getOutputStream(), target).registerWriteHandler(getHorizontalCellStyleStrategy())
                        .registerWriteHandler(new CustomHiddenRowStyleStrategy(0, 15))
                        .includeColumnFieldNames(includeColumnFieldNames).build();
        final WriteSheet sheet = EasyExcel.writerSheet(sheetName).build();
        writer.write(data, sheet);
        writer.finish();
    }

    /**
     * 导出文件
     *
     * @param response        请求相应
     * @param fileName        文件名称
     * @param sheetName       表名
     * @param data            导出数据
     * @param target          导出数据类型
     * @param exportAttribute 导出字段
     * @throws IOException
     */
    public static void exportByExportAttribute(HttpServletResponse response, String fileName, String sheetName,
                                               List<?> data, Class<?> target, List<String> exportAttribute) throws IOException {
        setHead(response, fileName, data.size());
        final ExcelWriter writer =
                EasyExcel.write(response.getOutputStream(), target).registerWriteHandler(getHorizontalCellStyleStrategy())
                        .registerWriteHandler(new CustomHiddenRowStyleStrategy(0, 15))
                        .includeColumnFieldNames(getIncludeColumnFieldNames(exportAttribute, target)).build();
        final WriteSheet sheet = EasyExcel.writerSheet(sheetName).build();
        writer.write(data, sheet);
        writer.finish();
    }

    /**
     * 导出文件
     *
     * @param response     请求相应
     * @param fileName     文件名称
     * @param data         导出数据
     * @param target       导出数据类型
     * @param writeHandler 写入数据处理器
     * @throws IOException
     */
    public static void export(HttpServletResponse response, String fileName, String sheetName, List data, Class target,
                              WriteHandler writeHandler) throws IOException {
        setHead(response, fileName, data.size());
        final ExcelWriter writer = EasyExcel.write(response.getOutputStream(), target)
                .registerWriteHandler(writeHandler)
                .registerWriteHandler(getHorizontalCellStyleStrategy())
                .inMemory(true).build();
        final WriteSheet sheet = EasyExcel.writerSheet(sheetName).build();
        writer.write(data, sheet);
        writer.finish();
    }

    /**
     * 导出文件
     *
     * @param response                请求相应
     * @param fileName                文件名称
     * @param data                    导出数据
     * @param target                  导出数据类型
     * @param writeHandler            写入数据处理器
     * @param excludeColumnFieldNames 排除字段
     * @throws IOException
     */
    public static void export(HttpServletResponse response, String fileName, String sheetName, List data, Class target,
                              WriteHandler writeHandler, Collection<String> excludeColumnFieldNames) throws IOException {
        setHead(response, fileName, data.size());
        final ExcelWriter writer = EasyExcel.write(response.getOutputStream(), target)
                .registerWriteHandler(writeHandler).excludeColumnFieldNames(excludeColumnFieldNames).inMemory(true).build();
        final WriteSheet sheet = EasyExcel.writerSheet(sheetName).build();
        writer.write(data, sheet);
        writer.finish();
    }

    public static void setHead(HttpServletResponse response, String fileName, Integer dataSize)
            throws UnsupportedEncodingException {
        response.setHeader("content-Type", "application/vnd.ms-excel");// application/octet-stream
        response.setCharacterEncoding("utf-8");
        if (!fileName.endsWith(ExcelTypeEnum.XLSX.getValue())) {
            fileName += ExcelTypeEnum.XLSX.getValue();
        }
        if (UrlEncoderUtils.hasUrlEncoded(fileName)) {
            fileName = URLEncoder.encode(fileName, Constants.UTF8);
        }
        response.setHeader("Content-Disposition", "attachment;filename=" + fileName);
        response.setHeader("size", dataSize.toString());
    }

    public static void setHead(HttpServletResponse response, String fileName) throws UnsupportedEncodingException {
        response.setHeader("content-Type", "application/vnd.ms-excel");// application/octet-stream
        response.setCharacterEncoding("utf-8");
        if (!fileName.endsWith(ExcelTypeEnum.XLSX.getValue())) {
            fileName += ExcelTypeEnum.XLSX.getValue();
        }
        if (UrlEncoderUtils.hasUrlEncoded(fileName)) {
            fileName = URLEncoder.encode(fileName, Constants.UTF8);
        }
        response.setHeader("Content-Disposition", "attachment;filename=" + fileName);
    }

    /**
     * 导出文件
     *
     * @param response
     * @param filePath
     * @throws IOException
     */
    public static void export(HttpServletResponse response, String filePath, String fileName) throws IOException {
        BufferedInputStream bis = null;
        BufferedOutputStream bos = null;
        try {
            response.setContentType("application/vnd.openxmlformats-officedocument.spreadsheetml.sheet");
            response.setCharacterEncoding("utf-8");
            fileName = URLEncoder.encode(fileName, "UTF-8").replaceAll("\\+", "%20");
            if (fileName.endsWith(".xlsx")) {
                response.setHeader("Content-disposition", "attachment;filename*=utf-8''" + fileName);
            } else {
                response.setHeader("Content-disposition", "attachment;filename*=utf-8''" + fileName + ".xlsx");
            }
            FileInputStream fis = new FileInputStream(new File(filePath));
            bis = new BufferedInputStream(fis);
            bos = new BufferedOutputStream(response.getOutputStream());
            byte[] buffer = new byte[2048];
            int len;
            while ((len = bis.read(buffer, 0, buffer.length)) != -1) {
                bos.write(buffer, 0, len);
                bos.flush();
            }
        } catch (Exception e) {
            throw e;
        } finally {
            IOUtils.closeQuietly(bis);
            IOUtils.closeQuietly(bos);
        }

    }

    /**
     * 根据导出字段来获取属性名称
     *
     * @param exportAttribute 导出字段类型
     * @param target          目标类
     * @return
     */
    public static List<String> getIncludeColumnFieldNames(List<String> exportAttribute, Class<?> target) {
        List<String> includeColumnFieldNames = new ArrayList<>(exportAttribute.size());
        Field[] fields = target.getDeclaredFields();
        Map<String, String> map = new HashMap<>(fields.length);
        for (Field field : fields) {
            if (null != field.getAnnotations() && field.getAnnotations().length > 0) {
                Optional<Annotation> optional = Arrays.stream(field.getAnnotations())
                        .filter(annotation -> annotation.annotationType() == ExcelProperty.class).findFirst();
                if (!Optional.empty().equals(optional)) {
                    ExcelProperty excelProperty = field.getAnnotation(ExcelProperty.class);
                    if (excelProperty.value().length > 0) {
                        map.put(excelProperty.value()[0], field.getName());
                    }
                }
            }
        }
        if (!CollUtil.containsAll(map.keySet(), exportAttribute)) {
            throw new CustomException("导出字段设置错误");
        }
        Collection<String> keys = CollUtil.intersection(map.keySet(), exportAttribute);
        for (String key : keys) {
            includeColumnFieldNames.add(map.get(key));
        }
        return includeColumnFieldNames;
    }

    /**
     * 导出公共样式
     *
     * @return HorizontalCellStyleStrategy
     */
    public static HorizontalCellStyleStrategy getHorizontalCellStyleStrategy() {
        // 头的字体格式
        WriteFont headWriteFont = new WriteFont();
        headWriteFont.setBold(true);
        headWriteFont.setFontName("Arial");
        headWriteFont.setFontHeightInPoints((short) 10);
        headWriteFont.setColor(IndexedColors.WHITE.getIndex());
        // 头的策略
        WriteCellStyle headWriteCellStyle = new WriteCellStyle();
        // 背景设置为灰色
        headWriteCellStyle.setFillForegroundColor(IndexedColors.GREY_80_PERCENT.getIndex());
        headWriteCellStyle.setFillPatternType(FillPatternType.SOLID_FOREGROUND);
        // 垂直对其方式
        headWriteCellStyle.setHorizontalAlignment(HorizontalAlignment.LEFT);
        // 水平对其方式
        headWriteCellStyle.setVerticalAlignment(VerticalAlignment.CENTER);
        // 自动换行
        headWriteCellStyle.setWrapped(true);
        headWriteCellStyle.setWriteFont(headWriteFont);

        // 内容的策略
        WriteCellStyle contentWriteCellStyle = new WriteCellStyle();
        // 这里需要指定 FillPatternType 为FillPatternType.SOLID_FOREGROUND 不然无法显示背景颜色.头默认了 FillPatternType所以可以不指定
        // contentWriteCellStyle.setFillPatternType(FillPatternType.SOLID_FOREGROUND);
        // 文字
        WriteFont contentWriteFont = new WriteFont();
        // 字体大小
        contentWriteFont.setFontHeightInPoints((short) 10);
        contentWriteFont.setFontName("Arial");
        contentWriteCellStyle.setWriteFont(contentWriteFont);
        // 垂直对其方式
        contentWriteCellStyle.setHorizontalAlignment(HorizontalAlignment.LEFT);
        // 水平对其方式
        contentWriteCellStyle.setVerticalAlignment(VerticalAlignment.CENTER);
        // 内容自动换行
        // contentWriteCellStyle.setWrapped(true);
        // 这个策略是 头是头的样式 内容是内容的样式 其他的策略可以自己实现
        return new HorizontalCellStyleStrategy(headWriteCellStyle, contentWriteCellStyle);
    }

    /**
     * 生成导出文件名
     *
     * @return String
     */
    public static String exportFileName(String fileName) throws UnsupportedEncodingException {
        if (StringUtils.isEmpty(fileName)) {
            throw new CustomException(ResponseEnum.EXPORT_PARAM_ERROR.getMsg(),
                    ResponseEnum.EXPORT_PARAM_ERROR.getCode());
        }
        fileName += Constants.Symbol.UNDERLINE + DateUtils.dateTimeNow() + Constants.EXCEL_XLSX;
        return URLEncoder.encode(fileName, Constants.UTF8);
    }

    /**
     * 导入
     *
     * @param file      MultipartFile
     * @param clazz     导入数据类型
     * @param sheetName 表格名称
     * @param <T>       导入数据类型
     * @return List
     * @throws IOException Exception
     */
    public static <T> List<T> read(MultipartFile file, Class<T> clazz, String sheetName) throws IOException {
        return read(file, CheckTemplateListener.build(clazz), clazz, sheetName);
    }

    /**
     * 导入
     *
     * @param file         MultipartFile
     * @param readListener 自定义验证模板
     * @param clazz        导入数据类型
     * @param sheetName    表格名称
     * @param <T>          导入数据类型
     * @return List
     * @throws IOException Exception
     */
    public static <T> List<T> read(MultipartFile file, CheckTemplateListener<T> readListener, Class<T> clazz,
                                   String sheetName) throws IOException {
        ExcelReader excelReader = null;
        List<T> dataList;
        try {
            String fileName = file.getOriginalFilename();
            if (StringUtils.isBlank(fileName) || !fileName.endsWith(FileTypeEnum.EXCEL.getName())) {
                throw new CustomException(ResponseEnum.FILE_TYPE_NOT_MATCH.getMsg());
            }
            ExcelReaderBuilder readerBuilder = EasyExcel.read(file.getInputStream()).head(clazz);
            // 验证模板
            readerBuilder.registerReadListener(readListener);
            excelReader = readerBuilder.build();

            // 获取sheet集合
            List<ReadSheet> sheets = excelReader.excelExecutor().sheetList();
            // 判断是否存在对应sheet名称sheet 存在取对应sheet 不存在默认取第一个sheet
            boolean checkTemplate = sheets.stream().anyMatch(sheet -> sheetName.equals(sheet.getSheetName()));
            ReadSheet readSheet =
                    checkTemplate ? EasyExcel.readSheet(sheetName).build() : EasyExcel.readSheet(0).build();
            excelReader.read(readSheet);
            dataList = readListener.getList();
        } catch (Exception e) {
            log.error("EasyExcelUtils read 读取文件公共方法报错{}", e.getMessage(), e);
            CustomException ce = new CustomException(ResponseEnum.WORK_TYPE_ERROR);
            if (e instanceof CustomException) {
                ce = (CustomException) e;
            }
            throw ce;
        } finally {
            if (Objects.nonNull(excelReader)) {
                excelReader.finish();
            }
            IOUtils.closeQuietly(excelReader);
        }
        if (CollectionUtils.isEmpty(dataList)) {
            throw new CustomException(ResponseEnum.UPLOAD_FILE_IS_NULL.getMsg());
        }
        return dataList;
    }

    /**
     * 下载导入模板
     *
     * @param response 请求相应
     * @param req      导出导入公共类
     * @throws IOException Exception
     */
    public static void excelTemplate(HttpServletResponse response, EasyExcelReq req) throws IOException {
        excelTemplate(response, null, req);
    }

    /**
     * 下载导入模板
     *
     * @param response 请求相应
     * @param target   导出数据类型
     * @param req      导出导入公共类
     * @throws IOException Exception
     */
    public static void excelTemplate(HttpServletResponse response, Class<?> target, EasyExcelReq req)
            throws IOException {
        setHead(response, req.getFileName(), 0);
        ExcelWriterBuilder writerBuilder;
        if (Objects.isNull(target)) {
            writerBuilder = EasyExcel.write(response.getOutputStream());
        } else {
            writerBuilder = EasyExcel.write(response.getOutputStream(), target);
            // 自定义排除列
            if (CollUtil.isNotEmpty(req.getExcludeColumnFieldNames())) {
                writerBuilder.excludeColumnFieldNames(req.getExcludeColumnFieldNames());
            }
            // 自定义输出列
            if (CollUtil.isNotEmpty(req.getIncludeColumnFieldNames())) {
                writerBuilder.includeColumnFieldNames(req.getIncludeColumnFieldNames())
                        .registerWriteHandler(new SortRowWriteHandler());
            }
        }
        // 设置导入模板
        writerBuilder.withTemplate(req.getTempInputStream());
        // 公共样式
        writerBuilder.registerWriteHandler(getHorizontalCellStyleStrategy());
        // 设置下拉框值
        if (MapUtils.isNotEmpty(req.getHeadNameMackMap())) {
            writerBuilder.registerWriteHandler(ProductCellWriteHandler.headNameBuild(req.getHeadNameMackMap()));
        }
        if (MapUtils.isNotEmpty(req.getMackMap())) {
            writerBuilder.registerWriteHandler(ProductCellWriteHandler.subscriptBuild(req.getMackMap()));
        }
        // 设置单元格内容格式
        writerBuilder.registerWriteHandler(ProductCellWriteHandler.customCellFormat());
        writerBuilder.sheet(req.getSheetName()).doWrite((Collection<?>) null);
    }

    /**
     * 下载错误信息
     *
     * @param response 请求相应
     * @param data     错误数据
     * @param target   导出数据类型
     * @param req      导出导入公共类
     * @throws IOException Exception
     */
    public static void excelErrorTemplate(HttpServletResponse response, List<?> data, Class<?> target, EasyExcelReq req)
            throws IOException {
        setHead(response, exportFileName(req.getFileName()), data.size());
        ExcelWriterBuilder writerBuilder = EasyExcel.write(response.getOutputStream(), target);
        // 设置错误信息模板
        writerBuilder.withTemplate(req.getTempInputStream());
        // 公共样式
        writerBuilder.registerWriteHandler(getHorizontalCellStyleStrategy());
        // 自定义排除列
        if (CollUtil.isNotEmpty(req.getExcludeColumnFieldNames())) {
            writerBuilder.excludeColumnFieldNames(req.getExcludeColumnFieldNames());
        }
        // 自定义输出列
        List<String> includeColumnFieldNames = req.getIncludeColumnFieldNames();
        if (CollUtil.isNotEmpty(includeColumnFieldNames)) {
            if (!includeColumnFieldNames.contains(ERROR_MSG_FIELDS)) {
                // 默认在第一位加上错误信息字段
                includeColumnFieldNames.add(0, ERROR_MSG_FIELDS);
            }
            writerBuilder.includeColumnFieldNames(includeColumnFieldNames)
                    .registerWriteHandler(new SortRowWriteHandler());
        }
        // 设置为false不打印表头 默认为true
        writerBuilder.needHead(req.getNeedHead());
        // 第一列错误信息字体颜色变红
        writerBuilder.registerWriteHandler(new CustomColumnColorStrategy()).inMemory(true);
        // 设置单元格内容格式
        writerBuilder.registerWriteHandler(ProductCellWriteHandler.customCellFormat());
        // 设置下拉框值
        if (MapUtils.isNotEmpty(req.getMackMap())) {
            writerBuilder.registerWriteHandler(ProductCellWriteHandler.subscriptBuild(req.getMackMap()));
        }
        if (MapUtils.isNotEmpty(req.getHeadNameMackMap())) {
            writerBuilder.registerWriteHandler(ProductCellWriteHandler.headNameBuild(req.getHeadNameMackMap()));
        }
        writerBuilder.sheet(req.getSheetName()).doWrite(data);
    }
}
