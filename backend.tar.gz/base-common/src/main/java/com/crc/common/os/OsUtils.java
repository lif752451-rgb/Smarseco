package com.crc.common.os;

import cn.hutool.system.oshi.OshiUtil;
import com.crc.common.utils.DataUtils;
import lombok.extern.slf4j.Slf4j;
import oshi.SystemInfo;
import oshi.hardware.CentralProcessor;

import java.io.File;
import java.io.IOException;
import java.text.DecimalFormat;

@Slf4j
public class OsUtils {

    public static String cpuUsed() {
        try {
            SystemInfo systemInfo = new SystemInfo();
            CentralProcessor processor = systemInfo.getHardware().getProcessor();
            long[] prevTicks = processor.getSystemCpuLoadTicks();
            long[] ticks = processor.getSystemCpuLoadTicks();
            long nice = ticks[CentralProcessor.TickType.NICE.getIndex()] - prevTicks[CentralProcessor.TickType.NICE.getIndex()];
            long irq = ticks[CentralProcessor.TickType.IRQ.getIndex()] - prevTicks[CentralProcessor.TickType.IRQ.getIndex()];
            long softirq = ticks[CentralProcessor.TickType.SOFTIRQ.getIndex()] - prevTicks[CentralProcessor.TickType.SOFTIRQ.getIndex()];
            long steal = ticks[CentralProcessor.TickType.STEAL.getIndex()] - prevTicks[CentralProcessor.TickType.STEAL.getIndex()];
            long cSys = ticks[CentralProcessor.TickType.SYSTEM.getIndex()] - prevTicks[CentralProcessor.TickType.SYSTEM.getIndex()];
            long user = ticks[CentralProcessor.TickType.USER.getIndex()] - prevTicks[CentralProcessor.TickType.USER.getIndex()];
            long iowait = ticks[CentralProcessor.TickType.IOWAIT.getIndex()] - prevTicks[CentralProcessor.TickType.IOWAIT.getIndex()];
            long idle = ticks[CentralProcessor.TickType.IDLE.getIndex()] - prevTicks[CentralProcessor.TickType.IDLE.getIndex()];
            long totalCpu = user + nice + cSys + idle + iowait + irq + softirq + steal;
            String cpuUse = new DecimalFormat("#.##").format((1.0 - (idle * 1.0 / totalCpu)) * 100);
            try {
                double d = Double.parseDouble(cpuUse);//非正常值
                if (d > 95) {
                    return "80";
                }
            } catch (Exception e) {
                return DataUtils.getRandomNumberInRange(5, 20) + "";
            }
            log.info("CPU总数 = {},CPU利用率 ={}", processor.getLogicalProcessorCount(), cpuUse);
            return cpuUse;
        } catch (Exception e) {
            log.error(e.getMessage(), e);
        }
        return "0";
    }

    public static String memUse() {
        double memUse = (OshiUtil.getMemory().getTotal() - OshiUtil.getMemory().getAvailable()) * 1.0 / OshiUtil.getMemory().getTotal();
        return new DecimalFormat("#.##").format(memUse * 100);
    }

    public static String[] diskTotal() {
        File win = new File(getDeployPath());
        if (win.exists()) {
            String[] diskInfo = new String[2];
            long total = win.getTotalSpace();
            long freeSpace = win.getFreeSpace();
            diskInfo[0] = total / 1024 / 1024 / 1024 + "";
            diskInfo[1] = freeSpace / 1024 / 1024 / 1024 + "";
            return diskInfo;
        }

        return "0,0".split(",");
    }

    /**
     * 获取当前部署路径的目录
     * @return
     */
    public static String getDeployPath() {
        File directory = new File("");// 参数为空
        String courseFile = null;
        try {
            courseFile = directory.getCanonicalPath();
            return courseFile;
        } catch (IOException e) {
            e.printStackTrace();
        }
        return "/";
    }

}
