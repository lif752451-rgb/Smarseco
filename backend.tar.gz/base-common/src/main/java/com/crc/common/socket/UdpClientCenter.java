package com.crc.common.socket;

import com.crc.common.utils.DataUtils;
import com.crc.common.utils.MyTheadUtils;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.io.IOUtils;

import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.InetAddress;
import java.util.concurrent.ArrayBlockingQueue;
import java.util.concurrent.ConcurrentHashMap;

/***
 * UDP Client端
 ***/
@Slf4j
public class UdpClientCenter extends Thread {
    public static ArrayBlockingQueue<String> magicQueue = new ArrayBlockingQueue<>(5000);
    public static ConcurrentHashMap<String, String> servList = new ConcurrentHashMap<>();

    @Override
    public void run() {
        log.info("操作日志和登陆日志推送服务启动");
        while (true) {
            if (magicQueue.isEmpty()) {
                MyTheadUtils.sleep(1);
            } else {
                while (!magicQueue.isEmpty()) {
                    try {
                        String opLog = magicQueue.poll();
                        if (servList.size() > 0) {
                            try {
                                for (String key : servList.keySet()) {
                                    send(key, servList.get(key), opLog);
                                }
                            } catch (Exception e) {
                                log.error(e.getMessage(), e);
                            }
                        }
                        MyTheadUtils.sleep(10);
                    } catch (Exception e) {
                        log.error(e.getMessage(), e);
                    }
                }
            }
        }


    }

    public void send(String servIp, String sport, String sendStr) {
        int port = DataUtils.toInt(sport);
        if (port < 1 || port > 65000) {
            return;
        }
        DatagramSocket datagramSocket = null;
        DatagramPacket datagramPacket = null;
        try {
            datagramSocket = new DatagramSocket();
            byte[] buf = sendStr.getBytes();
            InetAddress address = InetAddress.getByName(servIp);
            datagramPacket = new DatagramPacket(buf, buf.length, address, port);
            datagramSocket.send(datagramPacket);
            log.info("send udp>>{}:{}=={}", servIp,port,sendStr);
        } catch (Exception e) {
            //log.error(e.getMessage(), e);
        } finally {
            IOUtils.closeQuietly(datagramSocket);
        }
    }

}
