package com.crc.common.model.enums;

import lombok.Getter;

import java.util.Arrays;

/**
 * 业务系统类型
 */
@Getter
public enum SysNameTypeEnum {
    /**
     * 业务系统类型：stp
     */
    SYS_NAME_STP("stp", "慧联STP"),

    /**
     * 业务系统类型：scp
     */
    SYS_NAME_SCP("scp", "慧脑SCP"),

    /**
     * 业务系统类型：ssp
     */
    SYS_NAME_SSP("ssp", "慧眼SSP"),

    /**
     * 业务系统类型：scm
     */
    SYS_NAME_SCM("scm", "安全业务协同管理中心"),

    /**
     * 业务系统类型：admin
     */
    SYS_NAME_ADMIN("admin", "三慧管理后台"),

    /**
     * 业务系统类型：sbp
     */
    SYS_NAME_SBP("sbp", "个人工作台"),
    ;
    private final String type;

    private final String name;

    SysNameTypeEnum(String type, String name) {
        this.type = type;
        this.name = name;
    }

    public static String getType(String type) {
        return Arrays.stream(SysNameTypeEnum.values()).map(SysNameTypeEnum::getType)
                .filter(typeEnum -> typeEnum.equalsIgnoreCase(type)).findFirst().orElse("");
    }
}
