package com.crc.common.constant;

/**
 * 任务调度通用常量
 * 
 * @author shufengfeng
 */
public class ScheduleConstants
{
    public static final String TASK_CLASS_NAME = "TASK_CLASS_NAME";

    /** 执行目标key */
    public static final String TASK_PROPERTIES = "TASK_PROPERTIES";

    /**
     * 任务ID 参数
     */
    public static final String JOB_ID = "jobId";

    /**
     * 任务组名 参数
     */
    public static final String JOB_GROUP = "jobGroup";

    /**
     * 任务分组关联业务ID 参数
     */
    public static final String JOB_GROUP_BUS_ID = "jobGroupBusId";

    /**
     * 定时任务当前运行时间 参数
     */
    public static final String FIRE_TIME = "fireTime";

    /**
     * 定时任务下一次运行时间 参数
     */
    public static final String NEXT_FIRE_TIME = "nextFireTime";

    /** 默认 */
    public static final String MISFIRE_DEFAULT = "0";

    /** 立即触发执行 */
    public static final String MISFIRE_IGNORE_MISFIRES = "1";

    /** 触发一次执行 */
    public static final String MISFIRE_FIRE_AND_PROCEED = "2";

    /** 不触发立即执行 */
    public static final String MISFIRE_DO_NOTHING = "3";

    public enum Status
    {
        /**
         * 正常
         */
        NORMAL("0"),
        /**
         * 暂停
         */
        PAUSE("1");

        private String value;

        private Status(String value)
        {
            this.value = value;
        }

        public String getValue()
        {
            return value;
        }
    }
}
