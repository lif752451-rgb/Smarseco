package com.crc.common.easyexcel.listener;

import com.alibaba.excel.context.AnalysisContext;
import com.alibaba.excel.enums.RowTypeEnum;
import com.alibaba.excel.event.AnalysisEventListener;
import com.alibaba.excel.util.ListUtils;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.collections4.CollectionUtils;

import java.util.List;
import java.util.function.Consumer;

/**
 * 限制读取行数
 * @author SHUFENGFENG
 */
@Slf4j
public class ReadLimitRowListener<T> extends AnalysisEventListener<T> {

    /**
     * 批处理阈值100
     */
    private static final int BATCH_COUNT = 100;
    /**
     * 缓存的数据
     */
    private List<T> cachedDataList = null;

    private final Consumer<List<T>> consumer;

    /**
     *
     * @param consumer 消费者
     */
    public ReadLimitRowListener(Consumer<List<T>> consumer) {
        cachedDataList = ListUtils.newArrayListWithExpectedSize(BATCH_COUNT);
        this.consumer = consumer;
    }

    /**
     * 默认是从第二行开始读取数据
     * 这个每一条数据解析都会来调用
     * @param t
     * @param analysisContext
     */
    @Override
    public void invoke(T t, AnalysisContext analysisContext) {
        //过滤空行
        analysisContext.readWorkbookHolder().setIgnoreEmptyRow(false);
        cachedDataList.add(t);
        if (this.cachedDataList.size() >= BATCH_COUNT) {
            this.consumer.accept(this.cachedDataList);
            this.cachedDataList = ListUtils.newArrayListWithExpectedSize(BATCH_COUNT);
        }
    }

    @Override
    public boolean hasNext(AnalysisContext analysisContext){
        if(RowTypeEnum.EMPTY.equals(analysisContext.readRowHolder().getRowType())){
            doAfterAllAnalysed(analysisContext);
            return false;
        }
        return super.hasNext(analysisContext);
    }

    /**
     * 所有数据解析完成了 都会来调用
     * @param analysisContext
     */
    @Override
    public void doAfterAllAnalysed(AnalysisContext analysisContext) {
        if (CollectionUtils.isNotEmpty(this.cachedDataList)) {
            this.consumer.accept(this.cachedDataList);
        }
    }
}
