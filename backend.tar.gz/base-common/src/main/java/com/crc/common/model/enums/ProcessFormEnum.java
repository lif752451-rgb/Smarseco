package com.crc.common.model.enums;

/**
 * 流程表单枚举
 * @author WANGLEI
 */
public enum ProcessFormEnum {

    DEFAULT("formDefault", "默认表单",0),
    RISK_ORIGIN("formRiskOrigin", "风险验证表单",1),
    RISK_RECTIFY("formRiskRectify", "风险整改表单",2),
    RISK_CHECK("formRiskCheck", "风险验证表单",3),
    RISK_TRANSFER("formRiskTransfer", "风险转办表单",null),
    RISK_ASSIGN("formRiskAssign", "风险指派表单",null),
    RISK_DELAY_APPLY("formRiskDelayApply", "风险延期申请表单",4),
    RISK_DELAY_APPROVE("formRiskDelayApprove", "风险延期申请审批表单",5),
    LOOPHOLE_RISK_REPORT("formKeak", "漏洞-风险发起表单",6),
    ALARM_REPORT("formAlarmReport", "告警上报表单",7),
    ALARM_JUDGE("formAlarmJudge", "告警研判表单",8),
    ALARM_HANDLE("formAlarmHandle", "告警处置表单",9),
    ALARM_TRANSFER_HANDLE("formTransferHandle", "告警转办处置表单",10),
    ALARM_REVIEW("formToReview", "告警复核表单",11),
    ALARM_EXAMINE("formToExamine", "告警审核表单",12),
    RISK_AUTO_REPORT("riskAutoReport", "漏洞-风险发起表单",13),
    ALARM_HVV_REPORT("formAlarmHVVReport", "告警HVV上报表单",7),
    ;

    ProcessFormEnum(String formCode, String formName,Integer fromIndex) {
        this.formCode = formCode;
        this.formName = formName;
        this.formIndex = fromIndex;
    }

    /**
     * formCode 表单名称编码
     */
    private String formCode;
    /**
     * formName 表单名称
     */
    private String formName;
    /**
     * fromIndex 表单编号
     */
    private Integer formIndex;


    public String getFormCode() {
        return formCode;
    }

    public void setFormCode(String formCode) {
        this.formCode = formCode;
    }

    public String getFormName() {
        return formName;
    }

    public void setFormName(String formName) {
        this.formName = formName;
    }

    public Integer getFormIndex() {
        return formIndex;
    }

    public void setFormIndex(Integer formIndex) {
        this.formIndex = formIndex;
    }
}
