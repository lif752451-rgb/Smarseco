package com.crc.common.utils.jfreechart;

import com.alibaba.fastjson.JSONArray;
import com.alibaba.fastjson.JSONObject;
import org.apache.commons.io.IOUtils;
import org.jfree.chart.ChartColor;
import org.jfree.chart.ChartFactory;
import org.jfree.chart.JFreeChart;
import org.jfree.chart.axis.CategoryAxis;
import org.jfree.chart.axis.CategoryLabelPositions;
import org.jfree.chart.axis.NumberAxis;
import org.jfree.chart.axis.ValueAxis;
import org.jfree.chart.block.BlockBorder;
import org.jfree.chart.labels.ItemLabelAnchor;
import org.jfree.chart.labels.ItemLabelPosition;
import org.jfree.chart.labels.StandardCategoryItemLabelGenerator;
import org.jfree.chart.plot.CategoryPlot;
import org.jfree.chart.plot.PlotOrientation;
import org.jfree.chart.renderer.category.LineAndShapeRenderer;
import org.jfree.chart.title.LegendTitle;
import org.jfree.chart.title.TextTitle;
import org.jfree.data.category.DefaultCategoryDataset;
import org.jfree.ui.RectangleEdge;
import org.jfree.ui.TextAnchor;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.awt.*;
import java.io.IOException;
import java.io.InputStream;
import java.util.Iterator;
import java.util.Map;

public class JFreeLineChart implements JFreeCommonChart {
    private static final Logger log = LoggerFactory.getLogger(JFreeLineChart.class);

    public JFreeChart createChart(JSONArray resultData, Map<String, Object> jsonProperty){
        return createLineChart(resultData, jsonProperty);
    }

    /**
     * [{count: 53, NAME: "中风险"}, {count: 30, NAME: "低风险"}, {count: 276, NAME: "高风险"}]
     * {"legendDataColor":{"高风险":"#FFA39E","中风险":"#FFCA8F","低风险":"#91C3FF"}}
     *
     * @param resultData
     * @param jsonProperty
     * @return
     */
    private JFreeChart createLineChart(JSONArray resultData, Map<String, Object> jsonProperty) {
        if (resultData != null && resultData.size() > 0) {
            //X轴和Y轴翻转
            PlotOrientation orientation = PlotOrientation.VERTICAL;
            if (jsonProperty.containsKey("axisTransform")) {
                orientation = PlotOrientation.HORIZONTAL;
            }
            //标题
            String title = "";
            if (jsonProperty.containsKey("title")) {
                title = (String) jsonProperty.get("title");
            }
            //组装数据
            DefaultCategoryDataset data = new DefaultCategoryDataset();
            if (resultData.getJSONObject(0).containsKey("child") || resultData.getJSONObject(0).containsKey("CHILD")) {
                resultData.stream().forEach(object ->
                        data.setValue(((JSONObject) object).containsKey("COUNT") ? ((JSONObject) object).getDouble("COUNT") : ((JSONObject) object).getDouble("count"),
                                ((JSONObject) object).containsKey("CHILD") ? ((JSONObject) object).getString("CHILD") : ((JSONObject) object).getString("child"),
                                ((JSONObject) object).containsKey("NAME") ? ((JSONObject) object).getString("NAME") : ((JSONObject) object).getString("name"))
                );
            } else {
                resultData.stream().forEach(object ->
                        data.setValue(((JSONObject) object).containsKey("COUNT") ? ((JSONObject) object).getDouble("COUNT") : ((JSONObject) object).getDouble("count"),
                                jsonProperty.containsKey("legendData") ? (String) jsonProperty.get("legendData") : "",
                                ((JSONObject) object).containsKey("NAME") ? ((JSONObject) object).getString("NAME") : ((JSONObject) object).getString("name"))
                );
            }
            //生成图表
            JFreeChart chart = ChartFactory.createLineChart(title, "", "", data, orientation, true, true, true);
            chart.setBorderVisible(false);
            //报表主配置
            CategoryPlot plot = (CategoryPlot) chart.getCategoryPlot();
            plot.setBackgroundPaint(ChartColor.WHITE);
            plot.setOutlinePaint(null);
            plot.setRangeGridlinePaint(Color.decode("#e6ebf3"));
            plot.setRangeGridlinesVisible(true);
            LineAndShapeRenderer renderer = (LineAndShapeRenderer) plot.getRenderer();
            //颜色
            if (jsonProperty.containsKey("legendDataColor")) {
                if (resultData.getJSONObject(0).containsKey("child") || resultData.getJSONObject(0).containsKey("CHILD")) {
                    JSONObject color = (JSONObject) jsonProperty.get("legendDataColor");
                    Iterator iter = color.entrySet().iterator();
                    int index = 0;
                    while (iter.hasNext()) {
                        Map.Entry entry = (Map.Entry) iter.next();
                        renderer.setSeriesPaint(index, Color.decode(entry.getValue().toString()));
                        renderer.setSeriesOutlinePaint(index, Color.decode(entry.getValue().toString()));
                        renderer.setSeriesStroke(index, new BasicStroke(2.0F));
                        index++;
                    }
                } else {
                    String color = (String) jsonProperty.get("legendDataColor");
                    renderer.setSeriesPaint(0, Color.decode(color));
                    renderer.setSeriesOutlinePaint(0, Color.decode(color));
                    renderer.setSeriesStroke(0, new BasicStroke(2.0F));
                }
            }
            renderer.setBaseItemLabelGenerator(new StandardCategoryItemLabelGenerator());
            renderer.setBaseItemLabelsVisible(true);
            renderer.setBasePositiveItemLabelPosition(new ItemLabelPosition(ItemLabelAnchor.OUTSIDE12, TextAnchor.BASELINE_CENTER));
            renderer.setBaseItemLabelPaint(Color.decode("#575757"));
            renderer.setDrawOutlines(true);
            renderer.setBaseShapesVisible(true);
            plot.setRenderer(renderer);
            //设置没有小数点
            if(jsonProperty.containsKey("dataNumber")){
                NumberAxis numberaxis = (NumberAxis)plot.getRangeAxis();
                numberaxis.setStandardTickUnits(NumberAxis.createIntegerTickUnits());
            }
            //X轴配置
            CategoryAxis domainAxis = plot.getDomainAxis();
            domainAxis.setTickLabelFont(createFont(14));//设置x轴坐标上的字体
            domainAxis.setLabelFont(createFont(14));//设置x轴上的标题的字体
            if (jsonProperty.containsKey("xaxisLabelRotate")) {
                domainAxis.setCategoryLabelPositions(CategoryLabelPositions.UP_45);
            }
            //Y轴配置
            ValueAxis valueAxis = plot.getRangeAxis();//(柱状图的y轴)
            valueAxis.setTickLabelFont(createFont(14));//设置y轴坐标上的字体
            valueAxis.setLabelFont(createFont(14));//设置y轴坐标上的标题的字体
            //实例配置
            LegendTitle legend = chart.getLegend();
            legend.setPosition(RectangleEdge.TOP);
            legend.setFrame(new BlockBorder(Color.white));
            legend.setBackgroundPaint(null);
            legend.setItemFont(createFont(14));
            //标题样式配置
            TextTitle textTitle = chart.getTitle();
            textTitle.setFont(createFont(16));
            return chart;
        } else {
            return null;
        }
    }

    /**
     * 自定义字体
     * @return
     * @throws IOException
     * @throws FontFormatException
     */
    public Font createFont(float size){
        String fontPath = "static/" + "simsun.ttf";
        InputStream is = this.getClass().getClassLoader().getResourceAsStream(fontPath);
        Font ft = null;
        try {
            ft = Font.createFont(Font.TRUETYPE_FONT, is);
        } catch (FontFormatException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        } finally {
            try {
                IOUtils.close(is);
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
        ft = ft.deriveFont(Font.PLAIN,size);
        return ft;
    }

}
