package com.crc.common.utils;

import cn.hutool.core.lang.Assert;
import cn.hutool.core.util.StrUtil;
import com.crc.common.exception.CustomException;
import com.crc.common.model.enums.ResponseEnum;

import java.util.Objects;

/**
 * @author fuzhuangzhi
 * @title AssertUtils
 * @date 2023/6/30 15:42
 * @description 异常断言
 */
public class AssertUtils extends Assert {

    /**
     * 异常断言
     *
     * @param expression   Boolean值
     * @param responseEnum 异常枚举
     * @param <X>
     */
    public static <X extends Throwable> void isFalse(Boolean expression, ResponseEnum responseEnum) {
        isFalse(expression, () -> new CustomException(responseEnum.getMsg(), responseEnum.getCode()));
    }

    /**
     * 异常断言
     *
     * @param expression Boolean值
     * @param errorMsg   异常msg
     * @param <X>
     */
    public static <X extends Throwable> void isNull(Boolean expression, String errorMsg) {
        isFalse(expression, () -> new CustomException(errorMsg));
    }

    /**
     * 异常断言
     *
     * @param expression       Boolean值
     * @param errorMsgTemplate 异常msg模板
     * @param params           参数列表
     * @param <X>
     */
    public static <X extends Throwable> void format(Boolean expression, String errorMsgTemplate, Integer... params) {
        isFalse(expression, () -> new CustomException(StrUtil.format(errorMsgTemplate, params)));
    }

    /**
     * 异常断言，如果对象为null,抛出异常
     *
     * @param object       对象
     * @param responseEnum 异常枚举
     * @param <X>
     */
    public static <X extends Throwable> void isNull(Object object, ResponseEnum responseEnum) {
        isFalse(Objects.isNull(object), () -> new CustomException(responseEnum.getMsg(), responseEnum.getCode()));
    }

    /**
     * 异常断言，如果对象不为null,抛出异常
     *
     * @param object       对象
     * @param responseEnum 异常枚举
     * @param <X>
     */
    public static <X extends Throwable> void isNotNull(Object object, ResponseEnum responseEnum) {
        isFalse(Objects.nonNull(object), () -> new CustomException(responseEnum.getMsg(), responseEnum.getCode()));
    }

}
