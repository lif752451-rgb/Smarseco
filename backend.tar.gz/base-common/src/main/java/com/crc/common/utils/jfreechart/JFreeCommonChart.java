package com.crc.common.utils.jfreechart;

import com.alibaba.fastjson.JSONArray;
import org.jfree.chart.JFreeChart;

import java.util.Map;

public interface JFreeCommonChart {

    JFreeChart createChart(JSONArray resultData, Map<String, Object> jsonProperty);

}
