package com.crc.common.utils;

import cn.hutool.system.oshi.CpuInfo;
import cn.hutool.system.oshi.OshiUtil;
import com.crc.common.model.dto.SysDiskInfoDTO;
import lombok.extern.slf4j.Slf4j;

import java.io.BufferedReader;
import java.io.File;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.InetAddress;
import java.net.NetworkInterface;
import java.text.DecimalFormat;
import java.util.ArrayList;
import java.util.Enumeration;
import java.util.List;

/**
 * @author jixiangqi
 * @date 2023/9/12
 * win性能
 */
@Slf4j
public class WinInfoUtil {

    /**
     * 获取内存数据
     */
    public static String getMemoryInfo(){
        double total = (double)OshiUtil.getMemory().getTotal();
        double useValue = (total - OshiUtil.getMemory().getAvailable());
        DecimalFormat format = new DecimalFormat("#.00");
        double tempValue = (useValue / total) * 100;
        String value = format.format(tempValue);
        return value;
    }

    /**
     * 获取cpu利用率
     */
    public static String getOsInfo(){
        CpuInfo cpuInfo = OshiUtil.getCpuInfo();
        double used = cpuInfo.getUsed();
        return String.valueOf(used);
    }

    public static void main(String[] args) throws IOException {
        String a = "devtmpfs                  16G     0   16G    0% /dev";
        a = a.replaceAll("\\s+", " ");
        String[] split = DataUtils.getSplit(a, " ");
        for (int i = 0; i < split.length; i++) {
            System.out.println(split[i]);
        }
    }


    /**
     * 获取系统各个硬盘的总容量、已经使用的容量、剩余容量和使用率
     * @throws IOException
     */
    public static List<SysDiskInfoDTO> getDiskInfoNew(String ipAndPort) throws IOException {
        DecimalFormat df = new DecimalFormat("#0.00");
        File[] disks = File.listRoots();
        List<SysDiskInfoDTO> list = new ArrayList<>();
        for (File file : disks) {
            // 获取总容量
            long totalSpace = file.getTotalSpace();
            // 获取剩余容量
            long usableSpace = file.getUsableSpace();
            // 获取已经使用的容量
            long freeSpace = totalSpace - usableSpace;
            float useRate = (float)((freeSpace * 1.0 / totalSpace) * 100);
            SysDiskInfoDTO sysDiskInfoDTO = new SysDiskInfoDTO();
            sysDiskInfoDTO.setFileSys(file.getCanonicalPath());
            sysDiskInfoDTO.setIpPort(ipAndPort);
            sysDiskInfoDTO.setPartition(file.getCanonicalPath());
            sysDiskInfoDTO.setAvailable(transformation(usableSpace));
            sysDiskInfoDTO.setUsageRate(Double.parseDouble(df.format(useRate)) + "%   ");
            list.add(sysDiskInfoDTO);
        }
        return list;
    }

    public static List<SysDiskInfoDTO> getDiskInfoLinux(String ipAndPort) {
        List<SysDiskInfoDTO> list = new ArrayList<>();
        try {
            // 执行 df -h 命令
            Process process = Runtime.getRuntime().exec("df -h");
            BufferedReader reader = new BufferedReader(new InputStreamReader(process.getInputStream()));
            String line;
            while ((line = reader.readLine()) != null) {
                // 输出分区使用情况
                if (StringUtils.isNotEmpty(line) && !line.startsWith("文件系统")) {
                    line = line.replaceAll("\\s+", " ");
                    String[] split = DataUtils.getSplit(line, " ");
                    SysDiskInfoDTO sysDiskInfoDTO = new SysDiskInfoDTO();
                    if (split.length == 6) {
                        sysDiskInfoDTO.setFileSys(split[0]);
                        sysDiskInfoDTO.setPartition(split[5]);
                        sysDiskInfoDTO.setAvailable(split[3]);
                        sysDiskInfoDTO.setUsageRate(split[4]);
                        sysDiskInfoDTO.setIpPort(ipAndPort);
                        list.add(sysDiskInfoDTO);
                    }
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
            log.error("查询Linux磁盘使用情况失败：{}",e.getMessage(),e);
        }
        return list;
    }
    /**
     * 将字节容量转化为GB
     */
    public static String transformation(double size){
        DecimalFormat df = new DecimalFormat("#0.00");
        String format = df.format(size / (1024 * 1024 * 1024));
        return  format + "GB   " ;
    }


    /**
     * 判断操作系统是否是 Windows
     *
     * @return true：操作系统是 Windows
     *         false：其它操作系统
     */
    public static boolean isWindows() {
        String osName = getOsName();
        if (StringUtils.isNotEmpty(osName) && osName.toLowerCase().contains("win")) {
            return true;
        }
        return false;
    }

    /**
     * 判断操作系统是否是 Linux
     *
     * @return true：操作系统是 Linux
     *         false：其它操作系统
     */
    public static boolean isLinux() {
        String osName = getOsName();
        if (StringUtils.isNotEmpty(osName) && (osName.contains("nix") || osName.contains("nux") || osName.contains("mac"))) {
            return true;
        }
        return false;
    }

    /**
     * 获取操作系统名称
     * @return os.name 属性值
     */
    public static String getOsName() {
        return System.getProperty("os.name");
    }

    public static String getHostIp () {
        try {
            InetAddress localAddress = InetAddress.getLocalHost();
            return localAddress.getHostAddress();
        } catch (Exception e) {
            log.error("获取系统IP失败：{}",e.getMessage(), e);
        }
        return "";
    }


    public static String getHostIpLinux() {
        try {
            Enumeration<NetworkInterface> networkInterfaces = NetworkInterface.getNetworkInterfaces();
            while (networkInterfaces.hasMoreElements()) {
                NetworkInterface networkInterface = (NetworkInterface )networkInterfaces.nextElement();
                Enumeration<InetAddress> inetAddresses = networkInterface.getInetAddresses();
                while (inetAddresses.hasMoreElements()) {
                    InetAddress inetAddress = (InetAddress)inetAddresses.nextElement();
                    if (!inetAddress.isLoopbackAddress() && inetAddress.isSiteLocalAddress()) {
                        return inetAddress.getHostAddress();
                    }
                }
            }
        } catch (Exception e) {
            log.error("获取Linux IP地址失败:{}",e.getMessage(), e);
        }
        return "";
    }

}
