package com.crc.common.utils.ip;

import lombok.Data;

import java.math.BigInteger;
import java.util.Objects;

/**
 * @author fuzhuangzhi
 * @title AssetSegementIp
 * @date 2023/6/15 19:03
 * @description TODO
 */
@Data
public class AssetSegementIp {
    /**
     * 网段开始IP十进制
     */
    private BigInteger startLongIp;

    /**
     * 网段结束Ip十进制
     */
    private BigInteger endLongIp;

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        AssetSegementIp that = (AssetSegementIp) o;

        if (startLongIp == null || endLongIp == null) {
            return false;
        }
        if (that.startLongIp == null || that.endLongIp == null) {
            return false;
        }
        return startLongIp.compareTo(that.startLongIp) == 0 && endLongIp.compareTo(that.endLongIp) == 0;
    }

    @Override
    public int hashCode() {
        return Objects.hash(startLongIp.longValue() + endLongIp.longValue());
    }
}
