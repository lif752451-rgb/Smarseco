package com.crc.common.utils.youdu;

import com.google.gson.JsonElement;

// 消息体接口
public abstract class MessageBody {

    public abstract MessageBody fromJsonString(String json) throws ParamParserException;

    public abstract MessageBody fromJsonElement(JsonElement json) throws ParamParserException;

    public abstract String toJsonString();

    public abstract JsonElement toJsonElement();

    public TextBody getAsTextBody() {
        if (this instanceof TextBody) {
            return (TextBody)this;
        }
        return null;
    }

}
