package com.crc.common.utils.youdu;


public class ServiceException extends GeneralEntAppException {

    public ServiceException(String message, Throwable cause) {
        super(message, cause);
    }
}
