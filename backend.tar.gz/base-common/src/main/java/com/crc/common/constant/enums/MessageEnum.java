package com.crc.common.constant.enums;

/**
 * @author simba@onlying.cn
 * @date 2020/7/16 11:44
 */
public enum MessageEnum {

    EVENT_SAVE_FAIL(20011, "实时事件保存失败"),
    EVENT_UPDATE_FAIL(20012, "实时事件修改失败"),
    EVENT_DELETE_FAIL(20013, "实时事件删除失败"),
    EVENT_DOES_NOT_EXIST(20014, "实时事件不存在"),
    EVENT_ALREADY_EXISTS(20015, "实时事件已存在"),
    EVENT_ATTACK_IP_ERROR(20016, "攻击IP参数格式不正确"),
    EVENT_ATTACK_URL_ERROR(20017, "攻击URL参数格式不正确"),

    PANEL_SAVE_FAIL(20021, "面板保存失败"),
    PANEL_UPDATE_FAIL(20022, "面板修改失败"),
    PANEL_DELETE_FAIL(20023, "面板删除失败"),
    PANEL_DOES_NOT_EXIST(20024, "面板不存在"),

    TBVISUALIZATION_SAVE_FAIL(20031, "可视化保存失败"),
    TBVISUALIZATION_UPDATE_FAIL(20032, "可视化修改失败"),
    TBVISUALIZATION_DELETE_FAIL(20033, "可视化删除失败"),
    TBVISUALIZATION_DOES_NOT_EXIST(20034, "可视化不存在"),
    TBVISUALIZATION_DATA_ERROR(20035, "数据格式错误"),


    /**
     * amdin接口以及邮件配置
     */
    ADMIN_LDAP_URL_ERROR(200480, "LDAP地址长度不能大于500 "),
    ADMIN_BASE_DN_ERROR(200481, "Base DN 长度不能大于256"),
    ADMIN_BASE_DN_FAIL(200481, "Base DN 格式错误"),
    ADMIN_LDAP_SOURCE_ERROR(200482, "LDAP 身份源名称长度不能大于20"),
    ADMIN_USER_DN_ERROR(200483, "User DN长度不能大于256"),
    ADMIN_FILE_PATH_ERROR(200484, "SSL 密钥文件路径长度不能大于256"),
    ADMIN_FILE_NAME_ERROR(200486, "SSL 密钥文件专有名词不能大于256"),
    ADMIN_PORT_ERROR(200487, "端口号不合符规范，请检查"),
    SEND_LDAP_FAIL(200493, "连接失败，请检查配置信息"),


    SEND_EMAIL_ERROR(200489, "发件人邮箱长度不能大于200"),
    SEND_EMAIL_HOST_ERROR(200489, "SMTP邮件服务器长度不能大于200"),
    SEND_EMAIL_FORMAT_ERROR(200490, "发件人邮箱格式错误，请检查"),
    SEND_HOST_FORMAT_ERROR(200491, "SMTP邮件服务器格式错误，请检查"),
    SEND_EMAIL_FAIL(200492, "测试邮件发送失败，请检查配置信息"),

    /**
     * 数据源设备
     */
    DATA_SOURCE_DEVICE(200493, "数据源设备长度不能大于100"),
    DATA_SOURCE_BUS(200494, "数据源厂商长度不能大于100"),
    DATA_SOURCE_ADDRESS(200495, "数据源地址长度不能大于256"),
    DATA_SOURCE_PROTO_PORT(200495, "采集协议端口长度不能大于100"),
    DATA_NAME_EXIST(200496, "该数据源设备已存在，请勿重复添加"),


    /**
     * 数据解析
     */
    LOG_PARSE_RULE_NAME(200496, "规则名称长度不能超过100个字符"),
    LOG_PARSE_RULE_PARSE(200496, "解析规则长度不能超过1000个字符"),
    LOG_PARSE_DEVICE(200496, "解析设备长度不能超过100个字符"),
    LOG_PARSE_DEVICE_VERSION(200496, "设备版本长度不能超过100个字符"),
    LOG_PARSE_RULE_DESC(200496, "规则描述长度不能超过1000个字符"),
    LOG_PARSE_RULE_NAME_EXIST(200496, "该规则名称已存在，请勿重复添加"),
    LOG_PARSE_ERROR(200496, "解析规则配置有误，请完善"),
    LOG_PARSE_DELETE_ERROR(200498, "内置规则不能删除"),


    /**
     * 法规标准管理
     */
    NAME_LENGTH_ERROR(200497, "名称不能超过100个字符"),
    NUMBER_LENGTH_ERROR(200497, "编号不能超过50个字符"),
    DESCRIBE_LENGTH_ERROR(200497, "描述不能超过1000个字符"),
    SCOPE_LENGTH_ERROR(200497, "适用范围不能超过50个字符"),
    REMARK_LENGTH_ERROR(200497, "备注不能超过1000个字符"),

    /**
     * 监管案例
     */
    CASE_NAME_LENGTH_ERROR(200498, "案例名称不能超过100个字符"),
    ILLEGAL_BEHAVIOR_LENGTH_ERROR(200499, "违规行为不能超过50个字符"),
    PUNISH_MEASURE_NAME_LENGTH_ERROR(200498, "处罚措施不能超过50个字符"),
    PUNISH_OBJ_NAME_LENGTH_ERROR(200498, "被处罚对象不能超过50个字符"),
    RELATED_ORG_NAME_LENGTH_ERROR(200498, "相关机构不能超过50个字符"),


    /**
     * 制度管理
     */
    TITLE_LENGTH_ERROR(200498, "标题不能超过100个字符"),
    VERSION_LENGTH_ERROR(200498, "版本不能超过100个字符"),
    PUBLISHER_LENGTH_ERROR(200498, "发布者不能超过100个字符"),
    ID_NOT_EMPTY(200498, "id不能为空"),
    ;



    // 枚举名称
    private Integer key;

    // 枚举类型
    private String value;

    MessageEnum(Integer key, String value) {
        this.key = key;
        this.value = value;
    }

    public Integer getKey() {
        return key;
    }

    public void setKey(Integer key) {
        this.key = key;
    }

    public String getValue() {
        return value;
    }

    public void setValue(String value) {
        this.value = value;
    }


}
