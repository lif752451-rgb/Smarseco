package com.crc.common.model.enums;

/**
 * @Author shufengfeng
 * @Description 排序
 * @DateTime 2021/10/13 10:35
 */
public enum OrderByEnum {


    ASC("asc"),


    DESC("desc"),


    ;


    /**
     * 名称
     */
    private String val;


    OrderByEnum(String val){
        this.val = val;
    }

    public String getVal() {
        return val;
    }

    public void setVal(String val) {
        this.val = val;
    }
}
