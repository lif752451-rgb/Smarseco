package com.crc.common.utils;

import com.crc.common.constant.Constants;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.codec.binary.Base64;
import org.apache.commons.codec.digest.DigestUtils;

import javax.crypto.Cipher;
import javax.crypto.spec.IvParameterSpec;
import javax.crypto.spec.SecretKeySpec;
import java.nio.charset.StandardCharsets;

/**
 * @author 何景生
 */
@Slf4j
public class AESUtils {
    //加盐(长度为16)
    private static final String IV = "abcdefgh12345678";

    public static String md5(String plainText) {
        String md5Hex = DigestUtils.md5Hex(plainText).toUpperCase();
        return md5Hex;
    }

    // 加密
    public static String Encrypt(String content, String key) throws Exception {
        if (StringUtils.isEmpty(key)) {
            log.info("加密秘钥为空");
            return content;
        }
        try {
            IvParameterSpec iv = new IvParameterSpec(IV.getBytes(Constants.UTF8));
            SecretKeySpec skySpec = new SecretKeySpec(key.getBytes(Constants.UTF8), Constants.AES);
            Cipher cipher = Cipher.getInstance(Constants.AES_ALGORITHM);//"算法/模式/补码方式"
            cipher.init(Cipher.ENCRYPT_MODE, skySpec, iv);
            byte[] encrypted = cipher.doFinal(content.getBytes(StandardCharsets.UTF_8));
            return new Base64().encodeToString(encrypted);//此处使用BASE64做转码功能，同时能起到2次加密的作用。
        } catch (Exception e) {
            log.error("加密出错{}",e.getMessage(),e);
        }
        return content;
    }

    // 解密
    public static String Decrypt(String content, String key) throws Exception {
        // 判断Key是否正确
        if (StringUtils.isEmpty(key)) {
            log.info("加密秘钥为空");
            return null;
        }
        try {
            IvParameterSpec iv = new IvParameterSpec(IV.getBytes(Constants.UTF8));
            SecretKeySpec skySpec = new SecretKeySpec(key.getBytes(Constants.UTF8), Constants.AES);
            Cipher cipher = Cipher.getInstance(Constants.AES_ALGORITHM);
            cipher.init(Cipher.DECRYPT_MODE, skySpec, iv);
            byte[] original = cipher.doFinal(new Base64().decode(content));
            return new String(original, StandardCharsets.UTF_8);
        } catch (Exception e) {
            log.error("解密出错{}",e.getMessage(),e);
        }
        return content;
    }

    public static void main(String[] args) throws Exception {
        String str = AESUtils.Encrypt("hello","abcdefg123123123");
        System.out.println(str);
        String target = AESUtils.Decrypt(str, "abcdefg123123123");
        System.out.println(target);

        //AES aes = new AES(Mode.CTS, Padding.PKCS5Padding, "0CoJUm6Qyw8W8jud".getBytes(), "0102030405060708".getBytes());
        //System.out.println(aes.encryptBase64("hello阿爸的爸爸打包"));
    }
}
