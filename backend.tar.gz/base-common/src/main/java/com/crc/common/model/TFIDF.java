package com.crc.common.model;

import java.util.HashMap;
import java.util.Map;

/**
 * 字符串相似度匹配
 *
 * @author zhangbing
 */
public class TFIDF {

    private final Map<String, Double> tfValues;

    public TFIDF(String text) {
        Map<String, Integer> termFrequency = new HashMap<>();
        Map<String, Integer> documentFrequency = new HashMap<>();
        Map<String, Double> idfValues = new HashMap<>();
        tfValues = new HashMap<>();

        // 计算词频 (Term Frequency)
        String[] words = text.split("");
        for (String word : words) {
            if (!termFrequency.containsKey(word)) {
                termFrequency.put(word, 1);
            } else {
                termFrequency.put(word, termFrequency.get(word) + 1);
            }
        }

        // 计算逆文档频率 (Inverse Document Frequency)
        int totalDocuments = 1; // 当前只支持比较两个字符串，因此总文档数设定为1
        for (String word : termFrequency.keySet()) {
            int count = termFrequency.get(word);
            documentFrequency.put(word, count);
            totalDocuments += count;
        }
        for (String word : termFrequency.keySet()) {
            double idf = Math.log(totalDocuments / (1 + documentFrequency.get(word)));
            idfValues.put(word, idf);
        }

        // 计算词向量 (Term Vector)
        for (String word : termFrequency.keySet()) {
            tfValues.put(word, termFrequency.get(word) * idfValues.get(word));
        }
    }

    public double calculateSimilarity(String text) {
        double similarity = 0.0;
        String[] words = text.split("");
        for (String word : words) {
            if (tfValues.containsKey(word)) {
                similarity += tfValues.get(word);
            }
        }
        return similarity / words.length; // 平均值作为文本相似度
    }
}