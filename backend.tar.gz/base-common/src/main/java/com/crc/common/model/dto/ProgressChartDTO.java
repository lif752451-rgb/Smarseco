package com.crc.common.model.dto;

import com.crc.common.model.enums.ProgressChartStatusEnum;
import lombok.Data;

/**
 * 进度图
 * @author WANGLEI
 * @DateTime 2021/9/2 16:08
 */
@Data
public class ProgressChartDTO {
    /** 进度图节点 */
    private String nodeName;
    /** 进度图处理人 */
    private String dealUser;
    /** 进度图状态：1 历史，2 当前，3 未发生 */
    private ProgressChartStatusEnum state;
}
