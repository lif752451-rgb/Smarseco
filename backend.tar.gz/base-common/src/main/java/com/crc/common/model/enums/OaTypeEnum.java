package com.crc.common.model.enums;

import cn.hutool.core.util.StrUtil;
import lombok.Getter;

/**
 * OA提醒类型枚举
 *
 * @Author fuzhuangzhi
 * @Date 2023/1/30 16:46
 * @Version 1.0
 **/
@Getter
public enum OaTypeEnum {
    ASSET("资产变更","资产管理-资产变更","assetChangeUrl"),
    ALARM("告警","威胁管理-告警闭环","alarmUrl"),
    ALARM_WHITE_LIST("告警白名单","威胁管理-告警白名单","alarmWhiteUrl"),
    HOST_VUL("主机漏洞","漏洞管理-漏洞闭环-主机漏洞","hostVulUrl"),
    WEB_VUL("WEB漏洞","漏洞管理-漏洞闭环-WEB漏洞","webVulUrl"),
    CODE_VUL("弱口令漏洞","漏洞管理-漏洞闭环-弱口令漏洞","codeVulUrl"),
    VUL_WHITE_LIST("漏洞白名单","漏洞管理-漏洞白名单","vulnWhiteUrl"),
    VUL_DELAY("漏洞延期","漏洞管理-延期管理","vulnDelayUrl"),
    CODE_AUDIT("代码审计","代码审计-代码缺陷闭环","codeAuditUrl"),
    TASK_MANAGE("任务管理","任务管理-任务下发","taskManageUrl"),
    ;
    private String oaType;
    private String modelName;
    // 链接跳转value
    private String dictValue;

    OaTypeEnum(String oaType, String modelName, String dictValue) {
        this.oaType = oaType;
        this.modelName = modelName;
        this.dictValue = dictValue;
    }

    public static OaTypeEnum getTypeEnum(String oaTypeValue) {
        if (StrUtil.isEmpty(oaTypeValue)) {
            return null;
        }
        for (OaTypeEnum typeEnum : OaTypeEnum.values()) {
            if (oaTypeValue.equals(typeEnum.getDictValue())) {
                return typeEnum;
            }
        }
        return null;
    }
}
