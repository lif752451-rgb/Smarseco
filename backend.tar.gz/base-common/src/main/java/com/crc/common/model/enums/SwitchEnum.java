package com.crc.common.model.enums;

/**
 * @Author shufengfeng
 * @Description 开关枚举类
 * @DateTime 2021/8/27 17:10
 */
public enum SwitchEnum {

    OPEN("open","打开"),
    CLOSE("close","关闭"),

    ;


    /**
     * 名称
     */
    private String name;

    /**
     * 描述
     */
    private String desc;

    SwitchEnum(String name, String desc){
        this.name = name;
        this.desc = desc;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getDesc() {
        return desc;
    }

    public void setDesc(String desc) {
        this.desc = desc;
    }
}
