package com.crc.common.easyexcel.style;

import com.alibaba.excel.write.style.row.AbstractRowHeightStyleStrategy;
import org.apache.poi.ss.usermodel.Row;

/**
 * 设置吟唱行
 * @author SHUFENGFENG
 */
public class CustomHiddenRowStyleStrategy extends AbstractRowHeightStyleStrategy  {

    /**
     * 设置需要隐藏的行号
     */
    Integer rowNum;

    /**
     * 表头高度
     */
    private Integer headHeight;

    /**
     *
     * @param rowNum 需要隐藏的列序号,从0开始
     */
    public CustomHiddenRowStyleStrategy(int rowNum){
        this.rowNum = rowNum;
    }

    /**
     *
     * @param rowNum 需要隐藏的列序号,从0开始
     * @param headHeight 表头高度
     */
    public CustomHiddenRowStyleStrategy(int rowNum, Integer headHeight){
        this.rowNum = rowNum;
        this.headHeight = headHeight;
    }


    @Override
    protected void setHeadColumnHeight(Row row, int i) {
        //设置表头行高为20
        if(null != headHeight){
            row.setHeightInPoints(headHeight);
        }else {
            row.setHeightInPoints(20);
        }
    }

    /**
     * 设置内容的行高 relativeRowIndex为行数，索引从0开始
     */
    @Override
    protected void setContentColumnHeight(Row row, int relativeRowIndex) {
        if (relativeRowIndex + 1 == rowNum) {
            //设置行隐藏
            row.setHeightInPoints((0));
        }
    }

}