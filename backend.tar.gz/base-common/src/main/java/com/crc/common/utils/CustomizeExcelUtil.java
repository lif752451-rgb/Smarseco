package com.crc.common.utils;

import cn.hutool.core.util.StrUtil;
import com.crc.common.constant.Constants;
import com.crc.common.exception.CustomException;
import com.crc.common.utils.poi.ExcelUtil;
import org.apache.commons.io.IOUtils;
import org.apache.commons.lang3.StringUtils;
import org.apache.poi.hssf.usermodel.HSSFCell;
import org.apache.poi.hssf.usermodel.HSSFRow;
import org.apache.poi.hssf.usermodel.HSSFSheet;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.apache.poi.ss.usermodel.*;
import org.apache.poi.xssf.usermodel.XSSFCell;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.springframework.web.multipart.MultipartFile;

import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.io.InputStream;
import java.net.URLEncoder;
import java.util.*;
import java.util.function.BiFunction;
import java.util.function.Function;

import static com.crc.common.constant.Constants.EXCEL_CELL_MAXIMUM;
import static com.crc.common.constant.Constants.EXCEL_CELL_MAX_LENGTH;

/**
 * Classname:CustomizeExcelUtil
 * Description: 自定义列excel操作工具类
 * Author: cymiao
 * Date: 2021/7/20 16:15
 **/
public class CustomizeExcelUtil {

    /**
     * 创建Workbook对象
     * @param is
     * @param excelFileName
     * @return
     * @throws IOException
     */
    public static Workbook createWorkbook(InputStream is, String excelFileName) throws IOException {
        if (excelFileName.endsWith(".xls")) {
            if (null != is) {
                return new HSSFWorkbook(is);
            }
            return new HSSFWorkbook();
        } else if (excelFileName.endsWith(".xlsx") || excelFileName.endsWith(".xltm")  || excelFileName.endsWith(".xlsm")) {
            if (null != is) {
                return new XSSFWorkbook(is);
            }
            return new XSSFWorkbook();
        }
        return null;
    }

    /**
     * 创建excel名称
     * @param workbook
     */
    public static void createExcelName(Workbook workbook,String nameName,String expression){
        nameName = nameName.replace(Constants.Symbol.LEFT_PARENTHESES, Constants.Symbol.BLANK)
                .replace(Constants.Symbol.RIGHT_PARENTHESES, Constants.Symbol.BLANK)
                .replace(Constants.Symbol.ZH_LEFT_PARENTHESES, Constants.Symbol.BLANK)
                .replace(Constants.Symbol.ZH_RIGHT_PARENTHESES, Constants.Symbol.BLANK);
        Name name = workbook.getName(nameName);
        if(null == name) {
            name = workbook.createName();
            name.setNameName(nameName);
            name.setRefersToFormula(expression);
        }

    }

    /**
     * 解析excel数据
     * @param file
     * @param sheetName
     * @param keys
     * @param verificationFunction
     * @return
     */
    public static List<Map<String,String>> readExcelData(MultipartFile file, String sheetName, Map<String,String> keys, Function<Workbook,Object> verificationFunction){
        List<Map<String,String>> result = null;
        try(InputStream input = file.getInputStream()){
            result = new ArrayList<>();

            // 创建文档
            XSSFWorkbook wb = new XSSFWorkbook(input);

            //业务验证
            if(null != verificationFunction){
                verificationFunction.apply(wb);
            }
            XSSFSheet XSSFSheet = wb.getSheet(sheetName);
            if(XSSFSheet == null){
                throw new CustomException("文件错误");
            }

            //读取Row
            int totalRows = XSSFSheet.getLastRowNum();
            String[] titles = null;
            Map<String,String> rowMap = null;
            for(int rowNum = 0;rowNum <= totalRows;rowNum++){
                XSSFRow xssfRow = XSSFSheet.getRow(rowNum);
                if(xssfRow!=null){
                    if(rowNum == 0) {
                        titles = new String[xssfRow.getLastCellNum()];
                        XSSFCell cell = null;
                        for (int i = 0, num = xssfRow.getLastCellNum(); i < num; i++) {
                            cell = xssfRow.getCell(i);
                            titles[i] = cell.getStringCellValue();
                        }
                    }else{
                        rowMap = new HashMap<>();
                        int totalCells = EXCEL_CELL_MAX_LENGTH;
                        //读取列，从第一列开始
                        XSSFCell cell = null;
                        for(int i=0;i<=totalCells;i++){
                            cell = xssfRow.getCell(i);
                            if(cell==null){
                                continue;
                            }
                            String value = String.valueOf(getCellData(cell)).trim().replaceAll(" ","");
                            if(keys.containsKey(titles[i])){
                                rowMap.put(keys.get(titles[i]), value);
                            }
                        }
                        if(verificationRowData(rowMap)){
                            result.add(rowMap);
                        }
                    }
                }
            }
        }catch (IOException e){
            throw new CustomException("文件解析失败");
        }
        return result;
    }

    /**
     * 写入数据
     * @param workbook
     * @param data
     * @param keys
     * @param sheetName
     */
    public static void wirteData(Workbook workbook, List<Map<String,String>> data, Map<String, String> keys, String sheetName, Function<Row,BiFunction<Integer,String,Object>> function){
        Sheet sheet = workbook.getSheet(sheetName);
        //读取标题
        Row row = sheet.getRow(0);
        int lastCellNum = row.getLastCellNum();
        String[] titles = new String[lastCellNum];
        for(int i = 0; i < lastCellNum;i++){
            titles[i] = String.valueOf(getCellData(row.getCell(i))).trim().replaceAll(" ","");
        }

        // 导出数据样式
        CellStyle style = ExcelUtil.getDataStyle(workbook);
        int num = 1;
        Cell cell = null;
        for(Map<String,String> rowData : data){
            row = sheet.getRow(num);
            if(null == row){
                row = sheet.createRow(num);
            }
            Set<Map.Entry<String, String>> entrySet = keys.entrySet();
            int missNum = 0;
            for(Map.Entry<String, String> keyEntry : entrySet){
                boolean bool = false;
                for(int i = 0,size = titles.length;i < size;i++){
                    if(keyEntry.getKey().equals(titles[i])){
                        cell = row.getCell(i);
                        if(null == cell){
                            cell = row.createCell(i);
                        }
                        cell.setCellStyle(style);
                        String cellValue = rowData.get(keyEntry.getValue());
                        if(StrUtil.isNotEmpty(cellValue) && cellValue.length()>EXCEL_CELL_MAXIMUM){
                            cellValue = cellValue.substring(0,EXCEL_CELL_MAXIMUM);
                        }
                        cell.setCellValue(cellValue);
                        bool = true;
                        break;
                    }
                }
                if(!bool){
                    /*cell = row.createCell(lastCellNum + missNum);
                    cell.setCellValue(rowData.get(keyEntry.getValue()));*/
                    if(null != function){
                        function.apply(row).apply(lastCellNum + missNum,rowData.get(keyEntry.getValue()));
                    }
                    missNum++;
                }
            }
            num++;
        }
    }

    private static boolean verificationRowData(Map<String,String> rowMap){
        Set<Map.Entry<String, String>> entries = rowMap.entrySet();
        boolean result = false;
        for(Map.Entry<String, String> data : entries){
            if(StringUtils.isNotEmpty(data.getValue())){
                result = true;
                break;
            }
        }
        return result;
    }

    /**
     * 读取excel文件数据
     * @param file
     * @param startReadRow
     * @param startReadColl
     * @return
     */
    private static List<ArrayList<String>> readXls(MultipartFile file, int startReadRow, int startReadColl){
        List<ArrayList<String>> list = new ArrayList<>();
        // IO流读取文件
        InputStream input = null;
        HSSFWorkbook wb = null;
        ArrayList<String> rowList = null;
        try {
            input = file.getInputStream();
            // 创建文档
            wb = new HSSFWorkbook(input);
            //读取sheet(页)
            for(int numSheet=0;numSheet<wb.getNumberOfSheets();numSheet++){
                HSSFSheet hssfSheet = wb.getSheetAt(numSheet);
                if(hssfSheet == null){
                    continue;
                }
                int totalRows = hssfSheet.getLastRowNum();
                //读取Row,从第二行开始
                for(int rowNum = startReadRow;rowNum <= totalRows;rowNum++){
                    HSSFRow hssfRow = hssfSheet.getRow(rowNum);
                    if(hssfRow!=null){
                        rowList = new ArrayList<String>();
                        int totalCells = hssfRow.getLastCellNum();
                        //读取列，从第一列开始
                        for(int c=startReadColl;c<=totalCells+1;c++){
                            HSSFCell cell = hssfRow.getCell(c);
                            if(cell==null){
                                rowList.add("");
                                continue;
                            }
                            rowList.add(String.valueOf(getCellData(cell)).trim());
                        }
                        list.add(rowList);
                    }
                }
            }
            return list;
        } catch (IOException e) {
            e.printStackTrace();
        } finally{
            IOUtils.closeQuietly(input);
        }
        return null;
    }

    /**
     * 获取单元格信息
     * @param cell
     * @return
     */
    private static Object getCellData(Cell cell) {
        Object data = null;
        switch (cell.getCellType()) {
            // 数字
            case NUMERIC:
                data = cell.getNumericCellValue();
                break;
            // 字符串
            case STRING:
                data = cell.getStringCellValue();
                break;
            // Boolean
            case BOOLEAN:
                data = cell.getBooleanCellValue();
                break;
            // 公式
            case FORMULA:
                data = cell.getCellFormula();
                break;
            // 空值
            case BLANK:
                data = "";
                break;
            // 故障
            case ERROR:
            default:
                data = null;
                break;
        }
        return data;
    }

    /**
     * 创建导出表头
     * @param workbook
     * @param titles
     * @param sheetName
     */
    public static void wirteTitle(Workbook workbook,List<String> titles,String sheetName){
        Sheet sheet = workbook.getSheet(sheetName);
        if(null == sheet){
            sheet = workbook.createSheet(sheetName);
        }
        // 表头样式
        CellStyle style = ExcelUtil.getHeaderStyle(workbook);
        Row row = sheet.createRow(0);
        Cell cell = null;
        for(int cellNum = 0,size = titles.size();cellNum < size; cellNum++){
            cell = row.createCell(cellNum);
            cell.setCellValue(titles.get(cellNum));
        }
    }

    public static void wirteOutExcel(HttpServletResponse response,Workbook workbook, String outputName) throws IOException{
        response.setContentType("application/octet-stream");
        response.setHeader("Content-Disposition", "attachment;filename=" + URLEncoder.encode(outputName, "utf-8"));
        response.flushBuffer();
        workbook.write(response.getOutputStream());
    }


    /**
     * 带数据量的导出文件
     *
     * @param response
     * @param workbook
     * @param outputName
     * @param size
     * @throws IOException
     */
    public static void wirteOutExcel(HttpServletResponse response, Workbook workbook, String outputName, int size) throws IOException {
        response.setContentType("application/octet-stream");
        //response.setHeader("Content-Disposition", "attachment;filename=" + URLEncoder.encode(outputName, "utf-8"));
        response.setHeader("Content-Disposition", "attachment;" + "name=" + size + ";filename=" + URLEncoder.encode(outputName, "utf-8"));
        response.flushBuffer();
        workbook.write(response.getOutputStream());
    }
}
