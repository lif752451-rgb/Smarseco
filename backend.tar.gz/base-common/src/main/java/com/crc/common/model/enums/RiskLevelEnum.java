package com.crc.common.model.enums;

/**
 * @Author shufengfeng
 * @Description 风险闭环管理-自动发现-风险等级
 * @DateTime 2021/10/13 10:35
 */
public enum RiskLevelEnum {

    HIGH_RISK("高风险", "1"),
    MEDIUM_RISK("中风险", "2"),
    LOW_RISK("低风险", "3"),


    ;


    /**
     * 名称
     */
    private String label;

    /**
     * 字典键值
     */
    private String value;

    RiskLevelEnum(String label, String value){
        this.label = label;
        this.value = value;
    }


    public String getLabel() {
        return label;
    }

    public void setLabel(String label) {
        this.label = label;
    }

    public String getValue() {
        return value;
    }

    public void setValue(String value) {
        this.value = value;
    }



}
