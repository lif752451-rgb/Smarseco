package com.crc.common.model.enums;

import lombok.AllArgsConstructor;
import lombok.Getter;

/**
 * 描述：系统分组 枚举
 *
 * @author fuzhuangzhi
 * @date 2022/3/31 10:19
 */
@Getter
@AllArgsConstructor
public enum SysGroupTypeEnum {

    /**
     * 可视化报表
     */
    VISUAL_CHART("visualChart", "可视化报表", "100"),

    /**
     * 处置建议库
     */
    KNOWLEDGE_HANDLE("knowledgeHandle", "处置建议库", "200"),

    /**
     * 处置反馈指南
     */
    KNOWLEDGE_FEEDBACK("knowledgeFeedback", "处置反馈指南", "300"),

    /**
     * 研判知识库
     */
    KNOWLEDGE_AJ("knowledgeAj", "研判知识库", "500"),

    /**
     * 系统字典数据
     */
    SYS_DICT_TYPE("sysDictType", "系统字典数据", "600"),

    /**
     * 通报分类
     */
    NOTICE_TYPE("noticeType", "通报分类", "700"),
    ;

    /**
     * 名称
     */
    private final String name;

    /**
     * 描述
     */
    private final String desc;

    /**
     * 对应数据库主键ID
     */
    private final String id;

    public static boolean isContain(String name) {
        for (SysGroupTypeEnum sysGroupTypeEnum : SysGroupTypeEnum.values()) {
            if (name.equals(sysGroupTypeEnum.getName())) {
                return Boolean.TRUE;
            }
        }
        return Boolean.FALSE;
    }
}