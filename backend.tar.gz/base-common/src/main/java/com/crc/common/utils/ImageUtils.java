package com.crc.common.utils;

import org.apache.commons.io.IOUtils;
import org.jfree.chart.ChartUtilities;
import org.jfree.chart.JFreeChart;

import java.io.File;
import java.io.FileOutputStream;

/**
 * 描述：图片生成 工具类
 *
 * @Author: fuzhuangzhi
 * @Date: 2021/12/8 19:10
 */
public class ImageUtils {

    public static String createImage(String localPath, JFreeChart chart) {
        FileOutputStream fos_jpg = null;
        String fileName = null;
        try {
            String chartName = IdGen.uuid() + ".jpg";
            File dir = new File(localPath);
            fileName = localPath + File.separator + chartName;
            if (!dir.exists()) {
                dir.mkdir();
            }
            fos_jpg = new FileOutputStream(fileName);
            // 将报表保存为png文件
            ChartUtilities.writeChartAsPNG(fos_jpg, chart, 1000, 400);
            return chartName;
        } catch (Exception e) {
            e.printStackTrace();
            return null;
        } finally {
            IOUtils.closeQuietly(fos_jpg);
        }
    }
}
