package com.crc.common.model.enums;

import lombok.Getter;

/**
 * 自定义列类型枚举
 *
 * @author zhangbing
 */
@Getter
public enum ProcessHeaderShowEnum {

    /**
     * 告警闭环管理
     */
    ALARM_MANAGE("告警闭环管理", "alarmManage"),

    /**
     * 告警闭环管理搜索条件显示列
     */
    ALARM_MANAGE_SEARCH("告警闭环管理搜索条件显示列", "alarmManageSearch"),

    /**
     * 网段管理
     */
    NET_SEGMENT_MANAGE("网段管理", "netSegmentManage"),

    /**
     * 资产软件许可证
     */
    ASSET_SOWFWARE_LICENSE("资产软件许可证", "license"),

    /**
     * 资产协同-资产认领列表显示列
     */
    ASSET_CLAIM("资产协同-资产认领列表显示列", "assetClaim"),

    /**
     * 资产协同-资产认领搜索条件显示列
     */
    ASSET_CLAIM_SEARCH("资产协同-资产认领搜索条件显示列", "assetClaimSearch"),

    /**
     * 资产协同-资产网段列表展示列
     */
    ASSET_SEGMENT("资产协同-资产网段列表展示列", "assetSegment"),

    /**
     * 资产协同-资产网段列表搜索条件显示列
     */
    ASSET_SEGMENT_SEARCH("资产协同-资产网段列表搜索条件显示列", "assetSegmentSearch"),

    /**
     * 资产协同-国资监管资产列表展示列
     */
    INTERNET_ASSET("资产协同-国资监管资产列表展示列", "internetAsset"),

    /**
     * 资产协同-国资监管资产列表搜索条件显示列
     */
    INTERNET_ASSET_SEARCH("资产协同-国资监管资产列表搜索条件显示列", "internetAssetSearch"),

    /**
     * 资产管理
     */
    ASSET_MANAGE("资产管理", "assetManage"),

    /**
     * 资产全景
     */
    ASSET_SCREEN("资产全景", "assetScreen"),

    /**
     * 资产查询
     */
    ASSET_SEARCH("资产查询", "assetSearch"),

    /**
     * 漏洞待修复
     */
    VUL_REPAIRING("漏洞待修复", "vulRepairing"),

    /**
     * 漏洞已修复
     */
    VUL_REPAIRED("漏洞已修复", "vulRepaired"),

    /**
     * 风险闭环管理-自动发现
     */
    RISK_AUTO("风险闭环管理-自动发现", "riskAuto"),

    /**
     * 关停系统
     */
    ASSET_CLOSE_DOWN("关停系统", "assetCloseDown"),

    /**
     * 告警白名单
     */
    ALARM_WHITE_LIST("告警白名单", "alarmWhiteList"),

    /**
     * 告警白名单
     */
    ALARM_WHITE_LIST_SEARCH("告警白名单搜索", "alarmWhiteListSearch"),

    /**
     * 告警白名单已审核
     */
    ALARM_WHITE_LIST_DONE("告警白名单", "alarmWhiteListDone"),


    /**
     * 告警响应
     */
    ALARM_RESPONSE("告警响应", "alarmResponse"),

    /**
     * 风险上报-待推送
     */
    RISK_WAIT_PUSH("风险上报-待推送展示", "riskWaitPush"),

    /**
     * 风险上报-待推送
     */
    RISK_WAIT_PUSH_SEARCH("风险上报-待推送搜索", "riskWaitPushSearch"),


    /**
     * 风险上报-已推送
     */
    RISK_IS_PUSH("风险上报-已推送展示", "riskIsPush"),

    /**
     * 风险上报-已推送
     */
    RISK_IS_PUSH_SEARCH("风险上报-已推送搜索", "riskIsPushSearch"),

    /**
     * 风险提交-待推送
     */
    RISK_Submit_SAVED("风险提交-待推送", "riskSubmitSaved"),

    /**
     * 风险提交-已推送
     */
    RISK_SUBMIT_PUSHED("风险提交-已推送", "riskSubmitPushed"),

    /**
     * 风险闭环管理-人工
     */
    RISK_CLOSED_LOOP("风险闭环管理-人工", "riskClosedLoop"),

    /**
     * 告警模型-通用模型
     */
    EVENT_MODEL_COMMON("告警模型-通用模型", "eventModelCommon"),

    /**
     * 告警模型-自定义模型
     */
    EVENT_MODEL_DEFINE("告警模型-自定义模型", "eventModelDefine"),


    /**
     * 告警模型-查询
     */
    EVENT_MODEL_SEARCH("告警模型-自定义模型", "eventModelSearch"),

    /**
     * 日志解析-自定义解析规则
     */
    LOG_PARSE_DEFINE("日志解析-自定义解析规则", "logParseDefine"),

    /**
     * 日志解析-自定义解析规则
     */
    BEHAVIOR_LOG("日志解析-自定义解析规则", "behaviorLog"),

    /**
     * 数据库管理-数据源管理
     */
    DATABASE_SOURCE("数据库管理-数据源管理", "databaseSource"),

    /**
     * 数据库管理-数据索引管理
     */
    DATABASE_INDEX("数据库管理-数据索引管理", "databaseIndex"),

    /**
     * 告警闭环HVV管理
     */
    ALARM_HVV_MANAGE("告警闭环HVV管理", "alarmHvvManage"),

    /**
     * STP漏洞情报收集列表
     */
    VULN_INFORMATION_LIST_STP("STP漏洞情报收集列表", "vulnInformationListSTP"),

    /**
     * 研判知识库
     */
    KNOWLEDGE_AJ("研判知识库", "knowledgeAj"),

    /**
     * 处置建议库
     */
    KNOWLEDGE_HANDLE("处置建议库", "knowledgeHandle"),

    /**
     * 处置反馈指南
     */
    KNOWLEDGE_FEEDBACK("处置反馈指南", "knowledgeFeedback"),

    /**
     * 任务管理
     */
    TASK_MANAGER("任务管理", "taskManager"),

    /**
     * IOC情报库
     */
    INTELLIGENCE_IOC("IOC情报库", "intelligenceIoc"),

    /**
     * 资产应用系统
     */
    ASSET_APP_SYSTEM("资产应用系统", "assetAppSystem"),

    /**
     * 在建应用系统
     */
    BUILDING_SYSTEM("在建应用系统", "buildingSystem"),

    /**
     * 巡检任务
     */
    ASSET_INSPECTION_TASK("巡检任务", "assetInspectionTask"),

    /**
     * 巡检项
     */
    ASSET_INSPECTION_ITEM("巡检项", "assetInspectionItem"),

    /**
     * 应用系统-等保定级
     */
    EQUAL_GRADE("应用系统-等保定级", "equalGrade"),

    /**
     * 应用系统-渗透测试
     */
    INFILTRATION("应用系统-渗透测试", "penetrationTest"),

    /**
     * 全部漏洞-主机漏洞-待推送
     */
    PROCESS_ALL_VULN_NOT_PUSH("全部漏洞-主机漏洞-待推送", "processAllVulnNotPush"),

    /**
     * 全部漏洞-主机漏洞-已推送
     */
    PROCESS_ALL_VULN_ALREADY_PUSH("全部漏洞-主机漏洞-已推送", "processAllVulnAlreadyPush"),

    /**
     * 全部漏洞-WEB漏洞-待推送
     */
    WEB_VUL_WAIT_PUSH("全部漏洞-WEB漏洞-待推送", "webVulWaitPush"),

    /**
     * 全部漏洞-WEB漏洞-已推送
     */
    WEB_VUL_PUSHED("全部漏洞-WEB漏洞-已推送", "webVulPushed"),

    /**
     * 全部漏洞-弱口令-待推送
     */
    WEAK_PASSWORD_VUL_WAIT_PUSH("全部漏洞-弱口令-待推送", "weakPassWordVulWaitPush"),

    /**
     * 全部漏洞-弱口令-已推送
     */
    WEAK_PASSWORD_VUL_PUSHED("全部漏洞-弱口令-已推送", "weakPassWordVulPushed"),

    /**
     * 漏洞闭环-主机漏洞
     */
    PROCESS_VULN_LOOP("漏洞闭环-主机漏洞", "processVulnLoop"),

    /**
     * 漏洞闭环-WEB漏洞
     */
    WEB_VULN_LOOP("漏洞闭环-WEB漏洞", "webVulnLoop"),

    /**
     * 漏洞闭环-弱口令漏洞
     */
    CODE_VULN_LOOP("漏洞闭环-弱口令漏洞", "codeVulnLoop"),

    /**
     * 待审批延期
     */
    VUL_WAIT_DELAY("待审批延期", "vulDelayWait"),

    /**
     * 已审批延期
     */
    VUL_DONE_DELAY("已审批延期", "vulDelayDone"),

    /**
     * 代码审计-闭环缺陷
     */
    CODE_AUDIT_LOOP("代码审计-闭环缺陷", "codeAuditDefectLoop"),

    /**
     * 待推送代码审计缺陷
     */
    CODE_AUDIT_DEFECT_WAIT("待推送代码审计缺陷", "codeAuditDefectWait"),

    /**
     * 已推送代码审计缺陷
     */
    CODE_AUDIT_DEFECT_DONE("已推送代码审计缺陷", "codeAuditDefectDone"),

    /**
     * 待审核漏洞白名单
     */
    VUL_WAIT_WHITE_LIST("待审核漏洞白名单", "vulWaitWhiteList"),

    /**
     * 已审核漏洞白名单
     */
    VUL_DONE_WHITE_LIST("已审核漏洞白名单", "vulDoneWhiteList"),

    /**
     * 代码扫描任务
     */
    CODE_CHECK_TASK("代码扫描任务", "codeCheckTask"),

    /**
     * 漏洞扫描
     */
    VULN_SCAN_TASK("漏洞扫描", "vulnScanTask"),

    /**
     * 资产-攻击面-信息泄露管理
     */
    ASSET_ASM_INFO_LEAK("资产-攻击面-信息泄露管理", "assetAsmInfoLeak"),

    /**
     * 资产-攻击面-互联网资产管理
     */
    ASSET_ASM_INTERNET("资产-攻击面-互联网资产管理", "assetAsmInternet"),

    /**
     * 资产-攻击面-互联网资产管理
     */
    ASSET_ASM_INTERNET_SEARCH("资产-攻击面-互联网资产管理搜索条件显示列", "assetAsmInternetSearch"),

    /**
     * 资产-攻击面-互联网资产管理-认领显示列
     */
    ASSET_ASM_INTERNET_CLAIM("资产-攻击面-互联网资产管理-认领", "assetAsmInternetClaim"),

    /**
     * 资产-攻击面-互联网资产管理-认领搜索列
     */
    ASSET_ASM_INTERNET_CLAIM_SEARCH("资产-攻击面-互联网资产管理-认领搜索条件显示列", "assetAsmInternetSearchClaim"),

    /**
     * 资产-攻击面-互联网资产管理搜索条件显示列
     */
    ASSET_ASM_DOMAIN("资产-攻击面-域名管理", "assetAsmDomain"),

    /**
     * 资产-攻击面-域名管理搜索条件显示列
     */
    ASSET_ASM_DOMAIN_SEARCH("资产-攻击面-域名管理搜索条件显示列", "assetAsmDomainSearch"),

    /**
     * 资产-攻击面-信息泄露管理搜索条件显示列
     */
    ASSET_ASM_INFO_LEAK_SEARCH("资产-攻击面-信息泄露管理搜索条件显示列", "assetAsmInfoLeakSearch"),
    /**
     * 终端设备显示列
     */
    ASSET_TERMINAL_EQUIPMENT("终端资产-终端设备显示列", "assetTerminalEquipment"),
    /**
     * 终端设备搜索条件显示列
     */
    ASSET_TERMINAL_EQUIPMENT_SEARCH("终端资产-终端设备搜索条件显示列", "assetTerminalEquipmentSearch"),

    /**
     * 威胁管理-实战告警闭环-集团
     */
    ALARM_COMBAT_GROUP("威胁管理-实战告警闭环-集团", "alarmCombatGroup"),

    /**
     * 威胁管理-实战告警闭环-集团搜索条件显示列
     */
    ALARM_COMBAT_GROUP_SEARCH("威胁管理-实战告警闭环-集团搜索条件显示列", "alarmCombatGroupSearch"),

    /**
     * 威胁管理-实战告警闭环-租户
     */
    ALARM_COMBAT_TENANT("威胁管理-实战告警闭环-租户", "alarmCombatTenant"),

    /**
     * 威胁管理-实战告警闭环-租户搜索条件显示列
     */
    ALARM_COMBAT_TENANT_SEARCH("威胁管理-实战告警闭环-租户搜索条件显示列", "alarmCombatTenantSearch"),

    /**
     * 实战任务管理
     */
    TASK_COMBAT_SEARCH("实战任务管理", "taskCombatSearch"),

    /**
     * 实战任务管理
     */
    ALARM_RESPOND_SEARCH("防守画像-常态化告警响应-搜索条件显示列", "alarmRespondSearch"),

    /**
     * 防守画像-实战告警响应-搜索条件显示列
     */
    ALARM_COMBAT_RESPOND_SEARCH("防守画像-实战告警响应-搜索条件显示列", "alarmCombatRespondSearch"),

    /**
     * 互联网域名管理搜索条件显示列
     */
    F5_DOMAIN_SEARCH("互联网域名管理搜索条件显示列", "f5DomainSearch"),

    /**
     * 数据设备接入
     */
    DATA_DEVICE("数据接入字段显示列", "dataDevice"),

    /**
     * 数据设备接入搜索
     */
    DATA_DEVICE_SEARCH("数据接入搜索条件显示列", "dataDeviceSearch"),

    /**
     * SCP数据设备接入搜索
     */
    DATA_DEVICE_SCP_SEARCH("数据接入搜索条件显示列", "dataDeviceScpSearch"),

    /**
     * 数据解析
     */
    DATA_LOG_PARSE("数据解析字段显示列", "dataLogParse"),

    /**
     * 基线问题列表-搜索条件展示列
     */
    BASELINE_PROCESS_FORM_SEARCH("基线问题列表-搜索条件展示列", "baselineProcessFormSearch"),

    /**
     * 基线问题列表-字段展示列
     */
    BASELINE_PROCESS_FORM("基线问题列表-字段展示列", "baselineProcessForm"),

    /**
     * 基线问题列表-字段展示列
     */
    BASELINE_PROCESS_FORM_PUSH("基线问题列表-字段展示列", "baselineProcessFormPush"),

    /**
     * 基线问题列表-搜索条件展示列
     */
    BASELINE_PROCESS_BUSINESS_SEARCH("基线问题闭环列表-搜索条件展示列", "baselineProcessBusinessSearch"),

    /**
     * 基线问题列表-字段展示列
     */
    BASELINE_PROCESS_BUSINESS("基线问题闭环列表-字段展示列", "baselineProcessBusiness"),

    /**
     * 基线待审批表头
     */
    BASE_WAIT_APPROVE("脆弱性管理-基线管理-基线问题延期", "baseWaitApprove"),

    /**
     * 基线待审批查询
     */
    BASE_WAIT_APPROVE_SEARCH("脆弱性管理-基线管理-基线问题延期搜索列", "baseDelaySearch"),

    /**
     * 基线已审批表头
     */
    BASE_DONE_APPROVE("脆弱性管理-基线管理-基线问题延期", "baseDoneApprove"),

    /**
     * 数据解析搜索
     */
    DATA_LOG_PARSE_SEARCH("数据解析搜索条件显示列", "dataLogParseSearch"),


    /**
     * SCP互联网发布
     */
    SCP_INTERNET("SCP互联网发布", "scpInternet"),

    /**
     * 实战任务管理
     */
    SCP_INTERNET_SEARCH("SCP互联网发布", "scpInternetSearch"),

    /**
     * 风险整改延期搜索
     */
    RISK_PROCESS_DELAY_SEARCH("风险整改延期搜索", "riskProcessDelaySearch"),

    /**
     * 风险管理-风险整改-风险整改闭环-字段搜索列
     */
    RISK_PROCESS_BUSINESS_SEARCH("风险管理-风险整改-风险整改闭环-字段搜索列", "riskProcessBusinessSearch"),

    /**
     * 基线问题列表-字段展示列
     */
    RISK_PROCESS_BUSINESS("风险管理-风险整改-风险整改闭环-字段展示列", "riskProcessBusiness"),

    /**
     * 资产管理-应用系统-字段搜索列
     */
    ASSET_APP_SYSTEM_SEARCH("资产管理-应用系统-字段搜索列", "assetAppSystemSearch"),

    /**
     * 资产管理-在建应用系统-字段搜索列
     */
    ASSET_BUILD_APP_SYSTEM_SEARCH("资产管理-在建应用系统-字段搜索列", "assetBuildAppSystemSearch"),

    /**
     * 合规管理-安全监管-法规标准管理显示列
     */
    SUPER_VERSION_RULE("合规管理-安全监管-法规标准管理显示列", "superVersionRule"),

    /**
     * 合规管理-安全监管-法规标准管理搜索
     */
    SUPER_VERSION_RULE_SEARCH("合规管理-安全监管-法规标准管理搜索", "superVersionRuleSearch"),

    /**
     * 合规管理-安全监管-法规条目管理显示列
     */
    SUPER_VERSION_RULE_ITEM("合规管理-安全监管-法规条目管理显示列", "superVersionRuleItem"),

    /**
     * 合规管理-安全监管-法规条目管理搜索
     */
    SUPER_VERSION_RULE_ITEM_SEARCH("合规管理-安全监管-法规条目管理搜索", "superVersionRuleItemSearch"),

    /**
     * 合规管理-安全监管-监管案例显示列
     */
    SUPER_VERSION_CASE("合规管理-安全监管-法规标准管理显示列", "superVersionCase"),

    /**
     * 合规管理-安全监管-监管案例搜索
     */
    SUPER_VERSION_CASE_SEARCH("合规管理-安全监管-法规标准管理搜索", "superVersionCaseSearch"),

    /**
     * 脆弱性管理-漏洞发现-字段搜索列
     */
    VUL_PROCESS_SEARCH("脆弱性管理-漏洞发现-字段搜索列","vulProcessSearch"),

    /**
     * 脆弱性管理-漏洞闭环-字段搜索列
     */
    VUL_PROCESS_BUSINESS_SEARCH("脆弱性管理-漏洞闭环-字段搜索列","vulProcessBusinessSearch"),

    /**
     * 情报管理-漏洞情报-字段搜索列
     */
    VULN_INFORMATION_SEARCH("情报管理-漏洞情报-字段搜索列","vulnInformationSearch"),

    /**
     * 情报管理-IOC情报-字段搜索列
     */
    INTELLIGENCE_IOC_SEARCH("情报管理-IOC情报-字段搜索列","intelligenceIocSearch"),

    /**
     * 脆弱性管理-漏洞白名单-字段搜索列
     */
    VUL_WHITE_SEARCH("脆弱性管理-漏洞白名单-字段搜索列","vulWhiteSearch"),

    /**
     * 脆弱性管理-漏洞处置延期-字段搜索列
     */
    VUL_PROCESS_DELAY_SEARCH("脆弱性管理-漏洞处置延期-字段搜索列","vulProcessDelaySearch"),

    /**
     * 脆弱性管理-漏洞扫描-字段搜索列
     */
    VUL_SCAN_TASK_SEARCH("脆弱性管理-漏洞扫描-字段搜索列","vulScanTaskSearch"),

    /**
     * 合规管理-安全责任书创建-字段搜索列
     */
    TASK_LIABILITY_CREATE_SEARCH("任务管理-安全责任书创建-字段搜索列","taskLiabilityCreateSearch"),

    /**
     * 合规管理-安全责任书签订-字段搜索列
     */
    TASK_MANAGER_SEARCH("任务管理-安全责任书签订-字段搜索列","TaskManagerSearch"),

    /**
     * 合规管理-保密协议创建-字段搜索列
     */
    SECRECY_PROTOCOL_CREATE_SEARCH("合规管理-保密协议创建-字段搜索列","secrecyProtocolCreateSearch"),

    /**
     * 合规管理-保密协议签订-字段搜索列
     */
    SECRECY_PROTOCOL_SEARCH("合规管理-保密协议签订-字段搜索列","secrecyProtocolSearch"),

    /**
     * 合规管理-安全考核-项目管理-字段搜索列
     */
    CHECK_PROJECT_MANAGE_SEARCH("考核管理-项目管理搜索列","checkProjectManageSearch"),

    /**
     * 合规管理-安全考核-项目管理-字段显示列
     */
    CHECK_PROJECT_MANAGE_SHOW_SEARCH("考核管理-项目管理显示列","checkProjectManageShowSearch"),

    /**
     * 合规管理-安全考核-考核反馈-字段搜索列
     */
    CHECK_FEEDBACK_SEARCH("考核管理-考核反馈-字段搜索列","checkFeedBackSearch"),

    /**
     * 考核管理-考核反馈-字段显示列
     */
    CHECK_FEEDBACK_SHOW_SEARCH("考核管理-考核反馈-字段显示列","checkFeedBackShowSearch"),

    /**
     * 合规管理-安全考核-考核模板-字段搜索列
     */
    CHECK_TEMPLATE_SEARCH("考核管理-考核模板-字段搜索列","checkTemplateSearch"),

    /**
     * 考核管理-考核模板-字段显示列
     */
    CHECK_TEMPLATE_SHOW_SEARCH("考核管理-考核模板-字段显示列","checkTemplateShowSearch"),

    /**
     * 合规管理-安全考核-专家分配-字段搜索列
     */
    CHECK_APPEAL_SEARCH("合规管理-安全考核-专家-字段搜索列","checkAppealSearch"),

    /**
     * 考核管理-安全考核-专家分配-字段显示列
     */
    CHECK_APPEAL_SHOW_SEARCH("考核管理-安全考核-专家-字段显示列","checkAppealShowSearch"),

    /**
     * 合规管理-安全考核-考核评分-字段搜索列
     */
    CHECK_SCORE_SEARCH("考核管理-考核评分-字段搜索列","checkScoreSearch"),

    /**
     * 考核管理-考核评分-字段显示列
     */
    CHECK_SCORE_SHOW_SEARCH("考核管理-考核评分-字段显示列","checkScoreShowSearch"),

    /**
     * 考核管理-申诉审核-字段搜索列
     */
    CHECK_SCORE_APPEAL_SEARCH("考核管理-申诉审核-字段搜索列","checkScoreAppealSearch"),

    /**
     * 考核管理-申诉审核-字段显示列
     */
    CHECK_SCORE_APPEAL_SHOW_SEARCH("考核管理-申诉审核-字段显示列","checkScoreAppealShowSearch"),

    /**
     * 制度库-法律法规
     */
    KNOWLEDGE_REGULATION("制度库-法律法规","institutionRegulation"),

    /**
     * 制度库-网安标准
     */
    KNOWLEDGE_NETSECURITY("制度库-网安标准","institutionNetsecurity"),

    /**
     * 制度库-典型方案
     */
    KNOWLEDGE_TYPICAL("制度库-典型方案","institutionTypical"),


    /**
     * 制度库-企业制度
     */
    KNOWLEDGE_ENTERPRISE("制度库-企业制度","institutionEnterprise"),

    /**
     * 安全通报-搜索列
     */
    SECURITY_NOTICE_SEARCH("安全通报-搜索列","securityNoticeSearch"),

    /**
     * 制度库-企业制度
     */
    SECURITY_NOTICE("安全通报-列表列","securityNotice"),

    /**
     * 安全通报-通报预警-搜索列
     */
    SECURITY_NOTICE_WARN_SEARCH("安全通报-通报预警-搜索列","securityNoticeWarnSearch"),

    /**
     * 安全通报-通报预警-显示列
     */
    SECURITY_NOTICE_WARN("安全通报-通报预警-显示列","securityNoticeWarn"),

    /**
     * 软件许可证-搜索列
     */
    SOFTWARE_LICENSE_SEARCH("安全通报-通报预警-搜索列","softwareLicenseSearch"),

    /**
     * 终端资产-资源申请记录-搜索列
     */
    TERMINAL_RESOURCE_APPLY_SEARCH("终端资产-资源申请记录-搜索列","terminalResourceApplySearch"),

    /**
     * 终端资产-资源申请记录-显示列
     */
    TERMINAL_RESOURCE_APPLY("终端资产-资源申请记录-显示列","terminalResourceApply"),

    /**
     * 软件资产-授权申请记录-搜索列
     */
    ASSET_SOFTWARE_APPLY_SEARCH("软件资产-授权申请记录-搜索列","assetSoftwareApplySearch"),

    /**
     * 软件资产-授权申请记录-显示列
     */
    ASSET_SOFTWARE_APPLY("软件资产-授权申请记录-显示列","assetSoftwareApply"),


    /**
     * 钓鱼邮件管理列表-显示列
     */
    PISHING_MAIL("钓鱼邮件管理列表-显示列","pushingMailSearch"),

    /**
     * 钓鱼邮件管理列表-显示列
     */
    PISHING_MAIL_SEARCH("钓鱼邮件管理列表-显示列","pushingMail"),

    /**
     * 物联网资产-搜索列
     */
    ASSET_IOT_EQUIPMENT_SEARCH("终端资产-资源申请记录-搜索列","assetIotEquipmentSearch"),

    /**
     * 物联网资产-显示列
     */
    ASSET_IOT_EQUIPMENT("终端资产-资源申请记录-显示列","assetIotEquipment"),

    ;

    ProcessHeaderShowEnum(String name, String code) {
        this.name = name;
        this.code = code;
    }

    /**
     * 自定义列类型名称
     */
    private final String name;

    /**
     * 自定义列类型编码
     */
    private final String code;

    public static boolean isContain(String code) {
        for (ProcessHeaderShowEnum headerShowEnum : ProcessHeaderShowEnum.values()) {
            if (code.equals(headerShowEnum.getCode())) {
                return Boolean.TRUE;
            }
        }
        return Boolean.FALSE;
    }
}
