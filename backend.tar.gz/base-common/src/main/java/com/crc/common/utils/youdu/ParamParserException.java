package com.crc.common.utils.youdu;


public class ParamParserException extends GeneralEntAppException {

    public ParamParserException(String message, Throwable cause) {
        super(message, cause);
    }
}
