package com.crc.common.model.enums;

import java.util.Arrays;

/**
 * @Author SHUFENGFENG
 * @Description 比较枚举
 * @DateTime 2022/3/16 10:13
 */
public enum CompareEnum {
    /**
     * 精准匹配
     */
    EQUAL("EQUAL"),
    /**
     * 模糊匹配
     */
    LIKE("LIKE"),
    /**
     * 大于
     */
    GREATER("GREATER"),
    /**
     * 大于等于
     */
    GREATER_OR_EQUAL("GREATER_OR_EQUAL"),
    /**
     * 小于
     */
    LESS("LESS"),
    /**
     * 小于等于
     */
    LESS_OR_EQUAL("LESS_OR_EQUAL"),


    ;

    private String value;

    CompareEnum(String value) {
        this.value = value;
    }

    public String getValue() {
        return value;
    }

    public void setValue(String value) {
        this.value = value;
    }

    /**
     * 校验是否包含比较枚举，有返回true,否则返回false
     * @return
     */
    public static boolean hasThan(CompareEnum compareEnum){
        return Arrays.asList(GREATER, GREATER_OR_EQUAL, LESS, LESS_OR_EQUAL).contains(compareEnum);
    }

}
