package com.crc.common.model.enums;

/**
 * @Author WANGLEI
 * @Description 菜单权限枚举
 * @DateTime 2022/3/16 17:10
 */
public enum MenuPermsEnum {

    SBP("personal","智能安全数智化平台"),
    ;

    /**
     * 权限
     */
    private String perms;

    /**
     * 描述
     */
    private String desc;

    MenuPermsEnum(String perms, String desc){
        this.perms = perms;
        this.desc = desc;
    }

    public String getPerms() {
        return perms;
    }

    public void setPerms(String perms) {
        this.perms = perms;
    }

    public String getDesc() {
        return desc;
    }

    public void setDesc(String desc) {
        this.desc = desc;
    }
}
