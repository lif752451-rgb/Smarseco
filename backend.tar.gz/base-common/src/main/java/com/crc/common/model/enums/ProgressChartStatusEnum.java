package com.crc.common.model.enums;

/**
 * @Author shufengfeng
 * @Description 进度图状态枚举
 * @DateTime 2021/9/30 17:13
 */
public enum ProgressChartStatusEnum {
    //历史
    HISTORY,
    //当前
    NOW,
    //未发生
    UN_HAPPEN,

    ;




}
