package com.crc.common.constant;

/**
 * 公共附件类型
 *
 * @author zhangbing
 * @since 2023/4/13 16:48
 */
public interface CommonAttBusinessType {

    /**
     * 基线闭环-流程操作附件类型
     */
    String BASELINE_LOOP_ACTION = "baselineLoopAction";

    /**
     * 基线闭环-延期声情附件信息
     */
    String BASELINE_DELAY = "baselineDelay";

    /**
     * 漏洞闭环-主机漏洞-流程操作附件类型
     */
    String VULN_LOOP_ACTION = "vulnLoopAction";

    /**
     * 应用系统等保定级附件类型
     */
    String EQUAL_GRADE_TYPE = "equalGrade";

    /**
     * 应用系统测试渗透附件类型
     */
    String PENETRATION_TEST_TYPE = "penetrationTest";

    /**
     * 应用系统
     */
    String ASSET_APP_SYSTEM_TYPE = "assetAppSystem";

    /**
     * 漏洞闭环-延期声情附件信息
     */
    String VUL_DELAY = "vulDelay";

    /**
     * 任务管理H5
     */
    String TASK_MANAGE_H5 = "taskManageH5";

    /**
     * 风险上报-上报附件类型
     */
    String RISK_PROCESS_FORM = "riskProcessForm";

    /**
     * 风险流程-备注
     */
    String RISK_PROCESS_REMARK = "riskProcessRemark";

    /**
     * 上报缺陷附件信息
     */
    String CODE_AUDIT_DEFECT = "codeAuditDefect";

    /**
     * 上报缺陷附件信息
     */
    String ASSET_ASM_INFO_LEAK = "assetAsmInfoLeak";

    /**
     * 实战告警闭环-上报告警附件类型
     */
    String ALARM_COMBAT_REPORT_TYPE = "alarmCombatReport";

    /**
     * 实战告警闭环-告警审批附件类型
     */
    String ALARM_COMBAT_APPROVAL_TYPE = "alarmCombatApproval";

    /**
     * 实战告警闭环-告警溯源附件类型
     */
    String ALARM_COMBAT_TRACEABILITY_TYPE = "alarmCombatTraceability";

    /**
     * 实战告警闭环-告警补充备注附件类型
     */
    String ALARM_COMBAT_REMARK_TYPE = "alarmCombatRemark";

    /**
     * 实战任务管理
     */
    String TASK_COMBAT_TYPE = "taskCombat";

    /**
     * 实战任务管理反馈
     */
    String TASK_COMBAT_TYPE_FEEDBACK = "taskCombatFeedback";

    /**
     * 告警闭环-告警审批附件类型
     */
    String ALARM_APPROVAL_TYPE = "alarmApproval";

    /**
     * 风险整改延期申请
     */
    String RISK_DELAY_APPLY = "riskDelayApply";

    /**
     * 风险整改-风险操作日志附件
     */
    String RISK_ACT_LOG = "riskActLog";

    /**
     * 合规管理-法规标准附件类型
     */
    String SUPER_VERSION_RULE = "superVersionRule";

    /**
     * 合规管理-安全考核-考核模板-指标管理附件类型
     */
    String CHECK_METRIC = "checkMetric";

    /**
     * 知识管理-制度库-制度管理附件
     */
    String INSTITUTION_MANAGER = "institutionManager";

    /**
     * 合规管理-安全考核-考核反馈-指标反馈
     */
    String CHECK_METRIC_ITEM_FEED_BACK = "checkMetricItemFeedBack";

    /**
     * 安全通报-通报预警-反馈附件
     */
    String SECURITY_NOTICE_WARN_FEEDBACK = "SecurityNoticeWarnFeedback";

    /**
     * 合规管理-安全考核-考核反馈-申诉
     */
    String CHECK_METRIC_SCORE_APPEAL = "checkMetricScoreAppeal";
}
