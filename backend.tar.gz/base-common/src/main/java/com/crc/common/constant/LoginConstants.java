package com.crc.common.constant;

/**
 * 登录配置常量类
 */
public interface LoginConstants {

    String USER_NAME = "username";

    /**
     * 竹云统一认证 数据字典类型
     */
    String ZY_DICT_TYPE = "zy_auth_config";

    /**
     * 大地统一认证 数据字典类型
     */
    String CONTINENT_DICT_TYPE = "continent_auth_config";

    /**
     * 统一身份认证开关 0 关闭 1 打开
     */
    String AUTH_SWITCH = "authSwitch";

    /**
     * 登录类型
     */
    String GRANT_TYPE = "grantType";

    /**
     * 统一认证登录链接
     */
    String LOGIN_URL = "loginUrl";

    /**
     * 统一认证登出链接
     */
    String LOGOUT_URL = "logoutUrl";

    /**
     * 统一认证 授权码获取token信息链接
     */
    String TOKEN_URL = "tokenUrl";

    /**
     * 统一认证 token获取用户信息链接
     */
    String USER_INFO_URL = "userInfoUrl";

    /**
     * 统一认证 token获取用户信息链接
     */
    String REFRESH_TOKEN_URL = "refreshTokenUrl";

    /**
     * 统一认证 应用标识
     */
    String CLIENT_ID = "clientId";

    /**
     * 统一认证 应用密钥
     */
    String CLIENT_SECRET = "clientSecret";

    /**
     * 统一认证 登录登出成功跳转链接
     */
    String REDIRECT_URI = "redirectUri";

    /**
     * 统一认证 授权码参数名称
     */
    String CODE = "code";

    /**
     * 统一认证 token参数名称
     */
    String ACCESS_TOKEN = "accessToken";

    /**
     * 统一认证 刷新token参数名称
     */
    String REFRESH_TOKEN = "refreshToken";

    /**
     * 竹云统一认证 获取用户信息参数名称
     */
    String USER_NAME_FIELD = "userNameField";

    /**
     * 密码模式登录
     */
    String PASSWORD = "password";

    /**
     * 竹云统一登录
     */
    String LDAP_UNIFIED_LOGIN = "ldapUnifiedLogin";

    /**
     * 大地统一登录
     */
    String CONTINENT_UNIFIED_LOGIN = "continentUnifiedLogin";

    /**
     * 有度统一登录
     */
    String YOUDU_UNIFIED_LOGIN = "youDuUnifiedLogin";

    /**
     * 客户端类型参数名称
     */
    String CLIENT_TYPE = "clientType";

    /**
     * 业务系统类型参数名称
     */
    String SYS_NAME_TYPE = "sysNameType";
}
