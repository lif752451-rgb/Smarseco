package com.crc.common.model.enums;

/**
 * @Author shufengfeng
 * @Description 部门枚举
 * @DateTime 2021/10/18 11:05
 */
public enum SysDeptEnum {

    /**
     * 根节点
     */
    ROOT("根节点",0L),

    /**
     * 华润云
     */
    HUA_RUN_YUN("华润云",334L),


    /**
     * 华润集团
     */
    HUA_RUN_GROUP_HEADQUARTERS("集团总部", 100L),

    ;


    /**
     * 名称
     */
    private String name;


    private Long deptId;

    SysDeptEnum(String name, Long deptId) {
        this.name = name;
        this.deptId = deptId;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public Long getDeptId() {
        return deptId;
    }

    public void setDeptId(Long deptId) {
        this.deptId = deptId;
    }
}
