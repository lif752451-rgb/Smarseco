package com.crc.common.easyexcel.listener;

import com.alibaba.excel.context.AnalysisContext;
import com.alibaba.excel.enums.RowTypeEnum;
import com.alibaba.excel.event.AnalysisEventListener;
import lombok.extern.slf4j.Slf4j;


/**
 * 限制读取行数
 * @author SHUFENGFENG
 */
@Slf4j
public class ReadRowNumListener<T> extends AnalysisEventListener<T> {


    /**
     * 总行数
     */
    private Integer rowNum;


    /**
     * 默认是从第二行开始读取数据
     * 这个每一条数据解析都会来调用
     * @param t
     * @param analysisContext
     */
    @Override
    public void invoke(T t, AnalysisContext analysisContext) {
        //过滤空行
        analysisContext.readWorkbookHolder().setIgnoreEmptyRow(false);
        rowNum = analysisContext.readSheetHolder().getApproximateTotalRowNumber();
    }

    @Override
    public void doAfterAllAnalysed(AnalysisContext analysisContext) {

    }

    @Override
    public boolean hasNext(AnalysisContext analysisContext){
        if(RowTypeEnum.EMPTY.equals(analysisContext.readRowHolder().getRowType())){
            doAfterAllAnalysed(analysisContext);
            return false;
        }
        return super.hasNext(analysisContext);
    }

    public Integer getRowNum() {
        return rowNum;
    }

    public void setRowNum(Integer rowNum) {
        this.rowNum = rowNum;
    }
}
