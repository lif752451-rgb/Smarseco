package com.crc.common.model.request;

import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

/**
 * @Author shufengfeng
 * @Description TODO
 * @DateTime 2021/9/28 11:17
 */
@Data
public class PageRequest {

    /**
     * 页码
     */
    @ApiModelProperty(value = "页码")
    private Integer pageNum;

    /**
     * 每页行数
     */
    @ApiModelProperty(value = "每页行数")
    private Integer pageSize;
}
