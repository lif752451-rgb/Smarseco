package com.crc.common.model.enums;

import com.crc.common.constant.Constants;

/**
 * @Author shufengfeng
 * @Description 文件类型枚举
 * @DateTime 2021/9/15 16:35
 */
public enum FileTypeEnum {

    EXCEL(Constants.EXCEL_XLSX, "excel"),
    JSON(".ndjson", "json"),
    DAT(".dat","dat"),
    ZIP(".zip","zip"),

    ;

    /**
     * 文件名
     */
    private String name;

    /**
     * 后缀
     */
    private String desc;

    FileTypeEnum(String name, String desc) {
        this.name = name;
        this.desc = desc;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getDesc() {
        return desc;
    }

    public void setDesc(String desc) {
        this.desc = desc;
    }
}
