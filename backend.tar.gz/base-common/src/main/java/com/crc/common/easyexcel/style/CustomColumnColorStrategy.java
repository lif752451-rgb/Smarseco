package com.crc.common.easyexcel.style;

import com.alibaba.excel.metadata.Head;
import com.alibaba.excel.metadata.data.WriteCellData;
import com.alibaba.excel.write.handler.CellWriteHandler;
import com.alibaba.excel.write.metadata.holder.WriteSheetHolder;
import com.alibaba.excel.write.metadata.holder.WriteTableHolder;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Font;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.xssf.usermodel.XSSFRichTextString;

import java.util.List;

/**
 * @author shufengfeng
 * @Description: TODO
 * @date 2022/9/6 9:49
 */
public class CustomColumnColorStrategy implements CellWriteHandler {

    private Integer columnIndex = 0;
    private short color = Font.COLOR_RED;

    public CustomColumnColorStrategy(Integer columnIndex, short color){
        this.columnIndex = columnIndex;
        this.color = color;
    }

    /**
     * 默认给第一列设置字体颜色为红色
     */
    public CustomColumnColorStrategy(){
    }

    @Override
    public void afterCellDispose(final WriteSheetHolder writeSheetHolder, final WriteTableHolder writeTableHolder,
                                 final List<WriteCellData<?>> list, final Cell cell, final Head head, final Integer integer,
                                 final Boolean aBoolean) {
        Sheet sheet = writeSheetHolder.getSheet();
        Workbook workbook = sheet.getWorkbook();
        if(cell.getColumnIndex() == columnIndex) {
            // xlsx格式，如果是老版本格式的话就用 HSSFRichTextString
            XSSFRichTextString richString = new XSSFRichTextString(cell.getStringCellValue());
            Font font = workbook.createFont();
            font.setColor(color);
            // 从哪到哪，你想设置成什么样的字体都行startIndex，endIndex
            richString.applyFont(font);
            // 再设置回每个单元格里
            cell.setCellValue(richString);
        }
    }

}
