package com.crc.common.utils.youdu;
public class GeneralEntAppException extends Exception {

    public GeneralEntAppException(String message, Throwable cause) {
        super(message, cause);
    }
}
