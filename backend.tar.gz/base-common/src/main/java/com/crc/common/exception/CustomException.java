package com.crc.common.exception;

import com.crc.common.model.enums.ResponseEnum;

/**
 * 自定义异常
 *
 * @author wst
 */
public class CustomException extends RuntimeException
{
    private static final long serialVersionUID = 1L;

    private Integer code;

    private String message;

    public CustomException(String message)
    {
        this.message = message;
    }

    public CustomException(String message, Integer code)
    {
        this.message = message;
        this.code = code;
    }

    public CustomException(ResponseEnum responseEnum)
    {
        this.message = responseEnum.getMsg();
        this.code = responseEnum.getCode();
    }

    public CustomException(String message, Throwable e)
    {
        super(message, e);
        this.message = message;
    }

    public CustomException(ResponseEnum responseEnum, Object... msg) {
        this.message = String.format(responseEnum.getMsg(), msg.toString());
        this.code = responseEnum.getCode();
    }

    @Override
    public String getMessage()
    {
        return message;
    }

    public Integer getCode()
    {
        return code;
    }
}
