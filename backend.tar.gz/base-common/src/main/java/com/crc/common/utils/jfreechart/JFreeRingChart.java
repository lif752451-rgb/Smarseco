package com.crc.common.utils.jfreechart;

import com.alibaba.fastjson.JSONArray;
import com.alibaba.fastjson.JSONObject;
import org.jfree.chart.ChartColor;
import org.jfree.chart.ChartFactory;
import org.jfree.chart.JFreeChart;
import org.jfree.chart.block.BlockBorder;
import org.jfree.chart.labels.StandardPieSectionLabelGenerator;
import org.jfree.chart.plot.PiePlot;
import org.jfree.chart.title.LegendTitle;
import org.jfree.chart.title.TextTitle;
import org.jfree.data.general.DefaultPieDataset;
import org.jfree.ui.RectangleEdge;

import java.awt.*;
import java.io.IOException;
import java.io.InputStream;
import java.text.DecimalFormat;
import java.text.NumberFormat;
import java.util.Iterator;
import java.util.Map;
import java.util.Objects;

public class JFreeRingChart {

    public JFreeChart createChart(JSONArray resultData, Map<String, Object> jsonProperty){
        return createRingChart(resultData, jsonProperty);
    }

    /**
     * [{count: 53, NAME: "中风险"}, {count: 30, NAME: "低风险"}, {count: 276, NAME: "高风险"}]
     * {"legendDataColor":{"高风险":"#FFA39E","中风险":"#FFCA8F","低风险":"#91C3FF"}}
     * @param resultData
     * @param jsonProperty
     * @return
     */
    private JFreeChart createRingChart(JSONArray resultData, Map<String, Object> jsonProperty){
        if(resultData != null && resultData.size() > 0){
            DefaultPieDataset data = new DefaultPieDataset();
            resultData.stream().forEach(object ->
                    data.setValue(((JSONObject) object).containsKey("NAME") ? ((JSONObject) object).getString("NAME") : ((JSONObject) object).getString("name"),
                            ((JSONObject) object).containsKey("COUNT") ? ((JSONObject) object).getDouble("COUNT") : ((JSONObject) object).getDouble("count"))
            );
            JFreeChart chart = ChartFactory.createRingChart("", data, true, false, false);
            PiePlot plot = (PiePlot) chart.getPlot();
            if (Objects.nonNull(jsonProperty)) {
                if(jsonProperty.containsKey("legendDataColor")){
                    JSONObject color = (JSONObject) jsonProperty.get("legendDataColor");
                    Iterator iter = color.entrySet().iterator();
                    while (iter.hasNext()) {
                        Map.Entry entry = (Map.Entry) iter.next();
                        plot.setSectionPaint(entry.getKey().toString(), Color.decode(entry.getValue().toString()));
                    }
                }
            }
            plot.setBackgroundPaint(ChartColor.WHITE);
            plot.setOutlinePaint(null);
            plot.setLabelOutlinePaint(null);
            plot.setLabelShadowPaint(null);
            plot.setLabelFont(createFont(13));
            plot.setLabelBackgroundPaint(null);
            plot.setLabelGenerator(new StandardPieSectionLabelGenerator("{0} : {1}  ({2})", NumberFormat.getNumberInstance(),
                    new DecimalFormat("0.00%")));
            plot.setSectionOutlinesVisible(false);
            plot.setShadowPaint(Color.white);
            chart.setBorderVisible(false);
            LegendTitle legend = chart.getLegend();
            legend.setPosition(RectangleEdge.TOP);
            legend.setFrame(new BlockBorder(Color.white));
            legend.setBackgroundPaint(null);
            legend.setItemFont(createFont(13));
            TextTitle title = chart.getTitle();
            title.setFont(createFont(16));
            return chart;
        }else{
            return null;
        }
    }

    /**
     * 自定义字体
     * @return
     * @throws IOException
     * @throws FontFormatException
     */
    public Font createFont(float size){
        String fontPath = "static/" + "simsun.ttf";
        InputStream is = this.getClass().getClassLoader().getResourceAsStream(fontPath);
        Font ft = null;
        try {
            ft = Font.createFont(Font.TRUETYPE_FONT, is);
        } catch (FontFormatException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }
        ft = ft.deriveFont(Font.PLAIN,size);
        return ft;
    }
}
