package com.crc.common.utils;

import java.text.NumberFormat;
import java.util.Locale;

public class NumberUtil {
    public static String formatNumber(Double number, int decimals){
        return formatNumber(number, decimals, false);
    }
    public static String formatNumber(Double number){
        return formatNumber(number, 2, false);
    }
    public static String formatNumber(Double number, int decimals, boolean isUnit){
        String unit = "";
        if(isUnit){
            int k = 10000;
            String[] sizes = {"", "万", "亿", "万亿"};
            double i = 0l;
            if(number > k){
                i = Math.floor(Math.log(number)/Math.log(k));
                System.out.println(Math.pow(k, i));
                number = number/Math.pow(k, i);
                unit = sizes[(int)i];
            }
        }
        NumberFormat numberFormat = NumberFormat.getInstance(Locale.getDefault());
        numberFormat.setGroupingUsed(true);
        numberFormat.setMaximumFractionDigits(decimals);
        return numberFormat.format(number) + unit;
    }

}
