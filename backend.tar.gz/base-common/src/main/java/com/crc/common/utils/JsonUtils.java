package com.crc.common.utils;

import cn.hutool.core.util.ReflectUtil;
import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONArray;
import com.alibaba.fastjson.JSONObject;
import com.crc.common.exception.CustomException;
import org.apache.commons.collections4.CollectionUtils;
import org.apache.commons.lang3.StringEscapeUtils;

import java.lang.reflect.Type;
import java.time.LocalDateTime;
import java.time.ZoneId;
import java.util.Date;
import java.util.List;
import java.util.Objects;
import java.util.concurrent.atomic.AtomicReference;

import static com.crc.common.constant.Constants.EXPORT_ATTRIBUTE;
import static com.crc.common.constant.Constants.FILTER_PARAM;
import static com.crc.common.model.TableSupport.PAGE_NUM;
import static com.crc.common.model.TableSupport.PAGE_SIZE;
import static com.crc.common.model.enums.ResponseEnum.EXPORT_PARAM_ERROR;
import static com.crc.common.utils.DateUtils.UTCToCSTAndCheck;

/**
 * JSON工具类
 */
public class JsonUtils {

    public static JSONObject getJsonLike(JSONObject jsonObject, String like) {
        if (jsonObject != null) {
            AtomicReference<JSONObject> itemAggAtom = new AtomicReference<>();
            jsonObject.forEach((k,v)->{
                if (k.equals(like) || k.contains("#" + like)) {
                    itemAggAtom.set(jsonObject.getJSONObject(k));
                }
            });
            return itemAggAtom.get();
        }
        return new JSONObject();
    }

    public static void copyField(JSONObject json, String src, String dest) {
        if (isEmpty(json) || StringUtils.isBlank(src))
            return;

        try {
            if (json.get(src) != null)
                json.put(dest, json.get(src));
        } catch (Exception e) {

        }
    }

    public static boolean equal(JSONObject resultJson, String filter, String val) {
        String ret = getStr(resultJson, filter);
        return ret.equals(val);
    }

    public static JSONArray getJsonArray(JSONObject json, String filter) {
        if (isEmpty(json) || StringUtils.isBlank(filter))
            return createJsonArray();
        try {
            return json.getJSONArray(filter);
        } catch (Exception e) {
            return createJsonArray();
        }
    }

    public static JSONObject getJson(JSONObject json, String filter) {
        if (isEmpty(json) || StringUtils.isBlank(filter))
            return createJson();

        try {
            return json.getJSONObject(filter);
        } catch (Exception e) {

        }
        return createJson();
    }

    public static int getInt(JSONObject json, String filter) {
        if (isEmpty(json) || StringUtils.isBlank(filter))
            return 0;
        if (json.get(filter) == null) {
            return 0;
        }
        try {
            return json.getIntValue(filter);
        } catch (Exception e) {
            return 0;
        }
    }

    public static boolean getBoolean(JSONObject json, String filter) {
        if (isEmpty(json) || StringUtils.isBlank(filter))
            return false;
        if (json.get(filter) == null) {
            return false;
        }
        try {
            return json.getBoolean(filter);
        } catch (Exception e) {
            return false;
        }
    }


    public static long getLong(JSONObject json, String filter) {
        if (isEmpty(json) || StringUtils.isBlank(filter))
            return 0;
        if (json.get(filter) == null) {
            return 0;
        }
        try {
            return json.getLongValue(filter);
        } catch (Exception e) {
            return 0;
        }
    }

    public static String getStr(JSONObject json, String filter, String defaultVal) {
        String ret = getStr(json, filter);
        if (StringUtils.isBlank(ret))
            return defaultVal;
        return ret;
    }

    public static String getDate(JSONObject json, String filter) {
        if (isEmpty(json) || StringUtils.isBlank(filter))
            return "";

        if (json.get(filter) == null) {
            return "";
        }
        return "";
    }

    public static String getStr(JSONObject json, String filter) {
        if (isEmpty(json) || StringUtils.isBlank(filter))
            return "";

        if (json.get(filter) == null) {
            return "";
        }
        filter = filter.trim();
        try {
            String retStr = json.getString(filter);
            if (StringUtils.isNotBlank(retStr)) {
                if ("null".equalsIgnoreCase(retStr)) {
                    return "";
                }
                return retStr.trim();
            }
        } catch (Exception e1) {

        }

        try {
            String retStr = json.get(filter).toString();
            if (StringUtils.isNotBlank(retStr)) {
                if ("null".equalsIgnoreCase(retStr)) {
                    return "";
                }
                return retStr.trim();
            }
        } catch (Exception e1) {

        }
        return "";
    }

    //通过点带路径查询
    public static String getStrByPath(JSONObject sourceJson, String sourceKey) {
        if (sourceKey.contains(".")) {
            String[] sourceKeys = sourceKey.split("\\.");
            String sourceKey1 = sourceKeys[0];
            String sourceKey2 = sourceKey.substring(sourceKey1.length() + 1);
            JSONObject insideJson = JsonUtils.getJson(sourceJson, sourceKey1);
            //log.info("{}-{}", insideJson.toJSONString(), sourceKey2);
            return JsonUtils.getStrByPath(insideJson, sourceKey2);
        }
        return JsonUtils.getStr(sourceJson, sourceKey);
    }

    public static void main(String[] args) {
        JSONArray arr = new JSONArray();
        JSONObject o = new JSONObject();
        o.put("a", "1");
        arr.add(o);
        System.out.println(arr);
    }

    public static boolean containsKey(JSONObject json, String filter) {
        if (isEmpty(json) || StringUtils.isBlank(filter))
            return false;
        if (json.containsKey(filter)) {
            return true;
        }
        return false;
    }

    public static String replaceKey(String jsonStr, String key, String value) {
        JSONObject json = parse(jsonStr);
        if (containsKey(json, key)) {
            json.put(key, value);
            return toJSONString(json);
        }
        return jsonStr;
    }

    public static boolean isEmpty(JSONObject json) {
        if (json == null)
            return true;
        if (json.isEmpty()) {
            return true;
        }
        return false;
    }

    public static JSONObject createJson() {
        return new JSONObject();
    }

    public static JSONArray createJsonArray() {
        return new JSONArray();
    }

    public static JSONObject parse(Object obj) {
        JSONObject jsonObject = createJson();
        if (Objects.nonNull(obj)) {
            jsonObject = parse(JSON.toJSONString(obj));
        }
        return jsonObject;
    }

    public static JSONObject parse(String json) {
        try {
            if (StringUtils.isBlank(json)) {
                return createJson();
            }
            return JSON.parseObject(json);
        } catch (Exception e) {
            try {
                return parseUnescape(json);
            } catch (Exception e1) {

            }
        }
        return createJson();
    }

    /**
     * 对象转换指定类型
     * 
     * @param obj Object
     * @param clazz 指定class
     * @param <T> T
     * @return T
     */
    public static <T> T parseObject(Object obj, Class<T> clazz) {
        return parseObject(toJSONString(obj), clazz);
    }

    /**
     * 对象转换指定类型
     * 
     * @param text String
     * @param clazz 指定class
     * @param <T> T
     * @return T
     */
    public static <T> T parseObject(String text, Class<T> clazz) {
        T t = null;
        try {
            t = JSON.parseObject(text, clazz);
        } catch (Exception ignored) {
        }
        return t;
    }

    public static JSONArray parseArray(String json) {
        try {
            if (StringUtils.isBlank(json)) {
                return createJsonArray();
            }
            return JSON.parseArray(json);
        } catch (Exception e) {
            try {
                return parseUnescapeArray(json);
            } catch (Exception e1) {

            }
        }
        return createJsonArray();
    }

    public static JSONObject parseUnescape(String json) {
        try {
            if (StringUtils.isBlank(json)) {
                return createJson();
            }
            json = StringEscapeUtils.unescapeJson(json);
            return JSON.parseObject(json);
        } catch (Exception e) {

        }
        return createJson();
    }

    public static JSONArray parseUnescapeArray(String json) {
        try {
            if (StringUtils.isBlank(json)) {
                return createJsonArray();
            }
            json = StringEscapeUtils.unescapeJson(json);
            return JSON.parseArray(json);
        } catch (Exception e) {

        }
        return createJsonArray();
    }

    public static void print(Object json) {
        if (json != null) {
            System.out.println(DateUtils.getDateTimeString(new Date()) + " " + JSON.toJSONString(json));
        }
    }

    public static int getIntN(JSONObject job, String log_count) {
        int ret = getInt(job, log_count);
        if (ret < 1)
            return 1;
        return ret;
    }

    /**
     * 单位缩进字符串。
     */
    private static String SPACE = "   ";

    /**
     * 返回格式化JSON字符串。
     *
     * @param json 未格式化的JSON字符串。
     * @return 格式化的JSON字符串。
     */
    public static String formatJson(String json) {
        StringBuffer result = new StringBuffer();

        int length = json.length();
        int number = 0;
        char key = 0;

        // 遍历输入字符串。
        for (int i = 0; i < length; i++) {
            // 1、获取当前字符。
            key = json.charAt(i);

            // 2、如果当前字符是前方括号、前花括号做如下处理：
            if ((key == '[') || (key == '{')) {
                // （1）如果前面还有字符，并且字符为“：”，打印：换行和缩进字符字符串。
                if ((i - 1 > 0) && (json.charAt(i - 1) == ':')) {
                    // result.append('\n');
                    // result.append(indent(number));
                }

                // （2）打印：当前字符。
                result.append(key);

                // （3）前方括号、前花括号，的后面必须换行。打印：换行。
                // result.append('\n');

                // （4）每出现一次前方括号、前花括号；缩进次数增加一次。打印：新行缩进。
                number++;
                result.append(indent(number));

                // （5）进行下一次循环。
                continue;
            }

            // 3、如果当前字符是后方括号、后花括号做如下处理：
            if ((key == ']') || (key == '}')) {
                // （1）后方括号、后花括号，的前面必须换行。打印：换行。
                // result.append('\n');

                // （2）每出现一次后方括号、后花括号；缩进次数减少一次。打印：缩进。
                number--;
                // result.append(indent(number));

                // （3）打印：当前字符。
                result.append(key);

                // （4）如果当前字符后面还有字符，并且字符不为“，”，打印：换行。
                if (((i + 1) < length) && (json.charAt(i + 1) != ',')) {
                    result.append('\n');
                }

                // （5）继续下一次循环。
                continue;
            }

            // 4、如果当前字符是逗号。逗号后面换行，并缩进，不改变缩进次数。
            /*if ((key == ',')) {
                result.append(key);
                result.append('\n');
                result.append(indent(number));
                continue;
            }*/

            // 5、打印：当前字符。
            result.append(key);
        }

        return result.toString();
    }

    /**
     * 返回指定次数的缩进字符串。每一次缩进三个空格，即SPACE。
     *
     * @param number 缩进次数。
     * @return 指定缩进次数的字符串。
     */
    private static String indent(int number) {
        StringBuffer result = new StringBuffer();
        for (int i = 0; i < number; i++) {
            result.append(SPACE);
        }
        return result.toString();
    }

    /**
     * 集合转json字符串 集合为空返回""
     *
     * @param objList List
     * @return String
     */
    public static String toJSONString(List<?> objList) {
        String str = "";
        if (CollectionUtils.isNotEmpty(objList)) {
            str = JSONArray.toJSONString(objList);
        }
        return str;
    }

    /**
     * obj转json字符串 obj为空返回""
     *
     * @param obj Object
     * @return String
     */
    public static String toJSONString(Object obj) {
        String str = "";
        if (Objects.nonNull(obj)) {
            str = JSONObject.toJSONString(obj);
        }
        return str;
    }

    public static boolean equalVal(JSONObject json, String src, String val) {
        if (isEmpty(json) || StringUtils.isBlank(src))
            return false;
        if (isEmpty(json) || StringUtils.isBlank(val))
            return false;
        try {
            String sVal = getStr(json, src);
            if (StringUtils.isNotBlank(sVal) && sVal.equals(val))
                return true;
        } catch (Exception e) {

        }
        return false;
    }

    public static String getDateStr(JSONObject json, String filter) {
        return DateUtils.getDateTimeString1(getDate1(json, filter));
    }

    public static Date getDate1(JSONObject json, String filter) {
        if (isEmpty(json) || StringUtils.isBlank(filter))
            return new Date();

        if (json.get(filter) == null) {
            return new Date();
        }
        try {
            Object obj = json.get(filter);
            if (obj instanceof LocalDateTime) {
                // return DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss").format((LocalDateTime)obj);
                LocalDateTime localDateTime = (LocalDateTime)obj;
                return Date.from(localDateTime.atZone(ZoneId.systemDefault()).toInstant());
            } else if (obj instanceof Date) {
                return (Date)obj;
            }

            String dateStr = getStr(json, filter);
            dateStr = UTCToCSTAndCheck(dateStr);
            if (StringUtils.isNotBlank(dateStr))
                return DateUtils.parseDate(dateStr, DateUtils.DATE_FORMAT_STRING1);
        } catch (Exception e1) {

        }
        return new Date();
    }

    /**
     * 获取导出查询条件
     *
     * @param jsonParam 入参
     * @param tClass 类
     * @param <T> T
     * @return T
     */
    public static <T> T getFilterParam(JSONObject jsonParam, Class<T> tClass) {
        JSONObject filterParamJson = jsonParam.getJSONObject(FILTER_PARAM);
        if (Objects.isNull(filterParamJson)) {
            throw new CustomException(EXPORT_PARAM_ERROR.getMsg(), EXPORT_PARAM_ERROR.getCode());
        }
        T parseObject = JSONObject.parseObject(filterParamJson.toJSONString(), (Type)tClass);
        StringUtils.convertSpecialChar(parseObject);
        if (ReflectUtil.hasField(tClass, PAGE_NUM)) {
            ReflectUtil.setFieldValue(parseObject, PAGE_NUM, null);
        }
        if (ReflectUtil.hasField(tClass, PAGE_SIZE)) {
            ReflectUtil.setFieldValue(parseObject, PAGE_SIZE, null);
        }
        return parseObject;
    }

    /**
     * 获取导出自定义字段
     *
     * @param jsonParam 入参
     * @return 字段集合
     */
    public static JSONArray getExportAttribute(JSONObject jsonParam) {
        return getJsonArray(jsonParam, EXPORT_ATTRIBUTE);
    }

    public static Date getDateX(JSONObject json, String filter) {
        if (isEmpty(json) || StringUtils.isBlank(filter)) {
            return null;
        }

        if (json.get(filter) == null) {
            return null;
        }
        try {
            Object obj = json.get(filter);
            if (obj instanceof LocalDateTime) {
                // return DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss").format((LocalDateTime)obj);
                LocalDateTime localDateTime = (LocalDateTime)obj;
                return Date.from(localDateTime.atZone(ZoneId.systemDefault()).toInstant());
            } else if (obj instanceof Date) {
                return (Date)obj;
            }
            String dateStr = getStr(json, filter);
            return DateUtils.parseDateTimeX(dateStr, DateUtils.DATE_FORMAT_STRING1);
        } catch (Exception e1) {

        }
        return null;
    }
}
