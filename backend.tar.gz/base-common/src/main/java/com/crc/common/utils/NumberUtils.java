package com.crc.common.utils;

import org.apache.commons.lang3.StringUtils;

import java.util.regex.Matcher;
import java.util.regex.Pattern;
/**
 * 数字工具类
 * @author SHUFENGFENG
 */
public class NumberUtils {

    /**
     * 数字正则
     */
    public static Pattern NUM_PATTERN = Pattern.compile("[0-9]");

    /**
     *
     * @param num
     * @return
     */
    public static Integer NullConvert(Integer num){
        return null == num ? 0 : num;
    }

    /**
     *
     * @param num
     * @return
     */
    public static Long NullConvert(Long num){
        return null == num ? 0L : num;
    }

    /**
     *
     * @param num
     * @return
     */
    public static Double NullConvert(Double num){
        return null == num ? 0 : num;
    }


    /**
     *
     * @param num
     * @return
     */
    public static Integer NullConvert(String num){
        return StringUtils.isEmpty(num) ? 0 : Integer.parseInt(num);
    }




    /**
     * 判断字符串中是否包含数字,如果包含返回true,否则返回false
     * @param str
     * @return
     */
    public static boolean isContainNumber(String str) {
        Matcher m = NUM_PATTERN.matcher(str);
        if (m.find()) {
            return true;
        }
        return false;
    }

    /**
     * 只保留数字和小数点
     * @param str
     * @return
     */
    public static String keepNumbersAndDecimalPoints(String str){
        return str.replaceAll("[^0-9.]", "");
    }


    /**
     * String convert Integer
     *
     * @param num 字符串
     * @return Integer num为空或空串 返回null
     */
    public static Integer integerConvertStr(String num) {
        try {
            return StringUtils.isEmpty(num) ? null : Integer.parseInt(num);
        } catch (Exception e) {
            return null;
        }
    }
}
