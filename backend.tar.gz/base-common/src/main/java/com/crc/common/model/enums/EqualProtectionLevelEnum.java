package com.crc.common.model.enums;

/**
 * @Author shufengfeng
 * @Description 等保定级枚举
 * @DateTime 2021/9/23 16:37
 */
public enum EqualProtectionLevelEnum {


    UNCLASSIFIED(0,"未定级"),

    ;
    /**
     * 字典值
     */
    private Integer value;

    /**
     * 字典标签
     */
    private String label;

    EqualProtectionLevelEnum(Integer value, String label){
        this.value = value;
        this.label = label;
    }

    public Integer getValue() {
        return value;
    }

    public void setValue(Integer value) {
        this.value = value;
    }

    public String getLabel() {
        return label;
    }

    public void setLabel(String label) {
        this.label = label;
    }
}
