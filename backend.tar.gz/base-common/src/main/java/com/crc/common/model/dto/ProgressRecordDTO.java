package com.crc.common.model.dto;

import lombok.Data;

/**
 * 告警详情-进度图
 * @author WANGLEI
 * @date 2021/9/2 16:08
 */
@Data
public class ProgressRecordDTO {
    /** 操作人 */
    private String dealNickName;
    /** 执行动作 */
    private String nodeName;
}
