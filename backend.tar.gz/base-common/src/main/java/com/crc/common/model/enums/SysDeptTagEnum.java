package com.crc.common.model.enums;

/**
 * @Author shufengfeng
 * @Description 系统部门适用业务枚举
 * @DateTime 2021/11/11 16:11
 */
public enum SysDeptTagEnum {
    /**
     * 告警
     */
    ALARM("告警","告警"),
    /**
     * 风险
     */
    RISK("风险","风险"),
    ;


    private String value;

    private String desc;

    SysDeptTagEnum(String value, String desc) {
        this.value = value;
        this.desc = desc;
    }

    public String getValue() {
        return value;
    }

    public void setValue(String value) {
        this.value = value;
    }

    public String getDesc() {
        return desc;
    }

    public void setDesc(String desc) {
        this.desc = desc;
    }
}
