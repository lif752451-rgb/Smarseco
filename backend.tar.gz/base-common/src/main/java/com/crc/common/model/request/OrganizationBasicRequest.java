package com.crc.common.model.request;

import lombok.Data;
import lombok.EqualsAndHashCode;

/**
 * @Author shufengfeng
 * @Description 用户相关基础请求
 * @DateTime 2021/10/18 15:25
 */
@Data
@EqualsAndHashCode(callSuper = true)
public class OrganizationBasicRequest extends PageRequest {

    /**
     * 当前登录用户
     */
    private String currentUser;


    /**
     * 当前登录用户
     */
    private String currentUserNickName;

    /**
     * 当前登录用户id
     */
    private Long currentUserId;

    /**
     * 当前登录用户部门id
     */
    private String currentUserDeptId;

    /**
     * 是否系统管理员 true为系统管理员 false不是
     */
    private Boolean adminFlag;

    /**
     * 所属组织id
     */
    private Long organizationId;
}
