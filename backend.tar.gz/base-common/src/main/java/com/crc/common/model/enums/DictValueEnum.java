package com.crc.common.model.enums;

import lombok.Getter;

/**
 * 字典值枚举
 *
 * @Author fuzhuangzhi
 * @Date 2023/2/10 10:33
 * @Version 1.0
 **/
@Getter
public enum DictValueEnum {
    /**
     * 主机漏洞闭环流程通知
     */
    VULN_HOST_PROCESS("vulnHostProcess", "主机漏洞闭环流程通知"),

    /**
     * WEB漏洞闭环流程通知
     */
    VULN_WEB_PROCESS("vulnWebProcess", "WEB漏洞闭环流程通知"),

    /**
     * 弱口令闭环流程通知
     */
    VULN_CODE_PROCESS("vulnCodeProcess", "弱口令闭环流程通知"),

    /**
     * vulnCodeRebut
     */
    VULN_CODE_REBUT("vulnCodeRebut", "弱口令处置驳回通知"),

    /**
     * vulnHostRebut
     */
    VULN_HOST_REBUT("vulnHostRebut", "主机漏洞处置驳回通知"),

    /**
     * vulnWebRebut
     */
    VULN_WEB_REBUT("vulnWebRebut", "WEB漏洞处置驳回通知"),

    /**
     * vulProcessWeCom
     */
    VUL_PROCESS_WECOM("vulProcessWeCom", "漏洞闭环_流程节点企业微信推送 (0-关闭,1-开启)"),

    /**
     * vulFileWeCom
     */
    VUL_FILE_WECOM("vulFileWeCom", "漏洞闭环_归档企业微信推送 (0-关闭,1-开启)"),

    /**
     * 漏洞流程配置消息发送类型
     */
    VULN_PROCESS("vulnProcess", "漏洞流程配置消息发送类型 qywx:企业微信 feishu:飞书 youdu:有度 多个用英文逗号隔开"),

    /**
     * 告警流程配置消息发送类型
     */
    ALARM_PROCESS("alarmProcess", "告警流程配置消息发送类型 qywx:企业微信 feishu:飞书 youdu:有度 多个用英文逗号隔开"),

    /**
     * 实战告警申请配置消息发送类型
     */
    ALARM_COMBAT_APPLY("alarmCombatApply", "实战告警申请配置消息发送类型 qywx:企业微信 feishu:飞书 youdu:有度 多个用英文逗号隔开"),

    /**
     * 风险流程配置消息发送类型
     */
    RISK_PROCESS("riskProcess", "风险流程配置消息发送类型 qywx:企业微信 feishu:飞书 多个用英文逗号隔开"),

    /**
     * 安全报告配置消息发送类型
     */
    SEC_REPORT("secReport", "安全报告配置消息发送类型 qywx:企业微信 feishu:飞书 多个用英文逗号隔开"),

    /**
     * 跳转链接到<威胁管理-告警闭环-我的待办>
     */
    ALARM_PROCESS_URL("alarmProcess", "跳转链接到<威胁管理-告警闭环-我的待办>"),

    /**
     * 跳转链接到<威胁管理-告警闭环-查看-详情
     */
    ALARM_DETAIL_URL("alarmDetail", "跳转链接到<威胁管理-告警闭环-查看-详情>"),

    /**
     * 跳转链接到跳转链接到<威胁管理-告警闭环-我的已办>
     */
    SEC_REPORT_DONE_URL("alarmProcessDone", "跳转链接到<威胁管理-告警闭环-我的已办>"),

    /**
     * riskProcess跳转链接到<风险管理-风险闭环-我的待办>页面
     */
    RISK_PROCESS_URL("riskProcess", "跳转链接到<风险管理-风险闭环-我的待办>页面"),

    /**
     * riskProcessDone跳转链接到<风险管理-风险闭环-我的已办>页面
     */
    RISK_PROCESS_DONE_URL("riskProcessDone", "跳转链接到<风险管理-风险闭环-我的已办>页面"),

    /**
     * 告警闭环_流程节点企业微信推送
     */
    ALARM_PROCESS_WECOM("alarmProcessWeCom", "告警闭环_流程节点企业微信推送 (0-关闭,1-开启)"),

    /**
     * 告警闭环_归档企业微信推送
     */
    ALARM_FILE_WECOM("alarmFileWeCom", "告警闭环_归档企业微信推送 (0-关闭,1-开启)"),

    /**
     * 风险闭环_流程节点企业微信推送
     */
    RISK_PROCESS_WECOM("riskProcessWeCom", "风险闭环_流程节点企业微信推送 (0-关闭,1-开启)"),

    /**
     * 风险闭环_归档企业微信推送
     */
    RISK_FILE_WECOM("riskFileWeCom", "风险闭环_归档企业微信推送 (0-关闭,1-开启)"),

    /**
     * 实战告警溯源提醒消息发送类型
     */
    COMBAT_TRACEABILITY_WARN("combatTraceabilityWarn", "实战告警溯源提醒消息发送类型 qywx:企业微信 feishu:飞书 多个用英文逗号隔开"),

    ;

    private final String dictValue;
    private final String desc;

    DictValueEnum(String dictValue, String desc) {
        this.dictValue = dictValue;
        this.desc = desc;
    }
}
