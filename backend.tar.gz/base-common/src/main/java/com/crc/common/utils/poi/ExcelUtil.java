package com.crc.common.utils.poi;

import cn.hutool.core.collection.CollUtil;
import cn.hutool.core.util.StrUtil;
import com.crc.common.annotation.Excel;
import com.crc.common.annotation.Excel.ColumnType;
import com.crc.common.annotation.Excel.Type;
import com.crc.common.annotation.Excels;
import com.crc.common.constant.Constants;
import com.crc.common.exception.CustomException;
import com.crc.common.model.AjaxResult;
import com.crc.common.model.enums.ResponseEnum;
import com.crc.common.properties.CrcProperties;
import com.crc.common.utils.Convert;
import com.crc.common.utils.DateUtils;
import com.crc.common.utils.StringUtils;
import com.crc.common.utils.reflect.ReflectUtils;
import org.apache.commons.io.IOUtils;
import org.apache.poi.hssf.usermodel.*;
import org.apache.poi.ss.usermodel.*;
import org.apache.poi.ss.util.CellRangeAddressList;
import org.apache.poi.xssf.streaming.SXSSFWorkbook;
import org.apache.poi.xssf.usermodel.*;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.web.multipart.MultipartFile;

import javax.servlet.http.HttpServletResponse;
import java.io.*;
import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.math.BigDecimal;
import java.net.URLEncoder;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.text.DecimalFormat;
import java.util.*;
import java.util.function.BiFunction;
import java.util.function.Function;
import java.util.stream.Collectors;
import java.util.stream.IntStream;

import static com.crc.common.constant.Constants.EXCEL_CELL_MAXIMUM;
import static com.crc.common.constant.Constants.EXCEL_CELL_MAX_LENGTH;
import static com.crc.common.utils.DateUtils.YYYY_MM_DD_HH_MM_SS;
import static com.crc.common.utils.DateUtils.YYYY_MM_DD_HH_MM_SS_SS;

/**
 * Excel相关处理
 *
 * @author wst
 */
public class ExcelUtil<T> {
    private static final Logger log = LoggerFactory.getLogger(ExcelUtil.class);

    private static Class[] classType = {Integer.class, int.class, byte.class, Byte.class, short.class, Short.class,
            long.class, Long.class, float.class, Float.class, double.class, char.class,
            Character.class, boolean.class, Boolean.class, String.class, Date.class};

    /**
     * Excel sheet最大行数，默认65536
     */
    public static final int sheetSize = 65536;

    /**
     * 工作表名称
     */
    private String sheetName;

    /**
     * 导出类型（EXPORT:导出数据；IMPORT：导入模板）
     */
    private Type type;

    /**
     * 工作薄对象
     */
    private Workbook wb;

    /**
     * 工作表对象
     */
    private Sheet sheet;

    /**
     * 样式列表
     */
    private Map<String, CellStyle> styles;

    /**
     * 导入导出数据列表
     */
    private List<T> list;

    /**
     * 注解列表
     */
    private List<Object[]> fields;

    private String[] showFields;

    /**
     * 实体对象
     */
    public Class<T> clazz;

    public ExcelUtil(Class<T> clazz) {
        this.clazz = clazz;
    }

    public ExcelUtil(Class<T> clazz, String[] showFields) {
        this.clazz = clazz;
        this.showFields = showFields;
    }

    public void init(List<T> list, String sheetName, Type type, String[] showFields) {
        if (list == null) {
            list = new ArrayList<T>();
        }
        this.list = list;
        this.sheetName = sheetName;
        this.type = type;
        createExcelField(showFields);
        createWorkbook();
    }

    /**
     * 得到所有定义字段
     */
    private void createExcelField(String[] showFields) {
        this.fields = new ArrayList<Object[]>();
        List<Field> tempFields = new ArrayList<>();
        tempFields.addAll(Arrays.asList(clazz.getSuperclass().getDeclaredFields()));
        tempFields.addAll(Arrays.asList(clazz.getDeclaredFields()));
        for (Field field : tempFields) {
            // 单注解
            if (field.isAnnotationPresent(Excel.class)) {
                for (String temp : showFields) {
                    if (temp.equals(field.getName())) {
                        putToField(field, field.getAnnotation(Excel.class));
                    }
                }
            }

            // 多注解
            if (field.isAnnotationPresent(Excels.class)) {
                Excels attrs = field.getAnnotation(Excels.class);
                Excel[] excels = attrs.value();
                for (Excel excel : excels) {
                    for (String temp : showFields) {
                        if (temp.equals(field.getName())) {
                            putToField(field, excel);
                        }
                    }
                }
            }
        }
    }

    public void init(List<T> list, String sheetName, Type type) {
        if (list == null) {
            list = new ArrayList<T>();
        }
        this.list = list;
        this.sheetName = sheetName;
        this.type = type;
        createExcelField();
        createWorkbook();
    }

    /**
     * 对excel表单默认第一个索引名转换成list
     *
     * @param is 输入流
     * @return 转换后集合
     */
    public List<T> importExcel(InputStream is) throws Exception {
        return importExcel(StringUtils.EMPTY, is);
    }

    /**
     * 对excel表单指定表格索引名转换成list
     *
     * @param sheetName 表格索引名
     * @param is        输入流
     * @return 转换后集合
     */
    public List<T> importExcel(String sheetName, InputStream is) throws Exception {
        this.type = Type.IMPORT;
        this.wb = WorkbookFactory.create(is);
        List<T> list = new ArrayList<T>();
        Sheet sheet = null;
        if (StringUtils.isNotEmpty(sheetName)) {
            // 如果指定sheet名,则取指定sheet中的内容.
            sheet = wb.getSheet(sheetName);
        } else {
            // 如果传入的sheet名不存在则默认指向第1个sheet.
            sheet = wb.getSheetAt(0);
        }

        if (sheet == null) {
            throw new IOException("文件sheet不存在");
        }

        int rows = sheet.getPhysicalNumberOfRows();

        if (rows > 0) {
            // 定义一个map用于存放excel列的序号和field.
            Map<String, Integer> cellMap = new HashMap<String, Integer>();
            // 获取表头
            Row heard = sheet.getRow(0);
            for (int i = 0; i < heard.getPhysicalNumberOfCells(); i++) {
                Cell cell = heard.getCell(i);
                if (StringUtils.isNotNull(cell)) {
                    String value = this.getCellValue(heard, i).toString();
                    cellMap.put(value, i);
                } else {
                    cellMap.put(null, i);
                }
            }
            // 有数据时才处理 得到类的所有field.
            Field[] allFields = clazz.getDeclaredFields();
            // 验证导入模板
            this.checkImportTemplate(cellMap.keySet(), allFields);
            // 定义一个map用于存放列的序号和field.
            Map<Integer, Field> fieldsMap = new HashMap<Integer, Field>();
            for (Field field : allFields) {
                Excel attr = field.getAnnotation(Excel.class);
                if (attr != null && (attr.type() == Type.ALL || attr.type() == type)) {
                    // 设置类的私有字段属性可访问.
                    field.setAccessible(true);
                    Integer column = cellMap.get(attr.name());
                    fieldsMap.put(column, field);
                }
            }
            for (int i = 1; i < rows; i++) {
                // 从第2行开始取数据,默认第一行是表头.
                Row row = sheet.getRow(i);
                T entity = null;
                int count = 0;
                for (Map.Entry<Integer, Field> entry : fieldsMap.entrySet()) {
                    if (null == entry.getKey()) {
                        continue;
                    }
                    Object val = this.getCellValue(row, entry.getKey());
                    if (!Objects.isNull(val) && !"".equals(val)) {
                        count++;
                    }
                    // 如果不存在实例则新建.
                    entity = (entity == null ? clazz.newInstance() : entity);
                    // 从map中得到对应列的field.
                    Field field = fieldsMap.get(entry.getKey());
                    // 取得类型,并根据对象类型设置值.
                    Class<?> fieldType = field.getType();
                    if (String.class == fieldType) {
                        String s = Convert.toStr(val);
                        if (StringUtils.endsWith(s, ".0")) {
                            val = StringUtils.substringBefore(s, ".0");
                        } else {
                            val = Convert.toStr(val);
                        }
                    } else if ((Integer.TYPE == fieldType) || (Integer.class == fieldType)) {
                        val = Convert.toInt(val);
                    } else if ((Long.TYPE == fieldType) || (Long.class == fieldType)) {
                        val = Convert.toLong(val);
                    } else if ((Double.TYPE == fieldType) || (Double.class == fieldType)) {
                        val = Convert.toDouble(val);
                    } else if ((Float.TYPE == fieldType) || (Float.class == fieldType)) {
                        val = Convert.toFloat(val);
                    } else if (BigDecimal.class == fieldType) {
                        val = Convert.toBigDecimal(val);
                    } else if (Date.class == fieldType) {
                        if (val instanceof String) {
                            val = DateUtils.parseDate(val);
                        } else if (val instanceof Double) {
                            val = DateUtil.getJavaDate((Double) val);
                        }
                    }
                    if (StringUtils.isNotNull(fieldType)) {
                        Excel attr = field.getAnnotation(Excel.class);
                        String propertyName = field.getName();
                        if (StringUtils.isNotEmpty(attr.targetAttr())) {
                            propertyName = field.getName() + "." + attr.targetAttr();
                        } else if (StringUtils.isNotEmpty(attr.readConverterExp())) {
                            val = reverseByExp(String.valueOf(val), attr.readConverterExp());
                        }
                        ReflectUtils.invokeSetter(entity, propertyName, val);
                    }
                }
                if (count > 0) {
                    list.add(entity);
                }
            }
        }
        return list;
    }

    public List<T> importExcelNew(String sheetName, InputStream is) throws Exception {
        this.type = Type.IMPORT;
        this.wb = WorkbookFactory.create(is);
        List<T> list = new ArrayList<T>();
        Sheet sheet = null;
        if (StringUtils.isNotEmpty(sheetName)) {
            // 如果指定sheet名,则取指定sheet中的内容.
            sheet = wb.getSheet(sheetName);
        } else {
            // 如果传入的sheet名不存在则默认指向第1个sheet.
            sheet = wb.getSheetAt(0);
        }

        if (sheet == null) {
            throw new IOException("文件sheet不存在");
        }

        int rows = sheet.getPhysicalNumberOfRows();

        if (rows > 0) {
            // 定义一个map用于存放excel列的序号和field.
            Map<String, Integer> cellMap = new HashMap<>();
            // 获取表头
            Row heard = sheet.getRow(0);
            for (int i = 0; i < heard.getPhysicalNumberOfCells(); i++) {
                Cell cell = heard.getCell(i);
                if (StringUtils.isNotNull(cell != null)) {
                    String value = this.getCellValue(heard, i).toString();
                    cellMap.put(value, i);
                } else {
                    cellMap.put(null, i);
                }
            }
            // 有数据时才处理 得到类的所有field.
            Field[] allFields = clazz.getDeclaredFields();
            // 验证导入模板
            this.checkImportTemplate(cellMap.keySet(), allFields);
            // 定义一个map用于存放列的序号和field.
            Map<Integer, Field> fieldsMap = new HashMap<>();
            for (Field field : allFields) {
                Excel attr = field.getAnnotation(Excel.class);
                if (attr != null && (attr.type() == Type.ALL || attr.type() == type)) {
                    // 设置类的私有字段属性可访问.
                    field.setAccessible(true);
                    Integer column = cellMap.get(attr.name());
                    fieldsMap.put(column, field);
                }
            }
            for (int i = 1; i < rows; i++) {
                // 从第2行开始取数据,默认第一行是表头.
                Row row = sheet.getRow(i);
                T entity = null;
                int count = 0;
                for (Map.Entry<Integer, Field> entry : fieldsMap.entrySet()) {
                    if (null == entry.getKey()) {
                        continue;
                    }
                    Object val = this.getCellValue(row, entry.getKey());
                    if (!Objects.isNull(val) && !"".equals(val)) {
                        count++;
                    }
                    // 如果不存在实例则新建.
                    entity = (entity == null ? clazz.newInstance() : entity);
                    // 从map中得到对应列的field.
                    Field field = fieldsMap.get(entry.getKey());
                    // 取得类型,并根据对象类型设置值.
                    Class<?> fieldType = field.getType();
                    if (String.class == fieldType) {
                        if (val instanceof Date) {
                            Excel attr = field.getAnnotation(Excel.class);
                            String ft = YYYY_MM_DD_HH_MM_SS;
                            if (StringUtils.isNotEmpty(attr.dateFormat())) {
                                ft = attr.dateFormat();
                            }
                            val = DateUtils.formatDateTime((Date) val, ft);
                        } else {
                            String s = Convert.toStr(val);
                            if (StringUtils.endsWith(s, ".0")) {
                                val = StringUtils.substringBefore(s, ".0");
                            } else {
                                val = Convert.toStr(val);
                            }
                        }
                    } else if ((Integer.TYPE == fieldType) || (Integer.class == fieldType)) {
                        val = Convert.toInt(val);
                    } else if ((Long.TYPE == fieldType) || (Long.class == fieldType)) {
                        val = Convert.toLong(val);
                    } else if ((Double.TYPE == fieldType) || (Double.class == fieldType)) {
                        val = Convert.toDouble(val);
                    } else if ((Float.TYPE == fieldType) || (Float.class == fieldType)) {
                        val = Convert.toFloat(val);
                    } else if (BigDecimal.class == fieldType) {
                        val = Convert.toBigDecimal(val);
                    } else if (Date.class == fieldType) {
                        if (val instanceof String) {
                            val = DateUtils.parseDate(val);
                        } else if (val instanceof Double) {
                            val = DateUtil.getJavaDate((Double) val);
                        }
                    }
                    if (StringUtils.isNotNull(fieldType)) {
                        Excel attr = field.getAnnotation(Excel.class);
                        String propertyName = field.getName();
                        if (StringUtils.isNotEmpty(attr.targetAttr())) {
                            propertyName = field.getName() + "." + attr.targetAttr();
                        } else if (StringUtils.isNotEmpty(attr.readConverterExp())) {
                            val = reverseByExp(String.valueOf(val), attr.readConverterExp());
                        }
                        ReflectUtils.invokeSetter(entity, propertyName, val);
                    }
                }
                if (count > 0) {
                    list.add(entity);
                }
            }
        }
        return list;
    }


    /**
     * 验证导入模板是否正确
     *
     * @param heardList Set<String>
     * @param allFields Field[]
     */
    private void checkImportTemplate(Set<String> heardList, Field[] allFields) {
        List<String> dataHeardList = Arrays.stream(allFields).map(field -> field.getAnnotation(Excel.class))
                .filter(Objects::nonNull).map(Excel::name).collect(Collectors.toList());
        long count = heardList.stream().filter(dataHeardList::contains).count();
        if (dataHeardList.size() != count) {
            throw new CustomException(ResponseEnum.WORK_TYPE_ERROR.getMsg());
        }
    }

    /**
     * 对list数据源将其里面的数据导入到excel表单
     *
     * @param list      导出数据集合
     * @param sheetName 工作表的名称
     * @return 结果
     */
    public AjaxResult exportExcel(List<T> list, String sheetName) {
        if (this.showFields != null && this.showFields.length > 0) {
            this.init(list, sheetName, Type.EXPORT, this.showFields);
        } else {
            this.init(list, sheetName, Type.EXPORT);
        }
        return exportExcel();
    }

    /**
     * 对list数据源将其里面的数据导入到excel表单
     *
     * @param list      导出数据集合
     * @param sheetName 工作表的名称
     * @param fileName  文件名称
     * @return 结果
     */
    public AjaxResult exportExcel(List<T> list, String sheetName, String fileName) {
        if (this.showFields != null && this.showFields.length > 0) {
            this.init(list, sheetName, Type.EXPORT, this.showFields);
        } else {
            this.init(list, sheetName, Type.EXPORT);
        }
        return exportExcel(fileName);
    }


    /**
     * 对list数据源将其里面的数据导入到excel表单
     *
     * @param list      导出数据集合
     * @param sheetName 工作表的名称
     * @param file      文件
     * @return 结果
     */
    public AjaxResult exportExcel(List<T> list, String sheetName, File file) {
        if (this.showFields != null && this.showFields.length > 0) {
            this.init(list, sheetName, Type.EXPORT, this.showFields);
        } else {
            this.init(list, sheetName, Type.EXPORT);
        }
        return exportExcel(file);
    }

    /**
     * 对list数据源将其里面的数据导入到excel表单
     *
     * @param sheetName 工作表的名称
     * @return 结果
     */
    public AjaxResult importTemplateExcel(String sheetName) {
        this.init(null, sheetName, Type.IMPORT);
        return exportExcel();
    }

    /**
     * 对list数据源将其里面的数据导入到excel表单
     *
     * @return 结果
     */
    public AjaxResult exportExcel() {
        OutputStream out = null;
        try {
            // 取出一共有多少个sheet.
            double sheetNo = Math.ceil(list.size() / sheetSize);
            for (int index = 0; index <= sheetNo; index++) {
                createSheet(sheetNo, index);

                // 产生一行
                Row row = sheet.createRow(0);
                int column = 0;
                // 写入各个字段的列头名称
                for (Object[] os : fields) {
                    Excel excel = (Excel) os[1];
                    this.createCell(excel, row, column++);
                }
                if (Type.EXPORT.equals(type)) {
                    fillExcelData(index, row);
                }
            }
            String filename = encodingFilename(sheetName);
            out = Files.newOutputStream(Paths.get(getAbsoluteFile(filename)));
            wb.write(out);
            return AjaxResult.success(filename);
        } catch (Exception e) {
            log.error("导出Excel异常{}", e.getMessage());
            throw new CustomException("导出Excel失败，请联系网站管理员！");
        } finally {
            IOUtils.closeQuietly(wb);
            IOUtils.closeQuietly(out);
        }
    }


    /**
     * 对list数据源将其里面的数据导入到excel表单
     *
     * @return 结果
     */
    public String outputExcel(HttpServletResponse response, List<T> list, String sheetName) {
        String filename = encodingFilename(sheetName);
        if (this.showFields != null && this.showFields.length > 0) {
            this.init(list, sheetName, Type.EXPORT, this.showFields);
        } else {
            this.init(list, sheetName, Type.EXPORT);
        }

        OutputStream out = null;
        try {
            // 取出一共有多少个sheet.
            double sheetNo = Math.ceil(list.size() / sheetSize);
            for (int index = 0; index <= sheetNo; index++) {
                createSheet(sheetNo, index);
                // 产生一行
                Row row = sheet.createRow(0);
                int column = 0;
                // 写入各个字段的列头名称
                for (Object[] os : fields) {
                    Excel excel = (Excel) os[1];
                    this.createCell(excel, row, column++);
                }
                if (Type.EXPORT.equals(type)) {
                    fillExcelData(index, row);
                }
            }
            response.setContentType("application/octet-stream");
            response.setHeader("Content-Disposition", "attachment;filename=" + URLEncoder.encode(filename, "utf-8"));
            response.setHeader(Constants.SIZE, String.valueOf(list.size()));
            response.flushBuffer();
            wb.write(response.getOutputStream());
        } catch (Exception e) {
            log.error("导出Excel异常{}", e.getMessage());
            throw new CustomException("导出Excel失败，请联系网站管理员！");
        } finally {
            IOUtils.closeQuietly(wb);
            IOUtils.closeQuietly(out);
        }
        return filename;
    }

    /**
     * 对list数据源将其里面的数据导入到excel表单
     *
     * @return 结果
     */
    public AjaxResult exportExcel(String filename) {
        OutputStream out = null;
        try {
            // 取出一共有多少个sheet.
            double sheetNo = Math.ceil(list.size() / sheetSize);
            for (int index = 0; index <= sheetNo; index++) {
                createSheet(sheetNo, index);

                // 产生一行
                Row row = sheet.createRow(0);
                int column = 0;
                // 写入各个字段的列头名称
                for (Object[] os : fields) {
                    Excel excel = (Excel) os[1];
                    this.createCell(excel, row, column++);
                }
                if (Type.EXPORT.equals(type)) {
                    fillExcelData(index, row);
                }
            }
            out = new FileOutputStream(getAbsoluteFile(filename));
            wb.write(out);
            return AjaxResult.success(filename);
        } catch (Exception e) {
            log.error("导出Excel异常{}", e.getMessage());
            throw new CustomException("导出Excel失败，请联系网站管理员！");
        } finally {
            IOUtils.closeQuietly(wb);
            IOUtils.closeQuietly(out);
        }
    }


    /**
     * 对list数据源将其里面的数据导入到excel表单
     *
     * @return 结果
     */
    public AjaxResult exportExcel(File file) {
        OutputStream out = null;
        try {
            // 取出一共有多少个sheet.
            double sheetNo = Math.ceil(list.size() / sheetSize);
            for (int index = 0; index <= sheetNo; index++) {
                createSheet(sheetNo, index);

                // 产生一行
                Row row = sheet.createRow(0);
                int column = 0;
                // 写入各个字段的列头名称
                for (Object[] os : fields) {
                    Excel excel = (Excel) os[1];
                    this.createCell(excel, row, column++);
                }
                if (Type.EXPORT.equals(type)) {
                    fillExcelData(index, row);
                }
            }
            out = new FileOutputStream(file);
            wb.write(out);
            return AjaxResult.success(file.getName());
        } catch (Exception e) {
            log.error("导出Excel异常{}", e.getMessage());
            throw new CustomException("导出Excel失败，请联系网站管理员！");
        } finally {
            IOUtils.closeQuietly(wb);
            IOUtils.closeQuietly(out);
        }
    }

    /**
     * 填充excel数据
     *
     * @param index 序号
     * @param row   单元格行
     */
    public void fillExcelData(int index, Row row) {
        int startNo = index * sheetSize;
        int endNo = Math.min(startNo + sheetSize, list.size());
        for (int i = startNo; i < endNo; i++) {
            row = sheet.createRow(i + 1 - startNo);
            // 得到导出对象.
            T vo = (T) list.get(i);
            int column = 0;
            for (Object[] os : fields) {
                Field field = (Field) os[0];
                Excel excel = (Excel) os[1];
                // 设置实体类私有属性可访问
                field.setAccessible(true);
                this.addCell(excel, row, vo, field, column++);
            }
        }
    }

    /**
     * 创建表格样式
     *
     * @param wb 工作薄对象
     * @return 样式列表
     */
    private Map<String, CellStyle> createStyles(Workbook wb) {
        // 写入各条记录,每条记录对应excel表中的一行
        Map<String, CellStyle> styles = new HashMap<>();
        styles.put("data", ExcelUtil.getDataStyle(wb));
        styles.put("header", ExcelUtil.getHeaderStyle(wb));
        return styles;
    }

    /**
     * 表头样式
     *
     * @param workbook Workbook
     * @return CellStyle
     */
    public static CellStyle getHeaderStyle(Workbook workbook) {
        Font headerFont = workbook.createFont();
        headerFont.setFontName("Arial");
        headerFont.setFontHeightInPoints((short) 10);
        headerFont.setBold(true);
        headerFont.setColor(IndexedColors.WHITE.getIndex());
        CellStyle style = workbook.createCellStyle();
        style.setFont(headerFont);
        style.setFillForegroundColor(IndexedColors.GREY_80_PERCENT.getIndex());
        style.setFillPattern(FillPatternType.SOLID_FOREGROUND);
//        style.setAlignment(HorizontalAlignment.CENTER);
//        style.setVerticalAlignment(VerticalAlignment.CENTER);
        return style;
    }

    /**
     * 数据样式
     *
     * @param workbook Workbook
     * @return CellStyle
     */
    public static CellStyle getDataStyle(Workbook workbook) {
        CellStyle style = workbook.createCellStyle();
        Font dataFont = workbook.createFont();
        dataFont.setFontName("Arial");
        dataFont.setFontHeightInPoints((short) 10);
        style.setFont(dataFont);
//        style.setAlignment(HorizontalAlignment.CENTER);
//        style.setVerticalAlignment(VerticalAlignment.CENTER);
//        style.setBorderRight(BorderStyle.THIN);
//        style.setRightBorderColor(IndexedColors.GREY_50_PERCENT.getIndex());
//        style.setBorderLeft(BorderStyle.THIN);
//        style.setLeftBorderColor(IndexedColors.GREY_50_PERCENT.getIndex());
//        style.setBorderTop(BorderStyle.THIN);
//        style.setTopBorderColor(IndexedColors.GREY_50_PERCENT.getIndex());
//        style.setBorderBottom(BorderStyle.THIN);
//        style.setBottomBorderColor(IndexedColors.GREY_50_PERCENT.getIndex());
        return style;
    }

    /**
     * 创建单元格
     */
    public Cell createCell(Excel attr, Row row, int column) {
        // 创建列
        Cell cell = row.createCell(column);
        // 写入列信息
        cell.setCellValue(attr.name());
        setDataValidation(attr, row, column);
        cell.setCellStyle(styles.get("header"));
        return cell;
    }

    /**
     * 设置单元格信息
     *
     * @param value 单元格值
     * @param attr  注解相关
     * @param cell  单元格信息
     */
    public void setCellVo(Object value, Excel attr, Cell cell) {
        if (ColumnType.STRING == attr.cellType()) {
            cell.setCellType(CellType.NUMERIC);
            cell.setCellValue(StringUtils.isNull(value) ? attr.defaultValue() : value + attr.suffix());
        } else if (ColumnType.NUMERIC == attr.cellType()) {
            cell.setCellType(CellType.NUMERIC);
            cell.setCellValue(Integer.parseInt(value + ""));
        }
    }

    /**
     * 创建表格样式
     */
    public void setDataValidation(Excel attr, Row row, int column) {
        if (attr.name().indexOf("注：") >= 0) {
            sheet.setColumnWidth(column, 6000);
        } else {
            // 设置列宽
            sheet.setColumnWidth(column, (int) ((attr.width() + 0.72) * 256));
            row.setHeight((short) (attr.height() * 20));
        }
        // 如果设置了提示信息则鼠标放上去提示.
        if (StringUtils.isNotEmpty(attr.prompt())) {
            // 这里默认设了2-101列提示.
            setXSSFPrompt(sheet, "", attr.prompt(), 1, 100, column, column);
        }
        // 如果设置了combo属性则本列只能选择不能输入
        if (attr.combo().length > 0) {
            // 这里默认设了2-101列只能选择不能输入.
            setXSSFValidation(sheet, attr.combo(), 1, 100, column, column);
        }
    }

    /**
     * 添加单元格
     */
    public Cell addCell(Excel attr, Row row, T vo, Field field, int column) {
        Cell cell = null;
        try {
            // 设置行高
            row.setHeight((short) (attr.height() * 20));
            // 根据Excel中设置情况决定是否导出,有些情况需要保持为空,希望用户填写这一列.
            if (attr.isExport()) {
                // 创建cell
                cell = row.createCell(column);
                cell.setCellStyle(styles.get("data"));

                // 用于读取对象中的属性
                Object value = getTargetValue(vo, field, attr);
                String dateFormat = attr.dateFormat();
                String readConverterExp = attr.readConverterExp();
                if (StringUtils.isNotEmpty(dateFormat) && StringUtils.isNotNull(value)) {
                    cell.setCellValue(DateUtils.parseDateToStr(dateFormat, (Date) value));
                } else if (StringUtils.isNotEmpty(readConverterExp) && StringUtils.isNotNull(value)) {
                    cell.setCellValue(convertByExp(String.valueOf(value), readConverterExp));
                } else {
                    // 设置列类型
                    setCellVo(value, attr, cell);
                }
            }
        } catch (Exception e) {
            log.error("导出Excel失败{}",e.getMessage(), e);
        }
        return cell;
    }

    /**
     * 设置 POI XSSFSheet 单元格提示
     *
     * @param sheet         表单
     * @param promptTitle   提示标题
     * @param promptContent 提示内容
     * @param firstRow      开始行
     * @param endRow        结束行
     * @param firstCol      开始列
     * @param endCol        结束列
     */
    public void setXSSFPrompt(Sheet sheet, String promptTitle, String promptContent, int firstRow, int endRow,
                              int firstCol, int endCol) {
        DataValidationHelper helper = sheet.getDataValidationHelper();
        DataValidationConstraint constraint = helper.createCustomConstraint("DD1");
        CellRangeAddressList regions = new CellRangeAddressList(firstRow, endRow, firstCol, endCol);
        DataValidation dataValidation = helper.createValidation(constraint, regions);
        dataValidation.createPromptBox(promptTitle, promptContent);
        dataValidation.setShowPromptBox(true);
        sheet.addValidationData(dataValidation);
    }

    /**
     * 设置某些列的值只能输入预制的数据,显示下拉框.
     *
     * @param sheet    要设置的sheet.
     * @param textlist 下拉框显示的内容
     * @param firstRow 开始行
     * @param endRow   结束行
     * @param firstCol 开始列
     * @param endCol   结束列
     * @return 设置好的sheet.
     */
    public void setXSSFValidation(Sheet sheet, String[] textlist, int firstRow, int endRow, int firstCol, int endCol) {
        DataValidationHelper helper = sheet.getDataValidationHelper();
        // 加载下拉列表内容
        DataValidationConstraint constraint = helper.createExplicitListConstraint(textlist);
        // 设置数据有效性加载在哪个单元格上,四个参数分别是：起始行、终止行、起始列、终止列
        CellRangeAddressList regions = new CellRangeAddressList(firstRow, endRow, firstCol, endCol);
        // 数据有效性对象
        DataValidation dataValidation = helper.createValidation(constraint, regions);
        // 处理Excel兼容性问题
        if (dataValidation instanceof XSSFDataValidation) {
            dataValidation.setSuppressDropDownArrow(true);
            dataValidation.setShowErrorBox(true);
        } else {
            dataValidation.setSuppressDropDownArrow(false);
        }

        sheet.addValidationData(dataValidation);
    }

    /**
     * 解析导出值 0=男,1=女,2=未知
     *
     * @param propertyValue 参数值
     * @param converterExp  翻译注解
     * @return 解析后值
     * @throws Exception
     */
    public static String convertByExp(String propertyValue, String converterExp) throws Exception {
        try {
            String[] convertSource = converterExp.split(",");
            for (String item : convertSource) {
                String[] itemArray = item.split("=");
                if (itemArray[0].equals(propertyValue)) {
                    return itemArray[1];
                }
            }
        } catch (Exception e) {
            throw e;
        }
        return propertyValue;
    }

    /**
     * 反向解析值 男=0,女=1,未知=2
     *
     * @param propertyValue 参数值
     * @param converterExp  翻译注解
     * @return 解析后值
     * @throws Exception
     */
    public static String reverseByExp(String propertyValue, String converterExp) throws Exception {
        try {
            String[] convertSource = converterExp.split(",");
            for (String item : convertSource) {
                String[] itemArray = item.split("=");
                if (itemArray[1].equals(propertyValue)) {
                    return itemArray[0];
                }
            }
        } catch (Exception e) {
            throw e;
        }
        return propertyValue;
    }

    /**
     * 编码文件名
     */
    public String encodingFilename(String filename) {
        StringBuilder builder = new StringBuilder();
        builder.append(filename).append("_").append(DateUtils.dateTimeNow(YYYY_MM_DD_HH_MM_SS_SS)).append(".xlsx");
        return builder.toString();
    }

    /**
     * 获取下载路径
     *
     * @param filename 文件名称
     */
    public String getAbsoluteFile(String filename) {
        String downloadPath = CrcProperties.getDownloadPath() + filename;
        File desc = new File(downloadPath);
        if (!desc.getParentFile().exists()) {
            desc.getParentFile().mkdirs();
        }
        return downloadPath;
    }

    /**
     * 获取bean中的属性值
     *
     * @param vo    实体对象
     * @param field 字段
     * @param excel 注解
     * @return 最终的属性值
     * @throws Exception
     */
    private Object getTargetValue(T vo, Field field, Excel excel) throws Exception {
        Object o = field.get(vo);
        if (StringUtils.isNotEmpty(excel.targetAttr())) {
            String target = excel.targetAttr();
            if (target.indexOf(".") > -1) {
                String[] targets = target.split("[.]");
                for (String name : targets) {
                    o = getValue(o, name);
                }
            } else {
                o = getValue(o, target);
            }
        }
        return o;
    }

    /**
     * 以类的属性的get方法方法形式获取值
     *
     * @param o
     * @param name
     * @return value
     * @throws Exception
     */
    private Object getValue(Object o, String name) throws Exception {
        if (StringUtils.isNotEmpty(name)) {
            Class<?> clazz = o.getClass();
            String methodName = "get" + name.substring(0, 1).toUpperCase() + name.substring(1);
            Method method = clazz.getMethod(methodName);
            o = method.invoke(o);
        }
        return o;
    }

    /**
     * 得到所有定义字段
     */
    private void createExcelField() {
        this.fields = new ArrayList<Object[]>();
        List<Field> tempFields = new ArrayList<>();
        tempFields.addAll(Arrays.asList(clazz.getSuperclass().getDeclaredFields()));
        tempFields.addAll(Arrays.asList(clazz.getDeclaredFields()));
        for (Field field : tempFields) {
            // 单注解
            if (field.isAnnotationPresent(Excel.class)) {
                putToField(field, field.getAnnotation(Excel.class));
            }

            // 多注解
            if (field.isAnnotationPresent(Excels.class)) {
                Excels attrs = field.getAnnotation(Excels.class);
                Excel[] excels = attrs.value();
                for (Excel excel : excels) {
                    putToField(field, excel);
                }
            }
        }
    }

    /**
     * 放到字段集合中
     */
    private void putToField(Field field, Excel attr) {
        if (attr != null && (attr.type() == Type.ALL || attr.type() == type)) {
            this.fields.add(new Object[]{field, attr});
        }
    }

    /**
     * 创建一个工作簿
     */
    public void createWorkbook() {
        this.wb = new SXSSFWorkbook(500);
    }

    /**
     * 创建工作表
     *
     * @param sheetNo sheet数量
     * @param index   序号
     */
    public void createSheet(double sheetNo, int index) {
        this.sheet = wb.createSheet();
        this.styles = createStyles(wb);
        // 设置工作表的名称.
        if (sheetNo == 0) {
            wb.setSheetName(index, sheetName);
        } else {
            wb.setSheetName(index, sheetName + index);
        }
    }

    /**
     * 获取单元格值
     *
     * @param row    获取的行
     * @param column 获取单元格列号
     * @return 单元格值
     */
    public Object getCellValue(Row row, int column) {
        if (row == null) {
            return row;
        }
        Object val = "";
        try {
            Cell cell = row.getCell(column);
            if (cell != null) {
                if (cell.getCellType() == CellType.NUMERIC || cell.getCellType() == CellType.FORMULA) {
                    val = cell.getNumericCellValue();
                    if (HSSFDateUtil.isCellDateFormatted(cell)) {
                        val = DateUtil.getJavaDate((Double) val); // POI Excel 日期格式转换
                    } else {
                        if ((Double) val % 1 > 0) {
                            val = new DecimalFormat("0.00").format(val);
                        } else {
                            val = new DecimalFormat("0").format(val);
                        }
                    }
                } else if (cell.getCellType() == CellType.STRING) {
                    val = cell.getStringCellValue();
                } else if (cell.getCellType() == CellType.BOOLEAN) {
                    val = cell.getBooleanCellValue();
                } else if (cell.getCellType() == CellType.ERROR) {
                    val = cell.getErrorCellValue();
                }

            }
        } catch (Exception e) {
            return val;
        }
        return val;
    }

    public List<T> importExcelToList(InputStream is) throws Exception {
        this.type = Type.IMPORT;
        this.wb = WorkbookFactory.create(is);
        List<T> list = new ArrayList<T>();
        Sheet sheet = wb.getSheetAt(1);
        int rows = sheet.getPhysicalNumberOfRows();
        if (rows > 0) {
            // 定义一个map用于存放excel列的序号和field.
            Map<String, Integer> cellMap = new HashMap<String, Integer>();
            // 获取树节点表头
            Row heard = sheet.getRow(0);
            for (int i = 0; i < heard.getPhysicalNumberOfCells(); i++) {
                Cell cell = heard.getCell(i);
                if (StringUtils.isNotNull(cell != null)) {
                    String value = this.getCellValue(heard, i).toString();
                    cellMap.put(value, i);
                } else {
                    cellMap.put(null, i);
                }
            }
            // 有数据时才处理 得到类的所有field.
            Field[] allFields = clazz.getDeclaredFields();
            // 定义一个map用于存放列的序号和field.
            Map<Integer, Field> fieldsMap = new HashMap<Integer, Field>();
            for (int col = 0; col < allFields.length; col++) {
                Field field = allFields[col];
                Excel attr = field.getAnnotation(Excel.class);
                if (attr != null && (attr.type() == Type.ALL || attr.type() == type)) {
                    // 设置类的私有字段属性可访问.
                    field.setAccessible(true);
                    Integer column = cellMap.get(attr.name());
                    fieldsMap.put(column, field);
                }
            }
            for (int i = 1; i < rows; i++) {
                // 从第2行开始取数据,默认第一行是表头.
                Row row = sheet.getRow(i);
                String questionNumber = this.getCellValue(row, 0).toString();
                if ("问题双方确认".equals(questionNumber)) {
                    break;
                }
                T entity = null;
                for (Map.Entry<Integer, Field> entry : fieldsMap.entrySet()) {
                    if (entry.getKey() == null) {
                        continue;
                    }
                    Object val = this.getCellValue(row, entry.getKey());

                    // 如果不存在实例则新建.
                    entity = (entity == null ? clazz.newInstance() : entity);
                    // 从map中得到对应列的field.
                    Field field = fieldsMap.get(entry.getKey());
                    // 取得类型,并根据对象类型设置值.
                    Class<?> fieldType = field.getType();
                    if (String.class == fieldType) {
                        String s = Convert.toStr(val);
                        if (StringUtils.endsWith(s, "0")) {
                            val = StringUtils.substringBefore(s, "0");
                        } else {
                            val = Convert.toStr(val);
                        }
                    } else if ((Integer.TYPE == fieldType) || (Integer.class == fieldType)) {
                        val = Convert.toInt(val);
                    } else if ((Long.TYPE == fieldType) || (Long.class == fieldType)) {
                        val = Convert.toLong(val);
                    } else if ((Double.TYPE == fieldType) || (Double.class == fieldType)) {
                        val = Convert.toDouble(val);
                    } else if ((Float.TYPE == fieldType) || (Float.class == fieldType)) {
                        val = Convert.toFloat(val);
                    } else if (BigDecimal.class == fieldType) {
                        val = Convert.toBigDecimal(val);
                    } else if (Date.class == fieldType) {
                        if (val instanceof String) {
                            val = DateUtils.parseDate(val);
                        } else if (val instanceof Double) {
                            val = DateUtil.getJavaDate((Double) val);
                        }
                    }
                    if (StringUtils.isNotNull(fieldType)) {
                        Excel attr = field.getAnnotation(Excel.class);
                        String propertyName = field.getName();
                        if (StringUtils.isNotEmpty(attr.targetAttr())) {
                            propertyName = field.getName() + "." + attr.targetAttr();
                        } else if (StringUtils.isNotEmpty(attr.readConverterExp())) {
                            val = reverseByExp(String.valueOf(val), attr.readConverterExp());
                        }
                        ReflectUtils.invokeSetter(entity, propertyName, val);
                    }
                }
                if (entity != null) {
                    list.add(entity);
                }
            }
        }
        return list;
    }

    /**
     * 创建Workbook对象
     *
     * @param is
     * @param excelFileName
     * @return
     * @throws IOException
     */
    public static Workbook createWorkbook(InputStream is, String excelFileName) throws IOException {
        if (excelFileName.endsWith(".xls")) {
            if (null != is) {
                return new HSSFWorkbook(is);
            }
            return new HSSFWorkbook();
        } else if (excelFileName.endsWith(".xlsx") || excelFileName.endsWith(".xltm") || excelFileName.endsWith(".xlsm")) {
            if (null != is) {
                return new XSSFWorkbook(is);
            }
            return new XSSFWorkbook();
        }
        return null;
    }

    /**
     * 创建excel名称
     *
     * @param workbook
     */
    public static void createExcelName(Workbook workbook, String nameName, String expression) {
        nameName = nameName.replace(Constants.Symbol.LEFT_PARENTHESES, Constants.Symbol.NULL_STR)
                .replace(Constants.Symbol.RIGHT_PARENTHESES, Constants.Symbol.NULL_STR)
                .replace(Constants.Symbol.ZH_LEFT_PARENTHESES, Constants.Symbol.NULL_STR)
                .replace(Constants.Symbol.MINUS, Constants.Symbol.NULL_STR)
                .replace(Constants.Symbol.ZH_RIGHT_PARENTHESES, Constants.Symbol.NULL_STR);
        Name name = workbook.getName(nameName);
        if (null == name) {
            name = workbook.createName();
            name.setNameName(nameName);
            name.setRefersToFormula(expression);
        }

    }

    /**
     * 解析excel数据
     *
     * @param file
     * @param sheetName
     * @param keys
     * @param verificationFunction
     * @return
     */
    public static List<Map<String, String>> readExcelData(MultipartFile file, String sheetName, Map<String, String> keys, Function<Workbook, Object> verificationFunction) {
        List<Map<String, String>> result = null;
        try (InputStream input = file.getInputStream()) {
            result = new ArrayList<>();

            // 创建文档
            XSSFWorkbook wb = new XSSFWorkbook(input);

            //业务验证
            if (null != verificationFunction) {
                verificationFunction.apply(wb);
            }
            XSSFSheet XSSFSheet = wb.getSheet(sheetName);
            if (XSSFSheet == null) {
                throw new CustomException("文件错误");
            }

            //读取Row
            int totalRows = XSSFSheet.getLastRowNum();
            String[] titles = null;
            Map<String, String> rowMap = null;
            for (int rowNum = 0; rowNum <= totalRows; rowNum++) {
                XSSFRow xssfRow = XSSFSheet.getRow(rowNum);
                if (xssfRow != null) {
                    if (rowNum == 0) {
                        titles = new String[xssfRow.getLastCellNum()];
                        XSSFCell cell = null;
                        for (int i = 0, num = xssfRow.getLastCellNum(); i < num; i++) {
                            cell = xssfRow.getCell(i);
                            titles[i] = cell.getStringCellValue();
                        }
                    } else {
                        rowMap = new HashMap<>();
                        int totalCells = EXCEL_CELL_MAX_LENGTH;
                        //读取列，从第一列开始
                        XSSFCell cell = null;
                        for (int i = 0; i <= totalCells; i++) {
                            cell = xssfRow.getCell(i);
                            if (cell == null) {
                                continue;
                            }
                            String value = String.valueOf(getCellData(cell)).trim();
                            if (keys.containsKey(titles[i])) {
                                rowMap.put(keys.get(titles[i]), value);
                            }
                        }
                        if (verificationRowData(rowMap)) {
                            result.add(rowMap);
                        }
                    }
                }
            }
        } catch (IOException e) {
            throw new CustomException("文件解析失败");
        }
        return result;
    }

    /**
     * 写入数据
     *
     * @param workbook
     * @param data
     * @param keys
     * @param sheetName
     */
    public static void wirteData(Workbook workbook, List<Map<String, String>> data, Map<String, String> keys, String sheetName, Function<Row, BiFunction<Integer, String, Object>> function) {
        Sheet sheet = workbook.getSheet(sheetName);
        //读取标题
        Row row = sheet.getRow(0);
        int lastCellNum = row.getLastCellNum();
        String[] titles = new String[lastCellNum];
        for (int i = 0; i < lastCellNum; i++) {
            titles[i] = String.valueOf(getCellData(row.getCell(i))).trim().replaceAll(" ", "");
        }

        int num = 1;
        Cell cell = null;
        for (Map<String, String> rowData : data) {
            row = sheet.getRow(num);
            if (null == row) {
                row = sheet.createRow(num);
            }
            Set<Map.Entry<String, String>> entrySet = keys.entrySet();
            int missNum = 0;
            for (Map.Entry<String, String> keyEntry : entrySet) {
                boolean bool = false;
                for (int i = 0, size = titles.length; i < size; i++) {
                    if (keyEntry.getKey().equals(titles[i])) {
                        cell = row.getCell(i);
                        if (null == cell) {
                            cell = row.createCell(i);
                        }
                        String cellValue = rowData.get(keyEntry.getValue());
                        if (StrUtil.isNotEmpty(cellValue) && cellValue.length() > EXCEL_CELL_MAXIMUM) {
                            cellValue = cellValue.substring(0, EXCEL_CELL_MAXIMUM);
                        }
                        cell.setCellValue(cellValue);
                        bool = true;
                        break;
                    }
                }
                if (!bool) {
                    /*cell = row.createCell(lastCellNum + missNum);
                    cell.setCellValue(rowData.get(keyEntry.getValue()));*/
                    if (null != function) {
                        function.apply(row).apply(lastCellNum + missNum, rowData.get(keyEntry.getValue()));
                    }
                    missNum++;
                }
            }
            num++;
        }
    }

    private static boolean verificationRowData(Map<String, String> rowMap) {
        Set<Map.Entry<String, String>> entries = rowMap.entrySet();
        boolean result = false;
        for (Map.Entry<String, String> data : entries) {
            if (org.apache.commons.lang3.StringUtils.isNotEmpty(data.getValue())) {
                result = true;
                break;
            }
        }
        return result;
    }

    /**
     * 读取excel文件数据
     *
     * @param file
     * @param startReadRow
     * @param startReadColl
     * @return
     */
    private static List<ArrayList<String>> readXls(MultipartFile file, int startReadRow, int startReadColl) {
        List<ArrayList<String>> list = new ArrayList<>();
        // IO流读取文件
        InputStream input = null;
        HSSFWorkbook wb = null;
        ArrayList<String> rowList = null;
        try {
            input = file.getInputStream();
            // 创建文档
            wb = new HSSFWorkbook(input);
            //读取sheet(页)
            for (int numSheet = 0; numSheet < wb.getNumberOfSheets(); numSheet++) {
                HSSFSheet hssfSheet = wb.getSheetAt(numSheet);
                if (hssfSheet == null) {
                    continue;
                }
                int totalRows = hssfSheet.getLastRowNum();
                //读取Row,从第二行开始
                for (int rowNum = startReadRow; rowNum <= totalRows; rowNum++) {
                    HSSFRow hssfRow = hssfSheet.getRow(rowNum);
                    if (hssfRow != null) {
                        rowList = new ArrayList<String>();
                        int totalCells = hssfRow.getLastCellNum();
                        //读取列，从第一列开始
                        for (int c = startReadColl; c <= totalCells + 1; c++) {
                            HSSFCell cell = hssfRow.getCell(c);
                            if (cell == null) {
                                rowList.add("");
                                continue;
                            }
                            rowList.add(String.valueOf(getCellData(cell)).trim());
                        }
                        list.add(rowList);
                    }
                }
            }
            return list;
        } catch (IOException e) {
            e.printStackTrace();
        } finally {
            IOUtils.closeQuietly(input);
        }
        return null;
    }

    /**
     * 获取单元格信息
     *
     * @param cell
     * @return
     */
    private static Object getCellData(Cell cell) {
        Object data = null;
        switch (cell.getCellType()) {
            // 数字
            case NUMERIC:
                data = cell.getNumericCellValue();
                break;
            // 字符串
            case STRING:
                data = cell.getStringCellValue();
                break;
            // Boolean
            case BOOLEAN:
                data = cell.getBooleanCellValue();
                break;
            // 公式
            case FORMULA:
                data = cell.getCellFormula();
                break;
            // 空值
            case BLANK:
                data = "";
                break;
            // 故障
            case ERROR:
            default:
                data = null;
                break;
        }
        return data;
    }

    /**
     * 创建导出表头
     *
     * @param workbook
     * @param titles
     * @param sheetName
     */
    public static void wirteTitle(Workbook workbook, List<String> titles, String sheetName) {
        Sheet sheet = workbook.getSheet(sheetName);
        if (null == sheet) {
            sheet = workbook.createSheet(sheetName);
        }
        Row row = sheet.createRow(0);
        Cell cell = null;
        for (int cellNum = 0, size = titles.size(); cellNum < size; cellNum++) {
            cell = row.createCell(cellNum);
            cell.setCellValue(titles.get(cellNum));
        }
    }

    public static void wirteOutExcel(HttpServletResponse response, Workbook workbook, String outputName) throws IOException {
        response.setContentType("application/octet-stream");
        response.setHeader("Content-Disposition", "attachment;filename=" + URLEncoder.encode(outputName, "utf-8"));
        response.flushBuffer();
        workbook.write(response.getOutputStream());
    }

    /**
     * 计算excel表头
     *
     * @param cellNum
     * @param sheetName
     * @return
     */
    public static String calculationExpression(int rowNum, int cellNum, String sheetName) {
        int total = 26;
        int A_ascii = 65;
        String excelTab = "";
        if (cellNum < total) {
            char titleChar = (char) (cellNum + A_ascii);
            excelTab = String.valueOf(titleChar);
        } else {
            int remainder = cellNum % total;
            int num = cellNum / total - 1;
            char firstChar = (char) (num + A_ascii);
            char endChar = (char) (remainder + A_ascii);
            excelTab = String.valueOf(firstChar) + String.valueOf(endChar);
        }

        StringBuilder expression = new StringBuilder();
        expression.append(sheetName)
                .append("!")
                .append("$")
                .append(excelTab)
                .append("$1")
                .append(":$")
                .append(excelTab)
                .append("$")
                .append(rowNum);
        return expression.toString();
    }


    /**
     * excel中填入模板数据
     *
     * @param workbook
     * @param data
     * @param sheetName
     * @param cellNum
     */
    public static void makeDataForExcel(Workbook workbook, List<String> data, String sheetName, int cellNum) {
        if (null == data || data.isEmpty()) {
            return;
        }
        Sheet sheet = workbook.getSheet(sheetName);
        if (null == sheet) {
            sheet = workbook.createSheet(sheetName);
        }

        int rowNum = 0;
        for (String str : data) {
            Row row = sheet.getRow(rowNum);
            if (null == row) {
                row = sheet.createRow(rowNum);
            }
            Cell coll = row.createCell(cellNum);
            coll.setCellValue(str);
            rowNum++;
        }
    }

    /**
     * 设置错误详情单元格字体格式
     *
     * @param workbook
     */
    public static CellStyle setCellStyle(Workbook workbook) {
        Font font = workbook.createFont();
        font.setColor(Font.COLOR_RED);
        CellStyle cellStyle = workbook.createCellStyle();
        cellStyle.setFont(font);
        return cellStyle;
    }

    /**
     * 导入错误写入表格  默认第一列为错误信息单元格字体标红
     *
     * @param response    HttpServletResponse
     * @param inputStream InputStream
     * @param list        数据源
     * @param sheetName   sheet名称
     * @param fileName    导出文件名称
     */
    public void errorWriteData(HttpServletResponse response, InputStream inputStream, List<T> list,
                               String sheetName, String fileName) throws IOException {
        wb = WorkbookFactory.create(inputStream);
        createExcelField();
        this.styles = createStyles(wb);
        Sheet sheet = wb.getSheet(sheetName);
        // 错误信息列单元格样式
        CellStyle style = ExcelUtil.setCellStyle(wb);
        // 创建普通行
        IntStream.range(0, list.size()).forEach(i -> {
            Row row = sheet.createRow(i + 1);
            // 得到导出对象.
            T vo = list.get(i);
            int column = 0;
            for (Object[] os : fields) {
                Field field = (Field) os[0];
                Excel excel = (Excel) os[1];
                // 设置实体类私有属性可访问
                field.setAccessible(true);
                Cell cell = this.addCell(excel, row, vo, field, column++);
                if (1 == column) {
                    cell.setCellStyle(style);
                }
            }
        });
        ExcelUtil.wirteOutExcel(response, wb, this.encodingFilename(fileName));
    }

    /**
     * 校验模板来源
     * @param sheetName 工作表名称
     * @param identity 正版标识
     * @param is 文件流
     * @return 返回枚举
     */
    public ResponseEnum traceSource(String sheetName, String identity, InputStream is){
        try {
            this.type = Type.IMPORT;
            this.wb = WorkbookFactory.create(is);
            Sheet sheet = null;
            if (StringUtils.isNotEmpty(sheetName)) {
                // 如果指定sheet名,则取指定sheet中的内容.
                sheet = wb.getSheet(sheetName);
            } else {
                // 如果传入的sheet名不存在则默认指向第1个sheet.
                sheet = wb.getSheetAt(0);
            }

            if (sheet == null) {
                return ResponseEnum.IMPORT_COLUMN_TYPE_ERROR;
            }

            int rows = sheet.getPhysicalNumberOfRows();
            if(rows <= 0){
                return ResponseEnum.UPLOAD_FILE_IS_NULL;
            }
            //获取表头
            Row heard = sheet.getRow(0);
            Cell cell = heard.getCell(0);
            String stringCellValue = cell.getStringCellValue();
            if(StrUtil.isEmpty(stringCellValue) || !identity.equals(stringCellValue)){
                return ResponseEnum.IMPORT_COLUMN_TYPE_ERROR;
            }
        }catch (Exception e){
            return ResponseEnum.IMPORT_COLUMN_TYPE_ERROR;
        }
        return null;
    }

    public ResponseEnum checkTitle(String sheetName, InputStream is, List<String> titles) {
        try {
            this.type = Type.IMPORT;
            this.wb = WorkbookFactory.create(is);
            Sheet sheet = null;
            if (StringUtils.isNotEmpty(sheetName)) {
                // 如果指定sheet名,则取指定sheet中的内容.
                sheet = wb.getSheet(sheetName);
            } else {
                // 如果传入的sheet名不存在则默认指向第1个sheet.
                sheet = wb.getSheetAt(0);
            }

            if (sheet == null) {
                return ResponseEnum.IMPORT_COLUMN_TYPE_ERROR;
            }

            int rows = sheet.getPhysicalNumberOfRows();
            if(rows <= 0){
                return ResponseEnum.UPLOAD_FILE_IS_NULL;
            }
            //获取表头
            Row heard = sheet.getRow(0);
            List<String> cellValueList = new ArrayList<>();
            for (int i = 0; i < heard.getPhysicalNumberOfCells(); i++) {
                Cell cell = heard.getCell(i);
                if (StringUtils.isNotNull(cell != null)) {
                    cellValueList.add(this.getCellValue(heard, i).toString());
                }
            }
            if(CollUtil.isEmpty(cellValueList) || !cellValueList.containsAll(titles)){
                return ResponseEnum.IMPORT_COLUMN_TYPE_ERROR;
            }
        }catch (Exception e){
            return ResponseEnum.IMPORT_COLUMN_TYPE_ERROR;
        }
        return null;
    }
}
