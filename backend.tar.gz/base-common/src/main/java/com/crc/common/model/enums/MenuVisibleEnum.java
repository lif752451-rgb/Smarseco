package com.crc.common.model.enums;

/**
 * @Author WANGLEI
 * @Description 菜单是否显示枚举
 * @DateTime 2022/3/16 17:10
 */
public enum MenuVisibleEnum {

    DISPLAY("0","显示"),
    HIDDEN("1","隐藏"),

    ;


    /**
     * 类型
     */
    private String type;

    /**
     * 描述
     */
    private String desc;

    MenuVisibleEnum(String type, String desc){
        this.type = type;
        this.desc = desc;
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }

    public String getDesc() {
        return desc;
    }

    public void setDesc(String desc) {
        this.desc = desc;
    }
}
