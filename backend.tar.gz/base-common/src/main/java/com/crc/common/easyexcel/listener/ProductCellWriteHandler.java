package com.crc.common.easyexcel.listener;

import java.lang.annotation.Annotation;
import java.lang.reflect.Field;
import java.util.Arrays;
import java.util.Map;
import java.util.Optional;

import com.alibaba.excel.constant.BuiltinFormats;
import org.apache.poi.ss.usermodel.CellStyle;
import org.apache.poi.ss.usermodel.DataValidation;
import org.apache.poi.ss.usermodel.DataValidationConstraint;
import org.apache.poi.ss.usermodel.DataValidationHelper;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.util.CellRangeAddressList;

import com.alibaba.excel.annotation.write.style.ContentStyle;
import com.alibaba.excel.metadata.Head;
import com.alibaba.excel.write.handler.SheetWriteHandler;
import com.alibaba.excel.write.metadata.holder.WriteSheetHolder;
import com.alibaba.excel.write.metadata.holder.WriteWorkbookHolder;
import com.alibaba.excel.write.property.ExcelWriteHeadProperty;

/**
 * 下载模板设置下拉框监控器、设置单元格格式
 * 
 * @author zhangbing
 */
public abstract class ProductCellWriteHandler implements SheetWriteHandler {

    /**
     * 根据下标自定义下拉框
     * 
     * @param subscriptMap k 为存在下拉数据集的单元格下表 v为下拉数据集
     * @return ProductCellWriteHandler
     */
    public static ProductCellWriteHandler subscriptBuild(Map<Integer, String[]> subscriptMap) {
        return new ProductCellWriteHandler() {

            @Override
            public void beforeSheetCreate(WriteWorkbookHolder writeWorkbookHolder, WriteSheetHolder writeSheetHolder) {

            }

            @Override
            public void afterSheetCreate(WriteWorkbookHolder writeWorkbookHolder, WriteSheetHolder writeSheetHolder) {
                // 这里可以对cell进行任何操作
                Sheet sheet = writeSheetHolder.getSheet();
                DataValidationHelper helper = sheet.getDataValidationHelper();
                // k 为存在下拉数据集的单元格下表 v为下拉数据集
                subscriptMap.forEach((k, v) -> {
                    // 下拉列表约束数据
                    DataValidationConstraint constraint = helper.createExplicitListConstraint(v);
                    // 设置下拉单元格的首行 末行 首列 末列
                    CellRangeAddressList rangeList = new CellRangeAddressList(1, 65536, k, k);
                    // 设置约束
                    DataValidation validation = helper.createValidation(constraint, rangeList);
                    // 阻止输入非下拉选项的值
                    validation.setErrorStyle(DataValidation.ErrorStyle.STOP);
                    validation.setShowErrorBox(true);
                    validation.setSuppressDropDownArrow(true);
                    validation.createErrorBox("提示", "此值与单元格定义格式不一致");
                    // validation.createPromptBox("填写说明：","填写内容只能为下拉数据集中的单位，其他单位将会导致无法入仓");
                    sheet.addValidationData(validation);
                });
            }
        };
    }

    /**
     * 根据属性自定义下拉框
     *
     * @param headNameMap k 为存在下拉数据集的实体类映射属性名称 v为下拉数据集
     * @return ProductCellWriteHandler
     */
    public static ProductCellWriteHandler headNameBuild(Map<String, String[]> headNameMap) {
        return new ProductCellWriteHandler() {

            @Override
            public void beforeSheetCreate(WriteWorkbookHolder writeWorkbookHolder, WriteSheetHolder writeSheetHolder) {

            }

            @Override
            public void afterSheetCreate(WriteWorkbookHolder writeWorkbookHolder, WriteSheetHolder writeSheetHolder) {
                // 这里可以对cell进行任何操作
                Sheet sheet = writeSheetHolder.getSheet();
                DataValidationHelper helper = sheet.getDataValidationHelper();
                ExcelWriteHeadProperty excelWriteHeadProperty = writeSheetHolder.getExcelWriteHeadProperty();
                Map<Integer, Head> headMap = excelWriteHeadProperty.getHeadMap();
                // k 为存在下拉数据集的实体类映射属性名称 v为下拉数据集
                for (Map.Entry<String, String[]> entry : headNameMap.entrySet()) {
                    // 获取对应下拉框所有列数
                    Optional<Integer> colNumOpt = headMap.entrySet().stream()
                        .filter(handEntry -> handEntry.getValue().getFieldName().equals(entry.getKey()))
                        .map(Map.Entry::getKey).findFirst();
                    if (colNumOpt.isPresent()) {
                        // 下拉列表约束数据
                        DataValidationConstraint constraint = helper.createExplicitListConstraint(entry.getValue());
                        // 设置下拉单元格的首行 末行 首列 末列
                        int colNum = colNumOpt.get();
                        CellRangeAddressList rangeList = new CellRangeAddressList(1, 65536, colNum, colNum);
                        // 设置约束
                        DataValidation validation = helper.createValidation(constraint, rangeList);
                        // 阻止输入非下拉选项的值
                        validation.setErrorStyle(DataValidation.ErrorStyle.STOP);
                        validation.setShowErrorBox(true);
                        validation.setSuppressDropDownArrow(true);
                        validation.createErrorBox("提示", "此值与单元格定义格式不一致");
                        // validation.createPromptBox("填写说明：","填写内容只能为下拉数据集中的单位，其他单位将会导致无法入仓");
                        sheet.addValidationData(validation);
                    }
                }
            }
        };
    }

    /**
     * 下载模板时设置整列单元格格式
     * 
     * @return ProductCellWriteHandler
     */
    public static ProductCellWriteHandler customCellFormat() {
        return new ProductCellWriteHandler() {

            @Override
            public void beforeSheetCreate(WriteWorkbookHolder writeWorkbookHolder, WriteSheetHolder writeSheetHolder) {

            }

            @Override
            public void afterSheetCreate(WriteWorkbookHolder writeWorkbookHolder, WriteSheetHolder writeSheetHolder) {
                // 这里可以对cell进行任何操作
                Sheet sheet = writeSheetHolder.getSheet();

                ExcelWriteHeadProperty excelWriteHeadProperty = writeSheetHolder.getExcelWriteHeadProperty();
                Map<Integer, Head> headMap = excelWriteHeadProperty.getHeadMap();
                for (Map.Entry<Integer, Head> entry : headMap.entrySet()) {
                    Field field = entry.getValue().getField();
                    Optional<Annotation> opt = Arrays.stream(field.getAnnotations())
                        .filter(annotation -> annotation.annotationType() == ContentStyle.class).findFirst();
                    if (opt.isPresent()) {
                        CellStyle columnStyle = sheet.getWorkbook().createCellStyle();
                        ContentStyle style = field.getAnnotation(ContentStyle.class);
                        columnStyle.setDataFormat(style.dataFormat());
                        sheet.setDefaultColumnStyle(entry.getKey(), columnStyle);
                    }
                }
            }
        };
    }
}
