package com.crc.common.model.response;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;
import lombok.ToString;

/**
 * 数据统计-前端显示
 */
@Data
@ToString
@ApiModel(value = "数据统计-前端显示")
public class DictStatResp {

    /**
     * 显示值
     */
    @ApiModelProperty(value = "显示值")
    private String dictLabel;

    /**
     * 实际值-前后端交互
     */
    @ApiModelProperty(value = "实际值")
    private String dictValue;

    /**
     * 统计数量
     */
    @ApiModelProperty(value = "统计数量")
    private Integer count;

    /**
     * 备注
     */
    @ApiModelProperty(value = "统计数量")
    private String remark;

    public DictStatResp() {
    }

    public DictStatResp(String dictLabel, String dictValue, Integer count, String remark) {
        this.dictLabel = dictLabel;
        this.dictValue = dictValue;
        this.count = count;
        this.remark = remark;
    }
}
