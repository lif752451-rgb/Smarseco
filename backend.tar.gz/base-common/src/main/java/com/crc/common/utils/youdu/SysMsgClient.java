package com.crc.common.utils.youdu;

import com.google.gson.JsonObject;


public class SysMsgClient {

    private int buin;
    private String host;
    private String appId;
    private String appAeskey;

    private AESCrypto crypto;
    private AppTokenClient tokenClient;

    private final static String MessageTypeSystem = "sysMsg";

    public SysMsgClient(YDApp app) {
        this.buin = app.getBuin();
        this.host = app.getHost();
        this.appId = app.getAppId();
        this.appAeskey = app.getAppAesKey();
        this.crypto = new AESCrypto(appId, appAeskey);
        this.tokenClient = new AppTokenClient(buin, host, appId, appAeskey);
    }

    /**
     * 发送系统消息
     *
     * @param toUser
     *         接收消息的用户
     * @param toDept
     *         接收消息的部门
     * @param sysMsg
     *         系统消息对象
     * @throws AESCryptoException
     *         加解密失败
     * @throws ParamParserException
     *         参数解析失败
     * @throws HttpRequestException
     *         http请求失败
     */
    public void sendSysMsg(String toUser, SysMsgBody sysMsg) throws ParamParserException, HttpRequestException, AESCryptoException {
        Message msg = new Message(toUser,null, MessageTypeSystem, sysMsg);
        String cipherText = this.crypto.encrypt(Helper.utf8Bytes(msg.toJson()));
        JsonObject param = new JsonObject();
        param.addProperty("buin", this.buin);
        param.addProperty("appId", this.appId);
        param.addProperty("encrypt", cipherText);
        Helper.postJson(uriSendMsg(), param.toString());
    }

    private String uriSendMsg() throws ParamParserException, HttpRequestException, AESCryptoException {
        String msg = String.format("%s%s%s?accessToken=%s", "http://", this.host, "/cgi/msg/send", this.tokenClient.getToken());
        return String.format("%s%s%s?accessToken=%s", "http://", this.host, "/cgi/msg/send", this.tokenClient.getToken());

    }
}
