package com.crc.common.utils;

import com.crc.common.constant.TimeUnit;
import org.apache.commons.lang3.StringUtils;
import org.apache.commons.lang3.time.DateFormatUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.lang.management.ManagementFactory;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.time.Instant;
import java.time.LocalDateTime;
import java.time.ZoneId;
import java.time.format.DateTimeFormatter;
import java.util.*;

/**
 * 时间工具类
 *
 * @author wst
 */
public class DateUtils extends org.apache.commons.lang3.time.DateUtils {

    private static Logger logger = LoggerFactory.getLogger(DataUtils.class);

    public static String YYYY = "yyyy";

    public static String YYYY_MM = "yyyy-MM";
    public static String YYYYMMDD = "yyyyMMdd";
    public static String YYYYMMDD2 = "yyyy.MM.dd";
    public static String YYYY_MM_DD = "yyyy-MM-dd";
    public static String YYYY_MM_DD_ = "yyyy/MM/dd";
    public static String HH_MM_SS = "HH:mm:ss";

    private static final String DATE_FORMAT_STRING5 = "yyyy.MM.dd";
    public static String YYYY_MM_DD_HH = "yyyy-MM-dd HH";
    public static String YYYY_MM_DD_HH_MM_SS_  = "yyyy/MM/dd HH:mm:ss";

    public static String YYYYMMDDHHMMSS = "yyyyMMddHHmmss";

    public static String YYYY_MM_DD_HH_MM = "yyyy-MM-dd HH:mm";


    public static String YYYY_MM_DD_HH_MM_SS = "yyyy-MM-dd HH:mm:ss";

    private static String ES_TIME_FORMAT1 = "yyyy-MM-dd'T'HH:mm:ss";
    public static final String DATE_FORMAT_HOUR = "yyyy-MM-dd HH";

    public static final String DATE_FORMAT_MINUTE = "yyyy-MM-dd HH:mm";

    public static final String DATE_FORMAT_DAY = "yyyy-MM-dd";

    public static final String DATE_FORMAT_DAY_ZH = "yyyy年MM月dd日";


    public static final String DATE_FORMAT_HOUR_MINUTE = "HH:mm";


    public static final String DATE_FORMAT_STRING1 = "yyyy-MM-dd HH:mm:ss";

    public static String ES_TIME_FORMAT = "yyyy-MM-dd'T'HH:mm:ss.SSSZ";

    public static String ES_TIME_FORMAT2 = "yyyy-MM-dd'T'HH:mm:ss";

    public static final String DATE_TIME_FORMAT_STRING1 = "yyyy-MM-dd HH:mm:ss";

    public static String YYYY_MM_DD_HH_MM_SS_SS = "yyyyMMddHHmmssSS";

    public static final String DATE_FORMAT_MINUTE_NEW = "MM-dd HH:mm:ss";

    public static final String DATE_FORMAT_MONTH_DAY = "MM-dd HH:mm";

    public static final String DATE_FORMAT_MONTH_DAY_NEW = "MM-dd";

    public static final String DATE_FORMAT_MONTH_DAY_NEW2 = "yyyy-MM-dd'T'HH:mm:ss.SSS";

    public static String DD = "dd";

    public static String format(LocalDateTime localDateTime, String pattern) {
        DateTimeFormatter formatter = DateTimeFormatter.ofPattern(pattern);
        formatter.withZone(ZoneId.of("Asia/Shanghai"));
        return formatter.format(localDateTime);
    }

    public static String[] getTimeRangeBy7Today() {
        String[] times = new String[2];
        Calendar calendar = Calendar.getInstance();
        SimpleDateFormat sdf8 = new SimpleDateFormat(ES_TIME_FORMAT);
        sdf8.setTimeZone(TimeZone.getTimeZone("GMT+8:00"));
        calendar.setTime(new Date());
        calendar.set(Calendar.SECOND, 0);
        times[0] = sdf8.format(calendar.getTime());
        calendar.add(Calendar.DAY_OF_YEAR, -7);
        calendar.set(Calendar.HOUR_OF_DAY, 0);
        calendar.set(Calendar.MINUTE, 0);
        calendar.set(Calendar.SECOND, 0);
        times[1] = sdf8.format(calendar.getTime());
        return times;
    }

    public static String[] getTimeRangeBy1Today() {
        String[] times = new String[2];
        Calendar calendar = Calendar.getInstance();
        SimpleDateFormat sdf8 = new SimpleDateFormat(ES_TIME_FORMAT);
        sdf8.setTimeZone(TimeZone.getTimeZone("GMT+8:00"));
        calendar.setTime(new Date());
        calendar.set(Calendar.SECOND, 0);
        times[0] = sdf8.format(calendar.getTime());
        times[1] = times[0].substring(0, 10) + "T00:00:00.000+08:00";
        return times;
    }

    /**
     * 获取现在时间
     */
    public static String getUTC(String timeStr) {
        TimeZone tz = TimeZone.getTimeZone("Asia/Shanghai");
        TimeZone.setDefault(tz);
        Date date = parseDate(timeStr);
        SimpleDateFormat sdf8 = new SimpleDateFormat(ES_TIME_FORMAT);
        return sdf8.format(date);
    }

    /**
     * 获得本周的第一天，周一
     *
     * @return
     */
    public static Date getCurrentWeekDayStartTime() {
        Calendar c = Calendar.getInstance();
        try {
            c.setTime(longSdf.parse(shortSdf.format(getWeekDate().get("mondayDate")) + " 00:00:00"));
        } catch (Exception e) {
            e.printStackTrace();
        }
        return c.getTime();
    }

    private final static SimpleDateFormat shortSdf = new SimpleDateFormat("yyyy-MM-dd");
    private final static SimpleDateFormat longHourSdf = new SimpleDateFormat("yyyy-MM-dd HH");
    ;
    public final static SimpleDateFormat longSdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
    ;

    /**
     * 获得本周的最后一天，周日
     *
     * @return
     */
    public static Date getCurrentWeekDayEndTime() {
        Calendar c = Calendar.getInstance();
        try {
            c.setTime(longSdf.parse(shortSdf.format(getWeekDate().get("sundayDate")) + " 23:59:59"));
        } catch (Exception e) {
            e.printStackTrace();
        }
        return c.getTime();
    }

    /**
     * 获取当前时间所在周的周一和周日的日期时间
     *
     * @return
     */
    public static Map<String, Date> getWeekDate() {
        Map<String, Date> map = new HashMap();
        Calendar cal = Calendar.getInstance();
        // 设置一个星期的第一天，按中国的习惯一个星期的第一天是星期一
        cal.setFirstDayOfWeek(Calendar.MONDAY);
        // 获得当前日期是一个星期的第几天
        int dayWeek = cal.get(Calendar.DAY_OF_WEEK);
        if (dayWeek == 1) {
            dayWeek = 8;
        }

        cal.add(Calendar.DATE, cal.getFirstDayOfWeek() - dayWeek);// 根据日历的规则，给当前日期减去星期几与一个星期第一天的差值
        Date mondayDate = cal.getTime();

        cal.add(Calendar.DATE, 4 + cal.getFirstDayOfWeek());
        Date sundayDate = cal.getTime();

        map.put("mondayDate", mondayDate);
        map.put("sundayDate", sundayDate);
        return map;
    }


    private static String[] parsePatterns = {
            "yyyy-MM-dd", "yyyy-MM-dd HH:mm:ss", "yyyy-MM-dd HH:mm", "yyyy-MM",
            "yyyy/MM/dd", "yyyy/MM/dd HH:mm:ss", "yyyy/MM/dd HH:mm", "yyyy/MM",
            "yyyy.MM.dd", "yyyy.MM.dd HH:mm:ss", "yyyy.MM.dd HH:mm", "yyyy.MM"};

    /**
     * 获取当前Date型日期
     *
     * @return Date() 当前日期
     */
    public static Date getNowDate() {
        return new Date();
    }

    /**
     * 间隔单位为小时
     *
     * @param offset
     * @return
     */
    public static Date getNowDate(int offset) {
        Date date = new Date();
        return new Date(date.getTime() + 1000L * 60 * 60 * offset);
    }


    /**
     * 获取当前日期, 默认格式为yyyy-MM-dd
     *
     * @return String
     */
    public static String getDate() {
        return dateTimeNow(YYYY_MM_DD);
    }

    public static String getYearAfterTwo() {
        return new SimpleDateFormat("yy", Locale.CHINESE).format(new Date());
    }

    public static String getYear() {
        return dateTimeNow(YYYY);
    }

    public static String getDateByFormat(String format) {
        return dateTimeNow(format);
    }

    public static String getDate2() {
        return dateTimeNow(YYYYMMDD2);
    }

    public static final String getTime() {
        return dateTimeNow(YYYY_MM_DD_HH_MM_SS);
    }

    public static final String dateTimeNow() {
        return dateTimeNow(YYYYMMDDHHMMSS);
    }

    public static final String dateTimeNow(final String format) {
        return parseDateToStr(format, new Date());
    }

    public static final String dateTime(final Date date) {
        return parseDateToStr(YYYY_MM_DD, date);
    }

    public static final String parseDateToStr(final String format, final Date date) {
        return new SimpleDateFormat(format).format(date);
    }

    public static final Date dateTime(final String format, final String ts) {
        try {
            return new SimpleDateFormat(format).parse(ts);
        } catch (ParseException e) {
            throw new RuntimeException(e);
        }
    }

    /**
     * 日期路径 即年/月/日 如2018/08/08
     */
    public static final String datePath() {
        Date now = new Date();
        return DateFormatUtils.format(now, "yyyy/MM/dd");
    }

    /**
     * 日期路径 即年/月/日 如20180808
     */
    public static final String dateTime() {
        Date now = new Date();
        return DateFormatUtils.format(now, "yyyyMMdd");
    }

    /**
     * 日期型字符串转化为日期 格式
     */
    public static Date parseDate(Object str) {
        if (str == null) {
            return null;
        }
        try {
            return parseDate(str.toString(), parsePatterns);
        } catch (ParseException e) {
            return null;
        }
    }

    public static String getDateTimeString1(Date date) {
        if (date == null) {
            return null;
        }
        return getDateTimeString(DATE_FORMAT_STRING1, date);
    }

    public static String getDateTimeString2(Date date) {
        if (date == null) {
            return null;
        }
        return getDateTimeString(DATE_FORMAT_DAY, date);
    }

    public static String getDateTimeString(String dateTimeFormat, Date date) {
        SimpleDateFormat format = new SimpleDateFormat(dateTimeFormat);
        return format.format(date);
    }

    public static String getSparkTime(Date date) {
        SimpleDateFormat sdf8 = new SimpleDateFormat(ES_TIME_FORMAT);
        sdf8.setTimeZone(TimeZone.getTimeZone("GMT8:00"));
        return sdf8.format(date);
    }

    public static String getSparkTime1(Date date) {
        return getSparkTime(minusMinutes(date, 0));
    }

    /**
     * 获取服务器启动时间
     */
    public static Date getServerStartDate() {
        long time = ManagementFactory.getRuntimeMXBean().getStartTime();
        return new Date(time);
    }

    /**
     * 计算两个时间差
     *
     * @param endDate 结束时间
     * @param nowDate 开始时间
     */
    public static String getDatePoor(Date endDate, Date nowDate) {
        if (nowDate == null) {
            return "";
        }
        // 获得两个时间的毫秒时间差异
        long diff = endDate.getTime() - nowDate.getTime();
        return getUsedTime(diff / 1000);
    }

    /**
     * 转换时间格式
     *
     * @param second 秒数
     * @return String
     */
    public static String getUsedTime(Long second) {
        if(Objects.isNull(second)){
            return "";
        }
        //获取天
        long days = second / 86400;
        second = second % 86400;
        //获取小时
        long hours = second / 3600;
        second = second % 3600;
        //获取分
        long minutes = second / 60;
        // 获取秒
        long sec = second % 60;
        StringBuilder builder = new StringBuilder();
        if (days > 0) {
            builder.append(days).append("天");
        }
        if (days > 0 || hours > 0) {
            builder.append(hours).append("小时");
        }
        if (days > 0 || hours > 0 || minutes > 0) {
            builder.append(minutes).append("分钟");
        }
        if(days > 0 || hours > 0 || minutes > 0 || sec > 0){
            builder.append(sec).append("秒");
        }
        if (builder.length() > 0) {
            return builder.toString();
        } else {
            return "";
        }
    }

    /**
     * 计算两个时间差(天数)
     */
    public static long getDayPoor(Date endDate, Date nowDate) {
        if (nowDate == null) {
            return 0;
        }
        long nd = 1000 * 24 * 60 * 60;
        // 获得两个时间的毫秒时间差异
        long diff = endDate.getTime() - nowDate.getTime();
        // 计算差多少天
        long day = diff / nd;
        return day;
    }

    /**
     * 计算两个时间差(秒数)
     *
     * @param endDate 结束时间
     * @param nowDate 开始时间
     * @return 秒
     */
    public static long getSecondPoor(Date endDate, Date nowDate) {
        if (nowDate == null) {
            return 0;
        }
        // 获得两个时间的毫秒时间差异
        long diff = endDate.getTime() - nowDate.getTime();
        // 计算差多少秒
        return diff / 1000;
    }

    public static String[] formatTimeRange(Date[] timeRanges) {
        String[] times = new String[2];
        SimpleDateFormat sdf8 = new SimpleDateFormat(ES_TIME_FORMAT);
        sdf8.setTimeZone(TimeZone.getTimeZone("GMT+8:00"));
        times[0] = sdf8.format(timeRanges[0]);
        times[1] = sdf8.format(timeRanges[1]);
        return times;
    }

    public static String formatDateTime(Date date, String pattern) {
        if (date == null) {
            return null;
        }
        SimpleDateFormat format = new SimpleDateFormat(pattern);
        return format.format(date);

    }

    public static Date parseDateTime(String dateTimeFormat, String date) {
        SimpleDateFormat format = new SimpleDateFormat(dateTimeFormat);
        try {
            return format.parse(date);
        } catch (ParseException e) {
        }
        return new Date();
    }

    public static Date parseDateTimeX(String date, String dateTimeFormat) {
        SimpleDateFormat format = new SimpleDateFormat(dateTimeFormat);
        try {
            return format.parse(date);
        } catch (ParseException e) {
            logger.error(e.getMessage(), e);
        }
        return null;
    }

    public static String getDateTimeString(Date date) {
        SimpleDateFormat format = new SimpleDateFormat(DATE_TIME_FORMAT_STRING1);
        return format.format(date);
    }

    public static Set<String> findDates(String start_time, String end_time) {
        Set<String> data = new HashSet<>();
        try {
            SimpleDateFormat df = new SimpleDateFormat("yyyy-MM-dd");
            Date start = df.parse(start_time);
            Date end = df.parse(end_time);
            Calendar tempStart = Calendar.getInstance();
            tempStart.setTime(start);
            tempStart.add(Calendar.DAY_OF_YEAR, 1);
            Calendar tempEnd = Calendar.getInstance();
            tempEnd.setTime(end);
            while (tempStart.before(tempEnd)) {
                data.add(df.format(tempStart.getTime()));
                tempStart.add(Calendar.DAY_OF_YEAR, 1);
            }
            data.add(df.format(end));
            return data;
        } catch (Exception e) {

        }
        return data;
    }

    public static String getDay(int day) {
        Date date = new Date();
        if (day != 0) {
            date.setDate(date.getDate() + day);
        }
        return new SimpleDateFormat("yyyy-MM-dd").format(date);
    }

    public static String getPlusDay(Date date, int day) {
        SimpleDateFormat f = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
        Date d = new Date(date.getTime() + day * 24 * 3600 * 1000);
        return f.format(d);
    }

    public static String getDate1() {
        return dateTimeNow(YYYYMMDD);
    }

    public static String minusMinutes2021(Date date, Integer minutes) {
        Date afterDate = new Date(date.getTime() - 60000 * minutes);
        SimpleDateFormat sdf8 = new SimpleDateFormat(ES_TIME_FORMAT1);
        return sdf8.format(afterDate);
    }

    public static String[] getTimeRangeBy1Hour() {
        String[] times = new String[2];
        Calendar calendar = Calendar.getInstance();
        SimpleDateFormat sdf8 = new SimpleDateFormat(ES_TIME_FORMAT);
        sdf8.setTimeZone(TimeZone.getTimeZone("GMT+8:00"));
        calendar.setTime(new Date());
        calendar.set(Calendar.SECOND, 0);
        times[0] = sdf8.format(calendar.getTime());
        times[1] = sdf8.format(new Date(calendar.getTime().getTime() - 1000 * 60 * 60));
        return times;
    }

    public static String[] getTimeRangeBy10Min() {
        String[] times = new String[2];
        Calendar calendar = Calendar.getInstance();
        SimpleDateFormat sdf8 = new SimpleDateFormat(ES_TIME_FORMAT);
        sdf8.setTimeZone(TimeZone.getTimeZone("GMT+8:00"));
        calendar.setTime(new Date());
        calendar.set(Calendar.SECOND, 0);
        times[0] = sdf8.format(calendar.getTime());
        times[1] = sdf8.format(new Date(calendar.getTime().getTime() - 1000 * 60 * 10));
        return times;
    }

    public static List<String[]> resolveTimeByDay(int day) {
        List<String[]> timeRangeList = new ArrayList<>();
        Calendar calendar = Calendar.getInstance();
        SimpleDateFormat sdf8 = new SimpleDateFormat(ES_TIME_FORMAT);
        sdf8.setTimeZone(TimeZone.getTimeZone("GMT+8:00"));
        SimpleDateFormat sdf = new SimpleDateFormat(DATE_FORMAT_HOUR_MINUTE);
        calendar.setTime(new Date());
        calendar.add(Calendar.DAY_OF_YEAR, 1);
        calendar.set(Calendar.HOUR_OF_DAY, 0);
        calendar.set(Calendar.MINUTE, 0);
        calendar.set(Calendar.SECOND, 0);
        for (int i = 0; i < 4 * day; i++) {
            String[] times = new String[4];
            calendar.add(Calendar.HOUR_OF_DAY, -(i * 6));

            times[0] = sdf8.format(calendar.getTime());
            times[2] = sdf.format(calendar.getTime());
            calendar.add(Calendar.HOUR_OF_DAY, -6);
            if (calendar.getTime().after(new Date())) {
                continue;
            }
            times[1] = sdf8.format(calendar.getTime());
            times[3] = sdf.format(calendar.getTime());
            timeRangeList.add(times);
            calendar.setTime(new Date());
            calendar.add(Calendar.DAY_OF_YEAR, 1);
            calendar.set(Calendar.HOUR_OF_DAY, 0);
            calendar.set(Calendar.MINUTE, 0);
            calendar.set(Calendar.SECOND, 0);
        }
        return timeRangeList;
    }

    public static List<String[]> resolveTimeByHw() {
        List<String[]> timeRangeList = new ArrayList<>();
        SimpleDateFormat sdf8 = new SimpleDateFormat(ES_TIME_FORMAT);
        sdf8.setTimeZone(TimeZone.getTimeZone("GMT+8:00"));
        SimpleDateFormat sdf = new SimpleDateFormat(DATE_FORMAT_HOUR_MINUTE);
        LocalDateTime startTime = LocalDateTime.of(2020, 9, 11, 0, 0, 0);
        LocalDateTime endTime = LocalDateTime.of(2020, 9, 24, 23, 59, 50);
        ZoneId zone = ZoneId.systemDefault();
        Instant instant = startTime.atZone(zone).toInstant();
        Instant instant2 = endTime.atZone(zone).toInstant();
        Calendar calendar1 = Calendar.getInstance();
        calendar1.setTime(Date.from(instant));
        Calendar calendar2 = Calendar.getInstance();
        calendar2.setTime(Date.from(instant2));
        while (calendar1.getTime().before(calendar2.getTime())) {

            for (int i = 0; i < 4; i++) {
                String[] times = new String[4];
                calendar1.add(Calendar.HOUR_OF_DAY, i * 6);
                times[1] = sdf8.format(calendar1.getTime());
                times[3] = sdf.format(calendar1.getTime());
                if (calendar1.getTime().after(new Date())) {
                    continue;
                }
                calendar1.add(Calendar.HOUR_OF_DAY, 6);
                times[0] = sdf8.format(calendar1.getTime());
                times[2] = sdf.format(calendar1.getTime());
                timeRangeList.add(times);
                calendar1.set(Calendar.HOUR_OF_DAY, 0);
                calendar1.set(Calendar.MINUTE, 0);
                calendar1.set(Calendar.SECOND, 0);
            }
        }

        return timeRangeList;
    }

    public static String[] getTimeRangeByHw() {
        String[] times = new String[2];
        Calendar calendar = Calendar.getInstance();
        SimpleDateFormat sdf8 = new SimpleDateFormat(ES_TIME_FORMAT);
        sdf8.setTimeZone(TimeZone.getTimeZone("GMT+8:00"));
        LocalDateTime startTime = LocalDateTime.of(2020, 9, 11, 0, 0, 0);
        LocalDateTime endTime = LocalDateTime.of(2020, 9, 24, 23, 59, 50);
        ZoneId zone = ZoneId.systemDefault();
        Instant instant = startTime.atZone(zone).toInstant();
        Instant instant2 = endTime.atZone(zone).toInstant();
        Calendar calendar1 = Calendar.getInstance();
        calendar1.setTime(Date.from(instant));
        Calendar calendar2 = Calendar.getInstance();
        calendar2.setTime(Date.from(instant2));
        times[0] = sdf8.format(calendar2.getTime());
        times[1] = sdf8.format(calendar1.getTime());
        return times;
    }

    public static Date parseSparkTime3(String logTime) {
        SimpleDateFormat format = new SimpleDateFormat(DATE_FORMAT_STRING1);
        try {
            format.setTimeZone(TimeZone.getTimeZone("GMT+8:00"));
            if (logTime.indexOf("+0800") != -1 || logTime.indexOf("+08:00") != -1) {
                logTime = logTime.substring(0, logTime.indexOf("."));
                logTime = logTime.replace("T", " ");
            }
            return format.parse(logTime);
        } catch (ParseException e) {
            e.printStackTrace();
        }
        return new Date();
    }

    public static String getCurrentDayFormat5() {
        SimpleDateFormat sdf8 = new SimpleDateFormat(DATE_FORMAT_STRING5);
        return sdf8.format(new Date());
    }

    /**
     * 比较两个时间的差值
     *
     * @param startTime
     * @param endTime
     * @param format
     * @return
     */
    public static long getCompareForStringDate(String startTime, String endTime, String format) {
        try {
            SimpleDateFormat f = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
            long smallTime = f.parse(startTime).getTime();
            long bigTime = f.parse(endTime).getTime();
            return (bigTime - smallTime) / 1000;
        } catch (Exception e) {
            return 0l;
        }
    }

    /**
     * 转化日期
     *
     * @param str
     * @return
     */
    public static Date parse(String str) {
        String pattern = "EEE MMM dd HH:mm:ss zzz yyyy";
        if (str == null) {
            return null;
        }
        try {
            return new SimpleDateFormat(pattern, Locale.US).parse(str);
        } catch (ParseException e) {
            e.printStackTrace();
        }
        return null;
    }


    /**
     * 转化日期
     *
     * @param str
     * @return
     */
    public static Date parseFormat(String str) throws Exception {
        String pattern = "EEE MMM dd HH:mm:ss zzz yyyy";
        if (str == null) {
            return null;
        }
        return new SimpleDateFormat(pattern, Locale.US).parse(str);

    }

    public static Date parseSparkTime(String logTime) {
        SimpleDateFormat format = new SimpleDateFormat(ES_TIME_FORMAT1);
        try {
            format.setTimeZone(TimeZone.getTimeZone("GMT+8:00"));
            return format.parse(logTime);
        } catch (ParseException e) {
            e.printStackTrace();
        }
        return new Date();
    }

    public static String[] parseSparkTimeRange(String[] timeRanges) {
        String[] newTimes = new String[2];
        newTimes[0] = formatDateTime(parseSparkTime(timeRanges[0]), "yyyy-MM-dd HH:mm:ss");
        newTimes[1] = formatDateTime(parseSparkTime(timeRanges[1]), "yyyy-MM-dd HH:mm:ss");
        return newTimes;
    }

    private static DateUtils instance = new DateUtils();

    public static String[] resolveTimeIntevalsByType(TimeUnit timeUnit, Date date, Integer taskInteval) throws InvocationTargetException, IllegalAccessException {
        Method[] methods = DateUtils.class.getMethods();
        String[] timeUnits = new String[2];
        if (timeUnit != null) {
            String funcName = timeUnit.getFunc();
            for (Method method : methods) {
                Object[] objectList = new Object[2];
                if (funcName.equalsIgnoreCase(method.getName())) {
                    objectList[0] = date;
                    objectList[1] = taskInteval;
                    timeUnits = (String[]) method.invoke(instance, objectList);
                }
            }
        }
        return timeUnits;
    }

    /**
     * 转换sparkTime的格式
     * 转换前：2021-10-21T16:02:34.183+0800
     * 转换后：2021-10-21 16:02:34
     *
     * @param logTime
     * @return
     */
    public static String parseSparkTimeStr(String logTime) {
        return formatDateTime(parseSparkTime(logTime), YYYY_MM_DD_HH_MM_SS);
    }


    /**
     * 获取现在时间
     */
    public static String getTimeMS() {
        String DATE_TIME_FORMAT_STRING3 = "yyyy-MM-dd HH:mm:ss:SSS";
        TimeZone tz = TimeZone.getTimeZone("Asia/Shanghai");
        TimeZone.setDefault(tz);
        Date date = new Date();
        SimpleDateFormat sdf8 = new SimpleDateFormat(DATE_TIME_FORMAT_STRING3);
        return sdf8.format(date);
    }

    public static String getSparkTimeX(Date endTime) {
        return getSparkTime(minusMinutes(endTime, 480));
    }

    public static Date minusMinutes(Date date, Integer minutes) {
        Date afterDate = new Date(date.getTime() - 60000 * minutes);
        return afterDate;
    }

    public static String getSparkTimeNew(Date endTime) {
        return getSparkTimeNewTwo(minusMinutes(endTime, 0));
    }

    public static String getSparkTimeNewTwo(Date date) {
        SimpleDateFormat sdf8 = new SimpleDateFormat(ES_TIME_FORMAT);
        sdf8.setTimeZone(TimeZone.getTimeZone("GMT+8:00"));
        return sdf8.format(date);
    }

    public static String getSparkTimeNewThree(Date date) {
        /*SimpleDateFormat sdf8 = new SimpleDateFormat(ES_TIME_FORMAT);
       // sdf8.setTimeZone(TimeZone.getTimeZone("GMT+0:00"));
        return sdf8.format(date);*/
        SimpleDateFormat sdf8 = new SimpleDateFormat(ES_TIME_FORMAT);
        sdf8.setTimeZone(TimeZone.getTimeZone("GMT8:00"));
        return sdf8.format(date);
    }

    public static String getAggTime(String time) throws ParseException {
        SimpleDateFormat sdf = new SimpleDateFormat(DATE_FORMAT_STRING1);
        Date parse = sdf.parse(time);
        sdf = new SimpleDateFormat(ES_TIME_FORMAT2);
        return sdf.format(parse);
    }
    /**
     * 最近1周获取起止日期
     *
     * @param date   需要参照的日期
     * @param option 0 开始日期；1 结束日期
     * @param k      0 包含本周 1 不包含本周
     * @return String
     */
    private static String getFromToDate(Date date, int option, int k) {
        SimpleDateFormat sdf = new SimpleDateFormat(YYYY_MM_DD);
        Calendar calendar = Calendar.getInstance();
        calendar.setTime(date);
        int dayOfWeek = calendar.get(Calendar.DAY_OF_WEEK) - 1;
        //判断是否为星期天,外国定义星期天是他们的第一天
        if (dayOfWeek <= 0) {
            dayOfWeek = 7;
        }
        int offset = 0 == option ? 1 - dayOfWeek : 7 - dayOfWeek;
        int amount = 0 == option ? offset - k * 7 : offset - k * 7;
        calendar.add(Calendar.DATE, amount);
        String format = null;
        try {
            format = sdf.format(calendar.getTime());
        } catch (Exception e) {
            e.printStackTrace();
        }
        return format;
    }

    /**
     * 根据当前日期获得上周的日期区间（上周周一和周日日期）
     *
     * @return String
     */
    public static String[] getLastWeekTimeInterval(Date date) {
        String beginDate = getFromToDate(date, 0, 1);
        String endDate = getFromToDate(date, 1, 1);
        String[] range = new String[2];
        range[0] = beginDate;
        range[1] = endDate;
        return range;
    }

    /**
     * 获取date的前offest天的日期
     *
     * @param offest
     * @return
     */
    public static String getFromHours(Date date, int offest, String format) {
        SimpleDateFormat sdf = new SimpleDateFormat(format);
        Calendar c = Calendar.getInstance();
        c.setTime(date);
        c.add(Calendar.HOUR, offest);
        Date d = c.getTime();
        String firstDay = sdf.format(d);
        return firstDay;
    }

    public static void main(String[] args) {
        System.out.println(getFromHours(new Date(), -1, "yyyy-MM-dd'T'HH:mm:ss.SSSZ"));
    }

    /**
     * 获取date的前offest天的日期
     *
     * @param offest
     * @return
     */
    public static String getFromDays(Date date, int offest, String format) {
        SimpleDateFormat sdf = new SimpleDateFormat(format);
        Calendar c = Calendar.getInstance();
        c.setTime(date);
        c.add(Calendar.DAY_OF_YEAR, offest);
        Date d = c.getTime();
        String firstDay = sdf.format(d);
        System.out.println(firstDay);
        return firstDay;
    }


    /**
     * 获取date的前offest天的日期
     *
     * @param offest
     * @return
     */
    public static String getFromWeek(Date date, int offest, String format) {
        SimpleDateFormat sdf = new SimpleDateFormat(format);
        Calendar c = Calendar.getInstance();
        c.setTime(date);
        c.add(Calendar.DATE, offest);
        Date d = c.getTime();
        String firstDay = sdf.format(d);
        return firstDay;
    }

    /**
     * 获取date的前offest天的日期
     *
     * @param offest
     * @return
     */
    public static String getFromMonth(Date date, int offest, String format) {
        SimpleDateFormat sdf = new SimpleDateFormat(format);
        Calendar c = Calendar.getInstance();
        c.setTime(date);
        c.add(Calendar.MONTH, offest);
        Date d = c.getTime();
        String firstDay = sdf.format(d);
        System.out.println(firstDay);
        return firstDay;
    }

    /**
     * 获取上个月的第一天
     *
     * @return
     */
    public static String getLastMonthFirstDay(int offest) {
        SimpleDateFormat sdf = new SimpleDateFormat(DATE_FORMAT_DAY);
        Calendar calendar = Calendar.getInstance();
        calendar.add(Calendar.MONTH, offest);
        calendar.set(Calendar.DAY_OF_MONTH, 1);
        return sdf.format(calendar.getTime());
    }

    /**
     * 获取上个月的最后一天
     *
     * @return
     */
    public static String getLastMonthLastDay(int offest) {
        SimpleDateFormat sdf = new SimpleDateFormat(DATE_FORMAT_DAY);
        Calendar calendar = Calendar.getInstance();
        int month = calendar.get(Calendar.MONTH);
        calendar.set(Calendar.MONTH, month + offest);
        calendar.set(Calendar.DAY_OF_MONTH, calendar.getActualMaximum(Calendar.DAY_OF_MONTH));
        return sdf.format(calendar.getTime());
    }

    /**
     * 判断日期是否为当月一号
     *
     * @param date
     * @return
     */
    public static boolean isFirstDayOfMonth(Date date) {
        Calendar calendar = Calendar.getInstance();
        calendar.setTime(date);
        calendar.set(Calendar.DATE, calendar.get(Calendar.DATE) + 1);
        if (calendar.get(Calendar.DAY_OF_MONTH) == 2) {
            return true;
        } else {
            return false;
        }
    }

    public static List<String> getDatesByDay(Date start, Date end) {
        List<String> days = new ArrayList<String>();
        try {
            SimpleDateFormat df = new SimpleDateFormat(YYYY_MM_DD);
            start = df.parse(parseDateToStr(YYYY_MM_DD, start));
            end = df.parse(parseDateToStr(YYYY_MM_DD, end));
            Calendar tempStart = Calendar.getInstance();
            tempStart.setTime(start);
            Calendar tempEnd = Calendar.getInstance();
            tempEnd.setTime(end);
            tempEnd.add(Calendar.DATE, +1);// 日期加1(包含结束)
            while (tempStart.before(tempEnd)) {
                days.add(df.format(tempStart.getTime()));
                tempStart.add(Calendar.DAY_OF_YEAR, 1);
            }

        } catch (ParseException e) {
            e.printStackTrace();
        }

        return days;
    }

    public static Date parseDateTime(String date) {
        SimpleDateFormat format = new SimpleDateFormat(DATE_TIME_FORMAT_STRING1);
        try {
            return format.parse(date);
        } catch (ParseException e) {
        }
        return new Date();
    }

    public static String UTCToCSTAndCheck(String UTCStr) {
        if (StringUtils.isBlank(UTCStr)) {
            return null;
        }
        Date date = null;
        SimpleDateFormat sdf = new SimpleDateFormat(ES_TIME_FORMAT1);
        Calendar calendar = Calendar.getInstance();
        if (UTCStr.contains("T")) {
            try {
                if (UTCStr.contains("+0800")) {
                    UTCStr = UTCStr.replace("+0800", "Z");
                }
                date = sdf.parse(UTCStr);
                calendar.setTime(date);

                SimpleDateFormat sdf2 = new SimpleDateFormat(DATE_FORMAT_STRING1);
                return sdf2.format(calendar.getTime());
            } catch (Exception e) {
                logger.error(e.getMessage(), e);
            }
        }
        return UTCStr;
    }

    public static String formatDateByFormat(String date, String dateFormat) {
        SimpleDateFormat format = new SimpleDateFormat(dateFormat);
        try {
            return format.format(format.parse(date));
        } catch (ParseException e) {
        }
        return date;
    }

    public static String[] resolveTimeRangeByType(String proveTimeUnit, int proveTime, Date date) {
        if ("1".equals(proveTimeUnit)) {
            return resolveTimeByMinusMinutes(date, proveTime);
        } else if ("2".equals(proveTimeUnit)) {
            return resolveTimeByMinusHours(date, proveTime);
        } else if ("3".equals(proveTimeUnit)) {
            return resolveTimeByMinusDays(date, proveTime);
        }
        return null;
    }

    public static String[] resolveTimeByMinusMinutes(Date date, Integer minutes) {
        String[] times = new String[2];
        Date afterDate = new Date(date.getTime() - 60000 * minutes);
        SimpleDateFormat sdf8 = new SimpleDateFormat(ES_TIME_FORMAT);
        sdf8.setTimeZone(TimeZone.getTimeZone("GMT+8:00"));
        times[0] = sdf8.format(date);
        times[1] = sdf8.format(afterDate);
        return times;
    }

    public static String[] resolveTimeByMinusHours(Date date, Integer hours) {
        String[] times = new String[2];
        Date afterDate = new Date(date.getTime() - 60000 * 60 * hours);
        SimpleDateFormat sdf8 = new SimpleDateFormat(ES_TIME_FORMAT);
        sdf8.setTimeZone(TimeZone.getTimeZone("GMT+8:00"));
        times[0] = sdf8.format(date);
        times[1] = sdf8.format(afterDate);
        return times;
    }

    public static String[] resolveTimeByMinusDays(Date date, Integer days) {
        String[] times = new String[2];
        Date afterDate = new Date(date.getTime() - 60000 * 60 * 24 * days);
        SimpleDateFormat sdf8 = new SimpleDateFormat(ES_TIME_FORMAT);
        sdf8.setTimeZone(TimeZone.getTimeZone("GMT+8:00"));
        times[0] = sdf8.format(date);
        times[1] = sdf8.format(afterDate);
        return times;
    }


    /**
     * 获取两个时间相差的天数
     *
     * @param startTime
     * @param endTime
     * @return
     */
    public static int getIntervalDays(Date startTime, Date endTime) {
        if (startTime != null && endTime != null) {
            long et = endTime.getTime();
            long st = startTime.getTime();
            long l = et - st;
            long dayCount = l / (24 * 60 * 60 * 1000);
            return new Integer((int) (dayCount));
        }
        return -10;
    }

    /**
     * 获取两个时间相差的小时
     *
     * @param startTime
     * @param endTime
     * @return
     */
    public static int getIntervalHours(Date startTime, Date endTime) {
        if (startTime != null && endTime != null) {
            long et = endTime.getTime();
            long st = startTime.getTime();
            long l = et - st;
            long dayCount = l / (60 * 60 * 1000);
            return new Integer((int) (dayCount));
        }
        return -10;
    }

    /**
     * 获取两个时间相差的分钟
     *
     * @param startTime
     * @param endTime
     * @return
     */
    public static int getIntervalMin(Date startTime, Date endTime) {
        if (startTime != null && endTime != null) {
            long et = endTime.getTime();
            long st = startTime.getTime();
            long l = et - st;
            long dayCount = l / (60 * 1000);
            return new Integer((int) (dayCount + 1));
        }
        return -10;
    }

    /**
     * 获取两个时间相差的小时
     *
     * @param startTime
     * @param endTime
     * @return
     */
    public static int getIntervalSec(Date startTime, Date endTime) {
        if (startTime != null && endTime != null) {
            long et = endTime.getTime();
            long st = startTime.getTime();
            long l = et - st;
            long dayCount = l / (1000);
            return new Integer((int) (dayCount + 1));
        }
        return -10;
    }

    public static Date resolveDateByUnit(Date date, Integer minutes, String type) {
        Map<String, Date> map = new HashMap<>();
        int value = 0;
        if (type.equals("1")) {
            value = 60000 * minutes;
        } else if (type.equals("2")) {
            value = 60000 * 60 * minutes;
        } else if (type.equals("3")) {
            value = 60000 * 60 * 24 * minutes;
        }
        Date afterDate = new Date(date.getTime() - value);
        return afterDate;
    }


    /**
     * 获取当前月偏移量月份的最后一天
     * @param offest 当前月的偏移量
     * @return
     */
    public static Integer getMonthLastDay(int offest) {
        SimpleDateFormat sdf = new SimpleDateFormat(DATE_FORMAT_DAY);
        SimpleDateFormat sdf2 = new SimpleDateFormat(DD);
        Calendar calendar = Calendar.getInstance();
        int month = calendar.get(Calendar.MONTH);
        calendar.set(Calendar.MONTH, month + offest);
        calendar.set(Calendar.DAY_OF_MONTH, calendar.getActualMaximum(Calendar.DAY_OF_MONTH));
        return Integer.parseInt(sdf2.format(calendar.getTime()));
    }

    public static String getDateX(int day) {
        Date date = new Date();
        if (day != 0) {
            date.setDate(date.getDate() + day);
        }
        return new SimpleDateFormat("yyyy-MM-dd").format(date);
    }

    public static final String DATE_TIME_FORMAT_STRING2 = "yyyy-MM-dd HH:mm";

    /**
     * 格式化
     *
     * @param date 日志
     * @return yyyy-MM-dd HH:mm
     */
    public static String getDateTimeString3(Date date) {
        return getDateTimeString(DATE_TIME_FORMAT_STRING2, date);
    }

    public static String getWeekStr() {
        String[] weekDays = {"周日", "周一", "周二", "周三", "周四", "周五", "周六"};
        Calendar calendar = Calendar.getInstance();
        return weekDays[calendar.get(Calendar.DAY_OF_WEEK) - 1];
    }

    /**
     * 获取时间增加多少小时 返回格式 HH:mm
     * 传入时间 2023-04-05 10:55:24 增加2小时返回 12:00 增加23小时  返回 9:00
     *
     * @param date    时间
     * @param addHour 增加小时数量
     * @return String
     */
    public static String getHHMMDownByHour(Date date, int addHour) {
        Calendar calendar = Calendar.getInstance();
        SimpleDateFormat sdf = new SimpleDateFormat(DATE_FORMAT_MONTH_DAY);
        calendar.setTime(date);
        calendar.add(Calendar.HOUR_OF_DAY, +addHour);
        calendar.set(Calendar.MINUTE, 0);
        calendar.set(Calendar.SECOND, 0);
        return sdf.format(calendar.getTime());
    }

    /**
     * 获取date的前offest分钟的日期
     *
     * @param offest
     * @return
     */
    public static String getFromMin(Date date, int offest, String format) {
        SimpleDateFormat sdf = new SimpleDateFormat(format);
        Calendar c = Calendar.getInstance();
        c.setTime(date);
        c.add(Calendar.MINUTE, offest);
        Date d = c.getTime();
        String firstDay = sdf.format(d);
        return firstDay;

    }

    public static boolean isDate(String str) {
        boolean result = true;
        SimpleDateFormat format = new SimpleDateFormat(YYYY_MM_DD);
        try {
            format.setLenient(false);
            format.parse(str);
        } catch (Exception e) {
            result = false;
        }
        return result;

    }

    /**
     * 获取当前时间从0点到现在的时间区间
     * @return
     */
    public static Map<String, Date> getDay() {
        // 获取今天的零点时间
        Calendar calendar = Calendar.getInstance();
        calendar.set(Calendar.HOUR_OF_DAY, 0);
        calendar.set(Calendar.MINUTE, 0);
        calendar.set(Calendar.SECOND, 0);
        calendar.set(Calendar.MILLISECOND, 0);
        Date todayStart = calendar.getTime();

        // 获取当前时间
        Date now = new Date();
        Map<String, Date> map = new HashMap<>();
        map.put("startDate", todayStart);
        map.put("endDate", now);
        return map;
    }

    /**
     * 得到时间差
     *
     * @param one
     * @param two
     * @return
     */
    public static String getDistanceDateTime(Date one, Date two) {
        long day = 0;// 天数差
        long hour = 0;// 小时数差
        long min = 0;// 分钟数差
        long second = 0;// 秒数差
        long diff = 0;// 毫秒差
        String result = "";
        final Calendar c = Calendar.getInstance();
        c.setTimeZone(TimeZone.getTimeZone("GMT+8:00"));
        c.setTime(one);
        long time1 = one.getTime();
        long time2 = two.getTime();
        diff = time2 - time1;
        day = diff / (24 * 60 * 60 * 1000);
        hour = (diff / (60 * 60 * 1000) - day * 24);
        min = ((diff / (60 * 1000)) - day * 24 * 60 - hour * 60);
        second = diff / 1000;
        return "" + day + "天" + hour + "小时" + min + "分钟";
    }
}
