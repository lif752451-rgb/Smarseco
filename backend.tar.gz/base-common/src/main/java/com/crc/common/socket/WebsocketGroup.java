package com.crc.common.socket;

/**
 * websocketGroup常量类
 *
 * @author zhangbing
 */
public interface WebsocketGroup {

    /**
     * 消息分组字段
     */
    String SOCKET_GROUP_FIELD = "socketGroup";

    /**
     * 消息分组常量类， 通用分组
     */
    String COMMON_SOCKET_GROUP = "common";

    /**
     * 消息分组常量类， 新增告警通知
     */
    String ALARM_ADD_VIEW_SOCKET_GROUP = "add_alarm_view";
}
