package com.crc.common.constant.enums;

import lombok.Getter;

/**
 * 转码类型
 *
 * @Author fuzhuangzhi
 * @Date 2023/3/9 16:10
 * @Version 1.0
 **/
@Getter
public enum TransCodeEnum {

    /**
     * unicode
     */
    UNICODE("unicode"),

    /**
     * hex
     */
    HEX("hex"),;

    private String type;

    TransCodeEnum(String type) {
        this.type = type;
    }
}
