package com.crc.common.model.enums;

import com.crc.common.constant.Constants;
import org.apache.commons.lang3.StringUtils;

import java.util.Arrays;

/**
 * @Author shufengfeng
 * @Description 结果枚举
 * @DateTime 2021/9/3 10:43
 */
public enum ResultEnum {

    PASS("pass","通过"),
    FAIL("fail","不通过"),
    ;

    private String name;
    private String desc;

    ResultEnum(String name, String desc) {
        this.name = name;
        this.desc = desc;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getDesc() {
        return desc;
    }

    public void setDesc(String desc) {
        this.desc = desc;
    }

    public static String findDescByName(String name){
        if(StringUtils.isNotEmpty(name)){
            return Arrays.stream(ResultEnum.values()).filter(resultEnum -> resultEnum.getName().equals(name.toLowerCase())).findFirst().get().getDesc();
        }
        return Constants.BLANK_STR;
    }
}
