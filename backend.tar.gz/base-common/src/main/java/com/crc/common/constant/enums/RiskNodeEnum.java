package com.crc.common.constant.enums;

import cn.hutool.core.util.StrUtil;
import com.google.common.collect.Lists;
import lombok.AllArgsConstructor;
import lombok.Getter;

import java.util.Arrays;
import java.util.List;
import java.util.stream.Collectors;

import static com.crc.common.constant.Constants.Symbol.COMMA;

/**
 * 风险整改节点
 * 
 * @author zhangbing
 */
@Getter
@AllArgsConstructor
public enum RiskNodeEnum {

    /**
     * 创建节点
     */
    CREATE("create", "创建", "", "", ""),

    /**
     * 推送节点
     */
    PUSH("push", "推送", "1", "待推送", ""),

    /**
     * 分配节点
     */
    ALLOT("allot", "分配", "2", "待分配", "risk:loop:all:divide,risk:loop:wait:divide"),

    /**
     * 处置节点
     */
    DEAL("deal", "处置", "3", "待处置", "risk:loop:all:deal,risk:loop:wait:deal"),

    /**
     * 部门审核节点
     */
    DEPT_AUDIT("deptAudit", "部门审核", "4", "部门审核", "risk:loop:all:audit,risk:loop:wait:audit"),

    /**
     * 残余处置节点
     */
    REMNANT_DEAL("remnantDeal", "残余处置", "5", "残余风险", "risk:loop:all:remain,risk:loop:wait:remain"),

    /**
     * 整改验证节点
     */
    RECTIFY_VERIFY("rectifyVerify", "整改验证", "6", "整改验证", "risk:loop:all:verify,risk:loop:wait:verify"),

    /**
     * 归档节点
     */
    COMPLETE("complete", "归档", "7", "已关闭", "risk:loop:all:close"),;

    /**
     * nodeKey 节点key
     */
    private final String nodeKey;

    /**
     * nodeName 节点名称
     */
    private final String nodeLabel;

    /**
     * 工单状态（1.待推送 2.待分配 3.待处置 4.部门审核 5.残余风险 6.整改验证 7.已关闭）
     */
    private final String orderState;

    /**
     * 工单状态Label
     */
    private final String orderStateLabel;

    /**
     * 状态页签权限标识，多个用英文逗号分隔
     */
    private final String perms;

    /**
     * 通过菜单下的所有权限标识获取当前配置的工单状态
     * 
     * @param permissions 菜单下的权限标识集合
     * @return 配置的工单状态 一个状态未匹配到返回["-1"]
     */
    public static List<String> getOrderStatusList(List<String> permissions) {
        return Arrays.stream(values())
            .filter(stateEnum -> Arrays.stream(stateEnum.getPerms().split(COMMA)).anyMatch(permissions::contains))
            .map(RiskNodeEnum::getOrderState).collect(Collectors.collectingAndThen(Collectors.toList(),
                list -> list.isEmpty() ? Lists.newArrayList("-1") : list));
    }

    /**
     * 通过工单状态value获取label
     * @param value 工单状态value
     * @return 工单状态label
     */
    public static String getOrderStateLabelByValue(String value) {
        if (StrUtil.isEmpty(value)) {
            return null;
        }
        return Arrays.stream(values()).filter(stateEnum -> stateEnum.getOrderState().equals(value)).findFirst()
            .map(RiskNodeEnum::getOrderStateLabel).orElseGet(String::new);
    }

    /**
     * nodeKey获取节点枚举
     * 
     * @param nodeKey key
     * @return nodeEnum
     */
    public static RiskNodeEnum getNodeEnumByNodeKey(String nodeKey) {
        return Arrays.stream(values()).filter(node -> node.getNodeKey().equals(nodeKey)).findFirst().orElse(null);
    }

    /**
     * orderState获取节点枚举
     *
     * @param orderState key
     * @return nodeEnum
     */
    public static RiskNodeEnum getNodeEnumByOrderState(String orderState) {
        return Arrays.stream(values()).filter(node -> node.getOrderState().equals(orderState)).findFirst().orElse(null);
    }
}