package com.crc.common.model.request;

import lombok.Data;

/**
 * 转码实体
 *
 * @Author fuzhuangzhi
 * @Date 2023/3/9 16:04
 * @Version 1.0
 **/
@Data
public class TransCodeRequest {

    /**
     * 待转码类型 hex,unicode
     */
    private String type;

    /**
     * 待转码字符
     */
    private String str;
}
