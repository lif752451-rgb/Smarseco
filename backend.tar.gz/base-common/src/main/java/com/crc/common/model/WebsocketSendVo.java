package com.crc.common.model;

import com.alibaba.fastjson.annotation.JSONField;
import com.fasterxml.jackson.annotation.JsonFormat;
import lombok.Data;

import java.util.Date;

/**
 * WEBSOCKET推送消息
 */
@Data
public class WebsocketSendVo {

    /**
     * 业务标识
     */
    private String businessType;
    /**
     * 业务ID
     */
    private String businessId;
    /**
     * 消息文案
     */
    private String message;

    /**
     * 处理人ID
     */
    private String dealUserId;
    /**
     * 跳转链接
     */
    private String url;
    /**
     * 备注
     */
    private String remark;
    /**
     * 创建时间
     */
    @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss", timezone = "GMT+8")
    @JSONField(format = "yyyy-MM-dd HH:mm:ss")
    private Date createTime;
    /**
     * 更新时间
     */
    @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss", timezone = "GMT+8")
    @JSONField(format = "yyyy-MM-dd HH:mm:ss")
    private Date updateTime;
}
