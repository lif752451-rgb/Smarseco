package com.crc.common.model.enums;

/**
 * @Author shufengfeng
 * @Description 下载模板枚举
 * @DateTime 2021/9/15 16:35
 */
public enum DownloadTemplateEnum {

    /**
     * 用户信息导入模板
     */
    SYS_USER("用户信息导入模板","用户信息导入模板.xlsx"),

    /**
     * 用户信息导入错误详情
     */
    SYS_USER_ERROR("用户信息导入错误详情","用户信息导入错误详情.xlsx"),

    /**
     * 资产导入模板
     */
    ASSET("资产导入模板","资产导入模板.xlsx"),

    /**
     * 资产导入错误详情
     */
    ASSET_ERROR("资产导入错误详情","资产导入错误详情.xlsx"),

    /**
     * 软件许可证导入模板
     */
    ASSET_SOFTWARE_LICENSE("软件许可证导入模板","软件许可证导入模板.xlsx"),

    /**
     * 软件许可证错误详情
     */
    ASSET_SOFTWARE_LICENSE_ERROR("软件许可证错误详情","软件许可证错误详情.xlsx"),

    /**
     * 国资监管资产导入模板
     */
    INTERNET_ASSET("国资监管资产导入模板","国资监管资产导入模板.xlsx"),

    /**
     * 国资监管资产导入错误详情
     */
    INTERNET_ASSET_ERROR("国资监管资产导入错误详情","国资监管资产导入错误详情.xlsx"),

    /**
     * 网络安全报告模板
     */
    NETWORK_INFORMATION_SECURITY_OPERATION("网络安全报告模板","网络安全报告模板.docx"),
    /**
     * 网络安全报告模板
     */
    NETWORK_INFORMATION_SECURITY_OPERATION_NEW("安全工作月报模板V2.0","安全工作月报模板V2.0.docx"),

    /**
     * 重点关注问题导入模板
     */
    EVENT_ATTENTION("重点关注问题导入模板","重点关注问题导入模板.xlsx"),

    /**
     * 重点关注问题导入错误详情
     */
    EVENT_ATTENTION_ERROR("重点关注问题导入错误详情","重点关注问题导入错误详情.xlsx"),

    /**
     * 研判知识库导入模板
     */
    KNOWLEDGE_JUDGE("研判知识库导入模板", "研判知识库导入模板.xlsx"),

    /**
     * 研判知识库导入错误详情
     */
    KNOWLEDGE_JUDGE_ERROR("研判知识库导入错误详情", "研判知识库导入错误详情.xlsx"),

    /**
     * 处置建议库导入模板
     */
    KNOWLEDGE_ALARM_HANDLE("处置建议库导入模板", "处置建议库导入模板.xlsx"),

    /**
     * 处置建议库导入错误详情
     */
    KNOWLEDGE_ALARM_HANDLE_ERROR("处置建议库导入错误详情", "处置建议库导入错误详情.xlsx"),

    /**
     * 漏洞情报导入模板
     */
    VULN_INFORMATION("漏洞情报导入模板", "漏洞情报导入模板.xlsx"),

    /**
     * 漏洞情报导入错误详情
     */
    VULN_INFORMATION_ERROR("漏洞情报导入错误详情", "漏洞情报导入错误详情.xlsx"),

    /**
     * IOC情报导入模板
     */
    INTELLGENCE_IOC("IOC情报导入模板", "IOC情报导入模板.xlsx"),

    /**
     * IOC情报导入错误详情
     */
    INTELLGENCE_IOC_ERROR("IOC情报导入错误详情", "IOC情报导入错误详情.xlsx"),

    /**
     * 应用系统导入模板
     */
    APP_SYSTEM("应用系统导入模板", "应用系统导入模板.xlsx"),

    /**
     * 应用系统审批导入模板
     */
    APP_SYSTEM_APPROVE("在建信息系统管理", "在建信息系统管理.rar"),

    /**
     * 应用系统导入错误详情
     */
    APP_SYSTEM_ERROR("应用系统导入错误详情", "应用系统导入错误详情.xlsx"),

    /**
     * 漏洞信息导入模板
     */
    CLIENT_VULN("漏洞信息导入模板", "漏洞信息导入模板.xlsx"),

    /**
     * 漏洞信息导入错误详情
     */
    CLIENT_VULN_ERROR("漏洞信息导入错误详情", "漏洞信息导入错误详情.xlsx"),

    /**
     * SSP告警模型_通用模型
     */
    DEFINE_CURRENCY_MODEL_EXPORT_EXCEL("SSP告警模型_通用模型", "SSP告警模型_通用模型_下载模板.xlsx"),

    /**
     * SSP告警模型_自定义模型
     */
    DEFINE_MODEL_EXPORT_EXCEL("SSP告警模型_自定义模型", "SSP告警模型_自定义模型_下载模板.xlsx"),

    /**
     * 等保定级信息导入模板
     */
    EQUAL_GRADE("等保定级信息导入模板", "等保定级信息导入模板.xlsx"),

    /**
     * 等保定级信息导入错误详情
     */
    EQUAL_GRADE_ERROR("等保定级信息导入错误详情", "等保定级信息导入错误详情.xlsx"),

    /**
     * 等保定级信息导入模板
     */
    PENETRATION_TEST("渗透测试信息导入模板", "渗透测试信息导入模板.xlsx"),

    /**
     * 等保定级信息导入错误详情
     */
    PENETRATION_TEST_ERROR("渗透测试信息导入错误详情", "渗透测试信息导入错误详情.xlsx"),

    /**
     * 巡检项导入模板
     */
    PATROL_ITEM("巡检项导入模板.xlsx", "巡检项导入模板.xlsx"),

    /**
     * 巡检项导入错误详情
     */
    PATROL_ITEM_ERROR("巡检项导入错误详情", "巡检项导入错误详情.xlsx"),

    /**
     * 主机漏洞导入模板
     */
    VULN_HOST("主机漏洞导入模板.xlsx", "主机漏洞导入模板.xlsx"),

    /**
     * WEB漏洞导入模板
     */
    VULN_WEB("WEB漏洞导入模板.xlsx", "WEB漏洞导入模板.xlsx"),

    /**
     * 弱口令漏洞导入模板
     */
    VULN_WEAK_PASSWORD("弱口令漏洞导入模板.xlsx", "弱口令漏洞导入模板.xlsx"),

    /**
     * 主机漏洞导入错误详情
     */
    VULN_HOST_ERROR("主机漏洞导入错误详情", "主机漏洞导入错误详情.xlsx"),

    /**
     * WEB漏洞导入错误详情
     */
    VULN_WEB_ERROR("WEB漏洞导入错误详情", "WEB漏洞导入错误详情.xlsx"),

    /**
     * 弱口令漏洞导入错误详情
     */
    WEAK_PASSWORD_ERROR("弱口令漏洞导入错误详情", "弱口令漏洞导入错误详情.xlsx"),

    /**
     * 资产组件导入模板(单个资产)
     */
    ASSET_SOFTWARE_SINGLE_EXCEL("资产组件导入模板(单个资产)", "资产组件导入模板(单个资产).xlsx"),

    /**
     * 资产组件导入模板(批量多个资产)
     */
    ASSET_SOFTWARE_BATCH_EXCEL("资产组件导入模板(批量多个资产)", "资产组件导入模板(批量多个资产).xlsx"),

    /**
     * 资产组件导入模板(单个资产)错误详情
     */
    ASSET_SOFTWARE_SINGLE_ERROR_EXCEL("资产组件导入模板(单个资产)错误详情", "资产组件导入模板(单个资产)错误详情.xlsx"),

    /**
     * 资产组件导入模板(批量多个资产)错误详情
     */
    ASSET_SOFTWARE_BATCH_ERROR_EXCEL("资产组件导入模板(批量多个资产)错误详情", "资产组件导入模板(批量多个资产)错误详情.xlsx"),

    /**
     * 漏洞修复案例导入模板
     */
    VUL_KONWLEDGE("漏洞修复案例导入模板", "漏洞修复案例导入模板.xlsx"),

    /**
     * 漏洞修复案例导入错误详情
     */
    VUL_KONWLEDGE_ERROR("漏洞修复案例导入错误详情", "漏洞修复案例导入错误详情.xlsx"),

    /**
     * 域名信息导入模板
     */
    ASSET_ASM_DOMAIN_EXCEL("域名信息导入模板", "域名信息导入模板.xlsx"),

    /**
     * 域名信息导入错误详情
     */
    ASSET_ASM_DOMAIN_EXCEL_ERROR("域名信息导入错误详情", "域名信息导入错误详情.xlsx"),

    /**
     * 泄漏信息导入模板
     */
    ASSET_ASM_INFO_LEAK_EXPORT_EXCEL("泄漏信息导入模板", "泄漏信息导入模板.xlsx"),

    /**
     * 泄漏信息导入错误详情
     */
    ASSET_ASM_INFO_LEAK_EXPORT_EXCEL_ERROR("泄漏信息导入错误详情", "泄漏信息导入错误详情.xlsx"),

    /**
     * 互联网资产导入模板
     */
    ASSET_ASM_INTERNET_EXCEL("互联网资产导入模板", "互联网资产导入模板.xlsx"),

    /**
     * 互联网资产导入错误详情
     */
    ASSET_ASM_INTERNET_EXCEL_ERROR("互联网资产导入错误详情", "互联网资产导入错误详情.xlsx"),

    /**
     * 端口映射关系导入模板
     */
    ASSET_ASM_PORT_EXCEL("端口映射关系导入模板", "端口映射关系导入模板.xlsx"),

    /**
     * 端口映射关系导入错误详情
     */
    ASSET_ASM_PORT_EXCEL_ERROR("端口映射关系导入错误详情", "端口映射关系导入错误详情.xlsx"),

    /**
     * 基线问题导入模板
     */
    BASELINE_PROCESS_FORM("基线问题导入模板", "基线问题导入模板.xlsx"),

    /**
     * 基线问题导入错误详情
     */
    BASELINE_PROCESS_FORM_ERROR("基线问题导入错误详情", "基线问题导入错误详情.xlsx"),

    /**
     * 网段导入模板
     */
    ASSET_SEGEMENT_EXCEL("网段导入模板", "网段导入模板.xlsx"),

    /**
     * 网段导入错误详情
     */
    ASSET_SEGEMENT_EXCEL_ERROR("网段导入错误详情", "网段导入错误详情.xlsx"),

    /**
     * 安全风险导入模板
     */
    RISK_EXCEL("安全风险导入模板", "安全风险导入模板.xlsx"),

    /**
     * 安全风险导入错误详情
     */
    RISK_EXCEL_ERROR("安全风险导入错误详情", "安全风险导入错误详情.xlsx"),

    /**
     * 用户角色导入模板
     */
    USER_ROLE_EXCEL("用户角色导入模板", "用户角色导入模板.xlsx"),

    /**
     * 用户角色导入错误详情
     */
    USER_ROLE_ERROR_EXCEL("用户角色导入错误详情", "用户角色导入错误详情.xlsx"),

    /**
     * 法规标准导入模板
     */
    SUPER_VERSION_RULE_EXCEL("法规标准导入模板", "法规标准导入模板.xlsx"),

    /**
     * 法规标准导入错误详情
     */
    SUPER_VERSION_RULE_EXCEL_ERROR("法规标准导入错误详情", "法规标准导入错误详情.xlsx"),

    /**
     * 法规标准条目导入模板
     */
    SUPER_VERSION_RULE_ITEM_EXCEL("法规标准条目导入模板", "法规标准条目导入模板.xlsx"),

    /**
     * 法规标准条目导入错误详情
     */
    SUPER_VERSION_RULE_ITEM_EXCEL_ERROR("法规标准条目导入错误详情", "法规标准条目导入错误详情.xlsx"),

    /**
     * 监管案例导入模板
     */
    SUPER_VERSION_CASE_EXCEL("监管案例导入模板", "监管案例导入模板.xlsx"),

    /**
     * 监管案例导入错误详情
     */
    SUPER_VERSION_CASE_EXCEL_ERROR("监管案例导入错误详情", "监管案例导入错误详情.xlsx"),

    /**
     * 软件序列号导入模板
     */
    SOFTWARE_SERIAL_NUMBER_EXCEL("软件序列号导入模板", "软件序列号导入模板.xlsx"),

    /**
     * 软件序列号_错误详情_导出模板
     */
    SOFTWARE_SERIAL_NUMBER_EXCEL_ERROR("软件序列号_错误详情_导出模板", "软件序列号_错误详情_导出模板.xlsx"),


    /**
     * 软件台账导入模板
     */
    SOFTWARE_LICENSE_EXCEL("软件台账导入模板", "软件台账导入模板.xlsx"),

    /**
     * 软件台账_错误详情_导出模板
     */
    SOFTWARE_LICENSE_EXCEL_ERROR("软件台账_错误详情_导出模板", "软件台账_错误详情_导出模板.xlsx"),

    ASSET_TERMINAL_RESOURCE("已分配软件许可信息导入模板","已分配软件许可信息导入模板.xlsx"),

    ASSET_TERMINAL_RESOURCE_ERROR("已分配软件许可信息导入错误详情", "已分配软件许可信息导入错误详情.xlsx"),

    /**
     * 华东油气分公司系统风险接受清单模板
     */
    HD_SYSTEM_RISK_TEMPLATE("华东油气分公司系统风险接受清单模板","华东油气分公司系统风险接受清单模板.docx"),

    /**
     * 华东油气分公司系统风险接受清单RAR
     */
    HD_SYSTEM_RISK_ACCEPTANCE_LIST_TEMPLATE("华东油气分公司系统风险接受清单","华东油气分公司系统风险接受清单.rar"),

    /**
     * 物联网导入模板
     */
    INTERNET_OF_THINGS_IMPORT_EXCEL("物联网导入模板", "物联网资产导入模板.xlsx"),

    /**
     * 物联网资产导入错误详情
     */
    INTERNET_OF_THINGS_IMPORT_EXCEL_ERROR("物联网资产导入错误详情", "物联网资产导入错误详情.xlsx"),

    ;

    /**
     * 名称
     */
    private String name;

    /**
     * 描述
     */
    private String desc;

    DownloadTemplateEnum(String name, String desc){
        this.name = name;
        this.desc = desc;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getDesc() {
        return desc;
    }

    public void setDesc(String desc) {
        this.desc = desc;
    }
}
