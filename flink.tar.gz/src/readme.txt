linux启动方法：
java -jar -Xms1024m -Xmx2048m -XX:PermSize=456M -XX:MaxPermSize=712M -Dloader.path=lib flink-1.0.jar --spring.config.location=config/ --logging.config=config/log4j2.xml

tar -zcvf flink-1.0.tar.gz config flink-1.0.jar readme.txt lib
java -Dloader.path=/app/crc_flink/winhost/lib -jar flink-1.0.jar --version
