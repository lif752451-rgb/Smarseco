package com.crc.log.flink.parse;

import com.alibaba.fastjson.JSONObject;
import com.crc.log.flink.common.constants.LevelConstants;
import com.crc.log.flink.common.constants.LogConstants;
import com.crc.log.flink.common.utils.DataUtils;
import com.crc.log.flink.common.utils.JsonUtils;
import com.crc.log.flink.common.utils.MapUtils;
import org.apache.commons.lang3.StringUtils;

import java.util.concurrent.ConcurrentHashMap;

/**
 * Linux Syslog的JSON格式解析
 */
@SuppressWarnings("unchecked")
public class ResolvLinuxSyslog {
    /**
     * Linux 日志泛化
     */
    public static ConcurrentHashMap<String,Object> parse(String message) {
        try {
            ConcurrentHashMap<String,Object> data = proc(message);
            if (DataUtils.isNotEmptyJson(data)) {
                return data;
            }
        } catch (Exception ignored) {

        }
        return null;
    }

    private static ConcurrentHashMap<String,Object> proc(String jsonStr) {
        ConcurrentHashMap<String,Object> ldapJson = JsonUtils.createBaseMap(jsonStr);
        try {
            jsonStr = DataUtils.getSubString(jsonStr, DataUtils.getIndex(jsonStr, "{"));
                    //jsonStr.substring(jsonStr.indexOf("{"));
            jsonStr = DataUtils.getSubString(jsonStr, 0, DataUtils.getLastIndex(jsonStr, "}") + 1);
                    //jsonStr.substring(0, jsonStr.lastIndexOf("}") + 1);
            JSONObject jObj = JsonUtils.parse(jsonStr);
            if (JsonUtils.isEmpty(jObj)) {
                return ldapJson;
            }
            String devIp = JsonUtils.getStr(jObj, "dev_ip");
            if (StringUtils.isBlank(devIp)) {
                devIp = JsonUtils.getStr(jObj, "host");
            }
            MapUtils.setStr(ldapJson, LogConstants.LOG_DESCRIPTION, jObj, "message");

            MapUtils.setStr(ldapJson, LogConstants.MSG_CONTENT, jObj, "message");
            MapUtils.setStr(ldapJson, LogConstants.SRC_IP, devIp);
            MapUtils.setStr(ldapJson, LogConstants.HOST_NAME, jObj, "hostname");
            MapUtils.setStr(ldapJson, LogConstants.LOG_DEV_IP, devIp);
            MapUtils.setStr(ldapJson, LogConstants.LOG_PROTOCAL, jObj, "type");

            MapUtils.setStr(ldapJson, LogConstants.LOG_LEVEL, LevelConstants.INFO);
            ldapJson.put(LogConstants.LOG_LEVEL, LevelConstants.getLevel(MapUtils.getStr(ldapJson,LogConstants.LOG_LEVEL)));
            if (StringUtils.isBlank(MapUtils.getStr(ldapJson, LogConstants.SRC_IP))) {
                ldapJson.put(LogConstants.SRC_IP, "0.0.0.0");
            }
            if (StringUtils.isBlank(MapUtils.getStr(ldapJson, LogConstants.DEST_IP))) {
                ldapJson.put(LogConstants.DEST_IP, "0.0.0.0");
            }
            ldapJson.put(LogConstants.LOG_PRODUCT, "Linux服务器");
            setAlertName(ldapJson);
            return ldapJson;
        } catch (Exception e) {
            ldapJson.put(LogConstants.LOG_DESCRIPTION,jsonStr);
            ldapJson.put(LogConstants.ALERT_NAME,jsonStr);
            return ldapJson;
        }
    }

    private static void setAlertName(ConcurrentHashMap<String,Object> ldapJson) {
        String srcIp = MapUtils.getStr(ldapJson, LogConstants.SRC_IP);
        String protocal = MapUtils.getStr(ldapJson, LogConstants.LOG_PROTOCAL);
        String msg = MapUtils.getStr(ldapJson, LogConstants.MSG_CONTENT);
        String log = MapUtils.getStr(ldapJson, LogConstants.LOG_ORI_MSG);
        String msgFormat = "源IP:%s,协议:%s,日志内容:%s,日志详情为:%s";
        String alertName = String.format(msgFormat, srcIp, protocal, msg, log);
        ldapJson.put(LogConstants.ALERT_NAME, alertName);
    }
}
