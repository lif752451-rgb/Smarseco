package com.crc.log.flink.test.more;

import java.util.concurrent.CompletableFuture;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.TimeoutException;

public class ThreadTest {
    public static void main(String[] args) {
// 定义超时时间为3秒
        long timeout = 3000;
// 创建⼀个新的CompletableFuture
        CompletableFuture<Object> future = CompletableFuture.supplyAsync(() -> {
// 这⾥是要执⾏的⽅法
            return longRunningMethod();
        });
// 获取执⾏结果
        try {
            Object result = future.get(timeout, TimeUnit.MILLISECONDS);
            System.out.println("⽅法执⾏完毕，结果：" + result.toString());
        } catch (InterruptedException e) {
            System.out.println("出现异常，结束该⽅法的执⾏");
            future.cancel(true);
        } catch (ExecutionException e) {
            System.out.println("出现异常，结束该⽅法的执⾏");
            future.cancel(true);
        } catch (TimeoutException e) {
// 超时了，结束该⽅法的执⾏
            System.out.println("超时了，结束该⽅法的执⾏");
            future.cancel(true);
        }
    }


    // 耗时的⽅法
    public static Object longRunningMethod() {
        for (int i = 0; i < 2; i++) {
            System.out.println("这是第" + (i + 1) + "次打印");
            try {
//等待1秒
                Thread.sleep(1000);
            } catch (InterruptedException e) {
                e.printStackTrace();
                return null;
            }
        }
        return "完成";
    }
}
