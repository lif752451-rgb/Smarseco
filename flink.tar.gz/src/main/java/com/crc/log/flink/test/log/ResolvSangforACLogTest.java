package com.crc.log.flink.test.log;

import com.crc.log.flink.common.utils.JsonUtils;
import com.crc.log.flink.config.AllConfig;
import com.crc.log.flink.es.DataProcessFuncation;

import java.text.ParseException;
import java.util.concurrent.ConcurrentHashMap;

public class ResolvSangforACLogTest {
    public static void main(String[] args) throws ParseException {
        String msgx = "<190>Sep 10 2021 01:34:16 D166021BUFWHW189 %%01POLICY/6/POLICYPERMIT(l):vsys=public, protocol=6, source-ip=10.72.11.81, source-port=42092, destination-ip=10.10.44.101, destination-port=8889, time=2021/9/10 09:34:16, source-zone=untrust, destination-zone=trust, rule-name=REQ000000160164.";
        AllConfig config = new AllConfig();
        DataProcessFuncation.CONIFG = config;
        config.setMode("single");
        config.setParse("ResolvSangforACLog");
        config.setIndex("net_all");

        msgx = "<188>Dec  2 2021 08:29:06 USG6630-A IPSTRAP/4/THREATTRAP:OID 1.3.6.1.4.1.2011.6.122.43.1.2.8 An intrusion was detected.( SrcIp=172.16.18.79, DstIp=194.195.223.249, SrcPort=57210, DstPort=443,  Protocol=TCP, Event=JSON-RPC Mining Protocol - Miner Login, DetectTime=2021/12/02 16:29:06)";
        ConcurrentHashMap<String, Object> json = DataProcessFuncation.parse(msgx,"index");
        JsonUtils.printStr(json);

        msgx = "<12>Dec  7 14:08:17 localhost ac-online-user: [login_log][user_name:119.147.156.228] [ip:119.147.156.228] [mac:5c-e8-83-89-f7-d4] [online_time:2021-12-07 14:08:17] [action:login] [detail:不需要认证]";
        json = DataProcessFuncation.parse(msgx,"index");
        JsonUtils.printStr(json);

        msgx = "<12>Dec  7 14:08:57 localhost ac-online-user: [logout_log][user_name:113.142.50.51] [ip:113.142.50.51] [mac:5c-e8-83-89-f7-d4] [offline_time:2021-12-07 14:08:57] [action:logout] [detail:用户无流量注销]";
        json = DataProcessFuncation.parse(msgx,"index");
        JsonUtils.printStr(json);

        msgx = "<15>Dec  7 13:20:02 localhost logs: d0:attachlistcreator.cpp:459 sleep 60";
        json = DataProcessFuncation.parse(msgx,"index");
        JsonUtils.printStr(json);


        msgx = "<15>Dec 22 14:09:05 localhost logs: d0:reconstruct.c:68 lost packet of connection: 172.16.29.143:63653 <-> 218.2.0.155:80, may lost content";
        json = DataProcessFuncation.parse(msgx,"index");
        JsonUtils.printStr(json);


        msgx = "<134>May 06 13:32:21 jtnetvuwf02 BA[3040]: [log_type:url] [record_time:2022-05-06 13:22:58] [user:hejianfeng19] [group:/Users.crc.com.hk/] [host_ip:10.54.72.13] [dst_ip:49.4.35.22] [serv:访问网站] [app:网络存储（Web）] [site:未定义位置] [tm_type:/移动终端/windows系统移动终端] [net_action:记录] [url:oauth-login-drcn.platform.dbankcloud.com] [DNS:oauth-login-drcn.platform.dbankcloud.com] [title:-] [snapshot:-] [is_webapp:1] [dev_id:ea5f9b77] [serv_port:443] [src_port:54314] [urllog_type:0] [urltype:网络存储（Web）] [urldata:oauth-login-drcn.platform.dbankcloud.com] [filename:-] [host:oauth-login-drcn.platform.dbankcloud.com] [keyword_original:-] [trace_t:web_url] [usr_name:hejianfeng19] [result:<?xml version=\"1.0\" encoding=\"utf-8\"?>\n" +
                "<_d>\n" +
                "  <_f n=\"url\">oauth-login-drcn.platform.dbankcloud.com</_f>\n" +
                "  <_f n=\"DNS\">oauth-login-drcn.platform.dbankcloud.com</_f>\n" +
                "  <_f n=\"urltype\">网络存储（Web）</_f>\n" +
                "  <_f n=\"urldata\">oauth-login-drcn.platform.dbankcloud.com</_f>\n" +
                "  <_f n=\"host\">oauth-login-drcn.platform.dbankcloud.com</_f>\n" +
                "  <_f n=\"trace_t\">web_url</_f>\n" +
                "  <_f n=\"usr_name\">hejianfeng19</_f>\n" +
                "</_d>]";
        json = DataProcessFuncation.parse(msgx,"index");
        JsonUtils.printStr(json);
    }


}
