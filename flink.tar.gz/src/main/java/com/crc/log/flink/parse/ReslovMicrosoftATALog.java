package com.crc.log.flink.parse;

import com.crc.log.flink.common.constants.LevelConstants;
import com.crc.log.flink.common.constants.LogConstants;
import com.crc.log.flink.common.utils.DataUtils;
import com.crc.log.flink.common.utils.JsonUtils;
import com.crc.log.flink.common.utils.MapUtils;
import org.apache.commons.lang3.StringUtils;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * @author jixiangqi
 * @date 2021/12/29
 * 微软ATA
 */
public class ReslovMicrosoftATALog {
    public static ConcurrentHashMap<String,Object> parse(String message) {
        try {
            ConcurrentHashMap<String,Object> data = proc(message);
            if (DataUtils.isNotEmptyJson(data)) {
                return data;
            }
        } catch (Exception ignored) {

        }
        return null;
    }

    private static ConcurrentHashMap<String,Object> proc(String jsonStr) {
        ConcurrentHashMap<String,Object> rtnObjc = JsonUtils.createBaseMap(jsonStr);
        if (jsonStr.contains("CEF")) {
            String[] strings = DataUtils.getSplit(jsonStr, "\\|");
            //jsonStr.split("\\|");
            for (int i = 0; i < strings.length; i++) {
                switch (i) {
                    case 3:
                        rtnObjc.put(LogConstants.LOG_VERSION, strings[i]);
                        break;
                    case 4:
                        rtnObjc.put(LogConstants.LOG_NAME, strings[i]);
                        break;
                    case 5:
                        rtnObjc.put(LogConstants.LOG_DESCRIPTION, strings[i]);
                        break;
                    case 7:
                        List<String> ips = getIps(strings[i]);
                        if (ips.size() == 1) {
                            rtnObjc.put(LogConstants.SRC_IP, ips.get(0));
                        }
                        if (ips.size() == 2) {
                            rtnObjc.put(LogConstants.SRC_IP, ips.get(0));
                            rtnObjc.put(LogConstants.DEST_IP, ips.get(1));
                        }
                        String[] s = DataUtils.getSplit(strings[i], " ");
                        //strings[i].split(" ");
                        Map<String, String> resultMap = getSPace(strings[i]);
                        resultMap.forEach((key, value) -> {
                            switch (key) {
                                case "msg":
                                    rtnObjc.put(LogConstants.LOG_CONTENT, value);
                                    rtnObjc.put(LogConstants.ALERT_NAME, value);
                                    break;
                                case "cs1":
                                    if (resultMap.containsKey("cs1Label")) {
                                        if (resultMap.get("cs1Label").equals("url")) {
                                            rtnObjc.put(LogConstants.LOG_URL, value);
                                        }
                                    }
                                    break;
                                case "start":
                                    if (value.length() == 28) {
                                        if (value.contains("Z") || value.contains("z")) {
                                            value = value.replaceAll("z", "Z");
                                            value = value.substring(0, 23);
                                            value = value + "+0800";
                                        }
                                    } else if (value.length() == 24) {
                                        if (value.contains("Z") || value.contains("z")) {
                                            value = value.replaceAll("z", "Z");
                                            value = value.replaceAll("Z", "+0800");
                                        }
                                    }
                                    rtnObjc.put(LogConstants.LOG_START_TIME, value);
                                    break;
                                case "app":
                                    rtnObjc.put(LogConstants.LOG_APP, value);
                                    break;
                            }
                        });
                        break;
                }
            }
        }
        rtnObjc.put(LogConstants.LOG_PRODUCT, "微软ATA");
        rtnObjc.put(LogConstants.LOG_LEVEL, LevelConstants.getLevel(MapUtils.getStr(rtnObjc,LogConstants.LOG_LEVEL)));
        if (StringUtils.isBlank(MapUtils.getStr(rtnObjc, LogConstants.SRC_IP))) {
            rtnObjc.put(LogConstants.SRC_IP, "0.0.0.0");
        }
        if (StringUtils.isBlank(MapUtils.getStr(rtnObjc, LogConstants.DEST_IP))) {
            rtnObjc.put(LogConstants.DEST_IP, "0.0.0.0");
        }
        setAlertName(rtnObjc);
        return rtnObjc;
    }

    /**
     * 正则获取字符串中的IP地址
     *
     * @param ipString
     * @return
     */
    private static List<String> getIps(String ipString) {
        String regEx = "((2[0-4]\\d|25[0-5]|[01]?\\d\\d?)\\.){3}(2[0-4]\\d|25[0-5]|[01]?\\d\\d?)";
        List<String> ips = new ArrayList<String>();
        Pattern p = Pattern.compile(regEx);
        Matcher m = p.matcher(ipString);
        while (m.find()) {
            String result = m.group();
            ips.add(result);
        }
        return ips;
    }

    private static Map<String, String> getSPace(String jsonStr) {
        Map<String, String> resultMap = new HashMap<>();
        String index = "";
        String[] s = DataUtils.getSplit(jsonStr, " ");
        //jsonStr.split(" ");
        for (String temp : s) {
            if (temp.contains("=")) {
                String[] split = DataUtils.getSplit(temp, "=");
                //temp.split("=");
                if (split.length == 2) {
                    resultMap.put(split[0].trim(), split[1].trim());
                    index = split[0].trim();
                }
            } else {
                resultMap.put(index, resultMap.get(index) + " " + temp);
            }
        }
        return resultMap;
    }


    private static void setAlertName(ConcurrentHashMap<String,Object> rtnObjc) {
        String msgFormat = "";
        String alertName = "";
        String srcIp = MapUtils.getStr(rtnObjc, LogConstants.SRC_IP);
        String url = MapUtils.getStr(rtnObjc, LogConstants.LOG_URL);
        String logName = MapUtils.getStr(rtnObjc, LogConstants.LOG_NAME);
        String content = MapUtils.getStr(rtnObjc, LogConstants.LOG_CONTENT);
        String level = MapUtils.getStr(rtnObjc, LogConstants.LOG_LEVEL);
        String product = MapUtils.getStr(rtnObjc, LogConstants.LOG_PRODUCT);
        String log = MapUtils.getStr(rtnObjc, LogConstants.LOG_ORI_MSG);
        if (srcIp.equals("0.0.0.0")) {
            msgFormat = "%s产生了一个告警,路径为：%s,日志名称为:%s,日志详情为:%s,日志级别为:%s,原始日志为:%s";
            alertName = String.format(msgFormat, product, url, logName, content, level, log);
        } else {
            msgFormat = "源IP为:%s产生了一个告警,路径为：%s,日志名称为:%s,日志详情为:%s,日志级别为:%s,原始日志为:%s";
            alertName = String.format(msgFormat, srcIp, url, logName, content, level, log);
        }
        rtnObjc.put(LogConstants.ALERT_NAME, alertName);
    }

}
