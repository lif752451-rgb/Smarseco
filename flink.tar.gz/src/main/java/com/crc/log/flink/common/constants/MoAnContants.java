package com.crc.log.flink.common.constants;

import java.util.HashMap;

public class MoAnContants {
    public static HashMap<String, String> eventTypeMap = new HashMap<>();
    public static HashMap<String, String> actionTypeMap = new HashMap<>();

    static {
        eventTypeMap.put("110", "打开explorer");
        eventTypeMap.put("111", "打开浏览器");
        eventTypeMap.put("112", "创建文件");
        eventTypeMap.put("113", "删除文件");
        eventTypeMap.put("114", "修改文件");
        eventTypeMap.put("119", "登录");
        eventTypeMap.put("120", "执行恶意程序");
        eventTypeMap.put("121", "端口探测");
        eventTypeMap.put("122", "蠕虫攻击");
        eventTypeMap.put("123", "远程命令执行");
        eventTypeMap.put("124", "尝试RDP登录");
        eventTypeMap.put("115", "apache事件");
        eventTypeMap.put("116", "IIS事件");
        eventTypeMap.put("117", "mysql事件");
        eventTypeMap.put("118", "sqlserver事件");
        actionTypeMap.put("20", "执行sql");
        actionTypeMap.put("21", "登录成功");
        actionTypeMap.put("24", "登录失败");
        actionTypeMap.put("22", "执行sql");
        actionTypeMap.put("23", "建立连接");
    }


    /*
    event_type 执行系统操作
action_type
110: 打开 explorer
111: 打开浏览器
112: 创建文件
113: 删除文件
114: 修改文件
119: 登录
120: 执行恶意程序
121: 端口探测
122: 蠕虫攻击
123: 远程命令执行
124: 尝试RDP登录

event_type
115：apache 事件
116：IIS 事件
117：mysql 事件
118：sqlserver 事件

action_type
20: 执行sql
21: 登录成功
24: 登录失败
22: 执行sql
23: 建立连接
     */
}
