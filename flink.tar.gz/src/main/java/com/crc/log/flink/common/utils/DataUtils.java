package com.crc.log.flink.common.utils;

import com.alibaba.fastjson.JSONObject;
import org.apache.commons.lang3.RandomUtils;
import org.apache.commons.lang3.StringUtils;

import java.math.BigDecimal;
import java.math.RoundingMode;
import java.net.Inet4Address;
import java.security.SecureRandom;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.regex.Pattern;

/**
 * 数据转换处理
 *
 * @author hejs
 */
@SuppressWarnings("unchecked")
public class DataUtils {

    static  Pattern NUM_PATTERN = Pattern.compile("^[-\\+]?[\\d]*$");
    public static int getInt(String str) {
        if (StringUtils.isBlank(str)) {
            return 0;
        }
        if (!isInteger(str)) {
            return 0;
        }
        try {
            return Integer.parseInt(str);
        } catch (Exception ignored) {

        }
        return 0;
    }

    /***
     * 判断 String 是否是 int
     *
     * @param str
     * @return
     */
    public static boolean isInteger(String str) {
        if (StringUtils.isBlank(str)) {
            //log.debug("空内容为非数字");
            return false;
        }
        Pattern pattern = Pattern.compile("^[-\\+]?[\\d]*$");
        //log.debug("内容：{},为非数字", str);
        return pattern.matcher(str).matches();
    }
    /**
     * 获取数字值，下标从0开始
     *
     */
    public static String getArrayString(String[] arr, int index) {
        String ret = "";
        if (arr == null || index < 0 || (arr.length - 1) < index)
            return ret;

        return arr[index];
    }

    public static int getRandom(int max, int min) {
        SecureRandom random = new SecureRandom();
        return random.nextInt(max) % (max - min + 1) + min;
    }

    public static String getListString(List<String> list, int index) {
        if (list == null || list.size() < index || index < 1)
            return "";
        return list.get(index - 1);
    }


    public static String transform(String str) {
        if (StringUtils.isBlank(str))
            return str;
        if (str.contains("<") || str.contains(">") || str.contains("&")) {
            str = str.replaceAll("&", "&amp;");
            str = str.replaceAll("<", "&lt;");
            str = str.replaceAll(">", "&gt;");
        } else if (str.contains("'")) {
            str = str.replaceAll("'", "\\'");
        }

        return str;
    }

    /**
     * 清空列表
     *
     */
    public static void clearList(List... args) {
        if (args == null) {
            return;
        }
        for (List arg : args) {
            if (arg != null) {
                arg.clear();
                arg = null;
            }
        }
    }

    /**
     * 清空列表
     *
     */
    public static void clearMap(Map... args) {
        if (args == null) {
            return;
        }
        for (Map arg : args) {
            if (arg != null) {
                arg.clear();
                arg = null;
            }
        }
    }


    /**
     * 判断list是否为空
     */
    public static boolean isNotEmptyList(List<Object> list) {
        return !isEmptyList(list);
    }

    /**
     * 判断list是否为空
     */
    public static boolean isEmptyList(List<Object> list) {
        return list == null || list.size() == 0;
    }


    /**
     * 小k是24小时制，大K是12小时制
     *
     * @param jt 时间
     * @return 时间
     */
    public static Date parseJavaTime(String jt) {
        SimpleDateFormat sdf = new SimpleDateFormat("MMM d, yyyy k:m:s a", Locale.ENGLISH);
        Date d2 = null;
        try {
            d2 = sdf.parse(jt);
            return d2;
        } catch (Exception ignored) {
        }
        return null;
    }

    /**
     * 精确2位数
     *
     * @param d double
     * @return 2位
     */
    public static String doublePrec1(double d) {
        if (Math.floor(d) == d)
            return String.valueOf((int) d);
        BigDecimal b = new BigDecimal(d);
        double f1 = b.setScale(2, RoundingMode.HALF_UP).doubleValue();
        return String.valueOf(f1);
    }

    /**
     * 精确3位数
     *
     * @param d double
     * @return 2位
     */
    public static String doublePrec2(double d) {
        if (Math.floor(d) == d)
            return String.valueOf((int) d);
        BigDecimal b = new BigDecimal(d);
        double f1 = b.setScale(3, RoundingMode.HALF_UP).doubleValue();
        return String.valueOf(f1);
    }

    public static String doublePrec2(String d) {
        try {
            BigDecimal b = new BigDecimal(d);
            double f1 = b.setScale(3, RoundingMode.HALF_UP).doubleValue();
            return String.valueOf(f1);
        } catch (Exception ignored) {

        }
        return "0";

    }


    public static double toDouble(String d) {
        try {
            if (StringUtils.isBlank(d))
                return 0;
            return Double.parseDouble(d);
        } catch (Exception ignored) {

        }
        return 0;
    }

    /**
     * 精确2位数
     *
     */
    public static double doublePrec(double d) {
        if (Math.floor(d) == d)
            return (int) d;
        BigDecimal b = new BigDecimal(d);
        return b.setScale(2, RoundingMode.HALF_UP).doubleValue();
    }

    public static String str(long l) {
        return String.valueOf(l);
    }

    public static String str(int l) {
        return String.valueOf(l);
    }

    public static int toNum(String s) {
        if (!isNumeric(s)) {
            return 0;
        }
        try {
            if (StringUtils.isBlank(s))
                return 0;
            s = s.trim();
            return Integer.parseInt(s);
        } catch (Exception ignored) {
        }
        return 0;
    }

    public static long toLong(String s) {
        if (!isNumeric(s)) {
            return 0;
        }
        try {
            if (StringUtils.isBlank(s))
                return 0;
            s = s.trim();
            return Long.parseLong(s);
        } catch (Exception ignored) {
        }
        return 0;
    }

    //05/26/2020 09:25:01 -> 2020-05-26 09:25:01
    public static String getArrayDateString(String[] messageArr, int i) {
        String ds = getArrayString(messageArr, i);
        return getDateString(ds);
    }

    public static String getDateString(String ds) {
        if (StringUtils.isNotBlank(ds)) {
            String[] arr = ds.split(" ");
            if (arr.length < 2)
                return ds;
            String[] arr2 = arr[0].split("/");
            if (arr2.length != 3) {
                return ds;
            }
            return String.format("%s%s%s%s", arr2[2], arr2[0], arr2[1], arr[1]).replace(":", "");
        }
        return "";
    }

    public static String getString(Map map, String filter) {
        if (StringUtils.isNotBlank(filter) && map != null) {
            Object o = map.get(filter);
            if (o != null) {
                return o.toString();
            }
        }
        return "";
    }

    public static int getIntX(String parallelism) {
        if (!isNumeric(parallelism)) {
            return 1;
        }
        try {
            int p = DataUtils.toNum(parallelism);
            if (p < 1)
                p = 1;
            return p;
        } catch (Exception ignored) {
        }
        return 1;
    }


    public static String getSubString(String string, int first, int end) {
        if (end <= first) {
            return "";
        }
        if (StringUtils.isBlank(string)) {
            return "";
        }
        if (string.length() < end) {
            return "";
        }
        if (first < 0) {
            return "";
        }
        return string.substring(first, end);
    }

    public static String getSubString(String string, int first) {
        if (StringUtils.isBlank(string)) {
            return "";
        }
        if (string.length() < first) {
            return "";
        }
        if (first < 0) {
            return "";
        }
        return string.substring(first);
    }

    public static String[] getSplit(String str, String symbol) {
        String[] split = {};
        if (StringUtils.isNotBlank(str) && symbol != null) {
            split = str.split(symbol);
        }
        return split;
    }

    public static String[] getSplit2(String str, String symbol) {
        String[] split = new String[2];
        int index = DataUtils.getIndex(str, symbol);
        split[0] = DataUtils.getSubString(str, 0, index);
        split[1] = DataUtils.getSubString(str, index + 1);
        return split;
    }

    public static int getIndex(String str, String c) {
        int index = -1;
        if (StringUtils.isNotBlank(str) && c != null) {
            index = str.indexOf(c);
        }
        return index;
    }

    public static int getLastIndex(String str, String c) {
        int index = -1;
        if (StringUtils.isNotBlank(str) && c != null) {
            index = str.lastIndexOf(c);
        }
        return index;
    }

    /**
     * 获取本地+进程唯一ID
     *
     * @return id
     */
    public static short getWorkId() {
        try {
            String hostAddress = Inet4Address.getLocalHost().getHostAddress();
            int[] ints = StringUtils.toCodePoints(hostAddress);
            int sums = 0;
            for (int b : ints) {
                sums += b;
            }
            return (short) ((sums % 32) + getProccessId());
        } catch (Exception e) {
            // 如果获取失败，则使用随机数备用
            return (short) (RandomUtils.nextInt(0, 31) + getProccessId());
        }
    }

    public static int getProccessId() {
        try {
            java.lang.management.RuntimeMXBean runtime =
                    java.lang.management.ManagementFactory.getRuntimeMXBean();
            java.lang.reflect.Field jvm = runtime.getClass().getDeclaredField("jvm");
            jvm.setAccessible(true);
            sun.management.VMManagement mgmt =
                    (sun.management.VMManagement) jvm.get(runtime);
            java.lang.reflect.Method pid_method =
                    mgmt.getClass().getDeclaredMethod("getProcessId");
            pid_method.setAccessible(true);

            int procId =  (Integer) pid_method.invoke(mgmt);
            return  (short) (procId % 32);
        } catch (Exception e) {
            return RandomUtils.nextInt(1, 31);
        }
    }

    /***
     * 判断 String 是否是 int
     *
     * @param str String
     * @return f/t
     */
    public static boolean isNumeric(String str) {
        if (StringUtils.isBlank(str)) {
            return false;
        }
        return NUM_PATTERN.matcher(str).matches();
    }

    public static boolean isNotEmptyJson(JSONObject jsonObject) {
        if (jsonObject == null) {
            return false;
        }
        return !jsonObject.isEmpty();
    }

    public static boolean isNotEmptyJson(Map<String,Object> jsonObject) {
        if (jsonObject == null) {
            return false;
        }
        return !jsonObject.isEmpty();
    }
}
