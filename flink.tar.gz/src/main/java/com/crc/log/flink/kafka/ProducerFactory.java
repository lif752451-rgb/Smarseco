package com.crc.log.flink.kafka;

import org.apache.commons.pool2.PooledObject;
import org.apache.commons.pool2.PooledObjectFactory;
import org.apache.commons.pool2.impl.DefaultPooledObject;
import org.apache.kafka.clients.producer.KafkaProducer;
import org.apache.kafka.clients.producer.Producer;
import org.apache.kafka.clients.producer.ProducerConfig;

import java.util.Properties;

/**
 * @author simba@onlying.cn
 * @date 2020/8/31 18:48
 */
public class ProducerFactory implements PooledObjectFactory<Producer<String, String>> {

    private static final long serialVersionUID = 8271607366818512399L;

    private final Properties config;

    /**
     * 构造方法
     *
     * @param config 生产者配置
     */
    public ProducerFactory(final Properties config) {
        this.config = config;
    }

    /**
     * 构造方法
     *
     * @param brokers broker列表
     * @param retries    重试次数
     * @param acks    确认类型
     * @param codec   压缩类型
     * @param batch   批量大小
     */
    public ProducerFactory(final String brokers, final int retries, final String acks,
                           final String codec, final int batch) {
        Properties props = new Properties();
        props.put(ProducerConfig.BOOTSTRAP_SERVERS_CONFIG, brokers);
        props.put(ProducerConfig.RETRIES_CONFIG, 0);
        props.put(ProducerConfig.ACKS_CONFIG, acks);
        props.put(ProducerConfig.KEY_SERIALIZER_CLASS_CONFIG, codec);
        props.put(ProducerConfig.VALUE_SERIALIZER_CLASS_CONFIG, codec);
        props.put(ProducerConfig.BATCH_SIZE_CONFIG, batch);
        // 默认参数
        props.put(ProducerConfig.LINGER_MS_CONFIG, 1);
        props.put(ProducerConfig.BUFFER_MEMORY_CONFIG, 33554432);

        this.config = props;
    }

    @Override
    public PooledObject<Producer<String, String>> makeObject() throws Exception {
        Producer<String, String> producer = this.createConnection();
        return new DefaultPooledObject<>(producer);
    }

    @Override
    public void destroyObject(PooledObject<Producer<String, String>> p) throws Exception {
        Producer<String, String> producer = p.getObject();
        if (null != producer) {
            producer.close();
        }
    }

    @Override
    public boolean validateObject(PooledObject<Producer<String, String>> p) {
        Producer<String, String> producer = p.getObject();
        return (null != producer);
    }

    @Override
    public void activateObject(PooledObject<Producer<String, String>> p) throws Exception {
        // TODO
    }

    @Override
    public void passivateObject(PooledObject<Producer<String, String>> p) throws Exception {
        // TODO
    }

    public Producer<String, String> createConnection() throws Exception {
        return new KafkaProducer<>(config);
    }

}
