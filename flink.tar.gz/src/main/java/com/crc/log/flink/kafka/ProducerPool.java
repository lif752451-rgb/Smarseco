package com.crc.log.flink.kafka;

import org.apache.commons.pool2.impl.GenericObjectPoolConfig;
import org.apache.kafka.clients.producer.Producer;

import java.util.Properties;

/**
 * @author simba@onlying.cn
 * @date 2020/8/31 18:47
 */
public class ProducerPool extends PoolBase<Producer<String,String>>{

    private static final long serialVersionUID = -1506435964498488591L;

    private static final String LOCAL_MODE = "localhost:9092";

    /**
     * 默认构造方法
     */
    public ProducerPool() {
        this(LOCAL_MODE);
    }

    public ProducerPool(final String brokers) {
        this(new GenericObjectPoolConfig(), brokers);
    }

    public ProducerPool(final GenericObjectPoolConfig poolConfig, final String brokers) {
        this(poolConfig, brokers, 0);
    }

    public ProducerPool(final GenericObjectPoolConfig poolConfig, final String brokers, final int retries) {
        this(poolConfig, brokers, retries, "all",
                "org.apache.kafka.common.serialization.StringSerializer", 16384);
    }

    public ProducerPool(final GenericObjectPoolConfig poolConfig, final Properties props) {
        super(poolConfig, new ProducerFactory(props));
    }

    public ProducerPool(final GenericObjectPoolConfig poolConfig, final String brokers, final int retries,
                        final String acks, final String codec, final int batch) {
        super(poolConfig, new ProducerFactory(brokers, retries, acks, codec, batch));
    }

    public Producer<String, String> getConnection() {
        return super.getResource();
    }

    public void returnConnection(Producer<String,String> conn) {
        super.returnResource(conn);
    }

    public void invalidateConnection(Producer<String,String> conn) {
        super.invalidateResource(conn);
    }

}
