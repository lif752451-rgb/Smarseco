package com.crc.log.flink.parse;

import com.alibaba.fastjson.JSONObject;
import com.crc.log.flink.common.constants.LevelConstants;
import com.crc.log.flink.common.constants.LogConstants;
import com.crc.log.flink.common.utils.DataUtils;
import com.crc.log.flink.common.utils.DateUtils;
import com.crc.log.flink.common.utils.JsonUtils;
import com.crc.log.flink.common.utils.MapUtils;
import org.apache.commons.lang3.StringUtils;

import java.util.concurrent.ConcurrentHashMap;

/**
 * @author jixiangqi
 * @date 2022/4/29
 * 奇安信天擎终端安全
 */
public class ResolvQAXTerminalSafeLog {

    public static ConcurrentHashMap<String, Object> parse(String message) {
        try {
            ConcurrentHashMap<String, Object> data = proc(message);
            if (DataUtils.isNotEmptyJson(data)) {
                return data;
            }
        } catch (Exception ignored) {

        }
        return null;
    }

    private static ConcurrentHashMap<String, Object> proc(String jsonStr) {
        ConcurrentHashMap<String, Object> rtnObjc = JsonUtils.createBaseMap(jsonStr);
        JSONObject jsonObject = JSONObject.parseObject(jsonStr);
        jsonObject.forEach((k, v) -> {
            switchKeyValue(rtnObjc, k.trim(), v+"".trim());
        });
        rtnObjc.put(LogConstants.LOG_PRODUCT, "奇安信天擎终端安全");
        if (StringUtils.isBlank(MapUtils.getStr(rtnObjc, LogConstants.LOG_LEVEL))) {
            rtnObjc.put(LogConstants.LOG_LEVEL, LevelConstants.getLevel(MapUtils.getStr(rtnObjc,LogConstants.LOG_LEVEL)));
        }
        if (StringUtils.isBlank(MapUtils.getStr(rtnObjc, LogConstants.SRC_IP))) {
            rtnObjc.put(LogConstants.SRC_IP, "0.0.0.0");
        }
        if (StringUtils.isBlank(MapUtils.getStr(rtnObjc, LogConstants.DEST_IP))) {
            rtnObjc.put(LogConstants.DEST_IP, "0.0.0.0");
        }
        setAlertName(rtnObjc);
        return rtnObjc;
    }

    private static void setAlertName(ConcurrentHashMap<String, Object> rtnObjc) {
        String message = "";
        String alertName = "";
        String logTye = MapUtils.getStr(rtnObjc, LogConstants.LOG_TYPE);
        String logLevel = MapUtils.getStr(rtnObjc, LogConstants.LOG_LEVEL);
        String devIp = MapUtils.getStr(rtnObjc, LogConstants.LOG_DEV_IP);
        String actionResult = MapUtils.getStr(rtnObjc, LogConstants.ACTION_RESULT);
        String content = MapUtils.getStr(rtnObjc, LogConstants.LOG_CONTENT);
        switch (logTye) {
            case "漏洞管理":
            case "体检分":
                if (StringUtils.isNotBlank(actionResult)) {
                    message = "在IP为:%s的设备上发现了一个%s的日志,日志内容为:%s,处理结果:%s,日志级别:%s";
                    alertName = String.format(message, devIp, logTye, content, actionResult, logLevel);
                } else {
                    message = "在IP为:%s的设备上发现了一个%s的日志,日志内容为:%s,日志级别:%s";
                    alertName = String.format(message, devIp, logTye, content, logLevel);
                }
                break;
            case "系统修复":
            case "插件":
            case "xp盾甲":
                String action = MapUtils.getStr(rtnObjc, LogConstants.ACTION);
                message = "在IP为:%s的设备上发现了一个%s的日志,日志内容为:%s,处理动作为:%s,处理结果:%s,日志级别:%s";
                alertName = String.format(message, devIp, logTye, content, action, actionResult, logLevel);
                break;
            case "病毒分析": {
                String virusName = MapUtils.getStr(rtnObjc, LogConstants.VIRUS_NAME);
                String virusType = MapUtils.getStr(rtnObjc, LogConstants.VIRUS_TYPE);
                String actionType = MapUtils.getStr(rtnObjc, LogConstants.ACTION_TYPE);
                message = "在IP为:%s的设备上发现了一个%s的日志,病毒名称为:%s,病毒类型为:%s,处理动作为:%s,处理结果:%s,日志级别:%s";
                alertName = String.format(message, devIp, logTye, virusName, virusType, actionType, actionResult, logLevel);
                break;
            }
            case "违规外联": {
                String devName = MapUtils.getStr(rtnObjc, LogConstants.DEVICE_NAME);
                message = "在IP为:%s的设备上发现了一个%s的日志,外联设备为:%s,日志级别:%s";
                alertName = String.format(message, devIp, logTye, devName, logLevel);
                break;
            }
            case "进程违规运行": {
                String processName = MapUtils.getStr(rtnObjc, LogConstants.PROCESS_NAME);
                String processPatch = MapUtils.getStr(rtnObjc, LogConstants.PROCESS_PATCH);
                message = "在IP为:%s的设备上发现了一个%s的日志,违规进程名称为:%s,违规进程路径为:%s,日志级别:%s";
                alertName = String.format(message, devIp, logTye, processName, processPatch, logLevel);
                break;
            }
            case "使用违规互联网出口": {
                String devName = MapUtils.getStr(rtnObjc, LogConstants.DEVICE_NAME);
                message = "在IP为:%s的设备上发现了一个%s的日志,设备名称为:%s,是否信任:%s,日志级别:%s";
                alertName = String.format(message, devIp, logTye, devName, actionResult, logLevel);
                break;
            }
            case "外设使用": {
                String devName = MapUtils.getStr(rtnObjc, LogConstants.DEVICE_NAME);
                String actionType = MapUtils.getStr(rtnObjc, LogConstants.ACTION_TYPE);
                message = "在IP为:%s的设备上发现了一个%s的日志,设备名称为:%s,操作类型:%s,日志级别:%s";
                alertName = String.format(message, devIp, logTye, devName, actionType, logLevel);
                break;
            }
            case "桌面加固": {
                String riskType = MapUtils.getStr(rtnObjc, LogConstants.RISK_TYPE);
                String actionType = MapUtils.getStr(rtnObjc, LogConstants.ACTION_TYPE);
                message = "在IP为:%s的设备上发现了一个%s的日志,安全类型为:%s,操作类型:%s,日志级别:%s";
                alertName = String.format(message, devIp, logTye, riskType, actionType, logLevel);
                break;
            }
            case "账号登录登出": {
                String userName = MapUtils.getStr(rtnObjc, LogConstants.USER_NAME);
                String actionType = MapUtils.getStr(rtnObjc, LogConstants.ACTION_TYPE);
                message = "用户名为:%s在IP为:%s的设备上发现了一个%s的日志,操作类型:%s,日志级别:%s";
                alertName = String.format(message, userName, devIp, logTye, actionType, logLevel);
                break;
            }
            case "文件审计":
                String process = MapUtils.getStr(rtnObjc, LogConstants.PROCESS_NAME);
                message = "在IP为:%s的设备上发现了一个%s的日志,进程名称为:%s,日志级别:%s";
                alertName = String.format(message, devIp, logTye, process, logLevel);
                break;
            case "打印审计": {
                String filePath = MapUtils.getStr(rtnObjc, LogConstants.FILE_PATH);
                message = "在IP为:%s的设备上发现了一个%s的日志,文件路径为:%s,日志级别:%s";
                alertName = String.format(message, devIp, logTye, filePath, logLevel);
                break;
            }
            case "邮件审计":
                String emailSend = MapUtils.getStr(rtnObjc, LogConstants.EMAIL_SEND);
                String emailReceiver = MapUtils.getStr(rtnObjc, LogConstants.EMAIL_RECEIVER);
                message = "在IP为:%s的设备上发现了一个%s的日志,发件人:%s,收件人:%s,内容为:%s,日志级别:%s";
                alertName = String.format(message, devIp, logTye, emailSend, emailReceiver, content, logLevel);
                break;
            case "进程审计": {
                String processName = MapUtils.getStr(rtnObjc, LogConstants.PROCESS_NAME);
                String filePath = MapUtils.getStr(rtnObjc, LogConstants.FILE_PATH);
                message = "在IP为:%s的设备上发现了一个%s的日志,进程路径为:%s,文件路径为:%s,日志级别:%s";
                alertName = String.format(message, devIp, logTye, processName, filePath, logLevel);
                break;
            }
            case "安全U盘审计": {
                String fileName = MapUtils.getStr(rtnObjc, LogConstants.LOG_FILENAME);
                String userName = MapUtils.getStr(rtnObjc, LogConstants.USER_NAME);
                message = "用户名为:%s在IP为:%s的设备上发现了一个%s的日志,操作文件名称为:%s,日志级别:%s";
                alertName = String.format(message, userName, devIp, logTye, fileName, logLevel);
                break;
            }
            case "开关机审计":
                message = "在IP为:%s的设备上发现了一个%s的日志,日志级别:%s";
                alertName = String.format(message, devIp, logTye, logLevel);
                break;
            case "网络访问审计": {
                String processName = MapUtils.getStr(rtnObjc, LogConstants.PROCESS_NAME);
                String processPatch = MapUtils.getStr(rtnObjc, LogConstants.PROCESS_PATCH);
                String url = MapUtils.getStr(rtnObjc, LogConstants.LOG_URL);
                message = "在IP为:%s的设备上发现了一个%s的日志,进程名称为:%s,进程路径为:%s,访问url为:%s,日志级别:%s";
                alertName = String.format(message, devIp, logTye, processName, processPatch, url, logLevel);
                break;
            }
        }
        rtnObjc.put(LogConstants.ALERT_NAME, alertName);
    }


    private static void switchKeyValue(ConcurrentHashMap<String, Object> rtnObjc, String key, String value) {
        switch (key) {
            case "version":
                rtnObjc.put(LogConstants.LOG_VERSION, value);
                break;
            case "believe":
                rtnObjc.put(LogConstants.ACTION_RESULT, value);
                break;
            case "source_file":
                rtnObjc.put(LogConstants.LOG_FILENAME, value);
                break;
            case "task":
                rtnObjc.put(LogConstants.ACTION_TYPE, value);
                break;
            case "log_name":
                rtnObjc.put(LogConstants.LOG_TYPE, com.crc.log.flink.common.utils.StringUtils.unicodeDecode(value));
                break;
            case "log_id":
                rtnObjc.put(LogConstants.EVENT_ID, value);
                break;
            case "create_time":
                rtnObjc.put(LogConstants.LOG_START_TIME, DateUtils.getISO8601Timestamp(value.trim(), "yyyy-MM-dd HH:mm:ss"));
                break;
            case "ip":
                rtnObjc.put(LogConstants.LOG_DEV_IP, value);
                break;
            case "content":
                try {
                   JSONObject parseObject = JSONObject.parseObject(value);
                   parseObject.forEach((k,v) -> {
                       switchKeyValue(rtnObjc, k, String.valueOf(v));
                   });
                } catch (Exception e) {
                    rtnObjc.put(LogConstants.LOG_CONTENT, value);
                }
                break;
            case "name":
                String logName = MapUtils.getStr(rtnObjc, LogConstants.LOG_TYPE);
                switch (logName) {
                    case "漏洞管理":
                        rtnObjc.put(LogConstants.LOG_CONTENT, "windows uri " + com.crc.log.flink.common.utils.StringUtils.unicodeDecode(DataUtils.getSubString(value, "windows uri".length() + 1)));
                        break;
                    case "系统修复":
                    case "插件":
                        rtnObjc.put(LogConstants.ACTION, value);
                        break;
                    case "病毒分析":
                        rtnObjc.put(LogConstants.VIRUS_NAME, value);
                        break;
                    case "进程违规运行":
                        rtnObjc.put(LogConstants.PROCESS_NAME, value);
                        break;
                    case "使用违规互联网出口":
                        rtnObjc.put(LogConstants.DEVICE_NAME, value);
                        break;
                }
                break;
            case "type":
                logName = MapUtils.getStr(rtnObjc, LogConstants.LOG_TYPE);
                if (logName.equals("病毒分析")) {
                    rtnObjc.put(LogConstants.VIRUS_TYPE, value);
                } else {
                    rtnObjc.put(LogConstants.LOG_LEVEL, LevelConstants.getLevel(com.crc.log.flink.common.utils.StringUtils.unicodeDecode(value)));
                }
                break;
            case "action":
                logName = MapUtils.getStr(rtnObjc, LogConstants.LOG_TYPE);
                if (logName.equals("漏洞管理")) {
                    rtnObjc.put(LogConstants.ACTION_RESULT, com.crc.log.flink.common.utils.StringUtils.unicodeDecode(value));
                } else if (logName.equals("xp盾甲")){
                    rtnObjc.put(LogConstants.LOG_NAME, value);
                }
                break;
            case "score":
                rtnObjc.put(LogConstants.LOG_CONTENT, value);
                break;
            case "op":
                String result = "";
                if (MapUtils.getStr(rtnObjc, LogConstants.LOG_TYPE).equals("病毒分析")) {
                    rtnObjc.put(LogConstants.ACTION_RESULT, value);
                } else {
                    switch (value) {
                        case "0":
                            result = "修复";
                            break;
                        case "1":
                            result = "未处理";
                            break;
                        case "2":
                            result = "信任";
                            break;
                        case "3":
                            result = "移除信任";
                            break;
                    }
                    rtnObjc.put(LogConstants.ACTION_RESULT, result);
                }
                break;
            case "desc":
                rtnObjc.put(LogConstants.LOG_CONTENT, value);
                break;
            case "detail":
                rtnObjc.put(LogConstants.LOG_CONTENT, value);
                break;
            case "opt":
                rtnObjc.put(LogConstants.ACTION_RESULT, value);
                break;
            case "virus_path":
                rtnObjc.put(LogConstants.FILE_PATH, value);
                break;
            case "device":
                rtnObjc.put(LogConstants.DEVICE_NAME, value);
                break;
            case "path":
                rtnObjc.put(LogConstants.PROCESS_PATCH, value);
                break;
            case "device_type":
                rtnObjc.put(LogConstants.DEVICE_TYPE, value);
                break;
            case "account":
                rtnObjc.put(LogConstants.USER_NAME, value);
                break;
            case "process_name":
                rtnObjc.put(LogConstants.PROCESS_NAME, value);
                break;
            case "device_name":
                rtnObjc.put(LogConstants.DEVICE_NAME, value);
                break;
            case "computer_name":
                rtnObjc.put(LogConstants.USER_NAME, value);
                break;
            case "usb_name":
                rtnObjc.put(LogConstants.DEVICE_NAME, value);
                break;
            case "operation":
                rtnObjc.put(LogConstants.ACTION_TYPE, value);
                break;
            case "file_path":
                rtnObjc.put(LogConstants.FILE_PATH, value);
                break;
            case "sender":
                rtnObjc.put(LogConstants.EMAIL_SEND, value);
                break;
            case "recipient":
                rtnObjc.put(LogConstants.EMAIL_RECEIVER, value);
                break;
            case "oper_type":
                rtnObjc.put(LogConstants.ACTION_TYPE, value);
                break;
            case "cfg_type":
                rtnObjc.put(LogConstants.RISK_TYPE, value);
                break;
            case "process_path":
                rtnObjc.put(LogConstants.PROCESS_PATCH, value);
                break;
            case "destination_ip":
                rtnObjc.put(LogConstants.DEST_IP, value);
                break;
            case "url":
                rtnObjc.put(LogConstants.LOG_URL, value);
                break;
        }
    }
}
