package com.crc.log.flink.test.log;

import com.crc.log.flink.common.utils.JsonUtils;
import com.crc.log.flink.config.AllConfig;
import com.crc.log.flink.es.DataProcessFuncation;

import java.util.concurrent.ConcurrentHashMap;

/**
 * @author jixiangqi
 * @date 2022/5/26
 */
public class ResolvWafLogTest {

    public static void main(String[] args) {
        AllConfig config = new AllConfig();
        DataProcessFuncation.CONIFG = config;
        config.setMode("single");
        config.setParse("ResolvWafLog");
        config.setIndex("sec_all");

        String str = "{\"topic\":\"sec_all\",\"dev_ip\":\"21.10.34.31\",\"message\":\"<134>May 24 16:54:40 sjnode01 -: GUILOG(INFORMATIONAL)(id=S3JXPZL2Q7DSP1,service=guioper,server=21.10.34.12(WAF-21.10.34.12),account=admin,identity=po.wang(王坡),from=21.10.63.34,oper=<Backspace><Backspace>)\",\"type\":\"udp\",\"timestamp\":\"2022-05-24 17:13:33\"}";
        ConcurrentHashMap<String, Object> proc = DataProcessFuncation.parse(str, "index");
        JsonUtils.printStr(proc);


    }

}
