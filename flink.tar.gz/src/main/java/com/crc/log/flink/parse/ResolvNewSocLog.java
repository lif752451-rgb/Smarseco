package com.crc.log.flink.parse;

import com.alibaba.fastjson.JSONObject;
import com.crc.log.flink.common.constants.LogConstants;
import com.crc.log.flink.common.utils.DataUtils;
import com.crc.log.flink.common.utils.JsonUtils;
import com.crc.log.flink.common.utils.MapUtils;
import org.apache.commons.lang3.StringUtils;

import java.util.concurrent.ConcurrentHashMap;

/**
 * 测试类，不解析，只存储原始日志，进一步日志泛化分析
 */
public class ResolvNewSocLog {

    /**
     * windows AD 日志泛化
     */
    public static ConcurrentHashMap<String, Object> parse(String message) {
        try {
            ConcurrentHashMap<String, Object> data = proc(message);
            if (DataUtils.isNotEmptyJson(data)) {
                return data;
            }
        } catch (Exception ignored) {

        }
        return null;
    }

    private static ConcurrentHashMap<String, Object> proc(String jsonStr) {
        ConcurrentHashMap<String, Object> rtnObjc = JsonUtils.createBaseMap(jsonStr);
        JSONObject json = JsonUtils.parse(jsonStr);
        if (json.containsKey("dev_ip")) {
            rtnObjc.put(LogConstants.LOG_DEV_IP, JsonUtils.getStr(json, "dev_ip"));
            rtnObjc.put("office_id", JsonUtils.getStr(json, "officeId"));
            JSONObject message = JsonUtils.parse(JsonUtils.getStr(json, "message"));
            rtnObjc.put(LogConstants.LOG_CONTENT, JsonUtils.getStr(json, "ori_data"));
            rtnObjc.put(LogConstants.SRC_IP, JsonUtils.getStr(json, "c_src_ipv4"));
            rtnObjc.put(LogConstants.DEST_IP, JsonUtils.getStr(json, "c_dest_ipv4"));
            rtnObjc.put(LogConstants.SRC_PORT, JsonUtils.getInt(json, "c_src_port"));
            rtnObjc.put(LogConstants.DEST_PORT, JsonUtils.getInt(json, "c_dest_port"));
            if ("".equals(JsonUtils.getStr(json, "msg_type"))) {
                rtnObjc.put(LogConstants.LOG_NAME, "程序统计日志");
            } else {
                rtnObjc.put(LogConstants.ALERT_NAME, JsonUtils.getStr(json, "c_cookie") + JsonUtils.getStr(json, "c_return_info"));
                rtnObjc.put(LogConstants.LOG_NAME, "事件监测日志");
            }
        }
        rtnObjc.put(LogConstants.LOG_PRODUCT, "中资网安SOC");

        if (StringUtils.isBlank(MapUtils.getStr(rtnObjc, LogConstants.SRC_IP))) {
            rtnObjc.put(LogConstants.SRC_IP, "0.0.0.0");
        }
        if (StringUtils.isBlank(MapUtils.getStr(rtnObjc, LogConstants.DEST_IP))) {
            rtnObjc.put(LogConstants.DEST_IP, "0.0.0.0");
        }
        return rtnObjc;
    }
}
