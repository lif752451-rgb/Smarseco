package com.crc.log.flink.load;


import com.alibaba.fastjson.JSONObject;
import com.crc.log.flink.common.utils.DataUtils;
import com.crc.log.flink.common.utils.IPUtil;
import com.crc.log.flink.common.utils.JsonUtils;
import com.crc.log.flink.db.ConfBuzziMySql;
import com.crc.log.flink.net.IPBean;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.LinkedList;
import java.util.List;
import java.util.concurrent.ConcurrentHashMap;

/**
 * 用户自定义网段加载功能
 */
@Slf4j
public class NewUserSegmentLoad {
    public static final ConcurrentHashMap<String, IPBean[]> userSegMap = new ConcurrentHashMap<>();

    /**
     * 同步解析规则
     */
    public void syncAll() {
        String sql = "SELECT dict_value,dict_label FROM sys_dict_data WHERE dict_type = 'ip_config_types' AND STATUS = '0'";
        try {
            List<JSONObject> list = ConfBuzziMySql.query(sql);
            for (JSONObject rs : list) {
                String dmz = JsonUtils.getStr(rs, "dict_value");//dmz ip 10.0.70.0/24-10.0.79.0/24
                String label = JsonUtils.getStr(rs, "dict_label");
                /*
                 * 如有指定topic就使用指定topic
                 */
                if (StringUtils.isNotBlank(dmz)) {
                    syncType(dmz, label);
                }
            }
            if (NewUserSegmentLoad.userSegMap.size() < 1) {
                log.info("2022成功加载IP用户自定义网段信息数--无数据");
                return;
            }
            for (String key : NewUserSegmentLoad.userSegMap.keySet()) {
                System.out.printf("2022成功加载IP用户自定义网段信息数：%s->%d\n", key, NewUserSegmentLoad.userSegMap.get(key).length);
            }
        } catch (Exception e) {
            log.error(e.getMessage(), e);
        }
    }

    /**
     * 同步解析规则
     */
    public static void syncType(String type, String label) {
        String sql = "SELECT dict_value FROM sys_dict_data WHERE dict_type = '" + type + "' AND STATUS = '0'";
        List<IPBean> segList = new LinkedList<>();
        try {
            List<JSONObject> list = ConfBuzziMySql.query(sql);
            // 获取返回结果
            for (JSONObject rs : list) {
                try {
                    String dmz = JsonUtils.getStr(rs, "dict_value");//dmz ip 10.0.70.0/24-10.0.79.0/24
                    try {
                        List<IPBean> ipList = save2Segment(dmz, label);
                        if (ipList != null && ipList.size() > 0) {
                            segList.addAll(ipList);
                        }
                    } catch (Exception e) {
                        log.error(e.getMessage(), e);
                    }
                } catch (Exception e) {
                    log.error(e.getMessage(), e);
                }

            }

        } catch (Exception e) {
            log.error(e.getMessage(), e);
        }
        try {
            if (segList.size() > 0) {
                segList.sort(Comparator.comparingLong(IPBean::getBegin));
                IPBean[] ipBeans = segList.toArray(new IPBean[]{});
                userSegMap.put(label, ipBeans);
            }
        } catch (Exception e) {
            log.error(e.getMessage(), e);
        }
    }


    public static List<IPBean> save2Segment(String ipStr, String label) {
        if (StringUtils.isBlank(ipStr)) {
            return null;
        }
        List<IPBean> ipBeanList = new ArrayList<>();
        String[] ipList = IPUtil.getIpSegment(ipStr);
        for (String cidr : ipList) {
            try {
                long startIp2long;
                long endIp2long;
                if (cidr.contains("-") && cidr.contains("/")) {
                    String[] ips = cidr.split("-");
                    if (ips.length <= 1) {
                        continue;
                    }
                    startIp2long = IPUtil.getIp2long(getStartIp(ips[0].trim()));
                    endIp2long = IPUtil.getIp2long(getEndIp(ips[1].trim()));
                } else if (cidr.contains("-")) {
                    String[] ips = cidr.split("-");
                    if (ips.length <= 1) {
                        continue;
                    }
                    startIp2long = IPUtil.getIp2long(ips[0].trim());
                    endIp2long = IPUtil.getIp2long(ips[1].trim());
                } else if (cidr.contains("/")) {
                    startIp2long = IPUtil.getIp2long(getStartIp(cidr.trim()));
                    endIp2long = IPUtil.getIp2long(getEndIp(cidr.trim()));
                } else {
                    startIp2long = IPUtil.getIp2long(cidr.trim());
                    endIp2long = IPUtil.getIp2long(cidr.trim());
                }
                if (startIp2long > 0 && endIp2long > 0) {
                    ipBeanList.add(new IPBean(startIp2long, endIp2long, label));
                }
            } catch (Exception e) {
                log.error(e.getMessage(), e);
            }
        }
        return ipBeanList;
    }

    private static String getStartIp(String segment) {
        StringBuilder startIp = new StringBuilder();
        if (segment == null) {
            return null;
        }
        String[] arr = segment.split("/");
        String ip = arr[0];
        if (arr.length < 2) {
            log.error("ERROR getStartIp:" + segment);
            return null;
        }
        String maskIndex = arr[1];
        String mask = getNetMask(maskIndex);
        if (4 != ip.split("\\.").length || mask == null) {
            return null;
        }
        int[] ipArray = new int[4];
        int[] netMaskArray = new int[4];
        for (int i = 0; i < 4; i++) {
            try {
                ipArray[i] = DataUtils.toNum(ip.split("\\.")[i]);
                netMaskArray[i] = DataUtils.toNum(mask.split("\\.")[i]);
                if (ipArray[i] > 255 || ipArray[i] < 0 || netMaskArray[i] > 255 || netMaskArray[i] < 0) {
                    return null;
                }
                ipArray[i] = ipArray[i] & netMaskArray[i];
                if (i == 3) {
                    startIp.append(ipArray[i] + 1);
                } else {
                    startIp.append(ipArray[i]).append(".");
                }
            } catch (Exception e) {
                log.error("有错误网段数据" + e.getMessage(), e);
            }
        }
        return startIp.toString();
    }

    private static String getEndIp(String segment) {
        StringBuilder endIp = new StringBuilder();
        String startIp = getStartIp(segment);
        if (segment == null || startIp == null) {
            return null;
        }
        String[] arr = segment.split("/");
        String maskIndex = arr[1];
        //实际需要的IP个数
        int hostNumber;
        int[] startIpArray = new int[4];
        try {
            hostNumber = 1 << 32 - (DataUtils.toNum(maskIndex));
            for (int i = 0; i < 4; i++) {
                startIpArray[i] = DataUtils.toNum(startIp.split("\\.")[i]);
                if (i == 3) {
                    startIpArray[i] = startIpArray[i] - 1;
                    break;
                }
            }
            startIpArray[3] = startIpArray[3] + (hostNumber - 1);
        } catch (Exception e) {
            log.error(e.getMessage(), e);
        }

        if (startIpArray[3] > 255) {
            int k = startIpArray[3] / 256;
            startIpArray[3] = startIpArray[3] % 256;
            startIpArray[2] = startIpArray[2] + k;
        }
        if (startIpArray[2] > 255) {
            int j = startIpArray[2] / 256;
            startIpArray[2] = startIpArray[2] % 256;
            startIpArray[1] = startIpArray[1] + j;
            if (startIpArray[1] > 255) {
                int k = startIpArray[1] / 256;
                startIpArray[1] = startIpArray[1] % 256;
                startIpArray[0] = startIpArray[0] + k;
            }
        }
        for (int i = 0; i < 4; i++) {
            if (i == 3) {
                startIpArray[i] = startIpArray[i] - 1;
            }
            if ("".contentEquals(endIp) || endIp.length() == 0) {
                endIp.append(startIpArray[i]);
            } else {
                endIp.append(".").append(startIpArray[i]);
            }
        }
        return endIp.toString();
    }

    private static String getNetMask(String maskIndex) {
        StringBuilder mask = new StringBuilder();
        int inetMask;
        try {
            inetMask = DataUtils.toNum(maskIndex);
        } catch (Exception e) {
            log.error(e.getMessage());
            return null;
        }
        if (inetMask > 32) {
            return null;
        }
        // 子网掩码为1占了几个字节
        int num1 = inetMask / 8;
        // 子网掩码的补位位数
        int num2 = inetMask % 8;
        int[] array = new int[4];
        for (int i = 0; i < num1; i++) {
            array[i] = 255;
        }
        for (int i = num1; i < 4; i++) {
            array[i] = 0;
        }
        for (int i = 0; i < num2; num2--) {
            array[num1] += 1 << 8 - num2;
        }
        for (int i = 0; i < 4; i++) {
            if (i == 3) {
                mask.append(array[i]);
            } else {
                mask.append(array[i]).append(".");
            }
        }
        return mask.toString();
    }
}
