package com.crc.log.flink.common.utils;

import com.alibaba.fastjson.JSONObject;
import lombok.extern.slf4j.Slf4j;

import java.io.BufferedReader;
import java.io.FileReader;
import java.util.Enumeration;
import java.util.Properties;
@Slf4j
public class PropertiesUtils {
    public static JSONObject getProperties(String filePath) {
        Properties properties = new Properties();
        BufferedReader bufferedReader = null;
        JSONObject json = new JSONObject();
        try {
            bufferedReader = new BufferedReader(new FileReader(filePath));
            properties.load(bufferedReader);
            Enumeration<?> e = properties.propertyNames();
            while (e.hasMoreElements()) {
                String key = (String) e.nextElement();
                String value = properties.getProperty(key);
                json.put(key, value);
            }
        } catch (Exception e) {
            log.error(e.getMessage(), e);
        } finally {
            try {
                if (bufferedReader != null) {
                    bufferedReader.close();
                }
            } catch (Exception e) {

            }
        }

        return json;
    }
}
