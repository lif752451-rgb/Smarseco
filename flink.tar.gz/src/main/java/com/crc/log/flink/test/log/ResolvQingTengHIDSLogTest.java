package com.crc.log.flink.test.log;

import com.crc.log.flink.common.utils.JsonUtils;
import com.crc.log.flink.config.AllConfig;
import com.crc.log.flink.es.DataProcessFuncation;

import java.util.concurrent.ConcurrentHashMap;

/**
 * @author jixiangqi
 * @date 2022/5/25
 */
public class ResolvQingTengHIDSLogTest {

    public static void main(String[] args) {
        AllConfig config = new AllConfig();
        DataProcessFuncation.CONIFG = config;
        config.setMode("single");
        config.setParse("ResolvQingTengHIDSLog");
        config.setIndex("sec_all");


        String str = "<182>May 25 09:53:05 localhost.localdomain qtAlert[280] datatype=\"web_command\" datatime=\"1653443585\" agent_ip=\"10.128.12.133\" host_name=\"localhost.localdomain\" internal_ip=\"10.128.12.133\" external_ip=\"\" host_tag=\"\" host_memo=\"\" group_name=\"未分组主机\" action=\"add\" type=\"monitor\" group=\"1\" agent_id=\"626e86127b189af6\" comid=\"52633543466565416474\" event_type=\"web_command\" event_name=\"linux web命令执行\" event_level=\"info\" event_content=\"java进程发现异常执行行为，其进程树为：java(8548)-&gt;arp(41387)\" url=\"http://10.0.9.27//next/#/intrusion/webcommand-linux?search=%7B%22createTime%22%3A%7B%22min%22%3A%222022-05-25%2009%3A53%3A04%22%2C%22max%22%3A%222022-05-25%2009%3A53%3A06%22%7D%2C%22group%22%3A%5B1%5D%2C%22ip%22%3A%2210.128.12.133%22%2C%22description%22%3A%22java%E8%BF%9B%E7%A8%8B%E5%8F%91%E7%8E%B0%E5%BC%82%E5%B8%B8%E6%89%A7%E8%A1%8C%E8%A1%8C%E4%B8%BA%EF%BC%8C%E5%85%B6%E8%BF%9B%E7%A8%8B%E6%A0%91%E4%B8%BA%EF%BC%9Ajava(8548)-%3Earp(41387)%22%2C%22hostname%22%3A%22localhost.localdomain%22%7D\" detail.process_name=\"java\" detail.process_tree=\"systemd(1)-&gt;java(8548)-&gt;arp(41387)\" detail.hit_rule_name=\"spring执行系统命令\"";
        ConcurrentHashMap<String, Object> proc = DataProcessFuncation.parse(str, "index");
        JsonUtils.printStr(proc);

        str = "<182>May 25 09:50:54 localhost.localdomain qtAlert[328] datatype=\"access_log\" datatime=\"1653443522\" agent_ip=\"10.0.125.3\" host_name=\"localhost.localdomain\" internal_ip=\"10.0.125.3\" external_ip=\"\" host_tag=\"\" host_memo=\"\" group_name=\"内购平台\" severity=\"0\" action=\"add\" type=\"monitor\" group=\"3\" agent_id=\"626636db7b189964\" comid=\"52633543466565416474\" os=\"linux\" log_type=\"1\" src_ip=\"10.0.125.1\" location=\"局域网\" pname=\"sshd\" pid=\"75514\" uname=\"zjhc\" port=\"22\" login_con_port=\"48164\" login_type=\"password\" login_err_reason=\"-1\" logout_reason=\"-1\"";
        proc = DataProcessFuncation.parse(str, "index");
        JsonUtils.printStr(proc);
    }

}
