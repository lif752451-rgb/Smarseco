package com.crc.log.flink.parse;

import com.crc.log.flink.common.constants.LevelConstants;
import com.crc.log.flink.common.constants.LogConstants;
import com.crc.log.flink.common.utils.*;
import org.apache.commons.lang3.StringUtils;

import java.util.List;
import java.util.concurrent.ConcurrentHashMap;

/**
 * @author jixiangqi
 * @date 2022/3/24
 * 竹子云ldap
 *
 */
public class ResolvBAMVLog {
    public static ConcurrentHashMap<String, Object> parse(String message) {
        try {
            ConcurrentHashMap<String, Object> data = proc(message);
            if (DataUtils.isNotEmptyJson(data)) {
                return data;
            }
        } catch (Exception ignored) {

        }
        return null;
    }

    private static ConcurrentHashMap<String, Object> proc(String jsonStr) {
        ConcurrentHashMap<String, Object> rtnObjc = JsonUtils.createBaseMap(jsonStr);
        List<String> bracketsData = RegUtils.getBracketsData(jsonStr);
        for (String temp : bracketsData) {
            String[] split = DataUtils.getSplit(temp, ",");
            for (String tempStr : split) {
                int index = DataUtils.getIndex(tempStr, ":");
                String key = DataUtils.getSubString(tempStr, 0, index).replaceAll("\"", "");
                String value = DataUtils.getSubString(tempStr, index + 1).replaceAll("\"", "");
                switchKeyValue(rtnObjc, key, value);
            }
        }

        rtnObjc.put(LogConstants.LOG_PRODUCT, "竹云ldap");
        rtnObjc.put(LogConstants.LOG_LEVEL, LevelConstants.getLevel(MapUtils.getStr(rtnObjc,LogConstants.LOG_LEVEL)));
        if (StringUtils.isBlank(MapUtils.getStr(rtnObjc, LogConstants.SRC_IP))) {
            rtnObjc.put(LogConstants.SRC_IP, "0.0.0.0");
        }
        if (StringUtils.isBlank(MapUtils.getStr(rtnObjc, LogConstants.DEST_IP))) {
            rtnObjc.put(LogConstants.DEST_IP, "0.0.0.0");
        }
        setAlertName(rtnObjc);
        return rtnObjc;
    }

    private static void setAlertName(ConcurrentHashMap<String, Object> rtnObjc) {
        String messageFormat = "用户名为:%s在IP为:%s的设备上进行了%s操作,操作结果为:%s,日志详情为:%s";
        String alertName = "";
        String srcIp = MapUtils.getStr(rtnObjc, LogConstants.SRC_IP);
        String action = MapUtils.getStr(rtnObjc, LogConstants.ACTION_TYPE);
        String log = MapUtils.getStr(rtnObjc, LogConstants.LOG_ORI_MSG);
        String protocal = MapUtils.getStr(rtnObjc, LogConstants.LOG_PROTOCAL);
        String userName = MapUtils.getStr(rtnObjc, LogConstants.USER_NAME);
        String result = MapUtils.getStr(rtnObjc, LogConstants.ACTION_RESULT);
        if (StringUtils.isNotBlank(protocal)) {
            messageFormat = "用户名为:%s在IP为:%s的设备上进行了%s操作,操作结果为:%s,访问协议为:%s,日志详情为:%s";
            alertName = String.format(messageFormat, userName, srcIp, action, result, protocal, log);
        } else {
            alertName = String.format(messageFormat, userName, srcIp, action, result, log);
        }
        rtnObjc.put(LogConstants.ALERT_NAME, alertName);
    }

    private static void switchKeyValue(ConcurrentHashMap<String, Object> rtnObjc, String key, String value) {
        switch (key.trim()) {
            case "userId":
                rtnObjc.put(LogConstants.USER_NAME, value.trim());
                break;
            case "result":
                rtnObjc.put(LogConstants.ACTION_RESULT, value.trim());
                break;
            case "vistorIP":
                rtnObjc.put(LogConstants.SRC_IP, value.trim());
                break;
            case "createTime":
                rtnObjc.put(LogConstants.LOG_START_TIME, DateUtils.getISO8601Timestamp(value.trim(), "yyyy-MM-dd HH:mm:ss"));
                break;
            case "action":
                rtnObjc.put(LogConstants.ACTION_TYPE, value.trim());
                break;
            case "protocol":
                rtnObjc.put(LogConstants.LOG_PROTOCAL, value.trim());
                break;
            case "loginTime":
                rtnObjc.put(LogConstants.LOG_START_TIME, DateUtils.getISO8601Timestamp(value.trim(), "yyyy-MM-dd HH:mm:ss"));
                break;
            case "clientIp":
                rtnObjc.put(LogConstants.SRC_IP, value.trim());
                break;
        }
    }
}
