package com.crc.log.flink.parse;

import com.alibaba.fastjson.JSONObject;
import com.crc.log.flink.common.constants.LevelConstants;
import com.crc.log.flink.common.constants.LogConstants;
import com.crc.log.flink.common.utils.DataUtils;
import com.crc.log.flink.common.utils.JsonUtils;
import com.crc.log.flink.common.utils.MapUtils;
import org.apache.commons.lang3.StringUtils;

import java.util.concurrent.ConcurrentHashMap;

/**
 * 天擎解析类
 */
public class ResolvTqLog {
    /**
     * 通用日志 日志泛化
     */
    public static ConcurrentHashMap<String,Object> parse(String message) {
        try {
            ConcurrentHashMap<String,Object> data = proc(message);
            if (DataUtils.isNotEmptyJson(data)) {
                return data;
            }
        } catch (Exception ignored) {

        }
        return null;
    }

    private static ConcurrentHashMap<String,Object> proc(String jsonStr) {
        jsonStr = com.crc.log.flink.common.utils.StringUtils.unicodeDecode(jsonStr);
        ConcurrentHashMap<String,Object> rtnObjc = JsonUtils.createBaseMap(jsonStr);
        jsonStr = DataUtils.getSubString(jsonStr, DataUtils.getIndex(jsonStr, "{"), jsonStr.length());
                //jsonStr.substring(jsonStr.indexOf("{"));
        if (StringUtils.isNotBlank(jsonStr)) {
            jsonStr = DataUtils.getSubString(jsonStr, 0, DataUtils.getLastIndex(jsonStr, "}")+1);
                    //jsonStr.substring(0, jsonStr.lastIndexOf("}") + 1);
        }
        if (StringUtils.isBlank(jsonStr)) {
            return rtnObjc;
        }
        JSONObject jObj = JsonUtils.parse(jsonStr);
        MapUtils.setStr(rtnObjc, LogConstants.SRC_IP, jObj, "ip");
        MapUtils.setStr(rtnObjc, LogConstants.INTERNAL_IP, jObj, "report_ip");
        MapUtils.setStr(rtnObjc, LogConstants.LOG_NAME, jObj, "log_name");
        MapUtils.setStr(rtnObjc, LogConstants.MSG_CONTENT, jObj, "content");
        if (jObj.containsKey("content")) {
            JSONObject jsonObject = jObj.getJSONObject("content");
            MapUtils.setStr(rtnObjc, LogConstants.ACTION_TYPE, jsonObject, "action");
            String type = JsonUtils.getStr(jsonObject, "type");
            MapUtils.setStr(rtnObjc, LogConstants.LOG_LEVEL, LevelConstants.INFO);
            if (type.contains("高危")) {
                MapUtils.setStr(rtnObjc, LogConstants.LOG_LEVEL, LevelConstants.HIGH);
            } else if (type.contains("中危")) {
                MapUtils.setStr(rtnObjc, LogConstants.LOG_LEVEL, LevelConstants.MEDIUM);
            }
            MapUtils.setStr(rtnObjc, LogConstants.BEHAVIOR_TAG, jsonObject, "name");

            if (jsonObject.containsKey("desc")) {
                MapUtils.setStr(rtnObjc, LogConstants.LOG_DESCRIPTION, jsonObject, "desc");
            }
            if (jsonObject.containsKey("opt")) {
                MapUtils.setStr(rtnObjc, LogConstants.ACTION_RESULT, jsonObject, "opt");
            }
            if (jsonObject.containsKey("detail")) {
                MapUtils.setStr(rtnObjc, LogConstants.LOG_DESCRIPTION, jsonObject, "detail");
            }
            if (jsonObject.containsKey("type")) {
                MapUtils.setStr(rtnObjc, LogConstants.ACTION_TYPE, jsonObject, "type");
            }
            if (jsonObject.containsKey("op")) {
                MapUtils.setStr(rtnObjc, LogConstants.ACTION_RESULT, jsonObject, "op");
            }
            if (jsonObject.containsKey("virus_path")) {
                MapUtils.setStr(rtnObjc, LogConstants.LOG_DESCRIPTION, String.format("%s 存在 %s", JsonUtils.getStr(jsonObject, "virus_path"), JsonUtils.getStr(jsonObject, "name")));
            }
            if(jsonObject.containsKey("internet_ip")){
                MapUtils.setStr(rtnObjc, LogConstants.LOG_DESCRIPTION, jsonObject, "internet_ip");
            }
            if(jsonObject.containsKey("device_name")){
                MapUtils.setStr(rtnObjc, LogConstants.LOG_DESCRIPTION, jsonObject, "device_name");
            }
            if(jsonObject.containsKey("operation") && MapUtils.isBlank(rtnObjc,LogConstants.LOG_DESCRIPTION)){
                MapUtils.setStr(rtnObjc, LogConstants.LOG_DESCRIPTION, jsonObject, "operation");
            }
            if(jsonObject.containsKey("account_type") && jsonObject.containsKey("account") && MapUtils.isBlank(rtnObjc,LogConstants.LOG_DESCRIPTION)){
                MapUtils.setStr(rtnObjc, LogConstants.LOG_DESCRIPTION, jsonObject, "account");
            }
            if(jsonObject.containsKey("source_file") && jsonObject.containsKey("destination_file") && MapUtils.isBlank(rtnObjc,LogConstants.LOG_DESCRIPTION)){
                MapUtils.setStr(rtnObjc, LogConstants.LOG_DESCRIPTION, String.format("源文件%s,目标文件%s", JsonUtils.getStr(jsonObject, "source_file"), JsonUtils.getStr(jsonObject, "destination_file")));
            }
            if(jsonObject.containsKey("printer") && jsonObject.containsKey("file_path") && MapUtils.isBlank(rtnObjc,LogConstants.LOG_DESCRIPTION)){
                MapUtils.setStr(rtnObjc, LogConstants.LOG_DESCRIPTION, String.format("%s打印%s", JsonUtils.getStr(jsonObject, "printer"), JsonUtils.getStr(jsonObject, "file_path")));
            }
            if(jsonObject.containsKey("process_name") && jsonObject.containsKey("url") && MapUtils.isBlank(rtnObjc,LogConstants.LOG_DESCRIPTION)){
                MapUtils.setStr(rtnObjc, LogConstants.LOG_DESCRIPTION, String.format("%s访问%s", JsonUtils.getStr(jsonObject, "process_name"), JsonUtils.getStr(jsonObject, "url")));
            }
        }

        String action = MapUtils.getStr(rtnObjc, LogConstants.BEHAVIOR_TAG);
        if (org.apache.commons.lang3.StringUtils.isBlank(action) || rtnObjc.containsKey(LogConstants.LOG_DESCRIPTION)) {
            action = MapUtils.getStr(rtnObjc, LogConstants.LOG_DESCRIPTION);
        }
        if (org.apache.commons.lang3.StringUtils.isBlank(action)) {
            action = MapUtils.getStr(rtnObjc, LogConstants.LOG_NAME);
        }
        String alertName = String.format("%s %s %s - %s [%s],日志详情为:%s",
                MapUtils.getStr(rtnObjc, LogConstants.LOG_NAME),
                MapUtils.getStr(rtnObjc, LogConstants.SRC_IP),
                MapUtils.getStr(rtnObjc, LogConstants.ACTION_TYPE),
                MapUtils.getStr(rtnObjc, LogConstants.LOG_LEVEL),
                action,
                MapUtils.getStr(rtnObjc, LogConstants.LOG_ORI_MSG));
        MapUtils.setStr(rtnObjc, LogConstants.ALERT_NAME, alertName);
        rtnObjc.put(LogConstants.LOG_PRODUCT, "奇安信天擎");
        rtnObjc.put(LogConstants.LOG_LEVEL, LevelConstants.getLevel(MapUtils.getStr(rtnObjc,LogConstants.LOG_LEVEL)));
        if (StringUtils.isBlank(MapUtils.getStr(rtnObjc, LogConstants.SRC_IP))) {
            rtnObjc.put(LogConstants.SRC_IP, "0.0.0.0");
        }
        if (StringUtils.isBlank(MapUtils.getStr(rtnObjc, LogConstants.DEST_IP))) {
            rtnObjc.put(LogConstants.DEST_IP, "0.0.0.0");
        }
        return rtnObjc;

    }

}
