package com.crc.log.flink.test.log;

import com.crc.log.flink.common.utils.JsonUtils;
import com.crc.log.flink.config.AllConfig;
import com.crc.log.flink.es.DataProcessFuncation;

import java.util.concurrent.ConcurrentHashMap;

public class GuoceHoneyTest {
    public static void main(String[] args) {
        String msg = "<132> 2022-03-30T20:15:16+08:00 localhost.localdomain YJHP_Server[114539]: level=\"warning\" agentIp=\"192.168.0.104\" attackerIp=\"192.168.0.100\" dstPort=\"443\" eventType=\"honeyPotAccess\" honeypotName=\"华润集团 VPN(反制)蜜罐\" protocol=\"https\" type=\"event\"\n";
        AllConfig config = new AllConfig();
        DataProcessFuncation.CONIFG = config;
        config.setMode("single");
        config.setParse("ResolvGuoceHoneyLog");
        config.setIndex("sec_all");
        ConcurrentHashMap<String, Object> x = DataProcessFuncation.parse(msg, "sec_all");
        JsonUtils.printStr(x);

        String str = "132> 2022-03-30T20:08:23+08:00 localhost.localdomain YJHP_Server[114539]: level=\"warning\" agentIp=\"192.168.0.104\" attackerIp=\"192.168.0.108\" dstPort=\"60411\" eventType=\"portScan\" honeypotName=\"\" protocol=\"UDP\" type=\"event\"";
        ConcurrentHashMap<String, Object> proc = DataProcessFuncation.parse(str,"index");
        JsonUtils.printStr(proc);
    }
}
