package com.crc.log.flink.parse;

import com.crc.log.flink.common.constants.LogConstants;
import com.crc.log.flink.common.utils.DataUtils;
import com.crc.log.flink.common.utils.DateUtils;
import com.crc.log.flink.common.utils.JsonUtils;
import com.crc.log.flink.common.utils.MapUtils;
import org.apache.commons.lang3.StringUtils;

import java.util.HashMap;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

/**
 * @author jixianqqi
 * @date 2021/12/7
 * 启明星辰IPS
 */
public class ResolvQmxcIpsLog {
    public static ConcurrentHashMap<String,Object> parse(String message) {
        try {
            ConcurrentHashMap<String,Object> data = proc(message);
            if (DataUtils.isNotEmptyJson(data)) {
                return data;
            }
        } catch (Exception ignored) {

        }
        return null;
    }

    private static ConcurrentHashMap<String,Object> proc(String jsonStr) {
        ConcurrentHashMap<String,Object> rtnObjc = JsonUtils.createBaseMap(jsonStr);
        int index = DataUtils.getIndex(jsonStr, "IPS");
                //jsonStr.indexOf("IPS");
        if (index > -1) {
            jsonStr = DataUtils.getSubString(jsonStr, index+4).trim();
                    //jsonStr.substring(index+4).trim();
            Map<String, String> stringMap = splitBySpace(jsonStr);
            String srcIpVer = DataUtils.getString(stringMap,"SrcIPVer");
            String dstIPVer = DataUtils.getString(stringMap,"DstIPVer");
            if (srcIpVer.equals("4")) {
                rtnObjc.put(LogConstants.SRC_IP, stringMap.get("SrcIP"));
            } else if (srcIpVer.equals("6")) {
                rtnObjc.put(LogConstants.SRC_IP, stringMap.get("SrcIP6"));
            }
            if (dstIPVer.equals("4")) {
                rtnObjc.put(LogConstants.DEST_IP, stringMap.get("DstIP"));
            } else if (dstIPVer.equals("6")) {
                rtnObjc.put(LogConstants.DEST_IP, stringMap.get("DstIP6"));
            }
            stringMap.forEach((key, value) -> {
                switch (key) {
                    case "SerialNum":
                        rtnObjc.put(LogConstants.SERIAL_NUMBER, value);
                        break;
                    case "GenTime":
                        rtnObjc.put(LogConstants.LOG_START_TIME, DateUtils.getISO8601Timestamp(value, "yyyy-MM-dd HH:mm:ss"));
                        break;
                    /*case "SrcIP":
                        rtnObjc.put(LogConstants.SRC_IP, value);
                        break;*/
                   /* case "DstIP":
                        rtnObjc.put(LogConstants.DEST_IP, value);
                        break;*/
                    case "Protocol":
                        rtnObjc.put(LogConstants.LOG_PROTOCAL, value);
                        break;
                    case "SrcPort":
                        rtnObjc.put(LogConstants.SRC_PORT, value);
                        break;
                    case "DstPort":
                        rtnObjc.put(LogConstants.DEST_PORT, value);
                        break;
                    case "SMAC":
                        rtnObjc.put(LogConstants.SRC_MAC, value);
                        break;
                    case "EventID":
                        rtnObjc.put(LogConstants.EVENT_ID, value);
                        break;
                    case "EventLevel":
                        String level = "";
                        switch (value) {
                            case "0":
                                level = "信息";
                                break;
                            case "1":
                                level = "通知";
                                break;
                            case "2":
                                level = "警示";
                                break;
                            case "3":
                                level = "告警";
                                break;
                        }
                        rtnObjc.put(LogConstants.LOG_LEVEL, level);
                        break;
                    case "SecurityType":
                        rtnObjc.put(LogConstants.LOG_TYPE, value);
                        break;
                    case "Action":
                        rtnObjc.put(LogConstants.ACTION_TYPE, value);
                        break;
                    case "Content":
                        rtnObjc.put(LogConstants.LOG_CONTENT, value);
                        break;
                    case "EvtCount":
                        rtnObjc.put(LogConstants.LOG_COUNT, value);
                        break;
                    /*case "SrcIP6":
                        rtnObjc.put(LogConstants.SRC_IP, value);
                        break;
                    case "DstIP6":
                        rtnObjc.put(LogConstants.DEST_IP, value);*/
                }
            });
        }
        rtnObjc.put(LogConstants.LOG_PRODUCT, "启明星辰IPS");
        if (StringUtils.isBlank(MapUtils.getStr(rtnObjc, LogConstants.SRC_IP))) {
            rtnObjc.put(LogConstants.SRC_IP, "0.0.0.0");
        }
        if (StringUtils.isBlank(MapUtils.getStr(rtnObjc, LogConstants.DEST_IP))) {
            rtnObjc.put(LogConstants.DEST_IP, "0.0.0.0");
        }
        setAlertName(rtnObjc);
        return rtnObjc;
    }

    private static Map<String, String> splitBySpace(String jsonStr) {
        Map<String, String> map = new HashMap<>();
        String[] s = DataUtils.getSplit(jsonStr, " ");
                //jsonStr.split(" ");
        String index = "";
        for (String item : s) {
            String temp = item;
            if (temp.contains("\"")) {
                temp = temp.replaceAll("\"", "");
            }
            if (temp.contains("=")) {
                int num = DataUtils.getIndex(temp, "=");
                //temp.indexOf("=");
                String key = DataUtils.getSubString(temp, 0, num);
                //temp.substring(0, num);
                String value = DataUtils.getSubString(temp, num + 1);
                //temp.substring(num+1);
                map.put(key, value);
                index = key;
            } else {
                StringBuilder sb = new StringBuilder();
                if (map.size() != 0) {
                    sb = new StringBuilder(map.get(index));
                }
                sb.append(" ").append(temp);
                map.put(index, sb.toString());
            }
        }
        return map;
    }

    private static void setAlertName(ConcurrentHashMap<String,Object> rtnObjc) {
        String srcIp = MapUtils.getStr(rtnObjc, LogConstants.SRC_IP);
        String destIp = MapUtils.getStr(rtnObjc, LogConstants.DEST_IP);
        String actionType = MapUtils.getStr(rtnObjc, LogConstants.ACTION_TYPE);
        String eventType = MapUtils.getStr(rtnObjc, LogConstants.LOG_TYPE);
        String logCount = MapUtils.getStr(rtnObjc, LogConstants.LOG_COUNT);
        String level = MapUtils.getStr(rtnObjc, LogConstants.LOG_LEVEL);
        String content = MapUtils.getStr(rtnObjc, LogConstants.LOG_CONTENT);
        String log = MapUtils.getStr(rtnObjc, LogConstants.LOG_ORI_MSG);
        String msgFormat = "IP:%s对IP:%s发起了一个%s类型的攻击,事件类型为:%s,出现次数为:%s,事件级别为:%s,具体内容为:%s,日志详情为:%s";
        String alertName =  String.format(msgFormat, srcIp, destIp, actionType, eventType, logCount, level, content, log);
        rtnObjc.put(LogConstants.ALERT_NAME, alertName);
    }
}
