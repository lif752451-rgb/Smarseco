package com.crc.log.flink.es;

import lombok.extern.slf4j.Slf4j;
import org.apache.flink.streaming.connectors.elasticsearch.ActionRequestFailureHandler;
import org.apache.flink.streaming.connectors.elasticsearch.RequestIndexer;
import org.apache.flink.util.ExceptionUtils;
import org.apache.http.ConnectionClosedException;
import org.elasticsearch.ElasticsearchParseException;
import org.elasticsearch.action.ActionRequest;
import org.elasticsearch.common.util.concurrent.EsRejectedExecutionException;
import org.elasticsearch.index.engine.VersionConflictEngineException;

import java.net.SocketTimeoutException;

@Slf4j
public class ActionRequestFailureHandlerImpl implements ActionRequestFailureHandler {

    @Override
    public void onFailure(ActionRequest action, Throwable failure, int restStatusCode, RequestIndexer indexer) throws Throwable {
        // 异常1: ES队列满了(Reject异常)，放回队列
        if (ExceptionUtils.findThrowable(failure, EsRejectedExecutionException.class).isPresent()) {
            indexer.add(action);
            // 异常2: ES超时异常(timeout异常)，放回队列
        } else if (ExceptionUtils.findThrowable(failure, SocketTimeoutException.class).isPresent()) {
            indexer.add(action);
            // 异常3: ES语法异常，丢弃数据，记录日志
        } else if (ExceptionUtils.findThrowable(failure, ConnectionClosedException.class).isPresent() || ExceptionUtils.findThrowable(failure,InterruptedException.class).isPresent()) {
            //indexer.add(action);
            // 异常4: ES客户端长时间连接，服务端超时关闭，或中断
        } else if (ExceptionUtils.findThrowable(failure, ElasticsearchParseException.class).isPresent()) {
            log.error("Sink to es ElasticsearchParseException ,exceptionData: {} ,exceptionMsg:{},exceptionStackTrace: {}",action.toString(), failure.getMessage(), failure);
        } else if (ExceptionUtils.findThrowable(failure, VersionConflictEngineException.class).isPresent()) {
            // ES更新版本冲突 错误
            log.error("Sink to es ElasticsearchParseException ,exceptionData: {} ,exceptionMsg:{},exceptionStackTrace: {}",action.toString(), failure.getMessage(), failure);
        } else {
            // 异常4: 其他异常，丢弃数据，记录日志
            log.error("Sink to es OtherException ,exceptionData: {} ,exceptionMsg:{},exceptionStackTrace: {}",action.toString(), failure.getMessage(), failure);
        }
    }
}
