package com.crc.log.flink.parse;

import com.alibaba.fastjson.JSONObject;
import com.crc.log.flink.common.constants.LevelConstants;
import com.crc.log.flink.common.constants.LogConstants;
import com.crc.log.flink.common.constants.NtaConstants;
import com.crc.log.flink.common.utils.DataUtils;
import com.crc.log.flink.common.utils.JsonUtils;
import com.crc.log.flink.common.utils.MapUtils;
import com.crc.log.flink.common.utils.ScoreUtils;
import org.apache.commons.lang3.StringUtils;

import java.util.concurrent.ConcurrentHashMap;

public class ResolvNtaSecLog {

    /**
     * 通用日志 日志泛化
     */
    public static ConcurrentHashMap<String, Object> parse(String message) {
        try {
            ConcurrentHashMap<String, Object> data = proc(message);
            if (DataUtils.isNotEmptyJson(data)) {
                return data;
            }
        } catch (Exception ignored) {

        }
        return null;
    }

    private static ConcurrentHashMap<String, Object> proc(String msg) {
        ConcurrentHashMap<String, Object> rtnObjc = JsonUtils.createBaseMap(msg);
        if (StringUtils.isNotBlank(msg) && msg.contains("{")) {
            msg = DataUtils.getSubString(msg, DataUtils.getIndex(msg, "{"));
                    //msg.substring(msg.indexOf("{"));
            msg = DataUtils.getSubString(msg, 0, DataUtils.getLastIndex(msg, "}")+1);
                    //msg.substring(0, msg.lastIndexOf("}") + 1);
            if (StringUtils.isBlank(msg)) {
                return rtnObjc;
            }
            JSONObject json = JsonUtils.parse(msg);
            if (!json.isEmpty()) {
                ConcurrentHashMap<String,Object> retJson = parseEvent(json);
                int event_severity = JsonUtils.getInt(json, "event_severity");
                retJson.put(LogConstants.LOG_LEVEL, "低风险");
                if (event_severity > 2) {
                    retJson.put(LogConstants.LOG_LEVEL, "高风险");
                } else if (event_severity > 1) {
                    retJson.put(LogConstants.LOG_LEVEL, "中风险");
                }
                ScoreUtils.sipScore(retJson);
                rtnObjc.putAll(retJson);
                return rtnObjc;
            }
        }
        rtnObjc.put(LogConstants.LOG_LEVEL, LevelConstants.getLevel(MapUtils.getStr(rtnObjc,LogConstants.LOG_LEVEL)));
        if (StringUtils.isBlank(MapUtils.getStr(rtnObjc, LogConstants.SRC_IP))) {
            rtnObjc.put(LogConstants.SRC_IP, "0.0.0.0");
        }
        if (StringUtils.isBlank(MapUtils.getStr(rtnObjc, LogConstants.DEST_IP))) {
            rtnObjc.put(LogConstants.DEST_IP, "0.0.0.0");
        }
        rtnObjc.put(LogConstants.LOG_PRODUCT, "绿盟UTS");
        return rtnObjc;

    }

    private static ConcurrentHashMap<String,Object> parseEvent(JSONObject data) {
        JSONObject retJson = new JSONObject();
        JsonUtils.copyField(data, retJson, "zlog_ori_msg", LogConstants.LOG_ORI_MSG);
        JsonUtils.copyField(data, retJson, "source_endpoint_ip", LogConstants.SRC_IP);
        String srcIp = JsonUtils.getStr(retJson, LogConstants.SRC_IP);
        JsonUtils.copyField(data, retJson, "destination_endpoint_ip", LogConstants.DEST_IP);
        JsonUtils.copyField(data, retJson, "vendor_device_ip", LogConstants.LOG_DEV_IP);
        JsonUtils.copyField(data, retJson, "destination_endpoint_port", LogConstants.DEST_PORT);
        JsonUtils.copyField(data, retJson, "source_endpoint_port", LogConstants.SRC_PORT);

        JsonUtils.copyField(data, retJson, "event_name", LogConstants.LOG_NAME);
        JsonUtils.copyField(data, retJson, "event_description", LogConstants.LOG_DESCRIPTION);
        JsonUtils.copyField(data, retJson, "event_type_source", LogConstants.LOG_TYPE);
        JsonUtils.copyField(data, retJson, "event_subtype_source", LogConstants.ACTION_TYPE);
        JsonUtils.copyField(data, retJson, "office_id", "office_id");
        if (JsonUtils.containsKey(retJson, "dev_ip")) {
            JsonUtils.copyField(retJson, "vendor_device_ip", "dev_ip");
        }
        JsonUtils.setStr(retJson, "event_typeA_label", NtaConstants.getEventType(JsonUtils.getStr(data, "event_typeA")));
        JsonUtils.setStr(retJson, "event_severity_label", NtaConstants.getEventSeverity(JsonUtils.getStr(data, "event_severity")));
        JsonUtils.setStr(retJson, "event_phase_label", NtaConstants.getEventPhase(JsonUtils.getStr(data, "event_phase")));
        JsonUtils.setStr(retJson, "event_result_label", NtaConstants.getEventResult(JsonUtils.getStr(data, "event_result")));

        String destIp = JsonUtils.getStr(retJson, LogConstants.DEST_IP);
        String logName = JsonUtils.getStr(retJson, LogConstants.LOG_NAME);
        String desc = JsonUtils.getStr(retJson, LogConstants.LOG_DESCRIPTION);
        String log = JsonUtils.getStr(retJson, LogConstants.LOG_ORI_MSG);
        String alertName = String.format("%s 对 %s 进行 %s,%s,日志详情为:%s", srcIp, destIp, logName, desc, log);
        retJson.put(LogConstants.ALERT_NAME, alertName);
        return new ConcurrentHashMap<>(retJson);
    }
}
