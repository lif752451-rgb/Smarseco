package com.crc.log.flink.test.log;

import com.crc.log.flink.common.utils.JsonUtils;
import com.crc.log.flink.config.AllConfig;
import com.crc.log.flink.es.DataProcessFuncation;

import java.util.concurrent.ConcurrentHashMap;

/**
 * @author jixiangqi
 * @date 2021/12/13
 */
public class ResolvKafkaLogTest {

    public static void main(String[] args) {
        AllConfig config = new AllConfig();
        DataProcessFuncation.CONIFG = config;
        config.setMode("single");
        config.setParse("ResolvKafkaLog");
        config.setIndex("sec_all");


        /*String str = "{\n" +
                "\"@timestamp\":\"2021-12-10T01:04:28.295Z\",\n" +
                "\"beat\":{\n" +
                "\"hostname\":\"pisyslog03\",\n" +
                "\"name\":\"pisyslog03\",\n" +
                "\"version\":\"5.5.1\"\n" +
                "},\n" +
                "\"input_type\":\"log\",\n" +
                "\"message\":\"Dec 10 09:04:23 192.168.101.203 time=2021-12-10 07:38:33;log_type=ips;danger_degree=2;breaking_sighn=0;event=[10505]NTP ntpd monlist Query Reflection 拒绝服务漏洞(CVE-2013-5211);src_addr=XXX.XXX.XXX.XXX;src_port=44323;dst_addr=XXX.XXX.XXX.XXX;dst_port=123;user=null;smt_user=null;proto=NTP;\",\n" +
                "\"offset\":8133,\n" +
                "\"source\":\"/wls/applogs/logstash/syslog.log\",\n" +
                "\"type\":\"log\"\n" +
                "}";
        JSONObject proc = DataProcessFuncation.parse(str,"index");
        JsonUtils.printStr(proc);*/


        String str = "{\"@timestamp\":\"2021-12-10T00:49:47.262Z\",\"beat\":{\"hostname\":\"pisyslog03\",\"name\":\"pisyslog03\",\"version\":\"5.5.1\"},\"input_type\":\"log\",\"message\":\"Dec 10 08:49:44 58.2.2.241 ddddddd\",\"offset\":15543,\"source\":\"/wls/applogs/logstash/syslog.log\",\"type\":\"log\"}";
        //str = "<134>Nov 26 10:39:49 koalii00 SVS_ML [121233]:[INFO] df df aa df f f f f ad  d d d d d ";
        ConcurrentHashMap<String, Object> proc = DataProcessFuncation.parse(str,"index");
        JsonUtils.printStr(proc);
    }

}
