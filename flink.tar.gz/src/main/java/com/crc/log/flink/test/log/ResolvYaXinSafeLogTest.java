package com.crc.log.flink.test.log;

import com.crc.log.flink.common.utils.JsonUtils;
import com.crc.log.flink.config.AllConfig;
import com.crc.log.flink.es.DataProcessFuncation;

import java.util.concurrent.ConcurrentHashMap;

/**
 * @author jixiangqi
 * @date 2022/2/17
 */
public class ResolvYaXinSafeLogTest {

    public static void main(String[] args) {
        AllConfig config = new AllConfig();
        DataProcessFuncation.CONIFG = config;
        config.setMode("single");
        config.setParse("ResolvYaXinSafeLog");
        config.setIndex("sec_all");

        String str = "<134>May 25 09:21:08 hrsk-sec-deepsec-mg02 CEF:0|Asiainfo Security|Deep Security Agent|20.0.397|4000002|HackTool.Win32.WinActivator.GA|6|cn1=509 cn1Label=Host ID dvc=10.0.128.68 dvchost=szlfs03 groupName=华润置地 AsiainfoDsTenant=TenantID 1 AsiainfoDsTenantId=1 rt=May 25 09:21:33  malName=HackTool.Win32.WinActivator.GA malType=1 majorVirusType=4 directoryDN=N/A IP=10.0.128.68 hostGroupName=华润置地 serverName=10.200.10.28 10.200.10.26  filePath=/glusterfs/data/.glusterfs/cc/ab/ccab8de0-10e8-4f23-938c-25e852d18635 act=Pass msg=Scheduled AsiainfoDsMalwareTarget=N/A AsiainfoDsMalwareTargetType=N/A cat=Anti-Malware";
        ConcurrentHashMap<String, Object> proc = DataProcessFuncation.parse(str, "index");
        JsonUtils.printStr(proc);

        str = "LEEF:2.0|Asiainfo Security|Deep Security Manager|<DSA 版本>|192|cat=System name=Alert Ended desc=Alert:CPU Warning Threshold Exceeded\\nSubject:10.201.114.164\\nSeverity:Warning sev=3 src=10.201.114.164 usrName=System msg=Alert:CPU Warning Threshold Exceeded\\nSubject:10.201.114.164\\nSeverity:Warning TrendMicroDsTenant=Primary";
        proc = DataProcessFuncation.parse(str, "index");
        JsonUtils.printStr(proc);

        str = "<134>Apr 21 18:29:38 hrsk-sec-deepsec-mg02 CEF:0|Asiainfo Security|Deep Security Manager|20.0.397|600|User Signed In|3|src=10.200.10.28 suser=MasterAdmin target=MasterAdmin msg=User signed in from 10.54.16.179 AsiainfoDsTenant=TenantID 0 AsiainfoDsTenantId=0";
        proc = DataProcessFuncation.parse(str, "index");
        JsonUtils.printStr(proc);

        str = "<134>Apr 21 18:29:47 hrsk-sec-deepsec-mg02 CEF:0|Asiainfo Security|Deep Security Manager|20.0.397|190|Alert Started|3|src=10.200.10.28 suser=System target=10.128.63.82 msg=Alert: Anti-Malware Component Update Failed\\nSeverity: Warning AsiainfoDsTenant=TenantID 0 AsiainfoDsTenantId=0";
        proc = DataProcessFuncation.parse(str, "index");
        JsonUtils.printStr(proc);
    }

}
