package com.crc.log.flink.parse;

import com.alibaba.fastjson.JSONObject;
import com.crc.log.flink.common.constants.LevelConstants;
import com.crc.log.flink.common.constants.LogConstants;
import com.crc.log.flink.common.utils.DataUtils;
import com.crc.log.flink.common.utils.JsonUtils;
import com.crc.log.flink.common.utils.MapUtils;
import org.apache.commons.lang3.StringUtils;

import java.util.concurrent.ConcurrentHashMap;

@SuppressWarnings("unchecked")
public class ResolvLinuxLog {
    /**
     * Linux 日志泛化
     */
    public static ConcurrentHashMap<String,Object> parse(String message) {
        try {
            ConcurrentHashMap<String,Object> data = proc(message);
            if (DataUtils.isNotEmptyJson(data)) {
                return data;
            }
        } catch (Exception ignored) {

        }
        return null;
    }

    private static ConcurrentHashMap<String,Object> proc(String jsonStr) {
        ConcurrentHashMap<String,Object> ldapJson = JsonUtils.createBaseMap(jsonStr);
        try {
            jsonStr = DataUtils.getSubString(jsonStr, DataUtils.getIndex(jsonStr, "{"));
                    //jsonStr.substring(jsonStr.indexOf("{"));
            int index = DataUtils.getLastIndex(jsonStr, "}");
            if (index == -1) {
                return ldapJson;
            }
            jsonStr = DataUtils.getSubString(jsonStr, 0, index+1);
                    //jsonStr.substring(0, jsonStr.lastIndexOf("}") + 1);
            JSONObject jObj = JsonUtils.parse(jsonStr);
            if (JsonUtils.isEmpty(jObj)) {
                return ldapJson;
            }
            MapUtils.setStr(ldapJson, LogConstants.MSG_CONTENT, jObj, "message");
            MapUtils.setStr(ldapJson, LogConstants.LOG_LEVEL, jObj, "level");
            MapUtils.setStr(ldapJson, LogConstants.SRC_IP, jObj, "ip");
            MapUtils.setStr(ldapJson, LogConstants.HOST_NAME, jObj, "hostname");
            MapUtils.setStr(ldapJson, LogConstants.LOG_NAME, jObj, "programname");
            MapUtils.setStr(ldapJson, LogConstants.EVENT_ID, jObj, "procid");
            MapUtils.setStr(ldapJson, LogConstants.ACTION_TYPE, jObj, "facility");
            MapUtils.setJsonValue(ldapJson, jObj, LogConstants.HOST_NAME, "host.hostname",
                    LogConstants.SRC_DEV_INFO, "host.os");

            MapUtils.setStr(ldapJson, LogConstants.LOG_LEVEL, LevelConstants.INFO);

            if (MapUtils.isBlank(ldapJson, LogConstants.HOST_NAME))
                MapUtils.setJsonValue(ldapJson, jObj, LogConstants.HOST_NAME, "agent.name");
            MapUtils.setJsonValue(ldapJson, jObj, LogConstants.LOG_DEV_IP, "fields.dev_ip");

            ldapJson.put(LogConstants.LOG_LEVEL, LevelConstants.getLevel(MapUtils.getStr(ldapJson,LogConstants.LOG_LEVEL)));
            if (StringUtils.isBlank(MapUtils.getStr(ldapJson, LogConstants.SRC_IP))) {
                ldapJson.put(LogConstants.SRC_IP, "0.0.0.0");
            }
            if (StringUtils.isBlank(MapUtils.getStr(ldapJson, LogConstants.DEST_IP))) {
                ldapJson.put(LogConstants.DEST_IP, "0.0.0.0");
            }
            ldapJson.put(LogConstants.LOG_PRODUCT, "Linux服务器");
            return ldapJson;
        } catch (Exception e) {
            return ldapJson;
        }
    }
}
