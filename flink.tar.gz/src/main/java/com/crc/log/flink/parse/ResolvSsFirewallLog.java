package com.crc.log.flink.parse;

import com.crc.log.flink.common.constants.LevelConstants;
import com.crc.log.flink.common.constants.LogConstants;
import com.crc.log.flink.common.utils.DataUtils;
import com.crc.log.flink.common.utils.IPUtil;
import com.crc.log.flink.common.utils.JsonUtils;
import com.crc.log.flink.common.utils.MapUtils;
import org.apache.commons.lang3.StringUtils;

import java.util.concurrent.ConcurrentHashMap;

/**
 * 山石防火墙
 */
public class ResolvSsFirewallLog {
    public static ConcurrentHashMap<String, Object> parse(String message) {
        try {
            ConcurrentHashMap<String, Object> data = proc(message);
            if (DataUtils.isNotEmptyJson(data)) {
                return data;
            }
        } catch (Exception ignored) {

        }
        return null;
    }

    private static ConcurrentHashMap<String, Object> proc(String jsonStr) {
        ConcurrentHashMap<String, Object> rtnObjc = JsonUtils.createBaseMap(jsonStr);
        if (jsonStr.contains("Threat@FLOW")) {
            //威胁情报日志
            threatLog(jsonStr, rtnObjc);
            setAlertName(rtnObjc, 0);
        } else if (jsonStr.contains("Event@SECURITY")){
            //事件日志
            eventLogType(jsonStr, rtnObjc);
            setAlertName(rtnObjc, 1);
        } else {
            setAlertName(rtnObjc, 2);
        }
        return rtnObjc;
    }

    private static void eventLogType(String jsonStr, ConcurrentHashMap<String, Object> rtnObjc) {
        int index = DataUtils.getIndex(jsonStr, "user");
                //jsonStr.indexOf("user");
        if (index > -1) {
            jsonStr = DataUtils.getSubString(jsonStr, index);
                    //jsonStr.substring(index);
        }
        int index1 = DataUtils.getIndex(jsonStr, "\"");
                //jsonStr.indexOf("\"");
        if (index1 > -1) {
            jsonStr = DataUtils.getSubString(jsonStr, index1+1);
        }
        index1 = DataUtils.getIndex(jsonStr, "\"");
        if (index > -1) {
            String userName = DataUtils.getSubString(jsonStr, 0, index1);
                    //jsonStr.substring(0,index1);
            rtnObjc.put(LogConstants.USER_NAME, userName);
        }
        rtnObjc.put(LogConstants.LOG_LEVEL, LevelConstants.getLevel(MapUtils.getStr(rtnObjc,LogConstants.LOG_LEVEL)));
        rtnObjc.put(LogConstants.LOG_PRODUCT, "山石防火墙");
        if (StringUtils.isBlank(MapUtils.getStr(rtnObjc, LogConstants.SRC_IP))) {
            rtnObjc.put(LogConstants.SRC_IP, "0.0.0.0");
        }
        if (StringUtils.isBlank(MapUtils.getStr(rtnObjc, LogConstants.DEST_IP))) {
            rtnObjc.put(LogConstants.DEST_IP, "0.0.0.0");
        }
    }


    private static void threatLog(String jsonStr, ConcurrentHashMap<String, Object> rtnObjc) {
        String[] array =  DataUtils.getSplit(jsonStr, ",");
                //jsonStr.split(",");
        for (int i = 0; i < array.length; i++) {
            if (i == 0 && jsonStr.contains("to") && jsonStr.contains("From")) {
                String str = array[0];
                int indexFrom = DataUtils.getIndex(str, "From");
                        //str.indexOf("From");
                int indexTo = DataUtils.getIndex(str, "to");
                        //str.indexOf("to");
                String src = DataUtils.getSubString(str, indexFrom+5, indexTo-1);
                        //str.substring(indexFrom+5, indexTo-1);
                String dest = DataUtils.getSubString(str, indexTo+2);
                        //str.substring(indexTo+2);
                // 目的信息
                srcDest(dest, rtnObjc, 1);
                // 源信息
                srcDest(src, rtnObjc, 0);
            } else {
                String str = array[i];
                String[] split = DataUtils.getSplit(str, ":");
                        //str.split(":");
                String key = split[0].trim();
                String value = split.length > 1 ? split[1] : "";
                switch (key) {
                    case "threat name":
                        rtnObjc.put(LogConstants.LOG_NAME, value);
                        break;
                    case "threat type":
                        rtnObjc.put(LogConstants.LOG_TYPE, value);
                        break;
                    case "App/Protocol":
                        rtnObjc.put(LogConstants.LOG_PROTOCAL, value);
                        break;
                    case "action":
                        rtnObjc.put(LogConstants.BEHAVIOR_TAG, value);
                        break;
                    case "defender":
                        rtnObjc.put(LogConstants.ACTION_TYPE, value);
                        break;
                    case "severity":
                        rtnObjc.put(LogConstants.LOG_LEVEL, value);
                        break;
                    case "threat severity":
                        rtnObjc.put(LogConstants.LOG_LEVEL, value);
                        break;
                    case "zone untrust":
                        rtnObjc.put(LogConstants.MSG_CONTENT, value);
                        break;
                    case "zone":
                        rtnObjc.put(LogConstants.MSG_CONTENT, value);
                        break;
                    case "zone zone-name":
                        rtnObjc.put(LogConstants.MSG_CONTENT, value);
                        break;
                }
            }
        }
        rtnObjc.put(LogConstants.LOG_LEVEL, LevelConstants.getLevel(MapUtils.getStr(rtnObjc,LogConstants.LOG_LEVEL)));
        rtnObjc.put(LogConstants.LOG_PRODUCT, "山石防火墙");
        if (StringUtils.isBlank(MapUtils.getStr(rtnObjc, LogConstants.SRC_IP))) {
            rtnObjc.put(LogConstants.SRC_IP, "0.0.0.0");
        }
        if (StringUtils.isBlank(MapUtils.getStr(rtnObjc, LogConstants.DEST_IP))) {
            rtnObjc.put(LogConstants.DEST_IP, "0.0.0.0");
        }
    }


    private static void srcDest(String msg, ConcurrentHashMap<String, Object>  rtnObjc, int type) {
        String[] split = msg.split(":");
        String ip = "";
        String port = "";
        String intf = "";
        if (IPUtil.isIp(split[0].trim())) {
            ip = split[0];
        }
        String[] tempPort = DataUtils.getSplit(split[split.length - 1], "\\(");
                //split[split.length - 1].split("\\(");
        if (DataUtils.isNumeric(tempPort[0].trim())) {
            port = tempPort[0];
        }
        if (tempPort.length > 1) {
            intf = tempPort[1].replace(")", "");
        }
        if (type == 0) {
            rtnObjc.put(LogConstants.SRC_IP, ip);
            rtnObjc.put(LogConstants.SRC_PORT, port);
            rtnObjc.put(LogConstants.SRC_INTF, intf);
        } else {
            rtnObjc.put(LogConstants.DEST_IP, ip);
            rtnObjc.put(LogConstants.DEST_PORT, port);
            rtnObjc.put(LogConstants.DST_INTF, intf);
        }
    }

    private static void setAlertName(ConcurrentHashMap<String, Object>  rtnObjc, int type) {
        String msgFormat = "源IP为:%s,目的IP为:%s,风险级别:%s,攻击类型:%s,事件类型:%s,日志详情为:%s";
        String alertName = "";
        String level = MapUtils.getStr(rtnObjc, LogConstants.LOG_LEVEL);
        String log = MapUtils.getStr(rtnObjc, LogConstants.LOG_ORI_MSG);
        if (type == 0) {
            String srcIp = MapUtils.getStr(rtnObjc, LogConstants.SRC_IP);
            String destIp = MapUtils.getStr(rtnObjc, LogConstants.DEST_IP);
            String action = MapUtils.getStr(rtnObjc, LogConstants.ACTION_TYPE);
            String event = MapUtils.getStr(rtnObjc, LogConstants.LOG_TYPE);
            alertName = String.format(msgFormat, srcIp, destIp, level, action, event,log);
        } else if (type == 1){
            String userName = MapUtils.getStr(rtnObjc, LogConstants.USER_NAME);
            msgFormat = "用户:%s,事件风险为:%s,日志详情为:%s";
            alertName = String.format(msgFormat, userName,level, log);
        } else if (type == 2) {
            msgFormat = "日志详情为:%s";
            alertName = String.format(msgFormat, log);
        }
        rtnObjc.put(LogConstants.ALERT_NAME, alertName);
    }
}
