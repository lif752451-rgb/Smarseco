package com.crc.log.flink.common.utils;

import com.alibaba.fastjson.JSONObject;
import com.crc.log.flink.common.constants.LevelConstants;
import com.crc.log.flink.common.constants.LogConstants;

import java.util.Date;
import java.util.concurrent.ConcurrentHashMap;

public class MapUtils {
    public static void setJsonValue(ConcurrentHashMap<String, Object> targetJson, JSONObject sourceJson, String targetKey, String sourceKey) {
        setJsonValue(targetJson, sourceJson, targetKey, sourceKey, false);
    }

    public static void setJsonValue(ConcurrentHashMap<String, Object> targetJson, JSONObject sourceJson, String targetKey, String sourceKey, boolean isExist) {
        if (sourceKey.contains(".")) {
            String[] sourceKeys = sourceKey.split("\\.");
            String sourceKey1 = sourceKeys[0];
            String sourceKey2 = sourceKeys[1];
            JSONObject insideJson = JsonUtils.getJson(sourceJson, sourceKey1);
            if (insideJson == null) {
                return;
            }
            String sourceValue = JsonUtils.getStr(insideJson, sourceKey2);
            if (!isExist) {
                setStr(targetJson, targetKey, sourceValue);
            }
        } else {
            String sourceValue = JsonUtils.getStr(sourceJson, sourceKey);
            if (!isExist) {
                setStr(targetJson, targetKey, sourceValue);
            }

        }
    }

    public static void setJsonValue(ConcurrentHashMap<String, Object> targetJson, JSONObject sourceJson, String targetKey1,
                                    String sourceKey1, String targetKey2, String sourceKey2) {
        setJsonValue(targetJson, sourceJson, targetKey1, sourceKey1, targetKey2, sourceKey2, false);
    }

    public static void setJsonValue(ConcurrentHashMap<String, Object> targetJson, JSONObject sourceJson, String targetKey1,
                                    String sourceKey1, String targetKey2, String sourceKey2, boolean isExist) {
        String[] sourceKeys1 = sourceKey1.split("\\.");
        String[] sourceKeys2 = sourceKey2.split("\\.");
        if (sourceKeys1.length != 2 || sourceKeys2.length != 2) {
            return;
        }
        String sourceKeybef = sourceKeys1[0];
        String sourceKeyAft = sourceKeys1[1];
        String sourceValue = "";
        String sourceValue2 = "";
        JSONObject insideJson = null;
        JSONObject insideJson2 = null;
        insideJson = JsonUtils.getJson(sourceJson, sourceKeybef);
        if (sourceKeyAft.contains("|")) {
            String[] sourceKeyAfts = sourceKeyAft.split("\\|");
            StringBuilder sb = new StringBuilder();
            for (String source : sourceKeyAfts) {
                sb.append(JsonUtils.getStr(insideJson, source));
            }
            sourceValue = sb.toString();
        } else {
            sourceValue = JsonUtils.getStr(insideJson, sourceKeyAft);
        }
        String sourceKeyAft2 = sourceKeys2[1];
        if (sourceKeys1[0].equals(sourceKeys2[0])) {
            insideJson2 = insideJson;
        } else {
            insideJson2 = JsonUtils.getJson(sourceJson, sourceKeys2[0]);
        }
        if (sourceKeyAft2.contains("|")) {
            String[] sourceKeyAfts2 = sourceKeyAft2.split("\\|");
            StringBuilder sb = new StringBuilder();
            for (String source : sourceKeyAfts2) {
                sb.append(JsonUtils.getStr(insideJson2, source));
            }
            sourceValue2 = sb.toString();
        } else {
            sourceValue2 = JsonUtils.getStr(insideJson2, sourceKeyAft2);
        }
        if (!org.apache.commons.lang3.StringUtils.isEmpty(targetKey1) && !isExist) {
            setStr(targetJson, targetKey1, sourceValue);
        }
        if (!org.apache.commons.lang3.StringUtils.isEmpty(targetKey2) && !isExist) {
            setStr(targetJson, targetKey2, sourceValue2);
        }
    }

    public static boolean setStr(ConcurrentHashMap<String, Object> dest, String filter, String val) {
        /*
         * IP属性必须为合法
         */
        if (LogConstants.SRC_IP.equalsIgnoreCase(filter) || LogConstants.DEST_IP.equalsIgnoreCase(filter)) {
            if (!IPUtil.isIp(val)) {
                val = null;
            }
        }
        if (StringUtils.isNotBlank(filter) && StringUtils.isNotBlank(val)) {
            dest.put(filter, val.trim());
            return true;
        }
        return false;
    }

    public static void setStr(ConcurrentHashMap<String, Object> dest, String destFilter, JSONObject src, String srcFilter) {
        if (LogConstants.LOG_START_TIME.equalsIgnoreCase(destFilter)) {
            setDate(dest, destFilter, src, srcFilter);
            return;
        }
        if (LogConstants.LOG_LEVEL.equalsIgnoreCase(destFilter)) {
            String srcVal = LevelConstants.getLevel(JsonUtils.getStr(src, srcFilter));
            setStr(dest, destFilter, srcVal);
            return;
        }
        String srcVal = JsonUtils.getStr(src, srcFilter);
        setStr(dest, destFilter, srcVal);
    }

    public static void setDate(ConcurrentHashMap<String, Object> dest, String destFilter, JSONObject src, String srcFilter) {
        String dateStr = DateUtils.getISO8601Timestamp(JsonUtils.getStr(src, srcFilter));
        setStr(dest, destFilter, dateStr);
    }

    public static boolean isEmpty(ConcurrentHashMap<String, Object> json) {
        if (json == null)
            return true;
        return json.isEmpty();
    }

    public static String getStr(ConcurrentHashMap<String, Object> json, String filter) {
        if (isEmpty(json) || StringUtils.isBlank(filter)) {
            return "";
        }

        if (json.get(filter) == null) {
            return "";
        }
        try {
            Object val = json.get(filter);
            if (val instanceof Date) {
                return DateUtils.getSparkTime((Date) val);
            }
            String retStr = val.toString();
            if (StringUtils.isNotBlank(retStr)) {
                if ("null".equalsIgnoreCase(retStr)) {
                    return "";
                }
                return retStr.trim();
            }
        } catch (Exception ignored) {

        }
        return "";
    }

    public static boolean isBlank(ConcurrentHashMap<String, Object> ldapJson, String filter) {
        String str = getStr(ldapJson, filter);
        return StringUtils.isBlank(str);
    }

    public static boolean equal(ConcurrentHashMap<String, Object> resultJson, String filter, String val) {
        String ret = getStr(resultJson, filter);
        return ret.equals(val);
    }

    public static void setLong(ConcurrentHashMap<String, Object> dest, String destFilter, JSONObject src, String srcFilter) {
        long srcVal = JsonUtils.getLong(src, srcFilter);
        setLong(dest, destFilter, srcVal);
    }

    public static void setLong(ConcurrentHashMap<String, Object> dest, String filter, long val) {
        if (org.apache.commons.lang3.StringUtils.isNotBlank(filter)) {
            dest.put(filter, val);
        }
    }

    public static boolean containsKey(JSONObject sourceJson, String object) {
        if (sourceJson == null || object == null) {
            return false;
        }
        return sourceJson.containsKey(object);
    }
}
