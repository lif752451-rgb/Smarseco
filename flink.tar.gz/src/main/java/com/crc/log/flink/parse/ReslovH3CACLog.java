package com.crc.log.flink.parse;

import com.alibaba.fastjson.JSONObject;
import com.crc.log.flink.common.constants.LevelConstants;
import com.crc.log.flink.common.constants.LogConstants;
import com.crc.log.flink.common.utils.DataUtils;
import com.crc.log.flink.common.utils.JsonUtils;
import com.crc.log.flink.common.utils.MapUtils;
import org.apache.commons.lang3.StringUtils;

import java.util.concurrent.ConcurrentHashMap;

/**
 * 华三AC
 */
public class ReslovH3CACLog {
    public static ConcurrentHashMap<String,Object> parse(String message) {
        try {
            ConcurrentHashMap<String,Object> data = proc(message);
            if (DataUtils.isNotEmptyJson(data)) {
                return data;
            }
        } catch (Exception ignored) {

        }
        return null;
    }

    private static ConcurrentHashMap<String,Object> proc(String jsonStr) {
        ConcurrentHashMap<String,Object> rtnObjc = JsonUtils.createBaseMap(jsonStr);
        JSONObject json = getMsgContent(jsonStr);

        rtnObjc.put(LogConstants.SRC_IP, JsonUtils.getStr(json, "src_ip"));
        rtnObjc.put(LogConstants.DEST_IP, JsonUtils.getStr(json, "dst_ip"));
        rtnObjc.put(LogConstants.LOG_PROTOCAL, JsonUtils.getStr(json, "protocol"));
        rtnObjc.put(LogConstants.SRC_PORT, JsonUtils.getStr(json, "src_port"));
        rtnObjc.put(LogConstants.DEST_PORT, JsonUtils.getStr(json, "dst_port"));
        rtnObjc.put(LogConstants.ACTION_RESULT, JsonUtils.getStr(json, "action"));
        rtnObjc.put(LogConstants.OP_NAME, JsonUtils.getStr(json, "user_name"));
        rtnObjc.put(LogConstants.SRC_MAC, JsonUtils.getStr(json, "umac"));
        if (StringUtils.isBlank(MapUtils.getStr(rtnObjc, LogConstants.SRC_IP))) {
            rtnObjc.put(LogConstants.SRC_IP, JsonUtils.getStr(json, "uip"));
        }
        rtnObjc.put(LogConstants.LOG_CONTENT, JsonUtils.getStr(json, "Content"));
        rtnObjc.put(LogConstants.LOG_PRODUCT, "新华三AC");
        rtnObjc.put(LogConstants.LOG_LEVEL, LevelConstants.getLevel(MapUtils.getStr(rtnObjc,LogConstants.LOG_LEVEL)));
        if (StringUtils.isBlank(MapUtils.getStr(rtnObjc, LogConstants.SRC_IP))) {
            rtnObjc.put(LogConstants.SRC_IP, "0.0.0.0");
        }
        if (StringUtils.isBlank(MapUtils.getStr(rtnObjc, LogConstants.DEST_IP))) {
            rtnObjc.put(LogConstants.DEST_IP, "0.0.0.0");
        }
        setAlertName(rtnObjc);
        return rtnObjc;

    }


    /**
     * <6>Apr 13 11:13:00 RL092HP03ACGHC123;110104700120091633566634;ipv4;3; statistic_traffic: user_name=10.54.48.57;ugname=anonymous;umac=5C:C9:99:25:FC:01;uip=10.54.48.57;appname=微软官网_网页浏览;appgname=生活服务;up=1688;down=1816;create_time=1618283580;end_time=1618283640
     *
     * @param msg
     * @return
     */
    public static JSONObject getMsgContent(String msg) {
        JSONObject json = new JSONObject();
        try {
            msg = msg.replace("\"", "");
            for (String x : DataUtils.getSplit(msg, ";")) {
                try {
                    String[] m = x.split("=");
                    if (m.length == 2) {
                        String[] yy = DataUtils.getSplit(m[0].trim(), ":");
                                //m[0].trim().split(":");
                        String str = m[0].trim();
                        if (yy.length == 2) {
                            str = yy[1];
                        }
                        json.put(str.trim(), m[1].trim());
                    }
                } catch (Exception e) {

                }
            }

        } catch (Exception e) {

        }

        return json;
    }

    private static void setAlertName(ConcurrentHashMap<String,Object> rtnObjc) {
        String srcIp = MapUtils.getStr(rtnObjc, LogConstants.SRC_IP);
        String destIp = MapUtils.getStr(rtnObjc, LogConstants.DEST_IP);
        String result = MapUtils.getStr(rtnObjc, LogConstants.ACTION_RESULT);
        String log = MapUtils.getStr(rtnObjc, LogConstants.LOG_CONTENT);
        String msgFormat = "源IP:%s,目的IP:%s,操作结果:%s,日志详情为:%s";
        String alertName = String.format(msgFormat, srcIp, destIp, result, log);
        rtnObjc.put(LogConstants.ALERT_NAME, alertName);
    }

}
