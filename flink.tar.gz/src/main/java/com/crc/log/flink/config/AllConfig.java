package com.crc.log.flink.config;

import com.crc.log.flink.common.utils.CodeTool;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.context.annotation.Configuration;

@Configuration
@ConfigurationProperties(prefix = "flink")
public class AllConfig {
    String userAgent;

    String pushServer;

    public String getPushServer() {
        return pushServer;
    }

    public void setPushServer(String pushServer) {
        this.pushServer = pushServer;
    }

    public String getUserAgent() {
        return userAgent;
    }

    public void setUserAgent(String userAgent) {
        this.userAgent = userAgent;
    }

    private String eshost;
    private String esport;
    private String esproxyHeader;
    private String esusername;
    private String espassword;
    private String esmode;
    private String area;
    private String kafkagroup;
    private String kafka;
    private String zookeeper;
    private String topic;
    private String index;
    private String parallelism;
    private String doctype;
    private String consumertype;
    private String debug;
    private String cachePath;
    private String fixedDelayRestart;
    private String maxPoll;
    private String flushMaxAction;
    private String partition;
    private String fwfilter;
    private String indexSwitch;

    String groupId;

    public String getGroupId() {
        return groupId;
    }

    public void setGroupId(String groupId) {
        this.groupId = groupId;
    }

    private String segTimeout;

    public String getArea() {
        return area;
    }

    public void setArea(String area) {
        this.area = area;
    }

    public String getIndexSwitch() {
        return indexSwitch;
    }

    public void setIndexSwitch(String indexSwitch) {
        this.indexSwitch = indexSwitch;
    }

    public String getFwfilter() {
        return fwfilter;
    }

    public void setFwfilter(String fwfilter) {
        this.fwfilter = fwfilter;
    }

    public String getPartition() {
        return partition;
    }

    public void setPartition(String partition) {
        this.partition = partition;
    }

    public String getMaxPoll() {
        return maxPoll;
    }

    public void setMaxPoll(String maxPoll) {
        this.maxPoll = maxPoll;
    }

    public String getFlushMaxAction() {
        return flushMaxAction;
    }

    public void setFlushMaxAction(String flushMaxAction) {
        this.flushMaxAction = flushMaxAction;
    }

    public String getCachePath() {
        return cachePath;
    }

    public void setCachePath(String cachePath) {
        this.cachePath = cachePath;
    }

    public String getFixedDelayRestart() {
        return fixedDelayRestart;
    }

    public void setFixedDelayRestart(String fixedDelayRestart) {
        this.fixedDelayRestart = fixedDelayRestart;
    }

    public String getDebug() {
        return debug;
    }

    public void setDebug(String debug) {
        this.debug = debug;
    }

    public String getConsumertype() {
        return consumertype;
    }

    public void setConsumertype(String consumertype) {
        this.consumertype = consumertype;
    }

    public String getDoctype() {
        return doctype;
    }

    public void setDoctype(String doctype) {
        this.doctype = doctype;
    }

    public String getParallelism() {
        return parallelism;
    }

    public void setParallelism(String parallelism) {
        this.parallelism = parallelism;
    }

    private String parse;
    private String mode;

    private String chinese;

    public String getChinese() {
        return chinese;
    }

    public void setChinese(String chinese) {
        this.chinese = chinese;
    }

    private String test;

    public String getSegTimeout() {
        return segTimeout;
    }

    public void setSegTimeout(String segTimeout) {
        this.segTimeout = segTimeout;
    }

    private String groupx;

    public String getGroupx() {
        return groupx;
    }

    public void setGroupx(String groupx) {
        this.groupx = groupx;
    }

    public String getTest() {
        return test;
    }

    public void setTest(String test) {
        this.test = test;
    }

    public String getParse() {
        return parse;
    }

    public void setParse(String parse) {
        this.parse = parse;
    }

    public String getMode() {
        return mode;
    }

    public void setMode(String mode) {
        this.mode = mode;
    }

    public String getKafka() {
        return kafka;
    }

    public void setKafka(String kafka) {
        this.kafka = kafka;
    }

    public String getZookeeper() {
        return zookeeper;
    }

    public void setZookeeper(String zookeeper) {
        this.zookeeper = zookeeper;
    }

    public String getIndex() {
        return index;
    }

    public void setIndex(String index) {
        this.index = index;
    }

    public String getTopic() {
        return topic;
    }

    public void setTopic(String topic) {
        this.topic = topic;
    }

    public String getEsproxyHeader() {
        return esproxyHeader;
    }

    public void setEsproxyHeader(String esproxyHeader) {
        this.esproxyHeader = esproxyHeader;
    }

    public String getEsusername() {
        return esusername;
    }

    public void setEsusername(String esusername) {
        this.esusername = esusername;
    }

    public String getEspassword() {
        return espassword;
    }

    public void setEspassword(String espassword) {
        this.espassword = CodeTool.decrypt(espassword);
    }

    public String getEsmode() {
        return esmode;
    }

    public void setEsmode(String esmode) {
        this.esmode = esmode;
    }

    public String getKafkagroup() {
        return kafkagroup;
    }

    public void setKafkagroup(String kafkagroup) {
        this.kafkagroup = kafkagroup;
    }

    public String getEshost() {
        return eshost;
    }

    public void setEshost(String eshost) {
        this.eshost = eshost;
    }

    public String getEsport() {
        return esport;
    }

    public void setEsport(String esport) {
        this.esport = esport;
    }
}
