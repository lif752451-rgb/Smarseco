package com.crc.log.flink.db;

import com.alibaba.fastjson.JSONObject;
import com.crc.log.flink.common.entity.TbAsset;
import com.crc.log.flink.common.utils.IPUtil;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;

import java.util.ArrayList;
import java.util.List;

/**
 * @author simba@onlying.cn
 * @date 2020/8/26 21:11
 */
@Slf4j
public class AssetDao {

    public static List<TbAsset> queryList() {

        List<TbAsset> assetList = new ArrayList<>();
        try {
            long total = ConfBuzziMySql.getCount("SELECT count(1) FROM tb_asset a  where a.del_flag = '0'");
            String q = "select * from tb_asset where del_flag = '0' order by id limit %d,%d";
            int pageSize = 2000;
            for (int i = 0; i < (int) (total / pageSize) + 1; i++) {
                int offset = i * pageSize;
                List<JSONObject> list = ConfBuzziMySql.query(String.format(q, offset, pageSize));
                for (JSONObject rs : list) {
                    try {
                        TbAsset tbAsset = new TbAsset();
                        tbAsset.setCompanyName(getStr(rs, "company_name"));
                        tbAsset.setInstance(getStr(rs, "instance"));
                        tbAsset.setIp(getStr(rs, "internal_ip"));
                        tbAsset.setAffiliationDeptName(getStr(rs, "affiliation_dept_name"));
                        tbAsset.setArea(getStr(rs, "area"));
                        tbAsset.setSubArea(getStr(rs, "sub_area"));
                        tbAsset.setAreaName(getStr(rs, "area_name"));

                        if (IPUtil.isIp(tbAsset.getIp())) {
                            assetList.add(tbAsset);
                        }
                    } catch (Exception e) {
                        log.error(e.getMessage(), e);
                    }
                }
            }
        } catch (Exception e) {
            log.error(e.getMessage(), e);
        }
        return assetList;
    }

    public static String getStr(JSONObject rs, String col) {
        try {
            if (rs == null || StringUtils.isBlank(col)) {
                return "";
            }
            return rs.getString(col);
        } catch (Exception e) {
            log.error(e.getMessage(), e);
        }
        return "";
    }
}
