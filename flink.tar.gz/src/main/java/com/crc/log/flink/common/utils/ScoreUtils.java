package com.crc.log.flink.common.utils;

import com.crc.log.flink.common.constants.LevelConstants;
import com.crc.log.flink.common.constants.LogConstants;
import org.apache.commons.lang3.StringUtils;

import java.util.concurrent.ConcurrentHashMap;

/**
 * 打分工具类
 */
public class ScoreUtils {

    /**
     * 按事件级别打分 低10 中30 高80
     */
    public static void commonEventLevelScore(ConcurrentHashMap<String, Object> data) {
        String level = MapUtils.getStr(data, LogConstants.LOG_LEVEL);
        int eventScore = 0;
        if (StringUtils.isNotBlank(level)) {
            if (LevelConstants.LOW.equals(level)) {
                eventScore = 10;
            } else if (LevelConstants.MEDIUM.equals(level)) {
                eventScore = 30;
            } else if (LevelConstants.HIGH.equals(level)) {
                eventScore = 80;
            }
        }
        data.put(LogConstants.EVENT_SCORE, eventScore);
    }


    /*
       深信服SIP打分
     */
    public static void sipScore(ConcurrentHashMap<String,Object> data) {
        String propity = MapUtils.getStr(data,LogConstants.LOG_PRIORITY);
        String level = MapUtils.getStr(data,LogConstants.LOG_LEVEL);
        int eventScore = 0;
        if (LevelConstants.LOW.equals(level)) {
            if ("正常".equalsIgnoreCase(propity)) {
                //eventScore = 0;
            } else if ("低可疑".equalsIgnoreCase(propity)) {
                eventScore = 1;
            } else if ("高可疑".equalsIgnoreCase(propity)) {
                eventScore = 7;
            } else if ("已失陷".equalsIgnoreCase(propity)) {
                eventScore = 10;
            }
        } else if (LevelConstants.MEDIUM.equals(level)) {
            if ("正常".equalsIgnoreCase(propity)) {
                //eventScore = 0;
            } else if ("低可疑".equalsIgnoreCase(propity)) {
                eventScore = 5;
            } else if ("高可疑".equalsIgnoreCase(propity)) {
                eventScore = 35;
            } else if ("已失陷".equalsIgnoreCase(propity)) {
                eventScore = 50;
            }
        } else if (LevelConstants.HIGH.equals(level)) {
            if ("正常".equalsIgnoreCase(propity)) {
                // eventScore = 0;
            } else if ("低可疑".equalsIgnoreCase(propity)) {
                eventScore = 10;
            } else if ("高可疑".equalsIgnoreCase(propity)) {
                eventScore = 70;
            } else if ("已失陷".equalsIgnoreCase(propity)) {
                eventScore = 100;
            }
        }
        data.put(LogConstants.EVENT_SCORE, eventScore);
    }
}
