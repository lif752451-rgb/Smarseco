package com.crc.log.flink.test.log;

import com.crc.log.flink.common.utils.JsonUtils;
import com.crc.log.flink.config.AllConfig;
import com.crc.log.flink.es.DataProcessFuncation;

import java.util.concurrent.ConcurrentHashMap;

/**
 * @author jixiangqi
 * @date 2022/2/16
 */
public class Resolv360TerminalSafeLogTest {

    public static void main(String[] args) {
        AllConfig config = new AllConfig();
        DataProcessFuncation.CONIFG = config;
        config.setMode("single");
        config.setParse("Resolv360TerminalSafeLog");
        config.setIndex("sec_all");


        String str = "{\"id\":\"642419\",\"m2\":\"a1e4af86ff5fb3c65b228beceda93e5b8e9bf9342b13\",\"action\":\"已拦截\",\"action_time\":\"1587113468\",\"dns_name\":\"null\",\"ip_dst\":\"10.16.16.91\",\"port_dst\":\"445\",\"ip_src\":\"10.254.205.77\",\"port_src\":\"6000\",\"net_protocol\":\"ipblock\",\"process_id\":\"0\",\"process_name\":\"null\",\"rule_id\":\"null\",\"ltime\":\"2020-04-17 16:51:08\",\"mtime\":\"2020-04-17 16:51:10\",\"ctime\":\"2020-04-17 16:51:10\",\"inactivity\":\"\",\"computername\":\"WUZHIJUN-L3\",\"clientip\":\"10.254.185.254\",\"username\":\"CORP\\\\wuzhijun\",\"sysmaclist\":\"00:50:56:C0:00:01;00:50:56:C0:00:08;\",\"log_type\":\"360edr_netaction_log\"}";
        ConcurrentHashMap<String, Object> proc = DataProcessFuncation.parse(str,"index");
        JsonUtils.printStr(proc);
        str = "{\"id\":\"642420\",\"m2\":\"a1e4af86ff5fb3c65b228beceda93e5b8e9bf9342b13\",\"action\":\"已拦截\",\"action_time\":\"1587113469\",\"dns_name\":\"null\",\"ip_dst\":\"10.16.16.91\",\"port_dst\":\"445\",\"ip_src\":\"10.254.205.77\",\"port_src\":\"6000\",\"net_protocol\":\"ipblock\",\"process_id\":\"0\",\"process_name\":\"null\",\"rule_id\":\"null\",\"ltime\":\"2020-04-17 16:51:09\",\"mtime\":\"2020-04-17 16:51:11\",\"ctime\":\"2020-04-17 16:51:11\",\"inactivity\":\"\",\"computername\":\"WUZHIJUN-L3\",\"clientip\":\"10.254.185.254\",\"username\":\"CORP\\\\wuzhijun\",\"sysmaclist\":\"00:50:56:C0:00:01;00:50:56:C0:00:08;\",\"log_type\":\"360edr_netaction_log\"}";
        proc = DataProcessFuncation.parse(str,"index");
        JsonUtils.printStr(proc);
        str = "{\"id\":\"642421\",\"m2\":\"a1e4af86ff5fb3c65b228beceda93e5b8e9bf9342b13\",\"action\":\"已拦截\",\"action_time\":\"1587113471\",\"dns_name\":\"null\",\"ip_dst\":\"10.16.16.91\",\"port_dst\":\"445\",\"ip_src\":\"10.254.205.77\",\"port_src\":\"6000\",\"net_protocol\":\"ipblock\",\"process_id\":\"0\",\"process_name\":\"null\",\"rule_id\":\"null\",\"ltime\":\"2020-04-17 16:51:11\",\"mtime\":\"2020-04-17 16:51:12\",\"ctime\":\"2020-04-17 16:51:12\",\"inactivity\":\"\",\"computername\":\"WUZHIJUN-L3\",\"clientip\":\"10.254.185.254\",\"username\":\"CORP\\\\wuzhijun\",\"sysmaclist\":\"00:50:56:C0:00:01;00:50:56:C0:00:08;\",\"log_type\":\"360edr_netaction_log\"}";
        proc = DataProcessFuncation.parse(str,"index");
        JsonUtils.printStr(proc);
        str = "{\"id\":\"642422\",\"m2\":\"a1e4af86ff5fb3c65b228beceda93e5b8e9bf9342b13\",\"action\":\"已拦截\",\"action_time\":\"1587113475\",\"dns_name\":\"null\",\"ip_dst\":\"10.16.16.91\",\"port_dst\":\"445\",\"ip_src\":\"10.254.205.77\",\"port_src\":\"6000\",\"net_protocol\":\"ipblock\",\"process_id\":\"0\",\"process_name\":\"null\",\"rule_id\":\"null\",\"ltime\":\"2020-04-17 16:51:15\",\"mtime\":\"2020-04-17 16:51:17\",\"ctime\":\"2020-04-17 16:51:17\",\"inactivity\":\"\",\"computername\":\"WUZHIJUN-L3\",\"clientip\":\"10.254.185.254\",\"username\":\"CORP\\\\wuzhijun\",\"sysmaclist\":\"00:50:56:C0:00:01;00:50:56:C0:00:08;\",\"log_type\":\"360edr_netaction_log\"}";
        proc = DataProcessFuncation.parse(str,"index");
        JsonUtils.printStr(proc);
        str = "{\"id\":\"642423\",\"m2\":\"a1e4af86ff5fb3c65b228beceda93e5b8e9bf9342b13\",\"action\":\"已拦截\",\"action_time\":\"1587113483\",\"dns_name\":\"null\",\"ip_dst\":\"10.16.16.91\",\"port_dst\":\"445\",\"ip_src\":\"10.254.205.77\",\"port_src\":\"6000\",\"net_protocol\":\"ipblock\",\"process_id\":\"0\",\"process_name\":\"null\",\"rule_id\":\"null\",\"ltime\":\"2020-04-17 16:51:23\",\"mtime\":\"2020-04-17 16:51:25\",\"ctime\":\"2020-04-17 16:51:25\",\"inactivity\":\"\",\"computername\":\"WUZHIJUN-L3\",\"clientip\":\"10.254.185.254\",\"username\":\"CORP\\\\wuzhijun\",\"sysmaclist\":\"00:50:56:C0:00:01;00:50:56:C0:00:08;\",\"log_type\":\"360edr_netaction_log\"}";
        proc = DataProcessFuncation.parse(str,"index");
        JsonUtils.printStr(proc);
    }


}
