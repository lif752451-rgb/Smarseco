package com.crc.log.flink.parse;

import com.alibaba.fastjson.JSONObject;
import com.crc.log.flink.common.constants.LevelConstants;
import com.crc.log.flink.common.constants.LogConstants;
import com.crc.log.flink.common.utils.DataUtils;
import com.crc.log.flink.common.utils.DateUtils;
import com.crc.log.flink.common.utils.JsonUtils;
import com.crc.log.flink.common.utils.MapUtils;
import org.apache.commons.lang3.StringUtils;

import java.text.MessageFormat;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

/**
 * @author simba@onlying.cn
 * @date 2020/11/24 14:00
 */
public class ResolvSSPXiaQiangLog {
    private static final Map<String, ScanType> scanTypeMap = new HashMap<>();

    static {
        scanTypeMap.put("scan_22", new ScanType(1, "扫描22端口"));
        scanTypeMap.put("scan_80_443", new ScanType(1, "扫描80和443端口"));
        scanTypeMap.put("scan_1433", new ScanType(1, "扫描1433端口"));
        scanTypeMap.put("scan_3306", new ScanType(1, "扫描3306端口"));
        scanTypeMap.put("scan_3389", new ScanType(1, "扫描3389端口"));
        scanTypeMap.put("scan_6379", new ScanType(1, "扫描6379端口"));
        scanTypeMap.put("scan_7001", new ScanType(1, "扫描7001端口"));
        scanTypeMap.put("scan_nmap_port", new ScanType(2, "扫描器端口扫描"));
        scanTypeMap.put("SQL_injection", new ScanType(4, "SQL注入"));
        scanTypeMap.put("webscan", new ScanType(3, "网站扫描"));
        scanTypeMap.put("weblogic", new ScanType(4, "weblogic漏洞利用"));
        scanTypeMap.put("struts2", new ScanType(4, "struts2漏洞利用"));
        scanTypeMap.put("eternal_blue", new ScanType(4, "永恒之蓝漏洞利用"));
    }


    public static ConcurrentHashMap<String, Object> parse(String message) {
        try {
            ConcurrentHashMap<String, Object> data = proc(message);
            if (DataUtils.isNotEmptyJson(data)) {
                return data;
            }
        } catch (Exception ignored) {

        }
        return null;
    }

    private static ConcurrentHashMap<String, Object> proc(String jsonStr) {
        JSONObject logJson = JsonUtils.parse(jsonStr);
        ConcurrentHashMap<String, Object> retJson = new ConcurrentHashMap<>(logJson);
        logJson.put(LogConstants.LOG_ORI_MSG, jsonStr);
        logJson.put(LogConstants.LOG_PRODUCT, "深信服XQ");
        String logTime = DateUtils.getSparkTime();
        logJson.put(LogConstants.LOG_TIME, logTime);
        ConcurrentHashMap<String, Object> newDataJson = new ConcurrentHashMap<>();
        newDataJson.put(LogConstants.LOG_START_TIME, DateUtils.getISO8601Timestamp(JsonUtils.getStr(logJson, "import_time")));
        String evtId = JsonUtils.getStr(logJson, "evt_id");
        logJson.remove("_id");
        logJson.remove("alert_time");
        logJson.remove("is_submitted");
        logJson.remove("is_duplicate");
        logJson.remove("is_alerted");
        logJson.remove("import_time");
        logJson.remove("item_hash");
        newDataJson.putAll(logJson);
        //访问资源日志处理
        if (!logJson.containsKey(LogConstants.BEHAVIOR_TAG)) {
            return retJson;
        }
        if (!logJson.containsKey("src_ip")) {
            return retJson;
        }
        String behavior = logJson.getString(LogConstants.BEHAVIOR_TAG);
        if (!scanTypeMap.containsKey(behavior) && !behavior.contains("scan_")) {
            String srcIp = JsonUtils.getStr(logJson, "src_ip");
            String dstIp = JsonUtils.getStr(logJson, "dst_ip");
            String url = JsonUtils.getStr(logJson, "url");
            String account = JsonUtils.getStr(logJson, "account");

            String eventIdInfo = "";
            if (StringUtils.isNotBlank(evtId)) {
                eventIdInfo = "，原始日志ID:" + evtId;
            }
            if ("leak_password".equals(behavior)) {
                String alertName = String.format("主机尝试web弱口令登录，源IP：%s、目的IP：%s，访问链接为%s，账号信息为%s", srcIp, dstIp, url, account) + eventIdInfo;
                logJson.put(LogConstants.ALERT_NAME, alertName);
            } else if ("successful_attack".equals(behavior)) {
                String alertName = String.format("攻击成功事件，源IP：%s、目的IP：%s", srcIp, dstIp) + eventIdInfo;
                logJson.put(LogConstants.ALERT_NAME, alertName);
            }
            logJson.put(LogConstants.DEST_IP, dstIp);
            String sourcePlatform = JsonUtils.getStr(logJson, "source_platform");
            if (StringUtils.isNotBlank(sourcePlatform)) {
                String newAlertName = JsonUtils.getStr(logJson, LogConstants.ALERT_NAME) + "，告警来源为" + sourcePlatform;
                logJson.put(LogConstants.ALERT_NAME, newAlertName);
            }
            return retJson;
        }
        String eventIdInfo = "";
        if (StringUtils.isNotBlank(evtId)) {
            eventIdInfo = "，原始日志ID:" + evtId;
        }

        String dst_ip = logJson.getString("dst_ip");//源IP
        String unique_count_of_dst_ip = logJson.getString("unique_count_of_dst_ip");//不同目的IP的个数
        String last_8_dst_ip = logJson.getString("last_8_dst_ip");//源IP
        String last_8_dst_port = logJson.getString("last_8_dst_port");//源IP
        String unique_count_of_dst_port = logJson.getString("unique_count_of_dst_port");//源IP
        ScanType scanType = scanTypeMap.get(behavior);
        if (behavior.contains("scan_") && !behavior.contains("scan_nmap_port")) {
            String port = behavior.replace("scan_", "");
            String portInfo;
            if (port.contains("_")) {
                //scan_80_443
                portInfo = "";
                for (String portx : DataUtils.getSplit(port, "_")) {
                    if (StringUtils.isBlank(portInfo)) {
                        portInfo = String.format("扫描%s端口", portx);
                    } else {
                        portInfo = portInfo + String.format("和%s端口", portx);
                    }
                }
            } else {
                portInfo = String.format("扫描%s端口", port);
            }
            scanType = new ScanType(1, portInfo);
        }
        String src_ip = MapUtils.getStr(newDataJson, "src_ip");
        List<String> objectList = Arrays.asList("", src_ip, scanType.getScanDesc(),
                unique_count_of_dst_ip, last_8_dst_ip, dst_ip, unique_count_of_dst_port, last_8_dst_port);
        String[] valueList = new String[objectList.size()];
        objectList.toArray(valueList);

        if (scanType.getScanType() == 1) {
            MessageFormat form = new MessageFormat("{1}正在{2}");
            String logName = form.format(valueList);
            form = new MessageFormat("主机【{1}】10分钟内扫描{3}个主机的{2}，最近8个主机{4}");
            String logDescription = form.format(valueList);
            newDataJson.put(LogConstants.LOG_NAME, logName);
            newDataJson.put(LogConstants.LOG_LEVEL, "中风险");
            newDataJson.put(LogConstants.LOG_DESCRIPTION, logDescription);
            newDataJson.put(LogConstants.ALERT_NAME, logDescription);
            newDataJson.put(LogConstants.LOG_TYPE, "内网横向扫描");
            newDataJson.put(LogConstants.DEST_IP, last_8_dst_ip);
        } else if (scanType.getScanType() == 2) {
            MessageFormat form = new MessageFormat("{1}对{5}进行端口扫描");
            String logName = form.format(valueList);
            form = new MessageFormat("主机【{1}】10分钟内扫描主机【{5}】{6}个扫描器常用端口，最近10个端口：{7}");
            String logDescription = form.format(valueList);
            newDataJson.put(LogConstants.LOG_NAME, logName);
            newDataJson.put(LogConstants.LOG_LEVEL, "高风险");
            newDataJson.put(LogConstants.LOG_DESCRIPTION, logDescription);
            newDataJson.put(LogConstants.ALERT_NAME, logDescription);
            newDataJson.put(LogConstants.LOG_TYPE, "内网横向扫描");
            newDataJson.put(LogConstants.DEST_IP, dst_ip);
        } else if (scanType.getScanType() == 3) {
            MessageFormat form = new MessageFormat("主机【{1}】正在对主机【{5}】进行{2}");
            String logName = form.format(valueList);
            form = new MessageFormat("主机【{1}】正在对主机【{5}】进行{2}");
            String logDescription = form.format(valueList);
            newDataJson.put(LogConstants.LOG_NAME, logName);
            newDataJson.put(LogConstants.LOG_LEVEL, "高风险");
            newDataJson.put(LogConstants.LOG_DESCRIPTION, logDescription);
            newDataJson.put(LogConstants.ALERT_NAME, logDescription);
            newDataJson.put(LogConstants.LOG_TYPE, "系统漏洞利用");
            newDataJson.put(LogConstants.DEST_IP, dst_ip);
        } else if (scanType.getScanType() == 4) {
            MessageFormat form = new MessageFormat("主机【{1}】正在对主机【{5}】进行{2}");
            String logName = form.format(valueList);
            form = new MessageFormat("主机【{1}】正在对主机【{5}】进行{2}");
            String logDescription = form.format(valueList);
            newDataJson.put(LogConstants.LOG_NAME, logName);
            newDataJson.put(LogConstants.LOG_LEVEL, "高风险");
            newDataJson.put(LogConstants.LOG_DESCRIPTION, logDescription);
            newDataJson.put(LogConstants.ALERT_NAME, logDescription);
            newDataJson.put(LogConstants.LOG_TYPE, "系统漏洞利用");
            newDataJson.put(LogConstants.DEST_IP, dst_ip);
        }
        String sourcePlatform = JsonUtils.getStr(logJson, "source_platform");
        String log = JsonUtils.getStr(logJson, LogConstants.LOG_ORI_MSG);
        if (StringUtils.isNotBlank(sourcePlatform)) {
            String newAlertName = MapUtils.getStr(newDataJson, LogConstants.ALERT_NAME) + "，告警来源为" + sourcePlatform + eventIdInfo + "日志详情为:" + log;
            newDataJson.put(LogConstants.ALERT_NAME, newAlertName);
        }
        newDataJson.put(LogConstants.LOG_LEVEL, LevelConstants.getLevel(MapUtils.getStr(newDataJson, LogConstants.LOG_LEVEL)));
        if (behavior.equalsIgnoreCase("ty_ip_ban") || behavior.equalsIgnoreCase("sip_ip_ban")) {
            newDataJson.put(LogConstants.LOG_LEVEL, LevelConstants.HIGH);
        }

        if (StringUtils.isBlank(MapUtils.getStr(newDataJson, LogConstants.SRC_IP))) {
            newDataJson.put(LogConstants.SRC_IP, "0.0.0.0");
        }
        if (StringUtils.isBlank(MapUtils.getStr(newDataJson, LogConstants.DEST_IP))) {
            newDataJson.put(LogConstants.DEST_IP, "0.0.0.0");
        }
        return retJson;
    }

    static class ScanType {

        private Integer scanType;

        private String scanDesc;

        public ScanType(Integer scanType, String scanDesc) {
            this.scanType = scanType;
            this.scanDesc = scanDesc;
        }

        public Integer getScanType() {
            return scanType;
        }

        public void setScanType(Integer scanType) {
            this.scanType = scanType;
        }

        public String getScanDesc() {
            return scanDesc;
        }

        public void setScanDesc(String scanDesc) {
            this.scanDesc = scanDesc;
        }
    }
}
