package com.crc.log.flink.test.log;

import com.crc.log.flink.common.utils.JsonUtils;
import com.crc.log.flink.config.AllConfig;
import com.crc.log.flink.es.DataProcessFuncation;

import java.util.concurrent.ConcurrentHashMap;

public class VPNTest {
    public static void main(String[] args) {
        String msgx = "<173>May 25 17:23:37 sslvpn SVPN-USR[18234]: {\"id\":\"35499304982\",\"msgid\":\"568105\",\"userInfo\":{\"userName\":\"80033556\",\"groupId\":14,\"groupPath\":\"/成员公司/东方集团\",\"authMethods\":\"auth_local_pass\"},\"clientInfo\":{\"ip\":\"122.224.210.242\",\"vip\":\"\",\"osType\":\"WINDOWS\",\"macAddr\":\"\",\"deviceID\":\"A8A6FC23\"},\"msg\":\"[accessIP: 122.224.210.242] Log in successfully!MAC:38-f3-ab-95-c0-f0,HOST:DESKTOP-GQMKKH8,OS:Windows\",\"timeStamp\":1653470617,\"time\":\"2022-05-25 17:23:37\",\"type\":\"userlog\",\"logSubType\":\"login\",\"rcip\":\"\",\"actionResult\":\"success\"}";
        AllConfig config = new AllConfig();
        DataProcessFuncation.CONIFG = config;
        config.setMode("single");
        config.setParse("ResolvSsLVpnlog");
        config.setIndex("user_all");


        ConcurrentHashMap<String, Object> json = DataProcessFuncation.parse(msgx,"index");
        JsonUtils.printStr(json);
    }
}
