package com.crc.log.flink.common.utils;

import org.apache.commons.lang3.StringUtils;

import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.TimeZone;

/**
 * @author simba@onlying.cn
 * @date 2020/7/23 10:30
 */
public class DateUtils {

    public static final String DATE_TIME_FORMAT_STRING3 = "yyyy-MM-dd HH:mm:ss:SSS";

    private static final String ES_TIME_FORMAT = "yyyy-MM-dd'T'HH:mm:ss.SSSZ";
    private static final String ES_TIME_FORMAT1 = "yyyy-MM-dd'T'HH:mm:ss";
    private static final String DATE_TIME_FORMAT_STRING10 = "yyyy-MM-dd 00:00";
    private static final String DATE_TIME_FORMAT_STRING11 = "yyyy-MM-dd 00:00:00";
    public static final String DATE_TIME_FORMAT_STRING1 = "yyyy-MM-dd HH:mm:ss";
    private static final String DATE_FORMAT_STRING5 = "yyyy.MM.dd";

    private static final String DATE_FORMAT_HOUR = "yyyy-MM-dd HH";

    private static final String DATE_FORMAT_STRING1 = "yyyy-MM-dd HH:mm:ss";

    private static final String[] parsePatterns = {
            "yyyy-MM-dd", "yyyy-MM-dd HH:mm:ss", "yyyy-MM-dd HH:mm", "yyyy-MM",
            "yyyy/MM/dd", "yyyy/MM/dd HH:mm:ss", "yyyy/MM/dd HH:mm", "yyyy/MM",
            "yyyy.MM.dd", "yyyy.MM.dd HH:mm:ss", "yyyy.MM.dd HH:mm", "yyyy.MM"};

    /**
     * 获取日期格式 yyyy-MM-dd
     *
     * @return 根据天数返回日期
     */
    @SuppressWarnings("deprecation")
    public static String getDate(int day) {
        Date date = new Date();
        if (day != 0) {
            date.setDate(date.getDate() + day);
        }
        return new SimpleDateFormat("yyyy-MM-dd").format(date);
    }

    public static Date parseDateTime(String date) {
        if (StringUtils.isBlank(date)) {
            return new Date();
        }
        SimpleDateFormat format = new SimpleDateFormat(DATE_FORMAT_STRING1);
        try {
            return format.parse(date);
        } catch (Exception ignored) {
        }
        return new Date();
    }

    public static String getDateTimeString1(Date date) {
        return getDateTimeString(DATE_FORMAT_STRING1, date);
    }

    /**
     * @param dateTimeFormat
     * @param date
     * @return
     */
    private static String getDateTimeString(String dateTimeFormat, Date date) {
        SimpleDateFormat format = new SimpleDateFormat(dateTimeFormat);
        return format.format(date);
    }

    public static String getDate5(int day) {
        Date date = new Date();
        if (day != 0) {
            date.setDate(date.getDate() + day);
        }
        SimpleDateFormat sdf8 = new SimpleDateFormat(DATE_FORMAT_STRING5);
        return sdf8.format(date);
    }

    public static String minusHours(Date date) {
        Date afterDate = new Date(date.getTime() - 60000 * 60);
        SimpleDateFormat sdf8 = new SimpleDateFormat(ES_TIME_FORMAT);
        sdf8.setTimeZone(TimeZone.getTimeZone("GMT+8:00"));
        return sdf8.format(afterDate);
    }

    public static String minusMinutes(Date date, Integer minutes) {
        Date afterDate = new Date(date.getTime() - 60000L * minutes);
        SimpleDateFormat sdf8 = new SimpleDateFormat(ES_TIME_FORMAT);
        sdf8.setTimeZone(TimeZone.getTimeZone("GMT+8:00"));
        return sdf8.format(afterDate);
    }

    public static String[] resolveTimeByMinusHour(Date date) {
        String[] times = new String[2];
        Date afterDate = new Date(date.getTime() - 60000 * 60);
        SimpleDateFormat sdf8 = new SimpleDateFormat(ES_TIME_FORMAT);
        sdf8.setTimeZone(TimeZone.getTimeZone("GMT+8:00"));
        times[0] = sdf8.format(date);
        times[1] = sdf8.format(afterDate);
        return times;
    }

    public static String[] resolveTimeByMinusDays(Date date) {
        String[] times = new String[2];
        Calendar calendar = Calendar.getInstance();
        calendar.setTime(date);
        calendar.add(Calendar.DAY_OF_YEAR, -1);
        SimpleDateFormat sdf8 = new SimpleDateFormat(ES_TIME_FORMAT);
        sdf8.setTimeZone(TimeZone.getTimeZone("GMT+8:00"));
        times[0] = sdf8.format(date);
        times[1] = sdf8.format(calendar.getTime());
        return times;
    }

    public static String[] resolveTimeByMinusWeeks(Date date) {
        String[] times = new String[2];
        Calendar calendar = Calendar.getInstance();
        calendar.setTime(date);
        calendar.add(Calendar.WEEK_OF_YEAR, -1);
        SimpleDateFormat sdf8 = new SimpleDateFormat(ES_TIME_FORMAT);
        sdf8.setTimeZone(TimeZone.getTimeZone("GMT+8:00"));
        times[0] = sdf8.format(date);
        times[1] = sdf8.format(calendar.getTime());
        return times;
    }

    public static String[] resolveTimeByMinusMonths(Date date) {
        String[] times = new String[2];
        Calendar calendar = Calendar.getInstance();
        calendar.setTime(date);
        calendar.add(Calendar.MONTH, -1);
        SimpleDateFormat sdf8 = new SimpleDateFormat(ES_TIME_FORMAT);
        sdf8.setTimeZone(TimeZone.getTimeZone("GMT+8:00"));
        times[0] = sdf8.format(date);
        times[1] = sdf8.format(calendar.getTime());
        return times;
    }


    public static String getCurrentDayFormat5() {
        SimpleDateFormat sdf8 = new SimpleDateFormat(DATE_FORMAT_STRING5);
        return sdf8.format(new Date());
    }

    public static String getHourFormatString(Date date) {
        SimpleDateFormat sdf8 = new SimpleDateFormat(DATE_FORMAT_HOUR);
        return sdf8.format(date);
    }

    public static String getTimeFormatString(Date date) {
        SimpleDateFormat sdf8 = new SimpleDateFormat(DATE_FORMAT_STRING1);
        return sdf8.format(date);
    }

    public static String minusMinute5(Date date) {
        Date afterDate = new Date(date.getTime() - 60000 * 5);
        SimpleDateFormat sdf8 = new SimpleDateFormat(ES_TIME_FORMAT);
        sdf8.setTimeZone(TimeZone.getTimeZone("GMT+8:00"));
        return sdf8.format(afterDate);
    }

    public static String getSparkTime() {
        SimpleDateFormat sdf8 = new SimpleDateFormat(ES_TIME_FORMAT);
        sdf8.setTimeZone(TimeZone.getTimeZone("GMT+8:00"));
        return sdf8.format(new Date());
    }

    public static String getSparkTime(Date date) {
        SimpleDateFormat sdf8 = new SimpleDateFormat(ES_TIME_FORMAT);
        sdf8.setTimeZone(TimeZone.getTimeZone("GMT+8:00"));
        return sdf8.format(date);
    }

    public static String getUTCTime(Date date) {
        SimpleDateFormat sdf8 = new SimpleDateFormat(ES_TIME_FORMAT);
        sdf8.setTimeZone(TimeZone.getTimeZone("UTC"));
        return sdf8.format(date);
    }

    public static String getYear() {
        Date nowDate = new Date();
        Calendar calendar = Calendar.getInstance();
        calendar.setTime(nowDate);
        return String.valueOf(calendar.get(Calendar.YEAR));
    }

    public static Date parseSparkTime(String logTime) {
        if (StringUtils.isBlank(logTime)) {
            return new Date();
        }
        SimpleDateFormat format = new SimpleDateFormat(ES_TIME_FORMAT1);
        try {
            format.setTimeZone(TimeZone.getTimeZone("GMT+8:00"));
            return format.parse(logTime);
        } catch (Exception ignored) {

        }
        return new Date();
    }

    public static boolean isDate(String str) {
        if (StringUtils.isBlank(str)) {
            return false;
        }
        boolean result = true;
        SimpleDateFormat format = new SimpleDateFormat(DATE_FORMAT_STRING1);
        try {
            format.setLenient(false);
            format.parse(str);
        } catch (Exception e) {
            result = false;
        }
        return result;

    }

    public static String getNowDateWithTimeZone(Date date) {
        SimpleDateFormat sdf8 = new SimpleDateFormat(ES_TIME_FORMAT);
        sdf8.setTimeZone(TimeZone.getTimeZone("GMT+0:00"));
        return sdf8.format(date);

    }

    /**
     * 传入Data类型日期，返回字符串类型时间（ISO8601标准时间）
     *
     * @param date
     * @return
     */
    public static String getISO8601Timestamp(Date date) {
        if (date == null) {
            date = new Date();
        }
        Date curDate = new Date();
        if (date.after(curDate)) {
            date = curDate;
        }
        SimpleDateFormat sdf8 = new SimpleDateFormat(ES_TIME_FORMAT);
        sdf8.setTimeZone(TimeZone.getTimeZone("GMT+8:00"));
        return sdf8.format(date);
    }

    /**
     * 传入Data类型日期，返回字符串类型时间（ISO8601标准时间）
     *
     * @param time
     * @return
     */
    public static String getISO8601Timestamp(long time) {
        Date date;
        if (time < 10000L) {
            date = new Date();
        } else {
            date = new Date(time);
        }
        SimpleDateFormat sdf8 = new SimpleDateFormat(ES_TIME_FORMAT);
        sdf8.setTimeZone(TimeZone.getTimeZone("GMT+8:00"));
        return sdf8.format(date);
    }

    //通用yyyy-MM-dd HH:mm:ss解析日期再转换
    public static String getISO8601Timestamp(String dateStr) {
        if (StringUtils.isBlank(dateStr)) {
            return getISO8601Timestamp(new Date());
        }
        Date date = null;
        try {
            date = parseDateTime(DATE_TIME_FORMAT_STRING1, dateStr);
            Date curDate = new Date();
            if (date.after(curDate)) {
                date = curDate;
            }
        } catch (Exception ignored) {

        }
        if (date == null) {
            date = new Date();
        }
        return getISO8601Timestamp(date);
    }

    public static String getQingtengTime(String msg) {
        if (StringUtils.isBlank(msg)) {
            return getISO8601Timestamp(new Date());
        }
        try {
            String[] app = msg.split(" ");
            String year = DateUtils.getYear();
            String[] months = {"Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"};
            String month = "";
            for (int i = 0; i < months.length; i++) {
                if (app[0].contains(months[i])) {
                    month = String.format("%02d", i + 1);
                }
            }
            String day = app[1];
            String hhmmss = app[2];
            String dateTime = String.format("%s-%s-%s %s", year, month, day, hhmmss);
            return DateUtils.getISO8601Timestamp(dateTime);
        } catch (Exception ignored) {

        }
        return DateUtils.getISO8601Timestamp(new Date());
    }


    /**
     * @param dateTimeFormat
     * @param date
     * @return
     * @throws ParseException
     */
    public static Date parseDateTime(String dateTimeFormat, String date)  {
        if (StringUtils.isBlank(date)) {
            return new Date();
        }
        try {
            SimpleDateFormat format = new SimpleDateFormat(dateTimeFormat);
            return format.parse(date);
        } catch (Exception ignored) {

        }
        return new Date();
    }

    /**
     * 日期型字符串转化为日期 格式
     */
    public static Date parseDate(Object str) {
        if (str == null) {
            return null;
        }
        try {
            return org.apache.commons.lang3.time.DateUtils.parseDate(str.toString(), parsePatterns);
        } catch (Exception e) {
            return null;
        }
    }

    /**
     * 获取现在时间
     */
    public static String getTime(String DATE_TIME_FORMAT) {
        Date date = new Date();
        SimpleDateFormat sdf8 = new SimpleDateFormat(ES_TIME_FORMAT);
        sdf8.setTimeZone(TimeZone.getTimeZone("GMT+8:00"));
        return sdf8.format(date);
    }

    public static String UTCToCST(String UTCStr) {
        if (StringUtils.isBlank(UTCStr)) {
            SimpleDateFormat sdf2 = new SimpleDateFormat(DATE_FORMAT_STRING1);
            return sdf2.format(new Date());
        }
        Date date = null;
        SimpleDateFormat sdf = new SimpleDateFormat(ES_TIME_FORMAT1);
        Calendar calendar = Calendar.getInstance();
        try {
            date = sdf.parse(UTCStr);
            calendar.setTime(date);
            calendar.set(Calendar.HOUR, calendar.get(Calendar.HOUR) + 8);
            //calendar.getTime() 返回的是Date类型，也可以使用calendar.getTimeInMillis()获取时间戳
            SimpleDateFormat sdf2 = new SimpleDateFormat(DATE_FORMAT_STRING1);
            return sdf2.format(calendar.getTime());
        } catch (Exception ignored) {
        }
        return null;

    }

    public static String getDate1(int day) {
        Date date = new Date();
        if (day != 0) {
            date.setDate(date.getDate() + day);
        }
        return new SimpleDateFormat("yyyy.MM.dd").format(date);
    }

    public static String getMon(int day) {
        Date date = new Date();
        if (day != 0) {
            date.setDate(date.getDate() + day);
        }
        return new SimpleDateFormat("yyyy.MM").format(date);
    }

    public static String getYear(int day) {
        Date date = new Date();
        if (day != 0) {
            date.setDate(date.getDate() + day);
        }
        return new SimpleDateFormat("yyyy").format(date);
    }

    public static String getISO8601Timestamp2(String dateStr, String pattern) {
        Date date = null;
        if (StringUtils.isNotBlank(dateStr)) {
            try {
                date = parseDateTime(pattern, dateStr);
            } catch (Exception ignored) {

            }
        }
        if (date == null) {
            date = new Date();
        }
        Date curDate = new Date();
        if (date.after(curDate))
            date = curDate;
        TimeZone tz = TimeZone.getTimeZone("GMT+0:00");
        DateFormat df = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss.SSS'Z'");
        df.setTimeZone(tz);
        return df.format(date);
    }

    public static String getISO8601Timestamp(String dateStr, String format) {
        Date date = null;
        if (StringUtils.isNotBlank(dateStr)) {
            try {
                date = parseDateTime(format, dateStr);
            } catch (Exception ignored) {

            }
        }
        if (date == null) {
            date = new Date();
        }
        Date curDate = new Date();
        if (date.after(curDate))
            date = curDate;
        return getISO8601Timestamp(date);
    }
}
