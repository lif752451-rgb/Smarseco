package com.crc.log.flink.parse;

import com.crc.log.flink.common.constants.LevelConstants;
import com.crc.log.flink.common.constants.LogConstants;
import com.crc.log.flink.common.utils.DataUtils;
import com.crc.log.flink.common.utils.DateUtils;
import com.crc.log.flink.common.utils.JsonUtils;
import com.crc.log.flink.common.utils.MapUtils;
import org.apache.commons.lang3.StringUtils;

import java.util.HashMap;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

/**
 * @author jixiangqi
 * @date 2022/4/28
 * 绿盟waf
 */
public class ResolvLvMengWafLog {
    public static ConcurrentHashMap<String, Object> parse(String message) {
        try {
            ConcurrentHashMap<String, Object> data = proc(message);
            if (DataUtils.isNotEmptyJson(data)) {
                return data;
            }
        } catch (Exception ignored) {

        }
        return null;
    }

    private static ConcurrentHashMap<String, Object> proc(String jsonStr) {
        ConcurrentHashMap<String, Object> rtnObjc = JsonUtils.createBaseMap(jsonStr);
        Map<String, String> stringMap = getKeyValueBySpace(jsonStr);
        stringMap.forEach((k,v) -> {
            switchKeyValue(rtnObjc, k, v);
        });
        rtnObjc.put(LogConstants.LOG_PRODUCT, "绿盟WAF");
        if (StringUtils.isBlank(MapUtils.getStr(rtnObjc, LogConstants.SRC_IP))) {
            rtnObjc.put(LogConstants.SRC_IP, "0.0.0.0");
        }
        if (StringUtils.isBlank(MapUtils.getStr(rtnObjc, LogConstants.DEST_IP))) {
            rtnObjc.put(LogConstants.DEST_IP, "0.0.0.0");
        }
        setAlertName(rtnObjc);
        return rtnObjc;
    }

    private static void setAlertName(ConcurrentHashMap<String, Object> rtnObjc) {
        String srcIp = MapUtils.getStr(rtnObjc, LogConstants.SRC_IP);
        String destIp = MapUtils.getStr(rtnObjc, LogConstants.DEST_IP);
        String logType = MapUtils.getStr(rtnObjc, LogConstants.LOG_TYPE);
        String logLevel = MapUtils.getStr(rtnObjc, LogConstants.LOG_LEVEL);
        String logCount = MapUtils.getStr(rtnObjc, LogConstants.LOG_COUNT);
        String proto = MapUtils.getStr(rtnObjc, LogConstants.LOG_PROTOCAL);
        String actionResult = MapUtils.getStr(rtnObjc, LogConstants.ACTION_RESULT);
        String log = MapUtils.getStr(rtnObjc, LogConstants.LOG_ORI_MSG);
        String message = "IP地址为:%s对IP为:%s的设备进行了一个%s类型的事件,攻击次数为:%s,攻击结果为:%s,事件级别为:%s,攻击协议为:%s,日志详情为:%s";
        String alertName = String.format(message, srcIp, destIp, logType, logCount, actionResult, logLevel, proto, log);
        rtnObjc.put(LogConstants.ALERT_NAME, alertName);

    }


    private static void switchKeyValue(ConcurrentHashMap<String, Object> rtnObjc, String key, String value) {
        switch (key) {
            case "stat_time":
                rtnObjc.put(LogConstants.LOG_START_TIME, DateUtils.getISO8601Timestamp(value.trim(), "yyyy-MM-dd HH:mm:ss"));
                break;
            case "alertlevel":
                rtnObjc.put(LogConstants.LOG_LEVEL, LevelConstants.getLevel(value));
                break;
            case "event_type":
                rtnObjc.put(LogConstants.LOG_TYPE, value);
                break;
            case "dst_ip":
                rtnObjc.put(LogConstants.DEST_IP, value);
                break;
            case "dst_port":
                rtnObjc.put(LogConstants.DEST_PORT, value);
                break;
            case "src_ip":
                rtnObjc.put(LogConstants.SRC_IP, value);
                break;
            case "src_port":
                rtnObjc.put(LogConstants.SRC_PORT, value);
                break;
            case "url":
                rtnObjc.put(LogConstants.LOG_URL, value);
                break;
            case "count_num":
                rtnObjc.put(LogConstants.LOG_COUNT, value);
                break;
            case "wa_host":
                rtnObjc.put(LogConstants.HOST_NAME, value);
                break;
            case "protocol_type":
                rtnObjc.put(LogConstants.LOG_PROTOCAL, value);
                break;
            case "action":
                String actionResult = "";
                switch (value.trim()) {
                    case "Other":
                        actionResult = "放过";
                        break;
                    case "Forward":
                        actionResult = "放过";
                        break;
                    case "Block":
                        actionResult = "阻断";
                        break;
                    case "Accept":
                        actionResult = "接受";
                        break;
                    case "Redirect":
                        actionResult = "重定向";
                        break;
                    case "Pretend":
                        actionResult = "伪装";
                        break;
                    case "Set":
                        actionResult = "设定";
                        break;
                    case "Clear":
                        actionResult = "清除";
                        break;
                    case "Replace":
                        actionResult = "替换";
                        break;
                }
                rtnObjc.put(LogConstants.ACTION_RESULT, actionResult);
                break;
        }
    }



    private static Map<String, String> getKeyValueBySpace(String jsonStr) {
        Map<String, String> resultMap = new HashMap<>();
        String keyIndex = "";
        String[] split = DataUtils.getSplit(jsonStr, " ");
        for (String tempStr : split) {
            if (tempStr.contains(":")) {
                int index = DataUtils.getIndex(tempStr, ":");
                String key = DataUtils.getSubString(tempStr, 0, index).trim();
                String value = DataUtils.getSubString(tempStr, index + 1).trim();
                resultMap.put(key, value);
                keyIndex = key;
            } else {
                resultMap.put(keyIndex, resultMap.get(keyIndex) + " " + tempStr);
            }
        }
        return resultMap;
    }
}
