package com.crc.log.flink.parse;

import com.crc.log.flink.common.constants.LevelConstants;
import com.crc.log.flink.common.constants.LogConstants;
import com.crc.log.flink.common.utils.DataUtils;
import com.crc.log.flink.common.utils.DateUtils;
import com.crc.log.flink.common.utils.JsonUtils;
import com.crc.log.flink.common.utils.MapUtils;
import org.apache.commons.lang3.StringUtils;

import java.util.LinkedList;
import java.util.List;
import java.util.concurrent.ConcurrentHashMap;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * @author jixiangqi
 * @date 2021/12/8
 * 启明星辰ADS
 */
public class ResolvQmxcAdsLog {

    public static ConcurrentHashMap<String,Object> parse(String message) {
        try {
            ConcurrentHashMap<String,Object> data = proc(message);
            if (DataUtils.isNotEmptyJson(data)) {
                return data;
            }
        } catch (Exception ignored) {

        }
        return null;
    }

    private static ConcurrentHashMap<String,Object> proc(String jsonStr) {
        ConcurrentHashMap<String,Object> rtnObjc = JsonUtils.createBaseMap(jsonStr);
        Pattern p = Pattern.compile("\\{([^\\}]+)\\}");
        Matcher m = p.matcher(jsonStr);
        List<String> dataList = new LinkedList<>();
        while (m.find()) {
            try {
                String data = m.group().substring(1, m.group().length() - 1);
                dataList.add(data);
            } catch (Exception ignored) {

            }
        }
        for (String temp : dataList) {
            String[] split = DataUtils.getSplit(temp, ",");
            //temp.split(",");
            for (String info : split) {
                int index = DataUtils.getIndex(info, ":");
                //info.indexOf(":");
                String key = DataUtils.getSubString(info, 0, index);
                if (StringUtils.isNotBlank(key)) {
                    key = key.replaceAll("\"", "");
                }
                //info.substring(0, index).replaceAll("\"", "");
                String value = DataUtils.getSubString(info, index + 1);
                if (StringUtils.isNotBlank(value)) {
                    value = value.replaceAll("\"", "");
                }
                switch (key) {
                    case "Domain_name":
                        rtnObjc.put(LogConstants.LOG_TYPE, value);
                        break;
                    case "dst_ip":
                        rtnObjc.put(LogConstants.DEST_IP, value);
                        break;
                    case "dst_port":
                        rtnObjc.put(LogConstants.DEST_PORT, value);
                        break;
                    case "src_ip":
                        rtnObjc.put(LogConstants.SRC_IP, value);
                        break;
                    case "src_port":
                        rtnObjc.put(LogConstants.SRC_PORT, value);
                        break;
                    case "timestamp":
                        rtnObjc.put(LogConstants.LOG_START_TIME, DateUtils.getISO8601Timestamp(value, "yyyy-MM-dd HH:mm:ss"));
                        break;
                    case "defend_type":
                        rtnObjc.put(LogConstants.ACTION_TYPE, value);
                        break;
                    case "country_cn_name":
                        rtnObjc.put(LogConstants.SRC_ZONE, value);
                        break;
                    case "Domain":
                        rtnObjc.put(LogConstants.LOG_TYPE, value);
                        break;
                    case "attack_type":
                        rtnObjc.put(LogConstants.ACTION_TYPE, value);
                        break;
                    case "start_time":
                        rtnObjc.put(LogConstants.LOG_START_TIME, DateUtils.getISO8601Timestamp(value, "yyyy-MM-dd HH:mm:ss"));
                        break;
                    case "attack_state":
                        rtnObjc.put(LogConstants.ACTION_RESULT, value);
                        break;
                }
            }
            rtnObjc.put(LogConstants.LOG_PRODUCT, "启明星辰ADS");
            rtnObjc.put(LogConstants.LOG_LEVEL, LevelConstants.getLevel(MapUtils.getStr(rtnObjc,LogConstants.LOG_LEVEL)));
            if (StringUtils.isBlank(MapUtils.getStr(rtnObjc, LogConstants.SRC_IP))) {
                rtnObjc.put(LogConstants.SRC_IP, "0.0.0.0");
            }
            if (StringUtils.isBlank(MapUtils.getStr(rtnObjc, LogConstants.DEST_IP))) {
                rtnObjc.put(LogConstants.DEST_IP, "0.0.0.0");
            }
            setAlertName(rtnObjc);
        }
        return rtnObjc;
    }


    private static void setAlertName(ConcurrentHashMap<String,Object> rtnObjc) {
        String srcIp = MapUtils.getStr(rtnObjc, LogConstants.SRC_IP);
        String destIp = MapUtils.getStr(rtnObjc, LogConstants.DEST_IP);
        String actionType = MapUtils.getStr(rtnObjc, LogConstants.ACTION_TYPE);
        String level = MapUtils.getStr(rtnObjc, LogConstants.LOG_LEVEL);
        String logType = MapUtils.getStr(rtnObjc, LogConstants.LOG_TYPE);
        String result = MapUtils.getStr(rtnObjc, LogConstants.ACTION_RESULT);
        String log = MapUtils.getStr(rtnObjc, LogConstants.LOG_ORI_MSG);
        String msgFormat = "";
        String alertName = "";
        if (!StringUtils.isBlank(result)) {
            msgFormat = "IP:%s对IP:%s发起了一个%s类型的攻击,事件类型为:%s,攻击结果为:%s,事件级别:%s,日志详情为:%s";
            alertName = String.format(msgFormat, srcIp, destIp, actionType, logType, result,level, log);
        } else {
            msgFormat = "IP:%s对IP:%s发起了一个%s类型的攻击,事件类型为:%s,事件级别:%s,日志详情为:%s";
            alertName = String.format(msgFormat, srcIp, destIp, actionType, logType, level, log);
        }

        rtnObjc.put(LogConstants.ALERT_NAME, alertName);
    }
}
