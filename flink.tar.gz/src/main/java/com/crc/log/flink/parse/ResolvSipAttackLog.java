package com.crc.log.flink.parse;

import com.alibaba.fastjson.JSONObject;
import com.crc.log.flink.common.constants.LevelConstants;
import com.crc.log.flink.common.constants.LogConstants;
import com.crc.log.flink.common.utils.DataUtils;
import com.crc.log.flink.common.utils.JsonUtils;
import com.crc.log.flink.common.utils.MapUtils;
import org.apache.commons.lang3.StringUtils;

import java.util.concurrent.ConcurrentHashMap;

/**
 * 深信服SIP-攻击事件
 */
@SuppressWarnings("unchecked")
public class ResolvSipAttackLog {
    public static ConcurrentHashMap<String, Object> parse(String message) {
        try {
            ConcurrentHashMap<String, Object> data = proc(message);
            if (DataUtils.isNotEmptyJson(data)) {
                return data;
            }
        } catch (Exception ignored) {

        }
        return null;
    }

    private static ConcurrentHashMap<String, Object> proc(String value) {
        ConcurrentHashMap<String, Object> data = JsonUtils.createBaseMap(value);
        JSONObject jsonObj = JsonUtils.parse(value);
        if (DataUtils.isNotEmptyJson(jsonObj)) {
            MapUtils.setStr(data, LogConstants.LOG_NAME, "SIP攻击事件");
            MapUtils.setStr(data, LogConstants.DEST_IP, jsonObj, "dest_ip");
            MapUtils.setStr(data, LogConstants.SRC_IP, jsonObj, "src_ip");
            MapUtils.setStr(data, LogConstants.SRC_PORT, jsonObj, "src_port");
            MapUtils.setStr(data, LogConstants.DEST_PORT, jsonObj, "dest_port");
            MapUtils.setStr(data, LogConstants.ACTION_TYPE, jsonObj, "module_attack_type");
            MapUtils.setStr(data, LogConstants.LOG_START_TIME, jsonObj, "record_date");
            MapUtils.setStr(data, LogConstants.MSG_CONTENT, jsonObj, "result");
            MapUtils.setStr(data, LogConstants.LOG_PRODUCT, "深信服SIP");
        }
        data.put(LogConstants.LOG_LEVEL, LevelConstants.getLevel(MapUtils.getStr(data,LogConstants.LOG_LEVEL)));
        if (StringUtils.isBlank(MapUtils.getStr(data, LogConstants.SRC_IP))) {
            data.put(LogConstants.SRC_IP, "0.0.0.0");
        }
        if (StringUtils.isBlank(MapUtils.getStr(data, LogConstants.DEST_IP))) {
            data.put(LogConstants.DEST_IP, "0.0.0.0");
        }
        setAlertName(data);
        return data;
    }

    public static void setAlertName(ConcurrentHashMap<String, Object> resultJson) {
        String srcIp = MapUtils.getStr(resultJson,LogConstants.SRC_IP);
        String destIp = MapUtils.getStr(resultJson,LogConstants.DEST_IP);
        String actionType = MapUtils.getStr(resultJson,LogConstants.ACTION_TYPE);
        String logName = MapUtils.getStr(resultJson,LogConstants.LOG_NAME);
        String log = MapUtils.getStr(resultJson,LogConstants.LOG_ORI_MSG);
        if (StringUtils.isBlank(destIp) || "null".equals(destIp) || "0.0.0.0".equals(destIp) || srcIp.equals(destIp)) {
            String messageFormat = "%s 发起 %s-%s,日志详情为:%s";
            String alertName = String.format(messageFormat, srcIp, actionType, logName, log);
            resultJson.put(LogConstants.ALERT_NAME, alertName);
        } else {
            String messageFormat = "%s 对 %s 进行 %s-%s,日志详情为:%s";
            String alertName = String.format(messageFormat, srcIp, destIp, actionType, logName, log);
            resultJson.put(LogConstants.ALERT_NAME, alertName);
        }
    }
}
