package com.crc.log.flink.test.log;

import com.crc.log.flink.common.utils.JsonUtils;
import com.crc.log.flink.config.AllConfig;
import com.crc.log.flink.es.DataProcessFuncation;

import java.util.concurrent.ConcurrentHashMap;

/**
 * @author jixiangqi
 * @date 2022/3/24
 */
public class ResolvBAMVLogTest {

    public static void main(String[] args) {
        AllConfig config = new AllConfig();
        DataProcessFuncation.CONIFG = config;
        config.setMode("single");
        config.setParse("ResolvBAMVLog");
        config.setIndex("sec_all");


        String str = "{\"topic\":\"zyldap_log\",\"dev_ip\":\"10.200.198.89\",\"message\":\"{\\\"userId\\\":\\\"zhangfan01\\\",\\\"entityId\\\":\\\"appHub\\\",\\\"protocol\\\":\\\"oauth2\\\",\\\"loginTime\\\":\\\"2022-04-08 10:52:29\\\",\\\"userToken\\\":\\\"-2429828871181768728\\\",\\\"chainName\\\":\\\"ADldap认证-校验密码过期\\\",\\\"clientIp\\\":\\\"10.201.34.15\\\",\\\"spTypeWithSession\\\":\\\"web\\\",\\\"authChainLevel\\\":1,\\\"browserName\\\":\\\"Chrome 10\\\",\\\"userAgent\\\":\\\"Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/100.0.4896.60 Safari/537.36 Edg/100.0.1185.29\\\",\\\"state\\\":\\\"true\\\",\\\"result\\\":\\\"成功\\\",\\\"action\\\":\\\"SSO\\\",\\\"traceId\\\":\\\"d5b55877927e4585ad89bfca7c1f7b0b\\\",\\\"size\\\":0}\",\"type\":\"udp\",\"timestamp\":\"2022-04-08 10:52:29\"}";
        ConcurrentHashMap<String, Object> proc = DataProcessFuncation.parse(str,"index");
        JsonUtils.printStr(proc);

        str = "{\"topic\":\"zyldap_log\",\"dev_ip\":\"10.200.198.89\",\"message\":\"{\\\"userId\\\":\\\"cuixidong\\\",\\\"entityId\\\":\\\"CRB_ASMP\\\",\\\"protocol\\\":\\\"oauth2\\\",\\\"loginTime\\\":\\\"2022-04-08 10:42:36\\\",\\\"userToken\\\":\\\"-7847459101424948724\\\",\\\"chainName\\\":\\\"ADLdap认证链勿删\\\",\\\"clientIp\\\":\\\"10.201.34.15\\\",\\\"spTypeWithSession\\\":\\\"web\\\",\\\"authChainLevel\\\":1,\\\"browserName\\\":\\\"Chrome 9\\\",\\\"userAgent\\\":\\\"Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/98.0.4758.82 Safari/537.36\\\",\\\"state\\\":\\\"true\\\",\\\"result\\\":\\\"成功\\\",\\\"action\\\":\\\"SSO\\\",\\\"traceId\\\":\\\"546ba3dc3fdc4c77abb1de27901fcf8a\\\",\\\"size\\\":0}\",\"type\":\"udp\",\"timestamp\":\"2022-04-08 10:42:36\"}";
        proc = DataProcessFuncation.parse(str,"index");
        JsonUtils.printStr(proc);
        str = "{\"topic\":\"zyldap_log\",\"dev_ip\":\"10.200.198.89\",\"message\":\"{\\\"userId\\\":\\\"bbcadmin\\\",\\\"entityId\\\":\\\"businessui\\\",\\\"protocol\\\":\\\"oauth2\\\",\\\"loginTime\\\":\\\"2022-04-08 10:58:28\\\",\\\"userToken\\\":\\\"-1096887134634942673\\\",\\\"chainName\\\":\\\"ADldap认证-检验用户协议\\\",\\\"clientIp\\\":\\\"10.201.34.15\\\",\\\"spTypeWithSession\\\":\\\"web\\\",\\\"authChainLevel\\\":1,\\\"browserName\\\":\\\"Chrome 10\\\",\\\"userAgent\\\":\\\"Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/100.0.4896.75 Safari/537.36\\\",\\\"state\\\":\\\"true\\\",\\\"result\\\":\\\"成功\\\",\\\"action\\\":\\\"SSO\\\",\\\"traceId\\\":\\\"5220479dc9a343e7a416c8d8f7092181\\\",\\\"size\\\":0}\",\"type\":\"udp\",\"timestamp\":\"2022-04-08 10:58:28\"}";
        proc = DataProcessFuncation.parse(str,"index");
        JsonUtils.printStr(proc);
    }

}
