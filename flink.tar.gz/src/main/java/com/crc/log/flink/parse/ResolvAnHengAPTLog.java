package com.crc.log.flink.parse;

import com.crc.log.flink.common.constants.LogConstants;
import com.crc.log.flink.common.utils.DataUtils;
import com.crc.log.flink.common.utils.DateUtils;
import com.crc.log.flink.common.utils.JsonUtils;
import com.crc.log.flink.common.utils.MapUtils;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;

import java.util.LinkedList;
import java.util.List;
import java.util.concurrent.ConcurrentHashMap;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * @author jixiangqi
 * @date 2022/4/26
 * 安恒APT
 */
@Slf4j
public class ResolvAnHengAPTLog {
    public static ConcurrentHashMap<String, Object> parse(String message) {
        try {
            ConcurrentHashMap<String, Object> data = proc(message);
            if (DataUtils.isNotEmptyJson(data)) {
                return data;
            }
        } catch (Exception ignored) {

        }
        return null;
    }

    private static ConcurrentHashMap<String, Object> proc(String jsonStr) {
        ConcurrentHashMap<String, Object> rtnObjc = JsonUtils.createBaseMap(jsonStr);
        List<String> stringList = getValueBySpace(jsonStr);
        stringList.forEach(str -> {
            String[] split = DataUtils.getSplit(str, ",");
            for (String tempStr : split) {
                if (tempStr.contains(":")) {
                    int index = DataUtils.getIndex(tempStr, ":");
                    String key = DataUtils.getSubString(tempStr, 0, index).trim().replaceAll("\"", "");
                    String value = DataUtils.getSubString(tempStr, index + 1).trim().replaceAll("\"", "");
                    switchKeyValue(rtnObjc, key, value);
                }
            }
        });
        if (StringUtils.isBlank(MapUtils.getStr(rtnObjc, LogConstants.SRC_IP))) {
            rtnObjc.put(LogConstants.SRC_IP, "0.0.0.0");
        }
        if (StringUtils.isBlank(MapUtils.getStr(rtnObjc, LogConstants.DEST_IP))) {
            rtnObjc.put(LogConstants.DEST_IP, "0.0.0.0");
        }
        rtnObjc.put(LogConstants.LOG_PRODUCT, "安恒APT");
        setAlertName(rtnObjc);
        return rtnObjc;
    }

    private static void switchKeyValue(ConcurrentHashMap<String, Object> rtnObjc, String key, String value) {
        switch (key) {
            case "sendType":
                rtnObjc.put(LogConstants.LOG_TYPE, value);
                break;
            case "eventCount":
                rtnObjc.put(LogConstants.LOG_COUNT, value);
                break;
            case "deviceSendProductName":
                rtnObjc.put(LogConstants.DEVICE_NAME, value);
                break;
            case "srcAddress":
                rtnObjc.put(LogConstants.SRC_IP, value);
                break;
            case "transProtocol":
                rtnObjc.put(LogConstants.LOG_PROTOCAL, value);
                break;
            case "srcPort":
                rtnObjc.put(LogConstants.SRC_PORT, value);
                break;
            case "srcMacAddress":
                rtnObjc.put(LogConstants.SRC_MAC, value);
                break;
            case "destAddress":
                rtnObjc.put(LogConstants.DEST_IP, value);
                break;
            case "destPort":
                rtnObjc.put(LogConstants.DEST_PORT, value);
                break;
            case "destMacAddress":
                rtnObjc.put(LogConstants.DEST_MAC, value);
                break;
            case "severity":
                String level  = "";
                switch (value) {
                    case "1":
                    case "2":
                    case "3":
                        level = "低风险";
                        break;
                    case "4":
                    case "5":
                    case "6":
                        level = "中风险";
                        break;
                    case "7":
                    case "8":
                    case "9":
                        level = "高风险";
                        break;
                }
                rtnObjc.put(LogConstants.LOG_LEVEL, level);
                break;
            case "eventId":
                rtnObjc.put(LogConstants.EVENT_ID, value);
                break;
            case "name":
                rtnObjc.put(LogConstants.LOG_NAME, value);
                break;
            case "ruleType":
                rtnObjc.put(LogConstants.RULE_NAME, value);
                break;
            case "alarmDesc":
                rtnObjc.put(LogConstants.LOG_DESCRIPTION, value);
                break;
            case "attackFileType":
                rtnObjc.put(LogConstants.ACTION_TYPE, value);
                break;
            case "collectorReceiptTime":
                rtnObjc.put(LogConstants.LOG_START_TIME, DateUtils.getISO8601Timestamp(value.trim(), "yyyy-MM-dd HH:mm:ss"));
                break;
        }
    }

    private static void setAlertName(ConcurrentHashMap<String, Object> rtnObjc) {
        String srcIp = MapUtils.getStr(rtnObjc, LogConstants.SRC_IP);
        String destIp = MapUtils.getStr(rtnObjc, LogConstants.DEST_IP);
        String count = MapUtils.getStr(rtnObjc, LogConstants.LOG_COUNT);
        String logType = MapUtils.getStr(rtnObjc, LogConstants.LOG_TYPE);
        String logName = MapUtils.getStr(rtnObjc, LogConstants.LOG_NAME);
        String logLevel = MapUtils.getStr(rtnObjc, LogConstants.LOG_LEVEL);
        String logDesc = MapUtils.getStr(rtnObjc, LogConstants.LOG_DESCRIPTION);
        String proto = MapUtils.getStr(rtnObjc, LogConstants.LOG_PROTOCAL);
        String actionType = MapUtils.getStr(rtnObjc, LogConstants.ACTION_TYPE);
        String message = "IP地址为:%s对IP为:%s产生了一个%s类型的攻击,攻击次数为:%s,日志类型为:%s,告警名为:%s,告警级别为:%s,告警描述为:%s,攻击协议为:%s";
        String alertName = String.format(message, srcIp, destIp, actionType, count, logType, logName, logLevel,logDesc,proto);
        rtnObjc.put(LogConstants.ALERT_NAME, alertName);
    }


    private static List<String> getValueBySpace(String jsonStr) {
        Pattern p = Pattern.compile("\\{([^\\}]+)\\}");
        Matcher m = p.matcher(jsonStr);
        List<String> dataList = new LinkedList<>();
        while (m.find()) {
            try {
                String data = m.group().substring(1, m.group().length() - 1);
                dataList.add(data);
            } catch (Exception e) {
                log.error("正则表达式获取数据失败：{}",e.getMessage(),e);
            }
        }
        return dataList;
    }
}
