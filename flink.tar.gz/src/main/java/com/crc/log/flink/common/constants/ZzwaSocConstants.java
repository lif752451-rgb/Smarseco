package com.crc.log.flink.common.constants;

public class ZzwaSocConstants
{

}
