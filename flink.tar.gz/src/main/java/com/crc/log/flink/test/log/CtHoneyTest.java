package com.crc.log.flink.test.log;

import com.crc.log.flink.FlinkApplication;
import com.crc.log.flink.common.utils.JsonUtils;
import com.crc.log.flink.config.AllConfig;
import com.crc.log.flink.es.DataProcessFuncation;

import java.util.concurrent.ConcurrentHashMap;

public class CtHoneyTest {
    public static void main(String[] args) {
        String msgx = "<12>Oct 09 10:07:43  {\"source\": \"scanner\", \"id\": \"adb5302965ab36e7dc4e7209b85442ad\", \"proto\": \"tcp\", \"start_time\": 1633745236, \"end_time\": 1633745236, \"agent\": \"10.8.9.195\", \"business_group\": \"\\u5206\\u7ec4\\u4e94\", \"src_ip\": \"10.0.89.146\", \"src_port\": \"29276\", \"dest_ip\": \"10.8.9.195\", \"dest_port\": \"10050\", \"dumb_captures\": []}";
        AllConfig config = new AllConfig();
        DataProcessFuncation.CONIFG = config;
        FlinkApplication.ALL_CONFIG = config;
        config.setMode("single");
        config.setParse("ResolvHoneyLog");
        config.setIndex("sec_all");
        config.setDebug("T");


        ConcurrentHashMap<String, Object> json = DataProcessFuncation.parse(msgx,"index");
        JsonUtils.printStr(json);
    }
}
