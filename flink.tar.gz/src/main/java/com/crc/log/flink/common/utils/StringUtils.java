package com.crc.log.flink.common.utils;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class StringUtils extends org.apache.commons.lang3.StringUtils{
    /**
     * @param string
     * @return
     * @Title: unicodeEncode
     * @Description: unicode编码
     */
    public static String unicodeEncode(String string) {
        char[] utfBytes = string.toCharArray();
        StringBuilder unicodeBytes = new StringBuilder();
        for (char utfByte : utfBytes) {
            String hexB = Integer.toHexString(utfByte);
            if (hexB.length() <= 2) {
                hexB = "00" + hexB;
            }
            unicodeBytes.append("\\u").append(hexB);
        }
        return unicodeBytes.toString();
    }

    /**
     * @param string
     * @return
     * @Title: unicodeDecode
     * @Description: unicode解码
     */
    public static String unicodeDecode(String string) {
        Pattern pattern = Pattern.compile("(\\\\u(\\p{XDigit}{4}))");
        Matcher matcher = pattern.matcher(string);
        char ch;
        while (matcher.find()) {
            ch = (char) Integer.parseInt(matcher.group(2), 16);
            string = string.replace(matcher.group(1), String.valueOf(ch));
        }
        return string;
    }

    public static void main(String[] args) {
        String sourceData = "这是原始的数据！！！";
        String unicodeEncode = unicodeEncode(sourceData);
        System.out.println("编码结果：");
        System.out.println(unicodeEncode);//\u8fd9\u662f\u539f\u59cb\u7684\u6570\u636e\uff01\uff01\uff01

        String unicodeDecode = unicodeDecode("<6>{\\\"version\\\":\\\"\\\\u5929\\\\u64ce6.7.0.4210\\\",\\\"log_name\\\":\\\"\\\\u6f0f\\\\u6d1e\\\\u7ba1\\\\u7406\\\",\\\"log_id\\\":\\\"fd2cb966a3c9534f02bd0556bed33e6d\\\",\\\"create_time\\\":\\\"2021-09-01 11:07:06\\\",\\\"ip\\\":\\\"10.75.230.93\\\",\\\"report_ip\\\":\\\"10.75.230.93\\\",\\\"mac\\\":\\\"584120db512e\\\",\\\"gid\\\":1,\\\"work_group\\\":\\\"crland.hk\\\",\\\"content\\\":{\\\"name\\\":\\\"2014 \\\\u5e74 10 \\\\u6708 14 Office 2013 \\\\u66f4\\\\u65b0 \\\\uff08KB2760371\\\\uff09\\\",\\\"type\\\":\\\"\\\\u8f6f\\\\u4ef6\\\\u5b89\\\\u5168\\\\u66f4\\\\u65b0\\\",\\\"action\\\":\\\"\\\\u6f0f\\\\u6d1e\\\\u4fee\\\\u590d\\\\u6210\\\\u529f\\\",\\\"kbid\\\":\\\"2760371\\\"}}");
        System.out.println("解码结果：");
        System.out.println(unicodeDecode);//这是原始的数据！！！
    }

    public static int stringSubIndex(String jsonStr, char a, int num) {
        int count = 0;
        for (int i = 0; i < jsonStr.length(); i++) {
            char c = jsonStr.charAt(i);
            if (c == a) {
                count++;
                if (count == num) {
                    count = i + 3;
                    break;
                }
            }
        }
        return count;
    }

    public static int stringSubIndexTwo(String jsonStr, char a, int num) {
        int count = 0;
        for (int i = 0; i < jsonStr.length(); i++) {
            char c = jsonStr.charAt(i);
            if (c == a) {
                count++;
                if (count == num) {
                    count = i;
                    break;
                }
            }
        }
        return count;
    }
}
