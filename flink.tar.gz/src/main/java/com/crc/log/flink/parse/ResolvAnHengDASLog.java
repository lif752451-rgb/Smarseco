package com.crc.log.flink.parse;

import com.crc.log.flink.common.constants.LevelConstants;
import com.crc.log.flink.common.constants.LogConstants;
import com.crc.log.flink.common.utils.DataUtils;
import com.crc.log.flink.common.utils.JsonUtils;
import com.crc.log.flink.common.utils.MapUtils;
import org.apache.commons.lang3.StringUtils;

import java.util.concurrent.ConcurrentHashMap;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * @author jixiangqi
 * @date 2022/5/24
 * 安恒-DAS-NGFW
 */
public class ResolvAnHengDASLog {
    private static final String FIELD_REG = "((?:Jan|Feb|Mar|May|Jun|Jul|Aug|Sep|Oct|Nov|Dec)\\s+\\d+\\s+\\d+\\:\\d+\\:\\d+).*src_ip=(\\d+\\.\\d+\\.\\d+\\.\\d+);dst_ip=(\\d+\\.\\d+\\.\\d+\\.\\d+);src_port=(\\d+);dst_port=(\\d+);X-Forwarded-For=(.*)app_name=([^\\;]+);protocol=(\\w+);app_protocol=(\\w+);event_id=(\\d+);event_name=([^\\;]+);event_type=([^\\;]+);.*attack_success:(\\d+);level=(\\S+);ctime=(\\d{4}\\-\\d+\\-\\d+\\s+\\d+\\:\\d+\\:\\d+);action=(\\S+)";

    public static ConcurrentHashMap<String, Object> parse(String message) {
        try {
            ConcurrentHashMap<String, Object> data = proc(message);
            if (DataUtils.isNotEmptyJson(data)) {
                return data;
            }
        } catch (Exception ignored) {

        }
        return null;
    }

    private static ConcurrentHashMap<String, Object> proc(String jsonStr) {
        ConcurrentHashMap<String, Object> rtnObjc = JsonUtils.createBaseMap(jsonStr);
        getFieldsByPattern(jsonStr, rtnObjc);
        if (StringUtils.isBlank(MapUtils.getStr(rtnObjc, LogConstants.SRC_IP))) {
            rtnObjc.put(LogConstants.SRC_IP, "0.0.0.0");
        }
        if (StringUtils.isBlank(MapUtils.getStr(rtnObjc, LogConstants.DEST_IP))) {
            rtnObjc.put(LogConstants.DEST_IP, "0.0.0.0");
        }
        rtnObjc.put(LogConstants.LOG_PRODUCT, "安恒DAS");
        setAlertName(rtnObjc);
        return rtnObjc;
    }

    private static void getFieldsByPattern(String jsonStr, ConcurrentHashMap<String, Object> rtnObjc) {
        Pattern pattern = Pattern.compile(FIELD_REG);
        Matcher matcher = pattern.matcher(jsonStr);
        while (matcher.find()) {
            rtnObjc.put(LogConstants.LOG_START_TIME, matcher.group(14));
            rtnObjc.put(LogConstants.SRC_IP, matcher.group(2));
            rtnObjc.put(LogConstants.DEST_IP, matcher.group(3));
            rtnObjc.put(LogConstants.SRC_PORT, matcher.group(4));
            rtnObjc.put(LogConstants.DEST_PORT, matcher.group(5));
            rtnObjc.put(LogConstants.LOG_APP, matcher.group(7));
            rtnObjc.put(LogConstants.LOG_PROTOCAL, matcher.group(8));
            rtnObjc.put(LogConstants.EVENT_ID, matcher.group(9));
            rtnObjc.put(LogConstants.LOG_NAME, matcher.group(10));
            rtnObjc.put(LogConstants.LOG_TYPE, matcher.group(11));
            rtnObjc.put(LogConstants.ACTION_RESULT, matcher.group(12));
            rtnObjc.put(LogConstants.LOG_LEVEL, LevelConstants.getLevel(matcher.group(13)));
            rtnObjc.put(LogConstants.ACTION_TYPE, matcher.group(15));
        }
    }

    private static void setAlertName(ConcurrentHashMap<String, Object> rtnObjc) {
        String message = "IP为:%s对IP为:%s产生了一个为:%s类型的攻击,事件名称为:%s,事件级别为:%s,攻击结果为:%s,攻击类型为:%s,日志详情为:%s";
        String srcIp = MapUtils.getStr(rtnObjc, LogConstants.SRC_IP);
        String destIp = MapUtils.getStr(rtnObjc, LogConstants.DEST_IP);
        String logType = MapUtils.getStr(rtnObjc, LogConstants.LOG_TYPE);
        String logName = MapUtils.getStr(rtnObjc, LogConstants.LOG_NAME);
        String logLevel = MapUtils.getStr(rtnObjc, LogConstants.LOG_LEVEL);
        String actionResult = MapUtils.getStr(rtnObjc, LogConstants.ACTION_RESULT);
        String actionType = MapUtils.getStr(rtnObjc, LogConstants.ACTION_TYPE);
        String log = MapUtils.getStr(rtnObjc, LogConstants.LOG_ORI_MSG);
        String alertName = String.format(message, srcIp, destIp,logType, logName, logLevel, actionResult, actionType, log);
        rtnObjc.put(LogConstants.ALERT_NAME, alertName);
    }
}
