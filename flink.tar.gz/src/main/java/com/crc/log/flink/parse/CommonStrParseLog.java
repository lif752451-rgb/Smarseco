package com.crc.log.flink.parse;

import com.alibaba.fastjson.JSONObject;
import com.crc.log.flink.common.constants.LogConstants;
import com.crc.log.flink.common.utils.DataUtils;
import org.apache.commons.lang3.StringUtils;

import java.util.concurrent.ConcurrentHashMap;

/**
 * 通用字符串日志解析
 * 1）找键对值
 */
public class CommonStrParseLog {
    public final static String[] SRC_IP_KEY = {"src_ip", "source_ip", "src_addr", "source_addr", "addr_src", "addr_source"};
    public final static String[] SRC_PORT_KEY = {"src_port", "source_port", "port_src", "port_source"};
    public final static String[] DEST_IP_KEY = {"dst_ip", "dest_ip", "dest_addr", "dst_addr", "addr_dst", "addr_dest"};
    public final static String[] DEST_PORT_KEY = {"dst_port", "dest_port", "port_dst", "port_dest"};

    public static ConcurrentHashMap<String,Object> parse(String logStr) {
        JSONObject jsonObject = new JSONObject();
        if (StringUtils.isNotBlank(logStr)) {
            try {
                String[] dataList = null;
                if (logStr.contains(";") && (logStr.contains(":") || logStr.contains("="))) {
                    dataList = logStr.split(";");
                } else if (logStr.contains(",") && (logStr.contains(":") || logStr.contains("="))) {
                    dataList = logStr.split(",");
                } else if (logStr.contains(" ") && (logStr.contains(":") || logStr.contains("="))) {
                    dataList = logStr.split(" ");
                }
                if (dataList == null) {
                    return null;
                }
                //JsonUtils.printStr(dataList);
                for (String data : dataList) {
                    if (logStr.contains("=")) {
                        int index = DataUtils.getIndex(data, "=");
                        if (index != -1) {
                            String key = DataUtils.getSubString(data, 0, index).replace("\"", "");
                            String value = DataUtils.getSubString(data, index + 1).replace("\"", "");
                            if (StringUtils.isNotBlank(key) && StringUtils.isNotBlank(value)) {
                                jsonObject.put(key, value);
                            }
                        }
                    } else if (data.contains(":")) {
                        int index = DataUtils.getIndex(data, ":");
                        if (index != -1) {
                            String key = DataUtils.getSubString(data, 0, index).replace("\"", "");
                            String value = DataUtils.getSubString(data, index + 1).replace("\"", "");
                            if (StringUtils.isNotBlank(key) && StringUtils.isNotBlank(value)) {
                                jsonObject.put(key, value);
                            }
                        }
                    }
                }
                ConcurrentHashMap<String,Object> newJson = new ConcurrentHashMap<>();
                if (jsonObject.size() > 0) {
                    jsonObject.forEach((k, v) -> {
                        for (String s : SRC_IP_KEY) {
                            if (s.equals(k)) {
                                newJson.put(LogConstants.SRC_IP, v);
                                break;
                            }
                            if (k.contains(" " + s)) {
                                newJson.put(LogConstants.SRC_IP, v);
                                break;
                            }
                        }
                        if (k.equals("src")) {
                            newJson.put(LogConstants.SRC_IP, v);
                        }
                        if (k.equals("dst") || k.equals("dest")) {
                            newJson.put(LogConstants.DEST_IP, v);
                        }
                        for (String s : DEST_IP_KEY) {
                            if (s.equals(k)) {
                                newJson.put(LogConstants.DEST_IP, v);
                                break;
                            }
                            if (k.contains(" " + s)) {
                                newJson.put(LogConstants.DEST_IP, v);
                                break;
                            }
                        }
                        for (String s : DEST_PORT_KEY) {
                            if (s.equals(k)) {
                                newJson.put(LogConstants.DEST_PORT, v);
                                break;
                            }
                        }
                        for (String s : SRC_PORT_KEY) {
                            if (s.equals(k)) {
                                newJson.put(LogConstants.SRC_PORT, v);
                                break;
                            }
                        }
                    });
                    if (newJson.size() > 0) {
                        newJson.put(LogConstants.LOG_ORI_MSG, logStr);
                    }
                    return newJson;
                }
            } catch (Exception ignored) {

            }
        }
        return null;
    }
}
