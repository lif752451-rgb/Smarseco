package com.crc.log.flink.test.log;

import com.crc.log.flink.common.utils.JsonUtils;
import com.crc.log.flink.config.AllConfig;
import com.crc.log.flink.es.DataProcessFuncation;

import java.util.concurrent.ConcurrentHashMap;

public class ResolvH3CFirewallTest {


    public static void main(String[] args) {
        AllConfig config = new AllConfig();
        DataProcessFuncation.CONIFG = config;
        config.setMode("single");
        config.setParse("ResolvH3CFirewall");
        config.setIndex("sec_all");

        String str = "190>Dec  1 09:43:00 2021 华侨城---互联网防火墙 %%10FILTER/6/FILTER_ZONE_IPV4_EXECUTION: SrcZoneName(1025)=Trust;DstZoneName(1035)=Untrust;Type(1067)=ACL;SecurityPolicy(1072)=上网流量;RuleID(1078)=0;Protocol(1001)=TCP;Application(1002)=https;SrcIPAddr(1003)=10.77.130.48;SrcPort(1004)=60429;SrcMacAddr(1021)=f84f-57d9-8ec3;DstIPAddr(1007)=218.13.60.233;DstPort(1008)=443;MatchCount(1069)=1;Event(1048)=Permit;\n";
        ConcurrentHashMap<String, Object> proc = DataProcessFuncation.parse(str,"index");
        JsonUtils.printStr(proc);

        str = "190>Dec  1 09:42:46 2021 华侨城---互联网防火墙 %%10FILTER/6/FILTER_ZONE_IPV4_EXECUTION: SrcZoneName(1025)=Trust;DstZoneName(1035)=Untrust;Type(1067)=ACL;SecurityPolicy(1072)=上网流量;RuleID(1078)=0;Protocol(1001)=TCP;Application(1002)=http;SrcIPAddr(1003)=10.77.130.10;SrcPort(1004)=54154;SrcMacAddr(1021)=f84f-57d9-8ec3;DstIPAddr(1007)=110.249.194.78;DstPort(1008)=80;MatchCount(1069)=5;Event(1048)=Permit;";
        proc = DataProcessFuncation.parse(str,"index");
        JsonUtils.printStr(proc);

        str = "<190>Dec  1 09:42:46 2021 华侨城---互联网防火墙 %%10FILTER/6/FILTER_ZONE_IPV4_EXECUTION: SrcZoneName(1025)=Trust;DstZoneName(1035)=Untrust;Type(1067)=ACL;SecurityPolicy(1072)=上网流量;RuleID(1078)=0;Protocol(1001)=TCP;Application(1002)=BaiduCloud;SrcIPAddr(1003)=10.77.130.45;SrcPort(1004)=9152;SrcMacAddr(1021)=f84f-57d9-8ec3;DstIPAddr(1007)=220.181.111.93;DstPort(1008)=443;MatchCount(1069)=54;Event(1048)=Permit;\n";
        proc = DataProcessFuncation.parse(str,"index");
        JsonUtils.printStr(proc);


        str = "<188> Dec 08 13:10:31 2021 WaiBu-WB1F-FW1080-01 %%10IPS/4/IPS_IPV4_INTERZONE: Protocol(1001)=UDP; Application(1002)=dns; SrcIPAddr(1003)=218.5.69.74; SrcPort(1004)=53960; DstIPAddr(1007)=218.85.157.99; DstPort(1008)=53; RcvVPNInstance(1042)=; SrcZoneName(1025)=Local; DstZoneName(1035)=Untrust; UserName(1113)=218.5.69.74; PolicyName(1079)=dns-server; AttackName(1088)=Miner_Worm_WannaMine_DNS_Connection; AttackID(1089)=34060; Category(1090)=MalwareTraffic; Protection(1091)=OperationSystem; SubProtection(1092)=Any; Severity(1087)=MEDIUM; Action(1053)=Drop & Logging; CVE(1075)=--; BID(1076)=--; MSB(1077)=--; HitDirection(1115)=original; RealSrcIP(1100)=; SubCategory(1124)=MaliciousDNSTraffic; CapturePktName(1116)=; HttpHost(1117)=; HttpFirstLine(1118)=; PayLoad(1135)=S\\c2\\01\\00\\00\\01\\00\\00\\00\\00\\00\\00\\05santa\\0binseription\\03com\\00\\00\\01\\00\\01;\"";proc = DataProcessFuncation.parse(str,"index");
        proc = DataProcessFuncation.parse(str,"index");
        JsonUtils.printStr(proc);
    }

}



