package com.crc.log.flink.common.constants;

import org.apache.commons.lang3.StringUtils;

public class LevelConstants {
    public static String HIGH = "高风险";
    public static String MEDIUM = "中风险";
    public static String LOW = "低风险";
    public static String INFO = "信息";
    private static final String[] HIGH_ARR = {"严重","危急","高风险", "high", "高危", "3", "高威胁", "danger","error","高"};
    private static final String[] MEDIUM_ARR = {"中风险", "medium", "中危", "2", "中威胁", "alert","warning","中"};
    private static final String[] LOW_ARR = {"低风险", "low", "低危", "1", "低威胁", "info","低"};

    public static String getLevel(String level) {
        if (StringUtils.isBlank(level))
            return INFO;
        level = level.trim();
        for (String l : HIGH_ARR) {
            if (l.equalsIgnoreCase(level))
                return HIGH;
        }
        for (String l : MEDIUM_ARR) {
            if (l.equalsIgnoreCase(level))
                return MEDIUM;
        }
        for (String l : LOW_ARR) {
            if (l.equalsIgnoreCase(level))
                return LOW;
        }
        return INFO;
    }

    public static String getLevel2(String level) {
        if (StringUtils.isBlank(level))
            return LOW;
        level = level.trim();
        for (String l : HIGH_ARR) {
            if (l.equalsIgnoreCase(level))
                return HIGH;
        }
        for (String l : MEDIUM_ARR) {
            if (l.equalsIgnoreCase(level))
                return MEDIUM;
        }
        for (String l : LOW_ARR) {
            if (l.equalsIgnoreCase(level))
                return LOW;
        }
        return LOW;
    }
}
