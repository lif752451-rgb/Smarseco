package com.crc.log.flink.parse;

import com.crc.log.flink.common.constants.LevelConstants;
import com.crc.log.flink.common.constants.LogConstants;
import com.crc.log.flink.common.utils.DataUtils;
import com.crc.log.flink.common.utils.DateUtils;
import com.crc.log.flink.common.utils.JsonUtils;
import com.crc.log.flink.common.utils.MapUtils;
import org.apache.commons.lang3.StringUtils;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.LinkedList;
import java.util.List;
import java.util.TimeZone;
import java.util.concurrent.ConcurrentHashMap;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * 华为防火墙
 */
public class ResolvFirewallLog {
    static SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");

    /**
     * 华为防火墙 USG9560 日志泛化
     */
    public static ConcurrentHashMap<String,Object> parse(String message) {
        try {
            ConcurrentHashMap<String,Object> data = proc(message);
            if (DataUtils.isNotEmptyJson(data)) {
                return data;
            }
        } catch (Exception ignored) {

        }
        return null;
    }

    private static ConcurrentHashMap<String,Object> proc(String jsonStr) {
        ConcurrentHashMap<String,Object> rtnObjc = JsonUtils.createBaseMap(jsonStr);

        if (jsonStr.contains("THREATTRAP")) {
            Pattern p = Pattern.compile("\\(([^)]*)\\)");
            Matcher m = p.matcher(jsonStr);
            List<String> dataList = new LinkedList<>();
            while (m.find()) {
                try {
                    String data = m.group().substring(1, m.group().length() - 1);
                    dataList.add(data);
                } catch (Exception ignored) {

                }
            }
            for (String value : dataList) {
                jsonStr = value.replaceAll(", ", ",");
                String[] IPS_buff = DataUtils.getSplit(jsonStr, ",");
                //jsonStr.split(",");
                switchKey(rtnObjc, IPS_buff);
            }
        } else {
            jsonStr = jsonStr.replaceAll(", ", ",");
            String[] IPS_buff = DataUtils.getSplit(jsonStr, ",");
            switchKey(rtnObjc, IPS_buff);
        }
        rtnObjc.put(LogConstants.LOG_LEVEL, LevelConstants.getLevel(MapUtils.getStr(rtnObjc,LogConstants.LOG_LEVEL)));
        if (StringUtils.isBlank(MapUtils.getStr(rtnObjc, LogConstants.SRC_IP))) {
            rtnObjc.put(LogConstants.SRC_IP, "0.0.0.0");
        }
        if (StringUtils.isBlank(MapUtils.getStr(rtnObjc, LogConstants.DEST_IP))) {
            rtnObjc.put(LogConstants.DEST_IP, "0.0.0.0");
        }
        rtnObjc.put(LogConstants.LOG_PRODUCT, "华为防火墙");
        setAlertName(rtnObjc);
        return rtnObjc;
    }

    private static void switchKey(ConcurrentHashMap<String,Object> rtnObjc, String[] IPS_buff) {
        sdf.setTimeZone(TimeZone.getTimeZone("GMT+0"));
        for (String s : IPS_buff) {
            String[] datakey = DataUtils.getSplit(s, "=");
            //IPS_buff[i].split("=");
            if (1 < datakey.length) {
                String key = datakey[0].trim();
                String value = datakey[1].trim();
                switch (key) {
                    case "SrcIp":
                        rtnObjc.put(LogConstants.SRC_IP, value);
                        break;
                    case "DstIp":
                        rtnObjc.put(LogConstants.DEST_IP, value);
                        break;
                    case "SrcPort":
                        rtnObjc.put(LogConstants.SRC_PORT, value);
                        break;
                    case "DstPort":
                        rtnObjc.put(LogConstants.DEST_PORT, value);
                        break;
                    case "Protocol":
                        rtnObjc.put(LogConstants.LOG_PROTOCAL, value);
                        break;
                    case "Event":
                        rtnObjc.put(LogConstants.LOG_DESCRIPTION, value);
                        break;
                    case "DetectTime":
                        rtnObjc.put(LogConstants.LOG_START_TIME, DateUtils.getISO8601Timestamp(value, "yyyy/MM/dd HH:mm:ss"));
                        break;
                    case "SourceIP":
                        rtnObjc.put(LogConstants.SRC_IP, value);
                        break;
                    case "DestinationIP":
                        rtnObjc.put(LogConstants.DEST_IP, value);
                        break;
                    case "SourcePort":
                        rtnObjc.put(LogConstants.SRC_PORT, value);
                        break;
                    case "DestinationPort":
                        rtnObjc.put(LogConstants.DEST_PORT, value);
                        break;
                    case "ApplicationName":
                        rtnObjc.put(LogConstants.LOG_APP, value);
                        break;
                    case "BeginTime":
                        rtnObjc.put(LogConstants.LOG_START_TIME, DateUtils.getISO8601Timestamp(sdf.format(new Date(DataUtils.toNum(value) * 1000L)), "yyyy-MM-dd HH:mm:ss"));
                        break;
                }
            }

        }
        if (IPS_buff[0].contains("devIp")) {
            String[] strArr = DataUtils.getSplit(IPS_buff[0], " ");
                    //IPS_buff[0].split(" ");
            if (strArr.length > 2) {
                String devName = strArr[strArr.length - 2];
                rtnObjc.put(LogConstants.HOST_NAME, devName);

                String vsys = strArr[strArr.length - 1];
                String[] datakey = DataUtils.getSplit(vsys, "=");
                        //vsys.split("=");
                if (1 < datakey.length) {
                    rtnObjc.put(LogConstants.OS_INFO, datakey[1]);
                }

            }
        }
    }

    private static void setAlertName(ConcurrentHashMap<String,Object> rtnObjc) {
        String srcIp = MapUtils.getStr(rtnObjc, LogConstants.SRC_IP);
        String destIp = MapUtils.getStr(rtnObjc, LogConstants.DEST_IP);
        String protocal = MapUtils.getStr(rtnObjc, LogConstants.LOG_PROTOCAL);
        String level = MapUtils.getStr(rtnObjc, LogConstants.LOG_LEVEL);
        String description = MapUtils.getStr(rtnObjc, LogConstants.LOG_DESCRIPTION);
        String log = MapUtils.getStr(rtnObjc, LogConstants.LOG_ORI_MSG);
        if (StringUtils.isBlank(description)) {
            description = MapUtils.getStr(rtnObjc, LogConstants.LOG_ORI_MSG);
        }
        String msgFormat = "IP为:%s对IP为:%s发起了一个%s类型的请求,具体请求内容为:%s,事件级别:%s,原始日志:%s";
        String alertName = String.format(msgFormat, srcIp, destIp, protocal, description, level, log);
        rtnObjc.put(LogConstants.ALERT_NAME, alertName);

    }
}
