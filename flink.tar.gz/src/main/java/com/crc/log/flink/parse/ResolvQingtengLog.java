package com.crc.log.flink.parse;

import com.crc.log.flink.common.constants.LevelConstants;
import com.crc.log.flink.common.constants.LogConstants;
import com.crc.log.flink.common.utils.*;
import org.apache.commons.lang3.StringUtils;

import java.util.concurrent.ConcurrentHashMap;

/**
 * @Author daiyd
 * @Date: 2020/5/29 11:53
 * @Version 1.0
 */
public class ResolvQingtengLog {

    public static ConcurrentHashMap<String, Object> parse(String message) {
        try {
            ConcurrentHashMap<String, Object> data = proc(message);
            if (DataUtils.isNotEmptyJson(data)) {
                return data;
            }
        } catch (Exception ignored) {

        }
        return null;
    }

    private static ConcurrentHashMap<String, Object> proc(String jsonStr) {
        ConcurrentHashMap<String, Object> rtnObjc = JsonUtils.createBaseMap(jsonStr);
        try {
            MapUtils.setStr(rtnObjc, LogConstants.LOG_PRODUCT, "青藤");
            MapUtils.setStr(rtnObjc, LogConstants.LOG_TYPE, getValue(jsonStr, "datatype"));
            MapUtils.setStr(rtnObjc, LogConstants.HOST_NAME, getValue(jsonStr, "host_name"));
            MapUtils.setStr(rtnObjc, LogConstants.ACTION_TYPE, getValue(jsonStr, "pname"));
            MapUtils.setStr(rtnObjc, LogConstants.EXTERNAL_IP, getValue(jsonStr, "internal_ip"));
            MapUtils.setStr(rtnObjc, LogConstants.ASSET_OFFICE, getValue(jsonStr, "group_name"));
            MapUtils.setStr(rtnObjc, LogConstants.OP_NAME, getValue(jsonStr, "uname"));
            MapUtils.setStr(rtnObjc, LogConstants.INTERNAL_IP, getValue(jsonStr, "external_ip"));
            MapUtils.setStr(rtnObjc, LogConstants.LOG_DESCRIPTION, getValue(jsonStr, "cmd"));
            //MapUtils.setStr(rtnObjc, LogConstants.EVENT_ID, jsonStr.split(" ")[0]);

            /*
              告警信息
             */
            if (jsonStr.contains("event_name")) {
                parseExistEventName(rtnObjc, jsonStr);
            } else if (jsonStr.contains("risk_name")) {
                parseExistRiskName(rtnObjc, jsonStr);
            }

            if (StringUtils.isBlank(MapUtils.getStr(rtnObjc,LogConstants.SRC_IP))) {
                MapUtils.setStr(rtnObjc, LogConstants.SRC_IP, getValue(jsonStr, "agent_ip"));
            }

            if (StringUtils.isBlank(MapUtils.getStr(rtnObjc,LogConstants.LOG_DESCRIPTION))) {
                MapUtils.setStr(rtnObjc, LogConstants.LOG_DESCRIPTION, MapUtils.getStr(rtnObjc,LogConstants.MSG_CONTENT));
            }
            //  LOG_DESCRIPTION 还为空，全量日志

            MapUtils.setStr(rtnObjc, LogConstants.LOG_START_TIME, DateUtils.getISO8601Timestamp(getLong(jsonStr, "datatime") * 1000));

            MapUtils.setStr(rtnObjc, LogConstants.LOG_LEVEL, LevelConstants.getLevel(MapUtils.getStr(rtnObjc,LogConstants.LOG_LEVEL)));
            String actionResult = MapUtils.getStr(rtnObjc,LogConstants.LOG_LEVEL).equalsIgnoreCase("信息") ? "其它" : "失陷";
            MapUtils.setStr(rtnObjc, LogConstants.ACTION_RESULT, actionResult);
            ScoreUtils.commonEventLevelScore(rtnObjc);
            rtnObjc.put(LogConstants.LOG_LEVEL, LevelConstants.getLevel(MapUtils.getStr(rtnObjc,LogConstants.LOG_LEVEL)));
            if (StringUtils.isBlank(MapUtils.getStr(rtnObjc, LogConstants.SRC_IP))) {
                rtnObjc.put(LogConstants.SRC_IP, "0.0.0.0");
            }
            if (StringUtils.isBlank(MapUtils.getStr(rtnObjc, LogConstants.DEST_IP))) {
                rtnObjc.put(LogConstants.DEST_IP, "0.0.0.0");
            }
            setAlertName(rtnObjc);
            return rtnObjc;
        } catch (
                Exception e) {
            System.err.println(e.getMessage());
            return rtnObjc;
        }

    }


    public static String getValue(String str, String key) {
        try {
            int index = DataUtils.getIndex(str, key);
            //str.indexOf(key);
            if (index == -1) {
                return "";
            }
            String tmpStr = DataUtils.getSubString(str, index + key.length() + 1);
            //str.substring(index + key.length() + 1);
            int index2 = DataUtils.getIndex(tmpStr, "\"");
            //tmpStr.indexOf("\"");
            tmpStr = DataUtils.getSubString(tmpStr, index2 + 1);
            //tmpStr.substring(index2 + 1);
            int index3 = DataUtils.getIndex(tmpStr, "\"");
            //tmpStr.indexOf("\"");
            tmpStr = DataUtils.getSubString(tmpStr, 0, index3);
            //tmpStr.substring(0, index3);
            return tmpStr.trim();
        } catch (Exception e) {
            return "";
        }
    }

    public static long getLong(String str, String key) {
        try {
            String longStr = getValue(str, key);
            return Long.parseLong(longStr);
        } catch (Exception e) {
            return 0;
        }
    }

    public static void parseExistEventName(ConcurrentHashMap<String, Object> rtnObjc, String jsonStr) {
        MapUtils.setStr(rtnObjc, LogConstants.DEST_IP, getValue(jsonStr, "agent_ip"));
        MapUtils.setStr(rtnObjc, LogConstants.SRC_IP, getValue(jsonStr, "detail.src_ip"));
        MapUtils.setStr(rtnObjc, LogConstants.LOG_NAME, getValue(jsonStr, "event_name"));
        MapUtils.setStr(rtnObjc, LogConstants.LOG_URL, getValue(jsonStr, "url"));
        MapUtils.setStr(rtnObjc, LogConstants.LOG_DESCRIPTION, getValue(jsonStr, "event_content"));
        MapUtils.setStr(rtnObjc, LogConstants.MSG_CONTENT, getValue(jsonStr, "event_content"));
        MapUtils.setStr(rtnObjc, LogConstants.LOG_LEVEL, getValue(jsonStr, "event_level"));
        MapUtils.setStr(rtnObjc, LogConstants.ACTION_TYPE, getValue(jsonStr, "detail.service"));

        String reason = getValue(jsonStr, "detail.reason");
        if ("1".equalsIgnoreCase(reason)) {
            MapUtils.setStr(rtnObjc, LogConstants.LOG_DESCRIPTION, "短时间爆破");
        } else if ("2".equalsIgnoreCase(reason)) {
            MapUtils.setStr(rtnObjc, LogConstants.LOG_DESCRIPTION, "尝试不存在的账号");
        } else if ("3".equalsIgnoreCase(reason)) {
            MapUtils.setStr(rtnObjc, LogConstants.LOG_DESCRIPTION, "较长时间内，间断性爆破");
        }

        String shellType = getValue(jsonStr, "detail.webshell_type");
        if ("0".equalsIgnoreCase(shellType)) {
            MapUtils.setStr(rtnObjc, LogConstants.ACTION_TYPE, "WeakFile");
        } else if ("1".equalsIgnoreCase(shellType)) {
            MapUtils.setStr(rtnObjc, LogConstants.ACTION_TYPE, "代码执行");
        } else if ("2".equalsIgnoreCase(shellType)) {
            MapUtils.setStr(rtnObjc, LogConstants.ACTION_TYPE, "系统执行");
        } else if ("3".equalsIgnoreCase(shellType)) {
            MapUtils.setStr(rtnObjc, LogConstants.ACTION_TYPE, "数据库后门");
        } else if ("4".equalsIgnoreCase(shellType)) {
            MapUtils.setStr(rtnObjc, LogConstants.ACTION_TYPE, "文件目录管理");
        } else if ("5".equalsIgnoreCase(shellType)) {
            MapUtils.setStr(rtnObjc, LogConstants.ACTION_TYPE, "特性后门");
        } else if ("6".equalsIgnoreCase(shellType)) {
            MapUtils.setStr(rtnObjc, LogConstants.ACTION_TYPE, "多功能木马");
        } else if ("7".equalsIgnoreCase(shellType)) {
            MapUtils.setStr(rtnObjc, LogConstants.ACTION_TYPE, "已知后门");
        } else if ("301".equalsIgnoreCase(shellType)) {
            MapUtils.setStr(rtnObjc, LogConstants.ACTION_TYPE, "远程下载");
        } else if ("401".equalsIgnoreCase(shellType)) {
            MapUtils.setStr(rtnObjc, LogConstants.ACTION_TYPE, "混淆加密");
        }

        String backdoor_type = getValue(jsonStr, "backdoor_type");
        if (StringUtils.isNotBlank(backdoor_type)) {
            MapUtils.setStr(rtnObjc, LogConstants.ACTION_TYPE, backdoor_type);
        }
    }

    public static void parseExistRiskName(ConcurrentHashMap<String, Object> rtnObjc, String jsonStr) {
        MapUtils.setStr(rtnObjc, LogConstants.LOG_NAME, getValue(jsonStr, "risk_name"));
        MapUtils.setStr(rtnObjc, LogConstants.OP_NAME, getValue(jsonStr, "account"));
        MapUtils.setStr(rtnObjc, LogConstants.ACTION_RULE, getValue(jsonStr, "app"));
        String at = getValue(jsonStr, "acct_type");
        if ("1".equalsIgnoreCase(at)) {
            MapUtils.setStr(rtnObjc, LogConstants.LOG_DESCRIPTION, "空口令");
        } else if ("2".equalsIgnoreCase(at)) {
            MapUtils.setStr(rtnObjc, LogConstants.LOG_DESCRIPTION, "系统默认口令");
        } else if ("3".equalsIgnoreCase(at)) {
            MapUtils.setStr(rtnObjc, LogConstants.LOG_DESCRIPTION, "密码与用户名相同");
        } else if ("4".equalsIgnoreCase(at)) {
            MapUtils.setStr(rtnObjc, LogConstants.LOG_DESCRIPTION, "常见弱密码");
        }


    }

    public static void setAlertName(ConcurrentHashMap<String, Object> resultJson) {
        String messageFormat = "%s 进行 [%s] %s,日志详情为:%s";
        String srcIp = MapUtils.getStr(resultJson, LogConstants.SRC_IP);
        String logName = MapUtils.getStr(resultJson, LogConstants.LOG_NAME);
        if (StringUtils.isEmpty(logName)) {
            logName = MapUtils.getStr(resultJson, LogConstants.LOG_TYPE);
        }
        String eventDescription = MapUtils.getStr(resultJson, LogConstants.LOG_DESCRIPTION);
        String log = MapUtils.getStr(resultJson, LogConstants.LOG_ORI_MSG);
        String alertName = String.format(messageFormat, srcIp, logName, eventDescription, log);
        if ((MapUtils.equal(resultJson, LogConstants.LOG_NAME, "反弹Shell") || MapUtils.equal(resultJson, LogConstants.LOG_NAME, "本地提权") || MapUtils.equal(resultJson, LogConstants.LOG_NAME, "外网暴力破解") || MapUtils.equal(resultJson, LogConstants.LOG_NAME, "后门检测") || MapUtils.equal(resultJson, LogConstants.LOG_NAME, "可疑操作") || MapUtils.equal(resultJson, LogConstants.LOG_NAME, "Web后门") || MapUtils.equal(resultJson, LogConstants.LOG_NAME, "内网暴力破解") || MapUtils.equal(resultJson, LogConstants.LOG_NAME, "异常登录")) && resultJson.containsKey("content")) {
            alertName = MapUtils.getStr(resultJson, "content") + " " + logName;
        }
        resultJson.put(LogConstants.ALERT_NAME, alertName);
    }

}
