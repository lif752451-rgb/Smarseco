package com.crc.log.flink.test.log;

import com.crc.log.flink.common.utils.JsonUtils;
import com.crc.log.flink.config.AllConfig;
import com.crc.log.flink.es.DataProcessFuncation;

import java.util.concurrent.ConcurrentHashMap;

public class ResolvYaXInTDALogTest {

    public static void main(String[] args) {
        AllConfig config = new AllConfig();
        DataProcessFuncation.CONIFG = config;
        config.setMode("single");
        config.setParse("ResolvYaXInTDALog");
        config.setIndex("sec_all");

        String str = "<158>CEF:0|Asiainfo Security|TDA|6.0.1010|4413|Possible Directory Traversal Exploit Attempted SENSOR - HEADERS - HTTP (Request)|4|dvc=10.108.250.239 dvcmac=E4:43:4B:7C:D3:FA dvchost=TDA-T2-FAB deviceExternalId=3A83D4C10D70-40E5AF57-1025-3200-BAC2 rt=Apr 28 2022 15:24:56 GMT+08:00 app=HTTP deviceDirection=1 dhost=203.208.43.98 dst=203.208.43.98 dpt=80 dmac=00:90:0b:35:5b:3f shost=368618-nb01 src=10.108.136.58 spt=21701 smac=10:8c:cf:29:39:40 cs3Label=HostName_Ext cs3=www.gstatic.com fileType=-65536 fsize=0 requestClientApplication=Mozilla/5.0 (Windows NT 10.0; rv:78.0) Gecko/20100101 Firefox/78.0 act=not blocked cn3Label=Threat Type cn3=3 destinationTranslatedAddress=203.208.43.98 sourceTranslatedAddress=10.108.136.58 cnt=1 cat=Exploit cs6Label=pAttackPhase cs6=Point of Entry flexNumber1Label=vLANId flexNumber1=4095 request=http://www.gstatic.com/CFIDE/administrator/enter.cfm?locale\\=../../../../../../../lib/password.properties%00en devicePayloadId=3:7471261:";
        ConcurrentHashMap<String, Object> proc = DataProcessFuncation.parse(str, "index");
        JsonUtils.printStr(proc);

        str = "{\"topic\":\"sec_all\",\"dev_ip\":\"10.108.250.239\",\"message\":\"<158>CEF:0|Asiainfo Security|TDA|6.0.1010|29|Unregistered sender and recipient domains - Email|6|dvc=10.108.250.239 dvcmac=E4:43:4B:7C:D3:FA dvchost=TDA-T2-FAB deviceExternalId=3A83D4C10D70-40E5AF57-1025-3200-BAC2 rt=Apr 19 2022 17:44:04 GMT+08:00 app=SMTP deviceDirection=1 dhost=113.96.208.206 dst=113.96.208.206 dpt=25 dmac=00:90:0b:35:5b:3f shost=10.108.29.210 src=10.108.29.210 spt=60798 smac=00:09:0f:aa:81:aa fileType=393871360 fsize=12352 duser=1142729356@qq.com; 335943758@qq.com; 837843798@qq.com suser=csot.tworkgz9@tcl.com act=not blocked cn3Label=Threat Type cn3=2 destinationTranslatedAddress=113.96.208.206 fileHash=A50F7DC7987727F0E6338AA68822772BE7DA3278 cs1Label=MailSubject cs1=[CSOT]STORY #1620 55\\t作业处理\\t异常做账\\tTrack Out - t9_Twork_FAB一期需求池 sourceTranslatedAddress=10.108.29.210 cnt=1 cat=Suspicious Traffic flexNumber1Label=vLANId flexNumber1=4095 request=http://10.110.37.249/zentao/file-read-10393.png devicePayloadId=2:7105522:\\n\",\"type\":\"udp\",\"timestamp\":\"2022-04-19 17:44:10\"}";
        proc = DataProcessFuncation.parse(str, "index");
        JsonUtils.printStr(proc);

        str = "{\"topic\":\"sec_all\",\"dev_ip\":\"10.108.250.239\",\"message\":\"<158>CEF:0|Asiainfo Security|TDA|6.0.1010|200120|Deny List updated|3|rt=Apr 19 2022 17:43:54 GMT+08:00 dvc=10.108.250.239 dvchost=TDA-T2-FAB dvcmac=E4:43:4B:7C:D3:FA deviceExternalId=3A83D4C10D70-40E5AF57-1025-3200-BAC2 cs1Label=type cs1=Deny List File SHA1 end=May 10 2022 18:28:16 GMT+08:00 act=Add fileHash=86390052F937F862619A3185D11D6A151CD42BA3 cs2Label=RiskLevel cs2=High\",\"type\":\"udp\",\"timestamp\":\"2022-04-19 17:43:54\"}";
        proc = DataProcessFuncation.parse(str, "index");
        JsonUtils.printStr(proc);

        str = "{\"topic\":\"sec_all\",\"dev_ip\":\"10.108.250.239\",\"message\":\"<158>CEF:0|Asiainfo Security|TDA|6.0.1010|200120|Deny List updated|3|rt=Apr 19 2022 17:44:14 GMT+08:00 dvc=10.108.250.239 dvchost=TDA-T2-FAB dvcmac=E4:43:4B:7C:D3:FA deviceExternalId=3A83D4C10D70-40E5AF57-1025-3200-BAC2 cs1Label=type cs1=Deny List File SHA1 end=Apr 22 2022 23:29:08 GMT+08:00 act=Add fileHash=DEE72B1818672195026F226B662DBA813CE7FFF1 cs2Label=RiskLevel cs2=High\",\"type\":\"udp\",\"timestamp\":\"2022-04-19 17:44:14\"}";
        proc = DataProcessFuncation.parse(str, "index");
        JsonUtils.printStr(proc);
    }

}
