package com.crc.log.flink.parse;

import com.crc.log.flink.common.constants.LevelConstants;
import com.crc.log.flink.common.constants.LogConstants;
import com.crc.log.flink.common.utils.DataUtils;
import com.crc.log.flink.common.utils.JsonUtils;
import com.crc.log.flink.common.utils.MapUtils;
import org.apache.commons.lang3.StringUtils;

import java.util.concurrent.ConcurrentHashMap;

@SuppressWarnings("unchecked")
public class ResolvLinuxStringLog {
    /**
     * 非法json的linux日志泛化
     */
    public static ConcurrentHashMap<String,Object> parse(String message) {
        try {
            ConcurrentHashMap<String,Object> data = proc(message);
            if (DataUtils.isNotEmptyJson(data)) {
                return data;
            }
        } catch (Exception ignored) {

        }
        return null;
    }

    private static ConcurrentHashMap<String,Object> proc(String jsonStr) {
        ConcurrentHashMap<String,Object> ldapJson = JsonUtils.createBaseMap(jsonStr);
        try {
            if (StringUtils.isNotBlank(jsonStr)) {
                MapUtils.setStr(ldapJson, LogConstants.MSG_CONTENT, getValue("message", jsonStr));
                MapUtils.setStr(ldapJson, LogConstants.LOG_LEVEL, getValue("level", jsonStr));
                MapUtils.setStr(ldapJson, LogConstants.ACTION_TYPE, getValue("facility", jsonStr));
                MapUtils.setStr(ldapJson, LogConstants.HOST_NAME, getValue("hostname", jsonStr));
                MapUtils.setStr(ldapJson, LogConstants.SRC_IP, getValue("ip", jsonStr));
                MapUtils.setStr(ldapJson, LogConstants.EVENT_ID, getValue("procid", jsonStr));
                MapUtils.setStr(ldapJson, LogConstants.LOG_NAME, getValue("programname", jsonStr));
                MapUtils.setStr(ldapJson, LogConstants.LOG_LEVEL, LevelConstants.INFO);
            }
            ldapJson.put(LogConstants.LOG_LEVEL, LevelConstants.getLevel(MapUtils.getStr(ldapJson,LogConstants.LOG_LEVEL)));
            if (StringUtils.isBlank(MapUtils.getStr(ldapJson, LogConstants.SRC_IP))) {
                ldapJson.put(LogConstants.SRC_IP, "0.0.0.0");
            }
            if (StringUtils.isBlank(MapUtils.getStr(ldapJson, LogConstants.DEST_IP))) {
                ldapJson.put(LogConstants.DEST_IP, "0.0.0.0");
            }
            return ldapJson;
        } catch (Exception e) {
            return ldapJson;
        }
    }

    public static String getValue(String key, String str) {
        try {
            int index = DataUtils.getIndex(str, key);
                    //str.indexOf(key);
            if (index == -1) {
                return "";
            }
            String tmpStr = DataUtils.getSubString(str, index + key.length() + 2);
                    //str.substring(index + key.length() + 2);
            int index2 = DataUtils.getIndex(str, "\"");
                    //str.indexOf("\"");
            tmpStr = DataUtils.getSubString(tmpStr, index2);
                    //tmpStr.substring(index2);
            int index3 = DataUtils.getIndex(tmpStr, "\"");
                    //tmpStr.indexOf("\"");
            tmpStr = DataUtils.getSubString(tmpStr, 0, index);
                    //tmpStr.substring(0, index3);
            return tmpStr;
        } catch (Exception e) {
            return "";
        }
    }
}
