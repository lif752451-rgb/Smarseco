package com.crc.log.flink.test.log;

import com.crc.log.flink.common.utils.JsonUtils;
import com.crc.log.flink.config.AllConfig;
import com.crc.log.flink.es.DataProcessFuncation;

import java.util.concurrent.ConcurrentHashMap;

//奇安信上网行为测试类
public class QAXNITest {
    public static void main(String[] args) {

        String msgx = "<182>Nov 26 14:15:01 NS : 操作日志, 时间:2021-11-26 14:11:09, 来源:用户(UI), 类型:用户管理中心, 用户:dcpcadmin{10.140.8.228}, 描述:修改用户: 年会视频。启用用户。描述：。所属组：/根/视频播放/。多维识别：禁用。IP：10.140.16.21，MAC：00:0E:C6:A6:0D:5A，登录名：，登录并发数：，是否临时用户：否，登录在线时长：分钟，无流量下线时长：分钟，指定下线时刻：，每天允许登录时长：分钟，每天允许登录次数：次，策略配置：[共享接入阻塞]共享接入策略_阻塞_1545720760,[网页]网站访问,[应用控制]人力网站访问,[应用控制]SFTP,[应用控制]微信文件传输,[应用控制]Guest-VPN,[应用控制]视频播放,[应用控制]运维-向日葵,[应用控制]其他网络硬盘网站,[应用控制]自由门,[应用控制]金山企业云,[应用控制]允许SOCKS,[应用控制]证券访问,直播带宽保障,[天擎]天擎准入,GUEST限速5M,共享接入白名单,免控制用户,用户黑名单,客户端推送,天擎推送,免审计用户,[审计]QQ客户端审计,[审计]SKYPE客户端审计,[审计]BAIDUHI客户端审计,[审计]微信客户端审计,[审计]百度网盘客户端审计,[管控]禁止wifi热点,[管控]QQ客户端外发文件封堵,[管控]微信客户端外发文件封堵,[管控]百度网盘客户端上传文件封堵";
        AllConfig config = new AllConfig();
        DataProcessFuncation.CONIFG = config;
        config.setMode("single");
        config.setParse("ResolvQAXNI");
        config.setIndex("sec_all");


        ConcurrentHashMap<String, Object> json = DataProcessFuncation.parse(msgx, "index");
        JsonUtils.printStr(json);
    }
}
