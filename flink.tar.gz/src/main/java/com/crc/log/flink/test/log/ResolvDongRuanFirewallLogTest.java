package com.crc.log.flink.test.log;

import com.crc.log.flink.common.utils.JsonUtils;
import com.crc.log.flink.config.AllConfig;
import com.crc.log.flink.es.DataProcessFuncation;

import java.util.concurrent.ConcurrentHashMap;

/**
 * @author jixiangqi
 * @date 2022/1/18
 */
public class ResolvDongRuanFirewallLogTest {


    public static void main(String[] args) {
        AllConfig config = new AllConfig();
        DataProcessFuncation.CONIFG = config;
        config.setMode("single");
        config.setParse("ResolvDongRuanFirewallLog");
        config.setIndex("sec_all");


        String str = "<164>2022-01-18 14:56:30 ZY-JG6F-SER-FW5200-02:root 03-01-071-0002 Warning System attack rep=1 | 识别具有攻击行为的数据包， 其内容是： 协议6， 从22.0.129.128:36974[Untrust]到22.0.3.35:80， 在虚拟系统0中， 是被NULLSCAN_DETECTOR所检测到的。";
        ConcurrentHashMap<String, Object> proc = DataProcessFuncation.parse(str, "index");
        JsonUtils.printStr(proc);

        str = "<164>2022-01-18 14:56:29 ZY-JG6F-SER-FW5200-02:root 03-01-071-0002 Warning System attack rep=1 | 识别具有攻击行为的数据包， 其内容是： 协议6， 从22.0.129.128:39621[Untrust]到22.0.1.20:21， 在虚拟系统0中， 是被XMASSCAN_DETECTOR所检测到的。";
        proc = DataProcessFuncation.parse(str, "index");
        JsonUtils.printStr(proc);

        str = "<161>2022-01-18 14:56:25 ZY-JG6F-SER-FW5200-02:root 03-01-071-0001 Alert System attack rep=1 | 识别具有攻击行为的数据包， 其内容是： 协议1， 从22.0.129.128[Untrust]到22.0.2.25， 在虚拟系统0中， 是被IPSWEEP_DETECTOR所检测到的。";
        proc = DataProcessFuncation.parse(str, "index");
        JsonUtils.printStr(proc);
    }

}
