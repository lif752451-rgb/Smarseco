package com.crc.log.flink.test.log;

import com.crc.log.flink.common.utils.JsonUtils;
import com.crc.log.flink.config.AllConfig;
import com.crc.log.flink.es.DataProcessFuncation;

import java.util.concurrent.ConcurrentHashMap;

/**
 * @author jixiangqi
 * @date 2022/5/24
 */
public class ResolvAnHengDASLogTest {

    public static void main(String[] args) {
        AllConfig config = new AllConfig();
        DataProcessFuncation.CONIFG = config;
        config.setMode("single");
        config.setParse("ResolvAnHengDASLog");
        config.setIndex("sec_all");


        String str = "<1>May 23 04:54:46 DAS-Gateway-A;530000500119092317606286;ipv4;3; ips: user_id=2;user_name=41.86.18.153;policy_id=128;src_mac=0c:73:eb:90:f9:8e;dst_mac=90:f1:b0:fb:55:16;src_ip=41.86.18.153;dst_ip=10.128.2.97;src_port=43439;dst_port=80;X-Forwarded-For=;app_name=网页浏览(HTTP);protocol=TCP;app_protocol=HTTP;event_id=46624;event_name=SERVER-WEBAPP GPON路由器身份验证绕过和命令注入尝试;event_type=蠕虫/病毒;agg_mode:0;agg_count:0;attack_success:1;level=alert;ctime=2022-05-23 04:54:46;action=drop";
        ConcurrentHashMap<String, Object> proc = DataProcessFuncation.parse(str, "index");
        JsonUtils.printStr(proc);
    }

}
