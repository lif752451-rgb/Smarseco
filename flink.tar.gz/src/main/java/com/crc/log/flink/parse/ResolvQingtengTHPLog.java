package com.crc.log.flink.parse;

import com.alibaba.fastjson.JSONObject;
import com.crc.log.flink.common.constants.LevelConstants;
import com.crc.log.flink.common.constants.LogConstants;
import com.crc.log.flink.common.utils.DataUtils;
import com.crc.log.flink.common.utils.JsonUtils;
import com.crc.log.flink.common.utils.MapUtils;
import org.apache.commons.lang3.StringUtils;

import java.util.concurrent.ConcurrentHashMap;

public class ResolvQingtengTHPLog {

    /**
     * 通用日志 日志泛化
     */
    public static ConcurrentHashMap<String, Object> parse(String message) {
        try {
            ConcurrentHashMap<String, Object> data = proc(message);
            if (DataUtils.isNotEmptyJson(data)) {
                return data;
            }
        } catch (Exception ignored) {

        }
        return null;
    }

    private static ConcurrentHashMap<String, Object> proc(String jsonStr) {
        ConcurrentHashMap<String, Object> rtnObjc = JsonUtils.createBaseMap(jsonStr);
        JSONObject json = getMsgContent(jsonStr);

        rtnObjc.put(LogConstants.SRC_IP, JsonUtils.getStr(json, "agent_ip"));
        rtnObjc.put(LogConstants.HOST_NAME, JsonUtils.getStr(json, "host_name"));
        rtnObjc.put(LogConstants.LOG_NAME, JsonUtils.getStr(json, "instruction_title"));
        rtnObjc.put(LogConstants.LOG_DESCRIPTION, JsonUtils.getStr(json, "instruction_description"));
        rtnObjc.put(LogConstants.ACTION_TYPE, JsonUtils.getStr(json, "instruction_tag"));
        //rtnObjc.put(LogConstants.LOG_START_TIME, MapUtils.getStr(json, "from_unixtime(datatime)"));
        rtnObjc.put("agent_id", JsonUtils.getStr(json, "agent_id"));
        rtnObjc.put("uname", JsonUtils.getStr(json, "uname"));
        rtnObjc.put("ppname", JsonUtils.getStr(json, "ppname"));


//        try {
//            if (json.containsKey("content"))
//                rtnObjc.putAll(json.getJSONObject("content"));
//        } catch (Exception e) {
//
//        }
        rtnObjc.put(LogConstants.LOG_PRODUCT, "青藤THP");
        rtnObjc.put(LogConstants.LOG_LEVEL, LevelConstants.getLevel(MapUtils.getStr(rtnObjc,LogConstants.LOG_LEVEL)));
        if (StringUtils.isBlank(MapUtils.getStr(rtnObjc, LogConstants.SRC_IP))) {
            rtnObjc.put(LogConstants.SRC_IP, "0.0.0.0");
        }
        if (StringUtils.isBlank(MapUtils.getStr(rtnObjc, LogConstants.DEST_IP))) {
            rtnObjc.put(LogConstants.DEST_IP, "0.0.0.0");
        }
        setAlertName(rtnObjc);
        return rtnObjc;

    }

    private static void setAlertName(ConcurrentHashMap<String, Object> rtnObjc) {
        String srcIp = MapUtils.getStr(rtnObjc, LogConstants.SRC_IP);
        String name = MapUtils.getStr(rtnObjc, LogConstants.LOG_NAME);
        String logDescription = MapUtils.getStr(rtnObjc, LogConstants.LOG_DESCRIPTION);
        String log = MapUtils.getStr(rtnObjc, LogConstants.LOG_ORI_MSG);
        String msgFormat = "";
        String alertName = "";
        if (!srcIp.equals("0.0.0.0") && StringUtils.isNotBlank(name) && StringUtils.isNotBlank(logDescription)) {
            msgFormat = "IP为:%s产生了一个:%s的日志,具体描述为:%s,日志详情为:%s";
            alertName = String.format(msgFormat, srcIp, name, logDescription, log);
        } else {
            alertName = "日志详情为:" + log;
        }
        rtnObjc.put(LogConstants.ALERT_NAME, alertName);
    }

    public static JSONObject getMsgContent(String msg) {
        try {

            msg = "{\""+DataUtils.getSubString(msg, DataUtils.getIndex(msg, "instruction_title"), DataUtils.getIndex(msg, "pppath")-2).replace("=\"","\":\"").replace("\" ","\",\"")+"\"}";
            //msg = "{\""+msg.substring(msg.indexOf("instruction_title"),msg.indexOf("pppath")-2).replace("=\"","\":\"").replace("\" ","\",\"")+"\"}";
        }catch(Exception ignored){

        }


        return JsonUtils.parse(msg);
    }
}
