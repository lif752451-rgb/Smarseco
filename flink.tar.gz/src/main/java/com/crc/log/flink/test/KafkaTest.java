package com.crc.log.flink.test;

import com.crc.log.flink.kafka.CrcKafkaProducer;

public class KafkaTest {
    public static void main(String[] args) throws Exception {
        CrcKafkaProducer kafka = new CrcKafkaProducer("127.0.0.1:9092", "wifiAccess_log");
        kafka.start();

        //while (true) {
        //String msg = "nxlog_index=www_all#@%sender=ssp#@%src_ip=59.36.120.231#@%src_port=37104#@%dst_ip=10.54.238.10#@%dst_port=80#@%proto=HTTP#@%sparktime=2022-05-19 04:14:00#@%dev_ip=59.36.120.231#@%product=绿盟IPS#@%action_result=#@%action_type=[24298]Struts2远程命令执行漏洞(CVE-2018-11776)(S2-057)#@%log_level=#@%msg=<5>time=2021-04-19 18:00:54;log_type=ips;danger_degree=3;breaking_sighn=1;event=[24298]Struts2远程命令执行漏洞(CVE-2018-11776)(S2-057);src_addr=59.36.120.231;src_port=37104;dst_addr=10.54.238.10;dst_port=80;user=null;smt_user=null;proto=HTTP;";
        String msg = "{\"topic\":\"wifiAccess_log\",\"dev_ip\":\"10.54.250.13\",\"message\":\"<143>2023-01-05 08:21:44,970 10.54.250.13 Insight logs to logserver 11808082 1 0 Auth.Username=WANGHANLU,Auth.Host-MAC-Address=a0a4c5ad6727,Auth.Protocol=RADIUS,CppmNode.CPPM-Node=10.54.250.12,Auth.Login-Status=0,Auth.Service=BU-CS-CRC-service,Auth.Source=CRC-AD,Auth.Roles=Device-PC|[Machine Authenticated]|[User Authenticated],Radius.Framed-IP-Address=10.54.200.18\",\"type\":\"udp\",\"timestamp\":\"2023-01-04 12:26:23\"}";
        for (int i = 0; i < 10000; i++) {
            //String newMsg = msg.replace("2021-10-22", DateUtils.getDate(0));
            CrcKafkaProducer.magicQueue.offer(msg);
            //Thread.sleep(1000);
        }
        //    try {
        ////        Thread.sleep(5000);
        //    } catch (Exception e) {
        //        e.printStackTrace();
        //    }
        //}
    }
}
