package com.crc.log.flink.parse;

import com.crc.log.flink.common.constants.LevelConstants;
import com.crc.log.flink.common.constants.LogConstants;
import com.crc.log.flink.common.utils.*;
import org.apache.commons.lang3.StringUtils;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.LinkedList;
import java.util.List;
import java.util.concurrent.ConcurrentHashMap;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * 深信服AC
 */
public class ResolvSangforACLog {
    /**
     * 通用日志 日志泛化
     */
    public static ConcurrentHashMap<String,Object> parse(String message) {
        try {
            ConcurrentHashMap<String,Object> data = proc(message);
            if (DataUtils.isNotEmptyJson(data)) {
                return data;
            }
        } catch (Exception ignored) {

        }
        return null;
    }

    private static ConcurrentHashMap<String,Object> proc(String jsonStr) {
        ConcurrentHashMap<String,Object> rtnObjc = JsonUtils.createBaseMap(jsonStr);
        if (jsonStr.contains("[")) {
            Pattern p = Pattern.compile("(\\[[^\\]]*\\])");
            Matcher m = p.matcher(jsonStr);
            List<String> dataList = new LinkedList<>();
            while (m.find()) {
                try {
                    //∂String data = m.group().substring(1, m.group().length() - 1);
                    String data = DataUtils.getSubString(m.group(),1,m.group().length()-1);
                    dataList.add(data);
                } catch (Exception ignored) {
                    
                }
            }
            for (String data : dataList) {
                if (data.contains(":")) {
                    int index = DataUtils.getIndex(data, ":");
                            //data.indexOf(":");
                    String key = DataUtils.getSubString(data, 0, index);
                            //data.substring(0, index);
                    String value = DataUtils.getSubString(data, index+1);
                            //data.substring(index+1);
                    switchFields(rtnObjc, key, value);
                } else {
                    rtnObjc.put(LogConstants.LOG_TYPE, data);
                }
            }
        } else if (jsonStr.contains("connection")) {
            List<String> ips = getIps(jsonStr);
            if (ips.size() == 2) {
                String srcIp = ips.get(0);
                String destIp = ips.get(1);
                rtnObjc.put(LogConstants.SRC_IP, srcIp);
                rtnObjc.put(LogConstants.DEST_IP, destIp);
                int index = DataUtils.getIndex(jsonStr, srcIp);
                        //jsonStr.indexOf(srcIp);
                String temp = DataUtils.getSubString(jsonStr, index + srcIp.length() + 1);
                        //jsonStr.substring(index + srcIp.length() + 1);
                int index1 = DataUtils.getIndex(temp, " ");
                        //temp.indexOf(" ");
                try {
                    int srcPort = DataUtils.toNum(DataUtils.getSubString(temp, 0, index1));
                    rtnObjc.put(LogConstants.SRC_PORT, srcPort);
                    index = DataUtils.getIndex(jsonStr, destIp);
                            //jsonStr.indexOf(destIp);
                    temp = DataUtils.getSubString(jsonStr, index + destIp.length() + 1);
                            //jsonStr.substring(index + destIp.length() + 1);
                    index1 = DataUtils.getIndex(temp, ",");
                            //temp.indexOf(",");
                    int destPort = DataUtils.toNum(DataUtils.getSubString(temp, 0, index1));
                    rtnObjc.put(LogConstants.DEST_PORT, destPort);
                } catch (Exception ignored) {
                    
                }
            }
        } else {
            int index = DataUtils.getIndex(jsonStr, "(");
                    //jsonStr.indexOf("(");
            if (index > -1) {
                jsonStr = DataUtils.getSubString(jsonStr, index+1, jsonStr.length()-1);
                        //jsonStr.substring(index+1, jsonStr.length()-1);
                String[] split = DataUtils.getSplit(jsonStr, ",");
                        //jsonStr.split(",");
                for (String temp : split) {
                    String[] array = DataUtils.getSplit(temp, "=");
                    //temp.split("=");
                    String key = array[0].trim();
                    String value = array.length > 1 ? array[1] : "";
                    switchFields(rtnObjc, key, value);
                }
            } else if (jsonStr.contains("logs")){
                int index1 = DataUtils.getIndex(jsonStr, "logs");
                        //jsonStr.indexOf("logs");
                jsonStr = DataUtils.getSubString(jsonStr, index1+5).trim();
                        //jsonStr.substring(index1 + 5).trim();
                index1 = DataUtils.getIndex(jsonStr, " ");
                        //jsonStr.indexOf(" ");
                String type = DataUtils.getSubString(jsonStr, 0, index1);
                        //jsonStr.substring(0,index1);
                String event = DataUtils.getSubString(jsonStr, index1+1);
                        //jsonStr.substring(index1+1);
                rtnObjc.put(LogConstants.LOG_TYPE, type);
                rtnObjc.put(LogConstants.LOG_DESCRIPTION, event);
            }
        }

        rtnObjc.put(LogConstants.LOG_LEVEL, LevelConstants.getLevel(MapUtils.getStr(rtnObjc,LogConstants.LOG_LEVEL)));
        if (StringUtils.isBlank(MapUtils.getStr(rtnObjc, LogConstants.SRC_IP))) {
            rtnObjc.put(LogConstants.SRC_IP, "0.0.0.0");
        }
        if (StringUtils.isBlank(MapUtils.getStr(rtnObjc, LogConstants.DEST_IP))) {
            rtnObjc.put(LogConstants.DEST_IP, "0.0.0.0");
        }
        rtnObjc.put(LogConstants.LOG_PRODUCT, "深信服AC");
        setAlertName(rtnObjc);
        return rtnObjc;
    }

    private static void switchFields(ConcurrentHashMap<String,Object> rtnObjc, String key, String value) {
        switch (key) {
            case "SrcIp":
                rtnObjc.put(LogConstants.SRC_IP, value);
                break;
            case "DstIp":
                rtnObjc.put(LogConstants.DEST_IP, value);
                break;
            case "SrcPort":
                rtnObjc.put(LogConstants.SRC_PORT, value);
                break;
            case "DstPort":
                rtnObjc.put(LogConstants.DEST_PORT, value);
                break;
            case "Protocol":
                rtnObjc.put(LogConstants.LOG_PROTOCAL, value);
                break;
            case "Event":
                rtnObjc.put(LogConstants.LOG_CONTENT, value);
                break;
            case "DetectTime":
                rtnObjc.put(LogConstants.LOG_START_TIME, DateUtils.getISO8601Timestamp(DateUtils.parseDateTime("yyyy/MM/dd HH:mm:ss", value)));
                break;
            case "user_name":
                rtnObjc.put(LogConstants.USER_NAME, value);
                break;
            case "ip":
                rtnObjc.put(LogConstants.SRC_IP, value);
                break;
            case "mac":
                rtnObjc.put(LogConstants.SRC_MAC, value);
                break;
            case "online_time":
                rtnObjc.put(LogConstants.CANCEL_TIME, value);
                break;
            case "action":
                rtnObjc.put(LogConstants.ACTION_TYPE, value);
                break;
            case "detail":
                rtnObjc.put(LogConstants.LOG_DESCRIPTION, value);
                break;
            case "host_ip":
                rtnObjc.put(LogConstants.SRC_IP, value);
                break;
            case "user":
                rtnObjc.put(LogConstants.OP_NAME, value);
                break;
            case "protocol":
                rtnObjc.put(LogConstants.LOG_PROTOCAL, ProtoUtils.switchProto(DataUtils.toNum(value)));
                break;
        }
    }

    private static void setAlertName(ConcurrentHashMap<String,Object> rtnObjc) {
        String msgFormat = "";
        String alertName = "";
        String srcIp = MapUtils.getStr(rtnObjc, LogConstants.LOG_DEV_IP);
        String level = MapUtils.getStr(rtnObjc, LogConstants.LOG_LEVEL);
        String destIp = MapUtils.getStr(rtnObjc, LogConstants.DEST_IP);
        String actionType = MapUtils.getStr(rtnObjc, LogConstants.ACTION_TYPE);
        String description = MapUtils.getStr(rtnObjc, LogConstants.LOG_DESCRIPTION);
        String proto = MapUtils.getStr(rtnObjc, LogConstants.LOG_PROTOCAL);
        String content = MapUtils.getStr(rtnObjc, LogConstants.LOG_CONTENT);
        String log = MapUtils.getStr(rtnObjc, LogConstants.LOG_ORI_MSG);
        if (StringUtils.isNotBlank(content)) {
            msgFormat = "IP为:%s对IP为:%s发起了一个访问协议为:%s的访问,具体内容为:%s,风险级别:%s,日志详情为:%s";
            alertName = String.format(msgFormat, srcIp, destIp, proto, content, level, log);
        } else if (destIp.equals("0.0.0.0") && !srcIp.equals("0.0.0.0")){
            msgFormat = "用户在IP为:%s的设备上进行了:%s操作,具体描述为:%s,风险级别:%s,日志详情为:%s";
            alertName = String.format(msgFormat, srcIp, actionType,description, level, log);
        } else {
            if (destIp.equals("0.0.0.0") || srcIp.equals("0.0.0.0")) {
                msgFormat = "日志详情为:%s";
                alertName = String.format(msgFormat, log);
            } else {
                msgFormat = "源IP为:%s,目的IP为:%s,风险级别:%s,日志详情为:%s";
                alertName = String.format(msgFormat, srcIp, destIp, level, log);
            }
        }
        rtnObjc.put(LogConstants.ALERT_NAME, alertName);
    }

    public static List<String> getIps(String ipString){
        String regEx="((2[0-4]\\d|25[0-5]|[01]?\\d\\d?)\\.){3}(2[0-4]\\d|25[0-5]|[01]?\\d\\d?)";
        List<String> ips = new ArrayList<String>();
        Pattern p = Pattern.compile(regEx);
        Matcher m = p.matcher(ipString);
        while (m.find()) {
            String result = m.group();
            ips.add(result);
        }
        return ips;
    }


    static HashMap<String, String> keyMap = new HashMap<>();
    static HashMap<String, String> typeMap = new HashMap<>();

    static {
        keyMap.put("user", LogConstants.OP_NAME);
        keyMap.put("host_ip", LogConstants.SRC_IP);
        keyMap.put("src_port", LogConstants.SRC_PORT);
        keyMap.put("dst_ip", LogConstants.DEST_IP);
        keyMap.put("serv_port", LogConstants.DEST_PORT);
        keyMap.put("url", LogConstants.LOG_URL);
        keyMap.put("urllog_type", LogConstants.ACTION_TYPE);
        keyMap.put("urltype", LogConstants.ACTION_RULE);
        keyMap.put("title", LogConstants.LOG_TITLE);
        keyMap.put("DNS", LogConstants.LOG_DNS);
        keyMap.put("dev_id", LogConstants.SRC_DEV_INFO);
        keyMap.put("keyword_original", LogConstants.LOG_KEYWORD);
        keyMap.put("record_time", LogConstants.LOG_START_TIME);
        keyMap.put("group", LogConstants.LOG_GROUP);
        keyMap.put("filename", LogConstants.LOG_FILENAME);
        keyMap.put("host", LogConstants.TARGET_DOMAIN_NAME);
        keyMap.put("net_action", LogConstants.ACTION_RESULT);
        keyMap.put("app", LogConstants.LOG_APP);
        keyMap.put("mail_title", "mail_title");
        keyMap.put("mail_from", "mail_from");
        keyMap.put("mail_to", "mail_to");
        keyMap.put("mail_body", "mail_body");

        keyMap.put("chat_from", "chat_from");
        keyMap.put("chat_to", "chat_to");
        keyMap.put("msg", "msg");

        keyMap.put("usr_name", LogConstants.OP_NAME);
        keyMap.put("hst_ip", LogConstants.SRC_IP);
        keyMap.put("login_time", "login_time");
        keyMap.put("online_time", "online_time");


        keyMap.put("serv", LogConstants.LOG_TYPE);
        keyMap.put("up_flux", "up_flux");
        keyMap.put("down_flux", "down_flux");

        keyMap.put("risk_level", "risk_level");
        keyMap.put("virus", "virus");
        keyMap.put("category", "category");
        keyMap.put("family", "family");
        keyMap.put("sigclass", "sigclass");
        keyMap.put("signame", "signame");

        typeMap.put("mail_title", "mail邮件收发");
        typeMap.put("chat_from", "chat(聊天)");
        typeMap.put("login_time", "登陆注销");
        typeMap.put("up_flux", "流量日志");

    }
}
