//package com.crc.log.flink.test;
//
//import com.crc.log.flink.es.RestClientFactoryImpl;
//import org.apache.flink.api.common.functions.RuntimeContext;
//import org.apache.flink.api.common.serialization.SimpleStringSchema;
//import org.apache.flink.streaming.api.datastream.DataStreamSource;
//import org.apache.flink.streaming.api.environment.StreamExecutionEnvironment;
//import org.apache.flink.streaming.connectors.elasticsearch.ElasticsearchSinkFunction;
//import org.apache.flink.streaming.connectors.elasticsearch.RequestIndexer;
//import org.apache.flink.streaming.connectors.elasticsearch.util.RetryRejectedExecutionFailureHandler;
//import org.apache.flink.streaming.connectors.elasticsearch6.ElasticsearchSink;
//import org.apache.flink.streaming.connectors.kafka.FlinkKafkaConsumer011;
//import org.apache.http.HttpHost;
//import org.elasticsearch.action.index.IndexRequest;
//import org.elasticsearch.client.Requests;
//import org.slf4j.Logger;
//import org.slf4j.LoggerFactory;
//
//import java.util.*;
//
///**
// * sink es
// *
// * @since 2020/4/21 9:58
// */
//public class SinkTest {
//    private static final Logger log = LoggerFactory.getLogger(SinkTest.class);
//
//    public static void sinkEs() throws Exception {
//        final StreamExecutionEnvironment env = StreamExecutionEnvironment.getExecutionEnvironment();
//        Properties props = new Properties();
//        props.put("bootstrap.servers", "localhost:9092");
//        props.put("zookeeper.connect", "localhost:2181");
//        props.put("group.id", "test");
//        props.put("key.deserializer", "org.apache.kafka.common.serialization.StringDeserializer");
//        props.put("value.deserializer", "org.apache.kafka.common.serialization.StringDeserializer");
//        props.put("auto.offset.reset", "latest");
//        DataStreamSource<String> stream = env.addSource(new FlinkKafkaConsumer011<>(
//                //这个 kafka topic 需要和上面的工具类的 topic 一致
//                "testTopic", new SimpleStringSchema(), props)).setParallelism(4);
//        // 从指定的时间开始（毫秒）
//        // myConsumer.setStartFromTimestamp();
//        // myConsumer.setStartFromGroupOffsets(); // 默认的方法
//
//        // 添加数据源
//        stream.print();
//        List<HttpHost> esHttphost = new ArrayList<>();
//        esHttphost.add(new HttpHost("127.0.0.1", Integer.valueOf(9200), "http"));
//
//        ElasticsearchSink.Builder<String> esSinkBuilder = new ElasticsearchSink.Builder<>(
//                esHttphost,
//                new ElasticsearchSinkFunction<String>() {
//                    public IndexRequest createIndexRequest(String element) {
//                        Map<String, String> json = new HashMap<>();
//                        json.put("data", element);
//                        log.info("data:" + element);
//
//                        return Requests.indexRequest()
//                                .index("index-log")
//                                .type("doc")
//                                .source(json);
//                    }
//
//                    @Override
//                    public void process(String element, RuntimeContext ctx, RequestIndexer indexer) {
//                        indexer.add(createIndexRequest(element));
//                    }
//                }
//        );
//
//        esSinkBuilder.setBulkFlushMaxActions(1);
//
//        esSinkBuilder.setRestClientFactory(new RestClientFactoryImpl());
//        esSinkBuilder.setFailureHandler(new RetryRejectedExecutionFailureHandler());
//
//        stream.addSink(esSinkBuilder.build());
//        env.execute("flink learning connectors kafka");
//    }
//
//    public static void main(String[] args) throws Exception {
//        sinkEs();
//    }
//}
//
