package com.crc.log.flink.parse;

import com.crc.log.flink.common.constants.ActionResultConstants;
import com.crc.log.flink.common.constants.LevelConstants;
import com.crc.log.flink.common.constants.LogConstants;
import com.crc.log.flink.common.utils.*;
import org.apache.commons.lang3.StringUtils;

import java.util.LinkedList;
import java.util.List;
import java.util.concurrent.ConcurrentHashMap;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * 天融信上网行为
 */
public class ResolvInternetBehaviorLog {
    public static ConcurrentHashMap<String,Object> parse(String message) {
        try {
            ConcurrentHashMap<String,Object> data = proc(message);
            if (DataUtils.isNotEmptyJson(data)) {
                return data;
            }
        } catch (Exception ignored) {

        }
        return null;
    }

    private static ConcurrentHashMap<String,Object> proc(String jsonStr) {
        ConcurrentHashMap<String,Object> rtnObjc = JsonUtils.createBaseMap(jsonStr);
        Pattern p = Pattern.compile("(\\[[^\\]]*\\])");
        Matcher m = p.matcher(jsonStr);
        List<String> dataList = new LinkedList<>();
        while (m.find()) {
            try {
                String data = m.group().substring(1, m.group().length() - 1);
                dataList.add(data);
            } catch (Exception ignored) {

            }
        }
        for (String data : dataList) {
            int index = DataUtils.getIndex(data, ":");
            if (index > -1) {
                String key = DataUtils.getSubString(data, 0, index);
                String value = DataUtils.getSubString(data, index+1);
                switch (key){
                    case "log_type":
                        rtnObjc.put(LogConstants.LOG_TYPE, value);
                        break;
                    case "record_time":
                        rtnObjc.put(LogConstants.LOG_START_TIME, DateUtils.getISO8601Timestamp(value));
                        break;
                    case "user":
                        rtnObjc.put(LogConstants.USER_NAME, value);
                        break;
                    case "group":
                        rtnObjc.put(LogConstants.LOG_GROUP, value);
                        break;
                    case "host_ip":
                        if (IPUtil.isIp(value)) {
                            rtnObjc.put(LogConstants.SRC_IP, value);
                        }
                        break;
                    case "dst_ip":
                        if (IPUtil.isIp(value)) {
                            rtnObjc.put(LogConstants.DEST_IP, value);
                        }
                        break;
                    case "serv":
                        rtnObjc.put(LogConstants.LOG_SERV, value);
                        break;
                    case "app":
                        rtnObjc.put(LogConstants.LOG_APP, value);
                        break;
                    case "site":
                        rtnObjc.put(LogConstants.LOG_SITE, value);
                        break;
                    case "tm_type":
                        rtnObjc.put(LogConstants.LOG_TERMINAL_TYPE, value);
                        break;
                    case "up_flux":
                        rtnObjc.put(LogConstants.UP_FLUX, value);
                        break;
                    case "down_flux":
                        rtnObjc.put(LogConstants.DOWN_FLUX, value);
                        break;
                }
            }
        }
        int index = DataUtils.getIndex(jsonStr, "[");
        if (index > -1) {
            index = DataUtils.getLastIndex(DataUtils.getSubString(jsonStr, index), " ");
        }
        if (index > -1) {
            jsonStr = DataUtils.getSubString(jsonStr, 0, index).trim();
        }
        int index1 = DataUtils.getLastIndex(jsonStr, " ");
        if (index1 > -1) {
            String hostName =  DataUtils.getSubString(jsonStr, index1+1);
            MapUtils.setStr(rtnObjc, LogConstants.HOST_NAME, hostName);
            String actionResult = "success".equalsIgnoreCase(MapUtils.getStr(rtnObjc,LogConstants.ACTION_RESULT)) ?
                    ActionResultConstants.DENY : ActionResultConstants.NO_DENY;
            rtnObjc.put(LogConstants.ACTION_RESULT, actionResult);
        }
        rtnObjc.put(LogConstants.LOG_PRODUCT, "天融信上网行为");
        rtnObjc.put(LogConstants.LOG_LEVEL, LevelConstants.getLevel(MapUtils.getStr(rtnObjc,LogConstants.LOG_LEVEL)));
        if (StringUtils.isBlank(MapUtils.getStr(rtnObjc, LogConstants.SRC_IP))) {
            rtnObjc.put(LogConstants.SRC_IP, "0.0.0.0");
        }
        if (StringUtils.isBlank(MapUtils.getStr(rtnObjc, LogConstants.DEST_IP))) {
            rtnObjc.put(LogConstants.DEST_IP, "0.0.0.0");
        }
        setAlertName(rtnObjc);
        return rtnObjc;
    }

    private static void setAlertName(ConcurrentHashMap<String,Object> rtnObjc) {
        String msgFormat = "源IP为:%s,目的IP为:%s;风险级别:%s;攻击结果:%s;事件类型:%s,日志详情为:%s";
        String alertName = "";
        String srcIp = MapUtils.getStr(rtnObjc, LogConstants.SRC_IP);
        String destIp = MapUtils.getStr(rtnObjc, LogConstants.DEST_IP);
        String result = MapUtils.getStr(rtnObjc, LogConstants.ACTION_RESULT);
        String type = MapUtils.getStr(rtnObjc, LogConstants.LOG_TYPE);
        String level = MapUtils.getStr(rtnObjc, LogConstants.LOG_LEVEL);
        String log = MapUtils.getStr(rtnObjc, LogConstants.LOG_ORI_MSG);
        if (destIp.equals("0.0.0.0")) {
            msgFormat = "源IP为:%s产生了一个风险级别为:%s;攻击结果为:%s;事件类型为:%s的告警,日志详情为:%s";
            alertName = String.format(msgFormat, srcIp, level, result, type, log);
        } else {
            alertName = String.format(msgFormat, srcIp, destIp, level, result, type, log);
        }
        rtnObjc.put(LogConstants.ALERT_NAME, alertName);
    }
}




