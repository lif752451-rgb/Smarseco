package com.crc.log.flink.test.log;

import com.crc.log.flink.common.utils.JsonUtils;
import com.crc.log.flink.config.AllConfig;
import com.crc.log.flink.es.DataProcessFuncation;

import java.util.concurrent.ConcurrentHashMap;

/**
 * @author jixiangqi
 * @date 2022/5/9
 */
public class ResolvAnGyAPTLogTest {

    public static void main(String[] args) {
        AllConfig config = new AllConfig();
        DataProcessFuncation.CONIFG = config;
        config.setMode("single");
        config.setParse("ResolvAnGyAPTLog");
        config.setIndex("sec_all");


        String str = "<5>Feb 22 15:48:38 HOST;110104300117042052011873;ipv4;3;ips: user_id=2;user_name=192.168.1.171;policy_id=1;src_mac=08:9e:01:6b:9e:43;dst_mac=00:21:45:c7:00:c1;src_ip=192.168.1.171;dst_ip=192.168.88.1;src_port=37990;dst_port=80;X-Forwarded-For=;app_name=..(HTTP);protocol=TCP;app_protocol=HTTP;event_id=957736;event_name=log4j2..;event_type=..;agg_mode:0;agg_count:0;attack_success:0;level=notice;ctime=2021-02-22 15:48:38;action=drop";
        ConcurrentHashMap<String, Object> proc = DataProcessFuncation.parse(str, "index");
        JsonUtils.printStr(proc);

        str = "<5> Oct 25 09:18:52 Host;110104700118041322712017;ipv4;3; user_loginLogout: SSL VPN authentication logout:logname= sslvpnname @192.168.6.69(80:ed:2c:8a:2d:be) login at 2021-10-25 09:17:26, logout at 2021-10-25 09:18:52, duration is 85s, reason is logout";
        proc = DataProcessFuncation.parse(str, "index");
        JsonUtils.printStr(proc);
    }

}
