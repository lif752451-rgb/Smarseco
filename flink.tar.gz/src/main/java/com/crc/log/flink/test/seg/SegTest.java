package com.crc.log.flink.test.seg;

import com.crc.log.flink.common.entity.TbSegementInfo;
import com.crc.log.flink.common.utils.JsonUtils;
import com.crc.log.flink.load.NewSegmentLoad;

public class SegTest {
    public static void main(String[] args) {
        TbSegementInfo segementInfo = new TbSegementInfo();
        segementInfo.setSegment("10.137.58.0/24（长治分公司）");
        segementInfo.setSegment("10.137.58.0/24（长治分公司）");
        segementInfo.setSegment("10.137.58.0/24 \n 10.137.59.0/24");
        NewSegmentLoad log = new NewSegmentLoad();
        JsonUtils.print(log.save2Segment(segementInfo));
    }
}
