package com.crc.log.flink.test.ip;

import com.crc.log.flink.FlinkApplication;
import com.crc.log.flink.common.utils.JsonUtils;
import com.crc.log.flink.config.AllConfig;
import com.crc.log.flink.config.GetSpringBean;
import com.crc.log.flink.es.DataProcessFuncation;

import java.util.concurrent.ConcurrentHashMap;

public class IpTest4 {
    public static void main(String[] args) {
        if (FlinkApplication.ALL_CONFIG == null) {
            FlinkApplication.ALL_CONFIG = GetSpringBean.getBean(AllConfig.class);
        }
        AllConfig config = FlinkApplication.ALL_CONFIG;
        config.setMode("single");
        config.setParse("ResolvHoneyLog");
        config.setIndex("sec_all");
        int total = 10;
        for(int i = 0;i<total;i++) {
            String msgx = "<12>Oct 09 10:07:43  {\"source\": \"scanner\", \"id\": \"adb5302965ab36e7dc4e7209b85442ad\", \"proto\": \"tcp\", \"start_time\": 1633745236, \"end_time\": 1633745236, \"agent\": \"10.8.9.195\", \"business_group\": \"\\u5206\\u7ec4\\u4e94\", \"src_ip\": \"10.0.89.146\", \"src_port\": \"29276\", \"dest_ip\": \"10.8.9.195\", \"dest_port\": \"10050\", \"dumb_captures\": []}";

            ConcurrentHashMap<String, Object> json = DataProcessFuncation.parse(msgx, "index");
            JsonUtils.printStr(json);
        }
    }
}
