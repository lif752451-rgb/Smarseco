package com.crc.log.flink.test.log;

import com.crc.log.flink.common.utils.JsonUtils;
import com.crc.log.flink.config.AllConfig;
import com.crc.log.flink.es.DataProcessFuncation;

import java.util.concurrent.ConcurrentHashMap;

public class QAXBljTest
{
    public static void main(String[] args) {
        String msgx = "<174>2021-09-07T11:35:51.070604+08:00 LegenSec ssp logType=YAB_CMD_OPS_LOG, time=2021-09-07 11:35:51, user=ZHAOBINGJIE6, sourceIP=10.140.76.251, resource=YKDB-PRD-VW-old, targetIP=10.140.10.137, command=-- 删除余额单 with fk as (select T_CUR_CONS.TABLE_NAME CUR_TABLE_NAME, --当前表名 T_CUR_COLUMNS.COLUMN_NAME CUR_COLUMN_NAME, --当前字段名 T_CONS.R_CONSTRAINT_NAME CUR_COLUMN_ID, --当前字段ID T_CONS.TABLE_NAME REF_TABLE_NAME, --引用表名称 T_CONS.CONSTRAINT_NAME REF_COLUMN_ID, --引用表外键字段名 T_REF_COLUMNS.COLUMN_NAME REF_COLUMN_NAME --引用表外键字段ID from USER_CONSTRAINTS T_CONS --所有的主键外键数据 LEFT JOIN USER_CONSTRAINTS T_CUR_CONS --当前主键表 ON T_CONS.R_CONSTRAINT_NAME = T_CUR_CONS.CONSTRAINT_NAME LEFT JOIN USER_CONS_COLUMNS T_CUR_COLUMNS --当前字段表 ON T_CONS.R_CONSTRAINT_NAME = T_CUR_COLUMNS.CONSTRAINT_NAME LEFT JOIN USER_CONS_COLUMNS T_REF_COLUMNS --引用字段表 ON T_CONS.CONSTRAINT_NAME = T_REF_COLUMNS.CONSTRAINT_NAME WHERE T_CONS.CONSTRAINT_TYPE = 'R' --当前主键类型为R：主键 AND T_CUR_CONS.TABLE_NAME = 'NMRMS_DEPTPOLI_LIMIT' --查询表名 AND T_CUR_CONS.CONSTRAINT_TYPE = 'P') --查询字段的主键类型P:外键，在其他表就是外键 select 'alter table ' fk.ref_table_name ' enable constraint ' fk.ref_column_id ';' from fk;, action=permit";
        AllConfig config = new AllConfig();
        DataProcessFuncation.CONIFG = config;
        config.setMode("single");
        config.setParse("ResolvQAXBljLog");
        config.setIndex("sec_all");

        ConcurrentHashMap<String, Object> json = DataProcessFuncation.parse(msgx,"index");
        JsonUtils.printStr(json);
    }
}
