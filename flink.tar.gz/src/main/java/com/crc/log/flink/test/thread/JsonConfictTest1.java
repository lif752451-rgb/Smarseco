package com.crc.log.flink.test.thread;

import com.alibaba.fastjson.JSONObject;

public class JsonConfictTest1 {
    private static final JSONObject request = new JSONObject();

    private static void showException() {
        for (int i = 0; i < 10000; i++) {
            request.put(String.valueOf(i), i);
        }
        new Thread(() -> {
            for (int i = 10000; i < 20000; i++) {
                request.put(String.valueOf(i), i);
                for (int j = 0; j < 10000; j++) {
                    request.put(String.valueOf(j), j);
                }
            }
        }).start();
        System.out.println(request);

    }

    public static void main(String[] args) {
        showException();
        System.out.println("done");
    }
}


