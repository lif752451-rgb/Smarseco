package com.crc.log.flink.parse;

import com.alibaba.fastjson.JSONObject;
import com.crc.log.flink.common.constants.LevelConstants;
import com.crc.log.flink.common.constants.LogConstants;
import com.crc.log.flink.common.utils.DataUtils;
import com.crc.log.flink.common.utils.JsonUtils;
import com.crc.log.flink.common.utils.MapUtils;
import org.apache.commons.lang3.StringUtils;

import java.util.concurrent.ConcurrentHashMap;

public class ResolvAccessLog {

    /**
     * 联软准入日志 日志泛化
     */
    public static ConcurrentHashMap<String, Object> parse(String message) {
        try {
            ConcurrentHashMap<String, Object> data = proc(message);
            if (DataUtils.isNotEmptyJson(data)) {
                return data;
            }
        } catch (Exception ignored) {

        }
        return null;
    }

    private static ConcurrentHashMap<String, Object> proc(String jsonStr) {
        ConcurrentHashMap<String, Object> data = JsonUtils.createBaseMap(jsonStr);
        if (jsonStr.contains("<14>[AuditDB.tbl_devaccess8021x]")) {
            JSONObject jsonObj = getSplitFields(jsonStr, "<14>[AuditDB.tbl_devaccess8021x]");
            if (jsonObj.isEmpty()) {
                return new ConcurrentHashMap<>();
            }
            parseAccessLogJson(data, jsonObj);
        } else if (jsonStr.contains("<14>[AuditDB.tbl_aclfirewallauditinfo]")) {
            JSONObject jsonObj = getSplitFields(jsonStr, "<14>[AuditDB.tbl_aclfirewallauditinfo]");
            if (jsonObj.isEmpty()) {
                return new ConcurrentHashMap<>();
            }
            parseAccessLogJson(data, jsonObj);
        } else if (jsonStr.contains("<14>[AuditDB.tbl_emailcontrolauditinfo]")) {
            JSONObject jsonObj = getSplitFields(jsonStr, "<14>[AuditDB.tbl_emailcontrolauditinfo]");
            if (jsonObj.isEmpty()) {
                return new ConcurrentHashMap<>();
            }
            parseAccessLogJson(data, jsonObj);
        }
        data.put(LogConstants.LOG_PRODUCT, "联软准入");
        data.put(LogConstants.LOG_LEVEL, LevelConstants.getLevel(MapUtils.getStr(data,LogConstants.LOG_LEVEL)));
        if (StringUtils.isBlank(MapUtils.getStr(data, LogConstants.SRC_IP))) {
            data.put(LogConstants.SRC_IP, "0.0.0.0");
        }
        if (StringUtils.isBlank(MapUtils.getStr(data, LogConstants.DEST_IP))) {
            data.put(LogConstants.DEST_IP, "0.0.0.0");
        }
        return data;
    }

    public static JSONObject getSplitFields(String jsonStr, String filter) {
        JSONObject jsonObj = new JSONObject();
        String lenData = jsonStr.replace(filter, "");
        String[] len_buff = DataUtils.getSplit(lenData, ",");
                //lenData.split(",");
        for (String s : len_buff) {
            String[] datakey = DataUtils.getSplit(s, "=");
            //len_buff[i].split("=");
            if (1 < datakey.length) {
                jsonObj.put(datakey[0], datakey[1]);
            }
        }
        return jsonObj;
    }

    public static void parseAccessLogJson(ConcurrentHashMap<String, Object> data, JSONObject jsonObj) {
        MapUtils.setStr(data, LogConstants.LOG_PRODUCT, "联软准入");
        MapUtils.setStr(data, LogConstants.LOG_NAME, "准入终端日志");
        MapUtils.setStr(data, LogConstants.OP_NAME, jsonObj, "strusername");
        MapUtils.setStr(data, LogConstants.OP_CN_NAME, jsonObj, "struserdes");
        MapUtils.setStr(data, LogConstants.LOG_START_TIME, jsonObj, "dtinserttime");
        MapUtils.setStr(data, LogConstants.OP_OFFICE, jsonObj, "strrolename");
        
        if (MapUtils.isBlank(data, LogConstants.SRC_IP)) {
            MapUtils.setStr(data, LogConstants.SRC_IP, jsonObj, "strdevip");
        }
        if (MapUtils.isBlank(data, LogConstants.SRC_IP)) {
            MapUtils.setStr(data, LogConstants.SRC_IP, jsonObj, "strradiussrvip");
        }
        MapUtils.setStr(data, LogConstants.SRC_MAC, jsonObj, "strmac");
        MapUtils.setStr(data, LogConstants.LOG_LEVEL, LevelConstants.INFO);
    }
}
