package com.crc.log.flink.test.thread;

import java.util.concurrent.ConcurrentHashMap;

public class JsonConfictTest {
    private static final ConcurrentHashMap<Object,Object> request = new ConcurrentHashMap<>();

    private static void showException() {
        for (int i = 0; i < 10000; i++) {
            request.put(String.valueOf(i), i);
        }
        new Thread(() -> {
            for (int i = 10000; i < 20000; i++) {
                request.put(String.valueOf(i), i);
                for (int j = 0; j < 10000; j++) {
                    request.put(String.valueOf(j), j);
                }
            }
        }).start();
        System.out.println(request);

    }

    public static void main(String[] args) {
        showException();
        System.out.println("done");
    }
}


