package com.crc.log.flink.parse;

import com.crc.log.flink.common.constants.LevelConstants;
import com.crc.log.flink.common.constants.LogConstants;
import com.crc.log.flink.common.utils.DataUtils;
import com.crc.log.flink.common.utils.JsonUtils;
import com.crc.log.flink.common.utils.MapUtils;
import org.apache.commons.lang3.StringUtils;

import java.util.concurrent.ConcurrentHashMap;


/**
 * 绿盟防火墙
 */
public class ResolvLMFirewallLog {


    public static ConcurrentHashMap<String, Object> parse(String message) {
        try {
            ConcurrentHashMap<String, Object> data = proc(message);
            if (DataUtils.isNotEmptyJson(data)) {
                return data;
            }
        } catch (Exception ignored) {

        }
        return null;
    }

    private static ConcurrentHashMap<String, Object> proc(String jsonStr) {
        ConcurrentHashMap<String, Object> rtnObjc = JsonUtils.createBaseMap(jsonStr);
        logAnalysis(jsonStr, rtnObjc);
        return rtnObjc;
    }

    private static void logAnalysis(String jsonStr, ConcurrentHashMap<String, Object> rtnObjc) {
        jsonStr = jsonStr.replace("<5>", "").replace("<1>","");
        String[] split = DataUtils.getSplit(jsonStr, ";");
                //jsonStr.split(";");
        for (String s : split) {
            int index = DataUtils.getIndex(s, ":");
            //split[i].indexOf(":");
            String key = DataUtils.getSubString(s, 0, index);
            //split[i].substring(0, index);
            String value = DataUtils.getSubString(s, index + 1);
            //split[i].substring(index+1);
            switch (key) {
                case "time":
                    rtnObjc.put(LogConstants.LOG_START_TIME, value);
                    break;
                case "danger_degree":
                    rtnObjc.put(LogConstants.LOG_DAMAGE, value);
                    break;
                case "breaking_sighn":
                    rtnObjc.put(LogConstants.LOG_SOLUTION, value);
                    break;
                case "rule_id":
                    rtnObjc.put(LogConstants.EVENT_ID, value);
                    break;
                case "msg":
                    rtnObjc.put(LogConstants.LOG_KEYWORD, value);
                    break;
                case "src_addr":
                    rtnObjc.put(LogConstants.SRC_IP, value);
                    break;
                case "src_port":
                    rtnObjc.put(LogConstants.SRC_PORT, value);
                    break;
                case "dst_addr":
                    rtnObjc.put(LogConstants.DEST_IP, value);
                    break;
                case "dst_port":
                    rtnObjc.put(LogConstants.DEST_PORT, value);
                    break;
                case "proto":
                    rtnObjc.put(LogConstants.LOG_PROTOCAL, value);
                    break;
                case "user":
                    rtnObjc.put(LogConstants.USER_NAME, value);
                    break;


                // TODO  注意模块
                case "module":
                    rtnObjc.put(LogConstants.MODULE, value);
                    break;
                case "type":
                    rtnObjc.put(LogConstants.ACTION_TYPE, value);
                    break;
                case "level":
                    rtnObjc.put(LogConstants.LOG_LEVEL, value);
                    break;
                case "clientIp":
                    rtnObjc.put(LogConstants.LOG_DEV_IP, value);
                    break;
                case "LocationInfo":
                    rtnObjc.put(LogConstants.SRC_DEV_INFO, value);
                    break;
                case "description":
                    rtnObjc.put(LogConstants.LOG_DESCRIPTION, value);
                    break;

                // TODO
                case "src_intf":
                    rtnObjc.put(LogConstants.SRC_INTF, value);
                    break;
                case "dst_intf":
                    rtnObjc.put(LogConstants.DST_INTF, value);
                    break;
                case "action":
                    rtnObjc.put(LogConstants.ACTION_TYPE, value);
                    break;

                case "src_addr_nat":
                    rtnObjc.put(LogConstants.NAT_SRC_IP, value);
                    break;
                case "src_port_nat":
                    rtnObjc.put(LogConstants.NAT_SRC_PORT, value);
                    break;
                case "dst_addr_nat":
                    rtnObjc.put(LogConstants.NAT_DEST_IP, value);
                    break;
                case "dst_port_nat":
                    rtnObjc.put(LogConstants.NAT_DEST_PORT, value);
                    break;
                case "info":
                    rtnObjc.put(LogConstants.MSG_CONTENT, value);
                    break;
            }
        }
        rtnObjc.put(LogConstants.LOG_PRODUCT, "绿盟防火墙");
        rtnObjc.put(LogConstants.LOG_LEVEL, LevelConstants.getLevel(MapUtils.getStr(rtnObjc,LogConstants.LOG_LEVEL)));
        if (StringUtils.isBlank(MapUtils.getStr(rtnObjc, LogConstants.SRC_IP))) {
            rtnObjc.put(LogConstants.SRC_IP, "0.0.0.0");
        }
        if (StringUtils.isBlank(MapUtils.getStr(rtnObjc, LogConstants.DEST_IP))) {
            rtnObjc.put(LogConstants.DEST_IP, "0.0.0.0");
        }
        setAlertName(rtnObjc);
    }

    private static void setAlertName(ConcurrentHashMap<String, Object> rtnObjc) {
        String msgFormat = "";
        String alertName = "";
        String srcIp = MapUtils.getStr(rtnObjc, LogConstants.SRC_IP);
        String level = MapUtils.getStr(rtnObjc, LogConstants.LOG_LEVEL);
        String action = MapUtils.getStr(rtnObjc, LogConstants.ACTION_TYPE);
        String event = MapUtils.getStr(rtnObjc, LogConstants.LOG_DESCRIPTION);
        String log = MapUtils.getStr(rtnObjc, LogConstants.LOG_ORI_MSG);
        if (StringUtils.isBlank(srcIp)) {
            String product = MapUtils.getStr(rtnObjc, LogConstants.LOG_PRODUCT);
            msgFormat = "产品:%s,攻击类型为:%s,风险级别:%s,事件描述:%s,日志详情为:%s";
            alertName = String.format(msgFormat, product, action, level, event, log);
        } else {
            String destIp = MapUtils.getStr(rtnObjc, LogConstants.DEST_IP);
            if (StringUtils.isBlank(event)) {
                msgFormat = "源IP为:%s,目的IP为:%s,攻击类型为:%s,风险级别:%s,,日志详情为:%s";
                alertName = String.format(msgFormat, srcIp,destIp, action, level, log);
            } else {
                if (srcIp.equals("0.0.0.0") || destIp.equals("0.0.0.0")) {
                    msgFormat = "攻击类型为:%s,风险级别:%s,事件描述:%s,日志详情为:%s";
                    alertName = String.format(msgFormat, action, level, event, log);
                } else {
                    msgFormat = "源IP为:%s,目的IP为:%s,攻击类型为:%s,风险级别:%s,事件描述:%s,日志详情为:%s";
                    alertName = String.format(msgFormat, srcIp,destIp, action, level, event, log);
                }

            }
        }
        rtnObjc.put(LogConstants.ALERT_NAME, alertName);
    }
}
