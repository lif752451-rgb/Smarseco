package com.crc.log.flink.test.log;

import com.crc.log.flink.common.utils.JsonUtils;
import com.crc.log.flink.config.AllConfig;
import com.crc.log.flink.es.DataProcessFuncation;

import java.util.concurrent.ConcurrentHashMap;

public class ResolvLinkLoadBalancingLogTest {

    public static void main(String[] args) {
        AllConfig config = new AllConfig();
        DataProcessFuncation.CONIFG = config;
        config.setMode("single");
        config.setParse("ResolvLinkLoadBalancingLog");
        config.setIndex("sec_all");


        String str = "<156>Nov 25 00:01:38 src@HRZD-HBDQ-AD-1600-FZJH : DDOS: LAN: UDP FLOOD attack may be stoped(local network(bond0), 1 packet per min): 10.75.7.10 etc --> 202.106.196.115 etc";
        ConcurrentHashMap<String, Object> proc = DataProcessFuncation.parse(str,"index");
        JsonUtils.printStr(proc);

        str = "<157>Nov 24 05:02:04 src@HRZD-HBDQ-AD-1600-FZJH : root,127.0.0.1,POST,SYS,SUCCESS,新建配置备份与恢复[sangfor_ad_7.0.8R3_HRZD-HBDQ--_20211124050202]";
        proc = DataProcessFuncation.parse(str,"index");
        JsonUtils.printStr(proc);

        str = "<158>Nov 24 18:26:00 src@HRZD-HBDQ-AD-1600-FZJH : ISP_AGENT_LOG: 当前isp包版本号已是最新";
        proc = DataProcessFuncation.parse(str,"index");
        JsonUtils.printStr(proc);

        str = "<158>Nov 24 18:43:48 src@HRZD-HBDQ-AD-1600-FZJH : APPD: link[电信100M正式线路] upload is busy";
        proc = DataProcessFuncation.parse(str,"index");
        JsonUtils.printStr(proc);

        str = "LAN: UDP FLOOD attack may be stoped(local network(bond0), 54 packet per min): 10.75.125.191 etc --> 202.106.196.115 etc";
        proc = DataProcessFuncation.parse(str,"index");
        JsonUtils.printStr(proc);
    }
}
