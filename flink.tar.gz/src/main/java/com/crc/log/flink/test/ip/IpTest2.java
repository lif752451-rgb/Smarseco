package com.crc.log.flink.test.ip;

import com.crc.log.flink.common.utils.DataUtils;
import com.crc.log.flink.common.utils.IPUtil;

import java.util.List;

public class IpTest2 {
    public static void main(String[] args) {
        List<String> ipList = FakeIp.generateFakeIpGood(100000);
        double chance = FakeIp.correctCount(ipList);
        System.out.println("start testing, correct ip count is : " + chance);
        long t1 = System.nanoTime();
        ipList.forEach(IPUtil::isIpv4);
        long t2 = System.nanoTime();
        ipList.forEach(IPUtil::isIpv6);
        long t3 = System.nanoTime();
        System.out.println("isIpv4 cost time : " + DataUtils.doublePrec2((t2-t1) * 1.0/1000000L));
        System.out.println("isIpv6 cost time : " + DataUtils.doublePrec2((t3-t2) * 1.0/1000000L));
    }
}
