package com.crc.log.flink.method;

import com.crc.log.flink.common.constants.LogConstants;
import com.crc.log.flink.common.entity.TbAsset;
import com.crc.log.flink.common.entity.TbSegementInfo;
import com.crc.log.flink.common.utils.IPUtil;
import com.crc.log.flink.common.utils.MapUtils;
import com.crc.log.flink.load.AssetDataLoad;
import com.crc.log.flink.load.NewUserSegmentLoad;
import com.crc.log.flink.net.IPBean;
import com.crc.log.flink.net.SegmentTool;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;

import java.util.concurrent.ConcurrentHashMap;

@Slf4j
public class CustomMethod {
    public static String SRC_ASSET_OFFICE_KEY = "src_asset_office";
    public static String SRC_ASSET_INST_KEY = "src_instance";
    public static String SRC_ASSET_BRANCH_KEY = "src_branch";
    public static String SRC_ASSET_SUB_BRANCH_KEY = "src_sub_branch";


    public static String DEST_ASSET_OFFICE_KEY = "dest_asset_office";
    public static String DEST_ASSET_INST_KEY = "dest_instance";
    public static String DEST_ASSET_BRANCH_KEY = "dest_branch";
    public static String DEST_ASSET_SUB_BRANCH_KEY = "dest_sub_branch";


    public static String DEV_ASSET_OFFICE_KEY = "dev_asset_office";
    public static String DEV_ASSET_INST_KEY = "dev_instance";
    public static String DEV_ASSET_BRANCH_KEY = "dev_branch";
    public static String DEV_ASSET_SUB_BRANCH_KEY = "dev_sub_branch";


    /**
     * IP归属网段划分查询/实例/组织信息
     *
     * @param jsonObject 日志
     */
    public static void setAssetInfo(ConcurrentHashMap<String,Object> jsonObject) {
        try {
            /*
             * 加载资产数据
             */
            String ip = MapUtils.getStr(jsonObject, LogConstants.LOG_DEV_IP);
            if (StringUtils.isNotBlank(ip)) {
                TbAsset asset = AssetDataLoad.assetMap.get(ip);
                if (asset != null) {
                    if (!StringUtils.isBlank(asset.getCompanyName()))
                        jsonObject.put(DEV_ASSET_OFFICE_KEY, asset.getCompanyName());
                    if (!StringUtils.isBlank(asset.getInstance()))
                        jsonObject.put(DEV_ASSET_INST_KEY, asset.getInstance());
                    if (StringUtils.isNotBlank(asset.getArea())) {
                        jsonObject.put(DEV_ASSET_BRANCH_KEY, asset.getArea());
                    }
                    if (StringUtils.isNotBlank(asset.getSubArea())) {
                        jsonObject.put(DEV_ASSET_SUB_BRANCH_KEY, asset.getSubArea());
                    }
                    if (StringUtils.isNotBlank(asset.getAffiliationDeptName())) {
                        jsonObject.put(DEV_ASSET_OFFICE_KEY, asset.getAffiliationDeptName());
                    }
                    if (StringUtils.isNotBlank(asset.getAreaName())) {
                        jsonObject.put(DEV_ASSET_BRANCH_KEY, asset.getAreaName());
                    }
                }
            }

            ip = MapUtils.getStr(jsonObject, LogConstants.SRC_IP);
            if (StringUtils.isNotBlank(ip)) {
                TbAsset asset = AssetDataLoad.assetMap.get(ip);
                boolean haveSeg = false;
                boolean haveAsset = false;
                if (asset != null) {
                    if (!StringUtils.isBlank(asset.getCompanyName())) {
                        jsonObject.put(SRC_ASSET_OFFICE_KEY, asset.getCompanyName());
                        haveAsset = true;
                    }
                    if (!StringUtils.isBlank(asset.getInstance()))
                        jsonObject.put(SRC_ASSET_INST_KEY, asset.getInstance());
                    if (StringUtils.isNotBlank(asset.getArea())) {
                        jsonObject.put(SRC_ASSET_BRANCH_KEY, asset.getArea());
                        haveSeg = true;
                    }
                    if (StringUtils.isNotBlank(asset.getSubArea())) {
                        jsonObject.put(SRC_ASSET_SUB_BRANCH_KEY, asset.getSubArea());
                    }
                    if (StringUtils.isNotBlank(asset.getAffiliationDeptName())) {
                        jsonObject.put(SRC_ASSET_OFFICE_KEY, asset.getAffiliationDeptName());
                        haveAsset = true;
                    }
                    if (StringUtils.isNotBlank(asset.getAreaName())) {
                        jsonObject.put(SRC_ASSET_BRANCH_KEY, asset.getAreaName());
                        haveSeg = true;
                    }
                }

                IPBean ipBean = null;
                if (!haveSeg) {
                    ipBean = SegmentTool.getInstance().getSegmentByIp(ip);
                    if (ipBean != null) {
                        TbSegementInfo rdata = ipBean.getSegementInfo();
                        String firstUnitName = rdata.getFirstUnitName();
                        String area = rdata.getAreaName();
                        String subArea = rdata.getSubAreaName();
                        if (StringUtils.isNotBlank(firstUnitName) && !haveAsset) {
                            jsonObject.put(SRC_ASSET_OFFICE_KEY, firstUnitName);
                        }
                        if (StringUtils.isNotBlank(rdata.getAffiliationDeptName()) && !haveAsset) {
                            jsonObject.put(SRC_ASSET_OFFICE_KEY, rdata.getAffiliationDeptName());
                        }
                        if (StringUtils.isNotBlank(area)) {
                            jsonObject.put(SRC_ASSET_BRANCH_KEY, area);
                        }
                        if (StringUtils.isNotBlank(subArea)) {
                            jsonObject.put(SRC_ASSET_SUB_BRANCH_KEY, subArea);
                        }
                    }
                }
                isUserDefineIp(jsonObject, "src", ip);
                setIpType(jsonObject, ip, "src", ipBean, haveAsset);
            }

            ip = MapUtils.getStr(jsonObject, LogConstants.DEST_IP);
            if (!StringUtils.isEmpty(ip)) {
                TbAsset asset = AssetDataLoad.assetMap.get(ip);
                boolean haveSeg = false;
                boolean haveAsset = false;
                if (asset != null) {
                    if (!StringUtils.isBlank(asset.getCompanyName())) {
                        jsonObject.put(DEST_ASSET_OFFICE_KEY, asset.getCompanyName());
                        haveAsset = true;
                    }
                    if (!StringUtils.isBlank(asset.getInstance()))
                        jsonObject.put(DEST_ASSET_INST_KEY, asset.getInstance());
                    if (StringUtils.isNotBlank(asset.getArea())) {
                        jsonObject.put(DEST_ASSET_BRANCH_KEY, asset.getArea());
                        haveSeg = true;
                    }
                    if (StringUtils.isNotBlank(asset.getSubArea())) {
                        jsonObject.put(DEST_ASSET_SUB_BRANCH_KEY, asset.getSubArea());
                    }
                    if (StringUtils.isNotBlank(asset.getAffiliationDeptName())) {
                        jsonObject.put(DEST_ASSET_OFFICE_KEY, asset.getAffiliationDeptName());
                        haveAsset = true;
                    }
                    if (StringUtils.isNotBlank(asset.getAreaName())) {
                        jsonObject.put(DEST_ASSET_BRANCH_KEY, asset.getAreaName());
                        haveSeg = true;
                    }
                }

                IPBean ipBean = null;
                if (!haveSeg) {
                    ipBean = SegmentTool.getInstance().getSegmentByIp(ip);
                    if (ipBean != null) {
                        TbSegementInfo rdata = ipBean.getSegementInfo();
                        String firstUnitName = rdata.getFirstUnitName();
                        String area = rdata.getAreaName();
                        String subArea = rdata.getSubAreaName();
                        if (StringUtils.isNotBlank(firstUnitName) && !haveAsset) {
                            jsonObject.put(DEST_ASSET_OFFICE_KEY, firstUnitName);
                        }
                        if (StringUtils.isNotBlank(rdata.getAffiliationDeptName()) && !haveAsset) {
                            jsonObject.put(DEST_ASSET_OFFICE_KEY, rdata.getAffiliationDeptName());
                        }
                        if (StringUtils.isNotBlank(area)) {
                            jsonObject.put(DEST_ASSET_BRANCH_KEY, area);
                        }
                        if (StringUtils.isNotBlank(subArea)) {
                            jsonObject.put(DEST_ASSET_SUB_BRANCH_KEY, subArea);
                        }
                    }
                }
                isUserDefineIp(jsonObject, "dest", ip);
                setIpType(jsonObject, ip, "dest", ipBean, haveAsset);
            }


        } catch (Exception e) {
            log.error(e.getMessage(), e);
        }
    }

    /**
     * IP查询
     */
    private static void setIpType(ConcurrentHashMap<String,Object> datajson, String ip, String KEY, IPBean ipBean, boolean haveAsset) {
        if (ip != null && ip.length() > 6 && IPUtil.isIp(ip)) {
            try {
                if (IPUtil.isInnerIP(ip)) {
                    datajson.put(KEY + "_ip_type", "内网");
                    datajson.put(LogConstants.IP_SCORE, 2);
                } else if ("127.0.0.1".equals(ip) || "localhost".contains(ip) || "0.0.0.0".equals(ip)) {
                    datajson.put(KEY + "_ip_type", "本地");
                    datajson.put(LogConstants.IP_SCORE, 2);
                } else {
                    if (!"0.0.0.0".equalsIgnoreCase(ip)) {
                        // 获取执⾏结果
                        try {
                            if (haveAsset || (ipBean != null && ipBean.getSegementInfo() != null)) {
                                /*
                                 *公网私用
                                 */
                                datajson.put(KEY + "_ip_type", "内网");
                                datajson.put(LogConstants.IP_SCORE, 2);
                                datajson.put("crc_ip_status", "公网私用");
                            } else {
                                datajson.put(KEY + "_ip_type", "外网");
                                datajson.put(LogConstants.IP_SCORE, 1);
                            }
                        } catch (Exception ignored) {

                        }
                    }
                }
            } catch (Exception e) {
                log.error(e.getMessage(), e);
            }
        }
    }

    /**
     * 根据用户自定义网段定义配置，判断IP类型
     *
     * @param data 数据
     * @param type 类型
     * @param ip   目标IP
     */
    private static void isUserDefineIp(ConcurrentHashMap<String,Object> data, String type, String ip) {
        try {
            if (!IPUtil.isIpv4(ip)) {
                return;
            }
            if (NewUserSegmentLoad.userSegMap.size() < 1) {
                return;
            }
            SegmentTool.getInstance().setUserDefineIpSegment(data, type, ip);
        } catch (Exception ignored) {

        }
    }
}
