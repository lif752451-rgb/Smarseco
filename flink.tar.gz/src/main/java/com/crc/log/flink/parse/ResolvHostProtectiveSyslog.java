package com.crc.log.flink.parse;


import com.alibaba.fastjson.JSONException;
import com.alibaba.fastjson.JSONObject;
import com.crc.log.flink.common.constants.LevelConstants;
import com.crc.log.flink.common.constants.LogConstants;
import com.crc.log.flink.common.utils.DataUtils;
import com.crc.log.flink.common.utils.DateUtils;
import com.crc.log.flink.common.utils.JsonUtils;
import com.crc.log.flink.common.utils.MapUtils;
import org.apache.commons.lang3.StringUtils;

import java.util.concurrent.ConcurrentHashMap;

/**
 * @author jixiangqi
 * @date 2022/4/16
 * 工业主机防护syslog
 */
public class ResolvHostProtectiveSyslog {
    public static ConcurrentHashMap<String,Object> parse(String message) {
        try {
            ConcurrentHashMap<String,Object> data = proc(message);
            if (DataUtils.isNotEmptyJson(data)) {
                return data;
            }
        } catch (Exception ignored) {

        }
        return null;
    }

    private static ConcurrentHashMap<String,Object> proc(String jsonStr) {
        ConcurrentHashMap<String,Object> rtnObjc = JsonUtils.createBaseMap(jsonStr);
        int index = DataUtils.getIndex(jsonStr, "{");
        jsonStr = DataUtils.getSubString(jsonStr, index);
        JSONObject jsonObject = JSONObject.parseObject(jsonStr);
        jsonObject.forEach((k,v) -> {
            switchKeyValue(rtnObjc, k, v);
        });
        rtnObjc.put(LogConstants.LOG_LEVEL, LevelConstants.getLevel(MapUtils.getStr(rtnObjc,LogConstants.LOG_LEVEL)));
        if (org.apache.commons.lang3.StringUtils.isBlank(MapUtils.getStr(rtnObjc, LogConstants.SRC_IP))) {
            rtnObjc.put(LogConstants.SRC_IP, "0.0.0.0");
        }
        if (StringUtils.isBlank(MapUtils.getStr(rtnObjc, LogConstants.DEST_IP))) {
            rtnObjc.put(LogConstants  .DEST_IP, "0.0.0.0");
        }
        rtnObjc.put(LogConstants.LOG_PRODUCT, "工业主机防护");
        setAlertName(rtnObjc);
        return rtnObjc;
    }


    private static void switchKeyValue(ConcurrentHashMap<String,Object> rtnObjc, String key, Object value) {
        switch (key) {
            case "log_name":
                String type = "";
                if (value.equals("whitelist_alarm")) {
                    type = "白名单日志";
                } else if (value.equals("client_user_op")) {
                    type = "终端操作日志";
                } else if (value.equals("file_usb")) {
                    type = "文件审计日志";
                } else if (value.equals("client_udisk_op")) {
                    type = "外设管控日志";
                } else if (value.equals("leak_defense")) {
                    type = "漏洞防御日志";
                } else if (value.equals("net_defense")) {
                    type = "网络防护日志";
                } else if (value.equals("security_reinforcement")) {
                    type = "主机加固日志";
                } else if (value.equals("client_virus_find")) {
                    type = "病毒发现日志";
                }
                rtnObjc.put(LogConstants.LOG_TYPE, type);
                rtnObjc.put(LogConstants.LOG_NAME, value);
                break;
            case "ip":
                rtnObjc.put(LogConstants.SRC_IP, value);
                break;
            case "mac":
                rtnObjc.put(LogConstants.SRC_MAC, value);
                break;
            case "content":
                if (value != null && !"".equals(value)) {
                    //不为空有可能是json也有可能是字符串，需要判断
                    try {
                        JSONObject jsonObject = JSONObject.parseObject(String.valueOf(value));
                        jsonObject.forEach((k,v) -> {
                            switchKeyValue(rtnObjc, k, v);
                        });
                    } catch (JSONException e) {
                        rtnObjc.put(LogConstants.ACTION_TYPE, value);
                    }
                }
                break;
            case "client_name":
                rtnObjc.put(LogConstants.HOST_NAME, value);
                break;
            case "process_path":
                rtnObjc.put(LogConstants.FILE_PATH, value);
                break;
            case "process_name":
                rtnObjc.put(LogConstants.LOG_FILENAME, value);
                break;
            case "begin_time":
                rtnObjc.put(LogConstants.LOG_START_TIME, DateUtils.getISO8601Timestamp(String.valueOf(value), "yyyy-MM-dd HH:mm:ss"));
                break;
            case "count":
                rtnObjc.put(LogConstants.LOG_COUNT, value);
                break;
            case "login_user":
                rtnObjc.put(LogConstants.USER_NAME, value);
                break;
            case "op_time":
                rtnObjc.put(LogConstants.OP_NAME, value);
                break;
            case "result":
                rtnObjc.put(LogConstants.ACTION_RESULT, value);
                break;
            case "account":
                rtnObjc.put(LogConstants.USER_NAME, value);
                break;
            case "file_path":
                rtnObjc.put(LogConstants.FILE_PATH, value);
                break;
            case "name":
                rtnObjc.put(LogConstants.VIRUS_NAME, value);
                break;
            case "type":
                rtnObjc.put(LogConstants.LOG_DESCRIPTION, value);
                break;
            case "path":
                rtnObjc.put(LogConstants.FILE_PATH, value);
                break;
            case "computer_name":
                rtnObjc.put(LogConstants.HOST_NAME, value);
                break;
            case "info":
                rtnObjc.put(LogConstants.LOG_DESCRIPTION, value);
                break;
            case "group_name":
                rtnObjc.put(LogConstants.LOG_GROUP, value);
                break;
            case "operate":
                rtnObjc.put(LogConstants.ACTION_TYPE, value);
                break;
            case "audit_file_type":
                rtnObjc.put(LogConstants.ACTION_RESULT, value);
                break;
        }
    }


    private static void setAlertName(ConcurrentHashMap<String,Object> rtnObjc) {
        String eventType = MapUtils.getStr(rtnObjc, LogConstants.LOG_TYPE);
        String srcIp = MapUtils.getStr(rtnObjc, LogConstants.SRC_IP);
        String log = MapUtils.getStr(rtnObjc, LogConstants.LOG_ORI_MSG);
        String message = "";
        String alertName = "";
        switch (eventType) {
            case "病毒发现日志": {
                String virusName = MapUtils.getStr(rtnObjc, LogConstants.VIRUS_NAME);
                String virusType = MapUtils.getStr(rtnObjc, LogConstants.VIRUS_TYPE);
                String filePath = MapUtils.getStr(rtnObjc, LogConstants.FILE_PATH);
                message = "在IP为:%s的设备上发现了一个病毒类型为:%s,病毒名称为:%s,病毒路径为:%s的病毒,日志详情为:%s";
                alertName = String.format(message, srcIp, virusType, virusName, filePath, log);
                break;
            }
            case "主机加固日志": {
                String filePath = MapUtils.getStr(rtnObjc, LogConstants.FILE_PATH);
                String actionResult = MapUtils.getStr(rtnObjc, LogConstants.ACTION_RESULT);
                String description = MapUtils.getStr(rtnObjc, LogConstants.LOG_DESCRIPTION);
                message = "在IP为:%s的设备上发现了一个%s类型的日志,文件路径为:%s,操作结果为:%s,具体日志类型为:%s,日志详情为:%s";
                alertName = String.format(message, srcIp, eventType, filePath, actionResult, description, log);
                break;
            }
            case "网络防护日志":
            case "漏洞防御日志": {
                String description = MapUtils.getStr(rtnObjc, LogConstants.LOG_DESCRIPTION);
                message = "在IP为:%s的设备上发现了一个%s类型的日志,日志描述为:%s,日志详情为:%s";
                alertName = String.format(message, srcIp, eventType, description, log);
                break;
            }
            case "外设管控日志": {
                String actionType = MapUtils.getStr(rtnObjc, LogConstants.ACTION_TYPE);
                message = "在IP为:%s的设备上发现了一个%s类型的日志,操作结果为:%s,日志详情为:%s";
                alertName = String.format(message, srcIp, eventType, actionType, log);
                break;
            }
            case "文件审计日志": {
                String actionType = MapUtils.getStr(rtnObjc, LogConstants.ACTION_TYPE);
                String actionResult = MapUtils.getStr(rtnObjc, LogConstants.ACTION_RESULT);
                String filePath = MapUtils.getStr(rtnObjc, LogConstants.FILE_PATH);
                String fileName = MapUtils.getStr(rtnObjc, LogConstants.LOG_FILENAME);
                message = "在IP为:%s的设备上发现了一个%s类型的日志,操作类型为:%s,操作结果为:%s,文件路径为:%s,文件名称为:%s,日志详情为:%s";
                alertName = String.format(message, srcIp, eventType, actionType, actionResult, filePath, fileName, log);
                break;
            }
            case "终端操作日志": {
                String actionType = MapUtils.getStr(rtnObjc, LogConstants.ACTION_TYPE);
                String actionResult = MapUtils.getStr(rtnObjc, LogConstants.ACTION_RESULT);
                String userName = MapUtils.getStr(rtnObjc, LogConstants.USER_NAME);
                message = "用户为:%s在IP为:%s的设备上进行了:%s,操作结果为:%s,日志类型为:%s,日志详情为:%s";
                alertName = String.format(message, userName, srcIp, actionType, actionResult, eventType, log);
                break;
            }
            case "白名单日志": {
                String filePath = MapUtils.getStr(rtnObjc, LogConstants.FILE_PATH);
                String count = MapUtils.getStr(rtnObjc, LogConstants.LOG_COUNT);
                message = "在IP为:%s的设备上发现了一个%s类型的日志,出现次数为:%s,文件路径为:%s,日志详情为:%s";
                alertName = String.format(message, srcIp, eventType, count, filePath, log);
                break;
            }
        }
        rtnObjc.put(LogConstants.ALERT_NAME, alertName);
    }
}
