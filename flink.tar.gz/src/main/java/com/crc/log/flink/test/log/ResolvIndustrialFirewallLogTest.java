package com.crc.log.flink.test.log;

import com.crc.log.flink.common.utils.JsonUtils;
import com.crc.log.flink.config.AllConfig;
import com.crc.log.flink.es.DataProcessFuncation;

import java.util.concurrent.ConcurrentHashMap;

public class ResolvIndustrialFirewallLogTest {

    public static void main(String[] args) {
        AllConfig config = new AllConfig();
        DataProcessFuncation.CONIFG = config;
        config.setMode("single");
        config.setParse("ResolvIndustrialFirewallLog");
        config.setIndex("sec_all");

        String str = "devid=\"3\" dname=\"虚拟化服务器防火墙\" serial=\"8374dd8f0d3f66e2811850d4c82aafb44ea2e4eb\" module=\"flow\" severity=\"info\" vsys=\"root-vsys\" type=\"traffic-end\" session_id=\"2143103\" time=\"1650223350\" duration=\"1\" addr_src=\"10.143.11.71\" addr_dst=\"10.143.11.72\" nataddr_src=\"::\" nataddr_dst=\"::\" port_src=\"46446\" port_dst=\"27017\" natport_src=\"0\" natport_dst=\"0\" action=\"permit\" appname=\"Unidentified\" rule=\"F-01-Permit-TO-虚拟化服务器\" proto=\"TCP\" session_time=\"52297\" sess_nth=\"0\" sess_dev_id=\"0\" zone_src=\"Server\" zone_dst=\"Server\" locale_src=\"内网\" locale_dst=\"内网\" user_src=\"\" user_dst=\"\" app_category=\"CATEGORY-NONE\" app_risk=\"5\" asset_os_src=\"\" asset_os_dst=\"\" asset_name_src=\"\" asset_name_dst=\"\" asset_type_src=\"\" asset_type_dst=\"\" focus_type=\"NO\" profile=\"\" non_standard_port=\"NO\" interface_src=\"ge4\" interface_dst=\"ge5\" bytes_sent=\"60\" bytes_received=\"40\" pkts_sent=\"1\" pkts_received=\"1\" total_sess=\"0\" from_tunnel=\"\" to_tunnel=\"\" honeypot_rule_name=\"\" honeypot_drainage_type=\"\"";
        ConcurrentHashMap<String, Object> proc = DataProcessFuncation.parse(str, "index");
        JsonUtils.printStr(proc);

        str = "devid=\"3\" dname=\"虚拟化服务器防火墙\" serial=\"8374dd8f0d3f66e2811850d4c82aafb44ea2e4eb\" module=\"upgrade\" severity=\"err\" vsys=\"root-vsys\" type=\"system\" time=\"1650227350\" msg=\"[upgrade from auto], Auto upgrade download error:[Upgrade license has expired], name:[ioc signature]\" msg_cn=\"[自动升级]，库升级失败：[库升级许可证不存在或已过期]，名称：[威胁情报库]\"";
        proc = DataProcessFuncation.parse(str, "index");
        JsonUtils.printStr(proc);

    }

}
