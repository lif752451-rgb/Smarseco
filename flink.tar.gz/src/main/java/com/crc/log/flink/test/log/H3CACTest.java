package com.crc.log.flink.test.log;

import com.crc.log.flink.common.utils.JsonUtils;
import com.crc.log.flink.config.AllConfig;
import com.crc.log.flink.es.DataProcessFuncation;

import java.util.concurrent.ConcurrentHashMap;

public class H3CACTest {
    public static void main(String[] args) {
        String msg = "{\"dev_ip\":\"10.54.32.123\",\"message\":\"<6>Mar 30 11:21:50 RL092HP03ACGHC123;110104700120091633566634;ipv4;3; policy_detail: src_ip=10.54.40.151;dst_ip=47.107.17.51;protocol=TCP;src_port=53183;dst_port=443;in_interface=ge22;out_interface=ge0;policyid=3;action=deny;Content=\\\"POLICY*: The packet was blocked because the firewall policy isdeny\\\"\\r\\n\",\"type\":\"udp\",\"timestamp\":\"2021-03-30 11:22:28\"}";

        //String msg = "{\"dev_ip\":\"10.8.81.103\",\"message\":\"<132>2021-03-30T07:18:57+08:00 jtsecvdca01 YJHP_Server[23877]: level=warning msg=\\\"EventType:honeypotAccess, attackerIp:124.156.55.202, dstPort:80, protocol:http, honeypotName:华润集团VPN(反制)蜜罐, agentIp:10.10.128.10\\\" type=event\\n\",\"type\":\"udp\",\"timestamp\":\"2021-03-30 07:18:58\"}";
        AllConfig config = new AllConfig();
        DataProcessFuncation.CONIFG = config;
        config.setMode("single");
        config.setParse("ReslovH3CACLog");
        config.setIndex("user_all");
        ConcurrentHashMap<String, Object> x = DataProcessFuncation.parse(msg, "user_all");
        JsonUtils.printStr(x);

    }
}
