package com.crc.log.flink.test.ip;

import com.crc.log.flink.common.utils.IPUtil;

import java.security.SecureRandom;
import java.util.ArrayList;
import java.util.List;

public class FakeIp {
    /**
     * 有对和错IP
     * @param capacity 数量
     * @return ip列表
     */
    public static List<String> generateFakeIp(int capacity) {
        List<String> ipList = new ArrayList<String>(capacity);
        for (int i = 0; i < capacity; i++) {
            int parts = boundRandom(1, 3);
            if (chanceOf50()) { //each ip has 50% chance to be 4 parts
                parts = 4;
            }
            StringBuilder sbBuilder = new StringBuilder();
            for (int j = 0; j < parts; j++) {
                if (sbBuilder.length() > 0) {
                    sbBuilder.append(".");
                }
                StringBuilder stringBuilder = new StringBuilder();
                if (chanceOf10()) { //each part has 10% chance to generate a fake number
                    stringBuilder.append('a');
                } else { //each part has 90% chance to generate the correct number
                    stringBuilder.append(boundRandom(0, 255));
                }
                sbBuilder.append(stringBuilder);
            }
            ipList.add(sbBuilder.toString());
        }
        return ipList;
    }

    /**
     * 全对IP
     * @param capacity 数量
     * @return ip列表
     */
    public static List<String> generateFakeIpGood(int capacity) {
        List<String> ipList = new ArrayList<String>(capacity);
        for (int i = 0; i < capacity; i++) {
            int parts = 4;
            StringBuilder sbBuilder = new StringBuilder();
            for (int j = 0; j < parts; j++) {
                if (sbBuilder.length() > 0) {
                    sbBuilder.append(".");
                }
                StringBuilder stringBuilder = new StringBuilder();
                if (chanceOf10()) { //each part has 10% chance to generate a fake number
                    stringBuilder.append("10");
                } else { //each part has 90% chance to generate the correct number
                    stringBuilder.append(boundRandom(0, 255));
                }
                sbBuilder.append(stringBuilder);
            }
            ipList.add(sbBuilder.toString());
        }
        return ipList;
    }

    public static long correctCount(List<String> ipList) {
        return ipList.stream().filter(IPUtil::isIpv4).count();
    }

    // 50% chance
    private static boolean chanceOf50() {
        return boundRandom(0, 9) < 5;
    }

    // 10% chance
    private static boolean chanceOf10() {
        return boundRandom(0, 9) < 1;
    }

    private static final SecureRandom random = new SecureRandom();

    // random int between [start, end], both start and end are included
    private static int boundRandom(int start, int end) {
        return start + random.nextInt(end);
    }
}
