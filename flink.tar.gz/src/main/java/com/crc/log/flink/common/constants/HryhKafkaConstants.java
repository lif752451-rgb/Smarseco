package com.crc.log.flink.common.constants;

/**
 * 华润银行kafka类
 */
public class HryhKafkaConstants
{
    public static String getHrynKafkaDevIp(String jsonStr)
    {
        String devIp = null ;
        if (jsonStr.contains("192.168.101.203")) {
            devIp = "192.168.101.203";
        } else if (jsonStr.contains("58.2.2.241")) {
            devIp = "58.2.2.241";
        } else if (jsonStr.contains("57.12.16.201")) {
            devIp = "57.12.16.201";
        } else if (jsonStr.contains("56.8.32.21")) {
            devIp = "56.8.32.21";
        } else if (jsonStr.contains("56.8.32.22")) {
            devIp = "56.8.32.22";
        } else if (jsonStr.contains("10.200.219.226")) {
            devIp = "10.200.219.226";
        } else if (jsonStr.contains("10.200.219.227")) {
            devIp = "10.200.219.227";
        } else if (jsonStr.contains("10.200.219.228")) {
            devIp = "10.200.219.228";
        } else if (jsonStr.contains("10.200.219.169")) {
            devIp = "10.200.219.169";
        } else if (jsonStr.contains("10.200.219.170")) {
            devIp = "10.200.219.170";
        } else if (jsonStr.contains("10.200.212.235")) {
            devIp = "10.200.212.235";
        } else if (jsonStr.contains("10.200.219.167")) {
            devIp = "10.200.219.167";
        } else if (jsonStr.contains("10.200.219.168")) {
            devIp = "10.200.219.168";
        } else if (jsonStr.contains("192.168.101.230")) {
            devIp = "192.168.101.230";
        } else if (jsonStr.contains("56.255.66.164")) {
            devIp = "56.255.66.164";
        } else if (jsonStr.contains("56.255.66.165")) {
            devIp = "56.255.66.165";
        } else if (jsonStr.contains("56.255.66.170")) {
            devIp = "56.255.66.170";
        } else if (jsonStr.contains("56.255.66.171")) {
            devIp = "56.255.66.171";
        } else if (jsonStr.contains("56.255.66.225")) {
            devIp = "56.255.66.225";
        } else if (jsonStr.contains("56.255.66.226")) {
            devIp = "56.255.66.226";
        } else if (jsonStr.contains("56.255.66.231")) {
            devIp = "56.255.66.231";
        } else if (jsonStr.contains("56.255.66.232")) {
            devIp = "56.255.66.232";
        } else
        {
            return null;
        }
        return devIp;
    }
}
