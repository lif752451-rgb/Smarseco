package com.crc.log.flink.parse;

import com.alibaba.fastjson.JSONObject;
import com.crc.log.flink.common.constants.LevelConstants;
import com.crc.log.flink.common.constants.LogConstants;
import com.crc.log.flink.common.utils.DataUtils;
import com.crc.log.flink.common.utils.DateUtils;
import com.crc.log.flink.common.utils.JsonUtils;
import com.crc.log.flink.common.utils.MapUtils;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;

import java.util.concurrent.ConcurrentHashMap;

/**
 * @author jixiangqi
 * @date 2022/4/15
 * 微步TDP
 */
@Slf4j
public class ResolvWeiBuTDPLog {
    public static ConcurrentHashMap<String, Object> parse(String message) {
        try {
            ConcurrentHashMap<String, Object> data = proc(message);
            if (DataUtils.isNotEmptyJson(data)) {
                return data;
            }
        } catch (Exception ignored) {

        }
        return null;
    }

    private static ConcurrentHashMap<String, Object> proc(String jsonStr) {
        ConcurrentHashMap<String, Object> rtnObjc = JsonUtils.createBaseMap(jsonStr);
        int index = DataUtils.getIndex(jsonStr, "{");
        jsonStr = DataUtils.getSubString(jsonStr, index);
        try {
            JSONObject jsonObject = JSONObject.parseObject(jsonStr);
            jsonObject.forEach((k, v) -> {
                switchKeyValue(rtnObjc, k.trim(), v + "".trim());
            });
        } catch (Exception e) {
            log.error(e.getMessage(),e);
        }
        if (StringUtils.isBlank(MapUtils.getStr(rtnObjc, LogConstants.SRC_IP))) {
            rtnObjc.put(LogConstants.SRC_IP, "0.0.0.0");
        }
        if (StringUtils.isBlank(MapUtils.getStr(rtnObjc, LogConstants.DEST_IP))) {
            rtnObjc.put(LogConstants.DEST_IP, "0.0.0.0");
        }
        rtnObjc.put(LogConstants.LOG_PRODUCT, "微步TDP");
        setAlertName(rtnObjc);
        return rtnObjc;
    }


    private static void setAlertName(ConcurrentHashMap<String, Object> rtnObjc) {
        String srcIp = MapUtils.getStr(rtnObjc, LogConstants.SRC_IP);
        String destIp = MapUtils.getStr(rtnObjc, LogConstants.DEST_IP);
        String proto = MapUtils.getStr(rtnObjc, LogConstants.LOG_PROTOCAL);
        String actionType = MapUtils.getStr(rtnObjc, LogConstants.ACTION_TYPE);
        String log = MapUtils.getStr(rtnObjc, LogConstants.LOG_ORI_MSG);
        String message = "IP为:%s对IP为:%s的进行一个:%s类型的攻击,攻击协议为:%s,日志详情为:%s";
        String alertName = String.format(message, srcIp, destIp, actionType, proto, log);
        rtnObjc.put(LogConstants.ALERT_NAME, alertName);
    }

    private static void switchKeyValue(ConcurrentHashMap<String, Object> rtnObjc, String key, String value) {
        switch (key) {
            case "timeStr":
                rtnObjc.put(LogConstants.LOG_START_TIME, DateUtils.getISO8601Timestamp(value, "yyyy/MM/dd HH:mm:ss"));
                break;
            case "data_type":
                rtnObjc.put(LogConstants.ACTION_TYPE, value);
                break;
            case "device_id":
                rtnObjc.put(LogConstants.DEVICE_ID, value);
                break;
            case "file_upload_data":
                if (value != null && !value.equals("")) {
                    JSONObject jsonObject = JSONObject.parseObject(value);
                    jsonObject.forEach((k, v) -> {
                        switchKeyValue(rtnObjc, k.trim(), v + "".trim());
                    });
                }
                break;
            case "filename":
                rtnObjc.put(LogConstants.LOG_FILENAME, value);
                break;
            case "net":
                if (value != null && !value.equals("")) {
                    JSONObject jsonObject = JSONObject.parseObject(value);
                    jsonObject.forEach((k, v) -> {
                        switchKeyValue(rtnObjc, k.trim(), v + "".trim());
                    });
                }
                break;
            case "src_ip":
                rtnObjc.put(LogConstants.SRC_IP, value);
                break;
            case "src_port":
                rtnObjc.put(LogConstants.SRC_PORT, value);
                break;
            case "dest_ip":
                rtnObjc.put(LogConstants.DEST_IP, value);
                break;
            case "dest_port":
                rtnObjc.put(LogConstants.DEST_PORT, value);
                break;
            case "proto":
                rtnObjc.put(LogConstants.LOG_PROTOCAL, value);
                break;
            case "threat":
                if (value != null && !value.equals("")) {
                    JSONObject jsonObject = JSONObject.parseObject(value);
                    jsonObject.forEach((k, v) -> {
                        switchKeyValue(rtnObjc, "threat." + k.trim(), v + "".trim());
                    });
                }
                break;
            case "threat.severity":
                String level = LevelConstants.INFO;
                switch (value) {
                    case "0":
                        level = LevelConstants.INFO;
                        break;
                    case "1":
                        level = LevelConstants.LOW;
                        break;
                    case "2":
                        level = LevelConstants.MEDIUM;
                        break;
                    case "3":
                        level = LevelConstants.HIGH;
                        break;
                    case "4":
                        level = LevelConstants.HIGH;
                        break;
                }
                rtnObjc.put(LogConstants.LOG_LEVEL, level);
                break;
            case "threat.msg":
                rtnObjc.put(LogConstants.LOG_DESCRIPTION, value);
                break;
            case "threat.type":
                String type = "";
                switch (key) {
                    case "recon":
                        type = "侦查";
                        break;
                    case "exploit":
                        type = "漏洞利用";
                        break;
                    case "virus":
                        type = "病毒攻击";
                        break;
                    case "tunneling":
                        type = "通信隧道";
                        break;
                    case "infil":
                        type = "内网渗透";
                    case "post_exploit":
                        type = "内网渗透";
                        break;
                    case "dc":
                        type = "域控制攻击";
                        break;
                    case "shell":
                        type = "网站后面&shell";
                        break;
                    case "c2":
                        type = "连接远控地址";
                        break;
                    case "trojan":
                        type = "木马";
                        break;
                    case "dga":
                        type = "DGA地址连接";
                        break;
                    case "rat":
                        type = "远程控制工具";
                        break;
                    case "botnet":
                        type = "僵尸网络";
                        break;
                    case "exfil":
                        type = "数据窃取";
                        break;
                    case "phishing":
                        type = "网络钓鱼";
                        break;
                    case "dnslog":
                        type = "反连dnslog地址";
                        break;
                    case "attack_out":
                        type = "对外攻击";
                        break;
                    case "unknown_url":
                        type = "尝试下载恶意文件";
                        break;
                    case "File":
                        type = "下载或传播恶意文件";
                        break;
                    case "persistence":
                        type = "攻击持久化";
                        break;
                    case "ransom":
                        type = "勒索软件";
                        break;
                    case "worm":
                        type = "蠕虫";
                        break;
                    case "mining":
                        type = "挖矿";
                        break;
                }
                rtnObjc.put(LogConstants.LOG_TYPE, type);
                break;
            case "threat.result":
                rtnObjc.put(LogConstants.ACTION_RESULT, value);
                break;
            case "threat.suuid":
                rtnObjc.put(LogConstants.RULE_ID, value);
                break;
            case "data":
                rtnObjc.put(LogConstants.LOG_URL, value);
                break;
            case "threat.name":
                rtnObjc.put(LogConstants.LOG_NAME, value);
                break;
        }
    }
}
