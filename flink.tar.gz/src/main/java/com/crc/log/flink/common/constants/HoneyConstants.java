package com.crc.log.flink.common.constants;

import org.apache.commons.lang3.StringUtils;

import java.util.HashMap;

public class HoneyConstants {
    public static HashMap<String,String> eventTypeMap =  new HashMap<>();
    static {
        eventTypeMap.put("connect","连接建立");
        eventTypeMap.put("shell_command","命令执行");
        eventTypeMap.put("disconnect","连接断开");
        eventTypeMap.put("key_login","密钥登录事件");
        eventTypeMap.put("password_login","密码登录事件");
        eventTypeMap.put("file_event","入侵遗留文件");
        eventTypeMap.put("unauthorized_access","未授权访问");
        eventTypeMap.put("malicious_request","恶意请求");
        eventTypeMap.put("database_command","数据库操作命令");
    }

    public static  String getEventType(String type){
        String ret = eventTypeMap.get(type);
        if(StringUtils.isBlank(ret))
            return type;
        return ret;
    }

}
