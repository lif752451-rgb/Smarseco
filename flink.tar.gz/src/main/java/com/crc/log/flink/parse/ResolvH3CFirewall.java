package com.crc.log.flink.parse;

import com.alibaba.fastjson.JSONObject;
import com.crc.log.flink.common.constants.LevelConstants;
import com.crc.log.flink.common.constants.LogConstants;
import com.crc.log.flink.common.utils.DataUtils;
import com.crc.log.flink.common.utils.JsonUtils;
import com.crc.log.flink.common.utils.MapUtils;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;

import java.util.concurrent.ConcurrentHashMap;

/**
 * 华三防火墙解析类
 */
@Slf4j
public class ResolvH3CFirewall {
    public static ConcurrentHashMap<String, Object> parse(String message) {
        try {
            ConcurrentHashMap<String, Object> data = proc(message);
            if (DataUtils.isNotEmptyJson(data)) {
                return data;
            }
        } catch (Exception ignored) {

        }
        return null;
    }

    private static ConcurrentHashMap<String, Object> proc(String jsonStr) {
        ConcurrentHashMap<String, Object> ldapJson = JsonUtils.createBaseMap(jsonStr);
        try {
            JSONObject dataJson = new JSONObject();
            if (jsonStr.contains("(")) {
                int index = DataUtils.getIndex(jsonStr, "(");
                String temp = DataUtils.getSubString(jsonStr, 0, index);
                if (StringUtils.isBlank(temp)) {
                    return ldapJson;
                }
                int index1 = DataUtils.getLastIndex(temp, ":");
                if (index1 > -1) {
                    temp = DataUtils.getSubString(jsonStr, index1 + 1);
                }
                String[] IPS_buff = DataUtils.getSplit(temp, ";");
                for (String value : IPS_buff) {
                    String[] datakey = DataUtils.getSplit(value, "=");
                    if (1 < datakey.length) {
                        dataJson.put(datakey[0].trim(), datakey[1].trim());
                    }
                }

                ldapJson.put(LogConstants.LOG_PRODUCT, "H3C防火墙");
                if (StringUtils.isNotBlank(jsonStr)) {
                    MapUtils.setStr(ldapJson, LogConstants.LOG_PROTOCAL, dataJson, "Protocol(1001)");
                    MapUtils.setStr(ldapJson, LogConstants.LOG_APP, dataJson, "Application(1002)");
                    MapUtils.setStr(ldapJson, LogConstants.LOG_URL, dataJson, "URL(1093)");
                    MapUtils.setStr(ldapJson, LogConstants.LOG_TYPE, dataJson, "URLCategory(1094)");
                    MapUtils.setStr(ldapJson, LogConstants.LOG_NAME, dataJson, "PolicyName(1079)");
                    MapUtils.setStr(ldapJson, LogConstants.SRC_IP, dataJson, "SrcIPAddr(1003)");
                    MapUtils.setStr(ldapJson, LogConstants.SRC_PORT, dataJson, "SrcPort(1004)");
                    MapUtils.setStr(ldapJson, LogConstants.DEST_IP, dataJson, "DstIPAddr(1007)");
                    MapUtils.setStr(ldapJson, LogConstants.DEST_PORT, dataJson, "DstPort(1008)");
                    MapUtils.setStr(ldapJson, LogConstants.SRC_ZONE, dataJson, "SrcZoneName(1025)");
                    MapUtils.setStr(ldapJson, LogConstants.DEST_ZONE, dataJson, "DstZoneName(1035)");
                    MapUtils.setStr(ldapJson, LogConstants.OP_NAME, dataJson, "UserName(1113)");
                    MapUtils.setStr(ldapJson, LogConstants.ACTION_RESULT, dataJson, "Action(1053)");
                }
            }
            ldapJson.put(LogConstants.LOG_LEVEL, LevelConstants.getLevel(MapUtils.getStr(ldapJson, LogConstants.LOG_LEVEL)));
            if (StringUtils.isBlank(MapUtils.getStr(ldapJson, LogConstants.SRC_IP))) {
                ldapJson.put(LogConstants.SRC_IP, "0.0.0.0");
            }
            if (StringUtils.isBlank(MapUtils.getStr(ldapJson, LogConstants.DEST_IP))) {
                ldapJson.put(LogConstants.DEST_IP, "0.0.0.0");
            }
            setAlertName(ldapJson);
            return ldapJson;
        } catch (Exception e) {
            log.error(e.getMessage(), e);
            return ldapJson;
        }
    }


    private static void setAlertName(ConcurrentHashMap<String, Object> rtnObjc) {
        String msgFormat = "IP为:%s对目的IP为:%s,发起了一个%s访问,风险级别为:%s,日志详情为:%s";
        String level = MapUtils.getStr(rtnObjc, LogConstants.LOG_LEVEL);
        String srcIp = MapUtils.getStr(rtnObjc, LogConstants.SRC_IP);
        String destIp = MapUtils.getStr(rtnObjc, LogConstants.DEST_IP);
        String proto = MapUtils.getStr(rtnObjc, LogConstants.LOG_PROTOCAL);
        String log = MapUtils.getStr(rtnObjc, LogConstants.LOG_ORI_MSG);
        String alertName = String.format(msgFormat, srcIp, destIp, proto, level, log);
        rtnObjc.put(LogConstants.ALERT_NAME, alertName);
    }
}
