package com.crc.log.flink.parse;

import com.alibaba.fastjson.JSONObject;
import com.crc.log.flink.common.constants.G01Constants;
import com.crc.log.flink.common.constants.LevelConstants;
import com.crc.log.flink.common.constants.LogConstants;
import com.crc.log.flink.common.utils.DataUtils;
import com.crc.log.flink.common.utils.DateUtils;
import com.crc.log.flink.common.utils.JsonUtils;
import com.crc.log.flink.common.utils.MapUtils;
import org.apache.commons.lang3.StringUtils;

import java.util.concurrent.ConcurrentHashMap;

/**
 * @Author daiyd
 * @Date: 2020/5/29 11:30
 * @Version 1.0
 */

public class ResolvG01Log {

    /**
     * G01 日志泛化
     *
     * @param message
     * @return
     */
    public static ConcurrentHashMap<String,Object> parse(String message) {
        try {
            ConcurrentHashMap<String,Object> data = proc(message);
            if (DataUtils.isNotEmptyJson(data)) {
                return data;
            }
        } catch (Exception ignored) {

        }
        return null;
    }

    private static ConcurrentHashMap<String,Object> proc(String jsonStr) {

        ConcurrentHashMap<String,Object> g01Json = JsonUtils.createBaseMap(jsonStr);
        try {
            JSONObject jObj = JsonUtils.parse(jsonStr);
            g01Json.put(LogConstants.LOG_PRODUCT, "G01");
            if (JsonUtils.isEmpty(jObj)) {
                return g01Json;
            }
            parseG01Json(g01Json, jObj);
            g01Json.put(LogConstants.LOG_LEVEL, LevelConstants.getLevel(MapUtils.getStr(g01Json,LogConstants.LOG_LEVEL)));
            if (StringUtils.isBlank(MapUtils.getStr(g01Json, LogConstants.SRC_IP))) {
                g01Json.put(LogConstants.SRC_IP, "0.0.0.0");
            }
            if (StringUtils.isBlank(MapUtils.getStr(g01Json, LogConstants.DEST_IP))) {
                g01Json.put(LogConstants.DEST_IP, "0.0.0.0");
            }
            setAlertName(g01Json);
            return g01Json;
        } catch (Exception e) {
            return g01Json;
        }
    }

    public static void parseG01Json(ConcurrentHashMap<String,Object> g01Json, JSONObject jObj) {
        MapUtils.setJsonValue(g01Json, jObj, LogConstants.DEST_IP_CITY, "destIpAddress.city",
                LogConstants.DEST_IP_COUNTRY, "destIpAddress.country");
        MapUtils.setJsonValue(g01Json, jObj, LogConstants.SRC_IP_CITY, "srcIpAddress.city",
                LogConstants.SRC_IP_COUNTRY, "srcIpAddress.country");
        setIpAndPort(g01Json, jObj);
        MapUtils.setStr(g01Json, LogConstants.MSG_CONTENT, jObj, "action");
        if (MapUtils.containsKey(jObj, "ip")) {
            g01Json.put(LogConstants.SRC_IP, JsonUtils.getStr(jObj, "ip"));
        }
        setSevrityInfoAndLevel(g01Json, jObj);
        String result = JsonUtils.getStr(jObj, "result");
        result = result.equals("0") ? "拦截" : "放行";
        MapUtils.setStr(g01Json, LogConstants.ACTION_RESULT, result);
        String eventIdStr = JsonUtils.getStr(jObj, "eventIdStr");
        MapUtils.setStr(g01Json, LogConstants.EVENT_ID, eventIdStr);
        MapUtils.setStr(g01Json, LogConstants.LOG_NAME, G01Constants.getEventType(eventIdStr));
        MapUtils.setStr(g01Json, LogConstants.LOG_TYPE, G01Constants.getEventInfo(eventIdStr));
        //g01Json.put(LogConstants.LOG_COUNT, MapUtils.getInt(jObj, "reserve1"));
        MapUtils.setStr(g01Json, LogConstants.DEST_IP, jObj, "innerIp");
        MapUtils.setStr(g01Json, LogConstants.HOST_NAME, jObj, "machineName");
        MapUtils.setStr(g01Json, LogConstants.OS_INFO, jObj, "operatingSystem");
        MapUtils.setStr(g01Json, LogConstants.LOG_DESCRIPTION, jObj, "operation");
        MapUtils.setStr(g01Json, LogConstants.LOG_START_TIME, DateUtils.getISO8601Timestamp(JsonUtils.getLong(jObj, "localTimestamp")));
    }

    public static void setSevrityInfoAndLevel(ConcurrentHashMap<String,Object> targetJson, JSONObject sourceJson) {
        String type = JsonUtils.getStr(sourceJson, "logType");
        int j = DataUtils.toNum(type);
        String level = LevelConstants.LOW;
        switch (j) {
            case 0:
                type = "普通日志";
                break;
            case 1:
                type = "告警事件";
                level = LevelConstants.MEDIUM;
                break;
            case 2:
                type = "可疑行为";
                level = LevelConstants.HIGH;
                break;
            default:
                type = "未知";
        }
        targetJson.put(LogConstants.ACTION_TYPE, type);
        targetJson.put(LogConstants.LOG_LEVEL, level);

        String severity = JsonUtils.getStr(sourceJson, "insLevel");
        int i = DataUtils.toNum(severity);
        switch (i) {
            case 0:
                severity = "优秀";
                break;
            case 1:
                severity = "良好";
                break;
            case 2:
                severity = "及格";
                break;
            case 3:
                severity = "危险";
                break;
            case 4:
                severity = "未巡检";
                break;
            default:
                severity = "未知";
        }
        targetJson.put(LogConstants.LOG_PRIORITY, severity);


        int eventScore = 0;
        if (i == 0 || i == 1 || i == 2) {
            if (j == 0) {
                eventScore = 0;
            } else if (j == 1) {
                eventScore = 30;
            } else if (j == 2) {
                eventScore = 50;
            }
        } else if (i == 3 || i == 4) {
            if (j == 0) {
                eventScore = 10;
            } else if (j == 1) {
                eventScore = 70;
            } else if (j == 2) {
                eventScore = 100;
            }
        }
        targetJson.put(LogConstants.EVENT_SCORE, eventScore);

    }

    public static void setIpAndPort(ConcurrentHashMap<String,Object> targetJson, JSONObject sourceJson) {
        if (MapUtils.containsKey(sourceJson, "object")) {
            String ip = JsonUtils.getJsonValue(sourceJson, "object.ip");
            if (ip.contains(":")) {
                String[] arr = DataUtils.getSplit2(ip, ":");
                        //ip.split(":");
                targetJson.put(LogConstants.SRC_IP, arr[0]);
                targetJson.put(LogConstants.SRC_PORT, arr[1]);
            } else {
                targetJson.put(LogConstants.SRC_IP, ip);
            }
        }
    }

    public static void setAlertName(ConcurrentHashMap<String,Object> resultJson) {

        String srcIp = MapUtils.getStr(resultJson, LogConstants.SRC_IP);
        String destIp = MapUtils.getStr(resultJson, LogConstants.DEST_IP);
        String eventDescription = MapUtils.getStr(resultJson, LogConstants.LOG_DESCRIPTION);
        if (StringUtils.isBlank(eventDescription)) {
            eventDescription = MapUtils.getStr(resultJson, LogConstants.LOG_TYPE);
        }
        String logName = MapUtils.getStr(resultJson, LogConstants.LOG_NAME);
        String actionRule = MapUtils.getStr(resultJson, LogConstants.ACTION_RESULT);
        String log = MapUtils.getStr(resultJson, LogConstants.LOG_ORI_MSG);
        if (StringUtils.isBlank(destIp) || "null".equals(destIp) || "0.0.0.0".equals(destIp) || srcIp.equals(destIp)) {
            String messageFormat = "%s 发起 %s-%s-%s,原始日志:%s";
            String alertName = String.format(messageFormat, srcIp, logName, eventDescription, actionRule, log);
            resultJson.put(LogConstants.ALERT_NAME, alertName);
        } else {
            String messageFormat = "%s 对 %s 进行 %s-%s-%s,原始日志:%s";
            String alertName = String.format(messageFormat, srcIp, destIp, logName, eventDescription, actionRule, log);
            resultJson.put(LogConstants.ALERT_NAME, alertName);
        }

    }

}
