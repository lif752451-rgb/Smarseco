package com.crc.log.flink.parse;

import com.alibaba.fastjson.JSONObject;
import com.crc.log.flink.common.constants.LevelConstants;
import com.crc.log.flink.common.constants.LogConstants;
import com.crc.log.flink.common.utils.DataUtils;
import com.crc.log.flink.common.utils.IPUtil;
import com.crc.log.flink.common.utils.JsonUtils;
import com.crc.log.flink.common.utils.MapUtils;
import org.apache.commons.lang3.StringUtils;

import java.util.concurrent.ConcurrentHashMap;

public class ResolvWifiAccessLog {
    public static ConcurrentHashMap<String, Object> parse(String message) {
        try {
            ConcurrentHashMap<String, Object> data = proc(message);
            if (DataUtils.isNotEmptyJson(data)) {
                return data;
            }
        } catch (Exception ignored) {

        }
        return null;
    }

    private static ConcurrentHashMap<String, Object> proc(String value) {
        ConcurrentHashMap<String, Object> ldapJson = JsonUtils.createBaseMap(value);
        try {
            JSONObject dataJson = new JSONObject();
            String jsonStr = value;
            if (value.contains("<14>[AuditDB")) {
                return ResolvAccessLog.parse(value);
            } else if (value.contains("NDAM:")) {
                //无线访客系统
                String[] IPS_buff = DataUtils.getSplit(jsonStr, ";");
                for (String s : IPS_buff) {
                    String[] datakey = DataUtils.getSplit2(s, ":");
                    if (1 < datakey.length) {
                        dataJson.put(datakey[0], datakey[1]);
                    }
                }
            } else if (value.contains("crland")) {
                int index2 = DataUtils.getLastIndex(jsonStr, "crland");
                        //jsonStr.lastIndexOf("crland");
                String temp1 = DataUtils.getSubString(jsonStr, index2);
                        //jsonStr.substring(index2);
                int index3 = DataUtils.getIndex(temp1, " ");
                        //temp1.indexOf(" ");
                int index4 = DataUtils.getIndex(temp1, ">");
                        //temp1.indexOf(">");
                String destIp = "";
                if (index3 != -1 && index4 != -1) {
                    destIp = DataUtils.getSubString(temp1, index3 + 1, index4);
                }
                if (StringUtils.isNotBlank(destIp) && IPUtil.isIp(destIp)) {
                    ldapJson.put(LogConstants.DEST_IP, destIp);
                }
                int index = DataUtils.getLastIndex(jsonStr, "|");
                if (index > -1) {
                    jsonStr = DataUtils.getSubString(jsonStr, index+1);
                    String[] split = DataUtils.getSplit(jsonStr, ";");
                    for (String temp : split) {
                        if (temp.contains(":")) {
                            int index1 = DataUtils.getIndex(temp, ":");
                            String key = DataUtils.getSubString(temp, 0, index1).trim();
                            String content = DataUtils.getSubString(temp, index1 + 1).trim();
                            switch (key) {
                                case "Interfering AP":
                                    ldapJson.put(LogConstants.LOG_CONTENT, content);
                                    break;
                                case "Detector-AP-MAC":
                                    ldapJson.put(LogConstants.SRC_MAC, content);
                                    break;
                            }
                        }
                    }
                }
            } if(value.contains("Auth.Username") && value.contains("Insight logs")){
                int index2 = DataUtils.getLastIndex(jsonStr, "Auth.Username");
                //jsonStr.lastIndexOf("crland");
                String temp1 = DataUtils.getSubString(jsonStr, index2).replace("\n","").replace("\\n","");
                String[] IPS_buff = DataUtils.getSplit(temp1, ",");
                for (String s : IPS_buff) {
                    String[] datakey = DataUtils.getSplit2(s, "=");
                    if (1 < datakey.length) {
                        dataJson.put(datakey[0], datakey[1]);
                    }
                }
            }else {
                if (StringUtils.isNotBlank(jsonStr) && jsonStr.contains("Auth.")) {
                    jsonStr = DataUtils.getSubString(jsonStr, jsonStr.indexOf("Auth."));
                } else if (StringUtils.isNotBlank(jsonStr) && jsonStr.contains("RADIUS.")) {
                    jsonStr = DataUtils.getSubString(jsonStr, jsonStr.indexOf("RADIUS."));
                }

                String[] IPS_buff = DataUtils.getSplit(jsonStr, ",");
                for (String s : IPS_buff) {
                    String[] datakey = DataUtils.getSplit(s, "=");
                    if (1 < datakey.length) {
                        dataJson.put(datakey[0], datakey[1]);
                    }
                }
            }
            //retData.putAll(dataJson);
            ldapJson.put(LogConstants.LOG_PRODUCT, "Wifi准入");
            if (StringUtils.isNotBlank(jsonStr)) {
                if (StringUtils.isNotBlank(jsonStr) && jsonStr.contains("Auth.")) {
                    MapUtils.setStr(ldapJson, LogConstants.OP_NAME, dataJson, "Auth.Username");
                    MapUtils.setStr(ldapJson, LogConstants.SRC_MAC, dataJson, "Auth.Host-MAC-Address");
                    MapUtils.setStr(ldapJson, LogConstants.SRC_IP, dataJson, "Radius.Framed-IP-Address");
                } else if (StringUtils.isNotBlank(jsonStr) && jsonStr.contains("RADIUS.")) {
                    MapUtils.setStr(ldapJson, LogConstants.OP_NAME, dataJson, "RADIUS.Acct-Username");
                    MapUtils.setStr(ldapJson, LogConstants.SRC_MAC, dataJson, "RADIUS.Acct-Calling-Station-Id");
                    if (StringUtils.isNotBlank(jsonStr) && jsonStr.contains("RADIUS.Acct-Framed-IP-Address")) {
                        MapUtils.setStr(ldapJson, LogConstants.SRC_IP, dataJson, "RADIUS.Acct-Framed-IP-Address");
                    } else {
                        MapUtils.setStr(ldapJson, LogConstants.SRC_IP, dataJson, "RADIUS.Acct-NAS-IP-Address");
                    }
                    ldapJson.put(LogConstants.MSG_CONTENT, value);
                } else if (value.contains("NDAM:")) {
                    MapUtils.setStr(ldapJson, LogConstants.OP_NAME, dataJson, "username");
                    MapUtils.setStr(ldapJson, LogConstants.SRC_MAC, dataJson, "userMac");
                    MapUtils.setStr(ldapJson, LogConstants.SRC_IP, dataJson, "IP");
                    MapUtils.setStr(ldapJson, LogConstants.ACTION_RESULT, dataJson, "loginSuccess");
                    MapUtils.setStr(ldapJson,LogConstants.SRC_DEV_INFO,dataJson,"terminalPlatform");
                }
            }
            ldapJson.put(LogConstants.LOG_LEVEL, LevelConstants.getLevel(MapUtils.getStr(ldapJson,LogConstants.LOG_LEVEL)));
            if (StringUtils.isBlank(MapUtils.getStr(ldapJson, LogConstants.SRC_IP))) {
                ldapJson.put(LogConstants.SRC_IP, "0.0.0.0");
            }
            if (StringUtils.isBlank(MapUtils.getStr(ldapJson, LogConstants.DEST_IP))) {
                ldapJson.put(LogConstants.DEST_IP, "0.0.0.0");
            }
            setAlertName(ldapJson);
            return ldapJson;
        } catch (Exception e) {
            return ldapJson;
        }
    }


    private static void setAlertName(ConcurrentHashMap<String, Object> rtnObjc) {
        String msgFormat = "";
        String alertName = "";
        String level = MapUtils.getStr(rtnObjc, LogConstants.LOG_LEVEL);
        String srcIp = MapUtils.getStr(rtnObjc, LogConstants.SRC_IP);
        String destIp = MapUtils.getStr(rtnObjc, LogConstants.DEST_IP);
        String result = MapUtils.getStr(rtnObjc, LogConstants.ACTION_RESULT);
        String srcMac = MapUtils.getStr(rtnObjc, LogConstants.SRC_MAC);
        String log = MapUtils.getStr(rtnObjc, LogConstants.LOG_ORI_MSG);
        if (destIp.equals("0.0.0.0")) {
            if (srcIp.equals("0.0.0.0") && !"".equals(srcMac)) {
                msgFormat = "源MAC为:%s,风险级别为:%s,日志详情为:%s";
                alertName = String.format(msgFormat, srcMac, level, log);
            } else if (!"".equals(result)) {
                msgFormat = "源IP为:%s,风险级别为:%s,操作结果:%s,日志详情为:%s";
                alertName = String.format(msgFormat, srcIp, level, result, log);
            } else {
                msgFormat = "源IP为:%s,风险级别为:%s,日志详情为:%s";
                alertName = String.format(msgFormat, srcIp, level, log);
            }
        } else {
            if (srcIp.equals("0.0.0.0") && !"".equals(srcMac)) {
                msgFormat = "源MAC为:%s,目的IP:%s,风险级别为:%s,日志详情为:%s";
                alertName = String.format(msgFormat, srcMac, destIp, level, log);
            } else if (!"".equals(result)) {
                msgFormat = "源IP为:%s,目的IP:%s,风险级别为:%s,操作结果:%s,日志详情为:%s";
                alertName = String.format(msgFormat, srcIp, destIp, level, result, log);
            } else {
                msgFormat = "源IP为:%s,目的IP:%s,风险级别为:%s,日志详情为:%s";
                alertName = String.format(msgFormat, srcIp, destIp, level, log);
            }
        }
        rtnObjc.put(LogConstants.ALERT_NAME, alertName);
    }
}

