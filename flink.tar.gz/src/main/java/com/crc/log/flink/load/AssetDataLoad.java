package com.crc.log.flink.load;

import com.crc.log.flink.common.entity.TbAsset;
import com.crc.log.flink.db.AssetDao;
import lombok.extern.slf4j.Slf4j;

import java.util.List;
import java.util.concurrent.ConcurrentHashMap;

@Slf4j
public class AssetDataLoad {
    public static ConcurrentHashMap<String, TbAsset> assetMap = new ConcurrentHashMap<>();

    public static void loadAssetMap() {
        List<TbAsset> assetList = AssetDao.queryList();
        ConcurrentHashMap<String, TbAsset> linshiMap = new ConcurrentHashMap<>();
        assetList.forEach(asset -> {
            linshiMap.put(asset.getIp(), asset);
        });
        log.info("加载加载资产数据OLD：" + assetMap.size());
        assetMap = linshiMap;
        log.info("加载加载资产数据NEW：" + assetMap.size());
    }
}
