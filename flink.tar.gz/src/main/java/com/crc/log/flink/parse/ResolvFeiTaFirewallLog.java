package com.crc.log.flink.parse;

import com.crc.log.flink.common.constants.LevelConstants;
import com.crc.log.flink.common.constants.LogConstants;
import com.crc.log.flink.common.utils.DataUtils;
import com.crc.log.flink.common.utils.DateUtils;
import com.crc.log.flink.common.utils.JsonUtils;
import com.crc.log.flink.common.utils.MapUtils;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;

import java.util.HashMap;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.atomic.AtomicReference;

/**
 * 飞塔防火墙
 */
@Slf4j
public class ResolvFeiTaFirewallLog {
    public static ConcurrentHashMap<String,Object> parse(String message) {
        try {
            ConcurrentHashMap<String,Object> data = proc(message);
            if (DataUtils.isNotEmptyJson(data)) {
                return data;
            }
        } catch (Exception ignored) {

        }
        return null;
    }

    private static ConcurrentHashMap<String,Object> proc(String jsonStr) {
        ConcurrentHashMap<String,Object> rtnObjc = JsonUtils.createBaseMap(jsonStr);
        Map<String, String> stringMap = splitBySpace(jsonStr);
        AtomicReference<String> date = new AtomicReference<>("");
        stringMap.forEach((key, value) -> {
            if (key.contains("date")) {
                date.set(value);
            }
            switch (key.trim()) {
                case "devname":
                    rtnObjc.put(LogConstants.DEVICE_NAME, value);
                    break;
                case "devid":
                    rtnObjc.put(LogConstants.DEVICE_ID, value);
                    break;
                case "logid":
                    rtnObjc.put(LogConstants.EVENT_ID, value);
                    break;
                case "type":
                    rtnObjc.put(LogConstants.LOG_TYPE, value);
                    break;
                case "eventtype":
                    rtnObjc.put(LogConstants.VIRUS_TYPE, value);
                    break;
                case "level":
                    rtnObjc.put(LogConstants.LOG_LEVEL, LevelConstants.getLevel(value));
                    break;
                case "vd":
                    rtnObjc.put(LogConstants.USER_NAME, value);
                    break;
                case "time":
                    rtnObjc.put(LogConstants.LOG_START_TIME, DateUtils.getISO8601Timestamp(date.get() + " " + value));
                    break;
                case "severity":
                    rtnObjc.put(LogConstants.LOG_PRIORITY, value);
                    break;
                case "srcip":
                    rtnObjc.put(LogConstants.SRC_IP, value);
                    break;
                case "srccountry":
                    rtnObjc.put(LogConstants.SRC_ZONE, value);
                    break;
                case "dstip":
                    rtnObjc.put(LogConstants.DEST_IP, value);
                    break;
                case "srcintf":
                    rtnObjc.put(LogConstants.SRC_INTF, value);
                    break;
                case "action":
                    rtnObjc.put(LogConstants.BEHAVIOR_TAG, value);
                    break;
                case "count":
                    rtnObjc.put(LogConstants.ACTION_TIMES, value);
                    break;
                case "attack":
                    rtnObjc.put(LogConstants.ATTACK_DIRECTION, value);
                    break;
                case "msg":
                    rtnObjc.put(LogConstants.LOG_CONTENT, value);
                    break;
                case "service":
                    rtnObjc.put(LogConstants.LOG_PROTOCAL, value);
                    break;
                case "srcport":
                    rtnObjc.put(LogConstants.SRC_PORT, value);
                    break;
                case "dstport":
                    rtnObjc.put(LogConstants.DEST_PORT, value);
                    break;
                case "hostname":
                    rtnObjc.put(LogConstants.HOST_NAME, value);
                    break;
                case "url":
                    rtnObjc.put(LogConstants.LOG_URL, value);
                    break;
                case "policyid":
                    rtnObjc.put(LogConstants.STRATEGY_ID, value);
                    break;
            }
        });
        rtnObjc.put(LogConstants.LOG_PRODUCT, "飞塔防火墙");
        rtnObjc.put(LogConstants.LOG_LEVEL, LevelConstants.getLevel(MapUtils.getStr(rtnObjc,LogConstants.LOG_LEVEL)));
        if (StringUtils.isBlank(MapUtils.getStr(rtnObjc, LogConstants.SRC_IP))) {
            rtnObjc.put(LogConstants.SRC_IP, "0.0.0.0");
        }
        if (StringUtils.isBlank(MapUtils.getStr(rtnObjc, LogConstants.DEST_IP))) {
            rtnObjc.put(LogConstants.DEST_IP, "0.0.0.0");
        }
        setAlertName(rtnObjc);
        return rtnObjc;
    }

    private static Map<String, String> splitBySpace(String jsonStr) {
        Map<String, String> map = new HashMap<>();
        String[] s = DataUtils.getSplit(jsonStr, " ");
                //jsonStr.split(" ");
        String index = "";
        for (String item : s) {
            String temp = item;
            if (temp.contains("\"")) {
                temp = temp.replaceAll("\"", "");
            }
            if (temp.contains("=")) {
                String[] split = DataUtils.getSplit(temp, "=");
                //temp.split("=");
                String key = split[0];
                String value = split.length > 1 ? split[1] : "";
                map.put(key, value);
                index = key;
            } else {
                StringBuilder sb = new StringBuilder();
                if (map.size() != 0) {
                    sb = new StringBuilder(map.get(index));
                }
                sb.append(" ").append(temp);
                map.put(index, sb.toString());
            }
        }
        return map;
    }

    public static void setAlertName(ConcurrentHashMap<String,Object> resultJson) {
        try {
            String messageFormat = "源IP为:%s对目的IP为:%s发起了一个攻击类型为:%s的攻击,攻击风险:%s,具体内容为:%s,事件类型为:%s,原始日志:%s";
            String srcIp = MapUtils.getStr(resultJson, LogConstants.SRC_IP);
            String destIp = MapUtils.getStr(resultJson, LogConstants.DEST_IP);
            String event = MapUtils.getStr(resultJson, LogConstants.LOG_TYPE);
            String action = MapUtils.getStr(resultJson, LogConstants.BEHAVIOR_TAG);
            String level = MapUtils.getStr(resultJson, LogConstants.LOG_LEVEL);
            String content = MapUtils.getStr(resultJson, LogConstants.LOG_CONTENT);
            String log = MapUtils.getStr(resultJson, LogConstants.LOG_ORI_MSG);
            if (StringUtils.isBlank(srcIp)) {
                srcIp = MapUtils.getStr(resultJson, LogConstants.HOST_NAME);
            }
            String alertName = String.format(messageFormat, srcIp, destIp, action, level, content, event, log);
            resultJson.put(LogConstants.ALERT_NAME, alertName);
        } catch (Exception e) {
            log.error(e.getMessage(),e);
        }
    }
}
