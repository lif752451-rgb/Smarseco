package com.crc.log.flink.flink;

import com.crc.log.flink.common.utils.DataUtils;
import lombok.extern.slf4j.Slf4j;
import org.apache.flink.api.common.eventtime.WatermarkStrategy;
import org.apache.flink.api.common.serialization.DeserializationSchema;
import org.apache.flink.metrics.MetricGroup;
import org.apache.flink.streaming.api.operators.StreamingRuntimeContext;
import org.apache.flink.streaming.connectors.kafka.FlinkKafkaConsumerBase;
import org.apache.flink.streaming.connectors.kafka.KafkaDeserializationSchema;
import org.apache.flink.streaming.connectors.kafka.config.OffsetCommitMode;
import org.apache.flink.streaming.connectors.kafka.internals.*;
import org.apache.flink.util.Preconditions;
import org.apache.flink.util.PropertiesUtil;
import org.apache.flink.util.SerializedValue;
import org.apache.kafka.clients.consumer.KafkaConsumer;
import org.apache.kafka.clients.consumer.OffsetAndTimestamp;
import org.apache.kafka.common.TopicPartition;
import org.apache.kafka.common.serialization.ByteArrayDeserializer;

import java.util.*;
import java.util.regex.Pattern;

/**
 * @author jixiangqi
 * @date 2022/4/21
 * 自定义flink消费Kafka
 */
@Slf4j
public class MyFlinkKafkaConsumer<T> extends FlinkKafkaConsumerBase<T> {


    private static final long serialVersionUID = 1L;
    protected final Properties properties;
    protected final long pollTimeout;
    protected String partitionNo;

    public MyFlinkKafkaConsumer(String topic, DeserializationSchema<T> valueDeserializer, Properties props, String partition) {
        this(Collections.singletonList(topic), valueDeserializer, props);
        this.partitionNo = partition;
    }

    public MyFlinkKafkaConsumer(List<String> topics, DeserializationSchema<T> deserializer, Properties props) {
        this(topics, new KafkaDeserializationSchemaWrapper<>(deserializer), props);
    }

    public MyFlinkKafkaConsumer(List<String> topics, KafkaDeserializationSchema<T> deserializer, Properties props) {
        this(topics, null, deserializer, props);
    }

    private MyFlinkKafkaConsumer(List<String> topics, Pattern subscriptionPattern, KafkaDeserializationSchema<T> deserializer, Properties props) {
        super(topics, subscriptionPattern, deserializer, PropertiesUtil.getLong(Preconditions.checkNotNull(props, "props"), "flink.partition-discovery.interval-millis", -9223372036854775808L), !PropertiesUtil.getBoolean(props, "flink.disable-metrics", false));
        this.properties = props;
        setDeserializer(this.properties);

        try {
            if (this.properties.containsKey("flink.poll-timeout")) {
                this.pollTimeout = DataUtils.toLong(this.properties.getProperty("flink.poll-timeout"));
            } else {
                this.pollTimeout = 100L;
            }

        } catch (Exception var6) {
            throw new IllegalArgumentException("Cannot parse poll timeout for 'flink.poll-timeout'", var6);
        }
    }

    protected AbstractFetcher<T, ?> createFetcher(SourceContext<T> sourceContext, Map<KafkaTopicPartition, Long> assignedPartitionsWithInitialOffsets, SerializedValue<WatermarkStrategy<T>> watermarkStrategy, StreamingRuntimeContext runtimeContext, OffsetCommitMode offsetCommitMode, MetricGroup consumerMetricGroup, boolean useMetrics) throws Exception {
        adjustAutoCommitConfig(this.properties, offsetCommitMode);
        return new KafkaFetcher<>(sourceContext, assignedPartitionsWithInitialOffsets, watermarkStrategy, runtimeContext.getProcessingTimeService(), runtimeContext.getExecutionConfig().getAutoWatermarkInterval(), runtimeContext.getUserCodeClassLoader(), runtimeContext.getTaskNameWithSubtasks(), this.deserializer, this.properties, this.pollTimeout, runtimeContext.getMetricGroup(), consumerMetricGroup, useMetrics);
    }

    protected AbstractPartitionDiscoverer createPartitionDiscoverer(KafkaTopicsDescriptor topicsDescriptor, int indexOfThisSubtask, int numParallelSubtasks) {
        return new MyKafkaPartitionDiscoverer(topicsDescriptor, indexOfThisSubtask, numParallelSubtasks, this.properties, this.partitionNo);
    }

    protected Map<KafkaTopicPartition, Long> fetchOffsetsWithTimestamp(Collection<KafkaTopicPartition> partitions, long timestamp) {
        Map<TopicPartition, Long> partitionOffsetsRequest = new HashMap<>(partitions.size());

        for (KafkaTopicPartition partition : partitions) {
            partitionOffsetsRequest.put(new TopicPartition(partition.getTopic(), partition.getPartition()), timestamp);
        }

        Map<KafkaTopicPartition, Long> result = new HashMap<>(partitions.size());
        KafkaConsumer<?, ?> consumer = new KafkaConsumer<>(this.properties);
        Throwable var7 = null;

        try {
            for (Map.Entry<TopicPartition, OffsetAndTimestamp> topicPartitionOffsetAndTimestampEntry : consumer.offsetsForTimes(partitionOffsetsRequest).entrySet()) {
                result.put(new KafkaTopicPartition(((TopicPartition) ((Map.Entry<?, ?>) topicPartitionOffsetAndTimestampEntry).getKey()).topic(), ((TopicPartition) ((Map.Entry<?, ?>) topicPartitionOffsetAndTimestampEntry).getKey()).partition()), ((Map.Entry<?, ?>) topicPartitionOffsetAndTimestampEntry).getValue() == null ? null : ((OffsetAndTimestamp) ((Map.Entry<?, ?>) topicPartitionOffsetAndTimestampEntry).getValue()).offset());
            }
        } catch (Throwable var17) {
            var7 = var17;
            throw var17;
        } finally {
            if (var7 != null) {
                try {
                    consumer.close();
                } catch (Throwable var16) {
                    var7.addSuppressed(var16);
                }
            } else {
                consumer.close();
            }
        }

        return result;
    }

    protected boolean getIsAutoCommitEnabled() {
        return PropertiesUtil.getBoolean(this.properties, "enable.auto.commit", true) && PropertiesUtil.getLong(this.properties, "auto.commit.interval.ms", 5000L) > 0L;
    }

    private static void setDeserializer(Properties props) {
        String deSerName = ByteArrayDeserializer.class.getName();
        Object keyDeSer = props.get("key.deserializer");
        Object valDeSer = props.get("value.deserializer");
        if (keyDeSer != null && !keyDeSer.equals(deSerName)) {
            LOG.warn("Ignoring configured key DeSerializer ({})", "key.deserializer");
        }

        if (valDeSer != null && !valDeSer.equals(deSerName)) {
            LOG.warn("Ignoring configured value DeSerializer ({})", "value.deserializer");
        }

        props.put("key.deserializer", deSerName);
        props.put("value.deserializer", deSerName);
    }

}
