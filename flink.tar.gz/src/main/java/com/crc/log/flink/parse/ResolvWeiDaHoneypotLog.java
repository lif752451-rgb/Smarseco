package com.crc.log.flink.parse;

import com.crc.log.flink.common.constants.LevelConstants;
import com.crc.log.flink.common.constants.LogConstants;
import com.crc.log.flink.common.utils.DataUtils;
import com.crc.log.flink.common.utils.DateUtils;
import com.crc.log.flink.common.utils.JsonUtils;
import com.crc.log.flink.common.utils.MapUtils;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;

import java.util.LinkedList;
import java.util.List;
import java.util.concurrent.ConcurrentHashMap;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * @author jixiangqi
 * @date 2022/1/11
 * 卫达蜜罐
 */
@Slf4j
public class ResolvWeiDaHoneypotLog {
    public static ConcurrentHashMap<String, Object> parse(String message) {
        try {
            ConcurrentHashMap<String, Object> data = proc(message);
            if (DataUtils.isNotEmptyJson(data)) {
                return data;
            }
        } catch (Exception ignored) {

        }
        return null;
    }

    private static ConcurrentHashMap<String, Object> proc(String jsonStr) {
        ConcurrentHashMap<String, Object> rtnObjc = JsonUtils.createBaseMap(jsonStr);
        Pattern p = Pattern.compile("\\{([^\\}]+)\\}");
        Matcher m = p.matcher(jsonStr);
        List<String> dataList = new LinkedList<>();
        while (m.find()) {
            try {
                String data = m.group().substring(1, m.group().length() - 1);
                dataList.add(data);
            } catch (Exception e) {
                log.error(e.getMessage(),e);
            }
        }
        for (String temp : dataList) {
            String[] data = DataUtils.getSplit(temp, ",");
            //temp.split(",");
            for (String datum : data) {
                String keyValue = datum.replace("\"", "");
                int index = DataUtils.getIndex(keyValue, ":");
                //keyValue.indexOf(":");
                String key = DataUtils.getSubString(keyValue, 0, index).trim();
                //keyValue.substring(0, index).trim();
                String value = DataUtils.getSubString(keyValue, index + 1).trim();
                //keyValue.substring(index+1).trim();
                switchKeyValue(rtnObjc, key, value);
            }
        }
        rtnObjc.put(LogConstants.LOG_LEVEL, LevelConstants.getLevel(MapUtils.getStr(rtnObjc,LogConstants.LOG_LEVEL)));
        if (StringUtils.isBlank(MapUtils.getStr(rtnObjc, LogConstants.SRC_IP))) {
            rtnObjc.put(LogConstants.SRC_IP, "0.0.0.0");
        }
        if (StringUtils.isBlank(MapUtils.getStr(rtnObjc, LogConstants.DEST_IP))) {
            rtnObjc.put(LogConstants.DEST_IP, "0.0.0.0");
        }
        setAlertName(rtnObjc);
        rtnObjc.put(LogConstants.LOG_PRODUCT, "卫达蜜罐");
        return rtnObjc;
    }

    private static void switchKeyValue(ConcurrentHashMap<String, Object> rtnObjc, String key, String value) {
        switch (key) {
            case "syslog_version":
                rtnObjc.put(LogConstants.LOG_VERSION, value);
                break;
            case "dev_code":
                rtnObjc.put(LogConstants.DEVICE_ID, value);
                break;
            case "log_type":
                String logType = "";
                switch (value) {
                    case "1":
                        logType = "渗透日志";
                        break;
                    case "5":
                        logType = "主机封堵日志";
                        break;
                    case "8":
                        logType = "重定向日志";
                        break;
                    case "12":
                        logType = "溯源日志";
                        break;
                }
                rtnObjc.put(LogConstants.LOG_TYPE, logType);
                break;
            case "attack_mac":
                rtnObjc.put(LogConstants.SRC_MAC, value);
                break;
            case "attack_ip":
                rtnObjc.put(LogConstants.SRC_IP, value);
                break;
            case "response_ip":
                rtnObjc.put(LogConstants.DEST_IP, value);
                break;
            case "response_port":
                rtnObjc.put(LogConstants.DEST_PORT, value);
                break;
            case "proto":
                String protoType = "";
                switch (value) {
                    case "1":
                        protoType = "ICMP";
                        break;
                    case "2":
                        protoType = "IGMP";
                        break;
                    case "6":
                        protoType = "TCP";
                        break;
                    case "8":
                        protoType = "EGP";
                        break;
                    case "9":
                        protoType = "IGP";
                        break;
                    case "17":
                        protoType = "UDP";
                        break;
                    case "41":
                        protoType = "IPv6";
                        break;
                    case "47":
                        protoType = "GRE";
                        break;
                    case "50":
                        protoType = "ESP";
                        break;
                    case "51":
                        protoType = "AH";
                        break;
                    case "88":
                        protoType = "EIGRP";
                        break;
                    case "89":
                        protoType = "OSPF";
                        break;
                    case "112":
                        protoType = "VRRP";
                        break;
                    case "115":
                        protoType = "L2TP";
                        break;
                }
                rtnObjc.put(LogConstants.LOG_PROTOCAL, protoType);
                break;
            case "time":
                long time = DataUtils.toNum(value) * 1000L;
                rtnObjc.put(LogConstants.LOG_START_TIME, DateUtils.getISO8601Timestamp(time));
                break;
            case "src_mac":
                rtnObjc.put(LogConstants.SRC_MAC, value);
                break;
            case "sip":
                rtnObjc.put(LogConstants.SRC_IP, value);
                break;
            case "dip":
                rtnObjc.put(LogConstants.DEST_IP, value);
                break;
            case "sport":
                rtnObjc.put(LogConstants.SRC_PORT, value);
                break;
            case "dport":
                rtnObjc.put(LogConstants.DEST_PORT, value);
                break;
            case "type":
                String attackType = "";
                switch (value) {
                    case "1":
                        attackType = "IP";
                        break;
                    case "2":
                        attackType = "MAC";
                        break;
                    case "3":
                        attackType = "MAC + IP";
                        break;
                }
                rtnObjc.put(LogConstants.SRC_MAC, attackType);
                break;
            case "attack_Num":
                rtnObjc.put(LogConstants.LOG_COUNT, value);
                break;
        }
    }

    private static void setAlertName(ConcurrentHashMap<String, Object> rtnObjc) {
        String msgFormat = "";
        String alertName = "";
        String level = MapUtils.getStr(rtnObjc, LogConstants.LOG_LEVEL);
        String srcIp = MapUtils.getStr(rtnObjc, LogConstants.SRC_IP);
        String destIp = MapUtils.getStr(rtnObjc, LogConstants.DEST_IP);
        String proto = MapUtils.getStr(rtnObjc, LogConstants.LOG_PROTOCAL);
        String logType = MapUtils.getStr(rtnObjc, LogConstants.LOG_TYPE);
        String log = MapUtils.getStr(rtnObjc, LogConstants.LOG_ORI_MSG);
        if (!StringUtils.isBlank(proto)) {
            msgFormat = "源IP为:%s对目的IP为:%s发起了一个事件类型为:%s的攻击,攻击协议为:%s,事件级别为:%s,日志详情为:%s";
            alertName = String.format(msgFormat, srcIp, destIp, logType, proto, level, log);
        } else {
            msgFormat = "源IP为:%s对目的IP为:%s发起了一个事件类型为:%s的攻击,事件级别为:%s,日志详情为:%s";
            alertName = String.format(msgFormat, srcIp, destIp, logType, level, log);
        }
        rtnObjc.put(LogConstants.ALERT_NAME, alertName);
    }
}
