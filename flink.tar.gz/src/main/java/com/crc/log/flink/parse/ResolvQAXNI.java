package com.crc.log.flink.parse;

import com.alibaba.fastjson.JSONObject;
import com.crc.log.flink.common.constants.LevelConstants;
import com.crc.log.flink.common.constants.LogConstants;
import com.crc.log.flink.common.utils.DataUtils;
import com.crc.log.flink.common.utils.JsonUtils;
import com.crc.log.flink.common.utils.MapUtils;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;

import java.util.concurrent.ConcurrentHashMap;
@Slf4j
//奇安信上网行为解析类
public class ResolvQAXNI {
    public static boolean parseGood = false;

    public static ConcurrentHashMap<String, Object> parse(String message) {
        try {
            ConcurrentHashMap<String, Object> data = proc(message);
            if (DataUtils.isNotEmptyJson(data)) {
                return data;
            }
        } catch (Exception ignored) {

        }
        return null;
    }

    private static ConcurrentHashMap<String, Object> proc(String value) {
        ConcurrentHashMap<String, Object> ldapJson = JsonUtils.createBaseMap(value);
        try {
            JSONObject dataJson = new JSONObject();
            String jsonStr = value;


            jsonStr = DataUtils.getSubString(jsonStr, DataUtils.getIndex(jsonStr, "NS :"));
            //jsonStr.substring(jsonStr.indexOf("NS :"));


            String[] IPS_buff = jsonStr.split(",");
            for (String s : IPS_buff) {
                String[] datakey = s.split(":");
                if (1 < datakey.length) {
                    dataJson.put(datakey[0].trim(), datakey[1].trim());
                }
            }
            //retData.putAll(dataJson);
            ldapJson.put(LogConstants.LOG_PRODUCT, "奇安信上网行为");
            if (StringUtils.isNotBlank(jsonStr)) {
                MapUtils.setStr(ldapJson, LogConstants.LOG_TYPE, dataJson, "NS");
                MapUtils.setStr(ldapJson, LogConstants.LOG_START_TIME, dataJson, "时间");
                MapUtils.setStr(ldapJson, LogConstants.SRC_ZONE, dataJson, "来源");
                MapUtils.setStr(ldapJson, LogConstants.ACTION_TYPE, dataJson, "类型");
                MapUtils.setStr(ldapJson, LogConstants.OP_NAME, dataJson, "用户");
                MapUtils.setStr(ldapJson, LogConstants.LOG_DESCRIPTION, dataJson, "描述");
                MapUtils.setStr(ldapJson, LogConstants.HOST_NAME, dataJson, "账号");
            }
            ldapJson.put(LogConstants.LOG_LEVEL, LevelConstants.getLevel(MapUtils.getStr(ldapJson,LogConstants.LOG_LEVEL)));
            if (StringUtils.isBlank(MapUtils.getStr(ldapJson, LogConstants.SRC_IP))) {
                ldapJson.put(LogConstants.SRC_IP, "0.0.0.0");
            }
            if (StringUtils.isBlank(MapUtils.getStr(ldapJson, LogConstants.DEST_IP))) {
                ldapJson.put(LogConstants.DEST_IP, "0.0.0.0");
            }
            setAlertName(ldapJson);
            return ldapJson;
        } catch (Exception e) {
            log.error(e.getMessage(), e);
            return ldapJson;
        }
    }

    private static void setAlertName(ConcurrentHashMap<String, Object> ldapJson) {
        String type = MapUtils.getStr(ldapJson, LogConstants.ACTION_TYPE);
        String description = MapUtils.getStr(ldapJson, LogConstants.LOG_DESCRIPTION);
        String event = MapUtils.getStr(ldapJson, LogConstants.LOG_TYPE);
        String log = MapUtils.getStr(ldapJson, LogConstants.LOG_ORI_MSG);
        String msgFormat = "操作类型:%s,事件描述:%s,事件类型:%s,日志详情为:%s";
        String alertName = String.format(msgFormat, type, description, event, log);
        ldapJson.put(LogConstants.ALERT_NAME, alertName);
    }
}

