package com.crc.log.flink.test.log;

import com.crc.log.flink.common.utils.JsonUtils;
import com.crc.log.flink.config.AllConfig;
import com.crc.log.flink.es.DataProcessFuncation;

import java.util.concurrent.ConcurrentHashMap;

/**
 * @author jixiangqi
 * @date 2022/3/8
 */
public class ResolvHuiDunUESLogTest {

    public static void main(String[] args) {
        AllConfig config = new AllConfig();
        DataProcessFuncation.CONIFG = config;
        config.setMode("single");
        config.setParse("ResolvHuiDunUESLog");
        config.setIndex("sec_all");
        String str = "2022-03-07T09:49:38+08:00 rlkj-sec-txioa-prd-ioazk-01 /data/services/pcmgr_enterprise/public/service/event_deliver/bin/event_deliver[12718]: {\"_type\":\"VirusHandle\",\"recvTime\":\"2022-03-07T09:49:38+08:00\",\"sender\":{\"_type\":\"Terminal\",\"mid\":\"8CFFFBD3A05B3CF8FB72FEBF7C31F547606E9C0E\",\"publicIP\":\"10.54.228.177\",\"clientVersion\":\"106.8.10637.5501\",\"client\":{\"IpPort\":\"10.54.228.177\",\"Mid\":\"8CFFFBD3A05B3CF8FB72FEBF7C31F547606E9C0E\",\"Guid\":\"8CFFFBD3A05B3CF8FB72FEBF7C31F547\",\"Mac\":\"3C:F0:11:7B:32:CF\",\"Name\":\"sz-85-raoxi\",\"User\":\"raoxi\",\"OSType\":0,\"OS\":\"Microsoft Windows 10 专业版\",\"GroupIDPath\":\"1.1139.2693.3261.2330.2306.2332.3277.3206\",\"GroupNamePath\":\"全网终端.账号树.华润数科.crhd0a.00_CRH_BU.01-华润(集团)有限公司.05-集团财务部.SZ.Accounts\",\"Account\":\"raoxi\",\"Version\":29836382588179837},\"src\":null},\"args\":{\"virusName\":\"Win32.Packed.Asprotect.lhnh(aiScore=m)\",\"filePath\":\"D:\\\\raoxi\\\\培训\\\\新建文件夹\\\\FSCaptureSetup80_Portable\\\\FSCapture.exe\",\"fileMD5\":\"352da2ea1dfe6f9f6052ab1c11447149\",\"result\":\"succeed\",\"src\":{\"CallType\":2,\"FixResult\":1,\"FixType\":2,\"IsSysRep\":0,\"Md5\":\"352da2ea1dfe6f9f6052ab1c11447149\",\"Name\":\"Win32.Packed.Asprotect.lhnh(aiScore=m)\",\"Path\":\"D:\\\\raoxi\\\\培训\\\\新建文件夹\\\\FSCaptureSetup80_Portable\\\\FSCapture.exe\",\"Src\":1,\"SysrepVer\":\"2022.01.06.16.54.08\",\"TavLibVer\":\"2.0.13574.7771\",\"Type\":2,\"VirusType\":\"壳类病毒\",\"riskdesc\":\"强壳程序，恶意程序通常使用加强壳的手段来逃逸反病毒软件的识别。\",\"riskname\":\"D:\\\\raoxi\\\\培训\\\\新建文件夹\\\\FSCaptureSetup80_Portable\\\\FSCapture.exe\"}}}";
        ConcurrentHashMap<String, Object> proc = DataProcessFuncation.parse(str,"index");
        JsonUtils.printStr(proc);

        str = "2022-03-07T09:49:38+08:00 rlkj-sec-txioa-prd-ioazk-02 /data/services/pcmgr_enterprise/public/service/event_deliver/bin/event_deliver[18653]: {\"_type\":\"VirusHandle\",\"recvTime\":\"2022-03-07T09:49:38+08:00\",\"sender\":{\"_type\":\"Terminal\",\"mid\":\"8CFFFBD3A05B3CF8FB72FEBF7C31F547606E9C0E\",\"publicIP\":\"10.54.228.177\",\"clientVersion\":\"106.8.10637.5501\",\"client\":{\"IpPort\":\"10.54.228.177\",\"Mid\":\"8CFFFBD3A05B3CF8FB72FEBF7C31F547606E9C0E\",\"Guid\":\"8CFFFBD3A05B3CF8FB72FEBF7C31F547\",\"Mac\":\"3C:F0:11:7B:32:CF\",\"Name\":\"sz-85-raoxi\",\"User\":\"raoxi\",\"OSType\":0,\"OS\":\"Microsoft Windows 10 专业版\",\"GroupIDPath\":\"1.1139.2693.3261.2330.2306.2332.3277.3206\",\"GroupNamePath\":\"全网终端.账号树.华润数科.crhd0a.00_CRH_BU.01-华润(集团)有限公司.05-集团财务部.SZ.Accounts\",\"Account\":\"raoxi\",\"Version\":29836382588179837},\"src\":null},\"args\":{\"virusName\":\"OLE.Win32.Macro.700048\",\"filePath\":\"D:\\\\BU\\\\数科\\\\数科2022商业计划\\\\数科商业计划\\\\附件2：2022年现金预算及预计财务报表-华润数科-报送版2.xlsm --\\u003e xl\\\\vbaProject.bin\",\"fileMD5\":\"6060edc527bcc0fd9501acf97dc60e65\",\"result\":\"succeed\",\"src\":{\"CallType\":2,\"FixResult\":1,\"FixType\":2,\"IsSysRep\":0,\"Md5\":\"6060edc527bcc0fd9501acf97dc60e65\",\"Name\":\"OLE.Win32.Macro.700048\",\"Path\":\"D:\\\\BU\\\\数科\\\\数科2022商业计划\\\\数科商业计划\\\\附件2：2022年现金预算及预计财务报表-华润数科-报送版2.xlsm --\\u003e xl\\\\vbaProject.bin\",\"Src\":1,\"SysrepVer\":\"2022.01.06.16.54.08\",\"TavLibVer\":\"2.0.13574.7771\",\"Type\":2,\"VirusType\":\"宏病毒\",\"riskdesc\":\"宏病毒，寄生在Office文档或共用模板的宏中，运行之后会被激活并感染其他的Office文档。\",\"riskname\":\"D:\\\\BU\\\\数科\\\\数科2022商业计划\\\\数科商业计划\\\\附件2：2022年现金预算及预计财务报表-华润数科-报送版2.xlsm --\\u003e xl\\\\vbaProject.bin\"}}}";
        proc = DataProcessFuncation.parse(str,"index");
        JsonUtils.printStr(proc);

        str = "2022-03-04T20:06:38+08:00 rlkj-sec-txioa-prd-ioazk-02 /data/services/pcmgr_enterprise/public/service/event_deliver/bin/event_deliver[18653]: {\"_type\":\"VirusHandle\",\"recvTime\":\"2022-03-04T20:06:38+08:00\",\"sender\":{\"_type\":\"Terminal\",\"mid\":\"881CFE34C07B5753526691074CE9CFFA619F0E98\",\"publicIP\":\"10.66.30.48\",\"clientVersion\":\"106.8.10637.5501\",\"client\":{\"IpPort\":\"10.66.30.48\",\"Mid\":\"881CFE34C07B5753526691074CE9CFFA619F0E98\",\"Guid\":\"881CFE34C07B5753526691074CE9CFFA\",\"Mac\":\"98:22:EF:CA:F4:3B\",\"Name\":\"DESKTOP-KAHOEDH\",\"User\":\"NINGCHANGYI\",\"OSType\":0,\"OS\":\"Microsoft Windows 10 专业版\",\"GroupIDPath\":\"1.1139.2693.3261.2330.2306.2628.2974\",\"GroupNamePath\":\"全网终端.账号树.华润数科.crhd0a.00_CRH_BU.01-华润(集团)有限公司.13-集团群众工作部.无需启用邮箱的账号\",\"Account\":\"NINGCHANGYI\",\"Version\":29836382588179837},\"src\":null},\"args\":{\"virusName\":\"Html.Win32.Script.1500803\",\"filePath\":\"E:\\\\03.水泥学院\\\\04.M-领导力\\\\06.TWI\\\\云水TWI讲师赋能培训\\\\完美演绎（V3-简版）.pptx --\\u003e ppt\\\\media\\\\image30.gif\",\"fileMD5\":\"a402bfe4f253df2a18fadeba411ef27f\",\"result\":\"fail\",\"src\":{\"CallType\":2,\"FixResult\":0,\"FixType\":2,\"IsSysRep\":0,\"Md5\":\"a402bfe4f253df2a18fadeba411ef27f\",\"Name\":\"Html.Win32.Script.1500803\",\"Path\":\"E:\\\\03.水泥学院\\\\04.M-领导力\\\\06.TWI\\\\云水TWI讲师赋能培训\\\\完美演绎（V3-简版）.pptx --\\u003e ppt\\\\media\\\\image30.gif\",\"Src\":1,\"SysrepVer\":\"2022.01.06.16.54.08\",\"TavLibVer\":\"2.0.13574.7771\",\"Type\":2,\"VirusType\":\"脚本病毒\",\"riskdesc\":\"脚本病毒，运行后会篡改IE首页、注册表，访问网站时候有可能会泄露个人隐私，或下载更多的病毒木马。\",\"riskname\":\"E:\\\\03.水泥学院\\\\04.M-领导力\\\\06.TWI\\\\云水TWI讲师赋能培训\\\\完美演绎（V3-简版）.pptx --\\u003e ppt\\\\media\\\\image30.gif\"}}}";
        proc = DataProcessFuncation.parse(str,"index");
        JsonUtils.printStr(proc);

        str = "2022-03-09T08:39:00+08:00 rlkj-sec-txioa-prd-ioazk-01 /data/services/pcmgr_enterprise/public/service/event_deliver/bin/event_deliver[12718]: {\"_type\":\"VulHandle\",\"recvTime\":\"2022-03-09T08:39:00+08:00\",\"sender\":{\"_type\":\"Terminal\",\"mid\":\"7F0FAD9C13C41E26D754B96334000D90618CB7FD\",\"publicIP\":\"10.86.28.92\",\"clientVersion\":\"106.6.10285.5503\",\"client\":{\"IpPort\":\"10.86.28.92\",\"Mid\":\"7F0FAD9C13C41E26D754B96334000D90618CB7FD\",\"Guid\":\"7F0FAD9C13C41E26D754B96334000D90\",\"Mac\":\"28:DF:EB:AA:77:56\",\"Name\":\"SZ-LG-WANGBB\",\"User\":\"Administrator\",\"OSType\":0,\"OS\":\"Microsoft Windows 10 企业版\",\"GroupIDPath\":\"1.2\",\"GroupNamePath\":\"全网终端.未分组终端\",\"Account\":\"\",\"Version\":29836373975176575},\"src\":null},\"args\":{\"kb\":5008876,\"result\":\"notHandle\",\"src\":{\"FixAction\":3,\"FixResult\":1,\"IgnoreType\":0,\"IsDownPatch\":0,\"KB\":5008876,\"ScanId\":1646786279,\"ScanType\":13,\"SecLevel\":2,\"TaskId\":0}}}";
        proc = DataProcessFuncation.parse(str,"index");
        JsonUtils.printStr(proc);

        str = "2022-03-09T10:31:36+08:00 rlkj-sec-txioa-prd-ioazk-01 /data/services/pcmgr_enterprise/public/service/event_deliver/bin/event_deliver[12718]: {\"_type\":\"DefenseHandle\",\"recvTime\":\"2022-03-09T10:31:36+08:00\",\"sender\":{\"_type\":\"Terminal\",\"mid\":\"19F00FF79C2B6C121A8B11C23C93CE086080C9EC\",\"publicIP\":\"10.54.20.114\",\"clientVersion\":\"106.8.10637.5501\",\"client\":{\"IpPort\":\"10.54.20.114\",\"Mid\":\"19F00FF79C2B6C121A8B11C23C93CE086080C9EC\",\"Guid\":\"BB10593944B6C3246482046808C6DB51\",\"Mac\":\"A8:7E:EA:05:0F:37\",\"Name\":\"SZ-30-PF2B1NR1\",\"User\":\"\",\"OSType\":0,\"OS\":\"Microsoft Windows 10 企业版 LTSC\",\"GroupIDPath\":\"1.1139.2693.3261.2330.7892.7897\",\"GroupNamePath\":\"全网终端.账号树.华润数科.crhd0a.00_CRH_BU.322-华润数科控股有限公司.无需启用邮箱的账号\",\"Account\":\"BEYONDSOFT-173\",\"Version\":29836382588179837},\"src\":null},\"args\":{\"riskName\":\"有程序在修改URL协议关联\",\"result\":\"allow\",\"monitorId\":13301,\"optProcPath\":\"C:\\\\Users\\\\BEYONDSOFT-173\\\\AppData\\\\Local\\\\Postman\\\\app-8.0.7\\\\Postman.exe\",\"optThreadPath\":\"\",\"subFilePath\":\"\",\"attack_time\":1646793069,\"command_line\":[\"\\\"c:\\\\users\\\\beyondsoft-173\\\\appdata\\\\local\\\\postman\\\\app-8.0.7\\\\postman.exe\\\" \"]}}";
        proc = DataProcessFuncation.parse(str,"index");
        JsonUtils.printStr(proc);
    }

}
