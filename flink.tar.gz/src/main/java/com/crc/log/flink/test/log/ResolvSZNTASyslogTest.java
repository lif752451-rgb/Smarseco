package com.crc.log.flink.test.log;

import com.crc.log.flink.common.utils.JsonUtils;
import com.crc.log.flink.config.AllConfig;
import com.crc.log.flink.es.DataProcessFuncation;

import java.util.concurrent.ConcurrentHashMap;

/**
 * @author jixiangqi
 * @date 2022/5/19
 */
public class ResolvSZNTASyslogTest {

    public static void main(String[] args) {
        String str = "18-May-2022 18:57:34.202 警告 [com.mchange.v2.async.ThreadPoolAsynchronousRunner$PoolThread-#2] com.mchange.v2.resourcepool.BasicResourcePool$AcquireTask.run com.mchange.v2.resourcepool.BasicResourcePool$AcquireTask@714a3c9f -- Acquisition Attempt Failed!!! Clearing pending acquires. While trying to acquire a needed new resource, we failed to succeed more than the maximum number of allowed acquisition attempts (3).";
        AllConfig config = new AllConfig();
        DataProcessFuncation.CONIFG = config;
        config.setMode("single");
        config.setParse("ResolvSZNTASyslog");
        config.setIndex("sec_all");

        ConcurrentHashMap<String, Object> json = DataProcessFuncation.parse(str, "index");
        JsonUtils.printStr(json);
    }

}
