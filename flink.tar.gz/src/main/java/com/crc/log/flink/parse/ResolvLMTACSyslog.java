package com.crc.log.flink.parse;

import com.alibaba.fastjson.JSONArray;
import com.alibaba.fastjson.JSONObject;
import com.crc.log.flink.common.constants.LogConstants;
import com.crc.log.flink.common.utils.DataUtils;
import com.crc.log.flink.common.utils.DateUtils;
import com.crc.log.flink.common.utils.JsonUtils;
import com.crc.log.flink.common.utils.MapUtils;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;

import java.util.concurrent.ConcurrentHashMap;

/**
 * @author jixiangqi
 * @date 2022/5/6
 * 绿盟沙箱
 */
@Slf4j
public class ResolvLMTACSyslog {
    public static ConcurrentHashMap<String, Object> parse(String message) {
        try {
            ConcurrentHashMap<String, Object> data = proc(message);
            if (DataUtils.isNotEmptyJson(data)) {
                return data;
            }
        } catch (Exception ignored) {

        }
        return null;
    }

    private static ConcurrentHashMap<String, Object> proc(String jsonStr) {
        ConcurrentHashMap<String, Object> rtnObjc = JsonUtils.createBaseMap(jsonStr);
        String[] split = DataUtils.getSplit(jsonStr, ";");
        for (String s : split) {
            String tempStr = s.trim();
            if (tempStr.contains(":")) {
                int index = DataUtils.getIndex(tempStr, ":");
                String key = DataUtils.getSubString(tempStr, 0, index).trim().replaceAll("\"", "");
                if (key.contains(">")) {
                    int index1 = DataUtils.getIndex(key, ">");
                    key = DataUtils.getSubString(key, index1 + 1);
                }
                String value = DataUtils.getSubString(tempStr, index + 1).trim();
                switchKeyValue(rtnObjc, key, value);
            }
        }
        if (StringUtils.isBlank(MapUtils.getStr(rtnObjc, LogConstants.SRC_IP))) {
            rtnObjc.put(LogConstants.SRC_IP, "0.0.0.0");
        }
        if (StringUtils.isBlank(MapUtils.getStr(rtnObjc, LogConstants.DEST_IP))) {
            rtnObjc.put(LogConstants.DEST_IP, "0.0.0.0");
        }
        rtnObjc.put(LogConstants.LOG_PRODUCT, "绿盟沙箱");
        setAlertName(rtnObjc);
        return rtnObjc;
    }


    private static void setAlertName(ConcurrentHashMap<String, Object> rtnObjc) {
        String srcIp = MapUtils.getStr(rtnObjc, LogConstants.SRC_IP);
        String destIp = MapUtils.getStr(rtnObjc, LogConstants.DEST_IP);
        String log = MapUtils.getStr(rtnObjc, LogConstants.LOG_ORI_MSG);
        String message = "";
        String alertName = "";
        if (!srcIp.equals("0.0.0.0") && !destIp.equals("0.0.0.0")) {
            String logLevel = MapUtils.getStr(rtnObjc, LogConstants.LOG_LEVEL);
            message = "IP为:%s对IP为:%s产生了一个告警,告警级别为:%s,日志详情为:%s";
            alertName = String.format(message, srcIp, destIp, logLevel, log);
        } else {
            message = "用户名为:%s在IP地址为:%s的设备上产生了一条告警信息，日志详情为:%s";
            String userName = MapUtils.getStr(rtnObjc, LogConstants.USER_NAME);
            String devIp = MapUtils.getStr(rtnObjc, LogConstants.LOG_DEV_IP);
            alertName = String.format(message, userName, devIp, log);
        }
        rtnObjc.put(LogConstants.ALERT_NAME, alertName);
    }


    private static void switchKeyValue(ConcurrentHashMap<String, Object> rtnObjc, String key, String value) {
        switch (key) {
            case "user":
                rtnObjc.put(LogConstants.USER_NAME, value);
                break;
            case "loginip":
                rtnObjc.put(LogConstants.LOG_DEV_IP, value);
                break;
            case "time":
                rtnObjc.put(LogConstants.LOG_START_TIME, DateUtils.getISO8601Timestamp(value.trim(), "yyyy-MM-dd HH:mm:ss"));
                break;
            case "ip":
                rtnObjc.put(LogConstants.LOG_DEV_IP, value);
                break;
            case "data":
                try {
                    JSONObject jsonObject = JSONObject.parseObject(value);
                    jsonObject.forEach((k1, v1) -> {
                        if (k1.equals("threat_info") || k1.equals("network") || k1.equals("dropped")) {
                            JSONArray jsonArray = JSONArray.parseArray(String.valueOf(v1));
                            for (Object o : jsonArray) {
                                String string = o.toString();
                                JSONObject jsonObject1 = JSONObject.parseObject(string);
                                jsonObject1.forEach((k, v) -> {
                                    switchKeyValue(rtnObjc, k, String.valueOf(v));
                                });
                            }
                        } else {
                            JSONObject jsonObject1 = JSONObject.parseObject(String.valueOf(v1));
                            jsonObject1.forEach((k, v) -> {
                                switchKeyValue(rtnObjc, k, String.valueOf(v));
                            });
                        }
                    });
                } catch (Exception e) {
                    log.error(e.getMessage(), e);
                }
                break;
            case "threat_info":
                try {
                    JSONObject jsonObject = JSONObject.parseObject(value);
                    jsonObject.forEach((k, v) -> {
                        switchKeyValue(rtnObjc, k, String.valueOf(v));
                    });
                } catch (Exception e) {
                    log.error(e.getMessage(),e);
                }
                break;
            case "threat_name":
                rtnObjc.put(LogConstants.THREAT_NAME, value);
                break;
            case "threat_level":
                rtnObjc.put(LogConstants.LOG_LEVEL, value);
                break;
            case "behavior":
                rtnObjc.put(LogConstants.BEHAVIOR_TAG, value);
                break;
            case "session_info":
                try {
                    JSONObject jsonObject = JSONObject.parseObject(value);
                    jsonObject.forEach((k, v) -> {
                        switchKeyValue(rtnObjc, k, String.valueOf(v));
                    });
                } catch (Exception e) {
                    log.error(e.getMessage(), e);
                }
                break;
            case "sip":
                rtnObjc.put(LogConstants.SRC_IP, value);
                break;
            case "protocol":
                rtnObjc.put(LogConstants.LOG_PROTOCAL, value);
                break;
            case "dport":
                rtnObjc.put(LogConstants.DEST_PORT, value);
                break;
            case "sport":
                rtnObjc.put(LogConstants.SRC_PORT, value);
                break;
            case "dip":
                rtnObjc.put(LogConstants.DEST_IP, value);
                break;
            case "action":
                rtnObjc.put(LogConstants.ACTION_TYPE, value);
                break;
            case "process":
                rtnObjc.put(LogConstants.PROCESS_NAME, value);
                break;
        }
    }

}
