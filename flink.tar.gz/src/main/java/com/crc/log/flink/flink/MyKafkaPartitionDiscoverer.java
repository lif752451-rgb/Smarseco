package com.crc.log.flink.flink;

import com.crc.log.flink.common.utils.DataUtils;
import com.crc.log.flink.common.utils.StringUtils;
import lombok.extern.slf4j.Slf4j;
import org.apache.flink.streaming.connectors.kafka.internals.AbstractPartitionDiscoverer;
import org.apache.flink.streaming.connectors.kafka.internals.KafkaTopicPartition;
import org.apache.flink.streaming.connectors.kafka.internals.KafkaTopicsDescriptor;
import org.apache.flink.util.Preconditions;
import org.apache.kafka.clients.consumer.KafkaConsumer;
import org.apache.kafka.common.PartitionInfo;

import java.util.*;
import java.util.stream.Collectors;

/**
 * @author jixiangqi
 * @date 2022/4/21
 * 自定义flink消费Kafka
 */
@Slf4j
public class MyKafkaPartitionDiscoverer extends AbstractPartitionDiscoverer {

    private final Properties kafkaProperties;
    private KafkaConsumer<?, ?> kafkaConsumer;
    private final String partitionNo;


    public MyKafkaPartitionDiscoverer(KafkaTopicsDescriptor topicsDescriptor, int indexOfThisSubtask, int numParallelSubtasks,
                                      Properties kafkaProperties, String partition) {
        super(topicsDescriptor, indexOfThisSubtask, numParallelSubtasks);
        this.kafkaProperties = Preconditions.checkNotNull(kafkaProperties);
        this.partitionNo = partition;
    }

    protected void initializeConnections() {
        this.kafkaConsumer = new KafkaConsumer<>(this.kafkaProperties);
    }

    protected List<String> getAllTopics() throws WakeupException {
        try {
            return new ArrayList<>(this.kafkaConsumer.listTopics().keySet());
        } catch (org.apache.kafka.common.errors.WakeupException var2) {
            throw new WakeupException();
        }
    }

    protected List<KafkaTopicPartition> getAllPartitionsForTopics(List<String> topics) throws WakeupException, RuntimeException {
        LinkedList<KafkaTopicPartition> partitions = new LinkedList<>();

        try {
            for (String topic : topics) {
                List<PartitionInfo> kafkaPartitions = this.kafkaConsumer.partitionsFor(topic);
                if (kafkaPartitions == null) {
                    throw new RuntimeException(String.format("Could not fetch partitions for %s. Make sure that the topic exists.", topic));
                }
                if (StringUtils.isBlank(this.partitionNo)) {
                    kafkaPartitions.forEach(v->{
                        partitions.add(new KafkaTopicPartition(v.topic(), v.partition()));
                    });
                }else {
                    List<Integer> partitionList = kafkaPartitions.stream().map(PartitionInfo::partition).collect(Collectors.toList());
                    Iterator<PartitionInfo> var6 = kafkaPartitions.iterator();
                    PartitionInfo partitionInfo = var6.next();
                    String[] split = DataUtils.getSplit(this.partitionNo, ",");
                    StringBuilder sb = new StringBuilder();
                    for (String s : split) {
                        int num = DataUtils.toNum(s);
                        if (partitionList.contains(num)) {
                            partitions.add(new KafkaTopicPartition(partitionInfo.topic(), num));
                            sb.append(num).append(",");
                        } else {
                            System.err.println(topic + "主题下不存在" + num + "的分区");
                        }
                    }
                    log.info(topic + "主题下消费的分区为：" + sb);
                }
            }
            return partitions;
        } catch (org.apache.kafka.common.errors.WakeupException var8) {
            throw new WakeupException();
        }
    }

    protected void wakeupConnections() {
        if (this.kafkaConsumer != null) {
            this.kafkaConsumer.wakeup();
        }

    }

    protected void closeConnections() throws Exception {
        if (this.kafkaConsumer != null) {
            this.kafkaConsumer.close();
            this.kafkaConsumer = null;
        }

    }

}
