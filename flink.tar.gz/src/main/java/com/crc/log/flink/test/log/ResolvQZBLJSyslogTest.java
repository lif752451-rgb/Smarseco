package com.crc.log.flink.test.log;

import com.crc.log.flink.common.utils.JsonUtils;
import com.crc.log.flink.config.AllConfig;
import com.crc.log.flink.es.DataProcessFuncation;

import java.util.concurrent.ConcurrentHashMap;

/**
 * @author jixiangqi
 * @date 2022/5/24
 */
public class ResolvQZBLJSyslogTest {

    public static void main(String[] args) {
        AllConfig config = new AllConfig();
        DataProcessFuncation.CONIFG = config;
        config.setMode("single");
        config.setParse("ResolvQZBLJSyslog");
        config.setIndex("sec_all");


        String str = "<134>May 25 10:59:35 sjnode01 -: AUDITLOG(INFORMATIONAL)(id=AYD5J8Xyiueh4Ref3d_p,service=configlog,identity=admin-lws(管理员-林婉升),from=21.10.63.21,operate=修改资产,object=waf-manage-21.10.34.12,result=成功,details=[资产组集合:[信息安全组]->])";
        ConcurrentHashMap<String, Object> proc = DataProcessFuncation.parse(str, "index");
        JsonUtils.printStr(proc);
    }

}
