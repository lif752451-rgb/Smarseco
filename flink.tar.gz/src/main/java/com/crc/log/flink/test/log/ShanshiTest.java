package com.crc.log.flink.test.log;

import com.crc.log.flink.common.utils.JsonUtils;
import com.crc.log.flink.config.AllConfig;
import com.crc.log.flink.es.DataProcessFuncation;

import java.util.concurrent.ConcurrentHashMap;

public class ShanshiTest {
    public static void main(String[] args) {
        String msg = "<134>Oct 12 10:47:00 localhost fwlog: 日志类型:服务控制或应用控制, 策略名称:禁止服务器访问互联网, 用户:(null), 源IP:10.72.49.189, 源端口:60846, 目的IP:101.227.27.46, 目的端口:80, 应用类型:HTTP应用, 应用名称:any, 系统动作:拒绝";
        a1(msg);
    }

    public static void a1(String msg) {
        AllConfig config = new AllConfig();
        DataProcessFuncation.CONIFG = config;
        config.setMode("single");
        config.setParse("ResolvShanshiFirewallLog");
        config.setIndex("sec_all");


        ConcurrentHashMap<String, Object> json = DataProcessFuncation.parse(msg, "index");
        JsonUtils.printStr(json);
    }
}
