package com.crc.log.flink.common.constants;

public class ActionResultConstants {
    public  final static String DENY = "拦截";
    public  final static String NO_DENY = "放行";
    public  final static String UNKNOWN = "其它";
    public final static String ATTACK_SUCCUSS = "成功";
    public  final static String ATTACK_FAIL = "失败";
}
