package com.crc.log.flink.test.ip;

import com.crc.log.flink.FlinkApplication;
import com.crc.log.flink.config.AllConfig;
import com.crc.log.flink.config.GetSpringBean;
import com.crc.log.flink.net.SegmentTool;

import java.util.List;
import java.util.concurrent.ConcurrentHashMap;

public class IpTest3 {
    public static void main(String[] args) {
        if (FlinkApplication.ALL_CONFIG == null) {
            FlinkApplication.ALL_CONFIG = GetSpringBean.getBean(AllConfig.class);
        }
        int total = 100000;
        List<String> ipList = FakeIp.generateFakeIpGood(total);
        double chance = FakeIp.correctCount(ipList);
        System.out.println("start testing, correct ip count is : " + chance);
        long t1 = System.currentTimeMillis();
        ipList.forEach(SegmentTool.getInstance()::getSegmentByIp);
        long t2 = System.currentTimeMillis();
        System.out.println(total + "  getIPByHalf cost time : " + (t2-t1));
        ipList.forEach(ip->SegmentTool.getInstance().setUserDefineIpSegment(new ConcurrentHashMap<>(),"1",ip));
        long t3 = System.currentTimeMillis();
        System.out.println(total + "  getUserDefineIPByHalf cost time : " + (t3-t2));
    }
}
