package com.crc.log.flink;

import com.crc.log.flink.common.constants.Constants;
import com.crc.log.flink.config.AllConfig;
import com.crc.log.flink.config.GetSpringBean;
import com.crc.log.flink.es.FlinkDataFilter;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.EnableAutoConfiguration;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.autoconfigure.jdbc.DataSourceAutoConfiguration;
import org.springframework.core.env.Environment;

import java.io.InputStream;
import java.net.InetAddress;
import java.nio.charset.StandardCharsets;
import java.util.Arrays;


@Slf4j
@EnableAutoConfiguration(exclude={DataSourceAutoConfiguration.class})
@SpringBootApplication
public class FlinkApplication {
    public static AllConfig ALL_CONFIG = null;

    public static void main(String[] args) throws Exception {
        if (Arrays.asList(args).contains("--version") || Arrays.asList(args).contains("-version")) {
            getVersionInfo();
            System.exit(-1);
        }

        SpringApplication.run(FlinkApplication.class, args);


        try {
            Environment env = GetSpringBean.getBean(Environment.class);
            log.info("\n======================================================\n\t" +
                            "Flink数据解析引擎 成功运行!!! \n\t" +
                            "Auth: \tsmartseco\n\t" +
                            "Access URLs:\t http://{}:{}\n" +
                            "======================================================",
                    InetAddress.getLocalHost().getHostAddress(), env.getProperty("server.port")
            );
        } catch (Exception ignored) {

        }
        try {
            FlinkDataFilter.sinkEs();
        } catch (Exception e) {
            log.error(e.getMessage(), e);
        }
    }

    /**
     * 获取系统版本信息
     */
    private static void getVersionInfo() {
        try (InputStream in = Thread.currentThread().getContextClassLoader().getResourceAsStream("info/version.txt")) {
            if(in != null) {
                byte[] buf = new byte[1024];
                in.read(buf);
                in.close();
                String lines = new String(buf, StandardCharsets.UTF_8);
                if (StringUtils.isEmpty(lines)) {
                    System.err.println("读取 CRC日志解析引擎 当前版本 异常：版本文件为空");
                    return;
                }
                String[] lineLists = lines.split(Constants.Symbol.LINE_FEED);
                System.out.println();
                System.out.println("CRC日志解析引擎 当前版本信息：");
                for (String line : lineLists) {
                    if (line.contains(Constants.SPLIT_LINE)) {
                        break;
                    }
                    log.info(Constants.Symbol.TAB + line);
                }
                System.out.println();
            }
        } catch (Exception e) {
            System.err.println("读取 CRC日志解析引擎 当前版本 异常：" + e.getMessage());
        }
    }
}
