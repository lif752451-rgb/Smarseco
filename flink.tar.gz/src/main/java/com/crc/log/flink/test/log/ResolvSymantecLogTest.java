package com.crc.log.flink.test.log;

import com.crc.log.flink.common.utils.JsonUtils;
import com.crc.log.flink.config.AllConfig;
import com.crc.log.flink.es.DataProcessFuncation;

import java.util.concurrent.ConcurrentHashMap;

/**
 * @author jixiangqi
 * @date 2022/1/13
 */
public class ResolvSymantecLogTest {

    public static void main(String[] args) {
        String str = "<50>Jan 13 13:35:40 D4JTDCSVPWA02 SymantecServer: SZL57PCL63,SHA-256: 0DC86FDC18BB05541EA1F12F6E874894E2166D87370F049F02E60E31CEC64ADA,MD-5: ,[SID: 27570] Web Attack: Malicious File Download 11 攻击已被阻止。 已禁止此应用程序的通信: C:\\USERS\\ADMIN\\DOWNLOADS\\NOTEPAD++_290763063.EXE,本地: 10.114.12.101,本地: 000000000000,远程: ,远程: 119.96.70.244,远程: 000000000000,入站,TCP,Intrusion ID: 0,开始: 2021-10-27 14:20:56,结束: 2021-10-27 14:20:56,出现次数: 1,应用程序: C:/USERS/ADMIN/DOWNLOADS/NOTEPAD++_290763063.EXE,位置: 默认值,用户: admin,域: SZL57PCL63,本地端口 65298,远程端口 80,CIDS 特征 ID: 27570,CIDS 特征字符串: Web Attack: Malicious File Download 11,CIDS 特征子 ID: 67595,入侵 URL: http://download.2345.cn/down/2345Explorer_396263.exe,入侵负载 URL:";
        AllConfig config = new AllConfig();
        DataProcessFuncation.CONIFG = config;
        config.setMode("single");
        config.setParse("ResolvSymantecLog");
        config.setIndex("sec_all");

        ConcurrentHashMap<String, Object> json = DataProcessFuncation.parse(str, "index");
        JsonUtils.printStr(json);


        str = "<54>Apr 27 09:41:03 D4JTDCSVPWA02 SymantecServer: 发现病毒,IP 地址: 10.54.49.63,计算机名: XA-30-M70AQ12W,强防护等级: 0,证书发行机构: 天津珊瑚信息科技有限公司,证书签署人: DigiCert Assured ID Code Signing CA-1,证书指纹: B329C113D2756D4E777B91FF2F7B5BBE359B1D55,签名时间戳: 1647428898,证书序列号: 0837B84B760E63FACF22EFB0FE6A89DE,源: 自动防护扫描,风险名称: Trojan.Gen.2,出现次数: 1,C:\\Program Files (x86)\\BirdWallpaper\\Utils\\staticwp.exe,,实际的操作: 详细信息挂起,请求的操作: 已隔离,次要操作: 已清除,事件时间: 2022-04-27 09:36:40,已插入: 2022-04-27 09:41:03,结束: 2022-04-27 09:36:40,上次更新时间: 2022-04-27 09:41:03,域: 默认值,组: My Company\\办公电脑\\方大城,服务器: D4JTDCSVPWA02,用户: BEYONDSOFT-89,源计算机: ,源 IP: ,部署: 错误,下载站点: ,Web 域: ,下载人: ,流行程度: 有数千位 Symantec 用户查看了此文件。,可信度: 此文件是不可信文件。,URL 跟踪状态: 关,,首次出现: 此检测中未使用信誉。,敏感度: 低,不在允许的应用程序列表中,应用程序哈希: 56179EC33EC75772282577412DC807A2E7D4A1831AEB7955B27217B2FFD52434,哈希类型: SHA2,公司名称: ,应用程序名: 壁纸,应用程序版本: 1.1022.1005.315,应用程序类型: 127,文件大小 (字节): 494584,设置的类别: 恶意软件,类别类型: 病毒,位置: 默认值";
        json = DataProcessFuncation.parse(str, "index");
        JsonUtils.printStr(json);

        str = "<54>Jan 13 11:33:38 D4JTDCSVPWA02 SymantecServer: DESKTOP-VO2UTMC,SHA-256: ,MD-5: ,本地: 0.0.0.0,本地: 16962,本地: 0180C2000000,远程: 0.0.0.0,远程: ,远程: 0,远程: 441AFAAD82B6,7,入站,开始: 2022-01-13 10:57:42,结束: 2022-01-13 10:57:42,出现次数: 1,应用程序: ,规则: 禁止所有其他通信,位置: 默认值,用户: ZhouYuXing,域: DESKTOP-VO2UTMC,操作: 已禁止";
        json = DataProcessFuncation.parse(str, "index");
        JsonUtils.printStr(json);

        str = "<52>Jan 13 13:49:18 D4JTDCSVPWA02 SymantecServer: VDI-89-YQ-21,SHA-256: 5379732000000000000000000000000000000000000000000000000000000000,MD-5: 53797320000000000000000000000000,本地: 10.0.59.255,本地: 137,本地: FFFFFFFFFFFF,远程: 10.0.59.54,远程: ,远程: 137,远程: 005056BCF4DB,UDP,入站,开始: 2022-01-13 13:47:38,结束: 2022-01-13 13:47:42,出现次数: 6,应用程序: C:/Windows/system32/NTOSKRNL.EXE,规则: 禁止本地文件共享,位置: 默认值,用户: none,域: ,操作: 已禁止";
        json = DataProcessFuncation.parse(str, "index");
        JsonUtils.printStr(json);
    }

}
