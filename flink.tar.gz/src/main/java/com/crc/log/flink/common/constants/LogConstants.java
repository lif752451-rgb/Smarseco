package com.crc.log.flink.common.constants;

public class LogConstants {
    /**
     * 日志名称
     */
    public  final static String LOG_NAME = "log_name";
    //事件类型
    public  final static String LOG_TYPE = "event_type";
    //操作结果
    public  final static String ACTION_RESULT = "action_result";
    //操作类型
    public  final static String ACTION_TYPE = "action_type";
    //操作触发规则
    public  final static String ACTION_RULE = "action_rule";
    //操作发生次数
    public  final static String ACTION_TIMES = "action_times";
    //主机名
    public  final static String HOST_NAME = "hostname";
    //目标域名
    public  final static String TARGET_DOMAIN_NAME = "target_domain_name";
    //日志级别
    public  final static String LOG_LEVEL = "log_level";
    //日志可疑/优先级程度
    public  final static String LOG_PRIORITY = "log_priority";
    //原始日志
    public  final static String LOG_ORI_MSG = "zlog_ori_msg";
    //日志时间
    public  final static String LOG_TIME = "SparkTime";
    public  final static String LOG_ID = "SparkId";

    public  final static String LOG_CONTENT = "content";

    //日志源设备IP
    public  final static String LOG_DEV_IP = "dev_ip";

    //源设备信息
    public  final static String SRC_DEV_INFO = "src_dev_info";
    //归属组织
    public  final static String ASSET_OFFICE = "asset_office";
    //外部IP
    public  final static String EXTERNAL_IP = "external_ip";
    //内部IP
    public  final static String INTERNAL_IP = "internal_ip";
    //实例名称
    public  final static String SRC_INSTANCE = "instance";
    //事件ID
    public  final static String EVENT_ID = "event_id";
    //源设备类型
    public  final static String SRC_DEV_TYPE = "src_dev_type";
    //源IP
    public  final static String SRC_IP = "src_ip";
    //源IP类型 外网、内网
    public final static String SRC_IP_TYPE = "src_ip_type";
    //源安全区域
    public  final static String SRC_ZONE = "src_zone";
    //源IP城市
    public  final static String SRC_IP_CITY = "src_ip_city";
    //源IP省份
    public  final static String SRC_IP_PROVINCE = "src_ip_subdivision";
    //源IP国家
    public  final static String SRC_IP_COUNTRY = "src_ip_country";
    //源端口
    public  final static String SRC_PORT = "src_port";
    //源MAC
    public  final static String SRC_MAC = "src_mac";
    //目标IP
    public  final static String DEST_IP = "dest_ip";
    //目标IP类型 外网、内网
    public  final static String DEST_IP_TYPE = "dest_ip_type";
    //目标IP城市
    public  final static String DEST_IP_CITY = "dest_ip_city";
    //目标IP省份
    public  final static String DEST_IP_PROVINCE = "dest_ip_subdivision";
    //目标安全区域
    public  final static String DEST_ZONE = "dest_zone";
    //目标IP国家
    public  final static String DEST_IP_COUNTRY = "dest_ip_country";
    //目标端口
    public  final static String DEST_PORT = "dest_port";
    //所属网段
    public  final static String NET_SCOPE = "net_scope";
    //操作系统信息
    public  final static String OS_INFO = "os_info";

    //网段归属
    public  final static String NET_OFFICE = "net_office";
    //操作用户归属组织
    public  final static String OP_OFFICE = "op_office";
    //操作账户
    public  final static String OP_NAME = "op_name";
    //操作中文名称
    public  final static String OP_CN_NAME = "op_cn_name";
    //消息内容
    public  final static String MSG_CONTENT = "content";
    //事件发生时间
    public  final static String LOG_START_TIME = "log_start_time";
    //事件描述
    public  final static String LOG_DESCRIPTION = "event_description";
    //事件危害
    public  final static String LOG_DAMAGE = "damage";
    //解决方案
    public  final static String LOG_SOLUTION = "solution";
    //事件原理
    public  final static String LOG_PRINCIPLE = "principle";
    //访问协议
    public final static String LOG_PROTOCAL = "protocal";
    //出现次数
    public final static String LOG_COUNT = "log_count";
    //日志源服务器
    public final static String LOG_SERVER = "log_server";
    //使用正则解释是否成功的标识 1成功 0失败
    public final static String LOG_PARSE_STATUS = "log_parse_flag";
    //日志源产品
    public final static String LOG_PRODUCT = "product";
    //事件评分
    public final static String EVENT_SCORE = "event_score";
    //资产IP评分
    public final static String IP_SCORE = "ip_score";
    //事件链接
    public final static String LOG_URL = "log_url";
    //攻击阶段
    public final static String LOG_STAGE = "log_stage";
    //举证
    public final static String LOG_PROOF = "log_proof";

    public final static String ALERT_NAME ="alert_name";

    public final static String BEHAVIOR_TAG="behavior";

    public final static String LOG_TITLE = "log_title";

    public final static String LOG_DNS = "log_dns";

    public final static String LOG_KEYWORD = "keyword_original";

    public final static String LOG_FILENAME = "filename";

    public final static String LOG_GROUP = "group";

    public final static String LOG_APP = "app";

    // 用户名
    public final static String USER_NAME = "user_name";
    // 配置类型
    public final static String CONF_TYPE = "conf_type";
    // 操作过程
    public final static String ACTION_PROCESS = "action_process";
    // 应用
    public final static String LOG_SERV = "log_serv";
    // 位置
    public final static String LOG_SITE = "log_site";
    // 产生日志的终端
    public final static String LOG_TERMINAL_TYPE = "log_terminal_type";
    // 上行流量
    public final static String UP_FLUX = "up_flux";
    // 下行流量
    public final static String DOWN_FLUX = "down_flux";
    // 总流量
    public final static String ALL_FLUX = "all_flux";
    // nat后的源IP
    public final static String NAT_SRC_IP = "nat_src_ip";
    // nat后的源端口
    public final static String NAT_SRC_PORT = "nat_src_port";
    // nat后的目的IP
    public final static String NAT_DEST_IP = "nat_dest_ip";
    // nat后的目的端口
    public final static String NAT_DEST_PORT = "nat_dest_port";

    // 源接口
    public final static String SRC_INTF = "src_intf";
    // 目的接口
    public final static String DST_INTF = "dst_intf";
    // 客户端IP
    public final static String CLIENT_IP = "client_ip";
    // 模块
    public final static String MODULE = "module";
    // 策略id
    public final static String STRATEGY_ID = "strategy_id";
    // 策略名称
    public final static String STRATEGY_NAME = "strategy_name";
    // 规则id
    public final static String RULE_ID = "rule_id";
    // 动作
    public final static String ACTION = "action";
    // 攻击方法
    public final static String ATTACK_DIRECTION = "attack_direction";
    // 漏洞id
    public final static String LOOPHOLE_ID = "loophole_id";
    // 漏洞名称
    public final static String LOOPHOLE_NAME = "loophole_name";

    // 病毒类型
    public final static String VIRUS_TYPE = "virus_type";
    // 病毒名称
    public final static String VIRUS_NAME = "virus_name";
    // 操作对象
    public final static String ACTION_OBJ = "action_obj";
    // 操作对象id
    public final static String ACTION_OBJ_ID = "action_obj_id";
    // 操作对象type
    public final static String ACTION_OBJ_TYPE = "action_obj_type";
    // 注销时间
    public final static String CANCEL_TIME = "cancel_time";
    // 登录时间
    public final static String SING_IN_TIME = "sing_in_time";
    // 登录时长
    public final static String SING_IN_DURATION = "sing_in_duration";
    // 序列号
    public final static String SERIAL_NUMBER = "serial_number";
    // 状态
    public final static String STATUS = "status";
    // NAT 类型
    public final static String NAT_TYPE = "nat_type";
    // 转换后IP
    public final static String TRANS_IP = "trans_ip";
    // 转换后端口
    public final static String TRANS_PORT = "trans_port";
    // 设备类型
    public final static String DEVICE_TYPE = "device_type";
    // 设备名称
    public final static String DEVICE_NAME = "device_name";
    // 设备id
    public final static String DEVICE_ID = "device_id";
    // 设备地址
    public final static String DEVICE_ADDRESS = "device_address";
    // VR_ID
    public final static String VR_ID = "vr_id";
    // 风险类型
    public final static String RISK_TYPE = "risk_type";

    // 源主机
    public final static String SRC_HOST = "src_host";
    // 设备主机
    public final static String DVC_HOST = "dvc_host";
    // 文件大小
    public final static String  FILE_SIZE = "file_size";
    // 文件标签
    public final static String FILE_LABEL = "file_label";
    // 文件路径
    public final static String FILE_PATH = "file_path";
    // 目的MAC地址
    public final static String DEST_MAC = "dest_mac";

    //版本
    public final static String LOG_VERSION = "log_version";

    public final static String RULESET_NAME = "ruleset_name";

    public final static String RULE_NAME = "rule_name";

    public final static String SQL = "sql";

    public final static String GROUP_NAME = "group_name";

    public final static String HONEYPOT_NAME = "honeypot_name";

    public final static String TRAFFIC_DURATION = "traffic_duration";

    public final static String FILE_TYPE = "file_type";

    public final static String THREAT_NAME = "threat_name";

    public final static String THREAT_TYPE = "threat_type";

    public final static String EMAIL_SEND = "email_send";

    public final static String EMAIL_RECEIVER = "email_receiver";

    public final static String EMAIL_CC = "email_cc";

    public final static String RULE_TYPE = "rule_type";

    public final static String SQL_TABLE = "sql_table";

    public final static String ERROR_CODE = "error_code";

    public final static String PROCESS_PATCH = "process_patch";

    public final static String PROCESS_NAME = "process_name";
    //温度
    public final static String TEMPERATURE = "temperature";

    public final static String DISK = "disk";

    public final static String MEMORY = "memory";

    public final static String CPU = "CPU";

    public final static String SESSION_COUNT = "session_count";

    public final static String PHONE = "phone";

    public final static String EMAIL = "email";

    public final static String AGENT_IP = "agent_ip";

    public final static String SN = "sn";

    public final static String IOC = "ioc";

    public final static String STATUS_CODE = "status_code";

    public final static String PASSWORD = "password";
}
