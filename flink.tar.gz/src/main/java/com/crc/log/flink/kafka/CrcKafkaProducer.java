package com.crc.log.flink.kafka;


import com.crc.log.flink.common.utils.MyTheadUtils;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.pool2.impl.GenericObjectPoolConfig;
import org.apache.kafka.clients.producer.Producer;
import org.apache.kafka.clients.producer.ProducerRecord;

import java.util.Properties;
import java.util.concurrent.ArrayBlockingQueue;
@Slf4j
public class CrcKafkaProducer extends Thread {
    private static ProducerPool producerPool;
    public static ArrayBlockingQueue<String> magicQueue = new ArrayBlockingQueue<>(40000);
    private final String kafkaServer;
    private final String topic;

    public CrcKafkaProducer(String kafkaServer, String topic) {
        this.kafkaServer = kafkaServer;
        this.topic = topic;
    }


    public void run() {
        initPool();
        log.info("**************启动Kafka推送到" + topic + "***************");
        try {
            while (true) {
                Producer<String, String> producer = producerPool.getConnection();
                try {
                    while (!magicQueue.isEmpty()) {
                        String msg = magicQueue.poll();
                        try {
                            producer.send(new ProducerRecord<>(topic, msg));
                        } catch (Exception e) {
                            log.error(e.getMessage(),e);
                            producerPool.invalidateConnection(producer);
                            producer = producerPool.getConnection();
                            producer.send(new ProducerRecord<>(topic, msg));
                        }
                    }
                } catch (Exception e) {
                    log.error(e.getMessage(), e);
                } finally {
                    producerPool.returnConnection(producer);
                }
                MyTheadUtils.sleep(10);
            }

        } catch (Exception e) {
            log.error(e.getMessage(), e);
        }
    }


    public void initPool() {
        GenericObjectPoolConfig config = new GenericObjectPoolConfig();
        config.setMaxTotal(30);
        config.setMaxIdle(5);
        config.setMaxWaitMillis(1000);

        /* 参数配置 */
        Properties props = new Properties();
        //这个配置可以设定发送消息后是否需要Broker端返回确认
        //0: 不需要进行确认，速度最快。存在丢失数据的风险。
        //1: 仅需要Leader进行确认，不需要ISR进行确认。是一种效率和安全折中的方式。
        //all: 需要ISR中所有的Replica给予接收确认，速度最慢，安全性最高，但是由于ISR可能会缩小到仅包含一个Replica，所以设置参数为all并不能一定避免数据丢失。
        props.put("bootstrap.servers", kafkaServer);
        //这个配置可以设定发送消息后是否需要Broker端返回确认
        //0: 不需要进行确认，速度最快。存在丢失数据的风险。
        //1: 仅需要Leader进行确认，不需要ISR进行确认。是一种效率和安全折中的方式。
        //all: 需要ISR中所有的Replica给予接收确认，速度最慢，安全性最高，但是由于ISR可能会缩小到仅包含一个Replica，所以设置参数为all并不能一定避免数据丢失。
        props.put("acks", "1");
        props.put("retries", 0);
        props.put("batch.size", 163840);
        props.put("linger.ms", 5);
        props.put("buffer.memory", 33554432);
        props.put("key.serializer", "org.apache.kafka.common.serialization.StringSerializer");
        props.put("value.serializer", "org.apache.kafka.common.serialization.StringSerializer");
        producerPool = new ProducerPool(config, props);
    }
}
