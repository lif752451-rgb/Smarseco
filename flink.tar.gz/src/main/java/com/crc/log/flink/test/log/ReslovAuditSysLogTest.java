package com.crc.log.flink.test.log;

import com.crc.log.flink.common.utils.JsonUtils;
import com.crc.log.flink.config.AllConfig;
import com.crc.log.flink.es.DataProcessFuncation;

import java.util.concurrent.ConcurrentHashMap;

/**
 * @author jixiangqi
 * @date 2021/12/30
 */
public class ReslovAuditSysLogTest {

    public static void main(String[] args) {
        AllConfig config = new AllConfig();
        DataProcessFuncation.CONIFG = config;
        config.setMode("single");
        config.setParse("ReslovAuditSysLog");
        config.setIndex("sec_all");


        String str = "type:logout,flowInBytes:6417047,username:uu,IP:10.123.123.199,userMac:F4:F5:DB:13:02:EF,ssid:ND_Cis\n" +
                "co_TBQ,accessPointMac:00:A3:8E:31:D0:00,terminalPlatform:Android Phone,time:2050-07-12 12:23:1";
        ConcurrentHashMap<String, Object> proc = DataProcessFuncation.parse(str,"index");
        JsonUtils.printStr(proc);

    }

}
