package com.crc.log.flink.test.log;

import com.crc.log.flink.common.utils.JsonUtils;
import com.crc.log.flink.config.AllConfig;
import com.crc.log.flink.es.DataProcessFuncation;

import java.util.concurrent.ConcurrentHashMap;

/**
 * @author jixiangqi
 * @date 2022/1/11
 */
public class ResolvWeiDaHoneypotLogTest {

    public static void main(String[] args) {
        AllConfig config = new AllConfig();
        DataProcessFuncation.CONIFG = config;
        config.setMode("single");
        config.setParse("ResolvWeiDaHoneypotLog");
        config.setIndex("sec_all");

        String str = "<183>Jan 11 13:59:17 10.0.0.2 vedasyslog[2941] {\"syslog_version\":\"1.10.0\",\"dev_code\":\"43c006e9031bb753ec4c6b39\",\"log_type\":1,\"sub_type\":3,\"line_id\":1,\"iface_type\":1,\"vlan_id\":163,\"attack_mac\":\"60:a4:4c:50:7f:49\",\"attack_ip\":\"172.16.30.253\",\"response_ip\":\"172.16.30.52\",\"response_port\":0,\"proto\":1,\"time\":\"1641880757\"}";
        ConcurrentHashMap<String, Object> proc = DataProcessFuncation.parse(str,"index");
        JsonUtils.printStr(proc);


        str = "<183>Jan 11 13:59:17 10.0.0.2 vedasyslog[2941] {\"syslog_version\":\"1.10.0\",\"dev_code\":\"43c006e9031bb753ec4c6b39\",\"log_type\":1,\"sub_type\":3,\"line_id\":1,\"iface_type\":1,\"vlan_id\":163,\"attack_mac\":\"60:a4:4c:50:7f:49\",\"attack_ip\":\"172.16.30.253\",\"response_ip\":\"172.16.30.52\",\"response_port\":0,\"proto\":1,\"time\":\"1641880757\"}";
        proc = DataProcessFuncation.parse(str,"index");
        JsonUtils.printStr(proc);

        str = "<183>Jan 11 04:32:10 10.0.0.2  2022-01-10T28:32:10.971959Z 10.0.0.2 vedasyslog 2941 NO_USE - {\"syslog_version\":\"1.10.0\",\"dev_code\":\"43c006e9031bb753ec4c6b39\",\"log_type\":1,\"sub_type\":3,\"line_id\":1,\"iface_type\":1,\"vlan_id\":177,\"attack_mac\":\"90:fb:a6:19:83:b7\",\"attack_ip\":\"172.16.170.226\",\"response_ip\":\"172.16.170.54\",\"response_port\":0,\"proto\":1,\"time\":\"1641846730\"}";
        proc = DataProcessFuncation.parse(str,"index");
        JsonUtils.printStr(proc);

        str = "<183>Jan 11 03:28:10 10.0.0.2  2022-01-10T27:28:10.898320Z 10.0.0.2 vedasyslog 2941 NO_USE - {\"syslog_version\":\"1.10.0\",\"dev_code\":\"43c006e9031bb753ec4c6b39\",\"log_type\":1,\"sub_type\":3,\"line_id\":1,\"iface_type\":1,\"vlan_id\":177,\"attack_mac\":\"90:fb:a6:19:83:b7\",\"attack_ip\":\"172.16.170.226\",\"response_ip\":\"172.16.170.52\",\"response_port\":0,\"proto\":1,\"time\":\"1641842890\"}";
        proc = DataProcessFuncation.parse(str,"index");
        JsonUtils.printStr(proc);

        str = "<183>Jan 11 00:15:37 10.0.0.2  2022-01-10T24:15:37.426543Z 10.0.0.2 vedasyslog 2941 NO_USE - {\"syslog_version\":\"1.10.0\",\"dev_code\":\"43c006e9031bb753ec4c6b39\",\"log_type\":1,\"sub_type\":3,\"line_id\":1,\"iface_type\":1,\"vlan_id\":177,\"attack_mac\":\"90:fb:a6:19:83:b7\",\"attack_ip\":\"172.16.170.226\",\"response_ip\":\"172.16.170.51\",\"response_port\":0,\"proto\":1,\"time\":\"1641831337\"}";
        proc = DataProcessFuncation.parse(str,"index");
        JsonUtils.printStr(proc);

        str = "<174>{\"syslog_version\":\"1.0\",\"dev_code\":\"8a16ac0246bdd1a3\",\"log_type\":8,\"sub_t\n" +
                "ype\":1,\"line_id\":1,\"iface_type\":1,\"vlan_id\":0,\"src_mac\":\"6c:4b:90:c9:67:4d\",\"sip\":\"1\n" +
                "92.168.3.1\",\"dip\":\"192.168.3.5\",\"sport\":16,\"dport\":80,\"rline_id\":31,\"rvlan_id\":100,\n" +
                "\"rsip\":\"192.168.5.5\",\"dsip\":\"192.168.6.5\",\"rsport\":80,\"rdport\":3389,\"proto\":6,\"tim\n" +
                "e\":\"20170927083439\"}";
        proc = DataProcessFuncation.parse(str,"index");
        JsonUtils.printStr(proc);
    }

}
