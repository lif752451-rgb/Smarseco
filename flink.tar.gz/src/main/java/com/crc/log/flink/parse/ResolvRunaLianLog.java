package com.crc.log.flink.parse;

import com.crc.log.flink.common.constants.LevelConstants;
import com.crc.log.flink.common.constants.LogConstants;
import com.crc.log.flink.common.utils.DataUtils;
import com.crc.log.flink.common.utils.DateUtils;
import com.crc.log.flink.common.utils.JsonUtils;
import com.crc.log.flink.common.utils.MapUtils;
import org.apache.commons.lang3.StringUtils;

import java.util.concurrent.ConcurrentHashMap;

/**
 * @author jixiangqi
 * @date 2022/7/15
 */
public class ResolvRunaLianLog {
    /**
     * 通用日志 日志泛化
     */
    public static ConcurrentHashMap<String,Object> parse(String message) {
        try {
            ConcurrentHashMap<String,Object> data = proc(message);
            if (DataUtils.isNotEmptyJson(data)) {
                return data;
            }
        } catch (Exception ignored) {

        }
        return null;
    }

    private static ConcurrentHashMap<String,Object> proc(String jsonStr) {
        ConcurrentHashMap<String,Object> rtnObjc = JsonUtils.createBaseMap(jsonStr);
        int lastIndex = DataUtils.getLastIndex(jsonStr, "]");
        jsonStr = DataUtils.getSubString(jsonStr, lastIndex+1);
        String[] split = DataUtils.getSplit(jsonStr, ",");
        for (String temp : split) {
            if (temp.contains("=")) {
                String[] keyValue = DataUtils.getSplit(temp, "=");
                if (keyValue.length == 2) {
                    for (int j = 0; j < keyValue.length; j++) {
                        String key = keyValue[0].trim().toLowerCase();
                        String value = keyValue[1].trim();
                        switch (key) {
                            case "dttime":
                                rtnObjc.put(LogConstants.LOG_START_TIME, DateUtils.getISO8601Timestamp(value.trim(), "yyyy-MM-dd HH:mm:ss"));
                                break;
                            case "strusername":
                                rtnObjc.put(LogConstants.OP_NAME, value);
                                break;
                            case "uidrecordid":
                                rtnObjc.put(LogConstants.EVENT_ID, value);
                                break;
                            case "strdevname":
                                rtnObjc.put(LogConstants.DEVICE_NAME, value);
                                break;
                            case "strdevip":
                                rtnObjc.put(LogConstants.LOG_DEV_IP, value);
                                break;

                            case "strdesc":
                                rtnObjc.put(LogConstants.LOG_DESCRIPTION, value);
                                break;
                            case "iisblocked":
                                if (value.equals("1")) {
                                    rtnObjc.put(LogConstants.ACTION_RESULT, "阻止");
                                } else {
                                    rtnObjc.put(LogConstants.EVENT_ID, "不阻止");
                                }
                                break;
                            case "iaction":
                                rtnObjc.put(LogConstants.ACTION_TYPE, value);
                                break;
                            case "ioperatedevtype":
                                rtnObjc.put(LogConstants.DEVICE_TYPE, value);
                                break;
                            case "uiddevrecordid":
                                rtnObjc.put(LogConstants.DEVICE_ID, value);
                                break;
                            case "ioperatetype":
                                String operator = "";
                                switch (value) {
                                    case "1":
                                        operator = "读";
                                        break;
                                    case "2":
                                        operator = "写";
                                        break;
                                    case "4":
                                        operator = "复制";
                                        break;
                                    case "5":
                                        operator = "剪切";
                                        break;
                                    case "7":
                                        operator = "删除文件";
                                        break;
                                    case "8":
                                        operator = "导入文件";
                                        break;
                                    case "9":
                                        operator = "导出";
                                        break;
                                    case "11":
                                        operator = "新建";
                                        break;
                                    case "12":
                                        operator = "重命名";
                                        break;
                                }
                                rtnObjc.put(LogConstants.ACTION_TYPE, operator);
                                break;
                            case "ioperatesucc":
                                rtnObjc.put(LogConstants.ACTION_RESULT, value);
                                break;
                            case "strsecpolicyname":
                                rtnObjc.put(LogConstants.STRATEGY_NAME, value);
                                break;
                            case "uidsecpolicyid":
                                rtnObjc.put(LogConstants.STRATEGY_ID, value);
                                break;
                        }
                    }
                }
            }
        }
        if (StringUtils.isBlank(MapUtils.getStr(rtnObjc, LogConstants.SRC_IP))) {
            rtnObjc.put(LogConstants.SRC_IP, "0.0.0.0");
        }
        if (StringUtils.isBlank(MapUtils.getStr(rtnObjc, LogConstants.DEST_IP))) {
            rtnObjc.put(LogConstants.DEST_IP, "0.0.0.0");
        }
        rtnObjc.put(LogConstants.LOG_PRODUCT, "联软");
        //setAlertName(rtnObjc);
        rtnObjc.put(LogConstants.LOG_LEVEL, LevelConstants.getLevel(MapUtils.getStr(rtnObjc,LogConstants.LOG_LEVEL)));
        rtnObjc.put(LogConstants.ALERT_NAME, MapUtils.getStr(rtnObjc, LogConstants.LOG_ORI_MSG));
        return rtnObjc;
    }

}
