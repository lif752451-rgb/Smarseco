package com.crc.log.flink.parse;

import com.crc.log.flink.common.constants.LevelConstants;
import com.crc.log.flink.common.constants.LogConstants;
import com.crc.log.flink.common.utils.DataUtils;
import com.crc.log.flink.common.utils.DateUtils;
import com.crc.log.flink.common.utils.JsonUtils;
import com.crc.log.flink.common.utils.MapUtils;
import org.apache.commons.lang3.StringUtils;

import java.util.HashMap;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

/**
 * @author jixiangqi
 * @date 2022/1/5
 */
public class ResolvQimingSqlLog {

    /**
     * IPS 日志泛化
     */
    public static ConcurrentHashMap<String, Object> parse(String message) {
        try {
            ConcurrentHashMap<String, Object> data = proc(message);
            if (DataUtils.isNotEmptyJson(data)) {
                return data;
            }
        } catch (Exception ignored) {

        }
        return null;
    }

    private static ConcurrentHashMap<String, Object> proc(String jsonStr) {
        ConcurrentHashMap<String, Object> rtnObjc = JsonUtils.createBaseMap(jsonStr);
        String temp = "";
        int index = 0;
        if (jsonStr.contains("ORACLE")) {
            index = DataUtils.getIndex(jsonStr, "ORACLE");
            temp = DataUtils.getSubString(jsonStr, "ORACLE".length()+2 +index);
        } else if (jsonStr.contains("MS-SQL")) {
            index = DataUtils.getIndex(jsonStr, "MS-SQL");
            temp = DataUtils.getSubString(jsonStr, "MS-SQL".length()+2 +index);
        } else if (jsonStr.contains("DB2")) {
            index = DataUtils.getIndex(jsonStr, "DB2");
                    //jsonStr.indexOf("DB2");
            temp = DataUtils.getSubString(jsonStr, "DB2".length()+2 + index);
                    //jsonStr.substring("DB2".length()+2 + index);
        } else if (jsonStr.contains("MYSQL")) {
            index = DataUtils.getIndex(jsonStr, "MYSQL");
                    //jsonStr.indexOf("MySQL");
            temp = DataUtils.getSubString(jsonStr, "MySQL".length()+2 + index);
                    //jsonStr.substring("MySQL".length()+2 + index);
        } else if (jsonStr.contains("TERADATA")) {
            index = DataUtils.getIndex(jsonStr, "TERADATA");
                    //jsonStr.indexOf("TERADATA");
            temp = DataUtils.getSubString(jsonStr, "TERADATA".length()+2 + index);
                    //jsonStr.substring("TERADATA".length()+2 + index);
        } else if (jsonStr.contains("CACHE")) {
            index = DataUtils.getIndex(jsonStr, "CACHE");
                    //jsonStr.indexOf("CACHE");
            temp = DataUtils.getSubString(jsonStr, "CACHE".length()+2 +index);
                    //jsonStr.substring("CACHE".length()+2 +index);
        } else if (jsonStr.contains("INFORMIX")) {
            index = DataUtils.getIndex(jsonStr, "INFORMIX");
                    //jsonStr.indexOf("INFORMIX");
            temp = DataUtils.getSubString(jsonStr, "INFORMIX".length()+2 + index);
                    //jsonStr.substring("INFORMIX".length()+2 + index);
        } else if (jsonStr.contains("DM")) {
            index = DataUtils.getIndex(jsonStr, "DM");
                    //jsonStr.indexOf("DM");
            temp = DataUtils.getSubString(jsonStr, "DM".length()+2 + index);
                    //jsonStr.substring("DM".length()+2 + index);
        } else if (jsonStr.contains("SYBASE")) {
            index = DataUtils.getIndex(jsonStr, "SYBASE");
                    //jsonStr.indexOf("SYBASE");
            temp = DataUtils.getSubString(jsonStr, "SYBASE".length()+2 + index);
                    //jsonStr.substring("SYBASE".length()+2 + index);
        } else if (jsonStr.contains("GBASE")) {
            index = DataUtils.getIndex(jsonStr, "GBASE");
                    //jsonStr.indexOf("GBASE");
            temp = DataUtils.getSubString(jsonStr, "GBASE".length()+2 + index);
                    //jsonStr.substring("GBASE".length()+2 + index);
        } else if (jsonStr.contains("SHENTONG")) {
            index = DataUtils.getIndex(jsonStr, "SHENTONG");
                    //jsonStr.indexOf("SHENTONG");
            temp = DataUtils.getSubString(jsonStr, "SHENTONG".length()+2 + index);
                    //jsonStr.substring("SHENTONG".length()+2 + index);
        } else if (jsonStr.contains("SQLSERVER")) {
            index = DataUtils.getIndex(jsonStr, "SQLSERVER");
                    //jsonStr.indexOf("SQLSERVER");
            temp = DataUtils.getSubString(jsonStr, "SQLSERVER".length()+2 + index);
                    //jsonStr.substring("SQLSERVER".length()+2 + index);
        }
        if (!"".equals(temp)) {
            Map<String, String> map = splitSpace(temp);
            map.forEach((key,value) -> {
                switch (key) {
                    case "devsn":
                        rtnObjc.put(LogConstants.SERIAL_NUMBER, value);
                        break;
                    case "gen_time":
                        rtnObjc.put(LogConstants.LOG_START_TIME, DateUtils.getISO8601Timestamp(value, "yyyy-MM-dd HH:mm:ss"));
                        break;
                    case "id":
                        rtnObjc.put(LogConstants.EVENT_ID, value);
                        break;
                    case "transport_protocol":
                        rtnObjc.put(LogConstants.LOG_PROTOCAL, value);
                        break;
                    case "level":
                        String level = "";
                        switch (value) {
                            case "urgent":
                                level = LevelConstants.HIGH;
                                break;
                            case "high":
                                level = LevelConstants.HIGH;
                                break;
                            case "middle ":
                                level = LevelConstants.MEDIUM;
                                break;
                            case "low":
                                level = LevelConstants.LOW;
                                break;
                        }
                        rtnObjc.put(LogConstants.LOG_LEVEL, level);
                        break;
                    case "server_ip":
                        rtnObjc.put(LogConstants.DEST_IP, value);
                        break;
                    case "client_ip":
                        rtnObjc.put(LogConstants.SRC_IP, value);
                        break;
                    case "server_port":
                        rtnObjc.put(LogConstants.DEST_PORT, value);
                        break;
                    case "client_port":
                        rtnObjc.put(LogConstants.SRC_PORT, value);
                        break;
                    case "server_mac":
                        rtnObjc.put(LogConstants.DEST_MAC, value);
                        break;
                    case "client_mac":
                        rtnObjc.put(LogConstants.SRC_MAC, value);
                        break;
                    case "policy_id":
                        rtnObjc.put(LogConstants.STRATEGY_ID, value);
                        break;
                    case "rule_id":
                        rtnObjc.put(LogConstants.RULE_ID, value);
                        break;
                    case "client_host":
                        rtnObjc.put(LogConstants.HOST_NAME, value);
                        break;
                    case "client_user":
                        rtnObjc.put(LogConstants.USER_NAME, value);
                        break;
                    case "instance_name":
                        rtnObjc.put(LogConstants.SRC_INSTANCE, value);
                        break;
                    case "ruleset_name":
                        rtnObjc.put(LogConstants.RULESET_NAME, value);
                        break;
                    case "rule_name":
                        rtnObjc.put(LogConstants.RULE_NAME, value);
                        break;
                    case "sql":
                        rtnObjc.put(LogConstants.SQL, value);
                        break;
                }
            });
        }
        rtnObjc.put(LogConstants.LOG_PRODUCT, "启明数据库审计");
        if (StringUtils.isBlank(MapUtils.getStr(rtnObjc, LogConstants.LOG_LEVEL))) {
            rtnObjc.put(LogConstants.LOG_LEVEL, "信息");
        }
        if (StringUtils.isBlank(MapUtils.getStr(rtnObjc, LogConstants.SRC_IP))) {
            rtnObjc.put(LogConstants.SRC_IP, "0.0.0.0");
        }
        if (StringUtils.isBlank(MapUtils.getStr(rtnObjc, LogConstants.DEST_IP))) {
            rtnObjc.put(LogConstants.DEST_IP, "0.0.0.0");
        }
        setAlertName(rtnObjc);
        return  rtnObjc;
    }

    private static Map<String, String> splitSpace(String temp) {
        String[] s = temp.split(" ");
        Map<String, String> resultMap = new HashMap<>();
        String indexKey = "";
        for (String value : s) {
            if (value.contains("=")) {
                String[] split = DataUtils.getSplit(value, "=");
                //s[i].split("=");
                if (split.length == 2) {
                    resultMap.put(split[0].trim(), split[1].trim());
                    indexKey = split[0].trim();
                }
            } else {
                resultMap.put(indexKey, resultMap.get(indexKey) + " " + value);
            }
        }
        return resultMap;
    }


    private static void setAlertName(ConcurrentHashMap<String, Object> rtnObjc) {
        String srcIp = MapUtils.getStr(rtnObjc, LogConstants.SRC_IP);
        String destIp = MapUtils.getStr(rtnObjc, LogConstants.DEST_IP);
        String protocal = MapUtils.getStr(rtnObjc, LogConstants.LOG_PROTOCAL);
        String ruleName = MapUtils.getStr(rtnObjc, LogConstants.RULE_NAME);
        String ruleSetName = MapUtils.getStr(rtnObjc, LogConstants.RULESET_NAME);
        String sql = MapUtils.getStr(rtnObjc, LogConstants.SQL);
        String log = MapUtils.getStr(rtnObjc, LogConstants.LOG_ORI_MSG);
        String msgFormat = "源IP为:%s对目的IP为:%s发起了一个协议为:%s的访问,执行的sql命令为:%s,规则名称为:%s,执行命令规则为:%s,日志详情为:%s";
        String alertName = String.format(msgFormat, srcIp, destIp, protocal, sql, ruleName, ruleSetName, log);
        rtnObjc.put(LogConstants.ALERT_NAME, alertName);

    }
}
