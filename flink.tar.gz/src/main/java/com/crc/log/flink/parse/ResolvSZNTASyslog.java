package com.crc.log.flink.parse;

import com.alibaba.fastjson.JSONObject;
import com.crc.log.flink.common.constants.LevelConstants;
import com.crc.log.flink.common.constants.LogConstants;
import com.crc.log.flink.common.utils.DataUtils;
import com.crc.log.flink.common.utils.DateUtils;
import com.crc.log.flink.common.utils.JsonUtils;
import com.crc.log.flink.common.utils.MapUtils;
import org.apache.commons.lang3.StringUtils;

import java.util.concurrent.ConcurrentHashMap;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * @author jixiangqi
 * @date 2022/5/5
 * 神州灵云全流量设备的syslog
 */
public class ResolvSZNTASyslog {
    public static ConcurrentHashMap<String,Object> parse(String message) {
        try {
            ConcurrentHashMap<String,Object> data = proc(message);
            if (DataUtils.isNotEmptyJson(data)) {
                return data;
            }
        } catch (Exception ignored) {

        }
        return null;
    }

    private static ConcurrentHashMap<String,Object> proc(String jsonStr) {
        ConcurrentHashMap<String,Object> rtnObjc = JsonUtils.createBaseMap(jsonStr);

        String data = getData(jsonStr);

        JSONObject jsonObject = JsonUtils.parse(data);
        jsonObject.forEach((k, v) -> {
            switch (k.trim())  {
                case "recordTS":
                    int lastIndex = DataUtils.getLastIndex(String.valueOf(v), ".");
                    String temp = DataUtils.getSubString(String.valueOf(v), 0, lastIndex);
                    rtnObjc.put(LogConstants.LOG_START_TIME, DateUtils.getISO8601Timestamp(temp, "yyyy-MM-dd HH:mm:ss"));
                    break;
                case "clientIp":
                    rtnObjc.put(LogConstants.SRC_IP, v);
                    break;
                case "serverIp":
                    rtnObjc.put(LogConstants.DEST_IP, v);
                    break;
                case "clientPort":
                    rtnObjc.put(LogConstants.SRC_PORT, v);
                    break;
                case "serverPort":
                    rtnObjc.put(LogConstants.DEST_PORT, v);
                    break;
                case "malIpDescription":
                    rtnObjc.put(LogConstants.LOG_DESCRIPTION, v);
                    break;
            }
        });


        if (StringUtils.isBlank(MapUtils.getStr(rtnObjc, LogConstants.SRC_IP))) {
            rtnObjc.put(LogConstants.SRC_IP, "0.0.0.0");
        }
        if (StringUtils.isBlank(MapUtils.getStr(rtnObjc, LogConstants.DEST_IP))) {
            rtnObjc.put(LogConstants.DEST_IP, "0.0.0.0");
        }
        rtnObjc.put(LogConstants.LOG_PRODUCT, "神州灵云NTA");
        //setAlertName(rtnObjc);
        rtnObjc.put(LogConstants.LOG_LEVEL, LevelConstants.getLevel(MapUtils.getStr(rtnObjc,LogConstants.LOG_LEVEL)));
        rtnObjc.put(LogConstants.ALERT_NAME, MapUtils.getStr(rtnObjc, LogConstants.LOG_ORI_MSG));
        //setAlertName(rtnObjc);
        return rtnObjc;
    }

    private static void setAlertName(ConcurrentHashMap<String,Object> rtnObjc) {
        String srcIp = MapUtils.getStr(rtnObjc, LogConstants.SRC_IP);
        String destIp = MapUtils.getStr(rtnObjc, LogConstants.DEST_IP);
        String logLevel = MapUtils.getStr(rtnObjc, LogConstants.LOG_LEVEL);
        String log = MapUtils.getStr(rtnObjc, LogConstants.LOG_ORI_MSG);
        String ruleName = MapUtils.getStr(rtnObjc, LogConstants.RULE_NAME);
        String message = "IP地址为:%s对IP地址为:%s产生了一个攻击,攻击级别为:%s,攻击规则为:%s,日志详情为:%s";
        String alertName = String.format(message, srcIp, destIp, logLevel, ruleName, log);
        rtnObjc.put(LogConstants.ALERT_NAME, alertName);
    }

    private static String getData(String str) {
        Pattern p = Pattern.compile("\\{([^\\}]+)\\}");
        Matcher m = p.matcher(str);
        String group = "";
        if (m.find()) {
            group = m.group();
        }
        return group;
    }
}
