package com.crc.log.flink.load;

import com.alibaba.fastjson.JSONObject;
import com.crc.log.flink.common.entity.IpMappgingRule;
import com.crc.log.flink.common.utils.IPUtil;
import com.crc.log.flink.common.utils.JsonUtils;
import com.crc.log.flink.db.ConfBuzziMySql;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;

import java.util.List;
import java.util.concurrent.ConcurrentHashMap;
@Slf4j
public class EventRuleLoad {
    /**
     * 以IP+Topic作为KEY
     */
    public static ConcurrentHashMap<String, IpMappgingRule> IpTopicMapping = new ConcurrentHashMap<>();
    public static ConcurrentHashMap<String, IpMappgingRule> IpMapping = new ConcurrentHashMap<>();
    public static ConcurrentHashMap<String, IpMappgingRule> ResolveMapping = new ConcurrentHashMap<>();
    public static ConcurrentHashMap<String, String> topicMapping = new ConcurrentHashMap<>();

    static {
        topicMapping.put("1", "host");
        topicMapping.put("2", "security");
        topicMapping.put("3", "network");
        topicMapping.put("4", "app");
        topicMapping.put("5", "user");
    }

    /**
     * 同步解析规则
     */
    public static void syncRule() {
        String sql = "SELECT er.dev_ip,er.rule_group,er.log_type log_value,d.dict_label dev_type,d.remark log_type,er.cust_topic,er.update_time  FROM tb_event_custom_rule er LEFT JOIN sys_dict_data d ON d.dict_type = 'rule_base' AND er.rule_base = d.dict_value WHERE er.del_flag = 0";
        try {
            // 获取返回结果
            List<JSONObject> list = ConfBuzziMySql.query(sql);
            log.info("获取初始规则数：" + list.size());
            for (JSONObject rs : list) {
                try {
                    String logValue = JsonUtils.getStr(rs, "log_value");//日志源设备类型
                    String resolvClass = JsonUtils.getStr(rs, "log_type");//日志解析类
                    String devType = JsonUtils.getStr(rs, "dev_type");//设备类型->产品名称
                    String rule_group = JsonUtils.getStr(rs, "rule_group");//公司分组
                    String dev_ip = JsonUtils.getStr(rs, "dev_ip");
                    String custTopic = JsonUtils.getStr(rs, "cust_topic");
                    String updateTime = JsonUtils.getStr(rs, "update_time");
                    String topic = topicMapping.get(logValue);
                    String newTopic = String.format("%s_%s", rule_group, topic);
                    if (StringUtils.isNotBlank(resolvClass))
                        resolvClass = resolvClass.replace(" ", "").replace("\n", "");
                    /*
                      如有指定topic就使用指定topic
                     */
                    if (StringUtils.isNotBlank(custTopic))
                        newTopic = custTopic;
                    if (StringUtils.isNotBlank(dev_ip) && StringUtils.isNotBlank(topic)) {
                        List<String> ipList = IPUtil.getIps(dev_ip);
                        //System.out.println("*******规则分类统计：" + newTopic + " " + devType + " " + ipList.size());
                        for (String ip : ipList) {
                            String key = String.format("%s_%s", newTopic, ip);
                            //System.out.println(key);
                            IpTopicMapping.put(key, IpMappgingRule.getRuleMapping(ip, newTopic, resolvClass, rule_group, devType));
                            /*
                              兼容日志没有写入topic信息的
                             */
                            IpMapping.put(ip, IpMappgingRule.getRuleMapping(ip, newTopic, resolvClass, rule_group, devType));
                        }
                    }
                } catch (Exception e) {
                    log.error(e.getMessage(), e);
                }

            }
            log.info("IpMapping获取初始规则数：" + IpMapping.size());
        } catch (Exception e) {
            log.error(e.getMessage(), e);
        }
    }
}
