package com.crc.log.flink.es;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;
import com.crc.log.flink.FlinkApplication;
import com.crc.log.flink.common.utils.*;
import com.crc.log.flink.config.AllConfig;
import com.crc.log.flink.config.GetSpringBean;
import com.crc.log.flink.flink.MyFlinkKafkaConsumer;
import com.crc.log.flink.kafka.KafkaInfo;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.apache.flink.api.common.eventtime.SerializableTimestampAssigner;
import org.apache.flink.api.common.eventtime.WatermarkStrategy;
import org.apache.flink.api.common.functions.FilterFunction;
import org.apache.flink.api.common.restartstrategy.RestartStrategies;
import org.apache.flink.api.common.serialization.SimpleStringSchema;
import org.apache.flink.api.common.time.Time;
import org.apache.flink.runtime.state.filesystem.FsStateBackend;
import org.apache.flink.streaming.api.CheckpointingMode;
import org.apache.flink.streaming.api.datastream.DataStream;
import org.apache.flink.streaming.api.datastream.SingleOutputStreamOperator;
import org.apache.flink.streaming.api.environment.CheckpointConfig;
import org.apache.flink.streaming.api.environment.StreamExecutionEnvironment;
import org.apache.flink.streaming.connectors.elasticsearch.ElasticsearchSinkBase;
import org.apache.flink.streaming.connectors.elasticsearch6.ElasticsearchSink;
import org.apache.flink.streaming.connectors.kafka.FlinkKafkaConsumer;
import org.apache.http.Header;
import org.apache.http.HttpHost;
import org.apache.http.HttpResponse;
import org.apache.http.auth.AuthScope;
import org.apache.http.auth.UsernamePasswordCredentials;
import org.apache.http.client.CredentialsProvider;
import org.apache.http.conn.ConnectionKeepAliveStrategy;
import org.apache.http.impl.client.BasicCredentialsProvider;
import org.apache.http.impl.client.DefaultConnectionKeepAliveStrategy;
import org.apache.http.impl.nio.reactor.IOReactorConfig;
import org.apache.http.message.BasicHeader;
import org.apache.http.protocol.HttpContext;
import org.apache.kafka.common.serialization.StringDeserializer;

import java.io.File;
import java.time.Duration;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import java.util.Properties;

/**
 * sink es
 *
 * @author 何景生
 * @since 2020/4/21 9:58
 */
@Slf4j
public class FlinkDataFilter {
    public static void sinkEs() {
        // 一个时间段内的最大失败次数,衡量失败次数的是时间段 Time.of(10, TimeUnit.SECONDS) // 间隔
        AllConfig config = GetSpringBean.getBean(AllConfig.class);
        FlinkApplication.ALL_CONFIG = config;
        DataProcessFuncation.CONIFG = config;

        Properties props = new Properties();
        props.put("bootstrap.servers", config.getKafka());
        if (StringUtils.isNotBlank(config.getZookeeper())) {
            props.put("zookeeper.connect", config.getZookeeper());
        }
        String groupName = config.getGroupId();
        if (StringUtils.isBlank(groupName)) {
            groupName = IdGen.uuid();
        }
        props.put("group.id", groupName);
        props.put("key.deserializer", StringDeserializer.class.getName());
        props.put("value.deserializer", StringDeserializer.class.getName());
        props.put("session.timeout.ms", 30000);
        props.put("request.timeout.ms", 30000);
        int maxPoll = 1000;
        if (DataUtils.toNum(config.getMaxPoll()) > 500) {
            maxPoll = DataUtils.toNum(config.getMaxPoll());
        }
        System.out.println("kafka maxPoll:" + maxPoll);
        props.put("max.poll.records", String.valueOf(maxPoll));//最大拉取量
        props.forEach((k,v)->{
            System.out.println(k + " : " + v);
        });
        /*
         * 获取流处理环境并设置并行度
         */
        String targetTopic = config.getTopic();

        int partitionSize = KafkaInfo.getKafkaPartitionSize(config.getKafka(), targetTopic);
        int parallelism = DataUtils.getIntX(config.getParallelism());
        System.out.println(targetTopic + " partition size:" + partitionSize + ",parallelism:" + parallelism);
        StreamExecutionEnvironment env = StreamExecutionEnvironment.getExecutionEnvironment();
        String osName = System.getProperty("os.name");
        if (StringUtils.isBlank(config.getCachePath()) && osName != null) {
            if (osName.toLowerCase(Locale.ROOT).contains("win")) {
                config.setCachePath("c:\\temp\\cache");
            } else {
                config.setCachePath("/app/flink/cache");
            }
        }
        File file = new File(config.getCachePath());
        if (!file.exists()) {
            boolean v = file.mkdirs();
            System.out.println("CachePath create :" + config.getCachePath() + " - " + v);
        }
        env.setStateBackend(new FsStateBackend("file:///" + config.getCachePath()));
        //设置任务失败最大次数  任务失败的时间启动的间隔  允许任务延迟时间
        //env.setRestartStrategy(RestartStrategies.failureRateRestart(3, Time.of(5, TimeUnit.MINUTES),
        //        Time.of(30, TimeUnit.SECONDS)));
        // 设置检查点时间为10秒，当前为120秒，2分钟
        env.enableCheckpointing(120000);
        // 设置检查模式  恰好一次
        env.getCheckpointConfig().setCheckpointingMode(CheckpointingMode.EXACTLY_ONCE);
        // 设置检查点之间的最小暂停时间
        env.getCheckpointConfig().setMinPauseBetweenCheckpoints(120000);
        // 设置检查点超时 60秒 检查点必须在一分钟内完成，或者被丢弃【checkpoint的超时时间】
        env.getCheckpointConfig().setCheckpointTimeout(120000);
        // 设置最大并发检查点 同一时间只允许进行一个检查点
        env.getCheckpointConfig().setMaxConcurrentCheckpoints(1);
        // 表示一旦Flink处理程序被cancel后，会保留Checkpoint数据，以便根据实际需要恢复到指定的 Checkpoint (重启策略)
        env.getCheckpointConfig().enableExternalizedCheckpoints(CheckpointConfig.ExternalizedCheckpointCleanup.RETAIN_ON_CANCELLATION);
        /*
         * 最多容忍几次checkpoint失败
         * 如果为0则不容忍任何checkpoint失败，checkpoint失败即任务失败
         */
        //env.getCheckpointConfig().setTolerableCheckpointFailureNumber(5);
        /*
         * RestartStrategies.FailureRateRestartStrategyConfiguration failureRateRestart(failureRate: Int, failureInterval: Time, delayInterval: Time)
         * failureRate:失败次数
         * failureInterval：失败时间间隔（总的）
         * delayInterval：两次尝试重启的时间间隔
         */
        env.setRestartStrategy(RestartStrategies.failureRateRestart(3, Time.minutes(5), Time.seconds(10)));

        //env.getConfig().setTaskCancellationTimeout(360000);//用来监听Cancel任务是否成功的线程,默认是180s

        FlinkKafkaConsumer<String> commonConsumer = null;
        MyFlinkKafkaConsumer<String> userConsumer = null;
        /*
        指定分区消费
         */
        if (StringUtils.isNotBlank(config.getPartition())) {
            userConsumer = new MyFlinkKafkaConsumer<>(targetTopic, new SimpleStringSchema(), props, config.getPartition());
            userConsumer.setCommitOffsetsOnCheckpoints(true);
            if ("latest".equalsIgnoreCase(config.getConsumertype())) {
                userConsumer.setStartFromLatest();
                System.out.println("OffsetsInitializer.latest()");
            } else {
                userConsumer.setStartFromEarliest();
                System.out.println("OffsetsInitializer.earliest()");
            }

            if ("latest".equalsIgnoreCase(config.getConsumertype())) {
                userConsumer.setStartFromLatest();
            }
            System.out.println("Flink kafka消费模式为指定分区消费，当前消费分区为：" + config.getPartition());
        } else {
            /*
            通用消费所有分区
             */
            commonConsumer = new FlinkKafkaConsumer<>(targetTopic, new SimpleStringSchema(), props);
            commonConsumer.setCommitOffsetsOnCheckpoints(true);
            if ("earliest".equalsIgnoreCase(config.getConsumertype())) {
                commonConsumer.setStartFromEarliest();
                System.out.println("OffsetsInitializer.earliest()");
            } else {
                commonConsumer.setStartFromLatest();
                System.out.println("OffsetsInitializer.latest()");
            }
            System.out.println("Flink kafka消费模式为通用消费所有分区");
        }

        DataStream<String> stream = null;

        if (parallelism < partitionSize) {
            parallelism = partitionSize;
        }

        if (commonConsumer != null) {
            stream = env.addSource(commonConsumer).setParallelism(parallelism);
        } else {
            stream = env.addSource(userConsumer).setParallelism(parallelism);
        }

        System.out.println("kafka配置->" + JSON.toJSONString(props));
        List<HttpHost> httpHosts = new ArrayList<>();

        //读取ES集群配置
        String eshoststr = config.getEshost();
        String esport = config.getEsport();
        if (esport == null || eshoststr.contains(",")) {
            String[] eshostArr = eshoststr.split(",");
            for (String s : eshostArr) {
                if (s.contains(":")) {
                    String host = s.split(":")[0];
                    String portStr = s.split(":")[1];
                    int port = DataUtils.toNum(portStr);
                    if (port < 1) {
                        log.error("es配置错误->{}", s);
                    }
                    String mode = "http";
                    if ("https".equalsIgnoreCase(config.getEsmode())) {
                        mode = "https";
                    }
                    config.setEsmode(mode);
                    HttpHost httpHost = new HttpHost(host, port, mode);
                    httpHosts.add(httpHost);
                }
            }
        } else {
            int port = DataUtils.toNum(esport);
            if (port < 1) {
                log.error("es配置错误->{}:{}", eshoststr, esport);
            }
            String mode = "http";
            if ("https".equalsIgnoreCase(config.getEsmode())) {
                mode = "https";
            }
            config.setEsmode(mode);
            HttpHost httpHost = new HttpHost(eshoststr, port, mode);
            httpHosts.add(httpHost);
        }
        System.out.println("es 服务：" + JSON.toJSONString(httpHosts));
        System.out.println("索引 Prefix：" + config.getIndex());

        ElasticsearchSink.Builder<String> esSinkBuilder = new ElasticsearchSink.Builder<>(httpHosts,
                new SinkLogToESFunction(config.getIndex(), config.getIndexSwitch(), targetTopic, config.getMode(), config.getDoctype()));
        /*
        bulk.flush.max.actions: 默认1000。每个Bulk请求，最大缓冲Action个数。
        bulk.flush.max.size.mb: 默认5mb。每个Bulk请求，最大缓冲的Action大小。
        bulk.flush.interval.ms: 默认为空,单位毫秒。Bulk刷新间隔。不论Action个数或Action大小如何设置，到刷新间隔了，就会刷新缓冲，发起Bulk请求。
        延迟重试策略: 默认启用指数级间隔重试策略,初始等待50ms,8次重试。如需自定义延迟重试策略，可通过以下参数配置。
            bulk.flush.backoff.enable: 延迟重试是否启用。
            bulk.flush.backoff.type: 延迟重试类型，CONSTANT(固定间隔)或EXPONENTIAL(指数级间隔)。
            bulk.flush.backoff.delay: 延迟重试间隔。对于CONSTANT类型，此值为每次重试间的间隔;对于EXPONENTIAL，此值为初始延迟。
            bulk.flush.backoff.retries: 延迟重试次数。
         */
        // 设置批量写数据的缓冲区大小
        //批量写入时的最大数据量20M
        esSinkBuilder.setBulkFlushMaxSizeMb(50);
        System.out.println("setBulkFlushMaxSizeMb=50");
        int maxPush = DataUtils.toNum(config.getFlushMaxAction());
        if (maxPush < 500) {
            maxPush = 500;
        }
        System.out.println("setBulkFlushMaxActions=" + maxPush);//3000
        esSinkBuilder.setBulkFlushMaxActions(maxPush);
        esSinkBuilder.setBulkFlushInterval(3000);
        System.out.println("setBulkFlushInterval=3000ms");
        //500条日志或2秒提交一次
        // 3、添加异常处理
        esSinkBuilder.setFailureHandler(new ActionRequestFailureHandlerImpl());
        String username = config.getEsusername();
        String password = CodeTool.decrypt(config.getEspassword());
        String mode = config.getEsmode();
        String proxy = config.getEsproxyHeader();
        //设置用户名密码
        esSinkBuilder.setRestClientFactory(
                restClientBuilder -> {
                    Header[] defaultHeaders = new Header[]{new BasicHeader("X-Found-Cluster", proxy)};
                    // 该方法接收一个RequestConfig.Builder对象，对该对象进行修改后然后返回。
                    restClientBuilder.setRequestConfigCallback(requestConfigBuilder -> {
                        return requestConfigBuilder.setConnectTimeout(60000) // 连接超时（默认为1秒）
                                .setSocketTimeout(60000).setConnectionRequestTimeout(20000);// 套接字超时（默认为30秒）//更改客户端的超时限制默认30秒现在改为100*1000分钟
                    });
                    restClientBuilder.setDefaultHeaders(defaultHeaders);
                    restClientBuilder.setHttpClientConfigCallback(httpAsyncClientBuilder -> {
                        httpAsyncClientBuilder.setMaxConnTotal(100); //最大连接数
                        ConnectionKeepAliveStrategy keepAliveStrategy = new DefaultConnectionKeepAliveStrategy() {
                            @Override
                            public long getKeepAliveDuration(final HttpResponse response, final HttpContext context) {
                                return Duration.ofMinutes(5).toMillis();//保活 5 分钟
                            }
                        };
                        httpAsyncClientBuilder.setKeepAliveStrategy(keepAliveStrategy);
                        httpAsyncClientBuilder.setMaxConnPerRoute(100);  //针对一个域名同时间正在使用的最多的连接数
                        if (StringUtils.isNotBlank(username) && StringUtils.isNotBlank(password)) {
                            final CredentialsProvider credentialsProvider = new BasicCredentialsProvider();
                            credentialsProvider.setCredentials(AuthScope.ANY,
                                    new UsernamePasswordCredentials(username, password));
                            httpAsyncClientBuilder.setDefaultCredentialsProvider(credentialsProvider);
                        }
                        if ("https".equals(mode)) {
                            try {
                                httpAsyncClientBuilder.setConnectionManager(SslUtils.getConnectionManager());
                            } catch (Exception e) {
                                log.error(e.getMessage(), e);
                            }
                            //System.out.println("启用ES https链接模式");
                        }
                        return httpAsyncClientBuilder.setDefaultIOReactorConfig(
                                IOReactorConfig.custom().setIoThreadCount(10).build());//设置线程数量
                    });
                }
        );
        //2、重试策略，又可以分为以下两种类型
        //a、指数型，表示多次重试之间的时间间隔按照指数方式进行增长。eg:2 -> 4 -> 8 ...
        esSinkBuilder.setBulkFlushBackoffType(ElasticsearchSinkBase.FlushBackoffType.EXPONENTIAL);
        //用来表示是否开启重试机制
        esSinkBuilder.setBulkFlushBackoff(true);
        //失败重试的次数
        esSinkBuilder.setBulkFlushBackoffRetries(3);
        //进行重试的时间间隔。对于指数型则表示起始的基数
        esSinkBuilder.setBulkFlushBackoffDelay(10000);
        // 关掉基于Checkpoint的flush
        //esSinkBuilder.disableFlushOnCheckpoint();
        /*
          加入水印机制
         */
        SerializableTimestampAssigner<String> timestampAssigner = (element, recordTimestamp) -> {
            try {
                JSONObject jsonObject = JSON.parseObject(element);
                if (jsonObject.containsKey("LOG_TIMESTAMP")) {
                    return JsonUtils.getLong(jsonObject, "LOG_TIMESTAMP");
                }
                return System.currentTimeMillis();
            } catch (Exception e) {
                return System.currentTimeMillis();
            }
        };
        SingleOutputStreamOperator<String> watermarkStream = stream.assignTimestampsAndWatermarks(WatermarkStrategy.<String>forBoundedOutOfOrderness(Duration.ofSeconds(10)).withTimestampAssigner(timestampAssigner));
        /*
         * 把转换后的数据写入到ElasticSearch中
         */
        watermarkStream.filter((FilterFunction<String>) line -> {
            // 过滤掉无效日志
            return !StringUtils.isBlank(line) && line.length() >= 6;
        }).addSink(esSinkBuilder.build()).name("crc-flink-v2");

        System.out.println("flink 启动完成！");
        try {
            env.execute("Flink解析日志");
        } catch (Exception e) {
            log.error(e.getMessage(), e);
        }
    }
}

