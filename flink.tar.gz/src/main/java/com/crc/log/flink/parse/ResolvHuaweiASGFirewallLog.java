package com.crc.log.flink.parse;

import com.crc.log.flink.common.constants.LevelConstants;
import com.crc.log.flink.common.constants.LogConstants;
import com.crc.log.flink.common.utils.*;
import org.apache.commons.lang3.StringUtils;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.concurrent.ConcurrentHashMap;

/**
 * @author jixiangqi
 * @date 2022/1/11
 * HUAWEI ASG2100-专网防火墙
 */
public class ResolvHuaweiASGFirewallLog {
    static SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");

    public static ConcurrentHashMap<String,Object> parse(String message) {
        try {
            ConcurrentHashMap<String,Object> data = proc(message);
            if (DataUtils.isNotEmptyJson(data)) {
                return data;
            }
        } catch (Exception ignored) {

        }
        return null;
    }

    private static ConcurrentHashMap<String,Object> proc(String jsonStr) {
        int type = -1;
        ConcurrentHashMap<String,Object> rtnObjc = JsonUtils.createBaseMap(jsonStr);
        if (jsonStr.contains("USG6600E") || jsonStr.contains("USG6500")) {
            if (jsonStr.contains("USG6600E")) {
                rtnObjc.put(LogConstants.LOG_PRODUCT, "华为防火墙USG6600E");
            } else if (jsonStr.contains("USG6500")) {
                rtnObjc.put(LogConstants.LOG_PRODUCT, "华为防火墙USG6500");
            }
            jsonStr = findThirdColon(jsonStr);
            String[] split = DataUtils.getSplit(jsonStr, ",");
            for (String tempStr : split) {
                if (tempStr.contains("=")) {
                    int index = DataUtils.getIndex(tempStr, "=");
                    String key = DataUtils.getSubString(tempStr, 0, index).trim();
                    String value = DataUtils.getSubString(tempStr, index + 1).trim();
                    switchKeyValueTwo(rtnObjc, key, value);
                    type = 3;
                }
            }
        } else {
            jsonStr = findThirdColon(jsonStr);
            if (StringUtils.isNotBlank(jsonStr) && jsonStr.startsWith("AttackType")) {
                String[] split = DataUtils.getSplit(jsonStr, ",");
                //jsonStr.split(",");
                switchKeyValue(split, rtnObjc);
                type = 0;
            } else if (StringUtils.isNotBlank(jsonStr) && jsonStr.startsWith("User login succeeded")) {
                jsonStr = DataUtils.getSubString(jsonStr, "User login succeeded".length() + 3);
                //jsonStr.substring("User login succeeded".length() + 3);
                jsonStr = DataUtils.getSubString(jsonStr, 0, jsonStr.length());
                //jsonStr.substring(0, jsonStr.length());
                String[] split = DataUtils.getSplit(jsonStr, ",");
                //jsonStr.split(",");
                switchKeyValue(split, rtnObjc);
                type = 1;
            } else if (StringUtils.isNotBlank(jsonStr) && jsonStr.startsWith("In last five minutes")) {
                int index1 = DataUtils.getIndex(jsonStr, ":");
                //jsonStr.indexOf(":");
                if (index1 != -1) {
                    jsonStr = DataUtils.getSubString(jsonStr, index1+1);
                    //jsonStr.substring(index1+1);
                    String[] split = DataUtils.getSplit(jsonStr, ",");
                    //jsonStr.split(",");
                    switchKeyValue(split, rtnObjc);
                    type = 2;
                }
            }
            rtnObjc.put(LogConstants.LOG_PRODUCT, "华为防火墙ASG2100");
        }

        rtnObjc.put(LogConstants.LOG_LEVEL, LevelConstants.getLevel(MapUtils.getStr(rtnObjc,LogConstants.LOG_LEVEL)));
        if (StringUtils.isBlank(MapUtils.getStr(rtnObjc, LogConstants.SRC_IP))) {
            rtnObjc.put(LogConstants.SRC_IP, "0.0.0.0");
        }
        if (StringUtils.isBlank(MapUtils.getStr(rtnObjc, LogConstants.DEST_IP))) {
            rtnObjc.put(LogConstants.DEST_IP, "0.0.0.0");
        }
        setAlertName(rtnObjc, type);
        return rtnObjc;
    }

    private static void setAlertName(ConcurrentHashMap<String,Object> rtnObjc ,int type) {
        String msgFormat = "";
        String alertName = "";
        String level = MapUtils.getStr(rtnObjc, LogConstants.LOG_LEVEL);
        String log = MapUtils.getStr(rtnObjc, LogConstants.LOG_ORI_MSG);
        if (type == 0) {
            String srcIp = MapUtils.getStr(rtnObjc, LogConstants.SRC_IP);
            String destIp = MapUtils.getStr(rtnObjc, LogConstants.DEST_IP);
            String proto = MapUtils.getStr(rtnObjc, LogConstants.LOG_PROTOCAL);
            String actionType = MapUtils.getStr(rtnObjc, LogConstants.ACTION_TYPE);
            msgFormat = "源IP为:%s对目的IP为:%s发起了一个%s类型的攻击,攻击协议为:%s,事件级别为:%s,日志详情为:%s";
            alertName = String.format(msgFormat, srcIp, destIp, actionType, proto, level, log);
        } else if (type == 1) {
            String userName = MapUtils.getStr(rtnObjc, LogConstants.USER_NAME);
            String srcIp = MapUtils.getStr(rtnObjc, LogConstants.SRC_IP);
            String actionType = MapUtils.getStr(rtnObjc, LogConstants.ACTION_TYPE);
            msgFormat = "用户名为:%s在IP为:%s发起了一个%s类型的攻击,事件级别为:%s,日志详情为:%s";
            alertName = String.format(msgFormat, userName, srcIp, actionType, level, log);
        } else if(type == 2) {
            alertName = "日志详情为:" + log;
        } else if (type == 3) {
            String srcIp = MapUtils.getStr(rtnObjc, LogConstants.SRC_IP);
            String destIp = MapUtils.getStr(rtnObjc, LogConstants.DEST_IP);
            String proto = MapUtils.getStr(rtnObjc, LogConstants.LOG_PROTOCAL);
            msgFormat = "IP:%s对IP为:%s产生了一个告警,访问协议为:%s,原始日志为:%s";
            alertName = String.format(msgFormat, srcIp, destIp, proto, log);
        }
        rtnObjc.put(LogConstants.ALERT_NAME, alertName);
    }

    private static void switchKeyValue(String[] split, ConcurrentHashMap<String,Object> rtnObjc) {
        for (String temp : split) {
            String[] keyValue = DataUtils.getSplit(temp, "=");
            if (keyValue.length == 2) {
                String key = keyValue[0].trim();
                String value = keyValue[1].trim().replace("\"", "");
                switch (key) {
                    case "AttackType":
                        rtnObjc.put(LogConstants.ACTION_TYPE, value);
                        break;
                    case "proto":
                        rtnObjc.put(LogConstants.LOG_PROTOCAL, value);
                        break;
                    case "src":
                        String[] srcIpPort = DataUtils.getSplit2(value, ":");
                        //value.split(":");
                        if (srcIpPort.length == 2) {
                            rtnObjc.put(LogConstants.SRC_IP, srcIpPort[0]);
                            rtnObjc.put(LogConstants.SRC_PORT, srcIpPort[1]);
                        }
                        break;
                    case "dst":
                        if (value.contains(" ")) {
                            String[] s = DataUtils.getSplit(value, " ");
                            //value.split(" ");
                            String[] destIpPort = DataUtils.getSplit2(s[0], ":");
                            //s[0].split(":");
                            if (destIpPort.length == 2) {
                                rtnObjc.put(LogConstants.DEST_IP, destIpPort[0]);
                                rtnObjc.put(LogConstants.DEST_PORT, destIpPort[1]);
                            }
                        }
                        break;
                    case "begin time":
                        rtnObjc.put(LogConstants.LOG_START_TIME, DateUtils.getISO8601Timestamp(value, "yyyy-MM-dd HH:mm:ss"));
                        break;
                    case "User Name":
                        rtnObjc.put(LogConstants.USER_NAME, value);
                        break;
                    case "Group Name":
                        rtnObjc.put(LogConstants.LOG_GROUP, value);
                        break;
                    case "VPN Instance":
                        rtnObjc.put(LogConstants.SRC_INSTANCE, value);
                        break;
                    case "Source IP":
                        rtnObjc.put(LogConstants.SRC_IP, value);
                        break;
                    case "Source MAC":
                        rtnObjc.put(LogConstants.SRC_MAC, value);
                        break;
                    case "Logon Time":
                        rtnObjc.put(LogConstants.LOG_START_TIME, DateUtils.getISO8601Timestamp(value, "yyyy/MM/dd HH:mm:ss"));
                        break;
                    case "Logon Mode":
                        rtnObjc.put(LogConstants.ACTION_TYPE, value);
                        break;
                }
            }
        }
    }

    private static void switchKeyValueTwo(ConcurrentHashMap<String,Object> rtnObjc, String key, String value) {
        switch (key) {
            case "protocol":
                rtnObjc.put(LogConstants.LOG_PROTOCAL, ProtoUtils.switchProto(DataUtils.toNum(value)));
                break;
            case "source-ip":
                rtnObjc.put(LogConstants.SRC_IP, value);
                break;
            case "source-port":
                rtnObjc.put(LogConstants.SRC_PORT, value);
                break;
            case "destination-ip":
                rtnObjc.put(LogConstants.DEST_IP, value);
                break;
            case "destination-port":
                rtnObjc.put(LogConstants.DEST_PORT, value);
                break;
            case "time":
                rtnObjc.put(LogConstants.LOG_START_TIME, DateUtils.getISO8601Timestamp(value, "yyyy/MM/dd HH:mm:ss"));
                break;
            case "application-name":
                rtnObjc.put(LogConstants.LOG_APP, value);
                break;
            case "Protocol":
                rtnObjc.put(LogConstants.LOG_PROTOCAL, value);
                break;
            case "SourceIP":
                rtnObjc.put(LogConstants.SRC_IP, value);
                break;
            case "DestinationIP":
                rtnObjc.put(LogConstants.DEST_IP, value);
                break;
            case "SourcePort":
                rtnObjc.put(LogConstants.SRC_PORT, value);
                break;
            case "DestinationPort":
                rtnObjc.put(LogConstants.DEST_PORT, value);
                break;
            case "BeginTime":
                rtnObjc.put(LogConstants.LOG_START_TIME, DateUtils.getISO8601Timestamp(sdf.format(new Date(DataUtils.toNum(value) * 1000L)), "yyyy-MM-dd HH:mm:ss"));
                break;
        }
    }



    private static String findThirdColon(String jsonStr) {
        int count = 0;
        int index = 0;
        while (count != 3) {
            index = DataUtils.getIndex(jsonStr, ":");
                    //jsonStr.indexOf(":");
            if (index == -1) {
                return "";
            }
            jsonStr = DataUtils.getSubString(jsonStr, index+1).trim();
            count++;
        }
        return jsonStr;
    }

}
