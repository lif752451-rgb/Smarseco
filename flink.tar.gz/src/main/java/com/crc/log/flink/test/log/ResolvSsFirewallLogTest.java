package com.crc.log.flink.test.log;

import com.crc.log.flink.common.utils.JsonUtils;
import com.crc.log.flink.config.AllConfig;
import com.crc.log.flink.es.DataProcessFuncation;

import java.util.concurrent.ConcurrentHashMap;


public class ResolvSsFirewallLogTest {

    public static void main(String[] args) {
        AllConfig config = new AllConfig();
        DataProcessFuncation.CONIFG = config;
        config.setMode("single");
        config.setParse("ResolvSsFirewallLog");
        config.setIndex("sec_all");


        String str = "<188>Nov 29 10:23:49 2508129205014948(root) 4640940b Threat@FLOW: From 27.221.3.89:80(ethernet0/8) to 10.218.172.97:55251(ethernet0/1), threat name: GENERIC.HS, threat type: Malware, threat subtype: Riskware, App/Protocol: HTTP, action: reset, defender: AV, URL http://soft-dl.v78q.com/softmgr/package/B833CD6B-2FBC-4998-B962-26D4E7E5364A/wnwb10_0_2_10108.exe.pak, profile: predef_low, threat severity: Low, policy id: 1";
        ConcurrentHashMap<String, Object> proc = DataProcessFuncation.parse(str,"index");
        JsonUtils.printStr(proc);

        str = "<188>Nov 28 08:26:22 2508129205014948(root) 460c9412 Threat@FLOW: From 141.98.82.22:65532(ethernet0/8) to 221.215.148.62:61389(-), threat name: port-scan, threat type: Scan, threat subtype: Port Scan, App/Protocol: IPv4/TCP, action: DROP, defender: AD, severity: Medium, zone untrust: Port scan attack";
        proc = DataProcessFuncation.parse(str,"index");
        JsonUtils.printStr(proc);

        str = "<186>Nov  1 15:29:02 2508129205014948(root) 44040204 Event@SECURITY: The user \"sunxiaosu\" modified the policy (id 1), the \"ips\" has been modified: \"\"->\"predef_default:0\"";
        proc = DataProcessFuncation.parse(str,"index");
        JsonUtils.printStr(proc);

        str = "<186>Nov  1 15:29:02 2508129205014948(root) 44040204 Event@SECURITY: The user \"sunxiaosu\" modified the policy (id 1), the \"dst-zone\" has been modified: Any->untrust";
        proc = DataProcessFuncation.parse(str,"index");
        JsonUtils.printStr(proc);

        str = "<190>Nov  1 21:50:03 2508129205014948(root) 44243630 Traffic@FLOW: SESSION: 192.168.9.170:2->119.165.96.1:56693(ICMP: ECHO_REQUEST), application PING, interface ethernet0/1, vr trust-vr, policy 1, user -@-, host -, mac 0000.0000.0000, send packets 1,send bytes 74,receive packets 1,receive bytes 74, start time 2021-11-01 21:49:59, close time 2021-11-01 21:50:03,session end,Close-ICMP";
        proc = DataProcessFuncation.parse(str,"index");
        JsonUtils.printStr(proc);
    }


}
