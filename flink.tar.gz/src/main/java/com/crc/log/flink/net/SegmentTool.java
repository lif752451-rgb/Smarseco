package com.crc.log.flink.net;

import com.crc.log.flink.FlinkApplication;
import com.crc.log.flink.common.utils.DataUtils;
import com.crc.log.flink.common.utils.IPUtil;
import com.crc.log.flink.load.NewSegmentLoad;
import com.crc.log.flink.load.NewUserSegmentLoad;
import lombok.extern.slf4j.Slf4j;

import java.util.concurrent.*;

/**
 * 网段识别，设计为单例
 */
@Slf4j
public class SegmentTool {
    static ExecutorService executorService1 = Executors.newFixedThreadPool(1);
    static ExecutorService executorService2 = Executors.newFixedThreadPool(1);
    volatile boolean stop1 = false;
    volatile boolean stop2 = false;

    long timeout = 100;//必须计算完成的时间要求（单位毫秒）

    private SegmentTool() {
        if (FlinkApplication.ALL_CONFIG != null) {
            int t = DataUtils.toNum(FlinkApplication.ALL_CONFIG.getSegTimeout());
            if (t > 0) {
                timeout = t;
            }
        }
    }

    private static volatile SegmentTool instance = null;

    public static SegmentTool getInstance() {
        if (instance == null) {
            synchronized (SegmentTool.class) {
                if (instance == null) {
                    instance = new SegmentTool();
                }
            }
        }
        return instance;
    }

    public IPBean getSegmentByIp(String ip) {
        Future<IPBean> future = executorService2.submit(() -> {
            try {
                return getIPByHalf(ip);
            } catch (Exception ignored) {

            }
            return null;
        });
        // 获取执⾏结果
        try {
            return future.get(timeout, TimeUnit.MILLISECONDS);
        } catch (Exception e) {
            try {
                stop1 = true;
                future.cancel(true);
            } catch (Exception ignored) {

            }
        } finally {
            stop1 = false;
        }
        return null;
    }

    /**
     * 根据ip地址判断属于哪个ip地址段，返回这个段的ip地址对象
     * 使用二分查找算法来实现
     */
    private IPBean getIPByHalf(String ip) {
        try {
            if ("T".equals(FlinkApplication.ALL_CONFIG.getDebug())) {
                log.info("check segment getIPByHalf=" + ip);
            }
            IPBean[] ipBeans = NewSegmentLoad.ipSegMap.get("seg");
            if (ipBeans == null || ipBeans.length == 0) {
                return null;
            }
            long iplong = IPUtil.getIp2long(ip);
            if (iplong < ipBeans[0].getBegin() || iplong > ipBeans[ipBeans.length - 1].getEnd()) {
                return null;
            }
            int low = 0;
            int high = ipBeans.length - 1;
            //不能使用 int mid = (left + right) / 2,如果 low 和 high 比较大的话，两者之和就有可能会溢出
            int mid = low + ((high - low) >>> 1);
            long t1 = System.nanoTime();
            //当两个指针同时指向同一个数据时,需用 = 判断
            while (low <= high && !stop1) {
                long t2 = System.nanoTime();
                if (t2 - t1 > timeout * 1000000L) {
                    break;
                } else {
                    if (iplong < ipBeans[mid].getBegin()) {
                        high = mid - 1;
                    } else if (iplong > ipBeans[mid].getBegin()) {
                        low = mid + 1;
                    }
                    if (iplong >= ipBeans[mid].getBegin() && iplong <= ipBeans[mid].getEnd()) {
                        return ipBeans[mid];
                    }
                    mid = (low + high) / 2;
                }
            }
        } catch (Exception ignored) {

        }
        return null;
    }

    public void setUserDefineIpSegment(ConcurrentHashMap<String,Object> data, String type, String ip) {
        Future<Object> future = executorService1.submit(() -> {
            try {
                for (String key : NewUserSegmentLoad.userSegMap.keySet()) {
                    if (stop2) {
                        break;
                    }
                    IPBean ipBean = getUserDefineIPByHalf(key, ip);
                    boolean match = ipBean != null;
                    data.put(String.format("%s_%s", type, key), match ? "1" : "0");

                }
            } catch (Exception ignored) {

            }
            return null;
        });
        try {
            // 获取执⾏结果
            future.get(timeout, TimeUnit.MILLISECONDS);
        } catch (Exception ignored) {
            stop2 = true;
            future.cancel(true);
        } finally {
            stop2 = false;
        }
    }

    /**
     * 根据ip地址判断属于哪个ip地址段，返回这个段的ip地址对象
     * 使用二分查找算法来实现
     */
    private IPBean getUserDefineIPByHalf(String type, String ip) {
        try {
            if ("T".equals(FlinkApplication.ALL_CONFIG.getDebug())) {
                log.info("check segment getUserDefineIPByHalf=" + ip);
            }
            if (!IPUtil.isIp(ip)) {
                return null;
            }
            IPBean[] ipBeans = NewUserSegmentLoad.userSegMap.get(type);
            if (ipBeans == null || ipBeans.length == 0) {
                return null;
            }
            long iplong = IPUtil.getIp2long(ip);
            if (iplong < ipBeans[0].getBegin() || iplong > ipBeans[ipBeans.length - 1].getEnd()) {
                return null;
            }
            int low = 0;
            int high = ipBeans.length - 1;
            int mid;
            long t1 = System.nanoTime();
            while (low <= high && !stop2) {
                long t2 = System.nanoTime();
                if (t2 - t1 > timeout * 1000000L) {
                    break;
                } else {
                    mid = (low + high) / 2;
                    if (iplong < ipBeans[mid].getBegin()) {
                        high = mid - 1;
                    } else if (iplong > ipBeans[mid].getBegin()) {
                        low = mid + 1;
                    } else {
                        if (iplong >= ipBeans[mid].getBegin() && iplong <= ipBeans[mid].getEnd()) {
                            return ipBeans[mid];
                        }
                    }
                }
            }
        } catch (Exception ignored) {

        }
        return null;
    }

}