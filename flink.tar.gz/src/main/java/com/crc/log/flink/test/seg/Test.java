package com.crc.log.flink.test.seg;

import com.crc.log.flink.common.utils.MyTheadUtils;
import com.crc.log.flink.net.IPBean;
import com.crc.log.flink.net.SegmentTool;
import com.crc.log.flink.test.ip.FakeIp;
import lombok.extern.slf4j.Slf4j;

import java.util.List;
import java.util.concurrent.ArrayBlockingQueue;
import java.util.concurrent.ThreadPoolExecutor;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.atomic.AtomicLong;

@Slf4j
public class Test {
    public static AtomicLong createLong = new AtomicLong(1);
    public static AtomicLong finishLong = new AtomicLong(1);

    public static void main(String[] args) {
        ThreadPoolExecutor executor = new ThreadPoolExecutor(4000, 5000, 200, TimeUnit.MILLISECONDS,
                new ArrayBlockingQueue<>(4000));

        try {
            while (true) {
                try {
                    List<String> ips = FakeIp.generateFakeIp(10000);
                    for (String ip : ips) {

                        MyTask myTask = new MyTask(ip, createLong.addAndGet(1L));
                        executor.execute(myTask);
                    }
                } catch (Exception e) {
                    log.error(e.getMessage(), e);
                }
                MyTheadUtils.sleepBySec(1);
                System.out.println("##################");
            }
        } catch (Exception e) {
            log.error(e.getMessage(), e);
        } finally {
            executor.shutdown();
        }

    }
}

class MyTask implements Runnable {

    private final long taskNum;
    private final String ip;

    public MyTask(String ip, long num) {
        this.taskNum = num;
        this.ip = ip;
    }

    @Override
    public void run() {
        System.out.println("正在执行task " + taskNum + " " + ip + " ####" + Test.createLong.get());
        IPBean bean = SegmentTool.getInstance().getSegmentByIp(ip);
        Test.finishLong.addAndGet(1L);
        if (bean != null) {
            if (bean.getSegementInfo() != null) {
                System.out.println("task " + taskNum + "执行完毕 " + ip + String.format("========== C:%d,F:%d", Test.createLong.get(), Test.finishLong.get()));
            }
        }
        System.out.println("task " + taskNum + "执行完毕 " + ip + String.format("********** C:%d,F:%d", Test.createLong.get(), Test.finishLong.get()));
    }
}

