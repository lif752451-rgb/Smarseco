package com.crc.log.flink.common.constants;

import org.apache.commons.lang3.StringUtils;

import java.util.concurrent.ConcurrentHashMap;

public class G01Constants {
    public static ConcurrentHashMap<String, String> typeMap = new ConcurrentHashMap<>();
    public static ConcurrentHashMap<String, String> eventMap = new ConcurrentHashMap<>();

    static {
        initEventInfo();
    }

    public static String getEventInfo(String eventIdStr) {
        String info = eventMap.get(eventIdStr);
        if (StringUtils.isBlank(info))
            return "未知";
        return info;
    }

    public static String getEventType(String eventIdStr) {
        if (StringUtils.isNotBlank(eventIdStr) && eventIdStr.length() > 4) {
            String typeId = eventIdStr.substring(0, 4);
            String info = typeMap.get(typeId);
            if (StringUtils.isBlank(info))
                return "未知";
            return info;
        }
        return "未知";
    }

    public static void initEventInfo() {
        String eventArrStr = "";
        eventArrStr += "00000001	监听原始套接字\n";
        eventArrStr += "00000002	更改系统可执行文件\n";
        eventArrStr += "00000003	更改系统配置文件\n";
        eventArrStr += "00000004	更改系统PAM文件\n";
        eventArrStr += "00000005	更改系统引导文件\n";
        eventArrStr += "00000006	非信任进程创建autorun.inf文件\n";
        eventArrStr += "00000007	非信任进程创建Usp10.dll文件\n";
        eventArrStr += "00000008	添加系统启动项\n";
        eventArrStr += "00000009	可疑添加定时任务行为\n";
        eventArrStr += "00000010	修改账户信息\n";
        eventArrStr += "00000011	反连shell\n";
        eventArrStr += "00000012	进程自我复制\n";
        eventArrStr += "00000013	非信任进程修改系统日志\n";
        eventArrStr += "00000014	可疑进程创建可执行文件\n";
        eventArrStr += "00000015	黑名单进程执行危险命令\n";
        eventArrStr += "00000016	信任进程加载无数字签名DLL\n";
        eventArrStr += "00000017	非信任进程创建lpk.dll文件\n";
        eventArrStr += "00000018	非信任进程在系统目录下创建可执行文件\n";
        eventArrStr += "00000019	黑名单进程创建动态页面\n";
        eventArrStr += "00000020	黑名单进程创建危险扩展名文件\n";
        eventArrStr += "00000021	非信任进程在非正常目录下创建可执行文件\n";
        eventArrStr += "00000022	黑名单进程执行扩展非.exe的可执行文件\n";
        eventArrStr += "00000023	粘连键命令被篡改\n";
        eventArrStr += "00000024	加载可疑驱动\n";
        eventArrStr += "00000025	非信任进程尝试劫持系统引导过程\n";
        eventArrStr += "00000026	非信任进程尝试劫持系统登录过程\n";
        eventArrStr += "00000027	非信任进程尝试劫持系统启动过程\n";
        eventArrStr += "00000028	非信任进程尝试劫持EXE执行过程\n";
        eventArrStr += "00000029	非信任进程尝试劫持自启动过程可被禁止\n";
        eventArrStr += "00000030	非信任进程尝试劫持自启动过程可疑\n";
        eventArrStr += "00000031	非信任进程通过组策略劫持开机过程\n";
        eventArrStr += "00000032	非信任进程通过组策略劫持关机过程\n";
        eventArrStr += "00000033	非信任进程通过修改系统服务\n";
        eventArrStr += "00000034	非信任进程修改LSP\n";
        eventArrStr += "00000035	非信任进程修改MSI提权\n";
        eventArrStr += "00000036	非信任进程通过修改屏保程序劫持启动过程\n";
        eventArrStr += "00000037	运行隐藏的进程\n";
        eventArrStr += "00000038	非信任进程创建危险的定时任务脚本\n";
        eventArrStr += "00000039	非信任进程试图修改内核选项\n";
        eventArrStr += "00000040	创建危险的可执行文件\n";
        eventArrStr += "00000041	在BIN目录下面创建隐藏文件夹\n";
        eventArrStr += "00000042	非信任进程创建密码文件的符号链接\n";
        eventArrStr += "00000043	非信任进程在/dev/shm/下创建可执行文件\n";
        eventArrStr += "00000044	系统进程入口不在.init区段(疑似被病毒感染)\n";
        eventArrStr += "00000045	非信任进程尝试编译源代码(exec,.so)\n";
        eventArrStr += "00000046	netcate进程创建shell\n";
        eventArrStr += "00000047	netcat进程访问(读,写)管道\n";
        eventArrStr += "00000048	dd进程读写socket类型文件\n";
        eventArrStr += "00000049	非信任进程修改SSH永久认证文件\n";
        eventArrStr += "00000050	添加用户到管理员组\n";
        eventArrStr += "00000051	进程进行DNS查询\n";
        eventArrStr += "00000052	shell命令审计\n";
        eventArrStr += "00000053	利用系统漏洞提升权限\n";
        eventArrStr += "00010000	CC攻击\n";
        eventArrStr += "00020001	应用存在SQL注入漏洞\n";
        eventArrStr += "00020002	应用存在Struts2漏洞\n";
        eventArrStr += "00020003	应用存在Java反序列化漏洞\n";
        eventArrStr += "00020004	应用存在文件包含漏洞\n";
        eventArrStr += "00020005	应用存在代码执行漏洞\n";
        eventArrStr += "00020006	应用存在上传文件漏洞\n";
        eventArrStr += "00020007	Redis漏洞\n";
        eventArrStr += "00020008	应用存在PHP反序列化漏洞\n";
        eventArrStr += "00020009	WEB容器管理后台弱口令\n";
        eventArrStr += "00020010	FTP弱口令\n";
        eventArrStr += "00020011	应用存在信息泄露漏洞\n";
        eventArrStr += "00020012	SVN信息泄露\n";
        eventArrStr += "00020013	GIT信息泄露\n";
        eventArrStr += "00020014	SSRF漏洞\n";
        eventArrStr += "00020015	WEB可爆破漏洞\n";
        eventArrStr += "00020016	XXE实体注入漏洞\n";
        eventArrStr += "00020017	应用存在命令执行漏洞\n";
        eventArrStr += "00020018	应用存在任意文件读取漏洞\n";
        eventArrStr += "00020019	网站漏洞\n";
        eventArrStr += "00030000	发现已知Webshell\n";
        eventArrStr += "00040000	发现未知Webshell\n";
        eventArrStr += "00050001	应用上传二进制文件\n";
        eventArrStr += "00050002	尝试加载无签名驱动文件\n";
        eventArrStr += "00060001	发现病毒文件\n";
        eventArrStr += "00070001	并发连接数\n";
        eventArrStr += "00070002	吞吐率\n";
        eventArrStr += "00070003	上下行流量\n";
        eventArrStr += "00080001	上下行流量\n";
        eventArrStr += "00090001	IISCPU\n";
        eventArrStr += "00100001	CPU\n";
        eventArrStr += "00100002	内存\n";
        eventArrStr += "00100003	磁盘使用率\n";
        eventArrStr += "00110000	服务器离线\n";
        eventArrStr += "00120000	服务器疑似被入侵\n";
        eventArrStr += "00130000	危险端口暴露\n";
        eventArrStr += "00140000	服务器账户异常登录\n";
        eventArrStr += "00150000	服务器密码已被爆破\n";
        eventArrStr += "00160001	FTP暴力破解\n";
        eventArrStr += "00160002	SMTP暴力破解\n";
        eventArrStr += "00160003	POP3暴力破解\n";
        eventArrStr += "00160004	IMAP暴力破解\n";
        eventArrStr += "00160005	远程登录暴力破解\n";
        eventArrStr += "00160006	SSH登录暴力破解\n";
        eventArrStr += "00170000	TCP端口扫描\n";
        eventArrStr += "00170001	UDP端口扫描\n";
        eventArrStr += "00180001	服务器非法外连\n";
        eventArrStr += "00180002	网站访问异常\n";
        eventArrStr += "00190001	文件异常\n";
        eventArrStr += "00200001	用户异常\n";
        eventArrStr += "00210001	端口异常\n";
        for (String eventStr : eventArrStr.split("\n")) {
            if (StringUtils.isNotBlank(eventStr)) {
                String[] arr = eventStr.split("	");
                if (arr.length == 2) {
                    eventMap.put(arr[0], arr[1]);
                }
            }
        }

        String typeArrStr = "";
        typeArrStr += "0000	可疑行为\n";
        typeArrStr += "0001	CC攻击\n";
        typeArrStr += "0002	漏洞被利用\n";
        typeArrStr += "0003	已知Webshell\n";
        typeArrStr += "0004	未知Webshell\n";
        typeArrStr += "0005	可疑二进制文件\n";
        typeArrStr += "0006	病毒\n";
        typeArrStr += "0007	WEB流量异常\n";
        typeArrStr += "0008	网络流量异常\n";
        typeArrStr += "0009	WEB资源异常\n";
        typeArrStr += "0010	系统资源异常\n";
        typeArrStr += "0011	服务器离线\n";
        typeArrStr += "0012	服务器疑似被入侵\n";
        typeArrStr += "0013	危险端口暴露\n";
        typeArrStr += "0014	服务器账户异常登录\n";
        typeArrStr += "0015	服务器密码已被爆破\n";
        typeArrStr += "0016	暴力破解事件\n";
        typeArrStr += "0017	端口扫描\n";
        typeArrStr += "0018	异常事件\n";
        typeArrStr += "0019	文件异常监测\n";
        typeArrStr += "0020	用户异常监测\n";
        typeArrStr += "0021	端口异常监测\n";

        for (String eventStr : typeArrStr.split("\n")) {
            if (StringUtils.isNotBlank(eventStr)) {
                String[] arr = eventStr.split("	");
                if (arr.length == 2) {
                    typeMap.put(arr[0], arr[1]);
                }
            }
        }
    }
}
