package com.crc.log.flink.parse;

import com.crc.log.flink.common.constants.LevelConstants;
import com.crc.log.flink.common.constants.LogConstants;
import com.crc.log.flink.common.utils.DataUtils;
import com.crc.log.flink.common.utils.JsonUtils;
import com.crc.log.flink.common.utils.MapUtils;
import org.apache.commons.lang3.StringUtils;

import java.util.HashMap;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

/**
 * @author jixiangqi
 * @date 2022/2/17
 * 亚信安全日志
 */
public class ResolvYaXinSafeLog {
    public static ConcurrentHashMap<String, Object> parse(String message) {
        try {
            ConcurrentHashMap<String, Object> data = proc(message);
            if (DataUtils.isNotEmptyJson(data)) {
                return data;
            }
        } catch (Exception ignored) {

        }
        return null;
    }

    private static ConcurrentHashMap<String, Object> proc(String jsonStr) {
        ConcurrentHashMap<String, Object> rtnObjc = JsonUtils.createBaseMap(jsonStr);
        String[] split = DataUtils.getSplit(jsonStr, "\\|");
                //jsonStr.split("\\|");
        if (jsonStr.contains("CEF:")) {
            for (int i = 0; i < split.length; i++) {
                String temp = split[i].trim();
                switch (i) {
                    case 2:
                        rtnObjc.put(LogConstants.DEVICE_NAME, temp);
                        break;
                    case 3:
                        rtnObjc.put(LogConstants.DEVICE_TYPE, temp);
                        break;
                    case 6:
                        rtnObjc.put(LogConstants.LOG_LEVEL, LevelConstants.getLevel(temp));
                        break;
                    case 7:
                        Map<String, String> resultMap = getSpace(temp);
                        resultMap.forEach((k,v) -> {
                            k = k.toLowerCase();
                            switch (k.trim()) {
                                case "cn1label":
                                    rtnObjc.put(LogConstants.DEVICE_ID, v.trim());
                                    break;
                                case "filepath":
                                    rtnObjc.put(LogConstants.FILE_PATH, v.trim());
                                    break;
                                case "act":
                                    rtnObjc.put(LogConstants.ACTION_TYPE, v.trim());
                                    break;
                                case "msg":
                                    rtnObjc.put(LogConstants.LOG_CONTENT, v.trim());
                                    break;
                                case "ip":
                                case "src":
                                    rtnObjc.put(LogConstants.SRC_IP, v.trim());
                                    break;
                                case "suser":
                                    rtnObjc.put(LogConstants.USER_NAME, v.trim());
                                    break;
                                case "dvc":
                                    rtnObjc.put(LogConstants.LOG_DEV_IP, v.trim());
                                    break;
                                case "target":
                                    rtnObjc.put(LogConstants.DEST_IP, v.trim());
                                    break;
                                case "malname":
                                    rtnObjc.put(LogConstants.LOG_NAME, v.trim());
                                    break;
                            }
                        });
                }
            }
        } else if (jsonStr.contains("LEEF:")) {
            for (int i = 0; i < split.length; i++) {
                String temp = split[i].trim();
                switch (i) {
                    case 2:
                        rtnObjc.put(LogConstants.DEVICE_NAME, temp);
                        break;
                    case 3:
                        rtnObjc.put(LogConstants.DEVICE_TYPE, temp);
                        break;
                    case 5:
                        Map<String, String> resultMap = getSpace(temp);
                        resultMap.forEach((k,v) -> {
                            switch (k.trim()) {
                                case "cat":
                                    rtnObjc.put(LogConstants.LOG_TYPE, v.trim());
                                    break;
                                case "name":
                                    rtnObjc.put(LogConstants.LOG_NAME, v.trim());
                                    break;
                                case "desc":
                                    rtnObjc.put(LogConstants.LOG_DESCRIPTION, v.trim());
                                    break;
                                case "msg":
                                    rtnObjc.put(LogConstants.LOG_CONTENT, v.trim());
                                    break;
                                case "sev":
                                    rtnObjc.put(LogConstants.LOG_LEVEL, v.trim());
                                    break;
                                case "usrName":
                                    rtnObjc.put(LogConstants.USER_NAME, v.trim());
                                    break;
                                case "cn1Label":
                                    rtnObjc.put(LogConstants.DEVICE_ID, v.trim());
                                    break;
                                case "filePath":
                                    rtnObjc.put(LogConstants.FILE_PATH, v.trim());
                                    break;
                                case "act":
                                    rtnObjc.put(LogConstants.ACTION_TYPE, v.trim());
                                    break;
                                case "src":
                                    rtnObjc.put(LogConstants.SRC_IP, v.trim());
                                    break;
                                case "dvc":
                                    rtnObjc.put(LogConstants.LOG_DEV_IP, v.trim());
                                    break;
                                case "target":
                                    rtnObjc.put(LogConstants.DEST_IP, v.trim());
                                    break;
                            }
                        });
                }
            }
        } else {
            Map<String, String> space = getSpace(jsonStr);
            space.forEach((k, v) -> {
                switch (k.trim()) {
                    case "EVENTNUMBER":
                        rtnObjc.put(LogConstants.EVENT_ID, v.trim());
                        break;
                    case "TITLE":
                        rtnObjc.put(LogConstants.LOG_NAME, v.trim());
                        break;
                    case "TARGET":
                        rtnObjc.put(LogConstants.SRC_IP, v.trim());
                        break;
                    case "ACTIONBY":
                        rtnObjc.put(LogConstants.ACTION_OBJ, v.trim());
                        break;
                    case "DESCRIPTION":
                        rtnObjc.put(LogConstants.LOG_DESCRIPTION, v.trim());
                        break;
                }
            });
        }
        rtnObjc.put(LogConstants.LOG_PRODUCT, "亚信防病毒");
        if (StringUtils.isBlank(MapUtils.getStr(rtnObjc, LogConstants.SRC_IP))) {
            rtnObjc.put(LogConstants.SRC_IP, "0.0.0.0");
        }
        if (StringUtils.isBlank(MapUtils.getStr(rtnObjc, LogConstants.DEST_IP))) {
            rtnObjc.put(LogConstants.DEST_IP, "0.0.0.0");
        }
        if (StringUtils.isBlank(MapUtils.getStr(rtnObjc, LogConstants.LOG_LEVEL))) {
            rtnObjc.put(LogConstants.LOG_LEVEL, LevelConstants.getLevel(MapUtils.getStr(rtnObjc,LogConstants.LOG_LEVEL)));
        }
        setAlertName(rtnObjc);
        return rtnObjc;
    }


    private static Map<String, String> getSpace(String jsonStr) {
        Map<String,String> resultMap = new HashMap<>();
        String index = "";
        String[] s = DataUtils.getSplit(jsonStr, " ");
        for (String temp : s) {
            if (temp.contains("=")) {
                String[] split = DataUtils.getSplit(temp, "=");
                //temp.split("=");
                if (split.length == 2) {
                    resultMap.put(split[0].trim(), split[1].trim());
                    index = split[0].trim();
                }
            } else {
                resultMap.put(index, DataUtils.getString(resultMap, "index") + " " + temp);
            }
        }
        return resultMap;
    }

    private static void setAlertName(ConcurrentHashMap<String, Object> rtnObjc) {
        String msgFormat = "亚信安全产生了一个安全事件,事件详情为:%s";
        String log = MapUtils.getStr(rtnObjc, LogConstants.LOG_ORI_MSG);
        String alertName = String.format(msgFormat, log);
        rtnObjc.put(LogConstants.ALERT_NAME, alertName);
    }
}
