package com.crc.log.flink.schedule;


import com.crc.log.flink.load.*;
import lombok.extern.slf4j.Slf4j;
import org.springframework.boot.CommandLineRunner;
import org.springframework.scheduling.annotation.EnableScheduling;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Component;

/**
 * 配置信息，定时加载
 */
@Slf4j
@Component
@EnableScheduling
public class ConfigInitSchedule implements CommandLineRunner {

    /**
     * 启动时加载
     * @param args 参数
     */
    @Override
    public void run(String... args) {
        sync();
    }

    /**
     * 定时执行，每N分钟统计一次
     */
    @Scheduled(cron = "0 0/3 * * * ?")
    private void sync() {
        try {
            log.info("加载网段数据");
            NewSegmentLoad newSeg = new NewSegmentLoad();
            newSeg.sync();
        } catch (Exception e) {
            log.error(e.getMessage(),e);
        }

        try {
            log.info("加载DMZ数据");
            NewUserSegmentLoad newUserSegmentLoad = new NewUserSegmentLoad();
            newUserSegmentLoad.syncAll();
        } catch (Exception e) {
            log.error(e.getMessage(),e);
        }

        try {
            log.info("开始加载规则");
            EventRuleLoad.syncRule();
            log.info("读取规则数：" + EventRuleLoad.IpTopicMapping.size());
        } catch (Exception e) {
            log.error(e.getMessage(),e);
        }

        try {
            log.info("加载资产数据,预计 5 秒钟，请等候");
            AssetDataLoad.loadAssetMap();
        } catch (Exception e) {
            log.error(e.getMessage(),e);
        }

        try {
            SbrProdTypeLoad.sync();
        } catch (Exception e) {
            log.error(e.getMessage(), e);
        }
    }

}
