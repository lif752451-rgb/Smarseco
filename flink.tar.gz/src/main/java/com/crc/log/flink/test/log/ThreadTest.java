package com.crc.log.flink.test.log;

import com.crc.log.flink.common.utils.DataUtils;
import com.crc.log.flink.common.utils.MyTheadUtils;

import java.util.concurrent.CompletableFuture;
import java.util.concurrent.TimeUnit;

public class ThreadTest {

    public static void main(String[] args) {
        long timeout = 3000;
        CompletableFuture<Object> future = CompletableFuture.supplyAsync(()-> longRunningMethod());
        try {
            Object result = future.get(timeout, TimeUnit.MILLISECONDS);
            System.out.println("执行完毕："+result.toString());
        } catch (Exception e) {
            e.printStackTrace();
            future.cancel(true);
        }
    }

    private static <U> U longRunningMethod() {
        MyTheadUtils.sleepBySec(DataUtils.getRandom(5,2));
        System.out.println("longRunningMethod");
        return null;
    }

}
