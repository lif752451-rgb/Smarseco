package com.crc.log.flink.common.entity;

public class IpMappgingRule {
    private String ip;
    private String topic;
    private String resolvClass;
    private String ruleGroup;
    private String product;

    public static IpMappgingRule getRuleMapping(String ip, String topic, String resolvClass, String ruleGroup,String product) {
        IpMappgingRule imr = new IpMappgingRule();
        imr.setIp(ip);
        imr.setTopic(topic);
        imr.setResolvClass(resolvClass);
        imr.setProduct(product);
        imr.setRuleGroup(ruleGroup);
        return imr;
    }

    public String getProduct() {
        return product;
    }

    public void setProduct(String product) {
        this.product = product;
    }

    public String getIp() {
        return ip;
    }

    public void setIp(String ip) {
        this.ip = ip;
    }

    public String getTopic() {
        return topic;
    }

    public void setTopic(String topic) {
        this.topic = topic;
    }

    public String getResolvClass() {
        return resolvClass;
    }

    public void setResolvClass(String resolvClass) {
        this.resolvClass = resolvClass;
    }

    public String getRuleGroup() {
        return ruleGroup;
    }

    public void setRuleGroup(String ruleGroup) {
        this.ruleGroup = ruleGroup;
    }
}
