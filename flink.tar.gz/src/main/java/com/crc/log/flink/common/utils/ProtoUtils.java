package com.crc.log.flink.common.utils;

/**
 * @author jixiangqi
 * @date 2022/5/6
 * 协议转换
 */
public class ProtoUtils {


    public static String switchProto(int num) {
        String value = "";
        switch (num) {
            case 0:
                value = "HOPOPT";
                break;
            case 1:
                value = "ICMP";
                break;
            case 2:
                value = "IGMP";
                break;
            case 3:
                value = "GGP";
                break;
            case 4:
                value = "IP";
                break;
            case 5:
                value = "ST";
                break;
            case 6:
                value = "TCP";
                break;
            case 7:
                value = "CBT";
                break;
            case 8:
                value = "EGP";
                break;
            case 9:
                value = "IGP";
                break;
            case 10:
                value = "BBN-RCC-MON";
                break;
            case 11:
                value = "NVP-II";
                break;
            case 12:
                value = "PUP";
                break;
            case 13:
                value = "ARGUS";
                break;
            case 15:
                value = "XNET";
                break;
            case 14:
                value = "EMCON";
                break;
            case 16:
                value = "CHAOS";
                break;
            case 17:
                value = "UDP";
                break;
            case 18:
                value = "MUX";
                break;
            case 19:
                value = "DCN-MEAS";
                break;
            case 20:
                value = "HMP";
                break;
            case 21:
                value = "PRM";
                break;
            case 22:
                value = "XNS-IDP";
                break;
            case 23:
                value = "TRUNK-1";
                break;
            case 24:
                value = "TRUNK-2";
                break;
            case 25:
                value = "LEAF-1";
                break;
            case 26:
                value = "LEAF-2";
                break;
            case 27:
                value = "RDP";
                break;
            case 28:
                value = "IRTP";
                break;
            case 29:
                value = "ISO-TP4";
                break;
            case 30:
                value = "NETBLT";
                break;
            case 31:
                value = "MFE-NSP";
                break;
            case 32:
                value = "MERIT-INP";
                break;
            case 33:
                value = "SEP";
                break;
            case 34:
                value = "3PC";
                break;
            case 35:
                value = "IDPR";
                break;
            case 36:
                value = "XTP";
                break;
            case 37:
                value = "DDP";
                break;
            case 38:
                value = "IDPR-CMTP";
                break;
            case 39:
                value = "TP++";
                break;
            case 40:
                value = "IL";
                break;
            case 41:
                value = "IPv6";
                break;
            case 42:
                value = "SDRP";
                break;
            case 43:
                value = "IPv6-Route";
                break;
            case 44:
                value = "IPv6-Frag";
                break;
            case 45:
                value = "IDRP";
                break;
            case 46:
                value = "RSVP";
                break;
            case 47:
                value = "GRE";
                break;
            case 48:
                value = "MHRP";
                break;
            case 49:
                value = "BNA";
                break;



            case 50:
                value = "ESP";
                break;
            case 51:
                value = "AH";
                break;
            case 52:
                value = "I-NLSP";
                break;
            case 53:
                value = "SWIPE";
                break;
            case 54:
                value = "NARP";
                break;
            case 55:
                value = "MOBILE";
                break;
            case 56:
                value = "TLSP";
                break;
            case 57:
                value = "SKIP";
                break;
            case 58:
                value = "IPv6-ICMP";
                break;
            case 59:
                value = "IPv6-NoNxt";
                break;
            case 60:
                value = "IPv6-Opts";
                break;
           /* case 11:
                value = "";
                break;*/
            case 62:
                value = "CFTP";
                break;
           /* case 13:
                value = "ARGUS";
                break;*/
            case 65:
                value = "KRYPTOLAN";
                break;
            case 64:
                value = "SAT-EXPAK";
                break;
            case 66:
                value = "RVD";
                break;
            case 67:
                value = "IPPC";
                break;
            /*case 18:
                value = "MUX";
                break;*/
            case 69:
                value = "SAT-MON";
                break;
            case 70:
                value = "VISA";
                break;
            case 71:
                value = "IPCV";
                break;
            case 72:
                value = "CPNX";
                break;
            case 73:
                value = "CPHB";
                break;
            case 74:
                value = "WSN";
                break;
            case 75:
                value = "PVP";
                break;
            case 76:
                value = "BR-SAT-MON";
                break;
            case 77:
                value = "SUN-ND";
                break;
            case 78:
                value = "WB-MON";
                break;
            case 79:
                value = "WB-EXPAK";
                break;
            case 80:
                value = "ISO-IP";
                break;
            case 81:
                value = "VMTP";
                break;
            case 82:
                value = "SECURE-VMTP";
                break;
            case 83:
                value = "VINES";
                break;
            case 84:
                value = "TTP";
                break;
            case 85:
                value = "NSFNET-IGP";
                break;
            case 86:
                value = "DGP";
                break;
            case 87:
                value = "TCF";
                break;
            case 88:
                value = "EIGRP";
                break;
            case 89:
                value = "OSPFIGP";
                break;
            case 90:
                value = "Sprite-RPC";
                break;
            case 91:
                value = "LARP";
                break;
            case 92:
                value = "MTP";
                break;
            case 93:
                value = "AX.25";
                break;
            case 94:
                value = "IPIP";
                break;
            case 95:
                value = "MICP";
                break;
            case 96:
                value = "SCC-SP";
                break;
            case 97:
                value = "ETHERIP";
                break;
            case 98:
                value = "ENCAP";
                break;
            case 100:
                value = "GMTP";
                break;



            case 101:
                value = "IFMP";
                break;
            case 102:
                value = "PNNI";
                break;
            case 103:
                value = "PIM";
                break;
            case 104:
                value = "ARIS";
                break;
            case 105:
                value = "SCPS";
                break;
            case 106:
                value = "QNX";
                break;
            case 107:
                value = "A/N";
                break;
            case 108:
                value = "IPComp";
                break;
            case 109:
                value = "SNP";
                break;
            case 110:
                value = "Compaq-Peer";
                break;
            case 111:
                value = "IPX-in-IP";
                break;
            case 112:
                value = "VRRP";
                break;
            case 113:
                value = "PGM";
                break;
            case 116:
                value = "DDX";
                break;
            case 115:
                value = "L2TP";
                break;
            case 117:
                value = "IATP";
                break;
            case 118:
                value = "STP";
                break;
            case 119:
                value = "SRP";
                break;
            case 120:
                value = "UTI";
                break;
            case 121:
                value = "SMP";
                break;
            case 122:
                value = "SM";
                break;
            case 123:
                value = "PTP";
                break;
            case 124:
                value = "ISIS";
                break;
            case 125:
                value = "FIRE";
                break;
            case 126:
                value = "CRTP";
                break;
            case 127:
                value = "CRUDP";
                break;
            case 128:
                value = "SSCOPMCE";
                break;
            case 129:
                value = "IPLT";
                break;
            case 130:
                value = "SPS";
                break;
            case 131:
                value = "PIPE";
                break;
            case 132:
                value = "SCTP";
                break;
            case 133:
                value = "FC";
                break;
        }
        return value;
    }

}
