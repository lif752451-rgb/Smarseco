package com.crc.log.flink.test;


import com.crc.log.flink.common.utils.CodeTool;

public class CodeToolTest {
    public static void main(String[] args) throws Exception {
        t("yujdc++FD12");
        t("ssp!@#123");
        t("Ssp!@#web123");
    }

    public static void t(String s1) throws Exception {
        String s = CodeTool.encrypt(s1,"IpTFX6FjYs5zKDG8gjKFh7kTgCFdWWJE");
        System.out.println(s);
    }
}
