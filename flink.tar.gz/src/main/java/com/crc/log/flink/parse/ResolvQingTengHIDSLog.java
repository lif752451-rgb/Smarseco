package com.crc.log.flink.parse;

import com.crc.log.flink.common.constants.LevelConstants;
import com.crc.log.flink.common.constants.LogConstants;
import com.crc.log.flink.common.utils.DataUtils;
import com.crc.log.flink.common.utils.DateUtils;
import com.crc.log.flink.common.utils.JsonUtils;
import com.crc.log.flink.common.utils.MapUtils;
import lombok.extern.slf4j.Slf4j;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Locale;
import java.util.concurrent.ConcurrentHashMap;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * @author jixiangqi
 * @date 2022/5/25
 * 青藤-HIDS
 */
@Slf4j
public class ResolvQingTengHIDSLog {
    private static final String WEB_REG = "((?:Jan|Feb|Mar|May|Jun|Jul|Aug|Sep|Oct|Nov|Dec)\\s+\\d+\\s+\\d+\\:\\d+\\:\\d+).*datatype=\"([^\\\"]+)\"\\s+.*datatime.*agent_ip=\"(\\d+\\.\\d+\\.\\d+\\.\\d+)\"\\s+host_name=\"([^\\\"]+)\"\\s+internal_ip=\"(\\d+\\.\\d+\\.\\d+\\.\\d+)\"\\s+external_ip=\"(.*)?\"\\s+host_tag=\"(.*)?\"\\s+host_memo=\"(.*)?\"\\s+group_name=\"([^\\\"]+)\"\\s+action=\"([^\\\"]+)\"\\s+type=\"([^\\\"]+)\"\\s+group=\"([^\\\"]+)\".*event_type=\"([^\\\"]+)\"\\s+event_name=\"([^\\\"]+)\"\\s+event_level=\"([^\\\"]+)\"\\s+event_content=\"([^\\\"]+)\"\\s+url=\"([^\\\"]+)\"\\s+detail.process_name=\"([^\\\"]+)\"\\s+detail.process_tree=\"([^\\\"]+)\"\\s+detail.hit_rule_name=\"([^\\\"]+)\"";

    private static final String LOG_REG = "((?:Jan|Feb|Mar|May|Jun|Jul|Aug|Sep|Oct|Nov|Dec)\\s+\\d+\\s+\\d+\\:\\d+\\:\\d+).*datatype=\"([^\\\"]+)\".*agent_ip=\"([^\\\"]+)\"\\s+host_name=\"([^\\\"]+)\"\\s+internal_ip=\"(\\d+\\.\\d+\\.\\d+\\.\\d+)\"\\s+external_ip=\"(.*)?\"\\s+host_tag=\"(.*)?\"\\s+host_memo=\"(.*)?\"\\s+group_name=\"([^\\\"]+)\"\\s+severity=\"(\\d+)\"\\s+action=\"([^\\\"]+)\"\\s+type=\"([^\\\"]+)\"\\s+group=\"([^\\\"]+)\"\\s+agent_id=\"([^\\\"]+)\".*os=\"([^\\\"]+)\"\\s+log_type=\"([^\\\"]+)\"\\s+src_ip=\"(\\d+\\.\\d+\\.\\d+\\.\\d+)\"\\s+location=\"([^\\\"]+)\"\\s+.*pid=\"([^\\\"]+)\"\\s+uname=\"([^\\\"]+)\"\\s+port=\"(\\d+)\"\\s+login_con_port=\"(\\d+)\"\\s+login_type=\"([^\\\"]+)\"\\s+login_err_reason=\"([^\\\"]+)\"\\s+logout_reason=\"([^\\\"]+)\"";

    static SimpleDateFormat dateFormat = new SimpleDateFormat("MMM d HH:mm:ss yyyy", Locale.ENGLISH);
    /**
     * IPS 日志泛化
     */
    public static ConcurrentHashMap<String, Object> parse(String message) {
        try {
            ConcurrentHashMap<String, Object> data = proc(message);
            if (DataUtils.isNotEmptyJson(data)) {
                return data;
            }
        } catch (Exception ignored) {

        }
        return null;
    }

    private static ConcurrentHashMap<String, Object> proc(String jsonStr) {
        ConcurrentHashMap<String, Object> rtnObjc = JsonUtils.createBaseMap(jsonStr);
        try {
            getFieldsByPattern(jsonStr, rtnObjc);
        } catch (Exception e) {
            log.error(e.getMessage(),e);
        }
        rtnObjc.put(LogConstants.LOG_PRODUCT, "青藤HIDS");
        rtnObjc.put(LogConstants.LOG_LEVEL, LevelConstants.getLevel(MapUtils.getStr(rtnObjc,LogConstants.LOG_LEVEL)));
        if (org.apache.commons.lang3.StringUtils.isBlank(MapUtils.getStr(rtnObjc, LogConstants.SRC_IP))) {
            rtnObjc.put(LogConstants.SRC_IP, "0.0.0.0");
        }
        if (org.apache.commons.lang3.StringUtils.isBlank(MapUtils.getStr(rtnObjc, LogConstants.DEST_IP))) {
            rtnObjc.put(LogConstants.DEST_IP, "0.0.0.0");
        }
        setAlertName(rtnObjc);
        return rtnObjc;
    }

    private static void setAlertName(ConcurrentHashMap<String, Object> rtnObjc) {
        String logType = MapUtils.getStr(rtnObjc, LogConstants.LOG_TYPE);
        String log = MapUtils.getStr(rtnObjc, LogConstants.LOG_ORI_MSG);
        String message = "";
        String alertName = "";
        if (logType.equals("web_command")) {
            String hostName = MapUtils.getStr(rtnObjc, LogConstants.HOST_NAME);
            String logName = MapUtils.getStr(rtnObjc, LogConstants.LOG_NAME);
            String content = MapUtils.getStr(rtnObjc, LogConstants.LOG_CONTENT);
            String url = MapUtils.getStr(rtnObjc, LogConstants.LOG_URL);
            message = "在主机名为:%s的设备上出现了%s类型的日志,日志名称为:%s,日志内容为:%s,ulr为:%s,日志详情为:%s";
            alertName = String.format(message, hostName, logType, logName, content, url, log);
        } else if (logType.equals("access_log")) {
            String userName = MapUtils.getStr(rtnObjc, LogConstants.USER_NAME);
            String srcIp = MapUtils.getStr(rtnObjc, LogConstants.SRC_IP);
            String os = MapUtils.getStr(rtnObjc, LogConstants.OS_INFO);
            message = "用户为:%s在IP为:%s的主机上产生了%s日志,系统类型为:%s,日志详情为:%s";
            alertName = String.format(message, userName, srcIp, logType, os, log);
        }
        rtnObjc.put(LogConstants.ALERT_NAME, alertName);
    }

    private static void getFieldsByPattern(String jsonStr, ConcurrentHashMap<String, Object> rtnObjc) throws ParseException {
        if (jsonStr.contains("web_command")) {
            Pattern pattern = Pattern.compile(WEB_REG);
            Matcher matcher = pattern.matcher(jsonStr);
            while (matcher.find()) {
                rtnObjc.put(LogConstants.LOG_START_TIME, DateUtils.getISO8601Timestamp(dateFormat.parse(matcher.group(1) + " " +DateUtils.getYear())));
                rtnObjc.put(LogConstants.LOG_TYPE, matcher.group(2));
                rtnObjc.put(LogConstants.SRC_IP, matcher.group(3));
                rtnObjc.put(LogConstants.HOST_NAME, matcher.group(4));
                rtnObjc.put(LogConstants.DEST_PORT, matcher.group(5));
                rtnObjc.put(LogConstants.GROUP_NAME, matcher.group(9));
                rtnObjc.put(LogConstants.ACTION_TYPE, matcher.group(10));
                //rtnObjc.put(LogConstants.LOG_TYPE, matcher.group(11));
                rtnObjc.put(LogConstants.LOG_NAME, matcher.group(14));
                rtnObjc.put(LogConstants.LOG_LEVEL, LevelConstants.getLevel(matcher.group(15)));
                rtnObjc.put(LogConstants.LOG_CONTENT, matcher.group(16));
                rtnObjc.put(LogConstants.LOG_URL, matcher.group(17));
            }
        } else if (jsonStr.contains("access_log")){
            Pattern pattern = Pattern.compile(LOG_REG);
            Matcher matcher = pattern.matcher(jsonStr);
            while (matcher.find()) {
                rtnObjc.put(LogConstants.LOG_START_TIME, DateUtils.getISO8601Timestamp(dateFormat.parse(matcher.group(1) + " " +DateUtils.getYear())));
                rtnObjc.put(LogConstants.LOG_TYPE, matcher.group(2));
                rtnObjc.put(LogConstants.HOST_NAME, matcher.group(4));
                rtnObjc.put(LogConstants.DEST_PORT, matcher.group(5));
                rtnObjc.put(LogConstants.GROUP_NAME, matcher.group(9));
                rtnObjc.put(LogConstants.LOG_LEVEL, LevelConstants.getLevel(matcher.group(10)));
                rtnObjc.put(LogConstants.OS_INFO, matcher.group(15));
                rtnObjc.put(LogConstants.SRC_IP, matcher.group(17));
                rtnObjc.put(LogConstants.USER_NAME, matcher.group(20));
                rtnObjc.put(LogConstants.SRC_PORT, matcher.group(21));
            }
        }

    }

}
