package com.crc.log.flink.parse;

import com.crc.log.flink.common.constants.ActionResultConstants;
import com.crc.log.flink.common.constants.LevelConstants;
import com.crc.log.flink.common.constants.LogConstants;
import com.crc.log.flink.common.utils.DataUtils;
import com.crc.log.flink.common.utils.IPUtil;
import com.crc.log.flink.common.utils.JsonUtils;
import com.crc.log.flink.common.utils.MapUtils;
import org.apache.commons.lang3.StringUtils;

import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.ConcurrentHashMap;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * 深信服负载均衡
 */
public class ResolvLinkLoadBalancingLog {

    /**
     * IPS 日志泛化
     */
    public static ConcurrentHashMap<String,Object> parse(String message) {
        try {
            ConcurrentHashMap<String,Object> data = proc(message);
            if (DataUtils.isNotEmptyJson(data)) {
                return data;
            }
        } catch (Exception ignored) {

        }
        return null;
    }

    private static ConcurrentHashMap<String,Object> proc(String jsonStr) {
        ConcurrentHashMap<String,Object> rtnObjc = JsonUtils.createBaseMap(jsonStr);
        boolean flag = logType(jsonStr);
        if (flag) {
            adminTypeLog(jsonStr, rtnObjc);
            setAlertName(rtnObjc, 0);
        } else {
            serviceTypeLog(jsonStr, rtnObjc);
            setAlertName(rtnObjc, 1);
        }
        rtnObjc.put(LogConstants.LOG_PRODUCT, "深信服负载均衡");
        return rtnObjc;
    }

    private static boolean logType(String jsonStr) {
        String[] array = DataUtils.getSplit(jsonStr, ",");
                //jsonStr.split(",");
        if (array.length > 1 && array[1].contains("\"")) {
            array[1] = array[1].replaceAll("\"","");
        }
        return array.length > 1 && IPUtil.isIp(array[1]);
    }

    /**
     * @param jsonStr
     * @param rtnObjc
     */
    private static void serviceTypeLog(String jsonStr, ConcurrentHashMap<String,Object> rtnObjc){
        int count = 0;
        int index = 0;
        for (int i = 0; i < jsonStr.length(); i++) {
            char c = jsonStr.charAt(i);
            if (c == ':') {
                count ++;
            }
            if (count == 3) {
                index = i;
                break;
            }
        }
        String tempStr = DataUtils.getSubString(jsonStr, 0, index);
                // jsonStr.substring(0, index);
        int index1 = DataUtils.getLastIndex(tempStr.trim(), " ");
                //tempStr.trim().lastIndexOf(" ");
        String hostName = DataUtils.getSubString(jsonStr, index1+1, index);
                //jsonStr.substring(index1+1, index);
        tempStr = DataUtils.getSubString(jsonStr, index+1);
                //jsonStr.substring(index+1);
        int index2 = DataUtils.getIndex(tempStr, ":");
                //tempStr.indexOf(":");
        String modularName = DataUtils.getSubString(tempStr, 0, index2);
                //tempStr.substring(0, index2);
        String content = DataUtils.getSubString(tempStr, index2+1);
                //tempStr.substring(index2+1);
        List<String> ips = getIps(content);
        if (ips.size() > 1) {
            MapUtils.setStr(rtnObjc, LogConstants.SRC_IP, ips.get(0));
            MapUtils.setStr(rtnObjc, LogConstants.DEST_IP, ips.get(1));
        } else if (ips.size() == 1) {
            MapUtils.setStr(rtnObjc, LogConstants.SRC_IP, ips.get(0));
        }
        MapUtils.setStr(rtnObjc, LogConstants.HOST_NAME, hostName);
        MapUtils.setStr(rtnObjc, LogConstants.SRC_INSTANCE, modularName);
        MapUtils.setStr(rtnObjc, LogConstants.LOG_ORI_MSG, content);
        rtnObjc.put(LogConstants.LOG_LEVEL, LevelConstants.getLevel(MapUtils.getStr(rtnObjc,LogConstants.LOG_LEVEL)));
        if (StringUtils.isBlank(MapUtils.getStr(rtnObjc, LogConstants.SRC_IP))) {
            rtnObjc.put(LogConstants.SRC_IP, "0.0.0.0");
        }
        if (StringUtils.isBlank(MapUtils.getStr(rtnObjc, LogConstants.DEST_IP))) {
            rtnObjc.put(LogConstants.DEST_IP, "0.0.0.0");
        }
    }

    /**
     * @param jsonStr
     * @param rtnObjc
     */
    private static void adminTypeLog(String jsonStr, ConcurrentHashMap<String,Object> rtnObjc) {

        String[] array = DataUtils.getSplit(jsonStr, ",");
                //jsonStr.split(",");
        if (array.length >= 5) {
            int index = DataUtils.getLastIndex(array[0], ":");
            //array[0].lastIndexOf(":");
            String admin = DataUtils.getSubString(array[0], index+1);
            //array[0].substring(index+1);
            String tempStr = DataUtils.getSubString(array[0], 0, index+1).trim();
            //array[0].substring(0,index).trim();
            index = DataUtils.getLastIndex(array[0], " ");
            //tempStr.lastIndexOf(" ");
            String hostName = DataUtils.getSubString(array[0], index+1);
            //tempStr.substring(index+1);
            String ip = array[1];
            String actionType = array[2];
            String confType = array[3];
            String actionProcess = array[5];
            String result = array[4];
            MapUtils.setStr(rtnObjc, LogConstants.HOST_NAME, hostName);
            MapUtils.setStr(rtnObjc, LogConstants.USER_NAME, admin);
            MapUtils.setStr(rtnObjc, LogConstants.LOG_DEV_IP, ip);
            MapUtils.setStr(rtnObjc, LogConstants.ACTION_TYPE, actionType);
            MapUtils.setStr(rtnObjc, LogConstants.CONF_TYPE, confType);
            MapUtils.setStr(rtnObjc, LogConstants.ACTION_PROCESS, actionProcess);
            MapUtils.setStr(rtnObjc, LogConstants.ACTION_RESULT, result);
            rtnObjc.put(LogConstants.LOG_LEVEL, LevelConstants.getLevel(MapUtils.getStr(rtnObjc,LogConstants.LOG_LEVEL)));
            String actionResult = "success".equalsIgnoreCase(MapUtils.getStr(rtnObjc,LogConstants.ACTION_RESULT)) ?
                    ActionResultConstants.DENY : ActionResultConstants.NO_DENY;
            rtnObjc.put(LogConstants.ACTION_RESULT, actionResult);
            if (StringUtils.isBlank(MapUtils.getStr(rtnObjc, LogConstants.SRC_IP))) {
                rtnObjc.put(LogConstants.SRC_IP, "0.0.0.0");
            }
            if (StringUtils.isBlank(MapUtils.getStr(rtnObjc, LogConstants.DEST_IP))) {
                rtnObjc.put(LogConstants.DEST_IP, "0.0.0.0");
            }
        }
    }

    private static void setAlertName(ConcurrentHashMap<String,Object> rtnObjc, int type) {
        String msgFormat = "";
        String alertName = "";
        String srcIp = MapUtils.getStr(rtnObjc, LogConstants.SRC_IP);
        String destIp = MapUtils.getStr(rtnObjc, LogConstants.DEST_IP);
        String hostName = MapUtils.getStr(rtnObjc, LogConstants.HOST_NAME);
        String level = MapUtils.getStr(rtnObjc, LogConstants.LOG_LEVEL);
        String action = MapUtils.getStr(rtnObjc, LogConstants.ACTION_TYPE);
        String result = MapUtils.getStr(rtnObjc, LogConstants.ACTION_RESULT);
        String log = MapUtils.getStr(rtnObjc, LogConstants.LOG_ORI_MSG);
        if (type == 0) {
            if (!srcIp.equals("0.0.0.0") && !destIp.equals("0.0.0.0") ) {
                msgFormat = "源IP:%s,目的IP:%s,请求类型:%s,请求结果:%s,风险级别:%s,日志详情为:%s";
                alertName = String.format(msgFormat, srcIp, destIp, action, result, level, log);
            } else {
                msgFormat = "主机为:%s,请求类型:%s,请求结果:%s,风险级别:%s,日志详情为:%s";
                alertName = String.format(msgFormat, hostName, action, result, level, log);
            }
        } else {
            if (!srcIp.equals("0.0.0.0") && !destIp.equals("0.0.0.0") ) {
                msgFormat = "源IP:%s,目的IP:%s,风险级别:%s,日志详情为:%s";
                alertName = String.format(msgFormat, srcIp, destIp, level, log);
            } else {
                msgFormat = "主机为:%s,风险级别:%s,日志详情为:%s";
                alertName = String.format(msgFormat, hostName, level, log);
            }
        }
        rtnObjc.put(LogConstants.ALERT_NAME, alertName);
    }


    public static List<String> getIps(String ipString){
        String regEx="((2[0-4]\\d|25[0-5]|[01]?\\d\\d?)\\.){3}(2[0-4]\\d|25[0-5]|[01]?\\d\\d?)";
        List<String> ips = new ArrayList<String>();
        Pattern p = Pattern.compile(regEx);
        Matcher m = p.matcher(ipString);
        while (m.find()) {
            String result = m.group();
            ips.add(result);
        }
        return ips;
    }
}
