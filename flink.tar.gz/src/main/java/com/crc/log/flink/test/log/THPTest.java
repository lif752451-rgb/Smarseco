package com.crc.log.flink.test.log;

import com.alibaba.fastjson.JSONObject;
import com.crc.log.flink.common.utils.JsonUtils;
import com.crc.log.flink.parse.ResolvQingtengTHPLog;
import org.apache.commons.lang3.StringUtils;

import java.util.concurrent.ConcurrentHashMap;

public class THPTest {
    public static void main(String[] args) {
        String msg = "{\"dev_ip\":\"10.200.7.30\",\"message\":\"<180>instruction_title=\\\"利用SQL Server存储过程执行系统命令\\\" instruction_description=\\\"利用进程启动日志，查询利用SQL Server进程执行系统命令的可疑行为\\\" instruction_tag=\\\"['Windows', '持久化', '服务器软件组件 (T1505)']\\\" from_unixtime(datatime)=\\\"2021-03-30 23:50:07\\\" agent_id=\\\"604895e785510c2e\\\" agent_ip=\\\"10.93.194.29\\\" host_name=\\\"WIN-ECI7UPV6T6A\\\" uname=\\\"SYSTEM\\\" ppname=\\\"sqlservr.exe\\\" pppath=\\\"C:\\\\Program Files\\\\Microsoft SQL Server\\\\MSSQL10_50.IPVA\\\\MSSQL\\\\Binn\\\\sqlservr.exe\\\" path=\\\"C:\\\\Windows\\\\system32\\\\cmd.exe\\\" pname=\\\"cmd.exe\\\" cmd=\\\"\\\"C:\\\\Windows\\\\system32\\\\cmd.exe\\\" /c  BCP \\\"SELECT 'Hrzd_00014'+b.SiteKey SiteId,b.HostName DeviceId,b.[ChannelId],b.ChannelStatus ChannelStatus,b.UpdateTime FROM (SELECT DISTINCT InProjectKey,OutProjectKey FROM [IPVA_S0400_B1].[dbo].[System_MappingTable] WHERE Type=103 AND OutProjectKey='Hrzd_00014') a INNER JOIN  [IPVA_S0400_B1].[dbo].[View_System_ChannelsStatus] b ON a.InProjectKey=b.SiteKey \\\" queryout \\\"D:\\\\IPVA\\\\Data_traffic\\\\ipva.Hrzd_00014.DeviceChannelStatus.20210330.20210330235007797.tmp\\\" -c -S\\\".\\\\IPVA\\\" -T -\\\" \\u0000\",\"type\":\"udp\",\"timestamp\":\"2021-03-31 07:09:10\"}";
        ConcurrentHashMap<String, Object> x = ResolvQingtengTHPLog.parse(msg);
        JsonUtils.printStr(x);
        String jsonStr = msg;
        JSONObject jobj = JsonUtils.parse(jsonStr);
        String devIp = JsonUtils.getStr(jobj, "dev_ip");
        if (!StringUtils.isNotBlank(devIp)) {
            devIp = JsonUtils.getStr(jobj, "host");
        }
        /*
          Syslog接收的，处理message字段
         */
        if ("udp".equalsIgnoreCase(JsonUtils.getStr(jobj, "type"))) {
            jsonStr = JsonUtils.getStr(jobj, "message");
        }
        if (StringUtils.isBlank(devIp)) {
            JSONObject json = JsonUtils.parse(jsonStr);
            devIp = JsonUtils.getStr(json, "dev_ip");
        }


        x = ResolvQingtengTHPLog.parse(jsonStr);
        JsonUtils.printStr(x);
    }
}
