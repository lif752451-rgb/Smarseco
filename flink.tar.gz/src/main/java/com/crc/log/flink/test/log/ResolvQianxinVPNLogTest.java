package com.crc.log.flink.test.log;

import com.crc.log.flink.common.utils.JsonUtils;
import com.crc.log.flink.config.AllConfig;
import com.crc.log.flink.es.DataProcessFuncation;

import java.util.concurrent.ConcurrentHashMap;

/**
 * @author jixiangqi
 * @date 2022/1/14
 */
public class ResolvQianxinVPNLogTest {

    public static void main(String[] args) {
        AllConfig config = new AllConfig();
        DataProcessFuncation.CONIFG = config;
        config.setMode("single");
        config.setParse("ResolvQianxinVPNLog");
        config.setIndex("sec_all");


        String str = "20220114 16:48:46 SecSSL |4|0x0100046e|User|Service|急诊|Fail|用户[急诊]未通过服务的授权, 服务[健宫医院堡垒机], IP:Port[192.168.13.119:T:443].";
        ConcurrentHashMap<String, Object> proc = DataProcessFuncation.parse(str,"index");
        JsonUtils.printStr(proc);

        str = "20220112 15:33:19 SecSSL |4|0x00060416|Management|Log & Monitor|admin|Success|管理员[admin][192.168.1.120][GE2], 修改日志服务器运行状态: [ssp]从[禁止 ]变成[允许 ] [成功 ].";
        proc = DataProcessFuncation.parse(str,"index");
        JsonUtils.printStr(proc);

        str = "20220112 15:27:28 SecSSL |4|0x0006040c|Management|Log & Monitor|admin|Success|管理员[admin][192.168.1.120][GE2], 添加日志过滤条件[sspfiter]. [成功 ]";
        proc = DataProcessFuncation.parse(str,"index");
        JsonUtils.printStr(proc);
    }

}
