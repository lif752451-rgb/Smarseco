package com.crc.log.flink.parse;

import com.alibaba.fastjson.JSONObject;
import com.crc.log.flink.common.constants.LevelConstants;
import com.crc.log.flink.common.constants.LogConstants;
import com.crc.log.flink.common.utils.DataUtils;
import com.crc.log.flink.common.utils.IPUtil;
import com.crc.log.flink.common.utils.JsonUtils;
import com.crc.log.flink.common.utils.MapUtils;
import org.apache.commons.lang3.StringUtils;

import java.util.HashMap;
import java.util.concurrent.ConcurrentHashMap;

@SuppressWarnings("unchecked")
public class ResolvAdLog {
    private static boolean parseGood = false;
    public static HashMap<String, String> EventIdMap = new HashMap<>();
    public static HashMap<String, String> KickEventIdMap = new HashMap<>();

    static {
        String ids1 = "4740 已锁定用户账户\n" +
                "4776 域控制器尝试验证帐户的凭据\n" +
                "4741 已创建计算机帐户\n" +
                "4742 计算机帐户已更改\n" +
                "4743 计算机帐户已删除\n" +
                "4732 已向启用了安全性的本地组中添加某个成员\n" +
                "4673 特权服务被召唤\n" +
                "4756 已将成员添加到启用安全性的通用组中\n" +
                "4674 尝试对特权对象执行操作\n" +
                "4728 已向启用了安全性的全局组中添加某个成员\n" +
                "4625 账户登录失败\n" +
                "4723 尝试更改帐户的密码\n" +
                "4724 试图重置账户密码\n" +
                "4725 已禁用用户账户\n" +
                "4726 已删除用户账户";
        String ids2 = "4799 已枚举启用安全性的本地组成员身份\n" +
                "4620 创建用户\n" +
                "1102 审核日志已清除\n" +
                "4624 已登录账户\n" +
                "5060 验证操作失败\n" +
                "4634 已注销账户\n" +
                "4688 已创建新进程\n" +
                "4648 尝试使用显式凭据登录\n" +
                "4672 为新登录分配了特殊权限\n" +
                "4735 已更改启用了安全性的本地组\n" +
                "4719 系统审核策略已更改\n" +
                "4702 计划任务已更新\n" +
                "4738 已更改用户账户\n" +
                "4954 Windows防火墙组策略设置已更改。已应用新设置\n" +
                "4798 枚举了用户的本地组成员身份\n" +
                "18456 尝试使用SQL身份验证登录失败\n" +
                "14530 DFS无法从Active Directory访问其私有数据\n" +
                "14554 DFS命名空间服务已成功初始化承载命名空间根目录的共享文件夹";
        for (String ids : DataUtils.getSplit(ids1, "\n")) {
            String[] idarr = DataUtils.getSplit(ids, " ");
            if (idarr.length == 2) {
                if (StringUtils.isNotBlank(idarr[0])) {
                    EventIdMap.put(idarr[0], idarr[1]);
                }
            }
        }
        for (String ids : ids2.split("\n")) {
            String[] idarr = DataUtils.getSplit(ids, " ");
                    //ids.split(" ");
            if (idarr.length == 2) {
                if (StringUtils.isNotBlank(idarr[0])) {
                    EventIdMap.put(idarr[0], idarr[1]);
                }
            }
        }
    }

    /**
     * Windows操作日志，标准化解析
     *
     * @param message
     * @return
     */
    public static ConcurrentHashMap<String, Object> parse(String message) {
        try {
            ConcurrentHashMap<String, Object> data = proc(message);
            if (DataUtils.isNotEmptyJson(data)) {
                return data;
            }
        } catch (Exception ignored) {

        }
        return null;
    }

    private static ConcurrentHashMap<String, Object> proc(String jsonStr) {
        ConcurrentHashMap<String, Object> rtnObjc = JsonUtils.createBaseMap(jsonStr);
        try {
            jsonStr = DataUtils.getSubString(jsonStr, DataUtils.getIndex(jsonStr, "{"));
            jsonStr = DataUtils.getSubString(jsonStr, 0, DataUtils.getLastIndex(jsonStr, "}") + 1);
            if (StringUtils.isNotBlank(jsonStr)) {
                JSONObject jObj = JsonUtils.parse(jsonStr);
                if (JsonUtils.isEmpty(jObj)) {
                    return rtnObjc;
                }

                parseGood = parseAdLogJson(rtnObjc, jObj);
                if (!parseGood)
                    return new ConcurrentHashMap<>();
                rtnObjc.put(LogConstants.LOG_LEVEL, LevelConstants.getLevel(MapUtils.getStr(rtnObjc,LogConstants.LOG_LEVEL)));
                if (StringUtils.isBlank(MapUtils.getStr(rtnObjc, LogConstants.SRC_IP))) {
                    rtnObjc.put(LogConstants.SRC_IP, "0.0.0.0");
                }
                if (StringUtils.isBlank(MapUtils.getStr(rtnObjc, LogConstants.DEST_IP))) {
                    rtnObjc.put(LogConstants.DEST_IP, "0.0.0.0");
                }
            }
            return rtnObjc;
        } catch (Exception e) {
            return rtnObjc;
        }
    }

    private static void getIpInfo(ConcurrentHashMap<String,Object> rtnObjc, String message) {
        int pos = DataUtils.getIndex(message, "源网络地址:");
        if (pos != -1) {
            try {
                String subStr = DataUtils.getSubString(message, pos, pos + 50);
                String[] split = DataUtils.getSplit(subStr, ":");
                if (split.length > 1) {
                    String[] split1 = DataUtils.getSplit(split[1], "\n");
                    if (split1.length > 0) {
                        String srcIp = split1[0].replace("\t", "");
                        MapUtils.setStr(rtnObjc, LogConstants.SRC_IP, srcIp);
                    }
                }

                        //DataUtils.getSplit(subStr ,":").length > 1 ? DataUtils.getSplit(subStr ,":")[1]
                        //subStr.split(":")[1].split("\n")[0].replace("\t", "");

            } catch (Exception ignored) {

            }
        }
        pos = DataUtils.getIndex(message, "源地址:");
                //message.indexOf("源地址:");
        if (pos != -1) {
            try {
                String subStr = DataUtils.getSubString(message, pos, pos + 50);
                String[] split = DataUtils.getSplit(subStr, ":");
                if (split.length > 1) {
                    String[] split1 = DataUtils.getSplit(split[1], "\n");
                    if (split1.length > 1) {
                        String srcIp =  split1[0].replace("\t", "");
                        MapUtils.setStr(rtnObjc, LogConstants.SRC_IP, srcIp);
                    }
                }
                //String srcIp = subStr.split(":")[1].split("\n")[0].replace("\t", "");
            } catch (Exception ignored) {

            }
        }
        pos = DataUtils.getIndex(message, "目标地址:");
                //message.indexOf("目标地址:");
        if (pos != -1) {
            try {
                String subStr = DataUtils.getSubString(message, pos, pos + 50);
                String[] split = DataUtils.getSplit(subStr, ":");
                if (split.length > 1) {
                    String[] split1 = DataUtils.getSplit(split[1], "\n");
                    if (split1.length > 1) {
                        String srcIp =  split1[0].replace("\t", "");
                        MapUtils.setStr(rtnObjc, LogConstants.DEST_IP, srcIp);
                    }
                }

            } catch (Exception ignored) {

            }
        }
        pos = DataUtils.getIndex(message, "源工作站:");
                //message.indexOf("源工作站:");
        if (pos != -1) {
            try {
                String subStr = DataUtils.getSubString(message, pos);
                String[] split = DataUtils.getSplit(subStr, ":");
                if (split.length > 1) {
                    String[] split1 = DataUtils.getSplit(split[1], "\n");
                    if (split1.length > 1) {
                        String srcIp =  split1[0].replace("\t", "");
                        MapUtils.setStr(rtnObjc, LogConstants.DEST_IP, srcIp);
                    }
                }
                /*String subStr = message.substring(pos);
                String srcIp = subStr.split(":")[1].split("\n")[0].replace("\t", "");
                JsonUtils.setStr(rtnObjc, "src_hostname", srcIp);*/
            } catch (Exception ignored) {
            }
        }
    }

    public static boolean parseAdLogJson(ConcurrentHashMap<String, Object> rtnObjc, JSONObject jObj) {
        if (JsonUtils.containsKey(jObj, "dev_ip")) {
            MapUtils.setStr(rtnObjc, LogConstants.LOG_DEV_IP, jObj, "dev_ip");
        }

        if (JsonUtils.containsKey(jObj, "message")) {
            MapUtils.setStr(rtnObjc, LogConstants.MSG_CONTENT, jObj, "message");
            String message = MapUtils.getStr(rtnObjc, LogConstants.MSG_CONTENT);
            getIpInfo(rtnObjc, message);
        }
        MapUtils.setJsonValue(rtnObjc, jObj, LogConstants.HOST_NAME, "agent.hostname");
        if (MapUtils.isBlank(rtnObjc, LogConstants.HOST_NAME))
            MapUtils.setJsonValue(rtnObjc, jObj, LogConstants.HOST_NAME, "host.hostname",
                    LogConstants.TARGET_DOMAIN_NAME, "host.name");
        //}
        if (jObj.containsKey("winlog")) {
            JSONObject winlogObj = jObj.getJSONObject("winlog");
            MapUtils.setJsonValue(rtnObjc, jObj, LogConstants.ACTION_RESULT, "winlog.keywords",
                    LogConstants.EVENT_ID, "winlog.event_id");
            if (winlogObj.containsKey("event_data")) {
                JSONObject eventObj = winlogObj.getJSONObject("event_data");
                MapUtils.setStr(rtnObjc, LogConstants.OP_NAME, eventObj, "TargetUserName");
                if (StringUtils.isBlank(MapUtils.getStr(rtnObjc,LogConstants.OP_NAME)) || "-".equalsIgnoreCase(MapUtils.getStr(rtnObjc,LogConstants.OP_NAME))) {
                    MapUtils.setStr(rtnObjc, LogConstants.OP_NAME, eventObj, "SubjectUserName");
                }
                if (MapUtils.isBlank(rtnObjc, LogConstants.HOST_NAME))
                    MapUtils.setStr(rtnObjc, LogConstants.HOST_NAME, eventObj, "SubjectDomainName");
                if (MapUtils.isBlank(rtnObjc, LogConstants.SRC_IP))
                    MapUtils.setStr(rtnObjc, LogConstants.SRC_IP, eventObj, "SubjectDomainName");
                if (MapUtils.isBlank(rtnObjc, LogConstants.DEST_IP))
                    MapUtils.setStr(rtnObjc, LogConstants.DEST_IP, eventObj, "SubjectDomainName");
            }
        }
        if (jObj.containsKey("event")) {
            JSONObject eventObj = jObj.getJSONObject("event");
            MapUtils.setLong(rtnObjc, LogConstants.EVENT_ID, eventObj, "code");
            MapUtils.setStr(rtnObjc, LogConstants.ACTION_TYPE, eventObj, "action");
            MapUtils.setStr(rtnObjc, LogConstants.LOG_NAME, eventObj, "action");
        }

        if (MapUtils.isBlank(rtnObjc, LogConstants.SRC_IP))
            MapUtils.setJsonValue(rtnObjc, jObj, LogConstants.SRC_IP, "source.ip", true);
        if (MapUtils.isBlank(rtnObjc, LogConstants.HOST_NAME))
            MapUtils.setJsonValue(rtnObjc, jObj, LogConstants.HOST_NAME, "source.domain");
        if (MapUtils.isBlank(rtnObjc, LogConstants.SRC_IP))
            MapUtils.setJsonValue(rtnObjc, jObj, LogConstants.LOG_DEV_IP, "fields.dev_ip");
        MapUtils.setStr(rtnObjc, LogConstants.LOG_LEVEL, LevelConstants.INFO);

        String devIp = MapUtils.getStr(rtnObjc, LogConstants.LOG_DEV_IP);
        if (!IPUtil.isIp(devIp)) {
            String srcIp = MapUtils.getStr(rtnObjc, LogConstants.SRC_IP);
            if (StringUtils.isNotBlank(srcIp)) {
                MapUtils.setStr(rtnObjc, LogConstants.LOG_DEV_IP, srcIp);
            } else
                MapUtils.setStr(rtnObjc, LogConstants.LOG_DEV_IP, "127.0.0.1");
        }

        String evnId = MapUtils.getStr(rtnObjc, LogConstants.EVENT_ID);
        if (EventIdMap.containsKey(evnId)) {
            rtnObjc.put(LogConstants.LOG_NAME, EventIdMap.get(evnId));
            if (StringUtils.isBlank(MapUtils.getStr(rtnObjc, LogConstants.SRC_IP))) {
                rtnObjc.put(LogConstants.SRC_IP, "0.0.0.0");
            }
            if (StringUtils.isBlank(MapUtils.getStr(rtnObjc, LogConstants.DEST_IP))) {
                rtnObjc.put(LogConstants.DEST_IP, "0.0.0.0");
            }
            rtnObjc.put(LogConstants.LOG_PRODUCT, "Windows服务器");
            setAlertName(rtnObjc);
        } else {
            return false;
        }
        return true;
    }

    public static void setAlertName(ConcurrentHashMap<String, Object> resultJson) {
        try {
            String messageFormat = "%s 发生 %s";
            String opName = MapUtils.getStr(resultJson, LogConstants.OP_NAME);
            String eventId = MapUtils.getStr(resultJson, LogConstants.LOG_DEV_IP);
            String logName = MapUtils.getStr(resultJson, LogConstants.LOG_NAME);
            //String log = JsonUtils.getStr(resultJson, LogConstants.LOG_ORI_MSG);
            if (StringUtils.isBlank(eventId)) {
                eventId = MapUtils.getStr(resultJson,LogConstants.HOST_NAME);
            }
            if (StringUtils.isNotBlank(opName)) {
                messageFormat = "%s[%s] 发生 %s";
                String alertName = String.format(messageFormat, eventId, opName, logName);
                resultJson.put(LogConstants.ALERT_NAME, alertName);
            } else {
                String alertName = String.format(messageFormat, eventId, logName);
                resultJson.put(LogConstants.ALERT_NAME, alertName);
            }
        } catch (Exception ignored) {

        }
    }

    public boolean parseGood() {
        return parseGood;
    }
}
