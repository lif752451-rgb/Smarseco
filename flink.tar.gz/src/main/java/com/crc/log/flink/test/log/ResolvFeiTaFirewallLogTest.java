package com.crc.log.flink.test.log;

import com.crc.log.flink.common.utils.JsonUtils;
import com.crc.log.flink.config.AllConfig;
import com.crc.log.flink.es.DataProcessFuncation;

import java.util.concurrent.ConcurrentHashMap;

public class ResolvFeiTaFirewallLogTest {

    public static void main(String[] args) {
        AllConfig config = new AllConfig();
        DataProcessFuncation.CONIFG = config;
        config.setMode("single");
        config.setParse("ResolvFeiTaFirewallLog");
        config.setIndex("sec_all");


        String str = "<169>date=2021-11-30 time=08:58:12 devname=\"SZWXTD-EMPLSFW02-FG300D\" devid=\"FGT3HD3917801721\" logid=\"0419016384\" type=\"utm\" subtype=\"ips\" eventtype=\"signature\" level=\"alert\" vd=\"root\" eventtime=1638233892 severity=\"medium\" srcip=10.76.133.66 srccountry=\"Reserved\" dstip=10.90.12.7 srcintf=\"port1\" srcintfrole=\"wan\" dstintf=\"port2\" dstintfrole=\"undefined\" sessionid=3583566449 action=\"dropped\" proto=6 service=\"HTTP\" policyid=9 attack=\"WebRTC.Local.IP.Addresses.Disclosure\" srcport=56214 dstport=58888 hostname=\"10.90.12.7:58888\" url=\"/js/util/util.js\" direction=\"incoming\" attackid=40038 profile=\"default\" ref=\"http://www.fortinet.com/ids/VID40038\" incidentserialno=557130622 msg=\"web_app3: WebRTC.Local.IP.Addresses.Disclosure,\" crscore=10 crlevel=\"medium\"";
        ConcurrentHashMap<String, Object> proc = DataProcessFuncation.parse(str,"index");
        JsonUtils.printStr(proc);
        str = "<169>date=2021-11-25 time=19:19:37 devname=\"SZWXTD-EMPLSFW02-FG300D\" devid=\"FGT3HD3917801721\" logid=\"0720018433\" type=\"utm\" subtype=\"anomaly\" eventtype=\"anomaly\" level=\"alert\" vd=\"root\" eventtime=1637839177 severity=\"critical\" srcip=10.72.49.180 srccountry=\"Reserved\" dstip=10.95.105.34 srcintf=\"port1\" srcintfrole=\"wan\" sessionid=0 action=\"clear_session\" proto=1 service=\"PING\" count=1169 attack=\"icmp_src_session\" icmpid=\"0x3ef4\" icmptype=\"0x08\" icmpcode=\"0x00\" attackid=16777321 policyid=1 policytype=\"DoS-policy\" ref=\"http://www.fortinet.com/ids/VID16777321\" msg=\"anomaly: icmp_src_session, 301 > threshold 300, repeats 1169 times\" crscore=50 crlevel=\"critical\"";
        proc = DataProcessFuncation.parse(str,"index");
        JsonUtils.printStr(proc);
        str = "<169>date=2021-11-25 time=12:46:01 devname=\"SZWXTD-EMPLSFW02-FG300D\" devid=\"FGT3HD3917801721\" logid=\"0720018433\" type=\"utm\" subtype=\"anomaly\" eventtype=\"anomaly\" level=\"alert\" vd=\"root\" eventtime=1637815561 severity=\"critical\" srcip=10.72.49.180 srccountry=\"Reserved\" dstip=10.216.16.79 srcintf=\"port1\" srcintfrole=\"wan\" sessionid=0 action=\"clear_session\" proto=1 service=\"PING\" count=428 attack=\"icmp_sweep\" icmpid=\"0x0260\" icmptype=\"0x08\" icmpcode=\"0x00\" attackid=16777320 policyid=1 policytype=\"DoS-policy\" ref=\"http://www.fortinet.com/ids/VID16777320\" msg=\"anomaly: icmp_sweep, 101 > threshold 100, repeats 428 times\" crscore=50 crlevel=\"critical\"";
        proc = DataProcessFuncation.parse(str,"index");
        JsonUtils.printStr(proc);
        str = "<169>date=2021-11-04 time=11:16:10 devname=\"SZWXTD-EMPLSFW02-FG300D\" devid=\"FGT3HD3917801721\" logid=\"0419016384\" type=\"utm\" subtype=\"ips\" eventtype=\"signature\" level=\"alert\" vd=\"root\" eventtime=1635995770 severity=\"high\" srcip=10.0.248.87 srccountry=\"Reserved\" dstip=10.90.10.229 srcintf=\"port1\" srcintfrole=\"wan\" dstintf=\"port2\" dstintfrole=\"undefined\" sessionid=3459963630 action=\"dropped\" proto=6 service=\"HTTP\" policyid=5 attack=\"Apache.Tomcat.Arbitrary.JSP.file.Upload\" srcport=49796 dstport=80 hostname=\"hncc.crland.com.cn\" url=\"/S72d0b2b8cd1cc9ef71f1706c82cb20d5.jsp/\" direction=\"outgoing\" attackid=44543 profile=\"default\" ref=\"http://www.fortinet.com/ids/VID44543\" incidentserialno=557130606 msg=\"apache: Apache.Tomcat.Arbitrary.JSP.file.Upload,\" forwardedfor=\"221.12.175.66\" crscore=30 crlevel=\"high\"";
        proc = DataProcessFuncation.parse(str,"index");
        JsonUtils.printStr(proc);
        str = "<169>date=2021-11-04 time=11:14:43 devname=\"SZWXTD-EMPLSFW02-FG300D\" devid=\"FGT3HD3917801721\" logid=\"0419016384\" type=\"utm\" subtype=\"ips\" eventtype=\"signature\" level=\"alert\" vd=\"root\" eventtime=1635995683 severity=\"high\" srcip=10.0.248.86 srccountry=\"Reserved\" dstip=10.90.10.229 srcintf=\"port1\" srcintfrole=\"wan\" dstintf=\"port2\" dstintfrole=\"undefined\" sessionid=3459956876 action=\"dropped\" proto=6 service=\"HTTP\" policyid=5 attack=\"Apache.Struts.2.REST.Plugin.XStream.Handler.Code.Execution\" srcport=38818 dstport=80 hostname=\"58.250.180.140\" url=\"/struts2-rest-showcase/orders/3\" direction=\"outgoing\" attackid=44501 profile=\"default\" ref=\"http://www.fortinet.com/ids/VID44501\" incidentserialno=254796851 msg=\"apache: Apache.Struts.2.REST.Plugin.XStream.Handler.Code.Execution,\" forwardedfor=\"45.32.117.105\" crscore=30 crlevel=\"high\"";
        proc = DataProcessFuncation.parse(str,"index");
        JsonUtils.printStr(proc);
    }
}
