package com.crc.log.flink.test.log;

import com.crc.log.flink.common.utils.JsonUtils;
import com.crc.log.flink.config.AllConfig;
import com.crc.log.flink.es.DataProcessFuncation;

import java.util.concurrent.ConcurrentHashMap;

public class WifiTest {
    public static void main(String[] args) {
        String msg = "<14>Oct 12 10:47:05 - NDAM: messageType:portalAuthLog;username:18940015994;userMac:76:70:C2:B7:65:89;terminalPlatform:Android Phone;ssid:edb79a69-170d-4d86-bc3a-292e2a04dd96;mobile:18940015994;accessPointMac:B4:5D:50:CA:28:66;IP:fe80::1cf3:5c91:fe24:762a;loginSuccess:true";
        //a1(msg);

        msg = "<140>Dec 8 22:09:07 2021 crland-ac-232 wms[4031]: <126005> <4031> <WARN> <crland-ac-232 192.168.20.2> |ids| Interfering AP: The system classified an access point (BSSID ac:83:f3:b0:40:61 and SSID on CHANNEL 11) as interfering. Additional Info: Detector-AP-Name:ap-22; Detector-AP-MAC:38:17:c3:b0:53:a0; Detector-AP-Radio:2." ;
        a1(msg);

        msg = "<143>2023-01-04 16:36:36,274 10.54.250.13 Insight logs to logserver 11789237 1 0 Auth.Username=shejiayun1,Auth.Host-MAC-Address=02300a265070,Auth.Protocol=RADIUS,Auth.NAS-IP-Address=10.54.250.5,CppmNode.CPPM-Node=10.54.250.12,Auth.Login-Status=0,Auth.Service=JT-CS-BuShi-CRC-service,Auth.Source=CRC-AD,Auth.Roles=[Guest]|[User Authenticated],Nad.Network-Device=10.54.250.5";
        a1(msg);

        msg = "<143>2023-01-04 12:26:23,558 10.54.250.13 Insight logs to logserver 11769355 1 0 Auth.Username=chenlei3,Auth.Host-MAC-Address=d2db245ec05d,Auth.Protocol=RADIUS,Auth.NAS-IP-Address=10.128.250.10,CppmNode.CPPM-Node=10.54.250.12,Auth.Login-Status=0,Auth.Service=BU-CS-CRC-service,Auth.Source=CRC-AD,Auth.Roles=Device-Mobile|[User Authenticated],Nad.Network-Device=10.128.250.10,Radius.Framed-IP-Address=fe80::f5ee:4ef:8722:a0a8\\n";
        a1(msg);
        msg = "<143>2023-01-04 13:32:30,232 10.54.250.13 Insight logs to logserver 11774546 1 0 Auth.Username=ZENGLINGQI3,Auth.Host-MAC-Address=928cc2f90d49,Auth.Protocol=RADIUS,Auth.NAS-IP-Address=10.128.250.11,CppmNode.CPPM-Node=10.54.250.12,Auth.Login-Status=0,Auth.Service=BU-CS-CRC-service,Auth.Source=CRC-AD,Auth.Roles=[Guest]|[User Authenticated],Nad.Network-Device=10.128.250.11,Radius.Framed-IP-Address=fe80::c6d:99e4:7526:a39a\\n";
        a1(msg);
    }

    public static void a1(String msg) {
        AllConfig config = new AllConfig();
        DataProcessFuncation.CONIFG = config;
        config.setMode("single");
        config.setParse("ResolvWifiAccessLog");
        config.setIndex("sec_all");


        ConcurrentHashMap<String, Object> json = DataProcessFuncation.parse(msg, "index");
        JsonUtils.printStr(json);
    }
}
