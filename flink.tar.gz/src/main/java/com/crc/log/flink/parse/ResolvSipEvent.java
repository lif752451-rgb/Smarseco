package com.crc.log.flink.parse;

import com.alibaba.fastjson.JSONObject;
import com.crc.log.flink.common.constants.ActionResultConstants;
import com.crc.log.flink.common.constants.LevelConstants;
import com.crc.log.flink.common.constants.LogConstants;
import com.crc.log.flink.common.utils.*;
import org.apache.commons.lang3.StringUtils;
import org.apache.commons.lang3.tuple.Pair;

import java.util.HashMap;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

/**
 * 深信服SIP-攻事件日志
 */
public class ResolvSipEvent {
    private static final Map<Integer, Pair<String, String>> levalMap = new HashMap<>();
    private static final Map<Integer, Pair<String, String>> priorityMap = new HashMap<>();
    private static final Map<Integer, Pair<String, String>> actionTypeMap = new HashMap<>();
    private static final Map<Integer, Pair<String, String>> stageMap = new HashMap<>();

    static {
        levalMap.put(1, Pair.of(LogConstants.LOG_LEVEL, LevelConstants.INFO));
        levalMap.put(2, Pair.of(LogConstants.LOG_LEVEL, LevelConstants.MEDIUM));
        levalMap.put(3, Pair.of(LogConstants.LOG_LEVEL, LevelConstants.HIGH));
        priorityMap.put(0, Pair.of(LogConstants.LOG_PRIORITY, "正常"));
        priorityMap.put(1, Pair.of(LogConstants.LOG_PRIORITY, "低可疑"));
        priorityMap.put(2, Pair.of(LogConstants.LOG_PRIORITY, "高可疑"));
        priorityMap.put(3, Pair.of(LogConstants.LOG_PRIORITY, "已失陷"));
        actionTypeMap.put(100, Pair.of(LogConstants.ACTION_TYPE, "干扰事件"));
        actionTypeMap.put(101, Pair.of(LogConstants.ACTION_TYPE, "漏洞攻击"));
        actionTypeMap.put(102, Pair.of(LogConstants.ACTION_TYPE, "拒绝服务攻击"));
        actionTypeMap.put(103, Pair.of(LogConstants.ACTION_TYPE, "信息泄露"));
        actionTypeMap.put(104, Pair.of(LogConstants.ACTION_TYPE, "后门攻击"));
        actionTypeMap.put(105, Pair.of(LogConstants.ACTION_TYPE, "网络扫描窃听"));
        actionTypeMap.put(106, Pair.of(LogConstants.ACTION_TYPE, "网络钓鱼"));
        actionTypeMap.put(107, Pair.of(LogConstants.ACTION_TYPE, "僵尸网络"));
        actionTypeMap.put(108, Pair.of(LogConstants.ACTION_TYPE, "信息篡改"));
        actionTypeMap.put(109, Pair.of(LogConstants.ACTION_TYPE, "信息窃取"));
        actionTypeMap.put(110, Pair.of(LogConstants.ACTION_TYPE, "信息假冒"));
        actionTypeMap.put(111, Pair.of(LogConstants.ACTION_TYPE, "特洛伊木马事件"));
        actionTypeMap.put(112, Pair.of(LogConstants.ACTION_TYPE, "蠕虫"));
        actionTypeMap.put(113, Pair.of(LogConstants.ACTION_TYPE, "计算机病毒"));
        actionTypeMap.put(114, Pair.of(LogConstants.ACTION_TYPE, "混合攻击程序"));
        actionTypeMap.put(115, Pair.of(LogConstants.ACTION_TYPE, "网页内嵌恶意代码"));
        actionTypeMap.put(116, Pair.of(LogConstants.ACTION_TYPE, "其他网络攻击"));
        actionTypeMap.put(117, Pair.of(LogConstants.ACTION_TYPE, "其他有害程序"));
        actionTypeMap.put(118, Pair.of(LogConstants.ACTION_TYPE, "信息丢失"));
        actionTypeMap.put(119, Pair.of(LogConstants.ACTION_TYPE, "其他信息破坏"));
        stageMap.put(-1, Pair.of(LogConstants.LOG_STAGE, "全部阶段"));
        stageMap.put(1, Pair.of(LogConstants.LOG_STAGE, "遭受攻击"));
        stageMap.put(2, Pair.of(LogConstants.LOG_STAGE, "C&C 通信"));
        stageMap.put(3, Pair.of(LogConstants.LOG_STAGE, "黑产牟利"));
        stageMap.put(4, Pair.of(LogConstants.LOG_STAGE, "内网探测"));
        stageMap.put(5, Pair.of(LogConstants.LOG_STAGE, "内网扩散攻击"));
        stageMap.put(6, Pair.of(LogConstants.LOG_STAGE, "盗取数据"));
    }


    public static ConcurrentHashMap<String, Object> parse(String message) {
        try {
            ConcurrentHashMap<String, Object> data = proc(message);
            if (DataUtils.isNotEmptyJson(data)) {
                return data;
            }
        } catch (Exception ignored) {

        }
        return null;
    }

    private static ConcurrentHashMap<String, Object> proc(String value) {
        ConcurrentHashMap<String, Object> data = JsonUtils.createBaseMap(value);
        JSONObject jsonObjx = JsonUtils.parse(value);
        if (DataUtils.isNotEmptyJson(jsonObjx)) {
            MapUtils.setStr(data, LogConstants.LOG_PRODUCT, "深信服SIP");
            if (!jsonObjx.isEmpty()) {
                parseSipEvent(data, jsonObjx);
                ScoreUtils.sipScore(data);
            }

        } else {
            if (value.contains("!secevent")) {
                JSONObject json = null;
                String msg = value;
                if (StringUtils.isNotBlank(msg) && msg.contains("{")) {
                    msg = DataUtils.getSubString(msg, DataUtils.getIndex(msg, "{"));
                            //msg.substring(msg.indexOf("{"));
                    String bakMsg = msg;
                    msg = DataUtils.getSubString(msg, DataUtils.getLastIndex(msg, "}")+1);
                            //msg.substring(0, msg.lastIndexOf("}") + 1);
                    json = JsonUtils.parse(msg);
                    MapUtils.setStr(data, LogConstants.LOG_PRODUCT, "深信服SIP");
                    if (!json.isEmpty()) {
                        parseSipEvent2(data, json);
                        ScoreUtils.sipScore(data);
                    } else {
                        bakMsg = DataUtils.getSubString(bakMsg, DataUtils.getIndex(bakMsg, "{"));
                                //bakMsg.substring(bakMsg.indexOf("{"));
                        String bakMsg2 = bakMsg;
                        if (bakMsg.endsWith("\"")) {
                            bakMsg += "}";
                        } else if (bakMsg.endsWith(":")) {
                            bakMsg += "\"\"}";
                        } else if (bakMsg.endsWith(",")) {
                            bakMsg += "\"aa\":\"\"}";
                        } else {
                            if (!bakMsg.endsWith("}")) {
                                bakMsg += "\"}";
                            }
                        }
                        json = JsonUtils.parse(bakMsg);
                        if (json.isEmpty()) {
                            for (String pair : DataUtils.getSplit(bakMsg2, ",")) {
                                if (pair.contains(":")) {
                                    int pos = pair.indexOf(":");
                                    String k = pair.substring(0, pos);
                                    String v = pair.substring(pos + 1);
                                    json.put(clean(k), clean(v));
                                }
                            }
                        }
                        parseSipEvent2(data, json);
                        ScoreUtils.sipScore(data);
                    }
                }
            } else if (value.contains("!alarm")) {
                String[] split = DataUtils.getSplit(value, "\\|");
                if (split.length == 4) {
                    data.put(LogConstants.SRC_IP, DataUtils.getSubString(split[2], 1));
                    String tempStr = DataUtils.getSubString(split[3], 1);
                    if (JSONObject.isValidObject(tempStr)) {
                        JSONObject jsonObj = JsonUtils.parse(tempStr);
                        MapUtils.setStr(data, LogConstants.LOG_PRODUCT, "深信服SIP");
                        if (!jsonObj.isEmpty()) {
                            parseSipEvent3(data, jsonObj);
                            ScoreUtils.sipScore(data);
                        }

                    }
                }
            }
        }
        data.put(LogConstants.LOG_LEVEL, LevelConstants.getLevel(MapUtils.getStr(data,LogConstants.LOG_LEVEL)));
        if (StringUtils.isBlank(MapUtils.getStr(data, LogConstants.SRC_IP))) {
            data.put(LogConstants.SRC_IP, "0.0.0.0");
        }
        if (StringUtils.isBlank(MapUtils.getStr(data, LogConstants.DEST_IP))) {
            data.put(LogConstants.DEST_IP, "0.0.0.0");
        }
        return data;
    }

    public static String clean(String str) {
        if (str == null) {
            return "";
        }
        return str.replace("\"", "").replace(" ", "");
    }


    public static void setJsonValueByPair(ConcurrentHashMap<String, Object> data, Map<Integer, Pair<String, String>> pairMap, Integer pairKey, Pair<String, String> defaultPair) {
        if (pairMap.get(pairKey) != null) {
            Pair<String, String> pair = pairMap.get(pairKey);
            MapUtils.setStr(data, pair.getLeft(), pair.getRight());
        } else if (null != defaultPair)
            MapUtils.setStr(data, defaultPair.getLeft(), defaultPair.getRight());
    }

    public static void parseSipEvent3(ConcurrentHashMap<String, Object> data, JSONObject jsonObj) {

        MapUtils.setStr(data, LogConstants.LOG_DESCRIPTION, jsonObj, "event_desc");
        MapUtils.setStr(data, LogConstants.DEVICE_ID, JsonUtils.getStr(jsonObj, "dev_id"));
        String result = JsonUtils.getStr(jsonObj, "attack_state");
        switch (result) {
            case "0":
                MapUtils.setStr(data, LogConstants.ACTION_RESULT, "待研判");
                break;
            case "1":
                MapUtils.setStr(data, LogConstants.ACTION_RESULT, "失败");
                break;
            case "2":
                MapUtils.setStr(data, LogConstants.ACTION_RESULT, "成功");
                break;
            case "3":
                MapUtils.setStr(data, LogConstants.ACTION_RESULT, "失陷");
                break;
        }

        MapUtils.setStr(data, LogConstants.DEVICE_NAME, JsonUtils.getStr(jsonObj, "dev_name"));
        MapUtils.setStr(data, LogConstants.LOG_NAME, JsonUtils.getStr(jsonObj, "brief"));
        Pair<String, String> defaultPair = Pair.of(LogConstants.LOG_LEVEL, "其它");
        Integer level = JsonUtils.getInt(jsonObj, "reliability");
        setJsonValueByPair(data, levalMap, level, defaultPair);
        MapUtils.setStr(data, LogConstants.DEST_IP, JsonUtils.getStr(jsonObj, "suffer_ip"));
        MapUtils.setStr(data, LogConstants.SRC_PORT, JsonUtils.getStr(jsonObj, "attack_port"));
        MapUtils.setStr(data, LogConstants.DEVICE_NAME, DateUtils.getISO8601Timestamp(DataUtils.toLong(JsonUtils.getStr(jsonObj, "first_time")) * 1000));
        MapUtils.setStr(data, LogConstants.SRC_IP, JsonUtils.getStr(jsonObj, "attack_ip"));
        MapUtils.setStr(data, LogConstants.DEST_PORT, JsonUtils.getStr(jsonObj, "suffer_port"));
        MapUtils.setStr(data, LogConstants.LOG_COUNT, JsonUtils.getStr(jsonObj, "count"));
        MapUtils.setStr(data, LogConstants.ATTACK_DIRECTION, JsonUtils.getStr(jsonObj, "attack_type_name"));

        MapUtils.setStr(data, LogConstants.LOG_DAMAGE, JsonUtils.getStr(jsonObj, "damage"));
        MapUtils.setStr(data, LogConstants.ACTION_TYPE, JsonUtils.getStr(jsonObj, "principle"));
        /*MapUtils.setStr(data, LogConstants.LOG_COUNT, MapUtils.getStr(jsonObj, "count"));
        MapUtils.setStr(data, LogConstants.ATTACK_DIRECTION, MapUtils.getStr(jsonObj, "attack_type_name"));*/
        if (StringUtils.isBlank(MapUtils.getStr(data, LogConstants.SRC_IP))) {
            data.put(LogConstants.SRC_IP, "0.0.0.0");
        }
        if (StringUtils.isBlank(MapUtils.getStr(data, LogConstants.DEST_IP))) {
            data.put(LogConstants.DEST_IP, "0.0.0.0");
        }
        setAlertName(data);
    }


    public static void parseSipEvent(ConcurrentHashMap<String, Object> data, JSONObject jsonObj) {

        MapUtils.setStr(data, LogConstants.LOG_DAMAGE, jsonObj, "damage");
        MapUtils.setStr(data, LogConstants.HOST_NAME, JsonUtils.getStr(jsonObj, "hostName"));
        MapUtils.setStr(data, LogConstants.LOG_PRINCIPLE, JsonUtils.getStr(jsonObj, "principle"));
        MapUtils.setStr(data, LogConstants.LOG_DESCRIPTION, JsonUtils.getStr(jsonObj, "eventDes"));
        MapUtils.setStr(data, LogConstants.LOG_NAME, MapUtils.getStr(data,LogConstants.LOG_DESCRIPTION));
        MapUtils.setStr(data, LogConstants.LOG_SOLUTION, JsonUtils.getStr(jsonObj, "solution"));
        MapUtils.setStr(data, LogConstants.SRC_IP, JsonUtils.getStr(jsonObj, "ip"));
        MapUtils.setStr(data, LogConstants.SRC_INSTANCE, JsonUtils.getStr(jsonObj, "branchName"));
        MapUtils.setStr(data, LogConstants.LOG_PROOF, JsonUtils.getStr(jsonObj, "proof"));
        MapUtils.setStr(data, LogConstants.DEVICE_NAME, JsonUtils.getStr(jsonObj, "dev_name"));
        JSONObject proof = JsonUtils.getJson(jsonObj, "proof");
        if (!proof.isEmpty()) {
            String ar = JsonUtils.getStr(proof, "success");
            String actionResult = "true".equalsIgnoreCase(ar) ? ActionResultConstants.ATTACK_SUCCUSS : ActionResultConstants.ATTACK_FAIL;
            MapUtils.setStr(data, LogConstants.ACTION_RESULT, actionResult);
            if (proof.containsKey("detail_list")) {
                String destIp = ((JSONObject) proof.getJSONArray("detail_list").get(0)).getString("ip");
                MapUtils.setStr(data, LogConstants.DEST_IP, destIp);
            }
        }
        Pair<String, String> defaultPair = Pair.of(LogConstants.LOG_LEVEL, "其它");
        Integer level = JsonUtils.getInt(jsonObj, "reliability");
        setJsonValueByPair(data, levalMap, level, defaultPair);
        Pair<String, String> defaultPair2 = Pair.of(LogConstants.LOG_PRIORITY, "其它");
        Integer priority = JsonUtils.getInt(jsonObj, "priority");
        setJsonValueByPair(data, priorityMap, priority, defaultPair2);
        Pair<String, String> defaultPair3 = Pair.of(LogConstants.ACTION_TYPE, "其它");
        Integer actionType = JsonUtils.getInt(jsonObj, "infosecuritysub");
        setJsonValueByPair(data, actionTypeMap, actionType, defaultPair3);
        Integer stage = JsonUtils.getInt(jsonObj, "stage");
        setJsonValueByPair(data, stageMap, stage, null);
        MapUtils.setStr(data, LogConstants.LOG_START_TIME, DateUtils.getISO8601Timestamp(JsonUtils.getLong(jsonObj, "firstTime") * 1000L));
        MapUtils.setStr(data, LogConstants.LOG_LEVEL, LevelConstants.getLevel(MapUtils.getStr(data,LogConstants.LOG_LEVEL)));
        MapUtils.setStr(data, LogConstants.LOG_TYPE, MapUtils.getStr(data,LogConstants.ACTION_TYPE));

        if (StringUtils.isBlank(MapUtils.getStr(data, LogConstants.SRC_IP))) {
            data.put(LogConstants.SRC_IP, "0.0.0.0");
        }
        if (StringUtils.isBlank(MapUtils.getStr(data, LogConstants.DEST_IP))) {
            data.put(LogConstants.DEST_IP, "0.0.0.0");
        }
        setAlertName(data);
    }

    public static void parseSipEvent2(ConcurrentHashMap<String, Object> data, JSONObject jsonObj) {
        //MapUtils.setStr(data, LogConstants.LOG_DAMAGE, jsonObj, "damage");
        //MapUtils.setStr(data, LogConstants.HOST_NAME, MapUtils.getStr(jsonObj, "hostName"));
        MapUtils.setStr(data, LogConstants.LOG_PRINCIPLE, JsonUtils.getStr(jsonObj, "principle"));
        MapUtils.setStr(data, LogConstants.LOG_DESCRIPTION, JsonUtils.getStr(jsonObj, "event_content"));
        MapUtils.setStr(data, LogConstants.LOG_NAME, JsonUtils.getStr(jsonObj, "msg_sub_type"));
        MapUtils.setStr(data, LogConstants.LOG_SOLUTION, JsonUtils.getStr(jsonObj, "solution"));
        MapUtils.setStr(data, LogConstants.SRC_IP, JsonUtils.getStr(jsonObj, "src_ip"));
        MapUtils.setStr(data, LogConstants.DEST_IP, JsonUtils.getStr(jsonObj, "dst_ip"));
        MapUtils.setStr(data, LogConstants.SRC_PORT, JsonUtils.getStr(jsonObj, "src_port"));
        MapUtils.setStr(data, LogConstants.DEST_PORT, JsonUtils.getStr(jsonObj, "dst_port"));
        MapUtils.setStr(data, LogConstants.ACTION_TYPE, JsonUtils.getStr(jsonObj, "msg_type"));
        MapUtils.setStr(data, LogConstants.SRC_INSTANCE, JsonUtils.getStr(jsonObj, "branchName"));
        MapUtils.setStr(data, "event_evidence", JsonUtils.getStr(jsonObj, "event_evidence"));
        if (StringUtils.isBlank(MapUtils.getStr(data, LogConstants.SRC_IP))) {
            MapUtils.setStr(data, LogConstants.SRC_IP, JsonUtils.getStr(jsonObj, "ip"));
        }
//        JSONObject proof = MapUtils.getJson(jsonObj, "proof");
        Pair<String, String> defaultPair = Pair.of(LogConstants.LOG_LEVEL, "其它");
        Integer level = JsonUtils.getInt(jsonObj, "threat_level");
        setJsonValueByPair(data, levalMap, level, defaultPair);
//        Pair<String, String> defaultPair2 = Pair.of(LogConstants.LOG_PRIORITY, "其它");
//        Integer priority = MapUtils.getInt(jsonObj, "priority");
//        setJsonValueByPair(data, priorityMap, priority, defaultPair2);
//        Pair<String, String> defaultPair3 = Pair.of(LogConstants.ACTION_TYPE, "其它");
//        Integer actionType = MapUtils.getInt(jsonObj, "infosecuritysub");
//        setJsonValueByPair(data, actionTypeMap, actionType, defaultPair3);
        Integer stage = JsonUtils.getInt(jsonObj, "stage");
        setJsonValueByPair(data, stageMap, stage, null);
        MapUtils.setStr(data, LogConstants.LOG_START_TIME, DateUtils.getISO8601Timestamp(JsonUtils.getLong(jsonObj, "firstTime") * 1000L));
        MapUtils.setStr(data, LogConstants.LOG_LEVEL, LevelConstants.getLevel(MapUtils.getStr(data,LogConstants.LOG_LEVEL)));
        MapUtils.setStr(data, LogConstants.LOG_TYPE, MapUtils.getStr(data,LogConstants.ACTION_TYPE));
        if (StringUtils.isBlank(MapUtils.getStr(data, LogConstants.SRC_IP))) {
            data.put(LogConstants.SRC_IP, "0.0.0.0");
        }
        if (StringUtils.isBlank(MapUtils.getStr(data, LogConstants.DEST_IP))) {
            data.put(LogConstants.DEST_IP, "0.0.0.0");
        }
        if (MapUtils.isBlank(data, "event_evidence"))
            setAlertName(data);
        else {
            data.put(LogConstants.ALERT_NAME, JsonUtils.getStr(jsonObj, "event_evidence"));
        }
    }

    public static void setAlertName(ConcurrentHashMap<String, Object> resultJson) {
        String srcIp = MapUtils.getStr(resultJson, LogConstants.SRC_IP);
        String destIp = MapUtils.getStr(resultJson, LogConstants.DEST_IP);
        String actionType = MapUtils.getStr(resultJson, LogConstants.ACTION_TYPE);
        String logName = MapUtils.getStr(resultJson, LogConstants.LOG_NAME);
        String log = MapUtils.getStr(resultJson, LogConstants.LOG_ORI_MSG);
        if (StringUtils.isBlank(destIp) || "null".equals(destIp) || "0.0.0.0".equals(destIp) || srcIp.equals(destIp)) {
            String messageFormat = "";
            String alertName = "";
            if (!resultJson.containsKey(LogConstants.SRC_INSTANCE)) {
                messageFormat = "%s 遭受了 %s-%s,日志详情为:%s";
                alertName = String.format(messageFormat, srcIp, actionType, logName, log);
            } else {
                messageFormat = "%s 遭受了 %s-%s,来源为:%s,日志详情为:%s";
                alertName = String.format(messageFormat, srcIp, actionType, logName, MapUtils.getStr(resultJson, LogConstants.SRC_INSTANCE), log);
            }
            resultJson.put(LogConstants.ALERT_NAME, alertName);
        } else {
            String messageFormat = "";
            String alertName = "";
            if (!resultJson.containsKey(LogConstants.SRC_INSTANCE)) {
                messageFormat = "%s 对 %s 进行 %s-%s,日志详情为:%s";
                alertName = String.format(messageFormat, srcIp, destIp, actionType, logName, log);
            } else {
                messageFormat = "%s 对 %s 进行 %s-%s,来源为:%s,日志详情为:%s";
                alertName = String.format(messageFormat, srcIp, destIp, actionType, logName,MapUtils.getStr(resultJson, LogConstants.SRC_INSTANCE), log);
            }
            resultJson.put(LogConstants.ALERT_NAME, alertName);
        }
    }

}

