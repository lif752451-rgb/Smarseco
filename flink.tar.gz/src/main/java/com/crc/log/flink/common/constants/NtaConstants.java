package com.crc.log.flink.common.constants;

public class NtaConstants {
    public static String security_event_typeA = "身份认证\tAuthentication\n" +
            "访问控制\tAccess\n" +
            "蜜罐攻击\tHoneypot\n" +
            "漏洞攻击\tExploit\n" +
            "拒绝服务攻击\tDenialOfService\n" +
            "恶意邮件\tMaliciousEmail\n" +
            "恶意代码\tMalware\n" +
            "可疑行为\tSuspiciousActivity\n" +
            "其他\tOthers\n" +
            "入侵攻击\tIntrusion\n" +
            "侦查\tReconnaissance";
    public static String security_event_severity = "一般\t1\n" +
            "较大\t2\n" +
            "重大\t3\n" +
            "特别重大\t4\n";

    public static String security_event_phase = "侦查跟踪\t1\n" +
            "武器构建\t2\n" +
            "载荷投递\t3\n" +
            "漏洞利用\t4\n" +
            "安装植入\t5\n" +
            "命令与控制\t6\n" +
            "目标达成\t7\n";

    public static String getEventType(String type) {
        for (String str : security_event_typeA.split("\n")) {
            String[] arr = str.split("\t");
            if (arr.length != 2)
                return "";
            if (type.equalsIgnoreCase(arr[1])) {
                return arr[0];
            }
        }
        return "";
    }

    public static String getEventSeverity(String type) {
        for (String str : security_event_severity.split("\n")) {
            String[] arr = str.split("\t");
            if (arr.length != 2)
                return "";
            if (type.equalsIgnoreCase(arr[1])) {
                return arr[0];
            }
        }
        return "";
    }

    public static String getEventPhase(String type) {
        for (String str : security_event_phase.split("\n")) {
            String[] arr = str.split("\t");
            if (arr.length != 2)
                return "";
            if (type.equalsIgnoreCase(arr[1])) {
                return arr[0];
            }
        }
        return "";
    }

    /*
    1：攻击尝试
2：攻击成功
3：失陷
     */
    public static String getEventResult(String event_result) {
        if ("1".equalsIgnoreCase(event_result))
            return "攻击尝试";
        else if ("2".equalsIgnoreCase(event_result)) {
            return "攻击成功";
        } else if ("3".equalsIgnoreCase(event_result)) {
            return "失陷";
        }
        return "";
    }
}
