package com.crc.log.flink.parse;

import com.crc.log.flink.common.constants.LevelConstants;
import com.crc.log.flink.common.constants.LogConstants;
import com.crc.log.flink.common.utils.DataUtils;
import com.crc.log.flink.common.utils.JsonUtils;
import com.crc.log.flink.common.utils.MapUtils;
import org.apache.commons.lang3.StringUtils;

import java.util.HashMap;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

/**
 * 亚信终端安全
 */
public class ResolvTerminalSafeLog {
    public static ConcurrentHashMap<String,Object> parse(String message) {
        try {
            ConcurrentHashMap<String,Object> data = proc(message);
            if (DataUtils.isNotEmptyJson(data)) {
                return data;
            }
        } catch (Exception ignored) {

        }
        return null;
    }

    private static ConcurrentHashMap<String,Object> proc(String jsonStr) {
        ConcurrentHashMap<String,Object> rtnObjc = JsonUtils.createBaseMap(jsonStr);
        if (jsonStr.contains("CEF")) {
             cefLogType(jsonStr, rtnObjc);
        }
        rtnObjc.put(LogConstants.LOG_LEVEL, LevelConstants.getLevel(MapUtils.getStr(rtnObjc,LogConstants.LOG_LEVEL)));
        rtnObjc.put(LogConstants.LOG_PRODUCT, "亚信终端安全");
        if (StringUtils.isBlank(MapUtils.getStr(rtnObjc, LogConstants.SRC_IP))) {
            rtnObjc.put(LogConstants.SRC_IP, "0.0.0.0");
        }
        if (StringUtils.isBlank(MapUtils.getStr(rtnObjc, LogConstants.DEST_IP))) {
            rtnObjc.put(LogConstants.DEST_IP, "0.0.0.0");
        }
        setAlertName(rtnObjc);
        return rtnObjc;
    }


    private static void cefLogType(String jsonStr, ConcurrentHashMap<String,Object> rtnObjc) {
        String[] array = DataUtils.getSplit(jsonStr, "\\|");
                //jsonStr.split("\\|");
        String product = array[2];
        String signId = array[4];
        String logType = signIdToLogType(signId);
        String name = array[5];
        String seriousLevel = array[6];
        rtnObjc.put(LogConstants.DEVICE_TYPE, product);
        rtnObjc.put(LogConstants.LOG_TYPE, logType);
        rtnObjc.put(LogConstants.LOG_DAMAGE, LevelType.getDescribeByIndex(DataUtils.toNum(seriousLevel)));
        rtnObjc.put(LogConstants.LOG_NAME, name);
        for (int i = 7; i < array.length; i++) {
            Map<String, String> stringMap = splitStr(array[i]);
            stringMap.forEach((key, value) -> {
                switch (key) {
                    case "src":
                        rtnObjc.put(LogConstants.SRC_IP, value);
                        break;
                    case "suser":
                        rtnObjc.put(LogConstants.USER_NAME, value);
                        break;
                    case "target":
                        rtnObjc.put(LogConstants.ACTION_OBJ, value);
                        break;
                    case "targetID":
                        rtnObjc.put(LogConstants.ACTION_OBJ_ID, value);
                        break;
                    case "targetType":
                        rtnObjc.put(LogConstants.ACTION_OBJ_TYPE, value);
                        break;
                    case "msg":
                        rtnObjc.put(LogConstants.LOG_CONTENT, value);
                        break;
                    case "shost":
                        rtnObjc.put(LogConstants.SRC_HOST, value);
                        break;
                    case "dvchost":
                        rtnObjc.put(LogConstants.DVC_HOST, value);
                        break;
                    case "cn1":
                        rtnObjc.put(LogConstants.SRC_IP, value);
                        break;
                    case "cn1Label":
                        rtnObjc.put(LogConstants.SRC_IP, value);
                        break;
                    case "cn2":
                        rtnObjc.put(LogConstants.FILE_SIZE, value);
                        break;
                    case "cn2Label":
                        rtnObjc.put(LogConstants.FILE_LABEL, value);
                        break;
                    case "filePath":
                        rtnObjc.put(LogConstants.FILE_PATH, value);
                        break;
                    case "act":
                        rtnObjc.put(LogConstants.ACTION_TYPE, value);
                        break;
                    case "dst":
                        rtnObjc.put(LogConstants.DEST_IP, value);
                        break;
                    case "dpt":
                        rtnObjc.put(LogConstants.DEST_PORT, value);
                        break;
                    case "spt":
                        rtnObjc.put(LogConstants.SRC_PORT, value);
                        break;
                    case "smac":
                        rtnObjc.put(LogConstants.SRC_MAC, value);
                        break;
                    case "dmac":
                        rtnObjc.put(LogConstants.DEST_MAC, value);
                        break;
                    case "proto":
                        rtnObjc.put(LogConstants.LOG_PROTOCAL, value);
                        break;
                    case "dvc":
                        rtnObjc.put(LogConstants.DEVICE_ADDRESS, value);
                        break;

                    case "clientIP":
                        rtnObjc.put(LogConstants.SRC_IP, value);
                        break;
                    case "server_ip":
                        rtnObjc.put(LogConstants.DEST_IP, value);
                        break;
                }
            });
        }
    }


    private static String signIdToLogType(String signId) {
        int sign = DataUtils.toNum(signId);
        String type = "";
        if (sign == 10) {
            type = "定制入侵防御 (IPS) 规则";
        } else if (sign == 20) {
            type = "仅记录防火墙规则";
        } else if (sign == 21) {
            type = "拒绝防火墙规则";
        } else if (sign == 30) {
            type = "定制完整性监控规则";
        }else if (sign == 40) {
            type = "定制日志审查规则";
        }else if (sign >= 100 && sign <= 199) {
            type = "策略防火墙规则和防火墙状态配置";
        }else if (sign >= 200 && sign <= 299) {
            type = "IPS 内部错误";
        }else if (sign >= 300 && sign <= 399) {
            type = "SSL/TLS 事件";
        }else if (sign >= 500 && sign <= 899) {
            type = "IPS 规范化";
        }else if (sign >= 1000000 && sign <= 1999999) {
            type = "亚信安全 IPS 规则";
        }else if (sign >= 2000000 && sign <= 2999999) {
            type = "完整性监控规则";
        }else if (sign >= 3000000 && sign <= 3999999) {
            type = "日志审查规则";
        }else if (sign >= 4000000 && sign <= 4999999) {
            type = "防恶意软件事件";
        } else if (sign >= 5000000 && sign <= 5999999) {
            type = "Web 信誉事件";
        } else if (sign >= 6000000 && sign <= 6999999) {
            type = "应用程序控制事件";
        } else if (sign >= 900 && sign <= 7499) {
            type = "系统事件";
        }
        return type;
    }

    public static Map<String, String> splitStr(String jsonStr) {
        Map<String, String> map = new HashMap<>();
        String index = "";
        String[] s = DataUtils.getSplit(jsonStr, " ");
                //jsonStr.split(" ");
        for (String item : s) {
            if (!item.contains("=")) {
                StringBuilder sb = new StringBuilder();
                if (map.size() != 0) {
                    sb = new StringBuilder(map.get(index));
                }
                sb.append(" ").append(item);
                map.put(index, sb.toString());
            } else {
                String[] split = DataUtils.getSplit(item, "=");
                //s[i].split("=");
                String key = split[0];
                String value = split.length > 1 ? split[1] : "";
                map.put(key, value);
                index = key;
            }
        }
        return map;
    }


    private static void setAlertName(ConcurrentHashMap<String,Object> rtnObjc) {
        String msgFormat = "IP地址为:%s产生了一个事件类型:%s的事件,具体内容为:%s,危害级别为:%s,日志详情为:%s";
        String level = MapUtils.getStr(rtnObjc, LogConstants.LOG_LEVEL);
        String srcIp = MapUtils.getStr(rtnObjc, LogConstants.SRC_IP);
        String event = MapUtils.getStr(rtnObjc, LogConstants.LOG_TYPE);
        String content = MapUtils.getStr(rtnObjc, LogConstants.LOG_CONTENT);
        String damage = MapUtils.getStr(rtnObjc, LogConstants.LOG_DAMAGE);
        String log = MapUtils.getStr(rtnObjc, LogConstants.LOG_ORI_MSG);
        String alertName = String.format(msgFormat, srcIp, event, content, damage, log);

        rtnObjc.put(LogConstants.ALERT_NAME, alertName);
    }

    enum LevelType {
        ZERO("忽略，不采取任何行动",0),FIRST("未预定义使用",1),SECOND("系统低优先级通知",2),
        THIRD("成功或授权的活动",3),FOUR("系统低优先级错误",4),FIVE("用户生成的错误",5),
        SIX("低相关性攻击",6),SEVEN("未预定义使用",7),EIGHT("未预定义使用",8),
        NINE("错误来自无效的来源",9),TEN("多用户生成的错误",10),ELEVEN("没有预定义的使用",11),
        TWELVE("高度重视的事件",12),THIRTEEN("非常见错误（高度重要）",13),FOURTEEN("高度重视安全事件",14),
        FIFTEEN("攻击成功",15);
        private String describe;
        private int index;

        LevelType(String describe, int index) {
            this.describe = describe;
            this.index = index;
        }

        //枚举方法
        public static String getDescribeByIndex(int index){
            for(LevelType c : LevelType.values()){
                if(c.getIndex() == index){
                    return c.getDescribe();
                }
            }
            return null;
        }

        public String getDescribe() {
            return describe;
        }

        public void setDescribe(String describe) {
            this.describe = describe;
        }

        public int getIndex() {
            return index;
        }

        public void setIndex(int index) {
            this.index = index;
        }
    }
}
