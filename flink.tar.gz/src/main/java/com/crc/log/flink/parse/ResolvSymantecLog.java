package com.crc.log.flink.parse;

import com.crc.log.flink.common.constants.LevelConstants;
import com.crc.log.flink.common.constants.LogConstants;
import com.crc.log.flink.common.utils.DataUtils;
import com.crc.log.flink.common.utils.DateUtils;
import com.crc.log.flink.common.utils.JsonUtils;
import com.crc.log.flink.common.utils.MapUtils;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;

import java.lang.reflect.Method;
import java.util.Date;
import java.util.concurrent.ConcurrentHashMap;

@Slf4j
public class ResolvSymantecLog {
    /**
     * Symantec 日志泛化
     */
    public static ConcurrentHashMap<String,Object> parse(String message) {
        try {
            ConcurrentHashMap<String,Object> data = proc(message);
            if (DataUtils.isNotEmptyJson(data)) {
                return data;
            }
        } catch (Exception ignored) {

        }
        return null;
    }

    private static ConcurrentHashMap<String,Object> proc(String jsonStr) {
        ConcurrentHashMap<String,Object> rtnObjc = JsonUtils.createBaseMap(jsonStr);
        if (DataUtils.getIndex(jsonStr, "SymantecServer") > 0) {
            parseSymantecLogJson(jsonStr, rtnObjc);
            if (isForbidenMsg(jsonStr)) {
                rtnObjc.put(LogConstants.LOG_LEVEL, LevelConstants.HIGH);
                rtnObjc.put(LogConstants.ACTION_RESULT, "拦截");
            } else {
                rtnObjc.put(LogConstants.LOG_LEVEL, LevelConstants.LOW);
                rtnObjc.put(LogConstants.ACTION_RESULT, "放行");
            }
            String actionResult = MapUtils.getStr(rtnObjc,LogConstants.ACTION_RESULT);
            if (StringUtils.isNotBlank(actionResult) && actionResult.equalsIgnoreCase("已禁止")) {
                rtnObjc.put(LogConstants.ACTION_RESULT, "拦截");
            }

            rtnObjc.put(LogConstants.MSG_CONTENT, jsonStr);
            setAlertName(rtnObjc);
        }
        rtnObjc.put(LogConstants.LOG_LEVEL, LevelConstants.getLevel(MapUtils.getStr(rtnObjc,LogConstants.LOG_LEVEL)));
        if (StringUtils.isBlank(MapUtils.getStr(rtnObjc, LogConstants.SRC_IP))) {
            rtnObjc.put(LogConstants.SRC_IP, "0.0.0.0");
        }
        if (StringUtils.isBlank(MapUtils.getStr(rtnObjc, LogConstants.DEST_IP))) {
            rtnObjc.put(LogConstants.DEST_IP, "0.0.0.0");
        }
        rtnObjc.put(LogConstants.LOG_PRODUCT, "赛门铁克");
        return rtnObjc;
    }

    public static void parseSymantecLogJson(String jsonStr, ConcurrentHashMap<String,Object> rtnObjc) {
        String[] Symantec_buff = DataUtils.getSplit(jsonStr, ",");
                //jsonStr.split(",");
        for (String s : Symantec_buff) {
            String[] len_buff = null;
            if (isMatchFile(s)) {
                int pos = DataUtils.getIndex(s, ":");
                //Symantec_buff[i].indexOf(":");
                len_buff = new String[2];
                len_buff[0] = DataUtils.getSubString(s, pos);
                //Symantec_buff[i].substring(0, pos);
                len_buff[1] = DataUtils.getSubString(s, pos + 1, s.length());
                //Symantec_buff[i].substring(pos + 1, Symantec_buff[i].length());
            } else {
                len_buff = DataUtils.getSplit(s, ":");
                //Symantec_buff[i].split(":");
            }
            if (len_buff.length == 2) {
                setJsonByField(len_buff[0], rtnObjc, len_buff);
            } else if (len_buff.length == 1) {
                String temp = len_buff[0];
                if (temp.contains("本地端口")) {
                    int index = DataUtils.getIndex(temp, " ");
                    //temp.indexOf(" ");
                    String substring = DataUtils.getSubString(temp, index + 1);
                    //temp.substring(index + 1);
                    rtnObjc.put(LogConstants.SRC_PORT, substring);
                } else if (temp.contains("远程端口")) {
                    int index = DataUtils.getIndex(temp, " ");
                    //temp.indexOf(" ");
                    String substring = DataUtils.getSubString(temp, index + 1);
                    //temp.substring(index + 1);
                    rtnObjc.put(LogConstants.DEST_PORT, substring);
                }
            }
            if (s.contains("SID")) {
                int index = DataUtils.getIndex(s, "]");
                //Symantec_buff[i].indexOf("]");
                int index1 = DataUtils.getIndex(s, "。");
                //Symantec_buff[i].indexOf("。");
                String tempStr = DataUtils.getSubString(s, index + 1, index1);
                //Symantec_buff[i].substring(index+1, index1);
                index = DataUtils.getLastIndex(tempStr, " ");
                //tempStr.lastIndexOf(" ");
                tempStr = DataUtils.getSubString(tempStr, 0, index).trim();
                //tempStr.substring(0, index).trim();
                String[] split = DataUtils.getSplit(tempStr, ":");
                //tempStr.split(":");
                if (split.length == 2) {
                    rtnObjc.put(LogConstants.LOG_TYPE, split[0].trim());
                    rtnObjc.put(LogConstants.LOG_NAME, split[1].trim());
                }
            }
        }

        boolean f = false;
        if (jsonStr.contains("事件时间:")) {
            try {
                int pos = DataUtils.getIndex(jsonStr, "事件时间") + "事件时间:".length();
                        //jsonStr.indexOf("事件时间:") + "事件时间:".length();
                String newJsonStr = DataUtils.getSubString(jsonStr, pos);
                        //jsonStr.substring(pos);
                int pos2 = DataUtils.getIndex(newJsonStr, ",");
                        //newJsonStr.indexOf(",");
                String time = DataUtils.getSubString(newJsonStr, 0, pos2);
                        //newJsonStr.substring(0, pos2);
                rtnObjc.put(LogConstants.LOG_START_TIME, DateUtils.getISO8601Timestamp(time.trim()));
                f = true;
            } catch (Exception e) {
                log.error(e.getMessage(),e);
            }
        }
        if (!f) {
            rtnObjc.put(LogConstants.LOG_START_TIME, DateUtils.getISO8601Timestamp(new Date()));
        }

        String content = MapUtils.getStr(rtnObjc,LogConstants.MSG_CONTENT);
        if (StringUtils.isNotBlank(content)) {
            if (content.contains("Web Attack")) {
                rtnObjc.put(LogConstants.LOG_TYPE, "其他网络攻击");
            }
        }
    }


    public static void setAlertName(ConcurrentHashMap<String,Object> resultJson) {

        String srcIp = MapUtils.getStr(resultJson, LogConstants.SRC_IP);
        String destIp = MapUtils.getStr(resultJson, LogConstants.DEST_IP);
        String logName = MapUtils.getStr(resultJson, LogConstants.LOG_NAME);
        String actionResult = MapUtils.getStr(resultJson, LogConstants.ACTION_RESULT);
        String log = MapUtils.getStr(resultJson, LogConstants.LOG_ORI_MSG);
        if (StringUtils.isBlank(destIp) || "null".equals(destIp) || "0.0.0.0".equals(destIp) || srcIp.equals(destIp)) {
            String messageFormat = "%s 发起 %s-%s,日志详情为:%s";
            String alertName = String.format(messageFormat, srcIp, logName, actionResult, log);
            resultJson.put(LogConstants.ALERT_NAME, alertName);
        } else {
            String messageFormat = "%s 对 %s 进行 %s-%s,日志详情为:%s";
            String alertName = String.format(messageFormat, srcIp, destIp, logName, actionResult, log);
            resultJson.put(LogConstants.ALERT_NAME, alertName);
        }
    }
    public static void setJsonByField(String field, ConcurrentHashMap<String,Object> targetJson, String[] buffer) {
        String[] fields = DataUtils.getSplit(field, "\\|");
                //field.split("\\|");
        LogTypeMapping logTypeMapping = null;
        for (String f : fields) {
            logTypeMapping = LogTypeMapping.resolveByField(f);
            if (null != logTypeMapping) {
                break;
            }
        }
        if (null != logTypeMapping) {
            if (!StringUtils.isEmpty(logTypeMapping.getInvokeMethod())) {
                String clazzName = logTypeMapping.getInvokeMethod().substring(0, logTypeMapping.getInvokeMethod().lastIndexOf("."));
                String methodName = logTypeMapping.getInvokeMethod().substring(logTypeMapping.getInvokeMethod().lastIndexOf(".") + 1
                );
                try {
                    Class<?> invokeClazz = Class.forName(clazzName);
                    Method method = invokeClazz.getMethod(methodName, String.class);
                    Boolean isValid = (Boolean) method.invoke(null, buffer[1].trim());
                    if (isValid) {
                        MapUtils.setStr(targetJson, logTypeMapping.getProperty(), buffer[1].trim());
                    }
                } catch (Exception e) {
                    log.error(e.getMessage(),e);
                }
            } else {
                MapUtils.setStr(targetJson, logTypeMapping.getProperty(), buffer[1].trim());
            }
        }
    }

    enum LogTypeMapping {
        //域名:SymantecServer
        //源IP:本地
        //目标IP:远程
        //event_descrtpition:应用程序
        //log_name: 规则
        //op_name:用户名
        //action_result: 操作
        SymantecServer("SymantecServer", LogConstants.HOST_NAME, ""),
        LOCAL("本地", LogConstants.SRC_IP, "com.crc.log.flink.common.utils.IPUtil.isIp"),
        ReMOTE("远程", LogConstants.DEST_IP, "com.crc.log.flink.common.utils.IPUtil.isIp"),
        LOGURL("入侵 URL", LogConstants.LOG_URL, ""),
        USER("用户|用户名", LogConstants.OP_NAME, ""),
        TIMES("出现次数", LogConstants.LOG_COUNT, ""),
        APPNAME("应用程序|应用程序名", LogConstants.LOG_DESCRIPTION, ""),
        // HOSTNAME("计算机名", LogConstants.HOST_NAME, ""),
        DEFENDLEVEl("强防护等级", LogConstants.LOG_LEVEL, ""),
        SRC_IP("IP 地址", LogConstants.SRC_IP, ""),
        NET_OFFICE("组", LogConstants.NET_OFFICE, ""),
        LOG_NAME("风险名称|规则", LogConstants.LOG_NAME, ""),
        SERVER("服务器", LogConstants.LOG_SERVER, ""),
        ACTION_TYPE("类别", LogConstants.ACTION_TYPE, ""),
        ACTION_RESULT("操作", LogConstants.ACTION_RESULT, "");

        private final String field;
        private final String property;
        private final String invokeMethod;

        LogTypeMapping(String field, String property, String invokeMethod) {
            this.field = field;
            this.property = property;
            this.invokeMethod = invokeMethod;
        }

        public String getField() {
            return field;
        }

        public String getProperty() {
            return property;
        }

        public String getInvokeMethod() {
            return invokeMethod;
        }

        public static LogTypeMapping resolveByField(String field) {
            for (LogTypeMapping mapping : LogTypeMapping.values()) {
                String[] fields = DataUtils.getSplit(mapping.getField(), "\\|");
                        //mapping.getField().split("\\|");
                for (String f : fields) {
                    if (field.equals(f)) {
                        return mapping;
                    }
                }

            }
            return null;
        }
    }

    public static boolean isMatchFile(String field) {
        return field.indexOf(":") > 0 && field.indexOf("/") > 0;
    }

    public static boolean isForbidenMsg(String msg) {
        return msg.contains("已禁止");
    }
}
