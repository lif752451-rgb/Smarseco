package com.crc.log.flink.parse;

import com.crc.log.flink.common.constants.LevelConstants;
import com.crc.log.flink.common.constants.LogConstants;
import com.crc.log.flink.common.utils.DataUtils;
import com.crc.log.flink.common.utils.DateUtils;
import com.crc.log.flink.common.utils.JsonUtils;
import com.crc.log.flink.common.utils.MapUtils;
import org.apache.commons.lang3.StringUtils;

import java.util.HashMap;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

/**
 * @author jixiangqi
 * @date 2022/4/29
 * 绿盟ADS
 */
public class ResolvLvMengADSLog {
    public static ConcurrentHashMap<String, Object> parse(String message) {
        try {
            ConcurrentHashMap<String, Object> data = proc(message);
            if (DataUtils.isNotEmptyJson(data)) {
                return data;
            }
        } catch (Exception ignored) {

        }
        return null;
    }

    private static ConcurrentHashMap<String, Object> proc(String jsonStr) {
        ConcurrentHashMap<String, Object> rtnObjc = JsonUtils.createBaseMap(jsonStr);
        if (jsonStr.startsWith("Collapsar load")) {
            jsonStr = jsonStr.replaceAll(": ", ":");
            Map<String, String> keyValue = getKeyValueBySpace(jsonStr);
            keyValue.forEach((k, v) -> {
                switch (k) {
                    case "Collapsar load":
                        rtnObjc.put(LogConstants.CPU, v);
                        break;
                    case "Mem":
                        rtnObjc.put(LogConstants.MEMORY, v);
                        break;
                    case "SN":
                        rtnObjc.put(LogConstants.SN, v);
                        break;
                    case "Macid":
                        rtnObjc.put(LogConstants.DEVICE_ID, v);
                        break;
                    case "Version":
                        rtnObjc.put(LogConstants.LOG_VERSION, v);
                        break;
                }
            });
            rtnObjc.put(LogConstants.LOG_TYPE, "设备日志");
        } else if (jsonStr.startsWith("Action")){
            int index = DataUtils.getIndex(jsonStr, ":");
            jsonStr = DataUtils.getSubString(jsonStr, index+1);
            String[] split = DataUtils.getSplit(jsonStr, "\\|");
            rtnObjc.put(LogConstants.LOG_TYPE, "操作日志");
            rtnObjc.put(LogConstants.USER_NAME, split[4]);
            rtnObjc.put(LogConstants.LOG_CONTENT, split[2]);
            rtnObjc.put(LogConstants.LOG_DEV_IP, split[3]);
            rtnObjc.put(LogConstants.ACTION_TYPE, split[1]);
            rtnObjc.put(LogConstants.LOG_START_TIME, DateUtils.getISO8601Timestamp(split[0], "yyyy-MM-dd HH:mm:ss"));
        } else if (jsonStr.startsWith("Login")){
            int index = DataUtils.getIndex(jsonStr, ":");
            jsonStr = DataUtils.getSubString(jsonStr, index+1);
            String[] split = DataUtils.getSplit(jsonStr, "\\|");
            rtnObjc.put(LogConstants.LOG_TYPE, "登陆日志");
            rtnObjc.put(LogConstants.USER_NAME, split[0]);
            rtnObjc.put(LogConstants.ACTION_RESULT, split[2]);
            rtnObjc.put(LogConstants.LOG_DEV_IP, split[3]);
            rtnObjc.put(LogConstants.LOG_START_TIME, DateUtils.getISO8601Timestamp(split[4], "yyyy-MM-dd HH:mm:ss"));
        } else if (jsonStr.startsWith("Attack")){
            rtnObjc.put(LogConstants.LOG_TYPE, "攻击日志");
            int index = DataUtils.getIndex(jsonStr, ":");
            jsonStr = DataUtils.getSubString(jsonStr, index+1);
            String[] s = DataUtils.getSplit(jsonStr, " ");
            for (String tempStr : s) {
                if (tempStr.contains("=")) {
                    int index1 = DataUtils.getIndex(tempStr, "=");
                    String key = DataUtils.getSubString(tempStr, 0, index1).trim();
                    String value = DataUtils.getSubString(tempStr, index1 + 1).trim();
                    switch (key) {
                        case "src":
                            rtnObjc.put(LogConstants.SRC_IP, value);
                            break;
                        case "dst":
                            rtnObjc.put(LogConstants.DEST_IP, value);
                            break;
                        case "sport":
                            rtnObjc.put(LogConstants.SRC_PORT, value);
                            break;
                        case "dport":
                            rtnObjc.put(LogConstants.DEST_PORT, value);
                            break;
                        case "flag":
                            rtnObjc.put(LogConstants.LOG_CONTENT, value);
                            break;
                    }
                } else {
                    rtnObjc.put(LogConstants.ACTION_TYPE, s[0]);
                }
            }
        } else if (jsonStr.contains("trafficalert")) {
            int index = com.crc.log.flink.common.utils.StringUtils.stringSubIndexTwo(jsonStr, '>', 1);
            jsonStr = DataUtils.getSubString(jsonStr, index+1);
            String[] split = DataUtils.getSplit(jsonStr, ";");
            for (String tempStr : split) {
                int index1 = DataUtils.getIndex(tempStr, "=");
                String key = DataUtils.getSubString(tempStr, 0, index1).trim();
                String value = DataUtils.getSubString(tempStr, index1 + 1).trim();
                switch (key) {
                    case "logtype":
                        rtnObjc.put(LogConstants.LOG_TYPE, value);
                        break;
                    case "event_type":
                        rtnObjc.put(LogConstants.LOG_PROTOCAL, value);
                        break;
                    case "level":
                        rtnObjc.put(LogConstants.LOG_LEVEL, LevelConstants.getLevel(value));
                        break;
                    case "dstip":
                        rtnObjc.put(LogConstants.DEST_IP, value);
                        break;
                    /*case "status":
                        rtnObjc.put(LogConstants.LOG_TYPE, value);
                        break;*/
                }
            }
        }
        rtnObjc.put(LogConstants.LOG_PRODUCT, "绿盟ADS");
        rtnObjc.put(LogConstants.LOG_LEVEL, LevelConstants.getLevel(MapUtils.getStr(rtnObjc,LogConstants.LOG_LEVEL)));
        if (StringUtils.isBlank(MapUtils.getStr(rtnObjc, LogConstants.SRC_IP))) {
            rtnObjc.put(LogConstants.SRC_IP, "0.0.0.0");
        }
        if (StringUtils.isBlank(MapUtils.getStr(rtnObjc, LogConstants.DEST_IP))) {
            rtnObjc.put(LogConstants.DEST_IP, "0.0.0.0");
        }
        setAlertName(rtnObjc);
        return rtnObjc;
    }

    private static void setAlertName(ConcurrentHashMap<String, Object> rtnObjc) {
        String logType = MapUtils.getStr(rtnObjc, LogConstants.LOG_TYPE);
        String message = "";
        String alertName = "";
        String devIp = MapUtils.getStr(rtnObjc, LogConstants.LOG_DEV_IP);
        String userName = MapUtils.getStr(rtnObjc, LogConstants.USER_NAME);
        String log = MapUtils.getStr(rtnObjc, LogConstants.LOG_ORI_MSG);
        switch (logType) {
            case "登陆日志":
                String actionResult = MapUtils.getStr(rtnObjc, LogConstants.ACTION_RESULT);
                message = "用户为:%s在IP为:%s的设备上执行了%s操作,操作结果为:%s,日志详情为:%s";
                alertName = String.format(message, userName, devIp, logType, actionResult, log);
                break;
            case "操作日志":
                String content = MapUtils.getStr(rtnObjc, LogConstants.LOG_CONTENT);
                String actionType = MapUtils.getStr(rtnObjc, LogConstants.ACTION_TYPE);
                message = "用户为:%s在IP为:%s的设备上执行了%s操作,操作类型为:%s,日志内容为:%s,日志详情为:%s";
                alertName = String.format(message, userName, devIp, logType, actionType, content, log);
                break;
            case "攻击日志":
                String destIp = MapUtils.getStr(rtnObjc, LogConstants.DEST_IP);
                String srcIp = MapUtils.getStr(rtnObjc, LogConstants.SRC_IP);
                content = MapUtils.getStr(rtnObjc, LogConstants.LOG_CONTENT);
                message = "IP为:%s对IP为:%s进行了攻击,攻击内容为:%s,,日志详情为:%s";
                alertName = String.format(message, srcIp, destIp, content, log);
                break;
            case "设备日志":
                String cpu = MapUtils.getStr(rtnObjc, LogConstants.CPU);
                String memory = MapUtils.getStr(rtnObjc, LogConstants.MEMORY);
                String sn = MapUtils.getStr(rtnObjc, LogConstants.SN);
                String id = MapUtils.getStr(rtnObjc, LogConstants.DEVICE_ID);
                String version = MapUtils.getStr(rtnObjc, LogConstants.LOG_VERSION);
                message = "当前设备的CPU使用率:%s,内存使用率为:%s,序列号为:%s,硬件编号为:%s,版本为:%s";
                alertName = String.format(message, cpu, memory, sn, id, version);
            case "trafficalert":
                String level = MapUtils.getStr(rtnObjc, LogConstants.LOG_LEVEL);
                destIp = MapUtils.getStr(rtnObjc, LogConstants.DEST_IP);
                message = "在IP地址为:%s的设备上出现了流量日志,日志级别为:%s,日志详情为:%s";
                alertName = String.format(message, destIp, level, log);
        }
        rtnObjc.put(LogConstants.ALERT_NAME, alertName);
    }

    private static Map<String, String> getKeyValueBySpace(String jsonStr) {
        Map<String, String> resultMap = new HashMap<>();
        String[] s = DataUtils.getSplit(jsonStr, " ");
        StringBuilder keySb = new StringBuilder();
        for (String tempStr : s) {
            if (tempStr.contains(":")) {
                if (keySb.length() > 0) {
                    int index = DataUtils.getIndex(tempStr, ":");
                    String keyTemp = DataUtils.getSubString(tempStr, 0, index).trim();
                    String value = DataUtils.getSubString(tempStr, index + 1).trim();
                    String key = keySb.append(" ").append(keyTemp).toString();
                    resultMap.put(key, value);
                    keySb = new StringBuilder();
                } else {
                    int index = DataUtils.getIndex(tempStr, ":");
                    String key = DataUtils.getSubString(tempStr, 0, index).trim();
                    String value = DataUtils.getSubString(tempStr, index + 1).trim();
                    resultMap.put(key, value);
                }
            } else {
                keySb.append(tempStr);
            }
        }
        return  resultMap;
    }
}
