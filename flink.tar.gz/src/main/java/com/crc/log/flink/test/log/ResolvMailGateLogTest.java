package com.crc.log.flink.test.log;

import com.crc.log.flink.common.utils.JsonUtils;
import com.crc.log.flink.config.AllConfig;
import com.crc.log.flink.es.DataProcessFuncation;

import java.util.concurrent.ConcurrentHashMap;

public class ResolvMailGateLogTest {


    public static void main(String[] args) {
        AllConfig config = new AllConfig();
        DataProcessFuncation.CONIFG = config;
        config.setMode("single");
        config.setParse("ResolvMailGateLog");
        config.setIndex("sec_all");

        String str = "<23> inbound/pass1: 45-227-82-217.fibranetjf.com.br[45.227.82.217] 1650540120-09e56229920c9a0001-fbTjmn 1650540120 1650540124 SCAN - richard@halltv.com leiguangyong@crb.cn - 2 37 &#27604;&#29305;&#24065; SZ:17634 SUBJ:=?UTF-8?B?562J5b6F5LuY5qy+44CC6K+35rOo5oSPIQ==?=";
        ConcurrentHashMap<String, Object> proc = DataProcessFuncation.parse(str, "index");
        JsonUtils.printStr(proc);

        str = "<23> inbound/pass1: host-176-221-123-46.dynamic.mm.pl[176.221.123.46] 1650540128-09e56229950c9c0001-pejTAd 1650540128 1650540129 RECV jianxiangjin@calendar.nagase.cn changkf@crc.com.hk 2 62 176.221.123.46";
        proc = DataProcessFuncation.parse(str, "index");
        JsonUtils.printStr(proc);

        str = "<23> inbound/pass1: 45-227-82-217.fibranetjf.com.br[45.227.82.217] 1650540120-09e56229920c9a0001-fbTjmn 1650540120 1650540124 SCAN - richard@halltv.com leiguangyong@crb.cn - 2 37 &#27604;&#29305;&#24065; SZ:17634 SUBJ:=?UTF-8?B?562J5b6F5LuY5qy+44CC6K+35rOo5oSPIQ==?=";
        proc = DataProcessFuncation.parse(str, "index");
        JsonUtils.printStr(proc);

        str = "<23> scan: rrmtabm01.ms.com[205.228.15.61] 1650540107-09e56229920c980001-8c0n3g 1650540108 1650540120 SCAN ENC bmbounce+jymbc16afpiz74@ms.com xiongzhe5@crcapital.com.hk - 7 88 corporate SZ:211642 SUBJ:=?UTF-8?B?R2xvYmFsIE1hY3JvIERhdGE6IFVTIExpcXVpZCBSYXRlcyBUcmFja2VyIChF?==?UTF-8?B?eGNlbCBWZXJzaW9uKQ==?=\n";
        proc = DataProcessFuncation.parse(str, "index");
        JsonUtils.printStr(proc);
    }

}
