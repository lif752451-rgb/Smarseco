package com.crc.log.flink.load;

import com.alibaba.fastjson.JSONObject;
import com.crc.log.flink.common.entity.SbrProdType;
import com.crc.log.flink.common.utils.JsonUtils;
import com.crc.log.flink.db.ConfBuzziMySql;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;

import java.util.List;
import java.util.concurrent.ConcurrentHashMap;
@Slf4j
public class SbrProdTypeLoad {
    public static ConcurrentHashMap<String, SbrProdType> sbrMap = new ConcurrentHashMap<>();

    /**
     * 同步解析规则
     */
    public static void sync() {
        String sql = "SELECT * FROM sys_dict_data WHERE dict_type = 'sbr_prod_type' AND STATUS = '0'";
        try {
            // 获取返回结果
            List<JSONObject> list = ConfBuzziMySql.query(sql);
            for (JSONObject rs : list) {
                try {
                    SbrProdType sbr = new SbrProdType();
                    String id = JsonUtils.getStr(rs, "dict_code");
                    String product = JsonUtils.getStr(rs, "dict_label");
                    String value = JsonUtils.getStr(rs, "dict_value");
                    String index = JsonUtils.getStr(rs, "remark");

                    if (StringUtils.isNotBlank(value)) {
                        String[] arr = value.trim().split("#");
                        sbr.setKey(arr[0]);
                        sbr.setValue(arr[1]);
                    }
                    sbr.setIndex(index);
                    sbr.setProduct(product);
                    sbrMap.put(id, sbr);
                } catch (Exception e) {
                    log.error(e.getMessage(), e);
                }

            }
            //JsonUtils.printStr(sbrMap);
            log.info("*******SBR PROD统计：" + sbrMap.size());
        } catch (Exception e) {
            log.error(e.getMessage(), e);
        }
    }
}
