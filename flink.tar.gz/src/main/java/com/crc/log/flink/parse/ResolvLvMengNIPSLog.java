package com.crc.log.flink.parse;

import com.crc.log.flink.common.constants.LevelConstants;
import com.crc.log.flink.common.constants.LogConstants;
import com.crc.log.flink.common.utils.DataUtils;
import com.crc.log.flink.common.utils.DateUtils;
import com.crc.log.flink.common.utils.JsonUtils;
import com.crc.log.flink.common.utils.MapUtils;
import org.apache.commons.lang3.StringUtils;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.concurrent.ConcurrentHashMap;

/**
 * @author jixiangqi
 * @date 2022/4/29
 * 绿盟NIPS
 */
public class ResolvLvMengNIPSLog {
    static SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");

    public static ConcurrentHashMap<String, Object> parse(String message) {
        try {
            ConcurrentHashMap<String, Object> data = proc(message);
            if (DataUtils.isNotEmptyJson(data)) {
                return data;
            }
        } catch (Exception ignored) {

        }
        return null;
    }

    private static ConcurrentHashMap<String, Object> proc(String jsonStr) {
        ConcurrentHashMap<String, Object> rtnObjc = JsonUtils.createBaseMap(jsonStr);
        String[] split = DataUtils.getSplit(jsonStr, ";");
        for (String tempStr : split) {
            int index = DataUtils.getIndex(tempStr, "=");
            String key = DataUtils.getSubString(tempStr, 0, index).trim().replaceAll("\"", "");
            String value = DataUtils.getSubString(tempStr, index + 1).trim().replaceAll("\"", "");
            switchKeyValue(rtnObjc, key, value);
        }
        rtnObjc.put(LogConstants.LOG_PRODUCT, "绿盟NIPS");
        rtnObjc.put(LogConstants.LOG_LEVEL, LevelConstants.getLevel(MapUtils.getStr(rtnObjc,LogConstants.LOG_LEVEL)));
        if (StringUtils.isBlank(MapUtils.getStr(rtnObjc, LogConstants.SRC_IP))) {
            rtnObjc.put(LogConstants.SRC_IP, "0.0.0.0");
        }
        if (StringUtils.isBlank(MapUtils.getStr(rtnObjc, LogConstants.DEST_IP))) {
            rtnObjc.put(LogConstants.DEST_IP, "0.0.0.0");
        }
        setAlertName(rtnObjc);
        return rtnObjc;
    }

    private static void setAlertName(ConcurrentHashMap<String, Object> rtnObjc) {
        String message = "";
        String alertName = "";
        String level = MapUtils.getStr(rtnObjc, LogConstants.LOG_LEVEL);
        String count = MapUtils.getStr(rtnObjc, LogConstants.LOG_COUNT);
        String logType = MapUtils.getStr(rtnObjc, LogConstants.LOG_TYPE);
        String descript = MapUtils.getStr(rtnObjc, LogConstants.LOG_DESCRIPTION);
        String srcIp = MapUtils.getStr(rtnObjc, LogConstants.SRC_IP);
        String destIp = MapUtils.getStr(rtnObjc, LogConstants.DEST_IP);
        String proto = MapUtils.getStr(rtnObjc, LogConstants.LOG_PROTOCAL);
        String actionResult = MapUtils.getStr(rtnObjc, LogConstants.ACTION_RESULT);
        switch (logType) {
            case "登录":
            case "异常":
            case "自动更新":
            case "手工更新":
            case "重启引擎":
            case "重启设备":
            case "操作":
                String userName = MapUtils.getStr(rtnObjc, LogConstants.USER_NAME);
                String devIp = MapUtils.getStr(rtnObjc, LogConstants.LOG_DEV_IP);
                String content = MapUtils.getStr(rtnObjc, LogConstants.LOG_CONTENT);
                message = "用户名为:%s在IP地址为:%s上执行了%s,日志内容为:%s,日志级别为:%s";
                alertName = String.format(message, userName, devIp, logType, content, level);
                break;
            case "ips_log":
                String actionType = MapUtils.getStr(rtnObjc, LogConstants.ACTION_TYPE);
                message = "IP为:%s对IP为:%s进行了%s类型的攻击,攻击结果为:%s,攻击次数为:%s攻击协议为:%s,日志级别为:%s";
                alertName = String.format(message, srcIp, destIp, actionType, actionResult,count, proto, level);
                break;
            case "malicious_file_log":
                String url = MapUtils.getStr(rtnObjc, LogConstants.LOG_URL);
                message = "IP为:%s对IP为:%s进行了攻击,日志描述为:%s,攻击结果为:%s,攻击路径为:%s,攻击协议为:%s,日志级别为:%s";
                alertName = String.format(message, srcIp, destIp, descript, actionResult, url, proto, level);
                break;
            case "advance_threat_file_log":
                message = "IP为:%s对IP为:%s进行高级恶意样本攻击,日志描述为:%s,攻击结果为:%s,攻击次数:%s,攻击协议为:%s,日志级别为:%s";
                alertName = String.format(message, srcIp, destIp, descript, actionResult, count, proto, level);
                break;
            case "malicious_file_callback_log":
                message = "IP为:%s对IP为:%s进行回连监控阻断攻击,日志描述为:%s,攻击结果为:%s,攻击次数:%s,攻击协议为:%s,日志级别为:%s";
                alertName = String.format(message, srcIp, destIp, descript, actionResult, count, proto, level);
                break;
            case "wb_dns_log":
            case "wb_malicious_ip_log":
            case "web_secure_log":
            case "ddos_log":
            case "sensitive_file_log":
            case "abaction_log":
            case "cc_log":
                String logTypeNew = "";
                switch (logType){
                    case "wb_dns_log":
                        logTypeNew = "域名黑名单";
                        break;
                    case "wb_malicious_ip_log":
                        logTypeNew = "IP黑名单";
                        break;
                    case "web_secure_log":
                        logTypeNew = "Web安全";
                        break;
                    case "ddos_log":
                        logTypeNew = "DOS防护";
                        break;
                    case "sensitive_file_log":
                        logTypeNew = "文件传输控制";
                        break;
                    case "cc_log":
                        logTypeNew = "C&C通信";
                        break;
                    case "abaction_log":
                        logTypeNew = "服务器异常";
                        break;
                }
                if (StringUtils.isNotBlank(count)) {
                    message = "IP为:%s对IP为:%s进行了%s类型的攻击,攻击结果为:%s,日志描述为:%s,攻击次数为:%s,攻击协议为:%s,日志级别为:%s";
                    alertName = String.format(message, srcIp, destIp, logTypeNew, actionResult, descript, count, proto, level);
                } else {
                    message = "IP为:%s对IP为:%s进行了%s类型的攻击,攻击结果为:%s,日志描述为:%s,攻击协议为:%s,日志级别为:%s";
                    alertName = String.format(message, srcIp, destIp, logTypeNew, actionResult, descript, proto, level);
                }
                break;
            case "sensitive_data_log":
            case "app_log":
            case "ws_log":
                logTypeNew = "";
                switch (logType) {
                    case "ws_log":
                        logTypeNew = "URL分类";
                        break;
                    case "sensitive_data_log":
                        logTypeNew = "敏感数据";
                        break;
                    case "app_log":
                        logTypeNew = "应用管理";
                        break;
                }
                if (StringUtils.isNotBlank(descript)) {
                    message = "IP为:%s对IP为:%s进行了%s类型的攻击,攻击次数为:%s,日志描述为:%s,攻击协议为:%s,日志级别为:%s";
                    alertName = String.format(message, srcIp, destIp, logTypeNew, count, descript, proto, level);
                } else {
                    message = "IP为:%s对IP为:%s进行了%s类型的攻击,攻击次数为:%s,攻击协议为:%s,日志级别为:%s";
                    alertName = String.format(message, srcIp, destIp, logTypeNew, count, proto, level);
                }
                break;
            default:
                content = MapUtils.getStr(rtnObjc, LogConstants.LOG_CONTENT);
                if (StringUtils.isNotBlank(content)) {
                    String module = MapUtils.getStr(rtnObjc, LogConstants.MODULE);
                    message = "%s模块出现了%s,日志内容为:%s,日志级别为:%s";
                    alertName = String.format(message, module, logType, content, level);
                } else {
                    alertName = MapUtils.getStr(rtnObjc, LogConstants.LOG_ORI_MSG);
                }
                break;
        }
        rtnObjc.put(LogConstants.ALERT_NAME, alertName);
    }

    private static void switchKeyValue(ConcurrentHashMap<String, Object> rtnObjc, String key, String value) {
        switch (key) {
            case "level":
                rtnObjc.put(LogConstants.LOG_LEVEL, LevelConstants.getLevel(getLevel(value)));
                break;
            case "type":
                String logType = "";
                switch (value) {
                    case "1":
                        logType = "警告日志";
                        break;
                    case "2":
                        logType = "警告日志";
                        break;
                    case "3":
                        logType = "警告日志";
                        break;
                }
                rtnObjc.put(LogConstants.LOG_TYPE, logType);
                break;
            case "module":
                String module = "";
                switch (value.toLowerCase()) {
                    case "network":
                        module = "网络故障";
                        break;
                    case "interface":
                        module = "接口状态";
                        break;
                    case "ha":
                        module = "高可用性日志";
                        break;
                    case "system":
                        module = "系统日志";
                        break;
                    case "bypass":
                        module = "Bypass日志";
                        break;
                    case "power_temp":
                        module = "电源温度";
                        break;
                    case "board":
                        module = "主板温度";
                        break;
                    case "cpu":
                        module = "cpu温度";
                        break;
                    case "fan_speed?":
                        module = "风扇转速";
                        break;
                    case "mgtcpuratio":
                        module = "管理核利用率";
                        break;
                    case "corecpuratio":
                        module = "数据核利用率";
                        break;
                    case "memratio":
                        module = "内存利用率";
                        break;
                    case "cf":
                        module = "cf卡利用率";
                        break;
                    case "disk":
                        module = "硬盘利用率";
                        break;
                }
                rtnObjc.put(LogConstants.MODULE, module);
            case "risk":
                String logLevel = getLevel(value);
                rtnObjc.put(LogConstants.LOG_LEVEL, LevelConstants.getLevel(logLevel));
                break;
            case "device_type":
                rtnObjc.put(LogConstants.DEVICE_TYPE, value);
                break;
            case "time":
                try {
                    Date parse = sdf.parse(value);
                    rtnObjc.put(LogConstants.LOG_START_TIME, DateUtils.getISO8601Timestamp(value.trim(), "yyyy-MM-dd HH:mm:ss"));
                } catch (ParseException e) {
                    rtnObjc.put(LogConstants.LOG_START_TIME, DateUtils.getISO8601Timestamp(sdf.format(new Date(DataUtils.toNum(value) * 1000L)), "yyyy-MM-dd HH:mm:ss"));
                }
                break;
            case "user":
                rtnObjc.put(LogConstants.USER_NAME, value);
                break;
            case "loginip":
                rtnObjc.put(LogConstants.LOG_DEV_IP, value);
                break;
            case "msg":
                rtnObjc.put(LogConstants.LOG_CONTENT, value);
                break;
            case "log_type":
                String logTye = "";
                switch (value) {
                    case "1":
                        logTye = "登录";
                        break;
                    case "2":
                        logTye = "操作";
                        break;
                    case "3":
                        logTye = "异常";
                        break;
                    case "4":
                        logTye = "自动更新";
                        break;
                    case "5":
                        logTye = "手工更新";
                        break;
                    case "6":
                        logTye = "重启引擎";
                        break;
                    case "7":
                        logTye = "重启设备";
                        break;
                }
                rtnObjc.put(LogConstants.LOG_TYPE, logTye);
                break;
            case "oper_result":
                rtnObjc.put(LogConstants.ACTION_RESULT, value);
                break;
            case "security_name":
                rtnObjc.put(LogConstants.LOG_TYPE, value);
                break;
            case "sip":
                rtnObjc.put(LogConstants.SRC_IP, value);
                break;
            case "smac":
                rtnObjc.put(LogConstants.SRC_MAC, value);
                break;
            case "sport":
                rtnObjc.put(LogConstants.SRC_PORT, value);
                break;
            case "dip":
                rtnObjc.put(LogConstants.DEST_IP, value);
                break;
            case "dmac":
                rtnObjc.put(LogConstants.DEST_MAC, value);
                break;
            case "dport":
                rtnObjc.put(LogConstants.DEST_PORT, value);
                break;

            case "ruleid":
                rtnObjc.put(LogConstants.RULE_ID, value);
                break;
            case "event":
                rtnObjc.put(LogConstants.LOG_DESCRIPTION, value);
                break;
            case "threat_level":
                logLevel = getLevel(value);
                rtnObjc.put(LogConstants.LOG_LEVEL, LevelConstants.getLevel(logLevel));
                break;
            case "attack_type":
                String actionType = "";
                switch (value) {
                    case "1":
                        actionType = "获取权限类攻击";
                        break;
                    case "2":
                        actionType = "信息收集类攻击";
                        break;
                    case "3":
                        actionType = "可疑网络活动类攻击";
                        break;
                    case "4":
                        actionType = "网络监控类攻击";
                        break;
                    case "0":
                        actionType = "拒绝服务类攻击";
                        break;
                }
                rtnObjc.put(LogConstants.ACTION_TYPE, actionType);
                break;
            case "count":
                rtnObjc.put(LogConstants.LOG_COUNT, value);
                break;
            case "protocol":
                rtnObjc.put(LogConstants.LOG_PROTOCAL, value);
                break;
            case "ar":
                String actionResult = "";
                switch (value) {
                    case "1":
                        actionResult = "攻击失败（FAIL）";
                        break;
                    case "2":
                        actionResult = "未知（UNKNOWN)";
                        break;
                    case "0":
                        actionResult = "攻击成功（SUCCESS）";
                        break;
                }
                rtnObjc.put(LogConstants.ACTION_RESULT, actionResult);
                break;
            case "threat_type":
                rtnObjc.put(LogConstants.LOG_NAME, value);
                break;
            case "url":
                rtnObjc.put(LogConstants.LOG_URL, value);
                break;
            case "file_type":
                rtnObjc.put(LogConstants.FILE_TYPE, value);
            case "action":
                actionType = "";
                if (StringUtils.isBlank(MapUtils.getStr(rtnObjc, LogConstants.ACTION_TYPE))) {
                    switch (value) {
                        case "1":
                            actionType = "记录日志";
                            break;
                        case "2":
                            actionType = "阻断会话";
                            break;
                        case "4":
                            actionType = "丢弃当前报文";
                            break;
                        case "8":
                            actionType = "隔离";
                            break;
                        case "20":
                            actionType = "发送snmp trap";
                            break;
                        case "10":
                            actionType = "TCP旁路阻断";
                            break;
                        case "40":
                            actionType = "发送短信";
                            break;
                        case "80":
                            actionType = "抓取会话报文";
                            break;
                        case "100":
                            actionType = "抓取当前报文";
                            break;
                        case "200":
                            actionType = "限速";
                            break;
                    }
                    rtnObjc.put(LogConstants.ACTION_TYPE, actionType);
                }
        }
    }

    private static String getLevel(String value) {
        String logLevel = "";
        switch (value) {
            case "1":
                logLevel = "低危";
                break;
            case "2":
                logLevel = "中危";
                break;
            case "3":
                logLevel = "高危";
                break;
        }
        return logLevel;
    }
}
