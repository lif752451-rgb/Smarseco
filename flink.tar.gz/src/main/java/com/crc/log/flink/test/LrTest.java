package com.crc.log.flink.test;

import com.crc.log.flink.common.utils.JsonUtils;
import com.crc.log.flink.config.AllConfig;
import com.crc.log.flink.es.DataProcessFuncation;

import java.util.concurrent.ConcurrentHashMap;

public class LrTest {
    public static void main(String[] args) {
        String msg1 = "<14>[AuditDB.tbl_devaccess8021x]uiddomainid=S0229555410332978,uidrecordid=8a2bd924-2a57-31ec-8000-005056841c8a,strmac=A4:D9:31:92:05:32,strusername=A4:D9:31:92:05:32,struserdes=,uidroleid=0,strrolename=,strswitchip=10.54.0.103,strifname=0100000000000514,iisauthsuc=0,iisantipolicy=0,iisaccessed=0,strvlan=,strmachinecode=,strrandomcode=,straccessfailedreason=没有定义的未知MAC地址,iaccesstype=1,straccessfailedcode=UR_MAB_FAIL,uidnacpolicyid=,iaccesscode=0,strssid=CR-MAC,inahaccess=0,iguestaccess=0,strpolicyname=,strdomainname=本管理域,uiddevrecordid=,strdevip=,strip1=,strdevname=,uidswitchdeptid=0,uidswitchid=9de5b3b8-b6bc-11eb-8000-005056841c8a,strswitchname=RL755XYD05WXACHC103,iauthmodel=-1,inotifystatus=1,straccessfaileddesc=,idoublefactorauth=-1,idfauthresult=0,strvlanformat=,straclformat=,straccountname=A4:D9:31:92:05:32,strradiussrvip=10.54.0.212,strradiussrvmac=00:50:56:84:1c:8a,strradussrvname=jtfdcnacvpra02,iEnterpriseID=0,stracctsessionid=00000004202110110552520028969408100514,strradiusappid=UniRadiusd@00:50:56:84:1c:8a,ionlineduration=0,strofflinereason=,dtaccesstime=2021-10-11 13:53:21";
        String msg2 = "\t<14>[AuditDB.tbl_emailcontrolauditinfo]uidrecordid=C07CC6B4-0220-45A6-8EEB-213DB03E8000,strprocessname=C:\\Program Files (x86)\\Microsoft Office\\Office16\\OUTLOOK.EXE,strprocessuser=LINQIAOSHAN1,strip=crc.com.hk,iport=0,strrecipients=zhangluqi5@crc.com.hk,strccs=,strtitle=转发: 回复：录用通知书(西安) - 张彬彬,strcontent=,strattachlvfslink=,strkeywordidlisttitle=,strkeywordidlistcontent=,strkeywordidlistattach=,uidlvfsserverid=,strcontentlvfslink=,uiddevrecordid=02536EB0-5D9F-45E8-B220-874EA3E127A6,uiddomainid=S0229555410332978,strdomainname=本管理域,strdevip=10.54.18.72,strip1=10.54.18.72,strnet=10.54.16.0/21,strmac=14:85:7F:EA:71:67,strdevname=SZ-30-PC232548.crhd0a.crc.hk,strdevalias=,strusername=LINQIAOSHAN1,struserdesc=Lin Qiaoshan 林乔珊,uiddeptid=9727-b3472ecb671389da8b3-la,strrolename=人力资源部,uidsecpolicyid=d2a6-f4b8b788671f9564302-,isecpolicytype=741,strsecpolicyname=邮件审计策略,iblock=0,iagentonline=1,idevrecordid=0,strwindowsuser=LINQIAOSHAN1,stragentid=02536EB0-5D9F-45E8-B220-874EA3E127A6,strauditid=D75FE3F7-6B2F-4668-8E45-A38C5A74B656,strreason=,strsender=rsl_hrcb_zy@crc.com.hk,i_attach_file_counts=1,i_attach_file_size=1007,dttime=2021-10-11 13:55:09";
        a1(msg1);
        a1(msg2);
    }

    public static void a1(String msg){
        AllConfig config = new AllConfig();
        DataProcessFuncation.CONIFG = config;
        config.setMode("single");
        config.setParse("ResolvWifiAccessLog");
        config.setIndex("sec_all");


        ConcurrentHashMap<String, Object> json = DataProcessFuncation.parse(msg,"index");
        JsonUtils.printStr(json);
    }
}
