package com.crc.log.flink.test.log;

import com.crc.log.flink.common.utils.JsonUtils;
import com.crc.log.flink.config.AllConfig;
import com.crc.log.flink.es.DataProcessFuncation;

import java.util.concurrent.ConcurrentHashMap;


public class ResolvSxfFirewallLogTest {

    public static void main(String[] args) {
        AllConfig config = new AllConfig();
        DataProcessFuncation.CONIFG = config;
        config.setMode("single");
        config.setParse("ResolvSxfFirewallLog");
        config.setIndex("sec_all");

        String str = "<134>Nov 30 10:45:36 localhost fwlog: 日志类型:服务控制或应用控制, 策略名称:上网策略放行, 用户:(null), 源IP:10.222.11.253, 源端口:46945, 目的IP:198.41.0.4, 目的端口:53, 应用类型:Other, 应用名称:any, 系统动作:允许";
        ConcurrentHashMap<String, Object> proc = DataProcessFuncation.parse(str,"index");
        JsonUtils.printStr(proc);


        /*str = "<134>Nov 30 10:45:36 localhost fwlog: 日志类型:服务控制或应用控制, 策略名称:本地内网访问华润数据中心, 用户:(null), 源IP:10.222.3.130, 源端口:57537, 目的IP:10.72.64.73, 目的端口:80, 应用类型:Other, 应用名称:any, 系统动作:允许";
        proc = DataProcessFuncation.parse(str,"index");
        JsonUtils.printStr(proc);

        str = "<134>Nov 30 09:11:17 localhost fwlog: 日志类型:僵尸网络日志, 策略名称:服务器防护, 特征ID:0, 源IP:10.222.11.2, 源端口:50415, 目的IP:0.0.0.0, 目的端口:53, 攻击类型:僵尸网络, 严重级别:信息, 系统动作:拒绝, URL:tj.fanppp.cn";
        proc = DataProcessFuncation.parse(str,"index");
        JsonUtils.printStr(proc);

        str = "<134>Nov 29 18:26:28 localhost fwlog: 日志类型:僵尸网络日志, 策略名称:用户安全防护, 特征ID:0, 源IP:192.168.100.50, 源端口:49470, 目的IP:221.229.203.209, 目的端口:80, 攻击类型:异常流量, 严重级别:中, 系统动作:允许, URL:-";
        proc = DataProcessFuncation.parse(str,"index");
        JsonUtils.printStr(proc);

        str = "<134>Dec 22 14:09:08 localhost fwlog: 日志类型:用户认证, 用户:172.16.31.177, IP地址:172.16.31.177, 操作对象:登录, 登录时间:14:09:08, 登录时长:0, 注销时间:0";
        proc = DataProcessFuncation.parse(str,"index");
        JsonUtils.printStr(proc);

        str = "<134>Dec 22 14:31:07 localhost fwlog: 日志类型:用户认证, 用户:(null), IP地址:172.16.120.236, 操作对象:登录, 登录时间:14:31:07, 登录时长:0, 注销时间:0";
        proc = DataProcessFuncation.parse(str,"index");
        JsonUtils.printStr(proc);*/

        str = "<134>Jan 14 13:38:40 localhost fwlog: 日志类型:僵尸网络日志, 策略名称:业务防护-hw, 特征ID:0, 源IP:10.153.111.83, 源端口:63871, 目的IP:204.11.56.48, 目的端口:443, 攻击类型:僵尸网络, 严重级别:高, 系统动作:允许, URL:-";
        proc = DataProcessFuncation.parse(str,"index");
        JsonUtils.printStr(proc);
    }
}
