package com.crc.log.flink.parse;

import com.crc.log.flink.common.constants.LevelConstants;
import com.crc.log.flink.common.constants.LogConstants;
import com.crc.log.flink.common.utils.DataUtils;
import com.crc.log.flink.common.utils.DateUtils;
import com.crc.log.flink.common.utils.MapUtils;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringEscapeUtils;
import org.apache.commons.lang3.StringUtils;

import java.util.concurrent.ConcurrentHashMap;

/**
 * @author wenxiaoming
 * @date 2022/05/19
 * nxlog转发的安全设备Syslog日志
 */
@Slf4j
public class ReslovNxlogSysLog {
    public static boolean parseGood = false;

    public static ConcurrentHashMap<String, Object> parse(String message) {
        try {
            ConcurrentHashMap<String, Object> data = proc(message);
            if (DataUtils.isNotEmptyJson(data)) {
                return data;
            }
        } catch (Exception ignored) {

        }
        return null;
    }

    private static ConcurrentHashMap<String, Object> proc(String nxlogStr) {
        ConcurrentHashMap<String, Object> rtnObjc = new ConcurrentHashMap<>();
        String[] strings = DataUtils.getSplit(nxlogStr, "#@%");
        for (String string : strings) {
            if (strings.length == 1) {
                //log.error("无分割符#@%：" + nxlogStr);
                try {
                    return CommonStrParseLog.parse(nxlogStr);
                } catch (Exception e) {
                    return null;
                }
            }
            String temp = string;
            int index = DataUtils.getIndex(temp, "=");
            if (index == -1) {
                log.error("格式错误，日志详情为：" + nxlogStr);
                return null;
            }
            String key = DataUtils.getSubString(temp, 0, index).trim().toLowerCase();
            String value = DataUtils.getSubString(temp, index + 1).trim();
            if (key.length() > 100 || key.contains(".")) {
                log.error("nxlog字段拆分异常：" + nxlogStr);
                return null;
            }
            switch (key) {
                case "src_ip":
                    rtnObjc.put(LogConstants.SRC_IP, value);
                    break;
                case "src_port":
                    rtnObjc.put(LogConstants.SRC_PORT, value);
                    break;
                case "dst_ip":
                    rtnObjc.put(LogConstants.DEST_IP, value);
                    break;
                case "dst_port":
                    rtnObjc.put(LogConstants.DEST_PORT, value);
                    break;
                case "proto":
                    rtnObjc.put(LogConstants.LOG_PROTOCAL, value);
                    break;
                case "sparktime":
                    rtnObjc.put(LogConstants.LOG_TIME, DateUtils.getISO8601Timestamp(value));
                    break;
                case "dev_ip":
                    rtnObjc.put(LogConstants.LOG_DEV_IP, value);
                    break;
                case "product":
                    rtnObjc.put(LogConstants.LOG_PRODUCT, value);
                    break;
                case "action_result":
                    rtnObjc.put(LogConstants.ACTION_RESULT, value);
                    break;
                case "action_type":
                    rtnObjc.put(LogConstants.ACTION_TYPE, value);
                    break;
                case "alert_name":
                    rtnObjc.put(LogConstants.ALERT_NAME, value);
                    break;
                case "log_level":
                    rtnObjc.put(LogConstants.LOG_LEVEL, LevelConstants.getLevel(value));
                    break;
                case "msg":
                    rtnObjc.put(LogConstants.LOG_ORI_MSG, value);
                    break;
                default:
                    rtnObjc.put(key, value);
                    break;
            }
        }

        //奇安信天擎特殊处理
        if (MapUtils.equal(rtnObjc, LogConstants.LOG_PRODUCT, "奇安信天擎")) {
            String b = StringEscapeUtils.unescapeJava(MapUtils.getStr(rtnObjc, LogConstants.LOG_ORI_MSG));
            rtnObjc.put(LogConstants.LOG_ORI_MSG, b);
        }

        if (StringUtils.isBlank(MapUtils.getStr(rtnObjc, LogConstants.SRC_IP))) {
            rtnObjc.put(LogConstants.SRC_IP, "0.0.0.0");
        }
        if (StringUtils.isBlank(MapUtils.getStr(rtnObjc, LogConstants.DEST_IP))) {
            rtnObjc.put(LogConstants.DEST_IP, "0.0.0.0");
        }
        if (!rtnObjc.containsKey(LogConstants.LOG_TIME)) {
            rtnObjc.put(LogConstants.LOG_TIME, DateUtils.getSparkTime());
        }
        if (!rtnObjc.containsKey(LogConstants.ALERT_NAME)) {
            setAlertName(rtnObjc);
        }
        return rtnObjc;
    }

    private static void setAlertName(ConcurrentHashMap<String, Object> rtnObjc) {
        String devIp = MapUtils.getStr(rtnObjc, LogConstants.LOG_DEV_IP);
        String srcIp = MapUtils.getStr(rtnObjc, LogConstants.SRC_IP);
        String srcPort = MapUtils.getStr(rtnObjc, LogConstants.SRC_PORT);
        String dstIp = MapUtils.getStr(rtnObjc, LogConstants.DEST_IP);
        String dstPort = MapUtils.getStr(rtnObjc, LogConstants.DEST_PORT);
        String logType = MapUtils.getStr(rtnObjc, LogConstants.ACTION_TYPE);
        String logname = MapUtils.getStr(rtnObjc, LogConstants.LOG_NAME);
        String log = MapUtils.getStr(rtnObjc, LogConstants.LOG_ORI_MSG);
        String msgFormat = "【源IP：%s】【目的IP：%s】【分类：%s】【行为：%s】【告警来源设备IP：%s】【详情：%s】";
        String alertName = String.format(msgFormat, srcIp, dstIp, logType, logname, devIp, log);

        if (!srcPort.equalsIgnoreCase("") && !dstPort.equalsIgnoreCase("")) {
            msgFormat = "【源IP：%s】【源端口：%s】【目的IP：%s】【目的端口：%s】【分类：%s】【行为：%s】【告警来源设备IP：%s】 日志详情为：%s";
            alertName = String.format(msgFormat, srcIp, srcPort, dstIp, dstPort, logType, logname, devIp, log);
        }

        rtnObjc.put(LogConstants.ALERT_NAME, alertName);
    }
}
