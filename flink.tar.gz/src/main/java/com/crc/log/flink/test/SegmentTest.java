//package com.crc.log.flink.test;
//
//import com.crc.log.flink.common.utils.JsonUtils;
//import com.crc.log.flink.load.NewSegmentLoad;
//import com.crc.log.flink.load.SegmentLoad;
//import com.crc.log.flink.net.IPBean;
//import com.crc.log.flink.net.IpFixedUtils;
//import org.slf4j.Logger;
//import org.slf4j.LoggerFactory;
//
//import java.util.Map;
//
//public class SegmentTest {
//    private static final Logger log = LoggerFactory.getLogger(SegmentTest.class);
//
//    public static void test() throws InterruptedException {
//        String ip = "10.200.0.139";
//        log.info("开始SegmentLoad");
//        NewSegmentLoad newSeg = new NewSegmentLoad();
//        newSeg.sync();
//        log.info("结束SegmentLoad");
//        IPBean ipBean = NewSegmentLoad.getIPByHalf(ip);
//        JsonUtils.printStr(ipBean);
//    }
//
//    public static void test2() throws InterruptedException {
//        String ip = "10.200.0.139";
//        log.info("开始SegmentLoad");
//        SegmentLoad.sync();
//        log.info("结束SegmentLoad");
//
//        log.info("开始SegmentLoad");
//        NewSegmentLoad newSeg = new NewSegmentLoad();
//        newSeg.sync();
//        log.info("结束SegmentLoad");
//        Thread.sleep(1000*10);
//        long os = System.currentTimeMillis();
//        System.out.println("开始old=" + os);
//        for (int i = 0; i < 10000; i++) {
//            Map map = IpFixedUtils.findByIp(ip);
//            System.out.print(map == null?"0":map.size());
//        }
//        System.out.println();
//        long oe = System.currentTimeMillis();
//        System.out.println("结束old=" + oe);
//        System.out.println((oe-os));
//
//        long ns = System.currentTimeMillis();
//        System.out.println("开始new=" + ns);
//        for (int i = 0; i < 10000; i++) {
//            IPBean ipBean = NewSegmentLoad.getIPByHalf(ip);
//            System.out.print(ipBean == null?"0":ipBean.getBegin());
//        }
//        System.out.println();
//        long ne = System.currentTimeMillis();
//        System.out.println("结束new=" + ne);
//        System.out.println((ne-ns));
//    }
//}
