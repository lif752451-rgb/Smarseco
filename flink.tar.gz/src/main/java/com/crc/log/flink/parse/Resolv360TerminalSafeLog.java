package com.crc.log.flink.parse;

import com.crc.log.flink.common.constants.LevelConstants;
import com.crc.log.flink.common.constants.LogConstants;
import com.crc.log.flink.common.utils.DataUtils;
import com.crc.log.flink.common.utils.DateUtils;
import com.crc.log.flink.common.utils.JsonUtils;
import com.crc.log.flink.common.utils.MapUtils;
import org.apache.commons.lang3.StringUtils;

import java.util.concurrent.ConcurrentHashMap;

/**
 * @author jixiangqi
 * @date 2022/2/16
 * 360终端安全日志
 */
public class Resolv360TerminalSafeLog {
    public static ConcurrentHashMap<String, Object> parse(String message) {
        try {
            ConcurrentHashMap<String, Object> data = proc(message);
            if (DataUtils.isNotEmptyJson(data)) {
                return data;
            }
        } catch (Exception ignored) {

        }
        return null;
    }

    private static ConcurrentHashMap<String, Object> proc(String jsonStr) {
        ConcurrentHashMap<String, Object> rtnObjc = JsonUtils.createBaseMap(jsonStr);
        String[] split = DataUtils.getSplit(jsonStr, ",");
                //jsonStr.split(",");
        for (String s : split) {
            String[] keyValue = DataUtils.getSplit2(s, ":");
            //split[i].split(":");
            if (keyValue.length == 2) {
                String key = keyValue[0].trim().replaceAll("\"", "").replace("{", "");
                String value = keyValue[1].trim().replaceAll("\"", "");
                switchKeyValue(key, value, rtnObjc);
            }
        }
        if (StringUtils.isBlank(MapUtils.getStr(rtnObjc, LogConstants.SRC_IP))) {
            rtnObjc.put(LogConstants.SRC_IP, "0.0.0.0");
        }
        if (StringUtils.isBlank(MapUtils.getStr(rtnObjc, LogConstants.DEST_IP))) {
            rtnObjc.put(LogConstants.DEST_IP, "0.0.0.0");
        }
        rtnObjc.put(LogConstants.LOG_PRODUCT, "360EPP");
        setAlertName(rtnObjc);
        return rtnObjc;
    }

    private static void switchKeyValue(String key, String value, ConcurrentHashMap<String, Object> rtnObjc) {
        switch (key) {
            case "id":
                rtnObjc.put(LogConstants.EVENT_ID, value);
                break;
            case "name":
                rtnObjc.put(LogConstants.LOG_NAME, value);
                break;
            case "severitylevel":
                rtnObjc.put(LogConstants.LOG_LEVEL, LevelConstants.getLevel(value));
                break;
            case "summary":
                rtnObjc.put(LogConstants.LOG_DESCRIPTION, value);
                break;
            case "type":
                rtnObjc.put(LogConstants.ACTION_TYPE, value);
                break;
            case "ctime":
                rtnObjc.put(LogConstants.LOG_START_TIME, DateUtils.getISO8601Timestamp(value));
                break;
            case "status":
                rtnObjc.put(LogConstants.ACTION_RESULT, getResult(value));
                break;
            case "computername":
                rtnObjc.put(LogConstants.HOST_NAME, value);
                break;
            case "clientip":
                rtnObjc.put(LogConstants.SRC_IP, value);
                break;
            case "username":
                rtnObjc.put(LogConstants.USER_NAME, value);
                break;
            case "log_type":
                rtnObjc.put(LogConstants.LOG_TYPE, value.replace("}", ""));
                break;
            case "sysmaclist":
                rtnObjc.put(LogConstants.SRC_MAC, value);
                break;
            case "item_name":
                rtnObjc.put(LogConstants.LOG_NAME, value);
                break;
            case "item_description":
                rtnObjc.put(LogConstants.LOG_DESCRIPTION, value);
                break;
            case "system_repair_status":
                rtnObjc.put(LogConstants.ACTION_RESULT, getResult(value));
                break;
            case "process_path":
                rtnObjc.put(LogConstants.FILE_PATH, value);
                break;
            case "server_ip":
                rtnObjc.put(LogConstants.DEST_IP, value);
                break;
            case "file_path":
                rtnObjc.put(LogConstants.FILE_PATH, value);
                break;
            case "handle_result":
                rtnObjc.put(LogConstants.ACTION_RESULT, value);
                break;
            case "virus_name":
                rtnObjc.put(LogConstants.VIRUS_NAME, value);
                break;
            case "virus_type":
                rtnObjc.put(LogConstants.VIRUS_TYPE, value);
                break;
            case "handle_mode":
                rtnObjc.put(LogConstants.ACTION_TYPE, value);
                break;
            case "action":
                rtnObjc.put(LogConstants.ACTION_RESULT, value);
                break;
            case "ip_dst":
                rtnObjc.put(LogConstants.DEST_IP, value);
                break;
            case "port_dst":
                rtnObjc.put(LogConstants.DEST_PORT, value);
                break;
            case "ip_src":
                rtnObjc.put(LogConstants.SRC_IP, value);
                break;
            case "port_src":
                rtnObjc.put(LogConstants.SRC_PORT, value);
                break;
            case "net_protocol":
                rtnObjc.put(LogConstants.LOG_PROTOCAL, value);
                break;
            case "illegal_type":
                rtnObjc.put(LogConstants.ACTION_TYPE, value);
                break;
            case "archtype":
                rtnObjc.put(LogConstants.OS_INFO, value);
                break;
        }
    }

    private static String getResult(String value) {
        String result = "";
        if (StringUtils.isBlank(value)) {
            return result;
        }
        if (value.equalsIgnoreCase("remove")) {
            result = "修复";
        } else if (value.equalsIgnoreCase("ignore")) {
            result = "信任";
        } else if (value.equalsIgnoreCase("noignore")) {
            result = "不信任";
        }
        return result;
    }

    private static void setAlertName(ConcurrentHashMap<String, Object> rtnObjc) {
        String logType = MapUtils.getStr(rtnObjc, LogConstants.LOG_TYPE);
        String log = MapUtils.getStr(rtnObjc, LogConstants.LOG_ORI_MSG);
        String msgFormat = "";
        String alertName = "";
        String srcIp = MapUtils.getStr(rtnObjc, LogConstants.SRC_IP);
        switch (logType) {
            case "360edr_netaction_log":
                String destIp = MapUtils.getStr(rtnObjc, LogConstants.DEST_IP);
                String proto =  MapUtils.getStr(rtnObjc, LogConstants.LOG_PROTOCAL);
                String result = MapUtils.getStr(rtnObjc, LogConstants.ACTION_RESULT);
                msgFormat = "源IP为:%s对目的IP:%s发起了一个网络攻击,攻击协议:%s,攻击结果为:%s,源日志为:%s";
                alertName = String.format(msgFormat, srcIp, destIp, proto, result, log);
                break;
            case "360edr_hotpatch_log":
                String os = MapUtils.getStr(rtnObjc, LogConstants.OS_INFO);
                msgFormat = "IP地址为:%s的系统为:%s进行安全防护,源日志为:%s";
                alertName = String.format(msgFormat, srcIp, os, log);
                break;
            case "360exthost_360sdmgr_virus_log" :
            case "360exthost_360sdmgr_monitor_log":
                String path = MapUtils.getStr(rtnObjc, LogConstants.FILE_PATH);
                String virusName = MapUtils.getStr(rtnObjc, LogConstants.VIRUS_NAME);
                String virusResult = MapUtils.getStr(rtnObjc, LogConstants.ACTION_RESULT);
                msgFormat = "IP地址为:%s产生了一个病毒,病毒路径为:%s,病毒名称:%s,处理结果:%s,源日志为:%s";
                alertName = String.format(msgFormat, srcIp, path, virusName, virusResult, log);
                break;
            case "360exthost_netcontrol_illegal_net_log":
                msgFormat = "IP地址为:%s产生了一个违规外联,源日志为:%s";
                alertName = String.format(msgFormat, srcIp, log);
                break;
            case "360exthost_processxp_log":
                String processPath = MapUtils.getStr(rtnObjc, LogConstants.FILE_PATH);
                msgFormat = "IP地址为:%s产生了一个进程违规行为,进程路径为:%s,源日志为:%s";
                alertName = String.format(msgFormat, srcIp, processPath, log);
                break;
            case "360exthost_systemrepair":
                String des = MapUtils.getStr(rtnObjc, LogConstants.LOG_DESCRIPTION);
                String logResult = MapUtils.getStr(rtnObjc, LogConstants.ACTION_RESULT);
                msgFormat = "IP地址为:%s进行系统修复,修复原因为:%s,修复结果:%s,源日志为:%s";
                alertName = String.format(msgFormat, srcIp, des, logResult, log);
                break;
            case "360leakfix_system_log":
                msgFormat = "IP地址为:%s产生了一个系统日志,日志描述为:%s,日志级别为:%s,源日志为:%s";
                String logDes = MapUtils.getStr(rtnObjc, LogConstants.LOG_DESCRIPTION);
                String level = MapUtils.getStr(rtnObjc, LogConstants.LOG_LEVEL);
                alertName = String.format(msgFormat, srcIp, logDes, level, log);
                break;
        }
        rtnObjc.put(LogConstants.ALERT_NAME, alertName);
    }
}
