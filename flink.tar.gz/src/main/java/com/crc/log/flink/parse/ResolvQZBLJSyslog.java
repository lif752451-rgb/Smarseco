package com.crc.log.flink.parse;

import com.crc.log.flink.common.constants.LevelConstants;
import com.crc.log.flink.common.constants.LogConstants;
import com.crc.log.flink.common.utils.*;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;
import java.util.concurrent.ConcurrentHashMap;

/**
 * @author jixiangqi
 * @date 2022/5/24
 */
public class ResolvQZBLJSyslog {
    /**
     * 通用日志 日志泛化
     */
    public static ConcurrentHashMap<String,Object> parse(String message) {
        try {
            ConcurrentHashMap<String,Object> data = proc(message);
            if (DataUtils.isNotEmptyJson(data)) {
                return data;
            }
        } catch (Exception ignored) {

        }
        return null;
    }

    private static ConcurrentHashMap<String,Object> proc(String jsonStr) {
        ConcurrentHashMap<String,Object> rtnObjc = JsonUtils.createBaseMap(jsonStr);
        int i1 = StringUtils.stringSubIndexTwo(jsonStr, '>', 1);
        jsonStr = DataUtils.getSubString(jsonStr, i1+1);
        int index = 0;
        String tempStr = "";
        int index1 = 0;
        if (jsonStr.charAt(10) == 'T') {
            index = StringUtils.stringSubIndexTwo(jsonStr, ' ', 1);
            String time = DataUtils.getSubString(jsonStr, 0, index);
            rtnObjc.put(LogConstants.LOG_START_TIME, DateUtils.getISO8601Timestamp(time, "yyyy-MM-dd'T'HH:mm:ss"));
            index1 = StringUtils.stringSubIndexTwo(jsonStr, ' ', 2);
            String hostName = DataUtils.getSubString(jsonStr, index+1, index1+1).trim();
            rtnObjc.put(LogConstants.HOST_NAME,hostName);
            int index2 = StringUtils.stringSubIndexTwo(jsonStr, ':', 3);
            tempStr = DataUtils.getSubString(jsonStr, index2+1);
        } else {
            index = StringUtils.stringSubIndexTwo(jsonStr, ':', 3);
            tempStr = DataUtils.getSubString(jsonStr, 0, index).trim();
            index1 = StringUtils.stringSubIndexTwo(tempStr, ' ', 3);
            int index2 = StringUtils.stringSubIndexTwo(tempStr, ' ', 4);
            String time = DataUtils.getSubString(tempStr, 0, index1).trim();
            try {
                String d = time  + " " + DateUtils.getYear();
                SimpleDateFormat dateFormat = new SimpleDateFormat("MMM d HH:mm:ss yyyy", Locale.ENGLISH);
                Date date = dateFormat.parse(d);
                rtnObjc.put(LogConstants.LOG_START_TIME, DateUtils.getISO8601Timestamp(date));
            } catch (Exception ignored) {
                
            }
            String hostName = DataUtils.getSubString(tempStr, index1+1, index2).trim();
            rtnObjc.put(LogConstants.HOST_NAME,hostName);
            tempStr = DataUtils.getSubString(jsonStr, index+1);
        }
        if (tempStr.contains("(")) {
            index = StringUtils.stringSubIndexTwo(tempStr, '(', 1);
            index1 = StringUtils.stringSubIndexTwo(tempStr, ')', 1);
            String logName = DataUtils.getSubString(tempStr, 0, index);
            String logLevel = DataUtils.getSubString(tempStr, index + 1, index1);
            rtnObjc.put(LogConstants.LOG_LEVEL, LevelConstants.getLevel(logLevel));
            rtnObjc.put(LogConstants.LOG_NAME, logName);
            tempStr = DataUtils.getSubString(tempStr, index1+2, tempStr.length()-1);
            String[] split = DataUtils.getSplit(tempStr, ",");
            for (String temp : split) {
                String[] keyValue = DataUtils.getSplit(temp, "=");
                if (keyValue.length == 2) {
                    String key = keyValue[0].trim();
                    String value = keyValue[1].trim();
                    switch (key) {
                        case "id":
                            rtnObjc.put(LogConstants.EVENT_ID, value);
                            break;
                        case "service":
                            String type = "";
                            switch (value) {
                                case "native":
                                    type = "本地密码认证";
                                    break;
                                case "radius":
                                    type = "RADIUS认证";
                                    break;
                                case "totp":
                                    type = "动态令牌认证";
                                    break;
                                case "pubkey":
                                    type = "密钥认证";
                                    break;
                                case "usbkey":
                                    type = "USBKey认证";
                                    break;
                                default:
                                    type = value;
                                    break;
                            }
                            rtnObjc.put(LogConstants.ACTION_TYPE, type);
                            break;
                        case "identity":
                            rtnObjc.put(LogConstants.OP_NAME, value);
                            break;
                        case "from":
                            rtnObjc.put(LogConstants.SRC_IP, value);
                            break;
                        case "resName":
                        case "server":
                            rtnObjc.put(LogConstants.DEVICE_NAME, value);
                            break;
                        case "account":
                            rtnObjc.put(LogConstants.USER_NAME, value);
                            break;
                        case "action":
                            rtnObjc.put(LogConstants.ACTION_TYPE, value);
                            break;
                        case "command":
                            rtnObjc.put(LogConstants.LOG_CONTENT, value);
                            break;
                        case "protocol":
                            rtnObjc.put(LogConstants.LOG_PROTOCAL, value);
                            break;
                        case "changeType":
                            rtnObjc.put(LogConstants.ACTION_TYPE, value);
                            break;
                        case "resIp":
                            rtnObjc.put(LogConstants.LOG_DEV_IP, value);
                            break;
                        case "resType":
                            rtnObjc.put(LogConstants.DEVICE_TYPE, value);
                            break;
                        case "operate":
                            rtnObjc.put(LogConstants.ACTION_TYPE, value);
                            break;
                        case "status":
                        case "result":
                            rtnObjc.put(LogConstants.ACTION_RESULT, value);
                            break;
                        case "sql":
                        case "oper":
                        case "path":
                            rtnObjc.put(LogConstants.FILE_PATH, value);
                            break;

                    }
                } else if (keyValue.length == 1) {
                    if (temp.contains("login")) {
                        rtnObjc.put(LogConstants.ACTION_RESULT, temp);
                    }
                }
            }
        } else {
            rtnObjc.put(LogConstants.LOG_CONTENT, tempStr);
        }
        rtnObjc.put(LogConstants.LOG_PRODUCT, "齐治堡垒机");
        rtnObjc.put(LogConstants.LOG_LEVEL, LevelConstants.getLevel(MapUtils.getStr(rtnObjc,LogConstants.LOG_LEVEL)));
        if (org.apache.commons.lang3.StringUtils.isBlank(MapUtils.getStr(rtnObjc, LogConstants.SRC_IP))) {
            rtnObjc.put(LogConstants.SRC_IP, "0.0.0.0");
        }
        if (org.apache.commons.lang3.StringUtils.isBlank(MapUtils.getStr(rtnObjc, LogConstants.DEST_IP))) {
            rtnObjc.put(LogConstants.DEST_IP, "0.0.0.0");
        }
        setAlertName(rtnObjc);
        return rtnObjc;
    }

    private static void setAlertName(ConcurrentHashMap<String,Object> rtnObjc) {
        String message = "";
        String alertName = "";
        String srcIp = MapUtils.getStr(rtnObjc, LogConstants.SRC_IP);
        String log = MapUtils.getStr(rtnObjc, LogConstants.LOG_ORI_MSG);
        String content = MapUtils.getStr(rtnObjc, LogConstants.LOG_CONTENT);
        String logName = MapUtils.getStr(rtnObjc, LogConstants.LOG_NAME);
        if (srcIp.equals("0.0.0.0")) {
            String hostName = MapUtils.getStr(rtnObjc, LogConstants.HOST_NAME);
            if (org.apache.commons.lang3.StringUtils.isNotBlank(content)) {
                message = "在主机名为:%s的设备上出现名称为:%s的日志,日志详情为:%s";
                alertName = String.format(message, hostName, logName, log);
            } else {
                message = "在主机名为:%s的设备上出现了%s,日志名称为:%s,日志详情为:%s";
                alertName = String.format(message, hostName, content, logName, log);
            }
        } else {
            String opName = MapUtils.getStr(rtnObjc, LogConstants.OP_NAME);
            String actionType = MapUtils.getStr(rtnObjc, LogConstants.ACTION_TYPE);
            String actionResult = MapUtils.getStr(rtnObjc, LogConstants.ACTION_RESULT);
            String devName = MapUtils.getStr(rtnObjc, LogConstants.DEVICE_NAME);
            if (!org.apache.commons.lang3.StringUtils.isNotBlank(actionResult) &&
                    org.apache.commons.lang3.StringUtils.isNotBlank(content)) {
                message = "用户为:%s在IP为:%s的设备名称为:%s的机器上执行了%s操作,日志名称为:%s,日志内容为:%s,日志详情为:%s";
                alertName = String.format(message, opName, srcIp, devName, actionType, logName, content,log);

            } else {
                message = "用户为:%s在IP为:%s的设备名称为:%s的机器上执行了%s操作,操作结果为:%s,日志名称为:%s,日志详情为:%s";
                alertName = String.format(message, opName, srcIp, devName, actionType, actionResult, logName, log);
            }

        }
        rtnObjc.put(LogConstants.ALERT_NAME, alertName);
    }

}
