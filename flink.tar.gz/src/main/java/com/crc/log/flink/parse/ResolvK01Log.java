package com.crc.log.flink.parse;

import com.alibaba.fastjson.JSONObject;
import com.crc.log.flink.common.constants.ActionResultConstants;
import com.crc.log.flink.common.constants.LevelConstants;
import com.crc.log.flink.common.constants.LogConstants;
import com.crc.log.flink.common.utils.*;
import org.apache.commons.lang3.StringUtils;

import java.util.concurrent.ConcurrentHashMap;

/**
 * @Author daiyd
 * @Date: 2020/5/29 11:30
 * @Version 1.0
 */

public class ResolvK01Log {
    public static ConcurrentHashMap<String,Object> parse(String message) {
        try {
            ConcurrentHashMap<String,Object> data = proc(message);
            if (DataUtils.isNotEmptyJson(data)) {
                return data;
            }
        } catch (Exception ignored) {

        }
        return null;
    }

    private static ConcurrentHashMap<String,Object> proc(String jsonStr) {
        int i = DataUtils.getIndex(jsonStr, "{");
                //jsonStr.indexOf("{");
        jsonStr = DataUtils.getSubString(jsonStr, i);
                //jsonStr.substring(i);
        if (StringUtils.isBlank(jsonStr)) {
            return new ConcurrentHashMap<>();
        } else {
            ConcurrentHashMap<String,Object> k01Json = JsonUtils.createBaseMap(jsonStr);
            try {
                JSONObject jObj = JsonUtils.parse(jsonStr);
                if (JsonUtils.isEmpty(jObj)) {
                    return k01Json;
                }
                k01Json.put(LogConstants.LOG_PRODUCT, "K01");
                if (MapUtils.containsKey(jObj, "syslog")) {
                    JSONObject logObject = JsonUtils.getJson(jObj, "syslog");
                    MapUtils.setStr(k01Json, LogConstants.SRC_IP, logObject, "r_sip_s");
                    MapUtils.setStr(k01Json, LogConstants.SRC_PORT, logObject, "r_sport");

                    MapUtils.setStr(k01Json, LogConstants.DEST_IP, logObject, "r_dip_s");
                    MapUtils.setStr(k01Json, LogConstants.DEST_PORT, logObject, "r_dport");

                    MapUtils.setStr(k01Json, LogConstants.HOST_NAME, logObject, "r_hostname");

                    String actionResult = "1".equalsIgnoreCase(logObject.getString("r_action")) ?
                            ActionResultConstants.NO_DENY : ActionResultConstants.DENY;
                    MapUtils.setStr(k01Json, LogConstants.ACTION_RESULT, actionResult);
                    setLogNameAndLevel(k01Json, logObject);
                    MapUtils.setStr(k01Json, LogConstants.LOG_URL, logObject, "r_url");
                    MapUtils.setStr(k01Json, LogConstants.LOG_PROTOCAL, logObject, "r_layer_name");
                    MapUtils.setStr(k01Json, LogConstants.SRC_IP_COUNTRY, logObject, "r_country");
                    MapUtils.setStr(k01Json, LogConstants.SRC_IP_PROVINCE, logObject, "r_province");
                    MapUtils.setStr(k01Json, LogConstants.LOG_START_TIME, DateUtils.getISO8601Timestamp(JsonUtils.getLong(logObject, "r_time_i") * 1000L));
                    ScoreUtils.commonEventLevelScore(k01Json);
                }
                if (StringUtils.isBlank(MapUtils.getStr(k01Json, LogConstants.SRC_IP))) {
                    k01Json.put(LogConstants.SRC_IP, "0.0.0.0");
                }
                if (StringUtils.isBlank(MapUtils.getStr(k01Json, LogConstants.DEST_IP))) {
                    k01Json.put(LogConstants.DEST_IP, "0.0.0.0");
                }
                setAlertName(k01Json);
                return k01Json;
            } catch (Exception e) {
                return k01Json;
            }
        }
    }

    public static void setLogNameAndLevel(ConcurrentHashMap<String,Object> targetJson, JSONObject sourceJson) {
        String typeName = JsonUtils.getStr(sourceJson, "r_type_name");
        String eventName = "";
        if ("vul".equalsIgnoreCase(typeName)) {
            eventName = "漏洞利用";
        } else if ("Botnet".equalsIgnoreCase(typeName)) {
            eventName = "僵尸网络";
        } else if ("Malicious IP".equalsIgnoreCase(typeName)) {
            eventName = "恶意IP";
        } else if ("Scanner".equalsIgnoreCase(typeName)) {
            eventName = "扫描器";
        } else if ("WebShell Client".equalsIgnoreCase(typeName)) {
            eventName = "WebShell客户端";
        } else if ("TOR Node".equalsIgnoreCase(typeName)) {
            eventName = "TOR节点";
        } else if ("Crack".equalsIgnoreCase(typeName)) {
            eventName = "暴力破解";
        } else if ("CC".equalsIgnoreCase(typeName)) {
            eventName = "CC攻击";
        }else if("Black IP".equalsIgnoreCase(typeName)){
            eventName = "拦截IP";
        }
        String level = JsonUtils.getStr(sourceJson, "r_severity");
        if ("1".equalsIgnoreCase(level)) {
            targetJson.put(LogConstants.LOG_LEVEL, LevelConstants.MEDIUM);
        } else if ("2".equalsIgnoreCase(level)) {
            targetJson.put(LogConstants.LOG_LEVEL, LevelConstants.HIGH);
        } else
            targetJson.put(LogConstants.LOG_LEVEL, LevelConstants.LOW);
        if(StringUtils.isBlank(eventName)){
            eventName = "攻击行为";
        }
        targetJson.put(LogConstants.LOG_NAME, eventName);
    }

    //src_ip 对 dest_ip 的 hostname 进行 protocol-log_name-action_result
    public static void setAlertName(ConcurrentHashMap<String,Object> resultJson) {
        String srcIp = MapUtils.getStr(resultJson, LogConstants.SRC_IP);
        String destIp = MapUtils.getStr(resultJson, LogConstants.DEST_IP);
        String hostname = MapUtils.getStr(resultJson, LogConstants.HOST_NAME);
        String protocol = MapUtils.getStr(resultJson, LogConstants.LOG_PROTOCAL);
        String logName = MapUtils.getStr(resultJson, LogConstants.LOG_NAME);
        String actionResult = MapUtils.getStr(resultJson, LogConstants.ACTION_RESULT);
        String log = MapUtils.getStr(resultJson, LogConstants.LOG_ORI_MSG);
        if (StringUtils.isBlank(destIp) || "null".equals(destIp) || "0.0.0.0".equals(destIp)|| srcIp.equals(destIp)) {
            String alertName = "";
            if (!StringUtils.isEmpty(hostname)) {
                String messageFormat = "%s 对 %s 进行 %s-%s-%s,日志详情为:%s";
                alertName = String.format(messageFormat, srcIp, hostname, protocol, logName, actionResult, log);
            } else {
                String messageFormat = "%s 发起 %s 进行 %s-%s,日志详情为:%s";
                alertName = String.format(messageFormat, srcIp, protocol, logName, actionResult, log);
            }
            resultJson.put(LogConstants.ALERT_NAME, alertName);
        } else {
            String alertName = "";
            if (!StringUtils.isEmpty(hostname)) {
                String messageFormat = "%s 对 %s 的 %s 进行 %s-%s-%s,日志详情为:%s";
                alertName = String.format(messageFormat, srcIp, destIp, hostname, protocol, logName, actionResult, log);
            } else {
                String messageFormat = "%s 对 %s 进行 %s-%s-%s,日志详情为:%s";
                alertName = String.format(messageFormat, srcIp, destIp, protocol, logName, actionResult, log);
            }
            resultJson.put(LogConstants.ALERT_NAME, alertName);
        }
    }
}
