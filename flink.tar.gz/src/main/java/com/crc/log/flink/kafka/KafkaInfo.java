package com.crc.log.flink.kafka;

import lombok.extern.slf4j.Slf4j;
import org.apache.kafka.clients.admin.AdminClient;
import org.apache.kafka.clients.admin.DescribeTopicsResult;
import org.apache.kafka.clients.admin.TopicDescription;

import java.util.Collections;
import java.util.Properties;

@Slf4j
public class KafkaInfo {
    public static int getKafkaPartitionSize(String kafkaServer, String topicName) {
        // 设置Kafka连接属性
        Properties props = new Properties();
        props.put("bootstrap.servers", kafkaServer);

        try (AdminClient adminClient = AdminClient.create(props)) {
            // 指定要查询的主题名称
            // 构造TopicDescription对象并发送到服务器进行查询
            DescribeTopicsResult describeTopicsResult = adminClient.describeTopics(Collections.singletonList(topicName));
            TopicDescription topicDescription = describeTopicsResult.values().get(topicName).get();
            // 输出分区数量
            return topicDescription.partitions().size();
        } catch (Exception e) {
            log.error(e.getMessage(), e);
        }
        return -1;
    }
}