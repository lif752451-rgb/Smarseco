package com.crc.log.flink.es;

import com.alibaba.fastjson.JSONObject;
import com.crc.log.flink.common.constants.LevelConstants;
import com.crc.log.flink.common.constants.LogConstants;
import com.crc.log.flink.common.utils.DateUtils;
import com.crc.log.flink.common.utils.MapUtils;
import com.crc.log.flink.common.utils.RegUtils;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.apache.flink.api.common.functions.RuntimeContext;
import org.apache.flink.streaming.connectors.elasticsearch.ElasticsearchSinkFunction;
import org.apache.flink.streaming.connectors.elasticsearch.RequestIndexer;
import org.elasticsearch.action.index.IndexRequest;
import org.elasticsearch.client.Requests;
import org.elasticsearch.common.xcontent.XContentType;

import java.io.Serializable;
import java.util.concurrent.ConcurrentHashMap;


@Slf4j
public class SinkLogToESFunction implements ElasticsearchSinkFunction<String>, Serializable {
    private final String index;
    private final String indexSwitch;
    private final String topic;
    private final String mode;
    private final String docType;
    public static String[] DOC_FORM_TYPES = {"index", " _type", "_id", "_version"};//ES元数据字段

    public SinkLogToESFunction(String index, String indexSwitch, String topic, String mode, String docType) {
        this.index = index;
        this.topic = topic;
        this.indexSwitch = indexSwitch;
        this.mode = mode;
        if (StringUtils.isBlank(docType)) {
            docType = "_doc";
        }
        this.docType = docType;
    }

    public IndexRequest createIndexRequest(String esIndex, JSONObject jsonObject) {
        String indexName = String.format("%s-%s", esIndex, DateUtils.getDate1(0));
        if (StringUtils.isNotBlank(indexSwitch) && indexSwitch.equalsIgnoreCase("m")) {
            indexName = String.format("%s-%s", esIndex, DateUtils.getMon(0));
        } else if (StringUtils.isNotBlank(indexSwitch) && indexSwitch.equalsIgnoreCase("y")) {
            indexName = String.format("%s-%s", esIndex, DateUtils.getYear(0));
        }
        return Requests.indexRequest()
                .index(indexName)
                .type(docType)
                .source(jsonObject, XContentType.JSON);
    }

    @Override
    public void process(String string, RuntimeContext runtimeContext, RequestIndexer requestIndexer) {
        //System.out.println(string);
        ConcurrentHashMap<String,Object> msg = DataProcessFuncation.parse(string, topic);
        if (msg == null) {
            return;
        }
        if (!msg.containsKey(LogConstants.LOG_TIME)) {
            msg.put(LogConstants.LOG_TIME, DateUtils.getSparkTime());
        }
        msg.put("LOG_TIMESTAMP", System.currentTimeMillis());
        if (msg.containsKey(LogConstants.LOG_TIME)) {
            if (!msg.containsKey(LogConstants.LOG_NAME)) {
                msg.put(LogConstants.LOG_NAME, "行为日志");
            }
            if (msg.containsKey(LogConstants.DEST_PORT)) {
                msg.put(LogConstants.DEST_PORT, RegUtils.getNumber(MapUtils.getStr(msg, LogConstants.DEST_PORT)));
            }
            if (msg.containsKey(LogConstants.SRC_PORT)) {
                msg.put(LogConstants.SRC_PORT, RegUtils.getNumber(MapUtils.getStr(msg, LogConstants.SRC_PORT)));
            }

            //检测是否含有ES元数据字段 _index  、 _type   _id  _version
            for (String meta : DOC_FORM_TYPES) {
                msg.remove(meta);
            }

            String srcIp = MapUtils.getStr(msg, LogConstants.SRC_IP);
            String destIp = MapUtils.getStr(msg, LogConstants.DEST_IP);
            if ((StringUtils.isBlank(srcIp) || srcIp.equals("0.0.0.0")) && (StringUtils.isBlank(destIp) || destIp.equals("0.0.0.0"))) {
                msg.put(LogConstants.SRC_IP, MapUtils.getStr(msg, LogConstants.LOG_DEV_IP));
            }

            if (!msg.containsKey(LogConstants.LOG_LEVEL)) {
                msg.put(LogConstants.LOG_LEVEL, LevelConstants.INFO);
            }
            String newIndex = index;
            if (!"single".equals(mode)) {
                String index = MapUtils.getStr(msg, "es_index");
                if (StringUtils.isNotBlank(index))
                    newIndex = index;
            }
//            if (msg.containsKey("nxlog_index")) {
//                String index = MapUtils.getStr(msg, "nxlog_index");
//                msg.remove("nxlog_index");
//                if (StringUtils.isNotBlank(index))
//                    newIndex = index;
//            }
            try {
                JSONObject insertJson = new JSONObject(msg);
                requestIndexer.add(createIndexRequest(newIndex, insertJson));
            } catch (Exception ignored) {

            }
        }
    }
}

