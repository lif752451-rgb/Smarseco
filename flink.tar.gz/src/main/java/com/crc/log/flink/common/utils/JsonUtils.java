package com.crc.log.flink.common.utils;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;
import com.crc.log.flink.common.constants.LevelConstants;
import com.crc.log.flink.common.constants.LogConstants;
import org.apache.commons.lang3.StringEscapeUtils;
import org.apache.commons.lang3.StringUtils;

import java.util.Date;
import java.util.concurrent.ConcurrentHashMap;

/**
 * JSON工具类
 */
public class JsonUtils {
    public static void copyField(JSONObject sJson, JSONObject dJson, String src, String dest) {
        if (isEmpty(sJson) || StringUtils.isBlank(src)) {
            return;
        }

        try {
            if (sJson.get(src) != null) {
                dJson.put(dest, sJson.get(src));
            }
        } catch (Exception ignored) {

        }
    }

    public static void copyField(JSONObject json, String src, String dest) {
        if (isEmpty(json) || StringUtils.isBlank(src)) {
            return;
        }

        try {
            if (json.get(src) != null) {
                json.put(dest, json.get(src));
            }
        } catch (Exception ignored) {

        }
    }

    public static JSONObject getJson(JSONObject json, String filter) {
        if (isEmpty(json) || StringUtils.isBlank(filter)) {
            return createJson();
        }

        try {
            return json.getJSONObject(filter);
        } catch (Exception ignored) {

        }
        return createJson();
    }


    public static int getInt(JSONObject json, String filter) {
        if (isEmpty(json) || StringUtils.isBlank(filter)) {
            return 0;
        }
        if (json.get(filter) == null) {
            return 0;
        }
        try {
            return json.getIntValue(filter);
        } catch (Exception e) {
            return 0;
        }
    }

    public static long getLong(JSONObject json, String filter) {
        if (isEmpty(json) || StringUtils.isBlank(filter)) {
            return 0;
        }
        if (json.get(filter) == null) {
            return 0;
        }
        try {
            return json.getLongValue(filter);
        } catch (Exception e) {
            return 0;
        }
    }

    public static String getStr(JSONObject json, String filter, String defaultVal) {
        String ret = getStr(json, filter);
        if (StringUtils.isBlank(ret)) {
            return defaultVal;
        }
        return ret;
    }

    public static String getStr(JSONObject json, String filter) {
        if (isEmpty(json) || StringUtils.isBlank(filter)) {
            return "";
        }

        if (json.get(filter) == null) {
            return "";
        }
        try {
            Object val = json.get(filter);
            if (val instanceof Date) {
                return DateUtils.getSparkTime((Date) val);
            }
            String retStr = val.toString();
            if (StringUtils.isNotBlank(retStr)) {
                if ("null".equalsIgnoreCase(retStr)) {
                    return "";
                }
                return retStr.trim();
            }
        } catch (Exception ignored) {

        }
        return "";
    }

    /**
     * 判断filter值是否为空
     *
     * @param json
     * @param filter
     * @return
     */
    public static boolean isBlank(JSONObject json, String filter) {
        String str = getStr(json, filter);
        return !StringUtils.isBlank(str);
    }

    public static boolean containsKey(JSONObject json, String filter) {
        if (isEmpty(json) || StringUtils.isBlank(filter))
            return false;
        return json.containsKey(filter);
    }

    public static boolean isEmpty(JSONObject json) {
        if (json == null)
            return true;
        return json.isEmpty();
    }

    public static JSONObject createJson() {
        return new JSONObject();
    }

    public static JSONObject parse(String json) {
        try {
            if (StringUtils.isBlank(json)) {
                return createJson();
            }
            return JSON.parseObject(json);
        } catch (Exception ignored) {
        }
        return createJson();
    }

//    public static JSONObject parseUnescape(String json) {
//        try {
//            if (StringUtils.isBlank(json)) {
//                return createJson();
//            }
//            json = StringEscapeUtils.unescapeJson(json);
//            return JSON.parseObject(json);
//        } catch (Exception ignored) {
//
//        }
//        return createJson();
//    }

    public static ConcurrentHashMap<String,Object> createBaseMap(String json) {
        ConcurrentHashMap<String, Object> jsonObject = new ConcurrentHashMap<>();
        if (json.startsWith("devIp=")) {
            String devIp = json.split(" ")[0];
            jsonObject.put(LogConstants.LOG_DEV_IP, devIp.replace("devIp=", "").trim());
        }
        if (json.startsWith("crcTopic=")) {
            String devIp = json.split(" ")[0];
            String product = devIp.replace("crcTopic=", "").trim();
            product = product.replace("log_in", "");
            jsonObject.put(LogConstants.LOG_PRODUCT, product);
        }
        jsonObject.put(LogConstants.LOG_ORI_MSG, json);
        String logTime = DateUtils.getSparkTime();
        jsonObject.put(LogConstants.LOG_TIME, logTime);
        return jsonObject;
    }


    public static void print(Object json) {
        if (json != null)
            System.out.println(JSON.toJSONString(json));
    }

    public static boolean setStr(JSONObject dest, String filter, String val) {
        /*
         * IP属性必须为合法
         */
        if (LogConstants.SRC_IP.equalsIgnoreCase(filter) || LogConstants.DEST_IP.equalsIgnoreCase(filter)) {
            if (!IPUtil.isIp(val)) {
                val = null;
            }
        }
        if (StringUtils.isNotBlank(filter) && StringUtils.isNotBlank(val)) {
            dest.put(filter, val.trim());
            return true;
        }
        return false;
    }

    public static void setStr(JSONObject dest, String destFilter, JSONObject src, String srcFilter) {
        if (LogConstants.LOG_START_TIME.equalsIgnoreCase(destFilter)) {
            setDate(dest, destFilter, src, srcFilter);
            return;
        }
        if (LogConstants.LOG_LEVEL.equalsIgnoreCase(destFilter)) {
            String srcVal = LevelConstants.getLevel(getStr(src, srcFilter));
            setStr(dest, destFilter, srcVal);
            return;
        }
        String srcVal = getStr(src, srcFilter);
        setStr(dest, destFilter, srcVal);
    }

    public static void setDate(JSONObject dest, String destFilter, JSONObject src, String srcFilter) {
        String dateStr = DateUtils.getISO8601Timestamp(JsonUtils.getStr(src, srcFilter));
        setStr(dest, destFilter, dateStr);
    }

    public static String getJsonValue(JSONObject sourceJson, String sourceKey) {
        if (sourceKey.contains(".")) {
            String[] sourceKeys = sourceKey.split("\\.");
            String sourceKey1 = sourceKeys[0];
            String sourceKey2 = sourceKeys[1];
            JSONObject insideJson = JsonUtils.getJson(sourceJson, sourceKey1);
            return JsonUtils.getStr(insideJson, sourceKey2);
        }
        return JsonUtils.getStr(sourceJson, sourceKey);
    }


    public static void printStr(Object x) {
        print(x);
    }
}
