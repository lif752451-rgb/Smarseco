package com.crc.log.flink.test.log;

import com.crc.log.flink.common.utils.JsonUtils;
import com.crc.log.flink.config.AllConfig;
import com.crc.log.flink.es.DataProcessFuncation;

import java.util.concurrent.ConcurrentHashMap;

public class ResolvInternetBehaviorLogTest {

    public static void main(String[] args) {
        AllConfig config = new AllConfig();
        DataProcessFuncation.CONIFG = config;
        config.setMode("single");
        config.setParse("ResolvInternetBehaviorLog");
        config.setIndex("sec_all");
        String str = "<134>Nov 26 10:39:49 localhost BA[30907]: [log_type:flux] [record_time:2021-11-26 10:33:10] [user:10.152.222.51] [group:/办公楼的用户地址/] [host_ip:10.152.222.51] [dst_ip:::] [serv:未识别应用] [app:未识别应用] [site:未定义位置] [tm_type:/PC/MAC PC] [up_flux:8124] [down_flux:9288]";
        ConcurrentHashMap<String, Object> proc = DataProcessFuncation.parse(str,"index");
        JsonUtils.printStr(proc);
    }

}
