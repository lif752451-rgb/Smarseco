package com.crc.log.flink.test.log;

import com.crc.log.flink.common.utils.JsonUtils;
import com.crc.log.flink.config.AllConfig;
import com.crc.log.flink.es.DataProcessFuncation;

import java.util.concurrent.ConcurrentHashMap;

//深信服Waf测试类
public class SangforWafTest {
    public static void main(String[] args) {
//DOS攻击日志
//      String msgx ="<134>Nov 25 14:45:52 localhost fwlog: 日志类型:DOS攻击日志, 策略名称:外部DDOS防护, 源IP:218.17.168.189, 目的IP:10.91.13.115, 攻击方向:外网, 攻击类型:端口扫描, 严重等级:中, 系统动作:拒绝";
//失陷主机日志
        String msgx = "<134>Nov 25 19:16:58 localhost fwlog: 日志类型:失陷主机日志, 策略名称:业务防护, 特征ID:0, 源IP:10.74.59.60, 源端口:56537, 目的IP:0.0.0.0, 目的端口:53, 攻击类型:僵尸网络, 严重级别:信息, 系统动作:拒绝, URL:bit.pilutce.com";
//系统操作
//      String msgx="\t<134>Nov 22 17:55:20 localhost fwlog: 日志类型:系统操作, 用户:admin(local), IP地址:10.91.19.251, 操作对象:用户登录, 操作类型:登录, 描述:admin(local)  10.91.19.251  登录成功";
        AllConfig config = new AllConfig();
        DataProcessFuncation.CONIFG = config;
        config.setMode("single");
        config.setParse("ReslovSangforWaf");
        config.setIndex("sec_all");


        ConcurrentHashMap<String, Object> json = DataProcessFuncation.parse(msgx, "index");
        JsonUtils.printStr(json);
    }
}
