package com.crc.log.flink.test.log;

import com.crc.log.flink.common.utils.JsonUtils;
import com.crc.log.flink.config.AllConfig;
import com.crc.log.flink.es.DataProcessFuncation;

import java.util.concurrent.ConcurrentHashMap;

public class HwApTest
{
    public static void main(String[] args) {
        String msgx = "<190>Sep 17 13:41:18 2021 firewall-irf %%10FILTER/6/FILTER_ZONE_IPV4_EXECUTION: -Slot=2; SrcZoneName(1025)=1111;DstZoneName(1035)=总部2;Type(1067)=ACL;SecurityPolicy(1072)=成万访问总部;RuleID(1078)=27;Protocol(1001)=TCP;Application(1002)=http;SrcIPAddr(1003)=10.74.142.62;SrcPort(1004)=53125;SrcMacAddr(1021)=346b-5b12-8801;DstIPAddr(1007)=10.0.128.172;DstPort(1008)=80;MatchCount(1069)=1;Event(1048)=Permit;\\u0000";
        msgx = "<189>Nov 10 2021 00:01:11.180.1+00:00 HZ-ZZ-AC9700M %%01CM/5/USER_ACCESSRESULT(s)[20773]:[WLAN_STA_INFO_AUTHENTICATION]ACMAC:a4-16-e7-65-d1-f5;ACNAME:HZ-ZZ-AC9700M;APMAC:04-8c-16-69-cf-c0;APNAME:许昌紫云府项目部01;SSID:CRL-Mobile;RADIOID:1;USER:123456789..;MAC:e0-dc-ff-e0-d4-23;IPADDRESS:-;TIME:1636502471;ZONE:UTC-0000;DAYLIGHT:false;ERRCODE:206;RESULT:EAPOL client timeout;USERGROUP:NULL;AUTHENPLACE:RADIUS;CIB ID:95383;INTERFACE:Wlan-Dbss17676;ACCESS TYPE:None;SelectRDSIP:10.7.128.46/10.0.128.46SelectERRCODE:205/205;RDSIP:::;Portal TYPE:-;AUTHID=899622974;AuthFailType:802.1x;";

        AllConfig config = new AllConfig();
        DataProcessFuncation.CONIFG = config;
        config.setMode("single");
        config.setParse("ResolvHwAP");
        config.setIndex("sec_all");

        ConcurrentHashMap<String, Object> json = DataProcessFuncation.parse(msgx,"index");
        JsonUtils.printStr(json);
    }
}
