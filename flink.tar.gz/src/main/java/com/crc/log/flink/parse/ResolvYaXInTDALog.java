package com.crc.log.flink.parse;

import com.crc.log.flink.common.constants.LevelConstants;
import com.crc.log.flink.common.constants.LogConstants;
import com.crc.log.flink.common.utils.DataUtils;
import com.crc.log.flink.common.utils.DateUtils;
import com.crc.log.flink.common.utils.JsonUtils;
import com.crc.log.flink.common.utils.MapUtils;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;

import java.text.SimpleDateFormat;
import java.util.*;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.atomic.AtomicReference;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * @author jixiangqi
 * @date 2022/4/15
 * 亚信TDA
 */
@Slf4j
public class ResolvYaXInTDALog {
    public static ConcurrentHashMap<String, Object> parse(String message) {
        try {
            ConcurrentHashMap<String, Object> data = proc(message);
            if (DataUtils.isNotEmptyJson(data)) {
                return data;
            }
        } catch (Exception ignored) {

        }
        return null;
    }

    private static ConcurrentHashMap<String, Object> proc(String jsonStr) {
        ConcurrentHashMap<String, Object> rtnObjc = JsonUtils.createBaseMap(jsonStr);
        if (jsonStr.contains("CEF")) {
            String[] strings = DataUtils.getSplit(jsonStr, "\\|");
            for (int i = 0; i < strings.length; i++) {
                AtomicReference<String> labelValue = new AtomicReference<>("");
                switch (i) {
                    case 5:
                        rtnObjc.put(LogConstants.ACTION_TYPE, strings[i]);
                    case 7:
                        String[] s = DataUtils.getSplit(strings[i], " ");
                        Map<String, String> resultMap = getSpace(strings[i], " ", "=");
                        resultMap.forEach((key, value) -> {
                            switch (key) {
                                case "act":
                                    rtnObjc.put(LogConstants.ACTION_RESULT, value);
                                    break;
                                case "app":
                                    rtnObjc.put(LogConstants.LOG_PROTOCAL, value);
                                    break;
                               /* case "cat":
                                    rtnObjc.put(LogConstants.LOG_TYPE, value);
                                    break;*/
                                case "cnt":
                                    rtnObjc.put(LogConstants.LOG_COUNT, value);
                                    break;
                                case "cn3":
                                    String type = "";
                                    if (resultMap.get("cn3Label").equals("Threat Type")) {
                                        type = "Threat Type";
                                        switch (value) {
                                            case "0":
                                                type = type + "_恶意内容";
                                                break;
                                            case "1":
                                                type = type + "_恶意行为";
                                                break;
                                            case "2":
                                                type = type + "_可疑行为";
                                                break;
                                            case "3":
                                                type = type + "_漏洞利用";
                                                break;
                                            case "4":
                                                type = type + "_灰色软件";
                                                break;
                                        }
                                        rtnObjc.put(LogConstants.LOG_TYPE, type);
                                    }
                                    break;
                                case "cs1Label":

                                    break;
                                case "dmac":
                                    rtnObjc.put(LogConstants.DEST_MAC, value);
                                    break;
                                case "dpt":
                                    rtnObjc.put(LogConstants.DEST_PORT, value);
                                    break;
                                case "dst":
                                    rtnObjc.put(LogConstants.DEST_IP, value);
                                    break;
                                case "duser":
                                    rtnObjc.put(LogConstants.USER_NAME, value);
                                    break;
                                case "dvc":
                                    rtnObjc.put(LogConstants.LOG_DEV_IP, value);
                                    break;
                                case "filePath":
                                    rtnObjc.put(LogConstants.FILE_PATH, value);
                                    break;
                                case "fname":
                                    rtnObjc.put(LogConstants.LOG_FILENAME, value);
                                    break;
                                case "smac":
                                    rtnObjc.put(LogConstants.SRC_MAC, value);
                                    break;
                                case "src":
                                    rtnObjc.put(LogConstants.SRC_IP, value);
                                    break;
                                case "spt":
                                    rtnObjc.put(LogConstants.SRC_PORT, value);
                                    break;
                                case "rt":
                                    SimpleDateFormat dateFormat = new SimpleDateFormat("MMM d yyyy h:m:s", Locale.ENGLISH);
                                    try {
                                        rtnObjc.put(LogConstants.LOG_START_TIME, DateUtils.getISO8601Timestamp(dateFormat.parse(value)));
                                    } catch (Exception e) {
                                        log.error(e.getMessage(), e);
                                    }
                                    break;
                            }
                        });
                        break;
                }
            }
        }
        if (StringUtils.isBlank(MapUtils.getStr(rtnObjc, LogConstants.LOG_LEVEL))) {
            rtnObjc.put(LogConstants.LOG_LEVEL, LevelConstants.getLevel(MapUtils.getStr(rtnObjc,LogConstants.LOG_LEVEL)));
        }
        if (StringUtils.isBlank(MapUtils.getStr(rtnObjc, LogConstants.SRC_IP))) {
            rtnObjc.put(LogConstants.SRC_IP, "0.0.0.0");
        }
        if (StringUtils.isBlank(MapUtils.getStr(rtnObjc, LogConstants.DEST_IP))) {
            rtnObjc.put(LogConstants.DEST_IP, "0.0.0.0");
        }
        rtnObjc.put(LogConstants.LOG_PRODUCT, "亚信TDA");
        setAlertName(rtnObjc);
        return rtnObjc;
    }


    private static void setAlertName(ConcurrentHashMap<String, Object> rtnObjc) {
        String srcIp = MapUtils.getStr(rtnObjc, LogConstants.SRC_IP);
        String destIp = MapUtils.getStr(rtnObjc, LogConstants.DEST_IP);
        String logType = MapUtils.getStr(rtnObjc, LogConstants.LOG_TYPE);
        String result = MapUtils.getStr(rtnObjc, LogConstants.ACTION_RESULT);
        String actionType = MapUtils.getStr(rtnObjc, LogConstants.ACTION_TYPE);
        String log = MapUtils.getStr(rtnObjc, LogConstants.LOG_ORI_MSG);
        String alertName = "";
        String message;
        if (!srcIp.equals("0.0.0.0") && !destIp.equals("0.0.0.0")) {
            message = "IP为:%s对IP为:%s的进行了攻击,攻击结果为:%s,事件类型为:%s,攻击行为为:%s,日志详情为:%s";
            alertName = String.format(message, srcIp, destIp, result, logType, actionType, log);
        } else {
            String devIp = MapUtils.getStr(rtnObjc, LogConstants.LOG_DEV_IP);
            message = "设备IP为:%s的地址上产生了一个攻击,日志详情为:%s";
            alertName = String.format(message, devIp, log);
        }
        rtnObjc.put(LogConstants.ALERT_NAME, alertName);
    }


    /**
     * 正则获取字符串中的IP地址
     *
     * @param ipString
     * @return
     */
    private static List<String> getIps(String ipString) {
        String regEx = "((2[0-4]\\d|25[0-5]|[01]?\\d\\d?)\\.){3}(2[0-4]\\d|25[0-5]|[01]?\\d\\d?)";
        List<String> ips = new ArrayList<String>();
        Pattern p = Pattern.compile(regEx);
        Matcher m = p.matcher(ipString);
        while (m.find()) {
            String result = m.group();
            ips.add(result);
        }
        return ips;
    }


    private static Map<String, String> getSpace(String jsonStr, String symbol, String symbol1) {
        Map<String, String> resultMap = new HashMap<>();
        String index = "";
        String[] s = DataUtils.getSplit(jsonStr, symbol);
        for (String temp : s) {
            if (temp.contains("=")) {
                String[] split = DataUtils.getSplit(temp, symbol1);
                if (split.length == 2) {
                    resultMap.put(split[0].trim(), split[1].trim());
                    index = split[0].trim();
                }
            } else {
                resultMap.put(index, DataUtils.getString(resultMap,"index") + " " + temp);
            }
        }
        return resultMap;
    }
}
