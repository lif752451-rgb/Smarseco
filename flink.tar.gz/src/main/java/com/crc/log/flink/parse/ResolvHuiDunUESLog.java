package com.crc.log.flink.parse;

import com.alibaba.fastjson.JSONObject;
import com.crc.log.flink.common.constants.LevelConstants;
import com.crc.log.flink.common.constants.LogConstants;
import com.crc.log.flink.common.utils.*;
import lombok.extern.slf4j.Slf4j;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.concurrent.ConcurrentHashMap;

/**
 * @author jixiangqi
 * @date 2022/3/8
 * 惠盾UES日志解析类
 */
@Slf4j
public class ResolvHuiDunUESLog {
    
    public static ConcurrentHashMap<String,Object> parse(String message) {
        try {
            ConcurrentHashMap<String,Object> data = proc(message);
            if (DataUtils.isNotEmptyJson(data)) {
                return data;
            }
        } catch (Exception ignored) {

        }
        return null;
    }

    private static ConcurrentHashMap<String,Object> proc(String jsonStr) {
        int index = StringUtils.stringSubIndex(jsonStr, ':', 4);
        jsonStr = DataUtils.getSubString(jsonStr, index-1);
        ConcurrentHashMap<String,Object> rtnObjc = JsonUtils.createBaseMap(jsonStr);
        try {
            JSONObject jsonObject = JSONObject.parseObject(jsonStr);
            String type = JsonUtils.getStr(jsonObject, "_type");
            DateFormat df = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ssXXX");
            String recvTime = JsonUtils.getStr(jsonObject, "recvTime");
            Date parse = df.parse(recvTime);
            rtnObjc.put(LogConstants.LOG_START_TIME, DateUtils.getISO8601Timestamp(parse));
            String sender = JsonUtils.getStr(jsonObject, "sender");
            JSONObject senderObject = JSONObject.parseObject(sender);
            senderObject.forEach((k,v) -> {
                switchKeyValue(rtnObjc, k, v.toString());
            });
            senderObject = JSONObject.parseObject(JsonUtils.getStr(jsonObject, "args"));
            senderObject.forEach((k,v) -> {
                switchKeyValue(rtnObjc, k, v.toString());
            });
            rtnObjc.put(LogConstants.LOG_PRODUCT, "慧盾UES");
            if (org.apache.commons.lang3.StringUtils.isBlank(MapUtils.getStr(rtnObjc, LogConstants.SRC_IP))) {
                rtnObjc.put(LogConstants.SRC_IP, "0.0.0.0");
            }
            if (org.apache.commons.lang3.StringUtils.isBlank(MapUtils.getStr(rtnObjc, LogConstants.DEST_IP))) {
                rtnObjc.put(LogConstants.DEST_IP, "0.0.0.0");
            }
           /* if (org.apache.commons.lang3.StringUtils.isBlank(MapUtils.getStr(rtnObjc, LogConstants.LOG_LEVEL))) {
                rtnObjc.put(LogConstants.LOG_LEVEL, LevelConstants.getLevel(rtnObjc.getString(LogConstants.LOG_LEVEL)));
            }*/
            setAlertName(rtnObjc, type);
        } catch (Exception e) {
            log.error("惠盾日志解析错误：{}",e.getMessage(), e);
        }
        return rtnObjc;
    }

    private static void setAlertName(ConcurrentHashMap<String,Object> rtnObjc, String type) {
        rtnObjc.put(LogConstants.LOG_LEVEL, LevelConstants.LOW);
        String log = MapUtils.getStr(rtnObjc, LogConstants.LOG_ORI_MSG);
        String destIp = MapUtils.getStr(rtnObjc, LogConstants.DEST_IP);
        String srcIp = MapUtils.getStr(rtnObjc, LogConstants.DEST_IP);
        String virusName = "";
        String filePath = "";
        String result = "";
        String msgFormat = "";
        String alertName = "";
        String logType = "";
        switch (type) {
            case "VirusHandle":
                logType = "病毒处理";
                virusName = MapUtils.getStr(rtnObjc, LogConstants.VIRUS_NAME);
                filePath = MapUtils.getStr(rtnObjc, LogConstants.FILE_PATH);
                result = MapUtils.getStr(rtnObjc, LogConstants.ACTION_RESULT);
                msgFormat = "源IP为:%s对目的IP为:%s的设备上修复一个病毒,处理结果为:%s,病毒名称为:%s,病毒路径为:%s,源日志为:%s";
                alertName = String.format(msgFormat, srcIp, destIp, result, virusName, filePath, log);
                break;
            case "VirusDetect":
                virusName = MapUtils.getStr(rtnObjc, LogConstants.VIRUS_NAME);
                filePath = MapUtils.getStr(rtnObjc, LogConstants.FILE_PATH);
                result = MapUtils.getStr(rtnObjc, LogConstants.ACTION_RESULT);
                msgFormat = "源IP为:%s对目的IP为:%s的设备上发现了一个病毒,处理结果为:%s,病毒名称为:%s,病毒路径为:%s,源日志为:%s";
                alertName = String.format(msgFormat, srcIp, destIp, result, virusName, filePath, log);
                logType = "病毒发现";
                break;
            case "VulHandle":
                result = MapUtils.getStr(rtnObjc, LogConstants.ACTION_RESULT);
                msgFormat = "源IP为:%s对目的IP为:%s的设备上处理了一个漏洞,处理结果为:%s,源日志为:%s";
                alertName = String.format(msgFormat, srcIp, destIp, result, log);
                logType = "漏洞处理";
                break;
            case "DefenseHandle":
                virusName = MapUtils.getStr(rtnObjc, LogConstants.VIRUS_NAME);
                filePath = MapUtils.getStr(rtnObjc, LogConstants.FILE_PATH);
                result = MapUtils.getStr(rtnObjc, LogConstants.ACTION_RESULT);
                msgFormat = "源IP为:%s对目的IP为:%s的设备上产生了主动防御,处理结果为:%s,风险名称为:%s,操作路径为:%s,源日志为:%s";
                alertName = String.format(msgFormat, srcIp, destIp, result, virusName, filePath, log);
                logType = "实时防护";
                break;
        }
        rtnObjc.put(LogConstants.LOG_TYPE, logType);
        rtnObjc.put(LogConstants.ALERT_NAME, alertName);
    }


    private static void switchKeyValue(ConcurrentHashMap<String,Object> rtnObjc, String k, String v) {
        switch (k.trim()) {
            case "mid":
                rtnObjc.put(LogConstants.DEVICE_ID, v);
                break;
            case "publicIP":
                rtnObjc.put(LogConstants.DEST_IP, v);
                break;
            case "client":
                JSONObject jsonObject = JSONObject.parseObject(v);
                jsonObject.forEach((k1, v1) -> {
                    switchKeyValue(rtnObjc, k1, v1.toString());
                });
                break;
            case "IpPort":
                if (v.contains(":")) {
                    String[] split = DataUtils.getSplit2(v, ":");
                    if (split.length == 2) {
                        rtnObjc.put(LogConstants.SRC_IP, split[0]);
                        rtnObjc.put(LogConstants.SRC_PORT, split[1]);
                    }
                } else {
                    rtnObjc.put(LogConstants.SRC_IP, v);
                }
                break;
            case "Mac":
                rtnObjc.put(LogConstants.SRC_MAC, v);
                break;
            case "virusName":
                rtnObjc.put(LogConstants.VIRUS_NAME, v);
                break;
            case "filePath":
                rtnObjc.put(LogConstants.FILE_PATH, v);
                break;
            case "result":
                rtnObjc.put(LogConstants.ACTION_RESULT, v);
                break;
            case "FixResult":
                rtnObjc.put(LogConstants.ACTION_RESULT, v.equals("1") ? "成功":"失败");
                break;
            case "riskName":
                rtnObjc.put(LogConstants.VIRUS_NAME, v);
                break;
            case "optProcPath":
                rtnObjc.put(LogConstants.FILE_PATH, v);
                break;
            case "commandLine":
                rtnObjc.put(LogConstants.DEVICE_ID, v);
                break;
            case "ProtocolType":
                String protoType = "";
                switch (v) {
                    case "1":
                        protoType = "ICMP";
                        break;
                    case "2":
                        protoType = "IGMP";
                        break;
                    case "6":
                        protoType = "TCP";
                        break;
                    case "8":
                        protoType = "EGP";
                        break;
                    case "9":
                        protoType = "IGP";
                        break;
                    case "17":
                        protoType = "UDP";
                        break;
                    case "41":
                        protoType = "IPv6";
                        break;
                    case "47":
                        protoType = "GRE";
                        break;
                    case "50":
                        protoType = "ESP";
                        break;
                    case "51":
                        protoType = "AH";
                        break;
                    case "88":
                        protoType = "EIGRP";
                        break;
                    case "89":
                        protoType = "OSPF";
                        break;
                    case "112":
                        protoType = "VRRP";
                        break;
                    case "115":
                        protoType = "L2TP";
                        break;
                    case "0":
                        protoType = "HOPOPT IPv6";
                        break;
                }
                rtnObjc.put(LogConstants.LOG_PROTOCAL, protoType);
                break;
            case "DestIPv4":
                rtnObjc.put(LogConstants.DEST_IP, v);
                break;
            case "SrcIPv4":
                rtnObjc.put(LogConstants.SRC_IP, v);
                break;
            case "DestPort":
                rtnObjc.put(LogConstants.DEST_PORT, v);
                break;
            case "SrcPort":
                rtnObjc.put(LogConstants.SRC_PORT, v);
                break;
            case "User":
                rtnObjc.put(LogConstants.OP_NAME, v);
                break;
            case "Name":
                rtnObjc.put(LogConstants.HOST_NAME, v);
                break;
            case "GroupNamePath":
                rtnObjc.put(LogConstants.GROUP_NAME, v);
                break;
        }
    }
}
