package com.crc.log.flink.parse;

import com.alibaba.fastjson.JSONObject;
import com.crc.log.flink.common.constants.LevelConstants;
import com.crc.log.flink.common.constants.LogConstants;
import com.crc.log.flink.common.utils.DataUtils;
import com.crc.log.flink.common.utils.JsonUtils;
import com.crc.log.flink.common.utils.MapUtils;
import org.apache.commons.lang3.StringUtils;

import java.util.concurrent.ConcurrentHashMap;

/**
 * 奇安信防堡垒机解析类
 */
public class ResolvQAXBljLog {

    /**
     * 通用日志 日志泛化
     */
    public static ConcurrentHashMap<String, Object> parse(String message) {
        try {
            ConcurrentHashMap<String, Object> data = proc(message);
            if (DataUtils.isNotEmptyJson(data)) {
                return data;
            }
        } catch (Exception ignored) {

        }
        return null;
    }

    private static ConcurrentHashMap<String, Object> proc(String value) {
        ConcurrentHashMap<String, Object> ldapJson = JsonUtils.createBaseMap(value);

        JSONObject dataJson = new JSONObject();

        String jsonStr = value;
        jsonStr = DataUtils.getSubString(jsonStr, DataUtils.getIndex(jsonStr, "logType"));
        //jsonStr.substring(jsonStr.indexOf("logType"));
        String[] IPS_buff = DataUtils.getSplit(jsonStr, ", ");
        //jsonStr.split(", ");
        for (String s : IPS_buff) {
            String[] datakey = DataUtils.getSplit(s, "=");
            //IPS_buff[i].split("=");
            if (1 < datakey.length) {
                if (datakey[1].contains("\"")) {
                    dataJson.put(datakey[0], datakey[1].replaceAll("\"", ""));
                } else {
                    dataJson.put(datakey[0], datakey[1]);
                }
            }
        }

        ldapJson.put(LogConstants.LOG_PRODUCT, "奇安信堡垒机");
        if (dataJson.get("logType") != null && dataJson.get("logType").equals("YAB_SYSTEM_LOGIN_LOG")) {
            MapUtils.setStr(ldapJson, LogConstants.OP_NAME, dataJson, "user");
            MapUtils.setStr(ldapJson, LogConstants.SRC_IP, dataJson, "sourceIP");
            MapUtils.setStr(ldapJson, LogConstants.ALERT_NAME, dataJson, "operation");
        } else if (dataJson.get("logType") != null && dataJson.get("logType").equals("YAB_RESOURCE_LOGIN_LOG")) {
            MapUtils.setStr(ldapJson, LogConstants.OP_NAME, dataJson, "user");
            MapUtils.setStr(ldapJson, LogConstants.SRC_IP, dataJson, "sourceIP");
            MapUtils.setStr(ldapJson, LogConstants.DEST_IP, dataJson, "targetIP");
            MapUtils.setStr(ldapJson, LogConstants.LOG_PROTOCAL, dataJson, "protocol");
            MapUtils.setStr(ldapJson, LogConstants.ACTION_RESULT, dataJson, "action");
        } else if (dataJson.get("logType") != null && dataJson.get("logType").equals("YAB_CMD_OPS_LOG")) {
            MapUtils.setStr(ldapJson, LogConstants.OP_NAME, dataJson, "user");
            MapUtils.setStr(ldapJson, LogConstants.SRC_IP, dataJson, "sourceIP");
            MapUtils.setStr(ldapJson, LogConstants.DEST_IP, dataJson, "targetIP");
            MapUtils.setStr(ldapJson, LogConstants.LOG_PROTOCAL, dataJson, "protocol");
            MapUtils.setStr(ldapJson, LogConstants.ACTION_RESULT, dataJson, "action");
        }
        ldapJson.put(LogConstants.MSG_CONTENT, value);
        ldapJson.put(LogConstants.LOG_LEVEL, LevelConstants.getLevel(MapUtils.getStr(ldapJson,LogConstants.LOG_LEVEL)));
        if (StringUtils.isBlank(MapUtils.getStr(ldapJson, LogConstants.SRC_IP))) {
            ldapJson.put(LogConstants.SRC_IP, "0.0.0.0");
        }
        if (StringUtils.isBlank(MapUtils.getStr(ldapJson, LogConstants.DEST_IP))) {
            ldapJson.put(LogConstants.DEST_IP, "0.0.0.0");
        }
        setAlertName(ldapJson);
        return ldapJson;
    }

    private static void setAlertName(ConcurrentHashMap<String, Object> ldapJson) {
        String srcIp = MapUtils.getStr(ldapJson, LogConstants.SRC_IP);
        String destIp = MapUtils.getStr(ldapJson, LogConstants.DEST_IP);
        String result = MapUtils.getStr(ldapJson, LogConstants.ACTION_RESULT);
        String log = MapUtils.getStr(ldapJson, LogConstants.LOG_ORI_MSG);
        String msgFormat = "源IP:%s,目的IP:%s,操作结果:%s,日志详情为:%s";
        String alertName = String.format(msgFormat, srcIp, destIp, result, log);
        ldapJson.put(LogConstants.ALERT_NAME, alertName);
    }
}
