package com.crc.log.flink.parse;

import com.crc.log.flink.common.constants.LevelConstants;
import com.crc.log.flink.common.constants.LogConstants;
import com.crc.log.flink.common.utils.DataUtils;
import com.crc.log.flink.common.utils.DateUtils;
import com.crc.log.flink.common.utils.JsonUtils;
import com.crc.log.flink.common.utils.MapUtils;
import org.apache.commons.lang3.StringUtils;

import java.util.concurrent.ConcurrentHashMap;

/**
 * @author jixiangqi
 * @date 2022/1/13
 * 天融信EDR
 */
public class ResolvTrxEDRLog {
    public static ConcurrentHashMap<String,Object> parse(String message) {
        try {
            ConcurrentHashMap<String,Object> data = proc(message);
            if (DataUtils.isNotEmptyJson(data)) {
                return data;
            }
        } catch (Exception ignored) {

        }
        return null;
    }

    private static ConcurrentHashMap<String,Object> proc(String jsonStr) {
        ConcurrentHashMap<String,Object> rtnObjc = JsonUtils.createBaseMap(jsonStr);
        String[] s = DataUtils.getSplit(jsonStr, " ");
                //jsonStr.split(" ");
        for (String item : s) {
            String tempStr = item.replace("\"", "");
            String[] split = DataUtils.getSplit(tempStr, "=");
            //tempStr.split("=");
            if (split.length == 2) {
                String key = split[0].trim();
                String value = split[1].trim();
                switchKeyAndValue(rtnObjc, key, value);
            }
        }
        rtnObjc.put(LogConstants.LOG_PRODUCT, "天融信EDR");
        rtnObjc.put(LogConstants.LOG_LEVEL, LevelConstants.getLevel(MapUtils.getStr(rtnObjc,LogConstants.LOG_LEVEL)));
        if (StringUtils.isBlank(MapUtils.getStr(rtnObjc, LogConstants.SRC_IP))) {
            rtnObjc.put(LogConstants.SRC_IP, "0.0.0.0");
        }
        if (StringUtils.isBlank(MapUtils.getStr(rtnObjc, LogConstants.DEST_IP))) {
            rtnObjc.put(LogConstants.DEST_IP, "0.0.0.0");
        }
        setAlertName(rtnObjc);
        return rtnObjc;
    }

    private static void switchKeyAndValue(ConcurrentHashMap<String,Object> rtnObjc, String key, String value) {
        switch (key) {
            case "defense_type":
                rtnObjc.put(LogConstants.ACTION_TYPE,value);
                break;
            case "detail_cmdline":
                rtnObjc.put(LogConstants.LOG_APP,value);
                break;
            case "time":
                long time = DataUtils.toNum(value) * 1000L;
                rtnObjc.put(LogConstants.LOG_START_TIME, DateUtils.getISO8601Timestamp(time));
                break;
            case "detail_treatment":
                String actionResult = "";
                switch (value) {
                    case "0":
                        actionResult = "忽略";
                        break;
                    case "1":
                        actionResult = "询问";
                        break;
                    case "2":
                        actionResult = "清除";
                        break;
                    case "3":
                        actionResult = "阻止";
                        break;
                    case "4":
                        actionResult = "信任";
                        break;
                    case "5":
                        actionResult = "结束进程";
                        break;
                }
                rtnObjc.put(LogConstants.ACTION_RESULT, actionResult);
                break;
            case "client_id":
                rtnObjc.put(LogConstants.DEVICE_ID,value);
                break;
            case "hostname":
                rtnObjc.put(LogConstants.HOST_NAME,value);
                break;
            case "client_ip":
                rtnObjc.put(LogConstants.SRC_IP,value);
                break;
            case "detail_file_path":
                rtnObjc.put(LogConstants.FILE_PATH,value);
                break;
            case "detail_virus_name":
                rtnObjc.put(LogConstants.VIRUS_NAME,value);
                break;
            case "virus_type":
                rtnObjc.put(LogConstants.LOG_TYPE,value);
                break;
            case "detail_threats":
                rtnObjc.put(LogConstants.LOG_COUNT,value);
                break;
            case "version_product":
                rtnObjc.put(LogConstants.LOG_VERSION,value);
                break;
            case "detail_proc_path":
                rtnObjc.put(LogConstants.FILE_PATH,value);
                break;
            case "detail_protocol":
                String protoType = "";
                switch (value) {
                    case "1":
                        protoType = "ICMP";
                        break;
                    case "2":
                        protoType = "IGMP";
                        break;
                    case "6":
                        protoType = "TCP";
                        break;
                    case "8":
                        protoType = "EGP";
                        break;
                    case "9":
                        protoType = "IGP";
                        break;
                    case "17":
                        protoType = "UDP";
                        break;
                    case "41":
                        protoType = "IPv6";
                        break;
                    case "47":
                        protoType = "GRE";
                        break;
                    case "50":
                        protoType = "ESP";
                        break;
                    case "51":
                        protoType = "AH";
                        break;
                    case "88":
                        protoType = "EIGRP";
                        break;
                    case "89":
                        protoType = "OSPF";
                        break;
                    case "112":
                        protoType = "VRRP";
                        break;
                    case "115":
                        protoType = "L2TP";
                        break;
                }
                rtnObjc.put(LogConstants.LOG_PROTOCAL, protoType);
                break;
            case "detail_laddr":
                rtnObjc.put(LogConstants.DEST_IP,value);
                break;
            case "detail_lport":
                rtnObjc.put(LogConstants.DEST_PORT,value);
                break;
            case "group_name":
                rtnObjc.put(LogConstants.LOG_GROUP,value);
                break;
            case "detail_name":
                rtnObjc.put(LogConstants.LOG_NAME,value);
                break;
            case "detail_merged_dstfn":
                rtnObjc.put(LogConstants.LOG_URL,value);
                break;
            case "detail_fetched_dstfn":
                rtnObjc.put(LogConstants.LOG_URL,value);
                break;
        }
    }


    private static void setAlertName(ConcurrentHashMap<String,Object> rtnObjc) {
        String msgFormat = "";
        String alertName = "";
        String srcIp = MapUtils.getStr(rtnObjc, LogConstants.SRC_IP);
        String log = MapUtils.getStr(rtnObjc, LogConstants.LOG_ORI_MSG);
        if (MapUtils.getStr(rtnObjc, LogConstants.ACTION_TYPE).equals("virus")) {
            String virusName = MapUtils.getStr(rtnObjc, LogConstants.VIRUS_NAME);
            String result = MapUtils.getStr(rtnObjc, LogConstants.ACTION_RESULT);
            String filePath = MapUtils.getStr(rtnObjc, LogConstants.FILE_PATH);
            msgFormat = "IP为:%s的设备上产生一个名为:%s的病毒,病毒文件路径为:%s,用户操做结果为:%s,日志详情为:%s";
            alertName = String.format(msgFormat, srcIp, virusName, filePath, result, log);
        } else if (MapUtils.getStr(rtnObjc, LogConstants.ACTION_TYPE).equals("network")) {
            String destIp = MapUtils.getStr(rtnObjc, LogConstants.DEST_IP);
            String proto = MapUtils.getStr(rtnObjc, LogConstants.LOG_PROTOCAL);
            String logName = MapUtils.getStr(rtnObjc, LogConstants.LOG_NAME);
            msgFormat = "源IP为:%s对目的IP为:%s产生了一个网络攻击,攻击协议为:%s,日志名称为:%s,日志详情为:%s";
            alertName = String.format(msgFormat, srcIp, destIp, proto, logName, log);
        } else if (MapUtils.getStr(rtnObjc, LogConstants.ACTION_TYPE).equals("other")) {
            String url =  MapUtils.getStr(rtnObjc, LogConstants.LOG_URL);
            String level = MapUtils.getStr(rtnObjc, LogConstants.LOG_LEVEL);
            msgFormat = "源IP为:%s产生一个告警信息,告警url为:%s,告警级别为:%s,日志详情为:%s";
            alertName = String.format(msgFormat, srcIp, url, level, log);
        }
        rtnObjc.put(LogConstants.ALERT_NAME, alertName);
    }

}
