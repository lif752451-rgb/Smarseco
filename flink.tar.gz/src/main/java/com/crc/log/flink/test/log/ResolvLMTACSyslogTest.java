package com.crc.log.flink.test.log;

import com.crc.log.flink.common.utils.JsonUtils;
import com.crc.log.flink.config.AllConfig;
import com.crc.log.flink.es.DataProcessFuncation;

import java.util.concurrent.ConcurrentHashMap;

/**
 * @author jixiangqi
 * @date 2022/5/6
 */
public class ResolvLMTACSyslogTest {

    public static void main(String[] args) {
        AllConfig config = new AllConfig();
        DataProcessFuncation.CONIFG = config;
        config.setMode("single");
        config.setParse("ResolvLMTACSyslog");
        config.setIndex("sec_all");


        String str = "{\"topic\":\"lmtac_log\",\"dev_ip\":\"192.200.201.25\",\"message\":\"<255>user:DEVICE;loginip:0.0.0.0;time:2022-05-06 05:55:22;type:2;\\n时间同步失败，(时间同步服务器地址需要路由可达，且直连接口需要配置为可管理)\",\"type\":\"udp\",\"timestamp\":\"2022-05-06 05:53:14\"}\n";
        ConcurrentHashMap<String, Object> proc = DataProcessFuncation.parse(str,"index");
        JsonUtils.printStr(proc);

        str = "{\"topic\":\"lmtac_log\",\"dev_ip\":\"192.200.201.25\",\"message\":\"<5>msgtype:1;product:tac;ip:192.200.201.25;hash:7D81-34F7-975C-AAF3;data:{\\\"threat_info\\\": [{\\\"threat_name\\\": \\\"Exploit\\\", \\\"threat_level\\\": \\\"high\\\", \\\"engine_type\\\": 1, \\\"behavior\\\": \\\"Exploit.CVE-2018-0802.Gen\\\", \\\"description\\\": \\\"\\\"}], \\\"network\\\": [], \\\"session_info\\\": {\\\"sip\\\": \\\"37.49.225.157\\\", \\\"protocol\\\": \\\"\\\", \\\"time\\\": 1651790366, \\\"dport\\\": 25, \\\"sport\\\": 61190, \\\"dip\\\": \\\"10.0.76.11\\\"}, \\\"app_info\\\": {\\\"app_type\\\": \\\"SMTP\\\", \\\"app_detail\\\": \\\"{\\\\\\\"to\\\\\\\": \\\\\\\"\\\\\\\", \\\\\\\"orign\\\\\\\": \\\\\\\"\\\\\\\", \\\\\\\"from\\\\\\\": \\\\\\\"\\\\\\\", \\\\\\\"subject\\\\\\\": \\\\\\\"\\\\\\\"}\\\"}, \\\"summary\\\": {\\\"sha256\\\": \\\"7313b58fb069b063750310d29149b0bb38950980194e6d5895fa651116a1a412\\\", \\\"alert_time\\\": 1651790367, \\\"taskid\\\": \\\"7d8134f7975caaf31651790365a9e988\\\", \\\"file_size\\\": 211832, \\\"file_type\\\": \\\"XLSX\\\", \\\"file_name\\\": \\\"Q1VTVE9NIFBFUk1JVCBDTEVBUkFOQ0VTLnhsc3g=\\\", \\\"threat_level\\\": \\\"high\\\", \\\"tags\\\": [], \\\"md5\\\": \\\"fb3719db9072b22dcb3c1a87209703c6\\\"}, \\\"static\\\": {\\\"file_structure\\\": {\\\"MIME Type\\\": \\\"application/vnd.openxmlformats-officedocument.spreadsheetml.sheet\\\", \\\"File Type\\\": \\\"XLSX\\\"}, \\\"basic_info\\\": {\\\"crc32\\\": 3929456295, \\\"sha256\\\": \\\"7313b58fb069b063750310d29149b0bb38950980194e6d5895fa651116a1a412\\\", \\\"sha1\\\": \\\"fe6ee8b99e4c0d8224893ad3901315f62e164c93\\\", \\\"md5\\\": \\\"fb3719db9072b22dcb3c1a87209703c6\\\"}}, \\\"dropped\\\": []};\",\"type\":\"udp\",\"timestamp\":\"2022-05-06 06:37:19\"}";
        proc = DataProcessFuncation.parse(str,"index");
        JsonUtils.printStr(proc);


        str = "{\"topic\":\"lmtac_log\",\"dev_ip\":\"192.200.201.25\",\"message\":\"<5>msgtype:1;product:tac;ip:192.200.201.25;hash:7D81-34F7-975C-AAF3;data:{\\\"threat_info\\\": [], \\\"network\\\": [], \\\"session_info\\\": {\\\"sip\\\": \\\"10.0.190.28\\\", \\\"protocol\\\": \\\"\\\", \\\"time\\\": 1651800333, \\\"dport\\\": 25, \\\"sport\\\": 49206, \\\"dip\\\": \\\"111.160.241.210\\\"}, \\\"app_info\\\": {\\\"app_type\\\": \\\"SMTP\\\", \\\"app_detail\\\": \\\"{\\\\\\\"to\\\\\\\": \\\\\\\"\\\\\\\", \\\\\\\"orign\\\\\\\": \\\\\\\"\\\\\\\", \\\\\\\"from\\\\\\\": \\\\\\\"\\\\\\\", \\\\\\\"subject\\\\\\\": \\\\\\\"\\\\\\\"}\\\"}, \\\"summary\\\": {\\\"sha256\\\": \\\"cdbb5307d7ee6d5ab8cf9a6ce9773be55c579a4e90dd8a20feaea0cacbaddea9\\\", \\\"alert_time\\\": 0, \\\"taskid\\\": \\\"7d8134f7975caaf31651800330ab8fd7\\\", \\\"file_size\\\": 1762100, \\\"file_type\\\": \\\"ZIP\\\", \\\"file_name\\\": \\\"5aSn6JCl6ZSA6KGo5Y2VLnppcA==\\\", \\\"threat_level\\\": \\\"medium\\\", \\\"tags\\\": [], \\\"md5\\\": \\\"718f641d6a5ec7dc9810f925c904d64b\\\"}, \\\"static\\\": {\\\"file_structure\\\": {\\\"Zip Compression\\\": \\\"Deflated\\\", \\\"MIME Type\\\": \\\"application/zip\\\", \\\"Zip Bit Flag\\\": \\\"0\\\", \\\"Zip CRC\\\": \\\"0x957b4b62\\\", \\\"Zip Compressed Size\\\": \\\"11385\\\", \\\"Zip Modify Date\\\": \\\"2022:03:29 13:46:19\\\", \\\"File Type\\\": \\\"ZIP\\\", \\\"Zip File Name\\\": \\\"CRV_003_\\\\u9500\\\\u552e\\\\u8303\\\\u56f4\\\\u6307\\\\u5b9a\\\\u5355_V20.xlsx\\\", \\\"Zip Required Version\\\": \\\"20\\\", \\\"Zip Uncompressed Size\\\": \\\"14108\\\"}, \\\"basic_info\\\": {\\\"crc32\\\": 411732883, \\\"sha256\\\": \\\"cdbb5307d7ee6d5ab8cf9a6ce9773be55c579a4e90dd8a20feaea0cacbaddea9\\\", \\\"sha1\\\": \\\"62e2b54b873a83da277592aa4b0952786b643ec5\\\", \\\"md5\\\": \\\"718f641d6a5ec7dc9810f925c904d64b\\\"}}, \\\"dropped\\\": []};\",\"type\":\"udp\",\"timestamp\":\"2022-05-06 09:24:13\"}";
        proc = DataProcessFuncation.parse(str,"index");
        JsonUtils.printStr(proc);
    }

}
