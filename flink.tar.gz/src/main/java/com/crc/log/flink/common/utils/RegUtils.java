package com.crc.log.flink.common.utils;

import java.util.ArrayList;
import java.util.LinkedList;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class RegUtils {
    public static boolean isMatch(String value, String reg) {
        Pattern manMsgPattern = Pattern.compile(reg);
        Matcher manMsgMatcher = manMsgPattern.matcher(value);
        return manMsgMatcher.find();
    }

    public static List<String> getData(String value, String reg) {
        Pattern manMsgPattern = Pattern.compile(reg);
        Matcher manMsgMatcher = manMsgPattern.matcher(value);
        List<String> dataList = new ArrayList<>();
        if (manMsgMatcher.find()) {
            for (int i = 1; i <= manMsgMatcher.groupCount(); i++) {
                dataList.add(manMsgMatcher.group(i));
            }
        }
        return dataList;
    }

    public static String GET_NUM_REG = "\\d+";
    public static String getNumber(String content) {
        if (content == null || "".equals(content)) {
            return "0";
        }
        Pattern pattern = Pattern.compile(GET_NUM_REG);
        Matcher matcher = pattern.matcher(content);
        if (matcher.find()) {
            return matcher.group(0);
        }
        return "0";
    }

    public static String NUM_REG = "[1-9]+[0-9]*";

    public static boolean isNum(String s) {
        if (s == null || "".equals(s)) {
            return false;
        }
        Pattern pattern = Pattern.compile(NUM_REG);
        return pattern.matcher(s).matches();
    }

    public static String DIGITAL_REG = "[0-9]*";

    public static boolean isPureDigital(String str) {
        if (str == null || "".equals(str)) {
            return false;
        }
        Pattern pattern = Pattern.compile(DIGITAL_REG);
        return pattern.matcher(str).matches();
    }

    public static String BRACKET_DATA_REG = "\\{([^\\}]+)";

    public static List<String> getBracketsData(String jsonStr) {
        Pattern p = Pattern.compile(BRACKET_DATA_REG);
        Matcher m = p.matcher(jsonStr);
        List<String> dataList = new LinkedList<>();
        while (m.find()) {
            try {
                String data = m.group().substring(1, m.group().length() - 1);
                dataList.add(data);
            } catch (Exception e) {

            }
        }
        return dataList;
    }

    public static boolean isNumber(String jsonStr) {
        Pattern p = Pattern.compile("\\d+");
        Matcher m = p.matcher(jsonStr);
        return m.matches();
    }

    public static boolean isPort(String jsonStr) {
        if (isNumber(jsonStr)) {
            int i = DataUtils.toNum(jsonStr);
            return i >= 1 && i <= 65535;
        }
        return false;
    }
}
