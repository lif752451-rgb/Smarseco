package com.crc.log.flink.parse;

import com.alibaba.fastjson.JSONObject;
import com.crc.log.flink.common.constants.LogConstants;
import com.crc.log.flink.common.utils.DataUtils;
import com.crc.log.flink.common.utils.JsonUtils;

import java.util.concurrent.ConcurrentHashMap;

/**
 * @author jixiangqi
 * @date 2022/5/9
 * 深信服超融合产品
 */
public class ResolvSFHCISyslog {
    public static ConcurrentHashMap<String, Object> parse(String message) {
        try {
            ConcurrentHashMap<String, Object> data = proc(message);
            if (DataUtils.isNotEmptyJson(data)) {
                return data;
            }
        } catch (Exception ignored) {

        }
        return null;
    }

    private static ConcurrentHashMap<String, Object> proc(String jsonStr) {
        return JsonUtils.createBaseMap(jsonStr);
    }

    private static void getLogLevel(JSONObject rtnObjc, String value) {
        String logLevel = "";
        switch (value) {
            case "0":
                logLevel = "紧急";
                break;
            case "1":
                logLevel = "警报";
                break;
            case "2":
                logLevel = "关键";
                break;
            case "3":
                logLevel = "错误";
                break;
            case "4":
                logLevel = "警告";
                break;
            case "5":
                logLevel = "通知";
                break;
            case "6":
                logLevel = "信息";
                break;
            case "7":
                logLevel = "调试";
                break;
            case "10":
                logLevel = "其他";
                break;
            case "00":
                logLevel = "emergency";
                break;
            case "11":
                logLevel = "alert";
                break;
            case "22":
                logLevel = "critical";
                break;
            case "33":
                logLevel = "error";
                break;
            case "44":
                logLevel = "warning";
                break;
            case "55":
                logLevel = "notice";
                break;
            case "66":
                logLevel = "informational";
                break;
            case "1010":
                logLevel = "other";
                break;
        }
        rtnObjc.put(LogConstants.LOG_LEVEL, logLevel);
    }

    private static void getActionType(JSONObject rtnObjc, String value) {
        String actionType = "";
        switch (value) {
            case "0":
                actionType = "一般行为";
                break;
            case "1":
                actionType = "异常行为";
                break;
            case "2":
                actionType = "违规行为";
                break;
            case "10":
                actionType = "其他";
                break;
        }
        rtnObjc.put(LogConstants.ACTION_TYPE, actionType);
    }

    private static void getModule(JSONObject rtnObjc, String value) {
        String module = "";
        switch (value) {
            case "0":
                module = "虚拟机备份管理";
                break;
            case "1":
                module = "虚拟机管理";
                break;
            case "2":
                module = "虚拟硬盘管理";
                break;
            case "3":
                module = "服务器硬件";
                break;
            case "4":
                module = "网络资源管理";
                break;
            case "5":
                module = "系统管理";
                break;
            case "6":
                module = "软件资源配置";
                break;
            case "7":
                module = "快照管理";
                break;
            case "8":
                module = "角色管理";
                break;
            case "9":
                module = "告警事件";
                break;
            case "10":
                module = "用户管理";
                break;
            case "50":
                module = "其他";
                break;
        }
        rtnObjc.put(LogConstants.MODULE, module);
    }
}
