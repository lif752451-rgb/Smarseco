package com.crc.log.flink.parse;

import com.crc.log.flink.common.constants.LevelConstants;
import com.crc.log.flink.common.constants.LogConstants;
import com.crc.log.flink.common.utils.DataUtils;
import com.crc.log.flink.common.utils.IPUtil;
import com.crc.log.flink.common.utils.JsonUtils;
import com.crc.log.flink.common.utils.MapUtils;
import org.apache.commons.lang3.StringUtils;

import java.util.List;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

/**
 * @author jixiangqi
 * @date 2022/1/18
 */
public class ResolvDongRuanFirewallLog {
    /**
     * IPS 日志泛化
     */
    public static ConcurrentHashMap<String, Object> parse(String message) {
        try {
            ConcurrentHashMap<String, Object> data = proc(message);
            if (DataUtils.isNotEmptyJson(data)) {
                return data;
            }
        } catch (Exception ignored) {

        }
        return null;
    }

    private static ConcurrentHashMap<String, Object> proc(String jsonStr) {
        ConcurrentHashMap<String, Object> rtnObjc = JsonUtils.createBaseMap(jsonStr);
        jsonStr = findSecondSpace(jsonStr);
        int index = DataUtils.getIndex(jsonStr, ":");
                //jsonStr.indexOf(":");
        if (index > 0) {
            String hostName = DataUtils.getSubString(jsonStr,0 ,index);
            rtnObjc.put(LogConstants.HOST_NAME, hostName);
            jsonStr = DataUtils.getSubString(jsonStr,index+1);
            String[] split = DataUtils.getSplit(jsonStr, "\\|");
            if (split.length == 2) {
                String content = split[1].trim();
                rtnObjc.put(LogConstants.LOG_CONTENT, content);
                Map<String, List<String>> resultMap = IPUtil.getIpAndPortFromStr(content);
                List<String> ips = resultMap.get("ip");
                List<String> ports = resultMap.get("port");
                if (ips.size() == 2 && ports.size() == 2) {
                    rtnObjc.put(LogConstants.SRC_IP, ips.get(0));
                    rtnObjc.put(LogConstants.DEST_IP, ips.get(1));
                    rtnObjc.put(LogConstants.SRC_PORT, ports.get(0));
                    rtnObjc.put(LogConstants.DEST_PORT, ports.get(1));
                } else if (ips.size() == 1 && ports.size() == 1) {
                    String[] ip = DataUtils.getSplit(content, ips.get(0));
                    if (ip[0].contains("从") && ip[0].contains("到")) {
                        rtnObjc.put(LogConstants.DEST_IP, ips.get(0));
                        rtnObjc.put(LogConstants.DEST_PORT, ports.get(0));
                    } else {
                        rtnObjc.put(LogConstants.SRC_IP, ips.get(0));
                        rtnObjc.put(LogConstants.SRC_PORT, ports.get(0));
                    }
                } else if (ips.size() == 0) {
                    ips = IPUtil.getIpFromStr(content);
                    if (ips.size() == 2) {
                        rtnObjc.put(LogConstants.SRC_IP, ips.get(0));
                        rtnObjc.put(LogConstants.DEST_IP, ips.get(1));
                    } else if (ips.size() == 1) {
                        String[] ip = DataUtils.getSplit(content, ips.get(0));
                        if (ip[0].contains("从") && ip[0].contains("到")) {
                            rtnObjc.put(LogConstants.DEST_IP, ips.get(0));
                            rtnObjc.put(LogConstants.DEST_PORT, ports.get(0));
                        } else {
                            rtnObjc.put(LogConstants.SRC_IP, ips.get(0));
                            rtnObjc.put(LogConstants.SRC_PORT, ports.get(0));
                        }
                    }
                }
                if (content.contains("协议")) {
                    index = DataUtils.getIndex(content, "协议");
                    String proto = DataUtils.getSubString(content, index+2, index + 3);
                    proto = DataUtils.getSubString(proto, 0, 1);
                    String protoType = "";
                    switch (proto) {
                        case "1":
                            protoType = "ICMP";
                            break;
                        case "2":
                            protoType = "IGMP";
                            break;
                        case "6":
                            protoType = "TCP";
                            break;
                        case "8":
                            protoType = "EGP";
                            break;
                        case "9":
                            protoType = "IGP";
                            break;
                        case "17":
                            protoType = "UDP";
                            break;
                        case "41":
                            protoType = "IPv6";
                            break;
                        case "47":
                            protoType = "GRE";
                            break;
                        case "50":
                            protoType = "ESP";
                            break;
                        case "51":
                            protoType = "AH";
                            break;
                        case "88":
                            protoType = "EIGRP";
                            break;
                        case "89":
                            protoType = "OSPF";
                            break;
                        case "112":
                            protoType = "VRRP";
                            break;
                        case "115":
                            protoType = "L2TP";
                            break;
                    }
                    rtnObjc.put(LogConstants.LOG_PROTOCAL, protoType);
                }
                String[] s = split[0].split(" ");
                for (int i = 0; i < s.length; i++) {
                    String temp = s[i].trim();
                    switch (i){
                        case 0:
                            rtnObjc.put(LogConstants.OP_NAME, temp);
                            break;
                        case 1:
                            if (temp.contains("-")) {
                                String[] value = DataUtils.getSplit(temp, "-");
                                rtnObjc.put(LogConstants.LOG_VERSION, value[0]);
                                rtnObjc.put(LogConstants.EVENT_ID, value[3]);
                            }
                            break;
                        case 2:
                            rtnObjc.put(LogConstants.LOG_LEVEL, LevelConstants.getLevel2(temp));
                            break;
                        case 3:
                            rtnObjc.put(LogConstants.MODULE, temp);
                            break;
                        case 4:
                            rtnObjc.put(LogConstants.USER_NAME, temp);
                            break;
                        case 5:
                            if (temp.contains("=")) {
                                String[] split1 = DataUtils.getSplit(temp, "=");
                                rtnObjc.put(LogConstants.LOG_COUNT, split1[1]);
                            }
                            break;
                    }
                }
            }
        }
        if (StringUtils.isBlank(MapUtils.getStr(rtnObjc, LogConstants.SRC_IP))) {
            rtnObjc.put(LogConstants.SRC_IP, "0.0.0.0");
        }
        if (StringUtils.isBlank(MapUtils.getStr(rtnObjc, LogConstants.DEST_IP))) {
            rtnObjc.put(LogConstants.DEST_IP, "0.0.0.0");
        }
        setAlertName(rtnObjc);
        rtnObjc.put(LogConstants.LOG_PRODUCT, "东软防火墙");
        return rtnObjc;
    }

    private static void setAlertName(ConcurrentHashMap<String, Object> rtnObjc) {
        String srcIp = MapUtils.getStr(rtnObjc, LogConstants.SRC_IP);
        String destIp = MapUtils.getStr(rtnObjc, LogConstants.DEST_IP);
        String count = MapUtils.getStr(rtnObjc, LogConstants.LOG_COUNT);
        String content = MapUtils.getStr(rtnObjc, LogConstants.LOG_CONTENT);
        String log = MapUtils.getStr(rtnObjc, LogConstants.LOG_ORI_MSG);
        String proto = MapUtils.getStr(rtnObjc, LogConstants.LOG_PROTOCAL);
        String level = MapUtils.getStr(rtnObjc, LogConstants.LOG_LEVEL);
        String msgFormat = "IP为:%s的对IP为:%s进行了一个访问协议为:%s的访问，访问次数为:%s,日志级别为:%s,日志内容为:%s,日志详情为:%s";
        String alertName = String.format(msgFormat, srcIp, destIp, proto, count, level, content, log);
        rtnObjc.put(LogConstants.ALERT_NAME, alertName);
    }


    private static String findSecondSpace(String jsonStr) {
        int count = 0;
        int index = 0;
        while (count != 2) {
            index = DataUtils.getIndex(jsonStr, " ");
            if (index != -1) {
                jsonStr = DataUtils.getSubString(jsonStr, index+1).trim();
            }
            count++;
        }
        return jsonStr;
    }
}
