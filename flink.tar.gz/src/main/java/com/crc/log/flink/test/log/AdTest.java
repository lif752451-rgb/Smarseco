package com.crc.log.flink.test.log;

import com.crc.log.flink.common.utils.JsonUtils;
import com.crc.log.flink.parse.ResolvAdLog;
public class AdTest {
    public static void main(String[] args) {
        JsonUtils.printStr(ResolvAdLog.EventIdMap);
    }
}
