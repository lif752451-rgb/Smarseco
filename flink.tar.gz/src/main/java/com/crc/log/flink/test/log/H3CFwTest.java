package com.crc.log.flink.test.log;

import com.crc.log.flink.common.utils.JsonUtils;
import com.crc.log.flink.config.AllConfig;
import com.crc.log.flink.es.DataProcessFuncation;

import java.util.concurrent.ConcurrentHashMap;

public class H3CFwTest
{
    public static void main(String[] args) {
            //UFLT_MATCH_IPV4_LOG
            String msgx = "<190>Nov 26 15:16:52 2021 HRZD-HBDQ-H3C5030-FHQ %%10UFLT/6/UFLT_MATCH_IPV4_LOG: Protocol(1001)=TCP;Application(1002)=BaiduResource;URL(1093)=sgoutong.baidu.com/embed/1637636792/asset/embed/webimlight/main.js;URLCategory(1094)=SearchEngine & Portal;PolicyName(1079)=default;SrcIPAddr(1003)=10.75.123.215;SrcPort(1004)=2056;DstIPAddr(1007)=153.37.235.223;DstPort(1008)=80;SrcZoneName(1025)=Trust;DstZoneName(1035)=Untrust;UserName(1113)=10.75.123.215;Action(1053)=Permit;";
            //FFILTER_IPV4_LOG
            //String msgx ="<190>Nov 26 15:41:58 2021 HRZD-HBDQ-H3C5030-FHQ %%10FFILTER/6/FFILTER_IPV4_LOG: Protocol(1001)=TCP;Application(1002)=HTTP;DataDirection(1081)=upload;RuleName(1080)=default;PolicyName(1079)=default;SrcIPAddr(1003)=192.168.52.194;SrcPort(1004)=64289;DstIPAddr(1007)=36.110.237.19;DstPort(1008)=80;SrcZone(1025)=Trust;DstZone(1035)=Untrust;UserName(1113)=192.168.52.194;Action(1053)=permit;Filetype(1096)=php;";
            //DFILTER_IPV4_LOG
            //String msgx = "Protocol(1001)=TCP;Application(1002)=HTTP;DataDirection(1081)=upload;RuleName(1080)=default;PolicyName(1079)=default;SrcIPAddr(1003)=10.75.7.10;SrcPort(1004)=55967;DstIPAddr(1007)=121.41.210.63;DstPort(1008)=80;SrcZone(1025)=Trust;DstZone(1035)=Untrust;UserName(1113)=10.75.7.10;Action(1053)=permit;";
            AllConfig config = new AllConfig();
            DataProcessFuncation.CONIFG = config;
            config.setMode("single");
            config.setParse("ReslovH3CFW");
            config.setIndex("sec_all");


        ConcurrentHashMap<String, Object> json = DataProcessFuncation.parse(msgx, "index");
            JsonUtils.printStr(json);
    }
}
