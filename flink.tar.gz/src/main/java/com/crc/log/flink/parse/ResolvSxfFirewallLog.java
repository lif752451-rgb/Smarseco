package com.crc.log.flink.parse;

import com.crc.log.flink.common.constants.LevelConstants;
import com.crc.log.flink.common.constants.LogConstants;
import com.crc.log.flink.common.utils.DataUtils;
import com.crc.log.flink.common.utils.JsonUtils;
import com.crc.log.flink.common.utils.MapUtils;
import org.apache.commons.lang3.StringUtils;

import java.util.concurrent.ConcurrentHashMap;

/**
 * 深信服防火墙
 */
public class ResolvSxfFirewallLog {
    public static ConcurrentHashMap<String,Object> parse(String message) {
        try {
            ConcurrentHashMap<String,Object> data = proc(message);
            if (DataUtils.isNotEmptyJson(data)) {
                return data;
            }
        } catch (Exception ignored) {

        }
        return null;
    }

    private static ConcurrentHashMap<String,Object> proc(String jsonStr) {
        ConcurrentHashMap<String,Object> rtnObjc = JsonUtils.createBaseMap(jsonStr);
        int i = stringSubTime(jsonStr);
        if (i > -1) {
            jsonStr = DataUtils.getSubString(jsonStr, i+1);
                    //jsonStr.substring(i+1);
        }
        int index = DataUtils.getIndex(jsonStr, " ");
                //jsonStr.indexOf(" ");
        if (index > -1) {
            String hostName = DataUtils.getSubString(jsonStr, 0, index);
                    //jsonStr.substring(0, index);
            rtnObjc.put(LogConstants.HOST_NAME, hostName);
        }
        String[] split = DataUtils.getSplit(jsonStr, ",");
                //jsonStr.split(",");
        rtnObjc.put(LogConstants.ALERT_NAME, jsonStr);
        for (String temp : split) {
            if (temp.contains("日志类型")) {
                index = DataUtils.getIndex(temp, "日志类型");
                //temp.indexOf("日志类型");
                String type = DataUtils.getSubString(temp, index);
                //temp.substring(index);
                getValueByKey(rtnObjc, type);
            } else {
                getValueByKey(rtnObjc, temp);
            }
        }
        rtnObjc.put(LogConstants.LOG_PRODUCT, "深信服防火墙");
        rtnObjc.put(LogConstants.LOG_LEVEL, LevelConstants.getLevel(MapUtils.getStr(rtnObjc,LogConstants.LOG_LEVEL)));
        if (StringUtils.isBlank(MapUtils.getStr(rtnObjc, LogConstants.SRC_IP))) {
            rtnObjc.put(LogConstants.SRC_IP, "0.0.0.0");
        }
        if (StringUtils.isBlank(MapUtils.getStr(rtnObjc, LogConstants.DEST_IP))) {
            rtnObjc.put(LogConstants.DEST_IP, "0.0.0.0");
        }
        setAlertName(rtnObjc);
        return rtnObjc;
    }

    private static void getValueByKey(ConcurrentHashMap<String,Object> rtnObjc, String str){
        String[] split = DataUtils.getSplit(str, ":");
                //str.split(":");
        for (int i = 0; i < split.length; i++) {
            String key = split[0].trim();
            String value = split.length > 1 ? split[1] : "";
            switch (key) {
                case "策略名称":
                    rtnObjc.put(LogConstants.STRATEGY_ID, value);
                    break;
                case "规则ID":
                    rtnObjc.put(LogConstants.RULE_ID, value);
                    break;
                case "源IP":
                    rtnObjc.put(LogConstants.SRC_IP, value);
                    break;
                case "源端口":
                    rtnObjc.put(LogConstants.SRC_PORT, value);
                    break;
                case "目的IP":
                    rtnObjc.put(LogConstants.DEST_IP, value);
                    break;
                case "目的端口":
                    rtnObjc.put(LogConstants.DEST_PORT, value);
                    break;
                case "攻击类型":
                    rtnObjc.put(LogConstants.BEHAVIOR_TAG, value);
                    break;
                case "严重级别":
                    rtnObjc.put(LogConstants.LOG_LEVEL, value);
                    break;
                case "系统动作":
                    rtnObjc.put(LogConstants.ACTION_RULE, value);
                    break;
                case "URL":
                    rtnObjc.put(LogConstants.LOG_URL, value);
                    break;
                case "协议":
                    rtnObjc.put(LogConstants.LOG_PROTOCAL, value);
                    break;
                case "动作":
                    rtnObjc.put(LogConstants.ACTION, value);
                    break;
                case "攻击方向":
                    rtnObjc.put(LogConstants.ATTACK_DIRECTION, value);
                    break;
                case "漏洞ID":
                    rtnObjc.put(LogConstants.LOOPHOLE_ID, value);
                    break;
                case "漏洞名称":
                    rtnObjc.put(LogConstants.LOOPHOLE_NAME, value);
                    break;
                case "用户":
                    rtnObjc.put(LogConstants.USER_NAME, value);
                    break;
                case "应用名称":
                    rtnObjc.put(LogConstants.LOG_SERV, value);
                    break;
                case "病毒类型":
                    rtnObjc.put(LogConstants.VIRUS_TYPE, value);
                    break;
                case "病毒名":
                    rtnObjc.put(LogConstants.VIRUS_NAME, value);
                    break;
                case "IP地址":
                    rtnObjc.put(LogConstants.SRC_IP, value);
                    break;
                case "操作对象":
                    rtnObjc.put(LogConstants.ACTION_OBJ, value);
                    break;
                case "操作类型":
                    rtnObjc.put(LogConstants.ACTION_TYPE, value);
                    break;
                case "描述":
                    rtnObjc.put(LogConstants.LOG_DESCRIPTION, value);
                    break;
                case "原因描述":
                    rtnObjc.put(LogConstants.LOG_DESCRIPTION, value);
                    break;
                case "注销时间":
                    rtnObjc.put(LogConstants.CANCEL_TIME, value);
                    break;
                case "登录时间":
                    rtnObjc.put(LogConstants.SING_IN_TIME, value);
                    break;
                case "登录时长":
                    rtnObjc.put(LogConstants.SING_IN_DURATION, value);
                    break;
                case "NAT类型":
                    rtnObjc.put(LogConstants.NAT_TYPE, value);
                    break;
                case "转换后的IP":
                    rtnObjc.put(LogConstants.TRANS_IP, value);
                    break;
                case "转换后的端口":
                    rtnObjc.put(LogConstants.TRANS_PORT, value);
                    break;
                case "特征ID":
                    rtnObjc.put(LogConstants.EVENT_ID, value);
                    break;
                case "风险类型":
                    rtnObjc.put(LogConstants.RISK_TYPE, value);
                    break;
                case "时间":
                    rtnObjc.put(LogConstants.LOG_START_TIME, value);
                    break;
                case "用户名/主机":
                    rtnObjc.put(LogConstants.HOST_NAME, value);
                    break;
                case "应用类型":
                    rtnObjc.put(LogConstants.LOG_APP, value);
                    break;
                case "上行流量":
                    rtnObjc.put(LogConstants.UP_FLUX, value);
                    break;
                case "下行流量":
                    rtnObjc.put(LogConstants.DOWN_FLUX, value);
                    break;
                case "总流量":
                    rtnObjc.put(LogConstants.ALL_FLUX, value);
                    break;
                case "网关序列号":
                    rtnObjc.put(LogConstants.SERIAL_NUMBER, value);
                    break;
                case "当前状态":
                    rtnObjc.put(LogConstants.STATUS, value);
                    break;
                case "VRID":
                    rtnObjc.put(LogConstants.VR_ID, value);
                    break;
                case "设备名称":
                    rtnObjc.put(LogConstants.DEVICE_TYPE, value);
                    break;
                case "日志类型":
                    rtnObjc.put(LogConstants.LOG_TYPE, value);
                    break;
            }
        }
    }

    private static int stringSubTime(String jsonStr) {
        int count = 0;
        for (int i = 0; i < jsonStr.length(); i++) {
            char c = jsonStr.charAt(i);
            if (c == ':') {
                count++;
                if (count == 2) {
                    count = i + 3;
                    break;
                }
            }
        }
        return count;
    }

    private static void setAlertName(ConcurrentHashMap<String,Object> rtnObjc) {
        String msgFormat = "";
        String level = MapUtils.getStr(rtnObjc, LogConstants.LOG_LEVEL);
        String srcIp = MapUtils.getStr(rtnObjc, LogConstants.SRC_IP);
        String destIp = MapUtils.getStr(rtnObjc, LogConstants.DEST_IP);
        String event = MapUtils.getStr(rtnObjc, LogConstants.LOG_TYPE);
        String log = MapUtils.getStr(rtnObjc, LogConstants.LOG_ORI_MSG);
        String alertName = "";
        if (destIp.equals("0.0.0.0")) {
            String obj = MapUtils.getStr(rtnObjc, LogConstants.ACTION_OBJ);
            msgFormat = "用户在IP为:%s上进行了:%s操作,日志类型为:%s,日志详情为:%s";
            alertName = String.format(msgFormat, srcIp, obj, event, log);
        } else {
            String result = MapUtils.getStr(rtnObjc, LogConstants.ACTION_RULE);
            msgFormat = "IP为:%s对IP为:%s进行了一个:%s的操作,操作结果为:%s,事件等级为:%s,日志详情为:%s";
            alertName = String.format(msgFormat, srcIp, destIp, event,  result, level, log);
        }
        rtnObjc.put(LogConstants.ALERT_NAME, alertName);
    }
}
