package com.crc.log.flink.test.log;

import com.crc.log.flink.common.utils.JsonUtils;
import com.crc.log.flink.config.AllConfig;
import com.crc.log.flink.es.DataProcessFuncation;

import java.util.concurrent.ConcurrentHashMap;

/**
 * @author jixiangqi
 * @date 2021/12/8
 */
public class ResolvQmxcAdsLogTest {

    public static void main(String[] args) {
        AllConfig config = new AllConfig();
        DataProcessFuncation.CONIFG = config;
        config.setMode("single");
        config.setParse("ResolvQmxcAdsLog");
        config.setIndex("sec_all");


        String str = "<191>2021-12-08T11:42:51+08:00 DDoS-Firewall XX.XX.XX.XX_514tagintercept_log[2645]: {\"Domain_name\":\"电信\",\"dst_ip\":\"1.1.1.1\",\"dst_port\":\"443\",\"src_ip\":\"2.2.2.2\",\"src_port\":\"23580\",\"timestamp\":\"2021-12-08 11:42:08\"," +
                "\"defend_type\":\"LOG_ACK\",\"code\":\"-2165\",\"country_cn_name\":\"中国\",\"country_en_name\":\"China\"}";
        ConcurrentHashMap<String, Object> proc = DataProcessFuncation.parse(str,"index");
        JsonUtils.printStr(proc);

        str = "<191>2021-12-08T11:41:46+08:00 DDoS-Firewall XX.XX.XX.XX_514tagattack_event[2645]:{\"Domain\":\"移动\",\"src_ip\":\"3.3.3.3\",\"dst_ip\":\"4.4.4.4\",\"attack_type\":\"ACK\",\"start_time\":\"2021-12-08 11:39:07\",\"end_time\":\"2021-12-08 11:40:06\",\"in_total_mbps\":\"109542\",\"in_total_pps\":\"507\",\"attack_total_mbps\":\"0\",\"attack_total_pps\":\"0\",\"out_total_mbps\":109542,\"out_total_pps\":507,\"max_attack_mbps\":\"0\",\"max_attack_pps\":\"0\",\"attack_state\":\"攻击结束\"}";
        proc = DataProcessFuncation.parse(str,"index");
        JsonUtils.printStr(proc);

        str = "<191>2021-12-08T11:41:46+08:00 DDoS-Firewall XX.XX.XX.XX_514tagattack_event[2645]:{\"Domain\":\"移动\",\"src_ip\":\"6.6.6.6\",\n" +
                "\t\"dst_ip\":\"5.5.5.5\",\n" +
                "\t\"attack_type\":\"ACK\",\"start_time\":\"2021-12-08 11:37:11\",\"end_time\":\"2021-12-08 11:38:10\",\n" +
                "\t\"in_total_mbps\":\"1684924\",\n" +
                "\t\"in_total_pps\":\"3460\",\n" +
                "\t\"attack_total_mbps\":\"0\",\n" +
                "\t\"attack_total_pps\":\"0\",\"out_total_mbps\":1684924,\n" +
                "\t\"out_total_pps\":3460,\"max_attack_mbps\":\"0\",\"max_attack_pps\":\"0\",\"attack_state\":\"攻击结束\"}";
        proc = DataProcessFuncation.parse(str,"index");
        JsonUtils.printStr(proc);

        str = "<191>2021-12-08T11:32:21+08:00 DDoS-Firewall XX.XX.XX.XX_514tagintercept_log[2645]:{\"Domain_name\":\"联通\",\n" +
                "\"dst_ip\":\"7.7.7.7\",\n" +
                "\"dst_port\":\"443\",\n" +
                "\"src_ip\":\"8.8.8.8\",\n" +
                "\"src_port\":\n" +
                "\"33100\",\"timestamp\":\"2021-12-08 11:31:29\",\"defend_type\":\"LOG_ACK\",\"code\":\"-2165\",\"country_cn_name\":\"中国\",\"country_en_name\":\"China\"}";
        proc = DataProcessFuncation.parse(str,"index");
        JsonUtils.printStr(proc);

    }

}
