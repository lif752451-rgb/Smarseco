package com.crc.log.flink.test;

import com.crc.log.flink.common.utils.JsonUtils;
import com.crc.log.flink.config.AllConfig;
import com.crc.log.flink.es.DataProcessFuncation;

import java.util.concurrent.ConcurrentHashMap;

public class LinuxTest
{
    public static void main(String[] args) {
        String msgx = "<30>Nov  3 10:22:21 vm-48-55-centos systemd: Started libcontainer container e576c8fa2cff31c01c0db7169a210ae3c02eb084b4e1b36779953edc45e19a2c.";
        AllConfig config = new AllConfig();
        DataProcessFuncation.CONIFG = config;
        config.setMode("single");
        config.setParse("ResolvLinuxSyslog");
        config.setIndex("sec_all");

        ConcurrentHashMap<String, Object> json = DataProcessFuncation.parse(msgx,"index");
        JsonUtils.printStr(json);
    }
}
