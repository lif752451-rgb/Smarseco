package com.crc.log.flink.test.log;

import com.crc.log.flink.common.utils.JsonUtils;
import com.crc.log.flink.config.AllConfig;
import com.crc.log.flink.es.DataProcessFuncation;

import java.text.ParseException;
import java.util.concurrent.ConcurrentHashMap;

/**
 * @author jixiangqi
 * @date 2022/1/5
 */
public class ResolvQimingSqlLogTest {

    public static void main(String[] args) throws ParseException {
        AllConfig config = new AllConfig();
        DataProcessFuncation.CONIFG = config;
        config.setMode("single");
        config.setParse("ResolvQimingSqlLog");
        config.setIndex("net_all");

        String str  = "<962>JAN  2 10:55:14 引擎服务器 ORACLE: devsn=0614271811169999 gen_time=2022-01-02 10:55:14 id=5359794915679144592 session_id=5359794915645591744 transport_protocol=tcp app_protocol=ORACLE level=high dev_ip=10.0.34.74 server_ip=10.0.8.86 client_ip=10.0.14.45 server_port=1526 redirect_port=1526 client_port=53262 server_mac=00-50-56-A9-1C-0D client_mac=48-7A-DA-8F-B9-4C ruleset_name=高风险命令 rule_name=TABLE命令 bizaccout=jep auth_account= policy_id=91 rule_id=10499 rule_templet_id=36075 direction=response response_time=402311 error_code=0 block=no record_rows=0 sql=alter table tnnt_fin_bill_lines modify description varchar2(2000) client_host=JTSECVPWA16 server_host=10.0.8.88 library=ODBC client_software=plsqldev.exe client_user=HANDE-042 instance_name= db_name=MIXCRMDB table_name=tnnt_fin_bill_lines object_name= cmd=102 subcmd=modify colum";
        ConcurrentHashMap<String, Object> json = DataProcessFuncation.parse(str,"index");
        JsonUtils.printStr(json);

        str = "<850>JAN 18 10:52:07 引擎服务器 MYSQL: devsn=0614271811169999 gen_time=2022-01-18 10:52:07 id=5359818105365202256 session_id=5359818105281317216 transport_protocol=tcp app_protocol=MYSQL level=high dev_ip=10.0.34.74 server_ip=10.0.8.125 client_ip=10.0.8.126 server_port=3307 redirect_port=3307 client_port=46740 server_mac=00-50-56-A9-63-9D client_mac=00-50-56-A9-79-81 ruleset_name=DDL:数据定义语言 rule_name=TABLE命令 bizaccout= auth_account= policy_id=170 rule_id=10668 rule_templet_id=48075 direction=response response_time=3908 error_code=0 block=no record_rows=0 sql=drop table t03 client_host= server_host= library= client_software= client_user= instance_name= db_name= table_name=t03 object_name= cmd=103 subcmd=";
        json = DataProcessFuncation.parse(str,"index");
        JsonUtils.printStr(json);
    }
}
