package com.crc.log.flink.test.log;

import com.crc.log.flink.common.utils.JsonUtils;
import com.crc.log.flink.config.AllConfig;
import com.crc.log.flink.es.DataProcessFuncation;

import java.util.concurrent.ConcurrentHashMap;

public class ResolvHostProtectiveSyslogTest {

    public static void main(String[] args) {
        AllConfig config = new AllConfig();
        DataProcessFuncation.CONIFG = config;
        config.setMode("single");
        config.setParse("ResolvHostProtectiveSyslog");
        config.setIndex("sec_all");

        String str = "2019-08-09T20:57:18+08:00 WIN-4UHJRGSO225 skylar_log[8892]: {\"log_name\":\"whitelist_alarm\",\"create_time\":\"2019-08-09 20:57:18\",\"ip\":\"172.24.50.87\",\"report_ip\":\"10.95.162.183\",\"mac\":\"0050568e96d6\",\"gid\":\"1\",\"content\":{\"begin_time\":\"2018-05-03 13:05:52\",\"client_ip\":\"172.24.50.87\",\"client_name\":\"WIN-4UHJRGSOPFK\",\"count\":\"1\",\"end_time\":\"2018-05-03 13:15:01\",\"event_time\":\"2019-08-09 20:57:18\",\"gid\":1,\"mid\":\"a776b531dc304db9a2ea2024ed5e50d2\",\"parent_process_path\":\"C:\\\\Windows\\\\explorer.exe\",\"policy_mode\":\"2\",\"process_cmdline\":\"C:\\\\Users\\\\Administrator\\\\Desktop\\\\新建文本文档.bat\",\"process_company\":\"\",\"process_file_version\":\"\",\"process_md5\":\"\",\"process_name\":\"新建文本文档.bat\",\"process_path\":\"C:\\\\Users\\\\Administrator\\\\Desktop\\\\新建文本文档.bat\",\"process_product_name\":\"\",\"process_sha1\":\"\",\"process_user\":\"Administrator\"}}";
        ConcurrentHashMap<String, Object> proc = DataProcessFuncation.parse(str, "index");
        JsonUtils.printStr(proc);
    }

}
