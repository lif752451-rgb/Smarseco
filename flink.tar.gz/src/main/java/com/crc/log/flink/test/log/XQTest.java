package com.crc.log.flink.test.log;

import com.crc.log.flink.common.utils.JsonUtils;
import com.crc.log.flink.config.AllConfig;
import com.crc.log.flink.es.DataProcessFuncation;

import java.util.concurrent.ConcurrentHashMap;

public class XQTest {
    public static void main(String[] args) {
        String msg = "{\"src_ip\":\"10.0.34.245\",\"source_platform\":\"集团一级态势感知平台-192.200.201.208\",\"import_time\":\"2022-08-20 00:28:17\",\"_id\":\"2LjutoIB9rGHu_sK9Vf3\",\"id\":\"4896547\",\"behavior\":\"other_critical_vulns\",\"url\":\"10.0.34.5/weaver/bsh.servlet.BshServlet\",\"dst_ip\":\"10.7.34.2\",\"unique_count_of_dst\":\"\",\"account\":\"\",\"crc_attr\":\"xiaqiang\"}";
        //a(msg);
        String xx = "{\"src_ip\":\"10.112.244.203\",\"source_platform\":\"集团一级态势感知平台-192.200.201.208\",\"import_time\":\"2021-04-19 16:42:23\",\"id\":\"122883\",\"behavior\":\"leak_password\",\"dst_ip\":\"10.0.62.25\",\"unique_count_of_dst\":\"\",\"crc_attr\":\"xiaqiang\"}";
        //a(xx);
        a("{\"import_time\":\"2021-10-13 10:06:24\",\"dst_ip\":\"47.102.225.103\",\"url\":\"vip.71688.cn/api/UserLogin?username=13912285966&password=123456&memusername=1&Callback=jQuery172009412877299087485_1634090543696&v=0.7999605705863586&_=1634090545525\",\"crc_attr\":\"xiaqiang\",\"src_ip\":\"10.153.1.60\",\"source_platform\":\"华润医商二级态势感知平台-192.200.201.212\",\"id\":\"3998962\",\"behavior\":\"leak_password\",\"unique_count_of_dst\":\"\",\"account\":\"username:13912285966;password:123456\"}");
        a("{\"dev_ip\":\"\",\"message\":\"{\\\"import_time\\\":\\\"2021-10-13 10:16:15\\\",\\\"dst_ip\\\":\\\"192.100.2.197\\\",\\\"url\\\":\\\"192.100.2.197/prod-api/login\\\",\\\"crc_attr\\\":\\\"xiaqiang\\\",\\\"src_ip\\\":\\\"10.137.9.80\\\",\\\"source_platform\\\":\\\"华润医商二级态势感知平台-192.200.201.212\\\",\\\"id\\\":\\\"3999115\\\",\\\"behavior\\\":\\\"leak_password\\\",\\\"unique_count_of_dst\\\":\\\"\\\",\\\"account\\\":\\\"username:21141979;password:123456\\\"}\",\"type\":\"udp\",\"timestamp\":\"2021-10-13 10:16:15\"}");
        a("{\"src_ip\":\"192.171.50.6\",\"source_platform\":\"华润健康二级态势感知平台-192.200.201.211\",\"last_8_dst_ip\":\"192.169.141.241, 192.169.141.241, 192.169.141.241, 192.169.141.241, 192.169.141.241, 192.169.141.241, 192.169.141.241, 192.169.141.241\",\"import_time\":\"2021-10-13 10:29:59\",\"unique_count_of_dst_ip\":\"254\",\"id\":\"3999376\",\"behavior\":\"scan_80_443_445\",\"unique_count_of_dst\":\"\",\"crc_attr\":\"xiaqiang\"}");
        a("{\"topic\":\"sec_all_xq\",\"dev_ip\":\"10.8.8.63\",\"message\":\"{\\\"src_ip\\\":\\\"172.16.2.247\\\",\\\"last_8_dst_ip\\\":\\\"10.148.140.101, 10.148.140.99, 10.148.143.13, 172.16.1.246, 172.16.10.46, 172.16.10.45, 10.148.140.100, 10.148.143.12\\\",\\\"import_time\\\":\\\"2021-10-13 19:25:58\\\",\\\"id\\\":\\\"4005609\\\",\\\"unique_count_of_dst_ip\\\":\\\"9\\\",\\\"behavior\\\":\\\"scan_3306\\\",\\\"unique_count_of_dst\\\":\\\"\\\",\\\"crc_attr\\\":\\\"xiaqiang\\\"}\",\"type\":\"udp\",\"timestamp\":\"2021-10-13 19:26:00\"}");
        a("{\"item_hash\":\"-5563408532410070281\",\"alert_time\":\"2021-10-18T12:45:10.000Z\",\"is_submitted\":\"0\",\"last_8_dst_port\":\"3389, 22, 1900, 8000, 21, 9999, 8008, 8888\",\"import_time\":\"2021-10-18T12:45:10.000Z\",\"is_duplicate\":\"0\",\"dst_ip\":\"120.202.28.108\",\"dev_id\":\"F511AE72\",\"src_ip\":\"106.75.212.104\",\"source_platform\":\"华润医商二级态势感知平台-192.200.201.212\",\"id\":\"4090127\",\"behavior\":\"scan_nmap_port\",\"unique_count_of_dst_port\":\"22\",\"is_alerted\":\"1\"}\n");
    }

    public static void a(String msg) {
        AllConfig config = new AllConfig();
        DataProcessFuncation.CONIFG = config;
        config.setMode("single");
        config.setParse("ResolvSSPXiaQiangLog");
        config.setIndex("sec_all");
        ConcurrentHashMap<String, Object> x = DataProcessFuncation.parse(msg, "sec_all");
        JsonUtils.printStr(x);
    }
}
