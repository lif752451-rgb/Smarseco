package com.crc.log.flink.parse;

import com.crc.log.flink.common.constants.LevelConstants;
import com.crc.log.flink.common.constants.LogConstants;
import com.crc.log.flink.common.utils.*;
import org.apache.commons.lang3.StringUtils;

import java.util.List;
import java.util.concurrent.ConcurrentHashMap;

/**
 * @author jixiangqi
 * @date 2022/5/9
 * 安恒WAF
 */
public class ResolvAnWafAPTLog {
    public static ConcurrentHashMap<String, Object> parse(String message) {
        try {
            ConcurrentHashMap<String, Object> data = proc(message);
            if (DataUtils.isNotEmptyJson(data)) {
                return data;
            }
        } catch (Exception ignored) {

        }
        return null;
    }

    private static ConcurrentHashMap<String, Object> proc(String jsonStr) {
        ConcurrentHashMap<String, Object> rtnObjc = JsonUtils.createBaseMap(jsonStr);
        if (jsonStr.contains("DBAppWAF")) {
            String[] split = DataUtils.getSplit(jsonStr, ",");
            for (String tempStr : split) {
                int index = DataUtils.getIndex(tempStr, "/");
                String key = DataUtils.getSubString(tempStr, 0, index).trim();
                String value = DataUtils.getSubString(tempStr, index + 1);
                switchKeyValue(rtnObjc, key, value);
            }
        } else {
            List<String> ips = IPUtil.getIps(jsonStr);
            if (ips.size() == 2) {
                rtnObjc.put(LogConstants.SRC_IP, ips.get(0));
                rtnObjc.put(LogConstants.DEST_IP, ips.get(1));
            } else if (ips.size() == 1) {
                rtnObjc.put(LogConstants.SRC_IP, ips.get(0));
            }
        }
        if (StringUtils.isBlank(MapUtils.getStr(rtnObjc, LogConstants.SRC_IP))) {
            rtnObjc.put(LogConstants.SRC_IP, "0.0.0.0");
        }
        if (StringUtils.isBlank(MapUtils.getStr(rtnObjc, LogConstants.DEST_IP))) {
            rtnObjc.put(LogConstants.DEST_IP, "0.0.0.0");
        }
        if (StringUtils.isBlank(MapUtils.getStr(rtnObjc, LogConstants.LOG_LEVEL))) {
            rtnObjc.put(LogConstants.LOG_LEVEL, LevelConstants.getLevel(MapUtils.getStr(rtnObjc,LogConstants.LOG_LEVEL)));
        }
        rtnObjc.put(LogConstants.LOG_PRODUCT, "安恒WAF");
        setAlertName(rtnObjc, jsonStr);
        return rtnObjc;
    }

    private static void switchKeyValue(ConcurrentHashMap<String, Object> rtnObjc, String key, String value) {
        switch (key) {
            case "happentime":
                rtnObjc.put(LogConstants.LOG_START_TIME, DateUtils.getISO8601Timestamp(value.trim(), "yyyy-MM-dd HH:mm:ss"));
                break;
            case "msg_id":
                if (!RegUtils.isNumber(value)) {
                    rtnObjc.put(LogConstants.LOG_NAME, value);
                }
                break;
            case "severity_id":
                String logLevel = "";
                switch (value) {
                    case "1":
                        logLevel = "严重";
                        break;
                    case "2":
                        logLevel = "高";
                        break;
                    case "3":
                        logLevel = "中";
                        break;
                    case "4":
                        logLevel = "低";
                        break;
                    case "5":
                        logLevel = "信息";
                        break;
                }
                rtnObjc.put(LogConstants.LOG_LEVEL, logLevel);
                break;
            case "url":
                rtnObjc.put(LogConstants.LOG_URL, value);
                break;
            case "dip":
                rtnObjc.put(LogConstants.DEST_IP, value);
                break;
            case "hostname":
                rtnObjc.put(LogConstants.HOST_NAME, value);
                break;
            case "dport":
                rtnObjc.put(LogConstants.DEST_PORT, value);
                break;
            case "sip":
                rtnObjc.put(LogConstants.SRC_IP, value);
                break;
            case "sport":
                rtnObjc.put(LogConstants.SRC_PORT, value);
                break;
            case "user_agent":
                rtnObjc.put(LogConstants.OS_INFO, value);
                break;
            case "action_id":
                String actionResult = "";
                switch (value) {
                    case "1":
                        actionResult = "阻断";
                        break;
                    case "2":
                        actionResult = "告警";
                        break;
                    case "3":
                        actionResult = "放行";
                        break;
                }
                rtnObjc.put(LogConstants.ACTION_RESULT, actionResult);
                break;
            case "rule_id":
                rtnObjc.put(LogConstants.RULE_ID, value);
                break;
        }
    }

    private static void setAlertName(ConcurrentHashMap<String, Object> rtnObjc, String jsonStr) {
        String message = "";
        String alertName = "";
        String log = MapUtils.getStr(rtnObjc, LogConstants.LOG_ORI_MSG);
        if (jsonStr.contains("DBAppWAF")) {
            String srcIp = MapUtils.getStr(rtnObjc, LogConstants.SRC_IP);
            String destIp = MapUtils.getStr(rtnObjc, LogConstants.DEST_IP);
            String logLevel = MapUtils.getStr(rtnObjc, LogConstants.LOG_LEVEL);
            String actionResult = MapUtils.getStr(rtnObjc, LogConstants.ACTION_RESULT);
            String logName = MapUtils.getStr(rtnObjc, LogConstants.LOG_NAME);
            String logUrl = MapUtils.getStr(rtnObjc, LogConstants.LOG_URL);

            message = "IP地址为:%s对IP地址为:%s进行了告警攻击,攻击级别为:%s,攻击名称为:%s,攻击路径为:%s,攻击结果为:%s,日志详情为:%s";
            alertName = String.format(message, srcIp, destIp, logLevel, logName, logUrl, actionResult, log);
        } else {
            alertName = log;
        }
        rtnObjc.put(LogConstants.ALERT_NAME, alertName);
    }

}
