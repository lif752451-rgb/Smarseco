package com.crc.log.flink.common.constants;

import org.apache.commons.lang3.StringUtils;

import java.util.HashMap;

public class CtWafConstants {
    public static HashMap<String,String> eventTypeMap =  new HashMap<>();
    static {
        eventTypeMap.put("none","非Web攻击");
        eventTypeMap.put("sql_injection","SQL注入");
        eventTypeMap.put("xss","XSS");
        eventTypeMap.put("csrf","CSRF");
        eventTypeMap.put("ssrf","SSRF");
        eventTypeMap.put("dos","拒绝服务");
        eventTypeMap.put("backdoor","后门");
        eventTypeMap.put("deserialization","反序列化");
        eventTypeMap.put("code_execution","代码执行");
        eventTypeMap.put("code_injection","代码注入");
        eventTypeMap.put("command_injection","命令注入");
        eventTypeMap.put("file_upload","文件上传");
        eventTypeMap.put("file_inclusion","文件包含");
        eventTypeMap.put("redirect","重定向");
        eventTypeMap.put("weak_permission","权限不当");
        eventTypeMap.put("info_leak","信息泄露");
        eventTypeMap.put("unauthorized_access","未授权访问");
        eventTypeMap.put("unsafe_config","不安全的配置");
        eventTypeMap.put("xxe","XXE");
        eventTypeMap.put("xpath_injection","Xpath注入");
        eventTypeMap.put("ldap_injection","LDAP注入");
        eventTypeMap.put("directory_traversal","目录穿越");
        eventTypeMap.put("scanner","扫描器");
        eventTypeMap.put("permission_bypass","水平权限绕过");
        eventTypeMap.put("acl_bypass","垂直权限绕过");
        eventTypeMap.put("file_write","文件修改");
        eventTypeMap.put("file_download","文件读取");
        eventTypeMap.put("file_deletion","文件删除");
        eventTypeMap.put("logic_error","逻辑错误");
        eventTypeMap.put("crlf_injection","CRLF注入");
        eventTypeMap.put("ssti","模板注入");
        eventTypeMap.put("click_hijacking","点击劫持");
        eventTypeMap.put("buffer_overflow","缓冲区溢出");
        eventTypeMap.put("integer_overflow","整数溢出");
        eventTypeMap.put("format_string","格式化字符串");
        eventTypeMap.put("race_condition","条件竞争");
        eventTypeMap.put("timeout","超时");
        eventTypeMap.put("unknown","未知");
        eventTypeMap.put("m_rule","情报模块");
        eventTypeMap.put("m_sqli","SQL注入检测模块");
        eventTypeMap.put("m_xss","XSS检测模块");
        eventTypeMap.put("m_csrf","CSRF检测模块");
        eventTypeMap.put("m_ssrf","SSRF检测模块");
        eventTypeMap.put("m_php_unserialize","PHP反序列化检测模块");
        eventTypeMap.put("m_java_unserialize","Java反序列化检测模块");
        eventTypeMap.put("m_file_upload","文件上传攻击检测模块");
        eventTypeMap.put("m_file_include","文件包含攻击检测模块");
        eventTypeMap.put("m_php_code_injection","PHP代码注入检测模块");
        eventTypeMap.put("m_java","Java代码注入检测模块");
        eventTypeMap.put("m_cmd_injection","命令注入检测模块");
        eventTypeMap.put("m_response","服务器响应检测模块");
        eventTypeMap.put("m_scanner","机器人检测模块");
        eventTypeMap.put("m_timeout","检测超时");
        eventTypeMap.put("m_asp_code_injection","ASP代码注入检测模块");
    }

    public static  String getEventType(String type){
        String ret = eventTypeMap.get(type);
        if(StringUtils.isBlank(ret))
            return type;
        return ret;
    }

}
