package com.crc.log.flink.test;

import org.jasypt.encryption.pbe.PooledPBEStringEncryptor;
import org.jasypt.encryption.pbe.config.SimpleStringPBEConfig;

/**
* @author shuzhuo
* @date 2019/1/9 9:56
*/
public class JasyptUtil {

	/**
	 * Jasypt生成加密结果
 	* @param password 配置文件中设定的加密密
 	* @param value 加密值
 	* @return
 	*/
	public static String encyptPwd(String password,String value){
    	PooledPBEStringEncryptor encryptor = new PooledPBEStringEncryptor();
    	encryptor.setConfig(cryptor(password));
		return encryptor.encrypt(value);
	}

	/**
 	* 解密
 	* @param password 配置文件中设定的加密密码
 	* @param value 解密密文
 	* @return
 	*/
	public static String decyptPwd(String password,String value){
    	PooledPBEStringEncryptor encryptor = new PooledPBEStringEncryptor();
    	encryptor.setConfig(cryptor(password));
		return encryptor.decrypt(value);
	}

	public static SimpleStringPBEConfig cryptor(String password){
    	SimpleStringPBEConfig config = new SimpleStringPBEConfig();
    	config.setPassword(password);
    	config.setAlgorithm("PBEWithMD5AndDES");
    	config.setKeyObtentionIterations("1000");
    	config.setPoolSize("1");
    	config.setProviderName("SunJCE");
    	config.setSaltGeneratorClassName("org.jasypt.salt.RandomSaltGenerator");
    	config.setStringOutputType("base64");
    	return config;
	}

	public static void main(String[] args){
    	//加密
    	System.out.println(encyptPwd("IpTFX6FjYs5zKDG8gjKFh7kTgCFdWWJE","7iqtp6VYIIPsd68jhCCq"));
    	//解密
    	System.out.println(decyptPwd("IpTFX6FjYs5zKDG8gjKFh7kTgCFdWWJE","mFpQvAIBWAAHuDildXbM4oaocYx/nrtUxIn1gof/Q665qbelPlob6A=="));
	}
}
