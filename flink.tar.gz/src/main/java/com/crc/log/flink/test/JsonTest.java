package com.crc.log.flink.test;

import com.alibaba.fastjson.JSONObject;
import com.crc.log.flink.parse.ResolvHoneyLog;

public class JsonTest {
    public static void main(String[] args) {
        String msgx = "<173>Jun 11 14:04:31 sslvpn SVPN-USR[16637]: {\"id\":\"5837368603\",\"msgid\":\"100535798\",\"userInfo\":{\"userName\":\"LIJINFENG53\",\"groupId\":127,\"groupPath\":\"/华润集团_GROUP\",\"authMethods\":\"\"},\"clientInfo\":{\"ip\":\"111.31.49.195\",\"vip\":\"2.0.1.224\",\"osType\":\"WINDOWS\",\"macAddr\":\"\",\"deviceID\":\"3E697C81\"},\"msg\":\"[accessIP: 111.31.49.195 virtualIP: 2.0.1.224] User LIJINFENG53 for session 2cc24df7501f481c visit ip source ->ip 10.8.88.8 port 443!\",\"timeStamp\":1623391471,\"time\":\"2021-06-11 14:04:31\",\"type\":\"userlog\",\"logSubType\":\"access_resource\",\"rcip\":\"10.8.88.8\",\"actionResult\":\"success\"}";
        JSONObject json = ResolvHoneyLog.getMsgContent(msgx);
        System.out.println(escape(json.toJSONString()));
    }

    public static String escape(String s) {
        StringBuilder sb = new StringBuilder();
        for (int i = 0; i < s.length(); i++) {
            char c = s.charAt(i);
            // These characters are part of the query syntax and must be escaped
            if (c == '\\' || c == '+' || c == '-' || c == '!' || c == '(' || c == ')' || c == ':'
                    || c == '^' || c == '[' || c == ']' || c == '\"' || c == '~'
                    || c == '*' || c == '?' || c == '|' || c == '&' || c == '/') {
                sb.append('\\');
            }
            sb.append(c);
        }
        return sb.toString();
    }

}
