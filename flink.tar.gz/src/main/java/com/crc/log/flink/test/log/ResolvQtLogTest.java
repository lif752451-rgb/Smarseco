package com.crc.log.flink.test.log;

import com.crc.log.flink.common.utils.JsonUtils;
import com.crc.log.flink.config.AllConfig;
import com.crc.log.flink.es.DataProcessFuncation;

import java.text.ParseException;
import java.util.concurrent.ConcurrentHashMap;

/**
 * @author jixiangqi
 * @date 2022/5/10
 */
public class ResolvQtLogTest {

    public static void main(String[] args) throws ParseException {
        AllConfig config = new AllConfig();
        DataProcessFuncation.CONIFG = config;
        config.setMode("single");
        config.setParse("ResolvQtFcLog");
        config.setIndex("net_all");

        String msgx = "Dec 11 20:58:23 v3201 qtAlert[185] datatype=\"excep_login\" datatime=\"1544533101\" agent_ip=\"192.168.202.131\" host_name=\"localhost.localdomain\" internal_ip=\"192.168.202.131\" external_ip=\"\" host_tag=\"137标签\\,133标签\" host_memo=\"137备注 133备注\" group_name=\"武汉青藤/java组/业务线01\" action=\"add\" type=\"monitor\" group=\"13\" agent_id=\"0dcb44742637f821\" comid=\"56f3f9cf9bda255dce24\" event_type=\"excep_login\" event_name=\"异常登录\" event_level=\"alert\" event_content=\"主机192.168.202.1在2018-12-11 20:58:21成功登录主机192.168.202.131，登录账号为root，该来源属于非常用IP段的异常情况\" url=\"http://172.16.6.141/v3/#/app/loginabnormal/list?search=%7B%22ip%22:%22192.168.202.131%22%7D\" detail.uname=\"root\" detail.login_time=\"2018-12-11 20:58:21\" detail.src_ip=\"192.168.202.1\" detail.region=\"局域网\" detail.reason=\"非常用IP段\"";
        ConcurrentHashMap<String, Object> json = DataProcessFuncation.parse(msgx,"index");
        JsonUtils.printStr(json);

        msgx = "May 20 11:08:37 stalone-docker-pd.qingteng.cn qtAlert[369] datatype=\"ctn_proc_create\" datatime=\"1589944112\" agent_ip=\"192.168.148.129\" host_name=\"master\" internal_ip=\"192.168.148.134\\,fe80::20c:29ff:fe5d:464c\\,192.168.148.129\\,fe80::20c:29ff:fe5d:464c\" external_ip=\"\" host_tag=\"\" host_memo=\"\" group_name=\"未分组主机(linux)\" action=\"add\" type=\"monitor\" group=\"1\" agent_id=\"5eb233fc2f8c5b6a\" comid=\"3e1d949e58d2ebd8fbe2\" pname=\"ip\" pid=\"45056\" uname=\"root\" uid=\"0\" cmd=\"ip link show dev docker0\" path=\"/bin/ip\" ppname=\"calico-node\" md5=\"73fe330d767ba5145125260ecd378177\" ppid=\"46\" ppuname=\"root\" ppuid=\"0\" pppath=\"/bin/calico-node\" euname=\"root\" euid=\"0\" gname=\"root\" host_path=\"/var/lib/docker/overlay2/49dbf140f19e09e33528596db3ad3c008a17214fc826d6bf2a8b461126d4fdb0/merged/bin/ip\" host_pid=\"45056\" host_pppath=\"/var/lib/docker/overlay2/49dbf140f19e09e33528596db3ad3c008a17214fc826d6bf2a8b461126d4fdb0/merged/bin/calico-node\" container_id=\"d627defa5a7f63f67416831896607d5493573a798fa5b66bccb148db57b568fe\" container_name=\"k8s_calico-node_calico-node-2s9hh_kube-system_dc73fa35-54c9-4a6b-8974-35f156f7fd18_1\"";
        json = DataProcessFuncation.parse(msgx,"index");
        JsonUtils.printStr(json);
    }

}
