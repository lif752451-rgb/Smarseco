package com.crc.log.flink.net;

import com.crc.log.flink.common.entity.TbSegementInfo;

public class IPBean {
    long begin;
    long end;
    TbSegementInfo segementInfo;
    String label;

    public String getLabel() {
        return label;
    }

    public void setLabel(String label) {
        this.label = label;
    }

    public IPBean(long s, long e, TbSegementInfo segementInfo) {
        this.begin = s;
        this.end = e;
        this.segementInfo = segementInfo;
    }

    public IPBean(long s, long e, String label) {
        this.begin = s;
        this.end = e;
        this.label = label;
    }

    public long getBegin() {
        return begin;
    }

    public void setBegin(long begin) {
        this.begin = begin;
    }

    public long getEnd() {
        return end;
    }

    public void setEnd(long end) {
        this.end = end;
    }

    public TbSegementInfo getSegementInfo() {
        return segementInfo;
    }

    public void setSegementInfo(TbSegementInfo segementInfo) {
        this.segementInfo = segementInfo;
    }
}
