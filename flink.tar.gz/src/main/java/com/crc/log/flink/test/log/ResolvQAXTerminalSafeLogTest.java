package com.crc.log.flink.test.log;

import com.crc.log.flink.common.utils.JsonUtils;
import com.crc.log.flink.config.AllConfig;
import com.crc.log.flink.es.DataProcessFuncation;

import java.util.concurrent.ConcurrentHashMap;

/**
 * @author jixiangqi
 * @date 2022/5/11
 */
public class ResolvQAXTerminalSafeLogTest {

    public static void main(String[] args) {
        AllConfig config = new AllConfig();
        DataProcessFuncation.CONIFG = config;
        config.setMode("single");
        config.setParse("ResolvQAXTerminalSafeLog");
        config.setIndex("sec_all");

        String str = "{\"version\":\"\\u5929\\u64ce6.0.0.2500\",\"log_name\":\"\\u7f51\\u7edc\\u8bbf\\u95ee\\u5ba1\\u8ba1\",\"log_id\":\"76909ebdcd337fd49e02bfd79c9a1401\",\"create_time\":\"2017-01-18 18:11:27\",\"ip\":\"172.27.31.39\",\"report_ip\":\"172.27.31.39\",\"mac\":\"6c626db037fb\",\"gid\":1,\"work_group\":\"corp.qihoo.net\",\"content\":{\"process_md5\":\"B37FE8752232060D8283A0174E32FA4D\",\"process_path\":\"E:\\\\Users\\\\zhaoqiang-s\\\\AppData\\\\Roaming\\\\360se6\\\\Application\\\\360se.exe\",\"url\":\"dd.browser.360.cn\\/static\\/a\\/388.6667.gif?14706372763795445875339\",\"process_cmdline\":\"\\\"E:\\\\Users\\\\zhaoqiang-s\\\\AppData\\\\Roaming\\\\360se6\\\\Application\\\\360se.exe\\\" \",\"process_name\":\"360se.exe\",\"destination_ip\":\"106.39.219.26\"}}";
        ConcurrentHashMap<String, Object> proc = DataProcessFuncation.parse(str, "index");
        JsonUtils.printStr(proc);

       /* str = "<23> inbound/pass1: host-176-221-123-46.dynamic.mm.pl[176.221.123.46] 1650540128-09e56229950c9c0001-pejTAd 1650540128 1650540129 RECV jianxiangjin@calendar.nagase.cn changkf@crc.com.hk 2 62 176.221.123.46";
        proc = DataProcessFuncation.parse(str, "index");
        JsonUtils.printStr(proc);

        str = "<23> inbound/pass1: 45-227-82-217.fibranetjf.com.br[45.227.82.217] 1650540120-09e56229920c9a0001-fbTjmn 1650540120 1650540124 SCAN - richard@halltv.com leiguangyong@crb.cn - 2 37 &#27604;&#29305;&#24065; SZ:17634 SUBJ:=?UTF-8?B?562J5b6F5LuY5qy+44CC6K+35rOo5oSPIQ==?=";
        proc = DataProcessFuncation.parse(str, "index");
        JsonUtils.printStr(proc);

        str = "<23> scan: rrmtabm01.ms.com[205.228.15.61] 1650540107-09e56229920c980001-8c0n3g 1650540108 1650540120 SCAN ENC bmbounce+jymbc16afpiz74@ms.com xiongzhe5@crcapital.com.hk - 7 88 corporate SZ:211642 SUBJ:=?UTF-8?B?R2xvYmFsIE1hY3JvIERhdGE6IFVTIExpcXVpZCBSYXRlcyBUcmFja2VyIChF?==?UTF-8?B?eGNlbCBWZXJzaW9uKQ==?=\n";
        proc = DataProcessFuncation.parse(str, "index");
        JsonUtils.printStr(proc);*/
    }

}
