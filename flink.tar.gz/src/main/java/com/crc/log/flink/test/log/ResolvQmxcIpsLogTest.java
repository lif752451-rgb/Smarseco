package com.crc.log.flink.test.log;

import com.crc.log.flink.common.utils.JsonUtils;
import com.crc.log.flink.config.AllConfig;
import com.crc.log.flink.es.DataProcessFuncation;

import java.util.concurrent.ConcurrentHashMap;

/**
 * @author jixiangqi
 * @date 2021/12/7
 */
public class ResolvQmxcIpsLogTest {

    public static void main(String[] args) {
        AllConfig config = new AllConfig();
        DataProcessFuncation.CONIFG = config;
        config.setMode("single");
        config.setParse("ResolvQmxcIpsLog");
        config.setIndex("sec_all");


        String str = "<214>Dec 7 15:38:25 D1-NBB5000-IPS-01 IPS: SerialNum=0113242010199999 GenTime=\"2021-12-07 15:38:25\" SrcIP=10.0.64.54 SrcIP6= SrcIPVer=4 DstIP=223.202.135.137 DstIP6= DstIPVer=4 Protocol=TCP SrcPort=51954 DstPort=80 InInterface=ge0/2 OutInterface=ge0/1 SMAC=00:1c:54:ff:08:03 DMAC=00:03:b2:78:00:00 FwPolicyID=4 EventName=HTTP_Java_HttpClient_远程访问 EventID=152525413 EventLevel=0 EventsetName=高防版本事件库 SecurityType=安全审计 SecurityID=11 ProtocolType=HTTP ProtocolID=10 Action=PASS Vsysid=0 Content=\"Host=monitor.fahaicc.com;URL=/request?uid=PMALFLJB&api=item&rt=1638863215595&args={\"customerGroupId\";URL长度=71;Http协议头长度=477;User-Agent=Apache-HttpClient/4.5.2 (Java/1.8.0_192);\" CapToken= EvtCount=1";
        ConcurrentHashMap<String, Object> proc = DataProcessFuncation.parse(str,"index");
        JsonUtils.printStr(proc);

        str = "<214>Dec 7 15:38:25 D1-NBB5000-IPS-01 IPS: SerialNum=0113242010199999 GenTime=\"2021-12-07 15:38:25\" SrcIP=10.0.64.54 SrcIP6= SrcIPVer=4 DstIP=59.36.121.13 DstIP6= DstIPVer=4 Protocol=TCP SrcPort=51953 DstPort=443 InInterface=ge0/2 OutInterface=ge0/1 SMAC=00:1c:54:ff:08:03 DMAC=00:03:b2:78:00:00 FwPolicyID=4 EventName=TCP_建立SSL握手连接 EventID=152323088 EventLevel=1 EventsetName=高防版本事件库 SecurityType=协议分析 SecurityID=10 ProtocolType=HTTPS ProtocolID=51 Action=PASS Vsysid=0 Content=\"数据长度=75;TCP数据内容=1603030046100000424104dbbb6146a2ce489229ecd8da2f598fae09407d52c9d602fd21784761ca526e7a77991dcb09f6bb955dae22ee364452c4af27f95ba78db9be38df18796e05b9d6;\" CapToken= EvtCount=1";
        proc = DataProcessFuncation.parse(str,"index");
        JsonUtils.printStr(proc);

        str = "<214>Dec 7 15:38:24 D1-NBB5000-IPS-01 IPS: SerialNum=0113242010199999 GenTime=\"2021-12-07 15:38:24\" SrcIP=10.0.64.54 SrcIP6= SrcIPVer=4 DstIP=223.202.135.137 DstIP6= DstIPVer=4 Protocol=TCP SrcPort=51948 DstPort=80 InInterface=ge0/2 OutInterface=ge0/1 SMAC=00:1c:54:ff:08:03 DMAC=00:03:b2:78:00:00 FwPolicyID=4 EventName=HTTP_Java_HttpClient_远程访问 EventID=152525413 EventLevel=0 EventsetName=高防版本事件库 SecurityType=安全审计 SecurityID=11 ProtocolType=HTTP ProtocolID=10 Action=PASS Vsysid=0 Content=\"Host=monitor.fahaicc.com;URL=/request?uid=PMALFLJB&api=result&rt=1638863214915&args={\"customerGroupId\";URL长度=73;Http协议头长度=527;User-Agent=Apache-HttpClient/4.5.2 (Java/1.8.0_192);\" CapToken= EvtCount=1";
        proc = DataProcessFuncation.parse(str,"index");
        JsonUtils.printStr(proc);

        str = "<214>Dec 8 17:21:09 D1-NBB5000-IPS-01 IPS: SerialNum=0113242010199999 GenTime=\"2021-12-08 17:21:09\" SrcIP= SrcIP6=xxxx:xxxx:xxxx:xxxx:xxxx:xxxx:xxxx:76d SrcIPVer=6 DstIP= DstIP6=xxxx::xx:x:xx:xx DstIPVer=6 Protocol=TCP SrcPort=26368 DstPort=443 InInterface=ge0/1 OutInterface=ge0/2 SMAC=xx:xx:xx:xx:xx:xx DMAC=00:1c:54:ff:18:04 FwPolicyID=3 EventName=TCP_建立SSL握手连接 EventID=152323088 EventLevel=0 EventsetName=高防版本事件库 SecurityType=协议分析 SecurityID=10 ProtocolType=HTTPS ProtocolID=51 Action=PASS Vsysid=0 Content=\"数据长度=126;TCP数据内容=1603030046100000424104e8a731a4b2a53e8146dd52b0d61355e4de14f42f02cf96049c1df71c13baa4906c841b6151d67e4d14760e6b80848af8e1510c8dd0306d06018da8adb4d24d9b14030300010116030300280000000000000000781a376d938ebde242e9761c642466c2ab3435d9da7c7fe2132977a1fba31846;\" CapToken= EvtCount=1\"";
        proc = DataProcessFuncation.parse(str,"index");
        JsonUtils.printStr(proc);
    }

}
