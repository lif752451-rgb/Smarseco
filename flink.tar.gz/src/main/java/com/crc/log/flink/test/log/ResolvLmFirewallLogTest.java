package com.crc.log.flink.test.log;

import com.crc.log.flink.common.utils.JsonUtils;
import com.crc.log.flink.config.AllConfig;
import com.crc.log.flink.es.DataProcessFuncation;

import java.util.concurrent.ConcurrentHashMap;

public class ResolvLmFirewallLogTest {

    public static void main(String[] args) {
        AllConfig config = new AllConfig();
        DataProcessFuncation.CONIFG = config;
        config.setMode("single");
        config.setParse("ResolvLMFirewallLog");
        config.setIndex("sec_all");


        String str = "<1>rule_id:149;time:2021-11-08 09:03:35;module:fw;src_intf:G1/4;dst_intf:G1/2;action:drop;proto:tcp;src_addr:10.0.33.8;src_port:443;dst_addr:10.168.20.18;dst_port:25437;src_addr_nat:;src_port_nat:;dst_addr_nat:;dst_port_nat:;info:;user:";
        ConcurrentHashMap<String, Object> proc = DataProcessFuncation.parse(str,"index");
        JsonUtils.printStr(proc);

        str = "module:PLUTO;type:SYSTEM;level:INFO;time:1635816949;clientIp:;locationInfo:;description:loading secrets from /opt/nsfocus/etc/ipsecvpn/openswan/ipsec.secrets";
        proc = DataProcessFuncation.parse(str,"index");
        JsonUtils.printStr(proc);
    }

}
