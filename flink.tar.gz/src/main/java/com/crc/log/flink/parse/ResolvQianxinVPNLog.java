package com.crc.log.flink.parse;

import com.crc.log.flink.common.constants.LevelConstants;
import com.crc.log.flink.common.constants.LogConstants;
import com.crc.log.flink.common.utils.DataUtils;
import com.crc.log.flink.common.utils.IPUtil;
import com.crc.log.flink.common.utils.JsonUtils;
import com.crc.log.flink.common.utils.MapUtils;
import org.apache.commons.lang3.StringUtils;

import java.util.concurrent.ConcurrentHashMap;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * @author jixiangqi
 * @date 2022/1/14'
 * 奇安信VPN
 */
public class ResolvQianxinVPNLog {

    /**
     * 通用日志 日志泛化
     */
    public static ConcurrentHashMap<String, Object> parse(String message) {
        try {
            ConcurrentHashMap<String, Object> data = proc(message);
            if (DataUtils.isNotEmptyJson(data)) {
                return data;
            }
        } catch (Exception ignored) {

        }
        return null;
    }

    private static ConcurrentHashMap<String, Object> proc(String jsonStr) {
        ConcurrentHashMap<String, Object> rtnObjc = JsonUtils.createBaseMap(jsonStr);
        if (jsonStr.contains("IP")) {
            int index = DataUtils.getLastIndex(jsonStr, ",");
                    //jsonStr.lastIndexOf(",");
            String temp = DataUtils.getSubString(jsonStr, index+1);
                    //jsonStr.substring(index+1);
            jsonStr = DataUtils.getSubString(jsonStr, 0,index);
                    //jsonStr.substring(0,index);
            String data = getData(temp);
            index = DataUtils.getIndex(data, ":");
                    //data.indexOf(":");
            String srcIp = DataUtils.getSubString(data, 0, index);
                    //data.substring(0,index);
            String srcPort = DataUtils.getSubString(data, index+3);
                    //data.substring(index+3);
            if (IPUtil.isIp(srcIp)) {
                rtnObjc.put(LogConstants.SRC_IP, srcIp);
            }
            if (isPureDigital(srcPort)) {
                rtnObjc.put(LogConstants.SRC_PORT, srcPort);
            }
        }
        String[] split = DataUtils.getSplit(jsonStr, "\\|");
                //jsonStr.split("\\|");
        switchKeyAndValue(split, rtnObjc);
        rtnObjc.put(LogConstants.LOG_PRODUCT, "奇安信VPN");
        rtnObjc.put(LogConstants.LOG_LEVEL, LevelConstants.getLevel(MapUtils.getStr(rtnObjc,LogConstants.LOG_LEVEL)));
        if (StringUtils.isBlank(MapUtils.getStr(rtnObjc, LogConstants.SRC_IP))) {
            rtnObjc.put(LogConstants.SRC_IP, "0.0.0.0");
        }
        if (StringUtils.isBlank(MapUtils.getStr(rtnObjc, LogConstants.DEST_IP))) {
            rtnObjc.put(LogConstants.DEST_IP, "0.0.0.0");
        }
        setAlertName(rtnObjc);
        return rtnObjc;
    }

    private static void switchKeyAndValue(String[] array, ConcurrentHashMap<String, Object> rtnObjc) {
        int type = 0;
        for (int i = 1; i < array.length; i++) {
            String temp = array[i].trim();
            switch (i) {
                case 1:
                    rtnObjc.put(LogConstants.LOG_LEVEL, temp);
                    break;
                case 4:
                    if (temp.contains("Monitor")) {
                        type = 1;
                        rtnObjc.put(LogConstants.LOG_TYPE, "日志监控");
                    }
                    break;
                case 5:
                    if (type == 1) {
                        rtnObjc.put(LogConstants.USER_NAME, temp);
                    }
                    break;
                case 6:
                    rtnObjc.put(LogConstants.ACTION_RESULT, temp);
                    break;
                case 7:
                    rtnObjc.put(LogConstants.LOG_CONTENT, temp);
                    break;
            }
        }
    }

    private static String getData(String jsonStr) {
        int index = DataUtils.getIndex(jsonStr, "[");
                //jsonStr.indexOf("[");
        int index1 = DataUtils.getLastIndex(jsonStr, "]");
                //jsonStr.lastIndexOf("]");
        jsonStr = DataUtils.getSubString(jsonStr, index+1, index1);
                //jsonStr.substring(index+1, index1);
        return jsonStr;
    }

    public static boolean isPureDigital(String str) {
        if (str == null || "".equals(str)){
            return false;
        }
        Pattern p;
        Matcher m;
        p = Pattern.compile("[0-9]*");
        m = p.matcher(str);
        return m.matches();
    }


    private static void setAlertName(ConcurrentHashMap<String, Object> rtnObjc) {
        String log = MapUtils.getStr(rtnObjc, LogConstants.LOG_ORI_MSG);
        String alertName = "日志详情为:" + log;
        rtnObjc.put(LogConstants.ALERT_NAME, alertName);
    }
}
