package com.crc.log.flink.parse;

import com.alibaba.fastjson.JSONObject;
import com.crc.log.flink.common.constants.LevelConstants;
import com.crc.log.flink.common.constants.LogConstants;
import com.crc.log.flink.common.utils.DataUtils;
import com.crc.log.flink.common.utils.DateUtils;
import com.crc.log.flink.common.utils.JsonUtils;
import com.crc.log.flink.common.utils.MapUtils;
import org.apache.commons.lang3.StringUtils;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

/**
 * @author jixiangqi
 * @date 2022/5/10
 * 青藤蜂巢
 */
public class ResolvQtFcLog {
    static SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");

    public static ConcurrentHashMap<String,Object> parse(String message) {
        try {
            ConcurrentHashMap<String,Object> data = proc(message);
            if (DataUtils.isNotEmptyJson(data)) {
                return data;
            }
        } catch (Exception ignored) {

        }
        return null;
    }

    private static ConcurrentHashMap<String,Object> proc(String jsonStr) {
        ConcurrentHashMap<String,Object> rtnObjc = JsonUtils.createBaseMap(jsonStr);
        Map<String, String> keyValue = getKeyValueBySpace(jsonStr);
        keyValue.forEach((k,v) -> {
            switchKeyValue(rtnObjc, k, v);
        });
        rtnObjc.put(LogConstants.LOG_PRODUCT, "青藤蜂巢");
        if (StringUtils.isBlank(MapUtils.getStr(rtnObjc, LogConstants.LOG_LEVEL))) {
            rtnObjc.put(LogConstants.LOG_LEVEL, LevelConstants.getLevel(MapUtils.getStr(rtnObjc,LogConstants.LOG_LEVEL)));
        }
        if (StringUtils.isBlank(MapUtils.getStr(rtnObjc, LogConstants.SRC_IP))) {
            rtnObjc.put(LogConstants.SRC_IP, "0.0.0.0");
        }
        if (StringUtils.isBlank(MapUtils.getStr(rtnObjc, LogConstants.DEST_IP))) {
            rtnObjc.put(LogConstants.DEST_IP, "0.0.0.0");
        }
        setAlertName(rtnObjc);
        return rtnObjc;
    }

    private static void setAlertName(ConcurrentHashMap<String,Object> rtnObjc) {
        String message = "";
        String alertMame = "";
        String logType = MapUtils.getStr(rtnObjc, LogConstants.LOG_TYPE);
        switch (logType) {
            case "kubernetes_api_audit": {
                String srcIp = MapUtils.getStr(rtnObjc, LogConstants.SRC_IP);
                String url = MapUtils.getStr(rtnObjc, LogConstants.LOG_URL);
                String logLevel = MapUtils.getStr(rtnObjc, LogConstants.LOG_LEVEL);
                String actionType = MapUtils.getStr(rtnObjc, LogConstants.ACTION_TYPE);
                String actionResult = MapUtils.getStr(rtnObjc, LogConstants.ACTION_RESULT);
                String user = MapUtils.getStr(rtnObjc, LogConstants.USER_NAME);
                message = "用户为:%s在IP地址为:%s的k8s集群上产生了一条api访问日志,访问url为:%s,日志级别为:%s,操作类型为:%s,操作结果为:%s";
                alertMame = String.format(message, user, srcIp, url, logLevel, actionType, actionResult);
                break;
            }
            case "ctn_proc_create": {
                String devName = MapUtils.getStr(rtnObjc, LogConstants.DEVICE_NAME);
                String processName = MapUtils.getStr(rtnObjc, LogConstants.PROCESS_NAME);
                String actionType = MapUtils.getStr(rtnObjc, LogConstants.ACTION_TYPE);
                String actionResult = MapUtils.getStr(rtnObjc, LogConstants.ACTION_RESULT);
                message = "在集群名称为:%s的k8s集群上创建了一个新的进程,进程名称为:%s,操作类型为:%s,操作结果为:%s";
                alertMame = String.format(message, devName, processName, actionType, actionResult);
                break;
            }
            case "docker_virus_detect": {
                String agentIp = MapUtils.getStr(rtnObjc, LogConstants.AGENT_IP);
                String virusName = MapUtils.getStr(rtnObjc, LogConstants.VIRUS_NAME);
                String content = MapUtils.getStr(rtnObjc, LogConstants.LOG_CONTENT);
                String description = MapUtils.getStr(rtnObjc, LogConstants.LOG_DESCRIPTION);
                String logName = MapUtils.getStr(rtnObjc, LogConstants.LOG_NAME);
                String url = MapUtils.getStr(rtnObjc, LogConstants.LOG_URL);
                message = "在主机IP为:%s的设备上发现了名称为:%s的病毒,病毒内容为:%s,病毒描述为:%s,日志名称为:%s,路径为:%s";
                alertMame = String.format(message, agentIp, virusName, description, content, logName, url);
                break;
            }
            case "webshell_container": {
                String agentIp = MapUtils.getStr(rtnObjc, LogConstants.AGENT_IP);
                String virusName = MapUtils.getStr(rtnObjc, LogConstants.LOG_TYPE);
                String content = MapUtils.getStr(rtnObjc, LogConstants.LOG_CONTENT);
                String logName = MapUtils.getStr(rtnObjc, LogConstants.LOG_NAME);
                String url = MapUtils.getStr(rtnObjc, LogConstants.LOG_URL);
                message = "在主机IP为:%s的设备上发现了名称为:%s的web后门日志,病毒描述为:%s,日志名称为:%s,路径为:%s";
                alertMame = String.format(message, agentIp, virusName, content, logName, url);
                break;
            }
            case "docker_bounce_shell": {
                String destIp = MapUtils.getStr(rtnObjc, LogConstants.DEST_IP);
                String logLevel = MapUtils.getStr(rtnObjc, LogConstants.LOG_LEVEL);
                String content = MapUtils.getStr(rtnObjc, LogConstants.LOG_CONTENT);
                String logName = MapUtils.getStr(rtnObjc, LogConstants.LOG_NAME);
                String url = MapUtils.getStr(rtnObjc, LogConstants.LOG_URL);
                message = "IP为:%s受到了名称为:%s的日志,攻击内容为:%s,路径为:%s,日志级别为:%s";
                alertMame = String.format(message, destIp, logName, content, url, logLevel);
                break;
            }
            case "malicious_cmd_container":
            case "bruteforce_inter_container":
            case "bruteforce_ext_container":
            case "privilege_escalation_container": {
                String agentIp = MapUtils.getStr(rtnObjc, LogConstants.AGENT_IP);
                String logLevel = MapUtils.getStr(rtnObjc, LogConstants.LOG_LEVEL);
                String content = MapUtils.getStr(rtnObjc, LogConstants.LOG_CONTENT);
                String logName = MapUtils.getStr(rtnObjc, LogConstants.LOG_NAME);
                String url = MapUtils.getStr(rtnObjc, LogConstants.LOG_URL);
                String description = MapUtils.getStr(rtnObjc, LogConstants.LOG_DESCRIPTION);
                message = "在IP地址为:%s的容器中发现了名称为:%s的日志,日志描述为:%s,日志内容为:%s,路径为:%s,日志级别为:%s";
                alertMame = String.format(message, agentIp, logName, description, content, url, logLevel);
                break;
            }
            default: {
                String agentIp = MapUtils.getStr(rtnObjc, LogConstants.AGENT_IP);
                String logLevel = MapUtils.getStr(rtnObjc, LogConstants.LOG_LEVEL);
                String content = MapUtils.getStr(rtnObjc, LogConstants.LOG_CONTENT);
                String logName = MapUtils.getStr(rtnObjc, LogConstants.LOG_NAME);
                String url = MapUtils.getStr(rtnObjc, LogConstants.LOG_URL);
                message = "IP为:%s受到了名称为:%s的日志,攻击内容为:%s,路径为:%s,日志级别为:%s";
                alertMame = String.format(message, agentIp, logName, content, url, logLevel);
                break;
            }
        }
        rtnObjc.put(LogConstants.ALERT_NAME, alertMame);
    }

    private static Map<String, String> getKeyValueBySpace(String jsonStr) {
        Map<String, String> resultMap = new HashMap<>();
        String[] s = DataUtils.getSplit(jsonStr, " ");
        String keyIndex = "";
        for (String tempStr : s) {
            if (tempStr.contains("=")) {
                int index = DataUtils.getIndex(tempStr, "=");
                String key = DataUtils.getSubString(tempStr, 0, index).trim().replaceAll("\"", "");
                String value = DataUtils.getSubString(tempStr, index + 1).trim().replaceAll("\"", "");
                resultMap.put(key, value);
                keyIndex = key;
            } else {
                resultMap.put(keyIndex, resultMap.get(keyIndex) + " " + tempStr);
            }
        }
        return  resultMap;
    }

    private static void switchKeyValue(ConcurrentHashMap<String,Object> rtnObjc, String key, String value) {
        switch (key) {
            case "datatype":
                rtnObjc.put(LogConstants.LOG_TYPE, value);
                break;
            case "datatime":
                rtnObjc.put(LogConstants.LOG_START_TIME, DateUtils.getISO8601Timestamp(sdf.format(new Date(DataUtils.toNum(value) * 1000L)), "yyyy-MM-dd HH:mm:ss"));
                break;
            case "agent_ip":
                rtnObjc.put(LogConstants.AGENT_IP, value);
                break;
            case "action":
                rtnObjc.put(LogConstants.ACTION_TYPE, value);
                break;
            case "type":
                rtnObjc.put(LogConstants.ACTION_RESULT, value);
                break;
            case "event_name":
                rtnObjc.put(LogConstants.LOG_NAME, value);
                break;
            case "event_level":
                rtnObjc.put(LogConstants.LOG_LEVEL, value);
                break;
            case "event_content":
                rtnObjc.put(LogConstants.LOG_CONTENT, value);
                break;
            case "url":
                rtnObjc.put(LogConstants.LOG_URL, value);
                break;
            case "host_name":
                rtnObjc.put(LogConstants.HOST_NAME, value);
                break;
            case "detail.dst_ip":
                rtnObjc.put(LogConstants.DEST_IP, value);
                break;
            case "detail.src_ip":
                rtnObjc.put(LogConstants.SRC_IP, value);
                break;
            case "detail.process_tree":
                rtnObjc.put(LogConstants.PROCESS_PATCH, value);
                break;
            case "detail.pname":
                rtnObjc.put(LogConstants.PROCESS_NAME, value);
                break;
            case "ppname":
                rtnObjc.put(LogConstants.PROCESS_NAME, value);
                break;
            case "detail.clientIp":
                rtnObjc.put(LogConstants.SRC_IP, value);
                break;
            case "detail.reason":
                rtnObjc.put(LogConstants.LOG_DESCRIPTION, value);
                break;
            case "detail.rule":
                rtnObjc.put(LogConstants.LOG_DESCRIPTION, value);
                break;
            case "detail.port":
                rtnObjc.put(LogConstants.DEST_PORT, value);
                break;
            case "detail.path":
                rtnObjc.put(LogConstants.FILE_PATH, value);
                break;
            case "detail.name":
                rtnObjc.put(LogConstants.VIRUS_NAME, value);
                break;
            case "detail.file_type":
                rtnObjc.put(LogConstants.FILE_TYPE, value);
                break;
            case "request_uri":
                rtnObjc.put(LogConstants.LOG_URL, value);
                break;
            case "request_object":
                rtnObjc.put(LogConstants.ACTION_OBJ, value);
                break;
            case "source_ips":
                rtnObjc.put(LogConstants.SRC_IP, value);
                break;
            case "level":
                rtnObjc.put(LogConstants.LOG_LEVEL, value);
                break;
            case "user":
                String str = value.replaceAll("\\\\","\"");
                JSONObject jsonObject = JSONObject.parseObject(str);
                rtnObjc.put(LogConstants.USER_NAME, jsonObject.get("username"));
                break;
            case "container_id":
                rtnObjc.put(LogConstants.DEVICE_ID, value);
                break;
            case "container_name":
                rtnObjc.put(LogConstants.DEVICE_NAME, value);
                break;
        }
    }


}
