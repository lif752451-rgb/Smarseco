package com.crc.log.flink.test.log;

import com.crc.log.flink.common.utils.JsonUtils;
import com.crc.log.flink.config.AllConfig;
import com.crc.log.flink.es.DataProcessFuncation;

import java.util.concurrent.ConcurrentHashMap;

public class HryhKafkaTest
{
    public static void main(String[] args)
    {
        String msgx = "{\"@timestamp\":\"2022-06-05T18:41:26.598Z\",\"beat\":{\"hostname\":\"sisyslog03\",\"name\":\"sisyslog03\",\"version\":\"5.5.1\"},\"input_type\":\"log\",\"message\":\"Jun  6 02:41:25 56.8.32.21 1111111111111111111\",\"offset\":314138,\"source\":\"/wls/applogs/logstash/syslog.log\",\"type\":\"log\"}";
        AllConfig config = new AllConfig();
        DataProcessFuncation.CONIFG = config;
        config.setMode("single");
        config.setParse("ResolvKafkaLog");
        config.setIndex("sec_all");

        ConcurrentHashMap<String, Object> json = DataProcessFuncation.parse(msgx,"index");
        JsonUtils.printStr(json);
    }
}
