package com.crc.log.flink.test.log;

import com.crc.log.flink.common.utils.JsonUtils;
import com.crc.log.flink.config.AllConfig;
import com.crc.log.flink.es.DataProcessFuncation;

import java.util.concurrent.ConcurrentHashMap;

/**
 * @author jixiangqi
 * @date 2022/5/9
 */
public class ResolvAnWafAPTLogTest {

    public static void main(String[] args) {
        AllConfig config = new AllConfig();
        DataProcessFuncation.CONIFG = config;
        config.setMode("single");
        config.setParse("ResolvAnWafAPTLog");
        config.setIndex("sec_all");


        String str = "DBAppWAF: happentime/2012-09-14 04:28:11,severity_id/2,msg_id/12010,method/GET,url/192.168.54.184/web/index.asp?%20and%201=1,post/,dip/192.168.54.184,hostname/192.168.54.184,dport/80,sip/192.168.54.2,sport/63061,user_agent/Mozilla/4.0 (compatible; MSIE 8.0; Windows NT 6.1; WOW64; Trident/4.0; SLCC2; .NET CLR 2.0.50727; .NET CLR 3.5.30729; .NET CLR 3.0.30729; Media Center PC 6.0; InfoPath.3),tag_id/1201,action_id/1,response_code/403,match/and 1=,rule_id/12010070,unique_id/UFJB238AAAEAAhnOekkAAABO,country/LAN,province/,city/";
        ConcurrentHashMap<String, Object> proc = DataProcessFuncation.parse(str, "index");
        JsonUtils.printStr(proc);
    }
}
