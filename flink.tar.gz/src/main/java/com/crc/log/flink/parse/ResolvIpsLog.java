package com.crc.log.flink.parse;

import com.alibaba.fastjson.JSONObject;
import com.crc.log.flink.common.constants.ActionResultConstants;
import com.crc.log.flink.common.constants.LevelConstants;
import com.crc.log.flink.common.constants.LogConstants;
import com.crc.log.flink.common.utils.*;
import org.apache.commons.lang3.StringUtils;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.concurrent.ConcurrentHashMap;

public class ResolvIpsLog {
    static SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");

    /**
     * IPS 日志泛化
     */
    public static ConcurrentHashMap<String,Object> parse(String message) {
        try {
            ConcurrentHashMap<String,Object> data = proc(message);
            if (DataUtils.isNotEmptyJson(data)) {
                return data;
            }
        } catch (Exception ignored) {

        }
        return null;
    }

    private static ConcurrentHashMap<String,Object> proc(String jsonStr) {
        ConcurrentHashMap<String,Object> rtnObjc = JsonUtils.createBaseMap(jsonStr);
        if (jsonStr.contains("<5>time:") || jsonStr.contains("<5>time=")) {
            String IPS = jsonStr.replace("<5>time", "");
            JSONObject dataJson = new JSONObject();
            getDataByContent(IPS, dataJson);
            try {
                if (jsonStr.contains("<5>time:")) {
                    int pos = DataUtils.getIndex(jsonStr, "<5>time:");
                    if (pos != -1) {
                        pos = pos + "<5>time:".length();
                        int pos2 = DataUtils.getIndex(jsonStr, ";");
                        //jsonStr.indexOf(";");
                        String time = DataUtils.getSubString(jsonStr, pos, pos2);
                        //jsonStr.substring(pos, pos2);
                        //System.out.println(time);
                        MapUtils.setStr(rtnObjc, LogConstants.LOG_START_TIME, DateUtils.getISO8601Timestamp(time));
                    }
                }
                if (jsonStr.contains("<5>time=")) {
                    int pos = DataUtils.getIndex(jsonStr, "<5>time=");
                    if (pos != -1) {
                        pos = pos + "<5>time=".length();
                        int pos2 = DataUtils.getIndex(jsonStr, ";");
                        String time = DataUtils.getSubString(jsonStr, pos, pos2);
                        MapUtils.setStr(rtnObjc, LogConstants.LOG_START_TIME, DateUtils.getISO8601Timestamp(time));
                    }

                }
            } catch (Exception e) {

            }
            MapUtils.setStr(rtnObjc, LogConstants.DEST_IP, dataJson, "dst_addr");
            MapUtils.setStr(rtnObjc, LogConstants.SRC_IP, dataJson, "src_addr");
            MapUtils.setStr(rtnObjc, LogConstants.SRC_PORT, dataJson, "src_port");
            MapUtils.setStr(rtnObjc, LogConstants.DEST_PORT, dataJson, "dst_port");
            MapUtils.setStr(rtnObjc, LogConstants.LOG_NAME, dataJson, "event");
            MapUtils.setStr(rtnObjc, LogConstants.LOG_LEVEL, dataJson, "danger_degree");
            MapUtils.setStr(rtnObjc, LogConstants.ACTION_RESULT, dataJson, "breaking_sighn");
            MapUtils.setStr(rtnObjc, LogConstants.OP_NAME, dataJson, "user");
            MapUtils.setStr(rtnObjc, LogConstants.LOG_PROTOCAL, dataJson, "proto");
            MapUtils.setStr(rtnObjc, LogConstants.LOG_PRODUCT, "绿盟IPS");
            MapUtils.setStr(rtnObjc, LogConstants.MSG_CONTENT, jsonStr);
            rtnObjc.put(LogConstants.LOG_LEVEL, LevelConstants.getLevel(MapUtils.getStr(rtnObjc,LogConstants.LOG_LEVEL)));
            String actionResult = "1".equalsIgnoreCase(MapUtils.getStr(rtnObjc,LogConstants.ACTION_RESULT)) ?
                    ActionResultConstants.DENY : ActionResultConstants.NO_DENY;
//            if ("1".equalsIgnoreCase(rtnObjc.getString(LogConstants.ACTION_RESULT))) {
//                rtnObjc.put(LogConstants.ACTION_RESULT, ActionResultConstants.DENY);
//            } else rtnObjc.put(LogConstants.ACTION_RESULT, ActionResultConstants.NO_DENY);
            rtnObjc.put(LogConstants.ACTION_RESULT, actionResult);
            if (dataJson.containsKey(LogConstants.INTERNAL_IP)) {
                MapUtils.setStr(rtnObjc, LogConstants.INTERNAL_IP, dataJson.getString(LogConstants.INTERNAL_IP));
            }
            ScoreUtils.commonEventLevelScore(rtnObjc);
            if (StringUtils.isBlank(MapUtils.getStr(rtnObjc, LogConstants.SRC_IP))) {
                rtnObjc.put(LogConstants.SRC_IP, "0.0.0.0");
            }
            if (StringUtils.isBlank(MapUtils.getStr(rtnObjc, LogConstants.DEST_IP))) {
                rtnObjc.put(LogConstants.DEST_IP, "0.0.0.0");
            }
        } else {
            String[] split = DataUtils.getSplit(jsonStr, ";");
            for (String tempStr : split) {
                int index = DataUtils.getIndex(tempStr, "=");
                String key = DataUtils.getSubString(tempStr, 0, index).trim();
                String value = DataUtils.getSubString(tempStr, index + 1).trim();
                switchKeyValue(rtnObjc, key, value);
            }
        }
        setAlertName(rtnObjc);
        return rtnObjc;
    }

    public static void getDataByContent(String IPS, JSONObject dataJson) {

        String[] IPS_buff = DataUtils.getSplit(IPS, ";");
        //IPS.split(";");
        for (int i = 1; i < IPS_buff.length; i++) {
            String[] datakey = DataUtils.getSplit(IPS_buff[i], "=|:");
            //IPS_buff[i].split("=|:");
            if (1 < datakey.length) {
                dataJson.put(datakey[0], datakey[1].trim());
            }
        }
        if (IPS_buff[0].contains("devIp")) {
            String[] strArr = DataUtils.getSplit(IPS_buff[0], " ");
            //IPS_buff[0].split(" ");
            for (String s : strArr) {
                if (s.contains("devIp")) {
                    String[] datakey = DataUtils.getSplit(s, "=");
                    //s.split("=");
                    if (1 < datakey.length) {
                        // MapUtils.setStr(rtnObjc, LogConstants.INTERNAL_IP, datakey[1]);
                        dataJson.put(LogConstants.INTERNAL_IP, datakey[1]);
                        break;
                    }
                }
            }
        }
    }

    private static void switchKeyValue(ConcurrentHashMap<String,Object> rtnObjc, String key, String value) {
        switch (key) {
            case "time":
                if (DataUtils.isNumeric(value)) {
                    rtnObjc.put(LogConstants.LOG_START_TIME, DateUtils.getISO8601Timestamp(sdf.format(new Date(DataUtils.toNum(value) * 1000L)), "yyyy-MM-dd HH:mm:ss"));
                } else {
                    rtnObjc.put(LogConstants.LOG_START_TIME, DateUtils.getISO8601Timestamp(value, "yyyy-MM-dd HH:mm:ss"));
                }
                break;
            case "sip":
                rtnObjc.put(LogConstants.SRC_IP, value);
                break;
            case "smac":
                rtnObjc.put(LogConstants.SRC_MAC, value);
                break;
            case "sport":
                rtnObjc.put(LogConstants.SRC_PORT, value);
                break;
            case "dip":
                rtnObjc.put(LogConstants.DEST_IP, value);
                break;
            case "dmac":
                rtnObjc.put(LogConstants.DEST_MAC, value);
                break;
            case "dport":
                rtnObjc.put(LogConstants.DEST_PORT, value);
                break;
            case "count":
                rtnObjc.put(LogConstants.LOG_COUNT, value);
                break;
            case "protocol":
                rtnObjc.put(LogConstants.LOG_PROTOCAL, value);
                break;
            case "user_name":
                rtnObjc.put(LogConstants.USER_NAME, value);
                break;
            case "risk":
                rtnObjc.put(LogConstants.LOG_LEVEL, LevelConstants.getLevel(value));
                break;
            case "threat_level":
                rtnObjc.put(LogConstants.LOG_LEVEL, LevelConstants.getLevel(value));
                break;
            case "event":
                rtnObjc.put(LogConstants.LOG_NAME, value);
                break;
            case "action":
                String actionType = "";
                switch (value) {
                    case "1":
                        actionType = "记录日志";
                        break;
                    case "2":
                        actionType = "阻断会话";
                        break;
                    case "3":
                        actionType = "丢弃当前报文";
                        break;
                    case "8":
                        actionType = "隔离";
                        break;
                    case "20":
                        actionType = "发送snmp trap";
                        break;
                    case "10":
                        actionType = "TCP旁路阻断";
                        break;
                    case "40":
                        actionType = "发送短信";
                        break;
                    case "80":
                        actionType = "抓取会话报文";
                        break;
                    case "100":
                        actionType = "抓取当前报文";
                        break;
                    case "200":
                        actionType = "限速";
                        break;
                }
                rtnObjc.put(LogConstants.ACTION_RESULT, actionType);
                break;
        }
    }


    public static void setAlertName(ConcurrentHashMap<String,Object> resultJson) {
        String srcIp = MapUtils.getStr(resultJson, LogConstants.SRC_IP);
        String destIp = MapUtils.getStr(resultJson, LogConstants.DEST_IP);
        String logName = MapUtils.getStr(resultJson, LogConstants.LOG_NAME);
        String actionRule = MapUtils.getStr(resultJson, LogConstants.ACTION_RESULT);
        String log = MapUtils.getStr(resultJson, LogConstants.LOG_ORI_MSG);
        if (StringUtils.isBlank(destIp) || "null".equals(destIp) || "0.0.0.0".equals(destIp) || srcIp.equals(destIp)) {
            String messageFormat = "%s 发起 %s-%s,日志详情为:%s";
            String alertName = String.format(messageFormat, srcIp, logName, actionRule, log);
            resultJson.put(LogConstants.ALERT_NAME, alertName);
        } else {
            String messageFormat = "%s 对 %s 进行 %s-%s,日志详情为:%s";
            String alertName = String.format(messageFormat, srcIp, destIp, logName, actionRule, log);
            resultJson.put(LogConstants.ALERT_NAME, alertName);
        }
    }
}
