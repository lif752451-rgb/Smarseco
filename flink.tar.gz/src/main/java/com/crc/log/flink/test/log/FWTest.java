package com.crc.log.flink.test.log;

import com.crc.log.flink.common.utils.JsonUtils;
import com.crc.log.flink.config.AllConfig;
import com.crc.log.flink.es.DataProcessFuncation;

import java.util.concurrent.ConcurrentHashMap;

public class FWTest
{
    public static void main(String[] args) {
        String msgx = "\t<188>Dec  2 2021 08:29:59 USG6630-A IPSTRAP/4/THREATTRAP:OID 1.3.6.1.4.1.2011.6.122.43.1.2.8 An intrusion was detected.( SrcIp=172.16.18.79, DstIp=194.195.223.249, SrcPort=57216, DstPort=443,  Protocol=TCP, Event=JSON-RPC Mining Protocol - Miner Login, DetectTime=2021/12/02 16:30:00)";
        AllConfig config = new AllConfig();
        DataProcessFuncation.CONIFG = config;
        config.setMode("single");
        config.setParse("ResolvFirewallLog");
        config.setIndex("net_all");
        config.setFwfilter("F");

        msgx = "<188>Dec  2 2021 08:29:06 USG6630-A IPSTRAP/4/THREATTRAP:OID 1.3.6.1.4.1.2011.6.122.43.1.2.8 An intrusion was detected.( SrcIp=172.16.18.79, DstIp=194.195.223.249, SrcPort=57210, DstPort=443,  Protocol=TCP, Event=JSON-RPC Mining Protocol - Miner Login, DetectTime=2021/12/02 16:29:06)";
        ConcurrentHashMap<String, Object> json = DataProcessFuncation.parse(msgx,"index");
        JsonUtils.printStr(json);


        msgx = "<190>2021-12-07 14:13:16 LZ_HuaRunZD_USG6306E_INSIDE %%01SECLOG/6/SESSION_TEARDOWN(l):IPVer=4,Protocol=udp,SourceIP=10.74.248.80,DestinationIP=10.74.128.14,SourcePort=50355,DestinationPort=53,BeginTime=1638886361,EndTime=1638886361,SendPkts=1,SendBytes=60,RcvPkts=1,RcvBytes=123,SourceVpnID=0,DestinationVpnID=0,SourceZone=trust,DestinationZone=untrust,PolicyName=LZ->Center,CloseReason=aged-out,ApplicationName=DNS.";
        json = DataProcessFuncation.parse(msgx,"index");
        JsonUtils.printStr(json);

        msgx = "<188>2021-12-07 14:13:42 LZ_HuaRunZD_USG6306E_INSIDE %%01SECLOG/4/PACKET_DENY(l):IPVer=4,Protocol=udp,SourceIP=10.74.248.80,DestinationIP=10.74.248.255,SourcePort=137,DestinationPort=137,BeginTime=1638886423,EndTime=1638886423,SourceVpnID=0,DestinationVpnID=0,SourceZone=trust,DestinationZone=trust,PolicyName=��������,CloseReason=policy-deny.";
        json = DataProcessFuncation.parse(msgx,"index");
        JsonUtils.printStr(json);

        msgx = "<190>2021-12-14 10:04:33 LZ_HuaRunZD_USG6306E_INSIDE %%01SECLOG/6/SESSION_TEARDOWN(l):IPVer=4,Protocol=udp,SourceIP=10.74.248.69,DestinationIP=10.0.128.14,SourcePort=53922,DestinationPort=53,BeginTime=1639476238,EndTime=1639476238,SendPkts=1,SendBytes=81,RcvPkts=1,RcvBytes=97,SourceVpnID=0,DestinationVpnID=0,SourceZone=trust,DestinationZone=untrust,PolicyName=LZ->Center,CloseReason=aged-out,ApplicationName=DNS.";
        json = DataProcessFuncation.parse(msgx,"index");
        JsonUtils.printStr(json);

        System.out.println("##");
        msgx = "<190>Apr 29 2022 11:25:33 USG6300-���ĳ��� %%01POLICY/6/POLICYPERMIT(l):vsys=public, protocol=17, source-ip=10.73.225.252, source-port=61644, destination-ip=8.8.8.8, destination-port=53, time=2022/4/29 19:25:33, source-zone=trust, destination-zone=untrust, application-name=, rule-name=��ȫ����.\\u0000\",\"type\":\"udp\",\"timestamp\":\"2022-04-29 19:31:09\"}   ���$�`��u�+�u�+����������������{\"topic\":\"crcland_security\",\"dev_ip\":\"10.73.238.4\",\"message\":\"<190>Apr 29 2022 19:27:15 USG6300E--֣�� %%01POLICY/6/POLICYPERMIT(l):vsys=public, protocol=6, source-ip=172.16.0.99, source-port=55332, destination-ip=111.6.232.120, destination-port=80, time=2022/4/29 19:27:15, source-zone=trust, destination-zone=untrust, application-name=, rule-name=��ȫ����.\\u0000\",\"type\":\"udp\",\"timestamp\":\"2022-04-29 19:31:09\"}      ���6q���uɕ�uɕ����������������{\"topic\":\"crcland_security\",\"dev_ip\":\"10.73.230.4\",\"message\":\"<190>Apr 29 2022 19:30:09 USG6300E--�Ͳ� %%01POLICY/6/POLICYPERMIT(l):vsys=public, protocol=6, source-ip=172.16.0.204, source-port=56895, destination-ip=39.99.153.39, destination-port=80, time=2022/4/29 19:30:09, source-zone=trust, destination-zone=untrust, application-name=, rule-name=��ȫ����.\\u0000\",\"type\":\"udp\",\"timestamp\":\"2022-04-29 19:31:09\"}        ����;�t�uɳ�uɳ����������������{\"topic\":\"crcland_security\",\"dev_ip\":\"10.73.242.4\",\"message\":\"<190>Apr 29 2022 19:32:18 USG6300E--���ϻ������� %%01POLICY/6/POLICYDENY(l):vsys=public, protocol=6, source-ip=10.73.242.26, source-port=59935, destination-ip=192.168.55.20, destination-port=3306, time=2022/4/29 19:32:18, source-zone=trust, destination-zone=untrust, application-name=, rule-name=��Σ�˿�.\\u0000\",\"type\":\"udp\",\"timestamp\":\"2022-04-29 19:31:09\"}        ��P߲�u���u������������������{\"topic\":\"crcland_security\",\"dev_ip\":\"10.73.242.4\"";
        json = DataProcessFuncation.parse(msgx,"index");
        JsonUtils.printStr(json);
    }
}
