package com.crc.log.flink.common.entity;

import lombok.Data;

/**
 * 集团网段对象 tb_segement_info
 *
 * @author wst
 * @date 2021-04-09
 */
@Data
public class TbSegementInfo {
    String segment;
    String name;
    String firstUnitName;
    String secondUnitName;
    String areaName;
    String subAreaName;
    String affiliationDeptName;
}
