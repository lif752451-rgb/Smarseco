package com.crc.log.flink.test.log;

import com.crc.log.flink.common.utils.JsonUtils;
import com.crc.log.flink.config.AllConfig;
import com.crc.log.flink.es.DataProcessFuncation;

import java.util.concurrent.ConcurrentHashMap;

/**
 * @author jixiangqi
 * @date 2022/1/13
 */
public class ResolvTrxEDRLogTest {

    public static void main(String[] args) {


        AllConfig config = new AllConfig();
        DataProcessFuncation.CONIFG = config;
        config.setMode("single");
        config.setParse("ResolvTrxEDRLog");
        config.setIndex("sec_all");

        String str = "defense_type=\"virus\" detail_cmdline=\"\"C:\\Windows\\rundl132.exe\" \" detail_treatment=\"2\" fid=\"2\" time=\"1642042039\" client_id=\"D0D2A778-CD8D-2C8D-2982-A7FEE33DC323\" detail_parent_cmd=\"C:\\Windows\\Explorer.EXE\" detail_virus_type=\"BEHAV:Ransom\" hostname=\"口腔科4-23\" version_dbtime=\"1639015343\" client_ip=\"192.168.4.23\" detail_file_path=\"C:\\Windows\\rundl132.exe\" detail_virus_name=\"Rattrap.A\" fname=\"behavior\" person=\"云桌面\" tenancy_id=\"5f4dafa565bc280718f1dab4\" virus_name=\"Rattrap.A\" virus_type=\"BEHAV:Ransom\" detail_threats=\"1\" group_name=\"云桌面\" version_product=\"1.0.15.0\"";
        ConcurrentHashMap<String, Object> json = DataProcessFuncation.parse(str, "index");
        JsonUtils.printStr(json);

        str = "defense_type=\"network\" detail_blocked=\"1\" detail_proc_path=\"System\" detail_protocol=\"6\" hostname=\"USER-PC\" tenancy_id=\"5f4dafa565bc280718f1dab4\" version_product=\"1.0.15.0\" detail_icmp_code=\"0\" detail_icmp_type=\"0\" detail_laddr=\"10.101.100.51\" detail_lport=\"445\" fname=\"instrusion\" group_name=\"门诊检验科\" person=\"192.168.3.36\" time=\"1642042414\" client_id=\"E1681699-E068-6A5B-B1EE-3B3BE0364F85\" client_ip=\"192.168.3.36\" detail_outbound=\"0\" detail_raddr=\"10.101.100.50\" detail_rport=\"58291\" detail_cmdline=\"\" detail_name=\"Exploit/EternalBlue\" detail_parent_cmd=\"\" fid=\"30\" version_dbtime=\"1641521937\"";
        json = DataProcessFuncation.parse(str, "index");
        JsonUtils.printStr(json);

        str = "version_product=\"1.0.15.0\" detail_err=\"0\" group_name=\"云桌面\" hostname=\"口腔科4-46\" detail_auto=\"1\" detail_merged_err=\"0\" detail_timestamp=\"1642041220\" detail_newversion_dbtime=\"1641521937\" detail_newversion_product=\"1.0.15.0\" fname=\"update\" tenancy_id=\"5f4dafa565bc280718f1dab4\" time=\"1642041127\" client_id=\"D0CF251F-0316-B106-9779-DB2B07A2B42B\" client_ip=\"192.168.4.46\" detail_merged_timestamp=\"1642041220\" fid=\"18\" person=\"云桌面\" version_dbtime=\"1641521937\" defense_type=\"other\" detail_errmsg=\"\" detail_merged_dstfn=\"C:\\Program Files\\Topsec\\ESEndpoint\\bin\\libvxf.tdl\"";
        json = DataProcessFuncation.parse(str, "index");
        JsonUtils.printStr(json);

        str = "detail_newversion_dbtime=\"1641521937\" detail_newversion_product=\"1.0.15.0\" detail_timestamp=\"1642041220\" fname=\"update\" group_name=\"云桌面\" time=\"1642041127\" detail_fetched_err=\"0\" detail_fetched_url=\"bases/libvxf.tdl.vfs\" version_dbtime=\"1641521937\" hostname=\"口腔科4-46\" person=\"云桌面\" detail_errmsg=\"\" fid=\"18\" client_ip=\"192.168.4.46\" detail_err=\"0\" detail_auto=\"1\" detail_fetched_dstfn=\"C:\\Program Files\\Topsec\\ESEndpoint\\bin\\libvxf.tdl\" detail_fetched_timestamp=\"1642041219\" tenancy_id=\"5f4dafa565bc280718f1dab4\" version_product=\"1.0.15.0\" client_id=\"D0CF251F-0316-B106-9779-DB2B07A2B42B\" defense_type=\"other\"\n";
        json = DataProcessFuncation.parse(str, "index");
        JsonUtils.printStr(json);

        str = "detail_timestamp=\"1642041220\" group_name=\"云桌面\" time=\"1642041127\" version_product=\"1.0.15.0\" detail_fetched_timestamp=\"1642041219\" detail_newversion_dbtime=\"1641521937\" detail_newversion_product=\"1.0.15.0\" fname=\"update\" person=\"云桌面\" tenancy_id=\"5f4dafa565bc280718f1dab4\" detail_err=\"0\" detail_fetched_dstfn=\"C:\\ProgramData\\Topsec\\ESEndpoint\\\\virdb\\pset.db\" detail_fetched_err=\"0\" fid=\"18\" client_ip=\"192.168.4.46\" defense_type=\"other\" detail_fetched_url=\"bases/pset.db.vfs\" hostname=\"口腔科4-46\" version_dbtime=\"1641521937\" client_id=\"D0CF251F-0316-B106-9779-DB2B07A2B42B\" detail_auto=\"1\" detail_errmsg=\"\"";
        json = DataProcessFuncation.parse(str, "index");
        JsonUtils.printStr(json);
    }

}
