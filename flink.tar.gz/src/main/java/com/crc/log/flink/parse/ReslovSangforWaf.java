package com.crc.log.flink.parse;

import com.alibaba.fastjson.JSONObject;
import com.crc.log.flink.common.constants.LevelConstants;
import com.crc.log.flink.common.constants.LogConstants;
import com.crc.log.flink.common.utils.DataUtils;
import com.crc.log.flink.common.utils.JsonUtils;
import com.crc.log.flink.common.utils.MapUtils;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;

import java.util.concurrent.ConcurrentHashMap;

//深信服Waf解析类
@Slf4j
public class ReslovSangforWaf {
    public static ConcurrentHashMap<String, Object> parse(String message) {
        try {
            ConcurrentHashMap<String, Object> data = proc(message);
            if (DataUtils.isNotEmptyJson(data)) {
                return data;
            }
        } catch (Exception ignored) {

        }
        return null;
    }

    private static ConcurrentHashMap<String, Object> proc(String value) {
        ConcurrentHashMap<String, Object> ldapJson = JsonUtils.createBaseMap(value);
        try {
            JSONObject dataJson = new JSONObject();
            String jsonStr = value;

            int index =  DataUtils.getIndex(jsonStr, "fwlog:");
            if (index == -1) {
                return ldapJson;
            }
            jsonStr = DataUtils.getSubString(jsonStr, index + "fwlog:".length() + 1);
            String[] IPS_buff = DataUtils.getSplit(jsonStr, ",");
            for (String s : IPS_buff) {
                String[] datakey = DataUtils.getSplit2(s, ":");
                //IPS_buff[i].split(":");
                if (1 < datakey.length) {
                    dataJson.put(datakey[0].trim(), datakey[1].trim());
                }
            }
            //retData.putAll(dataJson);
            ldapJson.put(LogConstants.LOG_PRODUCT, "深信服WAF");
            if (StringUtils.isNotBlank(jsonStr)) {
                MapUtils.setStr(ldapJson, LogConstants.OP_NAME, dataJson, "用户");
                MapUtils.setStr(ldapJson, LogConstants.LOG_DESCRIPTION, dataJson, "描述");
                MapUtils.setStr(ldapJson, LogConstants.LOG_TYPE, dataJson, "日志类型");
                MapUtils.setStr(ldapJson, LogConstants.LOG_NAME, dataJson, "策略名称");
                MapUtils.setStr(ldapJson, LogConstants.EVENT_ID, dataJson, "特征ID");
                MapUtils.setStr(ldapJson, LogConstants.SRC_IP, dataJson, "源IP");
                MapUtils.setStr(ldapJson, LogConstants.SRC_PORT, dataJson, "源端口");
                MapUtils.setStr(ldapJson, LogConstants.DEST_IP, dataJson, "目的IP");
                MapUtils.setStr(ldapJson, LogConstants.DEST_PORT, dataJson, "目的端口");
                MapUtils.setStr(ldapJson, LogConstants.ACTION_TYPE, dataJson, "攻击类型");
                MapUtils.setStr(ldapJson, LogConstants.LOG_LEVEL, dataJson, "严重级别");
                MapUtils.setStr(ldapJson, LogConstants.LOG_LEVEL, dataJson, "严重等级");
                MapUtils.setStr(ldapJson, LogConstants.NET_SCOPE, dataJson, "攻击方向");
                MapUtils.setStr(ldapJson, LogConstants.ACTION_RESULT, dataJson, "系统动作");
                MapUtils.setStr(ldapJson, LogConstants.LOG_URL, dataJson, "URL");
            }
            ldapJson.put(LogConstants.LOG_LEVEL, LevelConstants.getLevel(MapUtils.getStr(ldapJson,LogConstants.LOG_LEVEL)));
            if (StringUtils.isBlank(MapUtils.getStr(ldapJson, LogConstants.SRC_IP))) {
                ldapJson.put(LogConstants.SRC_IP, "0.0.0.0");
            }
            if (StringUtils.isBlank(MapUtils.getStr(ldapJson, LogConstants.DEST_IP))) {
                ldapJson.put(LogConstants.DEST_IP, "0.0.0.0");
            }
            setAlertName(ldapJson);
            return ldapJson;
        } catch (Exception e) {
            log.error(e.getMessage(), e);
            return ldapJson;
        }
    }

    public static void setAlertName(ConcurrentHashMap<String, Object> resultJson) {
        try {
            String messageFormat = "源IP为:%s对目的IP为:%s发起了攻击类型为:%s的攻击,事件级别:%s,事件类型为:%s,攻击结果:%s,url:%s,原始日志为:%s";
            String srcIp = MapUtils.getStr(resultJson, LogConstants.SRC_IP);
            String destIp = MapUtils.getStr(resultJson, LogConstants.DEST_IP);
            String type = MapUtils.getStr(resultJson, LogConstants.ACTION_TYPE);
            String level = MapUtils.getStr(resultJson, LogConstants.LOG_LEVEL);
            String event = MapUtils.getStr(resultJson, LogConstants.LOG_TYPE);
            String result = MapUtils.getStr(resultJson, LogConstants.ACTION_RESULT);
            String url = MapUtils.getStr(resultJson, LogConstants.LOG_URL);
            String log = MapUtils.getStr(resultJson, LogConstants.LOG_ORI_MSG);
            if (StringUtils.isBlank(srcIp)) {
                srcIp = MapUtils.getStr(resultJson, LogConstants.HOST_NAME);
            }
            String alertName = String.format(messageFormat, srcIp, destIp, type, level, event, result, url,log);
            if ("0.0.0.0".equals(destIp)) {
                messageFormat = "源IP为:%s发起了一个攻击类型为:%s的攻击,事件级别:%s,事件类型为:%s,攻击结果:%s,url:%s,原始日志为:%s";
                alertName = String.format(messageFormat, srcIp, type, level, event, result, url, log);
            }
            resultJson.put(LogConstants.ALERT_NAME, alertName);
        } catch (Exception e) {
            log.error(e.getMessage(),e);
        }
    }

}

