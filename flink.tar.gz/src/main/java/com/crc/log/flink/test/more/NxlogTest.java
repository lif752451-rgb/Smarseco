package com.crc.log.flink.test.more;

import com.crc.log.flink.common.utils.JsonUtils;
import com.crc.log.flink.config.AllConfig;
import com.crc.log.flink.es.DataProcessFuncation;

import java.util.concurrent.ConcurrentHashMap;

public class NxlogTest
{
    public static void main(String[] args) {
        String msgx = "devid=\"3\" dname=\"安全管理区-核心-fw1\" serial=\"2ad74cb29071417edec272cc848c670ff7e86f21\" module=\"flow\" severity=\"info\" vsys=\"root-vsys\" type=\"traffic-end\" session_id=\"5603844\" time=\"1684206662\" duration=\"120\" addr_src=\"10.3.3.3\" addr_dst=\"100.100.1.13\" nataddr_src=\"::\" nataddr_dst=\"::\" port_src=\"45329\" port_dst=\"514\" natport_src=\"0\" natport_dst=\"0\" action=\"permit\" appname=\"SystemLog\" rule=\"any_to_any\" proto=\"UDP\" session_time=\"7447\" sess_nth=\"0\" sess_dev_id=\"0\" zone_src=\"l2trust\" zone_dst=\"l2untrust\" locale_src=\"内网\" locale_dst=\"\" user_src=\"\" user_dst=\"\" app_category=\"APP_NETWORK\" app_risk=\"2\" asset_os_src=\"\" asset_os_dst=\"\" asset_name_src=\"\" asset_name_dst=\"\" asset_type_src=\"\" asset_type_dst=\"\" focus_type=\"NO\" profile=\"\" non_standard_port=\"NO\" interface_src=\"s1xg1\" interface_dst=\"s1xg2\" bytes_sent=\"1968\" bytes_received=\"0\" pkts_sent=\"1\" pkts_received=\"0\" total_sess=\"0\" from_tunnel=\"\" to_tunnel=\"\" honeypot_rule_name=\"\" honeypot_drainage_type=\"\"";
        //msgx = "<6>May 16 11:12:40 DAS-Gateway;530001400122042735006578;ipv4;3; policy_detail: src_ip=10.2.23.208;dst_ip=1.2.3.4;protocol=UDP;src_port=55797;dst_port=61182;in_interface=xge2;out_interface=xge2;policyid=8;action=permit;Content=\"POLICY*: The packet pass because the firewall policy is permit\"\n";
        msgx = "\"NGTOS\" \"V3.2294.30110_NGFW.1\" \"2023-05-16 11:10:07\" \"大数据公司出口防火墙\" \"6\" \"访问控制\" \"ac\" \"1050\" \"0\" vsys_name=\"root_vsys\" policyid=\"17981\" policyname=\"permit_all\" protoname=\"UDP\" src=\"10.3.17.87\" sport=\"45297\" dst=\"180.76.76.76\" dport=\"53\" action=\"允许\" appname=\"DNS\" user=\"10.3.17.87\" ";
        msgx = "<5>time=2023-05-17 10:15:07;log_type=ips;danger_degree=1;breaking_sighn=0;event=[50562]HTTP 服务认证弱口令登录;src_addr=10.123.132.25;src_port=65485;dst_addr=10.181.107.193;dst_port=7443;user=null;smt_user=null;proto=HTTP;";
        AllConfig config = new AllConfig();
        DataProcessFuncation.CONIFG = config;
        config.setMode("single");
        config.setParse("ReslovNxlogSysLog");
        config.setIndex("sec_all");

        ConcurrentHashMap<String, Object> json = DataProcessFuncation.parse(msgx,"index");
        JsonUtils.printStr(json);
    }
}
