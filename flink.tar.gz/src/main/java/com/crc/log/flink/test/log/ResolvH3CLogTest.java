package com.crc.log.flink.test.log;

import com.crc.log.flink.common.utils.JsonUtils;
import com.crc.log.flink.config.AllConfig;
import com.crc.log.flink.es.DataProcessFuncation;

import java.util.concurrent.ConcurrentHashMap;

/**
 * @author jixiangqi
 * @date 2022/3/9
 */
public class ResolvH3CLogTest {

    public static void main(String[] args) {
        AllConfig config = new AllConfig();
        DataProcessFuncation.CONIFG = config;
        config.setMode("single");
        config.setParse("ResolvH3CLog");
        config.setIndex("sec_all");

        String str = "<188>2022-03-09 04:13:04 D185247DMFWHW98 %%01ATK/4/FIREWALLATCK(l):AttackType=\"Ip sweep attack\", slot=\" \", cpu=\"0\", receive interface=\"GE1/0/2 \", proto=\"TCP\", ip=\"121.36.68.1:37104->203.84.25.122:6379\", begin time=2022/03/09 12:12:42 , end time=2022/03/09 12:12:42 , total packets=\"1\", max speed=\"10000\", Action=\"discard\".";
        ConcurrentHashMap<String, Object> proc = DataProcessFuncation.parse(str, "index");
        JsonUtils.printStr(proc);

        str = "<188>2022-03-09 07:18:05 D185247DMFWHW98 %%01ATK/4/FIREWALLATCK(l):AttackType=\"IP spoof attack\", slot=\" \", cpu=\"0\", receive interface=\"Vlanif2002 GE1/0/2 Vlanif2002 GE1/0/2 Vlanif255 GE1/0/2 \", proto=\"TCP\", ip=\"2.0.1.99:53847->10.0.1.36:80; 10.53.1.37:53314->203.84.1.248:445; 2.0.1.1:58149->10.0.76.11:443; 192.168.0.103:60792->203.161.4.14:443; 192.168.77.16:64778->203.84.19.177:445; 168.143.143.38:34396->10.128.63.97:25; 172.19.2.144:26431->203.84.5.66:445; 192.168.0.178:58780->203.161.4.14:443\", begin time=2022/03/09 15:17:36 , end time=2022/03/09 15:18:05 , total packets=\"20\", max speed=\"0\", Action=\"discard\".";
        proc = DataProcessFuncation.parse(str, "index");
        JsonUtils.printStr(proc);

        str = "<188>2022-03-09 07:18:05 D185247DMFWHW98 %%01ATK/4/FIREWALLATCK(l):AttackType=\"Tcp flag attack\", slot=\" \", cpu=\"0\", receive interface=\"GE1/0/2 \", proto=\"TCP\", ip=\"1.116.89.251:53424->203.84.4.38:3032\", begin time=2022/03/09 15:17:38 , end time=2022/03/09 15:17:38 , total packets=\"1\", max speed=\"0\", Action=\"discard\".";
        proc = DataProcessFuncation.parse(str, "index");
        JsonUtils.printStr(proc);

        str = "<190>Mar  9 15:15:52 2022 D166021ZJRTHC022 %%10SHELL/6/SHELL_CMD: -DevIP=192.200.0.22; -Line=vty0-IPAddr=10.0.89.146-User=zabbix; Command is ping -a 192.168.24.9 192.168.24.10";
        proc = DataProcessFuncation.parse(str, "index");
        JsonUtils.printStr(proc);
    }
}
