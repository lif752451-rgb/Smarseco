package com.crc.log.flink.test.log;

import com.crc.log.flink.common.utils.JsonUtils;
import com.crc.log.flink.config.AllConfig;
import com.crc.log.flink.es.DataProcessFuncation;

import java.util.concurrent.ConcurrentHashMap;

/**
 * @author jixiangqi
 * @date 2022/1/4
 */
public class ReslovMicrosoftATALogTest {

    public static void main(String[] args) {
        AllConfig config = new AllConfig();
        DataProcessFuncation.CONIFG = config;
        config.setMode("single");
        config.setParse("ReslovMicrosoftATALog");
        config.setIndex("sec_all");


        String str = "<36>1 2021-12-30T04:50:48.403754+00:00 ZBATA-CENTER ATA 3548 DnsReconnaissanceSuspiciousActiv CEF:0| Microsoft| ATA| 1.9.7312.32791| DnsReconnaissanceSuspiciousActivity|" +
                "Reconnaissance using DNS|" +
                "5|" +
                "start=2021-12-30T04:49:02.9405819Z " +
                "app=Dns shost=CRL-HBTS-DC02 " +
                "msg=Suspicious DNS activity was observed, originating from CRL-HBTS-DC02 (which is not a DNS server) against ROOT-DC01. " +
                "externalId=2007" +
                " cs1Label=url" +
                " cs1=https://zbata-center.crland.hk/suspiciousActivity/61cd3aa8992f690ddcac4b54";
        ConcurrentHashMap<String, Object> proc = DataProcessFuncation.parse(str,"index");
        JsonUtils.printStr(proc);


        str = "<116>1 2021-12-29T03:46:57.541934+00:00 ZBATA-CENTER ATA 3548 GatewayLowMemoryMonitoringAlert CEF:0|" +
                "Microsoft|" +
                "ATA|" +
                "1.9.7312.32791|" +
                "GatewayLowMemoryMonitoringAlert|" +
                "GatewayLowMemoryMonitoringAlert|" +
                "5|" +
                "externalId=1019 " +
                "cs1Label=url " +
                "cs1=https://zbata-center.crland.hk/monitoring" +
                " msg=The Lightweight Gateway, ZB-DC01, stopped itself and will restart automatically to protect the domain controller from a low memory condition";
        proc = DataProcessFuncation.parse(str,"index");
        JsonUtils.printStr(proc);

        str = "<35>1 2022-01-12T04:10:46.006977+00:00 ZBATA-CENTER ATA 3548 PassTheTicketSuspiciousActivity \uFEFFCEF:0|Microsoft|ATA|1.9.7312.32791|PassTheTicketSuspiciousActivity|Identity theft using Pass-the-Ticket attack|10|start=2022-01-12T01:53:51.1519156Z app=Kerberos suser=张志愿 msg=张志愿's Kerberos tickets were stolen from HBQD-YYGL-ZZY-N to 10.218.177.78 and used to access cifs/crl-qdkf-dc03.crland.hk/crland.hk. externalId=2018 cs1Label=url cs1=https://zbata-center.crland.hk/suspiciousActivity/61de353c992f690ddccf4007";
        proc = DataProcessFuncation.parse(str,"index");
        JsonUtils.printStr(proc);
    }

}
