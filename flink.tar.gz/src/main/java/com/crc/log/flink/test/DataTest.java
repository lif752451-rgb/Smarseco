package com.crc.log.flink.test;

import com.crc.log.flink.common.utils.DataUtils;

public class DataTest {
    public static void main(String[] args) {
        System.out.println(DataUtils.isNumeric("111"));
        System.out.println(DataUtils.isNumeric("111a"));
    }
}
