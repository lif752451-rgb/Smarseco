package com.crc.log.flink.parse;

import com.crc.log.flink.common.constants.LevelConstants;
import com.crc.log.flink.common.constants.LogConstants;
import com.crc.log.flink.common.utils.DataUtils;
import com.crc.log.flink.common.utils.IPUtil;
import com.crc.log.flink.common.utils.JsonUtils;
import com.crc.log.flink.common.utils.MapUtils;
import org.apache.commons.lang3.StringUtils;

import java.util.concurrent.ConcurrentHashMap;

/**
 * @author jixiangqi
 * @date 2022/1/11
 * 盈高准入
 */
public class ResolvYingGaoAdmittanceLog {
    public static ConcurrentHashMap<String, Object> parse(String message) {
        try {
            ConcurrentHashMap<String, Object> data = proc(message);
            if (DataUtils.isNotEmptyJson(data)) {
                return data;
            }
        } catch (Exception ignored) {

        }
        return null;
    }

    private static ConcurrentHashMap<String, Object> proc(String jsonStr) {
        ConcurrentHashMap<String, Object> rtnObjc = JsonUtils.createBaseMap(jsonStr);
        jsonStr = findThirdColon(jsonStr);
        String[] split = DataUtils.getSplit(jsonStr, ",");
                //jsonStr.split(",");
        for (String temp : split) {
            int index = DataUtils.getIndex(temp, ":");
            //split[i].indexOf(":");
            String key = DataUtils.getSubString(temp, 0, index).trim();
            //split[i].substring(0, index).trim();
            String value = "";
            if (key.equals("content") && index != -1) {
                value = DataUtils.getSubString(temp, index + 8).trim();
                //split[i].substring(index+8).trim();
            } else {
                value = DataUtils.getSubString(temp, index + 1).trim();
                //split[i].substring(index+1).trim();
            }
            switchKeyValue(rtnObjc, key, value);
        }
        rtnObjc.put(LogConstants.LOG_LEVEL, LevelConstants.getLevel(MapUtils.getStr(rtnObjc,LogConstants.LOG_LEVEL)));
        if (StringUtils.isBlank(MapUtils.getStr(rtnObjc, LogConstants.SRC_IP))) {
            rtnObjc.put(LogConstants.SRC_IP, "0.0.0.0");
        }
        if (StringUtils.isBlank(MapUtils.getStr(rtnObjc, LogConstants.DEST_IP))) {
            rtnObjc.put(LogConstants.DEST_IP, "0.0.0.0");
        }
        setAlertName(rtnObjc);
        rtnObjc.put(LogConstants.LOG_PRODUCT, "赢高准入");
        return rtnObjc;
    }

    private static void setAlertName(ConcurrentHashMap<String, Object> rtnObjc) {
        String msgFormat = "";
        String alertName = "";
        String level = MapUtils.getStr(rtnObjc, LogConstants.LOG_LEVEL);
        String srcIp = MapUtils.getStr(rtnObjc, LogConstants.SRC_IP);
        String destIp = MapUtils.getStr(rtnObjc, LogConstants.DEST_IP);
        String srcMac = MapUtils.getStr(rtnObjc, LogConstants.SRC_MAC);
        String destMac = MapUtils.getStr(rtnObjc, LogConstants.DEST_MAC);
        String log = MapUtils.getStr(rtnObjc, LogConstants.LOG_ORI_MSG);
        if (srcIp.equals("0.0.0.0") || destIp.equals("0.0.0.0")) {
            msgFormat = "源MAC为:%s对目的MAC为:%s发起了一个攻击,事件级别为:%s,日志详情为:%s";
            alertName = String.format(msgFormat, srcMac, destMac, level, log);
        } else {
            msgFormat = "源IP为:%s对目的IP为:%s发起了一个攻击,事件级别为:%s,日志详情为:%s";
            alertName = String.format(msgFormat, srcIp, destIp, level, log);
        }
        rtnObjc.put(LogConstants.ALERT_NAME, alertName);
    }

    private static void switchKeyValue(ConcurrentHashMap<String, Object> rtnObjc, String key, String value) {
        switch (key) {
            case "level":
                rtnObjc.put(LogConstants.LOG_LEVEL, value);
                break;
            case "devid":
                rtnObjc.put(LogConstants.DEVICE_ID, value);
                break;
            case "devip":
                rtnObjc.put(LogConstants.LOG_DEV_IP, value);
                break;
            case "devname":
                rtnObjc.put(LogConstants.DEVICE_NAME, value);
                break;
            case "content":
                int index = DataUtils.getIndex(value, "MAC");
                        //value.indexOf("MAC");
                if (index != -1) {
                    String content = DataUtils.getSubString(value, 0, index);
                    String IP = DataUtils.getSubString(value, index+4, value.length() - 2);
                    rtnObjc.put(LogConstants.LOG_CONTENT, content);
                    String[] split = DataUtils.getSplit(IP, "/");
                            //IP.split("/");
                    if (split.length == 2) {
                        String srcIpMac = split[0];
                        if (srcIpMac.contains("-")) {
                            String[] IpMac = DataUtils.getSplit(srcIpMac, "-");
                                    //srcIpMac.split("-");
                            if (IpMac.length == 2) {
                                rtnObjc.put(LogConstants.SRC_MAC, IpMac[0]);
                                rtnObjc.put(LogConstants.SRC_IP, IpMac[1]);
                            } else if (IpMac.length == 1) {
                                if (IPUtil.isIp(IpMac[0])) {
                                    rtnObjc.put(LogConstants.SRC_IP, IpMac[0]);
                                } else {
                                    rtnObjc.put(LogConstants.SRC_MAC, IpMac[0]);
                                }
                            }
                        }
                        String destIpMac = split[0];
                        if (destIpMac.contains("-")) {
                            String[] IpMac = DataUtils.getSplit(destIpMac, "-");
                                    //destIpMac.split("-");
                            if (IpMac.length == 2) {
                                rtnObjc.put(LogConstants.DEST_MAC, IpMac[0]);
                                rtnObjc.put(LogConstants.DEST_IP, IpMac[1]);
                            } else if (IpMac.length == 1) {
                                if (IPUtil.isIp(IpMac[0])) {
                                    rtnObjc.put(LogConstants.DEST_IP, IpMac[0]);
                                } else {
                                    rtnObjc.put(LogConstants.DEST_MAC, IpMac[0]);
                                }
                            }
                        }
                    }
                    break;
                }
        }
    }

    private static String findThirdColon(String jsonStr) {
        int count = 0;
        int index = 0;
        while (count != 3) {
            index = DataUtils.getIndex(jsonStr, ":");
                    //jsonStr.indexOf(":");
            if (index != -1) {
                jsonStr = DataUtils.getSubString(jsonStr, index+1).trim();
                //jsonStr.substring(index+1).trim();
                count++;
            } else {
                return "";
            }

        }
        return jsonStr;
    }

}
