package com.crc.log.flink.parse;

import com.crc.log.flink.common.constants.LevelConstants;
import com.crc.log.flink.common.constants.LogConstants;
import com.crc.log.flink.common.utils.DataUtils;
import com.crc.log.flink.common.utils.DateUtils;
import com.crc.log.flink.common.utils.JsonUtils;
import com.crc.log.flink.common.utils.MapUtils;
import org.apache.commons.lang3.StringUtils;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.LinkedList;
import java.util.List;
import java.util.concurrent.ConcurrentHashMap;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * @author jixiangqi
 * @date 2022/1/13
 * TSA
 */
public class ResolvTSALog {
    static SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");

    public static ConcurrentHashMap<String, Object> parse(String message) {
        try {
            ConcurrentHashMap<String, Object> data = proc(message);
            if (DataUtils.isNotEmptyJson(data)) {
                return data;
            }
        } catch (Exception ignored) {

        }
        return null;
    }

    private static ConcurrentHashMap<String, Object> proc(String jsonStr) {
        ConcurrentHashMap<String, Object> rtnObjc = JsonUtils.createBaseMap(jsonStr);
        List<String> strings = getValueBySpace(jsonStr);
        strings.forEach(str -> {
            String[] split = DataUtils.getSplit(str, ",");
            for (String tempStr : split) {
                if (tempStr.contains(":")) {
                    int index = DataUtils.getIndex(tempStr, ":");
                    String key = DataUtils.getSubString(tempStr, 0, index).replaceAll("\"", "");
                    String value = DataUtils.getSubString(tempStr, index + 1).replaceAll("\"", "");
                    switchKeyValue(rtnObjc, key, value);
                }
            }
        });
        rtnObjc.put(LogConstants.LOG_PRODUCT, "科来TSA");
        rtnObjc.put(LogConstants.LOG_LEVEL, LevelConstants.getLevel(MapUtils.getStr(rtnObjc,LogConstants.LOG_LEVEL)));
        if (StringUtils.isBlank(MapUtils.getStr(rtnObjc, LogConstants.SRC_IP))) {
            rtnObjc.put(LogConstants.SRC_IP, "0.0.0.0");
        }
        if (StringUtils.isBlank(MapUtils.getStr(rtnObjc, LogConstants.DEST_IP))) {
            rtnObjc.put(LogConstants.DEST_IP, "0.0.0.0");
        }
        setAlertName(rtnObjc);
        return  rtnObjc;
    }

    private static void setAlertName(ConcurrentHashMap<String,Object> rtnObjc) {
        String logType = MapUtils.getStr(rtnObjc, LogConstants.LOG_TYPE);
        String message = "";
        String alertName = "";
        if (logType.equals("ALARM")) {
            String srcIp = MapUtils.getStr(rtnObjc, LogConstants.SRC_IP);
            String destIp = MapUtils.getStr(rtnObjc, LogConstants.DEST_IP);
            String logdesc = MapUtils.getStr(rtnObjc, LogConstants.LOG_DESCRIPTION);
            String logName = MapUtils.getStr(rtnObjc, LogConstants.LOG_NAME);
            String threadType = MapUtils.getStr(rtnObjc, LogConstants.THREAT_TYPE);
            String proto = MapUtils.getStr(rtnObjc, LogConstants.LOG_PROTOCAL);
            message = "IP地址为:%s对IP地址为:%s产生了一个告警事件,告警描述为:%s,告警名称为:%s,告警规则为:%s,访问协议为:%s";
            alertName = String.format(message, srcIp, destIp, logdesc, logName, threadType, proto);
        }
        rtnObjc.put(LogConstants.ALERT_NAME, alertName);
    }


    private static void switchKeyValue(ConcurrentHashMap<String, Object> rtnObjc, String key, String value) {
        switch (key) {
            case "log_type":
                rtnObjc.put(LogConstants.LOG_TYPE, value);
                break;
            case "host_name":
                rtnObjc.put(LogConstants.HOST_NAME, value);
                break;
            case "client_ip_addr":
                rtnObjc.put(LogConstants.SRC_IP, value);
                break;
            case "client_port":
                rtnObjc.put(LogConstants.SRC_PORT, value);
                break;
            case "server_ip_addr":
                rtnObjc.put(LogConstants.DEST_IP, value);
                break;
            case "server_port":
                rtnObjc.put(LogConstants.DEST_PORT, value);
                break;
            case "app":
                rtnObjc.put(LogConstants.DEVICE_ID, value);
                break;
            case "protocol":
                rtnObjc.put(LogConstants.LOG_PROTOCAL, value);
                break;
            case "src_mac":
                rtnObjc.put(LogConstants.SRC_MAC, value);
                break;
            case "src_ip_addr":
                rtnObjc.put(LogConstants.SRC_IP, value);
                break;
            case "dst_ip_addr":
                rtnObjc.put(LogConstants.DEST_IP, value);
                break;
            case "dst_mac":
                rtnObjc.put(LogConstants.DEST_MAC, value);
                break;
            case "ip_protocol":
                String protoType = "";
                switch (value) {
                    case "1":
                        protoType = "ICMP";
                        break;
                    case "2":
                        protoType = "IGMP";
                        break;
                    case "6":
                        protoType = "TCP";
                        break;
                    case "8":
                        protoType = "EGP";
                        break;
                    case "9":
                        protoType = "IGP";
                        break;
                    case "17":
                        protoType = "UDP";
                        break;
                    case "41":
                        protoType = "IPv6";
                        break;
                    case "47":
                        protoType = "GRE";
                        break;
                    case "50":
                        protoType = "ESP";
                        break;
                    case "51":
                        protoType = "AH";
                        break;
                    case "88":
                        protoType = "EIGRP";
                        break;
                    case "89":
                        protoType = "OSPF";
                        break;
                    case "112":
                        protoType = "VRRP";
                        break;
                    case "115":
                        protoType = "L2TP";
                        break;
                    case "803":
                        protoType = "DNS";
                        break;
                }
                rtnObjc.put(LogConstants.LOG_PROTOCAL, protoType);
                break;
            case "alarm_type":
                String type = "";
                String s = "0x"+ Integer.toHexString(4194304);
                switch (s) {
                    case "0xFFFFF":
                        type = "流量警报";
                        break;
                    case "0x100000":
                        type = "可疑域名警报";
                        break;
                    case "0x200000":
                        type = "邮件敏感字警报";
                        break;
                    case "0x400000":
                        type = "数据流特征警报";
                        break;
                    case "0x800000":
                        type = "可疑IP警报";
                        break;
                    case "0x2000000L":
                        type = "违规访问警报";
                        break;
                    case "0x1000000L":
                        type = "Web攻击警报";
                        break;
                    case "0x4000000L":
                        type = "威胁情报警报";
                        break;
                    case "0x8000000L":
                        type = "瑞星病毒库警报";
                        break;
                    case "0x10000000L":
                        type = "YARA警报";
                        break;
                    case "0x20000000L":
                        type = "MODBUS规则警报";
                        break;
                    case "0x40000000L":
                        type = "HTTP规则警报";
                        break;
                }
                rtnObjc.put(LogConstants.THREAT_TYPE, type);
                break;
            case "alarm_level":
                String level = "";
                switch (value) {
                    case "1":
                        level = LevelConstants.HIGH;
                        break;
                    case "2":
                        level = LevelConstants.MEDIUM;
                        break;
                    case "4":
                        level = LevelConstants.LOW;
                        break;
                }
                rtnObjc.put(LogConstants.LOG_PROTOCAL, level);
                break;
            case "name":
                rtnObjc.put(LogConstants.LOG_NAME, value);
                break;
            case "ws_req_url":
                rtnObjc.put(LogConstants.LOG_URL, value);
                break;
            case "originalfilename":
                rtnObjc.put(LogConstants.LOG_FILENAME, value);
                break;
            case "alertname":
                rtnObjc.put(LogConstants.VIRUS_NAME, value);
                break;
            case "alerttype":
                rtnObjc.put(LogConstants.VIRUS_TYPE, value);
                break;
            case "mail_sender":
                rtnObjc.put(LogConstants.EMAIL_SEND, value);
                break;
            case "mail_recipient":
                rtnObjc.put(LogConstants.EMAIL_RECEIVER, value);
                break;
            case "ioc_filter_handle_desc":
                rtnObjc.put(LogConstants.ACTION_TYPE, value);
                break;
            case "statTime":
                rtnObjc.put(LogConstants.LOG_START_TIME, value);
                break;
            case "behavior_desc":
                rtnObjc.put(LogConstants.LOG_DESCRIPTION, value);
                break;
            case "behavior_name":
                rtnObjc.put(LogConstants.LOG_NAME, value);
                break;
            case "behavior_type":
                String behaviorType = "";
                switch (value) {
                    case "0":
                        behaviorType = "单例行为模型";
                        break;
                    case "1":
                        behaviorType = "多例行为模型";
                        break;
                    case "2":
                        behaviorType = "计数行为模型";
                        break;
                }
                rtnObjc.put(LogConstants.ACTION_TYPE, behaviorType);
                break;
            case "category":
                rtnObjc.put(LogConstants.LOG_DESCRIPTION, value);
                break;
            case "real_stat_time":
                rtnObjc.put(LogConstants.LOG_START_TIME, DateUtils.getISO8601Timestamp(sdf.format(new Date(DataUtils.toNum(value) * 1000L)), "yyyy-MM-dd HH:mm:ss"));
                break;
            case "behavior_srcip":
                rtnObjc.put(LogConstants.SRC_IP, value);
                break;
            case "behavior_dstip":
                rtnObjc.put(LogConstants.DEST_IP, value);
                break;
            case "behavior_level":
                rtnObjc.put(LogConstants.LOG_LEVEL, LevelConstants.getLevel(value));
                break;
            case "behavior_category":
                rtnObjc.put(LogConstants.VIRUS_TYPE, value);
                break;
            case "rule_name":
                rtnObjc.put(LogConstants.RULE_NAME, value);
                break;
            case "rule_type":
                rtnObjc.put(LogConstants.RULE_TYPE, value);
                break;
            case "inner_ip":
                rtnObjc.put(LogConstants.SRC_IP, value);
                break;
            case "outer_ip":
                rtnObjc.put(LogConstants.DEST_IP, value);
                break;
            case "inner_port":
                rtnObjc.put(LogConstants.SRC_PORT, value);
                break;
            case "outer_port":
                rtnObjc.put(LogConstants.DEST_PORT, value);
                break;
            case "l4_protocol":
                rtnObjc.put(LogConstants.LOG_PROTOCAL, value);
                break;
            case "trigger_time":
                rtnObjc.put(LogConstants.LOG_START_TIME, value);
                break;
            case "src_port":
                rtnObjc.put(LogConstants.SRC_PORT, value);
                break;
            case "dst_port":
                rtnObjc.put(LogConstants.DEST_PORT, value);
                break;
            case "answer_count":
                rtnObjc.put(LogConstants.LOG_COUNT, value);
                break;
            case "req_url":
                rtnObjc.put(LogConstants.LOG_URL, value);
                break;
            case "date":
                rtnObjc.put(LogConstants.LOG_START_TIME, value);
                break;
            case "sender":
                rtnObjc.put(LogConstants.EMAIL_SEND, value);
                break;
            case "recipients":
                rtnObjc.put(LogConstants.EMAIL_RECEIVER, value);
                break;
            case "cc":
                rtnObjc.put(LogConstants.EMAIL_CC, value);
                break;
            case "user":
                rtnObjc.put(LogConstants.USER_NAME, value);
                break;
            case "version":
                rtnObjc.put(LogConstants.LOG_VERSION, value);
                break;
            case "username":
                rtnObjc.put(LogConstants.USER_NAME, value);
                break;
            case "query_statement":
                rtnObjc.put(LogConstants.LOG_CONTENT, value);
                break;
            case "table":
                rtnObjc.put(LogConstants.SQL_TABLE, value);
                break;
            case "data":
                rtnObjc.put(LogConstants.LOG_CONTENT, value);
                break;
            case "failure_code":
                rtnObjc.put(LogConstants.ERROR_CODE, value);
                break;
            case "security_protocol":
                rtnObjc.put(LogConstants.LOG_PROTOCAL, value);
                break;
            case "command":
                rtnObjc.put(LogConstants.LOG_CONTENT, value);
                break;
            case "file_name":
                rtnObjc.put(LogConstants.LOG_FILENAME, value);
                break;
            case "account_name":
                rtnObjc.put(LogConstants.USER_NAME, value);
                break;
            case "native_os":
                rtnObjc.put(LogConstants.OS_INFO, value);
                break;
            case "cmd_desc":
                rtnObjc.put(LogConstants.LOG_DESCRIPTION, value);
                break;
            case "operate":
                rtnObjc.put(LogConstants.ACTION_TYPE, value);
                break;
            case "dst_host_ip":
                rtnObjc.put(LogConstants.DEST_IP, value);
                break;
            case "dst_host_port":
                rtnObjc.put(LogConstants.DEST_PORT, value);
                break;
            case "cert_version":
                rtnObjc.put(LogConstants.LOG_VERSION, value);
                break;
            case "host":
                rtnObjc.put(LogConstants.HOST_NAME, value);
                break;
            case "url":
                rtnObjc.put(LogConstants.LOG_URL, value);
                break;
            case "sql_statement":
                rtnObjc.put(LogConstants.SQL, value);
                break;
            case "banner":
                rtnObjc.put(LogConstants.LOG_VERSION, value);
                break;
            case "top_protocol":
                rtnObjc.put(LogConstants.LOG_PROTOCAL, value);
                break;
            case "mail_from":
                rtnObjc.put(LogConstants.EMAIL_SEND, value);
                break;
            case "mail_to":
                rtnObjc.put(LogConstants.EMAIL_RECEIVER, value);
                break;
            case "mail_cc":
                rtnObjc.put(LogConstants.EMAIL_CC, value);
                break;
        }
    }


    private static List<String> getValueBySpace(String jsonStr) {
        Pattern p = Pattern.compile("\\{([^\\}]+)\\}");
        Matcher m = p.matcher(jsonStr);
        List<String> dataList = new LinkedList<>();
        while (m.find()) {
            try {
                String data = m.group().substring(1, m.group().length() - 1);
                dataList.add(data);
            } catch (Exception ignored) {

            }
        }
        return dataList;
    }

}
