package com.crc.log.flink.test;

import com.alibaba.fastjson.JSONObject;
import com.crc.log.flink.common.constants.LogConstants;
import com.crc.log.flink.common.utils.DataUtils;
import com.crc.log.flink.common.utils.JsonUtils;
import com.crc.log.flink.common.utils.RegUtils;

public class RegTest {
    public static void main(String[] args) {
        String ip = "4444 ";
        System.out.println(RegUtils.getNumber(ip));

        JSONObject msg = new JSONObject();
        msg.put(LogConstants.DEST_PORT,"122 ");
        if (msg.containsKey(LogConstants.DEST_PORT)) {
            msg.put(LogConstants.DEST_PORT, RegUtils.getNumber(JsonUtils.getStr(msg, LogConstants.DEST_PORT)));
        }
        if (msg.containsKey(LogConstants.SRC_PORT)) {
            msg.put(LogConstants.SRC_PORT, RegUtils.getNumber(JsonUtils.getStr(msg, LogConstants.SRC_PORT)));
        }
        System.out.println(msg.toJSONString());
    }

    public static void mainc() {
        String ipStr = "10.20.1.1";
        boolean isLegal = isLegal(ipStr);
        if (isLegal) {
            System.out.println("合法");
        } else
            System.out.println("非法");
    }

    public static boolean isLegal(String ipStr) {
        if (ipStr == null)
            return false;
        if (ipStr.length() < 7 || ipStr.length() > 15)
            return false;
        if (ipStr.charAt(0) == '.' || ipStr.charAt(ipStr.length() - 1) == '.')
            return false;
        String[] arr = ipStr.split("\\.");
        if (arr.length != 4)
            return false;
        for (String s : arr)
            for (int j = 0; j < s.length(); j++) {
                if (s.charAt(j) < '0' || s.charAt(j) > '9')
                    return false;
            }
        for (int i = 0; i < arr.length; i++) {
            int temp = DataUtils.toNum(arr[i]);
            if (i == 0) {
                if (temp < 1 || temp > 255)
                    return false;
            } else if (i == 3) {
                if (temp < 1 || temp > 255)
                    return false;
            } else {
                if (temp < 0 || temp > 255)
                    return false;
            }
        }
        return true;
    }
}


