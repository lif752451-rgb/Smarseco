package com.crc.log.flink.test;

import com.alibaba.fastjson.JSONObject;
import com.crc.log.flink.common.utils.DataUtils;

public class IpsTest {
    public static void main(String[] args) {
        JSONObject jsonObject = new JSONObject();
        jsonObject.put("1", "1");
        System.out.println(DataUtils.isNotEmptyJson(jsonObject));
    }
}
