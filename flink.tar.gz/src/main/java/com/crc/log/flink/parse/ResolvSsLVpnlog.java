package com.crc.log.flink.parse;

import com.alibaba.fastjson.JSONObject;
import com.crc.log.flink.common.constants.ActionResultConstants;
import com.crc.log.flink.common.constants.LevelConstants;
import com.crc.log.flink.common.constants.LogConstants;
import com.crc.log.flink.common.utils.*;
import org.apache.commons.lang3.StringUtils;

import java.util.Date;
import java.util.List;
import java.util.concurrent.ConcurrentHashMap;

/**
 * 深信服VPN日志解析
 */
public class ResolvSsLVpnlog {
    /**
     * SSL VPN 日志泛化
     */
    public static ConcurrentHashMap<String, Object> parse(String message) {
        try {
            ConcurrentHashMap<String, Object> data = proc(message);
            if (DataUtils.isNotEmptyJson(data)) {
                return data;
            }
        } catch (Exception ignored) {

        }
        return null;
    }

    private static ConcurrentHashMap<String, Object> proc(String jsonStr) {
        ConcurrentHashMap<String, Object> rtnObjc = JsonUtils.createBaseMap(jsonStr);
        //访问资源日志处理

        if (DataUtils.getIndex(jsonStr, "<7>[") >= 0) {
            if (jsonStr.contains("access resource")) {
                parseAccessResourceJson(jsonStr, rtnObjc);
                setAlertName(rtnObjc);
                rtnObjc.put(LogConstants.LOG_PRODUCT, "深信服VPN");
                return rtnObjc;
            } else if (jsonStr.contains("logout") || jsonStr.contains("login") || jsonStr.contains("send sms")) {
                parseLoginJson(jsonStr, rtnObjc);
                setAlertName(rtnObjc);
                rtnObjc.put(LogConstants.LOG_PRODUCT, "深信服VPN");
                return rtnObjc;
            }
        } else if (DataUtils.getIndex(jsonStr, "<23>[") >= 0) {
            if (jsonStr.contains("MDM")) {
                parseMDMJson(jsonStr, rtnObjc);
                setAlertName(rtnObjc);
            } else if (jsonStr.contains("SSL VPN") && jsonStr.contains("logout")) {
                parseSSNVpnJson(jsonStr, rtnObjc);
                setAlertName(rtnObjc);
                rtnObjc.put(LogConstants.LOG_PRODUCT, "深信服VPN");
                return rtnObjc;
            } else {
                rtnObjc.put(LogConstants.MSG_CONTENT, jsonStr);
                setAlertName(rtnObjc);
            }
        } else if (DataUtils.getIndex(jsonStr, "<173>") >= 0) {
            //新版VPN日志
            JSONObject xJson = ResolvHoneyLog.getMsgContent(jsonStr);
            MapUtils.setStr(rtnObjc,LogConstants.OP_NAME, JsonUtils.getJsonValue(xJson,"userInfo.userName"));
            MapUtils.setStr(rtnObjc,"group",JsonUtils.getJsonValue(xJson,"userInfo.groupPath"));
            MapUtils.setStr(rtnObjc,LogConstants.SRC_IP,JsonUtils.getJsonValue(xJson,"clientInfo.ip"));
            MapUtils.setStr(rtnObjc,LogConstants.EXTERNAL_IP,JsonUtils.getJsonValue(xJson,"clientInfo.vip"));
            MapUtils.setStr(rtnObjc,LogConstants.OS_INFO,JsonUtils.getJsonValue(xJson,"clientInfo.osType"));
            MapUtils.setStr(rtnObjc,LogConstants.DEST_IP,JsonUtils.getJsonValue(xJson,"rcip"));
            String type = JsonUtils.getJsonValue(xJson,"logSubType");
            switch (type) {
                case "access_resource":
                    rtnObjc.put(LogConstants.LOG_NAME, "资源访问日志");
                    break;
                case "login":
                    rtnObjc.put(LogConstants.LOG_NAME, "登录日志");
                    break;
                case "logout":
                    rtnObjc.put(LogConstants.LOG_NAME, "登出日志");
                    break;
            }
            //MapUtils.setStr(rtnObjc,LogConstants.LOG_NAME,MapUtils.getJsonValue(xJson,"logSubType").equals("access_resource")?"登入登出日志":MapUtils.getJsonValue(xJson,"logSubType"));
            MapUtils.setStr(rtnObjc,LogConstants.ACTION_TYPE,JsonUtils.getJsonValue(xJson,"type"));
            MapUtils.setStr(rtnObjc,LogConstants.ALERT_NAME,JsonUtils.getJsonValue(xJson,"msg"));
            MapUtils.setStr(rtnObjc,LogConstants.ACTION_RESULT,JsonUtils.getJsonValue(xJson,"actionResult"));
        }
        rtnObjc.put(LogConstants.LOG_PRODUCT, "深信服VPN");
        rtnObjc.put(LogConstants.LOG_LEVEL, LevelConstants.getLevel(MapUtils.getStr(rtnObjc,LogConstants.LOG_LEVEL)));
        if (StringUtils.isBlank(MapUtils.getStr(rtnObjc, LogConstants.SRC_IP))) {
            rtnObjc.put(LogConstants.SRC_IP, "0.0.0.0");
        }
        if (StringUtils.isBlank(MapUtils.getStr(rtnObjc, LogConstants.DEST_IP))) {
            rtnObjc.put(LogConstants.DEST_IP, "0.0.0.0");
        }
        return rtnObjc;
    }


    public static void parseMDMJson(String jsonStr, ConcurrentHashMap<String, Object> rtnObjc) {
        rtnObjc.put(LogConstants.LOG_NAME, "VPN系统心跳日志");
        rtnObjc.put(LogConstants.MSG_CONTENT, jsonStr);
        rtnObjc.put(LogConstants.LOG_START_TIME, DateUtils.getISO8601Timestamp(new Date()));
    }

    public static void parseAccessResourceJson(String jsonStr, ConcurrentHashMap<String, Object> rtnObjc) {
        String reg = "<(\\d+)>\\[(.*?)\\]\\[(.*?)\\](\\w*) from IP (\\d{1,3}.\\d{1,3}.\\d{1,3}.\\d{1,3}): access (\\d{1,3}.\\d{1,3}.\\d{1,3}.\\d{1,3}):(\\d+) (\\w*)?";
        List<String> dataList = RegUtils.getData(jsonStr, reg);
        MapUtils.setStr(rtnObjc, LogConstants.LOG_NAME, "访问资源");
        paserBaseVpnJson(rtnObjc, dataList);
        MapUtils.setStr(rtnObjc, LogConstants.LOG_PROTOCAL, DataUtils.getListString(dataList, 3));
        MapUtils.setStr(rtnObjc, LogConstants.SRC_IP, DataUtils.getListString(dataList, 5));
        MapUtils.setStr(rtnObjc, LogConstants.DEST_IP, DataUtils.getListString(dataList, 6));
        MapUtils.setStr(rtnObjc, LogConstants.DEST_PORT, DataUtils.getListString(dataList, 7));
        String ret = DataUtils.getListString(dataList, 8);
        String actionResult = "success".equalsIgnoreCase(ret) ? ActionResultConstants.ATTACK_SUCCUSS :
                ("failure".equalsIgnoreCase(ret) ? ActionResultConstants.ATTACK_FAIL : ActionResultConstants.UNKNOWN);
        MapUtils.setStr(rtnObjc, LogConstants.ACTION_RESULT, actionResult);
        rtnObjc.put(LogConstants.LOG_LEVEL, LevelConstants.INFO);
        rtnObjc.put(LogConstants.LOG_START_TIME, DateUtils.getISO8601Timestamp(new Date()));
    }

    public static void parseLoginJson(String jsonStr, ConcurrentHashMap<String, Object> rtnObjc) {
        String reg = "<(\\d+)>\\[(logout|login|send sms)\\]\\[(success|failure|illegal)\\](\\w*) from IP (\\d{1,3}.\\d{1,3}.\\d{1,3}.\\d{1,3}): (.*$)";
        List<String> dataList = RegUtils.getData(jsonStr, reg);
        rtnObjc.put(LogConstants.LOG_NAME, "用户登录");
        if (jsonStr.contains("logout")) {
            rtnObjc.put(LogConstants.LOG_NAME, "用户登出");
        } else if (jsonStr.contains("send sms")) {
            rtnObjc.put(LogConstants.LOG_NAME, "发送短信");
        }
        paserBaseVpnJson(rtnObjc, dataList);
        MapUtils.setStr(rtnObjc, LogConstants.ACTION_RESULT, DataUtils.getListString(dataList, 3));
        MapUtils.setStr(rtnObjc, LogConstants.SRC_IP, DataUtils.getListString(dataList, 5));
        MapUtils.setStr(rtnObjc, LogConstants.MSG_CONTENT, DataUtils.getListString(dataList, 6));
        rtnObjc.put(LogConstants.LOG_LEVEL, LevelConstants.INFO);
        rtnObjc.put(LogConstants.LOG_START_TIME, DateUtils.getISO8601Timestamp(new Date()));
        String ret = DataUtils.getListString(dataList, 3);
        String actionResult = "success".equalsIgnoreCase(ret) ? ActionResultConstants.ATTACK_SUCCUSS :
                ("failure".equalsIgnoreCase(ret) ? ActionResultConstants.ATTACK_FAIL : ActionResultConstants.UNKNOWN);
        MapUtils.setStr(rtnObjc, LogConstants.ACTION_RESULT, actionResult);
    }

    public static void paserBaseVpnJson(ConcurrentHashMap<String, Object> rtnObjc, List<String> dataList) {
        MapUtils.setStr(rtnObjc, LogConstants.EVENT_ID, DataUtils.getListString(dataList, 1));
        MapUtils.setStr(rtnObjc, LogConstants.ACTION_TYPE, DataUtils.getListString(dataList, 2));
        MapUtils.setStr(rtnObjc, LogConstants.OP_NAME, DataUtils.getListString(dataList, 4));

    }

    public static void parseSSNVpnJson(String jsonStr, ConcurrentHashMap<String, Object> rtnObjc) {
        String reg = "<(\\d+)>\\[(SSL VPN)\\]\\[(MOD_TWF)\\] User (\\w*) (\\w*) (\\w*),ip address: (\\d{1,3}.\\d{1,3}.\\d{1,3}.\\d{1,3}),(.*$)";
        List<String> dataList = RegUtils.getData(jsonStr, reg);
        rtnObjc.put(LogConstants.LOG_NAME, "登出日志");
        paserBaseVpnJson(rtnObjc, dataList);
        MapUtils.setStr(rtnObjc, LogConstants.LOG_PROTOCAL, DataUtils.getListString(dataList, 3));
        MapUtils.setStr(rtnObjc, LogConstants.ACTION_TYPE, DataUtils.getListString(dataList, 5));
        MapUtils.setStr(rtnObjc, LogConstants.ACTION_RESULT, DataUtils.getListString(dataList, 6));
        MapUtils.setStr(rtnObjc, LogConstants.SRC_IP, DataUtils.getListString(dataList, 7));
        MapUtils.setStr(rtnObjc, LogConstants.MSG_CONTENT, DataUtils.getListString(dataList, 8));

        rtnObjc.put(LogConstants.LOG_LEVEL, LevelConstants.INFO);
        rtnObjc.put(LogConstants.LOG_START_TIME, DateUtils.getISO8601Timestamp(new Date()));
    }

    public static void setAlertName(ConcurrentHashMap<String, Object> resultJson) {
        if (StringUtils.isBlank(MapUtils.getStr(resultJson, LogConstants.SRC_IP))) {
            resultJson.put(LogConstants.SRC_IP, "0.0.0.0");
        }
        if (StringUtils.isBlank(MapUtils.getStr(resultJson, LogConstants.DEST_IP))) {
            resultJson.put(LogConstants.DEST_IP, "0.0.0.0");
        }
        String logName = MapUtils.getStr(resultJson, LogConstants.LOG_NAME);
        String actionRule = MapUtils.getStr(resultJson, LogConstants.ACTION_RESULT);
        String log = MapUtils.getStr(resultJson, LogConstants.LOG_ORI_MSG);
        String messageFormat = "%s-%s,日志详情为:%s";
        String alertName = String.format(messageFormat, logName, actionRule, log);
        resultJson.put(LogConstants.ALERT_NAME, alertName);
    }
}
