package com.crc.log.flink.common.utils;

import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;

import java.math.BigInteger;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

@Slf4j
public class IPUtil {

    private static final String IPV4_REGEX =
            "^(\\d{1,3})\\.(\\d{1,3})\\.(\\d{1,3})\\.(\\d{1,3})$";
    private static final Pattern IPv4_PATTERN = Pattern.compile(IPV4_REGEX);

    private static final String ALL_IP_REG = "((2[0-4]\\d|25[0-5]|[01]?\\d\\d?)\\.){3}(2[0-4]\\d|25[0-5]|[01]?\\d\\d?)";

    private static final Pattern ALL_IP_PATTERN = Pattern.compile(ALL_IP_REG);
    public static final long a1 = getIp2long("10.0.0.0");
    public static final long a2 = getIp2long("10.255.255.255");
    public static final long b1 = getIp2long("172.16.0.0");
    public static final long b2 = getIp2long("172.31.255.255");
    public static final long c1 = getIp2long("192.168.0.0");
    public static final long c2 = getIp2long("192.168.255.255");
    public static String[] getIpSegment(String segment) {
        if (StringUtils.isBlank(segment)) {
            return null;
        }
        segment = segment.replace(" ", "").replace(",", "\n").replace("\t", "").replaceAll(" ", "\n");
        return segment.split("\n");
    }
    /**
     * 是否内部IP
     *
     * @param ip IP
     * @return T/F
     */
    public static boolean isInnerIP(String ip) {
        if (ip == null) {
            return false;
        }
        long n = getIp2long(ip);
        return !((n < a1 || n > a2) && (n < b1 || n > b2) && (n < c1 || n > c2));
    }


    public static long getIp2long(String ipaddress) {
        if (!isIp(ipaddress)) {
            return 0;
        }
        try {
            BigInteger data = IpConvert.StringToBigInt(ipaddress);
            return data.longValue();
        } catch (Exception ignored) {

        }
        return 0;
    }

    public static boolean isIp(String ipStr) {
        if (ipStr == null) {
            return false;
        }
        if (isIpv4(ipStr)) {
            return true;
        } else {
            return isIpv6(ipStr);
        }
    }


    public static boolean isIpv4(String ip) {
        if (ip == null || ip.trim().isEmpty()) {
            return false;
        }
        if (!IPv4_PATTERN.matcher(ip).matches()) {
            return false;
        }
        String[] parts = ip.split("\\.");
        try {
            for (String segment : parts) {
                if (Integer.parseInt(segment) > 255 ||
                        (segment.length() > 1 && segment.startsWith("0"))) {
                    return false;
                }
            }
        } catch (Exception e) {
            return false;
        }
        return true;
    }

    /**
     * Is ipv 6 boolean.
     */
    public static boolean isIpv6(String ipv6) {
        if (StringUtils.isBlank(ipv6)) {
            return false;
        }
        // 8*4 位数字，加上七个: ipv6地址长度不可能超过39位
        if (ipv6.length() > 39) {
            return false;
        }
        if (ipv6.endsWith(":") && !ipv6.endsWith("::")) {
            return false;
        }
        //如果包含多个“::”，一个IPv6地址中只能出现一个“::”
        if (ipv6.contains("::") && ipv6.indexOf("::", ipv6.indexOf("::") + 2) != -1) {
            return false;
        }

        //ipv6“::”
        String[] arr = ipv6.split(":");
        if (ipv6.contains("::")) {
            if (arr.length > 7 || arr.length < 1) {//"1::"是最短的字符串
                return false;
            }
            for (String s : arr) {
                if (s.equals("")) {
                    continue;
                }
                if (s.length() > 4) {
                    return false;
                }
                for (int j = 0; j < s.length(); j++) {
                    if ((s.charAt(j) >= '0' && s.charAt(j) <= '9') || (s.charAt(j) >= 'A' && s.charAt(j) <= 'F')
                            || (s.charAt(j) >= 'a' && s.charAt(j) <= 'f')) {
                        continue;
                    }
                    return false;
                }
            }
        } else {//如果不含有“::”
            if (arr.length != 8) {
                return false;
            }
            for (String s : arr) {
                if (s.length() > 4) {
                    return false;
                }
                for (int j = 0; j < s.length(); j++) {
                    if ((s.charAt(j) >= '0' && s.charAt(j) <= '9') || (s.charAt(j) >= 'A' && s.charAt(j) <= 'F')
                            || (s.charAt(j) >= 'a' && s.charAt(j) <= 'f')) {
                        continue;
                    }
                    return false;
                }
            }
        }
        return true;
    }


    public static List<String> getIpFromStr(String str) {
        if (str == null) {
            return new ArrayList<>();
        }
        String regEx = "((2[0-4]\\d|25[0-5]|[01]?\\d\\d?)\\.){3}(2[0-4]\\d|25[0-5]|[01]?\\d\\d?)";
        List<String> ips = new ArrayList<String>();
        Pattern p = Pattern.compile(regEx);
        Matcher m = p.matcher(str);
        while (m.find()) {
            String result = m.group();
            ips.add(result);
        }
        return ips;
    }

    public static Map<String, List<String>> getIpAndPortFromStr(String str) {
        if (str == null) {
            return new HashMap<>();
        }
        Map<String, List<String>> resultMap = new HashMap<>();
        Pattern p = Pattern.compile("(\\d+\\.\\d+\\.\\d+\\.\\d+)\\:(\\d+)");
        Matcher m = p.matcher(str);
        List<String> ips = new ArrayList<String>();
        List<String> ports = new ArrayList<String>();
        while (m.find()) {
            ips.add(m.group(1));
            ports.add(m.group(2));
        }
        resultMap.put("ip", ips);
        resultMap.put("port", ports);
        return resultMap;
    }

    public static List<String> getIps(String ipString) {
        if (ipString == null) {
            return new ArrayList<>();
        }
        List<String> ips = new ArrayList<String>();
        try {
            Matcher m = ALL_IP_PATTERN.matcher(ipString);
            while (m.find()) {
                ips.add(m.group());
            }
        } catch (Exception e) {
            log.error(e.getMessage(), e);
        }
        return ips;
    }


    public static String getIpsX(String ipString) {
        if (ipString == null) {
            return "";
        }
        String IP_REG = "((2[0-4]\\d|25[0-5]|[01]?\\d\\d?)\\.){3}(2[0-4]\\d|25[0-5]|[01]?\\d\\d?)";
        try {
            Pattern p = Pattern.compile(IP_REG);
            Matcher m = p.matcher(ipString);
            while (m.find()) {
                String ip = m.group();
                if (isIp(ip)) {
                    return ip;
                }
            }
        } catch (Exception e) {
            log.error(e.getMessage(), e);
        }
        return "";
    }
}
