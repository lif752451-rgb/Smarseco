package com.crc.log.flink.test.log;

import com.crc.log.flink.common.utils.JsonUtils;
import com.crc.log.flink.config.AllConfig;
import com.crc.log.flink.es.DataProcessFuncation;

import java.util.concurrent.ConcurrentHashMap;

/**
 * @author jixiangqi
 * @date 2022/1/12
 */
public class ResolvYingGaoAdmittanceLogTest {

    public static void main(String[] args) {
        AllConfig config = new AllConfig();
        DataProcessFuncation.CONIFG = config;
        config.setMode("single");
        config.setParse("ResolvYingGaoAdmittanceLog");
        config.setIndex("sec_all");

        String str = "<176>Jan 11 04:37:47 asm processor_server: classid:202, level:3, devid:1263, devip:192.168.202.202, devname:, content:�ڽ�����[192.168.202.202:GigabitEthernet0/0/13]����[2]��MAC[38:91:D5:97:65:E0-/38:91:D5:97:E3:C0-/]";
        ConcurrentHashMap<String, Object> proc = DataProcessFuncation.parse(str, "index");
        JsonUtils.printStr(proc);

        str = "<176>Jan 11 04:48:07 asm processor_server: classid:202, level:3, devid:1263, devip:192.168.202.202, devname:, content:�ڽ�����[192.168.202.202:GigabitEthernet0/0/24]����[2]��MAC[90:23:B4:10:37:02-172.16.254.16/38:91:D5:B2:BD:A0-172.16.254.36/]";
        proc = DataProcessFuncation.parse(str, "index");
        JsonUtils.printStr(proc);
    }

}
