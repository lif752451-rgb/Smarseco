package com.crc.log.flink.test.log;

import com.crc.log.flink.common.utils.JsonUtils;
import com.crc.log.flink.config.AllConfig;
import com.crc.log.flink.es.DataProcessFuncation;

import java.util.concurrent.ConcurrentHashMap;

/**
 * @author jixiangqi
 * @date 2022/5/13
 */
public class ResolvLvMengADSLogTest {

    public static void main(String[] args) {
        AllConfig config = new AllConfig();
        DataProcessFuncation.CONIFG = config;
        config.setMode("single");
        config.setParse("ResolvLvMengADSLog");
        config.setIndex("sec_all");


        String str = "<133>logtype=trafficalert;status=0;event_type=HTTPS Flood;level=low;dstip=21.9.254.57;zone_lable=;pps=pps=4381;bps=bps=5649224\n";
        ConcurrentHashMap<String, Object> proc = DataProcessFuncation.parse(str,"index");
        JsonUtils.printStr(proc);

        str = "Action: 2007-06-11 07:45:41|远程协助服务|启动远程协助服务|221.225.1.161|admin";
        proc = DataProcessFuncation.parse(str,"index");
        JsonUtils.printStr(proc);
    }

}
