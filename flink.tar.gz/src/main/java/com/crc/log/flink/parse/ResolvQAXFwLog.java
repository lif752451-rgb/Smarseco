package com.crc.log.flink.parse;

import com.alibaba.fastjson.JSONObject;
import com.crc.log.flink.common.constants.LevelConstants;
import com.crc.log.flink.common.constants.LogConstants;
import com.crc.log.flink.common.utils.DataUtils;
import com.crc.log.flink.common.utils.JsonUtils;
import com.crc.log.flink.common.utils.MapUtils;
import org.apache.commons.lang3.StringUtils;

import java.util.concurrent.ConcurrentHashMap;

/**
 * 奇安信防火墙集管解析类
 */
public class ResolvQAXFwLog {

    /**
     * 通用日志 日志泛化
     */
    public static ConcurrentHashMap<String, Object> parse(String message) {
        try {
            ConcurrentHashMap<String, Object> data = proc(message);
            if (DataUtils.isNotEmptyJson(data)) {
                return data;
            }
        } catch (Exception ignored) {

        }
        return null;
    }

    private static ConcurrentHashMap<String, Object> proc(String value) {
        ConcurrentHashMap<String, Object> ldapJson = JsonUtils.createBaseMap(value);

        JSONObject dataJson = new JSONObject();

        String[] IPS_buff = DataUtils.getSplit(value, " ");
        //jsonStr.split(" ");
        for (String s : IPS_buff) {
            String[] datakey = DataUtils.getSplit(s, "=");
            //IPS_buff[i].split("=");
            if (1 < datakey.length) {
                if (datakey[1].contains("\"")) {
                    dataJson.put(datakey[0], datakey[1].replaceAll("\"", ""));
                } else {
                    dataJson.put(datakey[0], datakey[1]);
                }
            }
        }

        ldapJson.put(LogConstants.LOG_PRODUCT, "奇安信防火墙集管");
        if (dataJson.get("type") != null && dataJson.get("type").equals("threat")) {
            MapUtils.setStr(ldapJson, LogConstants.LOG_LEVEL, dataJson, "severity");
            MapUtils.setStr(ldapJson, LogConstants.OP_NAME, dataJson, "appname");
            MapUtils.setStr(ldapJson, LogConstants.SRC_IP, dataJson, "addr_src");
            MapUtils.setStr(ldapJson, LogConstants.DEST_IP, dataJson, "addr_dst");
            MapUtils.setStr(ldapJson, LogConstants.ALERT_NAME, dataJson, "threat_name");
            ldapJson.put(LogConstants.MSG_CONTENT, value);
        } else if (dataJson.get("type") != null && dataJson.get("type").equals("system")) {
            MapUtils.setStr(ldapJson, LogConstants.LOG_LEVEL, dataJson, "severity");
        }
        ldapJson.put(LogConstants.MSG_CONTENT, value);
        ldapJson.put(LogConstants.ALERT_NAME, value);
        ldapJson.put(LogConstants.LOG_LEVEL, LevelConstants.getLevel(MapUtils.getStr(ldapJson,LogConstants.LOG_LEVEL)));
        if (StringUtils.isBlank(MapUtils.getStr(ldapJson, LogConstants.SRC_IP))) {
            ldapJson.put(LogConstants.SRC_IP, "0.0.0.0");
        }
        if (StringUtils.isBlank(MapUtils.getStr(ldapJson, LogConstants.DEST_IP))) {
            ldapJson.put(LogConstants.DEST_IP, "0.0.0.0");
        }
        return ldapJson;
    }

}
