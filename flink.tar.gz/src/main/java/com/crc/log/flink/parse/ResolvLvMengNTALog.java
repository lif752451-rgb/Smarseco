package com.crc.log.flink.parse;

import com.crc.log.flink.common.constants.LevelConstants;
import com.crc.log.flink.common.constants.LogConstants;
import com.crc.log.flink.common.utils.DataUtils;
import com.crc.log.flink.common.utils.DateUtils;
import com.crc.log.flink.common.utils.JsonUtils;
import com.crc.log.flink.common.utils.MapUtils;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;

import java.text.SimpleDateFormat;
import java.util.HashMap;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

/**
 * @author jixiangqi
 * @date 2022/4/29
 * 绿盟NTA
 */
@Slf4j
public class ResolvLvMengNTALog {

    static SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ssXXX");
    public static ConcurrentHashMap<String, Object> parse(String message) {
        try {
            ConcurrentHashMap<String, Object> data = proc(message);
            if (DataUtils.isNotEmptyJson(data)) {
                return data;
            }
        } catch (Exception ignored) {

        }
        return null;
    }

    private static ConcurrentHashMap<String, Object> proc(String jsonStr) {
        ConcurrentHashMap<String, Object> rtnObjc = JsonUtils.createBaseMap(jsonStr);
        int index = com.crc.log.flink.common.utils.StringUtils.stringSubIndexTwo(jsonStr, '>', 1);
        jsonStr = DataUtils.getSubString(jsonStr, index+1);
        Map<String, String> stringMap = getKeyValue(jsonStr);
        stringMap.forEach((k, v) -> {
            switchKeyValue(rtnObjc, k.trim(), v.trim());
        });
        if (StringUtils.isBlank(MapUtils.getStr(rtnObjc, LogConstants.LOG_LEVEL))) {
            rtnObjc.put(LogConstants.LOG_LEVEL, LevelConstants.getLevel(MapUtils.getStr(rtnObjc,LogConstants.LOG_LEVEL)));
        }
        if (StringUtils.isBlank(MapUtils.getStr(rtnObjc, LogConstants.SRC_IP))) {
            rtnObjc.put(LogConstants.SRC_IP, "0.0.0.0");
        }
        if (StringUtils.isBlank(MapUtils.getStr(rtnObjc, LogConstants.DEST_IP))) {
            rtnObjc.put(LogConstants.DEST_IP, "0.0.0.0");
        }
        rtnObjc.put(LogConstants.LOG_PRODUCT, "绿盟NTA");
        setAlertName(rtnObjc);
        return rtnObjc;
    }

    private static void setAlertName(ConcurrentHashMap<String, Object> rtnObjc) {
        String logType = MapUtils.getStr(rtnObjc, LogConstants.LOG_TYPE);
        String logLevel = MapUtils.getStr(rtnObjc, LogConstants.LOG_LEVEL);
        String message = "";
        String alertName = "";
        switch (logType) {
            case "attackevent":
                String logName = MapUtils.getStr(rtnObjc, LogConstants.LOG_NAME);
                String actionResult = MapUtils.getStr(rtnObjc, LogConstants.ACTION_RESULT);
                String actionType = MapUtils.getStr(rtnObjc, LogConstants.ACTION_TYPE);
                String logdesc = MapUtils.getStr(rtnObjc, LogConstants.LOG_DESCRIPTION);
                String destIp = MapUtils.getStr(rtnObjc, LogConstants.DEST_IP);
                message = "IP为:%s的设备受到了%s的攻击,日志名称为:%s,日志描述为:%s,攻击方式为:%s,攻击结果为:%s,日志级别为:%s";
                alertName = String.format(message, destIp, logType, logName, logdesc, actionType, actionResult, logLevel);
                break;
            case "diverting":
                destIp = MapUtils.getStr(rtnObjc, LogConstants.DEST_IP);
                actionResult = MapUtils.getStr(rtnObjc, LogConstants.ACTION_RESULT);
                logdesc = MapUtils.getStr(rtnObjc, LogConstants.LOG_DESCRIPTION);
                message = "IP为:%s的设备受到了%s的攻击,日志描述为:%s,攻击结果为:%s,日志级别为:%s";
                alertName = String.format(message, destIp, logType, logdesc, actionResult, logLevel);
                break;
            case "audit":
                String userName = MapUtils.getStr(rtnObjc, LogConstants.USER_NAME);
                actionResult = MapUtils.getStr(rtnObjc, LogConstants.ACTION_RESULT);
                logdesc = MapUtils.getStr(rtnObjc, LogConstants.LOG_DESCRIPTION);
                String srcIp = MapUtils.getStr(rtnObjc, LogConstants.LOG_DEV_IP);
                message = "用户名为:%s在IP地址为:%s的设备上进行了%s操作,操作结果为:%s,日志描述为:%s,日志级别为:%s";
                alertName = String.format(message, userName, srcIp, logType, actionResult, logdesc, logLevel);
                break;
            case "running":
                logdesc = MapUtils.getStr(rtnObjc, LogConstants.LOG_DESCRIPTION);
                String devName = MapUtils.getStr(rtnObjc, LogConstants.DEVICE_NAME);
                message = "设备名称为:%s上产生了%s日志,日志描述为:%s,日志级别为:%s";
                alertName = String.format(message, devName, logType, logdesc, logLevel);
                break;
            case "fsdiverting":
                srcIp = MapUtils.getStr(rtnObjc, LogConstants.SRC_IP);
                destIp = MapUtils.getStr(rtnObjc, LogConstants.DEST_IP);
                actionResult = MapUtils.getStr(rtnObjc, LogConstants.ACTION_RESULT);
                actionType = MapUtils.getStr(rtnObjc, LogConstants.ACTION_TYPE);
                logdesc = MapUtils.getStr(rtnObjc, LogConstants.LOG_DESCRIPTION);
                message = "IP为:%s对IP为:%s产生了一个%s类型的日志,操作类型为:%s,操作结果为:%s,日志描述为:%s,日志级别为:%s";
                alertName = String.format(message, srcIp, destIp, logType, actionType, actionResult, logdesc, logLevel);
                break;
        }
        rtnObjc.put(LogConstants.ALERT_NAME, alertName);
    }


    private static void switchKeyValue(ConcurrentHashMap<String, Object> rtnObjc, String key, String value) {
        switch (key) {
            case "logtype":
                rtnObjc.put(LogConstants.LOG_TYPE, value);
                break;
            case "event_id":
                rtnObjc.put(LogConstants.EVENT_ID, value);
                break;
            case "datetime":
                try {
                    rtnObjc.put(LogConstants.LOG_START_TIME, DateUtils.getISO8601Timestamp(sdf.parse(value)));
                } catch (Exception e) {
                    log.error(e.getMessage(), e);
                }
                break;
            case "dstip":
                rtnObjc.put(LogConstants.DEST_IP, value);
                break;
            case "account":
                rtnObjc.put(LogConstants.USER_NAME, value);
                break;
            case "eventType":
                String name = "";
                switch (value) {
                    case "DDoS Attack Alert":
                        name = "DDos 流量事件";
                        break;
                    case "Region Traffic Alert":
                        name = "业务域流量告警";
                        break;
                    case "Group Traffic Alert":
                        name = "IP 组流量告警";
                        break;
                    case "Router Interface Bandwidth Alert":
                        name = "路由器接口带宽告警";
                        break;
                    case "Router Performance Alert":
                        name = "路由器性能告警";
                        break;
                    case "Custom Featured Traffic Alert":
                        name = "自定义特征告警";
                        break;
                    case "NTA System Performance Alert":
                        name = "NTA 自身性能告警";
                        break;
                    default:
                        name = value;
                }
                rtnObjc.put(LogConstants.LOG_NAME, name);
                break;
            case "severity":
                rtnObjc.put(LogConstants.LOG_LEVEL, LevelConstants.getLevel(value));
                break;
            case "description":
                rtnObjc.put(LogConstants.LOG_DESCRIPTION, value);
                break;
            case "attackDirection":
                rtnObjc.put(LogConstants.ACTION_TYPE, value);
                break;
            case "optype":
                rtnObjc.put(LogConstants.ACTION_RESULT, value);
                break;
            case "clientip":
                rtnObjc.put(LogConstants.LOG_DEV_IP, value);
                break;
            case "result":
                if (value.equals("1")) {
                    rtnObjc.put(LogConstants.ACTION_RESULT, "成功");
                } else if (value.equals("0")){
                    rtnObjc.put(LogConstants.ACTION_RESULT, "失败");
                }
                break;
            case "from":
                rtnObjc.put(LogConstants.DEVICE_NAME, value);
                break;
            case "sourceip":
                rtnObjc.put(LogConstants.SRC_IP, value);
                break;
            case "sourceport":
                rtnObjc.put(LogConstants.SRC_PORT, value);
                break;
            case "destinationip":
                rtnObjc.put(LogConstants.DEST_IP, value);
                break;
            case "destinationport":
                rtnObjc.put(LogConstants.DEST_PORT, value);
                break;
            case "action":
                String actionResult = "";
                switch (value) {
                    case "accept":
                        actionResult = "接收";
                        break;
                    case "discard":
                        actionResult = "丢弃";
                        break;
                    case "rate-limit":
                        actionResult = "限速";
                        break;
                    case "redirect":
                        actionResult = "重定向";
                        break;
                    case "traffic_marking":
                        actionResult = "标记 DSCP";
                        break;
                }
                rtnObjc.put(LogConstants.ACTION_RESULT, actionResult);
                break;
            case "msgoptype":
                String actionType = "";
                switch (value) {
                    case "add-success":
                        actionType = "添加牵引-OK";
                        break;
                    case "del-success":
                        actionType = "撤销牵引-OK";
                        break;
                    case "add-error":
                        actionType = "添加牵引-ERROR";
                        break;
                    case "del-error":
                        actionType = "撤销牵引-ERROR";
                        break;
                }
                rtnObjc.put(LogConstants.ACTION_TYPE, actionType);
                break;
            case "protocol":
                rtnObjc.put(LogConstants.LOG_PROTOCAL, value);
                break;
            case "status":
                String result = "";
                switch (value) {
                    case "starting":
                        result = "开始告警";
                        break;
                    case "holding":
                        result = "保持期";
                        break;
                    case "end":
                        result = "结束";
                        break;
                    case "alert":
                        result = "告警级别发生变化";
                        break;
                    case "resume":
                        result = "告警状态从保持期切换为正在持续";
                        break;
                }
                rtnObjc.put(LogConstants.ACTION_RESULT, result);
                break;
        }
    }

    private static Map<String, String> getKeyValue(String jsonStr) {
        Map<String, String> resultMap = new HashMap<>();
        String keyIndex = "";
        String[] split = DataUtils.getSplit(jsonStr, ";");
        for (String tempStr : split) {
            if (tempStr.contains("=")) {
                int index = DataUtils.getIndex(tempStr, "=");
                String key = DataUtils.getSubString(tempStr, 0, index).trim();
                String value = DataUtils.getSubString(tempStr, index + 1).trim();
                resultMap.put(key, value);
                keyIndex = key;
            } else {
                resultMap.put(keyIndex, resultMap.get(keyIndex) + ";" + tempStr);
            }
        }
        return  resultMap;
    }
}
