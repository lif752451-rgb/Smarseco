package com.crc.log.flink.test;

import com.crc.log.flink.common.utils.IPUtil;

public class IpTest {
    public static void main(String[] args) {
        System.out.println(IPUtil.getIps("127.0.0.1 129.0.0.1"));
    }
}
