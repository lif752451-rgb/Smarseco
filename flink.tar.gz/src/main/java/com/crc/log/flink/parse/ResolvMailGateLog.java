package com.crc.log.flink.parse;

import com.crc.log.flink.common.constants.LevelConstants;
import com.crc.log.flink.common.constants.LogConstants;
import com.crc.log.flink.common.utils.DataUtils;
import com.crc.log.flink.common.utils.IPUtil;
import com.crc.log.flink.common.utils.JsonUtils;
import com.crc.log.flink.common.utils.MapUtils;
import org.apache.commons.lang3.StringUtils;

import java.util.concurrent.ConcurrentHashMap;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class ResolvMailGateLog {
    /**
     * 通用日志 日志泛化
     */
    public static ConcurrentHashMap<String, Object> parse(String message) {
        try {
            ConcurrentHashMap<String, Object> data = proc(message);
            if (DataUtils.isNotEmptyJson(data)) {
                return data;
            }
        } catch (Exception ignored) {

        }
        return null;
    }

    private static ConcurrentHashMap<String, Object> proc(String jsonStr) {
        ConcurrentHashMap<String, Object> rtnObjc = JsonUtils.createBaseMap(jsonStr);
        rtnObjc.put(LogConstants.LOG_PRODUCT, "邮件网关");
        int index = DataUtils.getIndex(jsonStr, ":");
        int index1 = DataUtils.getIndex(jsonStr, "[");
        int index2 = DataUtils.getIndex(jsonStr, "]");
        String srcIp = DataUtils.getSubString(jsonStr, index1+1, index2);
        if (IPUtil.isIp(srcIp)) {
            rtnObjc.put(LogConstants.SRC_IP, srcIp);
        }
        String tempStr = DataUtils.getSubString(jsonStr, index+1, index1);
        rtnObjc.put(LogConstants.EMAIL_SEND, tempStr);
        jsonStr = DataUtils.getSubString(jsonStr, index1+1);
        if (jsonStr.contains("RECV")) {
            index = DataUtils.getIndex(jsonStr, "RECV");
            jsonStr = DataUtils.getSubString(jsonStr, "RECV".length() + index);
        } else if (jsonStr.contains("ENC")) {
            index = DataUtils.getIndex(jsonStr, "ENC");
            jsonStr = DataUtils.getSubString(jsonStr, "ENC".length() + index);
        } else if (jsonStr.contains("SCAN") && !jsonStr.contains("ENC")) {
            index = DataUtils.getIndex(jsonStr, "SCAN");
            jsonStr = DataUtils.getSubString(jsonStr, "SCAN".length() + index+2);
        }
        StringBuffer sb = new StringBuffer();
        String email = getEamilBySpace(jsonStr, sb);
        rtnObjc.put(LogConstants.EMAIL_RECEIVER, DataUtils.getSubString(email, 0, email.length()-1));
        rtnObjc.put(LogConstants.LOG_LEVEL, LevelConstants.getLevel(MapUtils.getStr(rtnObjc,LogConstants.LOG_LEVEL)));
        if (StringUtils.isBlank(MapUtils.getStr(rtnObjc, LogConstants.SRC_IP))) {
            rtnObjc.put(LogConstants.SRC_IP, "0.0.0.0");
        }
        if (StringUtils.isBlank(MapUtils.getStr(rtnObjc, LogConstants.DEST_IP))) {
            rtnObjc.put(LogConstants.DEST_IP, "0.0.0.0");
        }
        setAlertName(rtnObjc);
        return rtnObjc;
    }


    private static void setAlertName(ConcurrentHashMap<String, Object> rtnObjc) {
        String log = MapUtils.getStr(rtnObjc, LogConstants.LOG_ORI_MSG);
        String send = MapUtils.getStr(rtnObjc, LogConstants.EMAIL_SEND);
        String receiver = MapUtils.getStr(rtnObjc, LogConstants.EMAIL_RECEIVER);
        String srcIp = MapUtils.getStr(rtnObjc, LogConstants.SRC_IP);
        String message = "邮件网关设备中产生了一条告警日志,源IP为:%s,发送人为:%s,接收人为:%s,日志详情为:%s";
        String alertName = String.format(message,srcIp, send, receiver, log);
        rtnObjc.put(LogConstants.ALERT_NAME, alertName);
    }


    private static String getEamilBySpace(String jsonStr, StringBuffer sb) {
        jsonStr = jsonStr.trim();
        int index = DataUtils.getIndex(jsonStr, " ");
        String tempStr = DataUtils.getSubString(jsonStr, 0, index);
        jsonStr = DataUtils.getSubString(jsonStr, index).trim();
        if (isEmail(tempStr)) {
            sb.append(tempStr).append(",");
        } else {
            return sb.toString();
        }
        if (tempStr.equals(jsonStr)) {
            return sb.toString();
        }
        getEamilBySpace(jsonStr, sb);
        return sb.toString();
    }

    public static boolean isEmail(String str){
        Pattern pattern = Pattern.compile("^\\w+([-+.]\\w+)*@\\w+([-.]\\w+)*\\.\\w+([-.]\\w+)*$");
        Matcher isNum = pattern.matcher(str);
        return isNum.matches();
    }
}
