package com.crc.log.flink.parse;

import com.crc.log.flink.common.constants.ActionResultConstants;
import com.crc.log.flink.common.constants.LevelConstants;
import com.crc.log.flink.common.constants.LogConstants;
import com.crc.log.flink.common.utils.*;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.apache.commons.lang3.tuple.Pair;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.HashMap;
import java.util.Locale;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

@Slf4j
public class ResolvWafLog {
    /**
     * Imperva waf 日志泛化
     */
    public static ConcurrentHashMap<String, Object> parse(String message) {
        try {
            ConcurrentHashMap<String, Object> data = proc(message);
            if (DataUtils.isNotEmptyJson(data)) {
                return data;
            }
        } catch (Exception ignored) {

        }
        return null;
    }

    private static ConcurrentHashMap<String, Object> proc(String jsonStr) {
        ConcurrentHashMap<String, Object> rtnObjc = JsonUtils.createBaseMap(jsonStr);
        if (jsonStr.contains("|Imperva Inc")) {

            parseWafLogJson(rtnObjc, jsonStr);


            rtnObjc.put(LogConstants.LOG_LEVEL, LevelConstants.getLevel(MapUtils.getStr(rtnObjc,LogConstants.LOG_LEVEL)));
            rtnObjc.put(LogConstants.LOG_START_TIME, DateUtils.getISO8601Timestamp(new Date()));
            ScoreUtils.commonEventLevelScore(rtnObjc);
            setAlertName(rtnObjc);
        } else {
            int index = com.crc.log.flink.common.utils.StringUtils.stringSubIndexTwo(jsonStr, '>', 1);
            int index1 = com.crc.log.flink.common.utils.StringUtils.stringSubIndexTwo(jsonStr, ' ', 3);
            String time = DataUtils.getSubString(jsonStr, index+1, index1);
            try {
                String d = time  + " " + DateUtils.getYear();
                SimpleDateFormat dateFormat = new SimpleDateFormat("MMM d HH:mm:ss yyyy", Locale.ENGLISH);
                Date date = dateFormat.parse(d);
                rtnObjc.put(LogConstants.LOG_START_TIME, DateUtils.getISO8601Timestamp(date));
            } catch (Exception e) {
                log.error(e.getMessage(),e);
            }
            index = com.crc.log.flink.common.utils.StringUtils.stringSubIndexTwo(jsonStr, ' ', 4);
            String hostName = DataUtils.getSubString(jsonStr, index1+1, index).trim();
            rtnObjc.put(LogConstants.HOST_NAME, hostName);
            index1 = com.crc.log.flink.common.utils.StringUtils.stringSubIndexTwo(jsonStr, ':', 3);
            index = com.crc.log.flink.common.utils.StringUtils.stringSubIndexTwo(jsonStr, '(', 1);
            String logName = DataUtils.getSubString(jsonStr, index1+1, index).trim();
            rtnObjc.put(LogConstants.LOG_NAME, logName);
            index1 = com.crc.log.flink.common.utils.StringUtils.stringSubIndexTwo(jsonStr, ')', 1);
            String logLevel = DataUtils.getSubString(jsonStr, index+1, index1).trim();
            rtnObjc.put(LogConstants.LOG_LEVEL, logLevel);
            index1 = com.crc.log.flink.common.utils.StringUtils.stringSubIndexTwo(jsonStr, '(', 2);
            index = DataUtils.getLastIndex(jsonStr, ")");
            jsonStr = DataUtils.getSubString(jsonStr, index1+1, index);
            String[] split = DataUtils.getSplit(jsonStr, ",");
            for (String tempStr : split) {
                String[] keyValue = DataUtils.getSplit(tempStr, "=");
                if (keyValue.length == 2) {
                    String key = keyValue[0].trim();
                    String value = keyValue[1].trim();
                    switch (key) {
                        case "id":
                            rtnObjc.put(LogConstants.EVENT_ID, value);
                            break;
                        case "service":
                            rtnObjc.put(LogConstants.ACTION_TYPE, value);
                            break;
                        case "identity":
                            rtnObjc.put(LogConstants.OP_NAME, value);
                            break;
                        case "from":
                            rtnObjc.put(LogConstants.SRC_IP, value);
                            break;
                        case "resName":
                        case "server":
                            rtnObjc.put(LogConstants.DEVICE_NAME, value);
                            break;
                        case "account":
                            rtnObjc.put(LogConstants.USER_NAME, value);
                            break;
                        case "action":
                            rtnObjc.put(LogConstants.ACTION_TYPE, value);
                            break;
                        case "command":
                            rtnObjc.put(LogConstants.LOG_CONTENT, value);
                            break;
                        case "protocol":
                            rtnObjc.put(LogConstants.LOG_PROTOCAL, value);
                            break;
                        case "changeType":
                            rtnObjc.put(LogConstants.ACTION_TYPE, value);
                            break;
                        case "resIp":
                            rtnObjc.put(LogConstants.LOG_DEV_IP, value);
                            break;
                        case "resType":
                            rtnObjc.put(LogConstants.DEVICE_TYPE, value);
                            break;
                        case "operate":
                            rtnObjc.put(LogConstants.ACTION_TYPE, value);
                            break;
                        case "status":
                        case "result":
                            rtnObjc.put(LogConstants.ACTION_RESULT, value);
                            break;
                        case "sql":
                        case "oper":
                        case "path":
                            rtnObjc.put(LogConstants.FILE_PATH, value);
                            break;
                    }
                }
            }
            setAlertName1(rtnObjc);
        }
        rtnObjc.put(LogConstants.LOG_PRODUCT, "Imperva WAF");
        rtnObjc.put(LogConstants.LOG_LEVEL, LevelConstants.getLevel(MapUtils.getStr(rtnObjc,LogConstants.LOG_LEVEL)));
        if (StringUtils.isBlank(MapUtils.getStr(rtnObjc, LogConstants.SRC_IP))) {
            rtnObjc.put(LogConstants.SRC_IP, "0.0.0.0");
        }
        if (StringUtils.isBlank(MapUtils.getStr(rtnObjc, LogConstants.DEST_IP))) {
            rtnObjc.put(LogConstants.DEST_IP, "0.0.0.0");
        }
        return rtnObjc;
    }

    public static void parseWafLogJson(ConcurrentHashMap<String, Object> rtnObjc, String jsonStr) {
        Map<String, Pair<String, Pattern>> patternMap = getPatternMap();
        for (Map.Entry<String, Pair<String, Pattern>> patternEntry : patternMap.entrySet()) {
            String key = patternEntry.getKey();
            Pair<String, Pattern> value = patternEntry.getValue();
            if (key.equals("cont")) {
                Matcher matcher = value.getRight().matcher(jsonStr);
                if (matcher.find()) {
                    MapUtils.setStr(rtnObjc, value.getLeft(), matcher.group(1));
                }
            } else {
                Matcher matcher = value.getRight().matcher(jsonStr);
                if (matcher.find()) {
                    MapUtils.setStr(rtnObjc, value.getLeft(), matcher.group(key));
                }
            }
        }

        Pattern info = Pattern.compile("SecureSphere*(?<SecureSphere>.+?) dst");
        Matcher infoMatcher = info.matcher(jsonStr);
        if (infoMatcher.find()) {
            String[] arr = DataUtils.getSplit(infoMatcher.group(1), "\\\\");
                    //infoMatcher.group(1).split("\\|");
            if (arr.length >= 3) {
                MapUtils.setStr(rtnObjc, LogConstants.ACTION_TYPE, arr[2]);
            }
            if (arr.length >= 5) {
                MapUtils.setStr(rtnObjc, LogConstants.LOG_LEVEL, arr[4]);
            }
            if (arr.length >= 6) {
                if (arr[5].equalsIgnoreCase("act=Block"))
                    rtnObjc.put(LogConstants.ACTION_RESULT, ActionResultConstants.DENY);
                else
                    rtnObjc.put(LogConstants.ACTION_RESULT, ActionResultConstants.NO_DENY);
            }
        }

    }

    public static Map<String, Pair<String, Pattern>> getPatternMap() {
        Map<String, Pair<String, Pattern>> patternMap = new HashMap<>();
        Pattern dst_ip_p = Pattern.compile("dst=*(?<dst>.+?) ");
        patternMap.put("dst", Pair.of(LogConstants.DEST_IP, dst_ip_p));
        Pattern dst_port_p = Pattern.compile("dpt=*(?<dpt>.+?) ");
        patternMap.put("dpt", Pair.of(LogConstants.DEST_PORT, dst_port_p));
        Pattern src_ip_p = Pattern.compile("src=*(?<src>.+?) ");
        patternMap.put("src", Pair.of(LogConstants.SRC_IP, src_ip_p));
        Pattern src_port_p = Pattern.compile("spt=*(?<spt>.+?) ");
        patternMap.put("spt", Pair.of(LogConstants.SRC_PORT, src_port_p));
        Pattern event_type = Pattern.compile("cs5=*(?<cs5>.+?)cs5Label");
        patternMap.put("cs5", Pair.of(LogConstants.LOG_TYPE, event_type));
        Pattern content = Pattern.compile("cs5Label=(.*)");
        patternMap.put("cont", Pair.of(LogConstants.MSG_CONTENT, content));
        Pattern act = Pattern.compile("act=*(?<act>.+?) ");
        patternMap.put("act", Pair.of(LogConstants.ACTION_RESULT, act));
        Pattern cat = Pattern.compile("cat=*(?<cat>.+?) ");
        patternMap.put("cat", Pair.of(LogConstants.LOG_LEVEL,cat));
        return patternMap;
    }


    //  src_ip 对 dest_ip 进行 [action_type] event_type-action_result
    public static void setAlertName(ConcurrentHashMap<String, Object> resultJson) {
        String srcIp = MapUtils.getStr(resultJson, LogConstants.SRC_IP);
        String destIp = MapUtils.getStr(resultJson, LogConstants.DEST_IP);

        String actionType = MapUtils.getStr(resultJson, LogConstants.ACTION_TYPE);
        String eventType = MapUtils.getStr(resultJson, LogConstants.LOG_TYPE);
        String actionResult = MapUtils.getStr(resultJson, LogConstants.ACTION_RESULT);
        String log = MapUtils.getStr(resultJson, LogConstants.LOG_ORI_MSG);
        if (StringUtils.isBlank(destIp) || "null".equals(destIp) || "0.0.0.0".equals(destIp) || srcIp.equals(destIp)) {
            String messageFormat = "%s 发起 进行 [%s]  %s-%s,日志详情为:%s";
            String alertName = String.format(messageFormat, srcIp, actionType, eventType, actionResult, log);
            resultJson.put(LogConstants.ALERT_NAME, alertName);
        } else {
            String messageFormat = "%s 对 %s 进行 [%s]  %s-%s,日志详情为:%s";
            String alertName = String.format(messageFormat, srcIp, destIp, actionType, eventType, actionResult, log);
            resultJson.put(LogConstants.ALERT_NAME, alertName);
        }
    }

    private static void setAlertName1(ConcurrentHashMap<String, Object> rtnObjc) {
        String message = "";
        String alertName = "";
        String srcIp = MapUtils.getStr(rtnObjc, LogConstants.SRC_IP);
        String log = MapUtils.getStr(rtnObjc, LogConstants.LOG_ORI_MSG);
        String content = MapUtils.getStr(rtnObjc, LogConstants.LOG_CONTENT);
        String logName = MapUtils.getStr(rtnObjc, LogConstants.LOG_NAME);
        String opName = MapUtils.getStr(rtnObjc, LogConstants.OP_NAME);
        String actionType = MapUtils.getStr(rtnObjc, LogConstants.ACTION_TYPE);
        String actionResult = MapUtils.getStr(rtnObjc, LogConstants.ACTION_RESULT);
        String devName = MapUtils.getStr(rtnObjc, LogConstants.DEVICE_NAME);
        if (!org.apache.commons.lang3.StringUtils.isNotBlank(actionResult) &&
                org.apache.commons.lang3.StringUtils.isNotBlank(content)) {
            message = "用户为:%s在IP为:%s的设备名称为:%s的机器上执行了%s操作,日志名称为:%s,日志内容为:%s,日志详情为:%s";
            alertName = String.format(message, opName, srcIp, devName, actionType, logName, content,log);

        } else {
            message = "用户为:%s在IP为:%s的设备名称为:%s的机器上执行了%s操作,操作结果为:%s,日志名称为:%s,日志详情为:%s";
            alertName = String.format(message, opName, srcIp, devName, actionType, actionResult, logName, log);
        }
        rtnObjc.put(LogConstants.ALERT_NAME, alertName);
    }
}
