package com.crc.log.flink.test.log;

import com.crc.log.flink.common.utils.JsonUtils;
import com.crc.log.flink.config.AllConfig;
import com.crc.log.flink.es.DataProcessFuncation;

import java.util.concurrent.ConcurrentHashMap;

/**
 * @author jixiangqi
 * @date 2022/5/12
 */
public class ResolvLvMengNIPSLogTest {

    public static void main(String[] args) {
        AllConfig config = new AllConfig();
        DataProcessFuncation.CONIFG = config;
        config.setMode("single");
        config.setParse("ResolvLvMengNIPSLog");
        config.setIndex("sec_all");

        String str = "<5> date=2022-05-25 17:44:17;manufacturers=nsfocus;device_type=IPS;sub_type=2;mem_heart_log=24%;";
        ConcurrentHashMap<String, Object> proc = DataProcessFuncation.parse(str, "index");
        JsonUtils.printStr(proc);



       /* String str = "device_type=\"ips\";manufacturers=\"nsfocus\";security_name=\"advance_threat_file_log\";time=1602572178;card=\"T1/2\";sip=\"10.67.5.50\";smac=\"B8-CA-3A-BA-F2-45\";sport=52728;dip=\"10.67.4.201\";dmac=\"18-03-73-AF-88-D6\";dport=25;vid=0;ruleid=41769;event=\"Trojan.Agent.BDXT\";module=12;threat_level=5;threat_type=\"av\";action=1;acted=1;count=1;protocol=\"TCP\";policy_id=0;cdnip=\"\";user_name=\"\";smt_user=\"\";file_md5=\"0006beaffe4b21d713583036b77d88ac\";file_sha256=\"7896d280794b2e82b7b3f0fce626c1e62c50c0cefbf175a77d75a913f9b35647\";orig_name=\"A1F1D44D88434A3299BF96DEBF67A601\";new_name=\"0006beaffe4b21d713583036b77d88ac\";tacinfo=\"\";url=\"\";submit_time=1602572156;taskid=409ac70405f8530a16025681400ed479;file_type=\"\";file_size=482273;tags=\"[\"trojan\"]\";app_info=\"\"\"\";threat_info=\"[{\"description\": \"\\u6728\\u9a6c\", \"threat_name\": \"Trojan.Agent.BDXT\", \"behavior\": \"Trojan\", \"proposal\": \"\\u4f7f\\u7528\\u6740\\u8f6f\\u8fdb\\u884c\\u5168\\u76d8\\u67e5\\u6740\", \"threat_level\": \"high\", \"engine_type\": \"av\"}]\";dropped=\"[]\";file_structure=\"{\"PE Type\": \"PE32\", \"Internal Name\": \"large\", \"Machine Type\": \"Intel 386 or later, and compatibles\", \"File OS\": \"Win32\", \"Code Size\": \"245760\", \"OS Version\": \"5.1\", \"Entry Point\": \"0x61000\", \"File Flags Mask\": \"0x003f\", \"Linker Version\": \"11.0\", \"File Subtype\": \"0\", \"Uninitialized Data Size\": \"0\", \"File Version\": \"or is a\", \"Initialized Data Size\": \"137728\", \"File Description\": \"Obtaining operating database with\", \"Product Version Number\": \"1.8.0.0\", \"Product Name\": \"large\", \"Company Name\": \"large\", \"MIME Type\": \"application/octet-stream\", \"Character Set\": \"Windows, Latin1\", \"Time Stamp\": \"2014:01:24 03:47:25+08:00\", \"Language Code\": \"English (U.S.)\", \"File Version Number\": \"1.8.0.0\", \"File Type\": \"Win32 DLL\", \"Original Filename\": \"Obtaining operating database with\", \"Legal Copyright\": \"Copyright (C) 2014\", \"Subsystem\": \"Windows GUI\", \"Object File Type\": \"Dynamic link library\", \"Image Version\": \"0.0\", \"File Flags\": \"(none)\", \"Subsystem Version\": \"5.1\", \"Product Version\": \"large\"}\";file_basic=\"{\"crc32\": 4083226098, \"sha256\": \"7896d280794b2e82b7b3f0fce626c1e62c50c0cefbf175a77d75a913f9b35647\", \"md5\": \"0006beaffe4b21d713583036b77d88ac\", \"sha1\": \"d6bdb4d72de4ae41cce80fd3e5cb6f00b90ab61a\"}\";ar=2;cve_id=\"\";network=\"\";src_asset=0;dst_asset=0;scountry=\"保留\";scity=\"\";dcountry=\"保留\";dcity=\"\"";
        JSONObject proc = DataProcessFuncation.parse(str, "index");
        JsonUtils.printStr(proc);*/
    }

}
