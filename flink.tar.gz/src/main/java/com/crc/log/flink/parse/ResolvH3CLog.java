package com.crc.log.flink.parse;

import com.crc.log.flink.common.constants.LevelConstants;
import com.crc.log.flink.common.constants.LogConstants;
import com.crc.log.flink.common.utils.*;

import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;
import java.util.concurrent.ConcurrentHashMap;

/**
 * @author jixiangqi
 * @date 2022/3/9
 * H3C以太网日志
 */
public class ResolvH3CLog {

    public static boolean parseGood = false;

    public static ConcurrentHashMap<String,Object> parse(String message) {
        try {
            ConcurrentHashMap<String,Object> data = proc(message);
            if (DataUtils.isNotEmptyJson(data)) {
                return data;
            }
        } catch (Exception ignored) {

        }
        return null;
    }

    private static ConcurrentHashMap<String,Object> proc(String jsonStr) {
        ConcurrentHashMap<String,Object> rtnObjc = JsonUtils.createBaseMap(jsonStr);
        if (org.apache.commons.lang3.StringUtils.isNotBlank(jsonStr)) {
            if (jsonStr.contains("SHELL_CMD")) {
                jsonStr = jsonStr.replace("-", " -");
            }
        }
        int index = StringUtils.stringSubIndex(jsonStr, ':', 3);
        jsonStr = DataUtils.getSubString(jsonStr, index - 2);
        switchKeyValue(rtnObjc, jsonStr);
        rtnObjc.put(LogConstants.LOG_PRODUCT, "H3C交换机");
        rtnObjc.put(LogConstants.LOG_LEVEL, LevelConstants.getLevel(MapUtils.getStr(rtnObjc,LogConstants.LOG_LEVEL)));
        if (org.apache.commons.lang3.StringUtils.isBlank(MapUtils.getStr(rtnObjc, LogConstants.SRC_IP))) {
            rtnObjc.put(LogConstants.SRC_IP, "0.0.0.0");
        }
        if (org.apache.commons.lang3.StringUtils.isBlank(MapUtils.getStr(rtnObjc, LogConstants.DEST_IP))) {
            rtnObjc.put(LogConstants.DEST_IP, "0.0.0.0");
        }
        setAlertName(rtnObjc);
        return rtnObjc;
    }

    private static void setAlertName(ConcurrentHashMap<String,Object> rtnObjc) {
        String srcIp = MapUtils.getStr(rtnObjc, LogConstants.SRC_IP);
        String destIp = MapUtils.getStr(rtnObjc, LogConstants.DEST_IP);
        String log = MapUtils.getStr(rtnObjc, LogConstants.LOG_ORI_MSG);
        String msgFormat = "";
        String alertName = "";
        if (!srcIp.equals("0.0.0.0") && !destIp.equals("0.0.0.0")) {
            String actionType = MapUtils.getStr(rtnObjc, LogConstants.ACTION_TYPE);
            String protocal = MapUtils.getStr(rtnObjc, LogConstants.LOG_PROTOCAL);
            msgFormat = "源IP为:%s对IP为:%s产生了一个攻击,攻击类型为:%s,攻击协议为:%s,原始日志为:%s";
            alertName = String.format(msgFormat, srcIp, destIp, actionType, protocal, log);
        } else {
            String userName = MapUtils.getStr(rtnObjc, LogConstants.USER_NAME);
            String devIp = MapUtils.getStr(rtnObjc, LogConstants.LOG_DEV_IP);
            if (org.apache.commons.lang3.StringUtils.isNotBlank(userName)) {
                msgFormat = "在IP为:%s的设备上产生了命令日志,原始日志为:%s";
                alertName = String.format(msgFormat, devIp, log);
            } else {
                msgFormat = "用户名为:%s,在IP为:%s的设备上执行登录操作,原始日志为:%s";
                alertName = String.format(msgFormat, userName, devIp, log);
            }
        }
        rtnObjc.put(LogConstants.ALERT_NAME, alertName);
    }


    private static void switchKeyValue(ConcurrentHashMap<String,Object> rtnObjc, String str) {
        String[] split = {};
        if (str.contains(",")) {
            split = DataUtils.getSplit(str, ", ");
        } else {
            split = DataUtils.getSplit(str, "; ");
        }
        for (String tempStr : split) {
            int p1 = tempStr.indexOf("=");
            int p2 = tempStr.lastIndexOf("=");
            String[] keyValue = DataUtils.getSplit(tempStr, "=");
            if (p1 != p2) {
                //多个等号
                String[] tempArr = tempStr.split(" ");
                for (String temp : tempArr) {
                    valueParse(rtnObjc, DataUtils.getSplit(temp, "="));
                }
            } else {
                valueParse(rtnObjc, keyValue);
            }

        }
    }

    private static void valueParse(ConcurrentHashMap<String,Object> rtnObjc, String[] keyValue) {
        try {
            if (keyValue.length == 2) {
                String key = keyValue[0].trim();
                String value = keyValue[1].trim();
                switch (key) {
                    case "UserType":
                        rtnObjc.put(LogConstants.LOG_PROTOCAL, value);
                        break;
                    case "UserName":
                        rtnObjc.put(LogConstants.USER_NAME, value);
                        break;
                    case "Ip":
                        rtnObjc.put(LogConstants.LOG_DEV_IP, value);
                        break;
                    case "loginIP":
                        rtnObjc.put(LogConstants.LOG_DEV_IP, value);
                        break;
                    case "loginTime":
                        rtnObjc.put(LogConstants.LOG_START_TIME, DateUtils.getISO8601Timestamp(value, "yyyy/MM/dd HH:mm:ss"));
                        break;
                    case "accessType":
                        rtnObjc.put(LogConstants.LOG_PROTOCAL, value);
                        break;
                    case "userLevel":
                        rtnObjc.put(LogConstants.LOG_PROTOCAL, value);
                        break;
                    case "AttackType":
                        rtnObjc.put(LogConstants.ACTION_TYPE, value);
                        break;
                    case "proto":
                        rtnObjc.put(LogConstants.LOG_PROTOCAL, value);
                        break;
                    case "begin time":
                        rtnObjc.put(LogConstants.LOG_START_TIME, DateUtils.getISO8601Timestamp(value, "yyyy/MM/dd HH:mm:ss"));
                        break;
                    case "-DevIP":
                        rtnObjc.put(LogConstants.LOG_DEV_IP, value);
                        break;
                    case "-IPAddr":
                        rtnObjc.put(LogConstants.SRC_IP, value);
                        break;
                    case "ip":
                        String[] split1 = DataUtils.getSplit(value, ";");
                        Set<String> srcIp = new HashSet<>();
                        Set<String> srcPort = new HashSet<>();
                        Set<String> destIp = new HashSet<>();
                        Set<String> destPort = new HashSet<>();
                        for (String s : split1) {
                            Map<String, Set> stringSetMap = srcDestIp(s);
                            srcIp.addAll(stringSetMap.get("srcIp"));
                            srcPort.addAll(stringSetMap.get("srcPort"));
                            destIp.addAll(stringSetMap.get("destIp"));
                            destPort.addAll(stringSetMap.get("destPort"));
                        }
                        rtnObjc.put(LogConstants.SRC_IP, srcIp.toString());
                        rtnObjc.put(LogConstants.SRC_PORT, srcPort.toString());
                        rtnObjc.put(LogConstants.DEST_IP, destIp.toString());
                        rtnObjc.put(LogConstants.DEST_PORT, destPort.toString());
                }
            }
        } catch (Exception e) {

        }
    }

    private static Map<String, Set> srcDestIp(String value) {
        Map<String, Set> resultMap = new HashMap<>();
        Set<String> srcIp = new HashSet<>();
        Set<String> srcPort = new HashSet<>();
        Set<String> destIp = new HashSet<>();
        Set<String> destPort = new HashSet<>();
        String[] ipSplits = DataUtils.getSplit(value.replaceAll("\"", ""), "->");
        if (ipSplits.length == 2) {
            String src = ipSplits[0].trim();
            String dest = ipSplits[1].trim();
            String[] srcValue = DataUtils.getSplit(src, ":");
            String[] destValue = DataUtils.getSplit(dest, ":");
            if (srcValue.length == 2) {
                if (IPUtil.isIp(srcValue[0])) {
                    srcIp.add(srcValue[0]);
                }
                if (RegUtils.isPureDigital(srcValue[1])) {
                    srcPort.add(srcValue[1]);
                }
            } else if (srcValue.length == 1) {
                if (IPUtil.isIp(srcValue[0])) {
                    srcIp.add(srcValue[0]);
                } else if (RegUtils.isPureDigital(srcValue[1])) {
                    srcPort.add(srcValue[0]);
                }
            }
            if (destValue.length == 2) {
                if (IPUtil.isIp(destValue[0])) {
                    destIp.add(destValue[0]);
                }
                if (RegUtils.isPureDigital(destValue[1])) {
                    destPort.add(destValue[1]);
                }
            } else if (destValue.length == 1) {
                if (IPUtil.isIp(destValue[0])) {
                    destIp.add(destValue[0]);
                } else if (RegUtils.isPureDigital(destValue[1])) {
                    destPort.add(destValue[0]);
                }
            }
        }
        resultMap.put("srcIp", srcIp);
        resultMap.put("srcPort", srcPort);
        resultMap.put("destIp", destIp);
        resultMap.put("destPort", destPort);
        return resultMap;
    }


}
