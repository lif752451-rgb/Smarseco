package com.crc.log.flink.parse;

import com.alibaba.fastjson.JSONObject;
import com.crc.log.flink.common.constants.LogConstants;
import com.crc.log.flink.common.utils.DataUtils;
import com.crc.log.flink.common.utils.JsonUtils;
import com.crc.log.flink.common.utils.MapUtils;
import org.apache.commons.lang3.StringUtils;

import java.util.HashMap;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

public class ResolvGuoceHoneyLog {
    /**
     * 通用日志 日志泛化
     */
    public static ConcurrentHashMap<String,Object> parse(String message) {
        try {
            ConcurrentHashMap<String,Object> data = proc(message);
            if (DataUtils.isNotEmptyJson(data)) {
                return data;
            }
        } catch (Exception ignored) {

        }
        return null;
    }

    private static ConcurrentHashMap<String,Object> proc(String jsonStr) {
        ConcurrentHashMap<String,Object> rtnObjc = JsonUtils.createBaseMap(jsonStr);
        getSplitBySpace(jsonStr).forEach((k,v) -> {
            switchKeyValue(rtnObjc, k, v);
        });
        rtnObjc.put(LogConstants.LOG_PRODUCT, "慧眼蜜罐");
        if (StringUtils.isBlank(MapUtils.getStr(rtnObjc, LogConstants.SRC_IP))) {
            rtnObjc.put(LogConstants.SRC_IP, "0.0.0.0");
        }
        if (StringUtils.isBlank(MapUtils.getStr(rtnObjc, LogConstants.DEST_IP))) {
            rtnObjc.put(LogConstants.DEST_IP, "0.0.0.0");
        }
        setAlertName(rtnObjc);
        return rtnObjc;
    }


    private static void switchKeyValue(ConcurrentHashMap<String,Object> rtnObjc, String key, String value) {
        switch (key) {
            case "level":
                String level = "";
                switch (value) {
                    case "warning":
                        level = "告警级别";
                        break;
                    case "info":
                        level = "信息级别";
                        break;
                    case "error":
                        level = "错误级别";
                        break;
                }
                rtnObjc.put(LogConstants.LOG_LEVEL, level);
                break;
            /*case "type":
                rtnObjc.put(LogConstants.LOG_TYPE, value);
                break;*/
            case "attackerIp":
                rtnObjc.put(LogConstants.SRC_IP, value);
                break;
            case "dstPort":
                rtnObjc.put(LogConstants.DEST_PORT, value);
                break;
            case "agentIp":
                rtnObjc.put(LogConstants.DEST_IP, value);
                break;
            case "protocol":
                rtnObjc.put(LogConstants.LOG_PROTOCAL, value);
                break;
            case "eventType":
                rtnObjc.put(LogConstants.LOG_TYPE, value);
                break;
            case "honeypotName":
                rtnObjc.put(LogConstants.HONEYPOT_NAME, value);
                break;
        }
    }

    private static Map<String, String> getSplitBySpace(String jsonStr) {
        Map<String, String> resultMap = new HashMap<>();
        String index = "";
        String[] split = DataUtils.getSplit(jsonStr, " ");
        for (String s : split) {
            String tempStr = s;
            tempStr = tempStr.replaceAll("\"", "");
            if (tempStr.contains("=")) {
                String[] keyValue = DataUtils.getSplit(tempStr, "=");
                if (keyValue.length == 2) {
                    String key = keyValue[0].trim();
                    String value = keyValue[1].trim();
                    resultMap.put(key, value);
                    index = key;
                }
            } else {
                resultMap.put(index, resultMap.get(index) + " " + tempStr.trim());
            }
        }
        return resultMap;
    }

    private static void setAlertName(ConcurrentHashMap<String,Object> rtnObjc) {
        String srcIp = MapUtils.getStr(rtnObjc, LogConstants.SRC_IP);
        String destIp = MapUtils.getStr(rtnObjc, LogConstants.DEST_IP);
        String destPort = MapUtils.getStr(rtnObjc, LogConstants.DEST_PORT);
        String protocal = MapUtils.getStr(rtnObjc, LogConstants.LOG_PROTOCAL);
        String logLevel = MapUtils.getStr(rtnObjc, LogConstants.LOG_LEVEL);
        String eventType = MapUtils.getStr(rtnObjc, LogConstants.LOG_TYPE);
        String log = MapUtils.getStr(rtnObjc, LogConstants.LOG_ORI_MSG);
        String message = "IP为:%s对IP为:%s的%s端口,进行了:%s攻击,事件级别为:%s,攻击协议为:%s,事件详情为:%s:";
        String alertName = String.format(message, srcIp, destIp, destPort, eventType, logLevel, protocal, log);
        rtnObjc.put(LogConstants.ALERT_NAME, alertName);
    }

    /**
     * <132>2021-04-13T10:12:46+08:00 jtsecvdca01 YJHP_Server[52807]: level=warning msg="EventType:honeypotAccess, attackerIp:61.148.223.18, dstPort:80, protocol:http, honeypotName:Nginx_Proxy_Honeypot, agentIp:10.8.80.250" type=event
     *
     * @param msg
     * @return
     */
    public static JSONObject getMsgContent(String msg) {
        JSONObject json = new JSONObject();
        try {
            if (StringUtils.isNotBlank(msg) && msg.contains("\"")) {
                msg = DataUtils.getSubString(msg, DataUtils.getIndex(msg, "\""));
                        //msg.substring(msg.indexOf("\""));
                int index = DataUtils.getLastIndex(msg, "\"");
                if (index == -1) {
                    return json;
                }
                msg = DataUtils.getSubString(msg, 0, index+1);
            }
            msg = msg.replace("\"", "");
            for (String x : msg.split(",")) {
                try {
                    String[] m = DataUtils.getSplit2(x, ":");
                            //x.split(":");
                    json.put(m[0].trim(), m[1].trim());
                } catch (Exception ignored) {

                }
            }

        } catch (Exception ignored) {

        }

        return json;
    }

}
