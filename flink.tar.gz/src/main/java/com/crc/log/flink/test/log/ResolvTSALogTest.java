package com.crc.log.flink.test.log;

import com.crc.log.flink.common.utils.JsonUtils;
import com.crc.log.flink.config.AllConfig;
import com.crc.log.flink.es.DataProcessFuncation;

import java.util.concurrent.ConcurrentHashMap;

public class ResolvTSALogTest {

    public static void main(String[] args) {
        AllConfig config = new AllConfig();
        DataProcessFuncation.CONIFG = config;
        config.setMode("single");
        config.setParse("ResolvTSALog");
        config.setIndex("sec_all");

        String str = "{\"topic\":\"tsa_log\",\"dev_ip\":\"10.0.14.40\",\"message\":\"<8>Apr 24 19:47:38 colasoft {\\\"app\\\":3502,\\\"src_mac\\\":\\\"02:1F:A0:00:00:01\\\",\\\"src_ip_addr\\\":\\\"218.13.52.8\\\",\\\"category_code\\\":10030010,\\\"alarm_level\\\":2,\\\"netlink\\\":1,\\\"ip_country_id1\\\":0,\\\"dst_mac\\\":\\\"E0:28:61:59:4F:4B\\\",\\\"ip_protocol\\\":803,\\\"ip_country_id2\\\":48,\\\"src_port\\\":42762,\\\"real_stat_time\\\":1650800855,\\\"duration\\\":0,\\\"log_type\\\":\\\"ALARM\\\",\\\"alarm_type\\\":4194304,\\\"dst_ip_addr\\\":\\\"223.5.5.5\\\",\\\"person\\\":\\\"pengyu\\\",\\\"dst_port\\\":53,\\\"name\\\":\\\"信息泄露-通过外部平台回显数据\\\",\\\"alarm_id\\\":10000041,\\\"id\\\":7090135686076174066,\\\"category\\\":\\\"其它漏洞利用\\\",\\\"host_name\\\":\\\"\\\",\\\"real_trigger_time\\\":1650800855}\",\"type\":\"udp\",\"timestamp\":\"2022-04-24 19:45:50\"}";
        ConcurrentHashMap<String, Object> proc = DataProcessFuncation.parse(str, "index");
        JsonUtils.printStr(proc);

        str = "{\"topic\":\"tsa_log\",\"dev_ip\":\"10.0.14.40\",\"message\":\"<8>Apr 24 20:13:19 colasoft {\\\"app\\\":3502,\\\"src_mac\\\":\\\"02:1F:A0:00:00:01\\\",\\\"src_ip_addr\\\":\\\"218.13.52.8\\\",\\\"category_code\\\":10030010,\\\"alarm_level\\\":2,\\\"netlink\\\":1,\\\"ip_country_id1\\\":0,\\\"dst_mac\\\":\\\"E0:28:61:59:4F:4B\\\",\\\"ip_protocol\\\":803,\\\"ip_country_id2\\\":48,\\\"src_port\\\":26332,\\\"real_stat_time\\\":1650802396,\\\"duration\\\":0,\\\"log_type\\\":\\\"ALARM\\\",\\\"alarm_type\\\":4194304,\\\"dst_ip_addr\\\":\\\"223.5.5.5\\\",\\\"person\\\":\\\"pengyu\\\",\\\"dst_port\\\":53,\\\"name\\\":\\\"信息泄露-通过外部平台回显数据\\\",\\\"alarm_id\\\":10000041,\\\"id\\\":7090142304621616655,\\\"category\\\":\\\"其它漏洞利用\\\",\\\"host_name\\\":\\\"\\\",\\\"real_trigger_time\\\":1650802396}\",\"type\":\"udp\",\"timestamp\":\"2022-04-24 20:11:32\"}";
        proc = DataProcessFuncation.parse(str, "index");
        JsonUtils.printStr(proc);

        str = "{\"topic\":\"tsa_log\",\"dev_ip\":\"10.0.14.40\",\"message\":\"<8>Apr 24 21:11:39 colasoft {\\\"app\\\":3502,\\\"src_mac\\\":\\\"02:1F:A0:00:00:01\\\",\\\"src_ip_addr\\\":\\\"218.13.52.8\\\",\\\"category_code\\\":10030010,\\\"alarm_level\\\":2,\\\"netlink\\\":1,\\\"ip_country_id1\\\":0,\\\"dst_mac\\\":\\\"E0:28:61:59:4F:4B\\\",\\\"ip_protocol\\\":803,\\\"ip_country_id2\\\":48,\\\"src_port\\\":16981,\\\"real_stat_time\\\":1650805896,\\\"duration\\\":0,\\\"log_type\\\":\\\"ALARM\\\",\\\"alarm_type\\\":4194304,\\\"dst_ip_addr\\\":\\\"223.5.5.5\\\",\\\"person\\\":\\\"pengyu\\\",\\\"dst_port\\\":53,\\\"name\\\":\\\"信息泄露-通过外部平台回显数据\\\",\\\"alarm_id\\\":10000041,\\\"id\\\":7090157337009000316,\\\"category\\\":\\\"其它漏洞利用\\\",\\\"host_name\\\":\\\"\\\",\\\"real_trigger_time\\\":1650805896}\",\"type\":\"udp\",\"timestamp\":\"2022-04-24 21:09:51\"}";
        proc = DataProcessFuncation.parse(str, "index");
        JsonUtils.printStr(proc);

        str = "{\"topic\":\"tsa_log\",\"dev_ip\":\"10.0.14.40\",\"message\":\"<8>Apr 24 22:07:39 colasoft {\\\"app\\\":3502,\\\"src_mac\\\":\\\"02:1F:A0:00:00:01\\\",\\\"src_ip_addr\\\":\\\"218.13.52.8\\\",\\\"category_code\\\":10030010,\\\"alarm_level\\\":2,\\\"netlink\\\":1,\\\"ip_country_id1\\\":0,\\\"dst_mac\\\":\\\"E0:28:61:59:4F:4B\\\",\\\"ip_protocol\\\":803,\\\"ip_country_id2\\\":48,\\\"src_port\\\":11118,\\\"real_stat_time\\\":1650809256,\\\"duration\\\":0,\\\"log_type\\\":\\\"ALARM\\\",\\\"alarm_type\\\":4194304,\\\"dst_ip_addr\\\":\\\"119.29.29.29\\\",\\\"person\\\":\\\"pengyu\\\",\\\"dst_port\\\":53,\\\"name\\\":\\\"信息泄露-通过外部平台回显数据\\\",\\\"alarm_id\\\":10000041,\\\"id\\\":7090171768100883625,\\\"category\\\":\\\"其它漏洞利用\\\",\\\"host_name\\\":\\\"\\\",\\\"real_trigger_time\\\":1650809256}\",\"type\":\"udp\",\"timestamp\":\"2022-04-24 22:05:51\"}";
        proc = DataProcessFuncation.parse(str, "index");
        JsonUtils.printStr(proc);

        str = "{\"topic\":\"tsa_log\",\"dev_ip\":\"10.0.14.40\",\"message\":\"<8>Apr 24 23:03:43 colasoft {\\\"app\\\":3502,\\\"src_mac\\\":\\\"02:1F:A0:00:00:01\\\",\\\"src_ip_addr\\\":\\\"218.13.52.8\\\",\\\"category_code\\\":10030010,\\\"alarm_level\\\":2,\\\"netlink\\\":1,\\\"ip_country_id1\\\":0,\\\"dst_mac\\\":\\\"E0:28:61:59:4F:4B\\\",\\\"ip_protocol\\\":803,\\\"ip_country_id2\\\":48,\\\"src_port\\\":14546,\\\"real_stat_time\\\":1650812620,\\\"duration\\\":0,\\\"log_type\\\":\\\"ALARM\\\",\\\"alarm_type\\\":4194304,\\\"dst_ip_addr\\\":\\\"114.114.114.114\\\",\\\"person\\\":\\\"pengyu\\\",\\\"dst_port\\\":53,\\\"name\\\":\\\"信息泄露-通过外部平台回显数据\\\",\\\"alarm_id\\\":10000041,\\\"id\\\":7090186216372590950,\\\"category\\\":\\\"其它漏洞利用\\\",\\\"host_name\\\":\\\"\\\",\\\"real_trigger_time\\\":1650812620}\",\"type\":\"udp\",\"timestamp\":\"2022-04-24 23:01:55\"}";
        proc = DataProcessFuncation.parse(str, "index");
        JsonUtils.printStr(proc);
    }
}
