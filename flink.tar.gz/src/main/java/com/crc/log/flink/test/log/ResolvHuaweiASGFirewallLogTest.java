package com.crc.log.flink.test.log;

import com.crc.log.flink.common.utils.JsonUtils;
import com.crc.log.flink.config.AllConfig;
import com.crc.log.flink.es.DataProcessFuncation;

import java.util.concurrent.ConcurrentHashMap;

/**
 * @author jixiangqi
 * @date 2022/1/11
 */
public class ResolvHuaweiASGFirewallLogTest {

    public static void main(String[] args) {
        AllConfig config = new AllConfig();
        DataProcessFuncation.CONIFG = config;
        config.setMode("single");
        config.setParse("ResolvHuaweiASGFirewallLog");
        config.setIndex("sec_all");

        /*String str = "<188>2022-01-11 04:39:03 HRHLJ-ASG2100 %%01SEC/4/ATCKDF(l): AttackType=\"Tcp flag attack\", slot=\"0\", receive interface=\"GigabitEthernet0/0/0 \", proto=\"TCP\", src=\"172.188.5.110:40045 \", dst=\"10.153.18.3:80 10.153.18.3:1 \", begin time=\"2022-01-11 12:38:36\", end time=\"2022-01-11 12:38:39\", total packets=\"24\", max speed=\"0\".";
        JSONObject proc = DataProcessFuncation.parse(str,"index");
        JsonUtils.printStr(proc);

        str = "<188>2022-01-11 01:32:33 HRHLJ-ASG2100 %%01SEC/4/ATCKDF(l): AttackType=\"Tcp flag attack\", slot=\"0\", receive interface=\"GigabitEthernet0/0/0 \", proto=\"TCP\", src=\"172.188.5.110:33986 \", dst=\"10.153.18.3:80 10.153.18.3:1 \", begin time=\"2022-01-11 09:32:29\", end time=\"2022-01-11 09:32:32\", total packets=\"24\", max speed=\"0\".";
        proc = DataProcessFuncation.parse(str,"index");
        JsonUtils.printStr(proc);

        str = "<190>2022-01-11 05:18:09 HRHLJ-ASG2100 %%01SEC/6/STREAM(l): In last five minutes connection statistic is: Normal closed = 14004, Unsuccessfully closed = 463, Policy rejected = 25, Route rejected = 0, Blacklist rejected = 0.";
        proc = DataProcessFuncation.parse(str,"index");
        JsonUtils.printStr(proc);*/


        String str = "<190>2022-05-07 08:00:42 USG6500 %%01SECLOG/6/SESSION_TEARDOWN(l):IPVer=4,Protocol=tcp,SourceIP=10.32.11.13,DestinationIP=182.254.116.117,SourcePort=50453,DestinationPort=80,SourceNatIP=119.139.198.219,SourceNatPort=59221,BeginTime=1651910426,EndTime=1651910426,SendPkts=5,SendBytes=372,RcvPkts=4,RcvBytes=324,SourceVpnID=0,DestinationVpnID=0,SourceZone=trust,DestinationZone=DX_untrust_adsl,PolicyName=��ҵ\u03A2�š�Ӧ�ò��䡿,CloseReason=tcp-fin,ApplicationName=HTTP";
        ConcurrentHashMap<String, Object> proc = DataProcessFuncation.parse(str,"index");
        JsonUtils.printStr(proc);
    }

}
