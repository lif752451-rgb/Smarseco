package com.crc.log.flink.load;


import com.alibaba.fastjson.JSONObject;
import com.crc.log.flink.common.entity.TbSegementInfo;
import com.crc.log.flink.common.utils.DataUtils;
import com.crc.log.flink.common.utils.IPUtil;
import com.crc.log.flink.db.ConfBuzziMySql;
import com.crc.log.flink.net.IPBean;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.LinkedList;
import java.util.List;
import java.util.concurrent.ConcurrentHashMap;

/**
 * 集团网段加载功能
 */
@Slf4j
public class NewSegmentLoad {
    public static final ConcurrentHashMap<String, IPBean[]> ipSegMap = new ConcurrentHashMap<>();



    public void sync() {
        String sql = "SELECT * FROM tb_asset_segement WHERE is_enable = '0'";
        List<IPBean> list = new LinkedList<>();
        try {
            // 获取返回结果
            List<JSONObject> jsonObjectList = ConfBuzziMySql.query(sql);
            for (JSONObject rs : jsonObjectList) {
                try {
                    String segment = DataUtils.getString(rs, "segment");//设备类型->产品名称
                    String name = DataUtils.getString(rs, "name");//公司分组
                    String first_unit_name = DataUtils.getString(rs, "first_unit_name");
                    String second_unit_name = DataUtils.getString(rs, "second_unit_name");
                    String area_name = DataUtils.getString(rs, "area_name");
                    String affiliation_dept_name = DataUtils.getString(rs, "affiliation_dept_name");

                    String sub_area_name = DataUtils.getString(rs, "sub_area_name");
                    //String remark = JsonUtils.getStr(rs, "remark");

                    TbSegementInfo seg = new TbSegementInfo();
                    seg.setSegment(segment);
                    seg.setName(name);
                    seg.setFirstUnitName(first_unit_name);
                    seg.setSecondUnitName(second_unit_name);
                    seg.setAreaName(area_name);
                    seg.setSecondUnitName(sub_area_name);
                    seg.setAffiliationDeptName(affiliation_dept_name);
                    try {
                        List<IPBean> ipList = save2Segment(seg);
                        if (ipList != null && ipList.size() > 0) {
                            list.addAll(ipList);
                        }
                    } catch (Exception e) {
                        log.error(e.getMessage(), e);
                    }
                } catch (Exception e) {
                    log.error(e.getMessage(), e);
                }

            }
        } catch (Exception e) {
            log.error(e.getMessage(), e);
        }

        try {
            if (list.size() > 0) {
                list.sort(Comparator.comparingLong(IPBean::getBegin));
                IPBean[] ipBeans = list.toArray(new IPBean[]{});
                ipSegMap.put("seg", ipBeans);
            }
        } catch (Exception e) {
            log.error(e.getMessage(), e);
        }
        log.info("2022成功加载IP网段信息数：" + list.size());
    }

    public List<IPBean> save2Segment(TbSegementInfo segementInfo) {
        String ipStr = segementInfo.getSegment();
        if (StringUtils.isBlank(ipStr)) {
            return null;
        }
        List<IPBean> ipBeanList = new ArrayList<>();
        String[] ipList = IPUtil.getIpSegment(ipStr);
        for (String cidr : ipList) {
            try {
                long startIp2long;
                long endIp2long;
                if (cidr.contains("-") && cidr.contains("/")) {
                    String[] ips = cidr.split("-");
                    if (ips.length <= 1) {
                        continue;
                    }
                    startIp2long = IPUtil.getIp2long(getStartIp(ips[0].trim()));
                    endIp2long = IPUtil.getIp2long(getEndIp(ips[1].trim()));
                } else if (cidr.contains("-")) {
                    String[] ips = cidr.split("-");
                    if (ips.length <= 1) {
                        continue;
                    }
                    startIp2long = IPUtil.getIp2long(ips[0].trim());
                    endIp2long = IPUtil.getIp2long(ips[1].trim());
                } else if (cidr.contains("/")) {
                    startIp2long = IPUtil.getIp2long(getStartIp(cidr.trim()));
                    endIp2long = IPUtil.getIp2long(getEndIp(cidr.trim()));
                } else {
                    startIp2long = IPUtil.getIp2long(cidr.trim());
                    endIp2long = IPUtil.getIp2long(cidr.trim());
                }
                if (startIp2long > 0 && endIp2long > 0) {
                    ipBeanList.add(new IPBean(startIp2long, endIp2long, segementInfo));
                }
            } catch (Exception ignored) {

            }
        }
        return ipBeanList;
    }

    private String getStartIp(String segment) {
        StringBuilder startIp = new StringBuilder();
        if (segment == null) {
            return null;
        }
        String[] arr = segment.split("/");
        String ip = arr[0];
        if (arr.length < 2) {
            return null;
        }
        String maskIndex = arr[1];
        String mask = getNetMask(maskIndex);
        if (4 != ip.split("\\.").length || mask == null) {
            return null;
        }
        int[] ipArray = new int[4];
        int[] netMaskArray = new int[4];
        try {
            for (int i = 0; i < 4; i++) {
                ipArray[i] = DataUtils.toNum(ip.split("\\.")[i]);
                netMaskArray[i] = DataUtils.toNum(mask.split("\\.")[i]);
                if (ipArray[i] > 255 || ipArray[i] < 0 || netMaskArray[i] > 255 || netMaskArray[i] < 0) {
                    return null;
                }
                ipArray[i] = ipArray[i] & netMaskArray[i];
                if (i == 3) {
                    startIp.append(ipArray[i] + 1);
                } else {
                    startIp.append(ipArray[i]).append(".");
                }
            }
        } catch (Exception e) {
            return null;
        }
        return startIp.toString();
    }

    private String getEndIp(String segment) {
        StringBuilder endIp = new StringBuilder();
        String startIp = getStartIp(segment);
        if (segment == null || startIp == null) {
            return null;
        }
        if (4 != startIp.split("\\.").length) {
            return null;
        }
        String[] arr = segment.split("/");
        String maskIndex = arr[1];
        //实际需要的IP个数
        int hostNumber;
        int[] startIpArray = new int[4];
        try {
            hostNumber = 1 << 32 - (DataUtils.toNum(maskIndex));
            for (int i = 0; i < 4; i++) {
                startIpArray[i] = DataUtils.toNum(startIp.split("\\.")[i]);
                if (i == 3) {
                    startIpArray[i] = startIpArray[i] - 1;
                    break;
                }
            }
            startIpArray[3] = startIpArray[3] + (hostNumber - 1);


            if (startIpArray[3] > 255) {
                int k = startIpArray[3] / 256;
                startIpArray[3] = startIpArray[3] % 256;
                startIpArray[2] = startIpArray[2] + k;
            }
            if (startIpArray[2] > 255) {
                int j = startIpArray[2] / 256;
                startIpArray[2] = startIpArray[2] % 256;
                startIpArray[1] = startIpArray[1] + j;
                if (startIpArray[1] > 255) {
                    int k = startIpArray[1] / 256;
                    startIpArray[1] = startIpArray[1] % 256;
                    startIpArray[0] = startIpArray[0] + k;
                }
            }
            for (int i = 0; i < 4; i++) {
                if (i == 3) {
                    startIpArray[i] = startIpArray[i] - 1;
                }
                if ("".contentEquals(endIp) || endIp.length() == 0) {
                    endIp.append(startIpArray[i]);
                } else {
                    endIp.append(".").append(startIpArray[i]);
                }
            }
        } catch (Exception e) {
            return null;
        }


        return endIp.toString();
    }

    private String getNetMask(String maskIndex) {
        StringBuilder mask = new StringBuilder();
        int inetMask;
        try {
            inetMask = DataUtils.toNum(maskIndex);
        } catch (Exception e) {
            log.error(e.getMessage(),e);
            return null;
        }
        if (inetMask > 32) {
            return null;
        }
        try {
            // 子网掩码为1占了几个字节
            int num1 = inetMask / 8;
            // 子网掩码的补位位数
            int num2 = inetMask % 8;
            int[] array = new int[4];
            for (int i = 0; i < num1; i++) {
                array[i] = 255;
            }
            for (int i = num1; i < 4; i++) {
                array[i] = 0;
            }
            for (int i = 0; i < num2; num2--) {
                array[num1] += 1 << 8 - num2;
            }
            for (int i = 0; i < 4; i++) {
                if (i == 3) {
                    mask.append(array[i]);
                } else {
                    mask.append(array[i]).append(".");
                }
            }
        } catch (Exception e) {
            return null;
        }
        return mask.toString();
    }
}
