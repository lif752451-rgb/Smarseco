package com.crc.log.flink.parse;

import com.alibaba.fastjson.JSONObject;
import com.crc.log.flink.common.constants.LevelConstants;
import com.crc.log.flink.common.constants.LogConstants;
import com.crc.log.flink.common.entity.SbrProdType;
import com.crc.log.flink.common.utils.DataUtils;
import com.crc.log.flink.common.utils.DateUtils;
import com.crc.log.flink.common.utils.JsonUtils;
import com.crc.log.flink.common.utils.MapUtils;
import com.crc.log.flink.load.SbrProdTypeLoad;
import org.apache.commons.lang3.StringUtils;

import java.util.concurrent.ConcurrentHashMap;

//中国生物 圣博睿日志审计解析类
public class ResolvSbrLog {
    public static ConcurrentHashMap<String, Object> parse(String message) {
        try {
            ConcurrentHashMap<String, Object> data = proc(message);
            if (DataUtils.isNotEmptyJson(data)) {
                return data;
            }
        } catch (Exception ignored) {

        }
        return null;
    }

    private static ConcurrentHashMap<String, Object> proc(String jsonStr) {
        ConcurrentHashMap<String, Object> ldapJson = new ConcurrentHashMap<>();
        try {
            jsonStr = DataUtils.getSubString(jsonStr, DataUtils.getIndex(jsonStr, "{"));
            //jsonStr.substring(jsonStr.indexOf("{"));
            jsonStr = DataUtils.getSubString(jsonStr, 0, DataUtils.getLastIndex(jsonStr, "}") + 1);
            //jsonStr.substring(0, jsonStr.lastIndexOf("}") + 1);
            JSONObject jObj = JsonUtils.parse(jsonStr);
            if (JsonUtils.isEmpty(jObj)) {
                return ldapJson;
            }

            String fieldValues = JsonUtils.getStr(jObj, "fieldValues");
            jObj = JsonUtils.parse(fieldValues);
            ldapJson.put(LogConstants.LOG_PRODUCT, "圣博润日志审计");
            MapUtils.setStr(ldapJson, LogConstants.LOG_TIME, DateUtils.getSparkTime());
            //String removeIds = "lid";
            ldapJson.remove("lid");
            MapUtils.setStr(ldapJson, LogConstants.SRC_IP, jObj, "ccolletorip");
            MapUtils.setStr(ldapJson, LogConstants.SRC_IP, jObj, "cdevip");
            MapUtils.setStr(ldapJson, LogConstants.LOG_DEV_IP, jObj, "cdevip");
            MapUtils.setStr(ldapJson, LogConstants.ACTION_RESULT, jObj, "cresult");
            MapUtils.setStr(ldapJson, LogConstants.LOG_NAME, jObj, "ceventname");
            MapUtils.setStr(ldapJson, LogConstants.ALERT_NAME, jObj, "ceventname");
            MapUtils.setStr(ldapJson, LogConstants.ACTION_TYPE, jObj, "coritype");
            MapUtils.setStr(ldapJson, LogConstants.LOG_ORI_MSG, jObj, "corilog");

            if (jObj.containsKey("csip")) {
                MapUtils.setStr(ldapJson, LogConstants.SRC_IP, jObj, "csip");
            }
            if (jObj.containsKey("cdip")) {
                MapUtils.setStr(ldapJson, LogConstants.DEST_IP, jObj, "cdip");
            }
            String msg = MapUtils.getStr(ldapJson, "corilog");
            try {
                if (msg.contains("源IP")) {
                    String[] arr = msg.split(",");
                    for (String str : arr) {
                        if (!str.contains(":"))
                            continue;
                        String[] arrx = DataUtils.getSplit2(str, ":");
                        //str.split(":");
                        if (arrx.length != 2)
                            continue;
                        String data = arrx[0];
                        String val = arrx[1];
                        if ("源IP".equals(data)) {
                            MapUtils.setStr(ldapJson, LogConstants.SRC_IP, val);
                        } else if ("系统动作".equals(data)) {
                            MapUtils.setStr(ldapJson, LogConstants.ACTION_RESULT, val);
                        } else if ("目的IP".equals(data)) {
                            MapUtils.setStr(ldapJson, LogConstants.DEST_IP, val);
                        }
                    }
                }
            } catch (Exception ignored) {

            }

            if (MapUtils.isBlank(ldapJson, LogConstants.LOG_NAME)) {
                MapUtils.setStr(ldapJson, LogConstants.LOG_NAME, "行为日志");
            }
            int severity = JsonUtils.getInt(jObj, "coripriority");
            if (severity <= 0) {
                ldapJson.put(LogConstants.LOG_LEVEL, LevelConstants.INFO);
            } else if (severity > 4) {
                ldapJson.put(LogConstants.LOG_LEVEL, LevelConstants.INFO);
            } else if (severity > 2) {
                ldapJson.put(LogConstants.LOG_LEVEL, LevelConstants.MEDIUM);
            } else {
                ldapJson.put(LogConstants.LOG_LEVEL, LevelConstants.HIGH);
            }

            if (SbrProdTypeLoad.sbrMap.size() > 0) {
                for (String value : SbrProdTypeLoad.sbrMap.keySet()) {
                    SbrProdType sp = SbrProdTypeLoad.sbrMap.get(value);
                    if (sp != null && ldapJson.containsKey(sp.getKey())) {
                        if (sp.getValue() != null && sp.getValue().equalsIgnoreCase(MapUtils.getStr(ldapJson, sp.getKey()))) {
                            MapUtils.setStr(ldapJson, LogConstants.LOG_PRODUCT, sp.getProduct());
                            MapUtils.setStr(ldapJson, "es_index", sp.getIndex());
                        }
                    }
                }
            }
            ldapJson.put(LogConstants.LOG_LEVEL, LevelConstants.getLevel(MapUtils.getStr(ldapJson, LogConstants.LOG_LEVEL)));
            if (StringUtils.isBlank(MapUtils.getStr(ldapJson, LogConstants.SRC_IP))) {
                ldapJson.put(LogConstants.SRC_IP, "0.0.0.0");
            }
            if (StringUtils.isBlank(MapUtils.getStr(ldapJson, LogConstants.DEST_IP))) {
                ldapJson.put(LogConstants.DEST_IP, "0.0.0.0");
            }
            setAlertName(ldapJson);
            return ldapJson;
        } catch (Exception e) {
            return ldapJson;
        }
    }

    private static void setAlertName(ConcurrentHashMap<String, Object> ldapJson) {
        String srcIp = MapUtils.getStr(ldapJson, LogConstants.SRC_IP);
        String destIp = MapUtils.getStr(ldapJson, LogConstants.DEST_IP);
        String name = MapUtils.getStr(ldapJson, LogConstants.LOG_NAME);
        String content = MapUtils.getStr(ldapJson, LogConstants.LOG_ORI_MSG);
        String msgFormat = "IP为:%s对IP为:%s发起了一个:%s的访问,日志详情为:%s";
        String alertName = String.format(msgFormat, srcIp, destIp, name, content);
        ldapJson.put(LogConstants.ALERT_NAME, alertName);

    }

}

