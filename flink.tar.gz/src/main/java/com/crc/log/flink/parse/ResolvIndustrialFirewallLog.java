package com.crc.log.flink.parse;


import com.crc.log.flink.common.constants.LogConstants;
import com.crc.log.flink.common.utils.DataUtils;
import com.crc.log.flink.common.utils.JsonUtils;
import com.crc.log.flink.common.utils.MapUtils;
import org.apache.commons.lang3.StringUtils;

import java.util.HashMap;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

/**
 * @author jixiangqi
 * @date 2022/4/16
 * 工业防火墙
 */
public class ResolvIndustrialFirewallLog {
    public static ConcurrentHashMap<String,Object> parse(String message) {
        try {
            ConcurrentHashMap<String,Object> data = proc(message);
            if (DataUtils.isNotEmptyJson(data)) {
                return data;
            }
        } catch (Exception ignored) {

        }
        return null;
    }

    private static ConcurrentHashMap<String,Object> proc(String jsonStr) {
        ConcurrentHashMap<String,Object> rtnObjc = JsonUtils.createBaseMap(jsonStr);
        Map<String, String> stringMap = getValueBySpace(jsonStr);
        stringMap.forEach((k,v) -> {
            switchKeyValue(rtnObjc, k ,v);
        });
        //rtnObjc.put(LogConstants.LOG_LEVEL, LevelConstants.getLevel(rtnObjc.getString(LogConstants.LOG_LEVEL)));
        if (org.apache.commons.lang3.StringUtils.isBlank(MapUtils.getStr(rtnObjc, LogConstants.SRC_IP))) {
            rtnObjc.put(LogConstants.SRC_IP, "0.0.0.0");
        }
        if (StringUtils.isBlank(MapUtils.getStr(rtnObjc, LogConstants.DEST_IP))) {
            rtnObjc.put(LogConstants  .DEST_IP, "0.0.0.0");
        }
        rtnObjc.put(LogConstants.LOG_PRODUCT, "工业防火墙");
        setAlertName(rtnObjc);
        return rtnObjc;
    }

    private static Map<String, String> getValueBySpace(String jsonStr) {
        Map<String, String> resultMap = new HashMap<>();
        String[] s = DataUtils.getSplit(jsonStr, " ");
        String index = "";
        for (String item : s) {
            String tempStr = item.replaceAll("\"", "");
            if (tempStr.contains("=")) {
                String[] split = DataUtils.getSplit(tempStr, "=");
                if (split.length == 2) {
                    String key = split[0].trim();
                    String value = split[1].trim();
                    index = key;
                    resultMap.put(key, value);
                } else {
                    String key = split[0].trim();
                    index = key;
                    resultMap.put(key, "");
                }
            } else {
                resultMap.put(index, resultMap.get(index) + " " + tempStr);
            }
        }
        return resultMap;
    }


    private static void switchKeyValue(ConcurrentHashMap<String,Object> rtnObjc, String key, Object value) {
        switch (key) {
            case "devid":
                rtnObjc.put(LogConstants.DEVICE_ID, value);
                break;
            case "dname":
                rtnObjc.put(LogConstants.DEVICE_NAME, value);
                break;
            case "severity":
                rtnObjc.put(LogConstants.LOG_LEVEL, value);
                break;
            case "type":
                rtnObjc.put(LogConstants.LOG_TYPE, value);
                break;
            case "time":
                rtnObjc.put(LogConstants.LOG_START_TIME, value);
                break;
            case "user":
                rtnObjc.put(LogConstants.USER_NAME, value);
                break;
            case "from":
                rtnObjc.put(LogConstants.OS_INFO, value);
                break;
            case "addr_src":
                rtnObjc.put(LogConstants.SRC_IP, value);
                break;
            case "msg_cn":
                rtnObjc.put(LogConstants.LOG_DESCRIPTION, value);
                break;
            case "addr_dst":
                rtnObjc.put(LogConstants.DEST_IP, value);
                break;
            case "proto":
                rtnObjc.put(LogConstants.LOG_PROTOCAL, value);
                break;
            case "hit_num":
                rtnObjc.put(LogConstants.LOG_COUNT, value);
                break;
            case "action":
                rtnObjc.put(LogConstants.ACTION_RESULT, value);
                break;
            case "port_src":
                rtnObjc.put(LogConstants.SRC_PORT, value);
                break;
            case "port_dst":
                rtnObjc.put(LogConstants.DEST_PORT, value);
                break;
            case "duration":
                rtnObjc.put(LogConstants.TRAFFIC_DURATION, value);
                break;
            case "bytes_sent":
                rtnObjc.put(LogConstants.UP_FLUX, value);
                break;
            case "bytes_received":
                rtnObjc.put(LogConstants.DOWN_FLUX, value);
                break;
            case "direction":
                rtnObjc.put(LogConstants.ACTION_TYPE, value);
                break;
            case "content_type":
                rtnObjc.put(LogConstants.SRC_PORT, value);
                break;
            case "filename":
                rtnObjc.put(LogConstants.LOG_FILENAME, value);
                break;
            case "filetype":
                rtnObjc.put(LogConstants.FILE_TYPE, value);
                break;
            case "behavior_proto":
                rtnObjc.put(LogConstants.LOG_TYPE, "行为日志");
                rtnObjc.put(LogConstants.LOG_PROTOCAL, value);
                break;
            case "behavior_commond":
                rtnObjc.put(LogConstants.BEHAVIOR_TAG, value);
                break;
            case "attacker_ip":
                rtnObjc.put(LogConstants.SRC_IP, value);
                break;
            case "victim_ip":
                rtnObjc.put(LogConstants.DEST_IP, value);
                break;
            case "filepath":
                rtnObjc.put(LogConstants.FILE_PATH, value);
                break;
            case "url":
                rtnObjc.put(LogConstants.LOG_URL, value);
                break;
            case "threat_type":
                rtnObjc.put(LogConstants.THREAT_TYPE, value);
                break;
            case "threat_name":
                rtnObjc.put(LogConstants.THREAT_NAME, value);
                break;
            case "detail":
                rtnObjc.put(LogConstants.LOG_DESCRIPTION, value);
                break;
            case "threat_severity":
                rtnObjc.put(LogConstants.LOG_LEVEL, value);
                break;
            case "icpe_whitelist_protocol":
                rtnObjc.put(LogConstants.LOG_TYPE, "白名单日志");
                rtnObjc.put(LogConstants.LOG_PROTOCAL, value);
                break;
            case "icpe_whitelist_detail":
                rtnObjc.put(LogConstants.LOG_DESCRIPTION, value);
                break;
            case "confidence":
                rtnObjc.put(LogConstants.LOG_TYPE, "威胁日志");
                break;
            case "keyword":
                rtnObjc.put(LogConstants.LOG_TYPE, "内容日志");
                break;
            case "to_tunnel":
                rtnObjc.put(LogConstants.LOG_TYPE, "流量日志");
                break;
        }
    }

    private static void setAlertName(ConcurrentHashMap<String,Object> rtnObjc) {
        String eventType = MapUtils.getStr(rtnObjc, LogConstants.LOG_TYPE);
        String log = MapUtils.getStr(rtnObjc, LogConstants.LOG_ORI_MSG);
        String message = "";
        String alertName = "";
        if (eventType.equals("traffic-end")) {
            String srcIp = MapUtils.getStr(rtnObjc, LogConstants.SRC_IP);
            String proto = MapUtils.getStr(rtnObjc, LogConstants.LOG_PROTOCAL);
            String destIp = MapUtils.getStr(rtnObjc, LogConstants.DEST_IP);
            String result = MapUtils.getStr(rtnObjc, LogConstants.ACTION_RESULT);
            message = "IP地址为:%s对IP为:%s发起了一个流量日志的行为,访问协议为:%s,访问结果为:%s,日志详情为:%s";
            alertName = String.format(message, srcIp, destIp, proto, result, log);
        } else if (eventType.equals("system")) {
            String levle = MapUtils.getStr(rtnObjc, LogConstants.LOG_LEVEL);
            String desc = MapUtils.getStr(rtnObjc, LogConstants.LOG_DESCRIPTION);
            message = "系统产生了一个日志,日志级别为:%s,日志描述为:%s,日志详情为:%s";
            alertName = String.format(message, levle, desc, log);
        } 
        rtnObjc.put(LogConstants.ALERT_NAME, alertName);
    }

}
