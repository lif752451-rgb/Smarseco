package com.crc.log.flink.common.entity;

import lombok.Data;

import java.io.Serializable;

/**
 * 资产信息对象 tb_asset
 *
 * @author lgl
 * @date 2020-07-15
 */
@Data
public class TbAsset implements Serializable {

    private String ip;

    private String companyName;

    private String instance;

    String area;
    String subArea;

    String affiliationDeptName;

    String areaName;
}
