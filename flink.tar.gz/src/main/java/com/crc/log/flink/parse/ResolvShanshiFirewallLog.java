package com.crc.log.flink.parse;

import com.alibaba.fastjson.JSONObject;
import com.crc.log.flink.common.constants.LevelConstants;
import com.crc.log.flink.common.constants.LogConstants;
import com.crc.log.flink.common.utils.DataUtils;
import com.crc.log.flink.common.utils.DateUtils;
import com.crc.log.flink.common.utils.JsonUtils;
import com.crc.log.flink.common.utils.MapUtils;
import org.apache.commons.lang3.StringUtils;

import java.util.concurrent.ConcurrentHashMap;

/**
 * 山石防火墙
 */
public class ResolvShanshiFirewallLog {

    /**
     * 华为防火墙 USG9560 日志泛化
     */
    public static ConcurrentHashMap<String, Object> parse(String message) {
        try {
            ConcurrentHashMap<String, Object> data = proc(message);
            if (DataUtils.isNotEmptyJson(data)) {
                return data;
            }
        } catch (Exception ignored) {

        }
        return null;
    }

    private static ConcurrentHashMap<String, Object> proc(String jsonStr) {
        ConcurrentHashMap<String, Object> rtnObjc = JsonUtils.createBaseMap(jsonStr);

        JSONObject dataJson = new JSONObject();
        if (jsonStr.contains("fwlog")) {
            int pos = DataUtils.getIndex(jsonStr, "fwlog");
                    //jsonStr.indexOf("fwlog");
            if (pos != -1) {
                String value = DataUtils.getSubString(jsonStr, pos+"fwlog".length() + 1);
                        //jsonStr.substring(pos + "fwlog".length() + 1);
                String[] IPS_buff = DataUtils.getSplit(value, ", ");
                        //value.split(", ");
                setHostAndOs(IPS_buff, dataJson);
                parseFirewallJson(rtnObjc, dataJson);
            }
        }
        rtnObjc.put(LogConstants.LOG_LEVEL, LevelConstants.getLevel(MapUtils.getStr(rtnObjc,LogConstants.LOG_LEVEL)));
        if (StringUtils.isBlank(MapUtils.getStr(rtnObjc, LogConstants.SRC_IP))) {
            rtnObjc.put(LogConstants.SRC_IP, "0.0.0.0");
        }
        if (StringUtils.isBlank(MapUtils.getStr(rtnObjc, LogConstants.DEST_IP))) {
            rtnObjc.put(LogConstants.DEST_IP, "0.0.0.0");
        }
        rtnObjc.put(LogConstants.LOG_PRODUCT, "山石防火墙");
        setAlertName(rtnObjc);
        return rtnObjc;
    }

    public static void parseFirewallJson(ConcurrentHashMap<String, Object> rtnObjc, JSONObject dataJson) {
        rtnObjc.put(LogConstants.DEST_IP, JsonUtils.getStr(dataJson, "目的IP"));
        rtnObjc.put(LogConstants.SRC_IP, JsonUtils.getStr(dataJson, "源IP"));//源IP
        rtnObjc.put(LogConstants.SRC_PORT, JsonUtils.getStr(dataJson, "源端口"));
        rtnObjc.put(LogConstants.DEST_PORT, JsonUtils.getStr(dataJson, "目的端口"));
        //time=2020/6/18 16:33:55,
        rtnObjc.put(LogConstants.LOG_START_TIME, DateUtils.getISO8601Timestamp(JsonUtils.getStr(dataJson, "time"), "yyyy/MM/dd HH:mm:ss"));
        //rtnObjc.put(LogConstants.OP_NAME, dataJson.get("application-name"));
        rtnObjc.put(LogConstants.ACTION_RESULT, JsonUtils.getStr(dataJson, "系统动作"));
        rtnObjc.put(LogConstants.LOG_COUNT, 1);
        rtnObjc.put(LogConstants.ACTION_TYPE, JsonUtils.getStr(dataJson, "日志类型"));
        rtnObjc.put(LogConstants.LOG_PRODUCT, "山石防火墙");
        rtnObjc.put(LogConstants.ACTION_RULE, JsonUtils.getStr(dataJson, "策略名称"));
        rtnObjc.put(LogConstants.LOG_LEVEL, LevelConstants.INFO);
    }

    /**
     * <134>Oct 12 10:47:00 localhost fwlog: 日志类型:服务控制或应用控制, 策略名称:禁止服务器访问互联网, 用户:(null), 源IP:10.72.49.189, 源端口:60846, 目的IP:101.227.27.46, 目的端口:80, 应用类型:HTTP应用, 应用名称:any, 系统动作:拒绝
     *
     * @param IPS_buff
     * @param dataJson
     */
    public static void setHostAndOs(String[] IPS_buff, JSONObject dataJson) {
        for (String s : IPS_buff) {
            String[] datakey = DataUtils.getSplit2(s, ":");
            //IPS_buff[i].split(":");
            if (1 < datakey.length) {
                dataJson.put(datakey[0].trim(), datakey[1].trim());
            }

        }
    }

    private static void setAlertName(ConcurrentHashMap<String, Object> rtnObjc) {
        String msgFormat = "源IP地址为:%s,目的IP:%s,风险级别为:%s,操作类型:%s,操作结果:%s,日志详情为:%s";
        String level = MapUtils.getStr(rtnObjc,LogConstants.LOG_LEVEL);
        String srcIp = MapUtils.getStr(rtnObjc,LogConstants.SRC_IP);
        String destIp = MapUtils.getStr(rtnObjc,LogConstants.DEST_IP);
        String result = MapUtils.getStr(rtnObjc,LogConstants.ACTION_RESULT);
        String type = MapUtils.getStr(rtnObjc,LogConstants.ACTION_TYPE);
        String log = MapUtils.getStr(rtnObjc,LogConstants.LOG_ORI_MSG);
        String alertName = String.format(msgFormat, srcIp, destIp, level, type, result, log);

        rtnObjc.put(LogConstants.ALERT_NAME, alertName);
    }
}
