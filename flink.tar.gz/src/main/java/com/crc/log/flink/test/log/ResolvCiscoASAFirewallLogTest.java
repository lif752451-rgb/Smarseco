package com.crc.log.flink.test.log;

import com.crc.log.flink.common.utils.JsonUtils;
import com.crc.log.flink.config.AllConfig;
import com.crc.log.flink.es.DataProcessFuncation;

import java.util.concurrent.ConcurrentHashMap;

/**
 * @author jixiangqi
 * @date 2022/1/17
 */
public class ResolvCiscoASAFirewallLogTest {


    public static void main(String[] args) {
        AllConfig config = new AllConfig();
        DataProcessFuncation.CONIFG = config;
        config.setMode("single");
        config.setParse("ResolvCiscoASAFirewallLog");
        config.setIndex("sec_all");

        String str = "<189>date=2022-05-13 time=14:45:47 devname=\\\"OA-ETAS-FG1100E-B\\\" devid=\\\"FG10E0TB21900734\\\" eventtime=1652424348215315743 tz=\\\"+0800\\\" logid=\\\"0000000013\\\" type=\\\"traffic\\\" subtype=\\\"forward\\\" level=\\\"notice\\\" vd=\\\"root\\\" srcip=10.108.164.171 srcport=58076 srcintf=\\\"port26\\\" srcintfrole=\\\"undefined\\\" dstip=10.115.250.170 dstport=59001 dstintf=\\\"port25\\\" dstintfrole=\\\"undefined\\\" srccountry=\\\"Reserved\\\" dstcountry=\\\"Reserved\\\" sessionid=2152660182 proto=6 action=\\\"close\\\" policyid=4703 policytype=\\\"policy\\\" poluuid=\\\"4229a92c-a8eb-51ec-b9de-85f235e571f2\\\" policyname=\\\"SZ_EDA_to_SUZ\\\" service=\\\"TCP-59001\\\" trandisp=\\\"noop\\\" duration=2 sentbyte=519 rcvdbyte=307 sentpkt=7 rcvdpkt=5 appcat=\\\"unscanned\\";
        ConcurrentHashMap<String, Object> proc = DataProcessFuncation.parse(str, "index");
        JsonUtils.printStr(proc);

        str = "<164>Jan 17 2022 05:49:45: %ASA-4-500004: Invalid transport field for protocol=UDP, from 10.168.173.2/12345 to 218.77.122.3/0";
        proc = DataProcessFuncation.parse(str,"index");
        JsonUtils.printStr(proc);

        str = "<162>Jan 17 2022 05:49:45: %ASA-2-106001: Inbound TCP connection denied from 138.19.183.226/56044 to 106.37.235.232/15000 flags SYN on interface outside";
        proc = DataProcessFuncation.parse(str,"index");
        JsonUtils.printStr(proc);

        str = "<163>Jan 17 2022 05:49:46: %ASA-3-106014: Deny inbound icmp src outside:106.37.235.225 dst outside:106.37.235.225 (type 0, code 0)";
        proc = DataProcessFuncation.parse(str,"index");
        JsonUtils.printStr(proc);
    }

}
