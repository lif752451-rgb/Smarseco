package com.crc.log.flink.parse;

import com.crc.log.flink.common.constants.LevelConstants;
import com.crc.log.flink.common.constants.LogConstants;
import com.crc.log.flink.common.utils.*;
import org.apache.commons.lang3.StringUtils;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;
import java.util.concurrent.ConcurrentHashMap;

/**
 * @author jixiangqi
 * @date 2022/5/9
 * 安恒明御网关
 */
public class ResolvAnGyAPTLog {

    static SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");

    public static ConcurrentHashMap<String, Object> parse(String message) {
        try {
            ConcurrentHashMap<String, Object> data = proc(message);
            if (DataUtils.isNotEmptyJson(data)) {
                return data;
            }
        } catch (Exception ignored) {

        }
        return null;
    }

    private static ConcurrentHashMap<String, Object> proc(String jsonStr) {
        ConcurrentHashMap<String, Object> rtnObjc = JsonUtils.createBaseMap(jsonStr);
        if (jsonStr.contains("Free") || jsonStr.contains("APP") || jsonStr.contains("Wechat")
                || jsonStr.contains("Local") || jsonStr.contains("Sms") || jsonStr.contains("Portal")
                || jsonStr.contains("SSO") || jsonStr.contains("二维码") || jsonStr.contains("POP3")
                || jsonStr.contains("IC卡") || jsonStr.contains("钉钉") || jsonStr.contains("SSL VPN")) {
            getLoginOrOut(rtnObjc, jsonStr);
        } else if (jsonStr.contains("nat:") && !jsonStr.contains("src_ip")) {
            int index = DataUtils.getIndex(jsonStr, "user");
            String tempStr = DataUtils.getSubString(jsonStr, "user".length() + index);
            index = DataUtils.getIndex(tempStr, ",");
            tempStr = DataUtils.getSubString(tempStr, 0, index);
            rtnObjc.put(LogConstants.LOG_DEV_IP, tempStr.trim());
        } else {
            String[] split = DataUtils.getSplit(jsonStr, ";");
            if (split.length == 1) {
                if (jsonStr.contains("@")) {
                    List<String> ips = IPUtil.getIps(jsonStr);
                    if (ips.size() > 0) {
                        rtnObjc.put(LogConstants.LOG_DEV_IP, ips.get(0));
                    }
                    int index = DataUtils.getIndex(jsonStr, "@");
                    String userName = DataUtils.getSubString(jsonStr, 0, index);
                    rtnObjc.put(LogConstants.USER_NAME, userName);
                }
            } else if (jsonStr.contains("system_state")) {
                int lastIndex = DataUtils.getLastIndex(jsonStr, ":");
                String content = DataUtils.getSubString(jsonStr, lastIndex + 1).trim();
                rtnObjc.put(LogConstants.LOG_CONTENT, content);
            } else {
                for (String tempStr : split) {
                    if (tempStr.contains("=")) {
                        int index = DataUtils.getIndex(tempStr, "=");
                        String key = DataUtils.getSubString(tempStr, 0, index).trim();
                        if (key.contains(":")) {
                            int index1 = DataUtils.getIndex(key, ":");
                            key = DataUtils.getSubString(key, index1 + 1).trim();
                        }
                        String value = DataUtils.getSubString(tempStr, index + 1).trim();
                        switchKeyValue(rtnObjc, key, value, jsonStr);
                    } else if (tempStr.contains(":") && !tempStr.contains("=")) {
                        int index = DataUtils.getIndex(tempStr, ":");
                        String key = DataUtils.getSubString(tempStr, 0, index).trim();
                        if (key.contains(":")) {
                            int index1 = DataUtils.getIndex(key, ":");
                            key = DataUtils.getSubString(key, index1 + 1).trim();
                        }
                        String value = DataUtils.getSubString(tempStr, index + 1).trim();
                        switchKeyValue(rtnObjc, key, value, jsonStr);
                    }
                }
            }
        }
        if (StringUtils.isBlank(MapUtils.getStr(rtnObjc, LogConstants.SRC_IP))) {
            rtnObjc.put(LogConstants.SRC_IP, "0.0.0.0");
        }
        if (StringUtils.isBlank(MapUtils.getStr(rtnObjc, LogConstants.DEST_IP))) {
            rtnObjc.put(LogConstants.DEST_IP, "0.0.0.0");
        }
        if (StringUtils.isBlank(MapUtils.getStr(rtnObjc, LogConstants.LOG_LEVEL))) {
            rtnObjc.put(LogConstants.LOG_LEVEL, LevelConstants.getLevel(MapUtils.getStr(rtnObjc,LogConstants.LOG_LEVEL)));
        }
        rtnObjc.put(LogConstants.LOG_PRODUCT, "安恒明御网关");
        setAlertName(rtnObjc, jsonStr);
        return rtnObjc;
    }

    private static void setAlertName(ConcurrentHashMap<String,Object> rtnObjc, String jsonStr) {
        String message = "";
        String alertName = "";
        String srcIp = MapUtils.getStr(rtnObjc, LogConstants.SRC_IP);
        String destIp = MapUtils.getStr(rtnObjc, LogConstants.DEST_IP);
        String logLevel = MapUtils.getStr(rtnObjc, LogConstants.LOG_LEVEL);
        if (StringUtils.isBlank(logLevel)) {
            rtnObjc.put(LogConstants.LOG_LEVEL, getLevel("6"));
            logLevel = getLevel("6");
        }
        String actionType = MapUtils.getStr(rtnObjc, LogConstants.ACTION_TYPE);
        String proto = MapUtils.getStr(rtnObjc, LogConstants.LOG_PROTOCAL);
        if (jsonStr.contains("operator_name")) {
            String userName = MapUtils.getStr(rtnObjc, LogConstants.USER_NAME);
            String actionResult = MapUtils.getStr(rtnObjc, LogConstants.ACTION_RESULT);
            String content = MapUtils.getStr(rtnObjc, LogConstants.LOG_CONTENT);
            message = "用户名为:%s的管理员在IP为:%s的设备上进行了:%s操作,操作结果为:%s,日志级别为:%s";
            alertName = String.format(message, userName, srcIp, content, actionResult, logLevel);
            rtnObjc.put(LogConstants.LOG_TYPE, "操作日志");
        } else if (jsonStr.contains("device_health")) {
            String memory = MapUtils.getStr(rtnObjc, LogConstants.MEMORY);
            String disk = MapUtils.getStr(rtnObjc, LogConstants.DISK);
            String cpu = MapUtils.getStr(rtnObjc, LogConstants.CPU);
            String count = MapUtils.getStr(rtnObjc, LogConstants.SESSION_COUNT);
            String temperature = MapUtils.getStr(rtnObjc, LogConstants.TEMPERATURE);
            message = "当前系统的cpu使用率为:%s,磁盘使用率为:%s,内存使用率为:%s,温度为:%s,会话数为:%s";
            alertName = String.format(message, cpu, disk, memory, temperature, count);
        } else if (jsonStr.contains("ips:")) {
            String actionResult = MapUtils.getStr(rtnObjc, LogConstants.ACTION_RESULT);
            String count = MapUtils.getStr(rtnObjc, LogConstants.LOG_COUNT);
            String logName = MapUtils.getStr(rtnObjc, LogConstants.LOG_NAME);
            message = "IP为:%s对IP为:%s进行的告警攻击,告警名称为:%s,告警结果为:%s,告警级别为:%s,告警次数为:%s,访问协议为:%s";
            alertName = String.format(message, srcIp, destIp, logName, actionResult, logLevel, count, proto);
        } else if (jsonStr.contains("AV")) {
            String virusName = MapUtils.getStr(rtnObjc, LogConstants.VIRUS_NAME);
            String fileName = MapUtils.getStr(rtnObjc, LogConstants.LOG_FILENAME);
            message = "IP为:%s对IP为:%s进行了病毒攻击,病毒名称为:%s,文件名称为:%s,攻击类型为:%s,病毒级别为:%s,访问协议为:%s";
            alertName = String.format(message, srcIp, destIp, virusName, fileName, actionType, logLevel, proto);
        } else if (jsonStr.contains("security")) {
            String count = MapUtils.getStr(rtnObjc, LogConstants.LOG_COUNT);
            String logName = MapUtils.getStr(rtnObjc, LogConstants.LOG_NAME);
            message = "IP为:%s对IP为:%s进行了:%s类型的网络攻击,日志名称为:%s,日志级别为:%s,攻击次数为:%s,攻击协议为:%s";
            alertName = String.format(message, srcIp, destIp, actionType, logName, logLevel, count, proto);
        } else if (jsonStr.contains("waf")) {
            String actionResult = MapUtils.getStr(rtnObjc, LogConstants.ACTION_RESULT);
            String descript = MapUtils.getStr(rtnObjc, LogConstants.LOG_DESCRIPTION);
            String url = MapUtils.getStr(rtnObjc, LogConstants.LOG_URL);
            message = "IP为:%s对IP为:%s进行了:%s类型的网络攻击,攻击结果为:%s,日志级别为:%s,攻击url为:%s,日志描述为:%s";
            alertName = String.format(message, srcIp, destIp, actionType, actionResult, logLevel, url, descript);
        } else if (jsonStr.contains("wpd")) {
            String log = MapUtils.getStr(rtnObjc, LogConstants.LOG_ORI_MSG);
            message = "IP为:%s对IP为:%s产生了一个弱密码防护策略类型的日志,日志详情为:%s";
            alertName = String.format(message, srcIp, destIp, log);
        } else if (jsonStr.contains("bfd")) {
            String log = MapUtils.getStr(rtnObjc, LogConstants.LOG_ORI_MSG);
            String logName = MapUtils.getStr(rtnObjc, LogConstants.LOG_NAME);
            String actionResult = MapUtils.getStr(rtnObjc, LogConstants.ACTION_RESULT);
            message = "IP为:%s对IP为:%s产生了一个防暴力破解规则类型的日志,日志名称为:%s,攻击结果为:%s,日志详情为:%s";
            alertName = String.format(message, srcIp, destIp, logName, actionResult, log);
        } else if (jsonStr.contains("servconn_policy")) {
            String log = MapUtils.getStr(rtnObjc, LogConstants.LOG_ORI_MSG);
            String actionResult = MapUtils.getStr(rtnObjc, LogConstants.ACTION_RESULT);
            message = "在IP地址为:%s上产生了\"匹配到非法外联防护策略\"类型的日志,日志结果为:%s,日志详情为:%s";
            alertName = String.format(message, srcIp, actionResult, log);
        } else if (jsonStr.contains("behavior_model")) {
            String actionResult = MapUtils.getStr(rtnObjc, LogConstants.ACTION_RESULT);
            String descript = MapUtils.getStr(rtnObjc, LogConstants.LOG_DESCRIPTION);
            String content = MapUtils.getStr(rtnObjc, LogConstants.LOG_CONTENT);
            message = "IP为:%s对IP为:%s进行了:%s类型的网络攻击,攻击结果为:%s,日志级别为:%s,告警内容为:%s,日志描述为:%s";
            alertName = String.format(message, srcIp, destIp, actionType, actionResult, logLevel, content, descript);
        } else if (jsonStr.contains("ti:")) {
            String threatName = MapUtils.getStr(rtnObjc, LogConstants.THREAT_NAME);
            String log = MapUtils.getStr(rtnObjc, LogConstants.LOG_ORI_MSG);
            message = "IP为:%s对IP为:%s产生了命中威胁情报,威胁名称为:%s,日志描述为:%s";
            alertName = String.format(message, srcIp, destIp, threatName, log);
        } else if (jsonStr.contains("edr_spread")) {
            String log = MapUtils.getStr(rtnObjc, LogConstants.LOG_ORI_MSG);
            message = "IP为:%s对IP为:%s产生了EDR推广策略日志,日志级别为:%s,攻击方式为:%s,访问协议为:%s,日志详情:%s";
            alertName = String.format(message, srcIp, destIp, logLevel, actionType, proto, log);
        } else if (jsonStr.contains("policy_detail")) {
            String log = MapUtils.getStr(rtnObjc, LogConstants.LOG_ORI_MSG);
            String actionResult = MapUtils.getStr(rtnObjc, LogConstants.ACTION_RESULT);
            message = "IP为:%s对IP为:%s产生了策略规则日志,日志级别为:%s,攻击结果为:%s,访问协议为:%s,日志详情:%s";
            alertName = String.format(message, srcIp, destIp,logLevel, actionResult, proto, log);
        } else if (jsonStr.contains("nat:")) {
            if (srcIp.equals("0.0.0.0")) {
                String log = MapUtils.getStr(rtnObjc, LogConstants.LOG_ORI_MSG);
                String devIp = MapUtils.getStr(rtnObjc, LogConstants.LOG_DEV_IP);
                message = "设备IP为:%s配置NAT44规则,日志详情为:%s";
                alertName = String.format(message, devIp, log);
            } else {
                message = "IP为:%s对IP为:%s产生了NAT规则日志,日志级别为:%s,攻击方式为:%s,访问协议为:%s";
                alertName = String.format(message, srcIp, destIp,logLevel, actionType, proto);
            }
        } else if (jsonStr.contains("quota")) {
            String devIp = MapUtils.getStr(rtnObjc, LogConstants.LOG_DEV_IP);
            String descritpion = MapUtils.getStr(rtnObjc, LogConstants.LOG_DESCRIPTION);
            message = "设备IP为:%s的用户流量使用超出了额定阈值,日志描述为:%s,日志级别为:%s";
            alertName = String.format(message, devIp, descritpion, logLevel);
        } else if (jsonStr.contains("web_access")) {
            String devIp = MapUtils.getStr(rtnObjc, LogConstants.USER_NAME);
            String url = MapUtils.getStr(rtnObjc, LogConstants.LOG_URL);
            String devName = MapUtils.getStr(rtnObjc, LogConstants.DEVICE_NAME);
            message = "设备IP为:%s的用户在%s上面进行了网站访问,访问路径为为:%s,日志级别为:%s";
            alertName = String.format(message, devIp, devName, url, logLevel);
        } else if (jsonStr.contains("im:") || jsonStr.contains("social_log")
                || jsonStr.contains("search_engine") || jsonStr.contains("relax_stock")
                || jsonStr.contains("app_filter")) {
            String app = MapUtils.getStr(rtnObjc, LogConstants.LOG_APP);
            String log = MapUtils.getStr(rtnObjc, LogConstants.LOG_ORI_MSG);
            message = "IP为:%s对IP为:%s进行了IM通讯,通讯方式为:%s,日志级别为:%s,日志详情为:%s";
            if (jsonStr.contains("search_engine")) {
                message = "IP为:%s对IP为:%s进行了搜索,通讯方式为:%s,日志级别为:%s,日志详情为:%s";
            } else if (jsonStr.contains("relax_stock")) {
                message = "IP为:%s对IP为:%s进行了娱乐/股票日志,通讯方式为:%s,日志级别为:%s,日志详情为:%s";
            }
            alertName = String.format(message, srcIp, destIp, app, logLevel, log);
        } else if (jsonStr.contains("mail") && !jsonStr.contains("network_share")) {
            String send = MapUtils.getStr(rtnObjc, LogConstants.EMAIL_SEND);
            String receiver = MapUtils.getStr(rtnObjc, LogConstants.EMAIL_RECEIVER);
            String obj = MapUtils.getStr(rtnObjc, LogConstants.ACTION_OBJ);
            message = "IP为;%s的用户名为:%s对IP地址为:%s的:%s用户发送了一封邮件,邮件主题为:%s";
            alertName = String.format(message, srcIp, send, destIp, receiver, obj);
        } else if (jsonStr.contains("file_transfer") || jsonStr.contains("proto_audit")) {
            String devName = MapUtils.getStr(rtnObjc, LogConstants.DEVICE_NAME);
            String app = MapUtils.getStr(rtnObjc, LogConstants.LOG_APP);
            String fileName = MapUtils.getStr(rtnObjc, LogConstants.LOG_FILENAME);
            message = "IP为:%s的%s设备通过:%s方式向IP为:%s的设备传输文件,文件名称为:%s";
            alertName = String.format(message, srcIp, devName, app, destIp , fileName);
        } else if (jsonStr.contains("other_app")) {
            String userName = MapUtils.getStr(rtnObjc, LogConstants.USER_NAME);
            String app = MapUtils.getStr(rtnObjc, LogConstants.LOG_APP);
            String devName = MapUtils.getStr(rtnObjc, LogConstants.DEVICE_NAME);
            String actionResult = MapUtils.getStr(rtnObjc, LogConstants.ACTION_RESULT);
            message = "用户为:%s在IP地址为:%s的:%s设备的%s应用上进行了:%s操作,结果为:%s";
            alertName = String.format(message, userName, srcIp, devName, app, actionType, actionResult);
        } else if (jsonStr.contains("Free") || jsonStr.contains("APP") || jsonStr.contains("Wechat")
                || jsonStr.contains("Local") || jsonStr.contains("Sms") || jsonStr.contains("Portal")
                || jsonStr.contains("SSO") || jsonStr.contains("二维码") || jsonStr.contains("POP3")
                || jsonStr.contains("IC卡") || jsonStr.contains("钉钉") || jsonStr.contains("SSL VPN")) {
            String userName = MapUtils.getStr(rtnObjc, LogConstants.USER_NAME);
            String type = MapUtils.getStr(rtnObjc, LogConstants.LOG_TYPE);
            String log = MapUtils.getStr(rtnObjc, LogConstants.LOG_ORI_MSG);
            message = "用户:%s执行了:%s操作,日志详情:%s";
            alertName = String.format(message, userName, type, log);
        } else if (jsonStr.contains("term_mgt")) {
            message = "发现移动终端的流量，用户名为:%s,源IP为:%s,终端类型为:%s,发现终端原因为:发现了%s的流量，用户当前状态为:%s";
            String userName = MapUtils.getStr(rtnObjc, LogConstants.USER_NAME);
            String description = MapUtils.getStr(rtnObjc, LogConstants.LOG_DESCRIPTION);
            String content = MapUtils.getStr(rtnObjc, LogConstants.LOG_CONTENT);
            String actionResult = MapUtils.getStr(rtnObjc, LogConstants.ACTION_RESULT);
            alertName = String.format(message, userName, srcIp, description, content, actionResult);
        } else if (jsonStr.contains("network_share")) {
            String sessionCount = MapUtils.getStr(rtnObjc, LogConstants.SESSION_COUNT);
            String email = MapUtils.getStr(rtnObjc, LogConstants.EMAIL);
            if (StringUtils.isNotBlank(sessionCount)) {
                String devIp = MapUtils.getStr(rtnObjc, LogConstants.LOG_DEV_IP);
                String count = MapUtils.getStr(rtnObjc, LogConstants.LOG_COUNT);
                message = "在IP为:%s的设备上发现了%s个终端共享接入,共出现:%s次,操作结果:%s";
                alertName = String.format(message, devIp, sessionCount, count, actionType);
            } else if (StringUtils.isNotBlank(email)) {
                String userName = MapUtils.getStr(rtnObjc, LogConstants.USER_NAME);
                String phone = MapUtils.getStr(rtnObjc, LogConstants.PHONE);
                String log = MapUtils.getStr(rtnObjc, LogConstants.LOG_ORI_MSG);
                String actionResult = MapUtils.getStr(rtnObjc, LogConstants.ACTION_RESULT);
                if (StringUtils.isNotBlank(actionResult)) {
                    message = "管理员批准了用户名为:%s,电话为:%s,邮箱为:%s提交的自注册申请,日志详情为:%s";
                    alertName = String.format(message, userName, phone, email, log);
                } else {
                    message = "用户名为:%s,电话为:%s,邮箱为:%s提交了自注册申请,日志详情为:%s";
                    alertName = String.format(message, userName, phone, email, log);
                }
            }
        } else {
            String url = MapUtils.getStr(rtnObjc, LogConstants.LOG_URL);
            String userName = MapUtils.getStr(rtnObjc, LogConstants.USER_NAME);
            String log = MapUtils.getStr(rtnObjc, LogConstants.LOG_ORI_MSG);
            if (StringUtils.isNotBlank(url)) {
                String decName = MapUtils.getStr(rtnObjc, LogConstants.DEVICE_NAME);
                message = "IP为:%s对IP地址为:%s的%s设备触发了过滤恶意URL策略日志,url为:%s,日志详情为:%s";
                alertName = String.format(message, srcIp, destIp, decName, url, log);
            } else if (StringUtils.isNotBlank(userName)) {
                String devIp = MapUtils.getStr(rtnObjc, LogConstants.LOG_DEV_IP);
                message = "用户为:%s在设备IP为:%s的设备上执行了操作,日志详情为:%s";
                alertName = String.format(message, userName, devIp, log);
            } else {
                alertName = log;
            }
        }
        rtnObjc.put(LogConstants.ALERT_NAME, alertName);
    }


    private static void switchKeyValue(ConcurrentHashMap<String, Object> rtnObjc, String key, String value, String jsonStr) {
        switch (key) {
            case "terminal_count":
                rtnObjc.put(LogConstants.SESSION_COUNT, value);
            case "detail_cn":
                rtnObjc.put(LogConstants.LOG_CONTENT, value);
                break;
            case "operator_name":
                rtnObjc.put(LogConstants.USER_NAME, value);
                break;
            case "operate_ip":
                rtnObjc.put(LogConstants.SRC_IP, value);
                break;
            case "create_time":
                if (RegUtils.isNumber(value)) {
                    rtnObjc.put(LogConstants.LOG_START_TIME, DateUtils.getISO8601Timestamp(sdf.format(new Date(DataUtils.toNum(value) * 1000L)), "yyyy-MM-dd HH:mm:ss"));
                } else {
                    rtnObjc.put(LogConstants.LOG_START_TIME, DateUtils.getISO8601Timestamp(value.trim(), "yyyy-MM-dd HH:mm:ss"));
                }
                break;
            case "level":
                if (RegUtils.isNumber(value)) {
                    value = getLevel(value);
                }
                rtnObjc.put(LogConstants.LOG_LEVEL, value);
                break;
            case "result":
                rtnObjc.put(LogConstants.ACTION_RESULT, value);
                break;
            case "managestyle":
                rtnObjc.put(LogConstants.ACTION_TYPE, value);
                break;
            case "content":
                rtnObjc.put(LogConstants.LOG_CONTENT, value);
                break;
            case "温度":
                rtnObjc.put(LogConstants.TEMPERATURE, value);
                break;
            case "磁盘使用":
                rtnObjc.put(LogConstants.DISK, value);
                break;
            case "内存使用":
                rtnObjc.put(LogConstants.MEMORY, value);
                break;
            case "CPU使用":
                rtnObjc.put(LogConstants.CPU, value);
                break;
            case "会话数":
                rtnObjc.put(LogConstants.SESSION_COUNT, value);
                break;
            case "user_name":
                rtnObjc.put(LogConstants.USER_NAME, value);
                break;
            case "policy_id":
                rtnObjc.put(LogConstants.STRATEGY_ID, value);
                break;
            case "src_mac":
                rtnObjc.put(LogConstants.SRC_MAC, value);
                break;
            case "dst_mac":
                rtnObjc.put(LogConstants.DEST_MAC, value);
                break;
            case "src_ip":
                rtnObjc.put(LogConstants.SRC_IP, value);
                break;
            case "dst_ip":
                rtnObjc.put(LogConstants.DEST_IP, value);
                break;
            case "src_port":
                rtnObjc.put(LogConstants.SRC_PORT, value);
                break;
            case "dst_port":
                rtnObjc.put(LogConstants.DEST_PORT, value);
                break;
                case "app_name":
                rtnObjc.put(LogConstants.LOG_APP, value);
                break;
            case "app_cat_name":
                rtnObjc.put(LogConstants.ACTION_TYPE, value);
                break;
            case "protocol":
                rtnObjc.put(LogConstants.LOG_PROTOCAL, value);
                break;
            case "event_id":
                rtnObjc.put(LogConstants.EVENT_ID, value);
                break;
            case "event_name":
                rtnObjc.put(LogConstants.LOG_NAME, value);
                break;
            case "event_type":
                rtnObjc.put(LogConstants.LOG_TYPE, value);
                break;
            case "agg_count":
                rtnObjc.put(LogConstants.LOG_COUNT, value);
                break;
            case "attack_success":
                if (value.equals("0")) {
                    rtnObjc.put(LogConstants.ACTION_RESULT, "尝试攻击");
                } else if (value.equals("1")){
                    rtnObjc.put(LogConstants.ACTION_RESULT, "攻击成功");
                }
                break;
            case "ctime":
                rtnObjc.put(LogConstants.LOG_START_TIME, DateUtils.getISO8601Timestamp(value.trim(), "yyyy-MM-dd HH:mm:ss"));
                break;
            case "action":
                if (jsonStr.contains("waf_ruledefend") || jsonStr.contains("waf_advdefend")
                        || jsonStr.contains("bfd")) {
                    if (value.equals("blist")) {
                        rtnObjc.put(LogConstants.ACTION_RESULT, "拉入黑名单");
                    } else if (value.equals("ignore")) {
                        rtnObjc.put(LogConstants.ACTION_RESULT, "忽略");
                    } else {
                        rtnObjc.put(LogConstants.ACTION_RESULT, value);
                    }
                } else if (jsonStr.contains("servconn_policy")) {
                    rtnObjc.put(LogConstants.ACTION_RESULT, value.equals("1")?"允许":"拒绝");
                } else if (jsonStr.contains("behavior_model") || jsonStr.contains("policy_detail")) {
                    rtnObjc.put(LogConstants.ACTION_RESULT, value);
                } else if (jsonStr.contains("edr_spread")){
                    rtnObjc.put(LogConstants.ACTION_TYPE, value);
                } else if (jsonStr.contains("network_share")) {
                    rtnObjc.put(LogConstants.ACTION_TYPE, value.equals("limit")?"限速":"阻断");
                } else if (jsonStr.contains("ips")) {
                    rtnObjc.put(LogConstants.ACTION_TYPE, value.equals("drop")?"阻断":"放行");
                } else if (jsonStr.contains("AV")) {
                    rtnObjc.put(LogConstants.ACTION_TYPE, value.equals("pass")?"允许":"阻断");
                }
                break;
            case "virus_name":
                rtnObjc.put(LogConstants.VIRUS_NAME, value);
                break;
            case "file_name":
                rtnObjc.put(LogConstants.LOG_FILENAME, value);
                break;
            case "name":
                rtnObjc.put(LogConstants.LOG_NAME, value);
                break;
            case "type":
                rtnObjc.put(LogConstants.ACTION_TYPE, value);
                break;
            case "count":
                rtnObjc.put(LogConstants.LOG_COUNT, value);
                break;
            case "policy_name":
                rtnObjc.put(LogConstants.STRATEGY_NAME, value);
                break;
            case "url":
                rtnObjc.put(LogConstants.LOG_URL, value);
                break;
            case "defend_type":
                rtnObjc.put(LogConstants.ACTION_TYPE, value);
                break;
            case "msg":
                rtnObjc.put(LogConstants.LOG_DESCRIPTION, value);
                break;
            case "src":
                rtnObjc.put(LogConstants.SRC_IP, value);
                break;
            case "dst":
                rtnObjc.put(LogConstants.DEST_IP, value);
                break;
            case "login":
                rtnObjc.put(LogConstants.USER_NAME, value);
                break;
            case "occur_time":
                rtnObjc.put(LogConstants.LOG_START_TIME, DateUtils.getISO8601Timestamp(value.trim(), "yyyy-MM-dd HH:mm:ss"));
                break;
            case "crack_success":
                if (value.equals("0")) {
                    rtnObjc.put(LogConstants.LOG_NAME, "破解失败");
                } else if (value.equals("1")) {
                    rtnObjc.put(LogConstants.LOG_NAME, "破解成功");
                }
                break;
            case "time":
                rtnObjc.put(LogConstants.LOG_START_TIME, DateUtils.getISO8601Timestamp(value.trim(), "yyyy-MM-dd HH:mm:ss"));
                break;
            case "server_addr":
                rtnObjc.put(LogConstants.SRC_IP, value);
                break;
            case "proto":
                rtnObjc.put(LogConstants.LOG_PRODUCT, value);
                break;
            case "behavior_name_cn":
                rtnObjc.put(LogConstants.ACTION_TYPE, value);
                break;
            case "behavior_detail":
                rtnObjc.put(LogConstants.LOG_CONTENT, value);
                break;
            case "behavior_desc":
                rtnObjc.put(LogConstants.LOG_DESCRIPTION, value);
                break;
            case "ti_threat":
                rtnObjc.put(LogConstants.THREAT_NAME, value);
                break;
            case "desc_id":
                rtnObjc.put(LogConstants.ACTION_RESULT, value.equals("1")?"丢弃报文并重定向":"丢弃报文");
                break;
            case "umac":
                rtnObjc.put(LogConstants.SRC_MAC, value);
                break;
            case "uip":
                rtnObjc.put(LogConstants.LOG_DEV_IP, value);
                break;
            case "appname":
                rtnObjc.put(LogConstants.LOG_APP, value);
                break;
            case "up":
                rtnObjc.put(LogConstants.UP_FLUX, value);
                break;
            case "down":
                rtnObjc.put(LogConstants.DOWN_FLUX, value);
                break;
            case "Content":
                rtnObjc.put(LogConstants.LOG_CONTENT, value);
                break;
            case "user ":
                rtnObjc.put(LogConstants.LOG_DEV_IP, value);
                break;
            case "user_ip":
                rtnObjc.put(LogConstants.LOG_DEV_IP, value);
                break;
            case "event_desc":
                rtnObjc.put(LogConstants.LOG_DESCRIPTION, value);
                break;
            case "log_level":
                rtnObjc.put(LogConstants.LOG_APP, getLevel(value));
                break;
            case "term_platform":
                rtnObjc.put(LogConstants.DEVICE_TYPE, value);
                break;
            case "term_device":
                rtnObjc.put(LogConstants.DEVICE_NAME, value);
                break;
            case "url_cate_name":
                rtnObjc.put(LogConstants.ACTION_RESULT, value);
                break;
            case "handle_action":
                rtnObjc.put(LogConstants.ACTION_RESULT, value.equals("0")?"放行":"阻断");
                break;
            /*case "action_name":
                rtnObjc.put(LogConstants.ACTION_RESULT, value);
                break;*/
            case "account":
                rtnObjc.put(LogConstants.OP_NAME, value);
                break;
            case "subject":
                rtnObjc.put(LogConstants.ACTION_OBJ, value);
                break;
            case "pid":
                rtnObjc.put(LogConstants.STRATEGY_ID, value);
                break;
            case "send_addr":
                rtnObjc.put(LogConstants.EMAIL_SEND, value);
                break;
            case "receive_addr":
                rtnObjc.put(LogConstants.EMAIL_RECEIVER, value);
                break;
            case "pname":
                rtnObjc.put(LogConstants.STRATEGY_NAME, value);
                break;
            case "ptype_desc":
                rtnObjc.put(LogConstants.LOG_DESCRIPTION, value);
                break;
            case "erm_type_cn":
                rtnObjc.put(LogConstants.DEVICE_TYPE, value);
                break;
            case "probe_time":
                rtnObjc.put(LogConstants.LOG_START_TIME, DateUtils.getISO8601Timestamp(value.trim(), "yyyy-MM-dd HH:mm:ss"));
                break;
            case "state":
                rtnObjc.put(LogConstants.ACTION_RESULT, value.equals("1")?"冻结":value);
                break;
            case "action_time":
                rtnObjc.put(LogConstants.LOG_COUNT, value);
                break;
            case "find_time":
                rtnObjc.put(LogConstants.LOG_START_TIME, DateUtils.getISO8601Timestamp(value.trim(), "yyyy-MM-dd HH:mm:ss"));
                break;
            case "log_time":
                rtnObjc.put(LogConstants.LOG_START_TIME, DateUtils.getISO8601Timestamp(value.trim(), "yyyy-MM-dd HH:mm:ss"));
                break;
            case "phone":
                rtnObjc.put(LogConstants.PHONE, value);
                break;
            case "mail":
                rtnObjc.put(LogConstants.EMAIL, value);
                break;
            case "description":
                rtnObjc.put(LogConstants.LOG_DESCRIPTION, value);
                break;
            case "term_type_cn":
                rtnObjc.put(LogConstants.LOG_DESCRIPTION, value);
                break;
        }
    }

    private static void getLoginOrOut(ConcurrentHashMap<String, Object> rtnObjc, String jsonStr) {
        if (jsonStr.contains("login") && jsonStr.contains("Free")) {
            int index = DataUtils.getIndex(jsonStr, ":");
            int index1 = DataUtils.getIndex(jsonStr, "@");
            int index2 = DataUtils.getIndex(jsonStr, "(");
            int index3 = DataUtils.getIndex(jsonStr, ")");
            String userName = DataUtils.getSubString(jsonStr, index+1, index1);
            String IP = DataUtils.getSubString(jsonStr, index1+1, index2);
            String mac = DataUtils.getSubString(jsonStr, index2+1, index3);
            rtnObjc.put(LogConstants.USER_NAME, userName);
            rtnObjc.put(LogConstants.LOG_DEV_IP, IP);
            rtnObjc.put(LogConstants.SRC_MAC, mac);
            rtnObjc.put(LogConstants.LOG_TYPE, "FREE login");
        } else if (jsonStr.contains("logout") && jsonStr.contains("Free")) {
            int index = DataUtils.getIndex(jsonStr, "=");
            int index1 = DataUtils.getIndex(jsonStr, "@");
            int index2 = DataUtils.getIndex(jsonStr, "(");
            int index3 = DataUtils.getIndex(jsonStr, ")");
            String userName = DataUtils.getSubString(jsonStr, index+1, index1).trim();
            String IP = DataUtils.getSubString(jsonStr, index1+1, index2);
            String mac = DataUtils.getSubString(jsonStr, index2+1, index3);
            rtnObjc.put(LogConstants.USER_NAME, userName);
            rtnObjc.put(LogConstants.LOG_DEV_IP, IP);
            rtnObjc.put(LogConstants.SRC_MAC, mac);
            rtnObjc.put(LogConstants.LOG_TYPE, "FREE logout");
        } else if (jsonStr.contains("APP")) {
            int index1 = DataUtils.getIndex(jsonStr, " ");
            int index5 = DataUtils.getIndex(jsonStr, ":");
            String type = DataUtils.getSubString(jsonStr, index1+1, index5).trim();
            int index = DataUtils.getIndex(jsonStr, "=");
            jsonStr = DataUtils.getSubString(jsonStr, index);
            index1 = DataUtils.getIndex(jsonStr, " ");
            String userName = DataUtils.getSubString(jsonStr, 1, index1).trim();
            int index2 = DataUtils.getIndex(jsonStr, "@");
            int index3 = DataUtils.getIndex(jsonStr, "(");
            int index4 = DataUtils.getIndex(jsonStr, ")");
            String IP = DataUtils.getSubString(jsonStr, index2+1, index3);
            String mac = DataUtils.getSubString(jsonStr, index3+1, index4);
            rtnObjc.put(LogConstants.USER_NAME, userName);
            rtnObjc.put(LogConstants.LOG_DEV_IP, IP);
            rtnObjc.put(LogConstants.SRC_MAC, mac);
            rtnObjc.put(LogConstants.LOG_TYPE, "APP " + type);
        } else if (jsonStr.contains("Wechat") && jsonStr.contains("login") && !jsonStr.contains("logout")) {
            int index1 = DataUtils.getIndex(jsonStr, ":");
            int index2 = DataUtils.getIndex(jsonStr, "@");
            int index3 = DataUtils.getIndex(jsonStr, "(");
            int index4 = DataUtils.getIndex(jsonStr, ")");
            String userName = DataUtils.getSubString(jsonStr, index1+1, index2);
            String IP = DataUtils.getSubString(jsonStr, index2+1, index3);
            String mac = DataUtils.getSubString(jsonStr, index3+1, index4);
            rtnObjc.put(LogConstants.USER_NAME, userName);
            rtnObjc.put(LogConstants.LOG_DEV_IP, IP);
            rtnObjc.put(LogConstants.SRC_MAC, mac);
            rtnObjc.put(LogConstants.LOG_TYPE, "Wechat login");
        } else if (jsonStr.contains("Wechat") && jsonStr.contains("logout")) {
            int index = DataUtils.getIndex(jsonStr, "=");
            int index1 = DataUtils.getIndex(jsonStr, "@");
            int index2 = DataUtils.getIndex(jsonStr, "(");
            int index3 = DataUtils.getIndex(jsonStr, ")");
            String userName = DataUtils.getSubString(jsonStr, index+1, index1);
            String IP = DataUtils.getSubString(jsonStr, index1+1, index2);
            String mac = DataUtils.getSubString(jsonStr, index2+1, index3);
            rtnObjc.put(LogConstants.USER_NAME, userName);
            rtnObjc.put(LogConstants.LOG_DEV_IP, IP);
            rtnObjc.put(LogConstants.SRC_MAC, mac);
            rtnObjc.put(LogConstants.LOG_TYPE, "Wechat logout");
        } else if (jsonStr.contains("Local")) {
            int index = DataUtils.getIndex(jsonStr, ":");
            int index1 = DataUtils.getIndex(jsonStr, "@");
            int index2 = DataUtils.getIndex(jsonStr, "(");
            int index3 = DataUtils.getIndex(jsonStr, ")");
            String userName = DataUtils.getSubString(jsonStr, index+1, index1);
            String IP = DataUtils.getSubString(jsonStr, index1+1, index2);
            String mac = DataUtils.getSubString(jsonStr, index2+1, index3);
            String type = DataUtils.getSubString(jsonStr, "Local authentication".length() + 1, index).trim();
            rtnObjc.put(LogConstants.USER_NAME, userName);
            rtnObjc.put(LogConstants.LOG_DEV_IP, IP);
            rtnObjc.put(LogConstants.SRC_MAC, mac);
            rtnObjc.put(LogConstants.LOG_TYPE, "Local " + type);
        } else if (jsonStr.contains("Sms")) {
            int index = DataUtils.getIndex(jsonStr, ":");
            int index1 = DataUtils.getIndex(jsonStr, "@");
            int index2 = DataUtils.getIndex(jsonStr, "(");
            int index3 = DataUtils.getIndex(jsonStr, ")");
            String userName = DataUtils.getSubString(jsonStr, index+1, index1);
            String IP = DataUtils.getSubString(jsonStr, index1+1, index2);
            String mac = DataUtils.getSubString(jsonStr, index2+1, index3);
            String type = DataUtils.getSubString(jsonStr, "Sms".length() + 1, index).trim();
            rtnObjc.put(LogConstants.USER_NAME, userName);
            rtnObjc.put(LogConstants.LOG_DEV_IP, IP);
            rtnObjc.put(LogConstants.SRC_MAC, mac);
            rtnObjc.put(LogConstants.LOG_TYPE, "Sms " + type);
        } else if (jsonStr.contains("Portal")) {
            getSplitData(rtnObjc, jsonStr);
            if (jsonStr.contains("Logout")) {
                rtnObjc.put(LogConstants.LOG_TYPE, "Portal?Server logout");
            } else {
                rtnObjc.put(LogConstants.LOG_TYPE, "Portal?Server login");
            }
        } else if (jsonStr.contains("SSO")) {
            int index = DataUtils.getIndex(jsonStr, " ");
            int index1 = DataUtils.getIndex(jsonStr, ":");
            int index2 = DataUtils.getIndex(jsonStr, "@");
            int index3 = DataUtils.getIndex(jsonStr, "(");
            int index4 = DataUtils.getIndex(jsonStr, ")");
            String type = DataUtils.getSubString(jsonStr, index+1, index1).trim();
            String userName = DataUtils.getSubString(jsonStr, index1+1, index2).trim();
            String IP = DataUtils.getSubString(jsonStr, index2+1, index3);
            String mac = DataUtils.getSubString(jsonStr, index3+1, index4);
            rtnObjc.put(LogConstants.USER_NAME, userName);
            rtnObjc.put(LogConstants.LOG_DEV_IP, IP);
            rtnObjc.put(LogConstants.SRC_MAC, mac);
            rtnObjc.put(LogConstants.LOG_TYPE, "SSO " + type);
        } else if (jsonStr.contains("二维码")) {
            getSplitData(rtnObjc, jsonStr);
            if (jsonStr.contains("login") && !jsonStr.contains("logout")) {
                rtnObjc.put(LogConstants.LOG_TYPE, "二维码认证 login");
            } else {
                rtnObjc.put(LogConstants.LOG_TYPE, "二维码认证 logout");
            }
        } else if (jsonStr.contains("POP3")) {
            getSplitData(rtnObjc, jsonStr);
            if (jsonStr.contains("login") && !jsonStr.contains("logout")) {
                rtnObjc.put(LogConstants.LOG_TYPE, "POP3认证上线通知");
            } else {
                rtnObjc.put(LogConstants.LOG_TYPE, "POP3认证下线通知");
            }
        } else if (jsonStr.contains("IC卡")) {
            getSplitData(rtnObjc, jsonStr);
            if (jsonStr.contains("login") && !jsonStr.contains("logout")) {
                rtnObjc.put(LogConstants.LOG_TYPE, "IC卡认证上线通知");
            } else {
                rtnObjc.put(LogConstants.LOG_TYPE, "IC卡认证下线通知");
            }
        } else if (jsonStr.contains("钉钉认证")) {
            getSplitData(rtnObjc, jsonStr);
            if (jsonStr.contains("login") && !jsonStr.contains("logout")) {
                rtnObjc.put(LogConstants.LOG_TYPE, "钉钉认证上线通知");
            } else {
                rtnObjc.put(LogConstants.LOG_TYPE, "钉钉认证下线通知");
            }
        } else if (jsonStr.contains("SSL VPN")) {
            getSplitData(rtnObjc, jsonStr);
            if (jsonStr.contains("login") && !jsonStr.contains("logout")) {
                rtnObjc.put(LogConstants.LOG_TYPE, "SSLVPN认证上线通知");
            } else {
                rtnObjc.put(LogConstants.LOG_TYPE, "SSLVPN认证下线通知");
            }
        }
        rtnObjc.put(LogConstants.LOG_LEVEL, getLevel("5"));
    }

    private static void getSplitData(ConcurrentHashMap<String, Object> rtnObjc, String jsonStr) {
        String[] split = DataUtils.getSplit(jsonStr, ":");
        if (split.length >= 4) {
            String tempStr = split[4];
            int index = DataUtils.getIndex(tempStr, "@");
            int index1 = DataUtils.getIndex(tempStr, "(");
            int index2 = DataUtils.getIndex(tempStr, ")");
            String userName = DataUtils.getSubString(tempStr, 0, index);
            String IP = DataUtils.getSubString(tempStr, index+1, index1);
            String mac = DataUtils.getSubString(tempStr, index1+1, index2);
            rtnObjc.put(LogConstants.USER_NAME, userName);
            rtnObjc.put(LogConstants.LOG_DEV_IP, IP);
            rtnObjc.put(LogConstants.SRC_MAC, mac);
        }
    }


    private static String getLevel(String value) {
        String logLevel = "";
        switch (value) {
            case "0":
                logLevel = "Emergency";
                break;
            case "1":
                logLevel = "Alert";
                break;
            case "2":
                logLevel = "Critical";
                break;
            case "3":
                logLevel = "Error";
                break;
            case "4":
                logLevel = "Warning";
                break;
            case "5":
                logLevel = "Notification";
                break;
            case "6":
                logLevel = "Informational";
                break;
            case "7":
                logLevel = "Debug";
                break;
        }
        return logLevel;
    }

}
