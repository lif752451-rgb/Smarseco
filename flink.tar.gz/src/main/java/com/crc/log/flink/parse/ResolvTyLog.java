package com.crc.log.flink.parse;

import com.alibaba.fastjson.JSONObject;
import com.crc.log.flink.common.constants.LevelConstants;
import com.crc.log.flink.common.constants.LogConstants;
import com.crc.log.flink.common.utils.*;
import org.apache.commons.lang3.StringUtils;

import java.util.concurrent.ConcurrentHashMap;

/**
 * 奇安信天眼日志格式化
 */
@SuppressWarnings("unchecked")
public class ResolvTyLog {
    public static ConcurrentHashMap<String, Object> parse(String message) {
        try {
            ConcurrentHashMap<String, Object> data = proc(message);
            if (DataUtils.isNotEmptyJson(data)) {
                return data;
            }
        } catch (Exception ignored) {

        }
        return null;
    }

    private static ConcurrentHashMap<String, Object> proc(String value) {
        ConcurrentHashMap<String, Object> ldapJson = JsonUtils.createBaseMap(value);
        try {
            String msg = value;
            ldapJson.put(LogConstants.LOG_PRODUCT, "奇安信天眼");
            if (StringUtils.isNotBlank(msg)) {
                boolean good = false;
                String[] msgArr = DataUtils.getSplit(msg, "\\|");
                        //msg.split("\\|");
                if (msgArr.length > 3) {
                    if (!"!log".equals(msgArr[2])) {
                        good = true;
                    }
                }
                if (!good) {
                    return ldapJson;
                }
                if (StringUtils.isNotBlank(msg) && msg.contains("{")) {
                    msg = DataUtils.getSubString(msg, DataUtils.getIndex(msg, "{"));
                            //msg.substring(msg.indexOf("{"));
                    msg = DataUtils.getSubString(msg, 0, DataUtils.getLastIndex(msg, "}") + 1);
                            //msg.substring(0, msg.lastIndexOf("}") + 1);
                    JSONObject json = JsonUtils.parse(msg);
                    if (null != json && !json.isEmpty()) {
                        goParseLog(ldapJson, json);
                    } else {
                        try {
                            json = new JSONObject();
                            msg = DataUtils.getSubString(msg, DataUtils.getIndex(msg, "{") + 1);
                            msg = msg.replace("\"", "");
                            for (String x : DataUtils.getSplit(msg, ",")) {
                                try {
                                    String[] m = DataUtils.getSplit(x, ":");
                                            //x.split(":");
                                    json.put(m[0].trim(), m[1].trim());
                                } catch (Exception ignored) {

                                }
                            }
                            goParseLog(ldapJson, json);
                        } catch (Exception ignored) {

                        }
                    }
                }
                if (!ldapJson.containsKey(LogConstants.LOG_LEVEL)) {
                    ldapJson.put(LogConstants.LOG_LEVEL, LevelConstants.getLevel(MapUtils.getStr(ldapJson,LogConstants.LOG_LEVEL)));
                }
                ScoreUtils.commonEventLevelScore(ldapJson);
            }
            ldapJson.put(LogConstants.LOG_LEVEL, LevelConstants.getLevel(MapUtils.getStr(ldapJson,LogConstants.LOG_LEVEL)));
            if (StringUtils.isBlank(MapUtils.getStr(ldapJson, LogConstants.SRC_IP))) {
                ldapJson.put(LogConstants.SRC_IP, "0.0.0.0");
            }
            if (StringUtils.isBlank(MapUtils.getStr(ldapJson, LogConstants.DEST_IP))) {
                ldapJson.put(LogConstants.DEST_IP, "0.0.0.0");
            }
            return ldapJson;
        } catch (Exception e) {
            return ldapJson;
        }
    }

    /**
     * 解析日志
     *
     * @param retData
     * @param json
     */
    public static void goParseLog(ConcurrentHashMap<String, Object> retData, JSONObject json) {
        try {
            MapUtils.setStr(retData, LogConstants.SRC_IP, json, "attack_sip");
            if (MapUtils.isBlank(retData, LogConstants.SRC_IP)) {
                MapUtils.setStr(retData, LogConstants.SRC_IP, json, "attacker");
            }
            MapUtils.setStr(retData, LogConstants.LOG_LEVEL, json, "hazard_rating");
            if (MapUtils.isBlank(retData, LogConstants.LOG_LEVEL)) {
                MapUtils.setStr(retData, LogConstants.LOG_LEVEL, json, "xml_confidence");
            }
            MapUtils.setStr(retData, LogConstants.LOG_NAME, json, "ioc");
            if (MapUtils.isBlank(retData, LogConstants.LOG_NAME)) {
                MapUtils.setStr(retData, LogConstants.LOG_NAME, json, "attack_type");
            }
            MapUtils.setStr(retData, LogConstants.DEST_IP, json, "alarm_sip");
            if (MapUtils.isBlank(retData, LogConstants.DEST_IP)) {
                MapUtils.setStr(retData, LogConstants.DEST_IP, json, "dip");
            }
            MapUtils.setStr(retData, LogConstants.DEST_PORT, json, "dport");
            String actionResult = JsonUtils.getStr(json, "host_state");
            if (actionResult.equalsIgnoreCase("攻击成功")) {
                MapUtils.setStr(retData, LogConstants.ACTION_RESULT, "成功");
            } else {
                MapUtils.setStr(retData, LogConstants.ACTION_RESULT, actionResult);
            }
            //   MapUtils.setStr(retData, LogConstants.ACTION_RESULT, json, "host_state");
            MapUtils.setStr(retData, LogConstants.LOG_URL, json, "url");
            if (MapUtils.isBlank(retData, LogConstants.LOG_URL)) {
                MapUtils.setStr(retData, LogConstants.LOG_URL, json, "host");
            }
            MapUtils.setStr(retData, LogConstants.HOST_NAME, json, "host");
            MapUtils.setStr(retData, LogConstants.MSG_CONTENT, JsonUtils.getStr(json, "_origin"));
            MapUtils.setStr(retData, LogConstants.LOG_DESCRIPTION, JsonUtils.getStr(json, "payload"));
            if (StringUtils.isBlank(MapUtils.getStr(retData, LogConstants.LOG_DESCRIPTION))) {
                MapUtils.setStr(retData, LogConstants.LOG_DESCRIPTION, JsonUtils.getStr(json, "detail_info"));
            }
            MapUtils.setStr(retData, LogConstants.ACTION_TYPE, JsonUtils.getStr(json, "rule_desc"));
            MapUtils.setStr(retData, LogConstants.SRC_DEV_INFO, JsonUtils.getStr(json, "x_forwarded_for"));
            MapUtils.setStr(retData, LogConstants.ACTION_RULE, JsonUtils.getStr(json, "attack_type"));
            MapUtils.setStr(retData, LogConstants.HOST_NAME, JsonUtils.getStr(json, "host"));
            MapUtils.setStr(retData, LogConstants.LOG_PRIORITY, JsonUtils.getStr(json, "hazard_level"));
            if (json.containsKey("sip")) {
                MapUtils.setStr(retData, LogConstants.SRC_IP, JsonUtils.getStr(json, "sip"));
            }
            if (json.containsKey("write_date")) {
                retData.put(LogConstants.LOG_START_TIME, DateUtils.getISO8601Timestamp(JsonUtils.getLong(json, "write_date") * 1000L));
            }
            if (json.containsKey("access_time")) {
                retData.put(LogConstants.LOG_START_TIME, DateUtils.getISO8601Timestamp(JsonUtils.getLong(json, "access_time")));
            }
            if (json.containsKey("_origin")) {
                JSONObject v = JsonUtils.getJson(json, "_origin");
                if (StringUtils.isBlank(MapUtils.getStr(retData, LogConstants.SRC_IP))) {
                    MapUtils.setStr(retData, LogConstants.SRC_IP, JsonUtils.getStr(v, "sip"));
                }
                if (StringUtils.isBlank(MapUtils.getStr(retData, LogConstants.DEST_IP))) {
                    MapUtils.setStr(retData, LogConstants.DEST_IP, JsonUtils.getStr(v, "dip"));
                }
                if (StringUtils.isBlank(MapUtils.getStr(retData, LogConstants.LOG_DESCRIPTION))) {
                    MapUtils.setStr(retData, LogConstants.LOG_DESCRIPTION, JsonUtils.getStr(v, "detail_info"));
                }
                if (v.containsKey("vuln_type")) {
                    MapUtils.setStr(retData, LogConstants.LOG_NAME, JsonUtils.getStr(v, "vuln_type"));
                }
                retData.put(LogConstants.LOG_START_TIME, DateUtils.getISO8601Timestamp(JsonUtils.getLong(v, "write_date") * 1000L));
            }
            if (StringUtils.isBlank(MapUtils.getStr(retData, LogConstants.SRC_IP))) {
                retData.put(LogConstants.SRC_IP, "0.0.0.0");
            }
            if (StringUtils.isBlank(MapUtils.getStr(retData, LogConstants.DEST_IP))) {
                retData.put(LogConstants.DEST_IP, "0.0.0.0");
            }
            setAlertName(json, retData);
            //123低风险456中风险78910高风险
            int severity = JsonUtils.getInt(json, "severity");
            if (severity == 0) {
                severity = JsonUtils.getInt(json, "hazard_level");
            }
            if (severity >= 6) {
                retData.put(LogConstants.LOG_LEVEL, LevelConstants.HIGH);
            } else if (severity > 3) {
                retData.put(LogConstants.LOG_LEVEL, LevelConstants.MEDIUM);
            } else {
                retData.put(LogConstants.LOG_LEVEL, LevelConstants.LOW);
            }
        } catch (Exception e) {
            //e.printStackTrace();
        }
    }

    public static void setAlertName(JSONObject jsonObject, ConcurrentHashMap<String, Object> resultJson) {
        String ruleName = JsonUtils.getStr(jsonObject,"rule_name");
        if (StringUtils.isEmpty(ruleName)) {
            if (jsonObject.containsKey("_origin")) {
                JSONObject sourceJson = JsonUtils.getJson(jsonObject, "_origin");//jsonObject.getJSONObject("_origin");
                ruleName = sourceJson.getString("rule_name");
                if (StringUtils.isEmpty(ruleName)) {
                    ruleName = sourceJson.getString("vuln_name");
                }
            }
        }
        String srcIp = MapUtils.getStr(resultJson, LogConstants.SRC_IP);
        String destIp = MapUtils.getStr(resultJson, LogConstants.DEST_IP);
        String actionType = MapUtils.getStr(resultJson, LogConstants.ACTION_TYPE);
        String logName = MapUtils.getStr(resultJson, LogConstants.LOG_NAME);
        String HOST_NAME = MapUtils.getStr(resultJson, LogConstants.HOST_NAME);
        String log = MapUtils.getStr(resultJson, LogConstants.LOG_ORI_MSG);
        String alertName = "";
        if (StringUtils.isEmpty(ruleName)) {
            if (StringUtils.isBlank(destIp) || "null".equals(destIp) || "0.0.0.0".equals(destIp) || srcIp.equals(destIp)) {
                String messageFormat = "%s 发起 %s-%s,日志详情为:%s";
                alertName = String.format(messageFormat, srcIp, actionType, logName, log);
            } else {
                String messageFormat = "%s 对 %s 进行 %s-%s,日志详情为:%s";
                alertName = String.format(messageFormat, srcIp, destIp, actionType, logName, log);
            }
        } else {
            if (StringUtils.isBlank(destIp) || "null".equals(destIp) || "0.0.0.0".equals(destIp) || srcIp.equals(destIp)) {
                String messageFormat = "%s 发起 %s-%s-%s,日志详情为:%s";
                alertName = String.format(messageFormat, srcIp, actionType, logName, ruleName, log);
            } else {
                String messageFormat = "%s 对 %s 进行 %s-%s-%s,日志详情为:%s";
                alertName = String.format(messageFormat, srcIp, destIp, actionType, logName, ruleName, log);
            }

        }
        if (StringUtils.isNotBlank(HOST_NAME)) {
            alertName = alertName + ",请求主机：" + HOST_NAME;
        }
        resultJson.put(LogConstants.ALERT_NAME, alertName);

    }
}
