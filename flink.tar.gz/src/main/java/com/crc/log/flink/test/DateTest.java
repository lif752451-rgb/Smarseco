package com.crc.log.flink.test;

import com.alibaba.fastjson.JSONObject;
import com.crc.log.flink.common.constants.LogConstants;
import com.crc.log.flink.common.utils.DataUtils;
import com.crc.log.flink.common.utils.DateUtils;
import com.crc.log.flink.common.utils.JsonUtils;

import java.text.SimpleDateFormat;
import java.util.Date;

public class DateTest {
    static SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
    public static void main(String[] args) {
        String msg = "<182>Apr 11 14:38:32 rlkj-qingtengprd-003 qtAlert[237] datatype=\"proc_create\" datatime=\"1618123107\" agent_ip=\"138.30.57.250\" host_name=\"spy12q1\" internal_ip=\"192.168.50.250\\,fe80::da9d:67ff:fe32:bb2d\" external_ip=\"138.30.57.250\" host_tag=\"\" host_memo=\"\" group_name=\"润联科技\" severity=\"0\" action=\"add\" type=\"monitor\" group=\"3\" agent_id=\"5f683c8fb2643e76\" comid=\"2020cd6871669f172c32\"  os=\"linux\" pname=\"wc\" pid=\"4682\" uname=\"root\" uid=\"0\" cmd=\"wc -l\" path=\"/usr/bin/wc\" ppname=\"ifx_status_disc\" ppid=\"4680\" ppuname=\"root\" ppuid=\"0\" pppath=\"/bin/bash\" euname=\"root\" euid=\"0\" gname=\"root\" md5=\"c14b18f3b298ef0df492e0a720902fcc\"";
        JsonUtils.printStr(DateUtils.getISO8601Timestamp(1000 * 1618123107));
        String app[] = msg.split(" ");
        String year = DateUtils.getYear();
        String[] months = {"Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"};
        String month = "";
        for (int i = 0; i < months.length; i++) {
            if (app[0].contains(months[i])) {
                month = String.format("%02d", i + 1);
            }
        }
        String day = app[1];
        String hhmmss = app[2];
        String dateTime = String.format("%s-%s-%s %s",year,month,day,hhmmss);
        JsonUtils.printStr(DateUtils.getISO8601Timestamp(dateTime));
        JSONObject rtnObjc = new JSONObject();
        String value = "2022-11-15 19:47:50";
        if (DataUtils.isNumeric(value)) {
            rtnObjc.put(LogConstants.LOG_START_TIME, DateUtils.getISO8601Timestamp(sdf.format(new Date(DataUtils.toNum(value) * 1000L)), "yyyy-MM-dd HH:mm:ss"));
        }else {
            rtnObjc.put(LogConstants.LOG_START_TIME, DateUtils.getISO8601Timestamp(value, "yyyy-MM-dd HH:mm:ss"));
        }

        System.out.println(rtnObjc.toJSONString());
    }
}
