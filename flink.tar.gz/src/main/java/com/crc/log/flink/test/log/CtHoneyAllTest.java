package com.crc.log.flink.test.log;

import com.crc.log.flink.FlinkApplication;
import com.crc.log.flink.common.entity.IpMappgingRule;
import com.crc.log.flink.common.utils.JsonUtils;
import com.crc.log.flink.config.AllConfig;
import com.crc.log.flink.es.DataProcessFuncation;
import com.crc.log.flink.load.EventRuleLoad;

import java.util.concurrent.ConcurrentHashMap;

public class CtHoneyAllTest {
    public static void main(String[] args) {
        String msgx = "{\"dev_ip\":\"10.0.0.1\",\"product\":\"默安蜜罐\",\"src_ip_type\":\"内网\",\"log_name\":\"扫描事件\",\"action_result\":\"企图\",\"event_score\":10,\"log_level\":\"低风险\",\"SparkTime\":\"2023-06-16T19:41:31.376+0800\",\"ip_score\":2,\"src_dev_info\":\"10.8.9.195\",\"src_ip\":\"10.0.89.146\",\"src_port\":\"29276\",\"flink\":\"1\",\"log_start_time\":\"2021-10-09T10:07:16.000+0800\",\"zlog_ori_msg\":\"<12>Oct 09 10:07:43  {\\\"source\\\": \\\"scanner\\\", \\\"id\\\": \\\"adb5302965ab36e7dc4e7209b85442ad\\\", \\\"proto\\\": \\\"tcp\\\", \\\"start_time\\\": 1633745236, \\\"end_time\\\": 1633745236, \\\"agent\\\": \\\"10.8.9.195\\\", \\\"business_group\\\": \\\"\\\\u5206\\\\u7ec4\\\\u4e94\\\", \\\"src_ip\\\": \\\"10.0.89.146\\\", \\\"src_port\\\": \\\"29276\\\", \\\"dest_ip\\\": \\\"10.8.9.195\\\", \\\"dest_port\\\": \\\"10050\\\", \\\"dumb_captures\\\": []}\",\"dest_ip\":\"10.8.9.195\",\"dest_ip_type\":\"内网\",\"es_index\":\"sec_all\",\"dest_port\":\"10050\",\"alert_name\":\"10.0.89.146 对 10.8.9.195 进行 扫描事件-,日志详情为:<12>Oct 09 10:07:43  {\\\"source\\\": \\\"scanner\\\", \\\"id\\\": \\\"adb5302965ab36e7dc4e7209b85442ad\\\", \\\"proto\\\": \\\"tcp\\\", \\\"start_time\\\": 1633745236, \\\"end_time\\\": 1633745236, \\\"agent\\\": \\\"10.8.9.195\\\", \\\"business_group\\\": \\\"\\\\u5206\\\\u7ec4\\\\u4e94\\\", \\\"src_ip\\\": \\\"10.0.89.146\\\", \\\"src_port\\\": \\\"29276\\\", \\\"dest_ip\\\": \\\"10.8.9.195\\\", \\\"dest_port\\\": \\\"10050\\\", \\\"dumb_captures\\\": []}\"}\n";
        AllConfig config = new AllConfig();
        DataProcessFuncation.CONIFG = config;
        FlinkApplication.ALL_CONFIG = config;
        IpMappgingRule impr = IpMappgingRule.getRuleMapping("10.0.0.1", "sec_all", "ResolvHoneyLog", "group", "蜜罐");
        //config.setMode("single");
        EventRuleLoad.IpMapping.put("10.0.0.1", impr);
        config.setParse("ResolvHoneyLog");
        config.setIndex("sec_all");
        config.setDebug("T");


        ConcurrentHashMap<String, Object> json = DataProcessFuncation.parse(msgx, "index");
        JsonUtils.printStr(json);
    }
}
