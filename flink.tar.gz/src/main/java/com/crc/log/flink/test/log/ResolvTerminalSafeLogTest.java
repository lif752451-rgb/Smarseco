package com.crc.log.flink.test.log;

/*
  亚信安全
 */
import com.crc.log.flink.common.utils.JsonUtils;
import com.crc.log.flink.config.AllConfig;
import com.crc.log.flink.es.DataProcessFuncation;

import java.util.concurrent.ConcurrentHashMap;

public class ResolvTerminalSafeLogTest {

    public static void main(String[] args) {
        String str = "<134>APPO-20200522SG CEF:0|AsiaInfo Security|OfficeScan|12.0.0.2821|4|TROJ_FRS.0NA103BO22|3|act=4 clientIP=172.17.77.202 clientMAC=CCB0DAFD940D deviceFacility=OfficeScan dhost=APPO-20200522SG domain=Yao\\\\ dvchost=APPO-20200522SG filePath=C:\\\\Windows\\\\SysWOW64\\\\Macromed\\\\Flash\\\\ fname=TROJ_FRS.0NA103BO22 foundTime=1650594356 guid=ef9b9ee7-d187-4b3d-91b4-389b6bea8ef7 infectChannel=4 infectfile=FlashHelperService.exe log_send_time=1650594399 log_type=viruslog platform=Windows 7 6.1.7601 rt=1650594356000 scanType=1 server_guid=91071517-eca0-4899-ada1-4204cc03afa3 server_ip=10.32.252.135 server_name=Qushi-App";

        AllConfig config = new AllConfig();
        DataProcessFuncation.CONIFG = config;
        config.setMode("single");
        config.setParse("ResolvTerminalSafeLog");
        config.setIndex("sec_all");

        ConcurrentHashMap<String, Object> json = DataProcessFuncation.parse(str,"index");
        JsonUtils.printStr(json);


        str = "<134>Nov 30 14:21:33 dsm CEF:0|AsiaInfo Security|Deep Security Manager|9.6.4184|771|Contact by Unrecognized Client|6|src=11.0.9.1 suser=System msg=A connection to Deep Security Manager was initiated by a client not identifiable as a managed computer: 11.0.14.241:61117.  Either the client is not a computer managed by Deep Security, or a secure communication channel could not be established.\\n\\nFound unknown VM, hostID: 1467, but not allow to reactivate. TrendMicroDsTenant=TenantID 0 TrendMicroDsTenantId=0";
        json = DataProcessFuncation.parse(str,"index");
        JsonUtils.printStr(json);

        str = "<134>Nov 30 14:21:33 dsm CEF:0|AsiaInfo Security|Deep Security Manager|9.6.4184|771|Contact by Unrecognized Client|6|src=11.0.9.1 suser=System msg=A connection to Deep Security Manager was initiated by a client not identifiable as a managed computer: 11.0.14.241:61117.  Either the client is not a computer managed by Deep Security, or a secure communication channel could not be established.\\n\\nFound unknown VM, hostID: 1467, but not allow to reactivate. TrendMicroDsTenant=TenantID 0 TrendMicroDsTenantId=0";
        json = DataProcessFuncation.parse(str,"index");
        JsonUtils.printStr(json);

        str = "<134>Nov 30 14:10:54 dsm CEF:0|AsiaInfo Security|Deep Security Manager|9.6.4184|710|Events Retrieved|3|src=11.0.9.1 suser=System target=localhost.localdom (Trend Micro Deep Security (3)) msg=Description Omitted TrendMicroDsTenant=TenantID 0 TrendMicroDsTenantId=0";
        json = DataProcessFuncation.parse(str,"index");
        JsonUtils.printStr(json);

        str = "<134>APPO-PC CEF:0|AsiaInfo Security|OfficeScan|12.0.0.2821|4|Ransom.Win32.WANNACRY.SM|3|act=4 clientIP=10.32.56.79 clientMAC=0862664CB3A6 deviceFacility=OfficeScan dhost=APPO-PC domain=缺省\\\\ dvchost=APPO-PC filePath=C:\\\\Windows\\\\ fname=Ransom.Win32.WANNACRY.SM foundTime=1651820584 guid=21952366-da6a-4cf1-9bff-bfa5610b0e00 infectChannel=4 infectfile=mssecsvr.exe log_send_time=1651820653 log_type=viruslog platform=Windows 7 6.1.7601 rt=1651820584000 scanType=1 server_guid=91071517-eca0-4899-ada1-4204cc03afa3 server_ip=10.32.252.135 server_name=Qushi-App";
        json = DataProcessFuncation.parse(str,"index");
        JsonUtils.printStr(json);
    }

}
