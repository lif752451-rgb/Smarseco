package com.crc.log.flink.db;

import com.alibaba.fastjson.JSONObject;
import com.crc.log.flink.common.utils.CodeTool;
import com.crc.log.flink.common.utils.DataUtils;
import com.crc.log.flink.common.utils.JsonUtils;
import com.crc.log.flink.config.GetSpringBean;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.springframework.core.env.Environment;

import java.sql.*;
import java.util.LinkedList;
import java.util.List;

@Slf4j
public class ConfBuzziMySql {
    private static String DRIVER_CLASS_NAME = null;
    private static String URL = null;
    private static String USERNAME = null;
    private static String PASSWORD = null;

    static {
        Environment env = GetSpringBean.getBean(Environment.class);
        DRIVER_CLASS_NAME = env.getProperty("spring.druid.driverClassName");
        URL = env.getProperty("spring.druid.url");
        USERNAME = env.getProperty("spring.druid.username");
        PASSWORD = CodeTool.decrypt(env.getProperty("spring.druid.password"));
    }

    public static Connection getConnection() throws Exception {
        Class.forName(DRIVER_CLASS_NAME);
        return DriverManager.getConnection(URL, USERNAME, PASSWORD);
    }

    public static int getCount(String sql) {
        Connection conn = null;
        PreparedStatement st = null;
        ResultSet rs = null;
        try {
            conn = getConnection();
            if (conn == null)
                return 0;
            st = conn.prepareStatement(sql);
            rs = st.executeQuery();
            if (rs.next()) {
                return rs.getInt(1);
            }

        } catch (Exception ignored) {

        } finally {
            close(rs,null,conn);
        }
        return 0;

    }


    public static void exeSQL(String sql) {
        Connection conn = null;
        PreparedStatement ps = null;
        try {
            conn = getConnection();
            if (conn != null) {
                ps = conn.prepareStatement(sql);
                ps.execute();
            }
        } catch (Exception se) {
            log.error(se.getMessage(),se);
        } finally {
            close(null,ps, conn);
        }
    }


    public static List<JSONObject> query(String sql) {
        List<JSONObject> jsonList = new LinkedList<>();
        Connection conn = null;
        PreparedStatement ps = null;
        ResultSet rs = null;

        try {
            conn = getConnection();
            if (conn == null)
                return jsonList;
            ps = conn.prepareStatement(sql);
            rs = ps.executeQuery();
            while (rs.next()) {
                ResultSetMetaData rsmd = rs.getMetaData();
                JSONObject jsonObject = new JSONObject();
                for (int i = 1; i <= rsmd.getColumnCount(); i++) {
                    String col = rsmd.getColumnLabel(i);
                    jsonObject.put(col, getStr(rs, col));
                }
                jsonList.add(jsonObject);
            }
        } catch (Exception se) {
            log.error(se.getMessage(),se);
        } finally {
            close(rs, ps, conn);
        }
        return jsonList;
    }


    public static String getStr(ResultSet rs, String filter) {
        try {
            return rs.getString(filter);
        } catch (Exception e) {
            return "";
        }
    }

    public static int getInt(ResultSet rs, String filter) {
        try {
            return rs.getInt(filter);
        } catch (Exception e) {
            return 0;
        }
    }

    public static List<JSONObject> getAllTable() {
        List<JSONObject> tbList = new LinkedList<>();
        List<JSONObject> list = query("select database() as dbname");
        if (list == null || list.size() < 1) {
            return tbList;
        }

        String dbname = JsonUtils.getStr(list.get(0), "dbname");
        if (StringUtils.isNotBlank(dbname)) {
            String sql = "SELECT table_name FROM information_schema.tables WHERE table_schema='" + dbname + "'";
            return query(sql);
        }
        return tbList;
    }

    public static int existTable(String tableName) {
        try {
            List<JSONObject> list = query("select database() as dbname");
            if (list == null || list.size() < 1) {
                return -1;
            }

            String dbname = DataUtils.getString(list.get(0), "dbname");
            if (StringUtils.isNotBlank(dbname)) {
                String sql = "SELECT count(1) FROM information_schema.tables WHERE table_schema='%s' and table_name = '%s'";
                if (getCount(String.format(sql, dbname, tableName)) > 0) {
                    return 1;
                } else {
                    return 0;
                }
            }
        } catch (Exception se) {
            log.error(se.getMessage(),se);
        }
        return -1;
    }

    public static String getValueBySql(String sql, String filter) {

        try {
            List<JSONObject> list = query(sql);
            if (list == null || list.size() < 1) {
                return "";
            }

            return JsonUtils.getStr(list.get(0), filter);
        } catch (Exception se) {
            log.error(se.getMessage(),se);
        }
        return "";
    }

    public static void close(ResultSet rs, PreparedStatement ps, Connection conn){
        try {
            if (rs != null) {
                rs.close();
            }
        } catch (Exception ignored) {

        }

        try {
            if (ps != null) {
                ps.close();
            }
        } catch (Exception ignored) {

        }


        try {
            if (conn != null) {
                conn.close();
            }
        } catch (Exception ignored) {

        }
    }
}

