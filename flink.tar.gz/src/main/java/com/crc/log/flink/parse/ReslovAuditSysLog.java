package com.crc.log.flink.parse;

import com.crc.log.flink.common.constants.LevelConstants;
import com.crc.log.flink.common.constants.LogConstants;
import com.crc.log.flink.common.utils.DataUtils;
import com.crc.log.flink.common.utils.DateUtils;
import com.crc.log.flink.common.utils.JsonUtils;
import com.crc.log.flink.common.utils.MapUtils;
import org.apache.commons.lang3.StringUtils;

import java.util.concurrent.ConcurrentHashMap;

/**
 * @author jixiangqi
 * @date 2021/12/30
 * 审计Syslog
 */
public class ReslovAuditSysLog {
    public static ConcurrentHashMap<String,Object> parse(String message) {
        try {
            ConcurrentHashMap<String,Object> data = proc(message);
            if (DataUtils.isNotEmptyJson(data)) {
                return data;
            }
        } catch (Exception ignored) {

        }
        return null;
    }

    private static ConcurrentHashMap<String,Object> proc(String jsonStr) {
        ConcurrentHashMap<String,Object> rtnObjc = JsonUtils.createBaseMap(jsonStr);
        String[] strings = DataUtils.getSplit(jsonStr, ",");
        for (String temp : strings) {
            int index = DataUtils.getIndex(temp, ":");
            String key = DataUtils.getSubString(temp, 0, index).trim();
            String value = DataUtils.getSubString(temp, index + 1).trim();
            switch (key) {
                case "type":
                    rtnObjc.put(LogConstants.ACTION_TYPE, value);
                    break;
                case "flowInBytes":
                    rtnObjc.put(LogConstants.DOWN_FLUX, value);
                    break;
                case "username":
                    rtnObjc.put(LogConstants.USER_NAME, value);
                    break;
                case "IP":
                    rtnObjc.put(LogConstants.SRC_IP, value);
                    break;
                case "userMac":
                    rtnObjc.put(LogConstants.SRC_MAC, value);
                    break;
                case "terminalPlatform":
                    rtnObjc.put(LogConstants.LOG_TERMINAL_TYPE, value);
                    break;
                case "time":
                    rtnObjc.put(LogConstants.LOG_START_TIME, DateUtils.getISO8601Timestamp(value));
                    break;
            }
        }

        rtnObjc.put(LogConstants.LOG_PRODUCT, "置地访客认证平台");
        rtnObjc.put(LogConstants.LOG_LEVEL, LevelConstants.getLevel(MapUtils.getStr(rtnObjc,LogConstants.LOG_LEVEL)));
        if (StringUtils.isBlank(MapUtils.getStr(rtnObjc, LogConstants.SRC_IP))) {
            rtnObjc.put(LogConstants.SRC_IP, "0.0.0.0");
        }
        if (StringUtils.isBlank(MapUtils.getStr(rtnObjc, LogConstants.DEST_IP))) {
            rtnObjc.put(LogConstants.DEST_IP, "0.0.0.0");
        }
        setAlertName(rtnObjc);
        return rtnObjc;
    }

    private static void setAlertName(ConcurrentHashMap<String,Object> rtnObjc) {
        String srcIp = MapUtils.getStr(rtnObjc, LogConstants.SRC_IP);
        String action = MapUtils.getStr(rtnObjc, LogConstants.ACTION_TYPE);
        String level = MapUtils.getStr(rtnObjc, LogConstants.LOG_LEVEL);
        String userName = MapUtils.getStr(rtnObjc, LogConstants.USER_NAME);
        String log = MapUtils.getStr(rtnObjc, LogConstants.LOG_ORI_MSG);
        String msgFormat = "用户名为:%s在IP地址为:%s发起了一个:%s，安全等级为:%s,日志详情为:%s";
        String alertName = String.format(msgFormat, userName, srcIp, action, level,log);
        rtnObjc.put(LogConstants.ALERT_NAME, alertName);
    }

}
