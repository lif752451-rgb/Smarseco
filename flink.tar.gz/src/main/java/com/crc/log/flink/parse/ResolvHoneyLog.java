package com.crc.log.flink.parse;

import com.alibaba.fastjson.JSONObject;
import com.crc.log.flink.common.constants.*;
import com.crc.log.flink.common.utils.*;
import org.apache.commons.lang3.StringUtils;

import java.util.Date;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

/**
 * 蜜罐日志格式化
 */
@SuppressWarnings("unchecked")
public class ResolvHoneyLog {

    /**
     * 蜜罐日志泛化
     */
    public static ConcurrentHashMap<String, Object> parse(String message) {
        try {
            ConcurrentHashMap<String, Object> data = proc(message);
            if (DataUtils.isNotEmptyJson(data)) {
                return data;
            }
        } catch (Exception ignored) {

        }
        return null;
    }

    private static ConcurrentHashMap<String, Object> proc(String value) {
        ConcurrentHashMap<String, Object> ldapJson = JsonUtils.createBaseMap(value);
        try {
            if (StringUtils.isNotBlank(value)) {
                ldapJson.put(LogConstants.LOG_PRODUCT, "长亭蜜罐");
                if (StringUtils.isNotBlank(value) && value.contains("{")) {
                    String destIp = getDestIpByPreMsg(value);
                    if (!StringUtils.isEmpty(destIp)) {
                        ldapJson.put(LogConstants.DEST_IP, destIp);
                    }
                    JSONObject msgJson2 = getMsgContent(value);
                    if (value.contains("ahhoneypot")) {
                        //安恒蜜罐
                        ldapJson.put(LogConstants.LOG_PRODUCT, "安恒蜜罐");
                        JSONObject msgJson = msgJson2.getJSONObject("payload");
                        MapUtils.setJsonValue(ldapJson, msgJson, LogConstants.SRC_IP, "src_ip");
                        MapUtils.setJsonValue(ldapJson, msgJson, LogConstants.DEST_IP, "dst_ip");
                        MapUtils.setJsonValue(ldapJson, msgJson, LogConstants.SRC_PORT, "src_port");
                        MapUtils.setJsonValue(ldapJson, msgJson, LogConstants.DEST_PORT, "dst_port");
                        if (MapUtils.isBlank(ldapJson, LogConstants.DEST_IP)) {
                            MapUtils.setJsonValue(ldapJson, msgJson, LogConstants.DEST_IP, "proxy_ip");
                        }

                        MapUtils.setJsonValue(ldapJson, msgJson, LogConstants.LOG_DESCRIPTION, "auth");
                        MapUtils.setJsonValue(ldapJson, msgJson, LogConstants.LOG_NAME, "name");
                        MapUtils.setJsonValue(ldapJson, msgJson, LogConstants.LOG_TYPE, "attack_type");
                        if (MapUtils.isBlank(ldapJson, LogConstants.LOG_DESCRIPTION)) {
                            MapUtils.setJsonValue(ldapJson, msgJson, LogConstants.LOG_DESCRIPTION, "description");
                        }
                        MapUtils.setStr(ldapJson, LogConstants.LOG_LEVEL, LevelConstants.LOW);
                        if (msgJson.containsKey("payload")) {
                            JSONObject payload = JsonUtils.getJson(msgJson, "payload");
                            int riskLevel = JsonUtils.getInt(payload, "risk_level");
                            if (riskLevel > 3) {
                                MapUtils.setStr(ldapJson, LogConstants.LOG_LEVEL, LevelConstants.HIGH);
                            } else if (riskLevel > 1) {
                                MapUtils.setStr(ldapJson, LogConstants.LOG_LEVEL, LevelConstants.MEDIUM);
                            }
                        }

                        MapUtils.setStr(ldapJson, LogConstants.LOG_START_TIME, DateUtils.getISO8601Timestamp(JsonUtils.getStr(msgJson, "start_time")));
                        setAlertName(ldapJson);
                    } else {
                        boolean isMoan = false;
                        String type = JsonUtils.getStr(msgJson2, "source");
                        String type2 = JsonUtils.getStr(msgJson2, "type");
                        String type3 = JsonUtils.getStr(msgJson2, "asset_name");
                        if ("honeypot".equalsIgnoreCase(type)) {
                            parseHoneyPotJson(ldapJson, msgJson2);
                        } else if ("scanner".equalsIgnoreCase(type)) {
                            parseScannerJson(ldapJson, msgJson2);
                        } else if (msgJson2.containsKey("browser")) {
                            parseAttackSourceJson(ldapJson, msgJson2);
                        } else {
                            if ("agent_connect".equalsIgnoreCase(type2) || "agent_disconnect".equalsIgnoreCase(type2)) {
                                parseOtherHoneyJson(ldapJson, msgJson2);
                            } else if (StringUtils.isNotBlank(type3)) {
                                parseMoanJson(ldapJson, msgJson2);
                                isMoan = true;
                            }
                        }
                        //默安蜜罐
                        ldapJson.put(LogConstants.LOG_PRODUCT, "默安蜜罐");
                        if (!isMoan) {
                            MapUtils.setStr(ldapJson, LogConstants.ACTION_RESULT, "企图");
                        }
                        MapUtils.setStr(ldapJson, LogConstants.LOG_LEVEL, LevelConstants.getLevel2(MapUtils.getStr(ldapJson, LogConstants.LOG_LEVEL)));
                        if (StringUtils.isEmpty(MapUtils.getStr(ldapJson, LogConstants.ALERT_NAME))) {
                            setAlertName(ldapJson);
                        }
                    }
                }

                ScoreUtils.commonEventLevelScore(ldapJson);
            }
            if (StringUtils.isBlank(MapUtils.getStr(ldapJson, LogConstants.SRC_IP))) {
                ldapJson.put(LogConstants.SRC_IP, "0.0.0.0");
            }
            if (StringUtils.isBlank(MapUtils.getStr(ldapJson, LogConstants.DEST_IP))) {
                ldapJson.put(LogConstants.DEST_IP, "0.0.0.0");
            }
            return ldapJson;
        } catch (Exception e) {
            System.err.println(e.getMessage());
            return ldapJson;
        }
    }

    public static String getLogName(int index) {
        String[] logNams = {"arp扫描"
                , "arp中间人攻击"
                , "非法登录"
                , "文件写入"
                , "文件删除"
                , "文件重命名"
                , "文件提权"
                , "可疑进程"
                , "异常流量"
                , "可疑启动项"
                , "可疑系统服务"
                , "可疑定时任务"
                , "暴力破解"
                , "命令执行"
                , "端口扫描"
                , "暴力破解"
                , "非法请求"
                , "modbus协议嗅探"
                , "snmp协议嗅探"
                , "s7comm协议嗅探"
                , "非法探测"
                , "非法外连", "远程下载"
                , "文件传输"
                , "进程退出"
                , "新增用户"
                , "删除用户"
                , "动态链接库变更"
                , "修改注册表"
                , "远程执行"
                , "软件卸载"
                , "端口转发"
                , "禁用防火墙"
                , "信息收集"
                , "隐匿踪迹"};
        try {
            return logNams[index - 1];
        } catch (Exception e) {

        }
        return "";
    }

    public static void setAlertName(ConcurrentHashMap<String, Object> resultJson) {
        String product = MapUtils.getStr(resultJson, LogConstants.LOG_PRODUCT);
        String srcIp = MapUtils.getStr(resultJson, LogConstants.SRC_IP);
        String destIp = MapUtils.getStr(resultJson, LogConstants.DEST_IP);
        String eventType = MapUtils.getStr(resultJson, LogConstants.LOG_TYPE);
        String logName = MapUtils.getStr(resultJson, LogConstants.LOG_NAME);
        String logDescription = MapUtils.getStr(resultJson, LogConstants.LOG_DESCRIPTION);
        if (product.equalsIgnoreCase("安恒蜜罐")) {
            resultJson.put(LogConstants.ALERT_NAME, eventType);
        } else if (product.equalsIgnoreCase("长亭蜜罐")) {
            if (StringUtils.isBlank(destIp) || "null".equals(destIp) || "0.0.0.0".equals(destIp) || srcIp.equals(destIp)) {
                if (logName.equals("攻击者溯源")) {
                    String messageFormat = "%s 发起 %s%s,日志详情为:%s";
                    String alertName = String.format(messageFormat, srcIp, logName,
                            String.format(",IP源归属%s%s", MapUtils.getStr(resultJson, "country"),
                                    MapUtils.getStr(resultJson, "city")),
                            MapUtils.getStr(resultJson, LogConstants.LOG_ORI_MSG));
                    resultJson.put(LogConstants.ALERT_NAME, alertName);
                } else {
                    String messageFormat = "%s 发起 %s-%s,日志详情为:%s";
                    String alertName = String.format(messageFormat, srcIp, logName, eventType, MapUtils.getStr(resultJson, LogConstants.LOG_ORI_MSG));
                    resultJson.put(LogConstants.ALERT_NAME, alertName);
                }
            } else {
                if (logName.equals("攻击者溯源")) {
                    String messageFormat = "%s 对 %s 进行 %s%s, 日志详情为:%s";
                    String alertName = String.format(messageFormat, srcIp, destIp, logName, String.format(",IP源归属%s%s",
                            MapUtils.getStr(resultJson, "country"),
                            MapUtils.getStr(resultJson, "city")), MapUtils.getStr(resultJson, LogConstants.LOG_ORI_MSG));
                    resultJson.put(LogConstants.ALERT_NAME, alertName);
                } else {
                    String messageFormat = "%s 对 %s 进行 %s-%s,日志详情为:%s";
                    String alertName = String.format(messageFormat, srcIp, destIp, logName, eventType, MapUtils.getStr(resultJson, LogConstants.LOG_ORI_MSG));
                    resultJson.put(LogConstants.ALERT_NAME, alertName);
                }
            }

        } else if (product.equalsIgnoreCase("默安蜜罐")) {
            if (StringUtils.isBlank(destIp) || "null".equals(destIp) || "0.0.0.0".equals(destIp) || srcIp.equals(destIp)) {
                String messageFormat = "%s 发起 %s-%s,日志详情为:%s";
                String alertName = String.format(messageFormat, srcIp, logName, logDescription, MapUtils.getStr(resultJson, LogConstants.LOG_ORI_MSG));
                resultJson.put(LogConstants.ALERT_NAME, alertName);
            } else {
                String messageFormat = "%s 对 %s 进行 %s-%s,日志详情为:%s";
                String alertName = String.format(messageFormat, srcIp, destIp, logName, logDescription, MapUtils.getStr(resultJson, LogConstants.LOG_ORI_MSG));
                resultJson.put(LogConstants.ALERT_NAME, alertName);
            }

        }
    }

    public static String getDestIpByPreMsg(String msg) {
        String ip = "";
        String preMsg = DataUtils.getSubString(msg, 0, DataUtils.getIndex(msg, "{"));
        //msg.substring(0, msg.indexOf("{"));
        if (StringUtils.isNotBlank(preMsg)) {
            String[] arr = DataUtils.getSplit(preMsg, " ");
            //preMsg.split(" ");
            if (arr.length > 1) {
                if (!DateUtils.isDate(arr[0])) {
                    arr[0] = DateUtils.getDateTimeString1(new Date());
                }
                if (IPUtil.isIp(arr[1])) {
                    ip = arr[1];
                }
            }
        }
        return ip;
    }

    public static JSONObject getMsgContent(String msg) {
        JSONObject json = null;
        if (StringUtils.isNotBlank(msg) && msg.contains("{")) {
            msg = DataUtils.getSubString(msg, DataUtils.getIndex(msg, "{"));
            //msg.substring(msg.indexOf("{"));
            int index = DataUtils.getLastIndex(msg, "}");
            if (index != -1) {
                msg = DataUtils.getSubString(msg, 0, index + 1);
                json = JsonUtils.parse(msg);
            }
        }
        return json;
    }

    public static void parseHoneyPotJson(ConcurrentHashMap<String, Object> ldapJson, JSONObject json) {
        MapUtils.setStr(ldapJson, LogConstants.SRC_MAC, json, "src_mac");
        MapUtils.setStr(ldapJson, LogConstants.SRC_DEV_INFO, json, "agent");
        MapUtils.setStr(ldapJson, LogConstants.SRC_IP, json, "src_ip");
        MapUtils.setStr(ldapJson, LogConstants.SRC_PORT, json, "src_port");
        MapUtils.setStr(ldapJson, LogConstants.LOG_LEVEL, json, "risk_level");
        MapUtils.setStr(ldapJson, LogConstants.LOG_NAME, "入侵事件");
        MapUtils.setStr(ldapJson, LogConstants.DEST_IP, json, "dest_ip");
        MapUtils.setStr(ldapJson, LogConstants.DEST_PORT, json, "dest_port");
        String actionType = JsonUtils.getStr(json, "event_type");
        MapUtils.setStr(ldapJson, LogConstants.ACTION_TYPE, HoneyConstants.getEventType(actionType));
        MapUtils.setStr(ldapJson, LogConstants.LOG_TYPE, HoneyConstants.getEventType(actionType));
        if (StringUtils.isNotBlank(actionType) && actionType.contains("login")) {
            JSONObject extra = JsonUtils.getJson(json, "extra");
            if (!extra.isEmpty()) {
                JSONObject suc = JsonUtils.getJson(extra, "success");
                String ret = JsonUtils.getStr(suc, "value");
                String actionResult = "yes".equalsIgnoreCase(ret) ? ActionResultConstants.ATTACK_SUCCUSS :
                        ("no".equalsIgnoreCase(ret) ? ActionResultConstants.ATTACK_FAIL : ActionResultConstants.UNKNOWN);
                MapUtils.setStr(ldapJson, LogConstants.ACTION_RESULT, actionResult);
            }
        }
        String logType = MapUtils.getStr(ldapJson, LogConstants.LOG_TYPE);
        if (logType.equalsIgnoreCase("连接断开") || logType.equalsIgnoreCase("连接建立")) {
            MapUtils.setStr(ldapJson, LogConstants.LOG_LEVEL, json, "低风险");
        }
        MapUtils.setStr(ldapJson, LogConstants.LOG_START_TIME, DateUtils.getISO8601Timestamp(JsonUtils.getLong(json, "time") * 1000L));
    }

    public static void parseScannerJson(ConcurrentHashMap<String, Object> ldapJson, JSONObject json) {
        MapUtils.setStr(ldapJson, LogConstants.SRC_DEV_INFO, json, "agent");
        MapUtils.setStr(ldapJson, LogConstants.SRC_IP, json, "src_ip");
        MapUtils.setStr(ldapJson, LogConstants.SRC_PORT, json, "src_port");
        MapUtils.setStr(ldapJson, LogConstants.LOG_NAME, "扫描事件");
        MapUtils.setStr(ldapJson, LogConstants.DEST_IP, json, "dest_ip");
        MapUtils.setStr(ldapJson, LogConstants.DEST_PORT, json, "dest_port");
        MapUtils.setStr(ldapJson, LogConstants.ACTION_TYPE, json, "type");
        MapUtils.setStr(ldapJson, LogConstants.LOG_TYPE, json, "type");
        MapUtils.setStr(ldapJson, LogConstants.LOG_START_TIME, DateUtils.getISO8601Timestamp(JsonUtils.getLong(json, "start_time") * 1000L));
    }

    public static void parseAttackSourceJson(ConcurrentHashMap<String, Object> ldapJson, JSONObject json) {
        ldapJson.put(LogConstants.LOG_NAME, "攻击者溯源");
        String desc = "攻击源IP为%s，地址为%s，设备信息为%s";

        MapUtils.setJsonValue(ldapJson, json, LogConstants.SRC_DEV_INFO, "host.os", LogConstants.MSG_CONTENT, "host.render");
        JSONObject network = JsonUtils.getJson(json, "network");
        String country = JsonUtils.getJsonValue(network, "realIP.country");
        if (StringUtils.isNotBlank(country))
            ldapJson.put("country", country);
        String city = JsonUtils.getJsonValue(network, "realIP.city");
        if (StringUtils.isNotBlank(city))
            ldapJson.put("city", city);


        // }
        String devInfo = "";
        JSONObject ipInfo = JsonUtils.getJson(json, "browser");
        MapUtils.setJsonValue(ldapJson, json, LogConstants.SRC_DEV_INFO, "browser.os");
        String di = JsonUtils.getStr(ipInfo, "os") + " " + JsonUtils.getStr(ipInfo, "name") + " " + JsonUtils.getStr(ipInfo, "version");
        if (StringUtils.isNotBlank(di))
            devInfo = di;

        MapUtils.setStr(ldapJson, LogConstants.LOG_START_TIME, DateUtils.getISO8601Timestamp(JsonUtils.getLong(json, "last_attack_time") * 1000L));
    }

    public static void parseOtherHoneyJson(ConcurrentHashMap<String, Object> ldapJson, JSONObject json) {
        String type = JsonUtils.getStr(json, "type");
        if ("agent_connect".equalsIgnoreCase(type) || "agent_disconnect".equalsIgnoreCase(type)) {
            MapUtils.setStr(ldapJson, LogConstants.SRC_DEV_INFO, json, "os_type");
            ldapJson.put(LogConstants.SRC_IP, JsonUtils.getStr(json, "host"));
            if (StringUtils.isBlank(MapUtils.getStr(ldapJson, LogConstants.SRC_IP))) {
                MapUtils.setStr(ldapJson, LogConstants.SRC_IP, JsonUtils.getStr(json, "src_ip"));

            }
            MapUtils.setStr(ldapJson, LogConstants.ACTION_RESULT, JsonUtils.getStr(json, "status"));
            MapUtils.setStr(ldapJson, LogConstants.LOG_NAME, "探针连接或断开事件");

            MapUtils.setStr(ldapJson, LogConstants.HOST_NAME, json, "hostname");
            MapUtils.setStr(ldapJson, LogConstants.LOG_START_TIME, DateUtils.getISO8601Timestamp(DateUtils.getISO8601Timestamp(JsonUtils.getLong(json, "created") * 1000L)));
            MapUtils.setStr(ldapJson, LogConstants.ACTION_TYPE, JsonUtils.getStr(json, "type"));
            MapUtils.setStr(ldapJson, LogConstants.LOG_TYPE, JsonUtils.getStr(json, "type"));
        }

    }

    public static void parseMoanJson(ConcurrentHashMap<String, Object> ldapJson, JSONObject json) {
        MapUtils.setStr(ldapJson, LogConstants.LOG_PRODUCT, "默安蜜罐");
        MapUtils.setStr(ldapJson, LogConstants.LOG_DESCRIPTION, JsonUtils.getStr(json, "attack_desc"));
        MapUtils.setStr(ldapJson, LogConstants.SRC_IP, JsonUtils.getStr(json, "attack_ip"));
        MapUtils.setStr(ldapJson, LogConstants.LOG_TYPE, JsonUtils.getStr(json, "asset_name"));
        MapUtils.setStr(ldapJson, LogConstants.LOG_START_TIME, DateUtils.getISO8601Timestamp(JsonUtils.getStr(json, "attack_time")));
        MapUtils.setStr(ldapJson, LogConstants.ACTION_TYPE, JsonUtils.getStr(json, "attack_type"));

        MapUtils.setStr(ldapJson, LogConstants.MSG_CONTENT, JsonUtils.getStr(json, "detail"));
        //探测事件  低风险  入侵事件  高风险
        String logName = "INVADE".equalsIgnoreCase(MapUtils.getStr(ldapJson, LogConstants.ACTION_TYPE)) ? "入侵事件" : "探测事件";
        String logLevel = "INVADE".equalsIgnoreCase(MapUtils.getStr(ldapJson, LogConstants.ACTION_TYPE)) ? "高风险" : "低风险";
        MapUtils.setStr(ldapJson, LogConstants.LOG_NAME, logName);
        MapUtils.setStr(ldapJson, LogConstants.LOG_LEVEL, logLevel);
        MapUtils.setJsonValue(ldapJson, json, LogConstants.SRC_IP_COUNTRY, "attack_ip_info.country",
                LogConstants.SRC_IP_CITY, "attack_ip_info.city");


        JSONObject detail = json.getJSONObject("detail");
        if (detail != null && !detail.isEmpty()) {
            String actionType = JsonUtils.getStr(detail, "action_type");
            String optType = JsonUtils.getStr(detail, "opt_type");
            if (StringUtils.isNotBlank(actionType)) {
                for (Map.Entry<String, String> entry : MoAnContants.eventTypeMap.entrySet()) {
                    String k = entry.getKey();
                    String v = entry.getValue();
                    if (k.equals(actionType)) {
                        if ("115".equals(k) || "116".equals(k) || "117".equals(k) || "118".equals(k)) {
                            ldapJson.put(LogConstants.LOG_TYPE, v);
                            if (StringUtils.isNotBlank(optType) && MoAnContants.actionTypeMap.containsKey(optType)) {
                                ldapJson.put(LogConstants.ACTION_TYPE, MoAnContants.actionTypeMap.get(optType));
                            }
                        } else {
                            ldapJson.put(LogConstants.LOG_TYPE, "执行系统操作");
                            ldapJson.put(LogConstants.ACTION_TYPE, v);
                        }
                    }
                }
            }
            if (!StringUtils.isEmpty(detail.getString("dest_ip"))) {
                ldapJson.put(LogConstants.DEST_IP, detail.getString("dest_ip"));
            }
        }
        if (StringUtils.isEmpty(MapUtils.getStr(ldapJson, LogConstants.DEST_IP))) {
            ldapJson.put(LogConstants.DEST_IP, json.getString("vm_ip"));
        }
        ldapJson.put(LogConstants.LOG_TYPE, MapUtils.getStr(ldapJson, LogConstants.ACTION_TYPE));

        setAlertName(ldapJson);
    }


}
