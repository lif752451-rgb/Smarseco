package com.crc.log.flink.parse;

import com.alibaba.fastjson.JSONObject;
import com.crc.log.flink.common.constants.ActionResultConstants;
import com.crc.log.flink.common.constants.CtWafConstants;
import com.crc.log.flink.common.constants.LevelConstants;
import com.crc.log.flink.common.constants.LogConstants;
import com.crc.log.flink.common.utils.*;
import org.apache.commons.lang3.StringUtils;

import java.util.concurrent.ConcurrentHashMap;

/**
 * 蜜罐日志格式化
 */
@SuppressWarnings("unchecked")
public class ResolvCtWafLog {

    /**
     * 长亭WAF日志泛化
     */
    public static ConcurrentHashMap<String, Object> parse(String message) {
        try {
            ConcurrentHashMap<String, Object> data = proc(message);
            if (DataUtils.isNotEmptyJson(data)) {
                return data;
            }
        } catch (Exception ignored) {

        }
        return null;
    }

    private static ConcurrentHashMap<String, Object> proc(String value) {
        ConcurrentHashMap<String, Object> ldapJson = JsonUtils.createBaseMap(value);
        try {
            String msg = value;
            ldapJson.put(LogConstants.LOG_PRODUCT, "长亭Waf");
            if (StringUtils.isNotBlank(msg)) {
                if (StringUtils.isNotBlank(msg) && msg.contains("{")) {
                    msg = DataUtils.getSubString(msg, msg.indexOf("{"));
                            //msg.substring(msg.indexOf("{"));
                    msg = DataUtils.getSubString(msg, 0, DataUtils.getLastIndex(msg, "}")+1);
                            //msg.substring(0, msg.lastIndexOf("}") + 1);
                    if (StringUtils.isBlank(msg)) {
                        return ldapJson;
                    }
                    JSONObject json = JsonUtils.parse(msg);
                    if (null != json && !json.isEmpty()) {
                        parseCtWafJson(json, ldapJson);
                    } else {
                        try {
                            json = new JSONObject();
                            msg = DataUtils.getSubString(msg, DataUtils.getIndex(msg, "{") + 1);
                                    //msg.substring(msg.indexOf("{") + 1);
                            //msg = msg.substring(0, msg.lastIndexOf("}") + 1);
                            msg = msg.replace("\"", "");
                            for (String x : DataUtils.getSplit(msg, ",")) {
                                try {
                                    String[] m = DataUtils.getSplit2(x, ":");
                                    json.put(m[0].trim(), m[1].trim());
                                } catch (Exception ignored) {

                                }
                            }
                            parseCtWafJson(json, ldapJson);
                        } catch (Exception e) {

                        }
                    }
                }
                ldapJson.put(LogConstants.LOG_LEVEL, LevelConstants.getLevel(MapUtils.getStr(ldapJson,LogConstants.LOG_LEVEL)));
                ScoreUtils.commonEventLevelScore(ldapJson);
            }
            if (StringUtils.isBlank(MapUtils.getStr(ldapJson, LogConstants.SRC_IP))) {
                ldapJson.put(LogConstants.SRC_IP, "0.0.0.0");
            }
            if (StringUtils.isBlank(MapUtils.getStr(ldapJson, LogConstants.DEST_IP))) {
                ldapJson.put(LogConstants.DEST_IP, "0.0.0.0");
            }
            return ldapJson;
        } catch (Exception e) {
            System.err.println(e.getMessage());
        }

        return ldapJson;
    }

    public static void parseCtWafJson(JSONObject json, ConcurrentHashMap<String, Object> retData) {
        String action = JsonUtils.getStr(json, "action");
        //deny（拦截）、allow（放行）、unknown（未知）
        String actionResult = "deny".equalsIgnoreCase(action) ? ActionResultConstants.DENY :
                ("allow".equalsIgnoreCase(action) ? ActionResultConstants.NO_DENY : ActionResultConstants.UNKNOWN);
        MapUtils.setStr(retData, LogConstants.ACTION_RESULT, actionResult);
        MapUtils.setStr(retData, LogConstants.SRC_IP, json, "src_ip");
        MapUtils.setStr(retData, LogConstants.SRC_PORT, json, "src_port");
        MapUtils.setStr(retData, LogConstants.LOG_LEVEL, json, "risk_level");
        MapUtils.setStr(retData, LogConstants.LOG_NAME, json, "reason");
        MapUtils.setStr(retData, LogConstants.DEST_IP, json, "dest_ip");
        if (json.containsKey("dst_ip")) {
            MapUtils.setStr(retData, LogConstants.DEST_IP, json, "dst_ip");
        }
        MapUtils.setStr(retData, LogConstants.DEST_PORT, json, "dest_port");
        if (json.containsKey("dst_port")) {
            MapUtils.setStr(retData, LogConstants.DEST_PORT, json, "dst_port");
        }
        MapUtils.setStr(retData, LogConstants.LOG_URL, json, "urlpath");
        MapUtils.setStr(retData, LogConstants.HOST_NAME, json, "host");
        MapUtils.setStr(retData, LogConstants.SRC_DEV_INFO, json, "user_agent");
        MapUtils.setStr(retData, LogConstants.MSG_CONTENT, json, "req_header_raw");
        if (json.containsKey("req_header")) {
            MapUtils.setStr(retData, LogConstants.MSG_CONTENT, json, "req_header");
        }
        MapUtils.setStr(retData, LogConstants.LOG_DESCRIPTION, json, "payload");
        if (json.containsKey("req_body")) {
            MapUtils.setStr(retData, LogConstants.LOG_DESCRIPTION, json, "req_body");
        }
        MapUtils.setStr(retData, LogConstants.LOG_PROTOCAL, json, "protocol");
        String actionRule = CtWafConstants.getEventType(JsonUtils.getStr(json, "module"));
        MapUtils.setStr(retData, LogConstants.ACTION_RULE, actionRule);
        MapUtils.setStr(retData, LogConstants.ACTION_TYPE, json, "method");
        String eventType = CtWafConstants.getEventType(JsonUtils.getStr(json, "attack_type"));
        MapUtils.setStr(retData, LogConstants.LOG_TYPE, CtWafConstants.getEventType(eventType));
        MapUtils.setStr(retData, LogConstants.LOG_START_TIME, DateUtils.getISO8601Timestamp(JsonUtils.getLong(json, "timestamp") * 1000L));
        retData.put(LogConstants.LOG_LEVEL, LevelConstants.getLevel(MapUtils.getStr(retData,LogConstants.LOG_LEVEL)));
        if (StringUtils.isBlank(MapUtils.getStr(retData, LogConstants.SRC_IP))) {
            retData.put(LogConstants.SRC_IP, "0.0.0.0");
        }
        if (StringUtils.isBlank(MapUtils.getStr(retData, LogConstants.DEST_IP))) {
            retData.put(LogConstants.DEST_IP, "0.0.0.0");
        }
        setAlertName(retData);
    }

    public static void setAlertName(ConcurrentHashMap<String, Object> resultJson) {
        String srcIp = MapUtils.getStr(resultJson, LogConstants.SRC_IP);
                //resultJson.getString(LogConstants.SRC_IP);
        String hostName = MapUtils.getStr(resultJson, LogConstants.DEST_IP);
        String actionRule = MapUtils.getStr(resultJson, LogConstants.ACTION_RULE);
        if (StringUtils.isEmpty(actionRule)) {
            actionRule = "自定义规则";
        }
        String eventType = MapUtils.getStr(resultJson, LogConstants.LOG_TYPE);
        String logName = MapUtils.getStr(resultJson, LogConstants.LOG_NAME);
        String actionResult = MapUtils.getStr(resultJson, LogConstants.ACTION_RESULT);
        String content = MapUtils.getStr(resultJson, LogConstants.LOG_CONTENT);
        String description = MapUtils.getStr(resultJson, LogConstants.LOG_DESCRIPTION);
        String log = MapUtils.getStr(resultJson, LogConstants.LOG_ORI_MSG);
        String messageFormat = "%s 对 %s 进行 %s-%s-%s-%s, 具体内容为:%s,具体描述为:%s,原始日志:%s";
        String alertName = String.format(messageFormat, srcIp, hostName, actionRule, eventType, logName, actionResult, content, description, log);
        if (StringUtils.isBlank(logName) && StringUtils.isBlank(eventType)) {
            messageFormat = "%s 对 %s 进行%s访问-%s,具体内容为:%s,具体描述为:%s,原始日志:%s";
            alertName = String.format(messageFormat, srcIp, hostName, actionRule, actionResult, content, description, log);
        }
        resultJson.put(LogConstants.ALERT_NAME, alertName);
    }
}
