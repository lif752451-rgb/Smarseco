package com.crc.log.flink.handle;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;
import com.crc.log.flink.FlinkApplication;
import com.crc.log.flink.common.constants.HryhKafkaConstants;
import com.crc.log.flink.common.constants.LogConstants;
import com.crc.log.flink.common.entity.IpMappgingRule;
import com.crc.log.flink.common.utils.*;
import com.crc.log.flink.load.EventRuleLoad;
import com.crc.log.flink.parse.*;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;

import java.util.Date;
import java.util.concurrent.ConcurrentHashMap;

/**
 * 根据解析规则，自动调用解析类
 */
@Slf4j
public class TidyRuleParseHandle {

    public static ConcurrentHashMap<String, Object> parse(String message, String topicName) {
        try {
            ConcurrentHashMap<String, Object> data = proc(message, topicName);
            if (DataUtils.isNotEmptyJson(data)) {
                return data;
            }
        } catch (Exception ignored) {

        }
        return null;
    }

    private static ConcurrentHashMap<String, Object> proc(String jsonStr, String topicName) {
        try {
            if (StringUtils.isNotBlank(jsonStr)) {
                JSONObject jobj = JsonUtils.parse(jsonStr);
                String devIp = JsonUtils.getStr(jobj, "dev_ip");
                /*
                Filebeat日志，设备IP埋在fields属性中 2022-03-28
                 */
                if (jobj.containsKey("@timestamp") && jobj.containsKey("fields")) {
                    JSONObject fields = jobj.getJSONObject("fields");
                    if (fields != null && fields.containsKey("dev_ip")) {
                        devIp = JsonUtils.getStr(fields, "dev_ip");
                    }
                }
                if (!StringUtils.isNotBlank(devIp)) {
                    devIp = JsonUtils.getStr(jobj, "host");
                }
                /*
                 * Syslog接收的，处理message字段
                 */
                Date revTime = null;
                if ("udp".equalsIgnoreCase(JsonUtils.getStr(jobj, "type")) || JsonUtils.isBlank(jobj, "type")) {
                    if (jobj.containsKey("message")) {
                        jsonStr = JsonUtils.getStr(jobj, "message");
                    }
                    if (jobj.containsKey("timestamp")) {
                        try {
                            revTime = DateUtils.parseDateTime(DateUtils.DATE_TIME_FORMAT_STRING1, JsonUtils.getStr(jobj, "timestamp"));
                        } catch (Exception ignored) {

                        }
                    }
                }

                if (StringUtils.isBlank(devIp)) {
                    JSONObject json = JsonUtils.parse(jsonStr);
                    devIp = JsonUtils.getStr(json, "dev_ip");
                    //String msgStr = JsonUtils.getStr(json, "message");
                }
                // 存es的索引名称使用topic
                /*
                 * 兼容日志没有写入topic信息的
                 */
                IpMappgingRule mappingData = EventRuleLoad.IpMapping.get(devIp);
                if (StringUtils.isNotBlank(topicName)) {
                    String key = String.format("%s_%s", topicName, devIp);
                    //根据ip+topic来确定解析类 有bug
                    IpMappgingRule mappingDataTmp = EventRuleLoad.IpTopicMapping.get(key);
                    if (mappingDataTmp != null)
                        mappingData = mappingDataTmp;
                }

                if (mappingData != null) {
                    String resolvClass = mappingData.getResolvClass();
                    ConcurrentHashMap<String,Object> retJson = null;
                    if ("ResolvHoneyLog".equalsIgnoreCase(resolvClass)) {
                        retJson = ResolvHoneyLog.parse(jsonStr);
                    } else if ("ResolvNtaSecLog".equalsIgnoreCase(resolvClass)) {
                        retJson = ResolvNtaSecLog.parse(jsonStr);
                    } else if ("ResolvNewSocLog".equals(resolvClass)) {
                        retJson = ResolvNewSocLog.parse(jsonStr);
                    } else if ("ResolvSipEvent".equalsIgnoreCase(resolvClass)) {
                        retJson = ResolvSipEvent.parse(jsonStr);
                    } else if ("ResolvLdapLog".equalsIgnoreCase(resolvClass)) {
                        retJson = ResolvLdapLog.parse(jsonStr);
                    } else if ("ReslovSangforWaf".equalsIgnoreCase(resolvClass)) {
                        retJson = ReslovSangforWaf.parse(jsonStr);
                    } else if ("ResolvQAXNI".equalsIgnoreCase(resolvClass)) {
                        retJson = ResolvQAXNI.parse(jsonStr);
                    } else if ("ResolvShanshiFirewallLog".equals(resolvClass)) {
                        retJson = ResolvShanshiFirewallLog.parse(jsonStr);
                    } else if ("ResolvAdLog".equalsIgnoreCase(resolvClass)) {
                        retJson = ResolvAdLog.parse(jsonStr);
                        if(retJson != null) {
                            retJson.put(LogConstants.LOG_PRODUCT, "AD");
                            retJson.remove(LogConstants.LOG_ORI_MSG);
                        }
                    } else if ("ResolvWinLog".equalsIgnoreCase(resolvClass)) {
                        retJson = ResolvWinLog.parse(jsonStr);
                    } else if ("ResolvLinuxSyslog".equalsIgnoreCase(resolvClass)) {
                        retJson = ResolvLinuxSyslog.parse(jsonStr);
                    } else if ("ResolvCtWafLog".equalsIgnoreCase(resolvClass)) {
                        retJson = ResolvCtWafLog.parse(jsonStr);
                    } else if ("ResolvAccessLog".equalsIgnoreCase(resolvClass)) {
                        retJson = ResolvAccessLog.parse(jsonStr);
                    } else if ("ResolvFirewallLog".equalsIgnoreCase(resolvClass)) {
                        if (!"F".equals(FlinkApplication.ALL_CONFIG.getFwfilter())) {
                            if (jsonStr.contains("web")) {

                            } else if (jsonStr.contains("POLICYPERMIT") || jsonStr.contains("POLICYDENY")) {
                                return null;
                            }
                        }
                        retJson = ResolvFirewallLog.parse(jsonStr);
                    } else if ("ResolvG01Log".equalsIgnoreCase(resolvClass)) {
                        retJson = ResolvG01Log.parse(jsonStr);
                    } else if ("ResolvIpsLog".equalsIgnoreCase(resolvClass)) {
                        retJson = ResolvIpsLog.parse(jsonStr);
                    } else if ("ResolvK01Log".equalsIgnoreCase(resolvClass)) {
                        retJson = ResolvK01Log.parse(jsonStr);
                    } else if ("ResolvLBLog".equalsIgnoreCase(resolvClass)) {
                        retJson = ResolvLBLog.parse(jsonStr);
                    } else if ("ResolvQingtengLog".equalsIgnoreCase(resolvClass)) {
                        retJson = ResolvQingtengLog.parse(jsonStr);
                    } else if ("ResolvSangforACLog".equalsIgnoreCase(resolvClass)) {
                        retJson = ResolvSangforACLog.parse(jsonStr);
                    } else if ("ResolvSsLVpnlog".equalsIgnoreCase(resolvClass)) {
                        retJson = ResolvSsLVpnlog.parse(jsonStr);
                    } else if ("ResolvSymantecLog".equalsIgnoreCase(resolvClass)) {
                        retJson = ResolvSymantecLog.parse(jsonStr);
                    } else if ("ResolvTqLog".equalsIgnoreCase(resolvClass)) {
                        retJson = ResolvTqLog.parse(jsonStr);
                    } else if ("ResolvTyLog".equalsIgnoreCase(resolvClass)) {
                        retJson = ResolvTyLog.parse(jsonStr);
                    } else if ("ResolvWafLog".equalsIgnoreCase(resolvClass)) {
                        retJson = ResolvWafLog.parse(jsonStr);
                    } else if ("ResolvWifiAccessLog".equalsIgnoreCase(resolvClass)) {
                        retJson = ResolvWifiAccessLog.parse(jsonStr);
                    } else if ("ResolvSSPXiaQiangLog".equals(resolvClass)) {
                        retJson = ResolvSSPXiaQiangLog.parse(jsonStr);
                    } else if ("ReslovH3CACLog".equals(resolvClass)) {
                        retJson = ReslovH3CACLog.parse(jsonStr);
                    } else if ("ResolvGuoceHoneyLog".equals(resolvClass)) {
                        retJson = ResolvGuoceHoneyLog.parse(jsonStr);
                    } else if ("ResolvQingtengTHPLog".equals(resolvClass)) {
                        retJson = ResolvQingtengTHPLog.parse(jsonStr);
                    } else if ("ResolvQAXFwLog".equals(resolvClass)) {
                        retJson = ResolvQAXFwLog.parse(jsonStr);
                    } else if ("ResolvQAXBljLog".equals(resolvClass)) {
                        retJson = ResolvQAXBljLog.parse(jsonStr);
                    } else if ("ResolvH3CFirewall".equals(resolvClass)) {
                        retJson = ResolvH3CFirewall.parse(jsonStr);
                    } else if ("ResolvHwAP".equals(resolvClass)) {
                        retJson = ResolvHwAP.parse(jsonStr);
                    } else if ("ResolvTerminalSafeLog".equals(resolvClass)) {
                        retJson = ResolvTerminalSafeLog.parse(jsonStr);
                    } else if ("ResolvSxfFirewallLog".equals(resolvClass)) {
                        retJson = ResolvSxfFirewallLog.parse(jsonStr);
                    } else if ("ResolvSsFirewallLog".equals(resolvClass)) {
                        retJson = ResolvSsFirewallLog.parse(jsonStr);
                    } else if ("ResolvLMFirewallLog".equals(resolvClass)) {
                        retJson = ResolvLMFirewallLog.parse(jsonStr);
                    } else if ("ResolvLinkLoadBalancingLog".equals(resolvClass)) {
                        retJson = ResolvLinkLoadBalancingLog.parse(jsonStr);
                    } else if ("ResolvInternetBehaviorLog".equals(resolvClass)) {
                        retJson = ResolvInternetBehaviorLog.parse(jsonStr);
                    } else if ("ResolvFeiTaFirewallLog".equals(resolvClass)) {
                        retJson = ResolvFeiTaFirewallLog.parse(jsonStr);
                    } else if ("ResolvSbrLog".equals(resolvClass)) {
                        retJson = ResolvSbrLog.parse(jsonStr);
                        //从日志接收器获取日志，特殊处理--何景生
                        if (retJson == null || retJson.size() < 1) {
                            retJson = JsonUtils.createBaseMap(jsonStr);
                        }
                        if (!retJson.containsKey(LogConstants.LOG_PRODUCT))
                            retJson.put(LogConstants.LOG_PRODUCT, mappingData.getProduct());
                        if (!retJson.containsKey("es_index"))
                            retJson.put("es_index", mappingData.getTopic());
                        retJson.put(LogConstants.LOG_DEV_IP, devIp);
                        if (revTime != null) {
                            retJson.put("log_rev_time", DateUtils.getSparkTime(revTime));
                        }
                        return retJson;
                    } else if ("ResolvQmxcIpsLog".equals(resolvClass)) {
                        retJson = ResolvQmxcIpsLog.parse(jsonStr);
                    } else if ("ResolvQmxcAdsLog".equals(resolvClass)) {
                        retJson = ResolvQmxcAdsLog.parse(jsonStr);
                    } else if ("ResolvKafkaLog".equals(resolvClass)) {
                        devIp = HryhKafkaConstants.getHrynKafkaDevIp(jsonStr);
                        if (devIp == null) {
                            return null;
                        }
                        retJson = ResolvKafkaLog.parse(jsonStr);
                        MapUtils.setStr(retJson, LogConstants.LOG_DEV_IP, devIp);
                    } else if ("ReslovAuditSysLog".equals(resolvClass)) {
                        retJson = ReslovAuditSysLog.parse(jsonStr);
                    } else if ("ReslovMicrosoftATALog".equals(resolvClass)) {
                        retJson = ReslovMicrosoftATALog.parse(jsonStr);
                    } else if ("ResolvQimingSqlLog".equals(resolvClass)) {
                        retJson = ResolvQimingSqlLog.parse(jsonStr);
                    } else if ("ResolvHuaweiASGFirewallLog".equals(resolvClass)) {
                        retJson = ResolvHuaweiASGFirewallLog.parse(jsonStr);
                    } else if ("ResolvWeiDaHoneypotLog".equals(resolvClass)) {
                        retJson = ResolvWeiDaHoneypotLog.parse(jsonStr);
                    } else if ("ResolvYingGaoAdmittanceLog".equals(resolvClass)) {
                        retJson = ResolvYingGaoAdmittanceLog.parse(jsonStr);
                    } else if ("ResolvTrxEDRLog".equals(resolvClass)) {
                        retJson = ResolvTrxEDRLog.parse(jsonStr);
                    } else if ("ResolvQianxinVPNLog".equals(resolvClass)) {
                        retJson = ResolvQianxinVPNLog.parse(jsonStr);
                    } else if ("ResolvCiscoASAFirewallLog".equals(resolvClass)) {
                        retJson = ResolvCiscoASAFirewallLog.parse(jsonStr);
                    } else if ("ResolvDongRuanFirewallLog".equals(resolvClass)) {
                        retJson = ResolvDongRuanFirewallLog.parse(jsonStr);
                    } else if ("Resolv360TerminalSafeLog".equalsIgnoreCase(resolvClass)) {
                        retJson = Resolv360TerminalSafeLog.parse(jsonStr);
                    } else if ("ResolvYaXinSafeLog".equals(resolvClass)) {
                        retJson = ResolvYaXinSafeLog.parse(jsonStr);
                    } else if ("ResolvHuiDunUESLog".equalsIgnoreCase(resolvClass)) {
                        retJson = ResolvHuiDunUESLog.parse(jsonStr);
                    } else if ("ResolvH3CLog".equalsIgnoreCase(resolvClass)) {
                        retJson = ResolvH3CLog.parse(jsonStr);
                    } else if ("ResolvBAMVLog".equals(resolvClass)) {
                        retJson = ResolvBAMVLog.parse(jsonStr);
                    } else if ("ResolvYaXInTDALog".equals(resolvClass)) {
                        retJson = ResolvYaXInTDALog.parse(jsonStr);
                    } else if ("ResolvWeiBuTDPLog".equals(resolvClass)) {
                        retJson = ResolvWeiBuTDPLog.parse(jsonStr);
                    } else if ("ResolvHostProtectiveSyslog".equals(resolvClass)) {
                        retJson = ResolvHostProtectiveSyslog.parse(jsonStr);
                    } else if ("ResolvIndustrialFirewallLog".equals(resolvClass)) {
                        retJson = ResolvIndustrialFirewallLog.parse(jsonStr);
                    } else if ("ResolvMailGateLog".equals(resolvClass)) {
                        retJson = ResolvMailGateLog.parse(jsonStr);
                    } else if ("ResolvTSALog".equals(resolvClass)) {
                        retJson = ResolvTSALog.parse(jsonStr);
                    } else if ("ResolvAnHengAPTLog".equals(resolvClass)) {
                        retJson = ResolvAnHengAPTLog.parse(jsonStr);
                    } else if ("ResolvLvMengWafLog".equals(resolvClass)) {
                        retJson = ResolvLvMengWafLog.parse(jsonStr);
                    } else if ("ResolvLMTACSyslog".equals(resolvClass)) {
                        retJson = ResolvLMTACSyslog.parse(jsonStr);
                    } else if ("ResolvSFHCISyslog".equals(resolvClass)) {
                        retJson = ResolvSFHCISyslog.parse(jsonStr);
                    } else if ("ResolvAnWafAPTLog".equals(resolvClass)) {
                        retJson = ResolvAnWafAPTLog.parse(jsonStr);
                    } else if ("ResolvAnGyAPTLog".equals(resolvClass)) {
                        retJson = ResolvAnGyAPTLog.parse(jsonStr);
                    } else if ("ResolvQtFcLog".equals(resolvClass)) {
                        retJson = ResolvQtFcLog.parse(jsonStr);
                    } else if ("ResolvQAXTerminalSafeLog".equals(resolvClass)) {
                        retJson = ResolvQAXTerminalSafeLog.parse(jsonStr);
                    } else if ("ResolvLvMengNTALog".equals(resolvClass)) {
                        retJson = ResolvLvMengNTALog.parse(jsonStr);
                    } else if ("ResolvLvMengNIPSLog".equals(resolvClass)) {
                        retJson = ResolvLvMengNIPSLog.parse(jsonStr);
                    } else if ("ResolvSZNTASyslog".equals(resolvClass)) {
                        retJson = ResolvSZNTASyslog.parse(jsonStr);
                    } else if ("ReslovNxlogSysLog".equalsIgnoreCase(resolvClass)) {
                        retJson = ReslovNxlogSysLog.parse(jsonStr);
                    } else if ("ResolvRuanLianSafeLog".equals(resolvClass)) {
                        retJson = ResolvRuanLianSafeLog.parse(jsonStr);
                    } else if ("ResolvAnHengDASLog".equals(resolvClass)) {
                        retJson = ResolvAnHengDASLog.parse(jsonStr);
                    } else if ("ResolvQZBLJSyslog".equals(resolvClass)) {
                        retJson = ResolvQZBLJSyslog.parse(jsonStr);
                    } else if ("ResolvQingTengHIDSLog".equals(resolvClass)) {
                        retJson = ResolvQingTengHIDSLog.parse(jsonStr);
                    } else if ("ResolvRunaLianLog".equals(resolvClass)) {
                        retJson = ResolvRunaLianLog.parse(jsonStr);
                    }
                    if ("T".equals(FlinkApplication.ALL_CONFIG.getDebug())) {
                        if (retJson == null || retJson.size() < 1) {
                            log.error(resolvClass + " " + topicName + " @@@ " + "空日志!!!!!!");
                        } else {
                            log.info(resolvClass + " " + topicName + " #####- > " + JSON.toJSON(retJson));
                        }
                    }
                    if (retJson == null || retJson.size() < 1) {
                        retJson = JsonUtils.createBaseMap(jsonStr);
                    }
                    if (StringUtils.isNotBlank(devIp))
                        retJson.put(LogConstants.LOG_DEV_IP, IPUtil.getIpsX(devIp));
                    retJson.put(LogConstants.LOG_PRODUCT, mappingData.getProduct());
                    if (jsonStr.contains("crc_attr") && jsonStr.contains("xiaqiang")) {
                        MapUtils.setStr(retJson, LogConstants.LOG_PRODUCT, "深信服XQ");
                    }
                    retJson.put("es_index", mappingData.getTopic());
                    if (revTime != null) {
                        retJson.put("log_rev_time", DateUtils.getSparkTime(revTime));
                    }
                    return retJson;
                }
            }
        } catch (Exception e) {
            log.error(e.getMessage(), e);
        }
        return new ConcurrentHashMap<>();
    }
}
