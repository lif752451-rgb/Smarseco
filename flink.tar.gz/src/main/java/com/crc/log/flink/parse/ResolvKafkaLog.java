package com.crc.log.flink.parse;

import com.crc.log.flink.common.constants.HryhKafkaConstants;
import com.crc.log.flink.common.constants.LevelConstants;
import com.crc.log.flink.common.constants.LogConstants;
import com.crc.log.flink.common.utils.DataUtils;
import com.crc.log.flink.common.utils.JsonUtils;
import com.crc.log.flink.common.utils.MapUtils;
import org.apache.commons.lang3.StringUtils;

import java.util.concurrent.ConcurrentHashMap;

/**
 * @author jixiangqi
 * @date 2021/12/13
 */
public class ResolvKafkaLog {
    public static ConcurrentHashMap<String,Object> parse(String message) {
        try {
            ConcurrentHashMap<String,Object> data = proc(message);
            if (DataUtils.isNotEmptyJson(data)) {
                return data;
            }
        } catch (Exception ignored) {

        }
        return null;
    }

    private static ConcurrentHashMap<String,Object> proc(String jsonStr) {
        ConcurrentHashMap<String,Object> rtnObjc = JsonUtils.createBaseMap(jsonStr);
        String devIp = HryhKafkaConstants.getHrynKafkaDevIp(jsonStr);
        MapUtils.setStr(rtnObjc, LogConstants.LOG_DEV_IP, devIp);
        if (StringUtils.isNotBlank(jsonStr)) {
            //正则表达式抽取字段

            MapUtils.setStr(rtnObjc, LogConstants.ALERT_NAME, jsonStr);
            rtnObjc.put(LogConstants.LOG_LEVEL, LevelConstants.getLevel(MapUtils.getStr(rtnObjc,LogConstants.LOG_LEVEL)));
            if (StringUtils.isBlank(MapUtils.getStr(rtnObjc, LogConstants.SRC_IP))) {
                rtnObjc.put(LogConstants.SRC_IP, "0.0.0.0");
            }
            if (StringUtils.isBlank(MapUtils.getStr(rtnObjc, LogConstants.DEST_IP))) {
                rtnObjc.put(LogConstants.DEST_IP, "0.0.0.0");
            }
        }

        return rtnObjc;
    }

}
