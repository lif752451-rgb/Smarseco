package com.crc.log.flink.parse;

import com.crc.log.flink.common.constants.LevelConstants;
import com.crc.log.flink.common.constants.LogConstants;
import com.crc.log.flink.common.utils.DataUtils;
import com.crc.log.flink.common.utils.IPUtil;
import com.crc.log.flink.common.utils.JsonUtils;
import com.crc.log.flink.common.utils.MapUtils;
import org.apache.commons.lang3.StringUtils;

import java.util.List;
import java.util.concurrent.ConcurrentHashMap;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * @author jixiangqi
 * @date 2022/1/17
 * 思科防火墙
 */
public class ResolvCiscoASAFirewallLog {
    public static ConcurrentHashMap<String, Object> parse(String message) {
        try {
            ConcurrentHashMap<String, Object> data = proc(message);
            if (DataUtils.isNotEmptyJson(data)) {
                return data;
            }
        } catch (Exception ignored) {

        }
        return null;
    }

    private static ConcurrentHashMap<String, Object> proc(String jsonStr) {
        ConcurrentHashMap<String, Object> rtnObjc = JsonUtils.createBaseMap(jsonStr);
        if (jsonStr.contains("outside") && !jsonStr.contains("from")) {
            List<String> ips = IPUtil.getIpFromStr(jsonStr);
            if (ips.size() == 2) {
                rtnObjc.put(LogConstants.SRC_IP, ips.get(0));
                rtnObjc.put(LogConstants.DEST_IP, ips.get(1));
            } else if (ips.size() == 1) {
                String[] split = DataUtils.getSplit(jsonStr, ips.get(0));
                if (split.length > 0) {
                    String temp = split[0];
                    if (temp.contains("src") && !temp.contains("dst")) {
                        rtnObjc.put(LogConstants.SRC_IP, ips.get(0));
                    } else if (temp.contains("src") && temp.contains("dst")) {
                        rtnObjc.put(LogConstants.DEST_IP, ips.get(0));
                    }
                }
            }
        } else if (jsonStr.contains("from") && jsonStr.contains("to")) {
            int index = DataUtils.getIndex(jsonStr, "from");
            String temp = "";
            if (index != -1) {
                temp = DataUtils.getSubString(jsonStr, index + "from".length() + 1);
            }
            index = DataUtils.getIndex(temp, " ");
            String src = DataUtils.getSubString(temp, 0 ,index);
            if (StringUtils.isNotBlank(src) && src.contains("/")) {
                String[] split = src.split("/");
                if (split.length == 2) {
                    if (IPUtil.isIp(split[0])) {
                        rtnObjc.put(LogConstants.SRC_IP, split[0]);
                    }
                    if (isPureDigital(split[1].trim())) {
                        rtnObjc.put(LogConstants.SRC_PORT, split[1]);
                    }
                }
            }
            index = DataUtils.getIndex(temp, "to");
            if (index != -1) {
                temp = DataUtils.getSubString(temp, index + "to".length() + 1);
            }
            String dest = "";
            if (StringUtils.isNotBlank(temp)) {
                if (temp.contains(" ")) {
                    index = DataUtils.getIndex(temp, " ");
                    dest = DataUtils.getSubString(temp, 0, index);
                } else {
                    dest = temp;
                }
                if (StringUtils.isNotBlank(dest) && dest.contains("/")) {
                    String[] split = DataUtils.getSplit(dest, "/");
                    if (split.length == 2) {
                        if (IPUtil.isIp(split[0])) {
                            rtnObjc.put(LogConstants.DEST_IP, split[0]);
                        }
                        if (isPureDigital(split[1].trim())) {
                            rtnObjc.put(LogConstants.DEST_PORT, split[1].trim());
                        }
                    }
                }
            }
        }
        if (jsonStr.contains("inbound") || jsonStr.contains("Inbound")) {
            int index = DataUtils.getIndex(jsonStr, "inbound");
            if (index < 0) {
                index = DataUtils.getIndex(jsonStr, "Inbound");
            }
            String temp = DataUtils.getSubString(jsonStr, index + "inbound".length() + 1);
            if (StringUtils.isNotBlank(temp)) {
                index = DataUtils.getIndex(temp, " ");
                String proto = DataUtils.getSubString(temp, 0, index);
                rtnObjc.put(LogConstants.LOG_PROTOCAL, proto);
            }
        }
        if (jsonStr.contains("protocol")) {
            int index = DataUtils.getIndex(jsonStr, "protocol");
            jsonStr = DataUtils.getSubString(jsonStr, index + "protocol".length() + 1);
                    //jsonStr.substring(index + "protocol".length() + 1);
            index = DataUtils.getIndex(jsonStr, " ");
                    //jsonStr.indexOf(" ");
            String proto = DataUtils.getSubString(jsonStr, 0, index);
                    //jsonStr.substring(0, index);
            rtnObjc.put(LogConstants.LOG_PROTOCAL, proto);
        }
        rtnObjc.put(LogConstants.LOG_PRODUCT, "思科防火墙");
        rtnObjc.put(LogConstants.LOG_LEVEL, LevelConstants.getLevel(MapUtils.getStr(rtnObjc,LogConstants.LOG_LEVEL)));
        if (StringUtils.isBlank(MapUtils.getStr(rtnObjc, LogConstants.SRC_IP))) {
            rtnObjc.put(LogConstants.SRC_IP, "0.0.0.0");
        }
        if (StringUtils.isBlank(MapUtils.getStr(rtnObjc, LogConstants.DEST_IP))) {
            rtnObjc.put(LogConstants.DEST_IP, "0.0.0.0");
        }
        setAlertName(rtnObjc);
        return rtnObjc;
    }

    public static boolean isPureDigital(String str) {
        if (str == null || "".equals(str)){
            return false;
        }
        Pattern p;
        Matcher m;
        p = Pattern.compile("[0-9]*");
        m = p.matcher(str);
        return m.matches();
    }

    private static void setAlertName(ConcurrentHashMap<String, Object> rtnObjc) {
        String msgFormat = "IP地址为:%s对IP地址为:%s,产生了一个访问，访问协议为:%s,日志详情为:%s";
        String srcIp = MapUtils.getStr(rtnObjc, LogConstants.SRC_IP);
        String destIp = MapUtils.getStr(rtnObjc, LogConstants.DEST_IP);
        String proto = MapUtils.getStr(rtnObjc, LogConstants.LOG_PROTOCAL);
        String log = MapUtils.getStr(rtnObjc, LogConstants.LOG_ORI_MSG);
        String alertName = String.format(msgFormat, srcIp, destIp, proto, log);
        rtnObjc.put(LogConstants.ALERT_NAME, alertName);
    }
}
