package com.crc.log.flink.test;

import com.alibaba.fastjson.JSONObject;

public class DataSpTest {
    public static void main(String[] args) {
        JSONObject jsonObject = new JSONObject();
        jsonObject.put("1", "1");
        jsonObject.put("3", "3");
        jsonObject.put("2", "2");
        jsonObject.put("4", "4");
        jsonObject.put("5", "5");
        System.out.println(jsonObject);
    }
}
