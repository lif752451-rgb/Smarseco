package com.crc.log.flink.common.utils;

import org.apache.commons.lang3.StringUtils;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.net.HttpURLConnection;
import java.net.URL;

/**
 * 通用http发送方法
 *
 * @author ruoyi
 */
public class HttpUtils {
    private static final int CONN_TIME_OUT = 5000;
    private static final int READ_TIME_OUT = 5000;

    /**
     * @param urlPath 对方地址
     * @param json    要传送的数据
     * @return
     */
    public static String sendPost(String urlPath, String json) {
        OutputStreamWriter out = null;
        BufferedReader in = null;
        StringBuilder result = new StringBuilder();
        HttpURLConnection urlConnection = null;
        try {
            URL url = new URL(urlPath);
            urlConnection = (HttpURLConnection) url.openConnection();
            // 设置doOutput属性为true表示将使用此urlConnection写入数据
            urlConnection.setDoOutput(true);
            // 定义待写入数据的内容类型，我们设置为application/x-www-form-urlencoded类型
            urlConnection.setRequestProperty("content-type", "application/json");
            urlConnection.setConnectTimeout(CONN_TIME_OUT);
            urlConnection.setReadTimeout(READ_TIME_OUT);
            // 得到请求的输出流对象
            out = new OutputStreamWriter(urlConnection.getOutputStream());
            // 把数据写入请求的Body
            if (StringUtils.isNotBlank(json))
                out.write(json);
            out.flush();
            // 定义BufferedReader输入流来读取URL的响应
            in = new BufferedReader(new InputStreamReader(urlConnection.getInputStream()));
            String line;
            while ((line = in.readLine()) != null) {
                result.append(line);
            }
        } catch (Exception e) {
            return "";
        }
        // 使用finally块来关闭输出流、输入流
        finally {
            try {
                if (in != null) {
                    in.close();
                }
            } catch (Exception ignored) {

            }
            try {
                if (out != null) {
                    out.close();
                }
            } catch (Exception ignored) {

            }
            try {
                if(urlConnection != null) {
                    urlConnection.disconnect();
                }
            } catch (Exception ignored) {

            }
        }
        return result.toString();
    }

}
