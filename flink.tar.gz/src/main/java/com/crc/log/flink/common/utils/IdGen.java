/**
 * Copyright &copy; 2012-2016 <a href="https://github.com/thinkgem/jeesite">JeeSite</a> All rights reserved.
 */
package com.crc.log.flink.common.utils;


import java.security.SecureRandom;
import java.text.Format;
import java.text.SimpleDateFormat;
import java.util.Calendar;

public class IdGen {

    /**
     * This Format for format the data to special format.
     */
    private final static Format dateFormat = new SimpleDateFormat("yyyyMMddHHmmssSSS");

    /**
     * 时间格式生成序列
     *
     * @return String
     */
    private static synchronized String generateSequenceNo() {

        Calendar rightNow = Calendar.getInstance();
        return dateFormat.format(rightNow.getTime());
    }

    /**
     * 封装JDK自带的UUID, 通过Random数字生成, 中间无-分割.
     */
    public static String uuid() {
        return generateSequenceNo()+String.format("%06d",new SecureRandom().nextInt(1000000));
    }
}
