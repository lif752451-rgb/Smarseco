package com.crc.log.flink.parse;

import com.alibaba.fastjson.JSONObject;
import com.crc.log.flink.common.constants.LevelConstants;
import com.crc.log.flink.common.constants.LogConstants;
import com.crc.log.flink.common.utils.DataUtils;
import com.crc.log.flink.common.utils.DateUtils;
import com.crc.log.flink.common.utils.JsonUtils;
import com.crc.log.flink.common.utils.MapUtils;
import org.apache.commons.lang3.StringUtils;

import java.util.concurrent.ConcurrentHashMap;

/**
 * LDAP日志格式化
 */
@SuppressWarnings("unchecked")
public class ResolvLdapLog {
    /**
     * ldap日志泛化
     */
    public static ConcurrentHashMap<String,Object> parse(String message) {
        try {
            ConcurrentHashMap<String,Object>  data = proc(message);
            if (DataUtils.isNotEmptyJson(data)) {
                return data;
            }
        } catch (Exception ignored) {

        }
        return null;
    }

    private static ConcurrentHashMap<String,Object>  proc(String value) {
        ConcurrentHashMap<String,Object>  ldapJson = JsonUtils.createBaseMap(value);
        try {
            JSONObject logObj = JsonUtils.parse(value);
            if (!logObj.isEmpty()) {
                String message = logObj.getString("message");
                String[] messageArr = DataUtils.getSplit(message, ",");
                        //message.split(",");
                MapUtils.setStr(ldapJson, LogConstants.LOG_PRODUCT, "LDAP");
                MapUtils.setStr(ldapJson, LogConstants.OP_NAME, DataUtils.getArrayString(messageArr, 1));
                //05/26/2020 09:25:01
                MapUtils.setStr(ldapJson, LogConstants.LOG_START_TIME, DateUtils.getISO8601Timestamp2(DataUtils.getArrayString(messageArr, 2), "MM/dd/yyyy HH:mm:ss"));
                MapUtils.setStr(ldapJson, LogConstants.SRC_IP, DataUtils.getArrayString(messageArr, 3));
                MapUtils.setStr(ldapJson, LogConstants.ACTION_TYPE, "登录验证");
                String result = DataUtils.getArrayString(messageArr, 5);
                String actionResult = "Y".equalsIgnoreCase(result) ? "成功" : ("N".equalsIgnoreCase(result) ? "失败" : "未知");
                MapUtils.setStr(ldapJson, LogConstants.ACTION_RESULT, actionResult);

                MapUtils.setStr(ldapJson, LogConstants.LOG_LEVEL, LevelConstants.INFO);
                MapUtils.setStr(ldapJson, LogConstants.ASSET_OFFICE, "润联科技");
                MapUtils.setStr(ldapJson, LogConstants.SRC_INSTANCE, "LDAP");
            }
            if (StringUtils.isBlank(MapUtils.getStr(ldapJson, LogConstants.SRC_IP))) {
                ldapJson.put(LogConstants.SRC_IP, "0.0.0.0");
            }
            if (StringUtils.isBlank(MapUtils.getStr(ldapJson, LogConstants.DEST_IP))) {
                ldapJson.put(LogConstants.DEST_IP, "0.0.0.0");
            }
            setAlertName(ldapJson);
            return ldapJson;
        } catch (Exception e) {
            System.err.println(e.getMessage());
            return ldapJson;
        }
    }

    private static void setAlertName(ConcurrentHashMap<String,Object>  rtnObjc) {
        String msgFormat = "源IP地址为:%s,操作类型:%s,操作结果:%s,日志详情为:%s";
        String srcIp = MapUtils.getStr(rtnObjc, LogConstants.SRC_IP);
        String result = MapUtils.getStr(rtnObjc, LogConstants.ACTION_RESULT);
        String type = MapUtils.getStr(rtnObjc, LogConstants.ACTION_TYPE);
        String log = MapUtils.getStr(rtnObjc, LogConstants.LOG_ORI_MSG);
        String alertName = String.format(msgFormat, srcIp, type, result, log);

        rtnObjc.put(LogConstants.ALERT_NAME, alertName);
    }

}
