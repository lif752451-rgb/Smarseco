package com.crc.log.flink.parse;

import com.alibaba.fastjson.JSONObject;
import com.crc.log.flink.common.constants.LevelConstants;
import com.crc.log.flink.common.constants.LogConstants;
import com.crc.log.flink.common.utils.DataUtils;
import com.crc.log.flink.common.utils.JsonUtils;
import com.crc.log.flink.common.utils.MapUtils;
import org.apache.commons.lang3.StringUtils;

import java.util.concurrent.ConcurrentHashMap;

/**
 * 华为无线AP
 */
public class ResolvHwAP {
    /**
     * 通用日志 日志泛化
     */
    public static ConcurrentHashMap<String,Object> parse(String message) {
        try {
            ConcurrentHashMap<String,Object> data = proc(message);
            if (DataUtils.isNotEmptyJson(data)) {
                return data;
            }
        } catch (Exception ignored) {

        }
        return null;
    }

    private static ConcurrentHashMap<String,Object> proc(String jsonStr) {
        ConcurrentHashMap<String,Object> rtnObjc = JsonUtils.createBaseMap(jsonStr);
        JSONObject json = getMsgContent(jsonStr);

        rtnObjc.put(LogConstants.SRC_IP, JsonUtils.getStr(json, "RDSIP"));
        rtnObjc.put(LogConstants.LOG_PROTOCAL, JsonUtils.getStr(json, "ACCESS TYPE"));
        rtnObjc.put(LogConstants.ACTION_RESULT, JsonUtils.getStr(json, "RESULT"));
        rtnObjc.put(LogConstants.OP_NAME, JsonUtils.getStr(json, "USER"));
        rtnObjc.put(LogConstants.SRC_MAC, JsonUtils.getStr(json, "MAC"));
        rtnObjc.put(LogConstants.HOST_NAME, JsonUtils.getStr(json, "APNAME"));
        rtnObjc.put(LogConstants.LOG_PRODUCT, "华为无线AP");
        
        rtnObjc.put(LogConstants.LOG_LEVEL, LevelConstants.getLevel(MapUtils.getStr(rtnObjc,LogConstants.LOG_LEVEL)));
        if (StringUtils.isBlank(MapUtils.getStr(rtnObjc, LogConstants.SRC_IP))) {
            rtnObjc.put(LogConstants.SRC_IP, "0.0.0.0");
        }
        if (StringUtils.isBlank(MapUtils.getStr(rtnObjc, LogConstants.DEST_IP))) {
            rtnObjc.put(LogConstants.DEST_IP, "0.0.0.0");
        }
        setAlertName(rtnObjc);
        return rtnObjc;
    }

    /**
     * <189>Oct 08 2021 15:26:01.970.1+00:00 HZ-ZZ-AC9700M %%01CM/5/USER_ACCESSRESULT(s)[1]:[WLAN_STA_INFO_AUTHENTICATION]ACMAC:a4-16-e7-65-d1-f5;ACNAME:HZ-ZZ-AC9700M;APMAC:50-46-4a-e2-bc-70;APNAME:新时代项目部01;SSID:CRL-Staff;RADIOID:1;USER:host/ZZ-B-qiaokai10.crland.hk;MAC:f0-9e-4a-33-9f-64;IPADDRESS:-;TIME:1633706761;ZONE:UTC-0000;DAYLIGHT:false;ERRCODE:0;RESULT:success;USERGROUP:NULL;AUTHENPLACE:RADIUS;CIB ID:344115;INTERFACE:Wlan-Dbss17499;ACCESS TYPE:802.1x;VLAN:40;SelectRDSIP:-;SelectERRCODE:-;RDSIP:10.7.128.46;Portal TYPE:-;AUTHID=2642956645;AuthFailType:None;
     *
     * @param msg
     * @return
     */
    public static JSONObject getMsgContent(String msg) {
        JSONObject json = new JSONObject();
        try {
            msg = msg.replace("\"", "");
            for (String x : DataUtils.getSplit(msg, ";")) {
                try {
                    String[] m = DataUtils.getSplit2(x, ":");
                            //x.split(":");
                    json.put(m[0].trim(), m[1].trim());
                } catch (Exception e) {
                }
            }
        } catch (Exception e) {
        }

        return json;
    }

    private static void setAlertName(ConcurrentHashMap<String,Object> rtnObjc) {
        String hostName = MapUtils.getStr(rtnObjc, LogConstants.HOST_NAME);
        String result = MapUtils.getStr(rtnObjc, LogConstants.ACTION_RESULT);
        String log = MapUtils.getStr(rtnObjc, LogConstants.LOG_ORI_MSG);
        String msgFormat = "主机名称:%s,操作结果:%s,日志详情为:%s";
        String alertName = String.format(msgFormat, hostName, result, log);
        rtnObjc.put(LogConstants.ALERT_NAME, alertName);
    }
}
