#!/bin/bash

cd /app/smartseco/back/flink/sec
nohup java  -Xms4096m -Xmx4096m -Dloader.path=/app/smartseco/back/flink/sec/lib -jar /app/smartseco/back/flink/sec/out-flink-1.0.0.jar --spring.config.location=/app/smartseco/back/flink/sec/config/application.properties --logging.config=/app/smartseco/back/flink/sec/config/log4j2.xml  &