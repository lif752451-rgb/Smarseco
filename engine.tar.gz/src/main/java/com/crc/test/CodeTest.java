package com.crc.test;

import com.crc.common.utils.CodeTool;

import java.nio.charset.StandardCharsets;
import java.util.Base64;

public class CodeTest {
    public static void main(String[] args) {
        System.out.println(CodeTool.encrypt("IpTFX6FjYs5zKDG8gjKFh7kTgCFdWWJE"));
        Base64.Encoder encoder = Base64.getEncoder();
        String userName = "anquanke";
        String passwd = "aqk$1234";
        String str = userName + ":" + passwd;
        byte[] data = encoder.encode(str.getBytes());
        String token = "Basic " + new String(data);
        System.out.println(token);

        String authHeader = new sun.misc.BASE64Encoder().encode(str.getBytes(StandardCharsets.UTF_8));
        token = "Basic " + authHeader;
        System.out.println(token);

    }
}
