package com.crc.test;

import com.crc.common.utils.JsonUtils;
import com.crc.secface.argo.AlarmUtils;
import com.crc.secface.argo.JsonArgo;
import com.crc.secface.entity.TbEventModel;

public class JsonArgoTest {
    public static void main(String[] args) {
        String jsonStr = "{\n" +
                "    \"dev_ip_type\": \"内网\",\n" +
                "    \"principle\": \"此情报由深信服威胁情报中心(https://wiki.sec.sangfor.com.cn/analysis-platform)提供，主要来源于深信服安全设备的流量与日志、云沙箱病毒分析结果、天眼开源情报采集系统以及商业合作与购买的外部情报，并由安全专家通过数据分析，计算引擎过滤与鉴定等方法，获得诸如僵尸网络C2域名、恶意链接URL、攻击者IP、APT组织行为等各种战术情报与事件情报， 从而帮助用户进行威胁举证、处置与查杀的闭环操作。如果组织单位的内网主机存在主动访问这些情报的行为，则说明主机正在与黑客通信，存在失陷可能，请尽快处置。\",\n" +
                "    \"src_ip_type\": \"内网\",\n" +
                "    \"action_type\": \"有害程序事件\",\n" +
                "    \"event_description\": \"主机访问malware家族通信域名\",\n" +
                "    \"log_stage\": \"C&C 通信\",\n" +
                "    \"dev_asset_office\": \"润联科技\",\n" +
                "    \"dev_instance\": \"IT技术服务部_态势感知\",\n" +
                "    \"dev_dns\": \"0\",\n" +
                "    \"ip_score\": 2,\n" +
                "    \"src_ip\": \"172.16.3.25\",\n" +
                "    \"log_start_time\": \"2021-12-01T16:16:47.000+0800\",\n" +
                "    \"event_type\": \"有害程序事件\",\n" +
                "    \"dev_dmz\": \"1\",\n" +
                "    \"solution\": \"1、深信服为广大用户免费提供查杀工具，可下载如下工具，进行检测查杀。\\n64位系统下载链接：http://edr.sangfor.com.cn/tool/SfabAntiBot_X64.7z\\n32位系统下载链接：http://edr.sangfor.com.cn/tool/SfabAntiBot_X86.7z\\n2、深信服EDR产品、下一代防火墙及安全感知平台等安全产品均具备病毒检测能力，部署相关产品用户可进行病毒检测。\\n3、深信服EDR产品、下一代防火墙及安全感知平台的用户建议开启接入安全云脑服务，即可第一时间更新相关流行病毒规则，有效拦截各类流行病毒。\",\n" +
                "    \"dev_branch\": \"汕尾数据中心\",\n" +
                "    \"zlog_ori_msg\": \"<14>2021-12-01 22:32:23|!secevent|!10.0.7.180|!{\\\"dealStatus\\\": 0, \\\"firstTime\\\": 1638346607, \\\"msg_type\\\": \\\"有害程序事件\\\", \\\"scan_time\\\": \\\"\\\", \\\"ip\\\": \\\"10.54.18.210\\\", \\\"tampered_url\\\": \\\"\\\", \\\"hostRisk\\\": \\\"10.54.18.210(上梅林职场)\\\", \\\"eventKey\\\": \\\"sec_iocdetect|145000001\\\", \\\"password_autofill\\\": \\\"\\\", \\\"tag\\\": [\\\"malware\\\", \\\"僵尸网络\\\"], \\\"detectEngine\\\": \\\"威胁情报检测引擎\\\", \\\"threat_level\\\": 2, \\\"dst_mac_addr\\\": \\\"\\\", \\\"vulnerability_description\\\": \\\"\\\", \\\"scan_success\\\": \\\"\\\", \\\"src_port\\\": \\\"\\\", \\\"branchId\\\": \\\"438\\\", \\\"src_mac_addr\\\": \\\"\\\", \\\"directory_browsing\\\": \\\"\\\", \\\"domain_name\\\": \\\"\\\", \\\"rsp_email\\\": \\\"\\\", \\\"src_ip\\\": \\\"10.54.18.210\\\", \\\"event_evidence\\\": \\\"主机访问域名：<a class='btnDetail' btncon='<div class=\\\\\\\"viewLog\\\\\\\" param={\\\\\\\"suspicious_domain_ip\\\\\\\":\\\\\\\"polling.burpcollaborator.net\\\\\\\"}>日志详情</div>'>polling.burpcollaborator.net</a> 777次，其中控制者IP（TOP3）：<a class='btnDetail' btncon='<div class=\\\\\\\"viewLog\\\\\\\" param={\\\\\\\"suspicious_domain_ip\\\\\\\":\\\\\\\"127.0.0.1\\\\\\\"}>日志详情</div>'>127.0.0.1</a>（-）；\\\", \\\"attachment\\\": \\\"\\\", \\\"eventType\\\": 0, \\\"recordDate\\\": 20211201, \\\"classify_id\\\": \\\"\\\", \\\"hostName\\\": \\\"\\\", \\\"phishing_link\\\": \\\"\\\", \\\"ruleId\\\": \\\"145000001\\\", \\\"attack_time\\\": \\\"\\\", \\\"attack_count\\\": \\\"\\\", \\\"suspect_level\\\": 3, \\\"branch_name\\\": \\\"上梅林职场\\\", \\\"msg_sub_type\\\": \\\"僵尸网络事件\\\", \\\"downstream_traffic\\\": \\\"\\\", \\\"data_collection_size\\\": \\\"\\\", \\\"dst_ip\\\": \\\"0.0.0.0\\\", \\\"log_time\\\": 1638352943, \\\"principle\\\": \\\"此情报由深信服威胁情报中心(https://wiki.sec.sangfor.com.cn/analysis-platform)提供，主要来源于深信服安全设备的流量与日志、云沙箱病毒分析结果、天眼开源情报采集系统以及商业合作与购买的外部情报，并由安全专家通过数据分析，计算引擎过滤与鉴定等方法，获得诸如僵尸网络C2域名、恶意链接URL、攻击者IP、APT组织行为等各种战术情报与事件情报， 从而帮助用户进行威胁举证、处置与查杀的闭环操作。如果组织单位的内网主机存在主动访问这些情报的行为，则说明主机正在与黑客通信，存在失陷可能，请尽快处置。\\\", \\\"upstream_traffic\\\": \\\"\\\", \\\"vulnerability_name\\\": \\\"\\\", \\\"stage\\\": 2, \\\"dev_name\\\": \\\"上梅林态势感知探针\\\", \\\"msg_count\\\": \\\"\\\", \\\"server_sensative_directory\\\": \\\"\\\", \\\"session_token\\\": \\\"\\\", \\\"url\\\": \\\"\\\", \\\"scan_count\\\": \\\"\\\", \\\"event_content\\\": \\\"主机访问malware家族通信域名\\\", \\\"solution\\\": \\\"1、深信服为广大用户免费提供查杀工具，可下载如下工具，进行检测查杀。\\\\n64位系统下载链接：http://edr.sangfor.com.cn/tool/SfabAntiBot_X64.7z\\\\n32位系统下载链接：http://edr.sangfor.com.cn/tool/SfabAntiBot_X86.7z\\\\n2、深信服EDR产品、下一代防火墙及安全感知平台等安全产品均具备病毒检测能力，部署相关产品用户可进行病毒检测。\\\\n3、深信服EDR产品、下一代防火墙及安全感知平台的用户建议开启接入安全云脑服务，即可第一时间更新相关流行病毒规则，有效拦截各类流行病毒。\\\", \\\"email_from\\\": \\\"\\\", \\\"email_to\\\": \\\"\\\", \\\"dst_host\\\": \\\"\\\", \\\"dst_port\\\": \\\"\\\", \\\"classify1_id\\\": \\\"\\\", \\\"data_collection_time\\\": \\\"\\\", \\\"src_host\\\": \\\"\\\"}\",\n" +
                "    \"dest_ip_type\": \"外网\",\n" +
                "    \"src_dns\": \"0\",\n" +
                "    \"es_index\": \"sec_all\",\n" +
                "    \"dest_dns\": \"0\",\n" +
                "    \"event_evidence\": \"主机访问域名：<a class='btnDetail' btncon='<div class=\\\"viewLog\\\" param={\\\"suspicious_domain_ip\\\":\\\"polling.burpcollaborator.net\\\"}>日志详情</div>'>polling.burpcollaborator.net</a> 777次，其中控制者IP（TOP3）：<a class='btnDetail' btncon='<div class=\\\"viewLog\\\" param={\\\"suspicious_domain_ip\\\":\\\"127.0.0.1\\\"}>日志详情</div>'>127.0.0.1</a>（-）；\",\n" +
                "    \"dev_first_unit_name\": \"润联科技\",\n" +
                "    \"product\": \"深信服SIP\",\n" +
                "    \"src_dmz\": \"0\",\n" +
                "    \"src_second_unit_name\": \"福田新一代\",\n" +
                "    \"dest_dmz\": \"0\",\n" +
                "    \"dev_second_unit_name\": \"生产区\",\n" +
                "    \"log_name\": \"僵尸网络事件\",\n" +
                "    \"action_result\": 0,\n" +
                "    \"log_level\": \"中风险\",\n" +
                "    \"src_first_unit_name\": \"润联科技\",\n" +
                "    \"SparkTime\": \"2021-12-01T22:37:16.288+0800\",\n" +
                "    \"flink\": \"1\",\n" +
                "    \"dest_ip\": \"0.0.0.0\",\n" +
                "    \"src_branch\": \"办公区\",\n" +
                "    \"dev_ip\": \"10.0.7.180\",\n" +
                "    \"alert_name\": \"{dev_ip}主机访问域名：<a class='btnDetail' btncon='<div class=\\\"viewLog\\\" param={\\\"suspicious_domain_ip\\\":\\\"polling.burpcollaborator.net\\\"}>日志详情</div>'>polling.burpcollaborator.net</a> 777次，其中控制者IP（TOP3）：<a class='btnDetail' btncon='<div class=\\\"viewLog\\\" param={\\\"suspicious_domain_ip\\\":\\\"127.0.0.1\\\"}>日志详情</div>'>127.0.0.1</a>（-）；\"\n" +
                "  }";

//        String oldContent = "{dev_ip}告警标题！！！{src_branch}";
//        String newContent = JsonArgo.getDymContent(oldContent, JsonUtils.parse(jsonStr));
//        System.out.println(newContent);
//        TbEventModel model = new TbEventModel();
//        model.setEventName("{log_name}[{action_result}]");
//        System.out.println(AlarmUtils.getLogName(JsonUtils.parse(jsonStr), model));
//        model.setEventName("我是谁");
//        System.out.println(AlarmUtils.getLogName(JsonUtils.parse(jsonStr), model));
//        model.setEventName("{log_name.keyword}[{action_result.keyword}]");
//        System.out.println(AlarmUtils.getLogName(JsonUtils.parse(jsonStr), model));
   //     String alertName = JsonUtils.parse(jsonStr).getString("alert_name");
   //     String newContent = JsonArgo.getDymValue(alertName, JsonUtils.parse(jsonStr));
 //       System.out.println(newContent);

        String x = "多个外网IP【{{{src_ip.keyword}}}】针对目标主机【10.34.53.68】攻击【其他】告警设备名称【奇安信天眼】{\"d_ip\":11}";
        String newContent = JsonArgo.getDymValue(x, JsonUtils.parse(jsonStr));
        System.out.println(newContent);
    }
}
