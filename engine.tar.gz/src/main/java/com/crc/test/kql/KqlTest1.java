package com.crc.test.kql;

import com.crc.common.paser.KqlParser;
import com.crc.common.paser.KqlResult;

public class KqlTest1 {
    public static void main(String[] args) {
        KqlParser argo = new KqlParser("1");
        String s1 = "src_ip.keyword in (\"10.20.0.1#10.20.0.2#10.20.0.3\")";
        s1 = "src_ip_type.keyword : \"内网\" and dest_ip_type.keyword : \"内网\" and dest_port.keyword in (\"22#23#135#445#389#3389#7001#3306#1099#1433#1521#3873#4446#5985#6379#27017#2375#5900#5432#4899#20880\")";
        s1 = "product.keyword : \"奇安信天眼\" and content: \"Fastjson反序列化漏洞攻击\" and (zlog_ori_msg :500 or zlog_ori_msg:200)";
        System.out.println(s1);
        KqlResult ret = argo.parse(s1);
        ret.print();
    }
}
