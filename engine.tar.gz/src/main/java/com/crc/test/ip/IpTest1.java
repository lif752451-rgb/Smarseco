package com.crc.test.ip;

import com.crc.common.utils.IpUtils;

public class IpTest1 {
    public static void main(String[] args) {
        System.out.println(IpUtils.isIp("abc"));
        System.out.println(IpUtils.isIp("10.0.1.1"));
        System.out.println(IpUtils.isIp("http://10.0.1.1"));
        System.out.println(IpUtils.isIp("https://fe80::5069:7eff:fe69:bb97%llw0"));
    }
}
