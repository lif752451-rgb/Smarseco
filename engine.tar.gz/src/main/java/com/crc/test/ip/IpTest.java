package com.crc.test.ip;

import com.crc.common.utils.IpUtils;

public class IpTest {
    public static void main(String[] args) {
        String ip = "10.0.0.0/8";
        System.out.println(IpUtils.getStartIp(ip));
        System.out.println(IpUtils.getEndIp(ip));
    }
}
