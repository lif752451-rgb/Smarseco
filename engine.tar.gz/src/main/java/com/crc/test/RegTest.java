package com.crc.test;

import com.crc.common.paser.KqlParser;
import com.crc.common.utils.SimpleCodeTool;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class RegTest {
    public static void main(String[] args) {
        String authStr = "{\"corpId\":\"\",\n" +
                "      \"corpSecret\":\"\",\n" +
                "      \"agentid\":}";
        System.out.println(authStr);
        System.out.println(SimpleCodeTool.decryptBase64(authStr));

    }
}
