package com.crc.test;

import com.crc.common.constants.LogConstants;
import com.crc.secface.config.ElasticsearchProperties;
import com.crc.secface.es.EsSingleFactory;
import org.elasticsearch.action.search.SearchRequest;
import org.elasticsearch.action.search.SearchResponse;
import org.elasticsearch.client.RequestOptions;
import org.elasticsearch.client.RestHighLevelClient;
import org.elasticsearch.index.query.QueryBuilder;
import org.elasticsearch.index.query.QueryBuilders;
import org.elasticsearch.index.query.WrapperQueryBuilder;
import org.elasticsearch.search.SearchHit;
import org.elasticsearch.search.SearchHits;
import org.elasticsearch.search.builder.SearchSourceBuilder;
import org.elasticsearch.search.sort.FieldSortBuilder;
import org.elasticsearch.search.sort.SortOrder;

public class EsKqlTest {
    public static void main(String[] args) {
        getAll();
    }

    public static void getAll() {
        SearchSourceBuilder searchSourceBuilder = new SearchSourceBuilder();
        SearchRequest searchRequest = new SearchRequest();
        // 查询的索引
        searchRequest.indices("sec_all-*");
        // query 的查询
        String kql = "product.keyword :\"青藤\" and src_ip.keyword:\"10.8.8.170\"";
        String body = "{\"bool\":{\"must\":[{\"query_string\":{\"query\":\"" + kql + "\"}}]}}";
        //System.out.println(body);
        //String xBody = "{\"bool\":{\"must\":{\"terms\":{\"src_ip.keyword\":[\"10.8.8.170\"]}}}}";
        QueryBuilder queryBuilder = QueryBuilders.wrapperQuery(body);
        searchSourceBuilder.query(queryBuilder);
        searchRequest.source(searchSourceBuilder);
        // 排序
        searchSourceBuilder.sort(new FieldSortBuilder(LogConstants.SPARK_TIME_TAG).order(SortOrder.DESC));
        // from size
        searchSourceBuilder.from(0);
        searchSourceBuilder.size(10);
        EsSingleFactory factory = EsSingleFactory.getInstance();
        RestHighLevelClient restHighLevelClient = factory.getHighLevelClient(newEsProperty());
        try {
            SearchResponse searchResponse = restHighLevelClient.search(searchRequest, RequestOptions.DEFAULT);
            System.out.println(searchSourceBuilder.toString());
            SearchHits hits = searchResponse.getHits();

            SearchHit[] searchHits = hits.getHits();
            System.out.println("search hit size :" + hits.getTotalHits() + " " + searchHits.length);
            for (SearchHit s : searchHits) {
                System.out.println(s.getSourceAsString());
            }
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            factory.close(restHighLevelClient);
        }
    }

    private static void getAll2() {
        SearchSourceBuilder sourceBuilder = new SearchSourceBuilder();
        sourceBuilder.from(0);
        sourceBuilder.size(100);
        sourceBuilder.sort(new FieldSortBuilder(LogConstants.SPARK_TIME_TAG).order(SortOrder.DESC));
        EsSingleFactory factory = EsSingleFactory.getInstance();
        RestHighLevelClient restHighLevelClient = factory.getHighLevelClient(newEsProperty());
        try {
            String kql = "product.keyword :\"青藤\" and src_ip.keyword:\"10.8.8.170\"";
            String body = "{\"bool\":{\"must\":[{\"query_string\":{\"query\":\"" + kql + "\"}}]}}";
            WrapperQueryBuilder wqb = QueryBuilders.wrapperQuery(body);
            SearchRequest searchRequest = new SearchRequest("sec_all-*");
            sourceBuilder.query(wqb);
            searchRequest.source(sourceBuilder);

            SearchResponse response = restHighLevelClient.search(searchRequest, RequestOptions.DEFAULT);
            SearchHits sh = response.getHits();
            for (SearchHit s : sh) {
                System.out.println(s.getSourceAsString());
            }
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            factory.close(restHighLevelClient);
        }
    }


    public static ElasticsearchProperties newEsProperty() {
        ElasticsearchProperties esProperty = new ElasticsearchProperties();
        esProperty.setHost("10.201.1.180");
        esProperty.setPassword("5iQALYwSzL97LhoaXVm2ah6E");
        esProperty.setUserName("elastic");
        esProperty.setPort(80);
        esProperty.setSchema("http");
        esProperty.setProxyHeader("8994b14fd0ba4c5fabef5e6851a38c56");
        return esProperty;
    }

}
