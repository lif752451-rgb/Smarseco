package com.crc.test;

import com.alibaba.fastjson.JSONObject;
import com.crc.common.utils.JsonUtils;
import com.crc.secface.argo.JsonArgo;

public class ProductTest {
    public static void main(String[] args) {
        String jsonStr = "{\n" +
                "    \"dev_ip_type\": \"内网\",\n" +
                "    \"src_ip_type\": \"内网\",\n" +
                "    \"action_result\": \"拦截\",\n" +
                "    \"content\": \"<5>time=2023-04-19 18:42:35;log_type=ips;danger_degree=2;breaking_sighn=1;event=[60471]HTTP目录遍历读取/etc/passwd文件;src_addr=10.30.216.20;src_port=2354;dst_addr=10.173.116.243;dst_port=80;user=null;smt_user=null;proto=HTTP;\",\n" +
                "    \"ip_score\": 2,\n" +
                "    \"src_ip\": \"10.30.216.20\",\n" +
                "    \"log_start_time\": \"2023-04-19T18:42:35.000+0800\",\n" +
                "    \"zlog_ori_msg\": \"<5>time=2023-04-19 18:42:35;log_type=ips;danger_degree=2;breaking_sighn=1;event=[60471]HTTP目录遍历读取/etc/passwd文件;src_addr=10.30.216.20;src_port=2354;dst_addr=10.173.116.243;dst_port=80;user=null;smt_user=null;proto=HTTP;\",\n" +
                "    \"dest_ip_type\": \"内网\",\n" +
                "    \"src_dns\": \"0\",\n" +
                "    \"es_index\": \"sec_all\",\n" +
                "    \"dest_dns\": \"0\",\n" +
                "    \"dest_port\": \"80\",\n" +
                "    \"product\": \"绿盟IPS\",\n" +
                "    \"src_dmz\": \"0\",\n" +
                "    \"dest_dmz\": \"0\",\n" +
                "    \"log_name\": \"[60471]HTTP目录遍历读取/etc/passwd文件\",\n" +
                "    \"event_score\": 30,\n" +
                "    \"log_level\": \"中风险\",\n" +
                "    \"protocal\": \"HTTP\",\n" +
                "    \"SparkTime\": \"2023-04-19T18:42:35.985+0800\",\n" +
                "    \"src_port\": \"2354\",\n" +
                "    \"flink\": \"1\",\n" +
                "    \"log_rev_time\": \"2023-04-19T18:42:35.000+0800\",\n" +
                "    \"crc_seg_id\": \"crc_seg_no\",\n" +
                "    \"dest_ip\": \"10.173.116.243\",\n" +
                "    \"dev_ip\": \"10.54.238.106\",\n" +
                "    \"alert_name\": \"10.30.216.20 对 10.173.116.243 进行 [60471]HTTP目录遍历读取/etc/passwd文件-拦截,日志详情为:<5>time=2023-04-19 18:42:35;log_type=ips;danger_degree=2;breaking_sighn=1;event=[60471]HTTP目录遍历读取/etc/passwd文件;src_addr=10.30.216.20;src_port=2354;dst_addr=10.173.116.243;dst_port=80;user=null;smt_user=null;proto=HTTP;\"\n" +
                "  }";
        String p = "{product.keyword}";
        JSONObject jsonObject = JsonUtils.parse(jsonStr);
        System.out.println(JsonArgo.getDymValue(p, jsonObject));
    }
}
