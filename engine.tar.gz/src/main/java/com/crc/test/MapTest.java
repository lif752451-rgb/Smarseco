package com.crc.test;

import lombok.extern.slf4j.Slf4j;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

@Slf4j
public class MapTest {
    public static void main(String[] args) {
        HashMap<String, Object> map = new HashMap<>();
        List<String> list = new ArrayList<>();
        list.add("133");
        map.put("1", list);
        map.put("2", 3);
        log.info("map = {}",map);
    }
}
