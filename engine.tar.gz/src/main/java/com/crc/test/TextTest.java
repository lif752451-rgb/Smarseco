//package com.crc.test;
//
//import com.alibaba.fastjson.JSON;
//import com.alibaba.fastjson.JSONObject;
//import com.crc.common.paser.KqlParser;
//import com.crc.common.utils.DataUtils;
//import com.crc.secface.entity.TbAsset;
//import org.apache.commons.lang3.StringUtils;
//import org.apache.commons.text.StringEscapeUtils;
//
//public class TextTest {
//    public static void main(String[] args) {
//        String desc = "主机【106.75.212.104】10分钟内扫描主机【120.202.28.108】22个扫描器常用端口，最近10个端口：3389, 22, 1900, 8000, 21, 9999, 8008, 8888，告警来源为华润医商二级态势感知平台-192.200.201.212日志详情为:{\\\"item_hash\\\":\\\"-5563408532410070281\\\",\\\"alert_time\\\":\\\"2021-10-18T12:45:10.000Z\\\",\\\"is_submitted\\\":\\\"0\\\",\\\"last_8_dst_port\\\":\\\"3389, 22, 1900, 8000, 21, 9999, 8008, 8888\\\",\\\"import_time\\\":\\\"2021-10-18T12:45:10.000Z\\\",\\\"is_duplicate\\\":\\\"0\\\",\\\"dst_ip\\\":\\\"120.202.28.108\\\",\\\"dev_id\\\":\\\"F511AE72\\\",\\\"src_ip\\\":\\\"106.75.212.104\\\",\\\"source_platform\\\":\\\"华润医商二级态势感知平台-192.200.201.212\\\",\\\"id\\\":\\\"4090127\\\",\\\"behavior\\\":\\\"scan_nmap_port\\\",\\\"unique_count_of_dst_port\\\":\\\"22\\\",\\\"is_alerted\\\":\\\"1\\\"}";
//        String title = "告警详情";
//        StringBuilder sb = new StringBuilder();
//        if (desc.contains("日志详情为")) {
//            int pos = desc.indexOf("日志详情为:");
//            if(pos == -1){
//                pos = desc.indexOf("日志详情为：");
//            }
//            String newStr = DataUtils.getSubString(desc, 0, pos);
//            if (StringUtils.isBlank(newStr)) {
//                newStr = desc;
//            }
//            sb.append(title).append(": ").append(newStr);
//        }else if (desc.contains("原始日志:")) {
//            int pos = desc.indexOf("原始日志:{");
//            String newStr = DataUtils.getSubString(desc, 0, pos);
//            if (StringUtils.isBlank(newStr)) {
//                newStr = desc;
//            }
//            sb.append(title).append(": ").append(newStr);
//        }else if (desc.contains("【详情：")) {
//            int pos = desc.indexOf("【详情：");
//            String newStr = DataUtils.getSubString(desc, 0, pos);
//            if (StringUtils.isBlank(newStr)) {
//                newStr = desc;
//            }
//            sb.append(title).append(": ").append(newStr);
//        }
//        System.out.println(sb.toString());
//        TbAsset asset = new TbAsset();
//        asset.setAssetUser("周峰");
//        asset.setAssetMail("zhoufeng@xx");
//        if (StringUtils.isBlank(asset.getAssetUser()) && StringUtils.isNotBlank(asset.getAssetMail())) {
//            asset.setAssetUser(asset.getAssetMail());
//        } else if (StringUtils.isNotBlank(asset.getAssetUser()) && StringUtils.isNotBlank(asset.getAssetMail())) {
//            asset.setAssetUser(asset.getAssetUser() + asset.getAssetMail());
//        }
//        System.out.println(asset.getAssetUser());
//    }
//
////    public static String clean(String kql){
////        Object k = JSON.parse(kql);
////        System.out.println(k);
////        kql = kql.replace(":", " : ").replace("  ", " ").replace("\" \"","\"\"").replace(") \"",")\"");
////        String newKQL = kql;//org.apache.commons.lang3.StringEscapeUtils.unescapeJava(kql);
////        //System.out.println(kql);
////        if (newKQL.startsWith("\"") && newKQL.endsWith("\"\"")) {
////            newKQL = newKQL.substring(1, newKQL.length() - 1);
////        }else if (newKQL.startsWith("\"") && newKQL.endsWith(")\"")) {
////            newKQL = newKQL.substring(1, newKQL.length() - 1);
////        }
////        kql = newKQL;
////        return kql;
////    }
//}
