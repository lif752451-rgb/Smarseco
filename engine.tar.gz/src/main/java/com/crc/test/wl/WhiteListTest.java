package com.crc.test.wl;

import com.crc.common.utils.MyTheadUtils;
import com.crc.secface.service.WhiteListCenter;
import com.crc.secface.service.WhitelistService;
import lombok.extern.slf4j.Slf4j;

import java.util.concurrent.ConcurrentLinkedDeque;

@Slf4j
public class WhiteListTest extends Thread{
    public static ConcurrentLinkedDeque<WlModelTest> queue = new ConcurrentLinkedDeque<>();
    @Override
    public void run() {
        log.info("开始测试！！！！！！！！！！");
        while (true) {
            try {
                if (queue.size() < 1) {
                    MyTheadUtils.sleep(10);
                    continue;
                }
                WlModelTest data = queue.poll();

                try {
                    boolean ret = WhitelistService.isMatchV2(data.getModel(), data.getJsonObject(), false);
                    log.info("是否命中白名单：{}",ret);
                } catch (Exception e) {
                    log.error(e.getMessage(),e);
                }
            } catch (Exception e) {
                log.error(e.getMessage(), e);
            }
            MyTheadUtils.sleep(10);
        }
    }
}
