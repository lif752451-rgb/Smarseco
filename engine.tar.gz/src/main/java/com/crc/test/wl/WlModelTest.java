package com.crc.test.wl;

import com.alibaba.fastjson.JSONObject;
import com.crc.secface.entity.TbEventModel;
import lombok.Data;

@Data
public class WlModelTest {
    TbEventModel model;
    JSONObject jsonObject;
}
