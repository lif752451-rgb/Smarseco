package com.crc.test;

import com.crc.common.utils.DataUtils;
import com.crc.common.utils.JsonUtils;
import com.crc.secface.argo.AlarmUtils;
import com.crc.secface.entity.TbEventModel;

public class DataTest1 {
    public static void main(String[] args) {
        String jsonStr = "{\"dev_ip_type\":\"内网\",\"src_ip_type\":\"内网\",\"instance\":\"\",\"src_ip_instance\":\" 10.20.241.84\",\"action_result\":\"放行\",\"attack_type\":\"④系统被控制，植入木马等\",\"event_description\":\"10.20.241.84 对 10.243.55.244 进行 [50562]HTTP 服务认证弱口令登录-放行,日志详情为:<5>time=2023-04-20 17:42:22;log_type=ips;danger_degree=1;breaking_sighn=0;event=[50562]HTTP 服务认证弱口令登录;src_addr=10.20.241.84;src_port=65485;dst_addr=10.243.55.244;dst_port=7443;user=null;smt_user=null;proto=HTTP;<5>time=2023-04-20 17:42:22;log_type=ips;danger_degree=1;breaking_sighn=0;event=[50562]HTTP 服务认证弱口令登录;src_addr=10.20.241.84;src_port=65485;dst_addr=10.243.55.244;dst_port=7443;user=null;smt_user=null;proto=HTTP;源IP资产信息: 10.20.241.84目标IP资产信息: 10.243.55.244\",\"content\":\"<5>time=2023-04-20 17:42:22;log_type=ips;danger_degree=1;breaking_sighn=0;event=[50562]HTTP 服务认证弱口令登录;src_addr=10.20.241.84;src_port=65485;dst_addr=10.243.55.244;dst_port=7443;user=null;smt_user=null;proto=HTTP;\",\"ip_score\":2,\"src_ip\":\"10.20.241.84\",\"log_start_time\":\"2023-04-20 17:42:22.000+0800\",\"times\":1,\"event_type\":\"④系统被控制，植入木马等\",\"dest_ip_type\":\"内网\",\"src_dns\":\"0\",\"id\":\"23042017444834011174\",\"es_index\":\"sec_all-2023.04.20\",\"dest_dns\":\"0\",\"dest_port\":\"7443\",\"product\":\"绿盟IPS\",\"src_dmz\":\"0\",\"dest_dmz\":\"0\",\"log_name\":\"10.20.241.84对10.243.55.244发起二级\\\"10.20.241.84对10.243.55.244发起低风险\\\"[50562]HTTP 服务认证弱口令登录\\\"攻击\\\"攻击\",\"event_score\":10,\"log_level\":\"二级\",\"attack_result_id\":\"0\",\"protocal\":\"HTTP\",\"SparkTime\":\"2023-04-20T17:43:01.179+0800\",\"risk_ip\":\"10.20.241.84\",\"ori_event_id\":\"23042017444821011173\",\"src_port\":\"65485\",\"flink\":\"1\",\"log_rev_time\":\"2023-04-20T17:42:22.000+0800\",\"crc_seg_id\":\"crc_seg_no\",\"bus_model\":\"SSP-EBAPEDZG\",\"log_count\":1,\"dest_ip_instance\":\" 10.243.55.244\",\"is_whitelist\":\"0\",\"es_log_name\":\"10.20.241.84对10.243.55.244发起低风险\\\"[50562]HTTP 服务认证弱口令登录\\\"攻击\",\"dest_ip\":\"10.243.55.244\",\"ids\":\"nYIMnocBXznkmwFFQAU2\",\"dev_ip\":\"10.54.238.106\",\"alert_name\":\"10.20.241.84 对 10.243.55.244 进行 [50562]HTTP 服务认证弱口令登录-放行,日志详情为:<5>time=2023-04-20 17:42:22;log_type=ips;danger_degree=1;breaking_sighn=0;event=[50562]HTTP 服务认证弱口令登录;src_addr=10.20.241.84;src_port=65485;dst_addr=10.243.55.244;dst_port=7443;user=null;smt_user=null;proto=HTTP;\",\"event_time\":\"2023-04-20 17:42:22.000+0800\"}\n";
        String dmyStr = "{src_ip}对{dest_ip}发起{log_level}\"{log_name}\"攻击";
        TbEventModel model = new TbEventModel();
        model.setEventName(dmyStr);
        model.setDeviceName("何景生");
        model.setDeviceType(1);
        System.out.println(AlarmUtils.getDeviceName(JsonUtils.parse(jsonStr),model));
    }

}
