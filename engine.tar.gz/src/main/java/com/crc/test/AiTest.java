package com.crc.test;

import com.alibaba.fastjson.JSONObject;
import com.crc.SpringbootApplication;
import com.crc.common.utils.HttpUtils;
import com.crc.common.utils.JsonUtils;
import com.crc.secface.config.DeployConfig;
import com.crc.sync.ai.AiCheckSync;
import org.apache.commons.lang3.StringUtils;

import java.util.Map;

public class AiTest {
    public static void main(String[] args) {
        SpringbootApplication.OP_CONFIG = new DeployConfig();
        SpringbootApplication.OP_CONFIG.setAiUrl("http://localhost:9999/ai/predictall");
        String msg = "{\"instance\":\"\",\"src_ip_instance\":\"10.248.9.9-华润万家(华润万家-卡券-流水中心)[汕尾数据中心/万家区]\",\"action_result\":\"失陷\",\"attack_type\":\"4_应用层漏洞利用\",\"event_description\":\"【检测到主机 10.248.9.9 执行whoami且执行其它高危命令】【源IP资产信息:10.248.9.9-华润万家(华润万家-卡券-流水中心)[汕尾数据中心/万家区]】\",\"src_ip\":\"10.248.9.9\",\"log_start_time\":\"2021-12-13 16:28:36\",\"times\":3,\"event_type\":\"4_应用层漏洞利用\",\"id\":\"21121400290165011290\",\"behavior\":\"主机执行whoami且执行其它高危命令\",\"product\":\"青藤+青藤-自动\",\"log_name\":\"主机执行whoami且执行其它高危命令\",\"log_level\":\"高风险\",\"attack_result_id\":\"2\",\"SparkTime\":\"2021-12-13T16:28:36.255027733Z\",\"risk_ip\":\"10.248.9.9\",\"ori_event_id\":\"21121400290162011289\",\"log_count\":3,\"bus_model\":\"corr_command_exec\",\"is_whitelist\":\"0\",\"alarm_office\":\"\",\"corr_value\":2,\"es_log_name\":\"主机执行whoami且执行其它高危命令\",\"dest_ip\":\"0.0.0.0\",\"ids\":\"2MiftH0BnlXK0OUk4PBf\",\"alert_name\":\"检测到主机 10.248.9.9 执行whoami且执行其它高危命令\",\"event_time\":\"2021-12-13 16:28:36\"}";
        Map<String, String> ret = AiCheckSync.getAiInfo(JsonUtils.parse(msg));
        JsonUtils.print(ret);
    }

    public static void mainx(String[] args) {
        String json = "{\"isworkday\":true,\"attack_type\":\"4_应用层漏洞利用\",\"isdatacenter\":false,\"event_name\":\"主机执行whoami且执行其它高危命令\",\"event_level\":\"二级\",\"event_source\":\"青藤\",\"reg_sub_area\":\"\\\\N\",\"attack_result\":\"2\",\"reg_area\":\"\\\\N\"}";
        JSONObject jsonObject = JsonUtils.parse(json);
        jsonObject.forEach((k, v) -> {
            if (v instanceof String) {
                if (StringUtils.isBlank(v.toString())) {
                    jsonObject.put(k, "\\N");
                } else {
                    if (k.equalsIgnoreCase("reg_area") && ((String) v).equalsIgnoreCase("其他")) {
                        jsonObject.put(k, "\\N");
                    } else if (k.equalsIgnoreCase("reg_sub_area") && ((String) v).equalsIgnoreCase("其他")) {
                        jsonObject.put(k, "\\N");
                    }
                }
            }
        });
        System.out.println(jsonObject);
        String ret = HttpUtils.sendPost("http://10.200.0.173:8080/predict", jsonObject.toJSONString());
        System.out.println(ret);
    }
}
