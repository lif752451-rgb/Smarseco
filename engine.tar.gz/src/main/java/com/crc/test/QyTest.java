package com.crc.test;

import com.alibaba.fastjson.JSONObject;
import com.crc.common.utils.JsonUtils;
import com.crc.msg.wx.QyweixinConfig;

import java.util.ArrayList;
import java.util.List;

public class QyTest {
    public static void main(String[] args) {

        String authStr = "{\"corpId\":\"ww8983c5464774de88\",\n" +
                "      \"corpSecret\":\"pFtQN9BxZr-aa1Hf5caT7Ul2hw1zYVUAfmY0HDNmw58\",\n" +
                "      \"agentid\":100002}";
        JSONObject auth = JsonUtils.parse(authStr);
        String token = QyweixinConfig.getToken(auth);
        System.out.println(token);
        String msg = "你的快递已到，请携带工卡前往邮件中心领取。\\n出发前可查看<a href=\\\"http://work.weixin.qq.com\\\">邮件中心视频实况</a>，聪明避开排队。";
        List<String> userList = new ArrayList<>();
        userList.add("hejs");
        userList.add("mico");
        JSONObject json = new JSONObject();
        json.put("touser", String.join("|",userList));
        json.put("toparty", "");
        json.put("totag", "");
        json.put("msgtype", "text");
        JSONObject content = new JSONObject();
        content.put("content", msg);
        json.put("text", content);
        json.put("safe", 0);
        json.put("enable_id_trans", 0);
        json.put("enable_duplicate_check", 0);

        System.out.println(json.toJSONString());

    }
}
