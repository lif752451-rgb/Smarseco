package com.crc.test;

import cn.hutool.core.lang.UUID;
import com.alibaba.fastjson.JSONObject;
import com.crc.common.utils.JsonUtils;

import java.util.ArrayList;
import java.util.List;


public class DataTest {
    public static void main(String[] args) {
        List<String> terVirusList = new ArrayList<>();
        terVirusList.add("{\n" +
                "    \"src_ip_type\": \"内网\",\n" +
                "    \"action_type\": \"可疑进程参数\",\n" +
                "    \"action_result\": \"失陷\",\n" +
                "    \"event_description\": \"主机10.200.204.57存在可疑进程参数问题，进程bash的启动参数为/bin/bash -c curl -s https://ycms-download-test.crcloud.com/cmdb/linux/shell/ycms_exec_cmdb.sh|bash，符合可疑进程参数的特性。\",\n" +
                "    \"op_name\": \"root\",\n" +
                "    \"content\": \"主机10.200.204.57存在可疑进程参数问题，进程bash的启动参数为/bin/bash -c curl -s https://ycms-download-test.crcloud.com/cmdb/linux/shell/ycms_exec_cmdb.sh|bash，符合可疑进程参数的特性。\",\n" +
                "    \"ip_score\": 2,\n" +
                "    \"src_ip\": \"10.200.204.57\",\n" +
                "    \"log_start_time\": \"2022-01-10T15:01:35.000+0800\",\n" +
                "    \"virus_name\": \"病毒名称\",\n" +
                "    \"asset_office\": \"北京公司\",\n" +
                "    \"event_type\": \"backdoor_diagnose\",\n" +
                "    \"zlog_ori_msg\": \"<182>#DATE# rlkj-qingtengprd-003 qtAlert[173] datatype=\\\"backdoor_diagnose\\\" VirusHandle=\\\"1641798095\\\" agent_ip=\\\"10.200.204.57\\\" host_name=\\\"RLKJ-CentOS7-6-x64\\\" internal_ip=\\\"10.200.204.57\\\" external_ip=\\\"\\\" host_tag=\\\"\\\" host_memo=\\\"\\\" group_name=\\\"北京公司\\\" action=\\\"add\\\" type=\\\"monitor\\\" group=\\\"3\\\" agent_id=\\\"61a5c7e21129f3c7\\\" comid=\\\"2020cd6871669f172c32\\\" event_type=\\\"backdoor_diagnose\\\" event_name=\\\"Linux后门检测\\\" event_level=\\\"alert\\\" event_content=\\\"主机10.200.204.57存在可疑进程参数问题，进程bash的启动参数为/bin/bash -c curl -s https://ycms-download-test.crcloud.com/cmdb/linux/shell/ycms_exec_cmdb.sh|bash，符合可疑进程参数的特性。\\\"  url=\\\"http://10.200.3.6/next/#/intrusion/backdoor/linux?search=%7B%22createTime%22%3A%7B%22min%22%3A%222022-01-10%2015%3A01%3A34%22%2C%22max%22%3A%222022-01-10%2015%3A01%3A36%22%7D%2C%20%22group%22%3A%5B3%5D%2C%22backDoorType%22%3A%22%E5%8F%AF%E7%96%91%E8%BF%9B%E7%A8%8B%E5%8F%82%E6%95%B0%22%2C%22ip%22%3A%2210.200.204.57%22%7D\\\" detail.log_type=\\\"1\\\" detail.backdoor_type=\\\"可疑进程参数\\\" detail.name=\\\"可疑进程参数\\\" detail.item=\\\"可疑进程参数\\\" detail.comment=\\\"进程bash的启动参数为/bin/bash -c curl -s https://ycms-download-test.crcloud.com/cmdb/linux/shell/ycms_exec_cmdb.sh|bash，符合可疑进程参数的特性。\\\" detail.rule=\\\"BD-270931\\\" detail.pname=\\\"bash\\\" detail.pid=\\\"27911\\\" detail.path=\\\"/usr/bin/bash\\\" detail.file_type=\\\"regular file\\\" detail.size=\\\"968696\\\" detail.access_permission=\\\"0755\\\" detail.uname=\\\"root\\\" detail.md5=\\\"78447c6d495e48ff9c5aeb7f7190fed4\\\" detail.sha256=\\\"97d2d62071d7ecfcecdf67fe174c01041b68248c92b66ca218884458060b1bda\\\" detail.ctime=\\\"1615801290\\\" detail.mtime=\\\"1615801290\\\" detail.atime=\\\"1641721441\\\" detail.ppname=\\\"cms_agent\\\" detail.ppid=\\\"9540\\\" detail.ppath=\\\"/usr/local/cms/bin/cms_agent\\\" detail.puname=\\\"root\\\" detail.rootkit_info=\\\"\\\" detail.bootkit_info=\\\"\\\"\",\n" +
                "    \"dest_instance\": \"私有云-云监控\",\n" +
                "    \"log_url\": \"  url=\",\n" +
                "    \"src_instance\": \"私有云-云监控\",\n" +
                "    \"dest_ip_type\": \"内网\",\n" +
                "    \"src_dns\": \"0\",\n" +
                "    \"es_index\": \"sec_all\",\n" +
                "    \"dest_dns\": \"0\",\n" +
                "    \"external_ip\": \"10.200.204.57\",\n" +
                "    \"product\": \"慧盾UES\",\n" +
                "    \"src_dmz\": \"0\",\n" +
                "    \"src_second_unit_name\": \"资源计算区\",\n" +
                "    \"dest_dmz\": \"0\",\n" +
                "    \"log_name\": \"Linux后门检测\",\n" +
                "    \"event_score\": 30,\n" +
                "    \"src_branch_name\": \"私有云测试环境地址段\",\n" +
                "    \"dest_asset_office\": \"北京公司\",\n" +
                "    \"log_level\": \"中风险\",\n" +
                "    \"src_first_unit_name\": \"北京公司\",\n" +
                "    \"dest_branch\": \"私有云\",\n" +
                "    \"SparkTime\": \"2022-01-10T15:03:56.944+0800\",\n" +
                "    \"dest_second_unit_name\": \"资源计算区\",\n" +
                "    \"dest_first_unit_name\": \"北京公司\",\n" +
                "    \"flink\": \"1\",\n" +
                "    \"dest_ip\": \"10.200.204.57\",\n" +
                "    \"src_branch\": \"私有云\",\n" +
                "    \"dest_branch_name\": \"私有云测试环境地址段\",\n" +
                "    \"alert_name\": \"10.200.204.57 进行 [Linux木马病毒] 主机10.200.204.57存在可疑木马进程VirusHandle，进程bash的启动参数为/bin/bash/VirusHandle -c curl -s https://ycms-download-test.crcloud.com/cmdb/linux/shell/ycms_exec_cmdb.sh|bash，符合可疑进程参数的特性。\",\n" +
                "    \"src_asset_office\": \"北京公司\"\n" +
                "  }");
        for (String j : terVirusList) {
            System.out.println(JsonUtils.parse(j));
        }
    }


}
