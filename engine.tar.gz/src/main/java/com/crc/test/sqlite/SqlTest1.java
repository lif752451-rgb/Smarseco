package com.crc.test.sqlite;

import com.alibaba.fastjson.JSONObject;
import com.crc.common.utils.DateUtils;
import com.crc.common.utils.JsonUtils;
import com.crc.secface.es.SqliteTool;

import java.sql.SQLException;
import java.util.Date;
import java.util.List;

public class SqlTest1 {
    private static void createTable(){
        String sql = "CREATE TABLE IF NOT EXISTS receiveData11" +
                "(id integer PRIMARY KEY AUTOINCREMENT ," +
                " par_id          INT DEFAULT 0    , " +
                " par_var         INT    , " +
                " receive_time    text   ) ";
        SqliteTool.getSqlController().excuteSql(sql, stmt -> { });
    }

    private static void insert(){
        SqliteTool.getSqlController().excuteSql("INSERT INTO receiveData11(par_id,par_var,receive_time) VALUES(?,?,?);"
                , stmt -> {
                    try {
                        int idx = 1;
                        stmt.setInt(idx++,20 );
                        stmt.setInt(idx++,200 );
                        stmt.setString(idx++, DateUtils.getDateTimeString1(new Date()));
                    } catch (SQLException e) {
                        e.printStackTrace();
                    }
                });
    }

    private static void find(){
        List<JSONObject> protocolDataPojos = SqliteTool.getSqlController().excuteSqlAndGetData(
                "SELECT id,par_id,par_var,receive_time " +
                        "FROM receiveData11 order by id DESC"
                , stmt -> {
                });
        JsonUtils.print(protocolDataPojos);
    }



    public static void main(String[] args) {
        //createTable();
        insert();
        find();
    }

}
