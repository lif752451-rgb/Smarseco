package com.crc.test.sqlite;

import com.alibaba.fastjson.JSONObject;
import com.crc.common.constants.MySQLDataTypeEnum;
import com.crc.common.utils.DateUtils;
import com.crc.common.utils.JsonUtils;
import com.crc.secface.argo.JsonToSql;
import com.crc.secface.es.SqliteTool;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;

import java.sql.SQLException;
import java.util.Date;
import java.util.HashMap;
import java.util.List;

@Slf4j
public class SqlTest2 {

    public static void main(String[] args) {
        HashMap<String, String> colMap = new HashMap<>();
        colMap.put("h1", MySQLDataTypeEnum.INT.getValue());
        colMap.put("h2", MySQLDataTypeEnum.VARCHAR.getValue());
        String createTableSql = JsonToSql.getCreateTableSql(colMap, "hejs");
        if (StringUtils.isBlank(createTableSql)) {
            log.error("关联子集" + "TT" + "获取创建数据库表脚本失败");
            return;
        }
        StringBuilder sql = new StringBuilder("insert into " + "hejs" + " (" + JsonToSql.getSelectColX(colMap) + " )  values");
        try {
            if (SqliteTool.getSqlController().excuteSql(createTableSql, stmt -> {
            })) {
                System.out.println("GOOD");
            }else {
                System.out.println("BAD");
            }
        } catch (Exception e) {
            log.error(e.getMessage(),e);
        }
    }

}
