//package com.crc.test;
//
//import com.alibaba.fastjson.JSONObject;
//import com.crc.SpringbootApplication;
//import com.crc.common.constants.EventConstants;
//import com.crc.common.constants.LogConstantsX;
//import com.crc.common.utils.DataUtils;
//import com.crc.common.utils.HttpUtils;
//import com.crc.common.utils.JsonUtils;
//import com.crc.common.utils.MyTheadUtils;
//import com.crc.secface.argo.AlarmUtils;
//import com.crc.secface.config.SyncSecConfig;
//import com.crc.secface.entity.LogData;
//import com.crc.sync.ai.AiCheckSync;
//import org.apache.commons.lang3.StringUtils;
//
//import java.util.Map;
//import java.util.concurrent.ArrayBlockingQueue;
//
//public class MagicSendTest extends Thread {
//    public static ArrayBlockingQueue<LogData> magicQueue = new ArrayBlockingQueue(50000);
//
//    public void run() {
//        while (true) {
//            if (magicQueue.isEmpty()) {
//                MyTheadUtils.sleepBySec(1);
//            } else {
//                while (!magicQueue.isEmpty()) {
//                    try {
//                        LogData data = magicQueue.poll();
//                        proc(data);
//                        MyTheadUtils.sleep(10);
//                    } catch (Exception e) {
//                    }
//                }
//            }
//        }
//    }
//
//    private void proc(LogData data) {
//        String jsonStr = "{\"attackCount\":1,\"victimizedIp\":\"0.0.0.0\",\"rule_base\":\"深信服SIP\",\"attackIp\":\"10.210.29.12\",\"level\":\"2\",\"alarmTime\":\"2021-09-22 12:50:17\",\"attackResultLabel\":\"企图\",\"attackMeans\":\"4_应用层漏洞利用\",\"detail\":\"【10.210.29.12 发起 僵尸网络-主机访问malware家族通信域名 来源：深圳大区-东莞市南城区】【【10.210.29.12 发起 僵尸网络-主机访问malware家族通信域名 来源：深圳大区-东莞市南城区】【主机访问malware家族通信域名】】\",\"title\":\"发现shiro站点（需测试）何景生\"}";
//        JSONObject ret = JsonUtils.parse(jsonStr);
//        JSONObject json = JsonUtils.parse(data.getData());
//        ret.put("alarmTime", JsonUtils.getStr(json, LogConstantsX.LOG_START_TIME));
//        ret.put("title", AlarmUtils.getLogName(json,));
//        if (StringUtils.isBlank(JsonUtils.getStr(ret, "title"))) {
//            ret.put("title", JsonUtils.getStr(json, LogConstantsX.LOG_PRODUCT).split("-")[0] + "行为告警");
//        }
//        ret.put("attackIp", JsonUtils.getStr(json, LogConstantsX.SRC_IP));
//        if (StringUtils.isBlank(JsonUtils.getStr(ret, "attackIp"))) {
//            ret.put("attackIp", JsonUtils.getStr(ret, "dev_ip"));
//            if (StringUtils.isBlank(JsonUtils.getStr(ret, "attackIp"))) {
//                ret.put("attackIp", "0.0.0.0");
//            }
//        }
//        ret.put("victimizedIp", JsonUtils.getStr(json, LogConstantsX.DEST_IP));
//        if (StringUtils.isBlank(JsonUtils.getStr(ret, "victimizedIp"))) {
//            ret.put("victimizedIp", "0.0.0.0");
//        }
//        String eventDesc = "";
//        if (StringUtils.isNotBlank(JsonUtils.getStr(json, LogConstantsX.ALERT_NAME))) {
//            eventDesc += "【" + json.getString(LogConstantsX.ALERT_NAME) + "】";
//        }
//        if (StringUtils.isNotBlank(JsonUtils.getStr(json, LogConstantsX.LOG_DESCRIPTION)) && !JsonUtils.equal(json, LogConstantsX.ALERT_NAME, LogConstantsX.LOG_DESCRIPTION))
//            eventDesc += "【" + JsonUtils.getStr(json, LogConstantsX.LOG_DESCRIPTION) + "】";
//
//        if (StringUtils.isBlank(eventDesc)) {
//            eventDesc += JsonUtils.getStr(json, LogConstantsX.LOG_ORI_MSG);
//        }
//        ret.put("detail", eventDesc);
//        /*ret.put("source", 280);*/
//        ret.put("rule_base", JsonUtils.getStr(json, LogConstantsX.LOG_PRODUCT).split("-")[0]);
//        //System.out.println(data.getfJson());
//        json.put("attack_result_id", EventConstants.AttackResultMap.get(JsonUtils.getStr(ret,"attackResultLabel")));
//        json.put("attack_type",JsonUtils.getStr(ret,"attackMeans"));
//        if("T".equalsIgnoreCase(SpringbootApplication.OP_CONFIG.getAiCheck())) {
//            Map<String, String> aiCheck = AiCheckSync.getAiCheckV2(json);
//            ret.put("aiCheck", DataUtils.getStr(aiCheck, "priority"));
//        }
//        System.out.println(ret);
//        String stpApi = SyncSecConfig.getRemarkValue(SyncSecConfig.STP_API_URL);
//        if (StringUtils.isBlank(stpApi)) {
//            stpApi = SpringbootApplication.OP_CONFIG.getStpUrl();
//        }
//        String url = stpApi + "/alarm/report/reportAlarmAuto";
//        String res = HttpUtils.sendPost(url, ret.toJSONString());
//        JSONObject jsonObject = JsonUtils.parse(res);
//        //{"msg":"SSP2021-1244","code":200}
//        if ("200".equals(JsonUtils.getStr(jsonObject, "code"))) {
//            String orderId = JsonUtils.getStr(jsonObject, "msg");
//            System.err.println(String.format("@@线程Id:%s,新版本STP返回:%s", Thread.currentThread().getName(), orderId));
//        } else {
//            System.out.println("推送失败" + res);
//        }
//    }
//
//}
