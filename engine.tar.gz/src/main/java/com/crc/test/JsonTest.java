package com.crc.test;

import com.crc.common.utils.DateUtils;

public class JsonTest {
    public static void main(String[] args) {
        String[] dates = DateUtils.getminuHourTimeRange(24);
        String jsonStr = "{\n" +
                "  \"aggs\": {\n" +
                "    \"levelDist\": {\n" +
                "      \"terms\": {\n" +
                "        \"field\": \"log_level.keyword\",\n" +
                "        \"order\": {\n" +
                "          \"_count\": \"desc\"\n" +
                "        },\n" +
                "        \"size\": 5\n" +
                "      }\n" +
                "    }\n" +
                "  },\n" +
                "  \"size\": 0,\n" +
                "  \"stored_fields\": [\n" +
                "    \"*\"\n" +
                "  ],\n" +
                "  \"script_fields\": {},\n" +
                "  \"docvalue_fields\": [\n" +
                "    {\n" +
                "      \"field\": \"SparkTime\",\n" +
                "      \"format\": \"date_time\"\n" +
                "    },\n" +
                "    {\n" +
                "      \"field\": \"log_start_time\",\n" +
                "      \"format\": \"date_time\"\n" +
                "    }\n" +
                "  ],\n" +
                "  \"_source\": {\n" +
                "    \"excludes\": []\n" +
                "  },\n" +
                "  \"query\": {\n" +
                "    \"bool\": {\n" +
                "      \"must\": [],\n" +
                "      \"filter\": [\n" +
                "        {\n" +
                "          \"bool\": {\n" +
                "            \"should\": [\n" +
                "              {\n" +
                "                \"match_phrase\": {\n" +
                "                  \"log_level.keyword\": \"高风险\"\n" +
                "                }\n" +
                "              },\n" +
                "              {\n" +
                "                \"match_phrase\": {\n" +
                "                  \"log_level.keyword\": \"中风险\"\n" +
                "                }\n" +
                "              },\n" +
                "              {\n" +
                "                \"match_phrase\": {\n" +
                "                  \"log_level.keyword\": \"低风险\"\n" +
                "                }\n" +
                "              }\n" +
                "            ],\n" +
                "            \"minimum_should_match\": 1\n" +
                "          }\n" +
                "        },\n" +
                "        {\n" +
                "          \"range\": {\n" +
                "            \"SparkTime\": {\n" +
                "              \"gte\": \"#START_TIME#\",\n" +
                "              \"lte\": \"#END_TIME#\",\n" +
                "              \"format\": \"strict_date_optional_time\"\n" +
                "            }\n" +
                "          }\n" +
                "        }\n" +
                "      ],\n" +
                "      \"should\": [],\n" +
                "      \"must_not\": []\n" +
                "    }\n" +
                "  }\n" +
                "}";
        System.out.println(jsonStr);
        jsonStr = jsonStr.replace("#START_TIME#", dates[1]).replace("#END_TIME#", dates[0]);
        System.out.println(jsonStr);
    }

    public static void main1(String[] args) {
        String[] dates = DateUtils.getminuHourTimeRange(24);
        String jsonStr = "{\n" +
                "  \"aggs\": {\n" +
                "    \"levelDist\": {\n" +
                "      \"terms\": {\n" +
                "        \"field\": \"action_result.keyword\",\n" +
                "        \"order\": {\n" +
                "          \"_count\": \"desc\"\n" +
                "        },\n" +
                "        \"size\": 5\n" +
                "      }\n" +
                "    }\n" +
                "  },\n" +
                "  \"size\": 0,\n" +
                "  \"stored_fields\": [\n" +
                "    \"*\"\n" +
                "  ],\n" +
                "  \"script_fields\": {},\n" +
                "  \"docvalue_fields\": [\n" +
                "    {\n" +
                "      \"field\": \"SparkTime\",\n" +
                "      \"format\": \"date_time\"\n" +
                "    },\n" +
                "    {\n" +
                "      \"field\": \"log_start_time\",\n" +
                "      \"format\": \"date_time\"\n" +
                "    }\n" +
                "  ],\n" +
                "  \"_source\": {\n" +
                "    \"excludes\": []\n" +
                "  },\n" +
                "  \"query\": {\n" +
                "    \"bool\": {\n" +
                "      \"must\": [],\n" +
                "      \"filter\": [\n" +
                "        {\n" +
                "          \"match_all\": {}\n" +
                "        },\n" +
                "        {\n" +
                "          \"bool\": {\n" +
                "            \"should\": [\n" +
                "              {\n" +
                "                \"match_phrase\": {\n" +
                "                  \"action_result.keyword\": \"拦截\"\n" +
                "                }\n" +
                "              },\n" +
                "              {\n" +
                "                \"match_phrase\": {\n" +
                "                  \"action_result.keyword\": \"拒绝\"\n" +
                "                }\n" +
                "              },\n" +
                "              {\n" +
                "                \"match_phrase\": {\n" +
                "                  \"action_result.keyword\": \"阻断\"\n" +
                "                }\n" +
                "              }\n" +
                "            ],\n" +
                "            \"minimum_should_match\": 1\n" +
                "          }\n" +
                "        },\n" +
                "        {\n" +
                "          \"range\": {\n" +
                "            \"SparkTime\": {\n" +
                "              \"gte\": \"#START_TIME#\",\n" +
                "              \"lte\": \"#END_TIME#\",\n" +
                "              \"format\": \"strict_date_optional_time\"\n" +
                "            }\n" +
                "          }\n" +
                "        }\n" +
                "      ],\n" +
                "      \"should\": [],\n" +
                "      \"must_not\": []\n" +
                "    }\n" +
                "  }\n" +
                "}";
        System.out.println(jsonStr);
        jsonStr = jsonStr.replace("#START_TIME#", dates[1]).replace("#END_TIME#", dates[0]);
        System.out.println(jsonStr);
    }
}
