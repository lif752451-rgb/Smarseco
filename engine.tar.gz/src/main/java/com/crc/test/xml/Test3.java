package com.crc.test.xml;

import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.NodeList;
import org.xml.sax.InputSource;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import java.io.StringReader;

public class Test3 {
    public static void main(String[] args) {
        String xml = "<?xml version=\"1.0\" encoding=\"UTF-8\"?> \n" +
                "<reply xmlns=\"urn:ietf:params:xml:ns:restconf:base:1.0\"> \n" +
                "<data xmlns=\"urn:ietf:params:xml:ns:restconf:base:1.0\"> \n" +
                "<address-set xmlns=\"urn:huawei:params:xml:ns:yang:huawei-address-set\"> \n" +
                "<addr-object>        \n" +
                "<vsys>public</vsys>        \n" +
                "<name>aaa</name>      \n" +
                "</addr-object>       \n" +
                "<addr-object>         \n" +
                "<vsys>public</vsys>        \n" +
                "<name>abc</name>      \n" +
                "</addr-object>       \n" +
                "<addr-object>         \n" +
                "<vsys>public</vsys>         \n" +
                "<name>test</name>       \n" +
                "</addr-object>    \n" +
                "</address-set>  \n" +
                "</data> \n" +
                "</reply>";

        try {
            DocumentBuilderFactory factory = DocumentBuilderFactory.newInstance();
            factory.setFeature("http://apache.org/xml/features/disallow-doctype-decl", true);
            DocumentBuilder builder = factory.newDocumentBuilder();
            InputSource source = new InputSource(new StringReader(xml));
            Document document = builder.parse(source);

            Element root = document.getDocumentElement();
            NodeList elements = root.getElementsByTagName("name");
            if (elements.getLength() > 0) {
                for (int i = 0; i < elements.getLength(); i++) {
                    Element element = (Element) elements.item(i);
                    System.out.println(element.getTextContent());
                }
            }
            String url = "/restconf/data/huawei-address-set:address-set/addr-object=public,test";
            ///restconf/data/huawei-address-set:address-set
            String groupName = url.split(",")[1];
            int lastIndex = url.lastIndexOf("/");
            String newUrl = url.substring(0, lastIndex);
            System.out.println(groupName);
            System.out.println(newUrl);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
