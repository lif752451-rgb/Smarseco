package com.crc.test.xml;

import org.w3c.dom.*;
import org.xml.sax.InputSource;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import java.io.StringReader;

public class Test {
    public static void main(String[] args) {
        String xml = "<rpc-reply xmlns=\"urn:ietf:params:xml:ns:netconf:base:1.0\" message-id=\"1\"><data><address-set xmlns=\"urn:huawei:params:xml:ns:yang:huawei-address-set\"><addr-object><vsys>public</vsys><name>stpgroup</name><desc>test</desc><elements><elem-id>1</elem-id><address-ipv4>10.0.56.77/32</address-ipv4></elements></addr-object></address-set></data></rpc-reply>";

        try {
            DocumentBuilderFactory factory = DocumentBuilderFactory.newInstance();
            factory.setFeature("http://apache.org/xml/features/disallow-doctype-decl", true);
            DocumentBuilder builder = factory.newDocumentBuilder();
            InputSource source = new InputSource(new StringReader(xml));
            Document document = builder.parse(source);

            Element root = document.getDocumentElement();
            NodeList elements = root.getElementsByTagName("elements");
            if (elements.getLength() > 0) {
                for (int i = 0; i < elements.getLength(); i++) {
                    Element element = (Element) elements.item(i);
                    NodeList childs = element.getChildNodes();
                    for (int j = 0; j < childs.getLength(); j++) {
                        System.out.println(childs.item(j).getNodeName());
                        System.out.println(childs.item(j).getTextContent());
                    }
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
