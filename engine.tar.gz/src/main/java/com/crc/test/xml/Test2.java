package com.crc.test.xml;

import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.xml.sax.InputSource;

import javax.xml.XMLConstants;
import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.stream.StreamResult;
import java.io.ByteArrayOutputStream;
import java.io.StringReader;

public class Test2 {
    public static void main(String[] args) {
        String xml = "<addr-object> <desc>how are you</desc> ##DATA## </addr-object>";

        try {
            StringBuilder sb = new StringBuilder();
            sb.append("<elements>");
            sb.append("<elem-id>").append("1").append("</elem-id>");
            sb.append("<address-ipv4>").append("192.168.1.0/24").append("</address-ipv4>");
            sb.append("</elements>");

            System.out.println(xml.replace("##DATA##",sb.toString()));
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
