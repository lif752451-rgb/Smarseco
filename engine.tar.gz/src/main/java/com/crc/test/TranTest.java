package com.crc.test;

import com.alibaba.fastjson.JSONObject;
import com.crc.common.constants.LogConstantsX;
import com.crc.common.utils.DateUtils;
import com.crc.common.utils.JsonUtils;
import com.crc.sync.send.SendToFlowV2;
import org.apache.commons.lang3.StringUtils;

public class TranTest {
    public static void main(String[] args) {
        String jsonStr = "{\n" +
                "    \"src_ip_type\": \"内网\",\n" +
                "    \"event_description\": \"主机【10.124.161.50】正在对主机【10.0.197.225】进行weblogic漏洞利用\",\n" +
                "    \"dst_ip\": \"10.0.197.225\",\n" +
                "    \"ip_score\": 2,\n" +
                "    \"crc_attr\": \"xiaqiang\",\n" +
                "    \"src_ip\": \"10.124.161.50\",\n" +
                "    \"log_start_time\": \"2021-12-02T14:43:41.000+0800\",\n" +
                "    \"source_platform\": \"集团一级态势感知平台-192.200.201.208\",\n" +
                "    \"event_type\": \"系统漏洞利用\",\n" +
                "    \"zlog_ori_msg\": \"{\\\"src_ip\\\":\\\"10.124.161.50\\\",\\\"source_platform\\\":\\\"集团一级态势感知平台-192.200.201.208\\\",\\\"import_time\\\":\\\"2021-12-02 14:43:41\\\",\\\"_id\\\":\\\"20211202|183511|00000001|6c92bffa1cde\\\",\\\"id\\\":\\\"703295\\\",\\\"behavior\\\":\\\"weblogic\\\",\\\"url\\\":\\\"10.112.16.50:8888/wls-wsat/CoordinatorPortType\\\",\\\"dst_ip\\\":\\\"10.0.197.225\\\",\\\"unique_count_of_dst\\\":\\\"\\\",\\\"account\\\":\\\"\\\",\\\"crc_attr\\\":\\\"xiaqiang\\\"}\",\n" +
                "    \"dest_instance\": \"华润燃气-CIS\",\n" +
                "    \"dest_ip_type\": \"内网\",\n" +
                "    \"src_dns\": \"0\",\n" +
                "    \"id\": \"703295\",\n" +
                "    \"es_index\": \"sec_all\",\n" +
                "    \"dest_dns\": \"0\",\n" +
                "    \"behavior\": \"weblogic\",\n" +
                "    \"product\": \"深信服XQ\",\n" +
                "    \"src_dmz\": \"0\",\n" +
                "    \"src_second_unit_name\": \"华润燃气\",\n" +
                "    \"dest_dmz\": \"0\",\n" +
                "    \"log_name\": \"主机【10.124.161.50】正在对主机【10.0.197.225】进行weblogic漏洞利用\",\n" +
                "    \"dest_asset_office\": \"华润燃气\",\n" +
                "    \"log_level\": \"高风险\",\n" +
                "    \"src_first_unit_name\": \"华润燃气\",\n" +
                "    \"dest_branch\": \"汕尾数据中心\",\n" +
                "    \"url\": \"10.112.16.50:8888/wls-wsat/CoordinatorPortType\",\n" +
                "    \"SparkTime\": \"2021-12-02T14:44:45.558+0800\",\n" +
                "    \"dest_second_unit_name\": \"BU区\",\n" +
                "    \"dest_first_unit_name\": \"华润燃气\",\n" +
                "    \"flink\": \"1\",\n" +
                "    \"dest_ip\": \"10.0.197.225\",\n" +
                "    \"src_branch\": \"前置机房\",\n" +
                "    \"unique_count_of_dst\": \"\",\n" +
                "    \"account\": \"\",\n" +
                "    \"alert_name\": \"主机【10.124.161.50】正在对主机【10.0.197.225】进行weblogic漏洞利用，告警来源为集团一级态势感知平台-192.200.201.208\"\n" +
                "  }";

        JSONObject json = JsonUtils.parse(jsonStr);
        String startTime = JsonUtils.getStr(json, LogConstantsX.LOG_START_TIME);
        startTime = DateUtils.UTCToCSTAndCheck(startTime);
        if (StringUtils.isBlank(startTime)) {
            startTime = DateUtils.UTCToCST(JsonUtils.getStr(json, LogConstantsX.LOG_TIME));
        }
        json.put(LogConstantsX.EVENT_TIME, startTime);
        SendToFlowV2 vw = new SendToFlowV2();
        //JSONObject x = vw.trans(json);
        //System.out.println(x);
    }
}
