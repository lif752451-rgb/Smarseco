package com.crc.test;

import com.alibaba.fastjson.JSON;
import com.crc.common.utils.JsonUtils;
import com.crc.common.utils.SimpleCodeTool;

import java.util.List;

public class DataTest22 {
    public static void main(String[] args) {
        Object[] objects = {1685505315358L};
        JsonUtils.print(objects);
        String s = SimpleCodeTool.encryptBase64(JSON.toJSONString(objects));
        JsonUtils.print(s);
        System.out.println(SimpleCodeTool.decryptBase64(s));

        List<Object> list = JSON.parseArray(SimpleCodeTool.decryptBase64(s), Object.class);
        JsonUtils.print(list);
    }
}
