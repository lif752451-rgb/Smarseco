package com.crc.test;

import com.crc.common.utils.CodeTool;
import com.crc.common.utils.DataUtils;
import com.crc.common.utils.FreeMarkerUtil;

public class ShotTest {
    public static void main(String[] args) {
        System.out.println(CodeTool.encrypt("ydfhs++CD43D"));
        System.out.println(DataUtils.getShorter("1234567890我是谁",12));
    }
}
