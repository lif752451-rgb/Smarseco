package com.crc.test;

import com.crc.common.utils.DateUtils;
import org.apache.commons.lang3.StringUtils;

public class IndexTest {
    public static void main(String[] args) {
        String indexName = "sec_all";
        if (StringUtils.isNotBlank(indexName)) {
            String index = indexName.split("-")[0];
            indexName = index + "-" + DateUtils.getDate1(0);
        } else {
            indexName = "sec_all-" + DateUtils.getDate1(0);
        }
        System.out.println(indexName);
    }
}
