package com.crc.test;

import org.apache.commons.lang3.StringEscapeUtils;

public class ModelJsonTest {
    public static void main(String[] args) {
        String kql = "\"product.keyword: \\\"赛门铁克\\\" and log_name.keyword:\\\"Ransom.Wannacry\\\"\"";
        String kql1 = "\"product.keyword : \\\"长亭Waf\\\"  and src_ip_type.keyword : \\\"内网\\\" and src_dmz.keyword : \\\"0\\\" and log_level.keyword : \\\"高风险\\\" \"";
        t(kql);
        t(kql1);
        String kql2 = "\"product.keyword:\\\"青藤\\\" and (event_type.keyword:\\\"web_command_win\\\" or event_type.keyword:\\\"web_command\\\") and (content:\\\"java\\\" or content:\\\"python\\\" or content:\\\"bash\\\" or content:\\\"java.exe\\\")\"";
        t(kql2);
        t("src_ip:\"10.200.0.139\"");
    }

    private static void t(String kql) {
        kql = kql.replace(":", " : ").replace("  ", " ").replace("\" \"","\"\"").replace(") \"",")\"");
        String newKQL = StringEscapeUtils.unescapeJava(kql);
        System.out.println(kql);
        if (newKQL.startsWith("\"") && newKQL.endsWith("\"\"")) {
            newKQL = newKQL.substring(1, newKQL.length() - 1);
        }else if (newKQL.startsWith("\"") && newKQL.endsWith(")\"")) {
            newKQL = newKQL.substring(1, newKQL.length() - 1);
        }
        kql = newKQL;
        System.out.println(kql);
    }
}
