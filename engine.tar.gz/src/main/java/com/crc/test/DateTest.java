package com.crc.test;

import com.crc.common.utils.DateUtils;
import com.crc.common.utils.TestUtils;
import org.apache.commons.lang3.StringUtils;

import java.util.Calendar;
import java.util.Date;
import java.util.GregorianCalendar;

public class DateTest {
    public static void main(String[] args) {
        String tablename = "ssp_pvvyko2s_23060912301061032247";
        if (StringUtils.isNotBlank(tablename)) {
            //System.out.println(tablename);
            if (tablename.startsWith("ssp_")) {
                String[] dateStrs = tablename.split("_");
                if (dateStrs.length == 3) {
                    Date date = DateUtils.parseDate(dateStrs[2].substring(0, "230609123010".length()), "yyMMddHHmmss");
                    System.out.println(DateUtils.getDateTimeString1(date));
                    Date curDate = new Date();
                    Date diffDate = DateUtils.minusHoursX(curDate, 2);
                    if (date.before(diffDate)) {
                        String sql = "drop table  " + tablename;
                        System.out.println(sql);
                    }
                }
            }
        }
    }

    public static String getFirstEndTime(String str){
        if(StringUtils.isBlank(str)){
            return "";
        }
        Date big = null;
        Date sml = null;
        for (String dateStr : str.split(",")) {
            Date d = DateUtils.parseDate(DateUtils.UTCToCSTAndCheck(dateStr),DateUtils.DATE_FORMAT_STRING1);
            if(big == null){
                big = d;
            }else {
                if(big.before(d)){
                    big = d;
                }
            }
            if(sml == null){
                sml = d;
            }else {
                if(sml.after(d)){
                    sml = d;
                }
            }
        }
        if(big == null || sml == null){
            return "";
        }else if(big != null && sml != null){
            if(big.getTime() == (sml.getTime())){
                return DateUtils.getDateTimeString1(big);
            }else {
                return String.format("%s至%s",DateUtils.getDateTimeString1(sml),DateUtils.getDateTimeString1(big));
            }
        }else if(big != null){
            return DateUtils.getDateTimeString1(big);
        }else {
            return DateUtils.getDateTimeString1(sml);
        }
    }
}
