package com.crc.test;

import com.crc.sync.net.NewSegmentLoad;

public class SegmentTest {
    public static void main(String[] args) {
        System.out.println(NewSegmentLoad.isBelongThisSegment("172.168.0.0/16 \n 192.168.1.1-192.168.1.100 \n192.168.56.2","172.168.1.5"));
        System.out.println(NewSegmentLoad.isBelongThisSegment("192.168.56.2,192.168.56.5","192.168.56.5"));
        System.out.println(NewSegmentLoad.isBelongThisSegment("172.16.0.0/16 172.16.200.1","172.16.200.1"));
    }
}
