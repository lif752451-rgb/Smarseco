//package com.crc.test;
//
//import com.alibaba.fastjson.JSONArray;
//import com.alibaba.fastjson.JSONObject;
//import com.crc.common.utils.JsonUtils;
//
//import java.util.ArrayList;
//import java.util.List;
//
//public class TreeTest {
//    public static void main(String[] args) {
//        String treeDSL = "{\n" +
//                "  \"viewId\": 1,\n" +
//                "  \"prevNodeViewId\": 0,\n" +
//                "  \"children\": [\n" +
//                "    {\n" +
//                "      \"viewId\": 2,\n" +
//                "      \"prevNodeViewId\": 1,\n" +
//                "      \"children\": [\n" +
//                "        {\n" +
//                "          \"viewId\": 3,\n" +
//                "          \"prevNodeViewId\": 2,\n" +
//                "          \"children\": [],\n" +
//                "          \"ruleType\": \"4\",\n" +
//                "          \"ruleName\": \"product\",\n" +
//                "          \"rule\": \"515\",\n" +
//                "          \"attributes\": \"product\",\n" +
//                "          \"label\": \"product\",\n" +
//                "          \"content\": \"天眼\"\n" +
//                "        },\n" +
//                "        {\n" +
//                "          \"viewId\": 4,\n" +
//                "          \"prevNodeViewId\": 2,\n" +
//                "          \"children\": [],\n" +
//                "          \"ruleType\": \"4\",\n" +
//                "          \"ruleName\": \"alert_name\",\n" +
//                "          \"rule\": \"514\",\n" +
//                "          \"attributes\": \"alert_name\",\n" +
//                "          \"label\": \"alert_name\",\n" +
//                "          \"content\": \"攻击\"\n" +
//                "        }\n" +
//                "      ],\n" +
//                "      \"ruleType\": \"1\",\n" +
//                "      \"ruleName\": \"AND\",\n" +
//                "      \"rule\": \"\",\n" +
//                "      \"attributes\": \"\",\n" +
//                "      \"label\": \"AND\",\n" +
//                "      \"content\": \"\"\n" +
//                "    },\n" +
//                "    {\n" +
//                "      \"viewId\": 5,\n" +
//                "      \"prevNodeViewId\": 1,\n" +
//                "      \"children\": [\n" +
//                "        {\n" +
//                "          \"viewId\": 6,\n" +
//                "          \"prevNodeViewId\": 5,\n" +
//                "          \"children\": [],\n" +
//                "          \"ruleType\": \"4\",\n" +
//                "          \"ruleName\": \"abc\",\n" +
//                "          \"rule\": \"514\",\n" +
//                "          \"attributes\": \"abc\",\n" +
//                "          \"label\": \"abc\",\n" +
//                "          \"content\": \"1\"\n" +
//                "        }\n" +
//                "      ],\n" +
//                "      \"ruleType\": \"3\",\n" +
//                "      \"ruleName\": \"NOT\",\n" +
//                "      \"rule\": \"\",\n" +
//                "      \"attributes\": \"\",\n" +
//                "      \"label\": \"NOT\",\n" +
//                "      \"content\": \"\"\n" +
//                "    }\n" +
//                "  ],\n" +
//                "  \"ruleType\": \"\",\n" +
//                "  \"ruleName\": \"这里是规则名称\",\n" +
//                "  \"rule\": \"\",\n" +
//                "  \"attributes\": \"\",\n" +
//                "  \"label\": \"这里是规则名称\",\n" +
//                "  \"content\": \"\"\n" +
//                "}";
//        JSONObject jsonObject = JsonUtils.parse(treeDSL);
//        List<TbRule> ruleList = new ArrayList<>();
//        if (jsonObject.containsKey("ruleName")) {
//            ruleList.add(toRule(jsonObject));
//            JSONArray array = jsonObject.getJSONArray("children");
//            if (array != null && array.size() > 0) {
//                toRuleList(array, ruleList);
//            }
//        }
//        JsonUtils.print(ruleList);
//    }
//
//    public static void toRuleList(JSONArray arrayX, List<TbRule> ruleList) {
//        for (int i = 0; i < arrayX.size(); i++) {
//            JSONObject jsonObject = arrayX.getJSONObject(i);
//            ruleList.add(toRule(jsonObject));
//            JSONArray array = jsonObject.getJSONArray("children");
//            if (array != null && array.size() > 0) {
//                toRuleList(array, ruleList);
//            }
//        }
//    }
//
//    public static TbRule toRule(JSONObject json) {
//        TbRule rule = new TbRule();
//        rule.setPrevNodeViewId(JsonUtils.getInt(json, "prevNodeViewId"));
//        rule.setRuleLabel(JsonUtils.getStr(json, "label"));
//        rule.setRuleName(JsonUtils.getStr(json, "ruleName"));
//        rule.setRuleType(JsonUtils.getStr(json, "ruleType"));
//        rule.setRule(JsonUtils.getStr(json, "rule"));
//        rule.setContent(JsonUtils.getStr(json, "content"));
//        rule.setViewId(JsonUtils.getInt(json, "viewId"));
//
//        return rule;
//    }
//}
