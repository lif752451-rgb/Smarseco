package com.crc.test;

import com.crc.common.paser.KqlParser;
import com.crc.common.paser.KqlResult;

public class KqlTest2 {
    public static void main(String[] args) {
        KqlParser kqlParser = new KqlParser("1");
        String x = "src_ip_type.keyword : \"内网\" and dest_ip_type.keyword : \"内网\" and (dest_port.keyword: \"22\" or dest_port.keyword: \"23\" or dest_port.keyword: \"135\" or dest_port.keyword: \"445\" or dest_port.keyword: \"389\" or dest_port.keyword: \"3389\"  or dest_port.keyword: \"7001\" or dest_port.keyword: \"3306\"  or dest_port.keyword: \"1099\" or dest_port.keyword: \"1433\" or dest_port.keyword: \"1521\" or dest_port.keyword: \"3873\"  or dest_port.keyword: \"4446\" or dest_port.keyword: \"5985\" or dest_port.keyword: \"6379\" or dest_port.keyword: \"27017\" or dest_port.keyword: \"2375\" or dest_port.keyword: \"5900\" or dest_port.keyword: \"5432\" or dest_port.keyword: \"4899\" or dest_port.keyword: \"20880\") ";
        KqlResult result = kqlParser.parse(x);
        result.print();
    }
}
