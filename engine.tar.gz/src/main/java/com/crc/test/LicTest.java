package com.crc.test;

import com.alibaba.fastjson.JSONObject;
import com.crc.common.utils.CodeTool;
import com.crc.common.utils.DateUtils;
import com.crc.common.utils.HardWareUtils;
import com.crc.common.utils.JsonUtils;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;

public class LicTest {
    public static void main(String[] args) {
        Map<String, String> resultMap = new HashMap<>();
        String publicKey = "IpTFX6FjYs5zKDG8gjKFh7kTgCFdWWJE";
        File file = new File("d://license.dat");
        if (file.exists()) {
            try {
                StringBuilder buffer = new StringBuilder();
                BufferedReader bf = new BufferedReader(new FileReader(file));
                String s = null;
                while ((s = bf.readLine()) != null) {
                    buffer.append(s.trim());
                }
                String content = buffer.toString();
                content = CodeTool.decrypt(content, publicKey);

                JSONObject obj = JsonUtils.parse(content);
                String motherboard = JsonUtils.getStr(obj, "motherboard");
                String cpuSerial = JsonUtils.getStr(obj, "cpuSerial");
                motherboard = CodeTool.decrypt(motherboard, publicKey);
                cpuSerial = CodeTool.decrypt(cpuSerial, publicKey);
                if (!motherboard.equals(HardWareUtils.getMotherboardSN()) ||
                        !cpuSerial.equals(HardWareUtils.getCPUSerial())) {
                    resultMap.put("code", "11");
                    resultMap.put("msg", "认证失败,授权有误");
                } else {
                    Date date = new Date();
                    String newCurrentTime = JsonUtils.getStr(obj, "newCurrentTime");//证书生产时间
                    String newExpireTime = JsonUtils.getStr(obj, "newExpireTime");//证书过期时间
                    Date currentDate = DateUtils.parseDateTime(CodeTool.decrypt(newCurrentTime, publicKey), "yyyy-MM-dd");
                    Date expireTime = DateUtils.parseDateTime(CodeTool.decrypt(newExpireTime, publicKey), "yyyy-MM-dd");
                    if (date.before(currentDate)) {//机器修改了时间
                        resultMap.put("code", "21");
                        resultMap.put("msg", "0002认证失败,授权过期");
                    } else {
                        if (date.after(expireTime)) {//授权过期
                            resultMap.put("code", "22");
                            resultMap.put("msg", "0002认证失败,授权过期");
                        } else {
                            resultMap.put("code", "1");
                            resultMap.put("msg", "认证成功，授权有效");
                        }
                    }
                }
            } catch (Exception e) {
                resultMap.put("code", "12");
                resultMap.put("msg", "认证失败,授权有误");
            }
        } else {
            resultMap.put("code", "03");
            resultMap.put("msg", "认证失败,授权有误");
        }
        JsonUtils.print(resultMap);

    }
}
