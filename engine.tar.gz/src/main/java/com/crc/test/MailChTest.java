package com.crc.test;

import com.crc.common.utils.StringUtils;

public class MailChTest {

    public static boolean checkEmail(String email) {// 验证邮箱的正则表达式
        if (StringUtils.isBlank(email)) {
            return false;
        }
        if (email.contains("@") && email.contains(".")) {
            return email.lastIndexOf(".") > email.lastIndexOf("@");
        }
        return false;
    }

    public static void main(String[] args) throws Exception {
        String email = "cc365@qq.com"; // 需要进行验证的邮箱
        System.out.println(checkEmail(email));
    }
}
