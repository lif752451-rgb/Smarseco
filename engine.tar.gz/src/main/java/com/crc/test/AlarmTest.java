package com.crc.test;

import com.crc.secface.entity.TbOriDangerEvent;

public class AlarmTest {
    public static void main(String[] args) {
        TbOriDangerEvent event = new TbOriDangerEvent();
        event.setSrcIp("10.1.3.75");
        event.setDestIp("0.0.0.0");
        event.setEventName("主机请求网络蠕虫域名");
        String sql = "SELECT count(1) FROM tb_alarm_report WHERE order_status IN ('研判','处置') AND attack_ip = '" + event.getSrcIp() + "' AND victimized_ip = '" + event.getDestIp() + "' AND title = '" + event.getEventName() + "'";
        System.out.println(sql);
        System.out.println("{\"attackCount\":1,\"victimizedIp\":\"0.0.0.0\",\"rule_base\":\"深信服SIP\",\"attackIp\":\"10.210.29.12\",\"level\":\"2\",\"alarmTime\":\"2021-09-22 12:50:17\",\"attackResultLabel\":\"企图\",\"attackMeans\":\"4_应用层漏洞利用\",\"detail\":\"【10.210.29.12 发起 僵尸网络-主机访问malware家族通信域名 来源：深圳大区-东莞市南城区】【【10.210.29.12 发起 僵尸网络-主机访问malware家族通信域名 来源：深圳大区-东莞市南城区】【主机访问malware家族通信域名】】\",\"title\":\"发现shiro站点（需测试）何景生\"}");
    }
}
