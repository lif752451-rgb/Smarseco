package com.crc.test;

import com.crc.secface.entity.TbEventModel;

public class AlarmSendTest extends Thread {
    public static void main(String[] args) {
        String msg = "{\n" +
                "  \"action_rule\": \"SQL注入\",\n" +
                "  \"src_ip_type\": \"内网\",\n" +
                "  \"instance\": \"\",\n" +
                "  \"action_result\": \"企图\",\n" +
                "  \"attack_type\": \"内网横向扫描\",\n" +
                "  \"dev_dns\": \"0\",\n" +
                "  \"log_start_time\": \"2021-09-17 16:00:42\",\n" +
                "  \"hostname\": \"10.248.9.11\",\n" +
                "  \"dev_dmz\": \"0\",\n" +
                "  \"event_type\": \"4_应用层漏洞利用\",\n" +
                "  \"dev_branch\": \"润联科技.\",\n" +
                "  \"log_url\": \"10.248.9.11\",\n" +
                "  \"dest_ip_type\": \"内网\",\n" +
                "  \"id\": \"21091716170409011003\",\n" +
                "  \"dest_dns\": \"0\",\n" +
                "  \"src_dmz\": \"0\",\n" +
                "  \"log_name\": \"[精确告警]内网网页漏洞利用\",\n" +
                "  \"dest_asset_office\": \"华润万家\",\n" +
                "  \"log_level\": \"高风险\",\n" +
                "  \"log_priority\": \"6\",\n" +
                "  \"attack_result_id\": \"0\",\n" +
                "  \"SparkTime\": \"2021-09-17T16:01:09.199+0800\",\n" +
                "  \"risk_ip\": \"10.228.84.142\",\n" +
                "  \"flink\": \"1\",\n" +
                "  \"log_count\": 1,\n" +
                "  \"is_whitelist\": \"0\",\n" +
                "  \"es_log_name\": \"[精确告警]内网网页漏洞利用\",\n" +
                "  \"dest_ip\": \"10.248.9.11\",\n" +
                "  \"ids\": \"2u7G8nsBJHqdHhPUCL8f\",\n" +
                "  \"src_asset_office\": \"华润万家\",\n" +
                "  \"dev_ip_type\": \"内网\",\n" +
                "  \"action_type\": \"网页漏洞利用\",\n" +
                "  \"event_description\": \"【10.228.84.142 对 10.248.9.11 进行 网页漏洞利用-SQL注入-SQL注入攻击(机器学习/编码不规范),请求主机：10.248.9.11】【{\\\"req_header\\\":\\\"UE9TVCAvc3VwcGVyL0RhdGFTZXJ2aWNlU2VydmxldCBIVFRQLzEuMQ0KSG9zdDogMTAuMjQ4LjkuMTENCkNvbm5lY3Rpb246IGtlZXAtYWxpdmUNCkNvbnRlbnQtTGVuZ3RoOiA0NDgNCkFjY2VwdDogKi8qDQphY2NlcHQtbGFuZ3VhZ2U6IHpoLUNODQpjb250ZW50LXR5cGU6IGFwcGxpY2F0aW9uL2pzb247IGNoYXJzZXQ9dXRmLTgNClVzZXItQWdlbnQ6IE1vemlsbGEvNS4wIChjb21wYXRpYmxlOyBNU0lFIDEwLjA7IFdpbmRvd3MgTlQgNi4xOyBXT1c2NDsgVHJpZGVudC82LjA7IFNFIDIuWCBNZXRhU3IgMS4wKQ0KUmVmZXJlcjogaHR0cDovLzEwLjI0OC45LjExL3N1cHBlci9jb20uZWZ1dHVyZS5jb25nb3UuTWFpbi8yQzIyQjk2MUQ1QTQ5MThBODcyOTJERTU5NjkwMUIwMi5jYWNoZS5odG1sDQpBY2NlcHQtRW5jb2Rpbmc6IGd6aXAsIGRlZmxhdGUNCkNvb2tpZTogSlNFU1NJT05JRD03RUJGODk5NzIxNjAzRURFMzYyNDkwMDM2QUVFQTEyMC53amhxejF2cGNhMDhzdXBwZXIwMTsgcmVwb3J0SURTdHI9MjIyMDYzJTJDMTc5OyBPYlNTT0Nvb2tpZT10WnliSGFzeVFIcGUlMkJWbEV2Q29tQmpJeTdQaWJHVXZ5MDZ1WmlyWFJlZThCMER3RWRsVW5URENqaXlnUEtURzkxUE5ITVZGSXZRdWV2OWVRaUQlMkJzU0dlNEprQmpYamVlMXBsSUpBUm1lZFdUUVFZUWFNbkVqV1MwR202Q25aRjNlTENLNVY3UktYNWNDcGhqSE5adXFDZXlvWXhwSG55ejg1YU5tRVpZbnpQdVpMc1VFZUxQc1lDTXpJbyUyRjJqemEwb3ElMkJzdnlXQXo3cTNUdVJMbWR4JTJCJTJGNDh3dXpYb2p5WW9pUFI5bU94UXo1WWNuaSUyQnZadk5EU2d2cXR1R1B2WGgwaURoRU5MUEk3ZHFIVlhlM2dGS2hvNlpqN1BEb2d3dGtDb0xabXRDODFZeEVLdXFoMmElMkJHU3cwbmMyM2hkNXRkMGgxYk9ZaWlJOWplRUZWZ1hsRjUwcWVmSXQ5MWp6cmJoYUEzVDM2d1hCWE42b1JQVXkxbXdyRFlyQ2oxM2NEOyByb3V0ZT1kZWE0YWJkNTFmYTJjNDlkYTg0ZThhNDhjNTBlYjQ1ZQ0KDQo=\\\",\\\"req_body\\\":\\\"eyJ0b2tlbiI6Ijg2Mjk4NkQzMUFCMjZGRUE1NEE3NzY2RTg1OTNCRjE0IiwgIm1vZHVsZUlEIjoiMjIyMDY2IiwgInJlcUNhdElEIjoiMDQiLCAicmVxRGF0YSI6IntcIkRiaWRcIjowLCBcImRzU1FMXCI6XCJzZWxlY3QgdmVuZGVybmFtZSx2ZW5kZXJmbGFnIGZyb20gdmVuZGVyX3cgdixidWluZm8gYix1c2VyX2NhdGVnb3J5IGMgIHdoZXJlIHYuYnVpZD1iLmJ1aWQgYW5kIGIuY2F0ZWdvcnl0cmVlaWQ9Yy5jYXRlZ29yeXRyZWVpZCBhbmQgdi5jYXRlZ29yeWlkPWMuY2F0ZWdvcnlpZCAgYW5kIHYuYnVpZD0nMTYnIGFuZCB2LnZlbmRlcmlkPScxODEwNDMxMTAxJyBhbmQgYy51c2VyaWQ9NjA0MDBcIiwgXCJwcmVTUUxcIjpcIlwiLCBcInBvc3RTUUxcIjpcIlwiLCBcImlzVXNlVHJhblwiOmZhbHNlLCBcImlMaW1pdFJvd3NcIjowfSIsICJjb21tYW5kSUQiOiIiLCAicGFyYW0iOiIifQ==\\\",\\\"rsp_header\\\":\\\"SFRUUC8xLjEgMjAwIE9LDQpEYXRlOiBGcmksIDE3IFNlcCAyMDIxIDA4OjAwOjQwIEdNVA0KU2VydmVyOiBuZ2lueC8xLjEwLjENCkNhY2hlLUNvbnRyb2w6IHB1YmxpYw0KUHJhZ21hOiBwdWJsaWMNCkNvbnRlbnQtVHlwZTogYXBwbGljYXRpb24vanNvbjtjaGFyc2V0PVVURi04DQpDb250ZW50LUxlbmd0aDogMzg5DQpDb250ZW50LUVuY29kaW5nOiBnemlwDQpLZWVwLUFsaXZlOiB0aW1lb3V0PTUsIG1heD0xMDANCkNvbm5lY3Rpb246IEtlZXAtQWxpdmUNCg0K\\\",\\\"rsp_body\\\":\\\"eyJzdWNjZXNzIjp0cnVlLCJyZXFDYXRJRCI6IjA0IiwibWVzc2FnZSI6IiIsInJpZ2h0VmFsdWUiOjAsInZhbHVlIjoiZGF0YXNldDp7djpcIkRhdGFTZXR8MHwgfCB8LTF8MHxcIix0YWJsZXM6W3tuYW1lOlwiVGFibGUwXCIsY25hbWU6XCJcIixyYzoxLHJvOmZhbHNlLGNrOlwiXCIsa3k6XCJcIixjZWU6XCJcIixycHM6XCJcIix0YzpcIjFcIix0cmM6XCIxXCIsUm93c0xpbWl0OlwiMFwiLGZyOlwiMFwiLG5yaTpcIjFcIixoYzpmYWxzZSxjb2x1bW5zOlt7djpcInZlbmRlcm5hbWV8c3RyaW5nfFZFTkRFUk5BTUV8MXw1MTJ8NjR8MHwwfDB8MHwxfDB8MHwgfCB8IHwgfDB8IHwwfDB8MHwwfDB8MXwgfDB8IHwwfCB8IHxcIn0se3Y6XCJ2ZW5kZXJmbGFnfGZsb2F0fFZFTkRFUkZMQUd8MXw4MHwwfDB8MHwwfDB8MXwwfDB8IHwgfCB8IHwwfCB8MHwwfDB8MHwwfDF8IHwwfCB8MHwgfCB8XCJ9LHt2OlwiX3Jvd2lkfGludHxfcm93aWR8MXw0OHwwfDB8MHwwfDB8MHwwfDB8IHwgfCB8IHwwfCB8MHwwfDB8MHwwfDF8IHwwfCB8MHwgfCB8XCJ9LHt2OlwiX3NzZmxhZ3xzdHJpbmd8X3NzZmxhZ3wxfDIwNDB8MjU1fDB8MHwwfDB8MHwwfDB8IHwgfCB8IHwwfCB8MHwwfDB8MHwwfDF8IHwwfCB8MHwgfCB8XCJ9XSxhbW91bnQ6W10scGVhazpbXSxyZWNvcmRzOlt7djpcIuaXoOmUoeWkp+Wxsea0i+ihjOi0uOaYk+aciemZkOWFrOWPuHwwfDF8IFwifV19XX0ifQ==\\\"}】\",\n" +
                "  \"dev_asset_office\": \"\",\n" +
                "  \"content\": \"{\\\"write_date\\\":1631865642,\\\"vuln_harm\\\":\\\"攻击者可在SQL语句中执行恶意SQL命令。 被SQL注入后可能导致以下后果： 1.网页被篡改; 2.数据被篡改; 3.核心数据被窃取; 4.数据库所在服务器被攻击变成傀儡主机。\\\",\\\"vuln_type\\\":\\\"SQL注入\\\",\\\"dip\\\":\\\"10.248.9.11\\\",\\\"site_app\\\":\\\"\\\",\\\"uri\\\":\\\"/supper/DataServiceServlet\\\",\\\"dport\\\":80,\\\"rsp_status\\\":200,\\\"vuln_name\\\":\\\"SQL注入攻击(机器学习/编码不规范)\\\",\\\"code_language\\\":\\\"\\\",\\\"solution\\\":\\\"确认是否为业务导致告警，如是则对业务逻辑进行调整，将SQL操作编码至后端中或做采取其他安全措施保证安全。\\\",\\\"detail_info\\\":\\\"当前业务直接将SQL操作放置于前台操作，存在被SQL注入攻击的风险。\\\",\\\"xff\\\":\\\"\\\",\\\"sip\\\":\\\"10.228.84.142\\\",\\\"vuln_desc\\\":\\\"当前业务直接将SQL操作放置于前台操作，存在被SQL注入攻击的风险。\\\",\\\"public_date\\\":\\\"2020-11-25 06:30:22\\\",\\\"sport\\\":60738}\",\n" +
                "  \"ip_score\": 2,\n" +
                "  \"src_ip\": \"10.228.84.142\",\n" +
                "  \"times\": 1,\n" +
                "  \"dest_instance\": \"华润万家_MIS-总部供应链(HQSCM)\",\n" +
                "  \"src_dns\": \"0\",\n" +
                "  \"es_index\": \"sec_all\",\n" +
                "  \"add_info\": \"SSP自动提单 \",\n" +
                "  \"product\": \"奇安信天眼-自动\",\n" +
                "  \"dest_dmz\": \"0\",\n" +
                "  \"event_score\": 80,\n" +
                "  \"dest_branch\": \"汕尾数据中心.华润万家\",\n" +
                "  \"ori_event_id\": \"21091716170406011002\",\n" +
                "  \"bus_model\": \"ty_inside_webattack\",\n" +
                "  \"alarm_office\": \"\",\n" +
                "  \"src_branch\": \"汕尾数据中心.华润万家\",\n" +
                "  \"dev_ip\": \"10.0.14.210\",\n" +
                "  \"alert_name\": \"10.228.84.142 对 10.248.9.11 进行 网页漏洞利用-SQL注入-SQL注入攻击(机器学习/编码不规范),请求主机：10.248.9.11\",\n" +
                "  \"event_time\": \"2021-09-17 16:00:42\"\n" +
                "}";
        TbEventModel model = new TbEventModel();
        model.setEventLevelName("低危");

    }
}
