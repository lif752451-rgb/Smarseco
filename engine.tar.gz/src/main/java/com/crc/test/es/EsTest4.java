package com.crc.test.es;

import com.crc.common.utils.EsUtils;
import com.crc.secface.config.ElasticsearchProperties;
import com.crc.secface.es.EsSingleFactory;
import lombok.extern.slf4j.Slf4j;
import org.apache.http.HttpEntity;
import org.apache.http.util.EntityUtils;
import org.elasticsearch.client.Request;
import org.elasticsearch.client.Response;
import org.elasticsearch.client.RestHighLevelClient;


@Slf4j
public class EsTest4 {
    public static void main(String[] args) {
        try {
            String jsonStr = "{\n" +
                    "  \"aggs\": {\n" +
                    "    \"name\": {\n" +
                    "      \"terms\": {\n" +
                    "        \"field\": \"dev_ip.keyword\",\n" +
                    "        \"order\": {\n" +
                    "          \"_count\": \"desc\"\n" +
                    "        },\n" +
                    "        \"size\": 100\n" +
                    "      },\n" +
                    "      \"aggs\": {\n" +
                    "        \"child\": {\n" +
                    "          \"terms\": {\n" +
                    "            \"field\": \"product.keyword\",\n" +
                    "            \"order\": {\n" +
                    "              \"_count\": \"desc\"\n" +
                    "            },\n" +
                    "            \"missing\": \"__missing__\",\n" +
                    "            \"size\": 100\n" +
                    "          }\n" +
                    "        }\n" +
                    "      }\n" +
                    "    }\n" +
                    "  },\n" +
                    "  \"size\": 0,\n" +
                    "  \"fields\": [\n" +
                    "    {\n" +
                    "      \"field\": \"SparkTime\",\n" +
                    "      \"format\": \"date_time\"\n" +
                    "    },\n" +
                    "    {\n" +
                    "      \"field\": \"log_start_time\",\n" +
                    "      \"format\": \"date_time\"\n" +
                    "    }\n" +
                    "  ],\n" +
                    "  \"script_fields\": {\n" +
                    "\n" +
                    "  },\n" +
                    "  \"stored_fields\": [\n" +
                    "    \"*\"\n" +
                    "  ],\n" +
                    "  \"runtime_mappings\": {\n" +
                    "\n" +
                    "  },\n" +
                    "  \"_source\": {\n" +
                    "    \"excludes\": [\n" +
                    "\n" +
                    "    ]\n" +
                    "  },\n" +
                    "  \"query\": {\n" +
                    "    \"bool\": {\n" +
                    "      \"must\": [\n" +
                    "\n" +
                    "      ],\n" +
                    "      \"filter\": [\n" +
                    "        {\n" +
                    "          \"range\": {\n" +
                    "            \"SparkTime\": {\n" +
                    "              \"gte\": \"2023-06-07T12:24:01.739+0000\",\n" +
                    "              \"lte\": \"2023-06-07T12:54:01.739+0000\",\n" +
                    "              \"format\": \"strict_date_optional_time\"\n" +
                    "            }\n" +
                    "          }\n" +
                    "        }\n" +
                    "      ],\n" +
                    "      \"should\": [\n" +
                    "\n" +
                    "      ],\n" +
                    "      \"must_not\": [\n" +
                    "\n" +
                    "      ]\n" +
                    "    }\n" +
                    "  }\n" +
                    "}";
            System.out.println(jsonStr);
            System.out.println(EsUtils.getQueryStr(newEsProperty(),"sec_all-*",jsonStr));
        } catch (Exception e) {
            log.error(e.getMessage(),e);
        }
    }

    public static ElasticsearchProperties newEsProperty() {
        ElasticsearchProperties esProperty = new ElasticsearchProperties();
        esProperty.setHost("sec_es_test.crc.com.cn");
        esProperty.setPassword("w9Mu1qL0J5juVZttuFDt");
        esProperty.setUserName("elastic");
        esProperty.setPort(80);
        esProperty.setSchema("http");
        esProperty.setProxyHeader("8994b14fd0ba4c5fabef5e6851a38c56");
        return esProperty;
    }
}
