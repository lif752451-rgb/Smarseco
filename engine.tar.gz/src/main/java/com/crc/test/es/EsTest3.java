package com.crc.test.es;

import com.alibaba.fastjson.JSON;
import com.crc.common.utils.EsUtils;
import com.crc.secface.config.ElasticsearchProperties;
import com.crc.secface.es.EsSingleFactory;
import lombok.extern.slf4j.Slf4j;
import org.elasticsearch.action.admin.indices.alias.get.GetAliasesRequest;
import org.elasticsearch.client.GetAliasesResponse;
import org.elasticsearch.client.RequestOptions;
import org.elasticsearch.client.RestHighLevelClient;

import java.util.ArrayList;
import java.util.List;


@Slf4j
public class EsTest3 {
    public static void main(String[] args) {
        EsSingleFactory factory = EsSingleFactory.getInstance();
        RestHighLevelClient restHighLevelClient = factory.getHighLevelClient(newEsProperty());
        try {
            /**
             * 获取所有index
             */
            GetAliasesRequest aliasesRequest = new GetAliasesRequest();
            GetAliasesResponse resp = restHighLevelClient.indices().getAlias(aliasesRequest, RequestOptions.DEFAULT);
            List<String> indexs = new ArrayList<>();
            resp.getAliases().forEach((k,v)->{
                if(!k.startsWith(".") && EsUtils.indexContainDate(k)){
                    indexs.add(k);
                }
            });
            System.out.println(JSON.toJSONString(indexs));
        } catch (Exception e) {
            log.error(e.getMessage(),e);
        } finally {
            factory.close(restHighLevelClient);
        }
    }

    public static ElasticsearchProperties newEsProperty() {
        ElasticsearchProperties esProperty = new ElasticsearchProperties();
        esProperty.setHost("sec_es_test.crc.com.cn");
        esProperty.setPassword("w9Mu1qL0J5juVZttuFDt");
        esProperty.setUserName("elastic");
        esProperty.setPort(80);
        esProperty.setSchema("http");
        esProperty.setProxyHeader("8994b14fd0ba4c5fabef5e6851a38c56");
        return esProperty;
    }
}
