package com.crc.test.es;

import com.crc.common.constants.LogConstants;
import com.crc.common.utils.DateUtils;
import com.crc.common.utils.EsUtils;
import org.elasticsearch.index.query.BoolQueryBuilder;
import org.elasticsearch.index.query.QueryBuilders;
import org.elasticsearch.index.query.RangeQueryBuilder;

import java.util.Calendar;
import java.util.Date;
import java.util.GregorianCalendar;

public class EsIdTest {
    public static  BoolQueryBuilder buildQueryBuilder(String id) {
        BoolQueryBuilder boolBuilder = QueryBuilders.boolQuery();
        BoolQueryBuilder should = QueryBuilders.boolQuery();
        should.should(QueryBuilders.matchPhraseQuery("_id", id));
        Date date = new Date();//当前时间
        Calendar calendar = new GregorianCalendar();
        calendar.setTime(date);
        calendar.add(Calendar.DAY_OF_MONTH, -2);
        Date startDate = calendar.getTime();
        RangeQueryBuilder rangeQueryBuilder = QueryBuilders.rangeQuery(LogConstants.SPARK_TIME_TAG);
        rangeQueryBuilder.gt(DateUtils.getSparkTime(startDate));
        boolBuilder.filter(rangeQueryBuilder);
        boolBuilder.filter(should);
        return boolBuilder;
    }
    public static void main(String[] args) {
        System.out.println(buildQueryBuilder("11"));
    }
}
