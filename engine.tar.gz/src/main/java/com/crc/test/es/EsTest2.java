package com.crc.test.es;

import com.crc.secface.config.ElasticsearchProperties;
import com.crc.secface.es.EsSingleFactory;
import lombok.extern.slf4j.Slf4j;
import org.elasticsearch.action.admin.indices.alias.get.GetAliasesRequest;
import org.elasticsearch.action.admin.indices.segments.IndicesSegmentsRequest;
import org.elasticsearch.action.admin.indices.settings.get.GetSettingsResponse;
import org.elasticsearch.action.search.SearchRequest;
import org.elasticsearch.action.search.SearchResponse;
import org.elasticsearch.client.GetAliasesResponse;
import org.elasticsearch.client.RequestOptions;
import org.elasticsearch.client.RestHighLevelClient;
import org.elasticsearch.client.indices.GetIndexRequest;
import org.elasticsearch.client.indices.GetIndexResponse;
import org.elasticsearch.cluster.metadata.AliasMetaData;
import org.elasticsearch.cluster.metadata.MappingMetaData;
import org.elasticsearch.common.settings.Settings;
import org.elasticsearch.search.builder.SearchSourceBuilder;

import java.util.List;
import java.util.Map;


@Slf4j
public class EsTest2 {
    public static void main(String[] args) {
        EsSingleFactory factory = EsSingleFactory.getInstance();
        RestHighLevelClient restHighLevelClient = factory.getHighLevelClient(newEsProperty());
        try {
            //GetAliasesResponse resp = restHighLevelClient.indices().getAlias(new GetAliasesRequest(), RequestOptions.DEFAULT);
            GetIndexResponse getIndexResponse = restHighLevelClient.indices().get(new GetIndexRequest("sec_all-2023.05.31"), RequestOptions.DEFAULT);
            //查询的返回状态
            Map<String, List<AliasMetaData>> aliases = getIndexResponse.getAliases();
            Map<String, MappingMetaData> mappings = getIndexResponse.getMappings();
            Map<String, Settings> settings = getIndexResponse.getSettings();
            System.out.println("aliases："+aliases);
            System.out.println("mappings："+mappings);
            System.out.println("settings："+settings);
        } catch (Exception e) {
            log.error(e.getMessage(),e);
        } finally {
            factory.close(restHighLevelClient);
        }
    }

    public static void mainx(String[] args) {
        SearchSourceBuilder sourceBuilder = new SearchSourceBuilder();
        EsSingleFactory factory = EsSingleFactory.getInstance();
        RestHighLevelClient restHighLevelClient = factory.getHighLevelClient(newEsProperty());
        try {
            sourceBuilder.size(0);
            sourceBuilder.trackTotalHits(true);
            SearchRequest searchRequest = new SearchRequest("sec_all-2023.05.31");
            searchRequest.source(sourceBuilder);
            SearchResponse response = restHighLevelClient.search(searchRequest, RequestOptions.DEFAULT);
            System.out.println(response.getHits().totalHits);
        } catch (Exception e) {
            log.error(e.getMessage(),e);
        } finally {
            factory.close(restHighLevelClient);
        }
    }

    public static ElasticsearchProperties newEsProperty() {
        ElasticsearchProperties esProperty = new ElasticsearchProperties();
        esProperty.setHost("sec_es_test.crc.com.cn");
        esProperty.setPassword("w9Mu1qL0J5juVZttuFDt");
        esProperty.setUserName("elastic");
        esProperty.setPort(80);
        esProperty.setSchema("http");
        esProperty.setProxyHeader("8994b14fd0ba4c5fabef5e6851a38c56");
        return esProperty;
    }
}
