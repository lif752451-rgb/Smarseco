package com.crc.test.es;

import com.crc.common.paser.KqlParser;
import com.crc.common.paser.KqlResult;
import com.crc.secface.config.ElasticsearchProperties;
import com.crc.secface.es.EsSingleFactory;
import lombok.extern.slf4j.Slf4j;
import org.elasticsearch.action.search.SearchRequest;
import org.elasticsearch.action.search.SearchResponse;
import org.elasticsearch.client.RequestOptions;
import org.elasticsearch.client.RestHighLevelClient;
import org.elasticsearch.index.query.BoolQueryBuilder;
import org.elasticsearch.index.query.QueryBuilders;
import org.elasticsearch.search.SearchHit;
import org.elasticsearch.search.SearchHits;
import org.elasticsearch.search.builder.SearchSourceBuilder;
import org.elasticsearch.search.sort.FieldSortBuilder;
import org.elasticsearch.search.sort.SortOrder;


@Slf4j
public class EsTest1 {
    public static void main(String[] args) {
        KqlParser kqlParser = new KqlParser("1");
        String x = "src_ip_type.keyword : \"内网\" and dest_ip_type.keyword : \"内网\" and (dest_port.keyword: \"22\" or dest_port.keyword: \"23\" or dest_port.keyword: \"135\" or dest_port.keyword: \"445\" or dest_port.keyword: \"389\" or dest_port.keyword: \"3389\"  or dest_port.keyword: \"7001\" or dest_port.keyword: \"3306\"  or dest_port.keyword: \"1099\" or dest_port.keyword: \"1433\" or dest_port.keyword: \"1521\" or dest_port.keyword: \"3873\"  or dest_port.keyword: \"4446\" or dest_port.keyword: \"5985\" or dest_port.keyword: \"6379\" or dest_port.keyword: \"27017\" or dest_port.keyword: \"2375\" or dest_port.keyword: \"5900\" or dest_port.keyword: \"5432\" or dest_port.keyword: \"4899\" or dest_port.keyword: \"20880\") ";
        x = "src_ip_type.keyword : \"内网\" and dest_ip_type.keyword : \"内网\" and dest_port.keyword in (\"22#23#135#445#389#3389#7001#3306#1099#1433#1521#3873#4446#5985#6379#27017#2375#5900#5432#4899#20880\")";
        System.out.println(x);
        KqlResult result = kqlParser.parse(x);
        //String []times = DateUtils.resolveTimeByMinusHours(new Date(), 240);
        SearchSourceBuilder sourceBuilder = new SearchSourceBuilder();
        EsSingleFactory factory = EsSingleFactory.getInstance();
        RestHighLevelClient restHighLevelClient = factory.getHighLevelClient(newEsProperty());
        try {
            BoolQueryBuilder boolBuilder = QueryBuilders.boolQuery();
            boolBuilder.filter(result.getQuery());
            sourceBuilder.size(10);
            sourceBuilder.sort(new FieldSortBuilder("SparkTime").order(SortOrder.DESC));
//            RangeQueryBuilder rangeQueryBuilder = QueryBuilders.rangeQuery("SparkTime");
//            rangeQueryBuilder.gte(times[1]);
//            rangeQueryBuilder.lte(times[1]);
//            boolBuilder.should(rangeQueryBuilder).minimumShouldMatch(1);
            sourceBuilder.query(boolBuilder);
            //log.info(sourceBuilder.query().toString());
            SearchRequest searchRequest = new SearchRequest("sec_all*");
            searchRequest.source(sourceBuilder);
           // log.info(sourceBuilder.toString());
            SearchResponse response = restHighLevelClient.search(searchRequest, RequestOptions.DEFAULT);
            SearchHits sh = response.getHits();
            for (SearchHit s : sh) {
                log.info(s.getSourceAsString());
            }
        } catch (Exception e) {
            log.error(e.getMessage(),e);
        } finally {
            factory.close(restHighLevelClient);
        }
    }

    public static ElasticsearchProperties newEsProperty() {
        ElasticsearchProperties esProperty = new ElasticsearchProperties();
        esProperty.setHost("sec_es_test.crc.com.cn");
        esProperty.setPassword("w9Mu1qL0J5juVZttuFDt");
        esProperty.setUserName("elastic");
        esProperty.setPort(80);
        esProperty.setSchema("http");
        esProperty.setProxyHeader("8994b14fd0ba4c5fabef5e6851a38c56");
        return esProperty;
    }
}
