package com.crc.test.es;

import com.alibaba.fastjson.JSON;
import com.crc.common.constants.LogConstantsX;
import com.crc.common.utils.EsUtils;
import com.crc.common.utils.JsonUtils;
import com.crc.common.utils.Md5Utils;
import com.crc.common.utils.StringUtils;
import com.crc.secface.config.ElasticsearchProperties;
import com.crc.secface.es.EsSingleFactory;
import lombok.extern.slf4j.Slf4j;
import org.elasticsearch.action.search.SearchRequest;
import org.elasticsearch.action.search.SearchResponse;
import org.elasticsearch.action.search.SearchScrollRequest;
import org.elasticsearch.client.RequestOptions;
import org.elasticsearch.client.RestHighLevelClient;
import org.elasticsearch.common.unit.TimeValue;
import org.elasticsearch.search.Scroll;
import org.elasticsearch.search.SearchHit;
import org.elasticsearch.search.builder.SearchSourceBuilder;
import org.elasticsearch.search.sort.SortOrder;

import java.io.IOException;
import java.util.Map;


@Slf4j
public class EsScrollTest1 {
    /**
     * scroll有效时间
     */
    public final static TimeValue SCROLL_KEEP_ALIVE = TimeValue.timeValueMinutes(5);

    /**
     * 300s 超时
     */
    public final static TimeValue TIMEOUT_5_MINUTES = TimeValue.timeValueSeconds(300);	// 300s 超时
    public static void main(String[] args) {
        RestHighLevelClient restHighLevelClient = EsSingleFactory.getInstance().getHighLevelClient(newEsProperty());
        SearchSourceBuilder searchSourceBuilder = new SearchSourceBuilder();
        SearchRequest request = new SearchRequest("sec_all-*");
        searchSourceBuilder.sort(LogConstantsX.LOG_TIME, SortOrder.DESC);
        searchSourceBuilder.size(50);
        searchSourceBuilder.trackTotalHits(true);
        //将滚动放入
        String scrollId = "";//FGluY2x1ZGVfY29udGV4dF91dWlkDnF1ZXJ5VGhlbkZldGNoFxYwU0xvM3FjUFJoeTlaSGs3cHdnN0RnAAAAAAAtPZIWRC1wM3YybXlTZ2ktSFcybWNBYjVndxZWVmR4eGxCeFFtdU1rNmdjVE8tVF9BAAAAAAASVJMWZUNMaVpTZ3ZRWjZOX1VZTjJwTzAwURYwU0xvM3FjUFJoeTlaSGs3cHdnN0RnAAAAAAAtPZEWRC1wM3YybXlTZ2ktSFcybWNBYjVndxYwU0xvM3FjUFJoeTlaSGs3cHdnN0RnAAAAAAAtPZAWRC1wM3YybXlTZ2ktSFcybWNBYjVndxZWVmR4eGxCeFFtdU1rNmdjVE8tVF9BAAAAAAASVJQWZUNMaVpTZ3ZRWjZOX1VZTjJwTzAwURZ6VDJXUmtFOFNTTzFtcmZMMzZvdVNRAAAAAAAHSbUWSUdkMWdZMVJTY09HV0hCSkJwdjRLQRYwU0xvM3FjUFJoeTlaSGs3cHdnN0RnAAAAAAAtPY8WRC1wM3YybXlTZ2ktSFcybWNBYjVndxZ6VDJXUmtFOFNTTzFtcmZMMzZvdVNRAAAAAAAHSbQWSUdkMWdZMVJTY09HV0hCSkJwdjRLQRYwU0xvM3FjUFJoeTlaSGs3cHdnN0RnAAAAAAAtPY4WRC1wM3YybXlTZ2ktSFcybWNBYjVndxZWVmR4eGxCeFFtdU1rNmdjVE8tVF9BAAAAAAASVJIWZUNMaVpTZ3ZRWjZOX1VZTjJwTzAwURYwU0xvM3FjUFJoeTlaSGs3cHdnN0RnAAAAAAAtPY0WRC1wM3YybXlTZ2ktSFcybWNBYjVndxYwU0xvM3FjUFJoeTlaSGs3cHdnN0RnAAAAAAAtPYwWRC1wM3YybXlTZ2ktSFcybWNBYjVndxYwU0xvM3FjUFJoeTlaSGs3cHdnN0RnAAAAAAAtPYoWRC1wM3YybXlTZ2ktSFcybWNBYjVndxZ6VDJXUmtFOFNTTzFtcmZMMzZvdVNRAAAAAAAHSbIWSUdkMWdZMVJTY09HV0hCSkJwdjRLQRZWVmR4eGxCeFFtdU1rNmdjVE8tVF9BAAAAAAASVJUWZUNMaVpTZ3ZRWjZOX1VZTjJwTzAwURYwU0xvM3FjUFJoeTlaSGs3cHdnN0RnAAAAAAAtPYsWRC1wM3YybXlTZ2ktSFcybWNBYjVndxYwU0xvM3FjUFJoeTlaSGs3cHdnN0RnAAAAAAAtPYkWRC1wM3YybXlTZ2ktSFcybWNBYjVndxZ6VDJXUmtFOFNTTzFtcmZMMzZvdVNRAAAAAAAHSbMWSUdkMWdZMVJTY09HV0hCSkJwdjRLQRYwU0xvM3FjUFJoeTlaSGs3cHdnN0RnAAAAAAAtPYgWRC1wM3YybXlTZ2ktSFcybWNBYjVndxZ6VDJXUmtFOFNTTzFtcmZMMzZvdVNRAAAAAAAHSbEWSUdkMWdZMVJTY09HV0hCSkJwdjRLQRZWVmR4eGxCeFFtdU1rNmdjVE8tVF9BAAAAAAASVJEWZUNMaVpTZ3ZRWjZOX1VZTjJwTzAwURYwU0xvM3FjUFJoeTlaSGs3cHdnN0RnAAAAAAAtPYcWRC1wM3YybXlTZ2ktSFcybWNBYjVndxZ6VDJXUmtFOFNTTzFtcmZMMzZvdVNRAAAAAAAHSbYWSUdkMWdZMVJTY09HV0hCSkJwdjRLQQ==";//""FGluY2x1ZGVfY29udGV4dF91dWlkDnF1ZXJ5VGhlbkZldGNoFxYwU0xvM3FjUFJoeTlaSGs3cHdnN0RnAAAAAAAtLsAWRC1wM3YybXlTZ2ktSFcybWNBYjVndxZWVmR4eGxCeFFtdU1rNmdjVE8tVF9BAAAAAAASTFsWZUNMaVpTZ3ZRWjZOX1VZTjJwTzAwURYwU0xvM3FjUFJoeTlaSGs3cHdnN0RnAAAAAAAtLr8WRC1wM3YybXlTZ2ktSFcybWNBYjVndxYwU0xvM3FjUFJoeTlaSGs3cHdnN0RnAAAAAAAtLr4WRC1wM3YybXlTZ2ktSFcybWNBYjVndxZWVmR4eGxCeFFtdU1rNmdjVE8tVF9BAAAAAAASTF4WZUNMaVpTZ3ZRWjZOX1VZTjJwTzAwURZ6VDJXUmtFOFNTTzFtcmZMMzZvdVNRAAAAAAAHSBoWSUdkMWdZMVJTY09HV0hCSkJwdjRLQRYwU0xvM3FjUFJoeTlaSGs3cHdnN0RnAAAAAAAtLr0WRC1wM3YybXlTZ2ktSFcybWNBYjVndxZ6VDJXUmtFOFNTTzFtcmZMMzZvdVNRAAAAAAAHSBkWSUdkMWdZMVJTY09HV0hCSkJwdjRLQRYwU0xvM3FjUFJoeTlaSGs3cHdnN0RnAAAAAAAtLrwWRC1wM3YybXlTZ2ktSFcybWNBYjVndxZWVmR4eGxCeFFtdU1rNmdjVE8tVF9BAAAAAAASTF0WZUNMaVpTZ3ZRWjZOX1VZTjJwTzAwURYwU0xvM3FjUFJoeTlaSGs3cHdnN0RnAAAAAAAtLrsWRC1wM3YybXlTZ2ktSFcybWNBYjVndxYwU0xvM3FjUFJoeTlaSGs3cHdnN0RnAAAAAAAtLroWRC1wM3YybXlTZ2ktSFcybWNBYjVndxYwU0xvM3FjUFJoeTlaSGs3cHdnN0RnAAAAAAAtLrkWRC1wM3YybXlTZ2ktSFcybWNBYjVndxZ6VDJXUmtFOFNTTzFtcmZMMzZvdVNRAAAAAAAHSBgWSUdkMWdZMVJTY09HV0hCSkJwdjRLQRZWVmR4eGxCeFFtdU1rNmdjVE8tVF9BAAAAAAASTFwWZUNMaVpTZ3ZRWjZOX1VZTjJwTzAwURYwU0xvM3FjUFJoeTlaSGs3cHdnN0RnAAAAAAAtLrgWRC1wM3YybXlTZ2ktSFcybWNBYjVndxYwU0xvM3FjUFJoeTlaSGs3cHdnN0RnAAAAAAAtLrYWRC1wM3YybXlTZ2ktSFcybWNBYjVndxZ6VDJXUmtFOFNTTzFtcmZMMzZvdVNRAAAAAAAHSBcWSUdkMWdZMVJTY09HV0hCSkJwdjRLQRYwU0xvM3FjUFJoeTlaSGs3cHdnN0RnAAAAAAAtLrcWRC1wM3YybXlTZ2ktSFcybWNBYjVndxZ6VDJXUmtFOFNTTzFtcmZMMzZvdVNRAAAAAAAHSBYWSUdkMWdZMVJTY09HV0hCSkJwdjRLQRZWVmR4eGxCeFFtdU1rNmdjVE8tVF9BAAAAAAASTFoWZUNMaVpTZ3ZRWjZOX1VZTjJwTzAwURYwU0xvM3FjUFJoeTlaSGs3cHdnN0RnAAAAAAAtLrUWRC1wM3YybXlTZ2ktSFcybWNBYjVndxZ6VDJXUmtFOFNTTzFtcmZMMzZvdVNRAAAAAAAHSBsWSUdkMWdZMVJTY09HV0hCSkJwdjRLQQ==";
        request.scroll(TIMEOUT_5_MINUTES);
        SearchResponse search = null;
        try {
            request.source(searchSourceBuilder);
            SearchHit[] hits = new SearchHit[0];
            long total = 0;
            if (StringUtils.isBlank(scrollId)) {
                try {
                    search = restHighLevelClient.search(request, RequestOptions.DEFAULT);
                    /*
                     * list
                     */
                    hits = search.getHits().getHits();
                    total =  search.getHits().getTotalHits();
                    scrollId = search.getScrollId();
                } catch (Exception e) {
                    log.error(e.getMessage(), e);
                }
            } else {
                SearchScrollRequest searchScrollRequest = new SearchScrollRequest(scrollId);
                log.info("构造滚动查询条件");
                searchScrollRequest.scroll(TIMEOUT_5_MINUTES);
                try {
                    //响应必须是上面的响应对象，需要对上一层进行覆盖
                    search = restHighLevelClient.scroll(searchScrollRequest, RequestOptions.DEFAULT);
                    hits = search.getHits().getHits();
                    total =  search.getHits().getTotalHits();
                    scrollId = search.getScrollId();
                } catch (IOException e) {
                    log.error(e.getMessage(), e);
                }
            }
            if (hits != null) {
                for (SearchHit hit : hits) {
                    Map<String, Object> sourceAsMap = hit.getSourceAsMap();
                    System.out.println(JSON.toJSONString(sourceAsMap));
                    JsonUtils.print(hit.getSortValues());
                }
            } else {
                log.error("获取数据=0");
            }
            System.out.println(total);
            System.out.println(Md5Utils.hash(scrollId));
            System.out.println(scrollId);
        } catch (Exception e) {
            log.error(e.getMessage(), e);
        } finally {
            //EsUtils.cleanScrollId(restHighLevelClient, scrollId);
            EsSingleFactory.getInstance().close(restHighLevelClient);
        }
    }

    public static ElasticsearchProperties newEsProperty() {
        ElasticsearchProperties esProperty = new ElasticsearchProperties();
        esProperty.setHost("sec_es_test.crc.com.cn");
        esProperty.setPassword("w9Mu1qL0J5juVZttuFDt");
        esProperty.setUserName("elastic");
        esProperty.setPort(80);
        esProperty.setSchema("http");
        esProperty.setProxyHeader("8994b14fd0ba4c5fabef5e6851a38c56");
        return esProperty;
    }
}
