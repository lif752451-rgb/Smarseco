package com.crc.test.es;

import com.crc.common.paser.KqlParser;
import com.crc.common.paser.KqlResult;
import com.crc.common.utils.JsonUtils;
import com.crc.secface.config.ElasticsearchProperties;
import com.crc.secface.es.EsSingleFactory;
import lombok.extern.slf4j.Slf4j;
import org.elasticsearch.action.search.SearchRequest;
import org.elasticsearch.action.search.SearchResponse;
import org.elasticsearch.client.RequestOptions;
import org.elasticsearch.client.Requests;
import org.elasticsearch.client.RestHighLevelClient;
import org.elasticsearch.common.Strings;
import org.elasticsearch.common.settings.Settings;
import org.elasticsearch.common.xcontent.*;
import org.elasticsearch.common.xcontent.json.JsonXContent;
import org.elasticsearch.index.query.BoolQueryBuilder;
import org.elasticsearch.index.query.QueryBuilders;
import org.elasticsearch.search.SearchHit;
import org.elasticsearch.search.SearchHits;
import org.elasticsearch.search.SearchModule;
import org.elasticsearch.search.builder.SearchSourceBuilder;
import org.elasticsearch.search.sort.FieldSortBuilder;
import org.elasticsearch.search.sort.SortOrder;

import java.util.Collections;


@Slf4j
public class EsTest11 {
    private static final NamedXContentRegistry xContentRegistry;

    static {
        SearchModule searchModule =
                new SearchModule(Settings.EMPTY, false, Collections.emptyList());

        xContentRegistry =
                new NamedXContentRegistry(searchModule.getNamedXContents());
    }
    public static void main(String[] args) {
        String dsl = "{\n" +
                "  \"aggs\": {\n" +
                "    \"name\": {\n" +
                "      \"terms\": {\n" +
                "        \"field\": \"log_level.keyword\",\n" +
                "        \"order\": {\n" +
                "          \"_count\": \"desc\"\n" +
                "        },\n" +
                "        \"size\": 5\n" +
                "      }\n" +
                "    }\n" +
                "  },\n" +
                "  \"size\": 0,\n" +
                "  \"stored_fields\": [\n" +
                "    \"*\"\n" +
                "  ],\n" +
                "  \"script_fields\": {},\n" +
                "  \"docvalue_fields\": [\n" +
                "    {\n" +
                "      \"field\": \"SparkTime\",\n" +
                "      \"format\": \"date_time\"\n" +
                "    },\n" +
                "    {\n" +
                "      \"field\": \"alert_time\",\n" +
                "      \"format\": \"date_time\"\n" +
                "    },\n" +
                "    {\n" +
                "      \"field\": \"log_start_time\",\n" +
                "      \"format\": \"date_time\"\n" +
                "    }\n" +
                "  ],\n" +
                "  \"_source\": {\n" +
                "    \"excludes\": []\n" +
                "  },\n" +
                "  \"query\": {\n" +
                "    \"bool\": {\n" +
                "      \"must\": [],\n" +
                "      \"filter\": [\n" +
                "        {\n" +
                "          \"match_all\": {}\n" +
                "        },\n" +
                "        {\n" +
                "          \"bool\": {\n" +
                "            \"should\": [\n" +
                "              {\n" +
                "                \"match_phrase\": {\n" +
                "                  \"log_level.keyword\": \"低风险\"\n" +
                "                }\n" +
                "              },\n" +
                "              {\n" +
                "                \"match_phrase\": {\n" +
                "                  \"log_level.keyword\": \"中风险\"\n" +
                "                }\n" +
                "              },\n" +
                "              {\n" +
                "                \"match_phrase\": {\n" +
                "                  \"log_level.keyword\": \"高风险\"\n" +
                "                }\n" +
                "              },\n" +
                "              {\n" +
                "                \"match_phrase\": {\n" +
                "                  \"log_level.keyword\": \"信息\"\n" +
                "                }\n" +
                "              }\n" +
                "            ],\n" +
                "            \"minimum_should_match\": 1\n" +
                "          }\n" +
                "        },\n" +
                "        {\n" +
                "          \"range\": {\n" +
                "            \"SparkTime\": {\n" +
                "              \"gte\": \"2023-05-30T16:28:47\",\n" +
                "              \"lte\": \"2023-06-07T16:28:47\",\n" +
                "              \"format\": \"strict_date_optional_time\"\n" +
                "            }\n" +
                "          }\n" +
                "        }\n" +
                "      ],\n" +
                "      \"should\": [],\n" +
                "      \"must_not\": []\n" +
                "    }\n" +
                "  }\n" +
                "}";

        EsSingleFactory factory = EsSingleFactory.getInstance();
        RestHighLevelClient restHighLevelClient = factory.getHighLevelClient(newEsProperty());
        try {

            XContentParser parser =
                    XContentType.JSON.xContent().createParser(xContentRegistry,
                            LoggingDeprecationHandler.INSTANCE,
                            dsl);

            SearchSourceBuilder sourceBuilder = SearchSourceBuilder.fromXContent(parser);
            System.out.println(sourceBuilder);
            SearchRequest searchRequest = new SearchRequest("sec_all*");
            searchRequest.source(sourceBuilder);
            SearchResponse response = restHighLevelClient.search(searchRequest, RequestOptions.DEFAULT);
            System.out.println(response.toString());
        } catch (Exception e) {
            log.error(e.getMessage(),e);
        } finally {
            factory.close(restHighLevelClient);
        }
    }

    public static ElasticsearchProperties newEsProperty() {
        ElasticsearchProperties esProperty = new ElasticsearchProperties();
        esProperty.setHost("sec_es_test.crc.com.cn");
        esProperty.setPassword("w9Mu1qL0J5juVZttuFDt");
        esProperty.setUserName("elastic");
        esProperty.setPort(80);
        esProperty.setSchema("http");
        esProperty.setProxyHeader("8994b14fd0ba4c5fabef5e6851a38c56");
        return esProperty;
    }
}
