package com.crc.test;

import org.elasticsearch.index.query.BoolQueryBuilder;
import org.elasticsearch.index.query.QueryBuilders;

public class EsTest22 {
    public static void main(String[] args) {
        BoolQueryBuilder boolQuery = QueryBuilders.boolQuery();
        System.out.println(isBlankQuery(boolQuery));
    }


    public static boolean isBlankQuery(BoolQueryBuilder queryBuilder) {
        if (queryBuilder == null) {
            return true;
        }
        if(queryBuilder.should().size() < 1 && queryBuilder.filter().size() < 1 && queryBuilder.mustNot().size() < 1 && queryBuilder.must().size() < 1)
            return true;

        return false;
    }
}
