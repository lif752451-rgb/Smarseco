package com.crc.test;

import com.crc.common.utils.IpUtils;
import com.crc.sync.net.NewSegmentLoad;

public class IpTet {
    public static void main(String[] args) {
        System.out.println(IpUtils.isInternetIP("113.89.250.226"));
        System.out.println(IpUtils.isInternetIP("0.0.0.0"));
        System.out.println(NewSegmentLoad.isBelongThisSegment("113.89.250.226","113.89.250.226"));
    }
}
