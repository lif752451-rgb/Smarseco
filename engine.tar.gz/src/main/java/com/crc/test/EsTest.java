package com.crc.test;

import com.crc.common.constants.LogConstants;
import com.crc.common.constants.LogConstantsX;
import com.crc.secface.config.ElasticsearchProperties;
import com.crc.secface.es.EsSingleFactory;
import lombok.extern.slf4j.Slf4j;
import org.elasticsearch.action.search.SearchRequest;
import org.elasticsearch.action.search.SearchResponse;
import org.elasticsearch.client.RequestOptions;
import org.elasticsearch.client.RestHighLevelClient;
import org.elasticsearch.index.query.BoolQueryBuilder;
import org.elasticsearch.index.query.QueryBuilders;
import org.elasticsearch.search.SearchHit;
import org.elasticsearch.search.SearchHits;
import org.elasticsearch.search.builder.SearchSourceBuilder;
import org.elasticsearch.search.sort.FieldSortBuilder;
import org.elasticsearch.search.sort.SortOrder;

@Slf4j
public class EsTest {
    public static void main(String[] args) {
        SearchSourceBuilder sourceBuilder = new SearchSourceBuilder();
        sourceBuilder.from(0);
        sourceBuilder.size(10);
        sourceBuilder.sort(new FieldSortBuilder(LogConstants.SPARK_TIME_TAG).order(SortOrder.DESC));
        EsSingleFactory factory = EsSingleFactory.getInstance();
        RestHighLevelClient restHighLevelClient = factory.getHighLevelClient(newEsProperty());
        try {

            BoolQueryBuilder boolBuilder = QueryBuilders.boolQuery();
            boolBuilder.must(QueryBuilders.matchPhraseQuery(LogConstantsX.SRC_IP, "10.128.63.102"));
            //boolBuilder.must(QueryBuilders.matchPhraseQuery(LogConstantsX.LOG_LEVEL,"中风险"));
            sourceBuilder.query(boolBuilder);
            SearchRequest searchRequest = new SearchRequest("sec_all*");
            searchRequest.source(sourceBuilder);
            SearchResponse response = restHighLevelClient.search(searchRequest, RequestOptions.DEFAULT);
            SearchHits sh = response.getHits();
            Object[] sorts = null;
            for (SearchHit s : sh) {
                log.info(s.getSourceAsString());
            }
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            factory.close(restHighLevelClient);
        }
    }


    public static ElasticsearchProperties newEsProperty() {
        ElasticsearchProperties esProperty = new ElasticsearchProperties();
        esProperty.setHost("elscffdfcfe7f134d7b960ed1a94b844e86.els-elasticsearch.crcloud.com");
        esProperty.setPassword("w45q1fce6Hfe81d1dr8SQ4N1");
        esProperty.setUserName("elastic");
        esProperty.setPort(80);
        esProperty.setSchema("http");
        esProperty.setProxyHeader("8994b14fd0ba4c5fabef5e6851a38c56");
        return esProperty;
    }
}
