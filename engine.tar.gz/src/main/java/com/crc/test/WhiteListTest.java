package com.crc.test;

import com.alibaba.fastjson.JSONObject;
import com.crc.common.constants.LogConstantsX;
import com.crc.common.utils.DateUtils;
import com.crc.common.utils.JsonUtils;
import com.crc.secface.config.ElasticsearchProperties;
import com.crc.secface.entity.TbAlarmWhitelist;
import com.crc.secface.entity.TbEventModel;
import com.crc.secface.service.WhitelistService;
import org.apache.commons.lang3.StringUtils;

import java.util.LinkedList;
import java.util.List;

public class WhiteListTest {
    public static void main(String[] args) throws Exception {
        String jsonStr = "{\"action_rule\":\"urlpath\",\"dev_sub_branch\":\"运管区\",\"referer\":\"\",\"src_ip_type\":\"外网\",\"status_code\":\"\",\"real_src_ip\":\"2408:8340:c40:4ae0:c1a7:5fad:2801:aa6c\\\\\\\\r\\\\\\\\n\\\\\\\\r\\\\\\\\n\\\"\",\"action_type\":\"backdoor\",\"action_result\":\"拦截\",\"event_description\":\"\",\"dev_asset_office\":\"华润数科\",\"dev_instance\":\"IT技术服务部_网信安全_web应用安全防火墙\",\"ip_score\":1,\"src_ip\":\"2408:8340:c40:4ae0:c1a7:5fad:2801:aa6c\",\"log_start_time\":\"2024-01-25 10:40:04.259+0800\",\"update_time\":\"1706150404\",\"http_method\":\"GET\",\"engine\":\"m_rule/9bf31c7ff062936a96d3c8bd1f8f2ff3\",\"dev_branch\":\"汕尾数据中心\",\"zlog_ori_msg\":\"<30>Jan 25 10:40:04 jtscanvpwa05 safeline_event[1]: {\\\"action\\\":\\\"deny\\\",\\\"attack_type\\\":\\\"backdoor\\\",\\\"body\\\":\\\"\\\",\\\"cookie\\\":\\\"JSESSIONID=JJ8RlxJGs2h1qk9Lr93l0Jn0MtyqGpk3pfNntfQRwqSZPrDQKMGC!-1242259133!-190027996\\\",\\\"country\\\":\\\"CN\\\",\\\"decode_path\\\":\\\"\\\",\\\"dest_ip\\\":\\\"2406:440:400:8eda:0:8:1000:4\\\",\\\"dest_port\\\":6001,\\\"event_id\\\":\\\"e426602f525a47fda3383bddf53d5ab7\\\",\\\"host\\\":\\\"hrac.crc.com.cn\\\",\\\"location\\\":\\\"urlpath\\\",\\\"method\\\":\\\"GET\\\",\\\"module\\\":\\\"m_rule\\\",\\\"node\\\":\\\"jtscanvpwa04\\\",\\\"payload\\\":\\\"\\\",\\\"protocol\\\":\\\"http\\\",\\\"province\\\":\\\"\\\",\\\"reason\\\":\\\"后门\\\",\\\"referer\\\":\\\"\\\",\\\"req_header_raw\\\":\\\"GET /crac/WebShell.cgi HTTP/1.1\\\\\\\\r\\\\\\\\nHost: hrac.crc.com.cn\\\\\\\\r\\\\\\\\nuser-agent: Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/87.0.4280.88 Safari/537.36\\\\\\\\r\\\\\\\\nAccept-Encoding: gzip, deflate\\\\\\\\r\\\\\\\\naccept: */*\\\\\\\\r\\\\\\\\nConnection: keep-alive\\\\\\\\r\\\\\\\\naccept-rncoding: *\\\\\\\\r\\\\\\\\nkeep-alive: timeout=15, max=1000\\\\\\\\r\\\\\\\\ncache-control: max-age=0\\\\\\\\r\\\\\\\\nCookie: JSESSIONID=JJ8RlxJGs2h1qk9Lr93l0Jn0MtyqGpk3pfNntfQRwqSZPrDQKMGC!-1242259133!-190027996\\\\\\\\r\\\\\\\\nX-Forwarded-For: 2408:8340:c40:4ae0:c1a7:5fad:2801:aa6c\\\\\\\\r\\\\\\\\n\\\\\\\\r\\\\\\\\n\\\",\\\"resp_body\\\":\\\"\\\",\\\"resp_header_raw\\\":\\\"\\\",\\\"resp_reason_phrase\\\":\\\"\\\",\\\"resp_status_code\\\":\\\"\\\",\\\"risk_level\\\":\\\"high\\\",\\\"rule_id\\\":\\\"m_rule/9bf31c7ff062936a96d3c8bd1f8f2ff3\\\",\\\"selector_id\\\":\\\"\\\",\\\"session\\\":\\\"\\\",\\\"src_ip\\\":\\\"2408:8340:c40:4ae0:c1a7:5fad:2801:aa6c\\\",\\\"src_port\\\":34069,\\\"timestamp\\\":1706150404,\\\"timestamp_human\\\":\\\"2024-01-25 10:40:04\\\",\\\"urlpath\\\":\\\"/crac/WebShell.cgi\\\",\\\"user_agent\\\":\\\"Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/87.0.4280.88 Safari/537.36\\\"}\",\"host\":\"hrac.crc.com.cn\",\"dest_ip_type\":\"外网\",\"es_index\":\"sec_all\",\"dest_port\":\"6001\",\"user_agent\":\"Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/87.0.4280.88 Safari/537.36\",\"nxlog_index\":\"sec_all\",\"product\":\"慧眼SSP\",\"cookie\":\"JSESSIONID=JJ8RlxJGs2h1qk9Lr93l0Jn0MtyqGpk3pfNntfQRwqSZPrDQKMGC!-1242259133!-190027996\",\"log_name\":\"IPv6同源外网高风险攻击行为\",\"log_level\":\"高风险\",\"attack_result_id\":\"0\",\"protocal\":\"http\",\"url\":\"/crac/WebShell.cgi\",\"SparkTime\":\"2024-01-25T10:40:04.000+0800\",\"risk_ip\":\"2408:8340:c40:4ae0:c1a7:5fad:2801:aa6c\",\"ori_event_id\":\"202401251042172420235\",\"src_port\":\"34069\",\"event_content\":\"\",\"bus_model\":\"SSP-WO7VINIU\",\"log_count\":0,\"is_whitelist\":\"0\",\"src_country\":\"CN\",\"es_log_name\":\"IPv6同源外网高风险攻击行为\",\"dest_ip\":\"0.0.0.0\",\"ids\":\"bKl9Po0Bc-VyX3JRLmZm,3al9Po0Bc-VyX3JRIWR9,Mnl9Po0BIQxDBJm5Lc1G,z3l9Po0BIQxDBJm5F8lA,6q59Po0BaxddNFV9E1mR,OUl9Po0BVjHu7I2xEL07,PO59Po0B3Nuio1EqEzrY,y6l9Po0Bc-VyX3JRAmHa,aUl9Po0BVjHu7I2xBLrH,5658Po0BaxddNFV9_lXb,Ajl8Po0BAcwmZK8K_qba,EHl8Po0BIQxDBJm5-sf3,D158Po0BgohunLxS-Fil,ia58Po0BaxddNFV96lHS,r158Po0BgohunLxS0FTC,o0l8Po0BVjHu7I2x3LLX,1Hl8Po0BIQxDBJm528RT,lTl8Po0BAcwmZK8KxZks,ljl8Po0BAcwmZK8KxZks,3al8Po0Bc-VyX3JRp1fO,ZKl8Po0Bc-VyX3JRr1iz,9jl8Po0BAcwmZK8KrpQ-,lkl8Po0BVjHu7I2xtapc,wkl8Po0BVjHu7I2xramh,_Hl8Po0BIQxDBJm5sr_9,u0l8Po0BVjHu7I2xramh,hu58Po0B3Nuio1EqqCYP,F3l8Po0BIQxDBJm5l7vm,ZUl8Po0BVjHu7I2xoaeu,qV58Po0BgohunLxSlVBq,BO58Po0B3Nuio1EqhR-L,M-58Po0B3Nuio1EqlCJK,pl58Po0BgohunLxShU9x,6q58Po0BaxddNFV9cDiK,ZDl8Po0BAcwmZK8KcYgL,Ol58Po0BgohunLxSa07E,Ou58Po0B3Nuio1EqbBup,1Ul8Po0BVjHu7I2xYpul,X0l8Po0BVjHu7I2xZpxK,o3l8Po0BIQxDBJm5YLZa,yF58Po0BgohunLxSV0yh,5u58Po0B3Nuio1EqWBeq,e0l8Po0BVjHu7I2xXZtF,H158Po0BgohunLxSXU3h,x158Po0BgohunLxSV0yh,GTl8Po0BAcwmZK8KVYP3,wK58Po0BaxddNFV9XDQK,2Tl8Po0BAcwmZK8KXIN7,ZO58Po0B3Nuio1EqXBr4,JEl8Po0BVjHu7I2xTphh\",\"dev_ip\":\"10.0.14.200\",\"alert_name\":\"【2408:8340:c40:4ae0:c1a7:5fad:2801:aa6c】近24小时对【2406:440:400:8eda:0:8:0:10,2406:440:400:8eda:0:8:1000:4等】发起372种攻击行为：[29001]Web服务远程SQL注入攻击可疑行为(startracker),[41499]HTTP请求敏感路径访问尝试,检测到 SQL 注入 攻击,访问系统文件的请求,[23984]Shell命令执行漏洞，来源设备为：绿盟IPS,奇安信天眼,长亭Waf，涉及域名：hracm.crc.com.cn,runjob-hunter.crc.com.cn,runjob.crc.com.cn,hrac.crc.com.cn，建议在边界防火墙上对IPv6地址【2408:8340:c40:4ae0:c1a7:5fad:2801:aa6c】进行封堵\",\"event_time\":\"2024-01-25 10:40:04.259+0800\",\"src_province\":\"\"}";
        JSONObject json = JsonUtils.parse(jsonStr);

        TbAlarmWhitelist wl = new TbAlarmWhitelist();
        wl.setSrcIp("*");
        wl.setTitle("111");
        wl.setWhitelistId("XXX");
        wl.setDestContent("0.0.0.0");
        wl.setIsGlobal("1");
        wl.setBusModel("");
        wl.setBusinessTerm("1");
        wl.setEffectTimeStart("00:00:00");
        wl.setEffectTimeEnd("23:59:59");
        List<TbAlarmWhitelist> list = new LinkedList<>();
        list.add(wl);
        //JsonUtils.print(wl);
        String startTime = JsonUtils.getStr(json, LogConstantsX.LOG_START_TIME);
        startTime = DateUtils.UTCToCSTAndCheck(startTime);
        if (StringUtils.isBlank(startTime)) {
            startTime = DateUtils.UTCToCST(JsonUtils.getStr(json, LogConstantsX.LOG_TIME));
        }
        json.put(LogConstantsX.EVENT_TIME, startTime);
        //JsonUtils.print(json);
        TbEventModel model = new TbEventModel();
        model.setModelName("态势感知检测到SMTP弱口令");
        model.setModelId("SSP-7XGD466D");
        boolean d = WhitelistService.isMatchV2(model, json, false);
        System.out.println(d);
    }

    public static ElasticsearchProperties newEsProperty() {
        ElasticsearchProperties esProperty = new ElasticsearchProperties();
        esProperty.setHost("sec_es_test.crc.com.cn");
        esProperty.setPassword("w9Mu1qL0J5juVZttuFDt");
        esProperty.setUserName("elastic");
        esProperty.setPort(80);
        esProperty.setSchema("http");
        esProperty.setProxyHeader("8994b14fd0ba4c5fabef5e6851a38c56");
        return esProperty;
    }
}
