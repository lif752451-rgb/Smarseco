package com.crc.test.http;

import com.alibaba.fastjson.JSONObject;
import com.baomidou.mybatisplus.core.toolkit.StringUtils;
import com.crc.common.utils.DateUtils;
import com.crc.common.utils.HttpUtils;
import com.crc.common.utils.JsonUtils;
import lombok.extern.slf4j.Slf4j;

import java.util.Collections;
import java.util.Date;
import java.util.HashMap;

@Slf4j
public class BlockTest {
    public static void main(String[] args) {
        String apiUrl = "http://localhost:8080/FireWall/unsealPublicIP";
        String remark = "{\"OpenApi\":\"fb10469b4db688655f30d91f02a7885d\"}";
        HashMap<String, String> headerMap = new HashMap<>();
        if (StringUtils.isNotBlank(remark)) {
            JSONObject jsonObject = JsonUtils.parse(remark);
            jsonObject.forEach((k, v) -> {
                try {
                    headerMap.put(k, v.toString());
                } catch (Exception e) {
                    log.error(e.getMessage(), e);
                }
            });
        }
        JSONObject json = new JSONObject();
        json.put("ip_list", Collections.singletonList("10.0.0.1"));
        json.put("expire_time", DateUtils.getDateTimeString1(new Date()));
        String ret = HttpUtils.sendPost(apiUrl, json.toJSONString(), headerMap);
        System.out.println(ret);
    }
}
