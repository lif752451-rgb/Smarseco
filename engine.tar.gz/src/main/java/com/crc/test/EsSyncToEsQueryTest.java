package com.crc.test;

import com.crc.common.constants.LogConstants;
import com.crc.common.constants.LogConstantsX;
import com.crc.common.utils.MyTheadUtils;
import com.crc.secface.config.ElasticsearchProperties;
import com.crc.secface.config.GetSpringBean;
import com.crc.secface.entity.LogData;
import com.crc.secface.es.EsSingleFactory;
import org.elasticsearch.action.search.SearchRequest;
import org.elasticsearch.action.search.SearchResponse;
import org.elasticsearch.client.RequestOptions;
import org.elasticsearch.client.RestHighLevelClient;
import org.elasticsearch.index.query.BoolQueryBuilder;
import org.elasticsearch.index.query.QueryBuilders;
import org.elasticsearch.search.SearchHit;
import org.elasticsearch.search.SearchHits;
import org.elasticsearch.search.builder.SearchSourceBuilder;
import org.elasticsearch.search.sort.FieldSortBuilder;
import org.elasticsearch.search.sort.SortOrder;

public class EsSyncToEsQueryTest extends Thread {
    public static int QUERY_SIZE = 300;

    public void run() {

        MyTheadUtils.sleepBySec(2);
//        (new MagicSendTest()).start();
        while (true) {

            MyTheadUtils.sleepBySec(10);
            try {
                query("sec_all-*");
            } catch (Exception e) {

            }

            MyTheadUtils.sleepBySec(60 * 60);
        }
    }

    public void query(String indexName) {
        SearchSourceBuilder sourceBuilder = new SearchSourceBuilder();
        sourceBuilder.from(0);
        sourceBuilder.size(QUERY_SIZE);
        sourceBuilder.sort(new FieldSortBuilder(LogConstants.SPARK_TIME_TAG).order(SortOrder.DESC));
        ElasticsearchProperties esProperty = GetSpringBean.getBean(ElasticsearchProperties.class);
        EsSingleFactory factory = EsSingleFactory.getInstance();
        RestHighLevelClient restHighLevelClient = factory.getHighLevelClient(esProperty);
        try {

            BoolQueryBuilder boolBuilder = QueryBuilders.boolQuery();
            boolBuilder.must(QueryBuilders.matchPhraseQuery(LogConstantsX.SRC_IP, "10.128.63.102"));
            //boolBuilder.must(QueryBuilders.matchPhraseQuery(LogConstantsX.LOG_LEVEL,"中风险"));
            sourceBuilder.query(boolBuilder);
            SearchRequest searchRequest = new SearchRequest(indexName);
            searchRequest.source(sourceBuilder);
            SearchResponse response = restHighLevelClient.search(searchRequest, RequestOptions.DEFAULT);
            SearchHits sh = response.getHits();
            Object[] sorts = null;
            for (SearchHit s : sh) {
                LogData log = new LogData();
                log.setId(s.getId());
                log.setData(s.getSourceAsString());
                log.setEsIndex(s.getIndex());
//                MagicSendTest.magicQueue.offer(log);
                sorts = s.getSortValues();
            }
            queryMore(indexName, sorts);
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            factory.close(restHighLevelClient);
        }
    }

    public void queryMore(String indexName, Object[] lastId) {
        if (lastId == null)
            return;
        SearchSourceBuilder sourceBuilder = new SearchSourceBuilder();
        sourceBuilder.from(0);
        sourceBuilder.size(QUERY_SIZE);
        sourceBuilder.searchAfter(lastId);
        sourceBuilder.sort(new FieldSortBuilder(LogConstants.SPARK_TIME_TAG).order(SortOrder.DESC));
        ElasticsearchProperties esProperty = GetSpringBean.getBean(ElasticsearchProperties.class);
        EsSingleFactory factory = EsSingleFactory.getInstance();
        RestHighLevelClient restHighLevelClient = factory.getHighLevelClient(esProperty);
        try {

            BoolQueryBuilder boolBuilder = QueryBuilders.boolQuery();
            boolBuilder.must(QueryBuilders.matchPhraseQuery(LogConstantsX.SRC_IP, "10.128.63.102"));
            sourceBuilder.query(boolBuilder);
            SearchRequest searchRequest = new SearchRequest(indexName);
            searchRequest.source(sourceBuilder);
            SearchResponse response = restHighLevelClient.search(searchRequest, RequestOptions.DEFAULT);
            SearchHits sh = response.getHits();
            Object[] sorts = null;
            int total = 0;
            for (SearchHit s : sh) {
                LogData log = new LogData();
                log.setId(s.getId());
                log.setData(s.getSourceAsString());
                log.setEsIndex(s.getIndex());
//                MagicSendTest.magicQueue.offer(log);
                sorts = s.getSortValues();
                total++;
            }
            if (sorts == null || total < 1)
                return;
            queryMore(indexName, sorts);
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            factory.close(restHighLevelClient);
        }
    }
}
