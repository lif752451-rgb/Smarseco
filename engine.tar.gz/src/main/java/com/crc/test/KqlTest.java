package com.crc.test;

import com.crc.common.paser.KqlParser;
import com.crc.common.paser.KqlResult;

public class KqlTest {
    //public static void main(String[] args) {

    /**
     * 测试
     *
     * @方法名:main
     * @参数 @param args
     * @返回类型 void
     */
    public static void main(String[] args) {
        KqlParser argo = new KqlParser("1");
        KqlResult ret = null;
        /*String s1 = "src_ip: \"10.20.0.1\"";//--good
        ret = argo.parse(s1);
        ret.print();*/

        String s2 = "product.keyword : \"慧盾UES\" and action_top.keyword :\"Event_7003\" AND (file:\"表\" OR   file:\"联系\" OR   file:\"信息\" OR   file:\"调\" OR   file:\"问题\" OR   file:\"稿\" OR   file:\"项目\" OR   file:\"岗\" OR   file:\"简\" OR   file:\"说明\" OR   file:\"单\" OR   file:\"证明\" OR   file:\"文件\" OR   file:\"料\" OR   file:\"函\" OR   file:\"福利\" OR   file:\"公示\" OR   file:\"结果\" OR   file:\"申请\" OR   file:\"通知\" OR   file:\"汇总\" OR   file:\"要求\" OR   file:\"信息\" OR   file:\"税\" OR   file:\"发票\")";//--good
        ret = argo.parse(s2);
        ret.print();
        /*String s4 = "product.keyword :\"青藤\" or src_ip.keyword:\"10.8.8.170\"";//--good
        ret = argo.parse(s4);
        ret.print();

        String s5 = "not logID:\"202108130823180101511900792F05F2EC\"";//--good
        ret = argo.parse(s5);
        ret.print();

        String s6 = "not age >= 10";//--good

        ret = argo.parse(s6);

        ret.print();

        String s7 = "msg:\"res*\"";//--good
        ret = argo.parse(s7);
        ret.print();
        String s8 = "response:200 and (extension:\"php\" or extension:\"css\")";//--good

        ret = argo.parse(s8);
        ret.print();

        //String s9 = "response:200 and not (extension:\"php\" or extension:\"css\")";
        String s9 = "product.keyword: \"青藤\" and (src_asset_office:\"华润微电子\" )";
        ret = argo.parse(s9);
        ret.print();

        String s10 = "account_number >= 100 and items_sold <= 200";//--good
        ret = argo.parse(s10);
        ret.print();

        String s11 = "product.keyword :\"青藤\" or src_ip.keyword:\"10.8.8.170\" and dest_ip.keyword: \"10.0.0.1\"";
        ret = argo.parse(s11);
        ret.print();

        s11 = "\"product.keyword: \\\"奇安信天眼\\\" and action_type.keyword: \\\"Scarab勒索软件活动事件\\\"\"";
        ret = argo.parse(s11);
        ret.print();


        String s12 = "\"product.keyword : \\\"奇安信天眼\\\" and content: \\\"Fastjson反序列化漏洞攻击\\\" and (zlog_ori_msg :\\\"\\\\\\\"rsp_status\\\\\\\": \\\\\\\"500\\\\\\\"\\\" or zlog_ori_msg: \\\"\\\\\\\"rsp_status\\\\\\\": \\\\\\\"200\\\\\\\"\\\")\"";
        ret = argo.parse(s12);
        ret.print();

        String s13 = "product.keyword:\"深信服SIP\" and event_description:\"SSH服务器暴力破解攻击\" and not dest_ip:\"10.200.1.186\"  and not dest_ip:\"10.201.7.157\" and not dest_ip:\"10.10.44.67\"";
        ret = argo.parse(s2);
        ret.print();

        String x = "\"action_result.keyword:\\\"放行\\\" \"";


        ret = argo.parse(x);
        ret.print();*/
    }
}
