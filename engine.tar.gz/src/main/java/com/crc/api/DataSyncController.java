package com.crc.api;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;
import com.crc.common.utils.JsonUtils;
import com.crc.common.utils.StringUtils;
import com.crc.secface.entity.SyncVo;
import com.crc.secface.entity.TbEventModel;
import com.crc.secface.mapper.TbEventMapper;
import com.crc.secface.mapper.TbEventModelMapper;
import com.crc.secface.service.WhiteListCenter;
import com.crc.test.wl.WhiteListTest;
import com.crc.test.wl.WlModelTest;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.*;

import javax.servlet.http.HttpServletResponse;

@Slf4j
@Controller
@RequestMapping("/data")
public class DataSyncController extends BaseController {
    //http://localhost:9888/data/sync?pageNum=1&pageTotal=100&type=asset
    @GetMapping("/sync")
    public void sync(SyncVo vo, HttpServletResponse response) {
        vo.setCount(-1);
        toAjax(response, JSON.toJSONString(vo));
    }


    @Autowired
    TbEventModelMapper modelMapper;

    @PostMapping("/model")
    @ResponseBody
    public String model(@RequestBody String param) {
        if (StringUtils.isBlank(param)) {
            return "param null";
        }
        JSONObject jsonObject = JsonUtils.parse(param);
        String modelId = JsonUtils.getStr(jsonObject, "MODEL_ID");
        if (StringUtils.isBlank(modelId)) {
            return "modelId null";
        }
        TbEventModel model = modelMapper.selectTbEventModelById(modelId);
        if (model == null) {
            return "model null";
        }
        WlModelTest data = new WlModelTest();
        data.setModel(model);
        data.setJsonObject(jsonObject);
        log.info("发现一条日志");
        WhiteListTest.queue.push(data);
        return "good";
    }
}
