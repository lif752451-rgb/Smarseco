package com.crc.api;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import javax.servlet.http.HttpServletResponse;
import java.io.IOException;

public class BaseController {
    protected Logger logger = LoggerFactory.getLogger(BaseController.class);

    public void toAjax(HttpServletResponse response, String msg) {
        response.setCharacterEncoding("utf-8");
        try {
            response.getWriter().append(msg);
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}
