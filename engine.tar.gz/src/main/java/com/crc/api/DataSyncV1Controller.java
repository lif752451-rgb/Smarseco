package com.crc.api;

import com.alibaba.fastjson.JSON;
import com.crc.secface.entity.SyncVo;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;

import javax.servlet.http.HttpServletResponse;

@Controller
@RequestMapping("/data/v1")
public class DataSyncV1Controller extends BaseController {
    @GetMapping("/sync")
    public void sync(SyncVo vo, HttpServletResponse response) {
        vo.setCount(-1);
        toAjax(response, JSON.toJSONString(vo));
    }
}
