package com.crc.api;

import com.alibaba.fastjson.JSONObject;
import com.crc.common.constants.WeixinUrlConstants;
import com.crc.common.utils.HttpUtils;
import com.crc.common.utils.JsonUtils;
import com.crc.msg.wx.QyweixinConfig;
import com.crc.msg.wx.QyweixinSend;
import com.crc.msg.wx.QywxTokenThread;
import com.crc.secface.config.GetSpringBean;
import com.crc.secface.entity.MailDTO;
import com.crc.secface.service.MailService;
import com.crc.secface.tool.HuaweiTool;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import javax.servlet.http.HttpServletResponse;
import java.util.Collections;

@Slf4j
@Controller
@RequestMapping("/msg")
public class MsgController extends BaseController {

    @ResponseBody
    @PostMapping("/wx")
    public void wx(HttpServletResponse response, @RequestBody String param) {
        log.info(param);
        JSONObject jsonObject = JsonUtils.parse(param);
        String user = JsonUtils.getStr(jsonObject, "user");
        String msg = JsonUtils.getStr(jsonObject, "msg");
        QyweixinSend.batchSend(Collections.singletonList(user), msg);
        toAjax(response, "ok");
    }

    @ResponseBody
    @RequestMapping("/wxlist")
    public void wxlist(HttpServletResponse response) {
        JSONObject config = QyweixinConfig.getConfig();
        String token = QywxTokenThread.getToken();
        String url = JsonUtils.getStr(config, "url") + WeixinUrlConstants.QY_USER_ID_LIST + "?access_token=" + token;
        //发送请求
        String Str = "{\"limit\": 100}";
        try {
            String ret = HttpUtils.sendPost(url, Str);
            JSONObject retJson = JsonUtils.parse(ret);
            if (JsonUtils.equalVal(retJson, "errmsg", "ok")) {
                log.info("获取：" + ret);
            } else {
                log.error("发送失败！URL:{},错误参数：{}，请求返回信息：{}", url, Str, ret);
            }
        } catch (Exception e) {
            log.error("发送企业微信消息错误，URL：{},错误参数：{}", url, Str, e);
        }
        toAjax(response, "ok");
    }

    @ResponseBody
    @PostMapping("/mail")
    public void mail(HttpServletResponse response, @RequestBody String param) {
        log.info(param);
        JSONObject jsonObject = JsonUtils.parse(param);
        String user = JsonUtils.getStr(jsonObject, "user");
        String msg = JsonUtils.getStr(jsonObject, "msg");
        MailService mailService = GetSpringBean.getBean(MailService.class);
        String sb = "【安全告警消息】测试：" + user + "，请关注！";
        MailDTO mailDTO = MailDTO.builder()
                .to(user)
                .text(msg)
                .subject(sb)
                .build();
        mailService.sendHtmlMail(mailDTO);
        toAjax(response, "ok");
    }

    @ResponseBody
    @PostMapping("/block")
    public void block(HttpServletResponse response, @RequestBody String param) {
        log.info(param);
        JSONObject jsonObject = JsonUtils.parse(param);
        String ip = JsonUtils.getStr(jsonObject, "ip");
        String id = JsonUtils.getStr(jsonObject, "id");
        String ret = HuaweiTool.blockIp(id, ip, "test");
        toAjax(response, ret);
    }

    @ResponseBody
    @PostMapping("/unblock")
    public void unblock(HttpServletResponse response, @RequestBody String param) {
        log.info(param);
        JSONObject jsonObject = JsonUtils.parse(param);
        String id = JsonUtils.getStr(jsonObject, "id");
        String ret = HuaweiTool.unBlockIp(id);
        toAjax(response, ret);
    }
}
