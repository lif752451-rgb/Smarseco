package com.crc.job;

import com.alibaba.fastjson.JSON;
import com.crc.secface.entity.MessageTemplate;
import org.quartz.*;
import org.quartz.impl.StdSchedulerFactory;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.concurrent.ConcurrentHashMap;

public class JobManager {
    public static String GROUP_NAME = "report_group";
    public static String KEY_NAME = "tm_data";
    private static final Logger logger = LoggerFactory.getLogger(JobManager.class);
    public static ConcurrentHashMap<String, MessageTemplate> tempMap = new ConcurrentHashMap<>();
    public static void startJob(MessageTemplate tm) {
        JobDetail job = JobBuilder.newJob(com.crc.job.DayReportJob.class).withIdentity(tm.getCode(), GROUP_NAME).build();
        job.getJobDataMap().put(KEY_NAME, tm);
        try {
            if (tm.getCronValue() == null)
                return;
            if (!CronExpression.isValidExpression(tm.getCronValue())) {
                logger.error("start Job 失败：" + tm.getCode() + " 非法表达式：" + tm.getCronValue());
                return;
            }
            Trigger trigger = TriggerBuilder
                    .newTrigger()
                    .withSchedule(CronScheduleBuilder.cronSchedule(tm.getCronValue())).build();
            Scheduler scheduler = StdSchedulerFactory.getDefaultScheduler();
            scheduler.scheduleJob(job, trigger);
            if (!scheduler.isStarted()) {
                scheduler.start();
            }
            tempMap.put(tm.getCode(), tm);
            logger.info("start Job 成功：" + tm.getCode() + " " + tm.getCronValue());
        } catch (Exception e) {
            logger.error(JSON.toJSONString(tm) + " " + e.getMessage(), e);
            deleteJob(tm);
        }
    }

    public static void deleteJob(MessageTemplate tm) {
        try {
            JobKey jk = JobKey.jobKey(tm.getCode(), GROUP_NAME);
            Scheduler scheduler = StdSchedulerFactory.getDefaultScheduler();
            scheduler.deleteJob(jk);
            logger.info("delete Job " + tm.getCode());
        } catch (Exception e) {
            logger.error(e.getMessage(), e);
        }
    }
}
