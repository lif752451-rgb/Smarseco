package com.crc.job;

import com.alibaba.fastjson.JSONObject;
import com.crc.common.utils.JsonUtils;
import com.crc.secface.entity.SysDictData;
import lombok.extern.slf4j.Slf4j;
import org.quartz.*;
import org.quartz.impl.StdSchedulerFactory;

import java.util.concurrent.ConcurrentHashMap;

@Slf4j
public class UserDefineJobManager {
    public static String GROUP_NAME = "UserDefine_group";
    public static String KEY_NAME = "UserDefine_data";
    public static ConcurrentHashMap<String, SysDictData> tempMap = new ConcurrentHashMap<>();

    public static void deleteJob(SysDictData tm) {
        try {
            JobKey jk = JobKey.jobKey(tm.getDictLabel(), GROUP_NAME);
            Scheduler scheduler = StdSchedulerFactory.getDefaultScheduler();
            scheduler.deleteJob(jk);
            log.info("delete Job " + tm.getDictLabel());
        } catch (Exception e) {
            log.error(e.getMessage(), e);
        }
    }

    public static void startJob(SysDictData tm) {
        JobDetail job = JobBuilder.newJob(UserDefineJob.class).withIdentity(tm.getDictLabel(), GROUP_NAME).build();
        job.getJobDataMap().put(KEY_NAME, tm);
        try {
            JSONObject json = JsonUtils.parse(tm.getRemark());
            if (!json.containsKey("cron"))
                return;
            Trigger trigger = TriggerBuilder
                    .newTrigger()
                    .withSchedule(CronScheduleBuilder.cronSchedule(json.getString("cron"))).build();
            Scheduler scheduler = StdSchedulerFactory.getDefaultScheduler();
            scheduler.scheduleJob(job, trigger);
            if (!scheduler.isStarted()) {
                scheduler.start();
            }
            tempMap.put(tm.getDictLabel(), tm);
            log.info("start Job " + tm.getDictLabel() + " " + tm.getRemark());
        } catch (Exception e) {
            log.error(e.getMessage(), e);
            deleteJob(tm);
        }
    }
}
