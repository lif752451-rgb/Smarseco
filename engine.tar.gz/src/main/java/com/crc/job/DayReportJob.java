package com.crc.job;

import com.alibaba.fastjson.JSONArray;
import com.alibaba.fastjson.JSONObject;
import com.crc.SpringbootApplication;
import com.crc.common.constants.AttackStatConstants;
import com.crc.common.constants.DslConstants;
import com.crc.common.constants.EventConstants;
import com.crc.common.utils.DataUtils;
import com.crc.common.utils.DateUtils;
import com.crc.common.utils.EsHttpUtils;
import com.crc.common.utils.IdGen;
import com.crc.rwork.RworkSend;
import com.crc.secface.config.ElasticsearchProperties;
import com.crc.secface.config.EsCluster2Config;
import com.crc.secface.config.GetSpringBean;
import com.crc.secface.entity.*;
import com.crc.secface.mapper.CommonMapper;
import com.crc.secface.mapper.SysDictDataMapper;
import com.crc.secface.mapper.TbRiskStaticMapper;
import com.crc.secface.mapper.TbRiskStaticTrendMapper;
import com.crc.secface.service.DynamicDslService;
import com.crc.secface.service.MailService;
import com.google.common.base.Joiner;
import lombok.SneakyThrows;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.quartz.*;
import org.springframework.util.CollectionUtils;

import java.io.IOException;
import java.lang.reflect.Method;
import java.util.*;
import java.util.concurrent.atomic.AtomicReference;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import java.util.stream.Collectors;

/**
 * 日报统计类
 */
@Slf4j
@DisallowConcurrentExecution
public class DayReportJob implements Job {

    @SneakyThrows
    @Override
    public void execute(JobExecutionContext context) throws JobExecutionException {
        /**
         * Do something
         */
        JobDataMap map = context.getJobDetail().getJobDataMap();
        MessageTemplate tm = (MessageTemplate) map.get(JobManager.KEY_NAME);
        if (SpringbootApplication.OP_CONFIG != null && !"F".equalsIgnoreCase(SpringbootApplication.OP_CONFIG.getReport())) {
            log.info(tm.getName() + " Start! " + DateUtils.getDateTimeString1(new Date()));
            report(tm, DateUtils.getStaticTime(Integer.parseInt(tm.getTaskInterval()), tm.getPeriodType().intValue(), 14));
            log.info(tm.getName() + "  end! " + DateUtils.getDateTimeString1(new Date()));
        }

    }

    private static final Integer[] productTypes = new Integer[]{7, 10, 4, 12, 1, 2, 3, 5, 13, 8, 14, 15, 16, 17, 18, 19, 20, 21, 22, 23, 24};

    private static final Integer OTHER_STAT_TYPE = 0;
    private static final Integer SYSTEM_DEFINE_TYPE = 10000;

    ElasticsearchProperties esProperty;
    private TbRiskStaticMapper riskStaticMapper;
    private DynamicDslService dslService;
    private TbRiskStaticTrendMapper staticTrendMapper;
    EsCluster2Config esCluster2Config;
    private void report(MessageTemplate tm, String[] timeRanges) throws IOException {
        staticTrendMapper = GetSpringBean.getBean(TbRiskStaticTrendMapper.class);
        sysDictDataMapper = GetSpringBean.getBean(SysDictDataMapper.class);
        esCluster2Config = GetSpringBean.getBean(EsCluster2Config.class);
        esProperty = GetSpringBean.getBean(ElasticsearchProperties.class);
        riskStaticMapper = GetSpringBean.getBean(TbRiskStaticMapper.class);
        dslService = GetSpringBean.getBean(DynamicDslService.class);
        riskStaticMapper = GetSpringBean.getBean(TbRiskStaticMapper.class);
        statRisk(tm, timeRanges, "华润集团");

        if (tm.getCode().contains("report")) {
            List<DeptStat> deptList = riskStaticMapper.selectDeptStat();
            deptList.forEach(dept -> {
                try {
                    statAreaRisk(tm, timeRanges, dept.getDeptName());
                } catch (Exception e) {
                    log.error(e.getMessage(), e);
                }
            });
        }
    }

    private void statAreaRisk(MessageTemplate tm, String[] timeRanges, String deptName) throws IOException {
        List<TbRiskStatic> riskStaticList = riskStaticMapper.selectByProductListWithStatDept(
                Arrays.asList(productTypes), deptName);
        if (CollectionUtils.isEmpty(riskStaticList)) {
            log.info("统计基础信息表配置有误");
            return;
        }
        /**
         * 获取利润中心安全接口人
         */
        List<String> userList = getReceiveUserByDept(deptName);
        if (CollectionUtils.isEmpty(userList)) {
            System.out.println(deptName + " bot_send_list发送日报用户为空");
            return;
        }
        List<TbRiskStatic> otherStaticList = riskStaticMapper.selectByProductListWithStatDept(
                Collections.singletonList(OTHER_STAT_TYPE), deptName);
        riskStaticList.addAll(otherStaticList);
        List<TbRiskStatic> systemConfigList = riskStaticMapper.selectByProductListWithStatDept(
                Collections.singletonList(SYSTEM_DEFINE_TYPE), deptName);
        riskStaticList.addAll(systemConfigList);
        Map<Long, String> productNames = riskStaticList.stream().collect(Collectors.toMap(TbRiskStatic::getProduct, TbRiskStatic::getProductName, (s, a) -> s));
        JSONObject shouldTermsJson = getBranchTerms();
        Map<String, TbRiskStatic> resultMap = new HashMap<>();


        HashMap<String, String> idMap = new HashMap<>();
        String msg = tm.getContent();
        //遍历大括号
        String reg2 = "(\\{(.*?)})";
        Pattern pattern2 = Pattern.compile(reg2);
        Matcher matcher2 = pattern2.matcher(msg);
        while (matcher2.find()) {
            String key = matcher2.group(1);
            String kevOne = key.replace("{", "").replace("}", "").replace(" ", "");
            idMap.put(kevOne, kevOne);
        }

        //遍历中括号
        String reg1 = "(\\[(.*?)])";
        Pattern pattern = Pattern.compile(reg1);
        Matcher matcher = pattern.matcher(msg);
        while (matcher.find()) {
            String key = matcher.group(1);
            String kevOne = key.replace("[", "").replace("]", "").replace(" ", "");
            idMap.put(kevOne, kevOne);
        }
        //查询ES的数据
        riskStaticList.forEach(risk -> {
            if (risk.getSource().equals(DslConstants.ES_STATIC_TYPE)) {
                String key = risk.getProductName() + "-" +
                        risk.getStaticCol();
                risk.setValue(postQueryByEs(risk, timeRanges).toString());
                resultMap.put(key, risk);
            } else if (risk.getSource().equals(DslConstants.DB_STATIC_TYPE)) {
                List<TbRiskStatic> riskStatics = postQueryByDb(risk, timeRanges);
                riskStatics.forEach(risk2 -> {
                    String key = risk2.getProductName() + "-" +
                            risk2.getStaticCol();
                    resultMap.putIfAbsent(key, risk2);
                });

            }
        });

        //计算中间数据
        riskStaticList.forEach(risk -> {
            if (risk.getSource().equals(DslConstants.MID_STATIC_TYPE)) {
                String key = risk.getProductName() + "-" +
                        risk.getStaticCol();
                String value = calMiddleByData(risk, resultMap, productNames);
                risk.setValue(value);
                resultMap.put(key, risk);
            }
        });


        //查询各类型预警
        //List<TbRiskStatic> alarmStaticList = riskStaticMapper.selectByDimision("3");
        List<TbRiskStatic> alarmStaticList = riskStaticMapper.selectByDimisionWithDept("3", deptName);
        Map<String, List<TbRiskStatic>> statMap = getAlarmList(idMap, alarmStaticList, timeRanges, shouldTermsJson);
        saveHistoryData(1L, DateUtils.formatDateTime(new Date(), "yyyy-MM-dd"), null,
                0, resultMap);

        List<TbRiskStatic> allStaticList = new ArrayList<>(resultMap.values());
        sendRworkMsg(tm, deptName, allStaticList, statMap);
    }


    public void sendRworkMsg(MessageTemplate messageTemplate, String deptName, List<TbRiskStatic> allStaticList, Map<String, List<TbRiskStatic>> statMap) throws IOException {
        //statMap 列表统计数据
        Map<String, TbRiskStatic> statMap2 = allStaticList.stream().collect(Collectors.toMap(TbRiskStatic::getId, a -> a, (k1, k2) -> k1));
        //statMap2 单指统计数据

        String msg = messageTemplate.getContent();
        //JsonUtils.print(statMap);
        //JsonUtils.print(statMap2);
        //JsonUtils.print(msg);
        //遍历大括号
        String reg2 = "(\\{(.*?)})";
        Pattern pattern2 = Pattern.compile(reg2);
        Matcher matcher2 = pattern2.matcher(msg);
        while (matcher2.find()) {
            String key = matcher2.group(1);
            String kevOne = key.replace("{", "").replace("}", "").replace(" ", "");
            TbRiskStatic val = statMap2.get(kevOne);
            if (val == null || StringUtils.isBlank(val.getValue())) {
                msg = msg.replace(key, "0") + "\n";
            } else {
                msg = msg.replace(key, val.getValue()) + "\n";
            }
        }

        //遍历中括号
        String reg1 = "(\\[(.*?)])";
        Pattern pattern = Pattern.compile(reg1);
        Matcher matcher = pattern.matcher(msg);
        while (matcher.find()) {
            String key = matcher.group(1);
            String kevOne = key.replace("[", "").replace("]", "").replace(" ", "");
            List<TbRiskStatic> val = statMap.get(kevOne);
            if (val == null) {
                msg = msg.replace(key, "无相关数据");
            } else {
                try {
                    String vtable = "";
                    for (TbRiskStatic k : val) {
                        if (StringUtils.isBlank(vtable)) {
                            vtable = k.getStaticName() + ": " + k.getValue() + "\n";
                        } else {
                            vtable += " " + k.getStaticName() + ": " + k.getValue() + "\n";
                        }
                    }
                    msg = msg.replace(key, vtable);
                } catch (Exception e) {
                    log.error(e.getMessage(), e);
                }
            }
        }
        String content = msg;

        //hejingsheng1修复 发送消息时，后面不断增加换行符 2021-05-08
        if (content != null) {
            StringBuilder sbStr = new StringBuilder();
            // 3.添加第一个字符【当前字符】
            sbStr.append(content.charAt(0));
            // 4.遍历字符串的每一个字符
            for (int i = 0; i < content.length() - 1; i++) {
                if (content.charAt(i) != '\n') {
                    sbStr.append(content.charAt(i + 1));
                    continue;
                }
                // 5.判断当前字符 于下一个字符是否相同
                if (content.charAt(i) != content.charAt(i + 1)) {
                    // 若不相同，则添加字符
                    sbStr.append(content.charAt(i + 1));
                }
            }
            content = sbStr.toString();
        }
        content = content.replace("\\n", "\n");
        log.info(content);
//
        List<String> userList;
        if (messageTemplate.getRworkStatus() == 1) {
            userList = Arrays.asList(messageTemplate.getRworkReceiver().split(","));
            RworkSend.batchSend(userList, content);
        }
        if (messageTemplate.getEmailStatus() == 1) {
            userList = Arrays.asList(messageTemplate.getEmailReceiver().split(","));
            content = content.replaceAll("\n", "<br>");
            pushEmail(userList, content, messageTemplate);
        }

    }


    public Map<String, List<TbRiskStatic>> getAlarmList(HashMap<String, String> idMap, List<TbRiskStatic> riskStaticList, String[] timeRanges, JSONObject shouldTermsJson) {
        Map<String, List<TbRiskStatic>> statMap = new HashMap<>();
        riskStaticList.forEach(risk -> {
            if (!idMap.containsKey(risk.getId()))
                return;
            if (risk.getSource().equals(DslConstants.ES_STATIC_TYPE)) {
//                String key = new StringBuffer().append(risk.getProductName()).append("-")
//                        .append(risk.getStaticCol()).toString();
                List<TbRiskStatic> riskStatics = postQueryByEsAndAggs(risk, timeRanges);
                statMap.put(risk.getId(), riskStatics);
            } else if (risk.getSource().equals(DslConstants.DB_STATIC_TYPE)) {
                List<TbRiskStatic> riskStatics = postQueryByDbAndAgg(risk, timeRanges);
                statMap.put(risk.getId(), riskStatics);
            }
        });
        return statMap;
    }

    public List<TbRiskStatic> postQueryByDbAndAgg(TbRiskStatic riskStatic, String[] timeRanges) {
        String[] times = DateUtils.parseSparkTimeRange(timeRanges);
        String[] selectCol = null;
        selectCol = getSelectColBySql(riskStatic.getQuery());
        List<TbRiskStatic> riskStatics = new ArrayList<>();
        String changeParams = riskStatic.getChangeParams();
        String querySql = rewriteQuerySql(riskStatic.getQuery(), changeParams, times);

        if (riskStatic.getAggDimision().equals("3")) {
            try {
                CommonMapper commonMapper = GetSpringBean.getBean(CommonMapper.class);
                List<HashMap<String, Object>> jsonList = commonMapper.query(querySql);
                for (HashMap<String, Object> jsonObject : jsonList) {
                    try {
                        TbRiskStatic tbRiskStatic = new TbRiskStatic();
                        tbRiskStatic.setId(riskStatic.getId());
                        tbRiskStatic.setProductName(riskStatic.getProductName());
                        if (selectCol.length > 1) {
                            tbRiskStatic.setValue(DataUtils.getStr(jsonObject, selectCol[1]));
                        } else {
                            tbRiskStatic.setValue("0");
                        }
                        tbRiskStatic.setStaticCol(riskStatic.getStaticCol());
                        String tmpCol = DataUtils.getStr(jsonObject, selectCol[0]);
                        if (StringUtils.isNotBlank(tmpCol))
                            tbRiskStatic.setStaticName(tmpCol);
                        else
                            tbRiskStatic.setStaticName(riskStatic.getStaticName());
                        riskStatics.add(tbRiskStatic);
                    } catch (Exception e) {
                        log.error(querySql + "\n" + e.getMessage(), e);
                    }
                }

            } catch (Exception e) {
                log.error(querySql + "\n" + e.getMessage(), e);
            }
        }
        return riskStatics;
    }

    public void saveHistoryData(Long staticType, String staticDate, String[] timeRanges, int assetInstanceId, Map<String, TbRiskStatic> dataMap) {
        for (Map.Entry<String, TbRiskStatic> entry : dataMap.entrySet()) {
            TbRiskStaticTrend staticTrend = new TbRiskStaticTrend();
            TbRiskStatic riskStatic = entry.getValue();
            staticTrend.setId(IdGen.uuid());
            staticTrend.setStaticId(riskStatic.getId());
            staticTrend.setStaticDate(staticDate);
            staticTrend.setDelFlag(0);
            staticTrend.setStaticType(staticType);
            staticTrend.setStaticValue(riskStatic.getValue());
            staticTrend.setAssetInstanceId(0L);
            staticTrend.setCreateTime(new Date());
            staticTrend.setCreateBy("admin");
            String timeRangeStr = "";
            if (timeRanges == null || timeRanges.length == 0) {
                timeRangeStr = "00:00-24:00";
            } else {
                timeRangeStr = timeRanges[3] + "-" + timeRanges[2];
            }
            staticTrend.setStaticTimeRange(timeRangeStr);
            staticTrendMapper.insertOrUpdateTbRiskStaticTrend(staticTrend);
        }
    }

    public List<TbRiskStatic> postQueryByEsAndAggs(TbRiskStatic riskStatic, String[] timeRanges) {
        List<TbRiskStatic> statList = new ArrayList<>();
        AtomicReference<Long> count = new AtomicReference<>(0L);
        String selectCol = getSelectCol(riskStatic);
        if (StringUtils.isEmpty(selectCol)) {
            log.info("解析 selectCol 字段出错");
            return Collections.emptyList();
        }
        //JSONObject dslJson = new JSONObject();
        RewriteQuery rewriteQuery = buildTimeRangeQuery(riskStatic, riskStatic.getChangeParams(), timeRanges);
        //to do otherwise
        String queryDSL = dslService.rewiteQuery(riskStatic.getQuery(), rewriteQuery);

        //聚合用agg api
        JSONObject resultJson = null;
        if (riskStatic.getEsClientIndex().equals("1")) {
            resultJson = getEsQueryByRetry(riskStatic.getEsIndex(), queryDSL,riskStatic.getId());
        } else {
            resultJson = getEsQueryByRetry(riskStatic.getEsIndex(), queryDSL,riskStatic.getId());
        }
        JSONObject json = JSONObject.parseObject(selectCol);
        if (resultJson != null) {
            for (Map.Entry<String, Object> entry : json.entrySet()) {
                if (!resultJson.containsKey("aggregations")) {
                    continue;
                }
                JSONArray jsonArray = resultJson.getJSONObject("aggregations").getJSONObject(entry.getKey()).getJSONArray(DslConstants.ES_BUCKET_TAG);
                if (!CollectionUtils.isEmpty(jsonArray)) {
                    jsonArray.forEach(data -> {
                        TbRiskStatic tbRiskStatic = new TbRiskStatic();
                        JSONObject dataJson = (JSONObject) data;
                        // tbRiskStatic.setId(riskStatic.getId());
                        tbRiskStatic.setProductName(riskStatic.getProductName());
                        tbRiskStatic.setStaticCol(riskStatic.getStaticCol());
                        tbRiskStatic.setStaticName(dataJson.getString("key"));
                        tbRiskStatic.setValue(dataJson.getString("doc_count"));
                        statList.add(tbRiskStatic);
                    });
                }
            }
        }

        return statList;

    }

    public String buildEsCountUrl(String esIndex) {
        String url = String.format("%s://%s:%s", esProperty.getSchema(), esProperty.getHost(), esProperty.getPort());
        return String.format("%s/%s/%s", url, esIndex, "_count");
    }

    private void statRisk(MessageTemplate tm, String[] timeRanges, String deptName) throws IOException {
        List<TbRiskStatic> riskStaticList = riskStaticMapper.selectByProductList(Arrays.asList(productTypes));
        if (CollectionUtils.isEmpty(riskStaticList)) {
            log.info("统计基础信息表配置有误");
            return;
        }
        List<TbRiskStatic> otherStaticList = riskStaticMapper.selectByProductList(Collections.singletonList(OTHER_STAT_TYPE));
        riskStaticList.addAll(otherStaticList);
        List<TbRiskStatic> systemConfigList = riskStaticMapper.selectByProductList(Collections.singletonList(SYSTEM_DEFINE_TYPE));
        riskStaticList.addAll(systemConfigList);


        for (TbRiskStatic stat : riskStaticList) {
            if (stat.getEsIndex() != null) {
                if (!tm.getCode().contains("report")) {
                    if (stat.getEsIndex().contains("alarm_all")) {
                        stat.setEsIndex(stat.getEsIndex().replace("alarm_all", "sec_all"));
                    }
                } else {
                    if (stat.getEsIndex().contains("sec_all")) {
                        stat.setEsIndex(stat.getEsIndex().replace("sec_all", "alarm_all"));
                    }
                }
            }
        }

        Map<Long, String> productNames = riskStaticList.stream().collect(Collectors.toMap(TbRiskStatic::getProduct, TbRiskStatic::getProductName, (s, a) -> s));
        JSONObject shouldTermsJson = getBranchTerms();
        Map<String, TbRiskStatic> resultMap = new HashMap<>();


        HashMap<String, String> idMap = new HashMap<>();
        String msg = tm.getContent();
        //遍历大括号
        String reg2 = "(\\{(.*?)})";
        Pattern pattern2 = Pattern.compile(reg2);
        Matcher matcher2 = pattern2.matcher(msg);
        while (matcher2.find()) {
            String key = matcher2.group(1);
            String kevOne = key.replace("{", "").replace("}", "").replace(" ", "");
            idMap.put(kevOne, kevOne);
        }

        //遍历中括号
        String reg1 = "(\\[(.*?)])";
        Pattern pattern = Pattern.compile(reg1);
        Matcher matcher = pattern.matcher(msg);
        while (matcher.find()) {
            String key = matcher.group(1);
            String kevOne = key.replace("[", "").replace("]", "").replace(" ", "");
            idMap.put(kevOne, kevOne);
        }

        //查询ES的数据
        riskStaticList.forEach(risk -> {
            try {
                if (risk.getSource().equals(DslConstants.ES_STATIC_TYPE)) {
                    String key = risk.getProductName() + "-" +
                            risk.getStaticCol();
                    risk.setValue(postQueryByEs(risk, timeRanges).toString());
                    resultMap.put(key, risk);
                } else if (risk.getSource().equals(DslConstants.DB_STATIC_TYPE)) {
                    List<TbRiskStatic> riskStatics = postQueryByDb(risk, timeRanges);
                    riskStatics.forEach(risk2 -> {
                        String key = risk2.getProductName() + "-" +
                                risk2.getStaticCol();
                        resultMap.putIfAbsent(key, risk2);
                    });

                }
            } catch (Exception e) {
                log.error(e.getMessage(), e);
            }
        });
        //计算中间数据
        riskStaticList.forEach(risk -> {
            if (risk.getSource().equals(DslConstants.MID_STATIC_TYPE)) {
                String key = risk.getProductName() + "-" +
                        risk.getStaticCol();
                String value = calMiddleByData(risk, resultMap, productNames);
                risk.setValue(value);
                resultMap.put(key, risk);
            }
        });
        //查询各类型预警
        List<TbRiskStatic> alarmStaticList = riskStaticMapper.selectByDimision("3");
        Map<String, List<TbRiskStatic>> statMap = getAlarmList(idMap, alarmStaticList, timeRanges, shouldTermsJson);
        //JsonUtils.print(statMap);
        //saveHistoryData(1L, DateUtils.formatDateTime(new Date(), "yyyy-MM-dd"), null,
        //       0, resultMap);
        // JsonUtils.print(resultMap);
        List<TbRiskStatic> allStaticList = new ArrayList<>(resultMap.values());
        sendRworkMsg(tm, deptName, allStaticList, statMap);
    }


    private static void pushEmail(List<String> userList, String msg, MessageTemplate tm) throws IOException {
        MailDTO mailDTO = MailDTO.builder()
                .to(Joiner.on(",").join(userList))
                .text(msg)
                .subject(tm.getName())
                .build();
        MailService mailService = GetSpringBean.getBean(MailService.class);
        mailService.sendHtmlMail(mailDTO);
    }

    SysDictDataMapper sysDictDataMapper;

    public List<String> getReceiveUserByDept(String deptName) {
        List<String> userIds = new ArrayList<>();
        if (!"T".equalsIgnoreCase(SpringbootApplication.OP_CONFIG.getMode())) {
            List<SysDictData> eventLevelList = sysDictDataMapper.selectDictDataByTypeAndValue(
                    EventConstants.BOT_SEND_LIST, deptName);
            eventLevelList.forEach(dict -> {
                if (dict.getDictValue() != null) {
                    List<String> userList = Arrays.asList(dict.getDictValue().split(","));
                    userList.forEach(userId -> {
                        if (userId.contains("@")) {
                            userId = userId.split("@")[0];
                        }
                        userIds.add(userId);
                    });

                }
            });
        } else {
            userIds.add("hejingsheng1");
        }
        // userIds.add("zhengyifeng5");
        //    userIds.add("pactera-509");
        return userIds;
    }


    public List<TbRiskStatic> postQueryByDb(TbRiskStatic riskStatic, String[] timeRanges) {
        String[] times = DateUtils.parseSparkTimeRange(timeRanges);
        String groupKeys = "";
        groupKeys = getGroupKeyBySql(riskStatic.getQuery());
        List<TbRiskStatic> riskStatics = new ArrayList<>();
        String changeParams = riskStatic.getChangeParams();
        String querySql = rewriteQuerySql(riskStatic.getQuery(), changeParams, times);
        if (riskStatic.getAggDimision().equals("1") || riskStatic.getAggDimision().equals("2")) {
            try {
                CommonMapper commonMapper = GetSpringBean.getBean(CommonMapper.class);
                List<HashMap<String, Object>> jsonList = commonMapper.query(querySql);
                for (HashMap<String, Object> jsonObject : jsonList) {
                    try {
                        TbRiskStatic tbRiskStatic = new TbRiskStatic();
                        tbRiskStatic.setId(riskStatic.getId());
                        tbRiskStatic.setProductName(DataUtils.getStr(jsonObject, groupKeys));
                        tbRiskStatic.setValue(DataUtils.getStr(jsonObject, DslConstants.COUNT));
                        tbRiskStatic.setStaticCol(riskStatic.getStaticCol());
                        String tmpCol = DataUtils.getStr(jsonObject, groupKeys);
                        if (StringUtils.isNotBlank(tmpCol))
                            tbRiskStatic.setStaticName(tmpCol);
                        else
                            tbRiskStatic.setStaticName(riskStatic.getStaticName());
                        riskStatics.add(tbRiskStatic);
                    } catch (Exception e) {
                        log.error(querySql + "\n" + e.getMessage(), e);
                    }
                }

            } catch (Exception e) {
                log.error(querySql + "\n" + e.getMessage(), e);
            }
        }
        return riskStatics;
    }

    public String rewriteQuerySql(String querySql, String changeParams, String[] times) {
        changeParams = String.format(changeParams, times[0], times[1]);
        JSONObject paramJson = JSONObject.parseObject(changeParams);
        String wheresql = "";
        for (Map.Entry<String, Object> entry : paramJson.entrySet()) {
            if (((JSONObject) entry.getValue()).getString(DslConstants.TYPE_TAG).equals(DslConstants.DSL_RANGE_TYPE)) {
                wheresql = " " + entry.getKey() + " " +
                        DslConstants.BETWEEN_TAG + " " + "'" + times[1] + "'" + " " +
                        DslConstants.AND_TAG + " " + "'" + times[0] + "'";
            }
        }
        return String.format(querySql, wheresql);
    }

    public String[] getMethodFields(String query) {
        String methodName = query.substring(0, query.indexOf("("));
        String parameters = query.substring(query.indexOf("(") + 1, query.indexOf(")"));
        // allMethod[0] =methodName;
        String[] params = parameters.split(",");
        String[] allMethodNames = new String[params.length + 1];
        allMethodNames[0] = methodName;
        System.arraycopy(params, 0, allMethodNames, 1, params.length);
        return allMethodNames;
    }

    public String getGroupKeyBySql(String querySql) {
        String[] groupBys = querySql.split(DslConstants.GROUP_BY);
        if (groupBys.length > 1) {
            return groupBys[1].split(",")[0].trim();
        }
        return "";
    }

    public String[] getSelectColBySql(String querySql) {
        String selectField = "";
        Pattern pattern = Pattern.compile(AttackStatConstants.SELECT_FROM_PATTERN);
        Matcher match = pattern.matcher(querySql);
        while (match.find()) {
            selectField = match.group(0);
        }
        String[] columns = selectField.split(",");
        if (columns.length > 0) {
            for (int i = 0; i < columns.length; i++) {
                if (columns[i].indexOf(AttackStatConstants.AS) > 0) {
                    columns[i] = columns[i].split(AttackStatConstants.AS)[1].trim();
                }
            }
        }
        return columns;
    }

    public String calMiddleByData(TbRiskStatic
                                          riskStatic, Map<String, TbRiskStatic> riskMap, Map<Long, String> productNames) {
        String query = riskStatic.getQuery2();
        String[] allMethods = getMethodFields(query);
        String[] paramList = new String[allMethods.length - 1];
        System.arraycopy(allMethods, 1, paramList, 0, allMethods.length - 1);
        String productName = riskStatic.getProductName();
        Object value = null;
        Object[] values = new Object[paramList.length];
        for (int i = 0; i < paramList.length; i++) {
            String param2 = paramList[i];
            if (param2.indexOf(".") > 0) {
                productName = productNames.get(Long.parseLong(param2.split("\\.")[0]));
                param2 = param2.split("\\.")[1];
                values[i] = getFieldValue(productName, param2, riskMap);
            } else {
                values[i] = getFieldValue(productName, paramList[i], riskMap);
            }

        }
        try {
            //JsonUtils.print(allMethods);
            Class clazz = Class.forName(allMethods[0].substring(0, allMethods[0].lastIndexOf(".")));
            for (Method method : clazz.getDeclaredMethods()) {
                if (method.getName().equals(allMethods[0].substring(allMethods[0].lastIndexOf(".") + 1, allMethods[0].length()))) {
                    //  System.out.println(JSONObject.toJSONString(method.getParameterTypes()));
                    boolean isArrayParams = false;
                    for (Class clazz1 : method.getParameterTypes()) {
                        if (clazz1.getName().equalsIgnoreCase("java.util.List")) {
                            isArrayParams = true;
                            break;
                        }
                    }
                    if (isArrayParams) {
                        List<Object> objectList = Arrays.asList(values);
                        value = method.invoke(clazz.newInstance(), objectList);
                    } else {
                        value = method.invoke(clazz.newInstance(), values);
                    }
                }
            }
        } catch (Exception e) {
            log.error(e.getMessage(), e);
        }
        if (value == null) {
            return "";
        }
        return value.toString();

    }

    public Long getFieldValue(String productName, String colName, Map<String, TbRiskStatic> resultMap) {
        String key = productName + "-" + colName;
        if (!resultMap.containsKey(key)) {
            return 0L;
        } else {
            return Long.parseLong(resultMap.get(key).getValue());
        }
    }

    public Long postQueryByEs(TbRiskStatic riskStatic, String[] timeRanges) {
        AtomicReference<Long> count = new AtomicReference<>(0L);
        try {
            String selectCol = getSelectCol(riskStatic);
            if (StringUtils.isEmpty(selectCol)) {
                log.info("解析 selectCol 字段出错");
                return 0L;
            }
            //JSONObject dslJson = new JSONObject();
            RewriteQuery rewriteQuery = buildTimeRangeQuery(riskStatic, riskStatic.getChangeParams(), timeRanges);
            //to do otherwise
            String queryDSL = dslService.rewiteQuery(riskStatic.getQuery2(), rewriteQuery);
            //计算总数用count api
            if (riskStatic.getAggDimision().equals("1")) {

                JSONObject resultJson = null;
                if (riskStatic.getEsClientIndex().equals("1")) {
                    String esSearchUrl = buildEsCountUrl(riskStatic.getEsIndex());
                    resultJson = getEsQueryByRetry(esSearchUrl, queryDSL, riskStatic.getId());
                } else {
                    String esSearchUrl = buildNgfwCountUrl(riskStatic.getEsIndex());
                    resultJson = getEsQueryByRetry(esSearchUrl, queryDSL, riskStatic.getId());
                }
                if (resultJson == null) {
                    return 0L;
                }
                log.info("{}-{}",riskStatic.getId(),resultJson.toJSONString());
                return resultJson.getLong("count");
            } else if (riskStatic.getAggDimision().equals("2")) {
                //聚合用agg api
                JSONObject resultJson = null;
                if (riskStatic.getEsClientIndex().equals("1")) {
                    String esSearchUrl = buildEsSearchUrl(riskStatic.getEsIndex());

                    resultJson = getEsQueryByRetry(esSearchUrl, queryDSL, riskStatic.getId());

                } else {
                    String esSearchUrl = buildNgfwSearchUrl(riskStatic.getEsIndex());
                    resultJson = getEsQueryByRetry(esSearchUrl, queryDSL, riskStatic.getId());
                }
                if (resultJson == null) {
                    return 0L;
                }
                log.info("{}-{}",riskStatic.getId(),resultJson.toJSONString());
                JSONObject json = JSONObject.parseObject(selectCol);
                for (Map.Entry<String, Object> entry : json.entrySet()) {
                    try {
                        count.set(resultJson.getJSONObject("aggregations").getJSONObject(entry.getKey()).getLong("value"));
                    } catch (Exception ignored) {

                    }
                }
            }
        } catch (Exception e) {
            log.error("查询Es 报错,dsl:{},t统计字段:{},日志来源:{},异常:{}", riskStatic.getQuery(),
                    riskStatic.getStaticName(), riskStatic.getProductName(),e.getMessage(), e);
        }
        return count.get();
    }

    private RewriteQuery buildTimeRangeQuery(TbRiskStatic riskStatic, String changeParams,
                                             String[] timeRanges) {
        String changeParamsJson = String.format(changeParams, timeRanges[1], timeRanges[0]);
        RewriteQuery rewriteQuery = JSONObject.parseObject(changeParamsJson, RewriteQuery.class);
        if (!StringUtils.isEmpty(riskStatic.getAreaStatType()) && riskStatic.getAreaStatType().equalsIgnoreCase("2")) {
            if (!StringUtils.isEmpty(riskStatic.getAssetField())) {
                JSONObject queryJson = new JSONObject();
                queryJson.put(DslConstants.FIELD_TAG, Arrays.asList(riskStatic.getAssetField().split(",")));
                queryJson.put(DslConstants.VALUE_TAG, Arrays.asList(riskStatic.getAssetQuery().split(",")));
                queryJson.put("type", DslConstants.MULTI_MATCH_TYPE);
                queryJson.put("property", "assetQuery");
                rewriteQuery.should(queryJson);
            }
            if (!StringUtils.isEmpty(riskStatic.getHostField())) {
                JSONObject queryJson = new JSONObject();
                queryJson.put(DslConstants.FIELD_TAG, Arrays.asList(riskStatic.getHostField().split(",")));
                queryJson.put(DslConstants.VALUE_TAG, Arrays.asList(riskStatic.getHostQuery().split(",")));
                queryJson.put("property", "hostQuery");
                queryJson.put("type", DslConstants.MULTI_MATCH_TYPE);
                rewriteQuery.should(queryJson);
            }
            //log.info("build rewriteQuery:{}", JSONObject.toJSONString(rewriteQuery));
        }

        return rewriteQuery;

    }

    public JSONObject getEsQueryByRetry(String esSearchUrl, String queryDSL, String id) {
        String responseStr = "";
        JSONObject response = null;
        try {
            responseStr = EsHttpUtils.sendSSLGet(esProperty, esSearchUrl, queryDSL,id);
        } catch (Exception e) {
            log.error(e.getMessage(), e);
        }
        if (!StringUtils.isEmpty(responseStr)) {
            response = JSONObject.parseObject(responseStr);
        }
        return response;
    }

    public String buildEsSearchUrl(String esIndex) {
        String url = String.format("%s://%s:%s", esProperty.getSchema(), esProperty.getHost(), esProperty.getPort());
        return String.format("%s/%s/%s", url, esIndex, "_search");
    }

    public String buildNgfwSearchUrl(String esIndex) {
        return String.format("%s/%s/%s", esCluster2Config.getUrl(), esIndex, "_search");
    }

    public String buildNgfwCountUrl(String esIndex) {
        return String.format("%s/%s/%s", esCluster2Config.getUrl(), esIndex, "_count");
    }

    //根据dsl 获取查询的字段
    public String getSelectCol(TbRiskStatic riskStatic) {
        //分析DsL 语句中有没有aggs 字段
        String selectCol = "";
        if (riskStatic.getSource().equals("es") && !StringUtils.isEmpty(riskStatic.getQuery())) {
            JSONObject dslJson = JSONObject.parseObject(riskStatic.getQuery());
            if (!dslJson.containsKey("aggs")) {
                selectCol = "total";
            } else {
                selectCol = dslJson.getJSONObject("aggs").toJSONString();
            }
        }
        return selectCol;
    }


    public JSONObject getBranchTerms() {
        JSONObject jsonObject = new JSONObject();
        jsonObject.put("asset_office", "水泥");
        jsonObject.put("src_asset_office", "水泥");
        jsonObject.put("src_branch", "水泥");
        jsonObject.put("src_instance", "水泥");
        jsonObject.put("dest_asset_office", "水泥");
        jsonObject.put("dest_branch", "水泥");
        jsonObject.put("dest_instance", "水泥");
        jsonObject.put("host", "crcement");
        return jsonObject;
    }
}
