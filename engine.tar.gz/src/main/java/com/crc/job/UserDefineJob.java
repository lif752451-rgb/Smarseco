package com.crc.job;

import com.alibaba.fastjson.JSONObject;
import com.crc.common.utils.DateUtils;
import com.crc.common.utils.JsonUtils;
import com.crc.secface.entity.SysDictData;
import lombok.extern.slf4j.Slf4j;
import org.quartz.*;

import java.util.Date;

/**
 * 安全告警，实时监控
 */
@Slf4j
@DisallowConcurrentExecution
public class UserDefineJob implements Job {
    @Override
    public void execute(JobExecutionContext context) throws JobExecutionException {
        /*
         * Do something
         */
        JobDataMap map = context.getJobDetail().getJobDataMap();
        SysDictData tm = (SysDictData) map.get(UserDefineJobManager.KEY_NAME);
        if (tm == null)
            return;
        log.info(tm.getDictLabel() + " Start! " + DateUtils.getDateTimeString1(new Date()));
        try {
            JSONObject json = JsonUtils.parse(tm.getRemark());
            if (!json.containsKey("type"))
                return;
            String type = json.getString("type");
            if ("riskMail".equals(type)) {
                //riskMail
//                RiskRectificationTask task = new RiskRectificationTask();
                //task.push();
            }
        } catch (Exception e) {
            log.error(e.getMessage(), e);
        }
        log.info(tm.getDictLabel() + "  end! " + DateUtils.getDateTimeString1(new Date()));
    }



}
