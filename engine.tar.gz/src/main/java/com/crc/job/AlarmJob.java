package com.crc.job;

import com.crc.common.utils.DateUtils;
import org.quartz.DisallowConcurrentExecution;
import org.quartz.Job;
import org.quartz.JobExecutionContext;
import org.quartz.JobExecutionException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.Date;

/**
 * 安全告警，实时监控
 */
@DisallowConcurrentExecution
public class AlarmJob implements Job {
    private static final Logger logger = LoggerFactory.getLogger(AlarmJob.class);

    @Override
    public void execute(JobExecutionContext context) throws JobExecutionException {
        logger.info(this.getClass().toString() + " Start! " + DateUtils.getDateTimeString1(new Date()));
        /**
         * Do something
         */
        logger.info(this.getClass().toString() + "  end! " + DateUtils.getDateTimeString1(new Date()));
    }
}
