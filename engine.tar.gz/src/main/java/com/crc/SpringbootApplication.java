package com.crc;

import com.crc.common.constants.Constants;
import com.crc.secface.config.DeployConfig;
import com.crc.secface.config.GetSpringBean;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.mybatis.spring.annotation.MapperScan;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.Configuration;
import org.springframework.core.env.Environment;

import java.io.InputStream;
import java.net.InetAddress;
import java.nio.charset.StandardCharsets;
import java.util.Arrays;
import java.util.List;

@Configuration
@SpringBootApplication
@MapperScan("com.crc.secface.mapper")
@Slf4j
public class SpringbootApplication {
    public static DeployConfig OP_CONFIG = null;

    public static void main(String[] args) {
        if (Arrays.asList(args).contains("--version") || Arrays.asList(args).contains("-version")) {
            getVersionInfo();
            System.exit(-1);
        }
        try {
            SpringApplication.run(SpringbootApplication.class, args);
            OP_CONFIG = GetSpringBean.getBean(DeployConfig.class);
            StartUp.start();
            try {
                Environment env = GetSpringBean.getBean(Environment.class);
                log.info("\n======================================================\n\t" +
                                "标准版分析引擎 SECFACE ENGINE 成功运行!!! \n\t" +
                                "Auth: \tsmartseco\n\t" +
                                "Access URLs:\t http://{}:{}\n" +
                                "======================================================",
                        InetAddress.getLocalHost().getHostAddress(), env.getProperty("server.port")
                );
            } catch (Exception ignored) {

            }
        } catch (Exception e) {
            log.error(e.getMessage(), e);
        }
    }

    /**
     * 获取系统版本信息
     */
    private static void getVersionInfo() {
        try (InputStream in = Thread.currentThread().getContextClassLoader().getResourceAsStream("info/version.txt");) {
            byte[] buf = new byte[1024];
            in.read(buf);
            String lines = new String(buf, StandardCharsets.UTF_8);
            if (StringUtils.isEmpty(lines)) {
                log.error("读取 CRC分析引擎 当前版本 异常：版本文件为空");
                return;
            }
            String[] lineLists = lines.split(Constants.Symbol.LINE_FEED);
            log.info("CRC分析引擎 当前版本信息：");
            for (String line : lineLists) {
                if (line.contains(Constants.SPLIT_LINE)) {
                    break;
                }
                log.info(Constants.Symbol.TAB + line);
            }
        } catch (Exception e) {
            log.error("读取 CRC分析引擎 当前版本 异常：" + e.getMessage(),e);
        }
    }
}

