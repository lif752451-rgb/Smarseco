package com.crc.msg.rwork;

import com.alibaba.fastjson.JSONObject;
import com.crc.common.utils.DictUtil;
import com.crc.common.utils.JsonUtils;
import com.crc.secface.entity.SysDictData;
import lombok.extern.slf4j.Slf4j;

@Slf4j
public class RworkConfig {
    private static JSONObject configData = null;

    /*
    demo:
     {"APP_ID":"cli_9e50ad556738d007",
      "APP_SECRET":"JYCCsv040LPnVOGGFaTZsevv8Lr6CVYE",
      "APP_SUB_ID":"0006003301KD",
      "APP_TOKEN":"2ab2700162644922b22a8f579ae0fa96",
      "PARTNER_ID":"00060000",
      "SYS_ID":"00060033",
      "URL":"https://ssdp.crc.com.cn"}
     */
    public static JSONObject getConfig() {
        if (configData != null) {
            return configData;
        }
        SysDictData dict = DictUtil.getDictByValue("rwork_push_auth", "rwork_push_auth");
        if (dict == null) {
            log.error("未配置飞书/飞书推送参数,在字典,rwork_push_auth/rwork_push_auth【remark】");
            return null;
        }
        configData = JsonUtils.parse(dict.getRemark());
        return configData;
    }
}
