package com.crc.msg.wx;


import com.crc.common.utils.MyTheadUtils;
import com.crc.secface.entity.TimeModel;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;


@Slf4j
public class QywxTokenThread extends Thread {
    private static TimeModel qyWxTimeKey;
    private static boolean SINGLE_START_FLAG = false;

    public QywxTokenThread() {
        if (qyWxTimeKey == null) {
            qyWxTimeKey = new TimeModel();
        }
    }

    public static String getToken() {
        return QyweixinConfig.getToken(QyweixinConfig.getConfig());
    }

    public static void startX() {
        if (!SINGLE_START_FLAG) {
            QywxTokenThread keyThread = new QywxTokenThread();
            keyThread.start();
        } else {
            SINGLE_START_FLAG = true;
        }
    }

    @Override
    public void run() {
        while (true) {
            try {
                long curTime = System.currentTimeMillis();
                long diff = curTime - qyWxTimeKey.getTimestamp();
                long GET_KEY_PERIOD = 1000 * 60 * 30L;
                if (diff > GET_KEY_PERIOD) {
                    qyWxTimeKey.setKey(getRworkToken());
                    qyWxTimeKey.setTimestamp(System.currentTimeMillis());
                }

                MyTheadUtils.sleepBySec(6);
            } catch (Exception e) {
                log.error(e.getMessage(), e);
            }
        }
    }

    /**
     * 获取token
     */
    public String getRworkToken() {
        return QyweixinConfig.getToken(QyweixinConfig.getConfig());
    }

}
