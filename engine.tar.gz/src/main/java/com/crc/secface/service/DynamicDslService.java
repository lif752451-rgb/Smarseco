package com.crc.secface.service;

import com.crc.secface.entity.RewriteQuery;
import org.elasticsearch.action.search.SearchResponse;

/**
 * @author simba@onlying.cn
 * @date 2020/7/30 17:21
 */
public interface DynamicDslService {

    public String  rewiteQuery(String dsl, RewriteQuery rewriteQuery);

    public SearchResponse parseResponse(String content);
}
