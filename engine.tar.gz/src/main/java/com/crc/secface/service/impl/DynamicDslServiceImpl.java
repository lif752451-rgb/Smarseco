package com.crc.secface.service.impl;

import com.alibaba.fastjson.JSONArray;
import com.alibaba.fastjson.JSONObject;
import com.crc.common.constants.DslConstants;
import com.crc.common.utils.DateUtils;
import com.crc.secface.config.ElasticsearchProperties;
import com.crc.secface.entity.RewriteQuery;
import com.crc.secface.service.DynamicDslService;
import org.elasticsearch.action.search.SearchResponse;
import org.elasticsearch.common.io.stream.NamedWriteableRegistry;
import org.elasticsearch.common.xcontent.NamedXContentRegistry;
import org.elasticsearch.common.xcontent.ParseFieldRegistry;
import org.elasticsearch.common.xcontent.XContentParser;
import org.elasticsearch.common.xcontent.json.JsonXContent;
import org.elasticsearch.index.query.*;
import org.elasticsearch.index.query.functionscore.FunctionScoreQueryBuilder;
import org.elasticsearch.plugins.SearchPlugin;
import org.elasticsearch.search.aggregations.AggregationBuilder;
import org.elasticsearch.search.aggregations.bucket.significant.heuristics.SignificanceHeuristicParser;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.InitializingBean;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.util.CollectionUtils;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

/**
 * @author simba@onlying.cn
 * @date 2020/7/30 17:23
 */
@Service
public class DynamicDslServiceImpl implements DynamicDslService, InitializingBean {

    private static final Logger logger = LoggerFactory.getLogger(DynamicDslServiceImpl.class);
    private final List<NamedWriteableRegistry.Entry> namedWriteables = new ArrayList<>();
    private final List<NamedXContentRegistry.Entry> namedXContents = new ArrayList<>();

    private static final String QUERY_FIELD_NAME="query";

    private static final String TIME_TAG ="time";

    @Autowired
    ElasticsearchProperties elasticsearchProperties;

    private final ParseFieldRegistry<SignificanceHeuristicParser> significanceHeuristicParserRegistry = new ParseFieldRegistry<>(
            "significance_heuristic");


    @Override
    public String rewiteQuery(String dsl, RewriteQuery rewriteQuery) {
        JSONObject dslJson = JSONObject.parseObject(dsl);
        JSONObject boolJson =dslJson.getJSONObject(QUERY_FIELD_NAME);
        NamedXContentRegistry registry = new NamedXContentRegistry(namedXContents);
        try {
            XContentParser parser = JsonXContent.jsonXContent.createParser(registry, null, boolJson.toJSONString());
            QueryBuilder qb = AbstractQueryBuilder.parseInnerQueryBuilder(parser);
            BoolQueryBuilder boolQueryBuilder = (BoolQueryBuilder) qb;

            rewriteCondition(rewriteQuery,boolQueryBuilder);

           // System.out.println("qb = " + boolQueryBuilder.toString());
            JSONObject rewiteJson = JSONObject.parseObject(boolQueryBuilder.toString());
            dslJson.put(QUERY_FIELD_NAME,rewiteJson);
            JSONObject aggJson = dslJson.getJSONObject("aggs");
            if(aggJson !=null) {
                if (aggJson.toJSONString().indexOf("hostname") > 0) {
                    //logger.info("rewrite query dsl,dsl is [{}]", dslJson.toJSONString());
                }
            }
            //String esSearchUrl = buildEsSearchUrl();
            return dslJson.toJSONString();
        }catch(IOException e){
            logger.error("dynamic build dsl error:{}",e.getMessage());
        }
        return null;
    }



    @Override
    public SearchResponse parseResponse(String content) {
        NamedXContentRegistry registry = new NamedXContentRegistry(namedXContents);
        SearchResponse searchResponse =null;
        try {
            XContentParser parser = JsonXContent.jsonXContent.createParser(registry, null, content);
            searchResponse = SearchResponse.fromXContent(parser);
        } catch (Exception e) {
            logger.error(e.getMessage(),e);
        }
        return searchResponse;
    }

    public void rewriteCondition(RewriteQuery rewriteQuery, BoolQueryBuilder boolQueryBuilder) {
        if (!CollectionUtils.isEmpty(rewriteQuery.getFilterList())) {
            List<QueryBuilder> filterlist = boolQueryBuilder.filter();
            List<QueryBuilder> newFilterList = new ArrayList<>();
            for (JSONObject condition : rewriteQuery.getFilterList()) {
                for (Map.Entry<String, Object> entry : condition.entrySet()) {
                    String type = entry.getKey();
                    JSONObject json = condition.getJSONObject(type);
                    if (type.equalsIgnoreCase(DslConstants.TERM_QUERY_TYPE)) {
                            String queryType = json.getString("type");
                            if (queryType.equals(DslConstants.DSL_RANGE_TYPE)) {
                                String field = json.getString(DslConstants.FIELD_TAG);
                                RangeQueryBuilder rangeQueryBuilder = QueryBuilders.rangeQuery(field);
                                rangeQueryBuilder.gte(json.getJSONObject("query").getString("gte"));
                                rangeQueryBuilder.lte(json.getJSONObject("query").getString("lt"));
                                newFilterList = filterlist.stream().filter(query -> {
                                    if (query instanceof RangeQueryBuilder) {
                                        return false;
                                    }
                                    return true;
                                }).collect(Collectors.toList());
                                filterlist.clear();
                                newFilterList.add(rangeQueryBuilder);
                                newFilterList.forEach(builder -> {
                                    boolQueryBuilder.filter(builder);
                                });
                            }
                    } else {
                        continue;
                    }
                }
            }
        }
        if (!CollectionUtils.isEmpty(rewriteQuery.getShouldList())) {
            BoolQueryBuilder shouldBoolQuery = QueryBuilders.boolQuery();
            for (JSONObject json : rewriteQuery.getShouldList()) {
                String queryType = json.getString("type");
                if (queryType.equalsIgnoreCase(DslConstants.MULTI_MATCH_TYPE)) {
                    JSONArray valueList = json.getJSONArray(DslConstants.VALUE_TAG);
                    List<String> fieldList = new ArrayList<>();

                    json.getJSONArray(DslConstants.FIELD_TAG).forEach(key -> {
                        fieldList.add(key.toString());
                    });
                    String[] fields = new String[fieldList.size()];
                    fieldList.toArray(fields);
                   String property = json.getString("property");
                    valueList.forEach(value -> {
                       if("assetQuery".equalsIgnoreCase(property)){
                           shouldBoolQuery.should(QueryBuilders.multiMatchQuery(value,fields));
                        }else{
                            QueryStringQueryBuilder queryStringBuilder = QueryBuilders.queryStringQuery("*" + value.toString() + "*");
                            fieldList.forEach(field -> {
                                queryStringBuilder.field(field);
                            });
                            shouldBoolQuery.should(queryStringBuilder);
                        }
                    });
                }
                boolQueryBuilder.filter(shouldBoolQuery);
            }
        }

    }



    @Override
    public void afterPropertiesSet() throws Exception {
        registerQuery(new SearchPlugin.QuerySpec<>(MatchQueryBuilder.NAME, MatchQueryBuilder::new, MatchQueryBuilder::fromXContent));
        registerQuery(new SearchPlugin.QuerySpec<>(MatchPhraseQueryBuilder.NAME, MatchPhraseQueryBuilder::new, MatchPhraseQueryBuilder::fromXContent));
        registerQuery(new SearchPlugin.QuerySpec<>(MatchPhrasePrefixQueryBuilder.NAME, MatchPhrasePrefixQueryBuilder::new,
                MatchPhrasePrefixQueryBuilder::fromXContent));
        registerQuery(new SearchPlugin.QuerySpec<>(MultiMatchQueryBuilder.NAME, MultiMatchQueryBuilder::new, MultiMatchQueryBuilder::fromXContent));
        registerQuery(new SearchPlugin.QuerySpec<>(NestedQueryBuilder.NAME, NestedQueryBuilder::new, NestedQueryBuilder::fromXContent));
        registerQuery(new SearchPlugin.QuerySpec<>(DisMaxQueryBuilder.NAME, DisMaxQueryBuilder::new, DisMaxQueryBuilder::fromXContent));
        registerQuery(new SearchPlugin.QuerySpec<>(IdsQueryBuilder.NAME, IdsQueryBuilder::new, IdsQueryBuilder::fromXContent));
        registerQuery(new SearchPlugin.QuerySpec<>(MatchAllQueryBuilder.NAME, MatchAllQueryBuilder::new, MatchAllQueryBuilder::fromXContent));
        registerQuery(new SearchPlugin.QuerySpec<>(QueryStringQueryBuilder.NAME, QueryStringQueryBuilder::new, QueryStringQueryBuilder::fromXContent));
        registerQuery(new SearchPlugin.QuerySpec<>(BoostingQueryBuilder.NAME, BoostingQueryBuilder::new, BoostingQueryBuilder::fromXContent));
        registerQuery(new SearchPlugin.QuerySpec<>(BoolQueryBuilder.NAME, BoolQueryBuilder::new, BoolQueryBuilder::fromXContent));
        registerQuery(new SearchPlugin.QuerySpec<>(TermQueryBuilder.NAME, TermQueryBuilder::new, TermQueryBuilder::fromXContent));
        registerQuery(new SearchPlugin.QuerySpec<>(TermsQueryBuilder.NAME, TermsQueryBuilder::new, TermsQueryBuilder::fromXContent));
        registerQuery(new SearchPlugin.QuerySpec<>(FuzzyQueryBuilder.NAME, FuzzyQueryBuilder::new, FuzzyQueryBuilder::fromXContent));
        registerQuery(new SearchPlugin.QuerySpec<>(RegexpQueryBuilder.NAME, RegexpQueryBuilder::new, RegexpQueryBuilder::fromXContent));
        registerQuery(new SearchPlugin.QuerySpec<>(RangeQueryBuilder.NAME, RangeQueryBuilder::new, RangeQueryBuilder::fromXContent));
        registerQuery(new SearchPlugin.QuerySpec<>(PrefixQueryBuilder.NAME, PrefixQueryBuilder::new, PrefixQueryBuilder::fromXContent));
        registerQuery(new SearchPlugin.QuerySpec<>(WildcardQueryBuilder.NAME, WildcardQueryBuilder::new, WildcardQueryBuilder::fromXContent));
        registerQuery(
                new SearchPlugin.QuerySpec<>(ConstantScoreQueryBuilder.NAME, ConstantScoreQueryBuilder::new, ConstantScoreQueryBuilder::fromXContent));
        registerQuery(new SearchPlugin.QuerySpec<>(SpanTermQueryBuilder.NAME, SpanTermQueryBuilder::new, SpanTermQueryBuilder::fromXContent));
        registerQuery(new SearchPlugin.QuerySpec<>(SpanNotQueryBuilder.NAME, SpanNotQueryBuilder::new, SpanNotQueryBuilder::fromXContent));
        registerQuery(new SearchPlugin.QuerySpec<>(SpanWithinQueryBuilder.NAME, SpanWithinQueryBuilder::new, SpanWithinQueryBuilder::fromXContent));
        registerQuery(new SearchPlugin.QuerySpec<>(SpanContainingQueryBuilder.NAME, SpanContainingQueryBuilder::new,
                SpanContainingQueryBuilder::fromXContent));
        registerQuery(new SearchPlugin.QuerySpec<>(FieldMaskingSpanQueryBuilder.NAME, FieldMaskingSpanQueryBuilder::new,
                FieldMaskingSpanQueryBuilder::fromXContent));
        registerQuery(new SearchPlugin.QuerySpec<>(SpanFirstQueryBuilder.NAME, SpanFirstQueryBuilder::new, SpanFirstQueryBuilder::fromXContent));
        registerQuery(new SearchPlugin.QuerySpec<>(SpanNearQueryBuilder.NAME, SpanNearQueryBuilder::new, SpanNearQueryBuilder::fromXContent));
        registerQuery(new SearchPlugin.QuerySpec<>(SpanOrQueryBuilder.NAME, SpanOrQueryBuilder::new, SpanOrQueryBuilder::fromXContent));
        registerQuery(new SearchPlugin.QuerySpec<>(MoreLikeThisQueryBuilder.NAME, MoreLikeThisQueryBuilder::new,
                MoreLikeThisQueryBuilder::fromXContent));
        registerQuery(new SearchPlugin.QuerySpec<>(WrapperQueryBuilder.NAME, WrapperQueryBuilder::new, WrapperQueryBuilder::fromXContent));
        registerQuery(new SearchPlugin.QuerySpec<>(CommonTermsQueryBuilder.NAME, CommonTermsQueryBuilder::new, CommonTermsQueryBuilder::fromXContent));
        registerQuery(
                new SearchPlugin.QuerySpec<>(SpanMultiTermQueryBuilder.NAME, SpanMultiTermQueryBuilder::new, SpanMultiTermQueryBuilder::fromXContent));
        registerQuery(new SearchPlugin.QuerySpec<>(FunctionScoreQueryBuilder.NAME, FunctionScoreQueryBuilder::new,
                FunctionScoreQueryBuilder::fromXContent));
        registerQuery(
                new SearchPlugin.QuerySpec<>(SimpleQueryStringBuilder.NAME, SimpleQueryStringBuilder::new, SimpleQueryStringBuilder::fromXContent));
        registerQuery(new SearchPlugin.QuerySpec<>(TypeQueryBuilder.NAME, TypeQueryBuilder::new, TypeQueryBuilder::fromXContent));
        registerQuery(new SearchPlugin.QuerySpec<>(ScriptQueryBuilder.NAME, ScriptQueryBuilder::new, ScriptQueryBuilder::fromXContent));
        registerQuery(new SearchPlugin.QuerySpec<>(GeoDistanceQueryBuilder.NAME, GeoDistanceQueryBuilder::new, GeoDistanceQueryBuilder::fromXContent));
        registerQuery(new SearchPlugin.QuerySpec<>(GeoBoundingBoxQueryBuilder.NAME, GeoBoundingBoxQueryBuilder::new,
                GeoBoundingBoxQueryBuilder::fromXContent));
        registerQuery(new SearchPlugin.QuerySpec<>(GeoPolygonQueryBuilder.NAME, GeoPolygonQueryBuilder::new, GeoPolygonQueryBuilder::fromXContent));
        registerQuery(new SearchPlugin.QuerySpec<>(ExistsQueryBuilder.NAME, ExistsQueryBuilder::new, ExistsQueryBuilder::fromXContent));
        registerQuery(new SearchPlugin.QuerySpec<>(MatchNoneQueryBuilder.NAME, MatchNoneQueryBuilder::new, MatchNoneQueryBuilder::fromXContent));
        registerQuery(new SearchPlugin.QuerySpec<>(TermsSetQueryBuilder.NAME, TermsSetQueryBuilder::new, TermsSetQueryBuilder::fromXContent));
    }

    private void registerQuery(SearchPlugin.QuerySpec<?> spec) {
        namedWriteables.add(new NamedWriteableRegistry.Entry(QueryBuilder.class, spec.getName().getPreferredName(), spec.getReader()));
        namedXContents.add(new NamedXContentRegistry.Entry(QueryBuilder.class, spec.getName(),
                (p, c) -> spec.getParser().fromXContent(p)));
    }
    private void registerAggs(SearchPlugin.AggregationSpec agger){
        namedWriteables.add(new NamedWriteableRegistry.Entry(AggregationBuilder.class, agger.getName().getPreferredName(), agger.getReader()));
        namedXContents.add(new NamedXContentRegistry.Entry(AggregationBuilder.class, agger.getName(),
                (p, c) -> agger.getParser().parse(c.toString(),p)));
    }


    public  String buildEsSearchUrl(){
        String esIndex = "sec_all-"+ DateUtils.getCurrentDayFormat5();
        String esClusterUrl = String.format("%s://%s:%d", elasticsearchProperties.getSchema(), elasticsearchProperties.getHost(), elasticsearchProperties.getPort());
        return String.format("%s/%s/%s",esClusterUrl,esIndex,"_search");
    }
}
