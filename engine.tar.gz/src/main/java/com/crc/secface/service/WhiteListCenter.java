package com.crc.secface.service;

import com.alibaba.fastjson.JSONObject;
import com.crc.common.utils.DataUtils;
import com.crc.secface.config.GetSpringBean;
import com.crc.secface.entity.TbAlarmWhitelist;
import com.crc.secface.mapper.CommonMapper;
import lombok.extern.slf4j.Slf4j;

import java.util.LinkedList;
import java.util.List;
import java.util.concurrent.ConcurrentHashMap;

@Slf4j
public class WhiteListCenter {
    private static ConcurrentHashMap<String, List<TbAlarmWhitelist>> whiteListMap = new ConcurrentHashMap<>();
    private final static String WL_KEY = "whitelist";

    public static boolean isEmpty(){
        List<TbAlarmWhitelist> list = whiteListMap.get(WL_KEY);
        return list == null || list.isEmpty();
    }

    public static List<TbAlarmWhitelist> getAllList(){
        if (isEmpty()) {
            initWhitelistData();
        }
        return whiteListMap.get(WL_KEY);
    }


    public static void initWhitelistData() {
        List<TbAlarmWhitelist> allList = new LinkedList<>();
        CommonMapper commonMapper = GetSpringBean.getBean(CommonMapper.class);
        try {
            List<JSONObject> list = commonMapper.queryX("select * from tb_alarm_whitelist where is_enable = '0' and del_flag = '0' and approve_status = '1'");
            for (JSONObject wjson : list) {
                TbAlarmWhitelist wl = new TbAlarmWhitelist();
                wl.setSrcIp(DataUtils.getStr(wjson, "src_ip"));
                wl.setTitle(DataUtils.getStr(wjson, "title"));
                wl.setWhitelistId(DataUtils.getStr(wjson, "whitelist_id"));
                wl.setDestContent(DataUtils.getStr(wjson, "dest_content"));
                wl.setIsGlobal(DataUtils.getStr(wjson, "is_global"));
                wl.setBusModel(DataUtils.getStr(wjson, "bus_model"));
                wl.setDestType(DataUtils.getStr(wjson, "dest_type"));
                wl.setBusinessTerm(DataUtils.getStr(wjson, "business_term"));
                wl.setEffectDateEnd(DataUtils.getStr(wjson, "effect_date_end"));
                wl.setEffectDateStart(DataUtils.getStr(wjson, "effect_date_start"));
                wl.setEffectTimeStart(DataUtils.getStr(wjson, "effect_time_start"));
                wl.setEffectTimeEnd(DataUtils.getStr(wjson, "effect_time_end"));
                wl.setWhitelistId(DataUtils.getStr(wjson, "whitelist_id"));
                allList.add(wl);
            }
        } catch (Exception e) {
            log.error(e.getMessage(), e);
        }

        whiteListMap.put(WL_KEY, allList);
        log.info("白名单数量:[{}]", allList.size());
    }
}
