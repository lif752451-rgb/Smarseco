package com.crc.secface.service;

import com.alibaba.fastjson.JSONObject;
import com.crc.common.constants.LogConstants;
import com.crc.common.constants.LogConstantsX;
import com.crc.common.utils.*;
import com.crc.secface.argo.AlarmUtils;
import com.crc.secface.config.GetSpringBean;
import com.crc.secface.entity.TbAlarmWhitelist;
import com.crc.secface.entity.TbEvent;
import com.crc.secface.entity.TbEventModel;
import com.crc.secface.mapper.TbEventMapper;
import com.crc.sync.net.NewSegmentLoad;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;

import java.util.*;
import java.util.function.Function;
import java.util.stream.Collectors;

/**
 * @author simba@onlying.cn
 * @date 2020/10/23 13:49
 */
@Slf4j
public class WhitelistService {

    public static boolean isMatchV2(TbEventModel modelInfo, JSONObject jsonObject, boolean saveWhiteListEvent) {
        modelInfo.setChgFlag(false);
        boolean flag = isMatchV1(modelInfo, jsonObject, saveWhiteListEvent);
        if (flag) {
            String dstIp = jsonObject.getString(LogConstantsX.DEST_IP);
            if (modelInfo.getDestIpSize() > 1 && StringUtils.isNotBlank(modelInfo.getMatchDestIp())) {
                List<String> dstIpList = IpUtils.getIpsX(dstIp);
                Map<String, String> destIpMap = dstIpList.stream().collect(Collectors.toMap(Function.identity(), Function.identity(), (k1, k2) -> k2));
                List<String> newIpList = new ArrayList<>();
                destIpMap.forEach((k, v) -> {
                    if (!k.equalsIgnoreCase(modelInfo.getMatchDestIp())) {
                        newIpList.add(k);
                    }
                });
                List<String> remainList = new ArrayList<>();
                for (String ip : newIpList) {
                    jsonObject.put(LogConstantsX.DEST_IP, ip);
                    flag = isMatchV1(modelInfo, jsonObject, saveWhiteListEvent);
                    if (!flag) {
                        remainList.add(ip);
                    }
                }
                if (remainList.size() < 1) {
                    flag = true;
                } else {
                    flag = false;
                    String srcIp = jsonObject.getString(LogConstantsX.SRC_IP);
                    dstIp = String.join(",", remainList);
                    log.warn("剔除命中白名单IP，最后更新为{}-->{}", srcIp, dstIp);
                    jsonObject.put(LogConstantsX.DEST_IP, dstIp);
                }
            }
        }


        return flag;
    }

    private static boolean isMatchV1(TbEventModel modelInfo, JSONObject jsonObject, boolean saveWhiteListEvent) {
        //logger.info("开始校验白名单数据");
        String srcIp = jsonObject.getString(LogConstantsX.SRC_IP);
        String dstIp = jsonObject.getString(LogConstantsX.DEST_IP);
        String dateStr = jsonObject.getString(LogConstantsX.EVENT_TIME);
        if (dateStr == null) {
            dateStr = jsonObject.getString(LogConstantsX.LOG_START_TIME);
        }
        if (dateStr == null) {
            dateStr = jsonObject.getString(LogConstantsX.LOG_TIME);
        }
        String buName = JsonUtils.getStr(jsonObject, "dest_first_unit_name");
        if (StringUtils.isBlank(buName)) {
            buName = JsonUtils.getStr(jsonObject, "dest_asset_office");
        }
        boolean srcMatch = false;
        boolean destMatch = false;
        boolean modelMatch = false;
        List<String> srcIpList = IpUtils.getIpsX(srcIp);
        List<String> dstIpList = IpUtils.getIpsX(dstIp);
        modelInfo.setDestIpSize(dstIpList.size());
        TbAlarmWhitelist wl = null;
        boolean isWhiteListDestIpContain0000 = false;
        boolean isWhiteListSrcIp0000 = false;
        String matchModelStr = "0";
        if (!WhiteListCenter.isEmpty()) {
            List<TbAlarmWhitelist> whitelist = WhiteListCenter.getAllList();
            for (TbAlarmWhitelist tbAlarmWhitelist : whitelist) {
                srcMatch = false;
                destMatch = false;
                modelMatch = false;
                wl = tbAlarmWhitelist;
                if (StringUtils.isBlank(wl.getEffectTimeStart())) {
                    wl.setEffectTimeStart("00:00:00");
                }
                if (StringUtils.isBlank(wl.getEffectTimeEnd())) {
                    wl.setEffectTimeEnd("23:59:59");
                }

                isWhiteListSrcIp0000 = isContain0000(wl.getSrcIp());
                isWhiteListDestIpContain0000 = isContain0000(wl.getDestContent());
                for (String ip : srcIpList) {
                    srcMatch = isMatchSrc(ip, dateStr, wl, isWhiteListSrcIp0000);
                    if (srcMatch) {
                        break;
                    }
                }
                if (srcIpList.size() < 1) {
                    if ("*".equalsIgnoreCase(wl.getSrcIp())) {
                        srcMatch = true;
                    }
                }


                for (String ip : dstIpList) {
                    destMatch = isMatchDst(ip, dateStr, wl, buName);
                    if (destMatch) {
                        modelInfo.setMatchDestIp(ip);
                        break;
                    }
                }
                if (dstIpList.size() < 1) {
                    if ("*".equalsIgnoreCase(wl.getDestContent())) {
                        destMatch = true;
                        isWhiteListDestIpContain0000 = true;
                    }
                }

                if ("1".equalsIgnoreCase(wl.getIsGlobal())) {
                    modelMatch = true;
                    if (StringUtils.isBlank(wl.getBusModel()))
                        matchModelStr = "10";
                    else if ("1".equalsIgnoreCase(wl.getIsGlobal())) {
                        matchModelStr = "11";
                    } else {
                        matchModelStr = "12";
                    }
                } else {
                    if (StringUtils.isBlank(wl.getBusModel())) {
                        log.error("hejscrc 非全局白名单，匹配模型清单为空！" + wl.getWhitelistId());
                    } else {
                        for (String model : wl.getBusModel().split(",")) {
                            if (StringUtils.isBlank(model)) {
                                continue;
                            }
                            if (modelInfo != null && Objects.equals(model, modelInfo.getModelName())) {
                                modelMatch = true;
                                matchModelStr = "2";
                                break;
                            }
                            if (modelInfo != null && DataUtils.convertSpecialChar(modelInfo.getModelName()).equalsIgnoreCase(DataUtils.convertSpecialChar(model))) {
                                modelMatch = true;
                                matchModelStr = "3";
                                break;
                            }
                        }
                    }
                }
                //源IP和目标IP是一样的，且源IP命中了，白名单规则目标IP还有0.0.0.0,算命中白名单
                if (srcMatch && !destMatch && modelMatch && isWhiteListDestIpContain0000) {
                    if (!"0.0.0.0".equals(srcIp)) {
                        if (srcIp.equals(dstIp)) {
                            log.info("源IP和目标IP是一样的，且源IP命中了，白名单规则目标IP还有0.0.0.0,算命中白名单->" + wl.getWhitelistId());
                            destMatch = true;
                            matchModelStr = "4";
                        }
                    }
                }

                if (srcMatch && destMatch && modelMatch) {
                    modelInfo.setWhiteId(tbAlarmWhitelist.getWhitelistId());
                    break;
                }
            }
        }
        boolean flag = srcMatch && destMatch && modelMatch;
        //log.info("{} whitelistTest,modelId={},srcIp={},srcMatch={},destIp={},destMatch={},modelMatch={}", matchModelStr, modelInfo.getModelId(), srcIp, dstIp, srcMatch, destMatch, modelMatch);

        try {
            if (flag && modelInfo != null) {
                log.warn(matchModelStr + " hejscrc => " + modelInfo.getModelId() + "/" + modelInfo.getModelName() + " # " + srcIp + " => " + dstIp + "命中白名单！" + String.format("白名单内容：%s，白名单ID=%s,原始日志关联信息：index=%s,log_id=%s", wl.getTitle(), wl.getWhitelistId(), JsonUtils.getStr(jsonObject, LogConstants.ES_LOG_INDEX), JsonUtils.getStr(jsonObject, "ids")));
                if (saveWhiteListEvent) {
                    saveWhiteListEvent(modelInfo, jsonObject, IdGen.uuid(), wl.getWhitelistId());
                }
            }
        } catch (Exception e) {
            log.error(e.getMessage(), e);
        }
        return flag;
    }


    private static void saveWhiteListEvent(TbEventModel model, JSONObject json, String flowId, String whiteListId) {
        String evtId = "";
        try {
            TbEventMapper tbEventMapper = GetSpringBean.getBean(TbEventMapper.class);
            //事件基本信息
            TbEvent event = new TbEvent();
            String operator = "admin";
            event.setStatus("研判");
            event.setCreateBy(operator);
            event.setDelFlag(0);
            event.setAttackResult(model.getAttackResult());
            event.setBusModel(model.getModelId());
            event.setEventName(JsonUtils.getStr(json, LogConstantsX.LOG_NAME));
            event.setAttackType(model.getAttackTypeName());
            event.setEventLevel(model.getEventLevelName());
            String product = AlarmUtils.getDeviceName(json, model);
            event.setEventSource(product);
            event.setStatus("待处置");
            //event.setEventNo(event.getId());
            event.setCreateTime(JsonUtils.getDate(json, "event_time"));
            event.setAttackCount(JsonUtils.getLong(json, LogConstantsX.LOG_COUNT, 1));
            event.setCommitTime(event.getCreateTime());
            event.setAlarmTime(JsonUtils.getDate(json, LogConstantsX.LOG_START_TIME));
            event.setAuditTime(event.getCreateTime());
            event.setUpdateTime(new Date());
            event.setEventStartTime(event.getCreateTime());
            event.setIsWhitelist("1");
            String eventDesc = JsonUtils.getStr(json, LogConstantsX.ALERT_NAME);
            if (StringUtils.isBlank(eventDesc)) {
                eventDesc = JsonUtils.getStr(json, LogConstantsX.ALERT_NAME_BAK);
            }
            if (StringUtils.isBlank(eventDesc)) {
                eventDesc = JsonUtils.getStr(json, LogConstantsX.LOG_ORI_MSG);
            }
            event.setRemarks(eventDesc);
            event.setAttackIp(JsonUtils.getStr(json, "src_ip"));
            event.setAttackUrl(JsonUtils.getStr(json, "dest_ip"));
            event.setQaxtId(flowId);
            event.setId(event.getQaxtId());
            event.setWhitelistId(whiteListId);
            List<TbEvent> list = tbEventMapper.selectWhiteListTbEventList(event);
            if (list != null && list.size() > 0) {
                //已经有同样的事件
                log.info("已经存在相同白名单事件" + whiteListId + " " + event.getAttackIp() + " " + event.getAttackUrl());
                return;
            }
            if (event.getRegCompany() != null) {
                event.setRegCompany("");
            }
            tbEventMapper.insertTbEvent(event);
        } catch (Exception e) {
            log.error(e.getMessage(), e);
        }
    }

    private static boolean isContain0000(String src) {
        if (StringUtils.isBlank(src)) {
            return false;
        }
        if ("0.0.0.0".equalsIgnoreCase(src)) {
            return true;
        }
        String[] ipList = IpUtils.getIpSegment(src);
        boolean isWhiteListDestIpContain0000 = false;
        for (String ipp : ipList) {
            List<String> whiteDstList = IpUtils.getIpsX(ipp);
            if (isWhiteListDestIpContain0000) {
                break;
            }
            for (String ip : whiteDstList) {
                if ("0.0.0.0".equals(ip)) {
                    isWhiteListDestIpContain0000 = true;
                    break;
                }
            }
        }
        return isWhiteListDestIpContain0000;
    }

    private static boolean isMatchSrc(String ip, String dateStr, TbAlarmWhitelist wl, boolean isWhiteListSrcIp0000) {
        //logger.info("开始校验白名单源IP数据");
        boolean isMatch = false;
        String wlSrcIp = wl.getSrcIp();

        try {
            Date eventTime = DateUtils.UTCToCSTAndCheck4Date(dateStr);
            if (eventTime == null) {
                eventTime = new Date();
            }
            //计算时间段是否匹配
            String startTime = "";
            String endTime = "";

            //是否永久有效  /** 业务期限 0：有限期限 1：永久 */
            if (!"1".equalsIgnoreCase(wl.getBusinessTerm())) {
                if (StringUtils.isBlank(wl.getEffectDateStart()) || StringUtils.isBlank(wl.getEffectDateEnd())) {
                    log.error("白名单非法日期==" + wl.getWhitelistId());
                    return false;
                }
                startTime = wl.getEffectDateStart() + " " + wl.getEffectTimeStart();
                endTime = wl.getEffectDateEnd() + " " + wl.getEffectTimeEnd();
            } else {
                startTime = DateUtils.formatDateTime(eventTime, "yyyy-MM-dd") + " " + wl.getEffectTimeStart();
                endTime = DateUtils.formatDateTime(eventTime, "yyyy-MM-dd") + " " + wl.getEffectTimeEnd();
            }

            Date startDateTime = DateUtils.parseDate(startTime, DateUtils.DATE_FORMAT_STRING1);
            Date endDateTime = DateUtils.parseDate(endTime, DateUtils.DATE_FORMAT_STRING1);

            if ((eventTime.after(startDateTime) || eventTime.compareTo(startDateTime) == 0) && (eventTime.before(endDateTime) || eventTime.compareTo(endDateTime) == 0)) {
                isMatch = true;
            }
            if (isMatch) {
                //根据算法计算ip 是否匹配
                if ("*".equalsIgnoreCase(wlSrcIp)) {
                    isMatch = true;
                } else {
                    isMatch = NewSegmentLoad.isBelongThisSegment(wlSrcIp, ip);
                    if (isWhiteListSrcIp0000) {
                        //源IP还有0。0。0。0
                        if ("0.0.0.0".equalsIgnoreCase(ip)) {
                            isMatch = true;
                        }
                    }
                }
            }

        } catch (Exception e) {
            log.error(e.getMessage(), e);
        }
        return isMatch;
    }

    private static boolean isMatchDst(String ip, String dateStr, TbAlarmWhitelist wl, String buName) {
        //logger.info("开始校验白名单目标IP数据");
        boolean isMatch = false;
        String wlSrcIp = wl.getDestContent();

        try {
            Date eventTime = DateUtils.UTCToCSTAndCheck4Date(dateStr);
            if (eventTime == null) {
                eventTime = new Date();
            }
            //计算时间段是否匹配
            String startTime = "";
            String endTime = "";

            //是否永久有效  /** 业务期限 0：有限期限 1：永久 */
            if (!"1".equalsIgnoreCase(wl.getBusinessTerm())) {
                if (StringUtils.isBlank(wl.getEffectDateStart()) || StringUtils.isBlank(wl.getEffectDateEnd())) {
                    log.error("白名单非法日期==" + wl.getWhitelistId());
                    return false;
                }
                startTime = wl.getEffectDateStart() + " " + wl.getEffectTimeStart();
                endTime = wl.getEffectDateEnd() + " " + wl.getEffectTimeEnd();
            } else {
                startTime = DateUtils.formatDateTime(eventTime, "yyyy-MM-dd") + " " + wl.getEffectTimeStart();
                endTime = DateUtils.formatDateTime(eventTime, "yyyy-MM-dd") + " " + wl.getEffectTimeEnd();
            }

            Date startDateTime = DateUtils.parseDate(startTime, DateUtils.DATE_FORMAT_STRING1);
            Date endDateTime = DateUtils.parseDate(endTime, DateUtils.DATE_FORMAT_STRING1);

            if ((eventTime.after(startDateTime) || eventTime.compareTo(startDateTime) == 0) && (eventTime.before(endDateTime) || eventTime.compareTo(endDateTime) == 0)) {
                isMatch = true;
            }
            if (isMatch) {
                //根据算法计算ip 是否匹配
                if (!"1".equalsIgnoreCase(wl.getDestType())) {
                    if ("*".equalsIgnoreCase(wlSrcIp)) {
                        isMatch = true;
                    } else {
                        isMatch = NewSegmentLoad.isBelongThisSegment(wlSrcIp, ip);
                        //目标IP还有0。0。0。0
                        if ("0.0.0.0".equalsIgnoreCase(ip) && !"*".equalsIgnoreCase(wl.getSrcIp())) {
                            isMatch = true;
                        }
                    }
                } else {
                    if (StringUtils.isBlank(buName)) {
                        isMatch = false;//目标组织为空，且需要比对组织，设置false
                    } else {
                        //比对组织
                        if (StringUtils.isNotBlank(wl.getDestContent())) {
                            for (String wBu : wl.getDestContent().split(",")) {
                                if (wBu.contains(buName)) {
                                    isMatch = true;
                                    break;
                                }
                            }
                        }
                    }
                }
            }

        } catch (Exception e) {
            log.error(e.getMessage(), e);
        }
        return isMatch;
    }
}
