package com.crc.secface.service;

import cn.hutool.core.collection.CollUtil;
import cn.hutool.core.date.DateUtil;
import cn.hutool.core.util.ReflectUtil;
import com.alibaba.fastjson.JSONArray;
import com.alibaba.fastjson.JSONObject;
import com.crc.common.constants.Constants;
import com.crc.common.enums.StatusEnum;
import com.crc.common.utils.DataUtils;
import com.crc.common.utils.DictUtil;
import com.crc.common.utils.JsonUtils;
import com.crc.secface.entity.*;
import com.crc.secface.mapper.TbAssetChangeRecordMapper;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.*;
import java.util.stream.Collectors;
import java.util.stream.Stream;

import static com.crc.common.constants.AssetConstant.INTERNAL_IP_FIELDS;
import static com.crc.common.constants.AssetConstant.OPINION_FIELDS;
import static com.crc.common.constants.Constants.*;
import static com.crc.common.constants.Constants.Symbol.*;
import static com.crc.common.enums.DictTypeEnum.*;
import static com.crc.sync.data.AlarmAssetSyncToDb.SSP_CMDB;


@Slf4j
@Service
public class AssetRecordService {

    /**
     * 资产状态
     */
    private Map<String, String> operatingStatus;

    /**
     * 资产等级
     */
    private Map<String, String> keyAsset;

    /**
     * 环境类型
     */
    private Map<String, String> environmentType;

    /**
     * 资源类型
     */
    private Map<String, String> sourceType;

    /**
     * 等保定级
     */
    private Map<String, String> equalProtectionLevel;

    @Autowired
    TbAssetChangeRecordMapper assetChangeRecordMapper;

    public void addChangeRecord(TbAsset oldAsset,TbAsset asset) {
        try {
            addAssetChangeRecord(asset, oldAsset, TbAsset.class, "asset_change_column");
        } catch (Exception e) {
            log.error(e.getMessage(),e);
        }
    }

    private void addAssetChangeRecord(TbAsset newAsset, TbAsset oldAsset, Class<TbAsset> tClass, String type) {
        Map<String, String> labelAndValue = DictUtil.getDict(type).stream()
                .collect(Collectors.toMap(SysDictData::getDictValue, SysDictData::getDictLabel));
        addAssetChangeRecord(newAsset, oldAsset, tClass, labelAndValue);
    }

    private void addAssetChangeRecord(Object newAsset, Object oldAsset, Class<?> tClass,
                                     Map<String, String> labelAndValue) {
        if (CollUtil.isNotEmpty(labelAndValue)) {
            // 获取资产相关数据字典
            findAssetDict();
            // 获取资产变更字段
            List<ChangeInfo> list = getChangeInfoList(newAsset, oldAsset, tClass, labelAndValue);
            AssetChangeRecord assetChangeRecord = buildAssetChangeRecord(newAsset, tClass, list);
            if (Objects.nonNull(assetChangeRecord)) {
                assetChangeRecordMapper.insert(assetChangeRecord);
            }
        }
    }

    /**
     * 构建新增资产变更记录实体类
     *
     * @param newAsset 变更后的值
     * @param tClass 映射实体对象class
     * @param list 变更字段
     * @return AssetChangeRecord
     */
    private AssetChangeRecord buildAssetChangeRecord(Object newAsset, Class<?> tClass, List<ChangeInfo> list) {
        // 判断资产变更字段、和内网ip 是否为空
        if (CollUtil.isNotEmpty(list) && ReflectUtil.hasField(tClass, INTERNAL_IP_FIELDS)) {
            String internalIp = String.valueOf(ReflectUtil.getFieldValue(newAsset, INTERNAL_IP_FIELDS));
            AssetChangeRecord assetChangeRecord = new AssetChangeRecord();
            assetChangeRecord.setUpdateByLabel("系统");
            assetChangeRecord.setCreateTime(new Date());
            assetChangeRecord.setUpdateTime(new Date());
            assetChangeRecord.setUpdateBy("system");
            assetChangeRecord.setCreateBy("system");
            assetChangeRecord.setInternalIp(internalIp);
            assetChangeRecord.setSource(String.valueOf(SSP_CMDB));
            assetChangeRecord.setChangeContent(JSONObject.toJSONString(list));
            assetChangeRecord
                    .setChangeColumn(list.stream().map(ChangeInfo::getNameCN).collect(Collectors.joining(COMMA)));
            return assetChangeRecord;
        }
        log.info("构建资产变更记录缺乏关键参数");
        return null;
    }

    /**
     * 获取资产变更字段
     *
     * @param newAsset 变更后的值
     * @param oldAsset 变前的值
     * @param tClass 映射实体对象class
     * @param labelAndValue 需要记录变更字段
     * @return List
     */
    private List<ChangeInfo> getChangeInfoList(Object newAsset, Object oldAsset, Class<?> tClass,
                                               Map<String, String> labelAndValue) {
        // 变更后的值newAsset 变更前的值oldAsset
        DataUtils.convertSpecialChar(newAsset);
        List<ChangeInfo> list = new ArrayList<>();
        String opinion = ReflectUtil.hasField(tClass, OPINION_FIELDS)
                ? String.valueOf(ReflectUtil.getFieldValue(newAsset, OPINION_FIELDS)) : null;
        for (Map.Entry<String, String> entry : labelAndValue.entrySet()) {
            String attr = entry.getKey();
            // 字段不存在 不记录
            if (!ReflectUtil.hasField(tClass, attr)) {
                continue;
            }
            log.info("变更记录检查字段名：" + attr + "对应字段名称：" + entry.getValue());
            String newValue = this.getFieldValue(attr, newAsset);
            String oldValue = this.getFieldValue(attr, oldAsset);
            log.info("变更字段，变更前值：" + oldValue + " 变更后值：" + newValue);
            // 变更前、变更后 值都为空或值相等 不记录
            if (StringUtils.isAllBlank(newValue, oldValue) || newValue.equals(oldValue)) {
                continue;
            }
            ChangeInfo changeInfo = new ChangeInfo();
            changeInfo.setName(attr);
            changeInfo.setNameCN(entry.getValue());
            changeInfo.setRemark(opinion);
            changeInfo.setNewValue(newValue);
            changeInfo.setOldValue(oldValue);
            list.add(changeInfo);
        }
        return list;
    }


    private String getFieldValue(String attr, Object obj) {
        Object fieldValue = ReflectUtil.getFieldValue(obj, attr);
        String value = "";
        if (Objects.isNull(fieldValue)) {
            return value;
        }
        if ("operatingStatus".equals(attr)) {
            value = operatingStatus.get(String.valueOf(fieldValue));
        } else if ("keyAsset".equals(attr)) {
            value = keyAsset.get(String.valueOf(fieldValue));
        } else if ("environmentType".equals(attr)) {
            value = environmentType.get(String.valueOf(fieldValue));
        } else if ("sourceType".equals(attr)) {
            value = sourceType.get(String.valueOf(fieldValue));
        } else if ("equalProtectionLevel".equals(attr)) {
            value = equalProtectionLevel.get(String.valueOf(fieldValue));
        } else if ("dutyUsers".equals(attr) || "operatingUsers".equals(attr)) {
            if (fieldValue instanceof List) {
                List<AssetPerson> assetPersonList =
                        JSONArray.parseArray(JsonUtils.toJSONString(fieldValue), AssetPerson.class);
                value = assetPersonList.stream()
                        .map(assetPerson -> Stream
                                .of(assetPerson.getUserName(), assetPerson.getEmail(), assetPerson.getPhone())
                                .filter(StringUtils::isNotEmpty).collect(Collectors.joining(SLASH)))
                        .collect(Collectors.joining(COMMA));
            }
        } else if ("assetPower".equals(attr) || "internetPublic".equals(attr) || "isCombatOff".equals(attr)
                || "isCombatPlan".equals(attr) || "isPersonalInfo".equals(attr) || "centralizedSystem".equals(attr)) {
            value = convertJudge(fieldValue);
        } else if ("transformationCompleted".equals(attr)) {
            Integer transformationCompleted = DataUtils.toInt(fieldValue);
            value = StatusEnum.YES.getValue().equals(transformationCompleted) ? FINISHED
                    : StatusEnum.NO.getValue().equals(transformationCompleted) ? UNFINISHED : Constants.NULL_STR;
        } else if ("offStartTime".equals(attr) || "offEndTime".equals(attr)) {
            if (fieldValue instanceof Date) {
                value = DateUtil.formatDateTime((Date)fieldValue);
            }
        } else if ("expirtTime".equals(attr) || "equalProtectionFirstTime".equals(attr)) {
            if (fieldValue instanceof Date) {
                value = DateUtil.formatDate((Date)fieldValue);
            }
        }
        if (StringUtils.isEmpty(value)) {
            value = String.valueOf(fieldValue);
        }
        return value;
    }

    /**
     * 转换判断
     *
     * @param source Integer
     * @return 0 否 1 是
     */
    public static String convertJudge(Object source) {
        if (null == source) {
            return Constants.BLANK_STR;
        }
        if (Constants.SYS_WHETHER_NO.equals(source.toString())) {
            return Constants.NO;
        } else if (Constants.SYS_WHETHER_YES.equals(source.toString())) {
            return Constants.YES;
        }
        return source.toString();
    }

    private void findAssetDict() {
        if (CollUtil.isEmpty(operatingStatus)) {
            operatingStatus = DictUtil.getMapValueLabel(OPERATING_STATUS.getName());
        }
        if (CollUtil.isEmpty(keyAsset)) {
            keyAsset = DictUtil.getMapValueLabel(KEY_ASSET.getName());
        }
        if (CollUtil.isEmpty(environmentType)) {
            environmentType = DictUtil.getMapValueLabel(ENVIRONMENT_TYPE.getName());
        }
        if (CollUtil.isEmpty(sourceType)) {
            sourceType = DictUtil.getMapValueLabel(SOURCE_TYPE.getName());
        }
        if (CollUtil.isEmpty(equalProtectionLevel)) {
            equalProtectionLevel = DictUtil.getMapValueLabel(EQUAL_PROTECTION_LEVEL.getName());
        }
    }
}
