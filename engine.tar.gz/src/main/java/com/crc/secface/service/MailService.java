package com.crc.secface.service;


import com.crc.secface.entity.MailDTO;

/**
 * @author SHUFENGFENG
 */
public interface MailService {
    /**
     * 发送邮件
     * @param mailDTO
     * @return
     */
    MailDTO sendHtmlMail(MailDTO mailDTO);

    /**
     * 普通格式邮件
     * @param mailDTO
     * @return
     */
    MailDTO sendMail(MailDTO mailDTO);
}
