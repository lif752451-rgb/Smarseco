package com.crc.secface.mapper;

import com.crc.secface.entity.AssetChangeRecord;
import org.apache.ibatis.annotations.Mapper;

import java.util.List;

/**
 * @description tb_asset_change_record
 * @author hejingsheng1
 * @date 2023-09-21
 */
@Mapper
public interface TbAssetChangeRecordMapper {

    /**
     * 新增
     * @author hejingsheng1
     * @date 2023/09/21
     **/
    int insert(AssetChangeRecord tbAssetChangeRecord);

    /**
     * 刪除
     * @author hejingsheng1
     * @date 2023/09/21
     **/
    int delete(int id);

    /**
     * 更新
     * @author hejingsheng1
     * @date 2023/09/21
     **/
    int update(AssetChangeRecord tbAssetChangeRecord);

    /**
     * 查询 根据主键 id 查询
     * @author hejingsheng1
     * @date 2023/09/21
     **/
    AssetChangeRecord load(int id);

}