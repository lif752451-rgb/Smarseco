package com.crc.secface.mapper;

import com.crc.secface.entity.TbAlarmCombatReport;
import com.crc.secface.entity.TbAlarmReport;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;

import java.util.List;

/**
 * @author zhengkai.blog.csdn.net
 * @description 威胁管理-告警主表(发起表)
 * @date 2023-07-24
 */
@Mapper
public interface TbAlarmReportMapper {

    /**
     * 新增
     *
     * @author zhengkai.blog.csdn.net
     * @date 2023/07/24
     **/
    int insert(TbAlarmReport tbAlarmReport);

    /**
     * 刪除
     *
     * @author zhengkai.blog.csdn.net
     * @date 2023/07/24
     **/
    int delete(int id);

    /**
     * 更新
     *
     * @author zhengkai.blog.csdn.net
     * @date 2023/07/24
     **/
    int update(TbAlarmReport tbAlarmReport);

    /**
     * 查询 根据主键 id 查询
     *
     * @author zhengkai.blog.csdn.net
     * @date 2023/07/24
     **/
    TbAlarmReport load(String id);

    TbAlarmCombatReport loadCombat(String id);

    /**
     * 查询 分页查询
     *
     * @author zhengkai.blog.csdn.net
     * @date 2023/07/24
     **/
    List<TbAlarmReport> pageList(int offset, int pagesize);

    List<TbAlarmReport> selectListByInternetIp(List<String> ips);
    List<TbAlarmCombatReport> selectCombatListByInternetIp(List<String> ips);
    /**
     * 查询 分页查询 count
     *
     * @author zhengkai.blog.csdn.net
     * @date 2023/07/24
     **/
    int pageListCount(int offset, int pagesize);

}
