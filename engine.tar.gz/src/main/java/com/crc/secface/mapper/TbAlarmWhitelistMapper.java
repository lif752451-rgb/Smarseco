package com.crc.secface.mapper;

import com.crc.secface.entity.TbAlarmWhitelist;

import java.util.List;

/**
 * 告警白名单Mapper接口
 *
 * @author wst
 * @date 2021-11-22
 */
public interface TbAlarmWhitelistMapper
{
    /**
     * 查询告警白名单
     *
     * @param id 告警白名单ID
     * @return 告警白名单
     */
    public TbAlarmWhitelist selectTbAlarmWhitelistById(Long id);

    /**
     * 查询告警白名单列表
     *
     * @param tbAlarmWhitelist 告警白名单
     * @return 告警白名单集合
     */
    public List<TbAlarmWhitelist> selectTbAlarmWhitelistList(TbAlarmWhitelist tbAlarmWhitelist);

    /**
     * 新增告警白名单
     *
     * @param tbAlarmWhitelist 告警白名单
     * @return 结果
     */
    public int insertTbAlarmWhitelist(TbAlarmWhitelist tbAlarmWhitelist);

    /**
     * 修改告警白名单
     *
     * @param tbAlarmWhitelist 告警白名单
     * @return 结果
     */
    public int updateTbAlarmWhitelist(TbAlarmWhitelist tbAlarmWhitelist);

    /**
     * 删除告警白名单
     *
     * @param id 告警白名单ID
     * @return 结果
     */
    public int deleteTbAlarmWhitelistById(Long id);

    /**
     * 批量删除告警白名单
     *
     * @param ids 需要删除的数据ID
     * @return 结果
     */
    public int deleteTbAlarmWhitelistByIds(Long[] ids);
}
