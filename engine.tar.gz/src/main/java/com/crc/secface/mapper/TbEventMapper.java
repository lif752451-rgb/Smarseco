package com.crc.secface.mapper;


import com.crc.secface.entity.TbEvent;

import java.util.List;
import java.util.Map;

/**
 * 实时事件Mapper接口
 *
 * @author wst
 * @date 2020-07-17
 */
public interface TbEventMapper {
    public TbEvent getAlarmId(String id);

    /**
     * 查询实时事件
     *
     * @param tbEvent 实时事件ID
     * @return 实时事件
     */
    public TbEvent selectTbEventById(TbEvent tbEvent);


    public int insertTbEvent(TbEvent tbEvent);


    /**
     * 根据
     * @param tbEvent
     */
    void updateAiData(TbEvent tbEvent);

    List<TbEvent> selectWhiteListTbEventList(TbEvent event);

    TbEvent getAlarmCombatId(String flowId);
}
