package com.crc.secface.mapper;

import com.crc.secface.entity.TbDatabaseIndex;
import com.crc.secface.entity.TbEventModel;
import org.apache.ibatis.annotations.Param;

import java.util.List;
import java.util.Map;

/**
 * 告警模型Mapper接口
 *
 * @author wst
 * @date 2022-03-15
 */
public interface TbEventModelMapper {
    public int selectModelCount(@Param("modelId") String modelId);

    /**
     * 查询告警模型
     *
     * @param id 告警模型ID
     * @return 告警模型
     */
    public TbEventModel selectTbEventModelById(String id);

    /**
     * 查询告警模型列表
     *
     * @param tbEventModel 告警模型
     * @return 告警模型集合
     */
    public List<TbEventModel> selectTbEventModelList(TbEventModel tbEventModel);

    /**
     * 新增告警模型
     *
     * @param tbEventModel 告警模型
     * @return 结果
     */
    public int insertTbEventModel(TbEventModel tbEventModel);

    /**
     * 修改告警模型
     *
     * @param tbEventModel 告警模型
     * @return 结果
     */
    public int updateTbEventModel(TbEventModel tbEventModel);

    /**
     * 删除告警模型
     *
     * @param id 告警模型ID
     * @return 结果
     */
    public int deleteTbEventModelById(String id);

    /**
     * 批量删除告警模型
     *
     * @param ids 需要删除的数据ID
     * @return 结果
     */
    public int deleteTbEventModelByIds(String[] ids);


    /**
     * 查找可用的聚合告警模型
     *
     * @return
     */
    List<TbEventModel> findAviableAggsEvent();

    Map<String, String> getIndexAndSource(TbEventModel tbEventModel);

    TbDatabaseIndex getEsConfig(String id);
}
