package com.crc.secface.mapper;

import com.crc.secface.entity.MessageTemplate;
import org.apache.ibatis.annotations.Param;

import java.util.List;

/**
 * @author simba@onlying.cn
 * @date 2020/10/13 14:16
 */
public interface MessageTemplateMapper {

    public MessageTemplate selectByCode(@Param("code") String code);

    public List<MessageTemplate> selectAll();
}
