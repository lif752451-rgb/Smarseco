package com.crc.secface.mapper;

import com.crc.secface.entity.DeptStat;
import com.crc.secface.entity.TbRiskStatic;
import org.apache.ibatis.annotations.Param;

import java.util.List;

/**
 * 【请填写功能名称】Mapper接口
 *
 * @author wst
 * @date 2020-09-03
 */
public interface TbRiskStaticMapper {
    /**
     * 查询【请填写功能名称】
     *
     * @param id 【请填写功能名称】ID
     * @return 【请填写功能名称】
     */
    public TbRiskStatic selectTbRiskStaticById(String id);

    /**
     * 查询【请填写功能名称】列表
     *
     * @param tbRiskStatic 【请填写功能名称】
     * @return 【请填写功能名称】集合
     */
    public List<TbRiskStatic> selectTbRiskStaticList(TbRiskStatic tbRiskStatic);

    public List<TbRiskStatic> selectByProductList(@Param("productTypes") List<Integer> productTypes);

    public List<TbRiskStatic> selectByProductListWithStatDept(@Param("productTypes") List<Integer> productTypes,
                                                              @Param("deptName") String deptName);

    public List<TbRiskStatic> selectByDimision(@Param("dimision") String dimision);

    public List<TbRiskStatic> selectByDimisionWithDept(@Param("dimision") String dimision, @Param("deptName") String deptName);

    /**
     * 新增【请填写功能名称】
     *
     * @param tbRiskStatic 【请填写功能名称】
     * @return 结果
     */
    public int insertTbRiskStatic(TbRiskStatic tbRiskStatic);

    /**
     * 修改【请填写功能名称】
     *
     * @param tbRiskStatic 【请填写功能名称】
     * @return 结果
     */
    public int updateTbRiskStatic(TbRiskStatic tbRiskStatic);

    /**
     * 删除【请填写功能名称】
     *
     * @param id 【请填写功能名称】ID
     * @return 结果
     */
    public int deleteTbRiskStaticById(String id);

    /**
     * 批量删除【请填写功能名称】
     *
     * @param ids 需要删除的数据ID
     * @return 结果
     */
    public int deleteTbRiskStaticByIds(String[] ids);

    public List<String> selectDistinctProduct();

    public List<DeptStat> selectDeptStat();
}
