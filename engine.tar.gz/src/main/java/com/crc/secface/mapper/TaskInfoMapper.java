package com.crc.secface.mapper;

import com.crc.secface.entity.TaskDetail;
import com.crc.secface.entity.TaskError;
import com.crc.secface.entity.TaskInfo;
import org.apache.ibatis.annotations.Param;

import java.util.List;

/**
 * 【请填写功能名称】Mapper接口
 *
 * @author wst
 * @date 2020-10-21
 */
public interface TaskInfoMapper {
    /**
     * 查询【请填写功能名称】
     *
     * @param id 【请填写功能名称】ID
     * @return 【请填写功能名称】
     */
    public TaskInfo selectTbTaskInfoById(Long id);


    public TaskInfo selectByCode(@Param("code") String code);

    /**
     * 查询【请填写功能名称】列表
     *
     * @param tbTaskInfo 【请填写功能名称】
     * @return 【请填写功能名称】集合
     */
    public List<TaskInfo> selectTbTaskInfoList(TaskInfo tbTaskInfo);

    /**
     * 新增【请填写功能名称】
     *
     * @param tbTaskInfo 【请填写功能名称】
     * @return 结果
     */
    public int insertTbTaskInfo(TaskInfo tbTaskInfo);

    /**
     * 修改【请填写功能名称】
     *
     * @param tbTaskInfo 【请填写功能名称】
     * @return 结果
     */
    public int updateTbTaskInfo(TaskInfo tbTaskInfo);

    /**
     * 删除【请填写功能名称】
     *
     * @param id 【请填写功能名称】ID
     * @return 结果
     */
    public int deleteTbTaskInfoById(Long id);

    /**
     * 批量删除【请填写功能名称】
     *
     * @param ids 需要删除的数据ID
     * @return 结果
     */
    public int deleteTbTaskInfoByIds(Long[] ids);

    public int insertTaskDetail(TaskDetail taskDetail);

    public int insertTaskError(TaskError taskError);

    public int deleteTaskDetailHis(@Param("dateStr") String dateStr);
}
