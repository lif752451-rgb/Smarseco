package com.crc.secface.mapper;


import com.crc.secface.entity.SendPolicy;
import com.crc.secface.entity.SendPolicyQuery;

import java.util.List;

/**
 * 【请填写功能名称】Mapper接口
 *
 * @author wst
 * @date 2020-12-08
 */
public interface SendPolicyMapper {
    public void updateFlag();

    public void deleteFlag(SendPolicy tbWhitelistRule);

    public long getMaxId();

    public long getMinId();

    public List<SendPolicy> selectTbSendPolicyListByRange(SendPolicy tbSendPolicy);

    /**
     * 查询【请填写功能名称】
     *
     * @param id 【请填写功能名称】ID
     * @return 【请填写功能名称】
     */

    public SendPolicy selectPolicyWithConfigById(Long id);

    public SendPolicy selectPolicyById(Long id);

    /**
     * 查询【请填写功能名称】列表
     *
     * @param tbSendPolicy 【请填写功能名称】
     * @return 【请填写功能名称】集合
     */
    public List<SendPolicy> selectTbSendPolicyList(SendPolicy tbSendPolicy);

    public List<SendPolicy> selectSendPolicyList(SendPolicyQuery query);

    public List<SendPolicy> selectByQuery(SendPolicyQuery query);

    /**
     * 新增【请填写功能名称】
     *
     * @param tbSendPolicy 【请填写功能名称】
     * @return 结果
     */
    public int insertTbSendPolicy(SendPolicy tbSendPolicy);

    /**
     * 修改【请填写功能名称】
     *
     * @param tbSendPolicy 【请填写功能名称】
     * @return 结果
     */
    public int updateTbSendPolicy(SendPolicy tbSendPolicy);

    /**
     * 删除【请填写功能名称】
     *
     * @param id 【请填写功能名称】ID
     * @return 结果
     */
    public int deleteTbSendPolicyById(Long id);

    /**
     * 批量删除【请填写功能名称】
     *
     * @param ids 需要删除的数据ID
     * @return 结果
     */
    public int deleteTbSendPolicyByIds(Long[] ids);

    long getTotal(SendPolicy rule);

    List<SendPolicy> selectTbSendPolicyListByLimit(SendPolicy rule);
}
