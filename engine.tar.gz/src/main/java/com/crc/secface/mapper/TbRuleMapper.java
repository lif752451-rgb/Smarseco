package com.crc.secface.mapper;


import com.crc.secface.entity.TbRule;

import java.util.List;

/**
 * 规则模型Mapper接口
 *
 * @author wst
 * @date 2020-09-02
 */
public interface TbRuleMapper {
    /**
     * 查询规则模型列表
     *
     * @param tbRuleModel 规则模型
     * @return 规则模型集合
     */
    public List<TbRule> selectTbRuleModelList(TbRule tbRuleModel);

    public List<TbRule> selectTbRuleModelListByRange(TbRule tbRuleModel);

    public long getMaxId();

    public long getMinId();

    /**
     * 新增【请填写功能名称】
     *
     * @param tbWhitelistRule 【请填写功能名称】
     * @return 结果
     */
    public int insertTbRuleModel(TbRule tbWhitelistRule);

    /**
     * 修改【请填写功能名称】
     *
     * @param tbWhitelistRule 【请填写功能名称】
     * @return 结果
     */
    public int updateTbRuleModel(TbRule tbWhitelistRule);

    TbRule selectTbRuleModelById(Long id);

    long getTotal(TbRule rule);

    List<TbRule> selectTbRuleModelListByLimit(TbRule rule);
}
