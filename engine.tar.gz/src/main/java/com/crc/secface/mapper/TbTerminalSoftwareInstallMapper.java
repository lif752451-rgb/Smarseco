package com.crc.secface.mapper;

import com.crc.secface.entity.TbTerminalSoftwareInstall;

import java.util.List;

/**
 * 终端软件安装统计Mapper接口
 *
 * @author wst
 * @date 2021-11-23
 */
public interface TbTerminalSoftwareInstallMapper
{
    /**
     * 查询终端软件安装统计
     *
     * @param id 终端软件安装统计ID
     * @return 终端软件安装统计
     */
    public TbTerminalSoftwareInstall selectTbTerminalSoftwareInstallById(String id);

    /**
     * 查询终端软件安装统计列表
     *
     * @param tbTerminalSoftwareInstall 终端软件安装统计
     * @return 终端软件安装统计集合
     */
    public List<TbTerminalSoftwareInstall> selectTbTerminalSoftwareInstallList(TbTerminalSoftwareInstall tbTerminalSoftwareInstall);

    /**
     * 新增终端软件安装统计
     *
     * @param tbTerminalSoftwareInstall 终端软件安装统计
     * @return 结果
     */
    public int insertTbTerminalSoftwareInstall(TbTerminalSoftwareInstall tbTerminalSoftwareInstall);

    /**
     * 修改终端软件安装统计
     *
     * @param tbTerminalSoftwareInstall 终端软件安装统计
     * @return 结果
     */
    public int updateTbTerminalSoftwareInstall(TbTerminalSoftwareInstall tbTerminalSoftwareInstall);

    /**
     * 删除终端软件安装统计
     *
     * @param id 终端软件安装统计ID
     * @return 结果
     */
    public int deleteTbTerminalSoftwareInstallById(Long id);

    /**
     * 批量删除终端软件安装统计
     *
     * @param ids 需要删除的数据ID
     * @return 结果
     */
    public int deleteTbTerminalSoftwareInstallByIds(Long[] ids);

    TbTerminalSoftwareInstall selectTbTerminalSoftwareInstallByIp(String ip);
}
