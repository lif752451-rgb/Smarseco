package com.crc.secface.mapper;

import com.crc.secface.entity.TbIpPluggingStrategy;
import org.apache.ibatis.annotations.Mapper;

import java.util.List;

/**
 * @description 封堵策略表
 * @author hejingsheng1
 * @date 2023-08-03
 */
@Mapper
public interface TbIpPluggingStrategyMapper {

    /**
     * 新增
     * @author zhengkai.blog.csdn.net
     * @date 2023/08/03
     **/
    int insert(TbIpPluggingStrategy tbIpPluggingStrategy);

    /**
     * 刪除
     * @author zhengkai.blog.csdn.net
     * @date 2023/08/03
     **/
    int delete(int id);

    /**
     * 更新
     * @author zhengkai.blog.csdn.net
     * @date 2023/08/03
     **/
    int update(TbIpPluggingStrategy tbIpPluggingStrategy);

    /**
     * 查询 根据主键 id 查询
     * @author zhengkai.blog.csdn.net
     * @date 2023/08/03
     **/
    TbIpPluggingStrategy load(int id);

    /**
     * 查询 分页查询
     * @author zhengkai.blog.csdn.net
     * @date 2023/08/03
     **/
    List<TbIpPluggingStrategy> pageList(int offset, int pagesize);
    List<TbIpPluggingStrategy> getList();

    /**
     * 查询 分页查询 count
     * @author zhengkai.blog.csdn.net
     * @date 2023/08/03
     **/
    int pageListCount(int offset,int pagesize);

    List<String> getIocList();
}
