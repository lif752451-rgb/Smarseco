package com.crc.secface.mapper;

import com.crc.secface.entity.TbRiskStaticTrend;

import java.util.List;

/**
 * 【请填写功能名称】Mapper接口
 *
 * @author wst
 * @date 2020-09-07
 */
public interface TbRiskStaticTrendMapper {
    /**
     * 查询【请填写功能名称】
     *
     * @param id 【请填写功能名称】ID
     * @return 【请填写功能名称】
     */
    public TbRiskStaticTrend selectTbRiskStaticTrendById(String id);

    /**
     * 查询【请填写功能名称】列表
     *
     * @param tbRiskStaticTrend 【请填写功能名称】
     * @return 【请填写功能名称】集合
     */
    public List<TbRiskStaticTrend> selectTbRiskStaticTrendList(TbRiskStaticTrend tbRiskStaticTrend);

    /**
     * 新增【请填写功能名称】
     *
     * @param tbRiskStaticTrend 【请填写功能名称】
     * @return 结果
     */
    public int insertTbRiskStaticTrend(TbRiskStaticTrend tbRiskStaticTrend);

    public int insertOrUpdateTbRiskStaticTrend(TbRiskStaticTrend tbRiskStaticTrend);

    /**
     * 修改【请填写功能名称】
     *
     * @param tbRiskStaticTrend 【请填写功能名称】
     * @return 结果
     */
    public int updateTbRiskStaticTrend(TbRiskStaticTrend tbRiskStaticTrend);

    /**
     * 删除【请填写功能名称】
     *
     * @param id 【请填写功能名称】ID
     * @return 结果
     */
    public int deleteTbRiskStaticTrendById(String id);

    /**
     * 批量删除【请填写功能名称】
     *
     * @param ids 需要删除的数据ID
     * @return 结果
     */
    public int deleteTbRiskStaticTrendByIds(String[] ids);
}
