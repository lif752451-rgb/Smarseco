package com.crc.secface.mapper;

import com.crc.secface.entity.TbRiskIp;
import org.apache.ibatis.annotations.Param;

import java.util.List;

/**
 * @author simba@onlying.cn
 * @date 2020/7/21 14:55
 */
public interface RiskIpMapper {

    public TbRiskIp selectById(String id);

    public void insertTbRiskIp(TbRiskIp tbRiskIp);

    public List<TbRiskIp> getAllBlockingList();

    public void updateBlockStatus(String id);

    public TbRiskIp selectBydistinctIpAndDay(@Param("ip") String ip, @Param("eventTime") String eventTime, @Param("esIndex") String esIndex);
}
