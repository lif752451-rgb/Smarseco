package com.crc.secface.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.crc.secface.entity.AlarmIp;
import com.crc.secface.entity.Asset;
import com.crc.secface.entity.AssetAsmPort;
import com.crc.secface.entity.InternetPublishApp;
import com.crc.secface.request.InternetAlarmRequest;
import com.crc.secface.response.AssetAsmInternetResponse;
import com.crc.secface.response.InternetAlarmResponse;
import com.crc.secface.response.InternetPublishAppResponse;
import org.apache.ibatis.annotations.Mapper;

import java.util.List;
import java.util.Set;

/**
 * @author jixiangqi
 * @date 2023/7/10
 */
@Mapper
public interface InternetPublishAppMapper extends BaseMapper<InternetPublishApp> {

    List<AssetAsmInternetResponse> searchList();

    List<AssetAsmInternetResponse> searchByIp(String ip);
    List<AssetAsmInternetResponse> searchByUrlOrHost(String url);


    List<AssetAsmPort> getByLine(String ip, String port, String searchIp, String searchPort);


    /**
     * scp互联网发布告警数据查询
     * @param request
     * @return
     */
    List<InternetAlarmResponse> getAlarmListAndCombat(InternetAlarmRequest request);


    List<Asset> getAllAsset(List<String> ipList);


    List<InternetPublishAppResponse> getRepeatData();

    List<InternetPublishAppResponse> getRepeatDataByAlarmNId(AlarmIp alarmIp);

    List<InternetPublishAppResponse> getRepeatDataNew(Set<InternetPublishApp> insertCombatSet);


    void update(InternetPublishApp list);

    void insert(List<InternetPublishApp> list);

    void delDupData();
}
