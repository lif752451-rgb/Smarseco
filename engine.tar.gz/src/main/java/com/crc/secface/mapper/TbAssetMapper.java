package com.crc.secface.mapper;


import com.crc.secface.entity.AssetPublicIp;
import com.crc.secface.entity.SqlModel;
import com.crc.secface.entity.TbAsset;

import java.util.List;

/**
 * 资产信息Mapper接口
 *
 * @author lgl
 * @date 2020-07-15
 */
public interface TbAssetMapper {

    int getProccessingAlarmCount(SqlModel sqlModel);

    List<TbAsset> selectTbAssetList2(TbAsset tbAsset);

    /**
     * 查询资产信息
     *
     * @param id 资产信息ID
     * @return 资产信息
     */
    public TbAsset selectTbAssetById(Long id);

    public TbAsset selectTbAssetByIpAndInstance(TbAsset tbAsset);

    /**
     * 查询资产信息列表
     *
     * @param tbAsset 资产信息
     * @return 资产信息集合
     */
    public List<TbAsset> selectTbAssetList(TbAsset tbAsset);

    public void insertAssetTab(TbAsset tbAsset);

    /**
     * 查询终端资产
     *
     * @return
     */
    public List<TbAsset> selectTbTerminalList();

    /**
     * 删除资产信息
     *
     * @param id 资产信息ID
     * @return 结果
     */
    public int deleteTbAssetById(Long id);

    /**
     * 批量删除资产信息
     *
     * @param ids 需要删除的数据ID
     * @return 结果
     */
    public int deleteTbAssetByIds(Long[] ids);

    TbAsset selectTbAssetByIp(TbAsset asset);

    /**
     * 根据多个以,分割的内网ip查询第一条资产数据
     * @param asset
     * @return
     */
    TbAsset selectTbAssetByIps(TbAsset asset);

    List<AssetPublicIp> queryAssetPublicIpByIp(long iplong);

    TbAsset selectTbAssetByInnerIp(String ip);

    int getProccessingAlarmCombatCount(SqlModel sqlModel);

    void insertOrUpdateSelective(TbAsset asset);
}
