package com.crc.secface.mapper;

import com.crc.secface.entity.TbAssetVul;

import java.util.List;

/**
 * vulMapper接口
 *
 * @author wst
 * @date 2021-08-30
 */
public interface TbAssetVulMapper {
    /**
     * 查询vul
     *
     * @param id vulID
     * @return vul
     */
    public TbAssetVul selectTbAssetVulById(String id);
    public void updateFlowVulLastTimeById(TbAssetVul id);
    public TbAssetVul selectTbAssetVulLogById(String id);

    public TbAssetVul selectTbAssetVulFlowById(String id);

    /**
     * 查询vul列表
     *
     * @param tbAssetVul vul
     * @return vul集合
     */
    public List<TbAssetVul> selectTbAssetVulList(TbAssetVul tbAssetVul);

    public List<TbAssetVul> selectTbAssetVulList100(TbAssetVul tbAssetVul);

    /**
     * 待复查列表
     *
     * @return
     */
    public List<TbAssetVul> selectTbAssetVulReviewList(TbAssetVul tbAssetVul);

    public void updateTbAssetVulReview(TbAssetVul tbAssetVul);

    /**
     * 新增vul
     *
     * @param tbAssetVul vul
     * @return 结果
     */
    public int insertTbAssetVulLog(TbAssetVul tbAssetVul);

    public int insertTbAssetVul(TbAssetVul tbAssetVul);

    /**
     * 修改vul
     *
     * @param tbAssetVul vul
     * @return 结果
     */
    public int updateTbAssetVul(TbAssetVul tbAssetVul);

    public int updateTbAssetVulLog(TbAssetVul tbAssetVul);

    public int updateTbAssetVulSend(String id);

    public int updateTbAssetVulSendX(String id);

    public int updateTbAssetVulSendE(String id);

    public int updateTbAssetVulLastTime(String id);

    /**
     * 删除vul
     *
     * @param id vulID
     * @return 结果
     */
    public int deleteTbAssetVulById(String id);

    /**
     * 批量删除vul
     *
     * @param ids 需要删除的数据ID
     * @return 结果
     */
    public int deleteTbAssetVulByIds(String[] ids);

    void updateTbAssetVulLogLastTime(String id);

    /**
     * 数据刷到正式版
     */
    void copyVulToLog();

    /**
     * 清空缓存log
     */
    void cleanVulLog();
}
