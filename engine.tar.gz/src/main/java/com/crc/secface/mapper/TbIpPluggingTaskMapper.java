package com.crc.secface.mapper;

import com.crc.secface.entity.TbIpPluggingTask;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;

import java.util.List;

/**
 * @description 封堵任务表
 * @author hejingsheng1
 * @date 2023-08-03
 */
@Mapper
public interface TbIpPluggingTaskMapper {

    /**
     * 新增
     * @author zhengkai.blog.csdn.net
     * @date 2023/08/03
     **/
    int insert(TbIpPluggingTask tbIpPluggingTask);

    /**
     * 刪除
     * @author zhengkai.blog.csdn.net
     * @date 2023/08/03
     **/
    int delete(int id);

    /**
     * 更新
     * @author zhengkai.blog.csdn.net
     * @date 2023/08/03
     **/
    int update(TbIpPluggingTask tbIpPluggingTask);

    /**
     * 查询 根据主键 id 查询
     * @author zhengkai.blog.csdn.net
     * @date 2023/08/03
     **/
    TbIpPluggingTask load(int id);

    /**
     * 查询 分页查询
     * @author zhengkai.blog.csdn.net
     * @date 2023/08/03
     **/
    List<TbIpPluggingTask> pageList(int offset, int pagesize);

    /**
     * 查询 分页查询 count
     * @author zhengkai.blog.csdn.net
     * @date 2023/08/03
     **/
    int pageListCount(int offset,int pagesize);

    String getUniqueCount(@Param("execDevice")String device, @Param("ip")String ip);

//    void updateExecCountAndTime(String finalIdStr2);

    void updateExecCountAndTime(String id, String status);

    TbIpPluggingTask getById(String taskId);
}
