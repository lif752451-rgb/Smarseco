package com.crc.secface.mapper;

import com.crc.secface.entity.SysEmailConfigDTO;

import java.util.Map;

/**
 * @author jixiangqi
 * @date 2022/7/5
 */
public interface SysEmailConfigMapper {

   SysEmailConfigDTO getEmailConfig(  String dbType);

}
