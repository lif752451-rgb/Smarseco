package com.crc.secface.mapper;

import com.crc.secface.entity.SeverAssetType;
import org.apache.ibatis.annotations.Mapper;

import java.util.List;

/**
 * @description 服务器资产类型
 * @author hejingsheng1
 * @date 2023-09-21
 */
@Mapper
public interface SeverAssetTypeMapper {

    /**
     * 新增
     * @author hejingsheng1
     * @date 2023/09/21
     **/
    int insert(SeverAssetType SeverAssetType);

    /**
     * 刪除
     * @author hejingsheng1
     * @date 2023/09/21
     **/
    int delete(int id);

    /**
     * 更新
     * @author hejingsheng1
     * @date 2023/09/21
     **/
    int update(SeverAssetType SeverAssetType);

    /**
     * 查询 根据主键 id 查询
     * @author hejingsheng1
     * @date 2023/09/21
     **/
    SeverAssetType load(int id);

    /**
     * 查询 分页查询
     * @author hejingsheng1
     * @date 2023/09/21
     **/
    List<SeverAssetType> pageList(int offset, int pagesize);

    /**
     * 查询 分页查询 count
     * @author hejingsheng1
     * @date 2023/09/21
     **/
    int pageListCount(int offset,int pagesize);

    List<SeverAssetType> findAssetTypeAll();
}