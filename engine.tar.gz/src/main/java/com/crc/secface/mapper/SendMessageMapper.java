package com.crc.secface.mapper;


import com.crc.secface.entity.SendMessage;

/**
 * 【请填写功能名称】Mapper接口
 *
 * @author wst
 * @date 2020-12-08
 */
public interface SendMessageMapper {
    /**
     * 新增【请填写功能名称】
     *
     * @param tbSendMessage 【请填写功能名称】
     * @return 结果
     */
    public int insertTbSendMessage(SendMessage tbSendMessage);

    /**
     * 修改【请填写功能名称】
     *
     * @param tbSendMessage 【请填写功能名称】
     * @return 结果
     */
    public int updateTbSendMessage(SendMessage tbSendMessage);

    /**
     * 删除【请填写功能名称】
     *
     * @param id 【请填写功能名称】ID
     * @return 结果
     */
    public int deleteTbSendMessageById(Long id);

    /**
     * 批量删除【请填写功能名称】
     *
     * @param ids 需要删除的数据ID
     * @return 结果
     */
    public int deleteTbSendMessageByIds(Long[] ids);
}
