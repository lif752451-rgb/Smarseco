package com.crc.secface.mapper;

import com.crc.secface.entity.TbAssetSegement;

import java.util.List;

/**
 * 集团网段Mapper接口
 *
 * @author wst
 * @date 2021-11-04
 */
public interface TbAssetSegementMapper {
    /**
     * 查询集团网段
     *
     * @param id 集团网段ID
     * @return 集团网段
     */
    public TbAssetSegement selectTbAssetSegementById(Long id);

    /**
     * 查询集团网段列表
     *
     * @param tbAssetSegement 集团网段
     * @return 集团网段集合
     */
    public List<TbAssetSegement> selectTbAssetSegementList(TbAssetSegement tbAssetSegement);

    /**
     * 删除集团网段
     *
     * @param id 集团网段ID
     * @return 结果
     */
    public int deleteTbAssetSegementById(Long id);

    /**
     * 批量删除集团网段
     *
     * @param ids 需要删除的数据ID
     * @return 结果
     */
    public int deleteTbAssetSegementByIds(Long[] ids);

    public long getTotal();

    public List<TbAssetSegement> selectTbSegementInfoListByLimit(TbAssetSegement tbAssetSegement);
}
