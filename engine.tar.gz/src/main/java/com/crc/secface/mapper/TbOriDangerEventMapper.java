package com.crc.secface.mapper;

import com.crc.secface.entity.LogData;
import com.crc.secface.entity.TbOriDangerEvent;
import org.apache.ibatis.annotations.Param;

import java.util.List;

/**
 * 高危事件Mapper接口
 *
 * @author wst
 * @date 2020-07-16
 */
public interface TbOriDangerEventMapper {
    void deleteTbOriDangerEventTmpById(String id);

    List<LogData> selectTbOriDangerEventTmpListByStatus(String status);

    void insertAlarmRefOriLog(TbOriDangerEvent tbOriDangerEvent);

    /**
     * 查询高危事件
     *
     * @param id 高危事件ID
     * @return 高危事件
     */
    public TbOriDangerEvent selectTbOriDangerEventById(String id);

    public TbOriDangerEvent selectTbOriDangerEventByIdTmp(LogData log);

    public List<LogData> selectTbOriDangerEventTmpList(@Param("idList") List<String> idList);

    /**
     * 查询高危事件列表
     *
     * @param tbOriDangerEvent 高危事件
     * @return 高危事件集合
     */
    public List<TbOriDangerEvent> selectTbOriDangerEventList(TbOriDangerEvent tbOriDangerEvent);


    public TbOriDangerEvent selectTbOriDangerByInfo(TbOriDangerEvent tbOriDangerEvent);

    public long selectTbOriDangerCount(TbOriDangerEvent tbOriDangerEvent);

    /**
     * 新增高危事件
     *
     * @param tbOriDangerEvent 高危事件
     * @return 结果
     */
    public int insertTbOriDangerEvent(TbOriDangerEvent tbOriDangerEvent);

    /**
     * 修改高危事件
     *
     * @param tbOriDangerEvent 高危事件
     * @return 结果
     */
    public int updateTbOriDangerEvent(TbOriDangerEvent tbOriDangerEvent);


    /**
     * 新增高危事件
     *
     * @param tbOriDangerEvent 高危事件
     * @return 结果
     */
    public int insertTbOriDangerEventTmp(LogData tbOriDangerEvent);


    /**
     * 批量插入
     * @param values
     * @return
     */
    int batchInsert(@Param("values")List<LogData> values,@Param("curDate") String curDate);

    /**
     * 修改高危事件
     *
     * @param tbOriDangerEvent 高危事件
     * @return 结果
     */
    public int updateTbOriDangerEventTmp(LogData tbOriDangerEvent);


    /**
     * 删除高危事件
     *
     * @param id 高危事件ID
     * @return 结果
     */
    public int deleteTbOriDangerEventById(String id);

    /**
     * 批量删除高危事件
     *
     * @param ids 需要删除的数据ID
     * @return 结果
     */
    public int deleteTbOriDangerEventByIds(String[] ids);

    public int updateStatusByIds(@Param("idList") List<String> idList, @Param("status") String status);

    /**
     * 根据日志来源,事件名发生时间去重
     *
     * @param product
     * @param eventName
     * @param eventTime
     * @return
     */
    public TbOriDangerEvent existByDistinctKey(@Param("product") String product, @Param("eventName") String eventName,
                                               @Param("eventTime") String eventTime);

    TbOriDangerEvent selectTbOriDangerEventByBatch(String batchId);

    int getRefLogCount(String id);
}
