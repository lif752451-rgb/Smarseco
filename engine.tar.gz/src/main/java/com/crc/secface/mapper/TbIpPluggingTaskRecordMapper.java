package com.crc.secface.mapper;

import com.crc.secface.entity.IpPluggingTaskRecordResponse;
import com.crc.secface.entity.TbIpPluggingTaskRecord;
import org.apache.ibatis.annotations.Mapper;

import java.util.List;

/**
 * @description 封堵记录表
 * @author hejingsheng1
 * @date 2023-08-03
 */
@Mapper
public interface TbIpPluggingTaskRecordMapper {

    /**
     * 新增
     * @author zhengkai.blog.csdn.net
     * @date 2023/08/03
     **/
    int insert(TbIpPluggingTaskRecord tbIpPluggingTaskRecord);

    /**
     * 刪除
     * @author zhengkai.blog.csdn.net
     * @date 2023/08/03
     **/
    int delete(int id);

    /**
     * 更新
     * @author zhengkai.blog.csdn.net
     * @date 2023/08/03
     **/
    int update(TbIpPluggingTaskRecord tbIpPluggingTaskRecord);

    /**
     * 查询 根据主键 id 查询
     * @author zhengkai.blog.csdn.net
     * @date 2023/08/03
     **/
    TbIpPluggingTaskRecord load(int id);

    /**
     * 查询 分页查询
     * @author zhengkai.blog.csdn.net
     * @date 2023/08/03
     **/
    List<TbIpPluggingTaskRecord> pageList(int offset, int pagesize);

    /**
     * 查询 分页查询 count
     * @author zhengkai.blog.csdn.net
     * @date 2023/08/03
     **/
    int pageListCount(int offset,int pagesize);

    void updateData(TbIpPluggingTaskRecord taskRecord);

    List<IpPluggingTaskRecordResponse> getByTaskId(String taskId);
}
