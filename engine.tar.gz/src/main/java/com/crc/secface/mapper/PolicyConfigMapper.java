package com.crc.secface.mapper;

import com.crc.secface.entity.PolicyConfig;
import org.apache.ibatis.annotations.Param;

import java.util.List;

/**
 * 【策略配置】Mapper接口
 *
 * @author wst
 * @date 2020-12-08
 */
public interface PolicyConfigMapper {
    public long getMaxId();

    public long getMinId();

    List<PolicyConfig> selectPolicyConfigListByRange(PolicyConfig policyConfig);

    /**
     * 新增【策略配置】
     */
    public int insertPolicyConfig(PolicyConfig policyConfig);

    public int batchInsertPolicyConfig(@Param("configList") List<PolicyConfig> configList);

    /**
     * 修改【策略配置】
     */
    public int updatePolicyConfig(PolicyConfig policyConfig);

    /**
     * 删除
     */
    public int deletePolicyConfigById(Long id);

    /**
     * 批量删除
     */
    public int deletePolicyConfigByIds(Long[] ids);

    public int deleteConfigByPolicyIds(@Param("policyIds") List<Long> policyId);

    PolicyConfig selectPolicyConfigById(Long id);

    long getTotal(PolicyConfig rule);

    List<PolicyConfig> selectPolicyConfigListByLimit(PolicyConfig rule);
}
