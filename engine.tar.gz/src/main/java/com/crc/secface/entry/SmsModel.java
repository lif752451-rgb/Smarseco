package com.crc.secface.entry;

import lombok.Data;

@Data
public class SmsModel {
    String stage;
    String token;
    String apiId;
    String appId;
    String submiterName;
    String submiter;
    String tenantId;
    String nationCode;
    String signCode;
    String templateCode;
}
