package com.crc.secface.entity;

import com.baomidou.mybatisplus.annotation.TableField;
import com.baomidou.mybatisplus.annotation.TableName;
import lombok.Data;
import lombok.experimental.Accessors;

/**
 * 
 * @author huganpu
 *
 */
@Data
@Accessors(chain = true)
@TableName("tb_asset_person")
public class AssetPerson  {

	private static final long serialVersionUID = 1L;

	/**
	 * 用户id
	 */
	@TableField("user_id")
	private String userId;

	/**
	 * 用户名全称
	 */
	@TableField("user_name")
	private String userName;

	/**
	 * 邮箱地址
	 */
	@TableField("email")
	private String email;

	/**
	 * 联系电话
	 */
	@TableField("phone")
	private String phone;

	/**
	 * 类型；1，责任人；2，运维人
	 */
	@TableField("type")
	private String type;
	
	/**
	 * 内网IP
	 */
	@TableField("internal_ip")
	private String internalIp;
	
	/**
	 * 资产ID
	 */
	@TableField("asset_id")
	private Long assetId;
	
}
