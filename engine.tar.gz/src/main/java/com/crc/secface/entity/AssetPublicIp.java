package com.crc.secface.entity;

import com.baomidou.mybatisplus.annotation.TableField;
import com.baomidou.mybatisplus.annotation.TableName;
import lombok.Data;
import lombok.experimental.Accessors;

@Data
@Accessors(chain = true)
@TableName("tb_asset_public_ip")
public class AssetPublicIp{

    private static final long serialVersionUID = 1L;

    private String id;

    @TableField("ip_start")
    private String ipStart;

    @TableField("ip_end")
    private String ipEnd;

    @TableField("ip_start_int")
    private Long ipStartInt;

    @TableField("ip_end_int")
    private Long ipEndInt;

    @TableField("nation")
    private String nation;

    @TableField("province")
    private String province;

    @TableField("city")
    private String city;

    @TableField("post_code")
    private String postCode;

    @TableField("nation_english_brief")
    private String nationEnglishBrief;

    @TableField("longitude")
    private String longitude;

    @TableField("latitude")
    private String latitude;

    @TableField("op")
    private String op;

}
