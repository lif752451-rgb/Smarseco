package com.crc.secface.entity;

import org.apache.commons.lang3.builder.ToStringBuilder;
import org.apache.commons.lang3.builder.ToStringStyle;

import java.util.Date;

/**
 * 风险IP对象 tb_risk_ip
 *
 * @author wst
 * @date 2020-07-16
 */
public class TbRiskIp {
    private static final long serialVersionUID = 1L;

    /**
     * 主键
     */
    private String id;

    /**
     * 攻击IP
     */

    private String ip;

    /**
     * IP风险值
     */

    private Long ipScore;

    /**
     * 事件风险值
     */

    private Long eventScore;

    /**
     * 总风险值
     */

    private Long totalScore;

    /**
     * 发生时间
     */

    private Date curTime;

    /**
     * 国家
     */
    private String country;

    /**
     * 城市/地区
     */
    private String city;

    /**
     * 状态
     */
    private String status;

    /**
     * $column.columnComment
     */
    private Date createDate;

    /**
     * $column.columnComment
     */
    private Date updateDate;

    /**
     * 处理时间
     */

    private Date procTime;

    private Integer delFlag;

    private String idStrs;

    private String esIndex;

    private Integer times;

    private String type;

    private String dataScope;

    /**
     * 搜索值
     */
    private String searchValue;

    /**
     * 创建者
     */
    private String createBy;

    /**
     * 创建时间
     */
    private Date createTime;

    /**
     * 更新者
     */
    private String updateBy;

    /**
     * 更新时间
     */
    private Date updateTime;

    /**
     * 备注
     */
    private String remark;


    /**
     * 开始时间
     */
    private String beginTime;

    /**
     * 结束时间
     */
    private String endTime;
    private String ids;

    public String getIds() {
        return ids;
    }

    public void setIds(String ids) {
        this.ids = ids;
    }

    public String getDataScope() {
        return dataScope;
    }

    public void setDataScope(String dataScope) {
        this.dataScope = dataScope;
    }

    public String getSearchValue() {
        return searchValue;
    }

    public void setSearchValue(String searchValue) {
        this.searchValue = searchValue;
    }

    public String getCreateBy() {
        return createBy;
    }

    public void setCreateBy(String createBy) {
        this.createBy = createBy;
    }

    public Date getCreateTime() {
        return createTime;
    }

    public void setCreateTime(Date createTime) {
        this.createTime = createTime;
    }

    public String getUpdateBy() {
        return updateBy;
    }

    public void setUpdateBy(String updateBy) {
        this.updateBy = updateBy;
    }

    public Date getUpdateTime() {
        return updateTime;
    }

    public void setUpdateTime(Date updateTime) {
        this.updateTime = updateTime;
    }

    public String getRemark() {
        return remark;
    }

    public void setRemark(String remark) {
        this.remark = remark;
    }

    public String getBeginTime() {
        return beginTime;
    }

    public void setBeginTime(String beginTime) {
        this.beginTime = beginTime;
    }

    public String getEndTime() {
        return endTime;
    }

    public void setEndTime(String endTime) {
        this.endTime = endTime;
    }

    public Integer getTimes() {
        return times;
    }

    public void setTimes(Integer times) {
        this.times = times;
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }

    public void setIdStrs(String idStrs) {
        this.idStrs = idStrs;
    }

    public void setEsIndex(String esIndex) {
        this.esIndex = esIndex;
    }

    public String getIdStrs() {
        return idStrs;
    }

    public String getEsIndex() {
        return esIndex;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getId() {
        return id;
    }

    public void setIp(String ip) {
        this.ip = ip;
    }

    public String getIp() {
        return ip;
    }

    public void setIpScore(Long ipScore) {
        this.ipScore = ipScore;
    }

    public Long getIpScore() {
        return ipScore;
    }

    public void setEventScore(Long eventScore) {
        this.eventScore = eventScore;
    }

    public Long getEventScore() {
        return eventScore;
    }

    public void setTotalScore(Long totalScore) {
        this.totalScore = totalScore;
    }

    public Long getTotalScore() {
        return totalScore;
    }

    public void setCurTime(Date curTime) {
        this.curTime = curTime;
    }

    public Date getCurTime() {
        return curTime;
    }

    public void setCountry(String country) {
        this.country = country;
    }

    public String getCountry() {
        return country;
    }

    public void setCity(String city) {
        this.city = city;
    }

    public String getCity() {
        return city;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public String getStatus() {
        return status;
    }

    public void setCreateDate(Date createDate) {
        this.createDate = createDate;
    }

    public Date getCreateDate() {
        return createDate;
    }

    public void setUpdateDate(Date updateDate) {
        this.updateDate = updateDate;
    }

    public Date getUpdateDate() {
        return updateDate;
    }

    public void setProcTime(Date procTime) {
        this.procTime = procTime;
    }

    public Date getProcTime() {
        return procTime;
    }

    public Integer getDelFlag() {
        return delFlag;
    }

    public void setDelFlag(Integer delFlag) {
        this.delFlag = delFlag;
    }


    @Override
    public String toString() {
        return new ToStringBuilder(this, ToStringStyle.MULTI_LINE_STYLE)
                .append("id", getId())
                .append("ip", getIp())
                .append("ipScore", getIpScore())
                .append("eventScore", getEventScore())
                .append("totalScore", getTotalScore())
                .append("curTime", getCurTime())
                .append("country", getCountry())
                .append("city", getCity())
                .append("status", getStatus())
                .append("createDate", getCreateDate())
                .append("updateDate", getUpdateDate())
                .append("procTime", getProcTime())
                .toString();
    }
}
