package com.crc.secface.entity;

import com.alibaba.fastjson.JSONObject;
import lombok.Data;

import java.util.List;
import java.util.concurrent.ConcurrentHashMap;

@Data
public class DangerEventSendModel {

    private String eventId;

    private int sendOp;

    private JSONObject eventJson;

    private TbEventModel model;

    List<RelationId> idList;

    ConcurrentHashMap<String,JSONObject> logMap;

    String ids;
}
