package com.crc.secface.entity;

import com.alibaba.fastjson.JSONObject;

import java.util.ArrayList;
import java.util.List;

/**
 * @author simba@onlying.cn
 * @date 2020/9/27 18:05
 */
public class RewriteQuery {

    private List<JSONObject> mustList =new ArrayList<>();

    private List<JSONObject> filterList =new ArrayList<>();

    private List<JSONObject> shouldList =new ArrayList<>();

    private List<JSONObject> mustNotList=new ArrayList<>();


    public List<JSONObject> getMustList() {
        return mustList;
    }

    public List<JSONObject> getFilterList() {
        return filterList;
    }

    public List<JSONObject> getShouldList() {
        return shouldList;
    }

    public List<JSONObject> getMustNotList() {
        return mustNotList;
    }

    public void setMustList(List<JSONObject> mustList) {
        this.mustList = mustList;
    }

    public void setFilterList(List<JSONObject> filterList) {
        this.filterList = filterList;
    }

    public void setShouldList(List<JSONObject> shouldList) {
        this.shouldList = shouldList;
    }

    public void setMustNotList(List<JSONObject> mustNotList) {
        this.mustNotList = mustNotList;
    }

    public void should(JSONObject jsonObject){
        shouldList.add(jsonObject);
    }

}
