package com.crc.secface.entity;

import lombok.Data;
import lombok.extern.slf4j.Slf4j;

import java.util.List;

@Data
public class ModelLogVo {
    TbEventModel model;
    List<LogData> logDataList;
}
