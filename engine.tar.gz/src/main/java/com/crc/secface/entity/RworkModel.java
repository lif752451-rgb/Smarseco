package com.crc.secface.entity;

import com.alibaba.fastjson.JSONObject;
import lombok.Data;

@Data
public class RworkModel {
    private JSONObject json;
    String orderId;
    TbEventModel model;

    String modelType;
}
