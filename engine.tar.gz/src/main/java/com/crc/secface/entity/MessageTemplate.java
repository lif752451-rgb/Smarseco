package com.crc.secface.entity;

/**
 * @author simba@onlying.cn
 * @date 2020/10/13 14:13
 */
public class MessageTemplate {

    /*private Long id;

    private String code;

    private String name;

    private String content;

    private Integer delFlag;

    private Integer maxFormatIndex;

    private String tempVer;//版本
    private String cronValue;
    private int countPeriodType;
    private int countPeriod;
    private String sendList;*/


    private static final long serialVersionUID = 1L;

    /**
     * $column.columnComment
     */
    private Long id;

    /**
     * 模板编码
     */
    private String code;

    /**
     * 模板名称
     */
    private String name;

    /**
     * 模板内容
     */
    private String content;

    /**
     * 删除标志（0代表存在 2代表删除）
     */
    private Long delFlag;

    /**
     * 最大格式化索引
     */
    private Long maxFormatIndex;

    /**
     * crontab表达式
     */
    private String cronValue;

    /**
     * 统计时间范围
     */
    private Long countPeriod;

    /**
     * 时间单位
     */
    private Long periodType;

    private String taskInterval;

    /**
     * 启停状态
     */
    private Long runStatus;

    /**
     * ldap账号，英文逗号隔开
     */
    private String sendList;

    private String runStatusLabel;

    /**
     * 版本，始0，每次变更+1
     */
    private String tempVer;

    /**
     * 推送方式  1  邮件  2飞书
     */
    private String pushType;

    /**
     * 1  启用  2停用
     */
    private Integer emailStatus;

    private String emailSender;

    private String emailReceiver;

    private String emailStartTime;

    private String emailEndTime;

    private String emailWeeks;

    /**
     * 1  启用  2停用
     */
    private Integer rworkStatus;

    private String rworkSender;

    private String rworkReceiver;

    private String rworkStartTime;

    private String rworkEndTime;

    private String rworkWeeks;

    public String getCronValue() {
        return cronValue;
    }

    public void setCronValue(String cronValue) {
        this.cronValue = cronValue;
    }


    public String getSendList() {
        return sendList;
    }

    public void setSendList(String sendList) {
        this.sendList = sendList;
    }

    public String getTempVer() {
        if (tempVer == null)
            tempVer = "";
        return tempVer;
    }

    public void setTempVer(String tempVer) {
        this.tempVer = tempVer;
    }

    public Long getId() {
        return id;
    }

    public String getCode() {
        return code;
    }

    public String getName() {
        return name;
    }

    public String getContent() {
        return content;
    }



    public void setId(Long id) {
        this.id = id;
    }

    public void setCode(String code) {
        this.code = code;
    }

    public void setName(String name) {
        this.name = name;
    }

    public void setContent(String content) {
        this.content = content;
    }

    public Long getDelFlag() {
        return delFlag;
    }

    public void setDelFlag(Long delFlag) {
        this.delFlag = delFlag;
    }

    public Long getMaxFormatIndex() {
        return maxFormatIndex;
    }

    public void setMaxFormatIndex(Long maxFormatIndex) {
        this.maxFormatIndex = maxFormatIndex;
    }

    public Long getCountPeriod() {
        return countPeriod;
    }

    public void setCountPeriod(Long countPeriod) {
        this.countPeriod = countPeriod;
    }

    public Long getPeriodType() {
        return periodType;
    }

    public void setPeriodType(Long periodType) {
        this.periodType = periodType;
    }

    public String getTaskInterval() {
        return taskInterval;
    }

    public void setTaskInterval(String taskInterval) {
        this.taskInterval = taskInterval;
    }

    public Long getRunStatus() {
        return runStatus;
    }

    public void setRunStatus(Long runStatus) {
        this.runStatus = runStatus;
    }

    public String getRunStatusLabel() {
        return runStatusLabel;
    }

    public void setRunStatusLabel(String runStatusLabel) {
        this.runStatusLabel = runStatusLabel;
    }

    public String getPushType() {
        return pushType;
    }

    public void setPushType(String pushType) {
        this.pushType = pushType;
    }

    public Integer getEmailStatus() {
        return emailStatus;
    }

    public void setEmailStatus(Integer emailStatus) {
        this.emailStatus = emailStatus;
    }

    public String getEmailSender() {
        return emailSender;
    }

    public void setEmailSender(String emailSender) {
        this.emailSender = emailSender;
    }

    public String getEmailReceiver() {
        return emailReceiver;
    }

    public void setEmailReceiver(String emailReceiver) {
        this.emailReceiver = emailReceiver;
    }

    public String getEmailStartTime() {
        return emailStartTime;
    }

    public void setEmailStartTime(String emailStartTime) {
        this.emailStartTime = emailStartTime;
    }

    public String getEmailEndTime() {
        return emailEndTime;
    }

    public void setEmailEndTime(String emailEndTime) {
        this.emailEndTime = emailEndTime;
    }

    public String getEmailWeeks() {
        return emailWeeks;
    }

    public void setEmailWeeks(String emailWeeks) {
        this.emailWeeks = emailWeeks;
    }

    public Integer getRworkStatus() {
        return rworkStatus;
    }

    public void setRworkStatus(Integer rworkStatus) {
        this.rworkStatus = rworkStatus;
    }

    public String getRworkSender() {
        return rworkSender;
    }

    public void setRworkSender(String rworkSender) {
        this.rworkSender = rworkSender;
    }

    public String getRworkReceiver() {
        return rworkReceiver;
    }

    public void setRworkReceiver(String rworkReceiver) {
        this.rworkReceiver = rworkReceiver;
    }

    public String getRworkStartTime() {
        return rworkStartTime;
    }

    public void setRworkStartTime(String rworkStartTime) {
        this.rworkStartTime = rworkStartTime;
    }

    public String getRworkEndTime() {
        return rworkEndTime;
    }

    public void setRworkEndTime(String rworkEndTime) {
        this.rworkEndTime = rworkEndTime;
    }

    public String getRworkWeeks() {
        return rworkWeeks;
    }

    public void setRworkWeeks(String rworkWeeks) {
        this.rworkWeeks = rworkWeeks;
    }
}
