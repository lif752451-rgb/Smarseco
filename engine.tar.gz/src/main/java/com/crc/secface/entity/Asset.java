package com.crc.secface.entity;

import lombok.Data;

/**
 * @author jixiangqi
 * @date 2023/7/10
 */
@Data
public class Asset {

    /**
     * 内网IP
     */
    private String internalIp;

    /**
     * 主键id
     */
    private Long id;

    /**
     * 互联网IP
     */
    private String internetIp;
}
