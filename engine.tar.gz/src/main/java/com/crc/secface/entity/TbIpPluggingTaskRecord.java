package com.crc.secface.entity;

import java.io.Serializable;
import java.util.Date;

/**
 * @description 封堵记录表
 * @author hejingsheng1
 * @date 2023-08-03
 */
public class TbIpPluggingTaskRecord implements Serializable {

    private static final long serialVersionUID = 1L;

    /**
     * 主键id
     */
    private String id;

    /**
     * 任务id
     */
    private String taskId;

    /**
     * 执行动作 1 封堵 2 解封
     */
    private int actionType;

    /**
     * 方式 1 手动 2 自动
     */
    private int operationType;

    /**
     * 执行人
     */
    private String operationUser;

    /**
     * 执行结果 1 执行中 2 成功 3 失败
     */
    private int actionResult;

    /**
     * 执行原因
     */
    private String actionReason;

    /**
     * 失败原因
     */
    private String msg;

    /**
     * 封堵截至时间
     */
    private Date deadlineTime;

    /**
     * 执行时间
     */
    private Date actionTime;

    /**
     * 是否需要定时任务获取结果
     * 1 不需要
     * 2 需要
     */
    private Integer resultFlag;
    public TbIpPluggingTaskRecord() {
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getTaskId() {
        return taskId;
    }

    public void setTaskId(String taskId) {
        this.taskId = taskId;
    }

    public int getActionType() {
        return actionType;
    }

    public void setActionType(int actionType) {
        this.actionType = actionType;
    }

    public int getOperationType() {
        return operationType;
    }

    public void setOperationType(int operationType) {
        this.operationType = operationType;
    }

    public String getOperationUser() {
        return operationUser;
    }

    public void setOperationUser(String operationUser) {
        this.operationUser = operationUser;
    }

    public int getActionResult() {
        return actionResult;
    }

    public void setActionResult(int actionResult) {
        this.actionResult = actionResult;
    }

    public String getActionReason() {
        return actionReason;
    }

    public void setActionReason(String actionReason) {
        this.actionReason = actionReason;
    }

    public String getMsg() {
        return msg;
    }

    public void setMsg(String msg) {
        this.msg = msg;
    }

    public Date getDeadlineTime() {
        return deadlineTime;
    }

    public void setDeadlineTime(Date deadlineTime) {
        this.deadlineTime = deadlineTime;
    }

    public Date getActionTime() {
        return actionTime;
    }

    public void setActionTime(Date actionTime) {
        this.actionTime = actionTime;
    }
    public Integer getResultFlag() {
        return resultFlag;
    }

    public void setResultFlag(Integer resultFlag) {
        this.resultFlag = resultFlag;
    }
}
