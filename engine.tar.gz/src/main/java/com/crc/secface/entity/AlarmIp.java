package com.crc.secface.entity;

import lombok.Data;

@Data
public class AlarmIp {
    String srcIp;
    String destIp;
    String modelId;

    String alarmId;
    String ruleBase;
    String ruleBaseIp;

    String fightPeriodType;
    String url;
    String host;
}
