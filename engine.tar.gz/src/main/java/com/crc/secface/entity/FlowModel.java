package com.crc.secface.entity;

import com.alibaba.fastjson.JSONObject;
import lombok.Data;

import java.util.List;

@Data
public class FlowModel {
    private JSONObject rJson;//推送润工作
    private JSONObject fJson;//推送工单
    TbEventModel model;

    String fightTab;//实战周期类型

    String oriEventId;
    List<RelationId> relationIdList;

    String alarmId;
}
