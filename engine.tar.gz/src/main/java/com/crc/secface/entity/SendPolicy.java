package com.crc.secface.entity;


/**
 * 【请填写功能名称】对象 tb_send_policy
 *
 * @author wst
 * @date 2020-12-08
 */
public class SendPolicy
{
    private static final long serialVersionUID = 1L;

    private Integer id;

    /**
     * 策略code
     */
    private String policyCode;

    /**
     * 策略名称
     */
    private String policyName;

    /**
     * 规则id
     */
    private String ruleIds;

    private String isDel;

    private String applyCompany;

    //规则名称
    private String ruleName;

    private PolicyConfig policyConfig;

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getPolicyCode() {
        return policyCode;
    }

    public void setPolicyCode(String policyCode) {
        this.policyCode = policyCode;
    }

    public String getPolicyName() {
        return policyName;
    }

    public void setPolicyName(String policyName) {
        this.policyName = policyName;
    }

    public String getRuleIds() {
        return ruleIds;
    }

    public void setRuleIds(String ruleIds) {
        this.ruleIds = ruleIds;
    }

    public String getIsDel() {
        return isDel;
    }

    public void setIsDel(String isDel) {
        this.isDel = isDel;
    }

    public String getApplyCompany() {
        return applyCompany;
    }

    public void setApplyCompany(String applyCompany) {
        this.applyCompany = applyCompany;
    }

    public PolicyConfig getPolicyConfig() {
        return policyConfig;
    }

    public void setPolicyConfig(PolicyConfig policyConfig) {
        this.policyConfig = policyConfig;
    }



    public static long getSerialVersionUID() {
        return serialVersionUID;
    }

    public String getRuleName() {
        return ruleName;
    }

    public void setRuleName(String ruleName) {
        this.ruleName = ruleName;
    }
}
