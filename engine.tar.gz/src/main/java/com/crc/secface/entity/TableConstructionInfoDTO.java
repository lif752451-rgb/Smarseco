package com.crc.secface.entity;

import lombok.Data;

/**
 * @author lyc
 * @date 2023/4/24
 */
@Data
public class TableConstructionInfoDTO {

    /**
     * 字段名称
     */
    private String columnName;

    /**
     * 字段类型
     */
    private String columnType;

    /**
     * 字段长度
     */
    private String columnSize;

    /**
     * 字段注释
     */
    private String columnRemark;

    /**
     * 关联字典
     */
    private String relaDict;

    /**
     * 是否必填
     */
    private boolean required  = false;

    /**
     * 是否开放
     */
    private boolean open = false;

}
