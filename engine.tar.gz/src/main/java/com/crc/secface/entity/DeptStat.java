package com.crc.secface.entity;

/**
 * @author simba@onlying.cn
 * @date 2020/11/12 11:18
 */
public class DeptStat {

    private Long deptId;

    private String deptName;

    private String deptQueryCN;

    private String deptQueryEN;

    public Long getDeptId() {
        return deptId;
    }

    public void setDeptId(Long deptId) {
        this.deptId = deptId;
    }

    public String getDeptName() {
        return deptName;
    }

    public void setDeptName(String deptName) {
        this.deptName = deptName;
    }

    public String getDeptQueryCN() {
        return deptQueryCN;
    }

    public void setDeptQueryCN(String deptQueryCN) {
        this.deptQueryCN = deptQueryCN;
    }

    public String getDeptQueryEN() {
        return deptQueryEN;
    }

    public void setDeptQueryEN(String deptQueryEN) {
        this.deptQueryEN = deptQueryEN;
    }

}
