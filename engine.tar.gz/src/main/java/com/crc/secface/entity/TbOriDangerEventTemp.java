package com.crc.secface.entity;

import com.baomidou.mybatisplus.annotation.TableField;
import lombok.Data;

/**
 * 高危事件对象 tb_ori_danger_event_temp
 *
 * @author wst
 * @date 2020-07-16
 */
@Data
public class TbOriDangerEventTemp {

    @TableField("id")
    private String id;

    @TableField("data")
    private String data;

    @TableField("status")
    private String status;

    @TableField("batch")
    private String batch;

    @TableField("es_index")
    private String esIndex;
}
