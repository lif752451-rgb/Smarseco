package com.crc.secface.entity;


import org.apache.commons.lang3.builder.ToStringBuilder;
import org.apache.commons.lang3.builder.ToStringStyle;

/**
 * 终端软件安装统计对象 tb_terminal_software_install
 *
 * @author wst
 * @date 2021-11-23
 */
public class TbTerminalSoftwareInstall {
    private static final long serialVersionUID = 1L;
    /**
     * 主键ID
     */
    private Long id;

    /**
     * 用户账号
     */
    private String strUserName;

    /**
     * 合法软件安装数
     */
    private Long iillegalInstallCount;

    /**
     * 部门
     */
    private String strRoleName;

    /**
     * uiddevrecordid
     */
    private String uidDevRecordId;

    /**
     * 用户名称
     */
    private String strUserDes;

    /**
     * IP
     */
    private String strDevIp;

    /**
     * 软件安装数
     */
    private Long iinstallCount;

    /**
     * uidroleid
     */
    private String uidRoleId;

    /**
     * MAC地址
     */
    private String strMac;

    /**
     * 计算机名称
     */
    private String strDevName;

    /**
     * 非授权安装软件数
     */
    private Long iauthInstallCount;

    public void setId(Long id) {
        this.id = id;
    }

    public Long getId() {
        return id;
    }

    public void setStrUserName(String strUserName) {
        this.strUserName = strUserName;
    }

    public String getStrUserName() {
        return strUserName;
    }

    public void setIillegalInstallCount(Long iillegalInstallCount) {
        this.iillegalInstallCount = iillegalInstallCount;
    }

    public Long getIillegalInstallCount() {
        return iillegalInstallCount;
    }

    public void setStrRoleName(String strRoleName) {
        this.strRoleName = strRoleName;
    }

    public String getStrRoleName() {
        return strRoleName;
    }

    public void setUidDevRecordId(String uidDevRecordId) {
        this.uidDevRecordId = uidDevRecordId;
    }

    public String getUidDevRecordId() {
        return uidDevRecordId;
    }

    public void setStrUserDes(String strUserDes) {
        this.strUserDes = strUserDes;
    }

    public String getStrUserDes() {
        return strUserDes;
    }

    public void setStrDevIp(String strDevIp) {
        this.strDevIp = strDevIp;
    }

    public String getStrDevIp() {
        return strDevIp;
    }

    public void setIinstallCount(Long iinstallCount) {
        this.iinstallCount = iinstallCount;
    }

    public Long getIinstallCount() {
        return iinstallCount;
    }

    public void setUidRoleId(String uidRoleId) {
        this.uidRoleId = uidRoleId;
    }

    public String getUidRoleId() {
        return uidRoleId;
    }

    public void setStrMac(String strMac) {
        this.strMac = strMac;
    }

    public String getStrMac() {
        return strMac;
    }

    public void setStrDevName(String strDevName) {
        this.strDevName = strDevName;
    }

    public String getStrDevName() {
        return strDevName;
    }

    public void setIauthInstallCount(Long iauthInstallCount) {
        this.iauthInstallCount = iauthInstallCount;
    }

    public Long getIauthInstallCount() {
        return iauthInstallCount;
    }

    @Override
    public String toString() {
        return new ToStringBuilder(this, ToStringStyle.MULTI_LINE_STYLE)
                .append("id", getId())
                .append("strUserName", getStrUserName())
                .append("iillegalInstallCount", getIillegalInstallCount())
                .append("strRoleName", getStrRoleName())
                .append("uidDevRecordId", getUidDevRecordId())
                .append("strUserDes", getStrUserDes())
                .append("strDevIp", getStrDevIp())
                .append("iinstallCount", getIinstallCount())
                .append("uidRoleId", getUidRoleId())
                .append("strMac", getStrMac())
                .append("strDevName", getStrDevName())
                .append("iauthInstallCount", getIauthInstallCount())
                .toString();
    }
}
