package com.crc.secface.entity;

import lombok.Data;

import java.io.Serializable;
import java.util.Date;
import java.util.List;

/**
 * @description 服务器资产类型
 * @author hejingsheng1
 * @date 2023-09-21
 */
@Data
public class SeverAssetType implements Serializable {

    /**
     * 主键id
     */
    private String id;

    /**
     * 类型名称
     */
    private String typeName;

    /**
     * 父级id
     */
    private String parentId;

    /**
     * 排序
     */
    private int sortNum;

    /**
     * 备注
     */
    private String remark;

    /**
     * 创建人姓名
     */
    private String createByLabel;

    /**
     * 删除标记
     */
    private int delFlag;

    /**
     * 路径
     */
    private String ancestors;

    /**
     * 资产类型全称
     */
    private String fullPath;

    private List<SeverAssetType> children;

    String createBy;
    Date createTime;
    Date updateTime;
    String updateBy;

}
