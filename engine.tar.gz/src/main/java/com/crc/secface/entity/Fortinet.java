package com.crc.secface.entity;

import lombok.Data;

import java.util.Date;

@Data
public class Fortinet {
    private String url;
    private String username;
    private String password;
    private String cookie;
    private String csrfToken;
    private Date ctime;
}
