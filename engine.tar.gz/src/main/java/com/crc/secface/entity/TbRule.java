package com.crc.secface.entity;


import org.apache.commons.lang3.builder.ToStringBuilder;
import org.apache.commons.lang3.builder.ToStringStyle;

import java.util.Date;

/**
 * 规则模型对象 tb_rule_model
 *
 * @author wst
 * @date 2020-09-02
 */
public class TbRule
{
    private static final long serialVersionUID = 1L;

    /** $column.columnComment */
    private Long id;

    /** 规则模型名称 */
    private String ruleName;

    //模型Id
    private Long modelId;

    /** 父级Id */
    private Long parentId;

    //父Id集合
    private String parentIds;

    /** 显示顺序 */
    private Long orderNum;

    /** 规则类型 */
    private String ruleType;


    /** $column.columnComment */
    private String delFlag;

    private String attributes;
    private String rule;
    private String content;
    private String modelStatus;
    private String ruleTypeLabel;
    private String attributesLabel;
    private String ruleLabel;

    /**
     * 创建者
     */
    private String createBy;

    /**
     * 创建时间
     */
    private Date createTime;

    /**
     * 更新者
     */
    private String updateBy;
    //前端显示Id
    private Integer viewId;

    private Integer prevNodeViewId;

    public Integer getViewId() {
        return viewId;
    }

    public void setViewId(Integer viewId) {
        this.viewId = viewId;
    }

    public Integer getPrevNodeViewId() {
        return prevNodeViewId;
    }

    public void setPrevNodeViewId(Integer prevNodeViewId) {
        this.prevNodeViewId = prevNodeViewId;
    }

    /**
     * 更新时间
     */
    private Date updateTime;
    private long idStart;
    private long idEnd;
    private String applyCompany;

    public long getIdStart() {
        return idStart;
    }

    public void setIdStart(long idStart) {
        this.idStart = idStart;
    }

    public long getIdEnd() {
        return idEnd;
    }

    public void setIdEnd(long idEnd) {
        this.idEnd = idEnd;
    }

    public String getApplyCompany() {
        return applyCompany;
    }

    public void setApplyCompany(String applyCompany) {
        this.applyCompany = applyCompany;
    }

    public String getCreateBy() {
        return createBy;
    }

    public void setCreateBy(String createBy) {
        this.createBy = createBy;
    }

    public Date getCreateTime() {
        return createTime;
    }

    public void setCreateTime(Date createTime) {
        this.createTime = createTime;
    }

    public String getUpdateBy() {
        return updateBy;
    }

    public void setUpdateBy(String updateBy) {
        this.updateBy = updateBy;
    }

    public Date getUpdateTime() {
        return updateTime;
    }

    public void setUpdateTime(Date updateTime) {
        this.updateTime = updateTime;
    }

    public String getAttributesLabel() {
        return attributesLabel;
    }

    public void setAttributesLabel(String attributesLabel) {
        this.attributesLabel = attributesLabel;
    }

    public String getRuleLabel() {
        return ruleLabel;
    }

    public void setRuleLabel(String ruleLabel) {
        this.ruleLabel = ruleLabel;
    }

    public String getRuleTypeLabel() {
        return ruleTypeLabel;
    }

    public void setRuleTypeLabel(String ruleTypeLabel) {
        this.ruleTypeLabel = ruleTypeLabel;
    }

    public String getModelStatus() {
        return modelStatus;
    }

    public void setModelStatus(String modelStatus) {
        this.modelStatus = modelStatus;
    }

    public String getAttributes() {
        return attributes;
    }

    public void setAttributes(String attributes) {
        this.attributes = attributes;
    }

    public String getRule() {
        return rule;
    }

    public void setRule(String rule) {
        this.rule = rule;
    }

    public String getContent() {
        return content;
    }

    public void setContent(String content) {
        this.content = content;
    }

    public void setId(Long id)
    {
        this.id = id;
    }

    public Long getId()
    {
        return id;
    }

    public void setParentId(Long parentId)
    {
        this.parentId = parentId;
    }

    public Long getParentId()
    {
        return parentId;
    }
    public void setOrderNum(Long orderNum)
    {
        this.orderNum = orderNum;
    }

    public Long getOrderNum()
    {
        return orderNum;
    }

    public void setRuleType(String ruleType)
    {
        this.ruleType = ruleType;
    }

    public String getRuleType()
    {
        return ruleType;
    }
    public void setDelFlag(String delFlag)
    {
        this.delFlag = delFlag;
    }

    public String getDelFlag()
    {
        return delFlag;
    }

    public String getParentIds() {
        return parentIds;
    }

    public void setParentIds(String parentIds) {
        this.parentIds = parentIds;
    }

    public String getRuleName() {
        return ruleName;
    }

    public void setRuleName(String ruleName) {
        this.ruleName = ruleName;
    }

    public Long getModelId() {
        return modelId;
    }

    public void setModelId(Long modelId) {
        this.modelId = modelId;
    }



    @Override
    public String toString() {
        return new ToStringBuilder(this, ToStringStyle.MULTI_LINE_STYLE)
            .append("id", getId())
            .append("ruleName", getRuleName())
            .append("parentId", getParentId())
            .append("orderNum", getOrderNum())
            .append("rule", getRule())
            .append("attributes", getAttributes())
            .append("content", getContent())
            .append("ruleType", getRuleType())
            .append("delFlag", getDelFlag())
            .toString();
    }
}
