package com.crc.secface.entity;

import org.apache.commons.lang3.builder.ToStringBuilder;
import org.apache.commons.lang3.builder.ToStringStyle;

import java.util.Date;

/**
 * 【请填写功能名称】对象 tb_task_info
 *
 * @author wst
 * @date 2020-10-21
 */
public class TaskInfo
{
    private static final long serialVersionUID = 1L;

    /** $column.columnComment */
    private Long id;

    /** 任务编码 */
    private String code;

    /** 任务名称 */
    private String taskName;

    /** 1.crclog任务,2.spark任务,3.业务模型定时任务 */
    private String taskType;

    /** 最后更新时间 */
    private Date lastStartTime;

    /** 任务状态:1.运行；2.正常退出;3.执行异常 */
    private String taskStatus;

    /** $column.columnComment */
    private Long isDel;

    private Date createTime;

    private String createBy;

    public void setId(Long id)
    {
        this.id = id;
    }

    public Long getId()
    {
        return id;
    }
    public void setCode(String code)
    {
        this.code = code;
    }

    public String getCode()
    {
        return code;
    }
    public void setTaskName(String taskName)
    {
        this.taskName = taskName;
    }

    public String getTaskName()
    {
        return taskName;
    }
    public void setTaskType(String taskType)
    {
        this.taskType = taskType;
    }

    public String getTaskType()
    {
        return taskType;
    }
    public void setLastStartTime(Date lastStartTime)
    {
        this.lastStartTime = lastStartTime;
    }

    public Date getLastStartTime()
    {
        return lastStartTime;
    }
    public void setTaskStatus(String taskStatus)
    {
        this.taskStatus = taskStatus;
    }

    public String getTaskStatus()
    {
        return taskStatus;
    }
    public void setIsDel(Long isDel)
    {
        this.isDel = isDel;
    }

    public Long getIsDel()
    {
        return isDel;
    }

    public Date getCreateTime() {
        return createTime;
    }

    public String getCreateBy() {
        return createBy;
    }

    public void setCreateTime(Date createTime) {
        this.createTime = createTime;
    }

    public void setCreateBy(String createBy) {
        this.createBy = createBy;
    }



    @Override
    public String toString() {
        return new ToStringBuilder(this, ToStringStyle.MULTI_LINE_STYLE)
            .append("id", getId())
            .append("code", getCode())
            .append("taskName", getTaskName())
            .append("taskType", getTaskType())
            .append("lastStartTime", getLastStartTime())
            .append("taskStatus", getTaskStatus())
            .append("isDel", getIsDel())
            .toString();
    }
}
