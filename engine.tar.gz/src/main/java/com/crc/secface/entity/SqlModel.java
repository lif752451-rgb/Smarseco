package com.crc.secface.entity;

import java.io.Serializable;

public class SqlModel implements Serializable {
    long total;
    long sumTotal;
    double avgValue;
    String a1;
    String a2;
    String a3;
    String a4;

    public String getA1() {
        return a1;
    }

    public void setA1(String a1) {
        this.a1 = a1;
    }

    public String getA2() {
        return a2;
    }

    public void setA2(String a2) {
        this.a2 = a2;
    }

    public String getA3() {
        return a3;
    }

    public void setA3(String a3) {
        this.a3 = a3;
    }

    public String getA4() {
        return a4;
    }

    public void setA4(String a4) {
        this.a4 = a4;
    }

    public long getTotal() {
        return total;
    }

    public void setTotal(long total) {
        this.total = total;
    }

    public long getSumTotal() {
        return sumTotal;
    }

    public void setSumTotal(long sumTotal) {
        this.sumTotal = sumTotal;
    }

    public double getAvgValue() {
        return avgValue;
    }

    public void setAvgValue(double avgValue) {
        this.avgValue = avgValue;
    }
}
