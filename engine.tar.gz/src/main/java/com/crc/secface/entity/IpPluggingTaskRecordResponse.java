package com.crc.secface.entity;

import com.fasterxml.jackson.annotation.JsonFormat;
import lombok.Data;

import java.util.Date;

/**
 * @author jixiangqi
 * @date 2023/2/7
 */
@Data
public class IpPluggingTaskRecordResponse {

    private String id;

    private String taskId;

    private String actionType;

    private String operationType;

    private String operationUser;

    private String actionResult;

    private String actionReason;

    private String msg;

    private String deadlineTime;

    @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss",timezone="GMT+8")
    private Date actionTime;

}
