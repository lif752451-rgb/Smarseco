package com.crc.secface.entity;

import com.crc.secface.config.EsDataSource;
import lombok.Data;

@Data
public class RelationId {
    String type;
    String id;
    String tableName;
    EsDataSource esDataSource;
    String newId;
}
