package com.crc.secface.entity;


import java.util.Date;

/**
 * vul对象 tb_asset_vul
 *
 * @author wst
 * @date 2021-08-30
 */
public class TbAssetVul {
    private static final long serialVersionUID = 1L;
    private String officeId;
    private String instance;
    private String send;

    public String getSend() {
        return send;
    }

    public void setSend(String send) {
        this.send = send;
    }

    public String getInstance() {
        return instance;
    }

    public void setInstance(String instance) {
        this.instance = instance;
    }

    public String getOfficeId() {
        return officeId;
    }

    public void setOfficeId(String officeId) {
        this.officeId = officeId;
    }

    /**
     * $column.columnComment
     */
    private String id;

    /**
     * $column.columnComment
     */
    private String name;

    /**
     * 0:低危, 1:中危, 2:⾼危, 3:严重
     */
    private String level;

    /**
     * 类型
     */
    private String type;

    /**
     * $column.columnComment
     */
    private String cveId;

    /**
     * 漏洞地址
     */
    private String url;

    /**
     * 漏洞描述
     */
    private String description;

    /**
     * 解决方案
     */
    private String solution;

    /**
     * 漏洞危害
     */
    private String impact;

    /**
     * $column.columnComment
     */
    private String ip;

    /**
     * 0-未修复，1已修复
     */
    private String status;

    /**
     * 0-D01,1-qingteng
     */
    private String dataSource;

    /**
     * $column.columnComment
     */
    private String ud1;

    /**
     * $column.columnComment
     */
    private String ud2;

    /**
     * $column.columnComment
     */
    private String ud3;

    /**
     * $column.columnComment
     */
    private String ud4;

    private Date publishTime;
    private String existExp;
    private String existPoc;
    private String existRemote;

    public Date getPublishTime() {
        return publishTime;
    }

    public void setPublishTime(Date publishTime) {
        this.publishTime = publishTime;
    }

    public String getExistExp() {
        return existExp;
    }

    public void setExistExp(String existExp) {
        this.existExp = existExp;
    }

    public String getExistPoc() {
        return existPoc;
    }

    public void setExistPoc(String existPoc) {
        this.existPoc = existPoc;
    }

    public String getExistRemote() {
        return existRemote;
    }

    public void setExistRemote(String existRemote) {
        this.existRemote = existRemote;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getId() {
        return id;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getName() {
        return name;
    }

    public void setLevel(String level) {
        this.level = level;
    }

    public String getLevel() {
        return level;
    }

    public void setType(String type) {
        this.type = type;
    }

    public String getType() {
        return type;
    }

    public void setCveId(String cveId) {
        this.cveId = cveId;
    }

    public String getCveId() {
        return cveId;
    }

    public void setUrl(String url) {
        this.url = url;
    }

    public String getUrl() {
        return url;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public String getDescription() {
        return description;
    }

    public void setSolution(String solution) {
        this.solution = solution;
    }

    public String getSolution() {
        return solution;
    }

    public void setImpact(String impact) {
        this.impact = impact;
    }

    public String getImpact() {
        return impact;
    }

    public void setIp(String ip) {
        this.ip = ip;
    }

    public String getIp() {
        return ip;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public String getStatus() {
        return status;
    }

    public void setDataSource(String dataSource) {
        this.dataSource = dataSource;
    }

    public String getDataSource() {
        return dataSource;
    }

    public void setUd1(String ud1) {
        this.ud1 = ud1;
    }

    public String getUd1() {
        return ud1;
    }

    public void setUd2(String ud2) {
        this.ud2 = ud2;
    }

    public String getUd2() {
        return ud2;
    }

    public void setUd3(String ud3) {
        this.ud3 = ud3;
    }

    public String getUd3() {
        return ud3;
    }

    public void setUd4(String ud4) {
        this.ud4 = ud4;
    }

    public String getUd4() {
        return ud4;
    }

    /**
     * $column.columnComment
     */
    private Date firstTime;

    /**
     * $column.columnComment
     */
    private Date repairTime;

    /**
     * $column.columnComment
     */
    private Date recentlyTime;

    /**
     * $column.columnComment
     */
    private String isHung;
    /**
     * 创建者
     */
    private String createBy;

    /**
     * 创建时间
     */
    private Date createTime;

    /**
     * 更新者
     */
    private String updateBy;

    /**
     * 更新时间
     */
    private Date updateTime;
    /**
     * $column.columnComment
     */
    private String isWhite;

    public Date getFirstTime() {
        return firstTime;
    }

    public void setFirstTime(Date firstTime) {
        this.firstTime = firstTime;
    }

    public Date getRepairTime() {
        return repairTime;
    }

    public void setRepairTime(Date repairTime) {
        this.repairTime = repairTime;
    }

    public Date getRecentlyTime() {
        return recentlyTime;
    }

    public void setRecentlyTime(Date recentlyTime) {
        this.recentlyTime = recentlyTime;
    }

    public String getIsHung() {
        return isHung;
    }

    public void setIsHung(String isHung) {
        this.isHung = isHung;
    }

    public String getCreateBy() {
        return createBy;
    }

    public void setCreateBy(String createBy) {
        this.createBy = createBy;
    }

    public Date getCreateTime() {
        return createTime;
    }

    public void setCreateTime(Date createTime) {
        this.createTime = createTime;
    }

    public String getUpdateBy() {
        return updateBy;
    }

    public void setUpdateBy(String updateBy) {
        this.updateBy = updateBy;
    }

    public Date getUpdateTime() {
        return updateTime;
    }

    public void setUpdateTime(Date updateTime) {
        this.updateTime = updateTime;
    }

    public String getIsWhite() {
        return isWhite;
    }

    public void setIsWhite(String isWhite) {
        this.isWhite = isWhite;
    }

    @Override
    public String toString() {
        return "TbAssetVul{" +
                "id='" + id + '\'' +
                ", name='" + name + '\'' +
                ", level='" + level + '\'' +
                ", type='" + type + '\'' +
                ", cveId='" + cveId + '\'' +
                ", url='" + url + '\'' +
                ", description='" + description + '\'' +
                ", solution='" + solution + '\'' +
                ", impact='" + impact + '\'' +
                ", ip='" + ip + '\'' +
                ", status='" + status + '\'' +
                ", dataSource='" + dataSource + '\'' +
                ", ud1='" + ud1 + '\'' +
                ", ud2='" + ud2 + '\'' +
                ", ud3='" + ud3 + '\'' +
                ", ud4='" + ud4 + '\'' +
                '}';
    }
}
