package com.crc.secface.entity;

import org.apache.commons.lang3.builder.ToStringBuilder;
import org.apache.commons.lang3.builder.ToStringStyle;

/**
 * 【请填写功能名称】对象 tb_task_config
 *
 * @author wst
 * @date 2020-10-21
 */
public class TaskConfig
{
    private static final long serialVersionUID = 1L;

    /** $column.columnComment */
    private Long id;

    /** 任务id */
    private Long taskId;

    /** 接收数据类型:1.syslog,2.mysql,3.kafka */
    private String sourceType;

    /** 源数据url */
    private String sourceUrl;

    /** 消费kafka主题 */
    private String consumerTopic;

    /** 发送数据kafka */
    private String sendKafkaUrl;

    /** 发送主题 */
    private String sendTopic;

    public void setId(Long id)
    {
        this.id = id;
    }

    public Long getId()
    {
        return id;
    }
    public void setTaskId(Long taskId)
    {
        this.taskId = taskId;
    }

    public Long getTaskId()
    {
        return taskId;
    }
    public void setSourceType(String sourceType)
    {
        this.sourceType = sourceType;
    }

    public String getSourceType()
    {
        return sourceType;
    }
    public void setSourceUrl(String sourceUrl)
    {
        this.sourceUrl = sourceUrl;
    }

    public String getSourceUrl()
    {
        return sourceUrl;
    }
    public void setConsumerTopic(String consumerTopic)
    {
        this.consumerTopic = consumerTopic;
    }

    public String getConsumerTopic()
    {
        return consumerTopic;
    }
    public void setSendKafkaUrl(String sendKafkaUrl)
    {
        this.sendKafkaUrl = sendKafkaUrl;
    }

    public String getSendKafkaUrl()
    {
        return sendKafkaUrl;
    }
    public void setSendTopic(String sendTopic)
    {
        this.sendTopic = sendTopic;
    }

    public String getSendTopic()
    {
        return sendTopic;
    }

    @Override
    public String toString() {
        return new ToStringBuilder(this, ToStringStyle.MULTI_LINE_STYLE)
            .append("id", getId())
            .append("taskId", getTaskId())
            .append("sourceType", getSourceType())
            .append("sourceUrl", getSourceUrl())
            .append("consumerTopic", getConsumerTopic())
            .append("sendKafkaUrl", getSendKafkaUrl())
            .append("sendTopic", getSendTopic())
            .toString();
    }
}
