package com.crc.secface.entity;

import java.io.Serializable;
import java.util.Date;

/**
 * @description 封堵任务表
 * @author hejingsheng1
 * @date 2023-08-03
 */
public class TbIpPluggingTask implements Serializable {

    private static final long serialVersionUID = 1L;

    /**
     * 主键id
     */
    private Integer id;

    /**
     * 封堵ip
     */
    private String ip;

    /**
     * 执行设备
     */
    private String execDevice;

    /**
     * 截至时间
     */
    private Date deadlineTime;

    /**
     * 封堵原因
     */
    private String reason;

    /**
     * 删除标记 0 未删除 1 已删除
     */
    private int delFlag;

    /**
     * 创建人
     */
    private String createBy;

    /**
     * 创建人姓名
     */
    private String createByLabel;

    /**
     * 更新时间
     */
    private Date updateTime;

    /**
     * 创建时间
     */
    private Date createTime;

    /**
     * 更新人
     */
    private String updateBy;

    /**
     * 封堵次数
     */
    private Integer execCount;

    /**
     * ip归属地
     */
    private String ipHome;

    /**
     * 安全设备ip
     */
    private String deviceIp;

    /**
     * 策略组
     */
    private String strategyName;

    /**
     * 最近解封时间
     */
    private Date unsealTime;

    /**
     * 最近封堵时间
     */
    private Date pluggingTime;

    /**
     * 1 已解封 2 已封堵
     */
    private int status;


    public TbIpPluggingTask() {
    }

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getIp() {
        return ip;
    }

    public void setIp(String ip) {
        this.ip = ip;
    }

    public String getExecDevice() {
        return execDevice;
    }

    public void setExecDevice(String execDevice) {
        this.execDevice = execDevice;
    }

    public Date getDeadlineTime() {
        return deadlineTime;
    }

    public void setDeadlineTime(Date deadlineTime) {
        this.deadlineTime = deadlineTime;
    }

    public String getReason() {
        return reason;
    }

    public void setReason(String reason) {
        this.reason = reason;
    }

    public int getDelFlag() {
        return delFlag;
    }

    public void setDelFlag(int delFlag) {
        this.delFlag = delFlag;
    }

    public String getCreateBy() {
        return createBy;
    }

    public void setCreateBy(String createBy) {
        this.createBy = createBy;
    }

    public String getCreateByLabel() {
        return createByLabel;
    }

    public void setCreateByLabel(String createByLabel) {
        this.createByLabel = createByLabel;
    }

    public Date getUpdateTime() {
        return updateTime;
    }

    public void setUpdateTime(Date updateTime) {
        this.updateTime = updateTime;
    }

    public Date getCreateTime() {
        return createTime;
    }

    public void setCreateTime(Date createTime) {
        this.createTime = createTime;
    }

    public String getUpdateBy() {
        return updateBy;
    }

    public void setUpdateBy(String updateBy) {
        this.updateBy = updateBy;
    }

    public Integer getExecCount() {
        return execCount;
    }

    public void setExecCount(Integer execCount) {
        this.execCount = execCount;
    }

    public String getIpHome() {
        return ipHome;
    }

    public void setIpHome(String ipHome) {
        this.ipHome = ipHome;
    }

    public String getDeviceIp() {
        return deviceIp;
    }

    public void setDeviceIp(String deviceIp) {
        this.deviceIp = deviceIp;
    }

    public String getStrategyName() {
        return strategyName;
    }

    public void setStrategyName(String strategyName) {
        this.strategyName = strategyName;
    }

    public Date getUnsealTime() {
        return unsealTime;
    }

    public void setUnsealTime(Date unsealTime) {
        this.unsealTime = unsealTime;
    }

    public Date getPluggingTime() {
        return pluggingTime;
    }

    public void setPluggingTime(Date pluggingTime) {
        this.pluggingTime = pluggingTime;
    }

    public int getStatus() {
        return status;
    }

    public void setStatus(int status) {
        this.status = status;
    }

}
