package com.crc.secface.entity;

import org.apache.commons.lang3.builder.ToStringBuilder;
import org.apache.commons.lang3.builder.ToStringStyle;

import java.util.Date;

/**
 * 【请填写功能名称】对象 tb_risk_static_trend
 *
 * @author wst
 * @date 2020-09-07
 */
public class TbRiskStaticTrend {
    private static final long serialVersionUID = 1L;

    /**
     * $column.columnComment
     */
    private String id;


    private String staticId;

    /**
     * 统计项值:计数,百分率
     */
    private String staticValue;

    /**
     * 统计类型:1.每天统计，2.每周统计,3.每月统计
     */
    private Long staticType;

    /**
     * 统计时间
     */
    private String staticDate;

    /**
     * 利润中心Id
     */
    private Long assetInstanceId;

    /**
     * 删除标志（0代表存在 2代表删除）
     */
    private Integer delFlag;

    //统计时间段
    private String staticTimeRange;
    /**
     * 创建者
     */
    private String createBy;

    /**
     * 创建时间
     */
    private Date createTime;

    /**
     * 更新者
     */
    private String updateBy;

    /**
     * 更新时间
     */
    private Date updateTime;

    public String getCreateBy() {
        return createBy;
    }

    public void setCreateBy(String createBy) {
        this.createBy = createBy;
    }

    public Date getCreateTime() {
        return createTime;
    }

    public void setCreateTime(Date createTime) {
        this.createTime = createTime;
    }

    public String getUpdateBy() {
        return updateBy;
    }

    public void setUpdateBy(String updateBy) {
        this.updateBy = updateBy;
    }

    public Date getUpdateTime() {
        return updateTime;
    }

    public void setUpdateTime(Date updateTime) {
        this.updateTime = updateTime;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getId() {
        return id;
    }

    public void setStaticId(String staticId) {
        this.staticId = staticId;
    }

    public String getStaticId() {
        return staticId;
    }

    public void setStaticValue(String staticValue) {
        this.staticValue = staticValue;
    }

    public String getStaticValue() {
        return staticValue;
    }

    public void setStaticType(Long staticType) {
        this.staticType = staticType;
    }

    public Long getStaticType() {
        return staticType;
    }

    public void setStaticDate(String staticDate) {
        this.staticDate = staticDate;
    }

    public String getStaticDate() {
        return staticDate;
    }

    public void setAssetInstanceId(Long assetInstanceId) {
        this.assetInstanceId = assetInstanceId;
    }

    public Long getAssetInstanceId() {
        return assetInstanceId;
    }

    public void setDelFlag(Integer delFlag) {
        this.delFlag = delFlag;
    }

    public Integer getDelFlag() {
        return delFlag;
    }

    public String getStaticTimeRange() {
        return staticTimeRange;
    }

    public void setStaticTimeRange(String staticTimeRange) {
        this.staticTimeRange = staticTimeRange;
    }

    @Override
    public String toString() {
        return new ToStringBuilder(this, ToStringStyle.MULTI_LINE_STYLE)
                .append("id", getId())
                .append("staticId", getStaticId())
                .append("staticValue", getStaticValue())
                .append("staticType", getStaticType())
                .append("staticDate", getStaticDate())
                .append("assetInstanceId", getAssetInstanceId())
                .append("delFlag", getDelFlag())
                .append("createTime", getCreateTime())
                .append("createBy", getCreateBy())
                .toString();
    }
}
