package com.crc.secface.entity;

public class LogData {
    private String id;
    private String data;
    private String status;
    private String batch;
    private String tbDate;

    private String esIndex;

    public String getTbDate() {
        return tbDate;
    }

    public void setTbDate(String tbDate) {
        this.tbDate = tbDate;
    }

    public String getBatch() {
        return batch;
    }

    public void setBatch(String batch) {
        this.batch = batch;
    }

    public LogData() {
        status = "0";
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getData() {
        return data;
    }

    public void setData(String data) {
        this.data = data;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public String getEsIndex() {
        return esIndex;
    }

    public void setEsIndex(String esIndex) {
        this.esIndex = esIndex;
    }

    String oldTbDate;
    public void setOldTbDate(String oldTbDate) {
        this.oldTbDate = oldTbDate;
    }

    public String getOldTbDate() {
        return oldTbDate;
    }
}
