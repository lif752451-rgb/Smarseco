package com.crc.secface.entity;

public class AssetUser {
    private String cmdbId;
    private String appname;
    private String username;
    private String mail;
    private String phone;

    public String getCmdbId() {
        return cmdbId;
    }

    public void setCmdbId(String cmdbId) {
        this.cmdbId = cmdbId;
    }

    public String getAppname() {
        return appname;
    }

    public void setAppname(String appname) {
        this.appname = appname;
    }

    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    public String getMail() {
        return mail;
    }

    public void setMail(String mail) {
        this.mail = mail;
    }

    public String getPhone() {
        return phone;
    }

    public void setPhone(String phone) {
        this.phone = phone;
    }
}
