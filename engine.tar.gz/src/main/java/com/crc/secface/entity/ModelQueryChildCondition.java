package com.crc.secface.entity;

import lombok.Data;

/**
 * @author jixiangqi
 * @date 2022/11/22
 * 模型子集条件
 */
@Data
public class ModelQueryChildCondition {

    /**
     * 子集名称
     */
    private String name;
    //数据源
    private String dataSourceId;

    private String dataSourceCode;

    /**
     * ES数据源
     */
    private String esConfigId;

    /**
     * 数据源索引
     */
    private String esIndexId;

    /**
     * 排序字段
     */
    private String sortKey;

    /**
     * 查询时间
     */
    private int queryRange;

    /**
     * 查询时间单位
     */
    private int queryRangeUnit;

    /**
     * 运算策略
     */
    private Object queryContent;

    /**
     * 运算模式：（1：规则树模式 2：自定义模式 3：条件模式）
     */
    private int operateType;
}
