package com.crc.secface.entity;

import com.baomidou.mybatisplus.annotation.TableField;
import com.crc.common.enums.DatabaseEnums;
import com.crc.common.utils.VersionUtils;
import lombok.Data;

import java.util.Date;

/**
 * @author hejingsheng1
 * @description 资产信息表
 * @date 2023-09-21
 */
@Data
public class TbAsset {

    /**
     * 主键id
     */
    private Long id;

    /**
     * 内网ip
     */
    private String internalIp;

    /**
     * 实例名称
     */
    private String instance;

    /**
     * 实例英文名称
     */
    private String instanceCode;

    /**
     * 资产等级
     */
    private Integer keyAsset;

    /**
     * 资产类型 (废弃)
     */
    private String type;

    /**
     * 资产子类型 (废弃)
     */
    private String subType;

    /**
     * 环境类型
     */
    private String environmentType;

    /**
     * 标记状态:0-未标记，1-已标记
     */
    private Integer status;

    /**
     * 资产描述
     */
    private String remarks;

    /**
     * 一级部门id (废弃)
     */
    private Long companyId;

    /**
     * 一级部门名称 (废弃)
     */
    private String companyName;

    /**
     * 二级部门id (废弃)
     */
    private Long subCompanyId;

    /**
     * 二级部门名称 (废弃)
     */
    private String subCompanyName;

    /**
     * 所属部门id (废弃)
     */
    private Long officeId;

    /**
     * 所属部门名称 (废弃)
     */
    private String officeName;

    /**
     * 所属项目
     */
    private String project;

    /**
     * 责任人
     */
    private String assetUser;

    /**
     * 所属责任人邮箱 (废弃)
     */
    private String assetMail;

    /**
     * 所属责任人联系方式 (废弃)
     */
    private String assetPhone;

    /**
     * 运维部门id (废弃)
     */
    private Long operatingDeptId;

    /**
     * 运维部门名称 (废弃)
     */
    private String operatingDeptName;

    /**
     * 运维人
     */
    private String operatingUser;

    /**
     * 运维责任人联系方式 (废弃)
     */
    private String operatingPhone;

    /**
     * 运维责任人邮箱 (废弃)
     */
    private String operatingEmail;

    /**
     * local_ip
     */
    private String localIp;

    /**
     * 虚ip
     */
    private String virtualIp;

    /**
     * 互联网ip
     */
    private String internetIp;

    /**
     * 带外ip
     */
    private String outofbandIp;

    /**
     * 域名
     */
    private String domain;

    /**
     * 网络区域 (废弃)
     */
    private String area;

    /**
     * 网络子区域 (废弃)
     */
    private String subArea;

    /**
     * 部署位置
     */
    private String geographicLocation;

    /**
     * 前置机房城市
     */
    private String frontComputerRoomCity;

    /**
     * 安全技术支撑单位
     */
    private String safetyTechnicalSupportUnit;

    /**
     * 等保定级
     */
    private Integer equalProtectionLevel;

    /**
     * 等保备案编号
     */
    private String equalProtectionCode;

    /**
     * 等保测评情况
     */
    private String equalProtectionTestContent;

    /**
     * 等保结论
     */
    private String equalProtectionResult;

    /**
     * 最近一次等级测评时间
     */
    private Date equalProtectionFirstTime;

    /**
     * 是否为关键基础设施 0否1是
     */
    private Integer assetPower;

    /**
     * 是否完成国密改造:0-未完成，1-已完成
     */
    private Integer transformationCompleted;

    /**
     * 数据来源
     */
    private Integer source;

    /**
     * 操作系统
     */
    private String os;

    /**
     * mac地址
     */
    private String macAddress;

    /**
     * 资产状态
     */
    private Integer operatingStatus;

    /**
     * 数据库系统
     */
    private String databaseSystem;

    /**
     * (废弃)
     */
    private String softVersion;

    /**
     * 维保到期时间
     */
    private Date expirtTime;

    /**
     * 是否发布互联网:0=否，1=是
     */
    private Integer internetPublic;

    /**
     * 创建者
     */
    private String createBy;

    /**
     * 创建时间
     */
    private Date createTime;

    /**
     * 更新者
     */
    private String updateBy;

    /**
     * 更新时间
     */
    private Date updateTime;

    /**
     * 删除标志（0代表存在 1代表删除）
     */
    private String delFlag;

    /**
     * 更新标记:1-新增，2-更新
     */
    private String updateFlag;

    /**
     * 认领状态:0-未认领，1-已认领
     */
    private String apply;

    /**
     * 认领人
     */
    private String applyUser;

    /**
     * 认领时间
     */
    private Date applyTime;

    /**
     * 资源类型
     */
    private Integer sourceType;

    /**
     * 所属单位名称
     */
    private String affiliationDeptName;

    /**
     * 所属单位叶子节点id
     */
    private Long affiliationDeptNodeId;

    /**
     * 网络区域自定义uuid
     */
    private String areaCustomUuid;

    /**
     * 网络区域名称
     */
    private String areaName;

    /**
     * 资产类型id
     */
    private String assetTypeId;

    /**
     * 资产类型名称
     */
    private String assetTypeName;

    /**
     * 主机名称
     */
    private String hostName;

    /**
     * 安全评分
     */
    private Double safetyScore;

    /**
     * 部门路径
     */
    private String deptPath;

    /**
     * 区域路径
     */
    private String areaPath;

    /**
     * 资产类型路径
     */
    private String assetTypePath;

    /**
     * 标签
     */
    private String tag;

    /**
     * 内核版本
     */
    private String kernelVersion;

    /**
     * 是否存在漏洞(0-否，1-是)
     */
    private String isExistVul;

    /**
     * 是否存在日志(0-否，1-是)
     */
    private String isExistLog;

    /**
     * 所属系统
     */
    private String appSystem;

    /**
     * 数据同步引擎使用字段
     */
    private String code;

    /**
     * 是否集权系统 0否1是
     */
    private Integer centralizedSystem;

    /**
     * 关联告警id
     */
    private String alarmId;

    /**
     * 告警设备
     */
    private String ruleBase;

    /**
     * 告警设备ip
     */
    private String ruleBaseIp;

    /**
     * 实战期间是否授权关闭 0 否(默认)
     */
    private Integer isCombatOff;

    /**
     * 授权关闭起始时间
     */
    private Date offStartTime;

    /**
     * 授权关闭截止时间
     */
    private Date offEndTime;

    /**
     * 实战期间是否有关闭计划 0 否(默认)
     */
    private Integer isCombatPlan;

    /**
     * 关闭计划
     */
    private String offPlan;

    /**
     * 是否包含个人信息 0 否(默认)
     */
    private Integer isPersonalInfo;

    /**
     * 个人信息类型
     */
    private String personalInfoType;

    /**
     * 个人信息量级
     */
    private String personalInfoOrder;

    @TableField(exist = false)
    private String dbType;

    public String getDbType() {
        if (VersionUtils.getDatabase() == DatabaseEnums.MYSQL.getCode()) {
            return "mysql";
        } else {
            return "other";
        }
    }

    public void setDbType(String dbType) {
        this.dbType = dbType;
    }

    String keyAssetLabel;
    String environmentTypeLabel;
    String operatingStatusLabel;
    String equalProtectionLevelLabel;
}
