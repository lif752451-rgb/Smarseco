package com.crc.secface.entity;

import lombok.Data;

@Data
public class HwVo {
    String elemId;
    String elemValue;
}
