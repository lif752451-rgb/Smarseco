package com.crc.secface.entity;

import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableField;
import com.baomidou.mybatisplus.annotation.TableId;
import lombok.Data;
import lombok.experimental.Accessors;


/**
 * <p>
 * 攻击面_互联网资产管理
 * </p>
 *
 * @author lyc
 * @since 2023-02-14
 */
@Data
@Accessors(chain = true)
public class AssetAsmInternet {

    /**
     * 唯一主键
     */
    @TableId(value = "id", type = IdType.AUTO)
    private Long id;

    /**
     * 资产ID
     */
    @TableField(value = "asset_id")
    private String assetId;

    /**
     * IP
     */
    @TableField(value = "ip")
    private String ip;

    /**
     * 端口
     */
    @TableField(value = "port")
    private String port;

    /**
     * 访问地址
     */
    @TableField(value = "access_address")
    private String accessAddress;

    /**
     * 网页标题
     */
    @TableField(value = "web_title")
    private String webTitle;

    /**
     * 域名
     */
    @TableField(value = "domain_name")
    private String domainName;

    /**
     * 协议(1tcp   2http   3https)
     */
    @TableField(value = "agreement")
    private Integer agreement;


    /**
     * web服务名
     */
    @TableField(value = "web_service_name")
    private String webServiceName;

    /**
     * web指纹
     */
    @TableField(value = "web_fingerprint")
    private String webFingerprint;

    /**
     * 数据来源
     */
    @TableField(value = "data_source")
    private String dataSource;

    /**
     * 备注
     */
    @TableField(value = "remark")
    private String remark;

    /**
     * 所属组织名称
     */
    @TableField(value = "affiliation_dept_name")
    private String affiliationDeptName;

    /**
     * 所属组织id
     */
    @TableField(value = "affiliation_dept_node_id")
    private Long affiliationDeptNodeId;

    /**
     * 责任人
     */
    @TableField(value = "responsible")
    private String responsible;

    /**
     * 发布位置(1数据中心 2公有云 3前置机房)
     */
    @TableField(value = "publish_location")
    private String publishLocation;

    /**
     * 使用状态 (1在用 2未使用)
     */
    @TableField(value = "use_status")
    private Integer useStatus;

    /**
     * 创建人-全称
     */
    @TableField(value = "create_by_label")
    private String createByLabel;
}
