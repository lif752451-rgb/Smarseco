package com.crc.secface.entity;

import lombok.Data;
import org.apache.commons.lang3.StringUtils;

/**
 * @author jixiangqi
 * @date 2022/11/22
 * 关联条件
 */
@Data
public class RelationCondition {

    private String firstName;

    private String firstField;

    private String operationType;

    private String secondName;

    private String secondField;


    public boolean isGood() {
        if (StringUtils.isBlank(firstField) || StringUtils.isBlank(firstName) || StringUtils.isBlank(operationType) || StringUtils.isBlank(secondName) || StringUtils.isBlank(secondField)) {
            return false;
        }
        return true;
    }
}
