package com.crc.secface.entity;

import lombok.Data;

/**
 * @author jixiangqi
 * @date 2022/11/22
 * sql子集条件
 */
@Data
public class SqlQueryChildCondition {

    private String name;

    private String queryContent;

    /**
     * 1 无
     * 2 固定时间
     * 3 最近时间
     */
    private int type;

    private String startTime;

    private String endTime;

    private String fixedTime;
}
