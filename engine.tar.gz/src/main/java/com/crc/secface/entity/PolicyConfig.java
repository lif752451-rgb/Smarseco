package com.crc.secface.entity;

/**
 * @author simba@onlying.cn
 * @date 2020/12/8 15:25
 */
public class PolicyConfig {

    private Long id;
    //策略ID
    private Long policyId;
    //发送策略
    private String sendType;
    //是否启用 0：启用 1：禁用
    private String isEnable;
    //发送人
    private String emailSender;

    private String rworkSender;

    //接收人
    private String emailReceiver;

    private String rworkReceiver;

    /*//发送开始时间
    private String sendTimeStart;
    //发送结束时间
    private String sendTimeEnd;
    //周几
    private String weeks;*/

    private String emailStartTime;

    private String emailEndTime;

    private String emailWeeks;

    private String rworkStartTime;

    private String rworkEndTime;

    private String rworkWeeks;

    private Integer emailStatus;

    private Integer rworkStatus;

    public Integer getEmailStatus() {
        return emailStatus;
    }

    public void setEmailStatus(Integer emailStatus) {
        this.emailStatus = emailStatus;
    }

    public Integer getRworkStatus() {
        return rworkStatus;
    }

    public void setRworkStatus(Integer rworkStatus) {
        this.rworkStatus = rworkStatus;
    }

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public Long getPolicyId() {
        return policyId;
    }

    public void setPolicyId(Long policyId) {
        this.policyId = policyId;
    }

    public String getSendType() {
        return sendType;
    }

    public void setSendType(String sendType) {
        this.sendType = sendType;
    }

    public String getIsEnable() {
        return isEnable;
    }

    public void setIsEnable(String isEnable) {
        this.isEnable = isEnable;
    }

    /*public String getSender() {
        return sender;
    }

    public void setSender(String sender) {
        this.sender = sender;
    }

    public String getReceiver() {
        return receiver;
    }

    public void setReceiver(String receiver) {
        this.receiver = receiver;
    }*/

    /*public String getSendTimeStart() {
        return sendTimeStart;
    }

    public void setSendTimeStart(String sendTimeStart) {
        this.sendTimeStart = sendTimeStart;
    }

    public String getSendTimeEnd() {
        return sendTimeEnd;
    }

    public void setSendTimeEnd(String sendTimeEnd) {
        this.sendTimeEnd = sendTimeEnd;
    }

    public String getWeeks() {
        return weeks;
    }

    public void setWeeks(String weeks) {
        this.weeks = weeks;
    }*/

    public String getEmailSender() {
        return emailSender;
    }

    public void setEmailSender(String emailSender) {
        this.emailSender = emailSender;
    }

    public String getRworkSender() {
        return rworkSender;
    }

    public void setRworkSender(String rworkSender) {
        this.rworkSender = rworkSender;
    }

    public String getEmailReceiver() {
        return emailReceiver;
    }

    public void setEmailReceiver(String emailReceiver) {
        this.emailReceiver = emailReceiver;
    }

    public String getRworkReceiver() {
        return rworkReceiver;
    }

    public void setRworkReceiver(String rworkReceiver) {
        this.rworkReceiver = rworkReceiver;
    }

    public String getEmailStartTime() {
        return emailStartTime;
    }

    public void setEmailStartTime(String emailStartTime) {
        this.emailStartTime = emailStartTime;
    }

    public String getEmailEndTime() {
        return emailEndTime;
    }

    public void setEmailEndTime(String emailEndTime) {
        this.emailEndTime = emailEndTime;
    }

    public String getEmailWeeks() {
        return emailWeeks;
    }

    public void setEmailWeeks(String emailWeeks) {
        this.emailWeeks = emailWeeks;
    }

    public String getRworkStartTime() {
        return rworkStartTime;
    }

    public void setRworkStartTime(String rworkStartTime) {
        this.rworkStartTime = rworkStartTime;
    }

    public String getRworkEndTime() {
        return rworkEndTime;
    }

    public void setRworkEndTime(String rworkEndTime) {
        this.rworkEndTime = rworkEndTime;
    }

    public String getRworkWeeks() {
        return rworkWeeks;
    }

    public void setRworkWeeks(String rworkWeeks) {
        this.rworkWeeks = rworkWeeks;
    }
}
