package com.crc.secface.entity;

public class EsData {
    private String id;
    private String day;
    private String storeSize;
    private String type;
    private String description;
    private String docCount;

    public EsData(String indexName, String size, String docCount, String day) {
        this.id = indexName;
        this.storeSize = size;
        this.docCount = docCount;
        this.day = day;
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getDay() {
        return day;
    }

    public void setDay(String day) {
        this.day = day;
    }

    public String getStoreSize() {
        return storeSize;
    }

    public void setStoreSize(String storeSize) {
        this.storeSize = storeSize;
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public String getDocCount() {
        return docCount;
    }

    public void setDocCount(String docCount) {
        this.docCount = docCount;
    }
}
