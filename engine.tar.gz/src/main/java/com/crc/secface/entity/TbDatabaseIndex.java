package com.crc.secface.entity;

import com.baomidou.mybatisplus.annotation.TableField;
import com.baomidou.mybatisplus.extension.handlers.FastjsonTypeHandler;
import lombok.Data;

import java.util.Date;

/**
 * @author jixiangqi
 * @date 2022/6/6
 */
@Data
public class TbDatabaseIndex  {

    private String id;

    private String dataIndexName;

    private String groupName;

    private String dataSourceId;

    private String dataSourceName;

    private String indexRule;

    private int sortNum;

    private String timeField;

    private int isShare;

    private String createByLabel;

    /** 创建时间 */
    private Date createTime;

    /** 创建时间 */
    private Date updateTime;

    /**
     * 数据库名称
     */
    private String showDatabase;

    private String type;

    private String ip;

    private String host;

    public String getIp() {
        return ip;
    }

    public void setIp(String ip) {
        this.ip = ip;
    }

    public String getHost() {
        return host;
    }

    public void setHost(String host) {
        this.host = host;
    }
    /**
     * 数据表结构列表内容
     */
    @TableField(value = "content", typeHandler = FastjsonTypeHandler.class)
    private String content;

    public String getContent() {
        return content;
    }

    public void setContent(String content) {
        this.content = content;
    }

    public String getShowDatabase() {
        return showDatabase;
    }

    public void setShowDatabase(String showDatabase) {
        this.showDatabase = showDatabase;
    }
    private String shareStr;

    private String beginTime;

    private String endTime;

    private int delFlag;

    private String sortStr;

    public String getSortStr() {
        return sortStr;
    }

    public void setSortStr(String sortStr) {
        this.sortStr = sortStr;
    }

    public String getShareStr() {
        return shareStr;
    }

    public void setShareStr(String shareStr) {
        this.shareStr = shareStr;
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getDataIndexName() {
        return dataIndexName;
    }

    public void setDataIndexName(String dataIndexName) {
        this.dataIndexName = dataIndexName;
    }

    public String getGroupName() {
        return groupName;
    }

    public void setGroupName(String groupName) {
        this.groupName = groupName;
    }

    public String getDataSourceId() {
        return dataSourceId;
    }

    public void setDataSourceId(String dataSourceId) {
        this.dataSourceId = dataSourceId;
    }

    public String getDataSourceName() {
        return dataSourceName;
    }

    public void setDataSourceName(String dataSourceName) {
        this.dataSourceName = dataSourceName;
    }

    public String getIndexRule() {
        return indexRule;
    }

    public void setIndexRule(String indexRule) {
        this.indexRule = indexRule;
    }

    public int getSortNum() {
        return sortNum;
    }

    public void setSortNum(int sortNum) {
        this.sortNum = sortNum;
    }

    public int getIsShare() {
        return isShare;
    }

    public void setIsShare(int isShare) {
        this.isShare = isShare;
    }


    public String getCreateByLabel() {
        return createByLabel;
    }

    public void setCreateByLabel(String createByLabel) {
        this.createByLabel = createByLabel;
    }

    public int getDelFlag() {
        return delFlag;
    }

    public void setDelFlag(int delFlag) {
        this.delFlag = delFlag;
    }

    public String getTimeField() {
        return timeField;
    }

    public void setTimeField(String timeField) {
        this.timeField = timeField;
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }

    public class EsEntity {

        private String status;

        private String isOpen;

        private String name;

        private String id;

        private String mainShardNum;

        private String viceShardNum;

        private String docNum;

        private String deletedDocNum;

        private String allShardSize;

        private String mainShardSize;

        public String getStatus() {
            return status;
        }

        public void setStatus(String status) {
            this.status = status;
        }

        public String getIsOpen() {
            return isOpen;
        }

        public void setIsOpen(String isOpen) {
            this.isOpen = isOpen;
        }

        public String getName() {
            return name;
        }

        public void setName(String name) {
            this.name = name;
        }

        public String getId() {
            return id;
        }

        public void setId(String id) {
            this.id = id;
        }

        public String getMainShardNum() {
            return mainShardNum;
        }

        public void setMainShardNum(String mainShardNum) {
            this.mainShardNum = mainShardNum;
        }

        public String getViceShardNum() {
            return viceShardNum;
        }

        public void setViceShardNum(String viceShardNum) {
            this.viceShardNum = viceShardNum;
        }

        public String getDocNum() {
            return docNum;
        }

        public void setDocNum(String docNum) {
            this.docNum = docNum;
        }

        public String getDeletedDocNum() {
            return deletedDocNum;
        }

        public void setDeletedDocNum(String deletedDocNum) {
            this.deletedDocNum = deletedDocNum;
        }

        public String getAllShardSize() {
            return allShardSize;
        }

        public void setAllShardSize(String allShardSize) {
            this.allShardSize = allShardSize;
        }

        public String getMainShardSize() {
            return mainShardSize;
        }

        public void setMainShardSize(String mainShardSize) {
            this.mainShardSize = mainShardSize;
        }
    }

}
