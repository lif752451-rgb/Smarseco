package com.crc.secface.entity;

import org.apache.commons.lang3.builder.ToStringBuilder;
import org.apache.commons.lang3.builder.ToStringStyle;

import java.util.Date;

/**
 * 【请填写功能名称】对象 tb_risk_static
 *
 * @author wst
 * @date 2020-09-03
 */
public class TbRiskStatic {
    private static final long serialVersionUID = 1L;

    /**
     * $column.columnComment
     */
    private String id;

    /**
     * 产品类型
     */
    private Long product;

    /**
     * 统计字段
     */
    private String staticCol;

    /**
     * 统计名称
     */
    private String staticName;

    /**
     * 数据来源,es:查询es,db:查询数据库，middle:中间计算函数
     */
    private String source;
    /**
     * 创建者
     */
    private String createBy;

    /**
     * 创建时间
     */
    private Date createTime;

    /**
     * 更新者
     */
    private String updateBy;

    /**
     * 更新时间
     */
    private Date updateTime;
    /**
     * 查询语句
     */
    private String query;

    /**
     * 删除标志（0代表存在 2代表删除）
     */
    private Long delFlag;

    private String value;

    private String esIndex;

    // 产品源
    private String productName;

    //客户端标志
    private String esClientIndex;

    //修改参数
    private String changeParams;

    private String aggDimision;

    private String areaStatType;

    private String assetField;

    private String hostField;

    private String assetQuery;

    private String hostQuery;

    public String getCreateBy() {
        return createBy;
    }

    public void setCreateBy(String createBy) {
        this.createBy = createBy;
    }

    public Date getCreateTime() {
        return createTime;
    }

    public void setCreateTime(Date createTime) {
        this.createTime = createTime;
    }

    public String getUpdateBy() {
        return updateBy;
    }

    public void setUpdateBy(String updateBy) {
        this.updateBy = updateBy;
    }

    public Date getUpdateTime() {
        return updateTime;
    }

    public void setUpdateTime(Date updateTime) {
        this.updateTime = updateTime;
    }

    public void setEsClientIndex(String esClientIndex) {
        this.esClientIndex = esClientIndex;
    }

    public void setChangeParams(String changeParams) {
        this.changeParams = changeParams;
    }

    public String getEsClientIndex() {
        return esClientIndex;
    }

    public String getChangeParams() {
        return changeParams;
    }

    public String getProductName() {
        return productName;
    }

    public void setProductName(String productName) {
        this.productName = productName;
    }

    public String getValue() {
        return value;
    }

    public void setValue(String value) {
        this.value = value;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getId() {
        return id;
    }

    public void setProduct(Long product) {
        this.product = product;
    }

    public Long getProduct() {
        return product;
    }

    public void setStaticCol(String staticCol) {
        this.staticCol = staticCol;
    }

    public String getStaticCol() {
        return staticCol;
    }

    public void setStaticName(String staticName) {
        this.staticName = staticName;
    }

    public String getStaticName() {
        return staticName;
    }

    public void setSource(String source) {
        this.source = source;
    }

    public String getSource() {
        return source;
    }

    public void setQuery(String query) {
        this.query = query;
    }

    public String getQuery() {
        if (query != null)
            return query.toLowerCase();
        return query;
    }

    public String getQuery2() {
        return query;
    }

    public void setDelFlag(Long delFlag) {
        this.delFlag = delFlag;
    }

    public Long getDelFlag() {
        return delFlag;
    }

    public String getEsIndex() {
        return esIndex;
    }

    public void setEsIndex(String esIndex) {
        this.esIndex = esIndex;
    }

    public String getAggDimision() {
        return aggDimision;
    }

    public void setAggDimision(String aggDimision) {
        this.aggDimision = aggDimision;
    }

    public String getAreaStatType() {
        return areaStatType;
    }

    public void setAreaStatType(String areaStatType) {
        this.areaStatType = areaStatType;
    }

    public String getAssetField() {
        return assetField;
    }

    public void setAssetField(String assetField) {
        this.assetField = assetField;
    }

    public String getHostField() {
        return hostField;
    }

    public void setHostField(String hostField) {
        this.hostField = hostField;
    }

    public String getAssetQuery() {
        return assetQuery;
    }

    public void setAssetQuery(String assetQuery) {
        this.assetQuery = assetQuery;
    }

    public String getHostQuery() {
        return hostQuery;
    }

    public void setHostQuery(String hostQuery) {
        this.hostQuery = hostQuery;
    }


    @Override
    public String toString() {
        return new ToStringBuilder(this, ToStringStyle.MULTI_LINE_STYLE)
                .append("id", getId())
                .append("product", getProduct())
                .append("staticCol", getStaticCol())
                .append("staticName", getStaticName())
                .append("source", getSource())
                .append("query", getQuery())
                .append("delFlag", getDelFlag())
                .append("createBy", getCreateBy())
                .append("createTime", getCreateTime())
                .append("updateBy", getUpdateBy())
                .append("updateTime", getUpdateTime())
                .toString();
    }
}
