package com.crc.secface.entity;

import lombok.Data;

import java.io.Serializable;
import java.util.Date;

/**
 * @description 威胁管理-告警主表(发起表)
 * @author zhengkai.blog.csdn.net
 * @date 2023-07-24
 */
@Data
public class TbAlarmReport implements Serializable {

    private static final long serialVersionUID = 1L;

    private Long id;

    /**
     * 告警id
     */
    //@Column(name="alarm_id")
    private String alarmId;

    /**
     * 标题
     */
    //@Column(name="title")
    private String title;

    /**
     * 攻击ip
     */
    //@Column(name="attack_ip")
    private String attackIp;

    /**
     * 攻击ip归属信息
     */
    //@Column(name="attack_ascription")
    private String attackAscription;

    /**
     * 受害ip/url
     */
    //@Column(name="victimized_ip")
    private String victimizedIp;

    /**
     * 受害ip/url归属信息
     */
    //@Column(name="victimized_ascription")
    private String victimizedAscription;

    /**
     * 告警级别
     */
    //@Column(name="level")
    private String level;

    /**
     * 告警级别名称
     */
    //@Column(name="level_label")
    private String levelLabel;

    /**
     * 攻击结果
     */
    //@Column(name="attack_result")
    private String attackResult;

    /**
     * 攻击结果名称
     */
    //@Column(name="attack_result_label")
    private String attackResultLabel;

    /**
     * 攻击手段
     */
    //@Column(name="attack_means")
    private String attackMeans;

    /**
     * 攻击手段名称
     */
    //@Column(name="attack_means_label")
    private String attackMeansLabel;

    /**
     * 行为性质(0 正常 1非正常)
     */
    //@Column(name="behavior_nature")
    private int behaviorNature;

    /**
     * 告警单位
     */
    //@Column(name="dept")
    private String dept;

    /**
     * 告警单位名称
     */
    //@Column(name="dept_label")
    private String deptLabel;

    /**
     * 告警设备
     */
    //@Column(name="device")
    private String device;

    /**
     * 告警设备名称
     */
    //@Column(name="device_label")
    private String deviceLabel;

    /**
     * 告警来源
     */
    //@Column(name="alarm_source")
    private String alarmSource;

    /**
     * 攻击次数
     */
    //@Column(name="attack_count")
    private Long attackCount;

    /**
     * 提交人
     */
    //@Column(name="commit_user_name")
    private String commitUserName;

    /**
     * 提交人姓名
     */
    //@Column(name="commit_nick_name")
    private String commitNickName;

    /**
     * 创建时间
     */
    //@Column(name="create_time")
    private Date createTime;

    /**
     * detail
     */
    //@Column(name="detail")
    private String detail;

    /**
     * 告警时间
     */
    //@Column(name="alarm_time")
    private Date alarmTime;

    /**
     * 流程处理完成时间
     */
    //@Column(name="complete_time")
    private Date completeTime;

    /**
     * 备注
     */
    //@Column(name="remark")
    private String remark;

    /**
     * 附件
     */
    //@Column(name="file_json")
    private String fileJson;

    /**
     * 工单状态
     */
    //@Column(name="order_status")
    private String orderStatus;

    /**
     * current_deal_user
     */
    //@Column(name="current_deal_user")
    private String currentDealUser;

    /**
     * current_deal_user_nick_name
     */
    //@Column(name="current_deal_user_nick_name")
    private String currentDealUserNickName;

    /**
     * 删除标记(0正常 1删除)
     */
    //@Column(name="del_flag")
    private int delFlag;

    /**
     * 业务key
     */
    //@Column(name="business_key")
    private String businessKey;

    /**
     * 修改时间
     */
    //@Column(name="update_time")
    private Date updateTime;

    /**
     * 修改人
     */
    //@Column(name="update_user")
    private String updateUser;

    /**
     * 节点名称
     */
    //@Column(name="node_name")
    private String nodeName;

    /**
     * 责任部门id
     */
    //@Column(name="duty_dept_id")
    private Long dutyDeptId;

    /**
     * 责任部门名称
     */
    //@Column(name="duty_dept_name")
    private String dutyDeptName;

    /**
     * 已失陷ip
     */
    //@Column(name="fallen_ip")
    private String fallenIp;

    /**
     * 上报类型（0 手动 1 系统自动）
     */
    //@Column(name="report_type")
    private Integer reportType;

    /**
     * 处理时间
     */
    //@Column(name="handling_time")
    private Date handlingTime;

    /**
     * 所属组织
     */
    //@Column(name="organization")
    private String organization;

    /**
     * 所属组织id
     */
    //@Column(name="organization_id")
    private Long organizationId;

    /**
     * 重点关注标记（0 未重点关注，1 已重点关注）
     */
    //@Column(name="focus_tag")
    private Integer focusTag;

    /**
     * ai研判值
     */
    //@Column(name="ai_check")
    private Double aiCheck;

    /**
     * 历史告警来源_上报单位
     */
    //@Column(name="his_dept_label")
    private String hisDeptLabel;

    /**
     * 历史责任部门
     */
    //@Column(name="his_duty_dept_name")
    private String hisDutyDeptName;

    /**
     * 历史责任部门id
     */
    //@Column(name="his_duty_dept_id")
    private String hisDutyDeptId;

    /**
     * 历史告警来源
     */
    //@Column(name="his_alarm_source")
    private String hisAlarmSource;

    /**
     * 漏洞关键字
     */
    //@Column(name="vul_keyword")
    private String vulKeyword;

    /**
     * 告警模型id
     */
    //@Column(name="event_model_id")
    private String eventModelId;

    /**
     * 0 否 1是 是否转风险
     */
    //@Column(name="is_turn_risk")
    private int isTurnRisk;

    /**
     * 知识库告警处置建议知识id
     */
    //@Column(name="knowledge_alarm_handle_id")
    private String knowledgeAlarmHandleId;

    /**
     * 攻击手段备份字段
     */
    //@Column(name="attack_means_bak")
    private String attackMeansBak;

    /**
     * 攻击手段备份字段
     */
    //@Column(name="attack_means_label_bak")
    private String attackMeansLabelBak;


}
