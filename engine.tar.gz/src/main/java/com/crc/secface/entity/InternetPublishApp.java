package com.crc.secface.entity;

import com.baomidou.mybatisplus.annotation.TableField;
import com.baomidou.mybatisplus.annotation.TableId;
import com.baomidou.mybatisplus.annotation.TableName;
import com.fasterxml.jackson.annotation.JsonFormat;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.experimental.Accessors;

import java.io.Serializable;
import java.util.Date;

/**
 * @author jixiangqi
 * @date 2023/6/26
 * scp互联网发布
 */
@Data
@Accessors(chain = true)
@EqualsAndHashCode()
@TableName("tb_internet_publish_app")
public class InternetPublishApp implements Serializable {

    private static final long serialVersionUID = 1L;

    /**
     * 主键Id
     */
    @TableId(value = "id")
    private String id;

    /**
     * 主键Id
     */
    @TableField(value = "internet_id")
    private Long internetId;

    /**
     * 所属组织名称
     */
    @TableField(value = "affiliation_dept_name")
    private String affiliationDeptName;

    /**
     * 所属组织id
     */
    @TableField(value = "affiliation_dept_node_id")
    private Long affiliationDeptNodeId;

    /**
     * 资产ID
     */
    @TableField(value = "asset_id")
    private String assetId;

    /**
     * IP
     */
    @TableField(value = "ip")
    private String ip;


    /**
     * 端口
     */
    @TableField(value = "port")
    private String port;

    /**
     * 域名
     */
    @TableField(value = "domain_name")
    private String domainName;

    /**
     * 关联IP
     */
    @TableField(value = "relation_ip")
    private String relationIp;

    /**
     * 告警id
     */
    @TableField(value = "alarm_id")
    private String alarmId;

    /**
     * 告警id
     */
    @TableField(value = "alarm_code")
    private String alarmCode;

    /**
     * 告警级别
     */
    @TableField(value = "alarm_level")
    private String alarmLevel;


    /**
     * 告警标题
     */
    @TableField(value = "alarm_title")
    private String alarmTitle;


    /**
     * 告警结果
     */
    @TableField(value = "attack_result")
    private String attackResult;



    /**
     * 告警手段
     */
    @TableField(value = "attack_means")
    private String attackMeans;


    /**
     * 攻击次数
     */
    @TableField(value = "attack_count")
    private Long attackCount;


    /**
     * 告警时间
     */
    @TableField(value = "alarm_time")
    @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss", timezone = "GMT+8")
    private Date alarmTime;

    /**
     * 告警提交时间
     */
    @TableField(value = "alarm_create_time")
    @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss", timezone = "GMT+8")
    private Date alarmCreateTime;

    /**
     * 工单状态
     */
    @TableField(value = "order_status")
    private String orderStatus;


    /**
     * 告警来源
     *  1 常态化
     *  2 实战
     */
    @TableField(value = "type")
    private int type;

    /**
     * 组织id
     */
    @TableField(value = "organization_id")
    private String organizationId;

    /**
     * r不为空说明当前IP有资产
     * 为空说明没有资产
     */
    @TableField(value = "relation_asset_id")
    private Long  relationAssetId;

    /**
     * 作战周期
     */
    @TableField(value = "fight_period_type")
    private String  fightPeriodType;

    /**
     * 最后更新时间
     */
    @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss", timezone = "GMT+8")
    @TableField(value = "update_time")
    private Date updateTime;


    /**
     * 创建时间
     */
    @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss", timezone = "GMT+8")
    @TableField(value = "create_time")
    private Date createTime;

    private String updateBy;

    private String createBy;

    private String createByLabel;
}
