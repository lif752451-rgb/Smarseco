package com.crc.secface.entity;

import com.crc.common.constants.TaskTypeEnum;

/**
 * @author simba@onlying.cn
 * @date 2020/10/22 16:06
 */
public class TaskEvent {


    //detail 任务详情,error 任务异常
    private TaskTypeEnum taskType;

    public TaskEvent(TaskTypeEnum taskType){
        this.taskType = taskType;
    }

    public TaskTypeEnum getTaskType() {
        return taskType;
    }


}
