package com.crc.secface.entity;


import lombok.Data;
import org.apache.commons.lang3.builder.ToStringBuilder;
import org.apache.commons.lang3.builder.ToStringStyle;

import java.util.Date;

/**
 * 实时事件处置对象 tb_event
 *
 * @author lgl
 * @date 2020-07-23
 */
@Data
public class TbEvent {
    private String isDmz;
    private String eventName;
    private String isWhitelist = "0";
    private String tab;
    private String tabDesc;

    /**
     * 齐安信ID
     */
    private String qaxtId;

    /**
     * tota系统ID
     */
    private String totaId;

    /**
     * 主键
     */
    private String id;

    /**
     * 事件编号
     */
    private String eventNo;

    /**
     * 事件级别
     */
    private String eventLevel;

    private String eventLevelLabel;

    /**
     * 事件来源
     */
    private String eventSource;

    private String eventSourceLabel;

    /**
     * 攻击类型
     */
    private String attackType;

    private String attackTypeLabel;

    /**
     * 攻击结果
     */
    private String attackResult;

    private String attackResultLabel;

    /**
     * 攻击次数
     */
    private Long attackCount;

    /**
     * 攻击IP
     */
    private String attackIp;

    /**
     * 受害IP/URL
     */
    private String attackUrl;

    /**
     * 事件提交人
     */
    private String commiterId;

    /**
     * 待处置人
     */
    private String disposerId;

    /**
     * 审核人
     */
    private String auditorId;

    /**
     * 提交时间
     */
    private Date commitTime;

    /**
     * 处置时间
     */
    private Date disposeTime;

    /**
     * 审核时间
     */
    private Date auditTime;

    /**
     * 事件状态
     */
    private String status;

    /**
     * 处置反馈
     */
    private String disposeContent;

    /**
     * 审核意见
     */
    private String auditContent;

    /**
     * $column.columnComment
     */
    private String remarks;

    /**
     * 创建类型
     */
    private String createType;

    /**
     * 关联事件ID
     */
    private String eventId;

    /**
     * 事件发生时间
     */
    private Date eventStartTime;

    /**
     * 事件结束时间
     */
    private Date eventEndTime;

    /**
     * 附件
     */
    private String attach;

    /**
     * 删除标志（0代表存在 2代表删除）
     */
    private Integer delFlag;

    /**
     * 关联事件
     */
    private String oriEventId;

    /**
     * 告警时间
     */
    private Date alarmTime;

    private String alarmTimeStr;

    /**
     * 指派部门
     */
    private String designatedDepartment;

    private String designatedDepartmentLabel;

    /**
     * 当前审核部门
     */
    private String nodeDepartment;

    /**
     * 是不是属于DMZ区（0：不是，1：是）
     */

    private String goStatus;//同步标记

    private String assetArea;
    private String subArea;
    private String riskIp;
    private String busModel;


    private String regArea;
    private String regBu;
    private String regCompany;
    private String regSubArea;
    private String sn;
    private String snBu;
    private String snArea;

    private String srcIpType;


    /**
     * 创建者
     */
    private String createBy;

    /**
     * 创建时间
     */
    private Date createTime;

    /**
     * 更新者
     */
    private String updateBy;


    /**
     * 更新时间
     */
    private Date updateTime;


    String whitelistId;

    private Double priority;

    private String solution;
    String solutions;
}
