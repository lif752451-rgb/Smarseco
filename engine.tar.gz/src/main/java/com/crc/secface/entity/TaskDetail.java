package com.crc.secface.entity;

import com.crc.common.constants.TaskTypeEnum;
import org.apache.commons.lang3.builder.ToStringBuilder;
import org.apache.commons.lang3.builder.ToStringStyle;

import java.util.Date;

/**
 * 【请填写功能名称】对象 tb_task_detail
 *
 * @author wst
 * @date 2020-10-21
 */
public class TaskDetail  extends TaskEvent
{
    public TaskDetail(){
        super(TaskTypeEnum.DETAIL);
    }
    private static final long serialVersionUID = 1L;

    private long id;

    /** 批次Id */
    private long batchId;

    /** 任务Id */
    private long taskId;

    /** 读取计数 */
    private long readNum;

    /** 写入计数 */
    private long writeNum;

    /** 读取错误计数 */
    private long readErrorNum;

    /** 写入错误计数 */
    private long writeErrorNum;

    /** 处理计数 */
    private long dealNum;

    private String stageName;

    private Date timestamp;

    public void setId(Long id)
    {
        this.id = id;
    }

    public long getId()
    {
        return id;
    }
    public void setBatchId(long batchId)
    {
        this.batchId = batchId;
    }

    public long getBatchId()
    {
        return batchId;
    }
    public void setTaskId(long taskId)
    {
        this.taskId = taskId;
    }

    public long getTaskId()
    {
        return taskId;
    }
    public void setReadNum(long readNum)
    {
        this.readNum = readNum;
    }

    public long getReadNum()
    {
        return readNum;
    }
    public void setWriteNum(long writeNum)
    {
        this.writeNum = writeNum;
    }

    public long getWriteNum()
    {
        return writeNum;
    }
    public void setReadErrorNum(long readErrorNum)
    {
        this.readErrorNum = readErrorNum;
    }

    public long getReadErrorNum()
    {
        return readErrorNum;
    }
    public void setWriteErrorNum(long writeErrorNum)
    {
        this.writeErrorNum = writeErrorNum;
    }

    public long getWriteErrorNum()
    {
        return writeErrorNum;
    }
    public void setDealNum(long dealNum)
    {
        this.dealNum = dealNum;
    }

    public long getDealNum()
    {
        return dealNum;
    }
    public void setStageName(String stageName)
    {
        this.stageName = stageName;
    }

    public String getStageName()
    {
        return stageName;
    }
    public void setTimestamp(Date timestamp)
    {
        this.timestamp = timestamp;
    }

    public Date getTimestamp()
    {
        return timestamp;
    }

    @Override
    public String toString() {
        return new ToStringBuilder(this, ToStringStyle.MULTI_LINE_STYLE)
            .append("id", getId())
            .append("batchId", getBatchId())
            .append("taskId", getTaskId())
            .append("readNum", getReadNum())
            .append("writeNum", getWriteNum())
            .append("readErrorNum", getReadErrorNum())
            .append("writeErrorNum", getWriteErrorNum())
            .append("dealNum", getDealNum())
            .append("stageName", getStageName())
            .append("timestamp", getTimestamp())
            .toString();
    }
}
