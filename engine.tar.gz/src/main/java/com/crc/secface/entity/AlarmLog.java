package com.crc.secface.entity;

import lombok.Data;

@Data
public class AlarmLog {
    String type;
    String modelId;
    String createTime;
    String ip;

    String ids;
    String indexName;
    String alarmId;
    String jsonStr;

    String dataSource;
}
