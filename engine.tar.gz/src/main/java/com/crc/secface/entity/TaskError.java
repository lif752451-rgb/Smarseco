package com.crc.secface.entity;


import com.crc.common.constants.TaskTypeEnum;

import java.util.Date;

/**
 * @author simba@onlying.cn
 * @date 2020/1:50
 */
public class TaskError extends TaskEvent {

    public TaskError(){
        super(TaskTypeEnum.ERROR);
    }

    private Long id;

    private Long taskId;

    private Long stageId;

    private String errorType;

    private String errorMsg;

    private Date errorTime;


    public void setId(Long id) {
        this.id = id;
    }

    public void setTaskId(Long taskId) {
        this.taskId = taskId;
    }

    public void setStageId(Long stageId) {
        this.stageId = stageId;
    }

    public void setErrorType(String errorType) {
        this.errorType = errorType;
    }

    public void setErrorMsg(String errorMsg) {
        this.errorMsg = errorMsg;
    }

    public void setErrorTime(Date errorTime) {
        this.errorTime = errorTime;
    }


    public Long getId() {
        return id;
    }

    public Long getTaskId() {
        return taskId;
    }

    public Long getStageId() {
        return stageId;
    }

    public String getErrorType() {
        return errorType;
    }

    public String getErrorMsg() {
        return errorMsg;
    }

    public Date getErrorTime() {
        return errorTime;
    }

}
