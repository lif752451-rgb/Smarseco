package com.crc.secface.entity;

import lombok.Data;

@Data
public class IpPluggingScene {
    /**
     * 时间查询范围-时间
     */
    private int queryTimeRange;

    /**
     * 时间查询范围-单位
     * 1:小时、2:天、3:月
     */
    private int getQueryTimeRangeUnit;

    private String queryTimeRangeUnitLabel;

    /**
     * 索引id
     */
    private String esIndexId;

    /**
     * 索引名称
     */
    private String esIndexName;

    /**
     * 排序字段
     */
    private String sortKey;

    /**
     * 排序字段id
     */
    private String sortKeyId;

    /**
     * 封堵对象-内容框
     */
    private String operationObj;

    /**
     * 是否为恶意IP
     * 1 是 2 否
     */
    private int isMalicious;

    /**
     * kql语句
     */
    private String kql;

    /**
     * 封堵ip
     */
    private String ip;

    /**
     * 索引
     */
    private String indexRule;

    /**
     * 数据源id
     */
    private String sourceId;

    private int operationType;

    private String operationTypeLabel;

    private String isMaliciousLabel;

    int getQueryTimeFreqUnit;//查询频率时间
    int queryTimeFreq;
    int langType;
}
