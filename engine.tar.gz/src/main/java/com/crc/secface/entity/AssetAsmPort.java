package com.crc.secface.entity;

import com.baomidou.mybatisplus.annotation.TableField;
import com.baomidou.mybatisplus.annotation.TableName;
import com.fasterxml.jackson.annotation.JsonFormat;
import lombok.Data;
import lombok.experimental.Accessors;

import java.util.Date;

/**
 * @author jixiangqi
 * @date 2023/2/13
 * 端口映射
 */
@Data
@Accessors(chain = true)
@TableName("tb_asset_asm_port")
public class AssetAsmPort {

    @TableField("id")
    private String id;

    /**
     * 源IP
     */
    @TableField("src_ip")
    private String srcIp;

    /**
     * 源端口
     */
    @TableField("src_port")
    private String srcPort;

    /**
     * 目的IP
     */
    @TableField("dest_ip")
    private String destIp;

    /**
     * 目的端口
     */
    @TableField("dest_port")
    private String destPort;

    /**
     * 创建人姓名
     */
    @TableField("create_by_label")
    private String createByLabel;

    /**
     * 状态
     */
    @TableField("status")
    private int status;

    /**
     * 创建者
     */
    @TableField("create_by")
    private String createBy;

    /**
     * 创建时间
     */
    @TableField("create_time")
    @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss", timezone = "GMT+8")
    private Date createTime;

    /**
     * 更新者
     */
    @TableField("update_by")
    private String updateBy;

    /**
     * 更新时间
     */
    @TableField("update_time")
    @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss", timezone = "GMT+8")
    private Date updateTime;

    /**
     * 备注
     */
    @TableField("remark")
    private String remark;
}
