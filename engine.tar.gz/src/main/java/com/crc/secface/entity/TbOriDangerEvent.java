package com.crc.secface.entity;

import java.util.Date;

/**
 * 高危事件对象 tb_ori_danger_event
 *
 * @author wst
 * @date 2020-07-16
 */
public class TbOriDangerEvent {
    private static final long serialVersionUID = 1L;
    private String dataScope;

    /**
     * 搜索值
     */
    private String searchValue;

    /**
     * 创建者
     */
    private String createBy;

    /**
     * 创建时间
     */
    private Date createTime;

    /**
     * 更新者
     */
    private String updateBy;

    /**
     * 更新时间
     */
    private Date updateTime;

    /**
     * 备注
     */
    private String remark;


    /**
     * 开始时间
     */
    private String beginTime;

    /**
     * 结束时间
     */
    private String endTime;
    /**
     * $column.columnComment
     */
    private String id;

    /**
     * 原始日志
     */
    private String data;

    /**
     * 事件状态
     */
    private String status;

    /**
     * 日志来源
     */
    private String product;

    /**
     * 事件级别
     */
    private String alertLevel;

    /**
     * IP风险值
     */
    private Long ipScore;

    /**
     * 事件风险值
     */
    private Long eventScore;

    /**
     * 事件发生时间
     */
    private Date eventTime;

    /**
     * 原始事件ID
     */
    private String eventId;

    /**
     * 事件名称
     */
    private String eventName;

    /**
     * 事件类型
     */
    private String eventType;

    /**
     * 事件描述
     */
    private String eventDesc;

    /**
     * 原始IP
     */
    private String srcIp;

    /**
     * 目标IP
     */
    private String destIp;

    /**
     * $column.columnComment
     */
    private Date createDate;

    /**
     * $column.columnComment
     */
    private Date updateDate;

    /**
     * 预判时间
     */
    private Date procTime;

    private Integer delFlag;

    private Date eventTimeStart;

    private Date eventTimeEnd;

    private String actionResult;

    private String isWhitelist;
    private String modelId;

    public String getModelId() {
        return modelId;
    }

    public void setModelId(String modelId) {
        this.modelId = modelId;
    }

    public String getActionResult() {
        return actionResult;
    }

    public void setActionResult(String actionResult) {
        this.actionResult = actionResult;
    }

    public String getDataScope() {
        return dataScope;
    }

    public void setDataScope(String dataScope) {
        this.dataScope = dataScope;
    }

    public String getSearchValue() {
        return searchValue;
    }

    public void setSearchValue(String searchValue) {
        this.searchValue = searchValue;
    }

    public String getCreateBy() {
        return createBy;
    }

    public void setCreateBy(String createBy) {
        this.createBy = createBy;
    }

    public Date getCreateTime() {
        return createTime;
    }

    public void setCreateTime(Date createTime) {
        this.createTime = createTime;
    }

    public String getUpdateBy() {
        return updateBy;
    }

    public void setUpdateBy(String updateBy) {
        this.updateBy = updateBy;
    }

    public Date getUpdateTime() {
        return updateTime;
    }

    public void setUpdateTime(Date updateTime) {
        this.updateTime = updateTime;
    }

    public String getRemark() {
        return remark;
    }

    public void setRemark(String remark) {
        this.remark = remark;
    }

    public String getBeginTime() {
        return beginTime;
    }

    public void setBeginTime(String beginTime) {
        this.beginTime = beginTime;
    }

    public String getEndTime() {
        return endTime;
    }

    public void setEndTime(String endTime) {
        this.endTime = endTime;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getId() {
        return id;
    }

    public void setData(String data) {
        this.data = data;
    }

    public String getData() {
        return data;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public String getStatus() {
        return status;
    }

    public void setProduct(String product) {
        this.product = product;
    }

    public String getProduct() {
        return product;
    }

    public void setAlertLevel(String alertLevel) {
        this.alertLevel = alertLevel;
    }

    public String getAlertLevel() {
        return alertLevel;
    }

    public void setIpScore(Long ipScore) {
        this.ipScore = ipScore;
    }

    public Long getIpScore() {
        return ipScore;
    }

    public void setEventScore(Long eventScore) {
        this.eventScore = eventScore;
    }

    private Long times;

    public Long getTimes() {
        return times;
    }

    public void setTimes(Long times) {
        this.times = times;
    }

    public Long getEventScore() {
        return eventScore;
    }

    public void setEventTime(Date eventTime) {
        this.eventTime = eventTime;
    }

    public Date getEventTime() {
        return eventTime;
    }

    public void setEventId(String eventId) {
        this.eventId = eventId;
    }

    public String getEventId() {
        return eventId;
    }

    public void setEventName(String eventName) {
        this.eventName = eventName;
    }

    public String getEventName() {
        return eventName;
    }

    public void setEventType(String eventType) {
        this.eventType = eventType;
    }

    public String getEventType() {
        return eventType;
    }

    public void setEventDesc(String eventDesc) {
        this.eventDesc = eventDesc;
    }

    public String getEventDesc() {
        return eventDesc;
    }

    public void setDestIp(String destIp) {
        this.destIp = destIp;
    }

    public String getDestIp() {
        return destIp;
    }

    public void setCreateDate(Date createDate) {
        this.createDate = createDate;
    }

    public Date getCreateDate() {
        return createDate;
    }

    public void setUpdateDate(Date updateDate) {
        this.updateDate = updateDate;
    }

    public Date getUpdateDate() {
        return updateDate;
    }

    public void setProcTime(Date procTime) {
        this.procTime = procTime;
    }

    public Date getProcTime() {
        return procTime;
    }

    public Integer getDelFlag() {
        return delFlag;
    }

    public void setDelFlag(Integer delFlag) {
        this.delFlag = delFlag;
    }

    public Date getEventTimeStart() {
        return eventTimeStart;
    }

    public Date getEventTimeEnd() {
        return eventTimeEnd;
    }

    public void setEventTimeStart(Date eventTimeStart) {
        this.eventTimeStart = eventTimeStart;
    }

    public void setEventTimeEnd(Date eventTimeEnd) {
        this.eventTimeEnd = eventTimeEnd;
    }

    public String getSrcIp() {
        return srcIp;
    }

    public void setSrcIp(String srcIp) {
        this.srcIp = srcIp;
    }

    public String getIsWhitelist() {
        return isWhitelist;
    }

    public void setIsWhitelist(String isWhitelist) {
        this.isWhitelist = isWhitelist;
    }
}
