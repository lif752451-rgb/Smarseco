package com.crc.secface.entity;

import lombok.Data;

@Data
public class CombatVo {
    /*
    是否为实战时间
     */
    boolean isCombat;
    /*
    命中作战周期
     */
    String type;
}
