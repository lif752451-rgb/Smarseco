package com.crc.secface.entity;

import com.baomidou.mybatisplus.annotation.TableField;
import lombok.Data;
import org.apache.commons.lang3.StringUtils;

/**
 * 告警白名单对象 tb_alarm_whitelist
 *
 * @author wst
 * @date 2021-11-22
 */

@Data
public class TbAlarmWhitelist {
    private static final long serialVersionUID = 1L;

    /**
     * 主键
     */
    private Long id;

    /**
     * 标题
     */
    private String title;

    /**
     * 源IP
     */
    private String srcIp;

    /**
     * 目的类型 0:目的IP 1：目的组织
     */
    private String destType;

    /**
     * 目的内容
     */
    private String destContent;

    /**
     * 目的url
     */
    private String destUrl;

    /**
     * 业务期限 0：有限期限 1：永久
     */
    private String businessTerm;

    /**
     * 生效开始日期，格式：yyyy-MM-dd
     */
    private String effectDateStart;

    /**
     * 生效结束日期，格式：yyyy-MM-dd
     */
    private String effectDateEnd;

    /**
     * 生效开始时间，格式：hh:mm:ss
     */
    private String effectTimeStart;

    /**
     * 生效结束时间，格式：hh:mm:ss
     */
    private String effectTimeEnd;

    /**
     * 业务模型
     */
    private String busModel;
    /**
     * 是否全局:1.是,0.不是
     */
    private String isGlobal;

    /**
     * $column.columnComment
     */
    private String remark;

    @TableField(exist = false)
    private String whitelistId;

    public String getWhitelistId() {
        if (StringUtils.isBlank(whitelistId)) {
            return String.valueOf(id);
        }
        return whitelistId;
    }

    public void setWhitelistId(String whitelistId) {
        this.whitelistId = whitelistId;
    }
}
