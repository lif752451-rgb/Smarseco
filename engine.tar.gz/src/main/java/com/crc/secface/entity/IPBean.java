package com.crc.secface.entity;


public class IPBean {
    long begin;
    long end;
    private  TbAssetSegement segementInfo;

    String name;

    public IPBean(long s, long e, TbAssetSegement segementInfo) {
        this.begin = s;
        this.end = e;
        this.segementInfo = segementInfo;
    }

    public IPBean(long s, long e) {
        this.begin = s;
        this.end = e;
    }


    public IPBean(String name, long s, long e) {
        this.begin = s;
        this.end = e;
        this.name = name;
    }

    public long getBegin() {
        return begin;
    }

    public void setBegin(long begin) {
        this.begin = begin;
    }

    public long getEnd() {
        return end;
    }

    public void setEnd(long end) {
        this.end = end;
    }

    public TbAssetSegement getSegementInfo() {
        return segementInfo;
    }

    public void setSegementInfo(TbAssetSegement segementInfo) {
        this.segementInfo = segementInfo;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }
}
