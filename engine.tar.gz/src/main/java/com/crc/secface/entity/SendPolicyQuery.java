package com.crc.secface.entity;

import java.util.Date;

/**
 * @author simba@onlying.cn
 * @date 2020/12/8 16:12
 */
public class SendPolicyQuery {

    private String policyName;

    private Long ruleIds;

    private String receiver;

    private Date queryDate;

    public String getPolicyName() {
        return policyName;
    }

    public void setPolicyName(String policyName) {
        this.policyName = policyName;
    }

    public Long getRuleIds() {
        return ruleIds;
    }

    public void setRuleIds(Long ruleIds) {
        this.ruleIds = ruleIds;
    }

    public String getReceiver() {
        return receiver;
    }

    public void setReceiver(String receiver) {
        this.receiver = receiver;
    }

    public Date getQueryDate() {
        return queryDate;
    }

    public void setQueryDate(Date queryDate) {
        this.queryDate = queryDate;
    }



}
