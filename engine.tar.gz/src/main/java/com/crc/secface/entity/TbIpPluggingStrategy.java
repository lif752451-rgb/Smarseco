package com.crc.secface.entity;

import java.io.Serializable;
import java.util.Date;

/**
 * @description 封堵策略表
 * @author hejingsheng1
 * @date 2023-08-03
 */
public class TbIpPluggingStrategy implements Serializable {

    private static final long serialVersionUID = 1L;

    /**
     * 主键
     */
    private String id;

    /**
     * 策略名称
     */
    private String strategyName;

    /**
     * 策略类型  1 封堵 2 解封
     */
    private int strategyType;

    /**
     * 策略场景 1 封堵关联场景、 2 封堵阈值变化、3 行为封堵场景 4 自动解封场景
     */
    private int strategyScene;

    /**
     * 策略状态 1 启用、2 禁用
     */
    private int strategyStatus;

    /**
     * 配置信息
     */
    private String configInfo;

    /**
     * 执行设备
     */
    private String execDevice;

    /**
     * 封堵周期
     */
    private Integer pluggingTime;

    /**
     * 封堵周期单位 1 小时、 2 天、3 月、4 年、5 永久
     */
    private int pluggingTimeUnit;

    /**
     * 解封开始时间
     */
    private String unsealStartTime;

    /**
     * 删除标记 0 未删除 1 删除
     */
    private int delFlag;

    /**
     * 创建人
     */
    private String createBy;

    /**
     * 创建人姓名
     */
    private String createByLabel;

    /**
     * 更新时间
     */
    private Date updateTime;

    /**
     * 创建时间
     */
    private Date createTime;

    /**
     * 更新人
     */
    private String updateBy;

    /**
     * 执行设备ip
     */
    private String deviceIp;

    /**
     * 策略名称
     */
    private String strategyGroup;

    /**
     * 解封结束时间
     */
    private String unsealEndTime;


    public TbIpPluggingStrategy() {
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getStrategyName() {
        return strategyName;
    }

    public void setStrategyName(String strategyName) {
        this.strategyName = strategyName;
    }

    public int getStrategyType() {
        return strategyType;
    }

    public void setStrategyType(int strategyType) {
        this.strategyType = strategyType;
    }

    public int getStrategyScene() {
        return strategyScene;
    }

    public void setStrategyScene(int strategyScene) {
        this.strategyScene = strategyScene;
    }

    public int getStrategyStatus() {
        return strategyStatus;
    }

    public void setStrategyStatus(int strategyStatus) {
        this.strategyStatus = strategyStatus;
    }

    public String getConfigInfo() {
        return configInfo;
    }

    public void setConfigInfo(String configInfo) {
        this.configInfo = configInfo;
    }

    public String getExecDevice() {
        return execDevice;
    }

    public void setExecDevice(String execDevice) {
        this.execDevice = execDevice;
    }

    public Integer getPluggingTime() {
        return pluggingTime;
    }

    public void setPluggingTime(Integer pluggingTime) {
        this.pluggingTime = pluggingTime;
    }

    public int getPluggingTimeUnit() {
        return pluggingTimeUnit;
    }

    public void setPluggingTimeUnit(int pluggingTimeUnit) {
        this.pluggingTimeUnit = pluggingTimeUnit;
    }

    public String getUnsealStartTime() {
        return unsealStartTime;
    }

    public void setUnsealStartTime(String unsealStartTime) {
        this.unsealStartTime = unsealStartTime;
    }

    public int getDelFlag() {
        return delFlag;
    }

    public void setDelFlag(int delFlag) {
        this.delFlag = delFlag;
    }

    public String getCreateBy() {
        return createBy;
    }

    public void setCreateBy(String createBy) {
        this.createBy = createBy;
    }

    public String getCreateByLabel() {
        return createByLabel;
    }

    public void setCreateByLabel(String createByLabel) {
        this.createByLabel = createByLabel;
    }

    public Date getUpdateTime() {
        return updateTime;
    }

    public void setUpdateTime(Date updateTime) {
        this.updateTime = updateTime;
    }

    public Date getCreateTime() {
        return createTime;
    }

    public void setCreateTime(Date createTime) {
        this.createTime = createTime;
    }

    public String getUpdateBy() {
        return updateBy;
    }

    public void setUpdateBy(String updateBy) {
        this.updateBy = updateBy;
    }

    public String getDeviceIp() {
        return deviceIp;
    }

    public void setDeviceIp(String deviceIp) {
        this.deviceIp = deviceIp;
    }

    public String getStrategyGroup() {
        return strategyGroup;
    }

    public void setStrategyGroup(String strategyGroup) {
        this.strategyGroup = strategyGroup;
    }

    public String getUnsealEndTime() {
        return unsealEndTime;
    }

    public void setUnsealEndTime(String unsealEndTime) {
        this.unsealEndTime = unsealEndTime;
    }

}
