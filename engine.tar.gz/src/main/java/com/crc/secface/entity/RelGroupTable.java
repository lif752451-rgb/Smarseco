package com.crc.secface.entity;


import com.crc.secface.config.EsDataSource;
import lombok.Data;

@Data
public class RelGroupTable {
    String groupName;//子集名称
    String tableName;//表名
    String selectCol;//查询字段列表
    String type;//1-ES,2-MYSQL
    EsDataSource esDataSource;
}
