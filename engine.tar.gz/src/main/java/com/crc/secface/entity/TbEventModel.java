package com.crc.secface.entity;

import com.alibaba.fastjson.JSONObject;
import com.baomidou.mybatisplus.annotation.TableField;
import com.crc.common.enums.DatabaseEnums;
import com.crc.common.utils.VersionUtils;
import com.crc.model.EsEventParams;
import lombok.Data;

import java.util.Date;
import java.util.List;
import java.util.Map;

/**
 * 告警模型对象 tb_event_model
 *
 * @author wst
 * @date 2022-03-15
 */
@Data
public class TbEventModel {
    private static final long serialVersionUID = 1L;
    List<SysDictData> keywordList;
    /**
     * 创建者
     */
    private String createBy;

    @TableField(exist = false)
    private String deviceNameStr;
    @TableField(exist = false)
    private String eventNameStr;
    /**
     * 创建时间
     */
    private Date createTime;

    /**
     * 更新者
     */
    private String updateBy;

    /**
     * 更新时间
     */
    private Date updateTime;
    /**
     * $column.columnComment
     */
    private String id;

    /**
     * 模型ID,识别模型的唯一性
     */
    private String modelId;

    /**
     * 模型分类：1.通用模型 2.自定义模型
     */
    private String modeClassify;

    /**
     * 模型类型：1.精确告警模型、2.关联告警模型、3.聚合告警模型
     */
    private String modelType;

    /**
     * 模型名称,用于对模型的匹配规则进行简要描述
     */
    private String modelName;

    /**
     * 设备名称 1：奇安信天眼 2：深信服SIP 3：D01 4：G01
     */
    private String deviceName;

    /**
     * 告警名称
     */
    private String eventName;

    /**
     * 攻击手段
     */
    private String attackType;

    private String attackTypeName;

    /**
     * 攻击结果 0：企图 1：疑似成功 2：疑似失陷 3：失败 4：已失陷 5：攻击成功
     */
    private String attackResult;

    /**
     * 运算模式：（1：规则树模式 2：自定义模式 3：条件模式）
     */
    private String operateType;

    /**
     * 状态,0.启用 1.停用
     */
    private String status;

    /**
     * 告警级别 1：一级 2：二级 3：三级 4：四级
     */
    private String eventLevel;

    private String eventLevelName;

    /**
     * 排序字段 1：SparkTime 2：log_start_time
     */
    private String sortKey;

    /**
     * ES索引 1：sec_all-* 2：user_all-* 3：net_all-*
     */
    private String esIndex;

    /**
     * 时间间隔
     */
    private String taskInterval;

    /**
     * 时间周期类型  1：分钟 2：小时 3：天
     */
    private String periodType;

    /**
     * 删除的标志，默认是0  0：未删除 2：已删除
     */
    private String delFlag;

    /**
     * 查询条件json串
     */
    private String jsonParam;

    /**
     * 漏洞关键字
     */
    private String vulKeyword;

    private String attackResultName;

    private String esIndexStr;
    private String esIndexName;

    private String attackStatus;

    /**
     * 聚合条件
     */
    private String aggParams;


    /**
     * 判断条件
     */
    private String judgeParams;

    /**
     * 告警名称类型
     * 0 表达式
     * 1 自定义
     */
    private int alarmType;

    /**
     * 攻击IP
     * 0 表达式
     * 1 自定义
     */
    private int attackIpType;


    /**
     * 攻击IP
     */
    private String attackIp;

    /**
     * 告警描述
     * 0 表达式
     * 1 自定义
     */
    private int alarmDescType;

    /**
     * 告警描述
     */
    private String alarmDesc;


    /**
     * 受害IP
     * 0 表达式
     * 1 自定义
     */
    private int sufferIpType;

    /**
     * 受害IP
     */
    private String sufferIp;


    /**
     * 查询时间范围
     */
    private String timeRange;

    /**
     * 时间范围单位
     */
    private String timeRangeUnit;

    @TableField(exist = false)
    private EsEventParams params;


    @TableField(exist = false)
    private List<Map<String, String>> alarmMsg;

    String relationParams;
    String sqlQueryChild;
    String relationChild;

    /**
     * 设备名称类型
     * 0 表达式
     * 1 自定义
     */
    @TableField("device_type")
    private int deviceType;

    private String esConfig;

    @TableField(exist = false)
    private String esIndexId;

    @TableField(exist = false)
    private int destIpSize;
    @TableField(exist = false)
    private String matchDestIp;
    @TableField(exist = false)
    private boolean chgFlag;
    @TableField(exist = false)
    private String whiteId;
    @TableField(exist = false)
    private String timeRemark;

    @TableField(exist = false)
    private String dataSourceId;

    @TableField(exist = false)
    private String dataSourceCode;

    @TableField(exist = false)
    private JSONObject content;

    @TableField(exist = false)
    private String dbType;

    public String getDbType() {
        if (VersionUtils.getDatabase() == DatabaseEnums.MYSQL.getCode()) {
            return "mysql";
        } else {
            return "other";
        }
    }

    public void setDbType(String dbType) {
        this.dbType = dbType;
    }

    public static TbEventModel createQuery(String id) {
        TbEventModel q = new TbEventModel();
        q.setId(id);
        return q;
    }
}

