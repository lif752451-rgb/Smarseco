package com.crc.secface.entity;


import com.alibaba.fastjson.JSONObject;
import com.crc.secface.config.EsDataSource;
import lombok.Data;

import java.util.List;

@Data
public class RelationData {
    private List<JSONObject> dataList;
    private EsDataSource esDataSource;
}
