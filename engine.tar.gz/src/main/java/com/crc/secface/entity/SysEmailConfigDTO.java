package com.crc.secface.entity;

import com.baomidou.mybatisplus.annotation.TableField;
import com.crc.common.enums.DatabaseEnums;
import com.crc.common.utils.CodeTool;
import com.crc.common.utils.VersionUtils;
import lombok.Data;

/**
 * @author jixiangqi
 * @date 2022/7/8
 */
@Data
public class SysEmailConfigDTO {

    private String id;

    private String sendEmail;

    private String sendHost;

    private int  port;

    private String password;

    private int emailStatus;

    private String createByLabel;

    private String receiverEmail;

    private String userName;
    @TableField(exist = false)
    private String dbType;

    public String getDbType() {
        if (VersionUtils.getDatabase() == DatabaseEnums.MYSQL.getCode()) {
            return "mysql";
        } else {
            return "other";
        }
    }

    public void setDbType(String dbType) {
        this.dbType = dbType;
    }
}
