package com.crc.secface.entity;

import java.util.Date;
import java.util.List;
import java.util.Map;

/**
 * 集团网段对象 tb_asset_segement
 *
 * @author wst
 * @date 2021-11-04
 */
public class TbAssetSegement {
    private long idStart;
    private long idEnd;

    public long getIdStart() {
        return idStart;
    }

    public void setIdStart(long idStart) {
        this.idStart = idStart;
    }

    public long getIdEnd() {
        return idEnd;
    }

    public void setIdEnd(long idEnd) {
        this.idEnd = idEnd;
    }

    /**
     * 创建者
     */
    private String createBy;

    /**
     * 创建时间
     */
    private Date createTime;

    /**
     * 更新者
     */
    private String updateBy;


    /**
     * 更新时间
     */
    private Date updateTime;
    private String remark;
    /**
     * 主键
     */
    private Long id;

    /**
     * 类型
     */
    private String type;

    /**
     * 环境
     */
    private String evn;

    /**
     * 网段
     */
    private String segment;

    /**
     * 网段名称
     */
    private String name;


    /**
     * 閼奉亜鐣炬稊澶婂礋娴?
     */
    private String customUnitName;

    /**
     * $column.columnComment
     */
    private Long areaId;

    /**
     * $column.columnComment
     */
    private String areaName;

    /**
     * $column.columnComment
     */
    private Long subAreaId;

    /**
     * $column.columnComment
     */
    private String subAreaName;

    public String getCreateBy() {
        return createBy;
    }

    public void setCreateBy(String createBy) {
        this.createBy = createBy;
    }

    public Date getCreateTime() {
        return createTime;
    }

    public void setCreateTime(Date createTime) {
        this.createTime = createTime;
    }

    public String getUpdateBy() {
        return updateBy;
    }

    public void setUpdateBy(String updateBy) {
        this.updateBy = updateBy;
    }

    public Date getUpdateTime() {
        return updateTime;
    }

    public void setUpdateTime(Date updateTime) {
        this.updateTime = updateTime;
    }

    public String getRemark() {
        return remark;
    }

    public void setRemark(String remark) {
        this.remark = remark;
    }


    private String affiliationDeptName;
    private Long affiliationDeptNodeId;

    private String areaCustomUuid;
    /**
     * 鏄惁鍙敤
     */
    private Long isEnable;

    private List<Map> ipList;

    public List<Map> getIpList() {
        return ipList;
    }

    public void setIpList(List<Map> ipList) {
        this.ipList = ipList;
    }


    public void setId(Long id) {
        this.id = id;
    }

    public Long getId() {
        return id;
    }

    public void setType(String type) {
        this.type = type;
    }

    public String getType() {
        return type;
    }

    public void setEvn(String evn) {
        this.evn = evn;
    }

    public String getEvn() {
        return evn;
    }

    public void setSegment(String segment) {
        this.segment = segment;
    }

    public String getSegment() {
        return segment;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getName() {
        return name;
    }

    public void setCustomUnitName(String customUnitName) {
        this.customUnitName = customUnitName;
    }

    public String getCustomUnitName() {
        return customUnitName;
    }

    public void setAreaId(Long areaId) {
        this.areaId = areaId;
    }

    public Long getAreaId() {
        return areaId;
    }

    public void setAreaName(String areaName) {
        this.areaName = areaName;
    }

    public String getAreaName() {
        return areaName;
    }

    public void setSubAreaId(Long subAreaId) {
        this.subAreaId = subAreaId;
    }

    public Long getSubAreaId() {
        return subAreaId;
    }

    public void setSubAreaName(String subAreaName) {
        this.subAreaName = subAreaName;
    }

    public String getSubAreaName() {
        return subAreaName;
    }

    public void setIsEnable(Long isEnable) {
        this.isEnable = isEnable;
    }

    public Long getIsEnable() {
        return isEnable;
    }

    public String getAffiliationDeptName() {
        return affiliationDeptName;
    }

    public void setAffiliationDeptName(String affiliationDeptName) {
        this.affiliationDeptName = affiliationDeptName;
    }

    public Long getAffiliationDeptNodeId() {
        return affiliationDeptNodeId;
    }

    public void setAffiliationDeptNodeId(Long affiliationDeptNodeId) {
        this.affiliationDeptNodeId = affiliationDeptNodeId;
    }

    public String getAreaCustomUuid() {
        return areaCustomUuid;
    }

    public void setAreaCustomUuid(String areaCustomUuid) {
        this.areaCustomUuid = areaCustomUuid;
    }
}
