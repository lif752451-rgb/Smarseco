package com.crc.secface.config;

import cn.hutool.core.collection.CollUtil;
import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONArray;
import com.alibaba.fastjson.JSONObject;
import com.crc.common.utils.DictUtil;
import com.crc.common.utils.HttpUtils;
import com.crc.common.utils.JsonUtils;
import com.crc.common.utils.StringUtils;
import com.crc.secface.entity.SysDictData;
import com.crc.secface.exception.CustomException;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Repository;

import java.net.InetAddress;
import java.net.UnknownHostException;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * @author jixiangqi
 * @date 2024/1/2
 * ip封堵
 */
@Repository
@Slf4j
public class MarvalnetConfig {

    public static JSONObject getConfig() {
        List<SysDictData> sysDictData = DictUtil.getDict("marvelnet_block_config");
        if (CollUtil.isEmpty(sysDictData)) {
            log.error("未配置IP封堵URL，字典【marvelnet_block_config】");
            throw new CustomException("未配置IP封堵URL，字典【marvelnet_block_config】", 601);
        }
        SysDictData dictData = sysDictData.get(0);
        String remark = dictData.getRemark();
        JSONObject parse = JsonUtils.parse(remark);
        String ip = getIp();
        String ipLocal = StringUtils.isNotEmpty(ip)?ip:"127.0.0.1";
        parse.put("ipLocal", "http://" + ipLocal);
        return parse;
    }

    /**
     * 获取对应的设备规则id
     * @param deviceIp 防火墙IP
     * @return
     */
    public static String getDeviceId(String deviceIp) {
        JSONObject config = getConfig();
        if (CollUtil.isEmpty(config)) {
            log.error("未配置IP封堵URL，字典【marvelnet_block_config】");
            throw new CustomException("未配置IP封堵URL，字典【marvelnet_block_config】", 601);
        }
        if (!config.containsKey("ruleUrl")) {
            log.error("未配置IP规则url，字典【marvelnet_block_config - config_info】");
            throw new CustomException("未配置IP规则URL，字典【marvelnet_block_config - config_info】", 601);
        }
        String ruleUrl = JsonUtils.getStr(config, "ruleUrl");
        String result = HttpUtils.sendGetMarvalnet(ruleUrl, JsonUtils.getStr(config, "ipLocal"), JsonUtils.getStr(config, "token"));
        JSONObject parse = JsonUtils.parse(result);
        if (CollUtil.isEmpty(parse) || JsonUtils.getInt(parse, "code") != 0) {
            log.error("获取规则列表失败:{}", JsonUtils.getStr(parse, "message"));
            throw new CustomException("获取规则列表失败", 602);
        }
        JSONObject data = JsonUtils.getJson(parse, "data");
        JSONArray rules = JsonUtils.getJsonArray(data, "rules");
        for (int i = 0; i < rules.size(); i++) {
            JSONObject jsonObject = rules.getJSONObject(i);
            String ruleIdTemp = JsonUtils.getStr(jsonObject, "rule_id");
            JSONArray devices = JsonUtils.getJsonArray(jsonObject, "devices");
            for (int j = 0; j < devices.size(); j++) {
                JSONObject devicesJSONObject = devices.getJSONObject(j);
                String deviceIpTemp = JsonUtils.getStr(devicesJSONObject, "device_ip");
                if (StringUtils.isNotEmpty(deviceIpTemp) && deviceIpTemp.trim().equals(deviceIp.trim())) {
                    return ruleIdTemp;
                }
            }
        }
        return "";
    }


    /**
     * IP封堵
     * @param ip 封堵的IP
     * @return
     */
    public static String blockIpV2(String ip, String deviceIp) {
        String deviceId = getDeviceId(deviceIp);
        if (StringUtils.isEmpty(deviceId)) {
            log.error("获取到的规则id为空");
            throw new CustomException("获取到的规则id为空", 603);
        }
        JSONObject config = getConfig();
        String blockUrl = JsonUtils.getStr(config, "blockUrl");
        if (StringUtils.isEmpty(blockUrl)) {
            log.error("未配置IP规则url，字典【marvelnet_block_config - config_info】");
            throw new CustomException("未配置IP规则URL，字典【marvelnet_block_config - config_info】", 601);
        }

        Map<String, List<String>> paramsMap = new HashMap<>();
        paramsMap.put("rules", Collections.singletonList(deviceId));
        paramsMap.put("addrs", Collections.singletonList(ip));
        String s = HttpUtils.sendPostMarvalnet(blockUrl, JSON.toJSONString(paramsMap), JsonUtils.getStr(config, "token"), JsonUtils.getStr(config, "ipLocal"));
        log.info("获取到的结果为:{}", s);
        JSONObject parse = JsonUtils.parse(s);
        if (CollUtil.isEmpty(parse) || JsonUtils.getInt(parse, "code") != 0) {
            log.error("封堵失败:{}", JsonUtils.getStr(parse, "message"));
            throw new CustomException("封堵失败", 602);
        } else {
            return "";
        }
    }

    /**
     * 解封IP
     * @param ip 解封的IP
     * @return
     */
    public static String unBlockIpV2(String ip, String deviceIp) {
        String deviceId = getDeviceId(deviceIp);
        if (StringUtils.isEmpty(deviceId)) {
            log.error("获取到的规则id为空");
            throw new CustomException("获取到的规则id为空", 603);
        }
        JSONObject config = getConfig();
        String unBlockUrl = JsonUtils.getStr(config, "unBlockUrl");
        if (StringUtils.isEmpty(unBlockUrl)) {
            log.error("未配置IP封堵url，字典【marvelnet_block_config - unBlockUrl】");
            throw new CustomException("未配置IP封堵URL，字典【marvelnet_block_config】", 601);
        }
        Map<String, List<String>> paramsMap = new HashMap<>();
        paramsMap.put("rules", Collections.singletonList(deviceId));
        paramsMap.put("addrs", Collections.singletonList(ip));
        String s = HttpUtils.sendPostMarvalnet(unBlockUrl, JSON.toJSONString(paramsMap), JsonUtils.getStr(config, "token"), JsonUtils.getStr(config, "ipLocal"));
        log.info("获取到的结果为:{}", s);
        JSONObject parse = JsonUtils.parse(s);
        if (parse.isEmpty() || JsonUtils.getInt(parse, "code") != 0) {
            log.error("解封失败:{}", JsonUtils.getStr(parse, "message"));
            throw new CustomException("解封失败", 602);
        } else {
            JSONObject data = JsonUtils.getJson(parse, "data");
            JSONArray ruleList = JsonUtils.getJsonArray(data, "rule_list");
            for (int i = 0; i < ruleList.size(); i++) {
                JSONObject jsonObject = ruleList.getJSONObject(i);
                int match = JsonUtils.getInt(jsonObject, "match");
                if (match == 0) {
                    log.error("解封失败:{}", jsonObject);
                    throw new CustomException("解封失败", 602);
                }
            }
            return "";
        }
    }

    /**
     * 获取封堵解封结果
     * @param ips
     * @return
     */
    public static String getResult(List<String> ips, List<String> deviceIps) {
        JSONObject config = getConfig();
        String resultUrl = JsonUtils.getStr(config, "resultUrl");
        if (StringUtils.isEmpty(resultUrl)) {
            log.error("未配置IP封堵url，字典【marvelnet_block_config - resultUrl】");
            throw new CustomException("未配置IP结果URL，字典【marvelnet_block_config】", 601);
        }
        Map<String, List<String>> paramsMap = new HashMap<>();
        paramsMap.put("target_ips", ips);
        paramsMap.put("device_ips", deviceIps);
        String s = HttpUtils.sendPostMarvalnet(resultUrl, JSON.toJSONString(paramsMap), JsonUtils.getStr(config, "token"), JsonUtils.getStr(config, "ipLocal"));
        log.info("获取到的结果为:{}", s);
        return s;
    }


    public static String getIp() {
        try {
            InetAddress inetAddress = InetAddress.getLocalHost();
            return inetAddress.getHostAddress();
        } catch (UnknownHostException e) {
            e.printStackTrace();
        }
        return null;
    }


    public static JSONObject blockIpV1(String ip) {
        List<SysDictData> list = DictUtil.getDict("block_ip_api_url");
        String apiUrl = "";
        String remark = "";
        if (list != null && list.size() > 0) {
            apiUrl = list.get(0).getDictValue();
            remark = list.get(0).getRemark();
        }
        if (StringUtils.isBlank(apiUrl)) {
            log.error("未配置IP封堵URL，字典【block_ip_api_url】");
            throw new CustomException("未配置IP封堵URL，字典【block_ip_api_url】", 601);
        }
        JSONObject json = new JSONObject();
        json.put("id", System.currentTimeMillis());
        json.put("remark", "STP下发IP封堵");
        json.put("ip_list", Collections.singleton(ip));
        log.info(apiUrl + "-》封堵IP:" + json.toJSONString());
        HashMap<String, String> headerMap = new HashMap<>();
        if (StringUtils.isNotBlank(remark)) {
            JSONObject jsonObject = JsonUtils.parse(remark);
            jsonObject.forEach((k, v) -> {
                try {
                    headerMap.put(k, v.toString());
                } catch (Exception e) {
                    log.error(e.getMessage(), e);
                }
            });
        }
        log.info("开始执行IP封堵，路径为：{},参数为:{}", apiUrl, json.toJSONString());
        String ret = HttpUtils.sendPost(apiUrl, json.toJSONString(), headerMap);
        log.info("执行封堵接口返回值为:{}", ret);
        JSONObject jsonObject = JsonUtils.parse(ret);
        return jsonObject;
    }


    public static JSONObject unBlockIpV1(String ip) {
        List<SysDictData> unblockIpApiUrl = DictUtil.getDict("unblock_ip_api_url");
        String apiUrl = "";
        String remark = "";
        if (unblockIpApiUrl != null && unblockIpApiUrl.size() > 0) {
            apiUrl = unblockIpApiUrl.get(0).getDictValue();
            remark = unblockIpApiUrl.get(0).getRemark();
        }
        if (StringUtils.isBlank(apiUrl)) {
            log.error("未配置IP解封URL，字典【unblock_ip_api_url】");
            throw new CustomException("未配置IP解封URL，字典【unblock_ip_api_url】", 601);
        }
        JSONObject json = new JSONObject();
        json.put("ip_list", Collections.singleton(ip));
        log.info(apiUrl + "解封IP:" + JSON.toJSONString(ip));
        HashMap<String, String> headerMap = new HashMap<>();
        if (StringUtils.isNotBlank(remark)) {
            JSONObject jsonObject = JsonUtils.parse(remark);
            jsonObject.forEach((k, v) -> {
                try {
                    headerMap.put(k, v.toString());
                } catch (Exception e) {
                    log.error(e.getMessage(), e);
                }
            });
        }
        log.info("开始执行IP解封，路径为：{},参数为:{}", apiUrl, json.toJSONString());
        String ret = HttpUtils.sendPost(apiUrl, json.toJSONString(), headerMap);
        log.info("执行解封接口返回值为:{}", ret);
        JSONObject jsonObject = JsonUtils.parse(ret);
        return jsonObject;
    }

}
