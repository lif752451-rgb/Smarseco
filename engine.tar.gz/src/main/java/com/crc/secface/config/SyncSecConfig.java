package com.crc.secface.config;

import com.crc.common.utils.DictUtil;
import com.crc.secface.entity.SysDictData;
import org.apache.commons.lang3.StringUtils;

/**
 * 字典工具类
 */
public class SyncSecConfig {
    static String SEC_SYNC_CONFIG = "sync_sec_config";
    /*
       推送STP的URL
        */
    public static String STP_API_URL = "stp_api_url";
    public static boolean isEnable(String value) {
        SysDictData config = DictUtil.getDictByValue(SEC_SYNC_CONFIG, value);
        if (config == null) {
            return false;
        }
        return !StringUtils.isBlank(config.getDictValue());
    }


    public static boolean isEnable(String dictType, String value) {
        SysDictData config = DictUtil.getDictByValue(dictType, value);
        if (config == null) {
            return false;
        }
        return !StringUtils.isBlank(config.getDictValue());
    }

    public static String getRemarkValue(String value) {
        if (value == null) {
            return "";
        }
        SysDictData config = DictUtil.getDictByValue(SEC_SYNC_CONFIG, value);
        if (config == null) {
            return "";
        }
        return config.getRemark();
    }
}
