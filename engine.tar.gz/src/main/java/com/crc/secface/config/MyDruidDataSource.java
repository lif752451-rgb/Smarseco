package com.crc.secface.config;

import com.alibaba.druid.pool.DruidDataSource;
import com.crc.common.utils.CodeTool;

public class MyDruidDataSource extends DruidDataSource {

    @Override
    public void setPassword(String password) {
        super.setPassword(CodeTool.decrypt(password));
    }

}