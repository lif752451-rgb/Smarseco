package com.crc.secface.config;

import com.alibaba.fastjson.JSONObject;
import com.crc.common.utils.CodeTool;
import com.crc.common.utils.DictUtil;
import com.crc.common.utils.JsonUtils;

import com.crc.secface.entity.SysDictData;
import lombok.extern.slf4j.Slf4j;

import java.util.List;

@Slf4j
public class SangforConfig {

    /**
    demo:
     {
     "url": "https://10.26.254.29",
     "username": "gdhadmin",
     "password": "P{g:EaLvcU4[Q^[",
     "deviceIp":"1.1.1.1"
     }
     */
    public static JSONObject getConfig(String devIp) {
        String str = "sangfor_auth";
        List<SysDictData> dictList = DictUtil.getDict("firewall_auth");
        for (SysDictData dict : dictList) {
            if (!dict.getDictValue().equals(str)) {
                continue;
            }
            JSONObject jsonObject = JsonUtils.parse(dict.getRemark());
            String PASS = JsonUtils.getStr(jsonObject, "password");
            try {
                if (PASS.startsWith("ENC") && jsonObject.containsKey("publicKey")) {
                    PASS = PASS.replace("ENC(", "").replace(")", "");
                    PASS = CodeTool.decrypt(PASS, JsonUtils.getStr(jsonObject, "publicKey"));
                    jsonObject.put("password", PASS);
                }
            } catch (Exception e) {
                log.error(e.getMessage(), e);
            }
            if (JsonUtils.equal(jsonObject,"deviceIp",devIp)) {
                return jsonObject;
            }
        }
        return null;
    }
}
