package com.crc.secface.config;

import com.crc.common.utils.CodeTool;

public class DbConfig {
    private String url;
    private String username;
    private String password;
    private String driverClassName;
    private String whereClause;
    private String dbName;
    private String tableName;

    public String getDbName() {
        return dbName;
    }

    public void setDbName(String dbName) {
        this.dbName = dbName;
    }

    public String getTableName() {
        return tableName;
    }

    public void setTableName(String tableName) {
        this.tableName = tableName;
    }

    public String getWhereClause() {
        return whereClause;
    }

    public void setWhereClause(String whereClause) {
        this.whereClause = whereClause;
    }

    public String getUrl() {
        return url;
    }

    public void setUrl(String url) {
        this.url = url;
    }

    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    public String getPassword() {
        return CodeTool.decrypt(password);
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public String getDriverClassName() {
        return driverClassName;
    }

    public void setDriverClassName(String driverClassName) {
        this.driverClassName = driverClassName;
    }

    int bufferRows;

    public int getBufferRows() {
        return bufferRows;
    }

    public void setBufferRows(int bufferRows) {
        this.bufferRows = bufferRows;
    }
}
