package com.crc.secface.config;

import com.alibaba.druid.pool.DruidDataSource;
import org.springframework.boot.autoconfigure.jdbc.DataSourceProperties;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

/**
 * @author simba@onlying.cn
 * @date 2020/7/21 14:53
 */
@Configuration
public class DruidConfig {


    @ConfigurationProperties(prefix = "spring.druid")
    @Bean(initMethod = "init", destroyMethod = "close")
    public DruidDataSource dataSource(DataSourceProperties properties) {
        return new MyDruidDataSource();
    }

}
