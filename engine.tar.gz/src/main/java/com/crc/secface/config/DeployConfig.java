package com.crc.secface.config;


import lombok.Data;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.context.annotation.Configuration;


@Data
@Configuration
@ConfigurationProperties(prefix = "deploy")
public class DeployConfig {
    String stpUrl;
    String stp;
    String email;
    String createAsset;
    String hvv;
    String rwork;//青藤资产
    String version;//v2是新版本工单 其他为就版本
    String alarm;//推送告警中心
    String mode;
    String alarmCenter;
    String report;//是否启动自动化报告
    String aiCheck;//是否启动AI 研判
    String aiUrl;
    String alarmBak;//老的告警模型是否启用


    String aggAlarm; //聚合告警开关

    String aggstp; //聚合告警开关

    String aggEmail;

    String aggRwork;

    String hvvRwork;

    String hvvEmail;

    private String blockIp;
    private String createLog;
}
