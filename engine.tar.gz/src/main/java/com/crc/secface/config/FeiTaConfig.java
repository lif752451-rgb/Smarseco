package com.crc.secface.config;

import com.alibaba.fastjson.JSONObject;
import com.crc.common.utils.CodeTool;
import com.crc.common.utils.DictUtil;
import com.crc.common.utils.JsonUtils;

import com.crc.secface.entity.SysDictData;
import lombok.extern.slf4j.Slf4j;

@Slf4j
public class FeiTaConfig {

    /*
    demo:
     {
            "url": "http://172.16.8.3",
            "username": "admin",
            "password": "ENC(dw6prY1nTM1NzOsajZQLDz6C6QgGE4ozJ5SPNeLKDmQxnIBqtzbGGA==)",
            "publicKey": "IpTFX6FjYs5zKDG8gjKFh7kTgCFdWWJE"
      }
     */
    public static JSONObject getConfig() {
        SysDictData dict = DictUtil.getDictByValue("firewall_auth", "feita_auth");
        if (dict == null) {
            log.error("未配置飞塔防火墙参数,在字典,firewall_auth/feita_auth【remark】类似：{\n" +
                    "            \"url\": \"http://172.16.8.3\",\n" +
                    "            \"username\": \"admin\",\n" +
                    "            \"password\": \"ENC(kRyVNBLuwg6MLMVIQLLaqR_d1Bgvr5Hoh9PnZ8v7qSE)\",\n" +
                    "            \"publicKey\": \"IpTFX6FjYs5zKDG8gjKFh7kTgCFdWWJE\"\n" +
                    "      }");
            return null;
        }
        JSONObject jsonObject = JsonUtils.parse(dict.getRemark());
        String PASS = JsonUtils.getStr(jsonObject, "password");
        try {
            if (PASS.startsWith("ENC") && jsonObject.containsKey("publicKey")) {
                PASS = PASS.replace("ENC(", "").replace(")", "");
                PASS = CodeTool.decrypt(PASS, JsonUtils.getStr(jsonObject, "publicKey"));
                jsonObject.put("password", PASS);
            }
        } catch (Exception e) {
            log.error(e.getMessage(), e);
        }

        return jsonObject;
    }
}
