package com.crc.secface.config;

import com.alibaba.fastjson.JSONArray;
import com.alibaba.fastjson.JSONObject;
import com.crc.common.utils.DictUtil;
import com.crc.common.utils.HttpUtils;
import com.crc.common.utils.JsonUtils;
import com.crc.common.utils.StringUtils;
import com.crc.secface.entity.SysDictData;
import com.crc.secface.redis.RedisUtil;
import lombok.extern.slf4j.Slf4j;

import java.util.concurrent.TimeUnit;

/**
 * @author jixiangqi
 * @date 2023/8/10
 */
@Slf4j
public class IDNACConfig {

    protected static final String IS_OK = "is_ok";

    protected static final String ERROR_REASONS = "error_reasons";

    protected static final String CN = "cn";

    private static final String AIKE_REDIS_KEY = "aikeRedisKey";

    public static String login() {
        RedisUtil redisUtil = GetSpringBean.getBean(RedisUtil.class);
        String value = (String)redisUtil.getValue(AIKE_REDIS_KEY);
        if (StringUtils.isNotEmpty(value)) {
            return value;
        }
        SysDictData dict = DictUtil.getDictByLabel("IDNAC", "login");
        if (dict == null) {
            log.error("未配置艾科网信IDNAC防火墙参数,在字典,IDNAC/login【remark】");
            return null;
        }
        JSONObject jsonObject = JsonUtils.parse(dict.getRemark());
        String content = JsonUtils.getStr(jsonObject, "content");
        String data = String.format(content, JsonUtils.getStr(jsonObject, "password"), JsonUtils.getStr(jsonObject, "userName"));
        String loginUrl = JsonUtils.getStr(jsonObject, "loginUrl");
        log.info("艾科网信登录接口为：{}", loginUrl);
        log.info("艾科网信登录参数为:{}", data);
        String s = HttpUtils.sendPost(loginUrl, data);
        log.info("艾科网信IDNAC登录的返回值为:{}", s);
        JSONObject retJson = JsonUtils.parse(s);
        boolean isOk = JsonUtils.getBoolean(retJson, "is_ok");
        String token = "";
        if (isOk) {
            JSONObject data1 = JsonUtils.getJson(retJson, "data");
            if (data1.size() > 0) {
                token = JsonUtils.getStr(data1, "token");
                redisUtil.setValue(AIKE_REDIS_KEY, token, 50L, TimeUnit.MINUTES);
                return token;
            }
        } else {
            log.error("获取艾科网信IDNAC登录token失败:{}", JsonUtils.getStr(retJson, "cn"));
            return null;
        }
        return null;
    }

    public static String block(String ip) {
        SysDictData dict = DictUtil.getDictByLabel("IDNAC", "block");
        if (dict == null) {
            log.error("封堵下发失败，原因为：未配置艾科网信IDNAC防火墙参数,在字典,IDNAC/block【remark】");
            return "封堵下发失败，原因为：未配置艾科网信IDNAC防火墙参数,在字典,IDNAC/block【remark】";
        }
        String blockUrl = dict.getDictValue();
        log.info("艾科网信封堵接口为:{}", blockUrl);
        String remark = dict.getRemark();
        String token = login();
        if (StringUtils.isNotEmpty(token)) {
            String blockContent = String.format(remark, ip, token);
            log.info("艾科网信封堵参数为:{}", blockContent);
            String s = HttpUtils.sendPost(blockUrl, blockContent, "utf-8", token);
            log.info("艾科网信封堵返回值为:{}", s);
            JSONObject parse = JsonUtils.parse(s);
            if (parse.containsKey(IS_OK) && JsonUtils.getBoolean(parse, IS_OK)) {
                return "";//说明封堵成功
            } else {
                JSONArray jsonArray = JsonUtils.getJsonArray(parse, ERROR_REASONS);
                if (null != jsonArray && jsonArray.size() > 0) {
                    JSONObject jsonObject = jsonArray.getJSONObject(0);
                    String str = JsonUtils.getStr(jsonObject, CN);
                    return str;
                }
            }
        } else {
            log.info("艾科网信登录token为空，请检查");
        }
        return "封堵失败";
    }


    public static String unBlock(String ip) {
        SysDictData dict = DictUtil.getDictByLabel("IDNAC", "unBlock");
        if (dict == null) {
            log.error("解封下发失败，原因为：未配置艾科网信IDNAC防火墙参数,在字典,IDNAC/unBlock【remark】");
            return "解封下发失败，原因为：未配置艾科网信IDNAC防火墙参数,在字典,IDNAC/unBlock【remark】";
        }
        String blockUrl = dict.getDictValue();
        log.info("艾科网信解封接口为:{}", blockUrl);
        String remark = dict.getRemark();
        String token = login();
        if (StringUtils.isNotEmpty(token)) {
            String blockContent = String.format(remark, ip, token);
            log.info("艾科网信解封参数为:{}", blockContent);
            String s = HttpUtils.sendPost(blockUrl, blockContent, "utf-8", token);
            log.info("艾科网信解封返回值为:{}", s);
            JSONObject parse = JsonUtils.parse(s);
            if (parse.containsKey(IS_OK) && JsonUtils.getBoolean(parse, IS_OK)) {
                return "";//说明解封成功
            } else {
                JSONArray jsonArray = JsonUtils.getJsonArray(parse, ERROR_REASONS);
                if (null != jsonArray && jsonArray.size() > 0) {
                    JSONObject jsonObject = jsonArray.getJSONObject(0);
                    String str = JsonUtils.getStr(jsonObject, CN);
                    return str;
                }
            }
        } else {
            log.info("艾科网信登录token为空，请检查");
        }
        return "解封失败";
    }
}
