package com.crc.secface.response;

import com.crc.secface.entity.AssetAsmInternet;
import lombok.Data;
import lombok.EqualsAndHashCode;

import java.util.List;

@Data
@EqualsAndHashCode(callSuper = true)
public class AssetAsmInternetResponse extends AssetAsmInternet {
    /**
     * 协议(1tcp   2http   3https)
     */
    private String agreementLabel;

    /**
     * 发布位置(1数据中心 2公有云 3前置机房)
     */
    private String publishLocationLabel;

    /**
     * 使用状态 (1在用 2未使用)
     */
    private String useStatusLabel;

    /**
     * 查看按钮权限
     */
    private Boolean viewButtonAuth = Boolean.TRUE;

    /**
     * 变更按钮权限
     */
    private Boolean editButtonAuth = Boolean.TRUE;

    /**
     * 删除按钮权限
     */
    private Boolean deleteButtonAuth = Boolean.TRUE;


    private List<String> ipList;
}
