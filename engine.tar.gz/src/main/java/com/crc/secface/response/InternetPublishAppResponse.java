package com.crc.secface.response;

import com.crc.secface.entity.InternetPublishApp;
import lombok.Data;

/**
 * @author jixiangqi
 * @date 2023/6/26
 */
@Data
public class InternetPublishAppResponse extends InternetPublishApp {

    /**
     * 告警级别label
     */
    private String alarmLevelLabel;

    /**
     * 攻击结果label
     */
    private String attackResultLabel;

    /**
     * 攻击手段label
     */
    private String attackMeansLabel;

    private String assetCode;

}
