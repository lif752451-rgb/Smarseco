package com.crc.secface.response;

import com.fasterxml.jackson.annotation.JsonFormat;
import lombok.Data;

import java.util.Date;

/**
 * @author jixiangqi
 * @date 2023/2/17
 */
@Data
public class InternetAlarmResponse {

    private String alarmId;

    private String title;

    private String level;

    private String levelLabel;

    private String attackResult;

    private String attackResultLabel;

    @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss", timezone = "GMT+8")
    private Date alarmTime;

    private String orderStatus;

    private int orderStatusLabel;

    private String ip;

    private int type;

    private String attackIp;

    private String victimizedIp;

    private String id;

    private String businessKey;

    private String organizationId;

    private Date createTime;

    private String attackMeans;

    private Long attackCount;

    private String fightPeriodType;
}
