package com.crc.secface.tool;

import com.alibaba.fastjson.JSONObject;
import com.crc.common.utils.DictUtil;
import com.crc.common.utils.HttpUtils;
import com.crc.common.utils.JsonUtils;
import com.crc.common.utils.StringUtils;
import com.crc.secface.entity.HwVo;
import com.crc.secface.entity.SysDictData;
import lombok.extern.slf4j.Slf4j;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.NodeList;
import org.xml.sax.InputSource;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import java.io.StringReader;
import java.nio.charset.StandardCharsets;
import java.util.HashMap;
import java.util.Map;

/**
 * @author jixiangqi
 * @date 2023/9/5
 * 华为封堵
 */
@Slf4j
public class HuaweiTool {
    public static Map<String, String> getToken() {
        SysDictData dict = DictUtil.getDictByValue("huawei_usg", "login_url");
        if (dict == null) {
            log.error("未配置华为防火墙参数,在字典,huawei_usg/login_url【remark】");
            return null;
        }
        JSONObject jsonObject = JsonUtils.parse(dict.getRemark());
        String url = JsonUtils.getStr(jsonObject, "url");
        String userName = JsonUtils.getStr(jsonObject, "userName");
        String passwd = JsonUtils.getStr(jsonObject, "passwd");
        // 手动构建验证信息
        String auth = userName + ":" + passwd;
        String authHeader = new sun.misc.BASE64Encoder().encode(auth.getBytes(StandardCharsets.UTF_8));
        String token = "Basic " + authHeader;
        Map<String, String> map = new HashMap<>();
        map.put("token", token);
        map.put("url", url);
        return map;
    }


    /**
     * 封堵 IP
     *
     * @param id   策略 ID
     * @param ip   IP
     * @param desc 描述
     * @return 结果
     */
    public static String blockIp(String id, String ip, String desc) {
        SysDictData dict = DictUtil.getDictByValue("huawei_usg", "block_url");
        if (dict == null) {
            log.error("未配置华为防火墙封堵参数,在字典,huawei_usg/block_url【remark】");
            return "华为封堵配置有误，请检查";
        }
        ip = ip + "/32";

        Map<String, String> tokenMap = getToken();
        if (tokenMap == null || tokenMap.size() < 1) {
            log.info("获取 token 失败");
            return "封堵失败";
        }
        String token = tokenMap.get("token");
        String url = tokenMap.get("url");
        String groupName = url.split(",")[1].trim();
        log.info("华为封堵参数为:{},url为:{},groupname:{}，token:{}", ip, url, groupName, token);
        String result = HttpUtils.sendGetXml(url, token);
        HashMap<String, HwVo> blockedMap = new HashMap<>();
        HashMap<String, String> groupMap = new HashMap<>();
        if (StringUtils.isNotBlank(result)) {
            try {
                DocumentBuilderFactory factory = DocumentBuilderFactory.newInstance();
                factory.setFeature("http://apache.org/xml/features/disallow-doctype-decl", true);
                DocumentBuilder builder = factory.newDocumentBuilder();
                InputSource source = new InputSource(new StringReader(result));
                Document document = builder.parse(source);

                Element root = document.getDocumentElement();
                NodeList elements = root.getElementsByTagName("elements");
                if (elements.getLength() > 0) {
                    for (int i = 0; i < elements.getLength(); i++) {
                        Element element = (Element) elements.item(i);
                        NodeList childs = element.getChildNodes();
                        HwVo vo = new HwVo();
                        boolean flag = false;
                        for (int j = 0; j < childs.getLength(); j++) {
                            if ("elem-id".equalsIgnoreCase(childs.item(j).getNodeName())) {
                                vo.setElemId(childs.item(j).getTextContent());
                            } else if ("address-ipv4".equalsIgnoreCase(childs.item(j).getNodeName()) || "address-ipv6".equalsIgnoreCase(childs.item(j).getNodeName())) {
                                vo.setElemValue(childs.item(j).getTextContent());
                                flag = true;
                            }
                        }
                        if (flag) {
                            blockedMap.put(vo.getElemId(), vo);
                        }
                    }
                }
                elements = root.getElementsByTagName("name");
                if (elements.getLength() > 0) {
                    for (int i = 0; i < elements.getLength(); i++) {
                        Element element = (Element) elements.item(i);
                        if (com.crc.common.utils.StringUtils.isNotBlank(element.getTextContent())) {
                            groupMap.put(element.getTextContent().trim(), "1");
                        }
                    }
                }
            } catch (Exception e) {
                log.error(e.getMessage(), e);
            }
        }

        log.info("封堵 IP 地址集数量:{}", blockedMap.size());
        if (blockedMap.containsKey(id)) {
            return "封堵失败,改id=" + id + "已经被封堵过,还未解封";
        }
        for (String key : blockedMap.keySet()) {
            HwVo data = blockedMap.get(key);
            if (ip.equalsIgnoreCase(data.getElemValue())) {
                return "封堵失败,改ip=" + ip + "已经被封堵过,还未解封";
            }
        }
        boolean flag = groupMap.containsKey(groupName);
        HwVo vo = new HwVo();
        vo.setElemId(id);
        vo.setElemValue(ip);
        blockedMap.put(id, vo);
        String remark = toXml(blockedMap);
        int i;
        if (flag) {
            i = HttpUtils.sendPutXml(url, remark, token);
        } else {
            i = HttpUtils.sendPostXml(url, remark, token);
        }
        if (i == 201 || i == 204 || i == 200 ) {
            return "";
        }
        return "封堵失败";
    }

    private static String toXml(HashMap<String, HwVo> blockedMap) {
        String xml = "<addr-object> <desc>how are you</desc> ##DATA## </addr-object>";

        try {
            StringBuilder sb = new StringBuilder();
            blockedMap.forEach((k, v) -> {
                sb.append("<elements>");
                sb.append("<elem-id>").append(v.getElemId()).append("</elem-id>");
                if (v.getElemValue().contains(":")) {
                    sb.append("<address-ipv6>").append(v.getElemValue()).append("</address-ipv6>");
                } else {
                    sb.append("<address-ipv4>").append(v.getElemValue()).append("</address-ipv4>");
                }

                sb.append("</elements>");
            });
            xml = xml.replace("##DATA##", sb.toString());
        } catch (Exception e) {
            e.printStackTrace();
        }

        return xml;
    }


    public static String unBlockIp(String id) {
        if (StringUtils.isEmpty(id)) {
            log.info("id为空不执行解封操作");
            return "解封失败";
        }
        Map<String, String> tokenMap = getToken();
        if (tokenMap == null || tokenMap.size() < 1) {
            log.info("获取 token 失败");
            return "解封失败";
        }
        String token = tokenMap.get("token");
        String url = tokenMap.get("url");
        log.info("华为解封url:{},token:{}", url, token);
        String result = HttpUtils.sendGetXml(url, token);
        HashMap<String, HwVo> blockedMap = new HashMap<>();
        if (StringUtils.isNotBlank(result)) {
            try {
                DocumentBuilderFactory factory = DocumentBuilderFactory.newInstance();
                factory.setFeature("http://apache.org/xml/features/disallow-doctype-decl", true);
                DocumentBuilder builder = factory.newDocumentBuilder();
                InputSource source = new InputSource(new StringReader(result));
                Document document = builder.parse(source);

                Element root = document.getDocumentElement();
                NodeList elements = root.getElementsByTagName("elements");
                if (elements.getLength() > 0) {
                    for (int i = 0; i < elements.getLength(); i++) {
                        Element element = (Element) elements.item(i);
                        NodeList childs = element.getChildNodes();
                        HwVo vo = new HwVo();
                        boolean flag = false;
                        for (int j = 0; j < childs.getLength(); j++) {
                            if ("elem-id".equalsIgnoreCase(childs.item(j).getNodeName())) {
                                vo.setElemId(childs.item(j).getTextContent());
                            } else if ("address-ipv4".equalsIgnoreCase(childs.item(j).getNodeName()) || "address-ipv6".equalsIgnoreCase(childs.item(j).getNodeName())) {
                                vo.setElemValue(childs.item(j).getTextContent());
                                flag = true;
                            }
                        }
                        if (flag) {
                            blockedMap.put(vo.getElemId(), vo);
                        }
                    }
                }
            } catch (Exception e) {
                log.error(e.getMessage(), e);
            }
        }
        log.info("封堵 IP 地址集数量:{}", blockedMap.size());
        if (!blockedMap.containsKey(id)) {
            return "解封失败,没有数据id=" + id + "可解封";
        }
        blockedMap.remove(id);
        String remark = toXml(blockedMap);
        int i = HttpUtils.sendPutXml(url, remark, token);
        if (i != 201 && i != 204) {
            return "解封失败";
        }
        return "";
    }
}
