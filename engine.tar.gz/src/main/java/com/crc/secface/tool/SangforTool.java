package com.crc.secface.tool;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;
import com.crc.common.utils.DateUtils;
import com.crc.common.utils.HttpUtils;
import com.crc.common.utils.JsonUtils;
import com.crc.common.utils.StringUtils;
import com.crc.secface.config.SangforConfig;
import lombok.extern.slf4j.Slf4j;

import java.util.*;

/**
 * 深信服防火墙封堵
 */
@Slf4j
public class SangforTool {
    /**
     * 登录防火墙,获取token
     */
    private static String login(String url, String userName, String password) {
        //POST https://192.168.1.1/api/v1/namespaces/public/login
        String token = "";
        try {
            Map<String, Object> params = new HashMap<>();
            params.put("name", userName);
            params.put("password", password);
            String json = HttpUtils.sendPostNew(url + "/api/v1/namespaces/public/login", params);
            log.info("login:{}", json);

            JSONObject retJson = JsonUtils.parse(json);
            JSONObject data = JsonUtils.getJson(retJson, "data");
            if (data.size() > 0) {
                JSONObject loginResult = JsonUtils.getJson(data, "loginResult");
                token = JsonUtils.getStr(loginResult, "token").trim();
            }
        } catch (Exception e) {
            log.error(e.getMessage(),e);
        }
        return token;
    }

    public static String blockIps(List<String> deviceIp, List<String> ipList, String deadlineTime) {
        //POST https://{host}/api/batch/v1/namespaces/@namespace/blockip
        if (deviceIp == null || deviceIp.size() < 1) {
            log.error("没有执行设备！！");
            return "没有执行设备";
        }
        boolean flag = false;
        for (String devIp : deviceIp) {
            JSONObject config = SangforConfig.getConfig(devIp);
            if (config == null) {
                log.info("没有找到{}封堵设备",devIp);
                continue;
            }
            String url = JsonUtils.getStr(config, "url");
            String token = login(url, JsonUtils.getStr(config, "username"), JsonUtils.getStr(config, "password"));
            Map<String, Object> params = new HashMap<>();
            if (StringUtils.isNotEmpty(deadlineTime)) {
                int intervalSec = DateUtils.getIntervalMin(new Date(), DateUtils.parseDateTime("yyyy-MM-dd HH:mm:ss", deadlineTime));
                params.put("blockTime", intervalSec +"m");
            } else {
                params.put("blockTime", "1d");
            }
            params.put("srcIP", ipList);
            params.put("ipType", "SRC");
            //log.info("深信服封堵参数为:{}", JSON.toJSONString(params));
            String s = HttpUtils.sendPost(url + "/api/batch/v1/namespaces/@namespace/blockip", JSON.toJSONString(params), "utf-8", token);
            JSONObject parse = JsonUtils.parse(s);
            if (JsonUtils.equalVal(parse, "code", "0")) {
                flag = true;
            } else {
                log.info("封堵失败：{}", s);
            }
        }
        return !flag ? "封堵失败" : "";
    }

    public static String unBlockIps(List<String> deviceIp, List<String> ipList) {
        //POST https://{host}/api/batch/v1/namespaces/@namespace/blockip?_method=delete
        if (deviceIp == null || deviceIp.size() < 1) {
            log.error("没有执行设备！！");
            return "没有执行设备";
        }
        boolean flag = false;
        for (String devIp : deviceIp) {
            try {
                JSONObject config = SangforConfig.getConfig(devIp);
                if (config == null) {
                    log.info("没有找到{}封堵设备",devIp);
                    continue;
                }
                String url = JsonUtils.getStr(config, "url");
                String token = login(url, JsonUtils.getStr(config, "username"), JsonUtils.getStr(config, "password"));
                List<JSONObject> ips = new ArrayList<>();
                for (String ip : ipList) {
                    JSONObject jsonObject = new JSONObject();
                    jsonObject.put("srcIP", ip);
                    jsonObject.put("attack", "PLT-MANUAL");
                    ips.add(jsonObject);
                }
                String s = HttpUtils.sendPost(url + "/api/batch/v1/namespaces/@namespace/blockip?_method=delete", JSON.toJSONString(ips), "utf-8", token);
                JSONObject parse = JsonUtils.parse(s);
                if (JsonUtils.equalVal(parse, "code", "0")) {
                    flag = true;
                } else {
                    log.info("解封失败：{}", s);
                }
            } catch (Exception e) {
                log.error(e.getMessage(),e);
            }
        }
        return !flag ? "解封失败" : "";
    }



}
