package com.crc.secface.tool;


import com.alibaba.fastjson.JSONArray;
import com.alibaba.fastjson.JSONObject;
import com.crc.common.utils.IpUtils;
import com.crc.common.utils.JsonUtils;
import com.crc.common.utils.StringUtils;
import com.crc.secface.config.FeiTaConfig;
import com.crc.secface.entity.Fortinet;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Repository;
import org.springframework.web.client.RestTemplate;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Map;
import java.util.function.Function;
import java.util.stream.Collectors;


@Repository
@Slf4j
public class FeitaTool {

    @Autowired
    private RestTemplate restTemplate;

    /**
     * 登录防火墙
     */
    private Fortinet login(String url, String username, String password) {
        HttpEntity<String> request = new HttpEntity<String>(
                "username=" + username + "&secretkey=" + password, new HttpHeaders());
        ResponseEntity<String> responses = restTemplate.exchange(
                url + "/logincheck",
                HttpMethod.POST, request,
                String.class);
        if (responses.getStatusCodeValue() == 200 & responses.getHeaders().getContentLength() < 150) {
            List<String> cookie = responses.getHeaders().get("Set-Cookie");
            if (cookie != null && cookie.size() > 2) {
                Fortinet fortinet = new Fortinet();
                fortinet.setCookie(cookie.get(0));
                fortinet.setCsrfToken(cookie.get(2).split(";")[0].replaceAll("\"", "").replaceAll("ccsrftoken=", ""));
                fortinet.setCtime(new Date());
                fortinet.setPassword(password);
                fortinet.setUrl(url);
                fortinet.setUsername(username);
                return fortinet;
            } else {
                log.error("登录遇到错误:{}", responses.getBody());
            }
        } else {
            log.error("登录遇到错误:{}", responses.getBody());
        }
        return null;
    }


    /**
     * 封堵IP组
     *
     * @param ipList ip数组
     * @return 操作完成
     */
    public String block(List<String> ipList) {
        JSONObject config = FeiTaConfig.getConfig();
        String url = JsonUtils.getStr(config, "url");
        String username = JsonUtils.getStr(config, "username");
        String password = JsonUtils.getStr(config, "password");
        if (config == null && (StringUtils.isBlank(url)) || StringUtils.isBlank(username) || StringUtils.isBlank(password)) {
            return "配置参数不完整！";
        }
        if (ipList == null || ipList.size() < 1) {
            return "没有封堵IP！";
        }
        // 登录防火墙
        Fortinet fortinet = login(url, username, password);
        if (fortinet != null) {
            // 获取已有封堵列表
            List<String> list = getGroupIpList(fortinet, "stp-group");
            boolean b = false;
            boolean ok = false;
            if (list.size() > 0) {
                b = true;
            }
            for (String ip : ipList) {
                if (IpUtils.isIp(ip) && addressAdd(fortinet, ip)) {
                    ok = true;
                    list.add(ip);
                }
            }
            // 如果返回数组是空就创建
            if (b) {
                // 添加地址成功了再添加
                if (ok && list.size() > 0) {
                    if (addressGroupPut(fortinet, "stp-group", list)) {
                        log.info("往地址组添加IP成功");
                    }

                }
            } else {
                if (list.size() > 0) {
                    if (addressGroupAdd(fortinet, "stp-group", list)) {
                        log.info("添加地址组成功了");
                    }
                }
            }
            // 退出
            logout(fortinet);
            log.info("飞塔封堵成功");
            return "";
        }
        return "操作失败!";
    }

    public String unBlock(List<String> ipList) {
        JSONObject config = FeiTaConfig.getConfig();
        String url = JsonUtils.getStr(config, "url");
        String username = JsonUtils.getStr(config, "username");
        String password = JsonUtils.getStr(config, "password");
        if (config == null && (StringUtils.isBlank(url)) || StringUtils.isBlank(username) || StringUtils.isBlank(password)) {
            return "配置参数不完整！";
        }
        if (ipList == null || ipList.size() < 1) {
            return "没有解封IP！";
        }
        Map<String, String> unBlockingMap = ipList.stream().collect(Collectors.toMap(Function.identity(), Function.identity(), (k1, k2) -> k2));
        // 登录防火墙
        Fortinet fortinet = login(url, username, password);
        List<String> newList = new ArrayList<>();
        if (fortinet != null) {
            // 获取已有封堵列表
            List<String> list = getGroupIpList(fortinet, "stp-group");
            Map<String, String> unBlockedMap = list.stream().collect(Collectors.toMap(Function.identity(), Function.identity(), (k1, k2) -> k2));
            // 过滤掉要解封的IP
            unBlockingMap.forEach((k, v) -> {
                if (unBlockedMap.containsKey(k)) {
                    //已封堵
                    newList.add(k);
                }
            });
            // 更新地址组
            addressGroupPut(fortinet, "stp-group", newList);
            // 删除地址
            for (String ip : ipList) {
                addressDel(fortinet, ip);
                log.info("解封IP：{}", ip);
            }
            // 退出
            logout(fortinet);
            return "";
        }
        return "操作失败!";
    }

    private void logout(Fortinet fortinet) {
        HttpEntity<String> request = new HttpEntity<String>(httpHeaders(fortinet));
        ResponseEntity<String> responses = restTemplate.exchange(
                fortinet.getUrl() + "/logout",
                HttpMethod.GET, request,
                String.class);
    }

    /**
     * 添加地址
     */
    private boolean addressGroupAdd(Fortinet fortinet, String id, List<String> ipList) {
        JSONObject body = new JSONObject();
        JSONArray member = new JSONArray();
        for (String ip : ipList) {
            JSONObject raw = new JSONObject();
            raw.put("name", "stp-" + ip);
            member.add(raw);
        }
        body.put("member", member);
        body.put("name", id);
        HttpEntity<String> request = new HttpEntity<String>(body.toJSONString(), httpHeaders(fortinet));
        ResponseEntity<String> responses = restTemplate.exchange(
                fortinet.getUrl() + "/api/v2/cmdb/firewall/addrgrp",
                HttpMethod.POST, request,
                String.class);
        if (responses.getStatusCodeValue() == 200) {
            if (responses.hasBody() && responses.getBody().indexOf("\"status\":\"success\"") != -1) {
                return true;
            } else {
                log.error("地址组创建错误:{}", responses.getBody());
            }
        } else {
            log.error("地址组创建错误:{}", responses.getBody());
        }
        return false;
    }

    /**
     * 地址组添加IP
     */
    private boolean addressGroupPut(Fortinet fortinet, String id, List<String> ipList) {
        // " {'member': [{'name': 'stp-10.0.0.1'}]}"
        JSONObject body = new JSONObject();
        JSONArray member = new JSONArray();
        for (String ip : ipList) {
            JSONObject raw = new JSONObject();
            raw.put("name", "stp-" + ip);
            member.add(raw);
        }
        body.put("member", member);
        HttpEntity<String> request = new HttpEntity<String>(body.toJSONString(), httpHeaders(fortinet));
        ResponseEntity<String> responses = restTemplate.exchange(
                fortinet.getUrl() + "/api/v2/cmdb/firewall/addrgrp/" + id,
                HttpMethod.PUT, request,
                String.class);
        if (responses.getStatusCodeValue() == 200) {
            if (responses.hasBody() && responses.getBody().indexOf("\"status\":\"success\"") != -1) {
                return true;
            } else {
                log.error("地址组添加错误:{}", responses.getBody());
            }
        } else {
            log.error("地址组添加错误:{}", responses.getBody());
        }
        return false;
    }

    //往地址组添加IP
    private boolean addressAdd(Fortinet fortinet, String ip) {
        // 查看IP是否已经添加
        if (addressGet(fortinet, ip)) {
            return true;
        }
        HttpEntity<String> request = new HttpEntity<String>(
                "{\"name\":\"stp-" + ip + "\",\"subnet\":\"" + ip + " 255.255.255.255\"}", httpHeaders(fortinet));
        ResponseEntity<String> responses = restTemplate.exchange(
                fortinet.getUrl() + "/api/v2/cmdb/firewall/address",
                HttpMethod.POST, request,
                String.class);
        if (responses.getStatusCodeValue() == 200) {
            if (responses.hasBody() && responses.getBody().indexOf("\"status\":\"success\"") != -1) {
                return true;
            } else {
                log.error("ip:" + ip + "添加地址错误:{}", responses.getBody());
            }
        } else {
            log.error("ip:" + ip + "添加地址错误:{}", responses.getBody());
        }
        return false;
    }

    /**
     * 删除地址
     */
    private boolean addressDel(Fortinet fortinet, String ip) {
        HttpEntity<String> request = new HttpEntity<String>(httpHeaders(fortinet));
        ResponseEntity<String> responses = restTemplate.exchange(
                fortinet.getUrl() + "/api/v2/cmdb/firewall/address/stp-" + ip,
                HttpMethod.DELETE, request,
                String.class);
        if (responses.getStatusCodeValue() == 200) {
            if (responses.hasBody() && responses.getBody().indexOf("\"status\":\"success\"") != -1) {
                return true;
            } else {
                log.error("ip:" + ip + "删除地址错误:{}", responses.getBody());
            }
        } else {
            log.error("ip:" + ip + "删除地址错误:{}", responses.getBody());
        }
        return false;
    }

    /**
     * 判断IP是否存在地址组
     *
     * @param fortinet 链接信息
     * @param ip       目标IP
     * @return 是否
     */
    private boolean addressGet(Fortinet fortinet, String ip) {
        HttpEntity<String> request = new HttpEntity<String>(httpHeaders(fortinet));
        ResponseEntity<String> responses = restTemplate.exchange(
                fortinet.getUrl() + "/api/v2/cmdb/firewall/address/stp-" + ip,
                HttpMethod.GET, request,
                String.class);
        if (responses.getStatusCodeValue() == 200) {
            if (responses.hasBody() && responses.getBody().indexOf("\"status\":\"success\"") != -1) {
                return true;
            } else {
                log.error("ip:" + ip + "获取地址错误:{}", responses.getBody());
            }
        } else {
            log.error("ip:" + ip + "获取地址错误:{}", responses.getBody());
        }
        return false;
    }

    /**
     * 获取地址组IPList
     */
    private List<String> getGroupIpList(Fortinet fortinet, String id) {
        List<String> IPlist = new ArrayList<>();
        HttpEntity<String> request = new HttpEntity<String>(httpHeaders(fortinet));
        ResponseEntity<JSONObject> responses = restTemplate.exchange(
                fortinet.getUrl() + "/api/v2/cmdb/firewall/addrgrp/" + id,
                HttpMethod.GET, request,
                JSONObject.class);
        if (responses.getStatusCodeValue() == 200) {
            JSONObject body = responses.getBody();
            if (body != null && body.containsKey("results") && body.getJSONArray("results").size() > 0) {
                JSONArray member = body.getJSONArray("results").getJSONObject(0).getJSONArray("member");
                for (int i = 0; i < member.size(); i++) {
                    IPlist.add(member.getJSONObject(i).getString("name").replaceAll("stp-", ""));
                }
            }
        }
        return IPlist;
    }

    /**
     * 构建请求头
     */
    public HttpHeaders httpHeaders(Fortinet fortinet) {
        HttpHeaders headers = new HttpHeaders();
        headers.set("Accept", "*/*");
        headers.set("Content-Type", "application/json");
        headers.add(HttpHeaders.COOKIE, fortinet.getCookie());
        headers.add("X-CSRFTOKEN", fortinet.getCsrfToken());
        return headers;
    }
}
