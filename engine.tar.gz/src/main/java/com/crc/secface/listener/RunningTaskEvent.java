package com.crc.secface.listener;

import com.crc.secface.entity.TaskEvent;
import org.springframework.context.ApplicationEvent;

/**
 * @author simba@onlying.cn
 * @date 2020/10/22 16:05
 */
public class RunningTaskEvent extends ApplicationEvent {


    private TaskEvent taskEvent;

    public RunningTaskEvent(Object source) {
        super(source);
    }

    public RunningTaskEvent(Object source,TaskEvent taskEvent){
        super(source);
        this.taskEvent = taskEvent;
    }

    public TaskEvent getTaskEvent() {
        return taskEvent;
    }



}
