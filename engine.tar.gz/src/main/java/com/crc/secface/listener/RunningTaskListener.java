package com.crc.secface.listener;

import com.crc.common.constants.TaskTypeEnum;
import com.crc.secface.entity.TaskDetail;
import com.crc.secface.entity.TaskError;
import com.crc.secface.entity.TaskEvent;
import com.crc.secface.mapper.TaskInfoMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.ApplicationListener;
import org.springframework.stereotype.Component;

/**
 * @author simba@onlying.cn
 * @date 2020/10/22 16:15
 */
@Component
public class RunningTaskListener implements ApplicationListener<RunningTaskEvent> {

    @Autowired
    private TaskInfoMapper taskInfoMapper;

    @Override
    public void onApplicationEvent(RunningTaskEvent runningTaskEvent) {
        TaskEvent taskEvent = runningTaskEvent.getTaskEvent();
        if (taskEvent.getTaskType() == TaskTypeEnum.DETAIL) {
            TaskDetail taskDetail = (TaskDetail) taskEvent;
            doProcessDetailEvent(taskDetail);
        } else if (taskEvent.getTaskType() == TaskTypeEnum.ERROR) {
            TaskError taskError = (TaskError) taskEvent;
            doProcessErrorEvent(taskError);
        }
    }

    public void doProcessDetailEvent(TaskDetail taskDetail) {
        taskInfoMapper.insertTaskDetail(taskDetail);
    }

    public void doProcessErrorEvent(TaskError taskError) {
        taskInfoMapper.insertTaskError(taskError);
    }
}
