package com.crc.secface.es;

import com.crc.common.utils.CodeTool;
import com.crc.secface.config.GetSpringBean;
import com.crc.secface.config.JdbcConfig;
import lombok.extern.slf4j.Slf4j;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.Statement;


@Slf4j
public class JdbcTemplateHelper {
    private static String DRIVER_CLASS_NAME = null;
    private static String URL = null;
    private static String USERNAME = null;
    private static String PASSWORD = null;

    static {
        JdbcConfig jdbcConfig = GetSpringBean.getBean(JdbcConfig.class);
        DRIVER_CLASS_NAME = jdbcConfig.getDriverClassName();
        URL = jdbcConfig.getUrl();
        USERNAME = jdbcConfig.getUsername();
        PASSWORD = CodeTool.decrypt(jdbcConfig.getPassword());
    }

    /**
     * <Description> 获取数据库连接<br>
     *
     * @return
     * @throws Exception <br>
     * @author lu.wei<br>
     * @email 1025742048@qq.com <br>
     * @date 2017年1月9日 下午10:19:41 <br>
     */
    public static Connection getConnection() throws Exception {
        Class.forName(DRIVER_CLASS_NAME);
        return DriverManager.getConnection(URL, USERNAME, PASSWORD);
    }

    /**
     * <Description> 提交事务<br>
     */
    public static void commit(Connection connection) {
        try {
            connection.commit();
        } catch (Exception e) {
            log.error(e.getMessage(), e);
        }
    }

    /**
     * <Description> 开启事务<br>
     */
    public static void beginTx(Connection connection) {
        try {
            connection.setAutoCommit(false);
        } catch (Exception e) {
            log.error(e.getMessage(), e);
        }
    }

    /**
     * <Description> 回滚<br>
     */
    public static void rollback(Connection connection) {
        try {
            connection.rollback();
        } catch (Exception e) {
            log.error(e.getMessage(), e);
        }
    }

    /**
     * <Description> 回滚<br>
     */
    public static void rollback(Connection connection, String tableName) {
        try {
            log.info("删除临时表：" + tableName);
            connection.createStatement().execute("drop table  " + tableName);
        } catch (Exception e) {
            log.error(e.getMessage(), e);
        }
        try {
            connection.rollback();
        } catch (Exception e) {
            log.error(e.getMessage(), e);
        }
    }
}
