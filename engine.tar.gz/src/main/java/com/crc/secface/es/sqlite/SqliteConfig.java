package com.crc.secface.es.sqlite;


import com.crc.common.utils.StringUtils;
import com.crc.secface.config.GetSpringBean;
import lombok.Getter;
import lombok.extern.slf4j.Slf4j;
import org.springframework.core.env.Environment;

import java.io.File;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

/**
 * 需要注入成单例，创建的时候需要给定数据库名称
 *
 * @Author ：何景生
 * @Date ：2020/9/3 13:32
 * @Version ：1.0
 */
@Slf4j
public class SqliteConfig {
    private static final ThreadLocal<Connection> threadLocal = new ThreadLocal<>();
    @Getter
    private final static String databaseName = "crc_engine_donot_delete.db";
    @Getter
    private  static String url = "jdbc:sqlite:" + databaseName;

    static {
        try {
            Class.forName("org.sqlite.JDBC");
        } catch (Exception e) {
            log.error(e.getMessage(), e);
        }
        try {
            Environment env = GetSpringBean.getBean(Environment.class);
            if (env != null) {
                String dbPath = env.getProperty("deploy.dbPath");
                if(StringUtils.isNotBlank(dbPath)){
                    url = "jdbc:sqlite:" + dbPath + File.separator +  databaseName;
                }
            }
            log.info("sqlite url:{}",url);
        } catch (Exception e) {
            log.error(e.getMessage(),e);
        }
    }

    /**
     * 连接数据库
     */
    public SqliteConfig() {
        try {
            Connection temp = DriverManager.getConnection(url);
            threadLocal.set(temp);
        } catch (Exception e) {
            log.error(e.getMessage(), e);
        }
    }

    /**
     * 获取连接
     *
     * @return
     */
    public Connection getConnection() {
        Connection connection = threadLocal.get();
        boolean isNeedCreate = false;
        if (connection == null) {
            isNeedCreate = true;
        } else {
            try {
                if (connection.isClosed()) {
                    isNeedCreate = true;
                }
            } catch (SQLException e1) {
                isNeedCreate = true;
            }
        }
        if (isNeedCreate) {
            Connection temp = null;
            try {
                temp = DriverManager.getConnection(url);
            } catch (SQLException e) {
                log.error(e.getMessage(), e);
            }
            threadLocal.set(temp);
            return temp;
        } else {
            return connection;
        }
    }

    /**
     * 释放连接对应线程的连接
     */
    public void close() {
        Connection c = threadLocal.get();
        threadLocal.remove();
        try {
            c.close();
        } catch (SQLException e) {
            log.error(e.getMessage(), e);
        }
    }
}
