package com.crc.secface.es;

import cn.hutool.db.DbUtil;
import com.alibaba.fastjson.JSONObject;
import com.crc.common.enums.DatabaseEnums;
import com.crc.common.utils.JsonUtils;
import com.crc.common.utils.VersionUtils;
import com.crc.secface.config.DbConfig;
import com.crc.secface.config.GetSpringBean;
import com.crc.secface.mapper.CommonMapper;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;

import java.sql.*;
import java.util.LinkedList;
import java.util.List;

@Slf4j
public class ConfBuzziMySql {
    // MySQL 8.0 以上版本 - JDBC 驱动名及数据库 URL

    public static Connection getMySQL(DbConfig dbConfig) {
        try {
            // 注册 JDBC 驱动
            Class.forName(dbConfig.getDriverClassName()).newInstance();
            return DriverManager.getConnection(dbConfig.getUrl(), dbConfig.getUsername(), dbConfig.getPassword());
        } catch (Exception e) {
            log.error(e.getMessage(), e);
        }
        return null;
    }


    public static int getCount(String sql) {
        Connection conn = null;
        PreparedStatement st = null;
        ResultSet rs = null;
        try {
            conn = JdbcTemplateHelper.getConnection();
            if (conn == null)
                return 0;
            st = conn.prepareStatement(sql);
            rs = st.executeQuery();
            if (rs.next()) {
                return rs.getInt(1);
            }

        } catch (Exception se) {
            log.error(sql + "\n" + se.getMessage(), se);
        } finally {
            DbUtil.close(rs, st, conn);
        }
        return 0;

    }


    public static int getCount(DbConfig dbConfig, String sql) {
        Connection conn = null;
        PreparedStatement st = null;
        ResultSet rs = null;
        try {
            conn = getMySQL(dbConfig);
            if (conn == null)
                return 0;
            st = conn.prepareStatement(sql);
            rs = st.executeQuery();
            if (rs.next()) {
                return rs.getInt(1);
            }

        } catch (Exception se) {
            log.error(sql + "\n" + se.getMessage(), se);
        } finally {
            DbUtil.close(rs, st, conn);
        }
        return 0;

    }

    public static void exeSQL(DbConfig dbConfig, String sql) {
        Connection conn = null;
        PreparedStatement ps = null;
        try {
            conn = getMySQL(dbConfig);
            if (conn != null) {
                ps = conn.prepareStatement(sql);
                ps.execute();
            }
        } catch (Exception se) {
            // 处理 JDBC 错误
            log.error(se.getMessage(), se);
        } finally {
            DbUtil.close(ps, conn);
        }
    }

    public static void exeSQL(String sql) {
        Connection conn = null;
        PreparedStatement ps = null;
        try {
            conn = JdbcTemplateHelper.getConnection();
            if (conn != null) {
                ps = conn.prepareStatement(sql);
                ps.execute();
            }
        } catch (Exception se) {
            // 处理 JDBC 错误
            log.error(se.getMessage(), se);
        } finally {
            DbUtil.close(ps, conn);
        }
    }

    public static List<JSONObject> query(DbConfig dbConfig, String sql) {
        List<JSONObject> jsonList = new LinkedList<>();
        Connection conn = null;
        PreparedStatement ps = null;
        ResultSet rs = null;

        try {
            conn = getMySQL(dbConfig);
            if (conn == null)
                return jsonList;
            ps = conn.prepareStatement(sql);
            rs = ps.executeQuery();
            while (rs.next()) {
                ResultSetMetaData rsmd = rs.getMetaData();
                JSONObject jsonObject = new JSONObject();
                for (int i = 1; i <= rsmd.getColumnCount(); i++) {
                    String col = rsmd.getColumnLabel(i);
                    jsonObject.put(col, getStr(rs, col));
                }
                jsonList.add(jsonObject);
            }
        } catch (Exception se) {
            // 处理 JDBC 错误
            log.error(se.getMessage(), se);
        } finally {
            DbUtil.close(rs, ps, conn);
        }
        return jsonList;
    }

    public static String getStr(ResultSet rs, String filter) {
        try {
            return rs.getString(filter);
        } catch (Exception e) {
            return "";
        }
    }

    public static int getInt(ResultSet rs, String filter) {
        try {
            return rs.getInt(filter);
        } catch (Exception e) {
            return 0;
        }
    }


    public static List<JSONObject> getAllTable() {
        List<JSONObject> tbList = new LinkedList<>();
        if (VersionUtils.getDatabase() == DatabaseEnums.MYSQL.getCode()) {
            List<JSONObject> list = query("select database() as dbname");
            if (list == null || list.size() < 1) {
                return tbList;
            }

            String dbname = JsonUtils.getStr(list.get(0), "dbname");
            if (StringUtils.isNotBlank(dbname)) {
                String sql = "SELECT table_name FROM information_schema.tables WHERE table_schema='" + dbname + "'";
                return query(sql);
            }
        } else {
            String sql = "SELECT table_name FROM user_tables";
            return query(sql);
        }
        return tbList;
    }

    public static int existTable(String tableName) {
        try {
            List<JSONObject> list = getAllTable();
            for (JSONObject jsonObject : list) {
                if (VersionUtils.getDatabase() == DatabaseEnums.MYSQL.getCode()) {
                    String tbName = JsonUtils.getStr(jsonObject, "table_name");
                    if (tbName.equalsIgnoreCase(tableName)) {
                        return 1;
                    }
                } else {
                    String tbName = JsonUtils.getStr(jsonObject, "table_name".toUpperCase());
                    if (StringUtils.isBlank(tbName)) {
                        tbName = JsonUtils.getStr(jsonObject, "table_name");
                    }
                    if (tbName.equalsIgnoreCase(tableName)) {
                        return 1;
                    }
                }
            }

        } catch (Exception e) {
            log.error(e.getMessage(), e);
        }
        return -1;
    }

    public static List<JSONObject> query(String sql) {
        try {
            CommonMapper commonMapper = GetSpringBean.getBean(CommonMapper.class);
            return commonMapper.queryX(sql);
        } catch (Exception se) {
            log.error(se.getMessage(), se);
        }
        return new LinkedList<>();
    }

    public static synchronized void checkAndCreate(String tableName) {
        CommonMapper commonMapper = GetSpringBean.getBean(CommonMapper.class);
        try {
            if (ConfBuzziMySql.existTable(tableName) < 1) {
                if (VersionUtils.getDatabase() == DatabaseEnums.MYSQL.getCode()) {
                    String createSQL = "CREATE TABLE  " + tableName + "(\n" +
                            "  id varchar(32) NOT NULL,\n" +
                            "  data longtext,\n" +
                            "  status varchar(1) DEFAULT NULL,\n" +
                            "  batch varchar(32) DEFAULT NULL,\n" +
                            "  es_index varchar(150) DEFAULT NULL,\n" +
                            "  PRIMARY KEY (id),\n" +
                            "  KEY status (status),\n" +
                            "  KEY batch (batch)\n" +
                            ") ENGINE=InnoDB DEFAULT CHARSET=utf8";
                    commonMapper.exeSQL(createSQL);

                } else {
                    String createSQL = "CREATE TABLE " + tableName + "( \n" +
                            "id varchar2(32) NOT NULL,\n" +
                            "DATA text,\n" +
                            "status varchar2(1) DEFAULT NULL,\n" +
                            "batch varchar2(32) DEFAULT NULL,\n" +
                            "es_index varchar2(150) DEFAULT NULL,\n" +
                            "PRIMARY KEY (id) ) ";
                    commonMapper.exeSQL(createSQL);
                }
            }
        } catch (Exception e) {
            log.error(e.getMessage(), e);
        }
    }
}

