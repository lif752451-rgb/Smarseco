package com.crc.secface.es;


import com.alibaba.fastjson.JSONObject;
import com.crc.secface.es.sqlite.SqliteConfig;
import lombok.Getter;
import lombok.extern.slf4j.Slf4j;

import java.sql.*;
import java.util.LinkedList;
import java.util.List;

/**
 * 该类不管 SQL 语句只对操作进行了简单封装
 *
 * @Author ：吴用
 * @Date ：2020/9/3 14:58
 * @Version ：1.0
 */
@Slf4j
@Getter
public class SqliteTool {
    @Getter
    private static SqliteConfig sqliteConfig;
    @Getter
    private static SqliteTool sqlController = new SqliteTool();

    /**
     * 单例设计模式
     */
    private SqliteTool() {
        sqliteConfig = new SqliteConfig();
    }

    /**
     * 返回 PreparedStatement 对象，用于放置参数,无返回值
     *
     * @param sql
     * @return
     */
    public boolean excuteSql(String sql, SqlTemplate sqlTemplate) {
        Connection c = null;
        PreparedStatement stmt = null;
        try {
            c = sqliteConfig.getConnection();
            stmt = c.prepareStatement(sql);
            c.setAutoCommit(false);
            sqlTemplate.setPreparedStatement(stmt);
            // 最主要是就是这2行
            stmt.addBatch();
            // 执行
            stmt.executeBatch();
            // 提交
            c.commit();
        } catch (Exception e) {
            log.error("ERROR SQL:{}" + e.getMessage(),sql, e);
            return false;
        } finally {
            close(null, stmt, c);
        }
        return true;
    }

    /**
     * 返回用于执行大量的sql语句
     *
     * @param sql          单个sql模板
     * @param sqlTemplates 执行方式的集合
     */
    public void excuteSqlMany(String sql, List<SqlTemplate> sqlTemplates) {
        Connection c = null;
        PreparedStatement stmt = null;
        try {
            c = sqliteConfig.getConnection();
            stmt = c.prepareStatement(sql);
            c.setAutoCommit(false);
            for (SqlTemplate sqlTemplate : sqlTemplates) {
                sqlTemplate.setPreparedStatement(stmt);
                // 最主要是就是这2行
                stmt.addBatch();
                // 执行
                stmt.executeBatch();
            }
            // 提交
            c.commit();
            stmt.close();
            c.close();
        } catch (Exception e) {
            log.error(e.getMessage(), e);
        } finally {
            close(null, stmt, c);
        }
    }

    /**
     * 主要用于查询操作
     *
     * @param sql
     * @param sqlTemplate
     */
    public List<JSONObject> excuteSqlAndGetData(String sql, SqlTemplate sqlTemplate) {
        Connection c = null;
        PreparedStatement stmt = null;
        ResultSet resultSet = null;
        List<JSONObject> jsonList = new LinkedList<>();
        try {
            c = sqliteConfig.getConnection();
            stmt = c.prepareStatement(sql);
            sqlTemplate.setPreparedStatement(stmt);
            resultSet = stmt.executeQuery();
            while (resultSet.next()) {
                ResultSetMetaData rsmd = resultSet.getMetaData();
                JSONObject jsonObject = new JSONObject();
                for (int i = 1; i <= rsmd.getColumnCount(); i++) {
                    String col = rsmd.getColumnLabel(i);
                    jsonObject.put(col, ConfBuzziMySql.getStr(resultSet, col));
                }
                jsonList.add(jsonObject);
            }
            return jsonList;
        } catch (Exception e) {
            log.error(e.getMessage(),e);
        } finally {
            close(resultSet,stmt,c);
        }
        return null;
    }

    /**
     * 主要用于查询操作
     *
     * @param sql
     * @param sqlTemplate
     */
    public int excuteSqlAndGetCount(String sql, SqlTemplate sqlTemplate) {
        Connection c = null;
        PreparedStatement stmt = null;
        ResultSet resultSet = null;
        try {
            c = sqliteConfig.getConnection();
            stmt = c.prepareStatement(sql);
            sqlTemplate.setPreparedStatement(stmt);
            resultSet = stmt.executeQuery();
            if (resultSet.next()) {
                return resultSet.getInt(1);
            }
        } catch (Exception e) {
            log.error(e.getMessage(),e);
        } finally {
            close(resultSet,stmt,c);
        }
        return 0;
    }


    public void close(ResultSet rs, PreparedStatement ps, Connection conn) {
        try {
            if (rs != null) {
                rs.close();
            }
        } catch (Exception ignored) {

        }

        try {
            if (ps != null) {
                ps.close();
            }
        } catch (Exception ignored) {

        }


        try {
            if (conn != null) {
                conn.close();
            }
        } catch (Exception ignored) {

        }
    }

    /**
     * 通过这个接口获取PreparedStatement实例，然后放置对应的参数
     */
    public interface SqlTemplate {
        /**
         * 在刚方法内部需要通过 preparedStatement 放置参数
         *
         * @param preparedStatement 语句
         */
        void setPreparedStatement(PreparedStatement preparedStatement);
    }

    /**
     * 关闭连接
     */
    public void close() {
        sqliteConfig.close();
    }
}
