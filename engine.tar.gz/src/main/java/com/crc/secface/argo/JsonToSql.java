package com.crc.secface.argo;

import com.alibaba.fastjson.JSONObject;
import com.crc.common.constants.MySQLDataTypeEnum;
import com.crc.common.utils.DataUtils;

import java.util.Date;
import java.util.HashMap;
import java.util.Map;
import java.util.Set;
import java.util.concurrent.atomic.AtomicInteger;

/**
 * JSON 转SQL工具算法类
 */
public class JsonToSql {

    /**
     * 获取子集的查询字段清单
     *
     * @param colMap    列名清单
     * @param groupName 子集名称
     */
    public static String getSelectCol(Map<String, String> colMap, String groupName) {
        StringBuilder sb = new StringBuilder();
        final int[] index = {0};
        /*
         * 防止多个子集字段冲突，需要使用别名，子集_原字段名称
         */
        colMap.forEach((k, v) -> {
            if (index[0] != colMap.size() - 1) {
                sb.append(getKeyName(groupName, k)).append(",");
            } else {
                sb.append(getKeyName(groupName, k));
            }
            index[0]++;
        });
        return sb.toString();
    }

    /**
     * 获取子集的查询字段清单
     *
     * @param colMap    列名清单
     */
    public static String getSelectColX(Map<String, String> colMap) {
        StringBuilder sb = new StringBuilder();
        final int[] index = {0};
        /*
         * 防止多个子集字段冲突，需要使用别名，子集_原字段名称
         */
        colMap.forEach((k, v) -> {
            if (index[0] != colMap.size() - 1) {
                sb.append(k).append(",");
            } else {
                sb.append(k);
            }
            index[0]++;
        });
        return sb.toString();
    }

    public static String getKeyName(String groupName, String field) {
        //防止多个子集字段冲突，需要使用别名，子集_原字段名称
        return groupName + "." + field + " " + groupName + "_" + field;
    }

    /**
     * 获取JSON 转化 MySQL的字段类型列表
     */
    public static Map<String, String> parseColumnTypeMap(JSONObject obj) {
        Map<String, String> colMap = new HashMap<>();
        Set<Map.Entry<String, Object>> entry = obj.entrySet();

        for (Map.Entry<String, Object> elem : entry) {
            String key = elem.getKey().toLowerCase();
            if (elem.getValue() instanceof Integer) {
                colMap.put(DataUtils.humpToLine(key), MySQLDataTypeEnum.INT.getValue());
            } else if (elem.getValue() instanceof Long) {
                colMap.put(DataUtils.humpToLine(key), MySQLDataTypeEnum.BIGINT.getValue());
            } else if (elem.getValue() instanceof Float) {
                colMap.put(DataUtils.humpToLine(key), MySQLDataTypeEnum.FLOAT.getValue());
            } else if (elem.getValue() instanceof Double) {
                colMap.put(DataUtils.humpToLine(key), MySQLDataTypeEnum.DOUBLE.getValue());
            } else if (elem.getValue() instanceof String) {
                //String val = elem.getValue().toString();
                colMap.put(DataUtils.humpToLine(key), MySQLDataTypeEnum.TEXT.getValue());
            } else if (elem.getValue() instanceof Date) {
                colMap.put(DataUtils.humpToLine(key), MySQLDataTypeEnum.DATE.getValue());
            } else {
                colMap.put(DataUtils.humpToLine(key), MySQLDataTypeEnum.VARCHAR.getValue());
            }

        }
        return colMap;
    }

    /**
     * 根据JSON，获取批量插入数据的SQL语句
     */
    public static String getBatchSql(Map<String, String> colMap, String tableName) {
        if (colMap.size() < 1) {
            return "";
        }
        //INSERT INTO coupons (user_id, type, expires) VALUES (?,?,?)
        StringBuilder sb = new StringBuilder();
        sb.append("INSERT INTO   ").append(tableName).append("(");
        AtomicInteger index = new AtomicInteger(0);
        colMap.forEach((k, v) -> {
            sb.append(k);
            index.getAndIncrement();
            if (index.get() != colMap.size()) {
                sb.append(",");
            }
        });
        sb.append(")");
        sb.append("VALUES ( ");
        index.set(0);
        colMap.forEach((k, v) -> {
            sb.append("?");
            index.getAndIncrement();
            if (index.get() != colMap.size()) {
                sb.append(",");
            }
        });
        sb.append(")");
        return sb.toString();
    }


    /**
     * 根据JSON，获取创建数据库表的语句
     */
    public static String getCreateTableSql(Map<String, String> colMap, String tableName) {
        if (colMap.size() < 1) {
            return "";
        }
        StringBuilder sb = new StringBuilder();
        sb.append("CREATE TABLE  ").append(tableName).append("(\n");
        //crc_id 作为默认自增主键
        AtomicInteger index = new AtomicInteger();
        colMap.forEach((k, v) -> {
            if (v.equals(MySQLDataTypeEnum.INT.getValue())) {
                sb.append(k).append(" INT DEFAULT 0,\n");
            } else if (v.equals(MySQLDataTypeEnum.BIGINT.getValue())) {
                sb.append(k).append(" INT DEFAULT 0,\n");
            } else if (v.equals(MySQLDataTypeEnum.FLOAT.getValue())) {
                sb.append(k).append(" REAL DEFAULT 0,\n");
            } else if (v.equals(MySQLDataTypeEnum.DOUBLE.getValue())) {
                sb.append(k).append(" REAL DEFAULT 0,\n");
            } else if (v.equals(MySQLDataTypeEnum.VARCHAR.getValue())) {
                sb.append(k).append(" text DEFAULT NULL,\n");
            } else if (v.equals(MySQLDataTypeEnum.TEXT.getValue())) {
                sb.append(k).append(" text DEFAULT NULL,\n");
            } else if (v.equals(MySQLDataTypeEnum.DATE.getValue())) {
                sb.append(k).append(" datetime DEFAULT NULL,\n");
            } else {
                sb.append(k).append(" text DEFAULT NULL,\n");
            }
            index.getAndIncrement();
        });
        sb.append("crc_id integer PRIMARY KEY AUTOINCREMENT \n");
        sb.append(")");
        return sb.toString();
    }
}
