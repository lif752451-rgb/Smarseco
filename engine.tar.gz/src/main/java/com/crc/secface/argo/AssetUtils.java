package com.crc.secface.argo;

import com.alibaba.fastjson.JSONObject;
import com.crc.common.constants.LogConstants;
import com.crc.common.constants.LogConstantsX;
import com.crc.common.utils.DataUtils;
import com.crc.common.utils.IpUtils;
import com.crc.common.utils.JsonUtils;
import com.crc.secface.config.ElasticsearchProperties;
import com.crc.secface.config.GetSpringBean;
import com.crc.secface.entity.IPBean;
import com.crc.secface.entity.TbAsset;
import com.crc.secface.entity.TbAssetSegement;
import com.crc.secface.es.ConfBuzziMySql;
import com.crc.secface.es.EsSingleFactory;
import com.crc.secface.mapper.CommonMapper;
import com.crc.secface.mapper.TbAssetMapper;
import com.crc.sync.net.NewSegmentLoad;
import org.apache.commons.lang3.StringUtils;
import org.elasticsearch.action.search.SearchRequest;
import org.elasticsearch.action.search.SearchResponse;
import org.elasticsearch.client.RequestOptions;
import org.elasticsearch.client.RestHighLevelClient;
import org.elasticsearch.index.query.BoolQueryBuilder;
import org.elasticsearch.index.query.QueryBuilders;
import org.elasticsearch.search.SearchHit;
import org.elasticsearch.search.SearchHits;
import org.elasticsearch.search.builder.SearchSourceBuilder;
import org.elasticsearch.search.sort.FieldSortBuilder;
import org.elasticsearch.search.sort.SortOrder;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.List;

public class AssetUtils {
    private static final Logger logger = LoggerFactory.getLogger(AssetUtils.class);

    public static String getVlanIp(String ip) {
        try {
            if ("127.0.0.1".equalsIgnoreCase(ip) || "0.0.0.0".equalsIgnoreCase(ip)) {
                return ip;
            }
            TbAssetMapper tbAssetMapper = GetSpringBean.getBean(TbAssetMapper.class);
            TbAsset q = new TbAsset();
            q.setInternalIp(ip);
            TbAsset asset = tbAssetMapper.selectTbAssetByIp(q);
            CommonMapper commonMapper = GetSpringBean.getBean(CommonMapper.class);
            if (asset == null || StringUtils.isBlank(asset.getInternalIp())) {
                if (ConfBuzziMySql.existTable("tb_asset_terminal_equipment") == 1) {
                    try {
                        String sql = "SELECT * FROM tb_asset_terminal_equipment WHERE report_ip = '" + ip + "' order by update_time desc limit 5";
                        List<JSONObject> list = commonMapper.queryX(sql);
                        if (list != null && list.size() > 0) {
                            asset = new TbAsset();
                            asset.setAffiliationDeptName(DataUtils.getStr(list.get(0), "organization"));
                            asset.setAssetUser(DataUtils.getStr(list.get(0), "use_bod"));
                            asset.setInternalIp(DataUtils.getStr(list.get(0), "report_ip"));
                            asset.setInstance(DataUtils.getStr(list.get(0), "computer_name"));
                        }
                    } catch (Exception ignored) {

                    }
                } else {
                    try {
                        String sql = "SELECT * FROM tb_terminal_software_install WHERE str_dev_ip = '" + ip + "' order by id desc limit 5";
                        List<JSONObject> list = commonMapper.queryX(sql);
                        if (list != null && list.size() > 0) {
                            asset = new TbAsset();
                            asset.setAffiliationDeptName(DataUtils.getStr(list.get(0), "str_role_name"));
                            asset.setAssetUser(DataUtils.getStr(list.get(0), "str_user_des"));
                            asset.setInternalIp(DataUtils.getStr(list.get(0), "str_dev_ip"));
                            asset.setInstance(DataUtils.getStr(list.get(0), "str_dev_name"));
                        }
                    } catch (Exception ignored) {

                    }
                }
            } else {
                if (StringUtils.isBlank(asset.getAssetUser()) && StringUtils.isNotBlank(asset.getAssetMail())) {
                    asset.setAssetUser(asset.getAssetMail());
                } else if (StringUtils.isNotBlank(asset.getAssetUser()) && StringUtils.isNotBlank(asset.getAssetMail())) {
                    asset.setAssetUser(asset.getAssetUser() + asset.getAssetMail());
                }
            }

            if (asset == null || StringUtils.isBlank(asset.getInternalIp())) {
                asset = new TbAsset();
            }
            TbAssetSegement ipBean = NewSegmentLoad.getIPSegmentByHalf(ip);
            if (ipBean != null) {
                if (StringUtils.isBlank(asset.getAffiliationDeptName())) {
                    asset.setAffiliationDeptName(ipBean.getAffiliationDeptName());
                }
                if (StringUtils.isBlank(asset.getArea())) {
                    asset.setArea(ipBean.getAreaName());
                }
            }


            String fname = asset.getAffiliationDeptName();
            String farea = asset.getArea();
            String username = asset.getAssetUser();
            if (StringUtils.isNotBlank(farea) && farea.contains("办公") && StringUtils.isBlank(username)) {
                String name = queryUserName("user_all-*", ip);
                if (StringUtils.isNotBlank(name)) {
                    username = name;
                }
            }
            if (StringUtils.isNotBlank(username)) {
                username = "(" + username + ")";
            } else {
                username = "";
            }
            String instance = asset.getInstance();
            if (IpUtils.isIp(instance) || StringUtils.isBlank(instance) || "null".equalsIgnoreCase(instance)) {
                instance = "";
            } else {
                instance = "<" + instance + ">";
            }
            String areaInfo = "";
            if (!StringUtils.isBlank(farea)) {
                areaInfo = "[" + farea + "]";
            }

            String officeInfo = "";
            if (!StringUtils.isBlank(fname)) {
                officeInfo = fname;
            }
            String assetInfo = officeInfo + instance + areaInfo + username;
            if (StringUtils.isNotBlank(assetInfo)) {
                return ip + "-" + officeInfo + instance + areaInfo + username;
            }
        } catch (Exception e) {
            logger.error(e.getMessage(), e);
        }
        return ip;
    }

    public static String queryUserName(String indexName, String ip) {
        SearchSourceBuilder sourceBuilder = new SearchSourceBuilder();
        sourceBuilder.from(0);
        sourceBuilder.size(1);
        sourceBuilder.sort(new FieldSortBuilder(LogConstants.SPARK_TIME_TAG).order(SortOrder.DESC));
        ElasticsearchProperties esProperty = GetSpringBean.getBean(ElasticsearchProperties.class);
        EsSingleFactory factory = EsSingleFactory.getInstance();
        RestHighLevelClient restHighLevelClient = factory.getHighLevelClient(esProperty);
        try {
            BoolQueryBuilder boolBuilder = QueryBuilders.boolQuery();
            boolBuilder.must(QueryBuilders.matchPhraseQuery(LogConstantsX.SRC_IP, ip));
            sourceBuilder.query(boolBuilder);
            SearchRequest searchRequest = new SearchRequest(indexName);
            searchRequest.source(sourceBuilder);
            SearchResponse response = restHighLevelClient.search(searchRequest, RequestOptions.DEFAULT);
            SearchHits sh = response.getHits();
            for (SearchHit s : sh) {
                JSONObject json = JsonUtils.parse(s.getSourceAsString());
                String name = JsonUtils.getStr(json, "user_name");
                if (StringUtils.isBlank(name)) {
                    name = JsonUtils.getStr(json, "op_cn_name");
                }
                if (StringUtils.isBlank(name)) {
                    name = JsonUtils.getStr(json, "op_name");
                }
                return name;
            }
        } catch (Exception ignored) {
        } finally {
            factory.close(restHighLevelClient);
        }
        return "";
    }

    /**
     * 获取外网地址
     *
     * @param ip
     * @return
     */
    public static String getInternetIpInfo(String ip) {
        if (!IpUtils.isIp(ip)) {
            return "";
        }
        try {
            String ipInfo = SearchIpUtils.search(ip);
            if (StringUtils.isNotBlank(ipInfo)) {
                return ipInfo;
            }
        } catch (Exception e) {
            logger.error(e.getMessage(), e);
        }
        return "";
    }

    /**
     * 获取IP的组织信息是否存在指定特殊函数
     *
     * @return
     */
    public static boolean checkAssetByInFixName(List<String> srcFixList, List<String> destFixList, JSONObject json) {
        /*
         * {
         *   "src_ip": "华润创业",
         *   "dest_ip": "华润创业",
         *   "dept_id": "226",
         *    "policy":"all"
         * }
         */

        boolean flag = false;

        try {
            String tmpStr = "";
            String tmpIp = "";
            String srcOffice = JsonUtils.getStr(json, "src_asset_office");
            if (srcFixList != null && srcFixList.size() > 0) {
                List<String> srcIpList = IpUtils.getIps(JsonUtils.getStr(json, LogConstants.SRC_IP_TAG));
                if (srcIpList.size() > 0) {
                    for (String ip : srcIpList) {
                        tmpStr = "";
                        tmpIp = "";
                        if ("127.0.0.1".equalsIgnoreCase(ip) || "0.0.0.0".equalsIgnoreCase(ip)) {
                            continue;
                        }
                        TbAsset asset = getAssetByIp(ip);
                        String fname = asset.getAffiliationDeptName();
                        if (StringUtils.isBlank(fname)) {
                            continue;
                        }
                        for (String fix : srcFixList) {
                            if (fname.contains(fix)) {
                                tmpStr = fname;
                                flag = true;
                                tmpIp = ip;
                                break;
                            }
                            if (StringUtils.isNotBlank(srcOffice)) {
                                if (srcOffice.contains(fix)) {
                                    tmpStr = srcOffice;
                                    flag = true;
                                    tmpIp = ip;
                                    break;
                                }
                            }
                        }

                    }
                }
            }
            if (flag) {
                logger.info("利润中心推送命中源IP{},命中{}", tmpIp, tmpStr);
                return flag;
            }
            String destOffice = JsonUtils.getStr(json, "dest_asset_office");
            if (destFixList != null && destFixList.size() > 0) {
                List<String> destIpList = IpUtils.getIps(JsonUtils.getStr(json, LogConstants.DEST_IP_TAG));
                if (destIpList.size() > 0) {
                    for (String ip : destIpList) {
                        tmpStr = "";
                        tmpIp = "";
                        if ("127.0.0.1".equalsIgnoreCase(ip) || "0.0.0.0".equalsIgnoreCase(ip)) {
                            continue;
                        }
                        TbAsset asset = getAssetByIp(ip);
                        String fname = asset.getAffiliationDeptName();
                        if (StringUtils.isBlank(fname)) {
                            continue;
                        }
                        for (String fix : destFixList) {
                            if (fname.contains(fix)) {
                                tmpStr = fname;
                                flag = true;
                                tmpIp = ip;
                                break;
                            }
                            if (StringUtils.isNotBlank(destOffice)) {
                                if (destOffice.contains(fix)) {
                                    tmpStr = destOffice;
                                    flag = true;
                                    tmpIp = ip;
                                    break;
                                }
                            }
                        }

                    }
                }
            }
            if (flag) {
                logger.info("利润中心推送命中目标IP{},命中{}", tmpIp, tmpStr);
                return flag;
            }
        } catch (Exception e) {
            logger.error(e.getMessage(), e);
        }
        return false;
    }


    /*
       根据IP获取资产详情
     */
    private static TbAsset getAssetByIp(String ip) {
        TbAssetMapper tbAssetMapper = GetSpringBean.getBean(TbAssetMapper.class);
        CommonMapper commonMapper = GetSpringBean.getBean(CommonMapper.class);
        TbAsset q = new TbAsset();
        q.setInternalIp(ip);
        TbAsset asset = tbAssetMapper.selectTbAssetByIp(q);
        if (asset == null || StringUtils.isBlank(asset.getInternalIp())) {
            if (ConfBuzziMySql.existTable("tb_asset_terminal_equipment") == 1) {
                try {
                    String sql = "SELECT * FROM tb_asset_terminal_equipment WHERE report_ip = '" + ip + "' order by update_time desc limit 5";
                    List<JSONObject> list = commonMapper.queryX(sql);
                    if (list != null && list.size() > 0) {
                        asset = new TbAsset();
                        asset.setAffiliationDeptName(DataUtils.getStr(list.get(0), "organization"));
                        asset.setAssetUser(DataUtils.getStr(list.get(0), "use_bod"));
                        asset.setInternalIp(DataUtils.getStr(list.get(0), "report_ip"));
                        asset.setInstance(DataUtils.getStr(list.get(0), "computer_name"));
                    }
                } catch (Exception ignored) {

                }
            } else {
                try {
                    String sql = "SELECT * FROM tb_terminal_software_install WHERE str_dev_ip = '" + ip + "' order by id desc limit 5";
                    List<JSONObject> list = commonMapper.queryX(sql);
                    if (list != null && list.size() > 0) {
                        asset = new TbAsset();
                        asset.setAffiliationDeptName(DataUtils.getStr(list.get(0), "str_role_name"));
                        asset.setAssetUser(DataUtils.getStr(list.get(0), "str_user_des"));
                        asset.setInternalIp(DataUtils.getStr(list.get(0), "str_dev_ip"));
                        asset.setInstance(DataUtils.getStr(list.get(0), "str_dev_name"));
                    }
                } catch (Exception ignored) {

                }
            }
        }

        if (asset == null || StringUtils.isBlank(asset.getInternalIp())) {
            asset = new TbAsset();
        }
        TbAssetSegement ipBean = NewSegmentLoad.getIPSegmentByHalf(ip);
        if (ipBean != null) {
            if (StringUtils.isBlank(asset.getAffiliationDeptName())) {
                asset.setAffiliationDeptName(ipBean.getAffiliationDeptName());
            }
            if (StringUtils.isBlank(asset.getArea())) {
                asset.setArea(ipBean.getAreaName());
            }
        }

        return asset;
    }
}
