package com.crc.secface.argo;

import com.crc.common.utils.DateUtils;
import com.crc.secface.config.GetSpringBean;
import com.crc.secface.entity.SysOperLog;
import com.crc.secface.mapper.CommonMapper;
import lombok.extern.slf4j.Slf4j;

import java.util.Date;

@Slf4j
public class OperLogUtils {
    public static void saveLog(String title,String method,String result,String errMsg){
        SysOperLog sysOperLog = new SysOperLog();
        sysOperLog.setOperatorType("100");
        sysOperLog.setBusinessType("100");
        sysOperLog.setTitle(title);
        sysOperLog.setMethod(method);
        sysOperLog.setOperName("system");
        sysOperLog.setOperTime(DateUtils.getDateTimeString1(new Date()));
        sysOperLog.setStatus("0");
        sysOperLog.setJsonResult(result);
        sysOperLog.setErrorMsg(errMsg);
        try {
            CommonMapper commonMapper = GetSpringBean.getBean(CommonMapper.class);
            CreateInsert<SysOperLog> ci = new CreateInsert<>();
            String sql = ci.createinsert(sysOperLog, "sys_oper_log");
            commonMapper.exeSQL(sql);
        } catch (Exception e) {
            log.error(e.getMessage(),e);
        }
    }
}
