package com.crc.secface.argo;

import com.alibaba.fastjson.JSONObject;
import com.crc.common.utils.DictUtil;
import com.crc.common.utils.JsonUtils;
import com.crc.secface.entity.CombatVo;
import com.crc.secface.entity.SysDictData;
import lombok.extern.slf4j.Slf4j;

import java.util.Date;
import java.util.HashMap;
import java.util.List;

@Slf4j
public class CombatUtils {
    static HashMap<String, String> ATTACK_MAPING = new HashMap<>();

    static {
        ATTACK_MAPING.put("①", "①对重点人投毒进行社工攻击");
        ATTACK_MAPING.put("②", "②发现隐藏攻击隧道");
        ATTACK_MAPING.put("③", "③发现重要敏感数据被窃取");
        ATTACK_MAPING.put("④", "④系统被控制，植入木马等");
        ATTACK_MAPING.put("⑤", "⑤邮件系统被盯控");
        ATTACK_MAPING.put("⑥", "⑥近源攻击突破网络防线");
        ATTACK_MAPING.put("⑦", "⑦攻击链打击");
        ATTACK_MAPING.put("⑧", "⑧通过下属单位,跨网,迂回攻击");
        ATTACK_MAPING.put("⑨", "⑨内网敏感信息被收集利用（网段信息,密码本,网络拓扑,源代码,组织架构信息等让防守方补充）");
        ATTACK_MAPING.put("⑩", "⑩漏洞利用、口令滥用、权限提升等高危操作");
    }

    /**
     * 判断当前是否为战时时间
     *
     * @return
     */
    public static CombatVo getCombatTime() {
        CombatVo vo = new CombatVo();
        vo.setCombat(false);
        try {
            List<SysDictData> dictList = DictUtil.getDict("combat_fight_period");
            if (dictList != null) {
                for (SysDictData dict : dictList) {
                    try {
                        //{ "startTime": 2023-04-01 00:00:00, "endTime":  2023-05-01 00:00:00 }
                        JSONObject jsonObject = JsonUtils.parse(dict.getRemark());
                        if (jsonObject.containsKey("startTime") && jsonObject.containsKey("endTime")) {
                            Date startDate = JsonUtils.getDateX(jsonObject, "startTime");
                            Date endDate = JsonUtils.getDateX(jsonObject, "endTime");
                            Date curDate = new Date();
                            if (startDate == null || endDate == null) {
                                log.error("{}实战告警闭环_作战周期，不合规", dict.getDictLabel());
                                continue;
                            }
                            if (startDate.before(curDate) && curDate.before(endDate)) {
                                log.error("{}实战告警闭环_作战周期，命中！", dict.getDictLabel());
                                vo.setType(dict.getDictValue());
                                vo.setCombat(true);
                                return vo;
                            }
                        }
                    } catch (Exception e) {
                        log.error(e.getMessage(), e);
                    }
                }
            }
        } catch (Exception e) {
            log.error(e.getMessage(), e);
        }
        return vo;
    }

    public static String getNewAttack(String oldAttack) {
        if (oldAttack == null) {
            return "";
        }
        if(!oldAttack.contains("_")){
            return oldAttack;
        }
        String code = oldAttack.split("_")[0].trim();
        String mapping = "1,->,⑩\n" +
                "        2,->,①\n" +
                "        3,->,⑦\n" +
                "        4,->,⑩\n" +
                "        5,->,⑩\n" +
                "        6,->,①\n" +
                "        7,->,①\n" +
                "        8,->,⑩\n" +
                "        9,->,④\n" +
                "        10,->,④\n" +
                "        11,->,⑥\n" +
                "        12,->,⑥\n" +
                "        13,->,⑩\n" +
                "        14,->,⑩\n" +
                "        15,->,②\n" +
                "        16,->,⑨\n" +
                "        17,->,⑦\n" +
                "        18,->,⑩";
        for (String map : mapping.split("\n")) {
            String[] arr = map.trim().split(",");
            if (arr.length == 3) {
                if (code.equalsIgnoreCase(arr[0].trim())) {
                    return ATTACK_MAPING.get(arr[2].trim());
                }
            }
        }
        return oldAttack;
    }
}
