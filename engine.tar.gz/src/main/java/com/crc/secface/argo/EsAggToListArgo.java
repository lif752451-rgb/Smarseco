package com.crc.secface.argo;

import com.alibaba.fastjson.JSONArray;
import com.alibaba.fastjson.JSONObject;
import com.crc.common.utils.DataUtils;
import com.crc.common.utils.JsonUtils;
import lombok.extern.slf4j.Slf4j;

import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

/**
 * AGG统计结果数，转换为 List JSON平行列表
 */
@Slf4j
public class EsAggToListArgo {
    private final List<JSONObject> retDataList = new ArrayList<>();
    public List<JSONObject> aggToList(JSONObject agg){
        treeToList(agg, null, null);
        int maxSize = 0;
        if (retDataList.size() > 0) {
            for (JSONObject jsonObject : retDataList) {
                if (jsonObject.size() > maxSize) {
                    maxSize = jsonObject.size();
                }
            }
            int finalMaxSize = maxSize;
            return retDataList.stream().filter(s -> s.size() == finalMaxSize).collect(Collectors.toList());
        }
        return retDataList;
    }

    private   void treeToList(JSONObject json, List<JSONObject> jsonList, String parentKey) {
        if (json == null || json.size() < 1) {
            return;
        }
        if (jsonList == null) {
            jsonList = new ArrayList<>();
        }
        List<JSONObject> finalJsonList = jsonList;
        String nk = DataUtils.cleanAgg(parentKey);
        json.forEach((k, v) -> {
            if (v instanceof JSONObject) {
            } else {
                for (JSONObject data : finalJsonList) {
                    JSONObject retJson = new JSONObject(data);
                    retJson.put(String.format("%s#key", nk), JsonUtils.getStr(json, "key"));
                    retJson.put(String.format("%s#count", nk), JsonUtils.getStr(json, "doc_count"));
                    retDataList.add(retJson);
                }
            }
        });
        json.forEach((k, v) -> {
            if (v instanceof JSONObject) {
                JSONObject bucketJson = (JSONObject) v;
                //log.info("iter {}", k);
                if (bucketJson.containsKey("buckets")) {
                    JSONArray subBuckets = bucketJson.getJSONArray("buckets");
                    String k1 = DataUtils.cleanAgg(k);
                    for (int j = 0; j < subBuckets.size(); j++) {
                        JSONObject subBucketJson = subBuckets.getJSONObject(j);
                        List<JSONObject> retList = new ArrayList<>();
                        if (finalJsonList.size() < 1) {
                            JSONObject retJson = new JSONObject();
                            retJson.put(String.format("%s#key", k1), JsonUtils.getStr(subBucketJson, "key"));
                            retJson.put(String.format("%s#count", k1), JsonUtils.getStr(subBucketJson, "doc_count"));
                            retList.add(retJson);
                        } else {
                            for (JSONObject data : finalJsonList) {
                                JSONObject retJson = data.clone();
                                retJson.put(String.format("%s#key", k1), JsonUtils.getStr(subBucketJson, "key"));
                                retJson.put(String.format("%s#count", k1), JsonUtils.getStr(subBucketJson, "doc_count"));
                                retList.add(retJson);
                            }
                        }
                        treeToList(subBucketJson, retList, k);
                    }
                }
            }
        });
    }
}
