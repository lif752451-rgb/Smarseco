package com.crc.secface.argo;

import cn.hutool.core.io.FileUtil;
import cn.hutool.core.io.resource.ClassPathResource;
import org.apache.commons.lang3.StringUtils;
import org.lionsoul.ip2region.xdb.Searcher;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.File;

/**
 * 外网IP查询
 */
public class SearchIpUtils {
    private static final Logger logger = LoggerFactory.getLogger(SearchIpUtils.class);
    private static String IP_DB_FILE_PATH = "";

    public static String search(String ip) {
        boolean flag = false;
        ClassPathResource classPathResource = new ClassPathResource("ip/ip2region.xdb");
        String dbPath = classPathResource.getAbsolutePath();
        if (StringUtils.isNotBlank(dbPath)) {
            if (FileUtil.exist(dbPath)) {
                flag = true;
            } else {
                try {
                    dbPath = System.getProperty("user.dir") + "/ip/ip2region.xdb";
                    File file = new File(dbPath);
                    if (StringUtils.isBlank(IP_DB_FILE_PATH)) {
                        FileUtil.mkdir(System.getProperty("user.dir") + "/ip");
                        FileUtil.writeFromStream(classPathResource.getStream(), file);
                        IP_DB_FILE_PATH = dbPath;
                    }
                    flag = true;
                } catch (Exception e) {
                    logger.error(e.getMessage(), e);
                }
            }
        }
        if (!flag) {
            return "";
        }
        if (StringUtils.isNotBlank(IP_DB_FILE_PATH)) {
            dbPath = IP_DB_FILE_PATH;
        }
        // 1、从 dbPath 中预先加载 VectorIndex 缓存，并且把这个得到的数据作为全局变量，后续反复使用。
        byte[] vIndex;
        try {
            vIndex = Searcher.loadVectorIndexFromFile(dbPath);
        } catch (Exception e) {
            logger.error(e.getMessage(), e);
            return "";
        }

        // 2、使用全局的 vIndex 创建带 VectorIndex 缓存的查询对象。
        Searcher searcher = null;
        try {
            try {
                searcher = Searcher.newWithVectorIndex(dbPath, vIndex);
            } catch (Exception e) {
                logger.error(e.getMessage(), e);
                return "";
            }
            // 3、查询
            try {
                String region = searcher.search(ip);
                if (StringUtils.isNotBlank(region)) {
                    String[] rs = region.split("\\|");
                    StringBuilder sb = new StringBuilder();
                    for (String r : rs) {
                        if (StringUtils.isNotBlank(r) && !"0".equalsIgnoreCase(r)) {
                            sb.append(r).append("/");
                        }
                    }
                    if (sb.toString().endsWith("/")) {
                        return sb.substring(0, sb.toString().length() - 1);
                    } else {
                        return sb.toString();
                    }
                }
            } catch (Exception e) {
                logger.error(e.getMessage(), e);
                return "";
            }

        } catch (Exception e) {
            logger.error(e.getMessage(), e);
            return "";
        } finally {
            try {
                // 4、关闭资源
                if (searcher != null) {
                    searcher.close();
                }
            } catch (Exception ignored) {
            }
        }
        return "";
    }
}
