package com.crc.secface.argo;

import org.apache.commons.lang3.RandomUtils;

/**
 * 随机算法，从N集合，获取M个不重复数据
 * 何景生
 */
public class RandomPick {
    public static int[] getRandomPick(int listSize, int m) {
        int[] data = new int[listSize];
        for (int i = 0; i < listSize; i++) {
            data[i] = i;
        }
        return reservoir(data, m);
    }


    public static int[] reservoir(int[] array, int m) {
        int[] result = new int[m];
        int n = array.length;
        for (int i = 0; i < n; i++) {
            int current_num = array[i];
            if (i < m) {
                result[i] = current_num;
            } else {
                int tmp = RandomUtils.nextInt(0, i + 1);
                if (tmp < m) {
                    result[tmp] = current_num;
                }
            }
        }
        return result;
    }
}
