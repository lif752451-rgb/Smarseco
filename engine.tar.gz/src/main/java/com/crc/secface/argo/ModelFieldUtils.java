package com.crc.secface.argo;

import org.apache.commons.lang3.StringUtils;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class ModelFieldUtils {

    /**
     * 获取需要的数据库字段
     * @param colMap 所有字段
     * @param headerMap 条件中的字段
     * @return 需要的字段
     */
    public static Map<String, String> getNeedColMap(Map<String, String> colMap, Map<String, String> headerMap) {
        if (headerMap == null || headerMap.size() < 1) {
            return colMap;
        }
        Map<String, String> needColMap = new HashMap<>();
        colMap.forEach((k,v)->{
            if (headerMap.containsKey(k)) {
                needColMap.put(k, v);
            }
        });
        headerMap.forEach((k,v)->{
            if (!needColMap.containsKey(k)) {
                needColMap.put(k, v);
            }
        });

        return needColMap;
    }

    /**
     * 抽字段
     * @param desc 内容描述
     * @return 字段列表
     */
    public static Map<String,String> getFields(List<String> groups, String desc) {
        Map<String, String> fields = new HashMap<>();
        if (StringUtils.isBlank(desc)) {
            return fields;
        }

        //desc = desc.replace("{{","{").replace("{{{","{").replace("}}","}");
        Pattern pattern = Pattern.compile("\\{([^}]*)\\}");
        Matcher matcher = pattern.matcher(desc);
        while (matcher.find()) {
            String field = matcher.group(1);
            String[] fs = field.split("\\.");
            for (String f : fs) {
                f = f.replace("{", "").replace("}","");
                if (StringUtils.isNumeric(f)) {
                    continue;
                }
                if (groups.contains(f)) {
                    continue;
                }
                fields.put(f,"1");
                break;
            }
        }

        return fields;
    }


    /**
     * 抽字段
     * @param desc 内容描述
     * @return 字段列表
     */
    public static Map<String,String> getFields(String desc) {
        Map<String, String> fields = new HashMap<>();
        if (StringUtils.isBlank(desc)) {
            return fields;
        }

        //desc = desc.replace("{{","{").replace("{{{","{").replace("}}","}");
        Pattern pattern = Pattern.compile("\\{([^}]*)\\}");
        Matcher matcher = pattern.matcher(desc);
        while (matcher.find()) {
            String field = matcher.group(1);
            String[] fs = field.split("\\.");
            for (String f : fs) {
                f = f.replace("{", "").replace("}","");
                if (StringUtils.isNumeric(f)) {
                    continue;
                }
                fields.put(f,"1");
                break;
            }
        }

        return fields;
    }


    public static Map<String, String> getFieldsX(String field) {
        Map<String, String> fields = new HashMap<>();
        if (StringUtils.isBlank(field)) {
            return fields;
        }

        String[] fs = field.split("\\.");
        for (String f : fs) {
            f = f.replace("{", "").replace("}","");
            if (StringUtils.isNumeric(f)) {
                continue;
            }
            fields.put(f,"1");
            break;
        }

        return fields;
    }
}
