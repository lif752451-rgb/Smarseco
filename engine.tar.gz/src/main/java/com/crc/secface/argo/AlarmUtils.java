package com.crc.secface.argo;

import com.alibaba.fastjson.JSONObject;
import com.crc.common.constants.LogConstantsX;
import com.crc.common.utils.DataUtils;
import com.crc.common.utils.DateUtils;
import com.crc.common.utils.DictUtil;
import com.crc.common.utils.JsonUtils;
import com.crc.secface.config.GetSpringBean;
import com.crc.secface.entity.AlarmLog;
import com.crc.secface.entity.SysDictData;
import com.crc.secface.entity.TbEventModel;
import com.crc.secface.mapper.CommonMapper;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;

import java.util.Date;
import java.util.List;
import java.util.concurrent.atomic.AtomicReference;

@Slf4j
public class AlarmUtils {

    public static String getDeviceName(JSONObject job, TbEventModel model) {
        String productName = "";
        try {
            AtomicReference<String> product = new AtomicReference<>(JsonUtils.getStr(job, LogConstantsX.LOG_PRODUCT));
            if (model != null) {
                //设备类型  0 表达式  1 自定义
                if (model.getDeviceType() == 0 && model.getDeviceName() != null && (!model.getDeviceName().contains("{"))) {
                    model.setDeviceNameStr(model.getDeviceName());
                    product.set(model.getDeviceName());
                    return model.getDeviceName();
                }
                try {
                    List<SysDictData> devicenameList = DictUtil.getDict("rule_base");
                    for (SysDictData dict : devicenameList) {
                        if (StringUtils.isNotBlank(model.getDeviceName()) && model.getDeviceName().equals(dict.getDictValue())) {
                            model.setDeviceNameStr(dict.getDictLabel());
                            product.set(dict.getDictLabel());
                            return product.get();
                        }
                    }
                    if (DataUtils.isInteger(product.get())) {
                        for (SysDictData dict : devicenameList) {
                            if (product.get().equals(dict.getDictValue())) {
                                model.setDeviceNameStr(dict.getDictLabel());
                                product.set(dict.getDictLabel());
                                return product.get();
                            }
                        }
                    }

                } catch (Exception e) {
                    log.error(e.getMessage(), e);
                }
                try {
                    if (model.getDeviceName().contains("{") || model.getDeviceName().contains("}")) {
                        product.set(JsonArgo.getDymValue(model.getDeviceName(), job));
                        model.setDeviceNameStr(product.get());
                        if (StringUtils.isNotBlank(model.getDeviceNameStr())) {
                            return model.getDeviceNameStr();
                        }
                    }
                } catch (Exception e) {
                    log.error(e.getMessage(), e);
                }
            }
            try {
                if (product.get().contains("{") || product.get().contains("}") || StringUtils.isBlank(product.get())) {
                    job.forEach((k, v) -> {
                        if (v instanceof String && (k.contains("product"))) {
                            String prod = JsonUtils.getStr(job, k);
                            product.set(prod);

                        }
                    });
                }
            } catch (Exception e) {
                log.error(e.getMessage(), e);
            }
            productName = product.get();
        } catch (Exception e) {
            log.error(e.getMessage(), e);
        }
        if (StringUtils.isBlank(productName)) {
            productName = "其他";
        }
        return productName;
    }

    /**
     * 判断告警是否推送过
     */
    public static boolean isReportAlarm(String type, String modelId, String attackIp, String repeatValue) {
        try {
            CommonMapper commonMapper = GetSpringBean.getBean(CommonMapper.class);
            if (StringUtils.isBlank(attackIp)) {
                return false;
            }
            String sql = "select count(1) from tb_danger_event_ori_tmp where type = '%s' and model_id = '%s' and ip = '%s' and create_time > date_sub(now(), interval 8 hour)";
            if (commonMapper.getCount(String.format(sql, type, modelId, attackIp)) > 0) {
                log.info("*********模型id为:{},内容为:{},攻击IP{},在8小时内重复发送过，所以暂不发送", modelId, attackIp, repeatValue);
                return true;
            } else {
                try {
                    AlarmLog alarmLog = new AlarmLog();
                    alarmLog.setIp(attackIp);
                    alarmLog.setCreateTime(DateUtils.getDateTimeString1(new Date()));
                    alarmLog.setModelId(modelId);
                    alarmLog.setType(type);
                    CreateInsert<AlarmLog> dataInsert = new CreateInsert<>();
                    String sqlx = dataInsert.createinsert(alarmLog, "tb_danger_event_ori_tmp");
                    commonMapper.exeSQL(sqlx);
                } catch (Exception e) {
                    log.error(e.getMessage(), e);
                }
            }
        } catch (Exception e) {
            log.error(e.getMessage(), e);
        }

        return false;
    }
}
