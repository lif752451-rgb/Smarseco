package com.crc.secface.argo;

import com.alibaba.fastjson.JSON;
import com.crc.common.constants.OperationEnum;
import com.crc.secface.entity.RelGroupTable;
import com.crc.secface.entity.RelationCondition;
import com.crc.secface.entity.TbEventModel;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;

import java.util.List;
import java.util.Map;
import java.util.concurrent.atomic.AtomicBoolean;

@Slf4j
public class RelationArgo {
    /**
     * 聚合模型分析算法
     *
     * @param model 模型对象
     */
    public static String getRelationWhere(TbEventModel model) {
        if (StringUtils.isBlank(model.getRelationParams())) {
            log.error(model.getModelId() + "关联告警模型没有配置比较条件！");
            return "";
        }
        try {
            List<RelationCondition> relationConditions = JSON.parseArray(model.getRelationParams(), RelationCondition.class);
            StringBuilder sb = new StringBuilder();
            int index = 0;
            for (RelationCondition rc : relationConditions) {
                if (!rc.isGood()) {
                    log.error("关联告警模型比较条件解析非法格式1=" + JSON.toJSONString(rc));
                    return "";
                }
                if (rc.getOperationType().equalsIgnoreCase(OperationEnum.EQ.getValue())) {
                    sb.append(rc.getFirstName()).append(".").append(rc.getFirstField()).append(" = ").append(rc.getSecondName()).append(".").append(rc.getSecondField());
                } else if (rc.getOperationType().equalsIgnoreCase(OperationEnum.LT.getValue())) {
                    sb.append(rc.getFirstName()).append(".").append(rc.getFirstField()).append(" < ").append(rc.getSecondName()).append(".").append(rc.getSecondField());
                } else if (rc.getOperationType().equalsIgnoreCase(OperationEnum.LTE.getValue())) {
                    sb.append(rc.getFirstName()).append(".").append(rc.getFirstField()).append(" <= ").append(rc.getSecondName()).append(".").append(rc.getSecondField());
                } else if (rc.getOperationType().equalsIgnoreCase(OperationEnum.GT.getValue())) {
                    sb.append(rc.getFirstName()).append(".").append(rc.getFirstField()).append(" > ").append(rc.getSecondName()).append(".").append(rc.getSecondField());
                } else if (rc.getOperationType().equalsIgnoreCase(OperationEnum.GTE.getValue())) {
                    sb.append(rc.getFirstName()).append(".").append(rc.getFirstField()).append(" >= ").append(rc.getSecondName()).append(".").append(rc.getSecondField());
                } else if (rc.getOperationType().equalsIgnoreCase(OperationEnum.LIKE.getValue())) {
                    // sb.append(rc.getFirstName()).append(".").append(rc.getFirstField()).append(" >= ").append(rc.getSecondName()).append(".").append(rc.getSecondField());
                    log.error("关联告警模型比较条件未识别0=" + JSON.toJSONString(rc));
                } else {
                    log.error("关联告警模型比较条件未识别1=" + JSON.toJSONString(rc));
                    return "";
                }
                if (index != relationConditions.size() - 1) {
                    sb.append(" and ");
                }
                index++;
            }
            return sb.toString();
        } catch (Exception e) {
            log.error("关联告警模型比较条件解析失败");
            log.error(e.getMessage(), e);
        }
        return "";
    }

    /**
     * 根据子集结果组装查询SQL
     * @param groupTableMap 子集结果
     * @param where where条件
     * @return SQL
     */
    public static String getRelationSql(Map<String, RelGroupTable> groupTableMap, String where) {
        if (groupTableMap.size() < 1) {
            log.error("子集数据为空！");
            return "";
        }
        StringBuilder fields = new StringBuilder();
        StringBuilder tables = new StringBuilder();
        final int[] index = {0};
        AtomicBoolean flag = new AtomicBoolean(false);
        groupTableMap.forEach((k,v)->{
            if (StringUtils.isBlank(v.getTableName())) {
                flag.set(true);
                return;
            }
            if(!StringUtils.isBlank(v.getSelectCol())) {
                fields.append(v.getSelectCol());
            }
            tables.append(v.getTableName()).append(" ").append(v.getGroupName());
            if (index[0] != groupTableMap.size() - 1) {
                if(!StringUtils.isBlank(v.getSelectCol())) {
                    fields.append(",");
                }
                tables.append(",");
            }
            index[0]++;
        });
        if (flag.get()) {
            return null;
        }
        return "select " + fields + " from " + tables + " where " + where;
    }
}
