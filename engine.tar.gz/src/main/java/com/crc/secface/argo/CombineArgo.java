package com.crc.secface.argo;

import com.alibaba.fastjson.JSONObject;
import com.crc.common.constants.LogConstants;
import com.crc.common.constants.LogConstantsX;
import com.crc.common.utils.IpUtils;
import com.crc.common.utils.JsonUtils;
import com.crc.common.utils.Md5Utils;
import com.crc.secface.entity.RelationId;
import com.crc.secface.entity.TbEventModel;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;

import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.ConcurrentHashMap;

/**
 * 日志合并算法
 */
@Slf4j
public class CombineArgo {
    public ConcurrentHashMap<String, JSONObject> dataMap = new ConcurrentHashMap<>();
    static int MAX_COMBINE_NUM = 20;//单批次同类事件最大合并梳理

    /**
     * 获取Key，src_ip + log_name + product
     * 合并dest_ip,dest_port,log_start_time,log_end_time
     *
     * @return
     */
    public String getKey(JSONObject msg, TbEventModel model) {
        String srcIp = JsonUtils.getStr(msg, LogConstants.SRC_IP_TAG);
        String product = JsonUtils.getStr(msg, LogConstants.PRODUCT_TAG);
        String logName = JsonUtils.getStr(msg, LogConstantsX.LOG_NAME);
        return Md5Utils.hash(product + "#" + srcIp + "#" + logName);
    }


    public String getCommandKey(JSONObject msg) {
        String srcIp = JsonUtils.getStr(msg, LogConstants.SRC_IP_TAG);
        //String logTime = JsonUtils.getStr(msg, LogConstants.SPARK_TIME_TAG);
        String product = JsonUtils.getStr(msg, LogConstants.PRODUCT_TAG);
        String description = JsonUtils.getStr(msg, LogConstantsX.ALERT_NAME);
        String commandIndex = JsonUtils.getStr(msg, LogConstantsX.COMMAND_INDEX);
        return product + "#" + srcIp + "#" + description + "#" + commandIndex;
    }


    public int getLogCount(JSONObject data) {
        int c = JsonUtils.getInt(data, LogConstantsX.LOG_COUNT);
        if (c > 0) {
            return c;
        }
        return 1;
    }

    /**
     * 数据融合
     *
     * @param data 模型
     */
    public void addRelationData(JSONObject data, TbEventModel model) {
        String id = getKey(data, model);
        if (!dataMap.containsKey(id)) {
            data.put("times", getLogCount(data));
            dataMap.put(id, data);
        } else {
            JSONObject src = dataMap.get(id);
            int times = JsonUtils.getInt(src, "times");
            if (times < 1) {
                times = 1;
            }
            src.put("times", (times + getLogCount(data)));
            //hejs 超过100，Id不合并
            if (times < MAX_COMBINE_NUM) {
                try {
                    List<RelationId> list1 = getIdList(data, "ids");
                    List<RelationId> list2 = getIdList(src, "ids");
                    list2.addAll(list1);
                    src.put("ids", list2);
                } catch (Exception ignored) {

                }
            }
            combineAttr(src, data, LogConstants.DEST_IP_TAG, true);  //缺少去重算法
            combineAttr(src, data, LogConstantsX.LOG_START_TIME, false);
            combineAttr(src, data, LogConstantsX.LOG_END_TIME, false);
            combineAttr(src, data, LogConstantsX.DEST_PORT, false);
        }
    }

    public List<RelationId> getIdList(JSONObject data, String filter) {
        try {
            return (List<RelationId>) data.get(filter);
        } catch (Exception ignored) {

        }
        return new ArrayList<>();
    }

    /**
     * 数据融合
     *
     * @param data 模型
     */
    public void addData(JSONObject data, TbEventModel model) {
        String id = getKey(data, model);
        if (!dataMap.containsKey(id)) {
            data.put("times", getLogCount(data));
            dataMap.put(id, data);
        } else {
            JSONObject src = dataMap.get(id);
            int times = JsonUtils.getInt(data, "times");
            if (times < 1) {
                times = 1;
            }
            src.put("times", (times + getLogCount(data)));
            //hejs 超过100，Id不合并
            if (times < MAX_COMBINE_NUM)
                combineAttr(src, data, "ids", false);
            combineAttr(src, data, LogConstants.DEST_IP_TAG, true);  //缺少去重算法
            combineAttr(src, data, LogConstantsX.LOG_START_TIME, false);
            combineAttr(src, data, LogConstantsX.LOG_END_TIME, false);
            combineAttr(src, data, LogConstantsX.DEST_PORT, false);
        }
    }

    public void addCommandEventData(JSONObject data) {
        String id = getCommandKey(data);
        if (!dataMap.containsKey(id)) {
            data.put("times", getLogCount(data));
            dataMap.put(id, data);
        } else {
            JSONObject src = dataMap.get(id);
            int times = JsonUtils.getInt(data, "times");
            if (times < 1) {
                times = 1;
            }
            src.put("times", (times + getLogCount(data)));
            //hejs 超过100，Id不合并
            if (times < MAX_COMBINE_NUM)
                combineAttr(src, data, "ids", false);
            combineAttr(src, data, LogConstants.DEST_IP_TAG, true);  //缺少去重算法
            combineAttr(src, data, LogConstantsX.LOG_END_TIME, false);
            combineAttr(src, data, LogConstantsX.DEST_PORT, false);
        }
    }

    //  public

    /**
     * 合并属性
     *
     * @param src
     * @param dest
     * @param filter
     */
    public void combineAttr(JSONObject src, JSONObject dest, String filter, boolean isIp) {
        String srcFilter = getString(src, filter);
        String destFilter = getString(dest, filter);
        if (LogConstantsX.LOG_START_TIME.equals(filter)) {
            int pos = srcFilter.indexOf(".");
            if (pos != -1) {
                srcFilter = srcFilter.substring(0, pos);
            }
            pos = destFilter.indexOf(".");
            if (pos != -1) {
                destFilter = destFilter.substring(0, pos);
            }
        }
        if (isIp) {
            if (StringUtils.isBlank(srcFilter)) {
                src.put(filter, destFilter);
            } else {
                for (String ip : srcFilter.split(",")) {
                    if (ip.equalsIgnoreCase(destFilter) || !IpUtils.isIp(ip))
                        return;
                }
                if (StringUtils.isNotBlank(destFilter)) {
                    src.put(filter, srcFilter + "," + destFilter);
                }
            }
        } else {
            if (StringUtils.isBlank(srcFilter)) {
                src.put(filter, destFilter);
            } else {
                for (String ip : srcFilter.split(",")) {
                    if (ip.equalsIgnoreCase(destFilter))
                        return;
                }
                if (StringUtils.isNotBlank(destFilter)) {
                    src.put(filter, srcFilter + "," + destFilter);
                }
            }
        }
//        System.out.println(getString(src, filter));
    }


    private String getString(JSONObject json, String filter) {
        if (json.containsKey(filter)) {
            String str = json.getString(filter);
            if (StringUtils.isBlank(str))
                return "";
            return str.trim();
        }
        return "";
    }

    public boolean isEmptyData() {
        return dataMap == null || dataMap.size() == 0;
    }

    public ConcurrentHashMap<String, JSONObject> getDataMap() {
        return dataMap;
    }
}
