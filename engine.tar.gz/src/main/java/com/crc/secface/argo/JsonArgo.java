package com.crc.secface.argo;

import com.alibaba.fastjson.JSONObject;
import com.crc.common.constants.LogConstantsX;
import com.crc.common.constants.MySQLDataTypeEnum;
import com.crc.common.utils.DataUtils;
import com.crc.common.utils.IdGen;
import com.crc.common.utils.IpUtils;
import com.crc.common.utils.JsonUtils;
import com.crc.secface.config.EsDataSource;
import com.crc.secface.entity.TbEventModel;
import com.crc.secface.es.SqliteTool;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;

import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import static com.crc.common.utils.DataUtils.escapeSpecialChar;


/**
 * JSON算法类
 */
@Slf4j
public class JsonArgo {
    /**
     * 返回表名称
     *
     * @param model     模型
     * @param groupName 关联子集名称 A1 A2
     * @param jsonList  关联子集内容数据
     */
    public static String batchSaveJsonDataJdbcWithNeedColumn(TbEventModel model, String groupName, List<JSONObject> jsonList, EsDataSource esDataSource, Map<String, String> colMap) {
        String tableStr = model.getModelId() + "_" + IdGen.uuid();
        String tableName = DataUtils.humpToLine(tableStr.toLowerCase(Locale.ROOT).replace("-", "_"));
        if (jsonList.size() < 1) {
            log.error("关联子集" + groupName + "没有数据");
            return "";
        }
        if (colMap.size() < 1) {
            log.error("关联子集" + groupName + "获取创建数据库表字段列表失败");
            return "";
        }
        //获取创建数据库表脚本
        String createTableSql = JsonToSql.getCreateTableSql(colMap, tableName);
        if (StringUtils.isBlank(createTableSql)) {
            log.error("关联子集" + groupName + "获取创建数据库表脚本失败");
            return "";
        }
        StringBuilder sql = new StringBuilder("insert into " + tableName + " (" + JsonToSql.getSelectColX(colMap) + " )  values");
        try {
            if(SqliteTool.getSqlController().excuteSql(createTableSql, stmt -> { })) {
                log.info("创建表：{}", createTableSql);
                long begin = System.currentTimeMillis();
                for (int i = 0; i < jsonList.size(); i++) {
                    sql.append("(");
                    final int[] index = {0};
                    JSONObject json = jsonList.get(i);
                    colMap.forEach((k, v) -> {
                        try {
                            if (v.equalsIgnoreCase(MySQLDataTypeEnum.BIGINT.getValue()) || v.equalsIgnoreCase(MySQLDataTypeEnum.INT.getValue()) || v.equalsIgnoreCase(MySQLDataTypeEnum.FLOAT.getValue()) || v.equalsIgnoreCase(MySQLDataTypeEnum.DOUBLE.getValue())) {
                                sql.append(json.get(k));
                            } else if (v.equalsIgnoreCase(MySQLDataTypeEnum.TEXT.getValue()) || v.equalsIgnoreCase(MySQLDataTypeEnum.VARCHAR.getValue())) {
                                if (k.equals("_index")) {
                                    sql.append("'").append(esDataSource.getIndexRule()).append("'");
                                } else {
                                    sql.append("'").append(getStrNow(escapeSpecialChar(getString(json, k)))).append("'");
                                }
                            } else if (v.equalsIgnoreCase(MySQLDataTypeEnum.DATE.getValue())) {
                                String date = JsonUtils.getDateStr(json, k);
                                if (StringUtils.isBlank(JsonUtils.getDateStr(json, k))) {
                                    sql.append("null");
                                } else {
                                    sql.append("'").append(date).append("'");
                                }
                            } else {
                                sql.append("'").append(getStrNow(escapeSpecialChar(getString(json, k)))).append("'");
                            }
                            if (index[0] != colMap.size() - 1) {
                                sql.append(",");
                            }
                            index[0]++;
                        } catch (Exception e) {
                            throw new RuntimeException(e);
                        }
                    });
                    sql.append(")");
                    if (i != jsonList.size() - 1) {
                        sql.append(",");
                    }
                }

                SqliteTool.getSqlController().excuteSql(sql.toString(), stmt -> {
                });
                long end = System.currentTimeMillis();
                log.info(model.getModelId() + " " + groupName + " 批量插入" + jsonList.size() + ",耗时" + (end - begin) + "ms");
            }
        } catch (Exception e) {
            log.error(model.getModelId() + " " + e.getMessage(), e);
            log.error("关联子集" + groupName + "创建批量插入数据失败");
            return "";
        }

        return tableName;
    }

    /**
     * 返回表名称
     *
     * @param model     模型
     * @param groupName 关联子集名称 A1 A2
     * @param jsonList  关联子集内容数据
     */
    public static String batchSaveJsonDataJdbcWithNeedColumn(TbEventModel model, String groupName, List<JSONObject> jsonList, Map<String, String> colMap) {
        String tableStr = model.getModelId() + "_" + IdGen.uuid();
        String tableName = DataUtils.humpToLine(tableStr.toLowerCase(Locale.ROOT).replace("-", "_"));
        if (jsonList.size() < 1) {
            log.error("关联子集" + groupName + "没有数据");
            return "";
        }
        if (colMap.size() < 1) {
            log.error("关联子集" + groupName + "获取创建数据库表字段列表失败");
            return "";
        }
        //获取创建数据库表脚本
        String createTableSql = JsonToSql.getCreateTableSql(colMap, tableName);
        if (StringUtils.isBlank(createTableSql)) {
            log.error("关联子集" + groupName + "获取创建数据库表脚本失败");
            return "";
        }
        StringBuilder sql = new StringBuilder("insert into " + tableName + " (" + JsonToSql.getSelectColX(colMap) + " )  values");
        try {
            SqliteTool.getSqlController().excuteSql(createTableSql, stmt -> { });
            log.info("创建表：{}", createTableSql);

            long begin = System.currentTimeMillis();
            for (int i = 0; i < jsonList.size(); i++) {
                sql.append("(");
                final int[] index = {0};
                JSONObject json = jsonList.get(i);
                colMap.forEach((k, v) -> {
                    try {
                        if (v.equalsIgnoreCase(MySQLDataTypeEnum.BIGINT.getValue()) || v.equalsIgnoreCase(MySQLDataTypeEnum.INT.getValue()) || v.equalsIgnoreCase(MySQLDataTypeEnum.FLOAT.getValue()) || v.equalsIgnoreCase(MySQLDataTypeEnum.DOUBLE.getValue())) {
                            sql.append(json.get(k));
                        } else if (v.equalsIgnoreCase(MySQLDataTypeEnum.TEXT.getValue()) || v.equalsIgnoreCase(MySQLDataTypeEnum.VARCHAR.getValue())) {
                            sql.append("'").append(getStrNow(escapeSpecialChar(getString(json, k)))).append("'");
                        } else if (v.equalsIgnoreCase(MySQLDataTypeEnum.DATE.getValue())) {
                            String date = JsonUtils.getDateStr(json, k);
                            if (StringUtils.isBlank(JsonUtils.getDateStr(json, k))) {
                                sql.append("null");
                            } else {
                                sql.append("'").append(date).append("'");
                            }
                        } else {
                            sql.append("'").append(getStrNow(escapeSpecialChar(getString(json, k)))).append("'");
                        }
                        if (index[0] != colMap.size() - 1) {
                            sql.append(",");
                        }
                        index[0]++;
                    } catch (Exception e) {
                        throw new RuntimeException(e);
                    }
                });
                sql.append(")");
                if (i != jsonList.size() - 1) {
                    sql.append(",");
                }
            }

            SqliteTool.getSqlController().excuteSql(sql.toString(), stmt -> { });
            long end = System.currentTimeMillis();
            log.info(model.getModelId() + " " + groupName + " 批量插入" + jsonList.size() + ",耗时" + (end - begin) + "ms");

        } catch (Exception e) {
            log.error(model.getModelId() + " " + e.getMessage(), e);
            log.error("关联子集" + groupName + "创建批量插入数据失败");
            return "";
        }

        return tableName;
    }

    private static String getStrNow(String str) {
        return str;
    }

    /**
     * 返回表名称
     *
     * @param model     模型
     * @param groupName 关联子集名称 A1 A2
     * @param jsonList  关联子集内容数据
     */
    public static String batchSaveJsonDataJdbc(TbEventModel model, String groupName, List<JSONObject> jsonList) {
        if (jsonList.size() < 1) {
            log.error("关联子集" + groupName + "没有数据");
            return "";
        }
        JSONObject oneJson = jsonList.get(0);
        //获取创建数据库表字段列表
        Map<String, String> colMap = JsonToSql.parseColumnTypeMap(oneJson);
        if (jsonList.size() > 3) {
            //随机抽多几个，怕数据字段不够
            colMap.putAll(JsonToSql.parseColumnTypeMap(jsonList.get(jsonList.size() / 2)));
            colMap.putAll(JsonToSql.parseColumnTypeMap(jsonList.get(jsonList.size() - 1)));
        }
        if (colMap.size() < 1) {
            log.error("关联子集" + groupName + "获取创建数据库表字段列表失败");
            return "";
        }
        return batchSaveJsonDataJdbcWithNeedColumn(model, groupName, jsonList, colMap);
    }

    private static String getString(JSONObject json, String k) {
        if (json == null) {
            return "";
        }
        String val = json.getString(k);
        if (StringUtils.isBlank(val) || "null".equalsIgnoreCase(val)) {
            return "";
        }
        return val.trim();
    }


    /**
     * 动态获取JSON内容
     *
     * @param oldContent 替换前内容
     * @param json       原始内容
     */
    public static String getDymContent(String oldContent, JSONObject json) {
        if (StringUtils.isBlank(oldContent)) {
            return "";
        }
        //遍历大括号
        try {
            if (oldContent.contains("}}")) {
                oldContent = oldContent.replace("}}", "}");
                oldContent = oldContent.replace("}}", "}");
            }
            if (oldContent.contains("{{")) {
                oldContent = oldContent.replace("{{", "{");
                oldContent = oldContent.replace("{{", "{");
            }
            String reg2 = "(\\{(.*?)})";
            Pattern pattern2 = Pattern.compile(reg2);
            Matcher matcher2 = pattern2.matcher(oldContent);
            String msg = oldContent;
            while (matcher2.find()) {
                String key = matcher2.group(1);
                String kevOne = key.replace("{", "").replace("}", "").replace(" ", "").trim();
                if (!json.containsKey(kevOne)) {
                    continue;
                }
                String val = JsonUtils.getStr(json, kevOne);
                if (StringUtils.isBlank(val)) {
                    msg = msg.replace(key, "");
                } else {
                    msg = msg.replace(key, val);
                }
            }
            return msg;
        } catch (Exception e) {
            log.error(e.getMessage(), e);
        }
        return oldContent.trim();
    }

    /**
     * 动态获取JSON 动态内容
     *
     * @param dymStr 表达式
     * @param json   原始内容
     */
    public static String getDymValue(String dymStr, JSONObject json) {
        return getDymValue(dymStr, json, null);
    }
    public static String getDymValue(String dymStr, JSONObject json,TbEventModel model) {
        if (StringUtils.isBlank(dymStr)) {
            return "";
        }
        if (IpUtils.isIp(dymStr)) {
            return dymStr;
        }
        //遍历大括号
        try {
            if (dymStr.contains("}}")) {
                dymStr = dymStr.replace("}}", "}");
                dymStr = dymStr.replace("}}", "}");
            }
            if (dymStr.contains("{{")) {
                dymStr = dymStr.replace("{{", "{");
                dymStr = dymStr.replace("{{", "{");
            }
            //System.out.println(dymStr);
            String reg2 = "(\\{(.*?)})";
            Pattern pattern2 = Pattern.compile(reg2);
            Matcher matcher2 = pattern2.matcher(dymStr);
            String msg = dymStr;
            while (matcher2.find()) {
                String key = matcher2.group(1);
                String kevOne = key.replace("{", "").replace("}", "").replace(" ", "").trim();
                kevOne = kevOne.replace(".keyword", "");
                kevOne = kevOne.replace(".keyword", "");
                if (kevOne.contains(".")) {
                    String[] ks = kevOne.split("\\.");
                    if (ks.length > 2) {
                        kevOne = String.format("%s.%s", ks[0], ks[1]);
                    }
                }
                kevOne = kevOne.replace(".", "_");
                String val = JsonUtils.getStr(json, kevOne);
                if (StringUtils.isEmpty(val)) {
                    val = JsonUtils.getStr(json, kevOne.toLowerCase());
                }
                if (model != null && LogConstantsX.LOG_PRODUCT.equalsIgnoreCase(kevOne)) {
                    val = AlarmUtils.getDeviceName(json, model);
                }
                if (StringUtils.isBlank(val)) {
                    msg = msg.replace(key, "");
                } else {
                    msg = msg.replace(key, val);
                }
            }
            return msg;
        } catch (Exception e) {
            log.error(e.getMessage(), e);
        }
        return dymStr.trim();
    }

    public static void main(String[] args) {
        String str = "{A1.dest_ip.keyword}";
        String pattern = "\\{+([A-Z0-9a-z]+\\.([_.\\w]+(.keyword)*))\\}+";
        Pattern r = Pattern.compile(pattern);
        Matcher m = r.matcher(str);
        while (m.find()) {
            System.out.println(m.group(1));
            System.out.println(m.group(2));
        }
    }

}
