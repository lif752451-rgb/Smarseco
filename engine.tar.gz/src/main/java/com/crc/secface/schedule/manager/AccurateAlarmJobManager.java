package com.crc.secface.schedule.manager;

import com.crc.common.utils.CronUtils;
import com.crc.secface.entity.TbEventModel;
import lombok.extern.slf4j.Slf4j;
import org.quartz.*;
import org.quartz.impl.StdSchedulerFactory;

import java.util.concurrent.ConcurrentHashMap;

@Slf4j
public class AccurateAlarmJobManager {
    public static String GROUP_NAME = "accurate_group";
    public static String KEY_NAME = "accurate_data";
    public static ConcurrentHashMap<String, TbEventModel> tempMap = new ConcurrentHashMap<>();

    public static void deleteJob(TbEventModel model) {
        try {
            JobKey jk = JobKey.jobKey(model.getModelId(), GROUP_NAME);
            Scheduler scheduler = StdSchedulerFactory.getDefaultScheduler();
            scheduler.deleteJob(jk);
            log.info("delete Job {} == {}", model.getModelName(), model.getModelId());
        } catch (Exception e) {
            log.error(e.getMessage(), e);
        }
    }

    public static void startJob(TbEventModel model) {
        JobDetail job = JobBuilder.newJob(com.crc.secface.schedule.task.AccurateAlarmSyncTask.class).withIdentity(model.getModelId(), GROUP_NAME).build();
        job.getJobDataMap().put(KEY_NAME, model);
        try {
            String cron = CronUtils.getCron(model);
            Trigger trigger = TriggerBuilder
                    .newTrigger()
                    .withSchedule(CronScheduleBuilder.cronSchedule(cron)).build();
            Scheduler scheduler = StdSchedulerFactory.getDefaultScheduler();
            scheduler.scheduleJob(job, trigger);
            if (!scheduler.isStarted()) {
                scheduler.start();
            }
            tempMap.put(model.getModelId(), model);
            log.info("启动精确告警分析 " + model.getModelName() + " " + model.getModelId() + " --> " + cron);
        } catch (Exception e) {
            log.error(model.getModelId() + " @@ " + e.getMessage(), e);
            deleteJob(model);
        }
    }
}
