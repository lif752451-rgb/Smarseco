package com.crc.secface.schedule.task;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;
import com.crc.SpringbootApplication;
import com.crc.common.constants.MySQLDataTypeEnum;
import com.crc.common.constants.LogConstantsX;
import com.crc.common.constants.MessageEnum;
import com.crc.common.paser.KqlParser;
import com.crc.common.paser.KqlResult;
import com.crc.common.paser.TreeParser;
import com.crc.common.utils.*;
import com.crc.secface.argo.*;
import com.crc.secface.config.EsDataSource;
import com.crc.secface.config.GetSpringBean;
import com.crc.secface.config.SyncSecConfig;
import com.crc.secface.entity.*;
import com.crc.secface.es.EsSingleFactory;
import com.crc.secface.es.SqliteTool;
import com.crc.secface.exception.CustomException;
import com.crc.secface.mapper.CommonMapper;
import com.crc.secface.mapper.TbAssetMapper;
import com.crc.secface.mapper.TbOriDangerEventMapper;
import com.crc.secface.schedule.manager.RelationAlarmJobManager;
import com.crc.secface.service.WhitelistService;
import com.crc.sync.send.SendEventExecutor;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.elasticsearch.action.search.SearchRequest;
import org.elasticsearch.action.search.SearchResponse;
import org.elasticsearch.client.RequestOptions;
import org.elasticsearch.client.RestHighLevelClient;
import org.elasticsearch.index.query.BoolQueryBuilder;
import org.elasticsearch.index.query.QueryBuilders;
import org.elasticsearch.index.query.RangeQueryBuilder;
import org.elasticsearch.search.SearchHit;
import org.elasticsearch.search.builder.SearchSourceBuilder;
import org.elasticsearch.search.sort.FieldSortBuilder;
import org.elasticsearch.search.sort.SortOrder;
import org.quartz.*;
import org.springframework.util.CollectionUtils;

import java.util.Calendar;
import java.util.*;
import java.util.concurrent.*;
import java.util.concurrent.atomic.AtomicBoolean;
import java.util.concurrent.atomic.AtomicInteger;
import java.util.stream.Collectors;

/**
 * 关联告警分析
 */
@Slf4j
@DisallowConcurrentExecution
public class RelationAlarmSyncTask implements Job {
    @Override
    public void execute(JobExecutionContext context) throws JobExecutionException {
        if (!SyncSecConfig.isEnable("sync_sec_config", "send_rel_alarm")) {
            return;
        }
        JobDataMap map = context.getJobDetail().getJobDataMap();
        TbEventModel model = (TbEventModel) map.get(RelationAlarmJobManager.KEY_NAME);
        try {
            sync(model);
        } catch (Exception e) {
            log.error(e.getMessage(), e);
        }
    }

    private void sync(TbEventModel model) {
        try {
            //白名单
            modelAnalysis(model);
        } catch (Exception e) {
            log.error("规则模型[{}] 执行异常:{}", model.getModelName(), e);
        }
    }

    /**
     * 模型分析
     *
     * @param eventModel       模型
     */
    public void modelAnalysis(TbEventModel eventModel) {
        CommonMapper commonMapper = GetSpringBean.getBean(CommonMapper.class);
        String relationChild = eventModel.getRelationChild();
        Map<String, RelGroupTable> groupTableMap = new ConcurrentHashMap<>();
        AtomicBoolean goodFlag = new AtomicBoolean(true);
        String where = RelationArgo.getRelationWhere(eventModel);
        if (StringUtils.isBlank(where)) {
            log.error(eventModel.getModelId() + ",子集比较条件为空！请检查");
            return;
        }

        String dictValue = DictUtil.getDictValue("sync_sec_config", "relation_alarm_query_num");
        int totalNum = DataUtils.toInt(dictValue);
        if (totalNum < 1) {
            totalNum = 2000;
        } else if (totalNum > 5000) {//性能不佳，子集查询数量不超过5000
            totalNum = 5000;
        }
        dictValue = DictUtil.getDictValue("sync_sec_config", "relation_alarm_result_num");
        int limitNum = DataUtils.toInt(dictValue);
        if (limitNum < 1) {
            limitNum = 1000;
        } else if (limitNum > 2000) {//性能不佳，最终查询数量不超过5000
            limitNum = 2000;
        }
        String relationParams = eventModel.getRelationParams();
        List<RelationCondition> relationConditions = JSON.parseArray(relationParams, RelationCondition.class);
        List<String> firstName = relationConditions.stream().map(RelationCondition::getFirstName).collect(Collectors.toList());
        List<String> secondName = relationConditions.stream().map(RelationCondition::getSecondName).collect(Collectors.toList());
        secondName.addAll(firstName);

        /*
         * 模型子集
         */
        List<ModelQueryChildCondition> modelQueryChildConditionList = JSON.parseArray(relationChild, ModelQueryChildCondition.class);
        List<SqlQueryChildCondition> sqlQueryChildConditionList = JSON.parseArray(eventModel.getSqlQueryChild(), SqlQueryChildCondition.class);
        log.info(eventModel.getModelId() + " 存在子集数：" + modelQueryChildConditionList.size());
        List<Callable<Map<String, RelationData>>> modelList = new ArrayList<>();

        AtomicInteger num = new AtomicInteger();

        /*
         * 分析模型需要的字段属性
         */
        Map<String, String> headerMap = ModelFieldUtils.getFields(secondName, eventModel.getAlarmDesc());
        headerMap.putAll(ModelFieldUtils.getFields(secondName, eventModel.getEventName()));
        headerMap.putAll(ModelFieldUtils.getFields(secondName, eventModel.getDeviceName()));
        headerMap.putAll(ModelFieldUtils.getFields(secondName, eventModel.getSufferIp()));
        headerMap.putAll(ModelFieldUtils.getFields(secondName, eventModel.getAttackIp()));
        relationConditions.forEach((k) -> {
            headerMap.putAll(ModelFieldUtils.getFieldsX(k.getFirstField()));
            headerMap.putAll(ModelFieldUtils.getFieldsX(k.getSecondField()));
        });
        /*
         * 关联的模型子集查询线程
         */
        int finalTotalNum = totalNum;
        modelQueryChildConditionList.forEach(modelQueryChildCondition -> {
            Callable<Map<String, RelationData>> callable = () -> {
                String name = modelQueryChildCondition.getName();
                if (secondName.contains(name)) {
                    RelGroupTable relGroupTable = new RelGroupTable();
                    relGroupTable.setGroupName(name);
                    groupTableMap.put(name, relGroupTable);
                    SearchSourceBuilder sourceBuilder = new SearchSourceBuilder();
                    sourceBuilder.from(0);
                    sourceBuilder.size(finalTotalNum);
                    int opType = modelQueryChildCondition.getOperateType();
                    List<JSONObject> resultList = new ArrayList<>();
                    BoolQueryBuilder boolQueryBuilder = QueryBuilders.boolQuery();
                    try {
                        if (opType == 1) {
                            //规则树模式
                            BoolQueryBuilder boolQuery = TreeParser.toDsl(modelQueryChildCondition.getQueryContent().toString());
                            if (EsUtils.isBlankQuery(boolQuery)) {
                                goodFlag.set(false);
                                throw new CustomException(eventModel.getModelId() + " 子集=" + name + " " + MessageEnum.ALARM_MODEL_SUB_RULE_FORMAT_ERROR.getValue(),
                                        MessageEnum.ALARM_MODEL_SUB_RULE_FORMAT_ERROR.getKey());
                            }
                            boolQueryBuilder.filter(boolQuery);
                        } else if (opType == 2) {
                            //KQL模式
                            KqlParser parser = new KqlParser(eventModel.getModelId());
                            KqlResult result = parser.parse(modelQueryChildCondition.getQueryContent().toString());
                            if (result.getCode() == 0) {
                                if (EsUtils.isBlankQuery(result.getQuery())) {
                                    goodFlag.set(false);
                                    throw new CustomException(eventModel.getModelId() + " 子集=" + name + " " + MessageEnum.ALARM_MODEL_SUB_KQL_FORMAT_ERROR.getValue(),
                                            MessageEnum.ALARM_MODEL_SUB_KQL_FORMAT_ERROR.getKey());
                                }
                                boolQueryBuilder.filter(result.getQuery());
                            } else {
                                goodFlag.set(false);
                                throw new CustomException(eventModel.getModelId() + " 子集=" + name + " " + MessageEnum.ALARM_MODEL_SUB_RULE_FORMAT_ERROR.getValue(),
                                        MessageEnum.ALARM_MODEL_SUB_RULE_FORMAT_ERROR.getKey());
                            }
                        } else {
                            goodFlag.set(false);
                            log.error("子集名称为:{}的模型运算策略未知类型{}", name, eventModel.getModelId());
                        }
                    } catch (Exception e) {
                        goodFlag.set(false);
                        log.error(e.getMessage(), e);
                        throw new CustomException(eventModel.getModelId() + " 子集=" + name + " " + MessageEnum.ALARM_MODEL_RULE_FORMAT_ERROR.getValue(),
                                MessageEnum.ALARM_MODEL_RULE_FORMAT_ERROR.getKey());
                    }
                    boolean flag = false;
                    String[] timeValues = new String[2];
                    try {
                        timeValues = DateUtils.resolveTimeRangeByType(String.valueOf(modelQueryChildCondition.getQueryRangeUnit()),
                                modelQueryChildCondition.getQueryRange(), new Date());
                    } catch (Exception e) {
                        goodFlag.set(false);
                        log.error("子集名称为:{}的模型组装查询时间范围出错：{}", name, e);
                        flag = true;
                    }


                    if (checkData(modelQueryChildCondition) && StringUtils.isNotBlank(modelQueryChildCondition.getQueryContent().toString())) {
                        if (timeValues == null) {
                            flag = true;
                        }
                        if (flag) {
                            goodFlag.set(false);
                            throw new CustomException(eventModel.getModelId() + " 子集=" + name + " " + MessageEnum.ALARM_MODEL_TIME_CONFIG_ERROR.getValue(),
                                    MessageEnum.ALARM_MODEL_TIME_CONFIG_ERROR.getKey());
                        }

                        RangeQueryBuilder rangeQueryBuilder = QueryBuilders.rangeQuery(modelQueryChildCondition.getSortKey());
                        rangeQueryBuilder.gt(timeValues[1]);
                        rangeQueryBuilder.lte(timeValues[0]);
                        boolQueryBuilder.filter(rangeQueryBuilder);

                        sourceBuilder.query(boolQueryBuilder);
                    } else {
                        goodFlag.set(false);
                        throw new CustomException(eventModel.getModelId() + " 子集=" + name + " " + MessageEnum.ALARM_MODEL_RULE_FORMAT_ERROR.getValue(),
                                MessageEnum.ALARM_MODEL_RULE_FORMAT_ERROR.getKey());
                    }

                    sourceBuilder.sort(new FieldSortBuilder(modelQueryChildCondition.getSortKey()).order(SortOrder.DESC));
                    //sourceBuilder.trackTotalHits(true);
                    //sourceBuilder.size(10000);

                    EsDataSource esDataSource = EsEventModelUtils.logSourceCheck(eventModel, modelQueryChildCondition);
                    RestHighLevelClient client = null;
                    try {
                        client = EsSingleFactory.getInstance().getHighLevelClientHigh(esDataSource);
                        log.debug("子集名称为:{}的查询语句为:{}", name, sourceBuilder);
                        SearchRequest request = new SearchRequest(esDataSource.getIndexRule());
                        request.source(sourceBuilder);
                        SearchResponse searchResponse = client.search(request, RequestOptions.DEFAULT);

                        for (SearchHit searchHit : searchResponse.getHits()) {
                            JSONObject json = JsonUtils.parse(searchHit.getSourceAsString());
                            json.put("_id", searchHit.getId());
                            resultList.add(json);
                        }
                        if (resultList.size() < 1) {
                            goodFlag.set(false);
                            throw new CustomException(eventModel.getModelId() + " 子集=" + name + " " + MessageEnum.ALARM_MODEL_NO_DATA_ERROR.getValue(),
                                    MessageEnum.ALARM_MODEL_NO_DATA_ERROR.getKey());
                        }
                    } catch (Exception e) {
                        goodFlag.set(false);
                        log.error("子集名称为:{}es查询错误：{}", eventModel.getModelId() + " " + name, e);
                    } finally {
                        EsSingleFactory.getInstance().close(client);
                    }
                    Map<String, RelationData> resultMap = new HashMap<>();
                    RelationData relationData = new RelationData();
                    relationData.setDataList(resultList);
                    relationData.setEsDataSource(esDataSource);
                    resultMap.put(name, relationData);
                    num.incrementAndGet();
                    return resultMap;
                }
                return null;
            };
            modelList.add(callable);
        });

        ThreadPoolExecutor threadPoolExecutor = GetSpringBean.getBean(ThreadPoolExecutor.class);
        CountDownLatch count = new CountDownLatch(modelList.size());
        List<Future<Map<String, RelationData>>> futures = null;
        try {
            futures = threadPoolExecutor.invokeAll(modelList);
            if (null != futures) {
                for (Future<Map<String, RelationData>> mapFuture : futures) {
                    Map<String, RelationData> relationDataMap = null;
                    try {
                        relationDataMap = mapFuture.get();
                    } catch (Exception e) {
                        log.error("模型子集线程池获取执行结果集失败：{}", e.getMessage(), e);
                        count.countDown();
                    }
                    if (null != relationDataMap && relationDataMap.size() > 0 && goodFlag.get()) {
                        Map<String, RelationData> finalStringListMap = relationDataMap;
                        new Thread(() -> {
                            finalStringListMap.forEach((k, v) -> {
                                try {
                                    log.info(eventModel.getModelId() + " 子集：" + k + " 获取数量：" + v.getDataList().size());
                                    if (v.getDataList().size() > 0) {
                                        JSONObject oneJson = v.getDataList().get(0);
                                        //获取创建数据库表字段列表
                                        Map<String, String> colMap = JsonToSql.parseColumnTypeMap(oneJson);
                                        if (v.getDataList().size() < 3) {
                                            //随机抽多几个，怕数据字段不够
                                            colMap.putAll(JsonToSql.parseColumnTypeMap(v.getDataList().get(v.getDataList().size() / 2)));
                                            colMap.putAll(JsonToSql.parseColumnTypeMap(v.getDataList().get(v.getDataList().size() - 1)));
                                        }
                                        Map<String, String> needColMap = ModelFieldUtils.getNeedColMap(colMap, headerMap);
                                        needColMap.put("_id", MySQLDataTypeEnum.TEXT.getValue());
                                        needColMap.put("_index", MySQLDataTypeEnum.TEXT.getValue());
                                        String tableName = JsonArgo.batchSaveJsonDataJdbcWithNeedColumn(eventModel, k, v.getDataList(), v.getEsDataSource(), needColMap);
                                        if (StringUtils.isBlank(tableName) || "null".equalsIgnoreCase(tableName)) {
                                            throw new CustomException(eventModel.getModelId() + " 子集=" + k + " " + MessageEnum.ALARM_MODEL_SAVE_DATA_ERROR.getValue(),
                                                    MessageEnum.ALARM_MODEL_SAVE_DATA_ERROR.getKey());
                                        } else {
                                            groupTableMap.get(k).setSelectCol(JsonToSql.getSelectCol(needColMap, k));
                                            groupTableMap.get(k).setTableName(tableName);
                                            groupTableMap.get(k).setType("1");
                                            groupTableMap.get(k).setEsDataSource(v.getEsDataSource());
                                        }
                                    } else {
                                        throw new CustomException(eventModel.getModelId() + " 子集=" + k + " " + MessageEnum.ALARM_MODEL_NO_DATA_ERROR.getValue(),
                                                MessageEnum.ALARM_MODEL_NO_DATA_ERROR.getKey());
                                    }

                                } catch (Exception e) {
                                    log.error(e.getMessage(), e);
                                } finally {
                                    count.countDown();
                                    log.info(eventModel.getModelId() + "线程执行完成");
                                }
                            });
                        }).start();
                    } else if (null == relationDataMap || !goodFlag.get()) {
                        count.countDown();
                    }
                }
            }
        } catch (Exception e) {
            log.error("模型子集线程池获取执行结果集失败：{}", e.getMessage(), e);
            cleanTableData(groupTableMap);
            return;
        }

        /**
         * sql子集
         * 不涉及插入数据，只是查询
         * 所以主线程执行即可
         */
        sqlQueryChildConditionList.forEach(sqlQueryChildCondition -> {
            int type = sqlQueryChildCondition.getType();
            String name = sqlQueryChildCondition.getName();
            if (secondName.contains(name)) {
                String startTime = "";
                String endTime = "";
                if (type == 2) {
                    startTime = sqlQueryChildCondition.getStartTime();
                    endTime = sqlQueryChildCondition.getEndTime();
                } else if (type == 3) {
                    String fixedTime = sqlQueryChildCondition.getFixedTime().replaceAll("\\s*|\r|\n|\t", "");
                    Date date = new Date();
                    endTime = DateUtils.parseDateToStr(DateUtils.DATE_FORMAT_STRING1, date);
                    Calendar rightNow = Calendar.getInstance();
                    rightNow.setTime(date);
                    Date time = null;
                    int i = DataUtils.toInt(fixedTime);
                    rightNow.add(Calendar.MINUTE, -i);
                    time = rightNow.getTime();
                    startTime = DateUtils.parseDateToStr(DateUtils.DATE_FORMAT_STRING1, time);
                }
                String queryContent = sqlQueryChildCondition.getQueryContent();
                if (StringUtils.isNotEmpty(startTime) && StringUtils.isNotEmpty(endTime)) {
                    queryContent = queryContent.replaceAll("dateStart", "'" + startTime + "'")
                            .replaceAll("dateEnd", "'" + endTime + "'");
                    sqlQueryChildCondition.setQueryContent(queryContent);
                }

                if (StringUtils.isBlank(queryContent) || !queryContent.toLowerCase().contains("select")) {
                    goodFlag.set(false);
                    throw new CustomException(eventModel.getModelId() + MessageEnum.ALARM_MODEL_SUB_RULE_FORMAT_ERROR.getValue(),
                            MessageEnum.ALARM_MODEL_SUB_RULE_FORMAT_ERROR.getKey());
                }

                List<JSONObject> dataList = commonMapper.queryX("select * from (" + queryContent + " ) sss limit " + finalTotalNum);
                log.info("SQL子集名称为:{}的查询语句为:{}", name, queryContent);
                if (dataList.size() > 0) {
                    String tableName = JsonArgo.batchSaveJsonDataJdbc(eventModel, sqlQueryChildCondition.getName(), dataList);
                    if (StringUtils.isBlank(tableName)) {
                        goodFlag.set(false);
                        throw new CustomException(eventModel.getModelId() + MessageEnum.ALARM_MODEL_SAVE_DATA_ERROR.getValue(),
                                MessageEnum.ALARM_MODEL_SAVE_DATA_ERROR.getKey());
                    } else {
                        log.info(eventModel.getModelId() + " 子集：" + name + " 获取数量：" + dataList.size());
                        RelGroupTable relGroupTable = new RelGroupTable();
                        relGroupTable.setGroupName(name);
                        groupTableMap.put(name, relGroupTable);
                        JSONObject oneJson = dataList.get(0);
                        //获取创建数据库表字段列表
                        Map<String, String> colMap = JsonToSql.parseColumnTypeMap(oneJson);
                        colMap.put("crc_id",MySQLDataTypeEnum.TEXT.getValue());
                        groupTableMap.get(name).setSelectCol(JsonToSql.getSelectCol(colMap, name));
                        groupTableMap.get(name).setTableName(tableName);
                        groupTableMap.get(name).setType("2");
                    }
                } else {
                    goodFlag.set(false);
                    throw new CustomException(eventModel.getModelId() + " 子集=" + name + " " + MessageEnum.ALARM_MODEL_NO_DATA_ERROR.getValue(),
                            MessageEnum.ALARM_MODEL_NO_DATA_ERROR.getKey());
                }
            }
        });
        try {
            count.await();
        } catch (Exception e) {
            log.error(e.getMessage(), e);
        }
        String sql = RelationArgo.getRelationSql(groupTableMap, where);
        if (StringUtils.isBlank(sql) || !goodFlag.get()) {
            log.error(eventModel.getModelId() + ",查询关联数据失败");
            cleanTableData(groupTableMap);
            return;
        }
        sql = "select * from (" + sql + " ) sss limit " + limitNum;
        log.info("最终查询SQL：" + sql);
        List<JSONObject> dataList = SqliteTool.getSqlController().excuteSqlAndGetData(sql, stmt -> {});
        log.info(eventModel.getModelId() + " 关联告警查询最终结果数据数量：" + dataList.size());

        processEvent(dataList, eventModel, groupTableMap);
        cleanTableData(groupTableMap);
    }


    /**
     * 处理合并告警数据
     *
     * @param curList          原始日志
     * @param model            模型
     * @param groupTableMap    子集配置信息
     */
    public void processEvent(List<JSONObject> curList, TbEventModel model,  Map<String, RelGroupTable> groupTableMap) {
        if (!CollectionUtils.isEmpty(curList)) {
            try {
                CombineArgo argo = new CombineArgo();
                for (JSONObject json : curList) {
                    JSONObject msg = new JSONObject();
                    msg.putAll(json);
                    JSONObject oriLog = msg.clone();
                    try {
                        /*
                         * DEST_IP IP去重
                         */
                        String srcIp = JsonArgo.getDymValue(model.getAttackIp(), oriLog);
                        if (StringUtils.isBlank(srcIp) || !IpUtils.isIp(srcIp)) {
                            msg.put(LogConstantsX.SRC_IP, "0.0.0.0");
                        } else {
                            msg.put(LogConstantsX.SRC_IP, srcIp);
                        }
                        String destIp = JsonArgo.getDymValue(model.getSufferIp(), oriLog);
                        if (StringUtils.isBlank(destIp) || !IpUtils.isIp(destIp)) {
                            msg.put(LogConstantsX.DEST_IP, "0.0.0.0");
                        } else {
                            msg.put(LogConstantsX.DEST_IP, destIp);
                        }

                        String eventName = JsonArgo.getDymValue(model.getEventName(),oriLog);

                        List<RelationId> idList = new ArrayList<>();
                        for (String k : groupTableMap.keySet()) {
                            RelGroupTable v = groupTableMap.get(k);
                            RelationId ido = new RelationId();
                            if ("1".equals(v.getType())) {
                                //ES
                                ido.setId(JsonUtils.getStr(json, String.format("%s_%s", v.getGroupName(), "_id")));
                                ido.setType(v.getType());
                                ido.setTableName(v.getTableName());
                                ido.setEsDataSource(v.getEsDataSource());
                            } else {
                                //MySQL
                                ido.setId(JsonUtils.getStr(json, String.format("%s_%s", v.getGroupName(), "crc_id")));
                                ido.setType(v.getType());
                                ido.setTableName(v.getTableName());
                            }
                            idList.add(ido);
                        }
                        msg.put("ids", idList);


                        if (model.getKeywordList() != null && StringUtils.isNotBlank(eventName)) {
                            for (SysDictData dictData : model.getKeywordList()) {
                                if (dictData.getDictLabel() != null) {
                                    if (eventName.contains(dictData.getDictLabel().trim())) {
                                        log.info("告警合并,model:{},事件：{},命中关键字{},不合并", model.getModelId(), eventName, dictData.getDictLabel());
                                        break;
                                    }
                                }
                            }
                        }
                        argo.addRelationData(msg, model);
                    } catch (Exception e) {
                        log.error(e.getMessage(), e);
                    }
                }
                if (argo.dataMap.size() > 0) {
                    log.info("[{}]-2合并完成,新增：{}", model.getModelId(), argo.dataMap.size());
                    try {
                        argo.dataMap.forEach((k, v) -> {
                            saveData(v, model, groupTableMap);
                        });
                    } catch (Exception e) {
                        log.error(e.getMessage(), e);
                    }
                }
            } catch (Exception e) {
                log.error(e.getMessage(), e);
            }
        }
    }


    public void saveData(JSONObject job, TbEventModel modelInfo,  Map<String, RelGroupTable> groupTableMap) {
        //log.info(modelInfo.getModelId() + ",获取告警：" + job.toJSONString());
        final String[] srcIp = {JsonArgo.getDymValue(modelInfo.getAttackIp(), job)};
        if (StringUtils.isBlank(srcIp[0])) {
            groupTableMap.forEach((k, v) -> {
                if (StringUtils.isBlank(srcIp[0])) {
                    srcIp[0] = JsonUtils.getStr(job, v.getGroupName() + "_" + LogConstantsX.SRC_IP);
                }
            });
        }

        String product = AlarmUtils.getDeviceName(job,modelInfo);
        if (StringUtils.isBlank(product)) {
            product = modelInfo.getDeviceName();
        }
        if (StringUtils.isNotBlank(product)) {
            job.put(LogConstantsX.LOG_PRODUCT, product);
            modelInfo.setDeviceNameStr(product);
        }
        String logName = modelInfo.getEventName();
        if (StringUtils.isNotBlank(logName)) {
            String eventName = logName;
            /*
             * 解析原始日志动态值
             */
            logName = JsonArgo.getDymValue(eventName, job);
        }
        if (StringUtils.isBlank(logName)) {
            logName = product + "告警";
        }
        String logType = modelInfo.getAttackTypeName();
        String logLevel = modelInfo.getEventLevelName();

        final String[] destIp = {JsonArgo.getDymValue(modelInfo.getSufferIp(), job)};
        if (StringUtils.isBlank(destIp[0])) {
            groupTableMap.forEach((k, v) -> {
                if (StringUtils.isBlank(destIp[0])) {
                    destIp[0] = JsonUtils.getStr(job, v.getGroupName() + "_" + LogConstantsX.DEST_IP);
                }
            });
        }
        String startTime = JsonUtils.getStr(job, LogConstantsX.LOG_START_TIME);
        if (StringUtils.isBlank(srcIp[0])) {
            srcIp[0] = JsonUtils.getStr(job, "dev_ip");
            job.put(LogConstantsX.SRC_IP, srcIp[0]);
        }
        if (StringUtils.isBlank(destIp[0])) {
            destIp[0] = "0.0.0.0";
        }
        if (srcIp[0].equalsIgnoreCase(destIp[0])) {
            log.warn(modelInfo.getModelId() + ",源IP={}和目标IP={}是一样的！为了合法逻辑使用0.0.0.0替换目标IP", srcIp[0], destIp[0]);
            destIp[0] = "0.0.0.0";
        }
        startTime = DateUtils.UTCToCSTAndCheck(startTime);
        if (StringUtils.isBlank(startTime)) {
            startTime = DateUtils.UTCToCST(JsonUtils.getStr(job, LogConstantsX.LOG_TIME));
        }
        job.put(LogConstantsX.LOG_START_TIME, startTime);
        String eventDesc = JsonArgo.getDymValue(modelInfo.getAlarmDesc(), job);
        if (StringUtils.isEmpty(eventDesc)) {
            eventDesc = JsonUtils.getStr(job, LogConstantsX.LOG_CONTENT);
            job.put(LogConstantsX.ALERT_NAME, eventDesc);
        } else {
            job.put(LogConstantsX.ALERT_NAME, eventDesc);
        }
        String actionResult = JsonUtils.getStr(job, LogConstantsX.ACTION_RESULT);
        TbAssetMapper tbAssetMapper = GetSpringBean.getBean(TbAssetMapper.class);
        long times = JsonUtils.getLong(job, "times");

        job.put(LogConstantsX.EVENT_TIME, startTime);
        job.put(LogConstantsX.ES_LOG_NAME, logName);
        job.put(LogConstantsX.LOG_NAME, logName);


        TbOriDangerEvent event = new TbOriDangerEvent();
        event.setId(IdGen.uuid());
        event.setAlertLevel(logLevel);
        event.setData(startTime);
        event.setTimes(times);
        event.setDelFlag(0);

        event.setEventDesc(eventDesc);
        event.setSrcIp(srcIp[0]);
        String whitelist = WhitelistService.isMatchV2(modelInfo, job, true) ? "1" : "0";
        event.setIsWhitelist(whitelist);
        if ("1".equalsIgnoreCase(whitelist)) {
            //hejs 白名单过滤
            log.warn(modelInfo.getModelId() + " # " + srcIp[0] + " => " + destIp[0] + "命中白名单！" + eventDesc);
            return;
        }
        /*
         * 源IP没有的不发告警
         */
        if (StringUtils.isBlank(srcIp[0])) {
            return;
        }
        event.setDestIp(destIp[0]);
        event.setStatus("0");
        event.setEventScore(0L);
        event.setEventName(logName);
        job.put(LogConstantsX.IS_WHITELIST, whitelist);
        job.put(LogConstantsX.DEST_IP, destIp[0]);
        event.setEventTime(new Date());
        event.setProduct(product);
        event.setIpScore(0L);
        event.setEventType(logType);
        event.setActionResult(actionResult);
        event.setModelId(modelInfo.getModelId());

        /**
         * 相同IP 相同告警，时间间隔
         */
        long interval = 60 * 12;
        TbOriDangerEvent tbOriDangerEvent = new TbOriDangerEvent();
        tbOriDangerEvent.setSrcIp(event.getSrcIp());
        tbOriDangerEvent.setDestIp(event.getDestIp());
        tbOriDangerEvent.setEventName(logName);
        tbOriDangerEvent.setModelId(modelInfo.getModelId());
        TbOriDangerEventMapper oriDangerEventMapper = GetSpringBean.getBean(TbOriDangerEventMapper.class);
        TbOriDangerEvent eventSingle = oriDangerEventMapper.selectTbOriDangerByInfo(tbOriDangerEvent);
        boolean newEvent = false;
        if (eventSingle != null && StringUtils.isNotBlank(eventSingle.getId())) {
            long diff = (event.getEventTime().getTime() - eventSingle.getEventTime().getTime()) / 1000 / 60;
            // 根据eventTime判断时间是否在${alarmInterval}间隔内发送过告警，如果发送过则不再发送
            if (diff < interval) {
                log.info("配置间隔:" + interval + " 分钟，目前间隔：" + diff + " 分钟");
                log.info("已发送过:" + modelInfo.getModelId() + " " + eventSingle.getSrcIp() + " " + eventSingle.getDestIp());
                return;
            } else {
                if (event.getEventName() != null) {
                    event.setEventName(DataUtils.getShorter(event.getEventName(), 512));
                }
                oriDangerEventMapper.insertTbOriDangerEvent(event);
                newEvent = true;
            }
        } else {
            if (event.getEventName() != null) {
                event.setEventName(DataUtils.getShorter(event.getEventName(), 512));
            }
            oriDangerEventMapper.insertTbOriDangerEvent(event);
            newEvent = true;
        }
        if (newEvent) {
            /*
                 状态为 '研判/处置' 的一旦出现，则本条告警不推送；
                 */
            try {
                //String sql = "SELECT count(1) as total FROM tb_alarm_report WHERE order_status IN ('研判','处置') AND attack_ip = '%s' AND victimized_ip = '%s' AND title = '%s'";
                //String newSql = String.format(sql,event.getSrcIp(),event.getDestIp(),event.getEventName());
                SqlModel sqlModel = new SqlModel();
                sqlModel.setA1(event.getSrcIp());
                sqlModel.setA2(event.getDestIp());
                sqlModel.setA3(logName);
                int count = 0;
                if (CombatUtils.getCombatTime().isCombat()) {
                    count = tbAssetMapper.getProccessingAlarmCombatCount(sqlModel);
                } else {
                    count = tbAssetMapper.getProccessingAlarmCount(sqlModel);
                }
                if (count > 0) {
                    log.warn(modelInfo.getModelId() + " " + "工单存在相同告警，且未处置完毕！" + JSON.toJSONString(event));
                    return;
                }
            } catch (Exception e) {
                log.error(e.getMessage(), e);
            }
        }

        log.info("启动关联告警推送新线程,modelId:{}", modelInfo.getModelId());

        job.put(LogConstantsX.BUS_MODEL, modelInfo.getModelId());
        job.put(LogConstantsX.RISK_IP, IpUtils.getRiskIp(tbOriDangerEvent.getSrcIp(), tbOriDangerEvent.getDestIp(), tbOriDangerEvent.getSrcIp()));
        job.put(LogConstantsX.ORI_EVENT_ID, event.getId());
        //生产环境
        DangerEventSendModel dangerEventSend = new DangerEventSendModel();
        dangerEventSend.setModel(modelInfo);
        dangerEventSend.setEventId(event.getId());
        dangerEventSend.setEventJson(job);
        dangerEventSend.setSendOp(1);
        CombineArgo argo = new CombineArgo();
        dangerEventSend.setIdList(argo.getIdList(job, "ids"));
        SendEventExecutor.doSend(dangerEventSend);
    }


    public static boolean checkData(ModelQueryChildCondition vo) {
        return com.crc.common.utils.StringUtils.isNotBlank(vo.getSortKey()) && vo.getQueryRange() > 0
                && com.crc.common.utils.StringUtils.isNotBlank(String.valueOf(vo.getQueryRangeUnit())) && com.crc.common.utils.StringUtils.isNotBlank(vo.getEsIndexId());
    }


    public void cleanTableData(Map<String, RelGroupTable> groupTableMap) {
        CommonMapper commonMapper = GetSpringBean.getBean(CommonMapper.class);
        /**
         * 删除临时表
         */
        groupTableMap.forEach((k, v) -> {
            String tablename = v.getTableName();
            if (StringUtils.isNotEmpty(tablename) && tablename.startsWith("ssp_")) {
                String sqlx = "drop table  " + tablename;
                if (!"T".equals(SpringbootApplication.OP_CONFIG.getMode())) {
                    log.info("删除临时表=" + sqlx);
                    SqliteTool.getSqlController().excuteSql(sqlx, stmt -> {});
                }

            }
        });
    }
}
