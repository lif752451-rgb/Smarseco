package com.crc.secface.schedule.task;

import cn.hutool.core.collection.CollUtil;
import cn.hutool.core.date.StopWatch;
import com.crc.common.utils.DataUtils;
import com.crc.common.utils.IdGen;
import com.crc.secface.config.SyncSecConfig;
import com.crc.secface.entity.AlarmIp;
import com.crc.secface.entity.InternetPublishApp;
import com.crc.secface.entity.TbAlarmCombatReport;
import com.crc.secface.entity.TbAlarmReport;
import com.crc.secface.mapper.InternetPublishAppMapper;
import com.crc.secface.mapper.TbAlarmReportMapper;
import com.crc.secface.response.AssetAsmInternetResponse;
import com.crc.secface.response.InternetPublishAppResponse;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.scheduling.annotation.EnableScheduling;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Component;

import java.util.*;
import java.util.stream.Collectors;

/**
 * @author jixiangqi
 * @date 2023/7/10
 * 定时刷新互联网发布到数据库
 */
@Slf4j
@Component
@EnableScheduling
public class FlushInternetData {

    @Autowired
    private InternetPublishAppMapper internetPublishAppMapper;

    @Autowired
    TbAlarmReportMapper alarmReportMapper;

    @Scheduled(cron = "0 0/30 * * * ?")
    //@Scheduled(cron = "00 29 14 * * ?")
    public void flushInternetData() {
        StopWatch stopWatch = new StopWatch();
        stopWatch.start();
        if (!SyncSecConfig.isEnable("sync_sec_config", "internet_app_alarm_enable")) {
            log.error("scp互联网发布定时任务字典状态为关闭，暂不执行");
            return;
        }
        try {
            internetPublishAppMapper.delDupData();
        } catch (Exception e) {
            log.error(e.getMessage(),e);
        }
        log.info("开始执行scp互联网发布定时任务");
        //查询出全部数据
        List<AssetAsmInternetResponse> list = internetPublishAppMapper.searchList();
        if (list.size() == 0) {
            log.info("获取到的互联网资产为空");
            return;
        }
        //计算互联网 IP
        /**
         * 计算实战化告警
         */
        List<String> ipList = list.stream().map(AssetAsmInternetResponse::getIp).distinct().collect(Collectors.toList());
        Map<String, List<AssetAsmInternetResponse>> alarmCombatReportMap = list.stream().collect(Collectors.groupingBy(AssetAsmInternetResponse::getIp));
        List<TbAlarmCombatReport> alarmCombatReports = alarmReportMapper.selectCombatListByInternetIp(ipList);
        Set<InternetPublishApp> insertCombatSet = new HashSet<>();
        for (int i = 0; i < alarmCombatReports.size(); i++) {
            TbAlarmCombatReport alarmReport = alarmCombatReports.get(i);
            String attackIp = alarmReport.getAttackIp();
            String victimizedIp = alarmReport.getVictimizedIp();
            String[] attackArray = DataUtils.getSplit(attackIp, ",");
            String[] victimizedArray = DataUtils.getSplit(victimizedIp, ",");
            List<String> attackList = Arrays.asList(attackArray);
            List<String> victimizedList = Arrays.asList(victimizedArray);
            List<String> ipCombatList = new ArrayList<>();
            if (CollUtil.isNotEmpty(attackList)) {
                ipCombatList.addAll(attackList);
            }
            if (CollUtil.isNotEmpty(victimizedList)) {
                ipCombatList.addAll(victimizedList);
            }

            for (int j = 0; j < ipCombatList.size(); j++) {
                String s = ipCombatList.get(j);
                if (alarmCombatReportMap.containsKey(s)) {
                    List<AssetAsmInternetResponse> asmInternetResponseList = alarmCombatReportMap.get(s);
                    for (int i1 = 0; i1 < asmInternetResponseList.size(); i1++) {
                        AssetAsmInternetResponse internetAlarmResponse = asmInternetResponseList.get(i1);
                        InternetPublishApp internetPublishApp = new InternetPublishApp();
                        internetPublishApp.setAffiliationDeptNodeId(internetAlarmResponse.getAffiliationDeptNodeId());
                        internetPublishApp.setAffiliationDeptName(internetAlarmResponse.getAffiliationDeptName());
                        internetPublishApp.setAssetId(internetAlarmResponse.getAssetId());
                        internetPublishApp.setIp(internetAlarmResponse.getIp());
                        internetPublishApp.setPort(internetAlarmResponse.getPort());
                        internetPublishApp.setDomainName(internetAlarmResponse.getDomainName());
                        internetPublishApp.setRelationIp(internetAlarmResponse.getIp());
                        internetPublishApp.setFightPeriodType(alarmReport.getFightPeriodType());
                        internetPublishApp.setAlarmId(alarmReport.getId());
                        internetPublishApp.setAlarmCode(alarmReport.getAlarmId());
                        internetPublishApp.setAlarmLevel(alarmReport.getLevel());
                        internetPublishApp.setAlarmTitle(alarmReport.getTitle());
                        internetPublishApp.setAttackResult(alarmReport.getAttackResult());
                        internetPublishApp.setAttackMeans(alarmReport.getAttackMeans());
                        internetPublishApp.setAttackCount(alarmReport.getAttackCount());
                        internetPublishApp.setAlarmTime(alarmReport.getAlarmTime());
                        internetPublishApp.setAlarmCreateTime(alarmReport.getCreateTime());
                        internetPublishApp.setOrderStatus(alarmReport.getOrderStatus());
                        internetPublishApp.setInternetId(internetAlarmResponse.getId());
                        internetPublishApp.setType(2);
                        internetPublishApp.setOrganizationId(String.valueOf(alarmReport.getOrganizationId()));
                        internetPublishApp.setId(IdGen.uuid());
                        internetPublishApp.setCreateTime(new Date());
                        internetPublishApp.setUpdateTime(new Date());
                        insertCombatSet.add(internetPublishApp);
                    }
                }
            }

        }
        if (CollUtil.isNotEmpty(insertCombatSet)) {
            List<InternetPublishAppResponse> repeatData = internetPublishAppMapper.getRepeatDataNew(insertCombatSet);
            if (CollUtil.isNotEmpty(repeatData)) {
                List<String> collect = repeatData.stream().map(InternetPublishAppResponse::getAssetCode).collect(Collectors.toList());
                Iterator<InternetPublishApp> it = insertCombatSet.iterator();
                while (it.hasNext()) {
                    InternetPublishApp next = it.next();
                    String assetId = next.getAssetId();
                    String alarmCode = next.getAlarmCode();
                    StringBuffer stringBuffer = new StringBuffer(assetId).append("-").append(alarmCode);
                    if (collect.contains(stringBuffer.toString())) {
                        it.remove();
                    }
                }
            }
        }
        //入库
        if (CollUtil.isNotEmpty(insertCombatSet)) {
            internetPublishAppMapper.insert(new ArrayList<>(insertCombatSet));
        }


        /**
         * 常态化告警
         */
        Set<InternetPublishApp> insertSet = new HashSet<>();
        List<TbAlarmReport> alarmReports = alarmReportMapper.selectListByInternetIp(ipList);
        for (int i = 0; i < alarmReports.size(); i++) {
            TbAlarmReport tbAlarmReport = alarmReports.get(i);
            String attackIp = tbAlarmReport.getAttackIp();
            String victimizedIp = tbAlarmReport.getVictimizedIp();
            String[] attackArray = DataUtils.getSplit(attackIp, ",");
            String[] victimizedArray = DataUtils.getSplit(victimizedIp, ",");
            List<String> attackList = Arrays.asList(attackArray);
            List<String> victimizedList = Arrays.asList(victimizedArray);
            List<String> ipCombatList = new ArrayList<>();
            if (CollUtil.isNotEmpty(attackList)) {
                ipCombatList.addAll(attackList);
            }
            if (CollUtil.isNotEmpty(victimizedList)) {
                ipCombatList.addAll(victimizedList);
            }
            for (int j = 0; j < ipCombatList.size(); j++) {
                String s = ipCombatList.get(j);
                if (alarmCombatReportMap.containsKey(s)) {
                    List<AssetAsmInternetResponse> asmInternetResponseList = alarmCombatReportMap.get(s);
                    for (int i1 = 0; i1 < asmInternetResponseList.size(); i1++) {
                        AssetAsmInternetResponse internetAlarmResponse = asmInternetResponseList.get(i1);
                        InternetPublishApp internetPublishApp = new InternetPublishApp();
                        internetPublishApp.setAffiliationDeptNodeId(internetAlarmResponse.getAffiliationDeptNodeId());
                        internetPublishApp.setAffiliationDeptName(internetAlarmResponse.getAffiliationDeptName());
                        internetPublishApp.setAssetId(internetAlarmResponse.getAssetId());
                        internetPublishApp.setIp(internetAlarmResponse.getIp());
                        internetPublishApp.setPort(internetAlarmResponse.getPort());
                        internetPublishApp.setDomainName(internetAlarmResponse.getDomainName());
                        internetPublishApp.setRelationIp(internetAlarmResponse.getIp());
                        internetPublishApp.setAlarmId(String.valueOf(tbAlarmReport.getId()));
                        internetPublishApp.setAlarmCode(tbAlarmReport.getAlarmId());
                        internetPublishApp.setAlarmLevel(tbAlarmReport.getLevel());
                        internetPublishApp.setAlarmTitle(tbAlarmReport.getTitle());
                        internetPublishApp.setAttackResult(tbAlarmReport.getAttackResult());
                        internetPublishApp.setAttackMeans(tbAlarmReport.getAttackMeans());
                        internetPublishApp.setAttackCount(tbAlarmReport.getAttackCount());
                        internetPublishApp.setAlarmTime(tbAlarmReport.getAlarmTime());
                        internetPublishApp.setAlarmCreateTime(tbAlarmReport.getCreateTime());
                        internetPublishApp.setOrderStatus(tbAlarmReport.getOrderStatus());
                        internetPublishApp.setInternetId(internetAlarmResponse.getId());
                        internetPublishApp.setType(1);
                        internetPublishApp.setOrganizationId(String.valueOf(tbAlarmReport.getOrganizationId()));
                        internetPublishApp.setId(IdGen.uuid());
                        internetPublishApp.setCreateTime(new Date());
                        internetPublishApp.setUpdateTime(new Date());
                        internetPublishApp.setCreateBy("task");
                        //log.info("常态化，互联网资产关联-> {}--{}",alarmIp.getAlarmId(),alarmIp.getSrcIp());
                        insertSet.add(internetPublishApp);
                    }

                }
            }
        }

        if (CollUtil.isNotEmpty(insertSet)) {
            List<InternetPublishAppResponse> repeatData = internetPublishAppMapper.getRepeatDataNew(insertSet);
            if (CollUtil.isNotEmpty(repeatData)) {
                List<String> collect = repeatData.stream().map(InternetPublishAppResponse::getAssetCode).collect(Collectors.toList());
                Iterator<InternetPublishApp> it = insertSet.iterator();
                while (it.hasNext()) {
                    InternetPublishApp next = it.next();
                    String assetId = next.getAssetId();
                    String alarmCode = next.getAlarmCode();
                    StringBuffer stringBuffer = new StringBuffer(assetId).append("-").append(alarmCode);
                    if (collect.contains(stringBuffer.toString())) {
                        it.remove();
                    }
                }
            }
        }
        if (CollUtil.isNotEmpty(insertSet)) {
            //入库
            internetPublishAppMapper.insert(new ArrayList<>(insertSet));
        }

        /*for (int i = 0; i < alarmCombatReports.size(); i++) {
            TbAlarmCombatReport tbAlarmCombatReport = alarmCombatReports.get(i);
            AlarmIp alarmIp = new AlarmIp();
            alarmIp.setSrcIp(internetAlarmResponse.getAssetId());
            alarmIp.setAlarmId(alarmReport.getAlarmId());
            List<InternetPublishAppResponse> tmpList = internetPublishAppMapper.getRepeatDataByAlarmNId(alarmIp);
            if (tmpList == null || tmpList.size() < 1) {
                InternetPublishApp internetPublishApp = new InternetPublishApp();
                internetPublishApp.setAffiliationDeptNodeId(internetAlarmResponse.getAffiliationDeptNodeId());
                internetPublishApp.setAffiliationDeptName(internetAlarmResponse.getAffiliationDeptName());
                internetPublishApp.setAssetId(internetAlarmResponse.getAssetId());
                internetPublishApp.setIp(internetAlarmResponse.getIp());
                internetPublishApp.setPort(internetAlarmResponse.getPort());
                internetPublishApp.setDomainName(internetAlarmResponse.getDomainName());
                internetPublishApp.setRelationIp(internetAlarmResponse.getIp());
                internetPublishApp.setFightPeriodType(alarmReport.getFightPeriodType());
                internetPublishApp.setAlarmId(alarmReport.getId());
                internetPublishApp.setAlarmCode(alarmReport.getAlarmId());
                internetPublishApp.setAlarmLevel(alarmReport.getLevel());
                internetPublishApp.setAlarmTitle(alarmReport.getTitle());
                internetPublishApp.setAttackResult(alarmReport.getAttackResult());
                internetPublishApp.setAttackMeans(alarmReport.getAttackMeans());
                internetPublishApp.setAttackCount(alarmReport.getAttackCount());
                internetPublishApp.setAlarmTime(alarmReport.getAlarmTime());
                internetPublishApp.setAlarmCreateTime(alarmReport.getCreateTime());
                internetPublishApp.setOrderStatus(alarmReport.getOrderStatus());
                internetPublishApp.setInternetId(internetAlarmResponse.getId());
                internetPublishApp.setType(2);
                internetPublishApp.setOrganizationId(String.valueOf(alarmReport.getOrganizationId()));
                internetPublishApp.setId(IdGen.uuid());
                internetPublishApp.setCreateTime(new Date());
                internetPublishApp.setUpdateTime(new Date());
                internetPublishApp.setCreateBy("task");
                log.info("作战周期，互联网资产关联-> {}--{}",alarmIp.getAlarmId(),alarmIp.getSrcIp());
                internetPublishAppMapper.insert(Collections.singletonList(internetPublishApp));
            }
        }*/
        /*for (AssetAsmInternetResponse internetAlarmResponse : list) {
            try {
                List<TbAlarmCombatReport> alarmList = alarmReportMapper.selectCombatListByInternetIp(internetAlarmResponse.getIp());
                if (alarmList != null && alarmList.size() > 0) {
                    for (TbAlarmCombatReport alarmReport : alarmList) {
                        c
                    }
                }
            } catch (Exception e) {
                log.error(e.getMessage(),e);
            }

            try {
                List<TbAlarmReport> alarmList = alarmReportMapper.selectListByInternetIp(internetAlarmResponse.getIp());
                if (alarmList != null && alarmList.size() > 0) {
                    for (TbAlarmReport alarmReport : alarmList) {
                        AlarmIp alarmIp = new AlarmIp();
                        alarmIp.setSrcIp(internetAlarmResponse.getAssetId());
                        alarmIp.setAlarmId(alarmReport.getAlarmId());
                        List<InternetPublishAppResponse> tmpList = internetPublishAppMapper.getRepeatDataByAlarmNId(alarmIp);
                        if (tmpList == null || tmpList.size() < 1) {
                            InternetPublishApp internetPublishApp = new InternetPublishApp();
                            internetPublishApp.setAffiliationDeptNodeId(internetAlarmResponse.getAffiliationDeptNodeId());
                            internetPublishApp.setAffiliationDeptName(internetAlarmResponse.getAffiliationDeptName());
                            internetPublishApp.setAssetId(internetAlarmResponse.getAssetId());
                            internetPublishApp.setIp(internetAlarmResponse.getIp());
                            internetPublishApp.setPort(internetAlarmResponse.getPort());
                            internetPublishApp.setDomainName(internetAlarmResponse.getDomainName());
                            internetPublishApp.setRelationIp(internetAlarmResponse.getIp());
                            internetPublishApp.setAlarmId(String.valueOf(alarmReport.getId()));
                            internetPublishApp.setAlarmCode(alarmReport.getAlarmId());
                            internetPublishApp.setAlarmLevel(alarmReport.getLevel());
                            internetPublishApp.setAlarmTitle(alarmReport.getTitle());
                            internetPublishApp.setAttackResult(alarmReport.getAttackResult());
                            internetPublishApp.setAttackMeans(alarmReport.getAttackMeans());
                            internetPublishApp.setAttackCount(alarmReport.getAttackCount());
                            internetPublishApp.setAlarmTime(alarmReport.getAlarmTime());
                            internetPublishApp.setAlarmCreateTime(alarmReport.getCreateTime());
                            internetPublishApp.setOrderStatus(alarmReport.getOrderStatus());
                            internetPublishApp.setInternetId(internetAlarmResponse.getId());
                            internetPublishApp.setType(1);
                            internetPublishApp.setOrganizationId(String.valueOf(alarmReport.getOrganizationId()));
                            internetPublishApp.setId(IdGen.uuid());
                            internetPublishApp.setCreateTime(new Date());
                            internetPublishApp.setUpdateTime(new Date());
                            internetPublishApp.setCreateBy("task");
                            log.info("常态化，互联网资产关联-> {}--{}",alarmIp.getAlarmId(),alarmIp.getSrcIp());
                            internetPublishAppMapper.insert(Collections.singletonList(internetPublishApp));
                        }
                    }
                }
            } catch (Exception e) {
                log.error(e.getMessage(),e);
            }
        }*/
        try {
            internetPublishAppMapper.delDupData();
        } catch (Exception e) {
            log.error(e.getMessage(),e);
        }
        log.info("结束执行scp互联网发布定时任务");
    }

}
