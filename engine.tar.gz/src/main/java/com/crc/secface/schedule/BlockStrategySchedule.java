package com.crc.secface.schedule;

import com.alibaba.fastjson.JSON;
import com.crc.common.utils.DateUtils;
import com.crc.common.utils.StringUtils;
import com.crc.secface.entity.IpPluggingScene;
import com.crc.secface.entity.TbIpPluggingStrategy;
import com.crc.secface.mapper.TbIpPluggingStrategyMapper;
import com.crc.secface.schedule.manager.IpPluggingStrategyJobManager;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.scheduling.annotation.EnableScheduling;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Component;

import java.util.HashMap;
import java.util.List;


/**
 * 告警引擎调度中心
 */
@Slf4j
@Component
@EnableScheduling
public class BlockStrategySchedule implements CommandLineRunner {
    @Autowired
    TbIpPluggingStrategyMapper tbIpPluggingStrategyMapper;

    @Scheduled(cron = "0 0/1 * * * ?")
    public void sync() {
        try {
            List<TbIpPluggingStrategy> strategyList = tbIpPluggingStrategyMapper.getList();
            sync(strategyList);
        } catch (Exception e) {
            log.error(e.getMessage(),e);
        }
    }

    /**
     * 封堵策略
     * @param strategyList 自动化封堵策略列表
     */
    private void sync(List<TbIpPluggingStrategy> strategyList) {
        try {
            log.info("自动化封堵策略: {}",strategyList.size());
            HashMap<String, String> linshiMap = new HashMap<>();
            for (TbIpPluggingStrategy tm : strategyList) {
                IpPluggingScene ipPluggingScene = JSON.parseObject(tm.getConfigInfo(), IpPluggingScene.class);
                if(ipPluggingScene.getQueryTimeFreq() < 1){
                    log.error("{},没有配置查询频率",tm.getStrategyName());
                    continue;
                }
                if(StringUtils.isBlank(ipPluggingScene.getEsIndexId())){
                    log.error("{},没有配置数据源",tm.getStrategyName());
                    continue;
                }
                if (IpPluggingStrategyJobManager.tempMap.containsKey(tm.getId())) {
                    //已启动
                    //判断版本号是否一致
                    String curVer = DateUtils.getDateTimeString1(tm.getUpdateTime());
                    String tempVer = DateUtils.getDateTimeString1(IpPluggingStrategyJobManager.tempMap.get(tm.getId()).getUpdateTime());
                    if (!curVer.equals(tempVer)) {
                        //版本更新
                        //stop
                        IpPluggingStrategyJobManager.deleteJob(tm);
                        //start
                        IpPluggingStrategyJobManager.startJob(tm);
                    }
                } else {
                    //新任务需启动
                    IpPluggingStrategyJobManager.startJob(tm);
                }
                linshiMap.put(tm.getId(), tm.getId());
            }
            HashMap<String, String> linshiMap2 = new HashMap<>();
            IpPluggingStrategyJobManager.tempMap.forEach((k, v) -> {
                if (!linshiMap.containsKey(k)) {
                    //已停止
                    IpPluggingStrategyJobManager.deleteJob(v);
                    linshiMap2.put(k, k);
                    log.info("Stop Job: {}-{}",k,v.getStrategyName());
                }
            });
            linshiMap2.forEach((k, v) -> {
                IpPluggingStrategyJobManager.tempMap.remove(k);
            });
        } catch (Exception e) {
            log.error(e.getMessage(), e);
        }
    }

    @Override
    public void run(String... args) throws Exception {
        sync();
    }
}
