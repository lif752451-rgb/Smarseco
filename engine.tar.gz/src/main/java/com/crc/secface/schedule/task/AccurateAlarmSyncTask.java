package com.crc.secface.schedule.task;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONArray;
import com.alibaba.fastjson.JSONObject;
import com.crc.common.constants.LogConstants;
import com.crc.common.constants.LogConstantsX;
import com.crc.common.paser.KqlParser;
import com.crc.common.paser.KqlResult;
import com.crc.common.paser.TreeParser;
import com.crc.common.utils.*;
import com.crc.secface.argo.CombatUtils;
import com.crc.secface.argo.CombineArgo;
import com.crc.secface.argo.JsonArgo;
import com.crc.secface.config.EsDataSource;
import com.crc.secface.config.GetSpringBean;
import com.crc.secface.config.SyncSecConfig;
import com.crc.secface.entity.*;
import com.crc.secface.es.ConfBuzziMySql;
import com.crc.secface.es.EsSingleFactory;
import com.crc.secface.mapper.TbAssetMapper;
import com.crc.secface.mapper.TbEventModelMapper;
import com.crc.secface.mapper.TbOriDangerEventMapper;
import com.crc.secface.schedule.manager.AccurateAlarmJobManager;
import com.crc.secface.service.WhitelistService;
import com.crc.sync.send.SendEventExecutor;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.elasticsearch.action.search.SearchRequest;
import org.elasticsearch.action.search.SearchResponse;
import org.elasticsearch.client.RequestOptions;
import org.elasticsearch.client.RestHighLevelClient;
import org.elasticsearch.index.query.BoolQueryBuilder;
import org.elasticsearch.index.query.QueryBuilders;
import org.elasticsearch.index.query.RangeQueryBuilder;
import org.elasticsearch.search.SearchHit;
import org.elasticsearch.search.SearchHits;
import org.elasticsearch.search.builder.SearchSourceBuilder;
import org.elasticsearch.search.sort.FieldSortBuilder;
import org.elasticsearch.search.sort.SortOrder;
import org.quartz.*;
import org.springframework.util.CollectionUtils;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;
import java.util.stream.Collectors;

import static com.crc.common.constants.DictTypeEnum.ALARM_MODEL_DEVICENAME;


/**
 * 精确告警分析
 */
@Slf4j
@DisallowConcurrentExecution
public class AccurateAlarmSyncTask implements Job {
    @Override
    public void execute(JobExecutionContext context) throws JobExecutionException {
        if (!SyncSecConfig.isEnable("sync_sec_config", "send_accurate_alarm")) {
            return;
        }
        JobDataMap map = context.getJobDetail().getJobDataMap();
        TbEventModel model = (TbEventModel) map.get(AccurateAlarmJobManager.KEY_NAME);
        String dataSourceId = model.getDataSourceId();
        if (StringUtils.isNotBlank(dataSourceId)) {
            TbEventModelMapper bean = GetSpringBean.getBean(TbEventModelMapper.class);
            TbDatabaseIndex esConfig = bean.getEsConfig(dataSourceId);
            if (esConfig != null) {
                String content = esConfig.getContent();
                if (com.crc.common.utils.StringUtils.isNotEmpty(content)) {
                    JSONArray jsonArray = JSON.parseArray(content);
                    List<TableConstructionInfoDTO> oldList = JSON.parseArray(jsonArray.toJSONString(), TableConstructionInfoDTO.class);
                    Map<String, String> mapData = oldList.stream().filter(tableConstructionInfoDTO -> StringUtils.isNotBlank(tableConstructionInfoDTO.getColumnRemark()))
                            .collect(Collectors.toMap(TableConstructionInfoDTO::getColumnRemark, TableConstructionInfoDTO::getColumnName, (key1, key2) -> key2));
                    String s = JSON.toJSONString(mapData);
                    JSONObject jsonObject = JSON.parseObject(s);
                    model.setContent(jsonObject);
                }
            }
        }

        try {
            sync(model);
        } catch (Exception e) {
            log.error(e.getMessage(), e);
        }
    }

    private void sync(TbEventModel model) {
        RestHighLevelClient client = null;
        try {
            EsDataSource esDataSource = EsEventModelUtils.logSourceCheck(model);
            if (StringUtils.isBlank(esDataSource.getHost())) {
                log.error(model.getModelId() + ",ES数据源配置有问题,使用默认配置");
            }
            client = EsSingleFactory.getInstance().getHighLevelClientHigh(esDataSource);
        } catch (Exception e) {
            log.error(model.getModelId() + " " + model.getEsConfig() + " " + model.getEsIndexId() + ",es配置失败:{}", e.getMessage(), e);
            return;
        }
        try {
            List<LogData> list = queryLogList(model, client);
            processEvent(list, model);
        } catch (Exception e) {
            log.error("规则模型[{}] 执行异常:{}", model.getModelId(), e);
        } finally {
            EsSingleFactory.getInstance().close(client);
        }
    }

    /**
     * 处理合并告警数据
     *
     * @param curList          原始日志
     * @param model            模型
     */
    public void processEvent(List<LogData> curList, TbEventModel model) {
        if (!CollectionUtils.isEmpty(curList)) {
            try {
                CombineArgo argo = new CombineArgo();
                List<JSONObject> noCombineAlarm = new ArrayList<>();
                ConcurrentHashMap<String, JSONObject> logMap = new ConcurrentHashMap<>();
                /*
                 * 字段映射
                 */
                for (LogData logData : curList) {
                    try {
                        JSONObject msg = JsonUtils.parse(logData.getData());
                        JsonUtils.copyField(msg, LogConstantsX.ALERT_NAME, LogConstantsX.ALERT_NAME_BAK);
                        JSONObject oriLog = msg.clone();
                        logMap.put(logData.getId(), oriLog);//原始日志

                        int alarmDescType = model.getAlarmDescType();
                        String alarmDesc = model.getAlarmDesc();
                        if (alarmDescType == 0 && StringUtils.isNotBlank(alarmDesc)) {
                            alarmDesc = JsonArgo.getDymValue(model.getAlarmDesc(), oriLog, model);
                            if (!StringUtils.isBlank(alarmDesc)) {
                                msg.put(LogConstantsX.ALERT_NAME, alarmDesc);
                            }
                        }

                        String attackIp = model.getAttackIp();
                        if (model.getAttackIpType() == 0) {

                            if (StringUtils.isNotBlank(model.getAttackIp())) {
                                attackIp = JsonArgo.getDymValue(model.getAttackIp(), oriLog);
                            } else {
                                //兼容旧版本
                                attackIp = JsonUtils.getStr(oriLog, LogConstantsX.SRC_IP);
                            }
                        }

                        if (StringUtils.isBlank(attackIp)) {
                            attackIp = "0.0.0.0";
                        }
                        msg.put(LogConstantsX.SRC_IP, attackIp);


                        String sufferIp = model.getSufferIp();
                        if (model.getSufferIpType() == 0) {
                            if (StringUtils.isNotBlank(model.getSufferIp())) {
                                sufferIp = JsonArgo.getDymValue(model.getSufferIp(), oriLog);
                            } else {
                                //兼容旧版本
                                sufferIp = JsonUtils.getStr(oriLog, LogConstantsX.DEST_IP);
                            }
                        }
                        if (StringUtils.isBlank(sufferIp)) {
                            sufferIp = "0.0.0.0";
                        }
                        msg.put(LogConstantsX.DEST_IP, sufferIp);

                        if (WhitelistService.isMatchV2(model, msg, true)) {
                            log.info("{},{}-{},命中白名单", model.getModelId(), JsonUtils.getStr(msg, LogConstantsX.SRC_IP), JsonUtils.getStr(msg, LogConstantsX.DEST_IP));
                            continue;
                        }

                        String alarmName = model.getEventName();
                        if (model.getAlarmType() == 0) {
                            alarmName = JsonArgo.getDymValue(model.getEventName(), oriLog);
                        }
                        if (StringUtils.isNotBlank(alarmName)) {
                            msg.put(LogConstantsX.ES_LOG_NAME, JsonUtils.getStr(oriLog, LogConstantsX.LOG_NAME));
                            msg.put(LogConstantsX.LOG_NAME, alarmName);
                        }


                        msg.put("ids", logData.getId());
                        msg.put(LogConstants.ES_LOG_INDEX, logData.getEsIndex());
                        boolean flag = false;

                        if (model.getKeywordList() != null && StringUtils.isNotBlank(alarmName)) {
                            for (SysDictData dictData : model.getKeywordList()) {
                                if (dictData.getDictLabel() != null && (alarmName.contains(dictData.getDictLabel().trim()))) {
                                    log.info("告警合并,model:{},index:{},事件：{},命中关键字{},不合并", model.getModelId(), model.getEsIndexName(), alarmName, dictData.getDictLabel());
                                    flag = true;
                                    break;

                                }
                            }
                        }
                        /*
                         * 设备类型  0 表达式  1 自定义
                         */
                        String deviceName = model.getDeviceName();
                        if (model.getDeviceType() == 0) {
                            if (model.getDeviceName() != null && (!model.getDeviceName().contains("{"))) {
                                model.setDeviceNameStr(deviceName);
                                msg.put(LogConstantsX.LOG_PRODUCT, deviceName);
                            }else {
                                List<String> list = DataUtils.replaceOutput(deviceName);
                                for (String s : list) {
                                    String replaceStr = "\\{" + s + "\\}";
                                    s = s.replace(".keyword", "");
                                    deviceName = DataUtils.getReplaceAll(deviceName, replaceStr, String.valueOf(oriLog.get(s)));
                                    //deviceName.replace(replaceStr, msg.get(s)+"");
                                    msg.put(LogConstantsX.LOG_PRODUCT, deviceName);
                                }
                            }
                        } else {
                            SysDictData labelByTypeAndVal = getLabelByTypeAndVal(ALARM_MODEL_DEVICENAME.getName(), model.getDeviceName());
                            if (null == labelByTypeAndVal || StringUtils.isEmpty(labelByTypeAndVal.getDictLabel())) {
                                msg.put(LogConstantsX.LOG_PRODUCT, "");
                            } else {
                                deviceName = labelByTypeAndVal.getDictLabel();
                                msg.put(LogConstantsX.LOG_PRODUCT, deviceName);
                            }
                        }
                        if ("深信服XQ".equalsIgnoreCase(JsonUtils.getStr(msg, LogConstants.PRODUCT_TAG))) {
                            flag = true;
                        }
                        if (flag) {
                            noCombineAlarm.add(msg);
                            continue;
                        }
                        argo.addData(msg, model);
                    } catch (Exception e) {
                        log.error(model.getModelId() + " " + e.getMessage(), e);
                    }
                }
                if (argo.dataMap.size() > 0) {
                    log.info("[{}]-2合并完成,index:{},新增：{}", model.getModelId(), model.getEsIndexName(), argo.dataMap.size());
                    try {
                        argo.dataMap.forEach((k, v) -> saveData(v, model, logMap));
                    } catch (Exception e) {
                        log.error(model.getModelId() + " " + e.getMessage(), e);
                    }
                }
                log.info("[{}]-2 合并告警,index:{},新增：{}", model.getModelId(), model.getEsIndexName(), noCombineAlarm.size());
                try {
                    noCombineAlarm.forEach((v) -> saveData(v, model, logMap));
                } catch (Exception e) {
                    log.error(model.getModelId() + " " + e.getMessage(), e);
                }
            } catch (Exception e) {
                log.error(model.getModelId() + " " + e.getMessage(), e);
            }
        }
    }

    public void saveData(JSONObject job, TbEventModel modelInfo, ConcurrentHashMap<String, JSONObject> logMap) {
        /*
         * 字段映射
         */
        /*String json = modelInfo.getTimeRemark();
        JSONObject jsonObject = new JSONObject();
        if (StringUtils.isNotBlank(json)) {
            jsonObject = JsonUtils.parse(json);
        }*/
        JSONObject fieldsJson = modelInfo.getContent();

        String srcIp = JsonUtils.getStr(job, LogConstantsX.SRC_IP);
        String product = JsonUtils.getStr(job, LogConstantsX.LOG_PRODUCT);
        //JsonArgo.getDymValue(modelInfo.getDeviceName(), job);
        if (StringUtils.isBlank(product)) {
            product = modelInfo.getDeviceName();
        }
        if (StringUtils.isNotBlank(product)) {
            job.put(LogConstantsX.LOG_PRODUCT, product);
            modelInfo.setDeviceNameStr(product);
        }
        String logName = JsonUtils.getStr(job, LogConstantsX.LOG_NAME);
        if (StringUtils.isBlank(logName)) {
            logName = product + "告警";
        }
        String logType = modelInfo.getAttackTypeName();
        String logLevel = modelInfo.getEventLevelName();
        String destIp = JsonUtils.getStr(job, LogConstantsX.DEST_IP);

        String startTime = "";
        String startField = JsonUtils.getStr(fieldsJson, "告警时间");
        if (StringUtils.isBlank(startField)) {
            startField = JsonUtils.getStr(fieldsJson, "入库时间");
        }
        if (StringUtils.isNotBlank(startField) && job.containsKey(startField)) {
            startTime = JsonUtils.getStr(job, startField);
        }
        if (StringUtils.isBlank(startTime)) {
            startTime = JsonUtils.getStr(job, LogConstantsX.LOG_START_TIME);
        }
        startTime = DateUtils.UTCToCSTAndCheck(startTime);
        if (StringUtils.isBlank(startTime)) {
            startTime = DateUtils.UTCToCST(JsonUtils.getStr(job, LogConstantsX.LOG_TIME));
        }
        job.put(LogConstantsX.LOG_START_TIME, startTime);

        if (StringUtils.isBlank(destIp) || srcIp.equalsIgnoreCase(destIp)) {
            destIp = "0.0.0.0";
        }

        String eventDesc = JsonUtils.getStr(job, LogConstantsX.ALERT_NAME);
        if (StringUtils.isEmpty(eventDesc)) {
            eventDesc = JsonArgo.getDymValue(modelInfo.getAlarmDesc(), job);
            if (StringUtils.isBlank(eventDesc)) {
                eventDesc = JsonUtils.getStr(job, LogConstantsX.LOG_CONTENT);
                job.put(LogConstantsX.ALERT_NAME, eventDesc);
            } else {
                job.put(LogConstantsX.ALERT_NAME, eventDesc);
            }
        }


        String actionResultField = JsonUtils.getStr(fieldsJson, "攻击结果");
        String actionResult = "";
        if (StringUtils.isBlank(actionResultField) && job.containsKey(actionResultField)) {
            actionResult = JsonUtils.getStr(job, actionResultField);
        }
        if (StringUtils.isBlank(actionResult)) {
            actionResult = JsonUtils.getStr(job, LogConstantsX.ACTION_RESULT);
        }

        TbAssetMapper tbAssetMapper = GetSpringBean.getBean(TbAssetMapper.class);
        long times = JsonUtils.getLong(job, "times");
        String ids = JsonUtils.getStr(job, "ids");
        job.put(LogConstantsX.EVENT_TIME, startTime);
        job.put(LogConstantsX.ES_LOG_NAME, logName);
        job.put(LogConstantsX.LOG_NAME, logName);

        //System.out.println(alertName);

        TbOriDangerEvent event = new TbOriDangerEvent();
        event.setId(IdGen.uuid());
        event.setAlertLevel(logLevel);
        event.setData(startTime);
        event.setTimes(times);
        event.setDelFlag(0);

        event.setEventDesc(eventDesc);
        event.setSrcIp(srcIp);
        String whitelist = WhitelistService.isMatchV2(modelInfo, job, true) ? "1" : "0";
        event.setIsWhitelist(whitelist);
        if ("1".equalsIgnoreCase(whitelist)) {
            //hejs 白名单过滤
            log.warn(modelInfo.getModelId() + " # " + srcIp + " => " + destIp + "命中白名单！" + eventDesc);
            return;
        } else {
            destIp = job.getString(LogConstantsX.DEST_IP);
        }
        event.setDestIp(destIp);
        /**
         * 源IP没有的不发告警
         */
        if (StringUtils.isBlank(srcIp)) {
            return;
        }
        event.setStatus("0");
        event.setEventId(ids);
        event.setEventName(logName);
        job.put(LogConstantsX.IS_WHITELIST, whitelist);
        job.put(LogConstantsX.DEST_IP, destIp);
        event.setEventTime(new Date());
        event.setProduct(product);
        event.setEventType(logType);
        event.setActionResult(actionResult);
        event.setModelId(modelInfo.getModelId());

        /**
         * 相同IP 相同告警，时间间隔
         */
        long interval = 60 * 12;
        TbOriDangerEvent tbOriDangerEvent = new TbOriDangerEvent();
        tbOriDangerEvent.setSrcIp(event.getSrcIp());
        tbOriDangerEvent.setDestIp(event.getDestIp());
        tbOriDangerEvent.setEventName(logName);
        tbOriDangerEvent.setModelId(modelInfo.getModelId());
        TbOriDangerEventMapper oriDangerEventMapper = GetSpringBean.getBean(TbOriDangerEventMapper.class);

        TbOriDangerEvent eventSingle = oriDangerEventMapper.selectTbOriDangerByInfo(tbOriDangerEvent);
        boolean newEvent = false;
        if (eventSingle != null && StringUtils.isNotBlank(eventSingle.getId())) {
            long diff = (event.getEventTime().getTime() - eventSingle.getEventTime().getTime()) / 1000 / 60;
            // 根据eventTime判断时间是否在${alarmInterval}间隔内发送过告警，如果发送过则不再发送
            if (diff < interval) {
                log.info("配置间隔:" + interval + " 分钟，目前间隔：" + diff + " 分钟,已发送过:" + modelInfo.getModelId() + " " + eventSingle.getSrcIp() + " " + eventSingle.getDestIp());
                return;
            } else {
                if (event.getEventName() != null) {
                    event.setEventName(DataUtils.getShorter(event.getEventName(), 512));
                }
                oriDangerEventMapper.insertTbOriDangerEvent(event);
                newEvent = true;
            }
        } else {
            if (event.getEventName() != null) {
                event.setEventName(DataUtils.getShorter(event.getEventName(), 512));
            }
            oriDangerEventMapper.insertTbOriDangerEvent(event);
            newEvent = true;
        }
        if (newEvent) {
            /*
                 状态为 '研判/处置' 的一旦出现，则本条告警不推送；
                 */
            try {
                SqlModel sqlModel = new SqlModel();
                sqlModel.setA1(event.getSrcIp());
                sqlModel.setA2(event.getDestIp());
                sqlModel.setA3(logName);
                int count = 0;
                if (CombatUtils.getCombatTime().isCombat()) {
                    count = tbAssetMapper.getProccessingAlarmCombatCount(sqlModel);
                } else {
                    count = tbAssetMapper.getProccessingAlarmCount(sqlModel);
                }
                if (count > 0) {
                    log.warn(modelInfo.getModelId() + " " + "工单存在相同告警，且未处置完毕！" + JSON.toJSONString(event));
                    return;
                }
            } catch (Exception e) {
                log.error(modelInfo.getModelId() + " " + e.getMessage(), e);
            }
        }

        log.info("启动精确告警推送新线程,modelId:{}", modelInfo.getModelId());

        job.put(LogConstantsX.BUS_MODEL, modelInfo.getModelId());
        job.put(LogConstantsX.ORI_EVENT_ID, event.getId());

        //生产环境
        DangerEventSendModel dangerEventSend = new DangerEventSendModel();
        dangerEventSend.setModel(modelInfo);
        dangerEventSend.setLogMap(logMap);
        dangerEventSend.setEventId(event.getId());
        dangerEventSend.setEventJson(job);
        dangerEventSend.setSendOp(1);
        dangerEventSend.setIds(ids);
        SendEventExecutor.doSend(dangerEventSend);
    }


    public List<LogData> queryLogList(TbEventModel model, RestHighLevelClient client) {
        BoolQueryBuilder boolQueryBuilder = QueryBuilders.boolQuery();
        TbOriDangerEventMapper oriDangerEventMapper = GetSpringBean.getBean(TbOriDangerEventMapper.class);
        if ("1".equals(model.getOperateType())) {
            //规则树模式
            BoolQueryBuilder boolQuery = TreeParser.toDsl(model.getJsonParam());
            if (EsUtils.isBlankQuery(boolQuery)) {
                log.error("树模型通用配置参数不完整，请检查" + model.getModelName() + " " + model.getModelId());
                return new ArrayList<>();
            }
            boolQueryBuilder.filter(boolQuery);
        } else if ("2".equals(model.getOperateType())) {
            //KQL模式
            KqlParser parser = new KqlParser(model.getModelId());
            KqlResult result = parser.parse(model.getJsonParam());
            if (result.getCode() == 0) {
                if (EsUtils.isBlankQuery(result.getQuery())) {
                    log.error("KQL模型通用配置参数不完整，请检查" + model.getModelName() + " " + model.getModelId());
                    return new ArrayList<>();
                }
                boolQueryBuilder.filter(result.getQuery());
            } else {
                log.error("KQL模型通用配置参数不完整，请检查" + model.getModelName() + " " + model.getModelId());
                return new ArrayList<>();
            }
        }
        if (EsUtils.isBlankQuery(boolQueryBuilder)) {
            return new ArrayList<>();
        }
        SearchSourceBuilder sourceBuilder = new SearchSourceBuilder();
        sourceBuilder.sort(new FieldSortBuilder(model.getSortKey()).order(SortOrder.DESC));
        sourceBuilder.from(0);
        String dictValue = DictUtil.getDictValue("sync_sec_config", "accurate_alarm_query_num");
        int totalNum = DataUtils.toInt(dictValue);
        if (totalNum < 1) {
            totalNum = 500;
        } else if (totalNum > 5000) {//性能不佳，子集查询数量不超过5000
            totalNum = 5000;
        }
        sourceBuilder.size(totalNum);
        int ret = parseQueryTime(boolQueryBuilder, model);
        if (ret == 1) {
            sourceBuilder.query(boolQueryBuilder);
            try {
                SearchResponse response = null;
                try {
                    SearchRequest searchRequest = new SearchRequest(model.getEsIndexName());
                    searchRequest.source(sourceBuilder);
                    response = client.search(searchRequest, RequestOptions.DEFAULT);
                    ArrayList<LogData> logList = new ArrayList<>();
                    SearchHits sh = response.getHits();
                    for (SearchHit s : sh) {
                        LogData log = new LogData();
                        log.setId(s.getId());
                        log.setData(s.getSourceAsString());
                        log.setEsIndex(s.getIndex());
                        logList.add(log);
                    }
                    log.info(model.getModelId() + " " + model.getEventName() + "-发现:" + logList.size());
                    ArrayList<LogData> curList = new ArrayList<>();
                    if (logList.size() < 1) {
                        log.warn("id:{},规则模型[{}]发现:{},index:{}", model.getModelId(), model.getModelName(), 0, model.getEsIndexName());
                        return new ArrayList<>();
                    }
                    int total = 0;
                    String curDate = DateUtils.getDateX(0);
                    String lastDate = DateUtils.getDateX(-1);
                    boolean f1 = false;
                    boolean f2 = false;
                    for (LogData logData : logList) {
                        //String batchId = getKey(msg);
                        logData.setBatch(IdGen.uuid());
                        logData.setTbDate(curDate);
                        logData.setOldTbDate(lastDate);
                        logData.setStatus("0");
                        /*
                         * 从今天的tmp表找
                         */
                        String tableName = "tb_ori_danger_event_tmp_" + curDate;
                        if (!f1) {
                            ConfBuzziMySql.checkAndCreate(tableName);
                            f1 = true;
                        }
                        tableName = "tb_ori_danger_event_tmp_" + lastDate;
                        if (!f2) {
                            ConfBuzziMySql.checkAndCreate(tableName);
                            f2 = true;
                        }
                        LogData todoData = new LogData();
                        BeanUtils.copyProperties(logData, todoData);
                        todoData.setId(Md5Utils.hash(logData.getId() + "#" + model.getModelId()));//数据区分模型
                        TbOriDangerEvent ode = oriDangerEventMapper.selectTbOriDangerEventByIdTmp(todoData);
                        if (ode == null) {
                            try {
                                oriDangerEventMapper.insertTbOriDangerEventTmp(todoData);
                                curList.add(logData);
                            } catch (Exception ignored) {
                            }
                            total++;
                        } else {
                            /*
                            日志是倒序，第一条已经在缓存，后面就不检查
                             */
                            log.info("1同步完成,model:{},index:{},新增：{}", model.getModelId(), model.getEsIndexName(), total);
                            break;
                        }
                    }
                    log.warn("id:{},规则模型[{}]发现:{},index:{}，size={}", model.getModelId(), model.getModelName(), curList.size(), model.getEsIndexName(),curList.size());
                    return curList;
                } catch (Exception e) {
                    log.error("modelId = {},esIndex:{},sourceBuilder:{}", model.getModelId(), model.getEsIndexName(), sourceBuilder);
                    log.error(e.getMessage(),e);
                } finally {
                    EsSingleFactory.getInstance().close(client);
                }
            } catch (Exception e) {
                log.error(model.getModelId() + " " + e.getMessage(), e);
            }
        } else {
            log.error(model.getModelId() + " 查询时间不合法");
        }
        return new ArrayList();
    }


    public int parseQueryTime(BoolQueryBuilder boolQueryBuilder, TbEventModel modelInfo) {
        String[] timeValues;
        try {
            if (StringUtils.isNotBlank(modelInfo.getTimeRange()) && StringUtils.isNotBlank(modelInfo.getTimeRangeUnit())) {
                TimeUnit timeUnit = TimeUnit.resolveByType(modelInfo.getTimeRangeUnit());
                //新改造，实现新的配置
                timeValues = DateUtils.resolveTimeIntevalsByType(timeUnit, new Date(), Integer.parseInt(modelInfo.getTimeRange()));
            } else {
                TimeUnit timeUnit = TimeUnit.resolveByType(modelInfo.getPeriodType());
                //旧模型没有时间间隔
                timeValues = DateUtils.resolveTimeIntevalsByType(timeUnit, new Date(), Integer.parseInt(modelInfo.getTaskInterval()));
            }
        } catch (Exception e) {
            log.error(modelInfo.getModelId() + " format 时间间隔错误" + e.getMessage(), e);
            return 0;
        }
        RangeQueryBuilder rangeQueryBuilder = QueryBuilders.rangeQuery(modelInfo.getSortKey());
        rangeQueryBuilder.gt(timeValues[1]);
        rangeQueryBuilder.lte(timeValues[0]);
        boolQueryBuilder.filter(rangeQueryBuilder);
        log.info(modelInfo.getModelId() + " 查询时间范围 " + timeValues[1] + " To " + timeValues[0]);
        return 1;
    }

    private SysDictData getLabelByTypeAndVal(String dictType, String value) {
        if (StringUtils.isEmpty(value)) {
            return null;
        }
        return DictUtil.getDictByValue(dictType, value);
    }
}
