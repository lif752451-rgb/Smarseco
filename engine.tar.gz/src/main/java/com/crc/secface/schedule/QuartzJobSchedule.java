package com.crc.secface.schedule;


import cn.hutool.core.date.DateUtil;
import com.alibaba.fastjson.JSON;
import com.crc.common.utils.DictUtil;
import com.crc.common.utils.StringUtils;
import com.crc.job.JobManager;
import com.crc.job.UserDefineJobManager;
import com.crc.rwork.SmsSend;
import com.crc.secface.entity.MessageTemplate;
import com.crc.secface.entity.SysDictData;
import com.crc.secface.entry.SmsModel;
import com.crc.secface.mapper.MessageTemplateMapper;
import com.crc.secface.service.WhiteListCenter;
import com.crc.sync.net.DataCenterLoad;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.scheduling.annotation.EnableScheduling;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Component;

import java.util.HashMap;
import java.util.List;

@Slf4j
@Component
@EnableScheduling
public class QuartzJobSchedule implements CommandLineRunner {
    @Override
    public void run(String... args) throws Exception {
        sync();
    }

    @Autowired
    MessageTemplateMapper templateMapper;

    /**
     * 每N分钟统计一次
     */
    @Scheduled(cron = "0 0/1 * * * ?")
    private void sync() {
        try {
            WhiteListCenter.initWhitelistData();
        } catch (Exception e) {
            log.error(e.getMessage(),e);
        }

        try {
            List<MessageTemplate> tempList = templateMapper.selectAll();
            HashMap<String, String> linshiMap = new HashMap<>();
            for (MessageTemplate tm : tempList) {
                if (JobManager.tempMap.containsKey(tm.getCode())) {
                    //已启动
                    //判断版本号是否一致
                    String curVer = tm.getTempVer();
                    if (!curVer.equals(JobManager.tempMap.get(tm.getCode()).getTempVer())) {
                        //版本更新
                        //stop
                        JobManager.deleteJob(tm);
                        //start
                        JobManager.startJob(tm);
                    }
                } else {
                    //新任务需启动
                    JobManager.startJob(tm);
                }
                linshiMap.put(tm.getCode(), tm.getCode());
            }
            HashMap<String, String> linshiMap2 = new HashMap<>();
            JobManager.tempMap.forEach((k, v) -> {
                if (!linshiMap.containsKey(k)) {
                    //已停止
                    JobManager.deleteJob(v);
                    linshiMap2.put(k, k);
                }
            });
            linshiMap2.forEach((k, v) -> {
                JobManager.tempMap.remove(k);
            });
        } catch (Exception e) {
            log.error(e.getMessage(), e);
        }
        syncDataCenterConfig();
    }


    public void syncDataCenterConfig() {
        try {
            List<SysDictData> tempList = DictUtil.getDict("data_center_log_name_lig");
            HashMap<String, String> linshiMap = new HashMap<>();
            for (SysDictData tm : tempList) {
                if (StringUtils.isNotBlank(tm.getDictValue())) {
                    try {
                        DataCenterLoad.nameMap.put(tm.getDictValue(), "1");
                        linshiMap.put(tm.getDictValue(), "1");
                    } catch (Exception e) {
                        log.error(e.getMessage(), e);
                    }
                }
            }
            HashMap<String, String> linshiMap2 = new HashMap<>();
            DataCenterLoad.nameMap.forEach((k, v) -> {
                if (!linshiMap.containsKey(k)) {
                    linshiMap2.put(k, k);
                }
            });
            linshiMap2.forEach((k, v) -> {
                DataCenterLoad.nameMap.remove(k);
            });
        } catch (Exception e) {
            log.error(e.getMessage(), e);
        }

        log.info(DateUtil.year(DateUtil.date())+"成功加载推送告警中心名称数量：" + DataCenterLoad.nameMap.size());
    }
}
