package com.crc.secface.schedule;

import com.crc.secface.config.SyncSecConfig;
import com.crc.secface.entity.TbAssetSegement;
import com.crc.secface.mapper.TbAssetSegementMapper;
import com.crc.sync.net.AlarmAssetSegmentLoad;
import com.crc.sync.net.NewSegmentLoad;
import com.crc.sync.net.WhiteIpSegmentLoad;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.scheduling.annotation.EnableScheduling;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Component;

import java.util.List;

/*
 * 集团网段加载功能
 */

@Slf4j
@Component
@EnableScheduling
public class SegmentSchedule implements CommandLineRunner {
    @Override
    public void run(String... args) throws Exception {
        sync();
    }


    @Autowired
    TbAssetSegementMapper tbSegementInfoMapper;

    /**
     * 每N分钟统计一次
     */
    @Scheduled(cron = "0 0/5 * * * ?")
    public void sync() {
        try {
            TbAssetSegement query = new TbAssetSegement();
            query.setIsEnable(0L);
            List<TbAssetSegement> listAll = tbSegementInfoMapper.selectTbAssetSegementList(query);
            NewSegmentLoad.setAllSegment(listAll);
            log.info("2023成功加载IP网段信息数：" + listAll.size());
        } catch (Exception e) {
            log.error(e.getMessage(), e);
        }
        (new AlarmAssetSegmentLoad()).syncAll();
        (new WhiteIpSegmentLoad()).syncAll();
        NewSegmentLoad.FILTER_SEGMENT_FLAG = SyncSecConfig.isEnable("filter_segment_enable");
        log.info("是否启用了网段识别 IP 过滤机制，{}",NewSegmentLoad.FILTER_SEGMENT_FLAG);
    }
}
