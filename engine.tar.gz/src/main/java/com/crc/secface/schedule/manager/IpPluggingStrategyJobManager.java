package com.crc.secface.schedule.manager;

import com.alibaba.fastjson.JSON;
import com.crc.common.utils.CronUtils;
import com.crc.secface.entity.IpPluggingScene;
import com.crc.secface.entity.TbIpPluggingStrategy;
import lombok.extern.slf4j.Slf4j;
import org.quartz.*;
import org.quartz.impl.StdSchedulerFactory;

import java.util.concurrent.ConcurrentHashMap;

@Slf4j
public class IpPluggingStrategyJobManager {
    public static String GROUP_NAME = "strategy_group";
    public static String KEY_NAME = "strategy_data";
    public static ConcurrentHashMap<String, TbIpPluggingStrategy> tempMap = new ConcurrentHashMap<>();

    public static void deleteJob(TbIpPluggingStrategy model) {
        try {
            JobKey jk = JobKey.jobKey(model.getId(), GROUP_NAME);
            Scheduler scheduler = StdSchedulerFactory.getDefaultScheduler();
            scheduler.deleteJob(jk);
            log.info("delete Job {} == {}", model.getStrategyName(), model.getId());
        } catch (Exception e) {
            log.error(e.getMessage(), e);
        }
    }

    public static void startJob(TbIpPluggingStrategy model) {
        JobDetail job = JobBuilder.newJob(com.crc.secface.schedule.task.IpPluggingStrategyTask.class).withIdentity(model.getId(), GROUP_NAME).build();
        job.getJobDataMap().put(KEY_NAME,model);
        try {
            IpPluggingScene ipPluggingScene = JSON.parseObject(model.getConfigInfo(), IpPluggingScene.class);
            String cron = CronUtils.getCronIp(ipPluggingScene);
            Trigger trigger = TriggerBuilder
                    .newTrigger()
                    .withSchedule(CronScheduleBuilder.cronSchedule(cron)).build();
            Scheduler scheduler = StdSchedulerFactory.getDefaultScheduler();
            scheduler.scheduleJob(job, trigger);
            if (!scheduler.isStarted()) {
                scheduler.start();
            }
            tempMap.put(model.getId(), model);
            log.info("自动化封堵策略 " + model.getStrategyName() + " " + model.getId() + " --> " + cron);
        } catch (Exception e) {
            log.error(model.getId() + " @@ " + e.getMessage(), e);
            deleteJob(model);
        }
    }
}
