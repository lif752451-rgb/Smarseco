package com.crc.secface.schedule.task;

import cn.hutool.core.collection.CollUtil;
import cn.hutool.core.date.DateUtil;
import cn.hutool.core.util.StrUtil;
import cn.hutool.http.HttpUtil;
import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONArray;
import com.alibaba.fastjson.JSONObject;
import com.crc.common.constants.Constants;
import com.crc.common.constants.IpPluggingActionTypeEnum;
import com.crc.common.constants.MessageEnum;
import com.crc.common.enums.DictTypeEnum;
import com.crc.common.paser.KqlParser;
import com.crc.common.paser.KqlResult;
import com.crc.common.utils.*;
import com.crc.msg.rwork.RworkSend;
import com.crc.msg.wx.QyweixinSend;
import com.crc.secface.argo.EsAggToListArgo;
import com.crc.secface.argo.SearchIpUtils;
import com.crc.secface.config.EsDataSource;
import com.crc.secface.config.GetSpringBean;
import com.crc.secface.config.IDNACConfig;
import com.crc.secface.config.MarvalnetConfig;
import com.crc.secface.entity.*;
import com.crc.secface.es.EsSingleFactory;
import com.crc.secface.exception.CustomException;
import com.crc.secface.mapper.*;
import com.crc.secface.redis.RedisUtil;
import com.crc.secface.schedule.manager.IpPluggingStrategyJobManager;
import com.crc.secface.tool.FeitaTool;
import com.crc.secface.tool.HuaweiTool;
import com.crc.secface.tool.SangforTool;
import com.crc.sync.net.WhiteIpSegmentLoad;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.text.StringEscapeUtils;
import org.elasticsearch.action.search.SearchRequest;
import org.elasticsearch.action.search.SearchResponse;
import org.elasticsearch.client.RequestOptions;
import org.elasticsearch.client.RestHighLevelClient;
import org.elasticsearch.common.Strings;
import org.elasticsearch.common.xcontent.ToXContent;
import org.elasticsearch.common.xcontent.XContentBuilder;
import org.elasticsearch.common.xcontent.XContentFactory;
import org.elasticsearch.index.query.BoolQueryBuilder;
import org.elasticsearch.index.query.QueryBuilders;
import org.elasticsearch.index.query.RangeQueryBuilder;
import org.elasticsearch.search.aggregations.Aggregation;
import org.elasticsearch.search.aggregations.AggregationBuilders;
import org.elasticsearch.search.aggregations.bucket.terms.TermsAggregationBuilder;
import org.elasticsearch.search.builder.SearchSourceBuilder;
import org.quartz.*;

import java.util.Calendar;
import java.util.*;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.atomic.AtomicBoolean;
import java.util.function.Function;
import java.util.regex.Pattern;
import java.util.stream.Collectors;

import static com.crc.common.constants.DictTypeEnum.QYWX_PUSH_AUTH;
import static com.crc.common.constants.DictTypeEnum.QYWX_SUBJECT_TEMPLATE;
import static com.crc.common.constants.IpPluggingConstant.*;
import static com.crc.common.enums.DictTypeEnum.RUN_WORK_SUBJECT_TEMPLATE;

/**
 * 自动化封堵
 */
@Slf4j
@DisallowConcurrentExecution
public class IpPluggingStrategyTask implements Job {
    Date runDate;

    private static final String BLOCK_LOGIN = "block_login";


    @Override
    public void execute(JobExecutionContext context) throws JobExecutionException {
        JobDataMap map = context.getJobDetail().getJobDataMap();
        try {
            TbIpPluggingStrategy model = (TbIpPluggingStrategy) map.get(IpPluggingStrategyJobManager.KEY_NAME);
            if (model == null) {
                log.error("封堵策略不存在");
                return;
            }
            runDate = new Date();
            sync(model);
            log.info("{},计算结束，开始时间{}", model.getStrategyName(), DateUtils.getDateTimeString1(runDate));
        } catch (Exception e) {
            log.error(e.getMessage(), e);
        }

    }

    private void sync(TbIpPluggingStrategy ipPluggingStrategy) {
        Map<String, Set<String>> ipSet = new HashMap<>();
        Map<String, String> ipPluggingTime = getQueryTimeRangeNew(ipPluggingStrategy.getPluggingTime(), ipPluggingStrategy.getPluggingTimeUnit());
        TbIpPluggingStrategyMapper ipPluggingStrategyMapper = GetSpringBean.getBean(TbIpPluggingStrategyMapper.class);
        List<String> iocDataList = ipPluggingStrategyMapper.getIocList();
        Map<String, String> iocMap = new HashMap<>();
        if (iocDataList != null) {
            iocMap = iocDataList.stream().collect(Collectors.toMap(Function.identity(), Function.identity(), (k1, k2) -> k2));
        }
        IpPluggingScene ipPluggingBehaviorScene = JSON.parseObject(ipPluggingStrategy.getConfigInfo(), IpPluggingScene.class);
        //封堵的字段
        String blockIpField = ipPluggingBehaviorScene.getIp();
        //是否是恶意IP
        int isMalicious = ipPluggingBehaviorScene.getIsMalicious();
        if (WhiteIpSegmentLoad.getAllSegment().size() < 1) {
            log.error("没有配置业务白名单block_white_list,或等待加载");
            return;
        }
        log.info("业务白名单数量:{}", WhiteIpSegmentLoad.getAllSegment().size());
        //组装ES客户端
        RestHighLevelClient client = null;
        try {
            //组装时间区间
            int queryTimeRange3 = ipPluggingBehaviorScene.getQueryTimeRange();
            int queryTimeRangeUnit2 = ipPluggingBehaviorScene.getGetQueryTimeRangeUnit();
            Map<String, String> queryTimeRange4 = getQueryTimeRange(queryTimeRange3, queryTimeRangeUnit2);
            RangeQueryBuilder rangeQueryBuilder = QueryBuilders.rangeQuery(ipPluggingBehaviorScene.getSortKey());
            rangeQueryBuilder.gt(DateUtils.getSparkTimeNew(DateUtils.parseDateTime(queryTimeRange4.get("startTime"), DateUtils.DATE_FORMAT_STRING1)));
            rangeQueryBuilder.lte(DateUtils.getSparkTimeNew(DateUtils.parseDateTime(queryTimeRange4.get("endTime"), DateUtils.DATE_FORMAT_STRING1)));


            TbEventModelMapper modelMapper = GetSpringBean.getBean(TbEventModelMapper.class);
            Map<String, String> indexMap = modelMapper.getIndexAndSource(TbEventModel.createQuery(ipPluggingBehaviorScene.getEsIndexId()));
            EsDataSource esDataSource = EsUtils.logSourceCheck(indexMap);
            if (esDataSource == null) {
                throw new CustomException(MessageEnum.ES_SOURCE_NOT_EXIST_ERROR.getValue(),
                        MessageEnum.ES_SOURCE_NOT_EXIST_ERROR.getKey());
            }
            String indexName = DataUtils.getString(indexMap, "indexRule");
            //组装查询语句
            SearchSourceBuilder sourceBuilder = new SearchSourceBuilder();
            BoolQueryBuilder boolQueryBuilder = QueryBuilders.boolQuery();
            if (ipPluggingBehaviorScene.getLangType() == 1) {//kql
                KqlParser parser = new KqlParser("common");
//                String kqlStr = StringUtils.convertSpecialChar(StringEscapeUtils.unescapeJava(ipPluggingBehaviorScene.getKql()));
                KqlResult result = parser.parse(ipPluggingBehaviorScene.getKql());
                if (result.getCode() == 0) {
                    if (EsUtils.isBlankQuery(result.getQuery())) {
                        throw new CustomException(MessageEnum.ALARM_MODEL_KQL_CONFIG_ERROR.getValue(),
                                MessageEnum.ALARM_MODEL_KQL_CONFIG_ERROR.getKey());
                    }
                    boolQueryBuilder.filter(result.getQuery());
                } else {
                    throw new CustomException(MessageEnum.ALARM_MODEL_KQL_CONFIG_ERROR.getValue(),
                            MessageEnum.ALARM_MODEL_KQL_CONFIG_ERROR.getKey());
                }
                System.out.println(blockIpField);
                sourceBuilder.size(0);
                //构建聚合名称
                TermsAggregationBuilder brandAgg = AggregationBuilders.terms(blockIpField.replace(".keyword", "")).field(blockIpField);
                boolQueryBuilder.filter(rangeQueryBuilder);
                sourceBuilder.query(boolQueryBuilder);
                brandAgg.size(1000);
                sourceBuilder.aggregation(brandAgg);
            } else if (ipPluggingBehaviorScene.getLangType() == 2) {//dsl
                String kqlStr = StringUtils.convertSpecialChar(StringEscapeUtils.unescapeJava(ipPluggingBehaviorScene.getKql()));
                sourceBuilder = EsUtils.strToDsl(kqlStr);
                if (sourceBuilder == null) {
                    throw new CustomException(MessageEnum.ES_SOURCE_DSL_PARSE_ERROR.getValue(),
                            MessageEnum.ES_SOURCE_DSL_PARSE_ERROR.getKey());
                }
                ((BoolQueryBuilder) sourceBuilder.query().queryName("filter").queryName("range")).filter(rangeQueryBuilder);
            } else {
                log.error("无法识别查询语句-{}", ipPluggingStrategy.getStrategyName());
            }
            SearchRequest searchRequest = new SearchRequest(indexName);
            searchRequest.source(sourceBuilder);
            log.info("block strategy={},查询语句,{}", ipPluggingStrategy.getStrategyName(), sourceBuilder);
            client = EsSingleFactory.getInstance().getHighLevelClientHigh(esDataSource);
            SearchResponse search = client.search(searchRequest, RequestOptions.DEFAULT);
            String name = ipPluggingStrategy.getStrategyName() + "[SSP自动化封堵]";
            if (search.getAggregations() != null) {
                List<Aggregation> aggs = search.getAggregations().asList();
                for (Aggregation agg : aggs) {
                    try (XContentBuilder builder = XContentFactory.jsonBuilder();) {
                        sourceBuilder.toXContent(builder, ToXContent.EMPTY_PARAMS);
                        String json = Strings.toString(agg, true, true);
                        EsAggToListArgo argo = new EsAggToListArgo();
                        List<JSONObject> list = argo.aggToList(JSON.parseObject(json));

                        log.info("{},aggToList====={},size={}", name, JSON.toJSONString(list), list.size());
                        for (JSONObject jsonObject : list) {
                            String ipValue = JsonUtils.getStr(jsonObject, blockIpField.replace(".keyword", "") + "#key");
                            //判断 不是白名单 IP
                            if (!WhiteIpSegmentLoad.getIPByHalf(ipValue)) {
                                //判断是否是恶意IP
                                boolean b = iocMap.containsKey(ipValue);
                                if ((isMalicious == 1 && b) || (isMalicious == 2 && !b)) {
                                    Set<String> orDefault = ipSet.getOrDefault(name, new HashSet<>());
                                    orDefault.add(ipValue);
                                    ipSet.put(name, orDefault);
                                }
                            }
                        }
                    } catch (Exception e) {
                        log.error(e.getMessage(), e);
                    }
                }
            }
            log.info("ipSet:{}", JSON.toJSONString(ipSet));
            CommonMapper commonMapper = GetSpringBean.getBean(CommonMapper.class);
            ipSet.forEach((k, v) -> {
                log.info("{}分析自动化封堵 IP 数量:{}", k, v.size());
                for (String s : v) {
                    List<JSONObject> recordlist = commonMapper.queryX("SELECT CONCAT(r.action_type,'') AS action_type,t.ip FROM tb_ip_plugging_task t INNER JOIN tb_ip_plugging_task_record r  ON t.id = r.task_id  WHERE   t.ip = '" + s + "' and r.action_time >  DATE_SUB(NOW(), INTERVAL 1 HOUR) AND r.action_result != 3  ORDER BY r.id DESC LIMIT 1");
                    try {
                        if (recordlist != null && recordlist.size() > 0) {
                            if (JsonUtils.getInt(recordlist.get(0), "action_type") == 1) {
                                //最新的一条记录是封堵
                                log.info("最近1个小时内，当前IP:{}执行过封堵，且执行结果为执行中 或封堵成功，暂不执行封堵", s);
                                continue;
                            }
                        }
                    } catch (Exception e) {
                        log.error(e.getMessage(), e);
                    }
                    TbIpPluggingTask request = new TbIpPluggingTask();
                    request.setReason(k);
                    request.setDeadlineTime(DateUtils.parseDateTime(ipPluggingTime.get("startTime")));
                    request.setIp(s);
                    request.setExecDevice(ipPluggingStrategy.getExecDevice());
                    request.setDeviceIp(ipPluggingStrategy.getDeviceIp());
                    request.setCreateByLabel("system");
                    request.setStrategyName(ipPluggingStrategy.getStrategyName());
                    request.setStatus(2);
                    request.setCreateByLabel("system");
                    request.setCreateBy("system");
                    request.setUpdateBy("system");
                    request.setPluggingTime(new Date());
                    insertBatch(request, ipPluggingStrategy.getCreateBy());
                }
            });
        } catch (Throwable  e) {
            log.error("{},ES查询失败，失败原因为:{}", ipPluggingStrategy.getStrategyName(), e.getMessage(), e);
        } finally {
            EsSingleFactory.getInstance().close(client);
        }
    }

    private void insertBatch(TbIpPluggingTask request, String userName) {
        String[] ipList = DataUtils.getSplit(request.getIp(), ",");
        List<String> taskIds = new ArrayList<>();
        TbIpPluggingTaskMapper ipPluggingTaskMapper = GetSpringBean.getBean(TbIpPluggingTaskMapper.class);
        //RedisUtil redisUtil = GetSpringBean.getBean(RedisUtil.class);
        TbIpPluggingTaskRecordMapper ipPluggingTaskRecordMapper = GetSpringBean.getBean(TbIpPluggingTaskRecordMapper.class);

        for (String ip : ipList) {
            if (StringUtils.isEmpty(ip)) {
                throw new CustomException(MessageEnum.IP_EMPTY.getValue(), MessageEnum.IP_EMPTY.getKey());
            }
            String ipHome = "";
            boolean isIp = IpUtils.isIpv4(ip);
            boolean ipv6 = IpUtils.isIpv6(ip);
            if (!isIp && !ipv6) {
                throw new CustomException(MessageEnum.IP_ERROR.getValue(), MessageEnum.IP_ERROR.getKey());
            } else {
                ipHome = "未知";
            }

            /*
             * 执行设备
             */
            try {
                String[] deviceIp = request.getDeviceIp().split(",");
                String[] devices = request.getExecDevice().split(",");
                String name = request.getStrategyName() + "[SSP自动化封堵]";
                for (int j = 0; j < devices.length; j++) {
                    TbIpPluggingTask ipPluggingTask = new TbIpPluggingTask();
                    ipPluggingTask.setIpHome(ipHome);
                    ipPluggingTask.setDeadlineTime(request.getDeadlineTime());
                    ipPluggingTask.setExecCount(0);
                    ipPluggingTask.setIp(ip);
                    ipPluggingTask.setCreateByLabel(request.getCreateByLabel());
                    ipPluggingTask.setCreateBy(request.getCreateBy());
                    ipPluggingTask.setUpdateBy(request.getUpdateBy());
                    ipPluggingTask.setCreateTime(new Date());
                    ipPluggingTask.setUpdateTime(new Date());
                    ipPluggingTask.setExecDevice(devices[j]);
                    ipPluggingTask.setReason(request.getReason());
                    ipPluggingTask.setIpHome(ipHome);
                    ipPluggingTask.setPluggingTime(new Date());
                    ipPluggingTask.setDeadlineTime(request.getDeadlineTime());
                    setInternetIpHome(ipPluggingTask);
                    ipPluggingTask.setStrategyName(name);
                    if (deviceIp.length >= j) {
                        ipPluggingTask.setDeviceIp(deviceIp[j]);
                    }

                    String idStr = ipPluggingTaskMapper.getUniqueCount(devices[j], ip);
                    if (StringUtils.isEmpty(idStr) || "null".equals(idStr)) {
                        ipPluggingTaskMapper.insert(ipPluggingTask);
                        idStr = String.valueOf(ipPluggingTask.getId());
                    }
                    // 任务id集合
                    taskIds.add(idStr);
                    String recordId = IdGen.uuid();
                    /*
                     * 需要在封堵记录表里面添加一条数据
                     */
                    TbIpPluggingTaskRecord taskRecord = new TbIpPluggingTaskRecord();
                    taskRecord.setId(recordId);
                    taskRecord.setTaskId(idStr);
                    taskRecord.setActionType(1);
                    taskRecord.setOperationUser("系统");
                    taskRecord.setOperationType(2);
                    taskRecord.setActionResult(1);
                    taskRecord.setActionReason(request.getReason());
                    taskRecord.setActionTime(new Date());
                    taskRecord.setDeadlineTime(request.getDeadlineTime());
                    ipPluggingTaskRecordMapper.insert(taskRecord);


                    String msg = "";
                    AtomicBoolean resultFlag = new AtomicBoolean(false);
                    try {
                        String execDeviceType = "";
                        List<SysDictData> executeDevice = DictUtil.getDict("execute_device");
                        int finalJ = j;
                        List<SysDictData> collect = executeDevice.stream().filter(sysDictData -> sysDictData.getDictLabel().equals(devices[finalJ])).collect(Collectors.toList());
                        if (collect.size() > 0) {
                            String s = collect.get(0).getRemark();
                            JSONObject parse = JsonUtils.parse(s);
                            execDeviceType = DataUtils.getString(parse,"type");
                        }
                        // TODO 执行封堵接口
                        if (StringUtils.isNotEmpty(execDeviceType) && !execDeviceType.equals("null")) {
                            if (execDeviceType.equals("dt")) {
                                msg = dtPluMethod(ip, ipPluggingTask, msg);
                            } else if (execDeviceType.equals("feita")) {
                                try {
                                    FeitaTool feitaTool = GetSpringBean.getBean(FeitaTool.class);
                                    msg = feitaTool.block(Collections.singletonList(ip));
                                } catch (Exception e) {
                                    log.error("封堵失败：{}",e.getMessage(),e);
                                    msg = "封堵失败";
                                }
                            } else if (execDeviceType.equals("sangfor")) {
                                try {
                                    msg = SangforTool.blockIps(Collections.singletonList(request.getDeviceIp()), Collections.singletonList(ip),
                                            DateUtils.formatDateTime(request.getDeadlineTime(), DateUtils.DATE_FORMAT_STRING1));
                                } catch (Exception e) {
                                    log.error("封堵失败：{}",e.getMessage(),e);
                                    msg = "封堵失败";
                                }
                            } else if (execDeviceType.equals("marvalnet")) {
//                                msg = marvalnetPluMethod(ip, ipPluggingTask, msg);
                                String devIp =  deviceIp[finalJ];
                                msg = marvalnetJTMethod(ip, resultFlag,devIp, msg);
                            } else if (devices[j].equals("IDNac")) {
                                //艾科网信封堵
                                try {
                                    msg = IDNACConfig.block(ip);
                                } catch (Exception e) {
                                    log.error("封堵失败：{}",e.getMessage(),e);
                                    msg = "封堵失败";
                                }
                            }  else if (devices[j].equals("hw_usg")) {
                                try {
                                    msg =  HuaweiTool.blockIp(idStr, ip, request.getReason());
                                } catch (Exception e) {
                                    log.error("封堵失败：{}",e.getMessage(),e);
                                    msg = "封堵失败";
                                }
                            }
                        } else {
                            msg = "封堵失败, 执行设备配置错误";
                            log.error("执行设备配置错误:{}", devices[j]);
                        }
                    } catch (Exception e) {
                        log.error(name + ",执行封堵IP操作失败，原因为:{}", e.getMessage(), e);
                        msg = name + ",封堵IP失败Error," + ip;
                    }
                    //TODO 更新记录表的状态
//                    if (StringUtils.isEmpty(msg)) {
//                        taskRecord.setActionResult(2);
//                        ipPluggingTaskMapper.updateExecCountAndTime(idStr);
//                        //监听redis的key
//                        Long timeValue = getTimeValue(request.getDeadlineTime());
//                        String redisKey = IP_TASK + "_" + idStr + "_" + "1" ;
//                        List<String> keyByPrefix = redisUtil.getKeyByPrefix(redisKey);
//                        boolean flag = false;
//                        for (int i = 0; i < keyByPrefix.size(); i++) {
//                            String s = keyByPrefix.get(i);
//                            long expireByKey = redisUtil.getExpireByKey(s);
//                            if (expireByKey < timeValue) {
//                                flag = true;
//                                redisUtil.remove(s);//删除时间短的key
//                            }
//                        }
//                        if (flag || null == keyByPrefix || keyByPrefix.size() == 0) {
//                            redisKey = redisKey + "_" + request.getCreateByLabel() + "_" + name;
//                            if (timeValue > 0) {
//                                redisUtil.setValue(redisKey, redisKey, timeValue, TimeUnit.SECONDS);
//                            }
//                        }
//                    } else {
//                        taskRecord.setActionResult(3);
//                    }
                    //合并集团分支封堵逻辑
                    if (StringUtils.isEmpty(msg)) {
                        String status = "0";
                        if (resultFlag.get()) {
                            //新版本,定时解封需要在定时任务中处理
                            taskRecord.setActionResult(1);
                            taskRecord.setResultFlag(2);
                        } else {
                            //旧版本
                            taskRecord.setActionResult(2);
                            status = "2";
                            //监听redis的key
                            redisUnSealTask(request, false, "", idStr);
                        }
                        ipPluggingTaskMapper.updateExecCountAndTime(idStr, status);
                        taskRecord.setOperationType(2);
                    } else {
                        taskRecord.setActionResult(3);
                    }
                    taskRecord.setMsg(msg);
                    ipPluggingTaskRecordMapper.updateData(taskRecord);
                    Thread.sleep(3000);

                }
            } catch (Exception e) {
                log.error("失败原因为:{}", e.getMessage(), e);
                log.info("添加封堵IP错误");
            }
        }

        try {
            //countDownLatch.await();
            // 发送润工作提醒
            sendVxNotice(taskIds, userName);
            sendRworkNotice(taskIds, userName);
        } catch (Exception e) {
            log.error("发送润工作提醒错误{}", e.getMessage(), e);
        }
    }

    private static final String IP_TASK = "ip_task";
    public static final String ZH_SEMICOLON = "；";
    /**
     * 发送润工作提醒
     *
     * @param taskIds 封堵任务集合
     */

    private void sendRworkNotice(List<String> taskIds, String userName) {
        if (CollUtil.isEmpty(taskIds)) {
            return;
        }
        TbIpPluggingTaskMapper ipPluggingTaskMapper = GetSpringBean.getBean(TbIpPluggingTaskMapper.class);
        TbIpPluggingTaskRecordMapper ipPluggingTaskRecordMapper = GetSpringBean.getBean(TbIpPluggingTaskRecordMapper.class);
        String actionDesc = IpPluggingActionTypeEnum.getDescByValue(1);
        // IP封堵发送润工作开关字典
        SysDictData sysDict = DictUtil.getDictByValue(DictTypeEnum.RUN_WORK_PUSH_AUTH.getName(), IP_PLUGGING_SWITCH);
        if (Constants.STR_VALUE_ZERO.equals(sysDict.getDictLabel()) || StringUtils.isNotBlank(sysDict.getRemark())) {
            // 获取 封堵任务管理组 角色下所有用户
            SysDictData subDict = DictUtil.getDictByValue(RUN_WORK_SUBJECT_TEMPLATE.getName(), IP_PLUGGING_SUBJECT);
            List<String> contentList = new ArrayList<>();
            // 主题
            String subject = String.format(QYWX_CONTENT, subDict.getDictLabel() + actionDesc, DateUtil.now(), actionDesc);
            taskIds.forEach(taskId -> {
                StringBuilder wxInfo = new StringBuilder();
                IpPluggingTaskRecordResponse recordResponse = new IpPluggingTaskRecordResponse();
                List<IpPluggingTaskRecordResponse> dataList = ipPluggingTaskRecordMapper.getByTaskId(taskId);
                if (CollUtil.isNotEmpty(dataList)) {
                    recordResponse = dataList.stream().max(Comparator.comparing(IpPluggingTaskRecordResponse::getActionTime)).orElseGet(IpPluggingTaskRecordResponse::new);
                    wxInfo.append(StringUtils.trim(DateUtil.formatDateTime(recordResponse.getActionTime()))).append(Constants.Symbol.BLANK);
                }
                TbIpPluggingTask task = ipPluggingTaskMapper.getById(taskId);
                if (Objects.nonNull(task)) {
                    wxInfo.append(StringUtils.trim(task.getExecDevice())).append(Constants.Symbol.EN_LEFT_BRACKET).append(StringUtils.trim(task.getDeviceIp())).append(Constants.Symbol.EN_RIGHT_BRACKET)
                            .append(TO).append(task.getIp()).append(Constants.Symbol.MINUS).append(actionDesc).append(StringUtils.trim(recordResponse.getActionResult())).append(Constants.Symbol.ZH_SEMICOLON);
                }
                contentList.add(wxInfo.toString());
            });
            // 润工作接收人
            // 异步发送润工作通知
            if (StrUtil.isEmpty(userName)) {
                log.error("推送用户为空，暂不推送");
                return;
            }
            RworkSend.batchSend(Collections.singletonList(userName), subject + Constants.Symbol.LINE_FEED + CollUtil.join(contentList, Constants.Symbol.LINE_FEED));
        } else {
            log.info("IP封堵对接润工作开关已关闭");
        }
    }

    /**
     * 发送企业微信提醒
     *
     * @param taskIds    封堵任务集合
     */
    private void sendVxNotice(List<String> taskIds, String userName) {
        if (CollUtil.isEmpty(taskIds)) {
            return;
        }
        TbIpPluggingTaskMapper ipPluggingTaskMapper = GetSpringBean.getBean(TbIpPluggingTaskMapper.class);
        TbIpPluggingTaskRecordMapper ipPluggingTaskRecordMapper = GetSpringBean.getBean(TbIpPluggingTaskRecordMapper.class);
        // IP封堵发送企业微信开关字典
        SysDictData sysDict = DictUtil.getDictByValue(QYWX_PUSH_AUTH.getName(), IP_PLUGGING_SWITCH);
        if (Constants.STR_VALUE_ZERO.equals(sysDict.getDictLabel())) {
            // 获取 封堵任务管理组 角色下所有用户

            // IP封堵发送企业微信标题
            SysDictData subDict = DictUtil.getDictByValue(QYWX_SUBJECT_TEMPLATE.getName(), IP_PLUGGING_SUBJECT);
            List<String> contentList = new ArrayList<>();
            String actionDesc = IpPluggingActionTypeEnum.getDescByValue(1);
            // 主题
            String subject = String.format(QYWX_CONTENT, subDict.getDictLabel() + actionDesc, DateUtil.now(), actionDesc);
            taskIds.forEach(taskId -> {
                StringBuilder wxInfo = new StringBuilder();
                IpPluggingTaskRecordResponse recordResponse = new IpPluggingTaskRecordResponse();
                List<IpPluggingTaskRecordResponse> dataList = ipPluggingTaskRecordMapper.getByTaskId(taskId);
                if (CollUtil.isNotEmpty(dataList)) {
                    recordResponse = dataList.stream().max(Comparator.comparing(IpPluggingTaskRecordResponse::getActionTime)).orElseGet(IpPluggingTaskRecordResponse::new);
                    wxInfo.append(StringUtils.trim(DateUtil.formatDateTime(recordResponse.getActionTime()))).append(Constants.Symbol.BLANK);
                }
                TbIpPluggingTask task = ipPluggingTaskMapper.getById(taskId);
                if (Objects.nonNull(task)) {
                    wxInfo.append(StringUtils.trim(task.getExecDevice())).append(Constants.Symbol.EN_LEFT_BRACKET).append(StringUtils.trim(task.getDeviceIp())).append(Constants.Symbol.EN_RIGHT_BRACKET)
                            .append(TO).append(task.getIp()).append(Constants.Symbol.MINUS).append(actionDesc).append(StringUtils.trim(recordResponse.getActionResult())).append(ZH_SEMICOLON);
                }
                contentList.add(wxInfo.toString());
            });
            // 企业微信接收人
            //List<String> userList = userDtoList.stream().map(UserDTO::getUserName).collect(Collectors.toList());
            if (StrUtil.isEmpty(userName)) {
                log.error("推送用户为空，暂不推送");
                return;
            }
            // 异步发送企业微信通知
            QyweixinSend.batchSend(Collections.singletonList(userName), subject + Constants.Symbol.BR + CollUtil.join(contentList, Constants.Symbol.BR));
        } else {
            log.info("IP封堵对接企业微信开关已关闭");
        }
    }

    public void setInternetIpHome(TbIpPluggingTask ipPluggingTask) {
        if (IpUtils.isIp(ipPluggingTask.getIp())) {
            String ipHome = SearchIpUtils.search(ipPluggingTask.getIp());
            if (StringUtils.isNotBlank(ipHome) && !ipHome.contains("内网")) {
                ipPluggingTask.setIpHome(ipHome);
            }
        }
    }

    /**
     * 构建查询时间
     *
     * @param queryTime
     * @param queryTimeUnit
     * @return
     */
    private static Map<String, String> getQueryTimeRange(int queryTime, int queryTimeUnit) {
        Calendar rightNow = Calendar.getInstance();
        Date date = new Date();
        rightNow.setTime(date);
        if (queryTimeUnit == 1) {
            rightNow.add(Calendar.MINUTE, -queryTime);
        } else if (queryTimeUnit == 2) {
            rightNow.add(Calendar.HOUR_OF_DAY, -queryTime);
        } else if (queryTimeUnit == 3) {
            rightNow.add(Calendar.DAY_OF_YEAR, -queryTime);
        } else if (queryTimeUnit == 4) {
            rightNow.add(Calendar.MONTH, -queryTime);
        } else if (queryTimeUnit == 5) {
            rightNow.add(Calendar.MINUTE, -queryTime);
        }
        Map<String, String> resultMap = new HashMap<>();
        String endTime = DateUtils.formatDateTime(date, DateUtils.DATE_FORMAT_STRING1);
        String startTime = DateUtils.formatDateTime(rightNow.getTime(), DateUtils.DATE_FORMAT_STRING1);
        resultMap.put("endTime", endTime);
        resultMap.put("startTime", startTime);
        return resultMap;
    }

    private static Long getTimeValue(Date date) {
        Date nowDate = new Date();
        long value = date.getTime() - nowDate.getTime();
        double ceil = Math.ceil((double) value / (1000));
        return (long) ceil;
    }


    /**
     * 构建查询时间
     *
     * @param queryTime
     * @param queryTimeUnit
     * @return
     */
    private static Map<String, String> getQueryTimeRangeNew(int queryTime, int queryTimeUnit) {
        Calendar rightNow = Calendar.getInstance();
        Date date = new Date();
        rightNow.setTime(date);
        if (queryTimeUnit == 1) {
            rightNow.add(Calendar.HOUR_OF_DAY, queryTime);
        } else if (queryTimeUnit == 2) {
            rightNow.add(Calendar.DAY_OF_YEAR, queryTime);
        } else if (queryTimeUnit == 3) {
            rightNow.add(Calendar.MONTH, queryTime);
        } else if (queryTimeUnit == 4) {
            rightNow.add(Calendar.YEAR, queryTime);
        } else if (queryTimeUnit == 5) {
            rightNow.add(Calendar.YEAR, queryTime);
        }
        Map<String, String> resultMap = new HashMap<>();
        String endTime = DateUtils.formatDateTime(date, DateUtils.DATE_FORMAT_STRING1);
        String startTime = DateUtils.formatDateTime(rightNow.getTime(), DateUtils.DATE_FORMAT_STRING1);
        resultMap.put("endTime", endTime);
        resultMap.put("startTime", startTime);
        return resultMap;
    }


    /**
     * 地铁封堵接口
     * @param ip
     * @param ipPluggingTask
     * @param msg
     * @return
     */
    public String dtPluMethod(String ip, TbIpPluggingTask ipPluggingTask, String msg) {
        try {
            RedisUtil redisUtil = GetSpringBean.getBean(RedisUtil.class);
            // TODO 执行封堵接口
            String blockToken = (String) redisUtil.getValue(BLOCK_LOGIN);
            List<SysDictData> blockUrl = DictUtil.getDict("block_url");
            if (StringUtils.isEmpty(blockToken)) {
                if (null != blockUrl) {
                    Map<String, SysDictData> collect = blockUrl.stream().collect(Collectors.toMap(SysDictData::getDictLabel, headers -> headers));
                    String loginUrl = collect.get("login_url").getDictValue();
                    String loginUserName = collect.get("login_user_name").getDictValue();
                    String loginPassword = collect.get("login_password").getDictValue();
                    Map<String, String> map = new HashMap<>();
                    map.put("username", loginUserName);
                    map.put("password", loginPassword);
                    log.info("登录接口url为:{}", loginUrl);
                    String s = HttpUtil.post(loginUrl, JSON.toJSONString(map));
                    log.info("登录返回值为:{}", s);
                    JSONObject jsonObject = JSON.parseObject(s);
                    Object code = jsonObject.get("code");
                    if (code.equals(200)) {
                        blockToken = (String) jsonObject.get("data");
                        redisUtil.setValue(BLOCK_LOGIN, blockToken, 30L, TimeUnit.MINUTES);
                    } else {
                        log.error("登录接口查询失败，查询结果为:{}", s);
                    }
                }
            }
            /**
             * 查询环境id接口
             */
            String deviceUrl = "";
            List<SysDictData> getEnvironment = blockUrl.stream().filter(sysDictData -> sysDictData.getDictLabel().equals("get_environment")).collect(Collectors.toList());
            for (int m = 0; m < getEnvironment.size(); m++) {
                SysDictData sysDictData = getEnvironment.get(0);
                deviceUrl = sysDictData.getDictValue();
                break;
            }
            log.info("获取环境id接口url为:{}", deviceUrl);
            String s = HttpUtils.sendPost(deviceUrl, "{\"filters\":{},\"search\":{},\"sorts\":{}}", blockToken);
            log.info("查询环境id接口返回值为:{}", s);
            JSONObject jsonObject1 = JSONObject.parseObject(s);
            String evnId = "";
            if (jsonObject1.get("code").equals(200)) {
                JSONArray jsonArray = jsonObject1.getJSONObject("data").getJSONObject("page").getJSONArray("list");
                for (int m = 0; m < jsonArray.size(); m++) {
                    JSONObject jsonObject2 = jsonArray.getJSONObject(m);
                    Object name = jsonObject2.get("name");
                    if (name.equals(ipPluggingTask.getExecDevice())) {
                        evnId = (String) jsonObject2.get("id");
                        break;
                    }
                }
            } else {
                log.error("获取执行设备环境失败,失败原因是:{}", jsonObject1);
            }
            if (StringUtils.isEmpty(evnId)) {
                msg = "执行设备不存在";
            } else {
                String blockSeal = "";
                String blockSealContent = "";
                List<SysDictData> getBlockSealList = blockUrl.stream().filter(sysDictData -> sysDictData.getDictLabel().equals("block_seal")).collect(Collectors.toList());
                for (int m = 0; m < getBlockSealList.size(); m++) {
                    SysDictData sysDictData = getBlockSealList.get(0);
                    blockSeal = sysDictData.getDictValue();
                    blockSealContent = sysDictData.getRemark();
                    break;
                }
                log.info("封堵接口url为:{}", blockSeal);
                String format = String.format(blockSealContent, evnId, UUID.randomUUID().toString(), ip);
                String s1 = HttpUtils.sendPost(blockSeal, format, blockToken);
                log.info("封堵接口返回值为:{}", s1);
                JSONObject jsonObject = JSONObject.parseObject(s1);
                if (!jsonObject.get("code").equals(200)) {
                    msg = (String) jsonObject.get("message");
                }
            }
        } catch (Exception e) {
            log.error("执行封堵IP操作失败，原因为:{}", e);
            msg = "调用封堵接口失败";
        }
        return msg;
    }

    /**
     * marvalnet封堵接口
     * @param ip
     * @param ipPluggingTask
     * @param msg
     * @return
     */
    public String marvalnetPluMethod(String ip, TbIpPluggingTask ipPluggingTask, String msg) {
        try {
            // TODO 执行封堵接口
            List<SysDictData> list = DictUtil.getDict("block_ip_api_url");
            String apiUrl = "";
            String remark = "";
            if (list != null && list.size() > 0) {
                apiUrl = list.get(0).getDictValue();
                remark = list.get(0).getRemark();
            }
            if (StringUtils.isBlank(apiUrl)) {
                log.error("未配置IP封堵URL，字典【block_ip_api_url】");
                throw new CustomException("未配置IP封堵URL，字典【block_ip_api_url】", 601);
            }
            JSONObject json = new JSONObject();
            json.put("id", System.currentTimeMillis());
            json.put("remark", "STP下发IP封堵");
            json.put("ip_list", Collections.singletonList(ip));
            log.info(apiUrl + "-》封堵IP:" + json.toJSONString());
            HashMap<String, String> headerMap = new HashMap<>();
            if (StringUtils.isNotBlank(remark)) {
                JSONObject jsonObject = JsonUtils.parse(remark);
                jsonObject.forEach((k,v)->{
                    try {
                        headerMap.put(k, v.toString());
                    } catch (Exception e) {
                        log.error(e.getMessage(),e);
                    }
                });
            }
            log.info("开始执行IP封堵，路径为：{},参数为:{}", apiUrl, json.toJSONString());
            String ret = HttpUtils.sendPost(apiUrl, json.toJSONString(),headerMap);
            log.info("执行解封接口返回值为:{}", ret);
            JSONObject jsonObject = JsonUtils.parse(ret);
            if (null == jsonObject || jsonObject.size() == 0) {
                String desc = "接口调用失败";
                log.info("{}解封失败:{}" + desc, ip);
                msg = "解封IP失败," + desc;
            } else {
                String returnCode = JsonUtils.getStr(jsonObject, "RETURN_CODE");
                String desc = JsonUtils.getStr(jsonObject, "RETURN_DESC");
                if (StringUtils.isNotEmpty(returnCode) && returnCode.equalsIgnoreCase("E")) {
                    log.info("IP:{}解封失败:{}" + ip, desc);
                    msg = "解封IP失败," + desc;
                } else if (StringUtils.isNotEmpty(returnCode) && returnCode.equalsIgnoreCase("S")) {
                    log.info("解封成功！{}", ip);
                }
            }
        } catch (Exception e) {
            log.error("执行封堵IP操作失败，原因为:{}", e);
            msg = "封堵IP失败";
        }
        return msg;
    }

    /**
     * marvalnet封堵接口
     * @param ip
     * @param
     * @param msg
     * @return
     */
    public String marvalnetJTMethod(String ip,  AtomicBoolean resultFlag,String devIp ,String msg) {
        try {
            //执行封堵接口
            List<SysDictData> marvelnetBlockConfig = DictUtil.getDict("marvelnet_block_config");
            if (CollUtil.isEmpty(marvelnetBlockConfig)) {
                log.info("执行V1版本封堵");
                JSONObject jsonObject = MarvalnetConfig.blockIpV1(ip);
                if (null == jsonObject || jsonObject.size() == 0) {
                    String desc = "接口调用失败";
                    log.info("{}封堵失败:{}", desc, ip);
                    msg = "封堵IP失败," + desc;
                } else {
                    String desc = JsonUtils.getStr(jsonObject, "RETURN_DESC");
                    if ("Success".equalsIgnoreCase(desc)) {
                        log.info("封堵成功！{}", ip);
                    } else {
                        log.info("IP:{}封堵失败:{}", ip, desc);
                        msg = "封堵IP失败," + desc;
                    }
                }
            } else {
                log.info("执行V2版本封堵");
                msg = MarvalnetConfig.blockIpV2(ip, devIp);
            }
        } catch (Exception e) {
            log.error(",执行封堵IP操作失败，原因为:{}", e.getMessage(), e);
            msg = ",封堵IP失败Error," + ip;
        }
        return msg;
    }

    /**
     * redis 定时解封任务key
     * @param request
     * @param type
     * @param finalUserNameLabel
     * @param id
     */
    public void redisUnSealTask(TbIpPluggingTask request, boolean type, String finalUserNameLabel, String id) {
        String redisKey = IP_TASK + "##" + id + "##" + "1" + "##";
        boolean redisFlag = true;
        Long timeValue = getTimeValue(request.getDeadlineTime());
        RedisUtil redisUtil = GetSpringBean.getBean(RedisUtil.class);
        List<String> keyByPrefix = redisUtil.getKeyByPrefix(redisKey);
        for (int m = 0; m < keyByPrefix.size(); m++) {
            String s = keyByPrefix.get(m);
            long expireByKey = redisUtil.getExpireByKey(s);
            if (expireByKey < timeValue) {
                redisUtil.removeValue(s);
            } else {
                redisFlag = false;
            }
        }
        if (redisFlag) {
            redisKey = redisKey + request.getCreateByLabel();
            redisKey = redisKey + "##" + "null";
            if (timeValue > 0) {
                redisUtil.setValue(redisKey, redisKey, timeValue, TimeUnit.SECONDS);
            }
        }
    }
}
