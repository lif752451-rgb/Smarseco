package com.crc.secface.schedule;

import com.crc.common.utils.DateUtils;
import com.crc.sync.system.CleanAlarmTmp;
import lombok.extern.slf4j.Slf4j;
import org.springframework.boot.CommandLineRunner;
import org.springframework.scheduling.annotation.EnableScheduling;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Component;

import java.util.Date;

/**
 * @author simba@onlying.cn
 * @date 2020/10/26 21:53
 */
@Slf4j
@Component
@EnableScheduling
public class ClearTaskScheduler implements CommandLineRunner {

    @Scheduled(cron = "0 0/59 * * * ?")
    public void clear() {
        System.out.println(this.getClass().toString() + " Start! " + DateUtils.getDateTimeString1(new Date()));
        /**
         * Do something
         */
        try {
            (new CleanAlarmTmp()).clean();
        } catch (Exception e) {
            log.error(e.getMessage(), e);
        }
        System.out.println(this.getClass().toString() + "  end! " + DateUtils.getDateTimeString1(new Date()));
    }

    @Override
    public void run(String... args) throws Exception {
        clear();
    }
}
