package com.crc.secface.schedule;

import com.crc.common.utils.DateUtils;
import com.crc.secface.entity.SysDictData;
import com.crc.secface.entity.TbEventModel;
import com.crc.secface.mapper.SysDictDataMapper;
import com.crc.secface.mapper.TbEventModelMapper;
import com.crc.secface.schedule.manager.AccurateAlarmJobManager;
import com.crc.secface.schedule.manager.AggAlarmJobManager;
import com.crc.secface.schedule.manager.RelationAlarmJobManager;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.core.env.Environment;
import org.springframework.scheduling.annotation.EnableScheduling;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Component;

import java.util.HashMap;
import java.util.List;


/**
 * 告警引擎调度中心
 */
@Slf4j
@Component
@EnableScheduling
public class AlarmJobSchedule implements CommandLineRunner {
    @Autowired
    SysDictDataMapper sysDictDataMapper;
    @Autowired
    TbEventModelMapper tbEventModelMapper;
    @Autowired
    Environment environment;

    @Scheduled(cron = "0 0/1 * * * ?")
    public void sync() {
        try {
            if (!"T".equalsIgnoreCase(environment.getProperty("deploy.alarm"))) {
                log.info("不分析告警");
                return;
            }

            //q.setModeClassify("1");
            List<SysDictData> attackTypeList = sysDictDataMapper.selectDictDataByType("attack_type");
            List<SysDictData> esIndexList = sysDictDataMapper.selectDictDataByType("alarm_model_es_index");
            List<SysDictData> eventAttackResultList = sysDictDataMapper.selectDictDataByType("event_attack_result");
            List<SysDictData> attackLevelList = sysDictDataMapper.selectDictDataByType("alarm_level");
            List<SysDictData> devicenameList = sysDictDataMapper.selectDictDataByType("rule_base");
            List<SysDictData> keywordList = sysDictDataMapper.selectDictDataByType("dont_combine_alarm_keyword");

            //精确告警
            TbEventModel q = new TbEventModel();
            q.setStatus("0");
            q.setModelType("1");
            List<TbEventModel> modelList = tbEventModelMapper.selectTbEventModelList(q);
            convertModel(modelList, attackTypeList, eventAttackResultList, attackLevelList, devicenameList, esIndexList, keywordList);
            accurate(modelList);
            //聚合告警
            List<TbEventModel> aggModeList = tbEventModelMapper.findAviableAggsEvent();
            convertModel(aggModeList, attackTypeList, eventAttackResultList, attackLevelList, devicenameList, esIndexList, keywordList);
            agg(aggModeList);
            //关联告警

            q.setModelType("3");
            List<TbEventModel> eventModelList = tbEventModelMapper.selectTbEventModelList(q);
            convertModel(eventModelList, attackTypeList, eventAttackResultList, attackLevelList, devicenameList, esIndexList, keywordList);
            relation(eventModelList);
        } catch (Exception e) {
            log.error(e.getMessage(),e);
        }
    }

    /**
     * 关联告警
     * @param modelList
     */
    private void relation(List<TbEventModel> modelList) {
        try {
            log.info("关联告警模型数量: {}",modelList.size());
            HashMap<String, String> linshiMap = new HashMap<>();
            for (TbEventModel tm : modelList) {
                if (RelationAlarmJobManager.tempMap.containsKey(tm.getModelId())) {
                    //已启动
                    //判断版本号是否一致
                    String curVer = DateUtils.getDateTimeString1(tm.getUpdateTime());
                    String tempVer = DateUtils.getDateTimeString1(RelationAlarmJobManager.tempMap.get(tm.getModelId()).getUpdateTime());
                    if (!curVer.equals(tempVer)) {
                        //版本更新
                        //stop
                        RelationAlarmJobManager.deleteJob(tm);
                        //start
                        RelationAlarmJobManager.startJob(tm);
                    }
                } else {
                    //新任务需启动
                    RelationAlarmJobManager.startJob(tm);
                }
                linshiMap.put(tm.getModelId(), tm.getModelId());
            }
            HashMap<String, String> linshiMap2 = new HashMap<>();
            RelationAlarmJobManager.tempMap.forEach((k, v) -> {
                if (!linshiMap.containsKey(k)) {
                    //已停止
                    RelationAlarmJobManager.deleteJob(v);
                    linshiMap2.put(k, k);
                    log.info("Stop Job: {}-{}",k,v.getModelName());
                }
            });
            linshiMap2.forEach((k, v) -> {
                RelationAlarmJobManager.tempMap.remove(k);
            });
        } catch (Exception e) {
            log.error(e.getMessage(), e);
        }
    }

    /**
     * 聚合告警
     * @param modelList
     */
    private void agg(List<TbEventModel> modelList) {
        try {
            log.info("聚合告警: {}",modelList.size());
            HashMap<String, String> linshiMap = new HashMap<>();
            for (TbEventModel tm : modelList) {
                if (AggAlarmJobManager.tempMap.containsKey(tm.getModelId())) {
                    //已启动
                    //判断版本号是否一致
                    String curVer = DateUtils.getDateTimeString1(tm.getUpdateTime());
                    String tempVer = DateUtils.getDateTimeString1(AggAlarmJobManager.tempMap.get(tm.getModelId()).getUpdateTime());
                    if (!curVer.equals(tempVer)) {
                        //版本更新
                        //stop
                        AggAlarmJobManager.deleteJob(tm);
                        //start
                        AggAlarmJobManager.startJob(tm);
                    }
                } else {
                    //新任务需启动
                    AggAlarmJobManager.startJob(tm);
                }
                linshiMap.put(tm.getModelId(), tm.getModelId());
            }
            HashMap<String, String> linshiMap2 = new HashMap<>();
            AggAlarmJobManager.tempMap.forEach((k, v) -> {
                if (!linshiMap.containsKey(k)) {
                    //已停止
                    AggAlarmJobManager.deleteJob(v);
                    linshiMap2.put(k, k);
                    log.info("Stop Job: {}-{}",k,v.getModelName());
                }
            });
            linshiMap2.forEach((k, v) -> {
                AggAlarmJobManager.tempMap.remove(k);
            });
        } catch (Exception e) {
            log.error(e.getMessage(), e);
        }
    }

    /**
     * 精确告警
     * @param modelList
     */
    private void accurate(List<TbEventModel> modelList) {
        try {
            log.info("精确告警: {}",modelList.size());
            HashMap<String, String> linshiMap = new HashMap<>();
            for (TbEventModel tm : modelList) {
                if (AccurateAlarmJobManager.tempMap.containsKey(tm.getModelId())) {
                    //已启动
                    //判断版本号是否一致
                    String curVer = DateUtils.getDateTimeString1(tm.getUpdateTime());
                    String tempVer = DateUtils.getDateTimeString1(AccurateAlarmJobManager.tempMap.get(tm.getModelId()).getUpdateTime());
                    if (!curVer.equals(tempVer)) {
                        //版本更新
                        //stop
                        AccurateAlarmJobManager.deleteJob(tm);
                        //start
                        AccurateAlarmJobManager.startJob(tm);
                    }
                } else {
                    //新任务需启动
                    AccurateAlarmJobManager.startJob(tm);
                }
                linshiMap.put(tm.getModelId(), tm.getModelId());
            }
            HashMap<String, String> linshiMap2 = new HashMap<>();
            AccurateAlarmJobManager.tempMap.forEach((k, v) -> {
                if (!linshiMap.containsKey(k)) {
                    //已停止
                    AccurateAlarmJobManager.deleteJob(v);
                    linshiMap2.put(k, k);
                    log.info("Stop Job: {}-{}",k,v.getModelName());
                }
            });
            linshiMap2.forEach((k, v) -> {
                AccurateAlarmJobManager.tempMap.remove(k);
            });
        } catch (Exception e) {
            log.error(e.getMessage(), e);
        }
    }

    private void convertModel(List<TbEventModel> modelList,List<SysDictData> attackTypeList,List<SysDictData> eventAttackResultList,List<SysDictData> attackLevelList,List<SysDictData> devicenameList,List<SysDictData> esIndexList,List<SysDictData> keywordList){
        //模型计算数量
        modelList.forEach(model -> {
            model.setKeywordList(keywordList);
            try {
                String firstLabel = null;
                for (SysDictData dict : attackTypeList) {
                    if (StringUtils.isBlank(firstLabel)) {
                        firstLabel = dict.getDictLabel();
                    }
                    if (StringUtils.isNotBlank(model.getAttackType()) && model.getAttackType().equals(dict.getDictValue())) {
                        model.setAttackTypeName(dict.getDictLabel());
                        break;
                    }
                }
                if (StringUtils.isBlank(model.getAttackTypeName())) {
                    model.setAttackTypeName(firstLabel);
                }
                for (SysDictData dict : eventAttackResultList) {
                    if (StringUtils.isNotBlank(model.getAttackResult()) && model.getAttackResult().equals(dict.getDictValue())) {
                        model.setAttackResultName(dict.getDictLabel());
                        break;
                    }
                }

                for (SysDictData dict : attackLevelList) {
                    if (StringUtils.isNotBlank(model.getEventLevel()) && model.getEventLevel().equals(dict.getDictValue())) {
                        model.setEventLevelName(dict.getDictLabel());
                        break;
                    }
                }
                for (SysDictData dict : devicenameList) {
                    if (StringUtils.isNotBlank(model.getDeviceName()) && model.getDeviceName().equals(dict.getDictValue())) {
                        model.setDeviceNameStr(dict.getDictLabel());
                        break;
                    }
                }
                for (SysDictData dict : esIndexList) {

                    if (dict.getDictValue().equals(model.getEsIndex())) {
                        String remark = "";
                        try {
                            String str = dict.getDictLabel();
                            str = str.replace("(", " ").replace("（", " ").replace(")", "").replace("）", " ").replace("  ", " ");
                            String[] arr = str.split(" ");
                            model.setEsIndexId(model.getEsIndex());
                            model.setEsIndexName(arr[1]);
                            remark = dict.getRemark();
                        } catch (Exception e) {
                            log.error(model.getModelId() + " " + e.getMessage(), e);
                        }
                        if (StringUtils.isNotBlank(dict.getRemark())) {
                            model.setEsIndexStr(dict.getRemark());
                        }
                        model.setTimeRemark(remark);
                    }
                }

            } catch (Exception e) {
                log.error(model.getModelId() + " " + e.getMessage(), e);
            }
        });
    }


    @Override
    public void run(String... args) throws Exception {
        sync();
    }
}
