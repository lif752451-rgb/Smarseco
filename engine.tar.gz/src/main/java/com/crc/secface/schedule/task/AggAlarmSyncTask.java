package com.crc.secface.schedule.task;

import cn.hutool.core.collection.CollUtil;
import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONArray;
import com.alibaba.fastjson.JSONObject;
import com.crc.common.constants.Constants;
import com.crc.common.constants.LogConstantsX;
import com.crc.common.paser.KqlParser;
import com.crc.common.paser.KqlResult;
import com.crc.common.paser.TreeParser;
import com.crc.common.utils.*;
import com.crc.model.EsConditionTree;
import com.crc.model.EsEventParams;
import com.crc.secface.argo.AlarmUtils;
import com.crc.secface.argo.CombatUtils;
import com.crc.secface.config.EsDataSource;
import com.crc.secface.config.GetSpringBean;
import com.crc.secface.config.SyncSecConfig;
import com.crc.secface.entity.*;
import com.crc.secface.es.EsSingleFactory;
import com.crc.secface.mapper.TbAssetMapper;
import com.crc.secface.mapper.TbOriDangerEventMapper;
import com.crc.secface.schedule.manager.AggAlarmJobManager;
import com.crc.secface.service.WhitelistService;
import com.crc.sync.send.SendEventExecutor;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.elasticsearch.action.search.SearchPhaseExecutionException;
import org.elasticsearch.action.search.SearchRequest;
import org.elasticsearch.action.search.SearchResponse;
import org.elasticsearch.client.RequestOptions;
import org.elasticsearch.client.RestHighLevelClient;
import org.elasticsearch.index.query.BoolQueryBuilder;
import org.elasticsearch.index.query.QueryBuilders;
import org.elasticsearch.index.query.RangeQueryBuilder;
import org.elasticsearch.search.SearchHit;
import org.elasticsearch.search.SearchHits;
import org.elasticsearch.search.aggregations.bucket.terms.Terms;
import org.elasticsearch.search.builder.SearchSourceBuilder;
import org.elasticsearch.search.sort.FieldSortBuilder;
import org.elasticsearch.search.sort.SortOrder;
import org.quartz.*;

import java.math.BigInteger;
import java.util.*;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import static com.crc.common.constants.DictTypeEnum.ALARM_MODEL_DEVICENAME;

/**
 * 聚合告警分析
 */
@Slf4j
@DisallowConcurrentExecution
public class AggAlarmSyncTask implements Job {
    @Override
    public void execute(JobExecutionContext context) throws JobExecutionException {
        if (!SyncSecConfig.isEnable("sync_sec_config", "send_agg_alarm")) {
            return;
        }
        JobDataMap map = context.getJobDetail().getJobDataMap();
        TbEventModel model = (TbEventModel) map.get(AggAlarmJobManager.KEY_NAME);
        try {
            sync(model);
        } catch (Exception e) {
            log.error(e.getMessage(), e);
        }
    }

    private void sync(TbEventModel model) {
        RestHighLevelClient client = null;
        try {
            EsDataSource esDataSource = EsEventModelUtils.logSourceCheck(model);
            if (StringUtils.isBlank(esDataSource.getHost())) {
                log.error(model.getModelId() + ",ES数据源配置有问题");
            }
            client = EsSingleFactory.getInstance().getHighLevelClientHigh(esDataSource);
        } catch (Exception e) {
            log.error(model.getModelId() + " " + model.getEsConfig() + " " + model.getEsIndexId() + ",es配置失败:{}", e.getMessage(), e);
            return;
        }

        try {
            queryLogList(model, client);
        } catch (Exception e) {
            log.error("规则模型[{}] 执行异常:{}", model.getModelId(), e);
        } finally {
            EsSingleFactory.getInstance().close(client);
        }
    }

    /**
     * 查询告警日志
     *
     * @param model 模型
     */
    public void queryLogList(TbEventModel model,  RestHighLevelClient client) {
        BoolQueryBuilder boolQueryBuilder = QueryBuilders.boolQuery();
        if ("1".equals(model.getOperateType())) {
            //规则树模式
            BoolQueryBuilder boolQuery = TreeParser.toDsl(model.getJsonParam());
            if (EsUtils.isBlankQuery(boolQuery)) {
                log.error("树模型通用配置参数不完整，请检查" + model.getModelName() + " " + model.getModelId());
                return;
            }
            boolQueryBuilder.filter(boolQuery);
        } else if ("2".equals(model.getOperateType())) {
            //KQL模式
            KqlParser parser = new KqlParser(model.getModelId());
            KqlResult result = parser.parse(model.getJsonParam());
            if (result.getCode() == 0) {
                if (EsUtils.isBlankQuery(result.getQuery())) {
                    log.error("KQL模型通用配置参数不完整，请检查" + model.getModelName() + " " + model.getModelId());
                    return;
                }
                boolQueryBuilder.filter(result.getQuery());
            } else {
                log.error("KQL模型通用配置参数不完整，请检查" + model.getModelName() + " " + model.getModelId());
                return;
            }
        }
        if (EsUtils.isBlankQuery(boolQueryBuilder)) {
            return;
        }

        SearchSourceBuilder sourceBuilder = new SearchSourceBuilder();
        sourceBuilder.sort(new FieldSortBuilder(model.getSortKey()).order(SortOrder.DESC));
        //先查询聚合结果,不需要原始数据
        sourceBuilder.size(0);

        List<Map<String, String>> aggAlarmTime = getAggAlarmTime(model);
        EsEventParams params = EsEventModelUtils.createEsQuery(model, sourceBuilder, aggAlarmTime, boolQueryBuilder);
        model.setParams(params);
        sourceBuilder.query(boolQueryBuilder);
        try {
            SearchRequest searchRequest = new SearchRequest(model.getEsIndexName());
            searchRequest.source(sourceBuilder);
            SearchResponse response = client.search(searchRequest, RequestOptions.DEFAULT);
            int value = 1;
            EsConditionTree newTree = new EsConditionTree();
            BeanUtils.copyBeanProp(newTree, params.getTree());
            String s = EsEventModelUtils.ergodicObtainTree(newTree);
            if (response.getAggregations() == null) {
                log.info(model.getModelId() + ",根据聚合条件查询聚合结果为空");
                return;
            }
            Terms group = response.getAggregations().get(s);
            Map<String, Object> alarmMsg = EsEventModelUtils.createAlarmMsg(group, model, value, newTree, new HashMap<>(), params);
            if (CollUtil.isEmpty(alarmMsg)) {
                log.info(model.getModelId() + ",根据聚合条件查询聚合结果为空");
                return;
            }
            List<Map<String, String>> resultMap1 = (List<Map<String, String>>) alarmMsg.get("resultMap");
            model.setAlarmMsg(resultMap1);

            /*
             * 获取去重字段
             */
            boolean eventNameFlag = false;
            boolean attackIpFlag = false;
            boolean sufferIpFlag = false;
            boolean alarmDescTypeFlag = false;
            boolean deviceTypeFlag = false;
            if (model.getAlarmType() == 1) {
                eventNameFlag = true;
            }
            if (model.getAttackIpType() == 1) {
                attackIpFlag = true;
            }
            if (model.getSufferIpType() == 1) {
                sufferIpFlag = true;
            }
            if (model.getAlarmDescType() == 1) {
                alarmDescTypeFlag = true;
            }
            if (model.getDeviceType() == 1) {
                deviceTypeFlag = true;
            }
            for (Map<String, String> alarmMap : resultMap1) {
                /*
                 * 处理聚合结果
                 */
                alarmMap.put("attackType", model.getAttackTypeName());
                alarmMap.put("eventLevel", model.getEventLevel());
                alarmMap.put("attackResult", model.getAttackResult());
                if (eventNameFlag) {
                    alarmMap.put("eventName", model.getEventName());
                }
                if (attackIpFlag) {
                    alarmMap.put("attackIp", model.getAttackIp());
                }

                if (sufferIpFlag) {
                    alarmMap.put("sufferIp", model.getSufferIp());
                }
                if (alarmDescTypeFlag) {
                    alarmMap.put("alarmDesc", model.getAlarmDesc());
                }
                if (deviceTypeFlag) {
                    SysDictData sysDictData = getLabelByTypeAndVal(ALARM_MODEL_DEVICENAME.getName(), model.getDeviceName());
                    if (null != sysDictData) {
                        String deviceName = sysDictData.getDictLabel();
                        alarmMap.put("deviceNameLabel", (null == deviceName ||
                                "".equals(deviceName)) ? model.getDeviceName() : deviceName);
                    }
                }

                //攻击ip
                String attackIp = alarmMap.get("attackIp");
                //受害ip
                String sufferIp = alarmMap.get("sufferIp");

                int emptyIp = 0;
                if (StringUtils.isBlank(attackIp)) {
                    log.warn("1根据攻击ip和受害ip查询原始日志结果包含空值,进行0.0.0.0补充,attackIp:{}, sufferIp:{}", attackIp, sufferIp);
                    List<String> ipList = IpUtils.getIpsX(model.getAttackIp());
                    if (ipList.size() > 0) {//聚合告警出来的值很有可能多个拼接
                        attackIp = String.join(",", ipList);
                    } else {
                        attackIp = "0.0.0.0";
                    }
                    emptyIp++;
                }
                if (StringUtils.isBlank(sufferIp)) {
                    log.warn("2根据攻击ip和受害ip查询原始日志结果包含空值,进行0.0.0.0补充,attackIp:{}, sufferIp:{}", attackIp, sufferIp);
                    List<String> ipList = IpUtils.getIpsX(model.getSufferIp());
                    if (ipList.size() > 0) {
                        sufferIp = String.join(",", ipList);
                    } else {
                        sufferIp = "0.0.0.0";
                    }
                    emptyIp++;
                }
                //ip进行排序
                attackIp = sortIp(attackIp);
                sufferIp = sortIp(sufferIp, attackIp);
                alarmMap.put("attackIp", attackIp);
                alarmMap.put("sufferIp", sufferIp);
                //根据kql和攻击ip,受害ip查询原始日志数据
                Map<String, List<String>> map = new HashMap<>(2);
                if (emptyIp != 2) {
                    /*
                     * 存在场景，账号爆破，操作系统日志可能不带IP，系统会自动补充0.0.0.0,但不能当中查询条件；hejs
                     */
                    //攻击ip
                    String attackIp1 = model.getAttackIp();
                    int attackIpType = model.getAttackIpType();
                    if (attackIpType == 0) {
                        attackIp1 = replaceOutput(attackIp1);
                        try {
                            int i1 = DataUtils.toInt(attackIp1);
                            if (i1 > 0) {
                                /*
                                 * 说明是数字，则需要从聚合条件中获取字段值
                                 */
                                String aggParams = model.getAggParams();
                                JSONArray jsonArray = JSON.parseArray(aggParams);
                                for (int i2 = 0; i2 < jsonArray.size(); i2++) {
                                    if (i2 == i1 - 1) {
                                        JSONObject jsonObject = jsonArray.getJSONObject(i2);
                                        attackIp1 = (String) jsonObject.get("aggFields");
                                        break;
                                    }
                                }
                            }
                        } catch (Exception e) {
                            log.error(e.getMessage(), e);
                        }
                    }
                    map.put(attackIp1, Arrays.asList(attackIp.split(Constants.Symbol.COMMA)));

                    //受害ip
                    String sufferIp1 = model.getSufferIp();
                    int sufferIpType = model.getSufferIpType();
                    if (sufferIpType == 0) {
                        sufferIp1 = replaceOutput(sufferIp1);
                        try {
                            int i1 = DataUtils.toInt(sufferIp1);
                            if (i1 > 0) {
                                /*
                                 * 说明是数字，则需要从聚合条件中获取字段值
                                 */
                                String aggParams = model.getAggParams();
                                JSONArray jsonArray = JSON.parseArray(aggParams);
                                for (int i2 = 0; i2 < jsonArray.size(); i2++) {
                                    if (i2 == i1 - 1) {
                                        JSONObject jsonObject = jsonArray.getJSONObject(i2);
                                        sufferIp1 = (String) jsonObject.get("aggFields");
                                        break;
                                    }
                                }
                            }
                        } catch (Exception e) {
                            log.error(e.getMessage(), e);
                        }
                    }
                    map.put(sufferIp1, Arrays.asList(sufferIp.split(Constants.Symbol.COMMA)));
                }
                //获取原始日志结果
                List<LogData> logList = queryLogOriginalData(model, map, client);
                log.info(model.getModelId() + " " + alarmMap.get("eventName") + " 攻击Ip:" + attackIp + ", 受害ip：" + sufferIp + " -发现:" + logList.size());
                if (!CollUtil.isEmpty(logList)) {
                    processEvent(logList, model, alarmMap);
                }
            }
            if (resultMap1.size() < 1) {
                try {
                    log.error("KQL模型没有查询出数据,模型名称：'{}',id={},alarmMsg={}", model.getModelName(), model.getModelId(), JSON.toJSONString(alarmMsg));
                } catch (Exception ignored) {

                }
            }
        } catch (SearchPhaseExecutionException e) {
            log.error(model.getModelId() + " " + sourceBuilder + " " + e.getMessage(), e);
        } catch (Exception e) {
            log.error(model.getModelId() + " " + e.getMessage(), e);
        }
    }

    /**
     * 处理清晰告警日志
     *
     * @param curList
     * @param modelInfo
     * @param alarmMap
     */
    public void processEvent(List<LogData> curList, TbEventModel modelInfo,  Map<String, String> alarmMap) {
        try {
            log.info(modelInfo.getModelId() + ",告警关联结果：" + JSON.toJSONString(alarmMap));
            log.info(modelInfo.getModelId() + ",告警关联原始日志数：" + curList.size());
            //数据已经聚合所以暂时去第一条数据
            JSONObject msg = JsonUtils.parse(curList.get(0).getData());
            List<String> idList = new ArrayList<>();
            /**
             * 数量太大，最多取200条
             */
            for (int i = 0; i < curList.size() && i < 200; i++) {
                idList.add(curList.get(i).getId());
            }
            String ids = String.join(",", idList);
            msg.put("ids", ids);
            //msg.put(LogConstants.ES_LOG_INDEX, modelInfo.getEsIndex());

            //msg.remove(LogConstantsX.LOG_ORI_MSG);

            saveData(msg, modelInfo, alarmMap);

        } catch (Exception e) {
            log.error(e.getMessage(), e);
        }
    }


    public void saveData(JSONObject job, TbEventModel modelInfo, Map<String, String> alarmMap) {
        /**
         * 字段映射
         */
        String json = modelInfo.getTimeRemark();
        JSONObject jsonObject = new JSONObject();
        if (StringUtils.isNotEmpty(json)) {
            jsonObject = JsonUtils.parse(json);
        }
        String srcIp = alarmMap.get("attackIp");
        String destIp = alarmMap.get("sufferIp");
        String product = alarmMap.get("deviceNameLabel");
        String logName = alarmMap.get("eventName");
        String logType = modelInfo.getAttackTypeName();
        String logLevel = modelInfo.getEventLevelName();

        String startTime = "";
        String startField = JsonUtils.getStr(jsonObject, "告警时间");
        if (StringUtils.isBlank(startTime)) {
            if (StringUtils.isBlank(startField)) {
                startField = JsonUtils.getStr(jsonObject, "入库时间");
            }
        }
        if (StringUtils.isNotBlank(startField) && job.containsKey(startField)) {
            startTime = JsonUtils.getStr(job, startField);
        }
        if (StringUtils.isBlank(startTime)) {
            startTime = JsonUtils.getStr(job, LogConstantsX.LOG_START_TIME);
        }
        startTime = DateUtils.UTCToCSTAndCheck(startTime);
        if (StringUtils.isBlank(startTime)) {
            startTime = DateUtils.UTCToCST(JsonUtils.getStr(job, LogConstantsX.LOG_TIME));
        }
        job.put(LogConstantsX.LOG_START_TIME, startTime);

        job.put(LogConstantsX.SRC_IP, srcIp);
        job.put(LogConstantsX.DEST_IP, destIp);

        String eventDesc = alarmMap.get("alarmDesc");
        if (StringUtils.isNotBlank(eventDesc))
            job.put(LogConstantsX.ALERT_NAME, eventDesc);
        String actionResultField = JsonUtils.getStr(jsonObject, "攻击结果");
        String actionResult = "";
        if (StringUtils.isBlank(actionResultField) && job.containsKey(actionResultField)) {
            actionResult = JsonUtils.getStr(job, actionResultField);
        }
        if (StringUtils.isEmpty(actionResult)) {
            actionResult = JsonUtils.getStr(job, LogConstantsX.ACTION_RESULT);
        }
        TbAssetMapper tbAssetMapper = GetSpringBean.getBean(TbAssetMapper.class);
        long times = JsonUtils.getLong(job, "times");
        String ids = JsonUtils.getStr(job, "ids");
        job.put(LogConstantsX.EVENT_TIME, startTime);
        job.put(LogConstantsX.ES_LOG_NAME, logName);
        job.put(LogConstantsX.LOG_PRODUCT, product);
        job.put(LogConstantsX.LOG_NAME, logName);

        TbOriDangerEvent event = new TbOriDangerEvent();
        event.setId(IdGen.uuid());
        event.setAlertLevel(logLevel);
        event.setData(startTime);
        event.setTimes(times);
        event.setDelFlag(0);

        event.setEventDesc(eventDesc);
        event.setSrcIp(srcIp);
        String whitelist = WhitelistService.isMatchV2(modelInfo, job, true) ? "1" : "0";
        event.setIsWhitelist(whitelist);
        if ("1".equalsIgnoreCase(whitelist)) {
            //hejs 白名单过滤
            log.warn(modelInfo.getModelId() + " " + srcIp + " => " + destIp + "命中白名单！" + eventDesc);
            return;
        } else {
            destIp = job.getString(LogConstantsX.DEST_IP);
        }
        /**
         * 源IP没有的不发告警
         */
        if (StringUtils.isBlank(srcIp)) {
            log.error("源IP没有的不发告警");
            return;
        }

        event.setStatus("0");
        event.setEventId(ids);
        event.setDestIp(destIp);

        event.setEventName(logName);
        job.put(LogConstantsX.IS_WHITELIST, whitelist);
        job.put(LogConstantsX.DEST_IP, destIp);
        event.setEventTime(new Date());
        event.setProduct(product);
        event.setEventType(logType);
        event.setActionResult(actionResult);
        event.setModelId(modelInfo.getModelId());

        /**
         * 相同IP 相同告警，时间间隔
         */
        long interval = 60 * 12;
        TbOriDangerEvent tbOriDangerEvent = new TbOriDangerEvent();
        tbOriDangerEvent.setSrcIp(event.getSrcIp());
        tbOriDangerEvent.setDestIp(event.getDestIp());
        tbOriDangerEvent.setEventName(event.getEventName());
        tbOriDangerEvent.setModelId(modelInfo.getModelId());
        // tbOriDangerEvent.setEventDesc(event.getEventDesc());
        TbOriDangerEventMapper oriDangerEventMapper = GetSpringBean.getBean(TbOriDangerEventMapper.class);
        TbOriDangerEvent eventSingle = oriDangerEventMapper.selectTbOriDangerByInfo(tbOriDangerEvent);
        boolean newEvent = false;
        if (eventSingle != null && StringUtils.isNotBlank(eventSingle.getId())) {
            long diff = (event.getEventTime().getTime() - eventSingle.getEventTime().getTime()) / 1000 / 60;
            // 根据eventTime判断时间是否在${alarmInterval}间隔内发送过告警，如果发送过则不再发送
            if (diff < interval) {
                log.info("配置间隔:" + interval + " 分钟，目前间隔：" + diff + " 分钟");
                log.info("已发送过:" + eventSingle.getEventName() + " " + eventSingle.getSrcIp() + " " + eventSingle.getDestIp());
                return;
            } else {
                if (event.getEventName() != null) {
                    event.setEventName(DataUtils.getShorter(event.getEventName(), 512));
                }
                oriDangerEventMapper.insertTbOriDangerEvent(event);
                newEvent = true;
            }
        } else {
            if (event.getEventName() != null) {
                event.setEventName(DataUtils.getShorter(event.getEventName(), 512));
            }
            oriDangerEventMapper.insertTbOriDangerEvent(event);
            newEvent = true;
        }
        if (newEvent) {
            /*
                 状态为 '研判/处置' 的一旦出现，则本条告警不推送；
                 */
            try {
                //String sql = "SELECT count(1) as total FROM tb_alarm_report WHERE order_status IN ('研判','处置') AND attack_ip = '%s' AND victimized_ip = '%s' AND title = '%s'";
                //String newSql = String.format(sql,event.getSrcIp(),event.getDestIp(),event.getEventName());
                SqlModel sqlModel = new SqlModel();
                sqlModel.setA1(event.getSrcIp());
                sqlModel.setA2(event.getDestIp());
                sqlModel.setA3(event.getEventName());
                int count = 0;
                if (CombatUtils.getCombatTime().isCombat()) {
                    count = tbAssetMapper.getProccessingAlarmCombatCount(sqlModel);
                } else {
                    count = tbAssetMapper.getProccessingAlarmCount(sqlModel);
                }
                if (count > 0) {
                    log.warn(modelInfo.getModelId() + " " + "工单存在相同告警，且未处置完毕！" + JSON.toJSONString(event));
                    return;
                }
            } catch (Exception e) {
                log.error(e.getMessage(), e);
            }
        }

        String allIp = String.format("%s#%s", srcIp, destIp);
        if (AlarmUtils.isReportAlarm("alarm_agg", modelInfo.getModelId(), allIp, JsonUtils.getStr(job, LogConstantsX.ALERT_NAME))) {
            return;
        }

        log.info("启动聚合告警推送新线程,modelId:{}", modelInfo.getModelId());

        job.put(LogConstantsX.BUS_MODEL, modelInfo.getModelId());
        job.put(LogConstantsX.RISK_IP, IpUtils.getRiskIp(tbOriDangerEvent.getSrcIp(), tbOriDangerEvent.getDestIp(), tbOriDangerEvent.getSrcIp()));
        job.put(LogConstantsX.ORI_EVENT_ID, event.getId());
        //生产环境
        DangerEventSendModel dangerEventSend = new DangerEventSendModel();
        dangerEventSend.setModel(modelInfo);
        dangerEventSend.setEventId(event.getId());

        dangerEventSend.setEventJson(job);
        dangerEventSend.setSendOp(1);
        log.info(modelInfo.getModelId() + ",###开始推送聚合告警：{}", event.getEventName());
        SendEventExecutor.doSend(dangerEventSend);
    }


    /**
     * 构建查询告警聚合的原始日志kql
     *
     * @param eventModel 模型
     */
    public List<LogData> queryLogOriginalData(TbEventModel eventModel, Map<String, List<String>> map, RestHighLevelClient client) {
        List<LogData> logList = new ArrayList<>();
        try {
            BoolQueryBuilder boolQueryBuilder = QueryBuilders.boolQuery();
            if ("1".equals(eventModel.getOperateType())) {
                //规则树模式
                BoolQueryBuilder boolQuery = TreeParser.toDsl(eventModel.getJsonParam());
                boolQueryBuilder.filter(boolQuery);
            } else if ("2".equals(eventModel.getOperateType())) {
                //KQL模式
                KqlParser parser = new KqlParser(eventModel.getModelId());
                KqlResult result = parser.parse(eventModel.getJsonParam());
                if (result.getCode() == 0) {
                    boolQueryBuilder.filter(result.getQuery());
                }
            }

            SearchSourceBuilder sourceBuilder = new SearchSourceBuilder();
            sourceBuilder.sort(new FieldSortBuilder(eventModel.getSortKey()).order(SortOrder.DESC));
            sourceBuilder.size(500);
            for (String filed : map.keySet()) {
                if (StringUtils.isBlank(filed)) {
                    continue;
                }
                boolQueryBuilder.filter(QueryBuilders.termsQuery(filed, map.get(filed)));
            }
            List<Map<String, String>> aggAlarmTime = getAggAlarmTime(eventModel);
            /*
             * 时间区间
             */
            aggAlarmTime.forEach(time -> {
                RangeQueryBuilder rangeQueryBuilder = QueryBuilders.rangeQuery(eventModel.getSortKey());
                String startTime = time.get("startTime");
                String endTime = time.get("endTime");
                rangeQueryBuilder.gte(startTime);
                rangeQueryBuilder.lte(endTime);
                //rangeQueryBuilder.format("yyyy-MM-dd HH:mm:ss||yyyy-MM-dd||epoch_millis");
                boolQueryBuilder.should(rangeQueryBuilder).minimumShouldMatch(1);
            });
            sourceBuilder.query(boolQueryBuilder);
            SearchResponse response = null;
            try {
                SearchRequest searchRequest = new SearchRequest(eventModel.getEsIndexName());
                searchRequest.source(sourceBuilder);
                response = client.search(searchRequest, RequestOptions.DEFAULT);
                if (null == response || CollUtil.isEmpty(response.getHits())) {
                    return logList;
                } else {
                    SearchHits sh = response.getHits();
                    for (SearchHit searchHit : sh) {
                        LogData log = new LogData();
                        log.setId(searchHit.getId());
                        log.setData(searchHit.getSourceAsString());
                        log.setEsIndex(searchHit.getIndex());
                        logList.add(log);
                    }
                }
            } catch (Exception e) {
                log.error(eventModel.getModelId() + " " + e.getMessage(), e);
            }
        } catch (Exception e) {
            log.error(eventModel.getModelId() + " " + e.getMessage(), e);
        }
        return logList;
    }


    /**
     * 获取聚合告警的查询时间段
     *
     * @param modelInfo 模型
     * @return 时间规则
     */
    private static List<Map<String, String>> getAggAlarmTime(TbEventModel modelInfo) {
        List<Map<String, String>> resultList = new ArrayList<>();
        String[] timeValues;
        try {
            if (StringUtils.isNotBlank(modelInfo.getTimeRange()) && StringUtils.isNotBlank(modelInfo.getTimeRangeUnit())) {
                TimeUnit timeUnit = TimeUnit.resolveByType(modelInfo.getTimeRangeUnit());
                //新改造，实现新的配置
                timeValues = DateUtils.resolveTimeIntevalsByType(timeUnit, new Date(), Integer.parseInt(modelInfo.getTimeRange()));
            } else {
                TimeUnit timeUnit = TimeUnit.resolveByType(modelInfo.getPeriodType());
                //旧模型没有时间间隔
                timeValues = DateUtils.resolveTimeIntevalsByType(timeUnit, new Date(), Integer.parseInt(modelInfo.getTaskInterval()));
            }
        } catch (Exception e) {
            log.error(modelInfo.getModelId() + " format 时间间隔错误" + e.getMessage(), e);
            return resultList;
        }
        Map<String, String> tempMap = new HashMap<>();
        tempMap.put("startTime", timeValues[1]);
        tempMap.put("endTime", timeValues[0]);
        resultList.add(tempMap);
        return resultList;
    }


    private SysDictData getLabelByTypeAndVal(String dictType, String value) {
        if (StringUtils.isEmpty(value)) {
            return null;
        }
        return DictUtil.getDictByValue(dictType, value);
    }


    private String sortIp(String source) {
        if (StringUtils.isBlank(source)) {
            return source;
        }
        List<String> ipList = Arrays.asList(source.split(","));
        if (ipList.size() < 2) {//只有一个IP直接返回
            return source;
        }
        return sortIp(Arrays.asList(source.split(",")));
    }

    private String sortIp(String source, String filterIp) {
        if (StringUtils.isBlank(source)) {
            return source;
        }
        List<String> newIpList = new ArrayList<>();
        List<String> ipList = Arrays.asList(source.split(","));
        if (ipList.size() < 2) {//只有一个IP直接返回
            return source;
        }
        HashMap<String, String> ipMap = new HashMap<>();
        for (String ip : ipList) {
            //目标IP跟源IP是一个IP，不能自己打自己
            if (!filterIp.equals("127.0.0.1") && !filterIp.equals(ip)) {
                ipMap.put(ip, ip);
            } else if (!filterIp.equals("0.0.0.0") && !filterIp.equals(ip)) {
                ipMap.put(ip, ip);
            }
        }
        //去除重复IP
        ipMap.forEach((k, v) -> {
            newIpList.add(k);
        });
        return sortIp(newIpList);
    }


    private String sortIp(List<String> source) {
        Comparator<String> ipComparator = (ip1, ip2) -> toNumeric(ip1).compareTo(toNumeric(ip2));
        SortedSet<String> ips = new TreeSet<>(ipComparator);
        ips.addAll(source);
        return CollUtil.join(ips, ",");
    }

    private Long toNumeric(String ip) {
        BigInteger iplong = IpUtils.getIp2long(ip);
        if (iplong == null) {
            return 0L;
        }
        return iplong.longValue();
    }

    /**
     * 精确告警输出定义
     *
     * @param str
     * @return
     */
    private static String replaceOutput(String str) {
        Pattern p = Pattern.compile("\\{+([a-zA-Z0-9_]+(.keyword)?)[\\.0-9A-Za-z]*\\}+");
        Matcher m = p.matcher(str);
        while (m.find()) {
            String group = m.group(1);
            if (StringUtils.isNotEmpty(group)) {
                return group;
            }
        }
        return "";
    }
}
