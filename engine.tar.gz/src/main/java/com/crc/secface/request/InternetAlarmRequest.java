package com.crc.secface.request;

import lombok.Data;

import java.util.List;

/**
 * @author jixiangqi
 * @date 2023/2/17
 * 关联告警
 */
@Data
public class InternetAlarmRequest {

    private String searchValue;

    private String  alarmLevel;

    private String attackResult;

    private String workStatus;

    private Long id;

    private List<String> ips;

    private Integer pageSize;

    private Integer pageNum;

    private String startTime;

    private String endTime;

    private String ip;

    private String port;
}
