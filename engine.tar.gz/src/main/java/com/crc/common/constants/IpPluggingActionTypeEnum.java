package com.crc.common.constants;

import lombok.Getter;

/**
 * IP封堵执行动作枚举
 *
 * @Author fuzhuangzhi
 * @Date 2023/2/8 17:08
 * @Version 1.0
 **/
@Getter
public enum IpPluggingActionTypeEnum {
    PLUGGING(1,"封堵"),
    UNSEAL(2,"解封"),
    ;

    /**
     * 执行动作  1 封堵 2 解封
     */
    private int value;

    /**
     * 描述
     */
    private String desc;

    IpPluggingActionTypeEnum(int value, String desc) {
        this.value = value;
        this.desc = desc;
    }

    public static String getDescByValue(int value) {
        for (IpPluggingActionTypeEnum actionTypeEnum : IpPluggingActionTypeEnum.values()) {
            if (value == actionTypeEnum.getValue()) {
                return actionTypeEnum.getDesc();
            }
         }
        return null;
    }
}
