package com.crc.common.constants;

import com.alibaba.fastjson.JSONObject;
import org.apache.commons.lang3.StringUtils;

public class LogConstantsX {
    public static final String BUS_MODEL = "bus_model";
    public static String LOG_ID = "id";
    public static String RISK_IP = "risk_ip";
    /**
     * 日志名称
     */
    public static String LOG_NAME = "log_name";

    public static String ES_LOG_NAME = "es_log_name";
    //事件类型
    public static String LOG_TYPE = "event_type";
    //事件发生时间
    public static String EVENT_TIME = "event_time";
    //操作结果
    public static String ACTION_RESULT = "action_result";
    //操作类型
    public static String ACTION_TYPE = "action_type";
    //操作触发规则
    public static String ACTION_RULE = "action_rule";
    //操作发生次数
    public static String ACTION_TIMES = "action_times";
    //主机名
    public static String HOST_NAME = "hostname";
    //目标域名
    public static String TARGET_DOMAIN_NAME = "target_domain_name";
    //日志级别
    public static String LOG_LEVEL = "log_level";
    //日志可疑/优先级程度
    public static String LOG_PRIORITY = "log_priority";
    //原始日志
    public static String LOG_ORI_MSG = "zlog_ori_msg";
    //日志时间
    public static String LOG_TIME = "SparkTime";
    //源设备信息
    public static String SRC_DEV_INFO = "src_dev_info";
    //归属组织
    public static String ASSET_OFFICE = "asset_office";
    //外部IP
    public static String EXTERNAL_IP = "external_ip";
    //内部IP
    public static String INTERNAL_IP = "internal_ip";
    //实例名称
    public static String SRC_INSTANCE = "instance";
    //事件ID
    public static String EVENT_ID = "event_id";
    //源设备类型
    public static String SRC_DEV_TYPE = "src_dev_type";
    //源IP
    public static String SRC_IP = "src_ip";
    //源IP类型 外网、内网
    public static String SRC_IP_TYPE = "src_ip_type";
    //源IP城市
    public static String SRC_IP_CITY = "src_ip_city";
    //源IP省份
    public static String SRC_IP_PROVINCE = "src_ip_subdivision";
    //源IP国家
    public static String SRC_IP_COUNTRY = "src_ip_country";
    //源IP 经纬度
    public static String SRC_IP_LOCATION = "src_ip_location";
    //源端口
    public static String SRC_PORT = "src_port";
    //源MAC
    public static String SRC_MAC = "src_mac";
    //目标IP
    public static String DEST_IP = "dest_ip";
    //目标IP类型 外网、内网
    public static String DEST_IP_TYPE = "dest_ip_type";
    //目标IP城市
    public static String DEST_IP_CITY = "dest_ip_city";
    //目标IP省份
    public static String DEST_IP_PROVINCE = "dest_ip_subdivision";
    //目标IP国家
    public static String DEST_IP_COUNTRY = "dest_ip_country";
    //目标IP 经纬度
    public static String DEST_IP_LOCATION = "dest_ip_location";
    //目标端口
    public static String DEST_PORT = "dest_port";
    //所属网段
    public static String NET_SCOPE = "net_scope";
    //操作系统信息
    public static String OS_INFO = "os_info";

    //网段归属
    public static String NET_OFFICE = "net_office";
    //操作用户归属组织
    public static String OP_OFFICE = "op_office";
    //操作账户
    public static String OP_NAME = "op_name";
    //操作中文名称
    public static String OP_CN_NAME = "op_cn_name";
    //消息内容
    public static String MSG_CONTENT = "content";
    //事件发生时间
    public static String LOG_START_TIME = "log_start_time";
    //事件结束时间
    public static String LOG_END_TIME = "log_end_time";
    //事件描述
    public static String LOG_CONTENT = "content";
    //事件危害
    public static String LOG_DAMAGE = "damage";
    //解决方案
    public static String LOG_SOLUTION = "solution";
    //事件原理
    public static String LOG_PRINCIPLE = "principle";
    //访问协议
    public static String LOG_PROTOCAL = "protocal";
    //出现次数
    public static String LOG_COUNT = "log_count";
    //日志源服务器
    public static String LOG_SERVER = "log_server";
    //使用正则解释是否成功的标识 1成功 0失败
    public static String LOG_PARSE_STATUS = "log_parse_flag";
    //日志源产品
    public static String LOG_PRODUCT = "product";

    //日志源产品
    public static String ES_LOG_PRODUCT = "es_product";

    //事件评分
    public static String EVENT_SCORE = "event_score";
    //资产IP评分
    public static String IP_SCORE = "ip_score";
    //事件链接
    public static String LOG_URL = "log_url";

    public static String DEFAULT_LOG_NAME = "default_log_name";

    public static String DEFAULT_LOG_TYPE = "default_log_type";

    public static String[] ACTION_RESULT_LIST = new String[]{"拦截", "放行", "成功", "成功"};

    public static String COMMAND_INDEX = "command_index";

    public static String IMPORT_TIME ="import_time";

    public static String SRC_IP_INSTANCE = "src_ip_instance";

    public static String DEST_IP_INSTANCE= "dest_ip_instance";

    public static String LOG_PROOF ="log_proof";

    public static String IS_WHITELIST ="is_whitelist";

    public static String ALERT_NAME="alert_name";
    public static String ALERT_NAME_BAK="alert_name_bak";

    public static String ORI_EVENT_ID="ori_event_id";

    /**
     * 按事件级别打分 低10 中30 高80
     */
    public static void commonEventLevelScore(JSONObject data) {
        String level = data.getString(LogConstantsX.LOG_LEVEL);
        int eventScore = 0;
        if (StringUtils.isNotBlank(level)) {
            if (LevelConstants.LOW.equals(level)) {
                eventScore = 10;
            } else if (LevelConstants.MEDIUM.equals(level)) {
                eventScore = 30;
            } else if (LevelConstants.HIGH.equals(level)) {
                eventScore = 80;
            }
        }
        data.put(LogConstantsX.EVENT_SCORE, eventScore);
    }
}
