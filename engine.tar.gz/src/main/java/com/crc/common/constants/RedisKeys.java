package com.crc.common.constants;

/**
 * @Author shufengfeng
 * @Description TODO
 * @DateTime 2021/9/17 15:01
 */
public class RedisKeys {

    /**
     * 聚合告警模型执行redisKey
     */
    public static final String EVENT_AGGS_ALARM_TASK_KEY = "event:aggs:alarm:task:%s";

}


