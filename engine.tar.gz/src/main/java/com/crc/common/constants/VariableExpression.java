package com.crc.common.constants;

/**
 * Classname:VariableExpression
 * Description:常量表达式类
 * Author: cymiao
 * Date: 2021/6/21 10:50
 **/
public class VariableExpression {

    /**
     * 流程首任务节点previousTaskNode属性的值
     */
    public static final String START_NODE_CODE = "startCode";

    /**
     * 流程首任务节点名称
     */
    public static final String START_NODE_NAME = "开始";

    /**
     * java任务节点，条件计算默认调用java类的全路径
     */
    public static final String CONDITION_JAVA_NODE_CLASS = "com.crc.activiti.delegate.CalculationConditionExpression";

    /**
     * java任务节点默认调用java类的全路径
     */
    public static final String RETURN_PREVIOUSCon_JAVA_NODE_CLASS = "com.crc.activiti.delegate.ReturnPreviousNodeExpression";

    /**
     * 条件网关id后缀
     */
    public static final String GATEWAY_ID_SUFFIX = "ToExclusiveGateway";

    /**
     * 并行网关后缀
     */
    public static final String PARALLEL_GATEWAY_ID_SUFFIX = "ToParallelGateway";

    /**
     * 包容网关后缀
     */
    public static final String INCLUSIVE_GATEWAY_ID_SUFFIX = "ToInclusiveGateway";
    /**
     * 条件网关id后缀
     */
    public static final String CONDITION_GATEWAY_ID_SUFFIX = "ToConditionExclusiveGateway";

    /**
     * 条件网关ID拼接连接符
     */
    public static final String CONDITION_GATEWAY_ID_CONNECTOR = "And";

    /**
     * 返回自选节点表达式
     */
    public static final String RETURN_HISTORY_NODE_CONDITION = "returnHistoryNodeCondition";

    /**
     * 条件网关分支表达式
     */
    public static final String CONDITION_CALCULATION_RESULT = "conditionCalculationResult";
}
