package com.crc.common.constants;

/**
 * @Author shufengfeng
 * @Description 字典类型枚举类
 * @DateTime 2021/8/27 17:10
 */
public enum DictTypeEnum {

    ALARM_LEVEL("alarm_level","告警级别"),
    EVENT_ATTACK_RESULT("event_attack_result","攻击结果"),
    ATTACK_TYPE("attack_type","攻击手段"),

    /**
     * 资产软件许可证
     */
    SOFTWARE_LICENSE_TYPE("software_license_type","许可类型"),
    SOFTWARE_OWNER("software_owner","知识产权所属国"),
    SOFTWARE_TYPE("software_type","软件类型"),


    /**
     * 资产
     */
    KEY_ASSET("key_asset","资产等级"),
    ASSET_TYPE("asset_type","资产类型"),
    ENVIRONMENT_TYPE("environment_type","环境类型"),
    OPERATING_STATUS("operating_status","资产状态"),
    EQUAL_PROTECTION_LEVEL("equal_protection_level","等保定级"),
    SOURCE_TYPE("source_type","资源类型"),
    SEGMENT_AREA("segment_area","网络区域"),
    ALERT_SOURCE_WAY("alert_source_way","告警设备"),
    SYS_YES_NO("sys_yes_no","系统默认是/否"),
    SAFETY_SCORE("safety_score", "安全评分"),

    /**
     * 互联网资产
     */
    DATA_SOURCE("internet_asset_data_source","数据来源"),

    /**
     * 风险自动发现 - 自动发现
     */
    RISK_LEVEL("risk_level", "风险等级"),
    ORDER_STATUS("order_status", "工单状态"),
    RECTIFICATION_TYPE("rectification_type", "处置方式"),
    RISK_AUTO_SOURCE("risk_auto_source", "风险来源"),

    /**
     * 资产全景-网络子区域
     */
    PANORAMIC_LABEL_SLOT("panoramic_label_slot", "资产全景-标签"),

    /**
     * 扫描引擎
     */
    CRON_SCAN_ENGINE("cron_scan_engine", "扫描引擎"),

    /**
     * 主动复查扫描
     */
    ACTIVE_BATCH_REVIEW_SOURCE("active_batch_review_source", "主动复查扫描源"),

    /**
     * 告警来源IP匹配规则
     */
    USER_IP_RULE("user_ip_rule", "告警来源IP匹配规则"),

    /**
     * 基础路径
     */
    BASE_PATH("base_path","基础路径"),
    STP_BASE_PATH("stp_base_path","STP基础路径"),
    SSP_BASE_PATH("ssp_base_path","SSP基础路径"),
    SCP_BASE_PATH("scp_base_path","SCP基础路径"),

    /**
     * 无流程角色配置
     */
    NO_PROCESS_ROLES("no_process_roles", "无流程角色配置"),

	/**
     * 告警模型
     */
    PERIOD_TYPE("period_type","时间周期类型"),

    /**
     * 告警模型
     */
    ALARM_MODEL_DEVICENAME("rule_base","设备名称"),
    ALARM_MODEL_ES_INDEX("alarm_model_es_index","数据源索引"),
    ALARM_MODEL_SORT_FIELD("alarm_model_sort_field","排序字段"),
    ALARM_MODEL_TYPE("alarm_model_type","模型类型"),
    ALARM_MODEL_ES_CONFIG("alarm_model_es_config","ES数据源"),

    /**
     * 导出数据字典
     */
    KNOWLEDGE_JUDGE_EXPORT_EXCEL("knowledge_judge_export_excel", "研判知识库_导出字段"),
    KNOWLEDGE_HANDLE_EXPORT_EXCEL("knowledge_handle_export_excel", "处置建议库_导出字段"),
    KNOWLEDGE_FEEDBACK_EXPORT_EXCEL("knowledge_feedback_export_excel", "处置反馈指南_导出字段"),
    /**
     * 攻击链路
     */
    ATTACK_IP_CLASSIFY("attack_ip_classify","攻击链路ip分类"),

    /**
     * websocket
     */
    ALARM_HVV_WEBSOCKET("alarm_hvv_websocket", "websocket推送开关"),

    /**
     * 规则库
     */
    RULE_BASE("rule_base", "规则库"),

    /**
     * 企业微信字典
     */
    QYWX_PUSH_AUTH("qywx_push_auth", "企业微信字典"),

    /**
     * 企业微信标题模板
     */
    QYWX_SUBJECT_TEMPLATE("qywx_subject_template", "企业微信标题模板"),

    ;


    /**
     * 名称
     */
    private String name;

    /**
     * 描述
     */
    private String desc;

    DictTypeEnum(String name, String desc){
        this.name = name;
        this.desc = desc;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getDesc() {
        return desc;
    }

    public void setDesc(String desc) {
        this.desc = desc;
    }
}
