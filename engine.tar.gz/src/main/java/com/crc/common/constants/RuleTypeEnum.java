package com.crc.common.constants;

/**
 * @author simba@onlying.cn
 * @date 2020/9/28 17:02
 */
public enum RuleTypeEnum {
    ROOT(0,"根节点"),
    AND(1,"与规则组"),
    SHOULD(2,"或规则组"),
    NOT(3,"非规则组"),
    NODE(4,"子规则");

    private int type;

    private String desc;

    RuleTypeEnum(int type, String desc){
      this.type = type;
      this.desc = desc;
    }

    public int getType() {
        return type;
    }

    public String getDesc() {
        return desc;
    }

    public static RuleTypeEnum resolveByType(int type){
        for(RuleTypeEnum ruleType:RuleTypeEnum.values()){
            if(ruleType.getType() ==type){
                return ruleType;
            }
        }
        return null;
    }

}
