package com.crc.common.constants;

import java.util.Date;
import java.util.concurrent.ConcurrentHashMap;

public class AlarmTimeWinodwContants {
    /**
     * 关联告警的时间窗口记录Map
     */
    public static ConcurrentHashMap<String, Date> relationAlarmTimeMap = new ConcurrentHashMap<>();

    /**
     * 聚合告警的时间窗口记录Map
     */
    public static ConcurrentHashMap<String, Date> aggAlarmTimeMap = new ConcurrentHashMap<>();

    /**
     * 精确告警的时间窗口记录Map
     */
    public static ConcurrentHashMap<String, Date> spotAlarmTimeMap = new ConcurrentHashMap<>();
}
