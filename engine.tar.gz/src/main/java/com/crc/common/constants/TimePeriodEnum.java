package com.crc.common.constants;

/**
 * @Author shufengfeng
 * @Description 时间周期类型枚举类
 * @DateTime 2022/09/21 17:10
 */
public enum TimePeriodEnum {
    SECOND("4","秒"),
    MINUTE("1","分钟"),
    HOUR("2","小时"),
    DAY("3","天"),

    ;


    /**
     * 值
     */
    private String value;

    /**
     * 描述
     */
    private String desc;

    TimePeriodEnum(String value, String desc) {
        this.value = value;
        this.desc = desc;
    }

    public String getValue() {
        return value;
    }

    public void setValue(String value) {
        this.value = value;
    }

    public String getDesc() {
        return desc;
    }

    public void setDesc(String desc) {
        this.desc = desc;
    }
}
