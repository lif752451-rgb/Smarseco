package com.crc.common.constants;


import org.apache.commons.lang3.StringUtils;

/**
 * @Class: com.crc.ssp.project.big.screen
 * @Desc：
 * @Author: cymiao
 * @Date: 2021/4/19 16:26
 */
public enum GroupTypeEnum {
    GROUP_HEADQUARTERS("集团总部", "集团总部"),
    GROUP_HEADQUARTERS1("北京华润大厦", "集团总部"),
    GROUP_HEADQUARTERS2("福田新职场", "集团总部"),
    GROUP_HEADQUARTERS3("西安办公网", "集团总部"),
    GROUP_HEADQUARTERS4("春笋大厦", "集团总部"),
    GROUP_HEADQUARTERS5("汕尾办公网", "集团总部"),
    GROUP_HEADQUARTERS6("百度大厦", "集团总部"),
    GROUP_HEADQUARTERS7("香港华润大厦", "集团总部"),
    GROUP_HEADQUARTERS8("华润大学", "集团总部"),
    GROUP_HEADQUARTERS9("档案馆", "集团总部"),
    GROUP_HEADQUARTERS10("华润守正", "集团总部"),
    //GROUP_HEADQUARTERS11("润联科技", "集团总部"),
    GROUP_HEADQUARTERS12("办公区", "集团总部"),
    GROUP_HEADQUARTERS13("北京华润大厦", "集团总部"),
    GROUP_HEADQUARTERS14("集团业务", "集团总部"),

    HUARUN_ZHIDI("华润置地", "华润置地"),
    HUARUN_ZHIDI1("置地区", "华润置地"),
    HUARUN_ZHIDI2("置地", "华润置地"),

    HUARUN_WANJIA("华润万家", "华润万家"),
    HUARUN_WANJIA1("万家区", "华润万家"),
    HUARUN_WANJIA2("万家", "华润万家"),

    HUARUN_YIYAO("华润医药", "华润医药"),
    HUARUN_YIYAO1("医药区", "华润医药"),
    HUARUN_YIYAO2("医药", "华润医药"),

    HUARUN_YISHANG("华润医商", "华润医商"),
    HUARUN_YISHANG1("华润医药商业", "华润医商"),

    HUARUN_YILIAO("华润医疗", "华润医疗"),
    HUARUN_YILIAO1("医疗&健康", "华润医疗"),
    HUARUN_YILIAO2("医疗", "华润医疗"),
    HUARUN_YILIAO3("健康", "华润医疗"),

    HUARUN_RANQI("华润燃气", "华润燃气"),

    HUARUN_SHUINI("华润水泥", "华润水泥"),

    HUARUN_HUANBAO("华润环保", "华润环保"),

    HUARUN_WUFENG("华润五丰", "华润五丰"),

    HUARUN_SANJIU("华润三九", "华润三九"),

    HUARUN_YIBAO("华润怡宝", "华润怡宝"),

    HUARUN_DIANZI("华润微电子", "华润微电子"),

    HUARUN_JIANGZHONG("华润江中", "华润江中"),

    HUARUN_SHUANGHE("华润双鹤", "华润双鹤"),

    HUARUN_HUAXUECAILIAO("华润化学材料", "华润化学材料"),

    HUARUN_DIANLI("华润电力", "华润电力"),

    HUARUN_XUEHUA("华润雪花", "华润雪花"),

    HUARUN_JIANGKANG("华润健康", "华润健康"),

    HUARUN_CHUANGYE("华润创业", "华润创业"),
    HUARUN_CHUANGYE1("华创办公网", "华润创业"),

    HUARN_YINGHANG("华润银行", "华润银行"),

    //HUARUN_YUN("华润云","华润云"),

    HUARUN_ZIBEN("华润资本", "华润资本"),

    HUARUN_ZICHAN("华润资产", "华润资产"),

    HUARUN_XINGTUO("华润信托", "华润信托"),

    HUARUN_WANGLUO("华润网络", "华润网络"),

    HUARUN_WANGLUO1("华润通区", "华润网络"),
    HUARUN_WANGLUO2("华润通", "华润网络"),

    HUARUN_WUYE("华润物业", "华润物业"),

    WEIZHI("未知", "未知");


    public static GroupTypeEnum valueOfs(String area) {
        area = getOffice(area);
        GroupTypeEnum[] values = GroupTypeEnum.values();
        for (GroupTypeEnum typeEnum : values) {
            if (typeEnum.getArea().equals(area)) {
                return typeEnum;
            }
        }

        return WEIZHI;
    }

    String area;
    String type;

    GroupTypeEnum(String area, String type) {
        this.area = area;
        this.type = type;
    }

    public String getType() {
        return type;
    }

    public String getArea() {
        return area;
    }

    public static String getOffice(String str) {
        if (str != null) {
            str = str.replace(" ", "");
        }
        if (StringUtils.isNotBlank(str)) {
            if (str.contains("万家") || str.contains("华润家") || str.contains("邓韩")) {
                return "华润万家";
            } else if (str.contains("集团总部") || str.contains("系统开发中心")) {
                return "集团总部";
            } else if (str.contains("水泥") || str.contains("泥") || str.contains("水")) {
                return "华润水泥";
            } else if (str.contains("燃气") || str.contains("润智") || str.contains("气") || str.contains("燃")) {
                return "华润燃气";
            } else if (str.contains("微电子") || str.contains("华润电子")) {
                return "华润微电子";
            } else if (str.contains("电力") || str.contains("电场") || str.contains("电站") || str.contains("华润电") || str.contains("力") || str.contains("煤")) {
                return "华润电力";
            } else if (str.contains("置地") || str.contains("华润置") || str.contains("万象") || str.contains("华润地") || str.contains("华润万")) {
                return "华润置地";
            } else if (str.contains("五丰") || str.contains("华润五") || str.contains("丰")) {
                return "华润五丰";
            } else if (str.contains("三九") || str.contains("三") || str.contains("九")) {
                return "华润三九";
            } else if (str.contains("雪花") || str.contains("雪") || str.contains("花")) {
                return "华润雪花";
            } else if (str.contains("守")) {
                return "华润雪花";
            } else if (str.contains("怡宝") || str.contains("饮料") || str.contains("饮")) {
                return "华润怡宝";
            } else if (str.contains("双") || str.contains("鹤")) {
                return "华润双鹤";
            } else if (str.contains("江中")) {
                return "华润江中";
            } else if (str.contains("健康") || str.contains("医院") || str.contains("维麟") || str.contains("健")) {
                return "华润健康";
            } else if (str.contains("医疗") || str.contains("疗")) {
                return "华润医疗";
            } else if (str.contains("生命")) {
                return "华润生命科学";
            } else if (str.contains("物业")) {
                return "华润物业";
            } else if (str.contains("金融") || str.contains("华润金控")) {
                return "华润金融";
            } else if (str.contains("保险") || str.contains("华润保")) {
                return "华润保险";
            } else if (str.contains("银行")) {
                return "华润银行";
            } else if (str.contains("租赁")) {
                return "华润租赁";
            } else if (str.contains("信托") || str.contains("托")) {
                return "华润信托";
            } else if (str.contains("资产")) {
                return "华润资产";
            } else if (str.contains("资本")) {
                return "华润资本";
            } else if (str.contains("材料") || str.contains("化工")) {
                return "华润化学材料";
            } else if (str.contains("环保") || str.contains("纺织") || str.contains("华润环") || str.contains("润薇")) {
                return "华润环保";
            } else if (str.contains("网络") || str.contains("华润通") || str.contains("润信") || str.contains("华润络") || str.contains("华润网")) {
                return "华润网络";
            } else if (str.contains("华润云") || str.contains("润联") || str.contains("耕云") || str.contains("股权") || str.contains("守正") || str.contains("大厦") || str.contains("新职场") || str.contains("香港") || str.contains("西安办公网") || str.contains("飞书")) {
                return "华润数科";
            } else if (str.contains("医药商业") || str.contains("医商") || str.contains("药商")) {
                return "华润医商";
            } else if (str.contains("医药") || str.contains("紫竹") || str.contains("东阿") || str.contains("华润药")) {
                return "华润医药";
            } else if (str.contains("华润云") || str.contains("智能科") || str.contains("IT产品服务") || str.contains("IT运营服务") || str.contains("技术") || str.contains("智慧技术部") || str.contains("管理与发展部") || str.contains("智慧空间组") || str.contains("X-LABS")) {
                return "华润数科";
            } else if (str.contains("服务部") || str.contains("软件") || str.contains("云") || str.contains("润科技") || str.contains("联科技") || str.contains("科技创新部")) {
                return "华润数科";
            } else if (str.contains("华创") || str.contains("创业") || str.contains("业") || str.contains("华润创")) {
                return "华润创业";
            }
        }

        return "";
    }
}
