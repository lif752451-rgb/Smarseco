package com.crc.common.constants;

/**
 * @author simba@onlying.cn
 * @date 2020/10/23 18:16
 */
public enum RuleArthimaticEnum {
    EQ("514","eq"),
    CONTAIN("515","contain"),
    REGREX("516","regrex"),
    SUBNETMASK("4","subnetmask");

    private String type;

    private String desc;
    RuleArthimaticEnum(String type, String desc){
        this.type = type;
        this.desc = desc;
    }

    public String getType() {
        return type;
    }

    public String getDesc() {
        return desc;
    }

    public static RuleArthimaticEnum resolveByType(String type){
        for(RuleArthimaticEnum enum2:RuleArthimaticEnum.values()){
            if(enum2.getType().equals(type)){
                return enum2;
            }
        }
        return null;
    }
}
