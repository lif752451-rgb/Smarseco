package com.crc.common.constants;

/**
 * @author simba@onlying.cn
 * @date 2020/7/22 10:15
 */
public class LogConstants {
    public static String LOG_ID = "id";

    public static String ES_LOG_INDEX ="es_index";

    public static String SRC_IP_TAG ="src_ip";

    public static String DEST_IP_TAG="dest_ip";

    public static String PRODUCT_TAG ="product";

    public static String SPARK_TIME_TAG ="SparkTime";

    public static String DEFAULT_ES_INDEX ="sec_all";

    public static String KEYWORD = "keyword";

    //日志索引
    public static String NN_WIN_INDEX="crcement_nn_win";

    public static String AD_INDEX="crcement_ad";

    public static String WIN_INDEX="crcement_win";

    public static String DEV_INDEX="crcement_dev";

    public static String LINUX_INDEX="crcement_linux";

    /**
     * 日志名称
     */
    public  final static String LOG_NAME = "log_name";
    //事件类型
    public  final static String LOG_TYPE = "event_type";
    //操作结果
    public  final static String ACTION_RESULT = "action_result";
    //操作类型
    public  final static String ACTION_TYPE = "action_type";
    //操作触发规则
    public  final static String ACTION_RULE = "action_rule";
    //操作发生次数
    public  final static String ACTION_TIMES = "action_times";
    //主机名
    public  final static String HOST_NAME = "hostname";
    //目标域名
    public  final static String TARGET_DOMAIN_NAME = "target_domain_name";
    //日志级别
    public  final static String LOG_LEVEL = "log_level";
    //日志可疑/优先级程度
    public  final static String LOG_PRIORITY = "log_priority";
    //原始日志
    public  final static String LOG_ORI_MSG = "zlog_ori_msg";
    //日志时间
    public  final static String LOG_TIME = "SparkTime";

    public  final static String LOG_CONTENT = "content";

    //日志源设备IP
    public  final static String LOG_DEV_IP = "dev_ip";

    //源设备信息
    public  final static String SRC_DEV_INFO = "src_dev_info";
    //归属组织
    public  final static String ASSET_OFFICE = "asset_office";
    //外部IP
    public  final static String EXTERNAL_IP = "external_ip";
    //内部IP
    public  final static String INTERNAL_IP = "internal_ip";
    //实例名称
    public  final static String SRC_INSTANCE = "instance";
    //事件ID
    public  final static String EVENT_ID = "event_id";
    //源设备类型
    public  final static String SRC_DEV_TYPE = "src_dev_type";
    //源IP
    public  final static String SRC_IP = "src_ip";
    //源IP类型 外网、内网
    public final static String SRC_IP_TYPE = "src_ip_type";
    //源安全区域
    public  final static String SRC_ZONE = "src_zone";
    //源IP城市
    public  final static String SRC_IP_CITY = "src_ip_city";
    //源IP省份
    public  final static String SRC_IP_PROVINCE = "src_ip_subdivision";
    //源IP国家
    public  final static String SRC_IP_COUNTRY = "src_ip_country";
    //源端口
    public  final static String SRC_PORT = "src_port";
    //源MAC
    public  final static String SRC_MAC = "src_mac";
    //目标IP
    public  final static String DEST_IP = "dest_ip";
    //目标IP类型 外网、内网
    public  final static String DEST_IP_TYPE = "dest_ip_type";
    //目标IP城市
    public  final static String DEST_IP_CITY = "dest_ip_city";
    //目标IP省份
    public  final static String DEST_IP_PROVINCE = "dest_ip_subdivision";
    //目标安全区域
    public  final static String DEST_ZONE = "dest_zone";
    //目标IP国家
    public  final static String DEST_IP_COUNTRY = "dest_ip_country";
    //目标端口
    public  final static String DEST_PORT = "dest_port";
    //所属网段
    public  final static String NET_SCOPE = "net_scope";
    //操作系统信息
    public  final static String OS_INFO = "os_info";

    //网段归属
    public  final static String NET_OFFICE = "net_office";
    //操作用户归属组织
    public  final static String OP_OFFICE = "op_office";
    //操作账户
    public  final static String OP_NAME = "op_name";
    //操作中文名称
    public  final static String OP_CN_NAME = "op_cn_name";
    //消息内容
    public  final static String MSG_CONTENT = "content";
    //事件发生时间
    public  final static String LOG_START_TIME = "log_start_time";
    //事件描述
    public  final static String LOG_DESCRIPTION = "event_description";
    //事件危害
    public  final static String LOG_DAMAGE = "damage";
    //解决方案
    public  final static String LOG_SOLUTION = "solution";
    //事件原理
    public  final static String LOG_PRINCIPLE = "principle";
    //访问协议
    public final static String LOG_PROTOCAL = "protocal";
    //出现次数
    public final static String LOG_COUNT = "log_count";
    //日志源服务器
    public final static String LOG_SERVER = "log_server";
    //使用正则解释是否成功的标识 1成功 0失败
    public final static String LOG_PARSE_STATUS = "log_parse_flag";
    //日志源产品
    public final static String LOG_PRODUCT = "product";
    //事件评分
    public final static String EVENT_SCORE = "event_score";
    //资产IP评分
    public final static String IP_SCORE = "ip_score";
    //事件链接
    public final static String LOG_URL = "log_url";
    //攻击阶段
    public final static String LOG_STAGE = "log_stage";
    //举证
    public final static String LOG_PROOF = "log_proof";

    public final static String ALERT_NAME ="alert_name";

    public final static String BEHAVIOR_TAG="behavior";


    public final static String LOG_TITLE = "log_title";

    public final static String LOG_DNS = "log_dns";

    public final static String LOG_KEYWORD = "keyword_original";

    public final static String LOG_FILENAME = "filename";

    public final static String LOG_GROUP = "group";

    public final static String LOG_APP = "app";


}
