package com.crc.common.constants;


/**
 * 微信接口 url常量
 * @author blueriver
 */
public class WeixinUrlConstants {

    public static final String WX_UPLOAD_MEDIA = "/cgi-bin/media/upload";

    /**
     * 企业号 *
     */
    // 获取企业号accessTOken
    public static final String QY_ACCESS_TOKEN = "/cgi-bin/gettoken";
    //创建部门
    public static final String QY_CREATE_DEPT = "/cgi-bin/department/create";
    //获取部门列表
    public static final String QY_GET_DEPT = "/cgi-bin/department/list";


    // 创建应用菜单
    public static final String QY_CREATE_MENU = "/cgi-bin/menu/create";
    // 获取应用菜单
    public static final String QY_GET_MENU = "/cgi-bin/menu/get";
    // 删除应用菜单
    public static final String QY_DEL_MENU = "/cgi-bin/menu/delete";
    // 发送消息
    public static final String QY_SEND_MESSAGE = "/cgi-bin/message/send";

    // 获取成员信息 ？？？
    public static final String QY_USER_INFO = "/cgi-bin/user/getuserinfo";
    public static final String QY_USER_ID_LIST = "/cgi-bin/user/list_id";
    // 创建成员
    public static final String QY_CREATE_USER = "/cgi-bin/user/create";
    // 读取成员
    public static final String QY_GET_USER = "/cgi-bin/user/get";
    // 更新成员
    public static final String QY_UPDATE_USER = "/cgi-bin/user/update";
    // 删除成员
    public static final String QY_DELETE_USER = "/cgi-bin/user/delete";
    // 批量删除成员
    public static final String QY_BATCH_DELETE_USER = "/cgi-bin/user/batchdelete";
    // 获取部门成员列表
    public static final String QY_DEPT_USER_LIST = "/cgi-bin/user/simplelist";
    // 获取部门成员详情列表
    public static final String QY_DEPT_USER_DETAIL_LIST = "/cgi-bin/user/list";

    // userid转换成openid
    public static final String QY_CONVERT_TO_OPENID = "/cgi-bin/user/convert_to_openid";
    // openid 转换成userid
    public static final String QY_CONVERT_TO_USERID = " /cgi-bin/user/convert_to_userid";

    // 获取企业号登录用户信息
    public static final String QY_LOGIN_USER_INFO = "/cgi-bin/user/getuserinfo";
    // 获取企业号登陆用户的详细信息
    public static final String QY_LOGIN_USER_DETAIL = "/cgi-bin/user/getuserdetail";

    //企业号jssdk ticket地址
    public static final String QY_JSAPI_TICKET = "/cgi-bin/get_jsapi_ticket";
}
