package com.crc.common.constants;

import org.apache.commons.lang3.StringUtils;

public class LevelConstants {
    public static String HIGH = "高风险";
    public static String MEDIUM = "中风险";
    public static String LOW = "低风险";
    public static String INFO = "信息";
    private static String[] HIGH_ARR = {"高风险", "high", "高危", "3", "高威胁", "danger"};
    private static String[] MEDIUM_ARR = {"中风险", "medium", "中危", "2", "中威胁", "alert"};
    private static String[] LOW_ARR = {"低风险", "low", "低危", "1", "低威胁", "info"};

    public static String getLevel(String level) {
        if (StringUtils.isBlank(level))
            return INFO;
        for (String l : HIGH_ARR) {
            if (l.equalsIgnoreCase(level))
                return HIGH;
        }
        for (String l : MEDIUM_ARR) {
            if (l.equalsIgnoreCase(level))
                return MEDIUM;
        }
        for (String l : LOW_ARR) {
            if (l.equalsIgnoreCase(level))
                return LOW;
        }
        return INFO;
    }
}
