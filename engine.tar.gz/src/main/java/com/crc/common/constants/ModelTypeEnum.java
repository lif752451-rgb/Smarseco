package com.crc.common.constants;

import lombok.Data;

/**
 * @Author shufengfeng
 * @Description 模型类型
 * @DateTime 2021/8/30 16:49
 */
@Data
public class ModelTypeEnum {
    //模型类型：1.精确告警模型、2.聚合告警模型、3.关联告警模型
    public static ModelTypeEnum JINGQUE = new ModelTypeEnum("1","精确告警模型");
    public static ModelTypeEnum JUHE = new ModelTypeEnum("2","聚合告警模型");
    public static ModelTypeEnum GUANLIAN = new ModelTypeEnum("3","关联告警模型");


    private String value;
    private String desc;

    public ModelTypeEnum() {
    }

    public ModelTypeEnum(String value, String desc) {
        this.value = value;
        this.desc = desc;
    }

    public String getValue() {
        return value;
    }

    public void setValue(String value) {
        this.value = value;
    }

    public String getDesc() {
        return desc;
    }

    public void setDesc(String desc) {
        this.desc = desc;
    }
}
