package com.crc.common.constants;

/**
 * 消息枚举
 * @author WANGLEI
 * @date 2021/5/25 15:50
 */
public enum MessageEnum {

    PARAM_ERR(20008, "参数不正确"),
    RISK_BUSINESS_PARAM_ERR(20009, "业务处理参数错误"),
    PARAM_CAN_NOT_EMPTY(20010, "参数不可为空"),
    OWNER_GROUP_SAVE_FAIL(20012, "人员所属组添加失败"),
    PROCESS_NOT_EXIST(20013, "流程不存在"),
    STARTER_NO_PERMISSION(20014, "当前登录用户无发起流程权限"),
    PROCESS_APPROVING_EXIST(20015, "已存在审批中的流程"),
    TASK_ALREADY_DEAL_OR_NO_PERMISSION(20016, "当前节点已经被处理或者无处理权限"),
    TASK_ALREADY_DEAL(20017, "任务已被处理或不存在"),
    PROCESS_TYPE_NAME_EXIST(20018, "此分组名称已存在"),
    PROCESS_UNPUBLISHED(20020, "流程未发布"),
    PROCESS_DEAL_DEALING(20021, "该风险单已被操作，无法撤回"),
    PROCESS_INSTANCE_NON_EXIST(20022, "当前流程不存在"),
    TASK_ALREADY_TRANSFERRED(20023, "该风险单已被撤回，请刷新页面"),
    RISK_DELAY_CONDITION(20024,"当前流程状态不能发起延期申请"),
    RISK_DELAY_APPLY_REPEAT(20025, "已存在延期申请流程，不能重复发起"),
    CURRENT_USER_NO_DEAL_PERMISSION(20026, "当前用户无处理权限"),
    WAIT_FOR_REVIEW_VULN_IP_NOT_EMPTY(20040, "待复查漏洞IP不可以为空"),
    VULN_DATA_NOT_EXIST(20041, "漏洞数据不存在"),
    VULN_BUSINESS_DATA_NOT_EXIST(20042, "漏洞流程数据不存在"),
    PROCESS_INFO_ERROR(20043, "流程数据异常"),
    CURRENT_USER_NO_START_PERMISSION(20044, "当前用户无发起权限"),
    VULN_STATE_ERROR(20045, "当前工单已被操作，请刷新"),
    ASSET_NOT_EXIST(20046, "资产数据不存在"),
    ASSET_MODIFY_NOT_EXIST(20047, "资产变更数据不存在"),
    ASSET_MODIFY_ALREADY_CLOSED(20048, "资产变更数据已被处理"),
    IP_REVIEW_STATUS_ERROR(20049, "该IP正在复查，无法处理，请刷新页面"),
    VISUAL_SOURCE_REMARK_NOT_CONFIG(20050, "可视化数据来源未配置"),
    VISUAL_REPORT_SQL_NOT_CONFIG(200451, "生产报表sql未配置"),
    SUBSCRIBE_TYPE_IS_NOT_EMPTY(20052, "订阅类型不可以为空"),
    SUBSCRIBE_CONTENT_IS_NOT_EMPTY(20053, "订阅内容不可以为空"),
    KEY_WORD_IS_NOT_EMPTY(20054, "检索关键字不可以为空"),

    EVENT_DOES_NOT_EXIST(200455, "实时事件不存在"),
    EVENT_ATTACK_IP_ERROR(200456, "攻击IP参数格式不正确"),
    EVENT_ATTACK_URL_ERROR(200457, "攻击URL参数格式不正确"),
    EVENT_SAVE_FAIL(200458, "实时事件保存失败"),
    EVENT_UPDATE_FAIL(200459, "实时事件修改失败"),
    ALARM_WHITE_LIST_NOT_EXIST(20060, "告警白名单不存在"),
    SECURITY_REPORT_STRATEGY_IS_EXIST(200462, "该安全报告策略已存在，不能重复添加"),
    EMAIL_FORMAT_ERROR(200463, "邮箱格式不正确"),
    SECURITY_REPORT_STRATEGY_IS_NOT_EXIST(200464, "安全报告策略不存在"),
    EVENT_MODEL_IS_NOT_EXIST(200465, "告警模型不存在"),
    DEV_IP_NOT_EMPTY(200466, "IP不可以为空"),
    VISUAL_CHART_IS_NOT_EXIST(200467, "报表不存在"),


    ALARM_MODEL_RULE_FORMAT_ERROR(200480, "规则格式不正确或不支持，请检查"),
    ALARM_MODEL_SUB_KQL_FORMAT_ERROR(200480, "子集KQL格式不正确或不支持，请检查"),
    ALARM_MODEL_SUB_RULE_FORMAT_ERROR(200480, "子集格式不正确或不支持，请检查"),
    ALARM_MODEL_KQL_CONFIG_ERROR(200481, "KQL模型通用配置参数不完整，请检查"),
    ALARM_MODEL_TIME_CONFIG_ERROR(200482, "验证时间配置参数不完整，请检查"),
    ALARM_MODEL_NO_DATA_ERROR(200482, "模型子集查询无数据或查询失败，请检查"),
    ALARM_MODEL_SAVE_DATA_ERROR(200482, "模型子集查询结果保存失败，请检查"),

    ES_SOURCE_NOT_EXIST_ERROR(200483, "数据源为空，请检查"),
    ES_SOURCE_DSL_PARSE_ERROR(200484, "DSL解析失败，请检查"),

    /**
     * IP封堵
     */
    IP_ERROR(200493, "封堵IP格式有误，请重新检查"),
    IP_EMPTY(200493, "封堵IP不能为空，请重新检查"),
    NAME_STRATEGY_ERROR(200493, "策略名称已存在"),
    ;

    // 枚举名称
    private Integer key;

    // 枚举类型
    private String value;

    MessageEnum(Integer key, String value) {
        this.key = key;
        this.value = value;
    }

    public Integer getKey() {
        return key;
    }

    public void setKey(Integer key) {
        this.key = key;
    }

    public String getValue() {
        return value;
    }

    public void setValue(String value) {
        this.value = value;
    }


}
