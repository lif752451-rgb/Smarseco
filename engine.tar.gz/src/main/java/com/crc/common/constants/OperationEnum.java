package com.crc.common.constants;

public enum OperationEnum {
    LT(0, "LT"),

    LTE(1, "LTE"),//整型

    EQ(2, "EQ"),

    GT(3, "GT"),

    GTE(4, "GTE"),

    LIKE(5, "LIKE"),
    ;

    // 枚举名称
    private Integer key;

    // 枚举类型
    private String value;

    OperationEnum(Integer key, String value) {
        this.key = key;
        this.value = value;
    }

    public Integer getKey() {
        return key;
    }

    public void setKey(Integer key) {
        this.key = key;
    }

    public String getValue() {
        return value;
    }

    public void setValue(String value) {
        this.value = value;
    }
}
