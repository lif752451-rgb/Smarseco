package com.crc.common.constants;

/**
 * @author simba@onlying.cn
 * @date 2020/10/22 16:09
 */
public enum TaskTypeEnum {
    DETAIL("detail","详情"),
    ERROR("error","异常");

    private String type;

    private String desc;
    TaskTypeEnum(String type, String desc){
        this.type= type;
        this.desc = desc;
    }
}
