package com.crc.common.constants;

/**
 * IP封堵常量类
 *
 * @Author fuzhuangzhi
 * @Date 2023/2/8 17:01
 * @Version 1.0
 **/
public class IpPluggingConstant {

    /**
     * 发送企业微信提醒开关字典值
     */
    public static final String IP_PLUGGING_SWITCH = "ip_plugging_switch";

    /**
     * IP封堵发送企业微信标题
     */
    public static final String IP_PLUGGING_SUBJECT = "ip_plugging_subject";

    /**
     * 企业微信内容
     */
    public static final String QYWX_CONTENT = "【%s通知】%s IP执行%s结果";

    public static final String TO = "对";
}
