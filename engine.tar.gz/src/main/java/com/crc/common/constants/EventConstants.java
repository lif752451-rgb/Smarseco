package com.crc.common.constants;

import org.apache.commons.lang3.StringUtils;

import java.util.HashMap;

/**
 * @author simba@onlying.cn
 * @date 2020/8/4 18:30
 */
public class EventConstants {

    public static final String NOT_DISPOSED = "1";

    public static final String UN_CONFIRMED = "0";

    public static final String PREDICTJUDGE = "1";

    //事件级别
    public static String EVENT_LEVEL_DICT = "event_level";
    public static String EVENT_REV_LIST_DICT = "rwork_rev_list";

    public static String BOT_SEND_LIST="bot_send_list";

    public static String EVENT_ATTACK_TYPE_DICT = "attack_type";

    public static String EVENT_SOURCE_DICT = "event_source";

    public static String ATTACK_RESULT_DICT = "attack_result";

    public static HashMap<String, String> AttackResultMap = new HashMap<>();
    public static HashMap<String, String> EventStatusMap = new HashMap<>();
    public static HashMap<String, String> EventLevelMap = new HashMap<>();

    public static HashMap<String, String> sendAttackResultMap = new HashMap<>();

    static {

        sendAttackResultMap.put("1", "疑似成功");
        sendAttackResultMap.put("0", "企图");
        sendAttackResultMap.put("3", "失败");
        sendAttackResultMap.put("2", "疑似失陷");
        sendAttackResultMap.put("4", "已失陷");
        sendAttackResultMap.put("5", "攻击成功");
        AttackResultMap.put("疑似成功", "1");
        AttackResultMap.put("企图", "0");
        AttackResultMap.put("失败", "3");
        AttackResultMap.put("疑似失陷", "2");
        AttackResultMap.put("已失陷", "4");
        AttackResultMap.put("攻击成功", "5");
        //1：待研判，2：待处置，3：待审核，4：已归档，5：误判事件
        EventStatusMap.put("待研判", "1");
        EventStatusMap.put("待处置", "2");
        EventStatusMap.put("待审核", "3");
        EventStatusMap.put("已归档", "4");
        EventStatusMap.put("无需处置", "5");
        EventLevelMap.put("一级事件", "1");
        EventLevelMap.put("二级事件", "1");
        EventLevelMap.put("三级事件", "1");
        EventLevelMap.put("四级事件", "1");
    }


    public static String getAttackResultId(String result) {
        String attackResult =sendAttackResultMap.get(result);
        String resId ="";
        if(StringUtils.isEmpty(attackResult)){
            resId = "3";
            return resId;
        }
         resId = AttackResultMap.get(attackResult);
        if (StringUtils.isBlank(resId))
            resId = "3";
        return resId;
    }

    public static String getEventStatusId(String result) {
        String resId = EventStatusMap.get(result);
        if (StringUtils.isBlank(resId))
            resId = "3";
        return resId;
    }
}
