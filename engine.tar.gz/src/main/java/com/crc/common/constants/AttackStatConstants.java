package com.crc.common.constants;

import java.util.Arrays;
import java.util.List;

/**
 * @author simba@onlying.cn
 * @date 2020/9/29 15:29
 */
public class AttackStatConstants {

    public static final List<String> K01_ATTACK_STATS = Arrays.asList(new String[]{"外网攻击数","拦截数","拦截率"});

    public static final List<String> ATTACK_DEFENDS = Arrays.asList(new String[]{"绿盟IPS","长亭Waf","Imperva WAF","K01"});

    public static final List<String> ATTACK_MONITOR = Arrays.asList(new String[]{"奇安信天眼","青藤","深信服SIP","长亭蜜罐"});

    public static final String SUMMARY_TAG="全部";

    public static final String STAT_ORDER_FIELD="attack_ip";

    public static final String SELECT_FROM_PATTERN="(?<=select).*?(?=from)";

    public static final String AS ="as";

    public static final String RWORK_DAY_REPORT="rwork_day_report";

    public static final String RWORK_WEEK_REPORT ="rwork_week_report";



}
