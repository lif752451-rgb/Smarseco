package com.crc.common.constants;

/**
 * @author simba@onlying.cn
 * @date 2020/9/3 18:07
 */
public class DslConstants {

    public static final String ES_STATIC_TYPE ="es";

    public static final String DB_STATIC_TYPE ="db";

    public static final String MID_STATIC_TYPE ="mid";

    public static final String DSL_RANGE_TYPE ="range";

    public static final String DSL_MATCH_TYPE ="match_parchas";

    public static final String TERM_QUERY_TYPE ="term";

    public static final String SHOULD_LIST_TYPE ="shoulds";

    public static final String MULTI_MATCH_TYPE ="multi_match";

    public static final String USERNAME_TAG ="userName";

    public static final String PASSWORD_TAG ="password";

    public static final String PROXYHEADER_TAG ="proxyHeader";

    public static final String GROUP_BY ="group by";

    public static final String COUNT ="count";

    public static final String TYPE_TAG ="type";

    public static final String VALUE_TAG="value";

    public static final String FIELD_TAG ="field";

    public static final String BETWEEN_TAG ="between";

    public static final String AND_TAG ="and";

    public static final String ES_BUCKET_TAG="buckets";
}
