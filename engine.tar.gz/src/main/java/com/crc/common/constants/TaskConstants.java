package com.crc.common.constants;

/**
 * @author simba@onlying.cn
 * @date 2020/10/22 15:03
 */
public class TaskConstants {

    public static final Integer LOG_COLLECT_TASK=1;

    public static final Integer SPARK_TASK =2;

    public static final Integer MODEL_SCHEDULE_TASK=3;
}
