package com.crc.common.constants;

/**
 * @author simba@onlying.cn
 * @date 2020/10/21 19:06
 */
public enum TaskStatus {
    RUNNING(1,"运行中"),
    NORMAL_EXIT(2,"正常退出"),
    EXCEPTION(3,"异常"),
    FINISH(4,"完成");

    private int status;

    private String desc;

    TaskStatus(int status, String desc){
        this.status = status;
        this.desc = desc;
    }

    public int getStatus() {
        return status;
    }

    public String getDesc() {
        return desc;
    }

}
