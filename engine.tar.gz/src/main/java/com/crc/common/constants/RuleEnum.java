package com.crc.common.constants;

/**
 * @author simba@onlying.cn
 * @date 2020/9/30 14:51
 */
public enum RuleEnum {
    EQ("514","相等"),
    CONTAIN("515","包含"),
    REGREX("3","正则表达式");

    private String type;

    private String desc;

    RuleEnum(String type,String desc){
        this.type = type;
        this.desc =desc;
    }

    public String getType() {
        return type;
    }

    public String getDesc() {
        return desc;
    }

    public static RuleEnum resolveByType(String type){
        for(RuleEnum rule:RuleEnum.values()){
            if(rule.getType().equals(type)){
                return rule;
            }
        }
        return null;
    }


}
