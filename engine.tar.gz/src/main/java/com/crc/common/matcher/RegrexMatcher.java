package com.crc.common.matcher;

import com.crc.common.constants.RuleArthimaticEnum;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * @author simba@onlying.cn
 * @date 2020/10/23 18:37
 */
public class RegrexMatcher extends AbstractMatch {

    public RegrexMatcher(){
        super(RuleArthimaticEnum.REGREX);
    }
    @Override
    public boolean doMatch(Object source, Object target) {
        String sourceStr = source.toString();
        Pattern pattern = Pattern.compile(target.toString());
        Matcher matcher = pattern.matcher(sourceStr);
        while (matcher.find()){
            return true;
        }
        return false;
    }
}
