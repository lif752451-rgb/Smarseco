package com.crc.common.matcher;


import com.crc.common.constants.RuleArthimaticEnum;

/**
 * @author simba@onlying.cn
 * @date 2020/10/23 18:42
 */
public class SubNetMaskMatcher extends AbstractMatch {

    public SubNetMaskMatcher() {
        super(RuleArthimaticEnum.SUBNETMASK);
    }

    @Override
    public boolean doMatch(Object source, Object target) {
        return false;
    }
}
