package com.crc.common.matcher;


import com.crc.common.constants.RuleEnum;
import com.crc.common.constants.RuleTypeEnum;
import com.crc.common.utils.EsUtils;
import com.crc.secface.entity.TbRule;
import org.apache.commons.lang3.tuple.Pair;
import org.elasticsearch.index.query.AbstractQueryBuilder;
import org.elasticsearch.index.query.BoolQueryBuilder;
import org.elasticsearch.index.query.QueryBuilders;
import org.springframework.util.CollectionUtils;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.atomic.AtomicBoolean;
import java.util.stream.Collectors;

/**
 * @author simba@onlying.cn
 * @date 2020/9/30 14:03
 */
public class RuleParserV2 {

    //parseRule(String busModel)


    public static BoolQueryBuilder parse(List<TbRule> ruleList) {

        return recuriveBuildQuery(ruleList);
    }


    public static BoolQueryBuilder recuriveBuildQuery(List<TbRule> ruleList) {
        BoolQueryBuilder boolQueryBuilder = new BoolQueryBuilder();
        if (CollectionUtils.isEmpty(ruleList) || ruleList.size() == 1) {
            return null;
        }
        AtomicBoolean flag = new AtomicBoolean(false);
        List<Pair<List<TbRule>, TbRule>> pairList = getSubRuleGroup(ruleList, ruleList.get(0).getId());
        Map<Long, Pair<List<AbstractQueryBuilder>, RuleTypeEnum>> queryMap = new HashMap<>();
        pairList.forEach(pair -> {
            List<Pair<List<TbRule>, TbRule>> groupRuleList = getSubRuleGroup(ruleList, pair.getRight().getId());
            groupRuleList.forEach(group -> {
                ruleList.removeAll(group.getLeft());
                BoolQueryBuilder subBoolQueryBuilder = recuriveBuildQuery(group.getLeft());
                reGroup(pair.getRight(), queryMap);
                reGroup(pair.getRight(), queryMap, subBoolQueryBuilder);
                flag.set(true);
            });
        });
        ruleList.forEach(rule -> {
            reGroup(rule, queryMap);
            flag.set(true);
        });
        queryMap.forEach((k, v) -> {
            flag.set(true);
            if (v.getRight() == RuleTypeEnum.AND) {
                v.getLeft().forEach(query -> {
                    boolQueryBuilder.filter(query);
                });
            } else if (v.getRight() == RuleTypeEnum.SHOULD) {
                v.getLeft().forEach(query -> {
                    boolQueryBuilder.should(query);
                });

            } else if (v.getRight() == RuleTypeEnum.NOT) {
                v.getLeft().forEach(query -> {
                    boolQueryBuilder.mustNot(query);
                });
            }
        });
        if (flag.get()) {
            if(EsUtils.isBlankQuery(boolQueryBuilder))
                return null;
            return boolQueryBuilder;
        }
        return null;
    }

    public static void reGroup(TbRule rule, Map<Long, Pair<List<AbstractQueryBuilder>, RuleTypeEnum>> queryMap) {
        if (rule.getParentId() != 0) {
            //规则组
            if (Integer.parseInt(rule.getRuleType()) > 0 && Integer.parseInt(rule.getRuleType()) < 4) {
                //Pair<Set<AbstractQueryBuilder>, RuleTypeEnum> pair = queryMap.get(rule.getParentId());
                RuleEnum ruleEnum = RuleEnum.resolveByType(rule.getRule());
                if (ruleEnum == RuleEnum.CONTAIN || ruleEnum == RuleEnum.EQ) {
                    List<AbstractQueryBuilder> tempSet = new ArrayList<>();
                    AbstractQueryBuilder queryBuilder = QueryBuilders.matchPhraseQuery(rule.getRuleLabel(), rule.getContent());
                    tempSet.add(queryBuilder);
                    Pair<List<AbstractQueryBuilder>, RuleTypeEnum> pair = Pair.of(tempSet, RuleTypeEnum.resolveByType(Integer.parseInt(rule.getRuleType())));
                    queryMap.put(rule.getId(), pair);
                }
            }/* else if (Integer.parseInt(rule.getRuleType()) == 4) {
                Set<AbstractQueryBuilder> queryList = new HashSet<>();
                RuleTypeEnum ruleType = RuleTypeEnum.resolveByType(Integer.parseInt(rule.getRuleType()));
                Pair<Set<AbstractQueryBuilder>, RuleTypeEnum> pair = Pair.of(queryList, ruleType);
                if (!queryMap.containsKey(rule.getId())) {
                    queryMap.put(rule.getId(), pair);
                }
            }*/
            /*if (Integer.parseInt(rule.getRuleType()) > 0 && Integer.parseInt(rule.getRuleType()) < 4) {
                List<AbstractQueryBuilder> queryList = new ArrayList<>();
                RuleTypeEnum ruleType = RuleTypeEnum.resolveByType(Integer.parseInt(rule.getRuleType()));
                Pair<List<AbstractQueryBuilder>, RuleTypeEnum> pair = Pair.of(queryList, ruleType);
                if (!queryMap.containsKey(rule.getId())) {
                    queryMap.put(rule.getId(), pair);
                }
            } else if (Integer.parseInt(rule.getRuleType()) == 4) {
                Pair<List<AbstractQueryBuilder>, RuleTypeEnum> pair = queryMap.get(rule.getParentId());
                RuleEnum ruleEnum = RuleEnum.resolveByType(rule.getRule());
                if (ruleEnum == RuleEnum.CONTAIN || ruleEnum == RuleEnum.EQ) {
                    AbstractQueryBuilder queryBuilder = QueryBuilders.matchPhraseQuery(rule.getRuleLabel(), rule.getContent());
                    pair.getLeft().add(queryBuilder);
                }
            }*/
        }
    }

    public static void reGroup(TbRule parentRule, Map<Long, Pair<List<AbstractQueryBuilder>, RuleTypeEnum>> queryMap, AbstractQueryBuilder queryBuilder) {
        if (parentRule.getParentId() != 0) {
            //规则组
            Pair<List<AbstractQueryBuilder>, RuleTypeEnum> pair = queryMap.get(parentRule.getId());
            pair.getLeft().add(queryBuilder);
        }
    }


    //获取规则组中的子规则组
    public static List<Pair<List<TbRule>, TbRule>> getSubRuleGroup(List<TbRule> ruleList, Long parentId) {
        List<Pair<List<TbRule>, TbRule>> childList = new ArrayList<>();
        List<TbRule> groupRuleList = ruleList.stream().filter(rule -> {
            return 0 < Integer.parseInt(rule.getRuleType()) && Integer.parseInt(rule.getRuleType()) < 4
                    && rule.getParentId().longValue() == parentId.longValue();
        }).collect(Collectors.toList());
        for (TbRule groupRule : groupRuleList) {
            List<TbRule> childs = ruleList.stream().filter(rule -> {
                if (rule.getParentIds().contains(groupRule.getParentIds())) {
                    return true;
                }
                return false;
            }).collect(Collectors.toList());
            childList.add(Pair.of(childs, groupRule));
        }
        return childList;
    }

    //获取第二层的子规则


}
