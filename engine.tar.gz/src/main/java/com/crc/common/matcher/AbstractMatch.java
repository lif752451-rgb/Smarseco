package com.crc.common.matcher;

import com.crc.common.constants.RuleArthimaticEnum;

/**
 * @author simba@onlying.cn
 * @date 2020/10/23 18:12
 * 算法匹配基类
 */
public abstract class AbstractMatch {

    public AbstractMatch(RuleArthimaticEnum arthimaticEnum){
        this.arthimaticEnum = arthimaticEnum;
    }

    protected RuleArthimaticEnum arthimaticEnum;

    public abstract boolean doMatch(Object source,Object target);

    public  boolean support(String type){
        RuleArthimaticEnum arthimaticEnum2 = RuleArthimaticEnum.resolveByType(type);
        return this.arthimaticEnum == arthimaticEnum2;
    }


}
