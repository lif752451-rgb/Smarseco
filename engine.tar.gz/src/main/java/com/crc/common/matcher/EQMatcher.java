package com.crc.common.matcher;

import com.crc.common.constants.RuleArthimaticEnum;

/**
 * @author simba@onlying.cn
 * @date 2020/10/23 18:22
 */
public class EQMatcher extends AbstractMatch {


    public EQMatcher() {
        super(RuleArthimaticEnum.EQ);
    }

    @Override
    public boolean doMatch(Object source, Object target) {
       return String.valueOf(source).equals(String.valueOf(target));
    }


}
