package com.crc.common.matcher;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.util.CollectionUtils;

import java.util.ArrayList;
import java.util.List;

/**
 * @author simba@onlying.cn
 * @date 2020/10/23 18:45
 */
public class MatchHandler {

    private static final Logger logger = LoggerFactory.getLogger(MatchHandler.class);

    public static List<AbstractMatch>  matchList = new ArrayList<>();

    static{
        matchList.add(new EQMatcher());
        matchList.add(new ContainMatcher());
        matchList.add(new RegrexMatcher());
        matchList.add(new SubNetMaskMatcher());
    }

    public static boolean doMatch(String ruleType,String content,String target){
        boolean isMatch=false;
        if(CollectionUtils.isEmpty(matchList)){
            return isMatch;
        }

        for(AbstractMatch match:matchList){
            if(match.support(ruleType)){
                isMatch = match.doMatch(content,target);
            }
        }
        return isMatch;
    }
}
