package com.crc.common.matcher;

import com.crc.common.constants.RuleArthimaticEnum;

/**
 * @author simba@onlying.cn
 * @date 2020/10/23 18:34
 */
public class ContainMatcher extends AbstractMatch {

    public ContainMatcher(){
        super(RuleArthimaticEnum.CONTAIN);
    }
    @Override
    public boolean doMatch(Object source, Object target) {
        return String.valueOf(source).contains(String.valueOf(target));
    }
}
