package com.crc.common.utils;

import com.alibaba.fastjson.JSONObject;
import com.crc.secface.config.ElasticsearchProperties;
import com.crc.secface.config.EsDataSource;
import com.crc.secface.config.GetSpringBean;
import com.crc.secface.es.EsSingleFactory;
import lombok.extern.slf4j.Slf4j;
import org.elasticsearch.action.admin.indices.alias.get.GetAliasesRequest;
import org.elasticsearch.action.search.ClearScrollRequest;
import org.elasticsearch.action.search.ClearScrollResponse;
import org.elasticsearch.action.search.SearchRequest;
import org.elasticsearch.action.search.SearchResponse;
import org.elasticsearch.client.GetAliasesResponse;
import org.elasticsearch.client.RequestOptions;
import org.elasticsearch.client.RestHighLevelClient;
import org.elasticsearch.client.core.CountRequest;
import org.elasticsearch.client.core.CountResponse;
import org.elasticsearch.common.Strings;
import org.elasticsearch.common.settings.Settings;
import org.elasticsearch.common.xcontent.*;
import org.elasticsearch.index.query.BoolQueryBuilder;
import org.elasticsearch.search.SearchModule;
import org.elasticsearch.search.builder.SearchSourceBuilder;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Map;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

@Slf4j
public class EsUtils {
    private static final NamedXContentRegistry xContentRegistry;

    static {
        SearchModule searchModule =
                new SearchModule(Settings.EMPTY, false, Collections.emptyList());

        xContentRegistry =
                new NamedXContentRegistry(searchModule.getNamedXContents());
    }

    public static EsDataSource getDefualtEsSource() {
        EsDataSource esConfig = new EsDataSource();
        ElasticsearchProperties esProperty = GetSpringBean.getBean(ElasticsearchProperties.class);
        esConfig.setMode(esProperty.getMode());
        esConfig.setIndexRule("sec_all-*");
        esConfig.setUserName(esProperty.getUserName());
        esConfig.setPassword(esProperty.getPassword());
        esConfig.setPort(esProperty.getPort());
        esConfig.setProxyHeader(esProperty.getProxyHeader());
        esConfig.setHost(esProperty.getHost());
        esConfig.setSchema(esProperty.getSchema());
        return esConfig;
    }

    public static EsDataSource logSourceCheck(Map<String, String> indexAndSource) {
        if (indexAndSource == null) {
            log.error("数据库来源出错=NULL");
            return getDefualtEsSource();
        }
        try {
            String password = EncryptUtil.aesDecrypt(indexAndSource.get("password"));
            EsDataSource esConfig = new EsDataSource();
            esConfig.setMode(DataUtils.getString(indexAndSource, "proto"));
            esConfig.setTimeField(DataUtils.getString(indexAndSource, "timeField"));
            esConfig.setIndexRule(DataUtils.getString(indexAndSource, "indexRule"));
            esConfig.setDataIndexName(DataUtils.getString(indexAndSource, "dataIndexName"));
            esConfig.setGroupName(DataUtils.getString(indexAndSource, "groupName"));
            esConfig.setUserName(DataUtils.getString(indexAndSource, "userName"));
            esConfig.setPassword(password);
            String host = DataUtils.getString(indexAndSource, "host");
            if (StringUtils.isBlank(host)) {
                host = DataUtils.getString(indexAndSource, "ip");
            }
            esConfig.setHost(host);
            esConfig.setPort(DataUtils.toInt(DataUtils.getString(indexAndSource, "port")));
            //String ip = DataUtils.getString(indexAndSource, "ip");
            //esConfig.setProxyHeader("8994b14fd0ba4c5fabef5e6851a38c56");
            //EsUtils.esHostAndIp(ip, host, esConfig);
            if (indexAndSource.containsKey("remark")) {
                String remark = indexAndSource.get("remark");
                JSONObject parse = JsonUtils.parse(remark);
                if (parse.containsKey("X-Found-Cluster")) {
                    esConfig.setProxyHeader(JsonUtils.getStr(parse, "X-Found-Cluster"));
                }
            }
            return esConfig;
        } catch (Exception e) {
            log.error("数据库来源出错：{}", e.getMessage(), e);
            return getDefualtEsSource();
        }
    }

    private static final boolean TEST_MODE = false;

    public static boolean isBlankQuery(BoolQueryBuilder queryBuilder) {
        if (queryBuilder == null) {
            return true;
        }
        return queryBuilder.should().size() < 1 && queryBuilder.filter().size() < 1 && queryBuilder.mustNot().size() < 1 && queryBuilder.must().size() < 1;
    }

    public static void print(SearchResponse searchResponse, String modelId) {
        try {
            if (searchResponse != null && TEST_MODE) {
                XContentBuilder builder = XContentFactory.jsonBuilder();
                searchResponse.toXContent(builder, ToXContent.EMPTY_PARAMS);
                log.info("打印聚合查询数据############### " + modelId + " #################");
                String json = Strings.toString(searchResponse, true, true);
                log.info(json);
            }
        } catch (Exception e) {
            log.error(e.getMessage(), e);
        }
    }

    public static void print(SearchSourceBuilder sourceBuilder, String modelId) {
        try {
            if (sourceBuilder != null && TEST_MODE) {
                XContentBuilder builder = XContentFactory.jsonBuilder();
                sourceBuilder.toXContent(builder, ToXContent.EMPTY_PARAMS);
                log.info("打印聚合查询条件############### " + modelId + " #################");
                String json = Strings.toString(sourceBuilder, true, true);
                log.info(json);
            }
        } catch (Exception e) {
            log.error(e.getMessage(), e);
        }
    }


    public static void esHostAndIp(String ip, String host, EsDataSource esConfig) {
        if (StringUtils.isNotBlank(host)) {
            esConfig.setHost(host);
        } else {
            esConfig.setHost(ip);
        }
    }


    public static void cleanScrollId(RestHighLevelClient client, String scrollId) {
        try {
            //清除滚动，否则影响下次查询
            ClearScrollRequest clearScrollRequest = new ClearScrollRequest();
            clearScrollRequest.addScrollId(scrollId);
            ClearScrollResponse clearScrollResponse = null;
            clearScrollResponse = client.clearScroll(clearScrollRequest, RequestOptions.DEFAULT);
            System.out.println("滚动查询删除=" + clearScrollResponse.isSucceeded());
        } catch (Exception e) {
            System.out.println("滚动查询删除失败");
        }
    }

    /**
     * 符合索引规则，并在7天范围之内
     *
     * @param indexName 索引名称
     * @return
     */
    public static boolean indexContainDate(String indexName) {
        if (StringUtils.isBlank(indexName)) {
            return false;
        }
        Pattern pattern = Pattern.compile("[0-9]{4}[.][0-9]{1,2}[.][0-9]{1,2}");
        Matcher matcher = pattern.matcher(indexName);
        while (matcher.find()) {
            String date = matcher.group(0);
            //统计7天内的数据
            long diff = DateUtils.getInterval(date);
            return diff <= 7;
        }
        return false;
    }

    public static List<String> getAllIndex(RestHighLevelClient client) {
        try {
            /**
             * 获取所有index
             */
            GetAliasesRequest aliasesRequest = new GetAliasesRequest();
            GetAliasesResponse resp = client.indices().getAlias(aliasesRequest, RequestOptions.DEFAULT);
            List<String> indexs = new ArrayList<>();
            resp.getAliases().forEach((k, v) -> {
                if (!k.startsWith(".") && EsUtils.indexContainDate(k)) {
                    indexs.add(k);
                }
            });
            return indexs;
        } catch (Exception e) {
            log.error(e.getMessage(), e);
        }
        return null;
    }

    /**
     * 根据DSL查询ES
     *
     * @param elasticsearchProperties 配置
     * @param dsl                     DSL
     * @return 数据String
     */
    public static JSONObject getQueryJson(ElasticsearchProperties elasticsearchProperties, String indexName, String dsl) {
        String str = getQueryStr(elasticsearchProperties, indexName, dsl);
        if (StringUtils.isNotBlank(str)) {
            return JsonUtils.parse(str);
        }
        return null;
    }

    /**
     * 根据DSL查询ES
     *
     * @param elasticsearchProperties 配置
     * @param dsl                     DSL
     * @return 数据String
     */
    public static String getQueryStr(ElasticsearchProperties elasticsearchProperties, String indexName, String dsl) {
        EsSingleFactory factory = EsSingleFactory.getInstance();
        RestHighLevelClient restHighLevelClient = factory.getHighLevelClient(elasticsearchProperties);
        try {
            JSONObject jsonObject = JsonUtils.parse(dsl);
            jsonObject.remove("fields");
            jsonObject.remove("script_fields");
            jsonObject.remove("stored_fields");
            jsonObject.remove("runtime_mappings");
            jsonObject.remove("docvalue_fields");
            XContentParser parser =
                    XContentType.JSON.xContent().createParser(xContentRegistry,
                            LoggingDeprecationHandler.INSTANCE,
                            jsonObject.toJSONString());

            SearchSourceBuilder sourceBuilder = SearchSourceBuilder.fromXContent(parser);
            System.out.println(sourceBuilder);
            SearchRequest searchRequest = new SearchRequest(indexName);
            searchRequest.source(sourceBuilder);
            SearchResponse response = restHighLevelClient.search(searchRequest, RequestOptions.DEFAULT);
            return response.toString();
        } catch (Exception e) {
            log.error(e.getMessage(), e);
        } finally {
            factory.close(restHighLevelClient);
        }
        return "";
    }

    /**
     * 根据DSL查询ES
     *
     * @param elasticsearchProperties 配置
     * @param dsl                     DSL
     * @return 数据String
     */
    public static String getQueryCountStr(ElasticsearchProperties elasticsearchProperties, String indexName, String dsl) {
        EsSingleFactory factory = EsSingleFactory.getInstance();
        RestHighLevelClient restHighLevelClient = factory.getHighLevelClient(elasticsearchProperties);
        try {
            JSONObject jsonObject = JsonUtils.parse(dsl);
            jsonObject.remove("fields");
            jsonObject.remove("script_fields");
            jsonObject.remove("stored_fields");
            jsonObject.remove("runtime_mappings");
            jsonObject.remove("docvalue_fields");
            XContentParser parser =
                    XContentType.JSON.xContent().createParser(xContentRegistry,
                            LoggingDeprecationHandler.INSTANCE,
                            jsonObject.toJSONString());

            SearchSourceBuilder sourceBuilder = SearchSourceBuilder.fromXContent(parser);
            System.out.println(sourceBuilder);
            CountRequest searchRequest = new CountRequest(indexName);
            searchRequest.source(sourceBuilder);
            CountResponse response = restHighLevelClient.count(searchRequest, RequestOptions.DEFAULT);
            long count = response.getCount();
            JSONObject retJson =  new JSONObject();
            retJson.put("count", count);
            return retJson.toJSONString();
        } catch (Exception e) {
            log.error(e.getMessage(), e);
        } finally {
            factory.close(restHighLevelClient);
        }
        return "";
    }


    public static SearchSourceBuilder strToDsl(String str) {
        if (StringUtils.isBlank(str)) {
            return null;
        }
        try (XContentParser parser = XContentType.JSON.xContent().createParser(xContentRegistry,
                LoggingDeprecationHandler.INSTANCE,
                str)) {
            return SearchSourceBuilder.fromXContent(parser);
        } catch (Exception e) {
            log.error(e.getMessage(), e);
        }
        return null;
    }
}
