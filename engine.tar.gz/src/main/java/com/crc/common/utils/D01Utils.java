package com.crc.common.utils;

import org.apache.commons.lang3.StringUtils;
import org.apache.http.conn.ssl.NoopHostnameVerifier;
import org.apache.http.conn.ssl.SSLConnectionSocketFactory;
import org.apache.http.conn.ssl.TrustSelfSignedStrategy;
import org.apache.http.impl.client.CloseableHttpClient;
import org.apache.http.impl.client.HttpClients;
import org.apache.http.ssl.SSLContextBuilder;

import javax.net.ssl.HostnameVerifier;
import javax.net.ssl.SSLContext;
import java.security.KeyManagementException;
import java.security.KeyStoreException;
import java.security.NoSuchAlgorithmException;
import java.util.Arrays;
import java.util.Comparator;
import java.util.Map;
import java.util.TreeMap;
import java.util.concurrent.atomic.AtomicReference;

public class D01Utils {
    /**
     * 忽略HTTPS证书校验
     */
    public static CloseableHttpClient createAcceptSelfSignedCertificateClient()
            throws KeyManagementException, NoSuchAlgorithmException, KeyStoreException {
        SSLContext sslContext = SSLContextBuilder.create().loadTrustMaterial(new TrustSelfSignedStrategy()).build();
        HostnameVerifier allowAllHosts = new NoopHostnameVerifier();
        SSLConnectionSocketFactory connectionFactory = new SSLConnectionSocketFactory(sslContext, allowAllHosts);
        return HttpClients.custom().setSSLSocketFactory(connectionFactory).build();
    }

    public static String parseParam(String str) {
        Map<String, String> map = new TreeMap<String, String>(
                new Comparator<String>() {
                    public int compare(String obj1, String obj2) {
                        // 升序排序
                        return obj1.compareTo(obj2);
                    }
                });
        if (StringUtils.isBlank(str)) return "";
        Arrays.stream(str.split("&"))
                .filter(kv -> kv.contains("="))
                .map(kv -> kv.split("="))
                .forEach(array -> {
                    //map.put(array[0], array[1]);
                    if (array.length < 2) {
                        map.put(array[0], "");
                    } else {
                        map.put(array[0], array[1]);
                    }
                });
        AtomicReference<String> ret = new AtomicReference<>("");
        map.forEach((k, v) -> {
            if (StringUtils.isBlank(ret.get())) {
                ret.set(k + "=" + v);
            } else {
                ret.set(ret.get() + "&" + k + "=" + v);
            }
        });

        return ret.get();
    }

//    public static void main(String[] args) {
//        System.out.println(parseParam("search=&scan_type=&type=complete&sponsor=&page=1&per_page=20"));
//    }
}
