package com.crc.common.utils;

import com.alibaba.fastjson.JSON;

import java.util.Date;

public class TestUtils {
    public static void printTest(int i) {
        System.out.println(DateUtils.getSparkTime() + " --> " + i);
    }

    public static void printTest(String i) {
        System.out.println(DateUtils.getSparkTime() + " --> " + i);
    }

    public static void printTest(Object obj) {
        if (obj instanceof Date) {
            System.out.println(DateUtils.getSparkTime() + " --> " + DateUtils.getDateTimeString1((Date)obj));
            return;
        }
        System.out.println(DateUtils.getSparkTime() + " --> " + JSON.toJSONString(obj));
    }
}
