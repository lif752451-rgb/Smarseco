package com.crc.common.utils;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;
import com.crc.model.AggCondition;
import com.crc.model.EsConditionTree;
import com.crc.model.EsEventParams;
import com.crc.model.JudgeCondition;
import com.crc.secface.config.ElasticsearchProperties;
import com.crc.secface.config.EsDataSource;
import com.crc.secface.config.GetSpringBean;
import com.crc.secface.entity.ModelQueryChildCondition;
import com.crc.secface.entity.SysDictData;
import com.crc.secface.entity.TbEventModel;
import com.crc.secface.mapper.SysDictDataMapper;
import com.crc.secface.mapper.TbEventModelMapper;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.apache.commons.text.StringEscapeUtils;
import org.elasticsearch.index.query.BoolQueryBuilder;
import org.elasticsearch.index.query.QueryBuilders;
import org.elasticsearch.index.query.RangeQueryBuilder;
import org.elasticsearch.script.Script;
import org.elasticsearch.search.aggregations.AggregationBuilder;
import org.elasticsearch.search.aggregations.AggregationBuilders;
import org.elasticsearch.search.aggregations.BucketOrder;
import org.elasticsearch.search.aggregations.ParsedAggregation;
import org.elasticsearch.search.aggregations.bucket.terms.Terms;
import org.elasticsearch.search.aggregations.bucket.terms.TermsAggregationBuilder;
import org.elasticsearch.search.aggregations.metrics.avg.AvgAggregationBuilder;
import org.elasticsearch.search.aggregations.metrics.avg.ParsedAvg;
import org.elasticsearch.search.aggregations.metrics.cardinality.CardinalityAggregationBuilder;
import org.elasticsearch.search.aggregations.metrics.cardinality.ParsedCardinality;
import org.elasticsearch.search.aggregations.metrics.max.MaxAggregationBuilder;
import org.elasticsearch.search.aggregations.metrics.max.ParsedMax;
import org.elasticsearch.search.aggregations.metrics.min.MinAggregationBuilder;
import org.elasticsearch.search.aggregations.metrics.min.ParsedMin;
import org.elasticsearch.search.aggregations.pipeline.PipelineAggregatorBuilders;
import org.elasticsearch.search.aggregations.pipeline.bucketselector.BucketSelectorPipelineAggregationBuilder;
import org.elasticsearch.search.builder.SearchSourceBuilder;

import java.util.*;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import java.util.stream.Collectors;

import static com.crc.common.constants.DictTypeEnum.ALARM_MODEL_ES_INDEX;

/**
 * @author jixiangqi
 * @date 2022/9/6
 * 组装聚合告警模型查询语句
 */
@Slf4j
public class EsEventModelUtils {

    private static final String CHECK_KEYWORD = "([\\w_]+.keyword).([\\d]+).([\\w]+)";

    private static final String CHECK_NO_KEYWORD = "([\\w_]+).([\\d]+).([\\w]+)";

    private static final String JUDGE_PREFIX = "judge_prefix_";

    private static final String PLACEHOLDER = "\\{{3}([^\\}]+)\\}{3}";

    private static final String CHECK_NO_SORT_AND_KEYWORD = "([\\w_]+)";

    private static final String CHECK_NO_SORT = "([\\w_]+.keyword)";
    public static final long DATE_START_2020 = 1577808000000L;
    public static EsEventParams createEsQuery(TbEventModel eventModel, SearchSourceBuilder sourceBuilder, List<Map<String, String>> timeList, BoolQueryBuilder boolQueryBuilder) {
        EsConditionTree tree = new EsConditionTree();
        TermsAggregationBuilder lastAgg = null;
        LinkedHashMap<String, String> aggFields = new LinkedHashMap();
        StringBuffer treeSb = new StringBuffer();

        /**
         * 时间区间
         */
        timeList.forEach(map -> {
            RangeQueryBuilder rangeQueryBuilder = QueryBuilders.rangeQuery(eventModel.getSortKey());
            String startTime = map.get("startTime");
            String endTime = map.get("endTime");
            rangeQueryBuilder.gte(startTime);
            rangeQueryBuilder.lte(endTime);
            boolQueryBuilder.filter(rangeQueryBuilder);//.minimumShouldMatch(1);
        });
        Object aggParams = eventModel.getAggParams();
        List<AggCondition> aggConditionList = JSON.parseArray(aggParams.toString(), AggCondition.class);
        List<JudgeCondition> judgeConditionList = JSON.parseArray(eventModel.getJudgeParams(), JudgeCondition.class);
        Map<String, TermsAggregationBuilder> stringTermsAggregationBuilderMap = aggCondition(aggConditionList, aggFields, judgeConditionList,
                tree, lastAgg, treeSb);
        TermsAggregationBuilder aggregationBuilder = stringTermsAggregationBuilderMap.get("termsAggregationBuilder");
        lastAgg = stringTermsAggregationBuilderMap.get("lastAgg");

        int index = 0;

        if (eventModel.getDeviceType() == 0) {
            Pattern p = Pattern.compile(PLACEHOLDER);
            Matcher m = p.matcher(eventModel.getDeviceName());
            while (m.find()) {
                boolean flag = true;
                boolean flag1 = true;
                String value = m.group(1);
                if (value.contains("keyword")) {
                    p = Pattern.compile(CHECK_KEYWORD);
                } else {
                    p = Pattern.compile(CHECK_NO_KEYWORD);
                }
                Matcher m1 = p.matcher(value);
                AggregationBuilder top = null;
                while (m1.find()) {
                    flag1 = false;
                    if (m1.group(3).equalsIgnoreCase("desc")) {
                        top = AggregationBuilders.terms(index + "topResult_" + value).field(m1.group(1)).order(BucketOrder.aggregation("orderAgg", false))
                                .size(DataUtils.toInt(m1.group(2))).subAggregation(AggregationBuilders.max("orderAgg").field("SparkTime"));
                    } else if (m1.group(3).equalsIgnoreCase("asc")) {
                        top = AggregationBuilders.terms(index + "topResult_" + value).field(m1.group(1)).order(BucketOrder.aggregation("orderAgg", true))
                                .size(DataUtils.toInt(m1.group(2))).subAggregation(AggregationBuilders.min("orderAgg").field("SparkTime"));
                    } else if (m1.group(3).equalsIgnoreCase("top")) {
                        top = AggregationBuilders.terms(index + "topResult_" + value).field(m1.group(1)).order(BucketOrder.count(false)).size(DataUtils.toInt(m1.group(2)));
                    }
                }
                if (flag1) {
                    if (flag) {
                        p = Pattern.compile(CHECK_NO_SORT);
                    } else {
                        p = Pattern.compile(CHECK_NO_SORT_AND_KEYWORD);
                    }
                    m1 = p.matcher(value);
                    while (m1.find()) {
                        top = AggregationBuilders.terms(index + "topResult_" + value).field(m1.group(1));
                    }
                }
                if (null != top) {
                    lastAgg.subAggregation(top);
                    treeSb.append(",").append(index).append("topResult_").append(value);
                    index++;
                }
            }
        }


        if (eventModel.getAlarmType() == 0) {
            Pattern p = Pattern.compile(PLACEHOLDER);
            Matcher m = p.matcher(eventModel.getEventName());
            while (m.find()) {
                boolean flag = true;
                boolean flag1 = true;
                String value = m.group(1);
                if (value.contains("keyword")) {
                    p = Pattern.compile(CHECK_KEYWORD);
                } else {
                    p = Pattern.compile(CHECK_NO_KEYWORD);
                }
                Matcher m1 = p.matcher(value);
                AggregationBuilder top = null;
                while (m1.find()) {
                    flag1 = false;
                    if (m1.group(3).equalsIgnoreCase("desc")) {
                        top = AggregationBuilders.terms(index + "topResult_" + value).field(m1.group(1)).order(BucketOrder.aggregation("orderAgg", false))
                                .size(DataUtils.toInt(m1.group(2))).subAggregation(AggregationBuilders.max("orderAgg").field("SparkTime"));
                    } else if (m1.group(3).equalsIgnoreCase("asc")) {
                        top = AggregationBuilders.terms(index + "topResult_" + value).field(m1.group(1)).order(BucketOrder.aggregation("orderAgg", true))
                                .size(DataUtils.toInt(m1.group(2))).subAggregation(AggregationBuilders.min("orderAgg").field("SparkTime"));
                    } else if (m1.group(3).equalsIgnoreCase("top")) {
                        top = AggregationBuilders.terms(index + "topResult_" + value).field(m1.group(1)).order(BucketOrder.count(false)).size(DataUtils.toInt(m1.group(2)));
                    }
                }
                if (flag1) {
                    if (flag) {
                        p = Pattern.compile(CHECK_NO_SORT);
                    } else {
                        p = Pattern.compile(CHECK_NO_SORT_AND_KEYWORD);
                    }
                    m1 = p.matcher(value);
                    while (m1.find()) {
                        top = AggregationBuilders.terms(index + "topResult_" + value).field(m1.group(1));
                    }
                }
                if (null != top) {
                    lastAgg.subAggregation(top);
                    treeSb.append(",").append(index).append("topResult_").append(value);
                    index++;
                }
            }
        }

        if (eventModel.getAttackIpType() == 0) {
            Pattern p = Pattern.compile(PLACEHOLDER);
            Matcher m = p.matcher(eventModel.getAttackIp());
            while (m.find()) {
                boolean flag = true;
                boolean flag1 = true;
                String value = m.group(1);
                if (value.contains("keyword")) {
                    p = Pattern.compile(CHECK_KEYWORD);
                } else {
                    p = Pattern.compile(CHECK_NO_KEYWORD);
                }
                Matcher m1 = p.matcher(value);
                AggregationBuilder top = null;
                while (m1.find()) {
                    flag1 = false;
                    if (m1.group(3).equalsIgnoreCase("desc")) {
                        top = AggregationBuilders.terms(index + "topResult_" + value).field(m1.group(1)).order(BucketOrder.aggregation("orderAgg", false))
                                .size(DataUtils.toInt(m1.group(2))).subAggregation(AggregationBuilders.max("orderAgg").field("SparkTime"));
                    } else if (m1.group(3).equalsIgnoreCase("asc")) {
                        top = AggregationBuilders.terms(index + "topResult_" + value).field(m1.group(1)).order(BucketOrder.aggregation("orderAgg", true))
                                .size(DataUtils.toInt(m1.group(2))).subAggregation(AggregationBuilders.min("orderAgg").field("SparkTime"));
                    } else if (m1.group(3).equalsIgnoreCase("top")) {
                        top = AggregationBuilders.terms(index + "topResult_" + value).field(m1.group(1)).order(BucketOrder.count(false)).size(DataUtils.toInt(m1.group(2)));
                    }
                }
                if (flag1) {
                    if (flag) {
                        p = Pattern.compile(CHECK_NO_SORT);
                    } else {
                        p = Pattern.compile(CHECK_NO_SORT_AND_KEYWORD);
                    }
                    m1 = p.matcher(value);
                    while (m1.find()) {
                        top = AggregationBuilders.terms(index + "topResult_" + value).field(m1.group(1));
                    }
                }
                if (null != top) {
                    lastAgg.subAggregation(top);
                    treeSb.append(",").append(index).append("topResult_").append(value);
                    index++;
                }
            }
        }

        if (eventModel.getAlarmDescType() == 0) {
            Pattern p = Pattern.compile(PLACEHOLDER);
            Matcher m = p.matcher(eventModel.getAlarmDesc());
            while (m.find()) {
                boolean flag = true;
                boolean flag1 = true;
                String value = m.group(1);
                if (value.contains("keyword")) {
                    p = Pattern.compile(CHECK_KEYWORD);
                } else {
                    p = Pattern.compile(CHECK_NO_KEYWORD);
                }
                Matcher m1 = p.matcher(value);
                AggregationBuilder top = null;
                while (m1.find()) {
                    flag1 = false;
                    if (m1.group(3).equalsIgnoreCase("desc")) {
                        top = AggregationBuilders.terms(index + "topResult_" + value).field(m1.group(1)).order(BucketOrder.aggregation("orderAgg", false))
                                .size(DataUtils.toInt(m1.group(2))).subAggregation(AggregationBuilders.max("orderAgg").field("SparkTime"));
                    } else if (m1.group(3).equalsIgnoreCase("asc")) {
                        top = AggregationBuilders.terms(index + "topResult_" + value).field(m1.group(1)).order(BucketOrder.aggregation("orderAgg", true))
                                .size(DataUtils.toInt(m1.group(2))).subAggregation(AggregationBuilders.min("orderAgg").field("SparkTime"));
                    } else if (m1.group(3).equalsIgnoreCase("top")) {
                        top = AggregationBuilders.terms(index + "topResult_" + value).field(m1.group(1)).order(BucketOrder.count(false)).size(DataUtils.toInt(m1.group(2)));
                    }
                }
                if (flag1) {
                    if (flag) {
                        p = Pattern.compile(CHECK_NO_SORT);
                    } else {
                        p = Pattern.compile(CHECK_NO_SORT_AND_KEYWORD);
                    }
                    m1 = p.matcher(value);
                    while (m1.find()) {
                        top = AggregationBuilders.terms(index + "topResult_" + value).field(m1.group(1));
                    }
                }
                if (null != top) {
                    lastAgg.subAggregation(top);
                    treeSb.append(",").append(index).append("topResult_").append(value);
                    index++;
                }
            }
        }

        String sufferIp = eventModel.getSufferIp();
        int sufferIpType = eventModel.getSufferIpType();
        if (sufferIpType == 0) {
            /*
             * 说明需要组装查询
             */
            Pattern p = Pattern.compile(PLACEHOLDER);
            Matcher m = p.matcher(sufferIp);
            boolean flag = true;
            boolean flag1 = true;
            while (m.find()) {
                String value = m.group(1);
                if (value.contains("keyword")) {
                    p = Pattern.compile(CHECK_KEYWORD);
                } else {
                    p = Pattern.compile(CHECK_NO_KEYWORD);
                    flag = false;
                }
                Matcher m1 = p.matcher(value);
                AggregationBuilder top = null;
                while (m1.find()) {
                    flag1 = false;
                    if (m1.group(3).equalsIgnoreCase("desc")) {
                        top = AggregationBuilders.terms(index + "topResult_" + value).field(m1.group(1)).order(BucketOrder.aggregation("orderAgg", false))
                                .size(DataUtils.toInt(m1.group(2))).subAggregation(AggregationBuilders.max("orderAgg").field("SparkTime"));
                    } else if (m1.group(3).equalsIgnoreCase("asc")) {
                        top = AggregationBuilders.terms(index + "topResult_" + value).field(m1.group(1)).order(BucketOrder.aggregation("orderAgg", true))
                                .size(DataUtils.toInt(m1.group(2))).subAggregation(AggregationBuilders.min("orderAgg").field("SparkTime"));
                    } else if (m1.group(3).equalsIgnoreCase("top")) {
                        top = AggregationBuilders.terms(index + "topResult_" + value).field(m1.group(1)).order(BucketOrder.count(false)).size(DataUtils.toInt(m1.group(2)));
                    }
                }
                if (flag1) {
                    if (flag) {
                        p = Pattern.compile(CHECK_NO_SORT);
                    } else {
                        p = Pattern.compile(CHECK_NO_SORT_AND_KEYWORD);
                    }
                    m1 = p.matcher(value);
                    while (m1.find()) {
                        top = AggregationBuilders.terms(index + "topResult_" + value).field(m1.group(1));
                    }
                }
                if (null != top) {
                    lastAgg.subAggregation(top);
                    treeSb.append(",").append(index).append("topResult_").append(value);
                    index++;
                }

            }
        }

        /**
         * 判断条件皆为同级关系
         * 所以直接使用new的方式创建
         */
        EsConditionTree lastTree = getLastTree(tree);
        lastTree.setChildren(new EsConditionTree(treeSb.substring(0, treeSb.length()), null));
        sourceBuilder.query(boolQueryBuilder).aggregation(aggregationBuilder);

        /*
         * 返回构建条件
         */
        Map<String, Integer> countIndexMap = new HashMap<>();
        for (int i = 0; i < judgeConditionList.size(); i++) {
            JudgeCondition judgeCondition = judgeConditionList.get(i);
            if (judgeCondition.getType() == 0) {
                countIndexMap.put(judgeCondition.getCensusFields(), i + 1);
            }
        }
        EsEventParams esEventParams = new EsEventParams();
        esEventParams.setTree(tree);
        esEventParams.setLastAgg(lastAgg);
        esEventParams.setAggFields(aggFields);
        esEventParams.setTreeSb(treeSb);
        esEventParams.setCountIndexMap(countIndexMap);
        return esEventParams;
    }


    static String tempTree = "";

    /**
     * 输出定义
     *
     * @param group
     * @param eventModelVo
     * @param value
     * @param newTree
     */
    public static Map<String, Object> createAlarmMsg(Terms group, TbEventModel eventModelVo, int value, EsConditionTree newTree, Map<String, String> mapTemp,
                                                     EsEventParams params) {
        LinkedHashMap<String, String> aggMap = params.getAggFields();
        int index = -1;
        int count = 0;
        List<Map<String, String>> resultMap = new ArrayList<>();
        if (null != newTree.getChildren()) {
            /**
             * 说明是聚合语句
             */
            BeanUtils.copyBeanProp(newTree, newTree.getChildren());
            if (null != group && group.getBuckets().size() > 0) {
                List<? extends Terms.Bucket> buckets = group.getBuckets();
                for (int j = 0; j < buckets.size(); j++) {
                    Terms.Bucket bucket = buckets.get(j);
                    String valueStr = bucket.getKeyAsString();
                    String groupName = group.getName();
                    String aggField = aggMap.get(groupName);
                    Map<String, Integer> countIndexMap = params.getCountIndexMap();
                    if (countIndexMap.size() > 0) {
                        if (countIndexMap.containsKey(aggField)) {
                            index = countIndexMap.get(aggField);
                        }
                    }
                    Map<String, String> map = new HashMap<>(mapTemp);
                    String replaceStr1 = "\\{" + value + "\\}(?!\\})";
                    String replaceStr2 = "\\{{2}" + index + "\\}{2}(?!\\})";
                    String s2 = String.valueOf(bucket.getDocCount());
                    if (eventModelVo.getAlarmType() == 0) {
                        String eventName = map.get("eventName");
                        if (StringUtils.isEmpty(eventName)) {
                            eventName = eventModelVo.getEventName();
                        }
                        eventName = DataUtils.getReplaceAll(eventName, replaceStr1, valueStr);
                        eventName = DataUtils.getReplaceAll(eventName, replaceStr2, s2);
                        map.put("eventName", eventName);
                    }
                    if (eventModelVo.getAttackIpType() == 0) {
                        String attackIp = map.get("attackIp");
                        if (StringUtils.isEmpty(attackIp)) {
                            attackIp = eventModelVo.getAttackIp();
                        }
                        attackIp = DataUtils.getReplaceAll(attackIp, replaceStr1, valueStr);
                        attackIp = DataUtils.getReplaceAll(attackIp, replaceStr2, s2);
                        map.put("attackIp", attackIp);
                    }
                    if (eventModelVo.getSufferIpType() == 0) {
                        String sufferIp = map.get("sufferIp");
                        if (StringUtils.isEmpty(sufferIp)) {
                            sufferIp = eventModelVo.getSufferIp();
                        }
                        sufferIp = DataUtils.getReplaceAll(sufferIp, replaceStr1, valueStr);
                        sufferIp = DataUtils.getReplaceAll(sufferIp, replaceStr2, s2);
                        map.put("sufferIp", sufferIp);
                    }
                    if (eventModelVo.getAlarmDescType() == 0) {
                        String alarmDesc = map.get("alarmDesc");
                        if (StringUtils.isEmpty(alarmDesc)) {
                            alarmDesc = eventModelVo.getAlarmDesc();
                        }
                        alarmDesc = DataUtils.getReplaceAll(alarmDesc, replaceStr1, valueStr);
                        alarmDesc = DataUtils.getReplaceAll(alarmDesc, replaceStr2, s2);
                        map.put("alarmDesc", alarmDesc);
                    }
                    if (eventModelVo.getDeviceType() == 0) {
                        String deviceName = map.get("deviceNameLabel");
                        if (StringUtils.isEmpty(deviceName)) {
                            deviceName = eventModelVo.getDeviceName();
                        }
                        deviceName = DataUtils.getReplaceAll(deviceName, replaceStr1, valueStr);
                        deviceName = DataUtils.getReplaceAll(deviceName, replaceStr2, s2);
                        map.put("deviceNameLabel", deviceName);
                    }
                    if (null != newTree.getChildren()) {
                        String s = ergodicObtainTree(newTree);
                        tempTree = s;
                        Terms group1 = bucket.getAggregations().get(s);
                        if (group1.getBuckets().size() <= 0) {
                            continue;
                        }
                        HashMap<String, String> objectObjectHashMap = new HashMap<>(map);
                        Map<String, Object> alarmMsg = createAlarmMsg(group1, eventModelVo, value + 1, newTree, objectObjectHashMap, params);
                        newTree = (EsConditionTree) alarmMsg.get("newTree");
                        List<Map<String, String>> resultMap1 = (List<Map<String, String>>) alarmMsg.get("resultMap");
                        resultMap.addAll(resultMap1);
                    } else {
                        /**
                         * 说明是判断语句
                         */
                        String name = newTree.getGroupName();
                        String[] split = DataUtils.getSplit(name, ",");
                        for (int i = 0; i < split.length; i++) {
                            String s = split[i];
                            int lastIndex = DataUtils.getLastIndex(s, "_");
                            String s1 = DataUtils.getSubString(s, lastIndex + 1, s.length());
                            int index2 = DataUtils.toInt(s1) + 1;
                            if (StringUtils.isNotBlank(s) && (s.contains("distinct") || s.contains("max") || s.contains("min") || s.contains("avg"))) {
                                /**
                                 * 说明是唯一计数的groupName
                                 */
                                ParsedAggregation groupJudge = bucket.getAggregations().get(s);
                                String value1 = "";
                                if (s.contains("distinct")) {
                                    ParsedCardinality a = (ParsedCardinality) groupJudge;
                                    value1 = String.valueOf(a.getValue());
                                } else if (s.contains("max")) {
                                    ParsedMax a = (ParsedMax) groupJudge;
                                    value1 = String.valueOf(a.getValue());
                                } else if (s.contains("min")) {
                                    ParsedMin a = (ParsedMin) groupJudge;
                                    value1 = String.valueOf(a.getValue());
                                } else if (s.contains("avg")) {
                                    ParsedAvg a = (ParsedAvg) groupJudge;
                                    value1 = String.format("%.2f", a.getValue());
                                }
                                String replaceStr = "\\{{2}" + index2 + "\\}{2}(?!\\})";
                                if (eventModelVo.getAlarmType() == 0) {
                                    String eventName = map.get("eventName");
                                    if (StringUtils.isEmpty(eventName)) {
                                        eventName = eventModelVo.getEventName();
                                    }
                                    eventName = DataUtils.getReplaceAll(eventName, replaceStr, value1);
                                    map.put("eventName", eventName);
                                }
                                if (eventModelVo.getAttackIpType() == 0) {
                                    String attackIp = map.get("attackIp");
                                    if (StringUtils.isEmpty(attackIp)) {
                                        attackIp = eventModelVo.getAttackIp();
                                    }
                                    attackIp = DataUtils.getReplaceAll(attackIp, replaceStr, value1);
                                    map.put("attackIp", attackIp);
                                }
                                if (eventModelVo.getAlarmDescType() == 0) {
                                    String alarmDesc = map.get("alarmDesc");
                                    if (StringUtils.isEmpty(alarmDesc)) {
                                        alarmDesc = eventModelVo.getAlarmDesc();
                                    }
                                    alarmDesc = DataUtils.getReplaceAll(alarmDesc, replaceStr, value1);
                                    map.put("alarmDesc", alarmDesc);
                                }
                                if (eventModelVo.getSufferIpType() == 0) {
                                    String sufferIp = map.get("sufferIp");
                                    if (StringUtils.isEmpty(sufferIp)) {
                                        sufferIp = eventModelVo.getSufferIp();
                                    }
                                    sufferIp = DataUtils.getReplaceAll(sufferIp, replaceStr, value1);
                                    map.put("sufferIp", sufferIp);
                                }
                                if (eventModelVo.getDeviceType() == 0) {
                                    String deviceName = map.get("deviceNameLabel");
                                    if (StringUtils.isEmpty(deviceName)) {
                                        deviceName = eventModelVo.getDeviceName();
                                    }
                                    deviceName = DataUtils.getReplaceAll(deviceName, replaceStr, value1);
                                    map.put("deviceNameLabel", deviceName);
                                }
                            } else if (StringUtils.isNotBlank(s) && s.contains("topResult")) {
                                /**
                                 * 说明是表达式替换
                                 */
                                int index1 = DataUtils.getIndex(s, "_");
                                String replaceStr = DataUtils.getSubString(s, index1 + 1, s.length());
                                String replaceValue = "\\{{3}" + replaceStr + "\\}{3}(?!\\})";
                                Terms groupTop = bucket.getAggregations().get(s);
                                StringBuilder sb = new StringBuilder();
                                for (Terms.Bucket bucketTop : groupTop.getBuckets()) {
                                    String valueStrX = bucketTop.getKeyAsString();
                                    if (valueStrX != null && valueStrX.length() > 10) {
                                        if(DateUtils.isDate(valueStrX.substring(0,10))) {
                                            try {
                                                Number data = bucketTop.getKeyAsNumber();
                                                if (data != null) {
                                                    if (data.longValue() > DATE_START_2020) {
                                                        valueStrX = DateUtils.getDateTimeString1(new Date(data.longValue()));
                                                    }
                                                }

                                            } catch (Exception ignored) {

                                            }
                                        }
                                    }
                                    sb.append(valueStrX).append(",");
                                }
                                int lastIndex1 = DataUtils.getLastIndex(sb.toString(), ",");
                                String subString = DataUtils.getSubString(sb.toString(), 0, lastIndex1);
                                if (eventModelVo.getAlarmType() == 0) {
                                    String eventName = map.get("eventName");
                                    if (StringUtils.isEmpty(eventName)) {
                                        eventName = eventModelVo.getEventName();
                                    }
                                    eventName = DataUtils.getReplaceAll(eventName, replaceValue, subString);
                                    map.put("eventName", eventName);
                                }
                                if (eventModelVo.getAttackIpType() == 0) {
                                    String attackIp = map.get("attackIp");
                                    if (StringUtils.isEmpty(attackIp)) {
                                        attackIp = eventModelVo.getAttackIp();
                                    }
                                    attackIp = DataUtils.getReplaceAll(attackIp, replaceValue, subString);
                                    map.put("attackIp", attackIp);
                                }
                                if (eventModelVo.getAlarmDescType() == 0) {
                                    String alarmDesc = map.get("alarmDesc");
                                    if (StringUtils.isEmpty(alarmDesc)) {
                                        alarmDesc = eventModelVo.getAlarmDesc();
                                    }
                                    alarmDesc = DataUtils.getReplaceAll(alarmDesc, replaceValue, subString);
                                    map.put("alarmDesc", alarmDesc);
                                }
                                if (eventModelVo.getSufferIpType() == 0) {
                                    String sufferIp = map.get("sufferIp");
                                    if (StringUtils.isEmpty(sufferIp)) {
                                        sufferIp = eventModelVo.getSufferIp();
                                    }
                                    sufferIp = DataUtils.getReplaceAll(sufferIp, replaceValue, subString);
                                    map.put("sufferIp", sufferIp);
                                }
                                if (eventModelVo.getDeviceType() == 0) {
                                    String deviceName = map.get("deviceNameLabel");
                                    if (StringUtils.isEmpty(deviceName)) {
                                        deviceName = eventModelVo.getDeviceName();
                                    }
                                    deviceName = DataUtils.getReplaceAll(deviceName, replaceValue, subString);
                                    map.put("deviceNameLabel", deviceName);
                                }
                            }
                        }
                        resultMap.add(map);
                    }
                    count++;
                }
                if (count == buckets.size()) {
                    tempTree = newTree.getGroupName();
                }
            }
        }
        //BeanUtils.copyBeanProp(newTree, params.getTree().getChildren());
        newTree = getTreeByName(tempTree, params.getTree());
        Map<String, Object> paramMap = new HashMap<>();
        paramMap.put("newTree", newTree);
        paramMap.put("resultMap", resultMap);
        return paramMap;
    }


    private static EsConditionTree getTreeByName(String name, EsConditionTree params) {
        EsConditionTree tree = new EsConditionTree();
        if (null != params.getChildren()) {
            if (params.getChildren().getGroupName().equals(name)) {
                BeanUtils.copyBeanProp(tree, params);
            } else {
                BeanUtils.copyBeanProp(tree, getTreeByName(name, params.getChildren()));
            }
        }
        return tree;
    }

    /**
     * 当出现计数是：需要根据统计的字段来对应分组
     * 如果没有字段是：默认过滤最后一个聚合字段的值
     *
     * @param termsAggregationBuilder
     * @param fields
     * @return
     */
    private static TermsAggregationBuilder countByAggField(TermsAggregationBuilder termsAggregationBuilder, String fields) {
        String name = termsAggregationBuilder.field();
        if (name.startsWith(fields) || fields.equals(name)) {
            return termsAggregationBuilder;
        } else {
            Collection<AggregationBuilder> subAggregations = termsAggregationBuilder.getSubAggregations();
            ArrayList<AggregationBuilder> list = new ArrayList<>(subAggregations);
            if (list.size() > 0) {
                TermsAggregationBuilder aggregationBuilder = (TermsAggregationBuilder) list.get(0);
                return countByAggField(aggregationBuilder, fields);
            }
        }
        return null;
    }


    /**
     * 构建查询语句
     *
     * @param aggConditionList
     * @param judgeConditionList
     * @return
     */
    private static Map<String, TermsAggregationBuilder> aggCondition(List<AggCondition> aggConditionList, LinkedHashMap<String, String> aggFields,
                                                                     List<JudgeCondition> judgeConditionList, EsConditionTree tree, TermsAggregationBuilder lastAgg,
                                                                     StringBuffer treeSb) {
        Map<String, TermsAggregationBuilder> map = new HashMap<>();
        TermsAggregationBuilder termsAggregationBuilder = null;

        Map<Integer, List<JudgeCondition>> collect = judgeConditionList.stream().collect(Collectors.groupingBy(JudgeCondition::getType));
        List<JudgeCondition> countList = new ArrayList<>();
        if (null != collect && collect.size() > 0) {
            countList = collect.get(0);
        }

        /**
         * 聚合条件
         */
        if (null != aggConditionList) {
            for (int i = 0; i < aggConditionList.size(); i++) {
                AggCondition aggCondition = aggConditionList.get(i);
                String groupName = "count_" + i;
                tree = getTreeGroupName(groupName, tree);
                TermsAggregationBuilder termsSourceTypeSourcePlaceGroup = AggregationBuilders.terms("count_" + i)
                        .field(aggCondition.getAggFields()).size(aggCondition.getValue()).order(BucketOrder.count(false));
                if (i == 0) {
                    termsAggregationBuilder = termsSourceTypeSourcePlaceGroup;
                    aggFields.put(groupName, aggCondition.getAggFields());
                    /**
                     * 判断是否存在对应的计数过滤
                     */
                    //TODO
                } else {
                    Collection<AggregationBuilder> subAggregations = termsAggregationBuilder.getSubAggregations();
                    ArrayList<AggregationBuilder> aggregationBuilders = new ArrayList<>(subAggregations);
                    subAgg(aggregationBuilders, termsAggregationBuilder, termsSourceTypeSourcePlaceGroup);
                    aggFields.put(groupName, aggCondition.getAggFields());
                }
            }
        }

        lastAgg = getLastAgg(termsAggregationBuilder);

        map.put("lastAgg", lastAgg);

        /**
         * 判断条件
         */
        List<Map<JudgeCondition, Integer>> onlyList = new ArrayList<>();
        List<Map<JudgeCondition, Integer>> avgList = new ArrayList<>();
        List<Map<JudgeCondition, Integer>> maxList = new ArrayList<>();
        List<Map<JudgeCondition, Integer>> minList = new ArrayList<>();
        for (int i = 0; i < judgeConditionList.size(); i++) {
            Map<JudgeCondition, Integer> mapJudge = new HashMap<>();
            JudgeCondition judgeCondition = judgeConditionList.get(i);
            mapJudge.put(judgeCondition, i);
            if (judgeCondition.getType() == 1) {
                onlyList.add(mapJudge);
            } else if (judgeCondition.getType() == 2) {
                avgList.add(mapJudge);
            } else if (judgeCondition.getType() == 3) {
                maxList.add(mapJudge);
            } else if (judgeCondition.getType() == 4) {
                minList.add(mapJudge);
            }
        }

        Map<String, String> bucketsPathsMap = new HashMap<>(8);
        bucketsPathsMap.put("orderCount", "_count");
        /**
         * 计数条件
         */
        if (null != countList) {
            for (int i = 0; i < countList.size(); i++) {
                String name = JUDGE_PREFIX + "having_" + i;
                StringBuilder sb = new StringBuilder();
                JudgeCondition judgeCondition = countList.get(i);
                int value = judgeCondition.getValue();
                String fields = judgeCondition.getCensusFields();
                String operator = judgeCondition.getOperator();
                sb.append("params.orderCount ").append(StringEscapeUtils.unescapeHtml4(operator)).append(" ").append(value);
                Script script = new Script(sb.toString());
                BucketSelectorPipelineAggregationBuilder bs = PipelineAggregatorBuilders.bucketSelector(name, bucketsPathsMap, script);
                treeSb.append(name).append(",");
                if (lastAgg != null) {
                    lastAgg.subAggregation(bs);
                }
            }
        }

        if (null != onlyList) {
            for (Map<JudgeCondition, Integer> judgeConditionIntegerMap : onlyList) {
                for (Map.Entry<JudgeCondition, Integer> next : judgeConditionIntegerMap.entrySet()) {
                    JudgeCondition key = next.getKey();
                    Integer v = next.getValue();
                    String operator = key.getOperator();
                    int value = key.getValue();
                    String fields = key.getCensusFields();
                    String name = JUDGE_PREFIX + "distinct_" + v;
                    CardinalityAggregationBuilder field = AggregationBuilders.cardinality(name).field(fields);

                    //设置脚本
                    Map<String, String> bucketsPathsOnlyMap = new HashMap<>(8);
                    bucketsPathsOnlyMap.put("orderCount", name);
                    treeSb.append(",").append(name);
                    Script script1 = new Script("params.orderCount " + StringEscapeUtils.unescapeHtml4(operator) + " " + value);

                    BucketSelectorPipelineAggregationBuilder bs1 =
                            PipelineAggregatorBuilders.bucketSelector(JUDGE_PREFIX + "filter_" + v, bucketsPathsOnlyMap, script1);
                    if (lastAgg != null) {
                        lastAgg.subAggregation(field);
                        lastAgg.subAggregation(bs1);
                    }
                }
            }
        }


        /**
         * 处理平均值
         */
        if (null != avgList) {
            for (Map<JudgeCondition, Integer> judgeConditionIntegerMap : avgList) {
                for (Map.Entry<JudgeCondition, Integer> next : judgeConditionIntegerMap.entrySet()) {
                    JudgeCondition judgeCondition = next.getKey();
                    Integer v = next.getValue();
                    String operator = judgeCondition.getOperator();
                    int value = judgeCondition.getValue();
                    String fields = judgeCondition.getCensusFields();

                    String name = JUDGE_PREFIX + "avg_" + v;
                    AvgAggregationBuilder field = AggregationBuilders.avg(name).field(fields);

                    //设置脚本
                    Map<String, String> bucketsPathsOnlyMap = new HashMap<>(8);
                    bucketsPathsOnlyMap.put("orderCount", name);
                    Script script1 = new Script("params.orderCount " + StringEscapeUtils.unescapeHtml4(operator) + " " + value);
                    BucketSelectorPipelineAggregationBuilder bs1 =
                            PipelineAggregatorBuilders.bucketSelector(JUDGE_PREFIX + "filter_" + v, bucketsPathsOnlyMap, script1);

                    if (null != lastAgg) {
                        lastAgg.subAggregation(field);
                        lastAgg.subAggregation(bs1);
                        treeSb.append(",").append(name);
                    }
                }
            }
        }


        /**
         * 处理最大值
         */
        if (null != maxList) {
            for (Map<JudgeCondition, Integer> judgeConditionIntegerMap : maxList) {
                for (Map.Entry<JudgeCondition, Integer> next : judgeConditionIntegerMap.entrySet()) {
                    JudgeCondition judgeCondition = next.getKey();
                    Integer v = next.getValue();
                    String operator = judgeCondition.getOperator();
                    int value = judgeCondition.getValue();
                    String fields = judgeCondition.getCensusFields();

                    String name = JUDGE_PREFIX + "max_" + v;

                    MaxAggregationBuilder field = AggregationBuilders.max(name).field(fields);

                    //设置脚本
                    Map<String, String> bucketsPathsOnlyMap = new HashMap<>(8);
                    bucketsPathsOnlyMap.put("orderCount", name);
                    Script script1 = new Script("params.orderCount " + StringEscapeUtils.unescapeHtml4(operator) + " " + value);
                    BucketSelectorPipelineAggregationBuilder bs1 =
                            PipelineAggregatorBuilders.bucketSelector(JUDGE_PREFIX + "filter_" + v, bucketsPathsOnlyMap, script1);
                    if (null != lastAgg) {
                        lastAgg.subAggregation(field);
                        lastAgg.subAggregation(bs1);
                        treeSb.append(",").append(name);
                    }
                }
            }
        }


        /**
         * 处理最小值
         */
        if (null != minList) {
            for (Map<JudgeCondition, Integer> judgeConditionIntegerMap : minList) {
                for (Map.Entry<JudgeCondition, Integer> next : judgeConditionIntegerMap.entrySet()) {
                    JudgeCondition judgeCondition = next.getKey();
                    Integer v = next.getValue();
                    String operator = judgeCondition.getOperator();
                    int value = judgeCondition.getValue();
                    String fields = judgeCondition.getCensusFields();

                    String name = JUDGE_PREFIX + "min_" + v;
                    MinAggregationBuilder field = AggregationBuilders.min(name).field(fields);

                    //设置脚本
                    Map<String, String> bucketsPathsOnlyMap = new HashMap<>(8);
                    bucketsPathsOnlyMap.put("orderCount", name);
                    Script script1 = new Script("params.orderCount " + StringEscapeUtils.unescapeHtml4(operator) + " " + value);

                    BucketSelectorPipelineAggregationBuilder bs1 =
                            PipelineAggregatorBuilders.bucketSelector(JUDGE_PREFIX + "filter_" + v, bucketsPathsOnlyMap, script1);
                    if (null != lastAgg) {
                        treeSb.append(",").append(name);
                        lastAgg.subAggregation(field);
                        lastAgg.subAggregation(bs1);
                    }
                }
            }
        }
        map.put("lastAgg", lastAgg);
        map.put("termsAggregationBuilder", termsAggregationBuilder);
        return map;
    }

    /**
     * 递归处理子级嵌套聚合
     *
     * @param subAggregations
     * @param termsAggregationBuilder
     * @param termsSourceTypeSourcePlaceGroup
     */
    private static void subAgg(ArrayList<AggregationBuilder> subAggregations,
                               TermsAggregationBuilder termsAggregationBuilder, TermsAggregationBuilder termsSourceTypeSourcePlaceGroup) {
        if (subAggregations.size() == 0) {
            termsAggregationBuilder.subAggregation(termsSourceTypeSourcePlaceGroup);
        } else {
            /**
             * 说明还有嵌套子级聚合
             * 递归查询最后一个子级聚合
             */
            ArrayList<AggregationBuilder> aggregationBuilders = new ArrayList<>(subAggregations);;
            Collection<AggregationBuilder> subAggregations1 = aggregationBuilders.get(0).getSubAggregations();
            ArrayList<AggregationBuilder> aggregationBuilders1 = new ArrayList<>(subAggregations1);;
            TermsAggregationBuilder termsAggregationBuilder1 = (TermsAggregationBuilder) aggregationBuilders.get(0);
            subAgg(aggregationBuilders1, termsAggregationBuilder1, termsSourceTypeSourcePlaceGroup);
        }
    }

    /**
     * 递归获取到聚合的最后一个聚合
     *
     * @param termsAggregationBuilder
     * @return
     */
    private static TermsAggregationBuilder getLastAgg(TermsAggregationBuilder termsAggregationBuilder) {
        if (termsAggregationBuilder == null) {
            return null;
        } else {
            Collection<AggregationBuilder> subAggregations = termsAggregationBuilder.getSubAggregations();
            ArrayList<AggregationBuilder> aggregationBuilders = new ArrayList<>(subAggregations);
            if (aggregationBuilders.size() > 0) {
                TermsAggregationBuilder aggregationBuilder = (TermsAggregationBuilder) aggregationBuilders.get(0);
                return getLastAgg(aggregationBuilder);
            } else {
                return termsAggregationBuilder;
            }
        }

    }


    /**
     * 组装聚合嵌套查询的聚合名称
     *
     * @param groupName
     * @param tree
     * @return
     */
    private static EsConditionTree getTreeGroupName(String groupName, EsConditionTree tree) {
        if (null == tree) {
            tree = new EsConditionTree();
            tree.setGroupName(groupName);
        } else {
            if (StringUtils.isEmpty(tree.getGroupName()) && null == tree.getChildren()) {
                tree.setGroupName(groupName);
            } else {
                EsConditionTree children = tree.getChildren();
                EsConditionTree treeGroupName = getTreeGroupName(groupName, children);
                tree.setChildren(treeGroupName);
            }
        }
        return tree;
    }

    /**
     * 获取最后一级树节点
     *
     * @param tree
     * @return
     */
    private static EsConditionTree getLastTree(EsConditionTree tree) {
        if (null == tree.getChildren()) {
            return tree;
        } else {
            EsConditionTree children = tree.getChildren();
            return getLastTree(children);
        }
    }

    /**
     * 获取当前节点的groupName
     *
     * @return
     */
    public static String ergodicObtainTree(EsConditionTree tree) {
        String groupName = tree.getGroupName();
        return groupName;
    }

    /**
     * 组装es客户端--for 关联模型
     *
     * @param model
     * @param queryCondition
     * @return
     */
    public static EsDataSource logSourceCheck(TbEventModel model, ModelQueryChildCondition queryCondition) {
        /**
         * 外库数据源
         */
        if (StringUtils.isNotBlank(queryCondition.getDataSourceCode())) {
            //todo code
        }
        if (StringUtils.isNotBlank(queryCondition.getDataSourceId())) {
            TbEventModelMapper modelMapper = GetSpringBean.getBean(TbEventModelMapper.class);
            Map<String, String> indexMap = modelMapper.getIndexAndSource(TbEventModel.createQuery(queryCondition.getDataSourceId()));
            String indexName = DataUtils.getString(indexMap, "indexRule");
            if (com.crc.common.utils.StringUtils.isNotBlank(indexName)) {
                model.setEsIndexName(indexName);
                model.setEsIndexStr(indexName);
            }
            return EsUtils.logSourceCheck(indexMap);
        }

        String modelId = model.getModelId();
        String esIndexId = queryCondition.getEsIndexId();
        String esConfigId = queryCondition.getEsConfigId();
        String remark = "";
        EsDataSource esConfig = new EsDataSource();
        String index = "";
        SysDictDataMapper sysDictDataMapper = GetSpringBean.getBean(SysDictDataMapper.class);
        if (StringUtils.isNotEmpty(esIndexId)) {
            List<SysDictData> dataList = sysDictDataMapper.selectDictDataByType(ALARM_MODEL_ES_INDEX.getName());
            for (SysDictData data : dataList) {
                if (data.getDictValue().equals(esIndexId)) {
                    try {
                        String str = data.getDictLabel();
                        str = str.replace("(", " ").replace("（", " ").replace(")", "").replace("）", " ").replace("  ", " ");
                        String[] arr = str.split(" ");
                        index = arr[1];
                    } catch (Exception e) {
                        log.error(e.getMessage(), e);
                    }
                    if (StringUtils.isNotBlank(data.getRemark())) {
                        JSONObject jsonObject = JSONObject.parseObject(remark);
                        esConfig.setMode(DataUtils.getString(jsonObject, "proto"));
                        esConfig.setIndexRule(index);
                        esConfig.setUserName(DataUtils.getString(jsonObject, "username"));
                        esConfig.setPassword(DataUtils.getString(jsonObject, "password"));
                        String host = DataUtils.getString(jsonObject, "host");
                        esConfig.setPort(DataUtils.toInt(DataUtils.getString(jsonObject, "port")));
                        String ip = DataUtils.getString(jsonObject, "ip");
                        esConfig.setProxyHeader(DataUtils.getString(jsonObject, "proxyHeader"));
                        EsUtils.esHostAndIp(ip, host, esConfig);
                    } else {
                        ElasticsearchProperties esProperty = GetSpringBean.getBean(ElasticsearchProperties.class);
                        esConfig.setMode(esProperty.getMode());
                        esConfig.setIndexRule(index);
                        esConfig.setUserName(esProperty.getUserName());
                        esConfig.setPassword(esProperty.getPassword());
                        esConfig.setPort(esProperty.getPort());
                        esConfig.setProxyHeader(esProperty.getProxyHeader());
                        esConfig.setHost(esProperty.getHost());
                        esConfig.setSchema(esProperty.getSchema());
                    }
                }
            }
        }
        if (StringUtils.isEmpty(index) || StringUtils.isBlank(esConfig.getHost())) {
            log.error(modelId + "ES连接配置,请检查字典={},index={},config={},子集={}", ALARM_MODEL_ES_INDEX.getName(), queryCondition.getName(), esIndexId, esConfigId);
        }
        return esConfig;
    }

    /**
     * 组装es客户端
     *
     * @param model
     * @return
     */
    public static EsDataSource logSourceCheck(TbEventModel model) {
        //.getModelId(), model.getEsConfig(), model.getEsIndexId()

        /**
         * 外库数据源
         */
        if (com.crc.common.utils.StringUtils.isNotBlank(model.getDataSourceId())) {
            TbEventModelMapper modelMapper = GetSpringBean.getBean(TbEventModelMapper.class);
            Map<String, String> indexMap = modelMapper.getIndexAndSource(TbEventModel.createQuery(model.getDataSourceId()));
            String indexName = DataUtils.getString(indexMap, "indexRule");
            if (com.crc.common.utils.StringUtils.isNotBlank(indexName)) {
                model.setEsIndexName(indexName);
                model.setEsIndexStr(indexName);
            }
            return EsUtils.logSourceCheck(indexMap);
        }

        String modelId = model.getModelId();
        String esIndexId = model.getEsIndexId();
        String esConfigId = model.getEsConfig();
        String remark = "";
        EsDataSource esConfig = new EsDataSource();
        String index = "";
        SysDictDataMapper sysDictDataMapper = GetSpringBean.getBean(SysDictDataMapper.class);
        if (StringUtils.isNotEmpty(esIndexId)) {
            List<SysDictData> dataList = sysDictDataMapper.selectDictDataByType(ALARM_MODEL_ES_INDEX.getName());
            for (SysDictData data : dataList) {
                if (data.getDictValue().equals(esIndexId)) {
                    try {
                        String str = data.getDictLabel();
                        str = str.replace("(", " ").replace("（", " ").replace(")", "").replace("）", " ").replace("  ", " ");
                        String[] arr = str.split(" ");
                        index = arr[1];
                    } catch (Exception e) {
                        log.error(e.getMessage(), e);
                    }
                    if (StringUtils.isNotBlank(data.getRemark())) {
                        JSONObject jsonObject = JSONObject.parseObject(remark);
                        esConfig.setMode(DataUtils.getString(jsonObject, "proto"));
                        esConfig.setIndexRule(index);
                        esConfig.setUserName(DataUtils.getString(jsonObject, "username"));
                        esConfig.setPassword(DataUtils.getString(jsonObject, "password"));
                        String host = DataUtils.getString(jsonObject, "host");
                        esConfig.setPort(DataUtils.toInt(DataUtils.getString(jsonObject, "port")));
                        String ip = DataUtils.getString(jsonObject, "ip");
                        esConfig.setProxyHeader(DataUtils.getString(jsonObject, "proxyHeader"));
                        EsUtils.esHostAndIp(ip, host, esConfig);
                    } else {
                        ElasticsearchProperties esProperty = GetSpringBean.getBean(ElasticsearchProperties.class);
                        esConfig.setMode(esProperty.getMode());
                        esConfig.setIndexRule(index);
                        esConfig.setUserName(esProperty.getUserName());
                        esConfig.setPassword(esProperty.getPassword());
                        esConfig.setPort(esProperty.getPort());
                        esConfig.setProxyHeader(esProperty.getProxyHeader());
                        esConfig.setHost(esProperty.getHost());
                        esConfig.setSchema(esProperty.getSchema());
                    }
                }
            }
        }
        if (StringUtils.isEmpty(index) || StringUtils.isBlank(esConfig.getHost())) {
            log.error(modelId + "ES连接配置,请检查字典={},index={},config={}", ALARM_MODEL_ES_INDEX.getName(), esIndexId, esConfigId);
        }
        return esConfig;
    }
}
