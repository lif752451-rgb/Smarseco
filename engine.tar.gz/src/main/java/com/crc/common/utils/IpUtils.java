package com.crc.common.utils;

import com.googlecode.ipv6.IPv6Network;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;

import javax.servlet.http.HttpServletRequest;
import java.math.BigInteger;
import java.net.InetAddress;
import java.net.UnknownHostException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * 获取IP方法
 *
 * @author wst
 */
@Slf4j
public class IpUtils {
    private static final String IP_REGX = "\\d{1,3}.\\d{1,3}.\\d{1,3}.\\d{1,3}";
    public static final BigInteger a1 = getIp2long("10.0.0.1");
    public static final BigInteger a2 = getIp2long("10.255.255.254");
    public static final BigInteger b1 = getIp2long("172.16.0.1");
    public static final BigInteger b2 = getIp2long("172.31.255.254");
    public static final BigInteger c1 = getIp2long("192.168.0.1");
    public static final BigInteger c2 = getIp2long("192.168.255.254");
    public static boolean isInnerIP(String ip) {
        if (IpUtils.isIpv6(ip)) {
            return true;
        }
//        long n = getIp2long(ip);
//        if (n >= a1 && n <= a2) {
//            return true;
//        }
//        if (n >= b1 && n <= b2) {
//            return true;
//        }
//        return n >= c1 && n <= c2;
        BigInteger n = getIp2long(ip);
        if (n.compareTo(a1) >=0  && n.compareTo(a2) <= 0) {
            //log.info("{},a:{},{}",n.longValue(),a1.longValue(),a2.longValue());
            return true;
        }
        if (n.compareTo(b1) >=0  && n.compareTo(b2) <= 0) {
            //log.info("{},b:{},{}",n.longValue(),b1.longValue(),b2.longValue());
            return true;
        }
        //log.info("{},c:{},{}",n.longValue(),c1.longValue(),c2.longValue());
        return n.compareTo(c1) >= 0 && n.compareTo(c2) <= 0;
    }
    public static String[] getIpSegment(String segment) {
        if (StringUtils.isBlank(segment)) {
            return null;
        }
        segment = segment.replace(" ", "").replace(",", "\n").replace("\t", "").replaceAll(" ", "\n");
        return segment.split("\n");
    }
    /**
     * 根据网段计算起始IP 网段格式:x.x.x.x/x
     * 一个网段0一般为网络地址,255一般为广播地址.
     * 起始IP计算:网段与掩码相与之后加一的IP地址
     *
     * @param segment 网段
     * @return 起始IP
     */
    public static String getStartIp(String segment) {
        StringBuilder startIp = new StringBuilder();
        if (segment == null) {
            return null;
        }
        if (isIp(segment)) {
            return segment;
        }
        String[] arr = segment.split("/");
        String ip = arr[0];
        if (arr.length < 2) {
            //log.error("ERROR getStartIp:" + segment);
            return null;
        }
        String maskIndex = arr[1];
        String mask = getNetMask(maskIndex);
        if (4 != ip.split("\\.").length || mask == null) {
            return null;
        }
        int[] ipArray = new int[4];
        int[] netMaskArray = new int[4];
        for (int i = 0; i < 4; i++) {
            try {
                ipArray[i] = DataUtils.toNum(ip.split("\\.")[i]);
                netMaskArray[i] = DataUtils.toNum(mask.split("\\.")[i]);
                if (ipArray[i] > 255 || ipArray[i] < 0 || netMaskArray[i] > 255 || netMaskArray[i] < 0) {
                    return null;
                }
                ipArray[i] = ipArray[i] & netMaskArray[i];
                if (i == 3) {
                    startIp.append(ipArray[i] + 1);
                } else {
                    startIp.append(ipArray[i]).append(".");
                }
            } catch (Exception e) {
                log.error("有错误网段数据" + e.getMessage(), e);
            }
        }
        return startIp.toString();
    }

    public static String getEndIp(String segment) {
        StringBuilder endIp = new StringBuilder();
        String startIp = getStartIp(segment);
        if (segment == null || startIp == null) {
            return null;
        }
        if (IpUtils.isIp(segment)) {
            return segment;
        }
        if (4 != startIp.split("\\.").length) {
            return null;
        }
        String[] arr = segment.split("/");
        String maskIndex = arr[1];
        //实际需要的IP个数
        int hostNumber;
        int[] startIpArray = new int[4];
        try {
            hostNumber = 1 << 32 - (DataUtils.toNum(maskIndex));
            for (int i = 0; i < 4; i++) {
                startIpArray[i] = DataUtils.toNum(startIp.split("\\.")[i]);
                if (i == 3) {
                    startIpArray[i] = startIpArray[i] - 1;
                    break;
                }
            }
            startIpArray[3] = startIpArray[3] + (hostNumber - 1);
        } catch (Exception e) {
            log.error(e.getMessage(), e);
        }

        if (startIpArray[3] > 255) {
            int k = startIpArray[3] / 256;
            startIpArray[3] = startIpArray[3] % 256;
            startIpArray[2] = startIpArray[2] + k;
        }
        if (startIpArray[2] > 255) {
            int j = startIpArray[2] / 256;
            startIpArray[2] = startIpArray[2] % 256;
            startIpArray[1] = startIpArray[1] + j;
            if (startIpArray[1] > 255) {
                int k = startIpArray[1] / 256;
                startIpArray[1] = startIpArray[1] % 256;
                startIpArray[0] = startIpArray[0] + k;
            }
        }
        for (int i = 0; i < 4; i++) {
            if (i == 3) {
                startIpArray[i] = startIpArray[i] - 1;
            }
            if ("".contentEquals(endIp) || endIp.length() == 0) {
                endIp.append(startIpArray[i]);
            } else {
                endIp.append(".").append(startIpArray[i]);
            }
        }
        return endIp.toString();
    }

    /**
     * 根据掩码位数计算掩码
     *
     * @param maskIndex 掩码位
     * @return 子网掩码
     */
    public static String getNetMask(String maskIndex) {
        StringBuilder mask = new StringBuilder();
        int inetMask = 0;
        try {
            inetMask = Integer.parseInt(maskIndex);
        } catch (Exception e) {
            System.out.println(e.getMessage());
            return null;
        }
        if (inetMask > 32) {
            return null;
        }
        // 子网掩码为1占了几个字节
        int num1 = inetMask / 8;
        // 子网掩码的补位位数
        int num2 = inetMask % 8;
        int[] array = new int[4];
        for (int i = 0; i < num1; i++) {
            array[i] = 255;
        }
        for (int i = num1; i < 4; i++) {
            array[i] = 0;
        }
        for (int i = 0; i < num2; num2--) {
            array[num1] += 1 << 8 - num2;
        }
        for (int i = 0; i < 4; i++) {
            if (i == 3) {
                mask.append(array[i]);
            } else {
                mask.append(array[i]).append(".");
            }
        }
        return mask.toString();
    }

    public static String getIpAddr(HttpServletRequest request) {
        if (request == null) {
            return "unknown";
        }
        String ip = request.getHeader("x-forwarded-for");
        if (ip == null || ip.length() == 0 || "unknown".equalsIgnoreCase(ip)) {
            ip = request.getHeader("Proxy-Client-IP");
        }
        if (ip == null || ip.length() == 0 || "unknown".equalsIgnoreCase(ip)) {
            ip = request.getHeader("X-Forwarded-For");
        }
        if (ip == null || ip.length() == 0 || "unknown".equalsIgnoreCase(ip)) {
            ip = request.getHeader("WL-Proxy-Client-IP");
        }
        if (ip == null || ip.length() == 0 || "unknown".equalsIgnoreCase(ip)) {
            ip = request.getHeader("X-Real-IP");
        }

        if (ip == null || ip.length() == 0 || "unknown".equalsIgnoreCase(ip)) {
            ip = request.getRemoteAddr();
        }

        return "0:0:0:0:0:0:0:1".equals(ip) ? "127.0.0.1" : ip;
    }


    /*
      判断互联网IP
     */
    public static boolean isInternetIP(String ip) {
        return isIp(ip) && !isInnerIP(ip) && !"127.0.0.1".equals(ip);
    }

    public static boolean internalIp(String ip) {
        byte[] addr = textToNumericFormatV4(ip);
        return internalIp(addr) || "127.0.0.1".equals(ip);
    }

    private static boolean internalIp(byte[] addr) {
        if (addr == null || addr.length < 2) {
            return true;
        }
        final byte b0 = addr[0];
        final byte b1 = addr[1];
        // 10.x.x.x/8
        final byte SECTION_1 = 0x0A;
        // 172.16.x.x/12
        final byte SECTION_2 = (byte) 0xAC;
        final byte SECTION_3 = (byte) 0x10;
        final byte SECTION_4 = (byte) 0x1F;
        // 192.168.x.x/16
        final byte SECTION_5 = (byte) 0xC0;
        final byte SECTION_6 = (byte) 0xA8;
        switch (b0) {
            case SECTION_1:
                return true;
            case SECTION_2:
                if (b1 >= SECTION_3 && b1 <= SECTION_4) {
                    return true;
                }
            case SECTION_5:
                if (b1 == SECTION_6) {
                    return true;
                }
            default:
                return false;
        }
    }

    /**
     * 将IPv4地址转换成字节
     *
     * @param text IPv4地址
     * @return byte 字节
     */
    public static byte[] textToNumericFormatV4(String text) {
        if (text.length() == 0) {
            return null;
        }

        byte[] bytes = new byte[4];
        String[] elements = text.split("\\.", -1);
        try {
            long l;
            int i;
            switch (elements.length) {
                case 1:
                    l = Long.parseLong(elements[0]);
                    if ((l < 0L) || (l > 4294967295L))
                        return null;
                    bytes[0] = (byte) (int) (l >> 24 & 0xFF);
                    bytes[1] = (byte) (int) ((l & 0xFFFFFF) >> 16 & 0xFF);
                    bytes[2] = (byte) (int) ((l & 0xFFFF) >> 8 & 0xFF);
                    bytes[3] = (byte) (int) (l & 0xFF);
                    break;
                case 2:
                    l = Integer.parseInt(elements[0]);
                    if ((l < 0L) || (l > 255L))
                        return null;
                    bytes[0] = (byte) (int) (l & 0xFF);
                    l = Integer.parseInt(elements[1]);
                    if ((l < 0L) || (l > 16777215L))
                        return null;
                    bytes[1] = (byte) (int) (l >> 16 & 0xFF);
                    bytes[2] = (byte) (int) ((l & 0xFFFF) >> 8 & 0xFF);
                    bytes[3] = (byte) (int) (l & 0xFF);
                    break;
                case 3:
                    for (i = 0; i < 2; ++i) {
                        l = Integer.parseInt(elements[i]);
                        if ((l < 0L) || (l > 255L))
                            return null;
                        bytes[i] = (byte) (int) (l & 0xFF);
                    }
                    l = Integer.parseInt(elements[2]);
                    if ((l < 0L) || (l > 65535L))
                        return null;
                    bytes[2] = (byte) (int) (l >> 8 & 0xFF);
                    bytes[3] = (byte) (int) (l & 0xFF);
                    break;
                case 4:
                    for (i = 0; i < 4; ++i) {
                        l = Integer.parseInt(elements[i]);
                        if ((l < 0L) || (l > 255L))
                            return null;
                        bytes[i] = (byte) (int) (l & 0xFF);
                    }
                    break;
                default:
                    return null;
            }
        } catch (NumberFormatException e) {
            return null;
        }
        return bytes;
    }

    public static String getHostIp() {
        try {
            return InetAddress.getLocalHost().getHostAddress();
        } catch (UnknownHostException e) {
            log.info(e.getMessage(), e);
        }
        return "127.0.0.1";
    }

    public static String getHostName() {
        try {
            return InetAddress.getLocalHost().getHostName();
        } catch (Exception e) {
            log.error(e.getMessage(), e);
        }
        return "未知";
    }

    public static boolean isMatchIp(String ip) {
        Pattern pattern = Pattern.compile(IP_REGX);
        Matcher matcher = pattern.matcher(ip);
        return matcher.matches();
    }

    public static boolean isMatchDomain(String domainName) {
        Pattern pattern = Pattern.compile(IP_REGX);
        Matcher matcher = pattern.matcher(domainName);
        return matcher.matches();
    }

    public static String getRiskIp(String srcIp, String destIp, String markIp) {
        String ips = getRiskIpX(srcIp, destIp, markIp);
        String[] flags = {"、", ",", ";", "；", "，", "/", "等", " ", "\\"};
        for (String flag : flags) {
            if (!ips.contains(flag))
                continue;
            if (flag.equalsIgnoreCase("\\"))
                flag = "\\\\";
            for (String ip : ips.split(flag)) {
                if (IpUtils.isInnerIP(ip))
                    return ip.trim();
            }
        }
        if (!isIp(ips)) {
            if (isIp(srcIp))
                return srcIp;
            if (isIp(destIp))
                return destIp;
        }

        return ips;
    }


    private static String getRiskIpX(String srcIp, String destIp, String markIp) {
        if (isInnerIP(srcIp) && !"0.0.0.0".equalsIgnoreCase(srcIp)) {
            return srcIp;
        } else if (!isInnerIP(srcIp)) {
            return destIp;
        } else if (!isInnerIP(destIp)) {
            return srcIp;
        } else if (isInnerIP(srcIp) && isInnerIP(destIp)) {
            return srcIp;
        }
        if ("0.0.0.0".equalsIgnoreCase(destIp)) {
            return srcIp;
        }
        return markIp;
    }

    public static boolean isIp(String addr) {
        if (StringUtils.isBlank(addr)) {
            return false;
        }
        if (isIpv4(addr)) {
            return true;
        }
        return isIpv6(addr);
    }

    private static final String regEx = "((2[0-4]\\d|25[0-5]|[01]?\\d\\d?)\\.){3}(2[0-4]\\d|25[0-5]|[01]?\\d\\d?)";

    public static List<String> getIps(String ipString) {
        if (StringUtils.isBlank(ipString)) {
            return new ArrayList<>();
        }
        List<String> ips = new ArrayList<>();
        try {
            HashMap<String, String> ipMap = new HashMap<>();
            if (StringUtils.isBlank(ipString))
                return new ArrayList<>();
            Pattern p = Pattern.compile(regEx);
            Matcher m = p.matcher(ipString);
            while (m.find()) {
                String result = m.group();
                if (IpUtils.isIp(result.trim()))
                    ipMap.put(result.trim(), "1");
            }
            String[] ipsNews0 = DataUtils.getSplit(ipString, " ");
            for (String ip : ipsNews0) {
                if (IpUtils.isIp(ip)) {
                    ipMap.put(ip.trim(), "1");
                }
            }
            String[] ipsNews1 = DataUtils.getSplit(ipString, ",");
            for (String ip : ipsNews1) {
                if (IpUtils.isIp(ip)) {
                    ipMap.put(ip.trim(), "1");
                }
            }
            String[] ipsNews2 = DataUtils.getSplit(ipString, "，");
            for (String ip : ipsNews2) {
                if (IpUtils.isIp(ip)) {
                    ipMap.put(ip.trim(), "1");
                }
            }

            ipMap.forEach((k, v) -> {
                ips.add(k);
            });
        } catch (Exception e) {
            log.error(e.getMessage(), e);
        }
        return ips;
    }

    public static List<String> getIpsX(List<String> ipList) {
        if (ipList == null) {
            return new ArrayList<>();
        }
        List<String> ips = new ArrayList<>();
        HashMap<String, String> ipMap = new HashMap<>();
        for (String ip : ipList) {
            getIpsX(ip).forEach(v -> {
                ipMap.put(v, v);
            });
            if ("0.0.0.0".equalsIgnoreCase(ip)) {
                ipMap.put(ip, ip);
            }
        }
        ipMap.forEach((k, v) -> {
            ips.add(k);
        });
        return ips;
    }


    public static List<String> getIpsX(String ipString) {
        List<String> ips = getIps(ipString);
        if ("0.0.0.0".equalsIgnoreCase(ipString)) {
            ips.add(ipString);
        }
        return ips;
    }

    /**
     * 多个IP去重
     *
     * @param ip
     * @return
     */
    public static String distinctIp(String ip) {
        List<String> ips = getIps(ip);
        if (ips.size() > 1) {
            HashMap<String, String> tmp = new HashMap<>();
            for (String tip : ips) {
                if (tmp.containsKey(tip)) {
                    continue;
                }
                tmp.put(tip, tip);
            }
            String retIp = "";
            for (String key : tmp.keySet()) {
                if (StringUtils.isBlank(retIp)) {
                    retIp = key;
                } else {
                    retIp = retIp + "," + key;
                }
            }
            return retIp;
        }


        return ip;
    }

    public static BigInteger getIp2long(String ipaddress) {
        if (!isIp(ipaddress)) {
            return BigInteger.ZERO;
        }
        try {
            return IpConvert.StringToBigInt(ipaddress);
        } catch (Exception e) {

        }
        return BigInteger.ZERO;
    }

    /**
     * Is ipv 4 boolean.
     */
    public static boolean isIpv4(String ipv4) {
        if (StringUtils.isBlank(ipv4)) {
            return false;
        }
        if (!ipv4.contains(".") && !ipv4.contains(":")) {
            return false;
        }
        //如果是IPV4
        if (ipv4.contains(".")) {
            if (ipv4.endsWith(".")) {
                return false;
            }
            String[] arr = ipv4.split("\\.");
            if (arr.length != 4) {
                return false;
            }

            for (int i = 0; i < 4; i++) {
                if (arr[i].length() == 0 || arr[i].length() > 3) {
                    return false;
                }
                for (int j = 0; j < arr[i].length(); j++) {
                    if (arr[i].charAt(j) >= '0' && arr[i].charAt(j) <= '9') {
                        continue;
                    }
                    return false;
                }
                if (Integer.parseInt(arr[i]) > 255 || (arr[i].length() >= 2 && String.valueOf(arr[i]).startsWith("0"))) {
                    return false;
                }
            }
            return true;
        }
        return false;
    }

    /**
     * Is ipv 6 boolean.
     */
    public static boolean isIpv6(String ipv6) {
        if (StringUtils.isBlank(ipv6)) {
            return false;
        }
        // 8*4 位数字，加上七个: ipv6地址长度不可能超过39位
        if (ipv6.length() > 39) {
            return false;
        }
        if (ipv6.endsWith(":") && !ipv6.endsWith("::")) {
            return false;
        }
        //如果包含多个“::”，一个IPv6地址中只能出现一个“::”
        if (ipv6.contains("::") && ipv6.indexOf("::", ipv6.indexOf("::") + 2) != -1) {
            return false;
        }

        //ipv6“::”
        if (ipv6.contains("::")) {
            String[] arr = ipv6.split(":");
            if (arr.length > 7 || arr.length < 1) {//"1::"是最短的字符串
                return false;
            }
            for (String s : arr) {
                if (s.equals("")) {
                    continue;
                }
                if (s.length() > 4) {
                    return false;
                }
                for (int j = 0; j < s.length(); j++) {
                    if ((s.charAt(j) >= '0' && s.charAt(j) <= '9') || (s.charAt(j) >= 'A' && s.charAt(j) <= 'F')
                            || (s.charAt(j) >= 'a' && s.charAt(j) <= 'f')) {
                        continue;
                    }
                    return false;
                }
            }
            return true;
        } else {//如果不含有“::”
            String[] arr = ipv6.split(":");
            if (arr.length != 8) {
                return false;
            }
            for (String s : arr) {
                if (s.length() > 4) {
                    return false;
                }
                for (int j = 0; j < s.length(); j++) {
                    if ((s.charAt(j) >= '0' && s.charAt(j) <= '9') || (s.charAt(j) >= 'A' && s.charAt(j) <= 'F')
                            || (s.charAt(j) >= 'a' && s.charAt(j) <= 'f')) {
                        continue;
                    }
                    return false;
                }
            }
            return true;
        }
    }

    /**
     * 获取 IP段的开始 IP 和结束 IP
     * @param cidr
     * @return
     */
    public static BigInteger[] getIpStartAndEnd(String cidr) {
        try {
            if (org.apache.commons.lang3.StringUtils.isBlank(cidr)) {
                return null;
            }
            cidr = cidr.trim();
            BigInteger startIp2long = null;
            BigInteger endIp2long = null;
            if (cidr.contains("-") && cidr.contains("/")) {
                String[] ips = cidr.split("-");
                if (ips.length <= 1) {
                    return null;
                }
                if (ips[0].contains(":")) {
                    if (IpUtils.isIP(ips[0].trim())) {
                        startIp2long = IpUtils.getIp2long(ips[0].trim());
                    } else {
                        try {
                            IPv6Network network = IPv6Network.fromString(ips[0]);
                            startIp2long = IpUtils.getIp2long(network.getFirst().toLongString());
                        } catch (Exception e) {
                            log.error("非法 IPV6掩码{}", ips[0]);
                        }
                    }

                } else {
                    startIp2long = IpUtils.getIp2long(IpUtils.getStartIp(ips[0].trim()));
                }
                if (ips[1].contains(":")) {
                    if (IpUtils.isIP(ips[1].trim())) {
                        endIp2long = IpUtils.getIp2long(ips[1].trim());
                    } else {
                        try {
                            IPv6Network network = IPv6Network.fromString(ips[1]);
                            endIp2long = IpUtils.getIp2long(network.getLast().toLongString());
                        } catch (Exception e) {
                            log.error("非法 IPV6掩码{}", ips[1]);
                        }
                    }
                } else {
                    endIp2long = IpUtils.getIp2long(IpUtils.getEndIp(ips[1].trim()));
                }
            } else if (cidr.contains("-")) {
                String[] ips = cidr.split("-");
                if (ips.length <= 1) {
                    return null;
                }
                if (ips[0].contains(":")) {
                    if (IpUtils.isIP(ips[0].trim())) {
                        startIp2long = IpUtils.getIp2long(ips[0].trim());
                    } else {
                        try {
                            IPv6Network network = IPv6Network.fromString(ips[0]);
                            startIp2long = IpUtils.getIp2long(network.getFirst().toLongString());
                        } catch (Exception e) {
                            log.error("非法 IPV6掩码{}", ips[0]);
                        }
                    }
                } else if (ips[0].contains("/")) {
                    startIp2long = IpUtils.getIp2long(IpUtils.getStartIp(ips[0].trim()));
                } else if (ips[0].contains(".")) {
                    startIp2long = IpUtils.getIp2long(ips[0].trim());
                } else {
                    startIp2long = IpUtils.getIp2long(IpUtils.getStartIp(ips[0].trim()));
                }
                if (ips[1].contains(":")) {
                    if (IpUtils.isIP(ips[1].trim())) {
                        endIp2long = IpUtils.getIp2long(ips[1].trim());
                    } else {
                        try {
                            IPv6Network network = IPv6Network.fromString(ips[1]);
                            endIp2long = IpUtils.getIp2long(network.getLast().toLongString());
                        } catch (Exception e) {
                            log.error("非法 IPV6掩码{}", ips[1]);
                        }
                    }
                } else if (ips[1].contains("/")) {
                    endIp2long = IpUtils.getIp2long(IpUtils.getStartIp(ips[1].trim()));
                } else if (ips[1].contains(".")) {
                    endIp2long = IpUtils.getIp2long(ips[1].trim());
                    //endIp2long = IpUtils.getIp2long(ips[1].trim());
                } else {
                    endIp2long = IpUtils.getIp2long(IpUtils.getEndIp(ips[1].trim()));
                }
            } else if (cidr.contains("/")) {
                if (cidr.contains(":")) {
                    try {
                        IPv6Network network = IPv6Network.fromString(cidr);
                        startIp2long = IpUtils.getIp2long(network.getFirst().toLongString());
                        endIp2long = IpUtils.getIp2long(network.getLast().toLongString());
                    } catch (Exception e) {
                        log.error("非法 IPV6掩码{}", cidr);
                    }
                } else {
                    startIp2long = IpUtils.getIp2long(IpUtils.getStartIp(cidr.trim()));
                    endIp2long = IpUtils.getIp2long(IpUtils.getEndIp(cidr.trim()));
                }
            } else {
                startIp2long = IpUtils.getIp2long(cidr.trim());
                endIp2long = IpUtils.getIp2long(cidr.trim());
            }

            BigInteger[] rets = new BigInteger[2];
            rets[0] = startIp2long;
            rets[1] = endIp2long;
            return rets;
        } catch (Exception e) {
            log.error(e.getMessage(),e);
        }
        return null;
    }

    private static boolean isIP(String trim) {
        return isIp(trim);
    }
}
