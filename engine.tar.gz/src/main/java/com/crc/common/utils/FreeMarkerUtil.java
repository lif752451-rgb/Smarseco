package com.crc.common.utils;

import com.crc.secface.config.GetSpringBean;
import com.crc.secface.config.ServerPortConfig;
import com.crc.secface.entity.MessageTemplate;
import com.crc.secface.entity.TbRiskStatic;
import freemarker.template.Configuration;
import freemarker.template.Template;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.xml.sax.SAXException;

import javax.xml.parsers.ParserConfigurationException;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.util.*;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * @author simba@onlying.cn
 * @date 2020/10/15 10:16
 */
public class FreeMarkerUtil {

    private static final Logger logger = LoggerFactory.getLogger(FreeMarkerUtil.class);


    public static void convertToHtmlImage(Long deptId, Map<String, Object> model, Configuration configuration,
                                          MessageTemplate messageTemplate, Map<String, List<TbRiskStatic>> statMap, String reportType) {
        try {
            List<List<TbRiskStatic>> statList = getGroupStatList(messageTemplate, statMap);
            Map<String, Object> dataMap = new HashMap<>();
            dataMap.put("map", model);
            for (int i = 0; i < statList.size(); i++) {
                List<TbRiskStatic> newList = statList.get(i);
                if (newList.size() <= 5) {
                    for (int j = newList.size(); j <= 5; j++) {
                        TbRiskStatic stat1 = new TbRiskStatic();
                        stat1.setValue("");
                        stat1.setStaticName("");
                        newList.add(stat1);
                    }
                }
                dataMap.put("list" + (i + 1), newList);
            }
            ServerPortConfig sc = GetSpringBean.getBean(ServerPortConfig.class);
            dataMap.put("timeStr", DateUtils.formatDateTime(new Date(), "yyyy.MM.dd"));
            String reportImg = reportType + "/" + deptId + ".png";
            dataMap.put("reportImg", reportImg);
            //logger.info("获取模板的数据:[{}]", JSONObject.toJSONString(dataMap));
            Template t1 = configuration.getTemplate("test2.ftl");
            FileWriter out = null;
            if (System.getProperty("os.name").toLowerCase().contains("windows")) {
                dataMap.put("basePath", "http://localhost:" + sc.getPort());
                out = new FileWriter(new File("D:\\html\\test.html"));
            } else {
                dataMap.put("basePath", "http://localhost:" + sc.getPort());
                out = new FileWriter(new File("/app/secface/test.html"));
            }
            t1.process(dataMap, out);
        } catch (Exception e) {
            logger.error(e.getMessage(), e);
        }
        // return "";
    }

    public static List<List<TbRiskStatic>> getGroupStatList(MessageTemplate messageTemplate, Map<String, List<TbRiskStatic>> statMap) {
        List<List<TbRiskStatic>> statList = new ArrayList<>();
        StringTokenizer stoke = new StringTokenizer(messageTemplate.getContent(), "\\n");
        String regex = "\\[(.*?)]";
        Pattern pattern = Pattern.compile(regex);
        while (stoke.hasMoreElements()) {
            String content = stoke.nextToken();
            Matcher matcher = pattern.matcher(content);
            boolean isMatch = false;
            while (matcher.find()) {
                String group = matcher.group(0);
                group = group.replaceAll("\\[|\\]", "");
                statList.add(statMap.get(group));
            }
        }
        return statList;
    }

    public static void exePhantomjsToImg() {
        try {

            if (System.getProperty("os.name").toLowerCase().contains("windows")) {
                String url = "file:///D:/html/test.html";
                String procUrl = "D:/software/phantomjs-2.1.1-windows/bin/phantomjs.exe D:/html/demo.js " + url + " shot";
                //CmdUtils.winCmd(procUrl);
            } else {
                // String url="file:///:/app/secface/test.html";
                // String url="/app/secface/test.html";
                String url = "/app/secface/test.html";
                String procUrl = "/usr/local/phantomjs/bin/phantomjs /app/secface/demo2.js " + url + " shot" ;
                //CmdUtils.linuxCmd(procUrl);
            }
        } catch (Exception e) {
            logger.error(e.getMessage(), e);
        }
    }


    public static void convertXhtmlToImage(String html, String inputFilename, String outputFilename, int widthImage, int heightImage) throws IOException, ParserConfigurationException, SAXException {
        //将html转成文件
        FileWriter writer = new FileWriter(inputFilename);
        writer.write(html);
        writer.flush();

        //将xhtml文件转成图片

//        final File f = new File(inputFilename);
//        Java2DRenderer renderer = new Java2DRenderer(f,600,4000);
//        ITextRenderer renderer2 = new ITextRenderer();
//        renderer2.
//        //renderer2.setDocumentFromString(html,baseUrl)
//        renderer.getSharedContext().setBaseURL("file:///d:/html2");
//        renderer.setBufferedImageType(BufferedImage.TYPE_INT_RGB);
//        final BufferedImage img = renderer.getImage();
//        final FSImageWriter imageWriter = new FSImageWriter();
//        imageWriter.setWriteCompressionQuality(0.9f);
        //  imageWriter.write(img, outputFilename);
        // final File fout = new File(outputFilename);
        // return fout;
        //imageWriter.
        writer.close();
    }
}
