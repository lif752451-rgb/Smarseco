package com.crc.common.utils;

import com.crc.common.constants.TimePeriodEnum;
import com.crc.secface.entity.IpPluggingScene;
import com.crc.secface.entity.TbEventModel;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.quartz.*;
import org.quartz.impl.triggers.CronTriggerImpl;
import org.springframework.scheduling.support.CronSequenceGenerator;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.function.BiConsumer;
import java.util.function.Consumer;

/*****************************
 * Class Name： CronUtil
 * Description： <获取Cron表达式最近几次执行的时间>
 * @Author: Seminar
 * @create: 2022/11/02
 * @since: 1.0.0
 ***************************/

@Slf4j
public class CronUtils {

    /**
     * 列出近cronCount次的执行时间
     *
     * @param cronExpression cron表达式
     * @param cronCount      cron时间次数
     * @param maxCronCount   最大cron时间次数
     * @return
     */
    public static List<String> listCronRunTime(String cronExpression, Integer cronCount, Integer maxCronCount) {
        if (StringUtils.isBlank(cronExpression)) {
            throw new RuntimeException("Cron 表达式不能为空!");
        }
        if (!CronSequenceGenerator.isValidExpression(cronExpression)) {
            throw new RuntimeException("Cron格式不正确,Cron: " + cronExpression);
        }
        if (cronCount < 1) {
            cronCount = 1;
        }
        if (maxCronCount < 1) {
            maxCronCount = 100;
        }
        if (cronCount > maxCronCount) {
            cronCount = maxCronCount;
        }
        CronSequenceGenerator cronSequenceGenerator = new CronSequenceGenerator(cronExpression);
        List<String> cronTimeList = new ArrayList<>();
        Date nextTimePoint = new Date();
        SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
        for (int i = 0; i < cronCount; i++) {
            nextTimePoint = cronSequenceGenerator.next(nextTimePoint);
            cronTimeList.add(sdf.format(nextTimePoint));
        }
        return cronTimeList;
    }

    //上次执行时间
    public static String[] getLastTriggerTime(String cron) {
        if (!CronExpression.isValidExpression(cron)) {
            return null;
        }
        CronTrigger trigger = TriggerBuilder.newTrigger().withIdentity("Caclulate Date").withSchedule(CronScheduleBuilder.cronSchedule(cron)).build();
        Date time0 = trigger.getStartTime();
        //log.info("time0={}", DateUtils.getDateTimeString1(time0));
        Date time1 = trigger.getFireTimeAfter(time0);
        //log.info("time1={}", DateUtils.getDateTimeString1(time1));
        Date time2 = trigger.getFireTimeAfter(time1);
        //log.info("time2={}", DateUtils.getDateTimeString1(time2));
        long diff = time2.getTime() - time1.getTime();
        long l = time0.getTime() - diff;
        Date date = new Date(l);
        String[] ds = new String[2];
        ds[0] = DateUtils.getDateTimeString1(date);

        l = date.getTime() - diff;
        date = new Date(l);
        ds[1] = DateUtils.getDateTimeString1(date);
        return ds;
    }

    /**
     * 列出近numTimes次的执行时间
     *
     * @param cronExpression cron表达式
     * @param numTimes       下几次运行时间
     * @return
     */
    public static List<String> getNextExecTime(String cronExpression, Integer numTimes) {
        List<String> list = new ArrayList<>();
        CronTriggerImpl cronTriggerImpl = new CronTriggerImpl();
        try {
            cronTriggerImpl.setCronExpression(cronExpression);
        } catch (ParseException e) {
            e.printStackTrace();
        }
        // 这个是重点，一行代码搞定
        List<Date> dates = TriggerUtils.computeFireTimes(cronTriggerImpl, null, numTimes);
        SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
        for (Date date : dates) {
            list.add(dateFormat.format(date));
        }
        return list;
    }

    /**
     * Java8 通过foreach 遍历List，同时输出下标
     * 利用BiConsumer实现foreach循环支持index
     *
     * @param biConsumer
     * @param <T>
     * @return
     */
    public static <T> Consumer<T> forEachWithIndex(BiConsumer<T, Integer> biConsumer) {
        /*这里说明一下，我们每次传入forEach都是一个重新实例化的Consumer对象，在lambada表达式中我们无法对int进行++操作,
        我们模拟AtomicInteger对象，写个getAndIncrement方法，不能直接使用AtomicInteger哦*/
        class IncrementInt {
            int i = 0;

            public int getAndIncrement() {
                return i++;
            }
        }
        IncrementInt incrementInt = new IncrementInt();
        return t -> biConsumer.accept(t, incrementInt.getAndIncrement());
    }

    /**
     * 获取cron表达式
     * @param model 模型
     * @return 表达式
     */
    public static String getCron(TbEventModel model) {
        //time_range
        if (StringUtils.isBlank(model.getPeriodType())) {
            //旧模型时间间隔为空 默认查询频率为60秒；
            model.setPeriodType("1");
        }
        int interval = DataUtils.toInt(model.getTaskInterval());
        if (interval < 1) {
            interval = 1;
        }

        if (TimePeriodEnum.HOUR.getValue().equals(model.getPeriodType())) {
            return String.format("0 0 */%d * * ?",interval);
        } else if (TimePeriodEnum.DAY.getValue().equals(model.getPeriodType())) {
            return String.format("0 0 0 */%d * ?",interval);
        } else if (TimePeriodEnum.SECOND.getValue().equals(model.getPeriodType())) {
            return String.format("0/%d * * * * ?",interval);
        }
        return  String.format("0 */%d * * * ?",interval);
    }


    /**
     * 获取cron表达式
     * @param ipPluggingScene 策略
     * @return 表达式
     */
    public static String getCronIp(IpPluggingScene ipPluggingScene) {
        //getQueryTimeFreqUnit 1:分钟、2:小时、3:天
        //queryTimeFreq
        if (ipPluggingScene.getGetQueryTimeFreqUnit() < 1) {
            //旧模型时间间隔为空 默认查询频率为60秒；
            ipPluggingScene.setGetQueryTimeFreqUnit(1);
        }
        String perType = String.valueOf(ipPluggingScene.getGetQueryTimeFreqUnit());
        int interval = ipPluggingScene.getQueryTimeFreq();
        if (interval < 1) {
            interval = 1;
        }

        if (TimePeriodEnum.HOUR.getValue().equals(perType)) {
            return String.format("0 0 */%d * * ?",interval);
        } else if (TimePeriodEnum.DAY.getValue().equals(perType)) {
            return String.format("0 0 0 */%d * ?",interval);
        } else if (TimePeriodEnum.SECOND.getValue().equals(perType)) {
            return String.format("0/%d * * * * ?",interval);
        }
        return  String.format("0 */%d * * * ?",interval);
    }
}

