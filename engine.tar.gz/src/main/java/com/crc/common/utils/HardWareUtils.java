package com.crc.common.utils;

import org.apache.commons.io.IOUtils;
import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.InputStream;

/**
 * Created by JAVA on 2018/7/26.
 * 本来写的是一个获取本机一些参数，作为源来进行加密的类，
 * 项目里只用到了硬盘编号，就没有用到这个类
 */
public class HardWareUtils {
    private static Logger logger = LoggerFactory.getLogger(HardWareUtils.class);

    public static void main(String[] args) throws Exception {
        System.out.println("CPU  SN:" + HardWareUtils.getCPUSerial());
        System.out.println("主板  SN:" + HardWareUtils.getMotherboardSN());
    }


    /**
     * 获取主板序列号
     *
     * @return
     */
    public static String getMotherboardSN() {
        String result = "";
        if (isWindows()) {
            //windows 不支持
        } else {
            result = getSerialNumber("dmidecode |grep 'Serial Number'", "Serial Number", ":");
        }
        return result.trim();
    }

    /**
     * @param cmd    命令语句
     * @param record 要查看的字段
     * @param symbol 分隔符
     * @return
     */
    private static String getSerialNumber(String cmd, String record, String symbol) {
        String execResult = executeLinuxCmd(cmd);
        String[] infos = execResult.split("\n");

        for (String info : infos) {
            if (StringUtils.isBlank(info))
                continue;
            info = info.trim();
            if (info.contains(record)) {
                info.replace(" ", "");
                String[] sn = info.split(symbol);
                if (sn.length > 1)
                    return sn[1];
            }
        }

        return "";
    }

    private static String executeLinuxCmd(String cmd) {
        Process process = null;
        InputStream in = null;
        try {
            Runtime run = Runtime.getRuntime();
            process = run.exec(cmd);
            in = process.getInputStream();
            StringBuilder out = new StringBuilder();
            byte[] b = new byte[8192];
            for (int n; (n = in.read(b)) != -1; ) {
                out.append(new String(b, 0, n));
            }

            return out.toString();
        } catch (Exception e) {
            logger.error(e.getMessage(), e);
        } finally {
            IOUtils.closeQuietly(in);
            try {
                process.destroy();
            } catch (Exception e) {
                logger.error(e.getMessage(), e);
            }
        }
        return "";
    }

    /**
     * 获取CPU序列号
     *
     * @return
     */
    public static String getCPUSerial() {
        String result = "";
        if (isWindows()) {
            //windows 不支持
        } else {
            result = getSerialNumber("dmidecode -t processor | grep 'ID'", "ID", ":");
        }
        return result.trim();
    }

    private static boolean isWindows() {
        String osName = System.getProperty("os.name");
        osName = osName.toLowerCase();
        if (osName.contains("windows"))
            return true;
        return false;
    }

}
