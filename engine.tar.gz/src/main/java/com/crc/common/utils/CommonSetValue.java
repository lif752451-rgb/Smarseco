package com.crc.common.utils;

import cn.hutool.core.util.ReflectUtil;

import java.util.Date;

/**
 * 通过属 set方法进行赋值
 * 
 * @author zhangbing
 */
public class CommonSetValue {

    private static final String DEL_FLAG = "delFlag";
    private static final String CREATE_BY = "createBy";
    private static final String CREATE_BY_LABEL = "createByLabel";
    private static final String CREATE_TIME = "createTime";
    private static final String UPDATE_BY = "updateBy";
    private static final String UPDATE_TIME = "updateTime";

    /**
     * 反射注入值-通过属 set方法进行赋值 <T> T 表示返回值是一个泛型 T 用于限制传递的数据类型（编译时才需要去确定的具体类型）
     *
     * @param t 对象
     */
    public static <T> T insertSetVal(T t) {
        Class<?> tClass = t.getClass();
        if (ReflectUtil.hasField(tClass, DEL_FLAG)) {
            ReflectUtil.setFieldValue(t, DEL_FLAG, "0");
        }
        Date date = new Date();
        if (ReflectUtil.hasField(tClass, CREATE_TIME)) {
            ReflectUtil.setFieldValue(t, CREATE_TIME, date);
        }
        if (ReflectUtil.hasField(tClass, UPDATE_TIME)) {
            ReflectUtil.setFieldValue(t, UPDATE_TIME, date);
        }
        return t;
    }

    /**
     * 反射注入值-通过属 set方法进行赋值 <T> T 表示返回值是一个泛型 T 用于限制传递的数据类型（编译时才需要去确定的具体类型）
     *
     * @param t 对象
     */
    public static <T> T updateSetVal(T t) {
        Class<?> tClass = t.getClass();
        if (ReflectUtil.hasField(tClass, UPDATE_TIME)) {
            ReflectUtil.setFieldValue(t, UPDATE_TIME, new Date());
        }
        return t;
    }
}