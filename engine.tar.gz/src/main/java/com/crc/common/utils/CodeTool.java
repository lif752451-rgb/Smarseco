package com.crc.common.utils;

import org.apache.commons.lang3.StringUtils;
import org.jasypt.encryption.pbe.StandardPBEStringEncryptor;
import org.jasypt.encryption.pbe.config.EnvironmentPBEConfig;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class CodeTool {
    private static Logger logger = LoggerFactory.getLogger(CodeTool.class);
    public synchronized  static String decrypt(String password, String publicKey) {
        if (StringUtils.isNotBlank(publicKey)) {
            try {
                StandardPBEStringEncryptor standardPBEStringEncryptor = new StandardPBEStringEncryptor();
                EnvironmentPBEConfig config = new EnvironmentPBEConfig();

                // 加密的算法，这个算法是默认的
                config.setAlgorithm("PBEWithMD5AndDES");
                // 加密的密钥，随便自己填写，很重要千万不要告诉别人
                config.setPassword(publicKey);
                standardPBEStringEncryptor.setConfig(config);
                return standardPBEStringEncryptor.decrypt(password);
            } catch (Exception e) {
                logger.error(e.getMessage(), e);
            }
        }
        return password;
    }

    public static String encrypt(String password, String publicKey) {
        try {
            if (StringUtils.isNotBlank(publicKey)) {
                StandardPBEStringEncryptor standardPBEStringEncryptor = new StandardPBEStringEncryptor();
                EnvironmentPBEConfig config = new EnvironmentPBEConfig();

                // 加密的算法，这个算法是默认的
                config.setAlgorithm("PBEWithMD5AndDES");
                // 加密的密钥，随便自己填写，很重要千万不要告诉别人
                config.setPassword(publicKey);
                standardPBEStringEncryptor.setConfig(config);
                return standardPBEStringEncryptor.encrypt(password);
            }
        } catch (Exception e) {
            logger.error(e.getMessage(), e);
        }
        return password;
    }

    public static String encrypt(String password) {
        String publicKey = "IpTFX6FjYs5zKDG8gjKFh7kTgCFdWWJE";
        return encrypt(password, publicKey);
    }

    public static String decrypt(String pass) {
        String publicKey = "IpTFX6FjYs5zKDG8gjKFh7kTgCFdWWJE";
        if (StringUtils.isBlank(pass)) {
            return pass;
        }

        if (pass.startsWith("ENC")) {
            pass = pass.replace("ENC(", "").replace(")", "");
            pass = CodeTool.decrypt(pass, publicKey);
        }
        return pass;
    }


    public static void main(String[] args) {
        String publicKey = "IpTFX6FjYs5zKDG8gjKFh7kTgCFdWWJE";
        //String encryptedText = encrypt("root", publicKey);
        String decryptText = decrypt("5ZHgosGxaGNp5OVTdC5oop71MdVYRVHFT+DctoIyCO0uC/bx8E2JFybWTlz76PqHM34R2M7eWIw=", publicKey);
        logger.info(decryptText);
        logger.info(CodeTool.encrypt("ydfhs++CD43D",publicKey));
        logger.info(CodeTool.encrypt("w9Mu1qL0J5juVZttuFDt",publicKey));
    }
}
