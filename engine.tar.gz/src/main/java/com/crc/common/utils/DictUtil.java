package com.crc.common.utils;

import com.crc.secface.config.GetSpringBean;
import com.crc.secface.entity.SysDictData;
import com.crc.secface.mapper.SysDictDataMapper;
import lombok.extern.slf4j.Slf4j;
import org.springframework.util.CollectionUtils;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

/**
 * 数据字典工具类
 */
@Slf4j
public class DictUtil {

    public static List<SysDictData> getDict(String dictType) {
        try {
            SysDictDataMapper sysDictDataService = GetSpringBean.getBean(SysDictDataMapper.class);
            return sysDictDataService.selectDictDataByType(dictType);
        } catch (Exception e) {
            log.error(e.getMessage(), e);
        }
        return new ArrayList<>();
    }

    /**
     * 获取数据字典(Map<value, label>)
     *
     * @param dictType 数据字典类型
     * @return map
     */
    public static Map<String, String> getMapValueLabel(String dictType) {
        List<SysDictData> dataList = getDict(dictType);
        return dataList.stream().collect(Collectors.toMap(SysDictData::getDictValue, SysDictData::getDictLabel));
    }

    /**
     * 查询数据字典
     *
     * @param dictType  数据字典类型
     * @param dictValue 数据字典项value
     * @return SysDictData
     */
    public static SysDictData getDictByValue(String dictType, String dictValue) {
        List<SysDictData> dataList = getDict(dictType);
        return dataList.stream().filter(vo -> vo.getDictValue().equals(dictValue)).findFirst().orElseGet(SysDictData::new);
    }

    /**
     * 获取数据字典显示值dictLabel
     *
     * @param dictType  数据字典类型
     * @param dictValue 数据字典项value
     * @return String
     */
    public static String getDictLabel(String dictType, String dictValue) {
        Map<String, String> map = getMapValueLabel(dictType);
        return map.get(dictValue);
    }

    /**
     * 获取数据字典(Map<label, value>)
     *
     * @param dictType 数据字典类型
     * @return map
     */
    public static Map<String, String> getMapLabelValue(String dictType) {
        List<SysDictData> dataList = getDict(dictType);
        return dataList.stream().collect(Collectors.toMap(SysDictData::getDictLabel, SysDictData::getDictValue));
    }

    /**
     * 获取数据字典项value
     *
     * @param dictType  数据字典类型
     * @param dictLabel 数据字典项Label
     * @return String
     */
    public static String getDictValue(String dictType, String dictLabel) {
        Map<String, String> map = getMapLabelValue(dictType);
        return map.get(dictLabel);
    }

    public static String selectDictValueOrDefault(String dictType, String dictLabel, String defaultValue) {
        SysDictDataMapper sysDictDataService = GetSpringBean.getBean(SysDictDataMapper.class);
        SysDictData sysDictData = new SysDictData();
        sysDictData.setDictType(dictType);
        sysDictData.setDictLabel(dictLabel);
        List<SysDictData> dictDataList = sysDictDataService.selectDictDataList(sysDictData);
        if (CollectionUtils.isEmpty(dictDataList)) {
            return defaultValue;
        }
        return dictDataList.get(0).getDictValue();
    }

    /**
     * 查询数据字典
     *
     * @param dictType  数据字典类型
     * @param dictLabel 数据字典项label
     * @return SysDictData
     */
    public static SysDictData getDictByLabel(String dictType, String dictLabel) {
        List<SysDictData> dataList = getDict(dictType);
        return dataList.stream().filter(vo -> vo.getDictLabel().equals(dictLabel)).findFirst().orElseGet(SysDictData::new);
    }

    /**
     * 数据字典取值 如果取不到默认取第一个数据字典
     *
     * @param dictList 数据字典结果集
     * @param label 数据字典显示值
     * @return 数据字典value值
     */
    public static String getDictDataValueOrDefault(List<SysDictData> dictList, String label) {
        return dictList.stream().filter(dict -> StringUtils.trim(label).equals(dict.getDictLabel()))
                .map(SysDictData::getDictValue).findFirst()
                .orElse(dictList.stream().map(SysDictData::getDictValue).findFirst().orElseGet(String::new));
    }
}