package com.crc.common.utils;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONArray;
import com.alibaba.fastjson.JSONObject;
import com.crc.common.constants.LogConstantsX;
import org.apache.commons.lang3.StringEscapeUtils;
import org.apache.commons.lang3.StringUtils;
import org.omg.Messaging.SYNC_WITH_TRANSPORT;

import java.text.SimpleDateFormat;
import java.time.LocalDateTime;
import java.time.ZoneId;
import java.util.Calendar;
import java.util.Date;
import java.util.Objects;

/**
 * JSON工具类
 */
public class JsonUtils {
    public static JSONArray parseArray(String json) {
        try {
            if (StringUtils.isBlank(json)) {
                return createJsonArray();
            }
            return JSON.parseArray(json);
        } catch (Exception e) {
            try {
                return parseUnescapeArray(json);
            } catch (Exception e1) {

            }
        }
        return createJsonArray();
    }

    public static JSONArray parseUnescapeArray(String json) {
        try {
            if (StringUtils.isBlank(json)) {
                return createJsonArray();
            }
            json = StringEscapeUtils.unescapeJson(json);
            return JSON.parseArray(json);
        } catch (Exception e) {

        }
        return createJsonArray();
    }

    public static void copyField(JSONObject json, String src, String dest) {
        if (isEmpty(json) || StringUtils.isBlank(src))
            return;

        try {
            if (json.get(src) != null)
                json.put(dest, json.get(src));
        } catch (Exception ignored) {

        }
    }

    public static JSONArray getJsonArray(JSONObject json, String filter) {
        if (isEmpty(json) || StringUtils.isBlank(filter))
            return createJsonArray();
        try {
            return json.getJSONArray(filter);
        } catch (Exception e) {
            return createJsonArray();
        }
    }

    public static JSONObject getJson(JSONObject json, String filter) {
        if (isEmpty(json) || StringUtils.isBlank(filter))
            return createJson();

        try {
            return json.getJSONObject(filter);
        } catch (Exception e) {

        }
        return createJson();
    }


    public static int getInt(JSONObject json, String filter) {
        if (isEmpty(json) || StringUtils.isBlank(filter))
            return 0;
        if (json.get(filter) == null) {
            return 0;
        }
        try {
            return json.getIntValue(filter);
        } catch (Exception e) {
            return 0;
        }
    }

    public static long getLong(JSONObject json, String filter,long def) {
        if (isEmpty(json) || StringUtils.isBlank(filter))
            return def;
        if (json.get(filter) == null) {
            return def;
        }
        try {
            return json.getLongValue(filter);
        } catch (Exception e) {
            return def;
        }
    }

    public static long getLong(JSONObject json, String filter) {
        if (isEmpty(json) || StringUtils.isBlank(filter))
            return 0;
        if (json.get(filter) == null) {
            return 0;
        }
        try {
            return json.getLongValue(filter);
        } catch (Exception e) {
            return 0;
        }
    }

    public static String getStr(JSONObject json, String filter, String defaultVal) {
        String ret = getStr(json, filter);
        if (StringUtils.isBlank(ret))
            return defaultVal;
        return ret;
    }

    public static Date getDateX(JSONObject json, String filter) {
        if (isEmpty(json) || StringUtils.isBlank(filter))
            return null;

        if (json.get(filter) == null) {
            return null;
        }
        try {
            Object obj = json.get(filter);
            if (obj instanceof LocalDateTime) {
                //return DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss").format((LocalDateTime)obj);
                LocalDateTime localDateTime = (LocalDateTime) obj;
                return Date.from(localDateTime.atZone(ZoneId.systemDefault()).toInstant());
            } else if (obj instanceof Date) {
                return (Date) obj;
            }
            String dateStr = getStr(json, filter);
            return DateUtils.parseDate1(dateStr, DateUtils.DATE_FORMAT_STRING1);
        } catch (Exception e1) {

        }
        return null;
    }

    public static Date getDate(JSONObject json, String filter) {
        if (isEmpty(json) || StringUtils.isBlank(filter))
            return new Date();

        if (json.get(filter) == null) {
            return new Date();
        }
        try {
            Object obj = json.get(filter);
            if (obj instanceof LocalDateTime) {
                //return DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss").format((LocalDateTime)obj);
                LocalDateTime localDateTime = (LocalDateTime) obj;
                return Date.from(localDateTime.atZone(ZoneId.systemDefault()).toInstant());
            } else if (obj instanceof Date) {
                return (Date) obj;
            }


            String dateStr = getStr(json, filter);
            dateStr = UTCToCSTAndCheck(dateStr);
            if (StringUtils.isNotBlank(dateStr))
                return DateUtils.parseDate(dateStr, DateUtils.DATE_FORMAT_STRING1);
        } catch (Exception e1) {

        }
        return new Date();
    }

    private static String UTCToCSTAndCheck(String UTCStr) {
        if (StringUtils.isBlank(UTCStr)) {
            return null;
        }
        Date date = null;
        SimpleDateFormat sdf = new SimpleDateFormat(DateUtils.ES_TIME_FORMAT1);
        Calendar calendar = Calendar.getInstance();
        if (UTCStr.contains("T")) {
            try {
                if (UTCStr.contains("+0800")) {
                    UTCStr = UTCStr.replace("+0800", "Z");
                }
                date = sdf.parse(UTCStr);
                calendar.setTime(date);

                SimpleDateFormat sdf2 = new SimpleDateFormat(DateUtils.DATE_FORMAT_STRING1);
                return sdf2.format(calendar.getTime());
            } catch (Exception e) {

            }
        }
        return UTCStr;
    }


    public static String getDateStr(JSONObject json, String filter) {
        if (isEmpty(json) || StringUtils.isBlank(filter))
            return "";

        if (json.get(filter) == null) {
            return "";
        }
        try {
            Date retStr = json.getDate(filter);
            /** GC日志特殊处理，将传入的时间参数固定+8小时 */
            Calendar cal = Calendar.getInstance();
            cal.setTime(retStr);
            cal.add(Calendar.HOUR_OF_DAY, 8);
            Date dateStart = cal.getTime();
            return DateUtils.getSparkTime(dateStart);
        } catch (Exception e1) {

        }
        return "";
    }

    public static String getStr(JSONObject json, String filter) {
        if (isEmpty(json) || StringUtils.isBlank(filter))
            return "";

        if (json.get(filter) == null) {
            return "";
        }

        try {
            String retStr = json.getString(filter);
            if (StringUtils.isNotBlank(retStr)) {
                if ("null".equalsIgnoreCase(retStr)) {
                    return "";
                }
                if ("-".equalsIgnoreCase(retStr)) {
                    return "";
                }
                if (LogConstantsX.LOG_START_TIME.equalsIgnoreCase(filter)) {
                    //2021-04-16T02:11:00.000+0800
                    retStr = retStr.replace("T", " ").replace("+8000", "");
                }
                return retStr.trim();
            }
        } catch (Exception e1) {

        }

        try {
            String retStr = json.get(filter).toString();
            if (StringUtils.isNotBlank(retStr)) {
                if ("null".equalsIgnoreCase(retStr)) {
                    return "";
                }
                if ("-".equalsIgnoreCase(retStr)) {
                    return "";
                }
                return retStr.trim();
            }
        } catch (Exception e1) {

        }
        return "";
    }

    public static boolean containsKey(JSONObject json, String filter) {
        if (isEmpty(json) || StringUtils.isBlank(filter))
            return false;
        if (json.containsKey(filter)) {
            return true;
        }
        return false;
    }

    public static boolean isEmpty(JSONObject json) {
        if (json == null)
            return true;
        if (json.isEmpty()) {
            return true;
        }
        return false;
    }

    public static JSONObject createJson() {
        return new JSONObject();
    }

    public static JSONArray createJsonArray() {
        return new JSONArray();
    }

    public static JSONObject parse(String json) {
        try {
            if (StringUtils.isBlank(json)) {
                return createJson();
            }
            return JSON.parseObject(json);
        } catch (Exception e) {
            try {
                return parseUnescape(json);
            } catch (Exception e1) {

            }
        }
        return createJson();
    }

    public static JSONObject parseUnescape(String json) {
        try {
            if (StringUtils.isBlank(json)) {
                return createJson();
            }
            json = StringEscapeUtils.unescapeJson(json);
            return JSON.parseObject(json);
        } catch (Exception e) {

        }
        return createJson();
    }


    public static String getLongToDate(JSONObject json, String longTime) {
        long time = getLong(json, longTime) * 1000;
        if (time > 0) {
            return DateUtils.getDateTimeString1(new Date(time));
        }
        return "";
    }

    public static Date getLongToDateX(JSONObject json, String longTime) {
        long time = getLong(json, longTime) * 1000;
        if (time > 0) {
            return new Date(time);
        }
        return new Date();
    }

    public static void print(Object json) {
        System.out.println("#################");
        if (json != null)
            System.out.println(JSON.toJSONString(json));
        System.out.println("#################");
    }

    public static void print(String label,Object json) {
        for (int i = 0; i < 10; i++) {
            System.out.print(label);
        }
        System.out.println();
        if (json != null)
            System.out.println(JSON.toJSONString(json));
        for (int i = 0; i < 10; i++) {
            System.out.print(label);
        }
        System.out.println();
    }


    public static int getIntN(JSONObject job, String log_count) {
        int ret = getInt(job, log_count);
        if (ret < 1)
            return 1;
        return ret;
    }

    public static boolean getBoolean(JSONObject json, String filter) {
        if (isEmpty(json) || StringUtils.isBlank(filter))
            return false;

        if (json.get(filter) == null) {
            return false;
        }
        try {
            return json.getBoolean(filter);
        } catch (Exception e) {

        }
        return false;
    }

    /**
     * 判断2个属性是否相等
     * @param json
     * @param src
     * @param dest
     * @return
     */
    public static boolean equal(JSONObject json, String src, String dest) {
        if (isEmpty(json) || StringUtils.isBlank(src))
            return false;
        if (isEmpty(json) || StringUtils.isBlank(dest))
            return false;
        try {
            String sVal = getStr(json, src);
            String dVal = getStr(json, dest);
            if (StringUtils.isNotBlank(sVal) && sVal.equals(dVal))
                return true;
        } catch (Exception e) {

        }
        return false;
    }

    /**
     * 判断第1属性跟目标值是否相等
     * @param json
     * @param src
     * @param val
     * @return
     */
    public static boolean equalVal(JSONObject json, String src, String val) {
        if (isEmpty(json) || StringUtils.isBlank(src))
            return false;
        if (isEmpty(json) || StringUtils.isBlank(val))
            return false;
        try {
            String sVal = getStr(json, src);
            if (StringUtils.isNotBlank(sVal) && sVal.equals(val))
                return true;
        } catch (Exception e) {

        }
        return false;
    }

    public static double getDouble(JSONObject json, String filter) {
        if (isEmpty(json) || StringUtils.isBlank(filter))
            return 0;
        if (json.get(filter) == null) {
            return 0;
        }
        try {
            return json.getDoubleValue(filter);
        } catch (Exception e) {
            return 0;
        }
    }
    /**
     * obj转json字符串 obj为空返回""
     *
     * @param obj Object
     * @return String
     */
    public static String toJSONString(Object obj) {
        String str = "";
        if (Objects.nonNull(obj)) {
            str = JSONObject.toJSONString(obj);
        }
        return str;
    }
}
