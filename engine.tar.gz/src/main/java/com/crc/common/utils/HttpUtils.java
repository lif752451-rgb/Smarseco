package com.crc.common.utils;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONArray;
import com.alibaba.fastjson.JSONObject;
import com.crc.secface.config.ElasticsearchProperties;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.codec.binary.Base64;
import org.apache.commons.lang3.StringUtils;
import org.apache.http.HttpEntity;
import org.apache.http.HttpHeaders;
import org.apache.http.client.config.RequestConfig;
import org.apache.http.client.methods.CloseableHttpResponse;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.client.methods.HttpPut;
import org.apache.http.config.Registry;
import org.apache.http.config.RegistryBuilder;
import org.apache.http.conn.socket.ConnectionSocketFactory;
import org.apache.http.conn.socket.PlainConnectionSocketFactory;
import org.apache.http.conn.ssl.NoopHostnameVerifier;
import org.apache.http.conn.ssl.SSLConnectionSocketFactory;
import org.apache.http.conn.ssl.TrustStrategy;
import org.apache.http.entity.StringEntity;
import org.apache.http.impl.client.BasicCookieStore;
import org.apache.http.impl.client.BasicResponseHandler;
import org.apache.http.impl.client.CloseableHttpClient;
import org.apache.http.impl.client.HttpClients;
import org.apache.http.impl.conn.PoolingHttpClientConnectionManager;
import org.apache.http.message.BasicHeader;
import org.apache.http.protocol.HTTP;
import org.apache.http.ssl.SSLContextBuilder;
import org.apache.http.util.EntityUtils;

import javax.net.ssl.*;
import java.io.*;
import java.net.*;
import java.nio.charset.StandardCharsets;
import java.security.cert.X509Certificate;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.TreeMap;

/**
 * 通用http发送方法
 *
 * @author ruoyi
 */
@Slf4j
public class HttpUtils {
    public static final int CONN_TIME_OUT = 20000;
    public static final int READ_TIME_OUT = 20000;


    /**
     * 向指定 URL 发送GET方法的请求
     *
     * @param url   发送请求的 URL
     * @param param 请求参数，请求参数应该是 name1=value1&name2=value2 的形式。
     * @return 所代表远程资源的响应结果
     */
    public static String sendGet(String url, String param) {
        if (url != null && url.toLowerCase().startsWith("https")) {
            return HttpsUtils.sendSSLGet(url, param);
        }
        StringBuilder result = new StringBuilder();
        BufferedReader in = null;
        HttpURLConnection connection = null;
        try {
            String urlNameString = url;
            if (StringUtils.isNotBlank(param)) {
                urlNameString = url + "?" + param;
            }
            log.info("sendGet - " + urlNameString);
            URL realUrl = new URL(urlNameString);
            connection = (HttpURLConnection) realUrl.openConnection();
            connection.setRequestProperty("accept", "*/*");
            connection.setRequestProperty("connection", "Keep-Alive");
            connection.setRequestProperty("user-agent", "Mozilla/4.0 (compatible; MSIE 6.0; Windows NT 5.1;SV1)");
            connection.setRequestProperty("content-type", "application/json");
            connection.setConnectTimeout(CONN_TIME_OUT);
            connection.setReadTimeout(READ_TIME_OUT);
            connection.connect();
            in = new BufferedReader(new InputStreamReader(connection.getInputStream()));
            String line;
            while ((line = in.readLine()) != null) {
                result.append(line);
            }
        } catch (Exception e) {
            log.error(e.getMessage(), e);
        } finally {
            IOUtils.close(in);
            IOUtils.close(connection);
        }
        return result.toString();
    }

    /**
     * 向指定 URL 发送GET方法的请求
     *
     * @param url   发送请求的 URL
     * @param param 请求参数，请求参数应该是 name1=value1&name2=value2 的形式。
     * @return 所代表远程资源的响应结果
     */
    public static String sendGet(String url, String param, HashMap<String, String> headerMap) {
        if (url != null && url.toLowerCase().startsWith("https")) {
            return HttpsUtils.sendSSLGet(url, param, headerMap);
        }
        StringBuilder result = new StringBuilder();
        BufferedReader in = null;
        HttpURLConnection connection = null;
        try {
            String urlNameString = url;
            if (StringUtils.isNotBlank(param)) {
                urlNameString = url + "?" + param;
            }
            log.info("sendGet - " + urlNameString);
            URL realUrl = new URL(urlNameString);
            connection = (HttpURLConnection) realUrl.openConnection();
            connection.setRequestProperty("accept", "*/*");
            connection.setRequestProperty("connection", "Keep-Alive");
            connection.setRequestProperty("user-agent", "Mozilla/4.0 (compatible; MSIE 6.0; Windows NT 5.1;SV1)");
            connection.setRequestProperty("content-type", "application/json");
            connection.setConnectTimeout(CONN_TIME_OUT);
            connection.setReadTimeout(READ_TIME_OUT);
            HttpURLConnection finalConnection = connection;
            if (headerMap != null) {
                headerMap.forEach((k, v) -> {
                    finalConnection.setRequestProperty(k, v);
                });
            }
            connection.connect();
            in = new BufferedReader(new InputStreamReader(connection.getInputStream()));
            String line;
            while ((line = in.readLine()) != null) {
                result.append(line);
            }
        } catch (Exception e) {
            log.error(e.getMessage(), e);
        } finally {
            IOUtils.close(in);
            IOUtils.close(connection);
        }
        return result.toString();
    }

    /**
     * 向指定 URL 发送GET方法的请求
     *
     * @param url   发送请求的 URL
     * @param param 请求参数，请求参数应该是 name1=value1&name2=value2 的形式。
     * @return 所代表远程资源的响应结果
     */
    public static String sendGet(String url, String param, String token) {
        StringBuilder result = new StringBuilder();
        BufferedReader in = null;
        HttpURLConnection connection = null;
        try {
            String urlNameString = url + "?" + param;
            if (StringUtils.isBlank(param)) {
                urlNameString = url;
            }
            log.info("sendGet - " + urlNameString);
            URL realUrl = new URL(urlNameString);
            connection = (HttpURLConnection) realUrl.openConnection();
            connection.setRequestProperty("accept", "*/*");
            connection.setRequestProperty("connection", "Keep-Alive");
            connection.setRequestProperty("user-agent", "Mozilla/4.0 (compatible; MSIE 6.0; Windows NT 5.1;SV1)");
            connection.setRequestProperty("Authorization", token);
            connection.setRequestProperty("content-type", "application/json");
            connection.setConnectTimeout(CONN_TIME_OUT);
            connection.setReadTimeout(READ_TIME_OUT);
            connection.connect();
            in = new BufferedReader(new InputStreamReader(connection.getInputStream()));
            String line;
            while ((line = in.readLine()) != null) {
                result.append(line);
            }
        } catch (Exception e) {
            log.error(e.getMessage(), e);
        } finally {
            IOUtils.close(in);
            IOUtils.close(connection);
        }
        return result.toString();
    }

    /**
     * @param urlPath 对方地址
     * @param json    要传送的数据
     * @return
     */
    public static String sendPost(String urlPath, String json, boolean print) {
        if (urlPath != null && urlPath.startsWith("https")) {
            return HttpsUtils.sendPost(urlPath, json);
        }
        OutputStreamWriter out = null;
        BufferedReader in = null;
        StringBuilder result = new StringBuilder();
        HttpURLConnection urlConnection = null;
        try {
            URL url = new URL(urlPath);
            if (print) {
                log.info("sendPost - " + urlPath + ",JSON参数：" + json);
            } else {
                log.info("sendPost - " + urlPath);
            }
            urlConnection = (HttpURLConnection) url.openConnection();
            // 设置doOutput属性为true表示将使用此urlConnection写入数据
            urlConnection.setDoOutput(true);
            // 定义待写入数据的内容类型，我们设置为application/x-www-form-urlencoded类型
            urlConnection.setRequestProperty("content-type", "application/json");
            urlConnection.setRequestProperty("accept", "*/*");
            urlConnection.setRequestProperty("connection", "Keep-Alive");
            urlConnection.setRequestProperty("user-agent", "Mozilla/4.0 (compatible; MSIE 6.0; Windows NT 5.1;SV1)");
            urlConnection.setConnectTimeout(CONN_TIME_OUT);
            urlConnection.setReadTimeout(READ_TIME_OUT);
//            System.out.println(urlPath);
//            urlConnection.getRequestProperties().forEach((k, v) -> {
//                System.out.println(k + " -> " + v);
//            });

            // 得到请求的输出流对象
            out = new OutputStreamWriter(urlConnection.getOutputStream());
            // 把数据写入请求的Body
            if (StringUtils.isNotBlank(json))
                out.write(json);
            out.flush();
            // 定义BufferedReader输入流来读取URL的响应
            in = new BufferedReader(new InputStreamReader(urlConnection.getInputStream()));
            String line;
            while ((line = in.readLine()) != null) {
                result.append(line);
            }
        } catch (Exception e) {
            log.error(e.getMessage(), e);
            return "";
        }
        // 使用finally块来关闭输出流、输入流
        finally {
            IOUtils.close(in);
            IOUtils.close(out);
            IOUtils.close(urlConnection);
        }
        return result.toString();
    }

    /**
     * @param urlPath 对方地址
     * @param json    要传送的数据
     * @return
     */
    public static String sendPost(String urlPath, String json) {
        if (StringUtils.isBlank(urlPath)) {
            return "";
        }
        if (urlPath.startsWith("https")) {
            return HttpsUtils.sendPost(urlPath, json);
        }
        OutputStreamWriter out = null;
        BufferedReader in = null;
        StringBuilder result = new StringBuilder();
        HttpURLConnection urlConnection = null;
        try {
            URL url = new URL(urlPath);
            log.info("sendPost - " + urlPath + ",JSON参数：" + json);
            urlConnection = (HttpURLConnection) url.openConnection();
            // 设置doOutput属性为true表示将使用此urlConnection写入数据
            urlConnection.setDoOutput(true);
            // 定义待写入数据的内容类型，我们设置为application/x-www-form-urlencoded类型
            urlConnection.setRequestProperty("Content-Type", "application/json");
            urlConnection.setRequestProperty("accept", "*/*");
            urlConnection.setRequestProperty("connection", "Keep-Alive");
            urlConnection.setRequestProperty("user-agent", "Mozilla/4.0 (compatible; MSIE 6.0; Windows NT 5.1;SV1)");
            urlConnection.setConnectTimeout(CONN_TIME_OUT);
            urlConnection.setReadTimeout(READ_TIME_OUT);

            // 得到请求的输出流对象
            out = new OutputStreamWriter(urlConnection.getOutputStream());
            // 把数据写入请求的Body
            if (StringUtils.isNotBlank(json))
                out.write(json);
            out.flush();
            // 定义BufferedReader输入流来读取URL的响应
            in = new BufferedReader(new InputStreamReader(urlConnection.getInputStream()));
            String line;
            while ((line = in.readLine()) != null) {
                result.append(line);
            }
        } catch (Exception e) {
            log.error(e.getMessage(), e);
            return "";
        }
        // 使用finally块来关闭输出流、输入流
        finally {
            IOUtils.close(in);
            IOUtils.close(out);
            IOUtils.close(urlConnection);
        }
        return result.toString();
    }

    /**
     * 向指定 URL 发送POST方法的请求
     *
     * @param url  发送请求的 URL
     * @param json JSON的形式。
     * @return 所代表远程资源的响应结果
     */
    public static String sendPost(String url, String json, HashMap<String, String> headerMap) {
        PrintWriter out = null;
        BufferedReader in = null;
        StringBuilder result = new StringBuilder();
        HttpURLConnection conn = null;
        try {
            URL realUrl = new URL(url);
            log.info("sendPost - " + url);
            conn = (HttpURLConnection) realUrl.openConnection();
            conn.setRequestProperty("accept", "*/*");
            conn.setRequestProperty("connection", "Keep-Alive");
            conn.setRequestProperty("user-agent", "Mozilla/4.0 (compatible; MSIE 6.0; Windows NT 5.1;SV1)");
            conn.setRequestProperty("Accept-Charset", "utf-8");
            conn.setRequestProperty("Content-Type", "application/json");
            conn.setConnectTimeout(CONN_TIME_OUT);
            conn.setReadTimeout(READ_TIME_OUT);
            for (String key : headerMap.keySet()) {
                conn.setRequestProperty(key, headerMap.get(key));
            }
            conn.setDoOutput(true);
            conn.setDoInput(true);
            out = new PrintWriter(conn.getOutputStream());
            if (json != null)
                out.write(json);
            out.flush();
            in = new BufferedReader(new InputStreamReader(conn.getInputStream(), StandardCharsets.UTF_8));
            String line;
            while ((line = in.readLine()) != null) {
                result.append(line);
            }
        } catch (Exception e) {
            log.error(e.getMessage(), e);
        } finally {
            IOUtils.close(in);
            IOUtils.close(out);
            IOUtils.close(conn);
        }
        return result.toString();
    }

    public static String sendEsGet(ElasticsearchProperties esConfig, String index, String json) {
        StringBuilder result = new StringBuilder();
        BufferedReader in = null;
        OutputStreamWriter out = null;
        HttpURLConnection connection = null;
        String url = buildEsSearchUrl(esConfig, index);
        try {
            if (StringUtils.isBlank(url)) {
                return "";
            }
            log.info("sendEsGet - " + url);
            URL urlx = new URL(url);
            connection = (HttpURLConnection) urlx.openConnection();
            // 设置doOutput属性为true表示将使用此urlConnection写入数据
            connection.setDoOutput(true);
            String userName = esConfig.getUserName();
            String password = esConfig.getPassword();
            String auth = userName + ":" + password;
            byte[] encodedAuth = Base64.encodeBase64(auth.getBytes(StandardCharsets.US_ASCII));
            String authHeader = "Basic " + new String(encodedAuth);
            connection.setRequestProperty(HttpHeaders.AUTHORIZATION, authHeader);
            String proxyHeader = esConfig.getProxyHeader();
            connection.setRequestProperty("X-Found-Cluster", proxyHeader);
            connection.setRequestProperty("accept", "*/*");
            connection.setRequestProperty("connection", "Keep-Alive");
            connection.setRequestProperty("Content-Length", "1000");
            System.setProperty("java.net.preferIPv4Stack", "true");
            connection.setRequestProperty("user-agent", "Mozilla/4.0 (compatible; MSIE 6.0; Windows NT 5.1;SV1)");
            connection.setRequestProperty("content-type", "application/json");
            connection.setConnectTimeout(CONN_TIME_OUT);
            connection.setReadTimeout(READ_TIME_OUT);
            // 得到请求的输出流对象
            out = new OutputStreamWriter(connection.getOutputStream());
            // 把数据写入请求的Body
            connection.connect();
            if (StringUtils.isNotBlank(json)) {
                out.write(json);
                out.flush();
            }
            //System.out.println(DateUtils.getDateTimeString2(new Date()));
            in = new BufferedReader(new InputStreamReader(connection.getInputStream(), StandardCharsets.UTF_8));
            String line;
            while ((line = in.readLine()) != null) {
                result.append(line);
            }
            //System.out.println(DateUtils.getDateTimeString2(new Date()));
        } catch (Exception e) {
            log.error(e.getMessage(), e);
        } finally {
            IOUtils.close(in);
            IOUtils.close(out);
            IOUtils.close(connection);
        }
        return result.toString();
    }

    public static String buildEsSearchUrl(ElasticsearchProperties esConfig, String esIndex) {
        if (esConfig == null) {
            return "";
        }
        return String.format("%s/%s/%s", esConfig.getBaseUrl(), esIndex, "_search");
    }

    public static String coverJson2String(JSONObject data, String excludeKey) {
        if (data == null || data.size() < 1) {
            return "";
        }
        TreeMap<String, Object> tree = new TreeMap<>();
        Iterator<Map.Entry<String, Object>> it = data.entrySet().iterator();
        while (it.hasNext()) {
            Map.Entry<String, Object> en = it.next();
            if (excludeKey != null && StringUtils.equals(excludeKey, en.getKey().trim()))
                continue;
            if (null == en.getValue())
                continue;
            tree.put(en.getKey(), en.getValue());
        }
        it = tree.entrySet().iterator();
        StringBuilder sf = new StringBuilder();
        while (it.hasNext()) {
            if (sf.length() > 0)
                sf.append("&");
            Map.Entry<String, Object> en = it.next();
            if (en.getValue() instanceof String || en.getValue() instanceof JSONObject || en.getValue() instanceof JSONArray) {
                String value = en.getValue().toString();
                try {
                    sf.append(en.getKey()).append("=").append(URLEncoder.encode(value, "UTF-8"));
                } catch (Exception e) {
                    sf.append(en.getKey()).append("=").append(en.getValue());
                }
            } else {
                sf.append(en.getKey()).append("=").append(en.getValue());
            }
        }
        return sf.toString();
    }

    /*
      通用HTTP GET请求接口
     */
    public static String sendGet(String urlPath, String param, JSONObject headers) {
        if (StringUtils.isBlank(urlPath)) {
            return "";
        }
        if (urlPath.startsWith("https")) {
            return HttpsUtils.sendGet(urlPath, param, headers);
        }
        StringBuilder result = new StringBuilder();
        BufferedReader in = null;
        HttpURLConnection connection = null;
        try {
            String urlNameString = urlPath + "?" + param;
            if (StringUtils.isBlank(param)) {
                urlNameString = urlPath;
            }
            log.info("sendGet - " + urlNameString);
            URL realUrl = new URL(urlNameString);
            connection = (HttpURLConnection) realUrl.openConnection();
            connection.setRequestProperty("accept", "*/*");
            connection.setRequestProperty("connection", "Keep-Alive");
            connection.setRequestProperty("user-agent", "Mozilla/4.0 (compatible; MSIE 6.0; Windows NT 5.1;SV1)");
            connection.setRequestProperty("Content-Type", "application/json");
            if (headers != null) {
                HttpURLConnection finalConnection = connection;
                headers.forEach((k, v) -> {
                    try {
                        finalConnection.setRequestProperty(k, v.toString());
                    } catch (Exception e) {
                        log.error(e.getMessage(), e);
                    }
                });
            }

            connection.setConnectTimeout(CONN_TIME_OUT);
            connection.setReadTimeout(READ_TIME_OUT);
            connection.connect();
            in = new BufferedReader(new InputStreamReader(connection.getInputStream()));
            String line;
            while ((line = in.readLine()) != null) {
                result.append(line);
            }
        } catch (Exception e) {
            log.error(e.getMessage(), e);
        } finally {
            IOUtils.close(in);
            IOUtils.close(connection);
        }
        return result.toString();
    }

    public static String sendPost(String urlPath, String param, JSONObject headers) {
        if (StringUtils.isBlank(urlPath)) {
            return "";
        }
        if (urlPath.startsWith("https")) {
            return HttpsUtils.sendPost(urlPath, param, headers);
        }
        OutputStreamWriter out = null;
        BufferedReader in = null;
        StringBuilder result = new StringBuilder();
        HttpURLConnection urlConnection = null;
        try {
            URL url = new URL(urlPath);
            log.info("sendPost - " + urlPath + ",JSON参数：" + param);
            urlConnection = (HttpURLConnection) url.openConnection();
            // 设置doOutput属性为true表示将使用此urlConnection写入数据
            urlConnection.setDoOutput(true);
            // 定义待写入数据的内容类型，我们设置为application/x-www-form-urlencoded类型
            urlConnection.setRequestProperty("Content-Type", "application/json");
            urlConnection.setRequestProperty("accept", "*/*");
            urlConnection.setRequestProperty("connection", "Keep-Alive");
            urlConnection.setRequestProperty("user-agent", "Mozilla/4.0 (compatible; MSIE 6.0; Windows NT 5.1;SV1)");
            if (headers != null) {
                HttpURLConnection finalConnection = urlConnection;
                headers.forEach((k, v) -> {
                    try {
                        finalConnection.setRequestProperty(k, v.toString());
                    } catch (Exception e) {
                        log.error(e.getMessage(), e);
                    }
                });
            }
            urlConnection.setConnectTimeout(CONN_TIME_OUT);
            urlConnection.setReadTimeout(READ_TIME_OUT);

            // 得到请求的输出流对象
            out = new OutputStreamWriter(urlConnection.getOutputStream());
            // 把数据写入请求的Body
            if (StringUtils.isNotBlank(param))
                out.write(param);
            out.flush();
            // 定义BufferedReader输入流来读取URL的响应
            in = new BufferedReader(new InputStreamReader(urlConnection.getInputStream()));
            String line;
            while ((line = in.readLine()) != null) {
                result.append(line);
            }
        } catch (Exception e) {
            log.error(e.getMessage(), e);
            return "";
        }
        // 使用finally块来关闭输出流、输入流
        finally {
            IOUtils.close(in);
            IOUtils.close(out);
            IOUtils.close(urlConnection);
        }
        return result.toString();
    }


    public static String sendPost(String url, String params, String token) {
        String body = "";

        // 创建httpclient对象
        CloseableHttpClient client = getHttpClient();
        // 创建post方式请求对象
        HttpPost httpPost = new HttpPost(url);
        // 设置连接超时时间2秒
        RequestConfig requestConfig = RequestConfig.custom().setSocketTimeout(5000)
                .setConnectTimeout(5000)
                .build();
        httpPost.setConfig(requestConfig);
        // 装填参数
        StringEntity s = new StringEntity(params, "utf-8");
        s.setContentEncoding(new BasicHeader(HTTP.CONTENT_TYPE, "application/json"));
        // 设置参数到请求对象中
        httpPost.setEntity(s);
        httpPost.setHeader("accept", "*/*");
        httpPost.setHeader("connection", "Keep-Alive");
        httpPost.setHeader("user-agent", "Mozilla/4.0 (compatible; MSIE 6.0; Windows NT 5.1;SV1)");
        httpPost.setHeader("Content-type", "application/json;charset=utf-8");
        // httpPost.setHeader("Authorization", "Bearer " + token);//如果需要token请修改传入自己的token以及Authorization
        httpPost.setHeader("contentType", "utf-8");
        httpPost.setHeader("Accept-Charset", "utf-8");
        httpPost.setHeader("cookie", "access_token=" + token);
        // httpPost.setHeader();
        // 执行请求操作，并拿到结果（同步阻塞）
        try (CloseableHttpResponse response = client.execute(httpPost)) {

            // 获取结果实体
            HttpEntity entity = response.getEntity();
            if (entity != null) {
                // 按指定编码转换结果实体为String类型
                body = EntityUtils.toString(entity, "utf-8");
            }
            EntityUtils.consume(entity);
            return body;
        } catch (Exception e) {
            log.error("调用post请求失败,原因为:{}", e.getMessage(), e);
        }
        return null;
    }

    public static int sendPostXml(String url, String params, String token) {
        String body = "";

        // 创建httpclient对象
        CloseableHttpClient client = getHttpClient();
        // 创建post方式请求对象
        HttpPost httpPost = new HttpPost(url);
        // 设置连接超时时间2秒
        RequestConfig requestConfig = RequestConfig.custom().setSocketTimeout(5000)
                .setConnectTimeout(5000)
                .build();
        httpPost.setConfig(requestConfig);
        // 装填参数
        StringEntity s = new StringEntity(params, "utf-8");
        // 设置参数到请求对象中
        httpPost.setEntity(s);
        httpPost.setHeader("Accept", "*/*");
        httpPost.setHeader("Connection", "Keep-Alive");
        httpPost.setHeader("Content-Type", "application/yang-data+xml");
        httpPost.setHeader("Authorization", token);//如果需要token请修改传入自己的token以及Authorization
        log.info("sendPost - " + url + ",JSON参数：" + params + ",token=" + token);
        // 执行请求操作，并拿到结果（同步阻塞）
        int statusCode = -1;
        try (CloseableHttpResponse response = client.execute(httpPost)) {
            statusCode = response.getStatusLine().getStatusCode();
            HttpEntity entity = response.getEntity();
            if (entity != null) {
                // 按指定编码转换结果实体为String类型
                body = EntityUtils.toString(entity, "utf-8");
            }
            EntityUtils.consume(entity);
            log.info("获取到的状态码为:{},ret={}", statusCode, body);
            return statusCode;
        } catch (Exception e) {
            log.error("调用post请求失败,原因为:{}", e.getMessage(), e);
        }
        return statusCode;
    }

    public static String sendGetXml(String url, String token) {
        HashMap<String, String> dataMap = new HashMap<>();
        // 创建httpclient对象
        CloseableHttpClient client = getHttpClient();
        // 创建post方式请求对象
        HttpGet httpPost = new HttpGet(url);
        // 设置连接超时时间2秒
        RequestConfig requestConfig = RequestConfig.custom().setSocketTimeout(5000)
                .setConnectTimeout(5000)
                .build();
        httpPost.setConfig(requestConfig);
        httpPost.setHeader("Accept", "*/*");
        httpPost.setHeader("Connection", "Keep-Alive");
        httpPost.setHeader("Content-Type", "application/yang-data+xml");
        httpPost.setHeader("Authorization", token);//如果需要token请修改传入自己的token以及Authorization
        log.info("sendGet - " + url + ",token=" + token);
        // 执行请求操作，并拿到结果（同步阻塞）
        try (CloseableHttpResponse response = client.execute(httpPost)) {
            HttpEntity entity = response.getEntity();
            String xml = "";
            if (entity != null) {
                // 按指定编码转换结果实体为String类型
                xml = EntityUtils.toString(entity, "utf-8");
            }
            EntityUtils.consume(entity);
            return xml;
        } catch (Exception e) {
            log.error("调用get请求失败,原因为:{}", e.getMessage(), e);
        }
        return null;
    }


    public static CloseableHttpClient getHttpClient() {
        try {
            System.setProperty("jdk.tls.allowUnsafeServerCertChange", "true");
            System.setProperty("sun.security.ssl.allowUnsafeRenegotiation", "true");
            System.setProperty("jdk.tls.client.protocols", "TLSv1,TLSv1.1,TLSv1.2");
            //使用 loadTrustMaterial() 方法实现一个信任策略，信任所有证书
            // 信任所有
            SSLContext sslContext = new SSLContextBuilder().loadTrustMaterial(null, (TrustStrategy) (chain, authType) -> true).build();
            //NoopHostnameVerifier类:  作为主机名验证工具，实质上关闭了主机名验证，它接受任何
            //有效的SSL会话并匹配到目标主机。
            HostnameVerifier hostnameVerifier = NoopHostnameVerifier.INSTANCE;
            SSLConnectionSocketFactory sslsf = new SSLConnectionSocketFactory(sslContext, hostnameVerifier);

            Registry<ConnectionSocketFactory> registry = RegistryBuilder.<ConnectionSocketFactory>create()
                    .register("http", new PlainConnectionSocketFactory())
                    .register("https", sslsf)
                    .build();
            PoolingHttpClientConnectionManager cm = new PoolingHttpClientConnectionManager(registry);
            cm.setMaxTotal(100);
            return HttpClients.custom()
                    .setSSLSocketFactory(sslsf)
                    .setDefaultCookieStore(new BasicCookieStore())
                    .setConnectionManager(cm).build();
        } catch (Exception e) {
            log.error(e.getMessage(), e);
        }
        return HttpClients.createDefault();
    }


    public static String sendPost(String url, String params, String encoding, String token) {
        String body = "";

        // 创建httpclient对象
        CloseableHttpClient client = getHttpClient();
        log.info(url + ",token:{}", token);
        // 创建post方式请求对象
        HttpPost httpPost = new HttpPost(url);
        // 设置连接超时时间2秒
        RequestConfig requestConfig = RequestConfig.custom().setSocketTimeout(5000)
                .setConnectTimeout(5000)
                .build();
        httpPost.setConfig(requestConfig);
        // 装填参数
        StringEntity s = new StringEntity(params, "utf-8");
        s.setContentEncoding(new BasicHeader(HTTP.CONTENT_TYPE, "application/json"));
        // 设置参数到请求对象中
        httpPost.setEntity(s);
        if (com.crc.common.utils.StringUtils.isNotEmpty(token)) {
            httpPost.setHeader("token", token);
        }
        httpPost.setHeader("Content-type", "application/json");
        httpPost.setHeader("User-Agent", "Mozilla/4.0 (compatible; MSIE 5.0; Windows NT; DigExt)");
        // 执行请求操作，并拿到结果（同步阻塞）
        CloseableHttpResponse response = null;
        try {
            response = client.execute(httpPost);
            // 获取结果实体
            HttpEntity entity = response.getEntity();
            if (entity != null) {
                // 按指定编码转换结果实体为String类型
                body = EntityUtils.toString(entity, encoding);
            }
            EntityUtils.consume(entity);
            log.info("block:{}", body);
            // 释放链接
            return body;
        } catch (Exception e) {
            log.error("调用post请求失败,原因为:{}", e.getMessage(), e);
        } finally {
            org.apache.commons.io.IOUtils.closeQuietly((InputStream) response);
        }
        return null;
    }


    public static String sendPostNew(String urlPath, Map<String, Object> params) {
        if (urlPath.startsWith("https")) {
            return sendSSLPost(urlPath, JSON.toJSONString(params), null);
        }
        OutputStreamWriter out = null;
        BufferedReader in = null;
        HttpURLConnection urlConnection = null;
        StringBuilder result = new StringBuilder();
        try {
            URL url = new URL(urlPath);
            log.info(urlPath);
            urlConnection = (HttpURLConnection) url.openConnection();
            // 设置doOutput属性为true表示将使用此urlConnection写入数据
            urlConnection.setDoOutput(true);
            // 定义待写入数据的内容类型，我们设置为application/x-www-form-urlencoded类型
            urlConnection.setRequestProperty("content-type", "application/x-www-form-urlencoded");
            // 得到请求的输出流对象
            out = new OutputStreamWriter(urlConnection.getOutputStream());
            // 把数据写入请求的Body
            String paras = JSON.toJSONString(params);
            System.out.println(url + "?" + paras);
            if (params != null && params.size() > 0)
                out.write(paras);
            out.write(paras);
            out.flush();
            // 定义BufferedReader输入流来读取URL的响应
            in = new BufferedReader(new InputStreamReader(urlConnection.getInputStream()));
            String line;
            while ((line = in.readLine()) != null) {
                result.append(line);
            }
        } catch (Exception e) {
            System.out.println("发送 POST 请求出现异常！" + urlPath);
            log.error(e.getMessage(), e);
            return "ERROR";
        }
        // 使用finally块来关闭输出流、输入流
        finally {
            org.apache.commons.io.IOUtils.closeQuietly(out);
            org.apache.commons.io.IOUtils.closeQuietly(in);
            try {
                urlConnection.disconnect();
            } catch (Exception e) {

            }
        }
        return result.toString();
    }


    /**
     * @param urlPath   对方地址
     * @param json      要传送的数据
     * @param headerMap
     * @return
     */
    public static String sendSSLPost(String urlPath, String json, Map<String, String> headerMap) {
        String result = "";
        //创建post方式请求对象
        HttpPost httpPost = new HttpPost(urlPath);
        log.info(urlPath);
        //创建httpclient对象
        try (CloseableHttpClient httpClient = getHttpClient()) {
            // 设置连接超时时间2秒
            RequestConfig requestConfig = RequestConfig.custom().setSocketTimeout(44000)
                    .setConnectTimeout(44000)
                    .build();
            if (headerMap != null) {
                headerMap.forEach(httpPost::setHeader);
            }
            httpPost.setConfig(requestConfig);
            BasicResponseHandler handler = new BasicResponseHandler();
            //设置请求格式
            StringEntity entity = new StringEntity(json, "utf-8");//解决中文乱码问题
            entity.setContentEncoding("UTF-8");
            entity.setContentType("application/json");
            httpPost.setEntity(entity);
            //执行POST请求
            result = httpClient.execute(httpPost, handler);
            return result;
        } catch (Exception e) {
            log.error(e.getMessage(), e);
        }
        //释放连接
        return result;
    }

    public static int sendPutXml(String url, String params, String token) {
        String body = "";
        // 创建httpclient对象
        CloseableHttpClient client = getHttpClient();
        // 创建post方式请求对象
        HttpPut httpPost = new HttpPut(url);
        // 设置连接超时时间2秒
        RequestConfig requestConfig = RequestConfig.custom().setSocketTimeout(50000)
                .setConnectTimeout(50000)
                .build();
        httpPost.setConfig(requestConfig);
        // 装填参数
        StringEntity s = new StringEntity(params, "utf-8");
        // 设置参数到请求对象中
        httpPost.setEntity(s);
        httpPost.setHeader("accept", "*/*");
        httpPost.setHeader("connection", "Keep-Alive");
        httpPost.setHeader("Content-Type", "application/yang-data+xml");
        httpPost.setHeader("Authorization", token);//如果需要token请修改传入自己的token以及Authorization
        httpPost.setHeader("Accept-Charset", "utf-8");
        log.info("sendPost - " + url + ",JSON参数：" + params + ",token=" + token);
        // 执行请求操作，并拿到结果（同步阻塞）
        int statusCode = -1;
        try (CloseableHttpResponse response = client.execute(httpPost)) {
            log.debug("获取到的报文为:{}", response);
            HttpEntity entity = response.getEntity();
            if (entity != null) {
                // 按指定编码转换结果实体为String类型
                body = EntityUtils.toString(entity, "utf-8");
            }
            EntityUtils.consume(entity);
            log.info("获取到的返回值为:{}", body);
            statusCode = response.getStatusLine().getStatusCode();
            log.info("获取到的状态码为:{}", statusCode);
            return statusCode;
        } catch (Exception e) {
            log.error("调用post请求失败,原因为:{}", e.getMessage(), e);
        }
        return statusCode;
    }

    private static class TrustAnyTrustManager implements X509TrustManager {
        @Override
        public void checkClientTrusted(X509Certificate[] chain, String authType) {
        }

        @Override
        public void checkServerTrusted(X509Certificate[] chain, String authType) {
        }

        @Override
        public X509Certificate[] getAcceptedIssuers() {
            return new X509Certificate[]{};
        }
    }

    private static class TrustAnyHostnameVerifier implements HostnameVerifier {
        @Override
        public boolean verify(String hostname, SSLSession session) {
            return true;
        }
    }

    // 设置 https 请求证书
    public static class miTM implements javax.net.ssl.TrustManager, javax.net.ssl.X509TrustManager {
        public java.security.cert.X509Certificate[] getAcceptedIssuers() {
            return null;
        }

        public boolean isServerTrusted(java.security.cert.X509Certificate[] certs) {
            return true;
        }

        public boolean isClientTrusted(java.security.cert.X509Certificate[] certs) {
            return true;
        }

        public void checkServerTrusted(java.security.cert.X509Certificate[] certs, String authType)
                throws java.security.cert.CertificateException {
            return;
        }

        public void checkClientTrusted(java.security.cert.X509Certificate[] certs, String authType)
                throws java.security.cert.CertificateException {
            return;
        }
    }


    /**
     * IP封堵专门方法
     * @param url
     * @param param
     * @return
     */
    public static String sendGetMarvalnet(String url, String param, String token) {
        if (url != null && url.toLowerCase().startsWith("https")) {
            return sendSSLGetMarvalnet(url, param, token);
        }
        StringBuilder result = new StringBuilder();
        BufferedReader in = null;
        HttpURLConnection connection = null;
        try {
            String urlNameString = url;
            if (StringUtils.isNotBlank(param)) {
                urlNameString = url + "?" + param;
            }
            log.info("sendGet - {}", urlNameString);
            URL realUrl = new URL(urlNameString);
            connection = (HttpURLConnection) realUrl.openConnection();
            connection.setRequestProperty("accept", "*/*");
            connection.setRequestProperty("connection", "Keep-Alive");
            connection.setRequestProperty("user-agent", "Mozilla/4.0 (compatible; MSIE 6.0; Windows NT 5.1;SV1)");
            connection.setRequestProperty("content-type", "application/json");
            connection.setRequestProperty("Cookie", token);
            connection.setRequestProperty("Referer", param);
            connection.setConnectTimeout(CONN_TIME_OUT);
            connection.setReadTimeout(READ_TIME_OUT);
            connection.connect();
            in = new BufferedReader(new InputStreamReader(connection.getInputStream()));
            String line;
            while ((line = in.readLine()) != null) {
                result.append(line);
            }
        } catch (ConnectException e) {
            log.error("调用HttpUtils.sendGet ConnectException, url=" + url, e);
        } catch (SocketTimeoutException e) {
            log.error("调用HttpUtils.sendGet SocketTimeoutException, url=" + url, e);
        } catch (IOException e) {
            log.error("调用HttpUtils.sendGet IOException, url=" + url, e);
        } catch (Exception e) {
            log.error("调用HttpsUtil.sendGet Exception, url=" + url, e);
        } finally {
            org.apache.commons.io.IOUtils.closeQuietly(in);
            try {
                connection.disconnect();
            } catch (Exception e) {
                log.error(e.getMessage(), e);
            }
        }
        return result.toString();
    }


    public static String sendSSLGetMarvalnet(String url, String param, String token) {
        StringBuilder result = new StringBuilder();
        BufferedReader in = null;
        HttpsURLConnection httpsConnection = null;
        try {
            // 创建SSLContext
            SSLContext sslContext = SSLContext.getInstance("SSL");
            sslContext.init(null, new TrustManager[]{new TrustAnyTrustManager()}, new java.security.SecureRandom());

            // 获取SSLSocketFactory对象
            SSLSocketFactory ssf = sslContext.getSocketFactory();
            HostnameVerifier HostnameVerifier = (var1, var2) -> true;
            String urlNameString = url + "?" + param;
            if (StringUtils.isBlank(param)) {
                urlNameString = url;
            }
            URL requestUrl = new URL(urlNameString);
            httpsConnection = (HttpsURLConnection) requestUrl.openConnection();
            httpsConnection.setDoOutput(false);
            httpsConnection.setDoInput(true);
            httpsConnection.setConnectTimeout(CONN_TIME_OUT);
            httpsConnection.setReadTimeout(READ_TIME_OUT);
            httpsConnection.setRequestProperty("Content-Type", "application/json;charset=UTF-8");
            httpsConnection.setRequestProperty("Charset", "UTF-8");
            httpsConnection.setRequestProperty("User-Agent", "Client identifier");
            httpsConnection.setRequestProperty("Cookie", token);
            httpsConnection.setRequestProperty("Referer", param);
            httpsConnection.setRequestMethod("GET");
            // 设置当前实例使用的SSLSoctetFactory
            httpsConnection.setSSLSocketFactory(ssf);
            httpsConnection.setHostnameVerifier(HostnameVerifier);
            httpsConnection.connect();
            in = new BufferedReader(new InputStreamReader(httpsConnection.getInputStream()));
            String line;
            while ((line = in.readLine()) != null) {
                result.append(line);
            }
        } catch (ConnectException e) {
            log.error("调用HttpUtils.sendGet ConnectException, url=" + url, e);
        } catch (SocketTimeoutException e) {
            log.error("调用HttpUtils.sendGet SocketTimeoutException, url=" + url, e);
        } catch (IOException e) {
            log.error("调用HttpUtils.sendGet IOException, url=" + url, e);
        } catch (Exception e) {
            log.error("调用HttpsUtil.sendGet Exception, url=" + url, e);
        } finally {
            try {
                if (in != null) {
                    in.close();
                }
            } catch (Exception ex) {
                log.error("调用in.close Exception, url=" + url, ex);
            }
            try {
                httpsConnection.disconnect();
            } catch (Exception e) {
                log.error(e.getMessage(), e);
            }
        }
        return result.toString();
    }


    public static String sendPostMarvalnet(String urlPath, String json, String token, String localIp) {
        String body = "";

        // 创建httpclient对象
        CloseableHttpClient httpClient = HttpClientUtils.getHttpClient();
        // 创建post方式请求对象
        HttpPost httpPost = new HttpPost(urlPath);
        // 设置连接超时时间2秒
        RequestConfig requestConfig = RequestConfig.custom().setSocketTimeout(5000)
                .setConnectTimeout(5000)
                .build();
        httpPost.setConfig(requestConfig);
        // 装填参数
        StringEntity s = new StringEntity(json, "utf-8");
        s.setContentEncoding(new BasicHeader(HTTP.CONTENT_TYPE, "application/json"));
        // 设置参数到请求对象中
        httpPost.setEntity(s);
        httpPost.setHeader("accept", "*/*");
        httpPost.setHeader("connection", "Keep-Alive");
        httpPost.setHeader("user-agent", "Mozilla/4.0 (compatible; MSIE 6.0; Windows NT 5.1;SV1)");
        httpPost.setHeader("Content-type", "application/json;charset=utf-8");
        // httpPost.setHeader("Authorization", "Bearer " + token);//如果需要token请修改传入自己的token以及Authorization
        httpPost.setHeader("contentType", "utf-8");
        httpPost.setHeader("Accept-Charset", "utf-8");
        httpPost.setHeader("Cookie", token);
        httpPost.setHeader("Referer", localIp);
        // httpPost.setHeader();
        // 执行请求操作，并拿到结果（同步阻塞）
        try (CloseableHttpResponse response = httpClient.execute(httpPost)) {

            // 获取结果实体
            HttpEntity entity = response.getEntity();
            if (entity != null) {
                // 按指定编码转换结果实体为String类型
                body = EntityUtils.toString(entity, "utf-8");
            }
            EntityUtils.consume(entity);
            return body;
        } catch (Exception e) {
            log.error("调用post请求失败,原因为:{}", e.getMessage(), e);
        }
        return null;
    }



}
