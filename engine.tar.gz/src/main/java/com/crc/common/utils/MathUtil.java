package com.crc.common.utils;

import org.apache.commons.lang3.StringUtils;

import java.text.NumberFormat;
import java.util.List;

/**
 * @author simba@onlying.cn
 * @date 2020/9/3 20:24
 */
public class MathUtil {

    public String percent(Long num1, Long num2) {
        NumberFormat numberFormat = NumberFormat.getInstance();
        numberFormat.setMaximumFractionDigits(2);
        if (num1.longValue() == 0) {
            return "0%";
        }
        String result = numberFormat.format((float) num1 / (float) num2 * 100) + "%";
        return result;

    }

    public String add(List<Object> values) {
        boolean isNumber = isNumber(values.get(0).toString());
        if (isNumber) {

            if (values.get(0).toString().indexOf(".") > 0) {
                Double sum = new Double(0.0);
                for (Object value : values) {
                    sum += Double.parseDouble(value.toString());
                }

                return String.valueOf(sum);
            } else {
                Long sum = new Long(0L);
                for (Object value : values) {
                    sum += Long.parseLong(value.toString());
                }
                return String.valueOf(sum);
            }
        }
        return "";
    }

    public boolean isNumber(String number) {
        int index = number.indexOf(".");
        if (index < 0) {
            return StringUtils.isNumeric(number);
        } else {
            String num1 = number.substring(0, index);
            String num2 = number.substring(index + 1);

            return StringUtils.isNumeric(num1) && StringUtils.isNumeric(num2);
        }
    }


}
