package com.crc.common.utils;

import org.apache.commons.lang3.StringUtils;

import java.util.LinkedList;
import java.util.List;

public class ListUtils {
    public static String getListToStr(List<String> list) {
        if (list != null) {
            int index = 1;
            StringBuffer sb = new StringBuffer();
            for (String s : list) {
                if (StringUtils.isNotBlank(s)) {
                    sb.append(String.format("%d. %s；", index, s));
                    index++;
                }
            }

            return sb.toString();
        }


        return "";
    }
}
