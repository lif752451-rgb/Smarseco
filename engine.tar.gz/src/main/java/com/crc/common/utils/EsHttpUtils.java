package com.crc.common.utils;

import com.crc.SpringbootApplication;
import com.crc.secface.config.ElasticsearchProperties;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.codec.binary.Base64;
import org.apache.commons.io.IOUtils;
import org.apache.commons.lang3.StringUtils;
import org.apache.http.HttpHeaders;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.net.HttpURLConnection;
import java.net.URL;
import java.nio.charset.StandardCharsets;

@Slf4j
public class EsHttpUtils {
    private static final int CONN_TIME_OUT = 20000;
    private static final int READ_TIME_OUT = 20000;

    /**
     * 向指定 URL 发送GET方法的请求
     *
     * @param url 发送请求的 URL
     * @return 所代表远程资源的响应结果
     */
    public static String sendSSLGet(ElasticsearchProperties elasticsearchProperties, String url, String json,String id) {
        StringBuilder result = new StringBuilder();
        if (url.contains("10.0.7.180") && "T".equalsIgnoreCase(SpringbootApplication.OP_CONFIG.getMode())) {
            return result.toString();
        }
        BufferedReader in = null;
        OutputStreamWriter out = null;
        HttpURLConnection connection = null;
        try {
            URL urlx = new URL(url);
            log.info("{} sendGet - {},dsl:{}", id,url, json);
            connection = (HttpURLConnection) urlx.openConnection();
            // 设置doOutput属性为true表示将使用此urlConnection写入数据
            connection.setDoOutput(true);
            String userName = elasticsearchProperties.getUserName();
            String password = elasticsearchProperties.getPassword();
            if (StringUtils.isNotBlank(userName) && StringUtils.isNotBlank(password)) {
                String auth = userName + ":" + password;
                byte[] encodedAuth = Base64.encodeBase64(auth.getBytes(StandardCharsets.US_ASCII));
                String authHeader = "Basic " + new String(encodedAuth);
                connection.setRequestProperty(HttpHeaders.AUTHORIZATION, authHeader);
                String proxyHeader = elasticsearchProperties.getProxyHeader();
                connection.setRequestProperty("X-Found-Cluster", proxyHeader);
            }
            connection.setRequestProperty("accept", "*/*");
            connection.setRequestProperty("connection", "Keep-Alive");
            connection.setRequestProperty("user-agent", "Mozilla/4.0 (compatible; MSIE 6.0; Windows NT 5.1;SV1)");
            connection.setRequestProperty("content-type", "application/json");
            connection.setConnectTimeout(CONN_TIME_OUT);
            connection.setReadTimeout(READ_TIME_OUT);
            // 得到请求的输出流对象
            out = new OutputStreamWriter(connection.getOutputStream());
            // 把数据写入请求的Body
            if (json != null)
                out.write(json);
            out.flush();
            connection.connect();
            in = new BufferedReader(new InputStreamReader(connection.getInputStream(), StandardCharsets.UTF_8));
            String line;
            while ((line = in.readLine()) != null) {
                result.append(line);
            }
        } catch (Exception e) {
            log.error("url=" + url + " " + e.getMessage(), e);
        } finally {
            IOUtils.closeQuietly(in);
            IOUtils.closeQuietly(out);
            try {
                if (connection != null)
                    connection.disconnect();
            } catch (Exception ignored) {

            }
        }
        return result.toString();
    }

    /**
     * 向指定 URL 发送GET方法的请求
     *
     * @param url 发送请求的 URL
     * @return 所代表远程资源的响应结果
     */
    public static String sendSSLGet(ElasticsearchProperties elasticsearchProperties, String url, String json) {
        return sendSSLGet(elasticsearchProperties, url, json, "");
    }
}
