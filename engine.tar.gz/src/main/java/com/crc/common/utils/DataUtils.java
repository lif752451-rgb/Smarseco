package com.crc.common.utils;


import cn.hutool.core.util.ReflectUtil;
import com.crc.common.constants.Constants;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;

import java.lang.reflect.Field;
import java.math.BigInteger;
import java.nio.charset.StandardCharsets;
import java.security.SecureRandom;
import java.sql.ResultSet;
import java.text.SimpleDateFormat;
import java.util.*;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

@Slf4j
public class DataUtils {
    /**
     * 比较 startIp2long<=ip2long && ip2long <=e
     *
     * @param startIp2long 开始 IP
     * @param ip2long      当前 IP
     * @param endIp2long   结束 IP
     * @return t/f
     */
    public static boolean isIpInSegment(BigInteger startIp2long, BigInteger ip2long, BigInteger endIp2long) {
        BigInteger a0 = new BigInteger("0");
        try {
            if (startIp2long == null || ip2long == null || endIp2long == null) {
                return false;
            }
            if (startIp2long.compareTo(a0) > 0 && compareBigInt(ip2long, startIp2long) > -1 && compareBigInt(endIp2long, ip2long) > -1) {
                return true;
            }
        } catch (Exception e) {
            log.error(e.getMessage(), e);
        }
        return false;
    }

    public static boolean bigTo0(BigInteger m1) {
        if (m1 == null) {
            return false;
        }
        try {
            BigInteger a0 = BigInteger.valueOf(0);
            return m1.compareTo(a0) > 0;
        } catch (Exception e) {
            return false;
        }

    }


    public static int compareBigInt(BigInteger m1, BigInteger m2) {
        if (m1 == null || m2 == null) {
            return -2;
        }
        try {
            BigInteger a0 = BigInteger.valueOf(0);
            if (m1.compareTo(a0) > 0 && m2.compareTo(a0) > 0) {
                return m1.compareTo(m2);//小于-1，等于0，大于 1
            } else {
                return -3;
            }
        } catch (Exception e) {
            return -4;
        }

    }
    public static String escapeSpecialChar(String keyword) {
        if (StringUtils.isNotBlank(keyword)) {
            if (keyword.contains("'")) {
                keyword = keyword.replace("'", "‘");
            }
        }

        return keyword;
    }


    public static int getRandom(int max, int min) {
        SecureRandom random = new SecureRandom();
        return random.nextInt(max) % (max - min + 1) + min;
    }

    public static String convertSpecialChar(String text) {
        String toStr = "";
        if (StringUtils.isNotEmpty(text)) {
            toStr = text.replaceAll(Constants.Symbol.LESS_THAN, Constants.Symbol.ENTITY_LESS_THAN)
                    .replaceAll(Constants.Symbol.GREATER_THAN, Constants.Symbol.ENTITY_GREATER_THAN);
        }
        return toStr;
    }

    /**
     * 实体类String类型 转换特殊字符 "&lt;"to"<" "&gt;"to">"
     *
     * @param t t
     */
    public static void convertSpecialChar(Object t) {
        Class<?> tClass = t.getClass();
        Field[] fields = ReflectUtil.getFields(tClass);
        Arrays.stream(fields).forEach(field -> {
            if (field.getGenericType().toString().equals("class java.lang.String")) {
                Object obj = ReflectUtil.getFieldValue(t, field);
                if (obj instanceof String) {
                    ReflectUtil.setFieldValue(t, field, convertSpecialChar(obj.toString()));
                }
            }
        });
    }

    public static char getCharAt(String string, int index) {
        if (index < 0) {
            return '\u0000';
        } else if (index > string.length()) {
            return '\u0000';
        }
        return string.charAt(index);
    }

    public static String getSubString(String string, int first, int end) {
        if (end <= first) {
            return "";
        }
        if (StringUtils.isBlank(string)) {
            return "";
        }
        if (string.length() < end) {
            return "";
        }
        if (first < 0) {
            return "";
        }
        return string.substring(first, end);
    }

    public static String getSubString(String string, int first) {
        if (StringUtils.isBlank(string)) {
            return "";
        }
        if (string.length() < first) {
            return "";
        }
        if (first < 0) {
            return "";
        }
        return string.substring(first);
    }

    /***
     * 判断 String 是否是 int
     *
     * @param str
     * @return
     */
    public static boolean isInteger(String str) {
        if (StringUtils.isBlank(str)) {
            //log.info("空内容为非数字");
            return false;
        }
        Pattern pattern = Pattern.compile("^[-\\+]?[\\d]*$");
        //if (!flag) {
        //log.info("内容：{},为非数字", str);
        //}
        return pattern.matcher(str).matches();
    }

    public static String getString(Map map, String filter) {
        if (StringUtils.isNotBlank(filter) && map != null) {
            Object o = map.get(filter);
            if (o != null && !"null".equals(o.toString())) {
                return o.toString();
            }
        }
        return "";
    }

    public static long getLong(Map map, String filter) {
        if (StringUtils.isNotBlank(filter) && map != null) {
            Object o = map.get(filter);
            if (o != null) {
                if (!isInteger(o.toString())) {
                    return 0;
                }
                try {
                    return Long.parseLong(o.toString());
                } catch (Exception ignored) {

                }
                return 0;
            }
        }
        return 0;
    }

    public static Date fromISODate(String time) {
        if (!time.matches("\\d{4}-\\d{2}-\\d{2}T\\d{2}:\\d{2}:\\d{2}.\\d{3}Z")) {
            return null;
        }
        time = time.replaceFirst("T", " ").replaceFirst(".\\d{3}Z", "");
        Date date = formatDate(time);
        // 1、取得本地时间：
        Calendar cal = Calendar.getInstance();
        cal.setTime(date);

        // 2、取得时间偏移量：
        int zoneOffset = cal.get(Calendar.ZONE_OFFSET);
        // 3、取得夏令时差：
        int dstOffset = cal.get(Calendar.DST_OFFSET);
        // 4、从本地时间里扣除这些差量，即可以取得UTC时间：
        cal.add(Calendar.MILLISECOND, (zoneOffset + dstOffset));
        return cal.getTime();
    }

    public static Date formatDate(String time) {
        SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
        try {
            return sdf.parse(time);
        } catch (Exception e) {
            return null;
        }
    }

    public static Date getDateX(Map<String, Object> object, String alarm_time) {
        String datestr = getString(object, alarm_time);
        if (datestr.contains("T")) {
            //2021-01-08T05:59:49.000Z
            return fromISODate(datestr);
        }
        Date date = null;
        if (StringUtils.isEmpty(datestr)) {
            date = new Date();
            return date;
        }
        SimpleDateFormat sdf = new SimpleDateFormat(DateUtils.DATE_FORMAT_STRING1);
        try {
            date = sdf.parse(datestr);
        } catch (Exception e) {
            log.error(e.getMessage(), e);
        }
        return date;
    }

    public static Date getDate(Map<String, String> object, String alarm_time) {
        String datestr = getString(object, alarm_time);
        if (datestr.contains("T")) {
            //2021-01-08T05:59:49.000Z
            return fromISODate(datestr);
        }
        Date date = null;
        if (StringUtils.isEmpty(datestr)) {
            date = new Date();
            return date;
        }
        SimpleDateFormat sdf = new SimpleDateFormat(DateUtils.DATE_FORMAT_STRING1);
        try {
            date = sdf.parse(datestr);
        } catch (Exception e) {
            log.error(e.getMessage(), e);
        }
        return date;
    }


    public static String getStr(ResultSet rs, String groupKeys2) {
        if (StringUtils.isBlank(groupKeys2) || rs == null)
            return "";
        try {
            return rs.getString(groupKeys2);
        } catch (Exception ignored) {

        }
        return "";
    }

    public static String getStr(Map rs, String groupKeys2) {
        if (StringUtils.isBlank(groupKeys2) || rs == null)
            return "";
        try {
            Object obj = rs.get(groupKeys2);
            if (obj != null) {
                return obj.toString();
            }
        } catch (Exception ignored) {

        }
        return "";
    }

    public static String getInt(ResultSet rs, String count) {
        if (StringUtils.isBlank(count) || rs == null)
            return 0 + "";
        try {
            return rs.getInt(count) + "";
        } catch (Exception ignored) {

        }
        return 0 + "";
    }

    public static int getInt(Map map, String fitler) {
        try {
            String count = getString(map, fitler);
            return Integer.parseInt(count);
        } catch (Exception ignored) {

        }
        return 0;
    }

    public static double getDouble(Map map, String fitler) {
        try {
            String count = getString(map, fitler);
            return Double.parseDouble(count);
        } catch (Exception ignored) {

        }
        return 0;
    }

    public static double getDouble(String count) {
        try {
            if (StringUtils.isBlank(count)) {
                return 0;
            }
            return Double.parseDouble(count);
        } catch (Exception ignored) {

        }
        return 0;
    }

    public static Long toLong(String count) {
        if (!isInteger(count)) {
            return 0L;
        }
        try {
            return Long.parseLong(count);
        } catch (Exception ignored) {

        }
        return -1L;
    }

    public static String[] getSplit(String str, String symbol) {
        String[] split = {};
        if (StringUtils.isNotBlank(str) && symbol != null) {
            split = str.split(symbol);
        }
        return split;
    }

    public static int getNum(String count) {
        if (!isInteger(count)) {
            return 0;
        }
        try {
            return (int) getDouble(count);
        } catch (Exception ignored) {

        }
        return 0;
    }

    public static int toInt(Object count) {
        if (count == null) {
            return 0;
        }
        try {
            return toInt(count.toString());
        } catch (Exception ignored) {

        }
        return 0;
    }

    public static int toInt(String strInt) {
        if (!isInteger(strInt)) {
            return 0;
        }
        try {
            return Integer.parseInt(strInt);
        } catch (Exception e) {

        }
        return 0;
    }

    public static int getLastIndex(String str, String c) {
        int index = -1;
        if (StringUtils.isNotBlank(str) && c != null) {
            index = str.lastIndexOf(c);
        }
        return index;
    }


    public static int getIndex(String str, String c) {
        int index = -1;
        if (StringUtils.isNotBlank(str) && c != null) {
            index = str.indexOf(c);
        }
        return index;
    }

    public static String getReplaceAll(String str1, String str2, String str3) {
        if (StringUtils.isBlank(str1) || StringUtils.isBlank(str2)) {
            return str1;
        }
        str3 = str3.replaceAll("\\$", "RDS_CHAR_DOLLAR");
        String s = "";
        if (StringUtils.isEmpty(str3) || "null".equals(str3)) {
            s = str1.replaceAll(str2, "");
        } else {
            if (str3.contains("\\")) {
                str3 = str3.replaceAll("\\\\","\\\\\\\\");
            }
            s = str1.replaceAll(str2, str3);
        }
        s = s.replaceAll("RDS_CHAR_DOLLAR", "\\$");
        return s;
    }

    public static final char UNDERLINE = '_';

    /**
     * 驼峰格式字符串转换为下划线格式字符串
     *
     * @param param
     * @return
     */
    public static String humpToLine(String param) {
        if (param == null || "".equals(param.trim())) {
            return "";
        }
        int len = param.length();
        StringBuilder sb = new StringBuilder(len);
        for (int i = 0; i < len; i++) {
            char c = param.charAt(i);
            if (Character.isUpperCase(c)) {
                sb.append(UNDERLINE);
                sb.append(Character.toLowerCase(c));
            } else {
                sb.append(c);
            }
        }
        return sb.toString();
    }

    public static boolean isNotEmpty(List list) {
        return list != null && list.size() > 0;
    }

    /**
     * 精确告警输出定义
     *
     * @param str
     * @return
     */
    public static List<String> replaceOutput(String str) {
        List<String> resultList = new ArrayList<>();
        if (StringUtils.isBlank(str)) {
            return resultList;
        }
        String pattern = "\\{+([^\\}]+)\\}+";
        Pattern r = Pattern.compile(pattern);
        Matcher m = r.matcher(str);
        while (m.find()) {
            String group = m.group(1);
            if (StringUtils.isNotEmpty(group)) {
                resultList.add(group);
            }
        }
        return resultList;
    }

    public static int getRandomNumber(int range) {
        SecureRandom r = new SecureRandom();
        return r.nextInt(range);
    }

    /**
     * 根据树路径获取对应节点
     *
     * @param str
     * @param level
     * @return
     */
    public static String getDeptTree(String str, int level) {
        if (StringUtils.isBlank(str)) {
            return str;
        } else {
            String[] tree = str.split("/");
            if (level < 2) {
                return tree[0];
            }
            return getArrayString(tree, level - 1);
        }
    }

    public static String getArrayString(String[] arr, int index) {
        if (arr == null || index < 0 || (arr.length - 1) < index)
            return getArrayString(arr, index - 1);

        return arr[index];
    }

    /**
     * 字符长度不能超过指定长度
     * @param str
     * @param maxLen 最小不能小于10
     * @return
     */
    public static String getShorter(String str,int maxLen){
        try {
            if (StringUtils.isBlank(str) || maxLen < 10) {
                return str;
            }
            if (str.length() <= maxLen) {
                return str;
            }
            return str.substring(0, maxLen) + "...";
        } catch (Exception ignored) {

        }
        return str;
    }

    public static boolean checkEmail(String email) {// 验证邮箱的正则表达式
        if (com.crc.common.utils.StringUtils.isBlank(email)) {
            return false;
        }
        if (email.contains("@") && email.contains(".")) {
            return email.lastIndexOf(".") > email.lastIndexOf("@");
        }
        return false;
    }

    public static int toNum(String s) {
        return toInt(s);
    }


    public static List<String> mapKeyToList(HashMap<String, String> map) {
        List<String> list = new ArrayList<>();
        if (map != null) {
            map.forEach((k,v)->{
                list.add(k);
            });
        }
        return list;
    }

    public static String cleanAgg(String s) {
        if (com.crc.common.utils.StringUtils.isBlank(s)) {
            return "";
        }
        return s.trim().replace("sterms#", "");
    }

    public static int getInt(String str) {
        if (StringUtils.isBlank(str)) {
            return 0;
        }
        if (!isInteger(str)) {
            return 0;
        }
        try {
            return Integer.parseInt(str);
        } catch (Exception ignored) {

        }
        return 0;
    }
}
