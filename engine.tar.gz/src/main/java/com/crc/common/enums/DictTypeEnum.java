package com.crc.common.enums;

/**
 * @Author shufengfeng
 * @Description 字典类型枚举类
 * @DateTime 2021/8/27 17:10
 */
public enum DictTypeEnum {

    /**
     * 用户性别
     */
    SYS_USER_SEX("sys_user_sex", "用户性别"),

    /**
     * 告警级别
     */
    ALARM_LEVEL("alarm_level", "告警级别"),

    /**
     * 攻击结果
     */
    EVENT_ATTACK_RESULT("event_attack_result", "攻击结果"),

    /**
     * 攻击手段
     */
    ATTACK_TYPE("attack_type", "攻击手段"),

    /**
     * 资产软件许可证
     */
    SOFTWARE_LICENSE_TYPE("software_license_type", "许可类型"),

    /**
     * 知识产权所属国
     */
    SOFTWARE_OWNER("software_owner", "知识产权所属国"),

    /**
     * 软件类型
     */
    SOFTWARE_TYPE("software_type", "软件类型"),

    /**
     * 资产
     */
    KEY_ASSET("asset_ip_level", "资产等级"),

    /**
     * 资产类型
     */
    ASSET_TYPE("asset_ip_type", "资产类型"),

    /**
     * 环境类型
     */
    ENVIRONMENT_TYPE("asset_ip_environment_type", "环境类型"),

    /**
     * 资产来源
     */
    ASSET_IP_SOURCE("asset_ip_source", "资产来源"),

    /**
     * 资产状态
     */
    OPERATING_STATUS("asset_ip_status", "资产状态"),

    /**
     * 等保定级
     */
    EQUAL_PROTECTION_LEVEL("equal_protection_level", "等保定级"),

    /**
     * 资源类型
     */
    SOURCE_TYPE("asset_ip_source_type", "资源类型"),

    /**
     * 网络区域
     */
    SEGMENT_AREA("segment_area", "网络区域"),

    /**
     * 告警设备
     */
    ALERT_SOURCE_WAY("alert_source_way", "告警设备"),

    /**
     * 系统默认是/否
     */
    SYS_YES_NO("sys_yes_no", "系统默认是/否"),

    /**
     * 安全评分
     */
    SAFETY_SCORE("asset_ip_safety_score", "安全评分"),

    /**
     * 个人信息量级
     */
    INFO_ORDER("asset_person_info_order", "个人信息量级"),

    /**
     * 资产信息_个人信息类型
     */
    ASSET_PERSON_INFO_TYPE("asset_person_info_type", "资产信息_个人信息类型"),

    /**
     * 互联网资产-数据来源
     */
    DATA_SOURCE("internet_asset_data_source", "数据来源"),

    /**
     * 风险等级
     */
    RISK_LEVEL("risk_level", "风险等级"),

    /**
     * 工单状态
     */
    ORDER_STATUS("order_status", "工单状态"),

    /**
     * 处置方式
     */
    RECTIFICATION_TYPE("rectification_type", "处置方式"),

    /**
     * 风险来源
     */
    RISK_AUTO_SOURCE("risk_auto_source", "风险来源"),

    /**
     * 资产全景-网络子区域
     */
    PANORAMIC_LABEL_SLOT("panoramic_label_slot", "资产全景-标签"),

    /**
     * 扫描引擎
     */
    CRON_SCAN_ENGINE("cron_scan_engine", "扫描引擎"),

    /**
     * 主动复查扫描
     */
    ACTIVE_BATCH_REVIEW_SOURCE("active_batch_review_source", "主动复查扫描源"),

    /**
     * 告警来源IP匹配规则
     */
    USER_IP_RULE("user_ip_rule", "告警来源IP匹配规则"),

    /**
     * 基础路径
     */
    BASE_PATH("base_path", "基础路径"),

    /**
     * STP基础路径
     */
    STP_BASE_PATH("stp_base_path", "STP基础路径"),

    /**
     * SSP基础路径
     */
    SSP_BASE_PATH("ssp_base_path", "SSP基础路径"),

    /**
     * SCP基础路径
     */
    SCP_BASE_PATH("scp_base_path", "SCP基础路径"),

    /**
     * 无流程角色配置
     */
    NO_PROCESS_ROLES("no_process_roles", "无流程角色配置"),

    /**
     * 告警模型
     */
    PERIOD_TYPE("period_type", "时间周期类型"),

    /**
     * 告警模型
     */
    ALARM_MODEL_DEVICENAME("rule_base", "设备名称"),

    /**
     * 数据源索引
     */
    ALARM_MODEL_ES_INDEX("alarm_model_es_index", "数据源索引"),

    /**
     * 排序字段
     */
    ALARM_MODEL_SORT_FIELD("alarm_model_sort_field", "排序字段"),

    /**
     * 模型类型
     */
    ALARM_MODEL_TYPE("alarm_model_type", "模型类型"),

    /**
     * ES数据源
     */
    ALARM_MODEL_ES_CONFIG("alarm_model_es_config", "ES数据源"),

    /**
     * 漏洞邮件通知
     */
    VULN_MAIL_URL("vuln_mail_url", "漏洞邮件通知"),

    /**
     * 邮件通知URL跳转
     */
    MAIL_URL("mail_url", "邮件通知URL跳转"),

    /**
     * 攻击链路
     */
    ATTACK_IP_CLASSIFY("attack_ip_classify", "攻击链路ip分类"),

    /**
     * 威胁情报信息
     */
    INTELLIGENCE_INFO("intelligence_info", "威胁情报信息"),

    /**
     * websocket
     */
    ALARM_HVV_WEBSOCKET("alarm_hvv_websocket", "websocket推送开关"),

    /**
     * IP资产列表_导出字段
     */
    ASSET_IP_EXPORT_EXCEL("asset_ip_export_excel", "IP资产列表_导出字段"),

    /**
     * 研判知识库_导出字段
     */
    KNOWLEDGE_JUDGE_EXPORT_EXCEL("knowledge_judge_export_excel", "研判知识库_导出字段"),

    /**
     * 处置建议库_导出字段
     */
    KNOWLEDGE_HANDLE_EXPORT_EXCEL("knowledge_handle_export_excel", "处置建议库_导出字段"),

    /**
     * 处置反馈指南_导出字段
     */
    KNOWLEDGE_FEEDBACK_EXPORT_EXCEL("knowledge_feedback_export_excel", "处置反馈指南_导出字段"),
    /**
     * 告警闭环_导出字段
     */
    ALARM_LOOP_EXPORT_EXCEL("alarm_loop_export_excel", "告警闭环_导出字段"),

    /**
     * 巡检类型
     */
    INSPECTION_ITEM_TYPE("inspection_item_type", "巡检类型"),

    /**
     * 巡检任务_导出字段
     */
    INSPECTION_TASK_EXPORT_EXCEL("inspection_task_export_excel", "巡检任务_导出字段"),

    /**
     * 漏洞管理-全部漏洞-主机漏洞-待推送-导出
     */
    VUL_ALL_HOST_WAIT_EXPORT_EXCEL("vul_all_host_wait_export_excel", "漏洞管理-全部漏洞-主机漏洞-待推送-导出"),

    /**
     * 漏洞管理-全部漏洞-主机漏洞-已推送-导出
     */
    VUL_ALL_HOST_DONE_EXPORT_EXCEL("vul_all_host_done_export_excel", "漏洞管理-全部漏洞-主机漏洞-已推送-导出"),

    /**
     * 漏洞管理-漏洞闭环-主机漏洞-导出
     */
    VUL_LOOP_HOST_EXPORT_EXCEL("vul_loop_host_export_excel", "漏洞管理-漏洞闭环-主机漏洞-导出"),

    /**
     * 漏洞管理-全部漏洞-WEB漏洞-待推送-导出
     */
    VUL_ALL_WEB_WAIT_EXPORT_EXCEL("vul_all_web_wait_export_excel", "漏洞管理-全部漏洞-WEB漏洞-待推送-导出"),

    /**
     * 漏洞管理-全部漏洞-WEB漏洞-已推送-导出
     */
    VUL_ALL_WEB_DONE_EXPORT_EXCEL("vul_all_web_done_export_excel", "漏洞管理-全部漏洞-WEB漏洞-已推送-导出"),

    /**
     * 漏洞管理-漏洞闭环-WEB漏洞-导出
     */
    VUL_LOOP_WEB_EXPORT_EXCEL("vul_loop_web_export_excel ", "漏洞管理-漏洞闭环-WEB漏洞-导出"),

    /**
     * 漏洞管理-漏洞闭环-弱口令漏洞-导出
     */
    VUL_LOOP_CODE_EXPORT_EXCEL("vul_loop_code_export_excel", "漏洞管理-漏洞闭环-弱口令漏洞-导出"),

    /**
     * 漏洞管理-全部漏洞-弱口令-待推送-导出
     */
    VUL_ALL_CODE_WAIT_EXPORT_EXCEL("vul_all_code_wait_export_excel", "漏洞管理-全部漏洞-弱口令-待推送-导出"),

    /**
     * 漏洞管理-全部漏洞-弱口令-已推送-导出
     */
    VUL_ALL_CODE_DONE_EXPORT_EXCEL("vul_all_code_done_export_excel", "漏洞管理-全部漏洞-弱口令-已推送-导出"),

    // 漏洞字典
    /**
     * 漏洞等级
     */
    VUL_LEVEL("vul_level", "漏洞等级"),

    /**
     * 修复影响
     */
    VUL_HOST_INFLUENCE("vul_host_influence", "修复影响"),

    /**
     * 企业微信推送
     */
    LOOP_WECOM_NOTICE("loop_Wecom_notice", "企业微信推送"),

    /**
     * 消息发送类别配置 qywx:企业微信 feishu:飞书 多个用英文逗号隔开
     */
    MSG_SEND_CONFIG("msg_send_config", "消息发送类别配置"),

    /**
     * 告警_企业微信URL
     */
    ALARM_WECOM_URL("alarm_WeCom_url", "告警_企业微信URL"),

    /**
     * 风险_企业微信URL
     */
    RISK_WECOM_URL("risk_WeCom_url", "风险_企业微信URL"),

    /**
     * 企业微信字典
     */
    QYWX_PUSH_AUTH("qywx_push_auth", "企业微信字典"),


    /**
     * 润工作字典
     */
    RUN_WORK_PUSH_AUTH("run_work_push_auth", "润工作字典"),

    /**
     * 润工作标题模板
     */
    RUN_WORK_SUBJECT_TEMPLATE("run_work_subject_template", "润工作标题模板"),

    /**
     * 企业微信标题模板
     */
    QYWX_SUBJECT_TEMPLATE("qywx_subject_template", "企业微信标题模板"),

    /**
     * 安全报告推送方式
     */
    SEC_REPORT_PUSH_WAY("sec_report_push_way", "安全报告推送方式"),

    /**
     * 攻击面-信息泄漏-类型
     */
    ASSET_ASM_INFO_LEAK_TYPE("asm_ilm_type", "攻击面_信息泄漏_类型"),

    /**
     * 互联网资产列表导出字典
     */
    ASM_IAM_EXPORT_EXCEL("asm_iam_export_excel", "互联网资产列表导出字典"),

    /**
     * 终端设备_系统架构
     */
    TERMINAL_SYS_ARCHITECTURE("terminal_sys_architecture", "终端设备_系统架构"),

    /**
     * 终端设备_数据来源
     */
    TERMINAL_DATA_SOURCE("terminal_data_source", "终端设备_数据来源"),

    /**
     * 终端设备_导出字段
     */
    TERMINAL_EQUIPMENT_EXPORT_EXCEL("terminal_equipment_export_excel", "终端设备_导出字段"),

    /**
     * 终端软件_导出字段
     */
    TERMINAL_SOFTWARE_EXPORT_EXCEL("terminal_software_export_excel", "终端软件_导出字段"),

    /**
     * 实战告警闭环_作战周期
     */
    COMBAT_FIGHT_PERIOD("combat_fight_period", "实战告警闭环_作战周期"),

    /**
     * 实战告警闭环_节点处理时限
     */
    COMBAT_TIME_LIMIT("combat_time_limit", "实战告警闭环_节点处理时限"),

    /**
     * 实战告警闭环_集团_导出字段
     */
    COMBAT_GROUP_EXPORT_EXCEL("combat_group_export_excel", "实战告警闭环_集团_导出字段"),

    /**
     * 实战告警闭环_租户_导出字段
     */
    COMBAT_TENANT_EXPORT_EXCEL("combat_tenant_export_excel", "实战告警闭环_租户_导出字段"),

    /**
     * SSP告警白名单导出字段
     */
    SSP_ALARM_WHITELIST_EXPORT_EXCEL("ssp_alarm_whitelist_export_excel", "SSP告警白名单导出字段"),

    /**
     * 双因子校验开关字典
     */
    GOOGLE_AUTH("google_auth", "双因子校验开关字典"),

    /**
     * 基线_数据来源
     */
    BASELINE_DATA_SOURCE("baseline_data_source", "基线_数据来源"),

    /**
     * 基线_风险等级
     */
    BASELINE_LEVEL("baseline_level", "基线_风险等级"),

    /**
     * 基线_检查项类别
     */
    BASELINE_TYPE("baseline_type", "基线_检查项类别"),

    /**
     * 基线_闭环_导出字段
     */
    BASELINE_LOOP_EXPORT_EXCEL("baseline_loop_export_excel", "基线_闭环_导出字段"),

    /**
     * 基线_闭环_导出字段
     */
    BASELINE_FIND_WAIT_EXPORT_EXCEL("baseline_find_wait_export_excel", "基线_待推送基线问题列表_导出字段"),

    /**
     * 基线_闭环_导出字段
     */
    BASELINE_FIND_DONE_EXPORT_EXCEL("baseline_find_done_export_excel", "基线_已推送基线问题列表_导出字段"),

    /**
     * 实战告警闭环_研判标签
     */
    COMBAT_JUDGE_TAG("combat_judge_tag", "实战告警闭环_研判标签"),

    /**
     * 资产维护接口人
     */
    ASSET_DEPT_DUTY_PERSON("asset_dept_duty_person", "资产维护接口人"),;

    /**
     * 名称
     */
    private String name;

    /**
     * 描述
     */
    private String desc;

    DictTypeEnum(String name, String desc) {
        this.name = name;
        this.desc = desc;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getDesc() {
        return desc;
    }

    public void setDesc(String desc) {
        this.desc = desc;
    }
}
