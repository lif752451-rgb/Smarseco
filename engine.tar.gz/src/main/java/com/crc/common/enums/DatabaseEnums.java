package com.crc.common.enums;

public enum DatabaseEnums {
    UNKOWN("UNKOWN", 0),
    MYSQL("MYSQL", 1),
    DaMeng("DaMeng", 2),
    YaShan("YaShan", 3),
    ;

    DatabaseEnums(String name, int code) {
        this.name = name;
        this.code = code;
    }

    //自定义列类型名称
    private String name;
    //自定义列类型编码
    private int code;

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public int getCode() {
        return code;
    }

    public void setCode(int code) {
        this.code = code;
    }
}
