package com.crc.common.paser;

import com.crc.common.utils.DataUtils;
import org.apache.commons.lang3.StringUtils;
import org.elasticsearch.index.query.BoolQueryBuilder;
import org.elasticsearch.index.query.QueryBuilders;
import org.elasticsearch.index.query.RangeQueryBuilder;

import java.util.ArrayList;
import java.util.List;

public class DslNode {
    private ExpressionNodeType type;
    private BoolQueryBuilder query;
    private int status;

    public static KqlResult createInQuery(String key, String value) {
        KqlResult ret = new KqlResult();
        ret.setCode(0);
        BoolQueryBuilder should = QueryBuilders.boolQuery();
        if (!StringUtils.isBlank(value)) {
            List<String> valList = new ArrayList<>();
            for (String val : value.split("#")) {
                if (StringUtils.isNotBlank(val)) {
                    valList.add(val);
                }
            }
            should.should(QueryBuilders.termsQuery(key, valList)).minimumShouldMatch(1);
            ret.setCode(1);
            ret.setQuery(should);
        }
        return ret;
    }


    public int getStatus() {
        return status;
    }

    public void setStatus(int status) {
        this.status = status;
    }

    public ExpressionNodeType getType() {
        return type;
    }

    public void setType(ExpressionNodeType type) {
        this.type = type;
    }

    public BoolQueryBuilder getQuery() {
        return query;
    }

    public void setQuery(BoolQueryBuilder query) {
        this.query = query;
    }

    public static DslNode createNode(ExpressionNodeType type, BoolQueryBuilder query) {
        DslNode dslNode = new DslNode();
        dslNode.setType(type);
        dslNode.setQuery(query);
        return dslNode;
    }


    public static KqlResult createShouldQuery(String key, String value) {
        KqlResult ret = new KqlResult();
        ret.setCode(0);
        BoolQueryBuilder should = QueryBuilders.boolQuery();
        if (!StringUtils.isBlank(value)) {
            should.should(QueryBuilders.matchPhraseQuery(key, value)).minimumShouldMatch(1);
            ret.setCode(1);
            ret.setQuery(should);
        }
        return ret;
    }


    public static KqlResult createRangeQuery(String key, String value, ExpressionNodeType type) {
        KqlResult ret = new KqlResult();
        ret.setCode(0);
        BoolQueryBuilder should = QueryBuilders.boolQuery();
        RangeQueryBuilder rangeQueryBuilder = QueryBuilders.rangeQuery(key);
        if (!StringUtils.isBlank(value)) {
            long data = DataUtils.toLong(value);
            if (type == ExpressionNodeType.GT) {
                rangeQueryBuilder.gt(data);
            } else if (type == ExpressionNodeType.GTOrEqual) {
                rangeQueryBuilder.gte(data);
            } else if (type == ExpressionNodeType.LT) {
                rangeQueryBuilder.lt(data);
            } else if (type == ExpressionNodeType.LTOrEqual) {
                rangeQueryBuilder.lte(data);
            }

            should.should(rangeQueryBuilder).minimumShouldMatch(1);
            ret.setCode(1);
            ret.setQuery(should);
        }
        return ret;
    }

    public static KqlResult createWildQuery(String key, String value) {
        BoolQueryBuilder should = QueryBuilders.boolQuery();
        KqlResult ret = new KqlResult();
        ret.setCode(0);
        if (!StringUtils.isBlank(value)) {
            should.should(QueryBuilders.wildcardQuery(key, value)).minimumShouldMatch(1);
            ret.setCode(1);
            ret.setQuery(should);
        }

        return ret;
    }
}
