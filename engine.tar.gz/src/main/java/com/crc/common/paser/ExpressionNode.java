package com.crc.common.paser;

import org.apache.commons.lang3.StringUtils;

/**
 * 存储表达式运算符或操作数的各个节点的类
 *
 * @项目名称: secface
 * @类名称: ExpressionNode
 * @类描述:
 * @创建人: 何景生
 * @创建时间: 2017年12月15日 上午9:50:50
 * @修改人: 何景生
 * @修改时间: 2017年12月15日 上午9:50:50
 * @修改备注:
 * @version: 1.0
 */
public class ExpressionNode {

    private String value;

    private ExpressionNodeType type;

    private int pri;

    private ExpressionNode unitaryNode;

    private Object numeric;

    /**
     * @param value 操作数或运算符
     */
    public ExpressionNode(String value) {
        this.value = value;
        this.type = parseNodeType(value);
        this.pri = getNodeTypePRI(this.type);
        this.numeric = null;
    }

    public Object getNumeric() {
        if (this.numeric == null) {

            if ((this.type == ExpressionNodeType.String)) {
                return this.value;
            }

            if (this.type != ExpressionNodeType.Numeric) {
                return 0;
            }
//                Double num = new Double(this.value);
//                if (this.unitaryNode != null && this.unitaryNode.type == ExpressionNodeType.Subtract) {
//                    num = 0 - num;
//                }
            //               this.numeric = num;
        }
        return numeric;
    }

    public void setNumeric(Object numeric) {
        this.numeric = numeric;
        this.value = this.numeric.toString();
    }

    /**
     * 设置或返回与当前节点相关联的一元操作符节点
     *
     * @param unitaryNode
     */
    public void setUnitaryNode(ExpressionNode unitaryNode) {
        this.unitaryNode = unitaryNode;
    }

    /**
     * 解析节点类型
     *
     * @param valueX
     * @return
     */
    private ExpressionNodeType parseNodeType(String valueX) {
        if (StringUtils.isEmpty(valueX)) {
            return ExpressionNodeType.Unknown;
        }
        String value = valueX.toLowerCase();
        switch (value) {
            case "(":
                return ExpressionNodeType.LParentheses;
            case ")":
                return ExpressionNodeType.RParentheses;
            case "and":
                return ExpressionNodeType.And;
            case "or":
                return ExpressionNodeType.Or;
            case "not":
                return ExpressionNodeType.Not;
            case ":":
                return ExpressionNodeType.Equal;
            case ">":
                return ExpressionNodeType.GT;
            case "<":
                return ExpressionNodeType.LT;
            case ">=":
            case "≥":
                return ExpressionNodeType.GTOrEqual;
            case "<=":
            case "≤":
                return ExpressionNodeType.LTOrEqual;

        }
        if (isNumerics(value)) {
            return ExpressionNodeType.Numeric;
        }
        if (value.contains("\"")) {
            return ExpressionNodeType.String;
        }
        return ExpressionNodeType.Unknown;
    }

    /**
     * 获取各节点类型的优先级
     *
     * @param nodeType
     * @return
     */
    private int getNodeTypePRI(ExpressionNodeType nodeType) {
        switch (nodeType) {
            case LParentheses:
            case RParentheses:
                return 9;
            // 逻辑非是一元操作符,所以其优先级较高
            case Not:
            case In:
                return 8;
            case Equal:
            case Unequal:
            case GT:
            case LT:
            case GTOrEqual:
            case LTOrEqual:
            case NotLike:
            case StartWith:
            case EndWith:
                return 3;
            case And:
                return 2;
            case Or:
                return 1;
            default:
                return 0;
        }

    }

    /**
     * 判断是否为数值
     *
     * @param op
     * @return
     */
    public boolean isNumerics(String op) {
        if(StringUtils.isBlank(op))
            return false;
        return op.matches("^[\\+\\-]?(0|[1-9]\\d*|[1-9]\\d*\\.\\d+|0\\.\\d+)");
    }

    /**
     * 判断是否为日期
     *
     * @param op
     * @return
     */
    public static boolean isDatetime(String op) {
        op = op.replace("\"", "").trim();
        return op.matches("\\d{4}\\-\\d{2}\\-\\d{2}(\\s\\d{2}\\:\\d{2}\\:\\d{2})?");
    }

    /**
     * 判断某个字符后是否需要更多的操作符
     *
     * @param c
     * @return
     */
    public boolean needMoreOperator(char c) {
        switch (c) {
            case '=':
            case '>':
            case ':':
            case '<':
            case '.': // 小数点
                return true;
        }
        // //数字则需要更多
        return Character.isDigit(c);
    }

    /**
     * 判断两个字符是否是同一类
     *
     * @param c1
     * @param c2
     * @return
     */
    public boolean IsCongener(char c1, char c2) {
        if ((c1 == '(') || (c2 == '(')) {
            return false;
        }
        if ((c1 == ')') || (c2 == ')')) {
            return false;
        }
        if ((c1 == '"') || (c2 == '"')) {
            return false;
        }
        return true;
        /*if (Character.isDigit(c1)) {
            // c1为数字,则c2也为数字
            return (Character.isDigit(c2));
        }
        return (!Character.isDigit(c2));*/
    }

    public boolean isAllNum(char c1, char c2) {
        if (Character.isDigit(c1)) {
            // c1为数字,则c2也为数字
            return (Character.isDigit(c2));
        }
        return (!Character.isDigit(c2));
    }

    /**
     * 判断某个字符是否是空白字符
     *
     * @param c
     * @return
     */
    public boolean IsWhileSpace(char c) {
        return c == ' ' || c == '\t';
    }

    public String getValue() {
        return value;
    }

    public void setValue(String value) {
        this.value = value;
    }

    public ExpressionNodeType getType() {
        return type;
    }

    public void setType(ExpressionNodeType type) {
        this.type = type;
    }

    public int getPri() {
        return pri;
    }

    public void setPri(int pri) {
        this.pri = pri;
    }

    public ExpressionNode getUnitaryNode() {
        return unitaryNode;
    }
}
