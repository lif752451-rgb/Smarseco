package com.crc.common.paser;

import com.alibaba.fastjson.JSON;
import com.crc.common.utils.DataUtils;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;

import java.util.HashMap;
import java.util.Map;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * 负责读取表达式生成ExpressionNode对象的类
 */
@Slf4j
public class ExpressionParser {

    // 当前分析的表达式
    private String expression;
    String modelId;

    private Map<String, String> dataMap = new HashMap<>();
    public HashMap<String, String> tmpMap = new HashMap<>();

    // 当前读取的位置
    private int position;

    public String getExpression() {
        return expression;
    }

    public String getModelId() {
        return modelId;
    }

    public void setModelId(String modelId) {
        this.modelId = modelId;
    }

    public void setExpression(String expression) {
        this.expression = expression;
    }

    public int getPosition() {
        return position;
    }

    public void setPosition(int position) {
        this.position = position;
    }

    public ExpressionParser(String modelId, String expression) {
        //this.expression = expression;
        this.position = 0;
        this.modelId = modelId;

        String tempX = expression.replace("\\\"", "@@");
        //System.out.println(tempX);
        String regex = "\"(.*?)\"";

        Pattern pattern = Pattern.compile(regex);
        Matcher matcher = pattern.matcher(tempX);
        int index = 0;
        while (matcher.find()) {
            String key = String.format("#%d#", index++);
            String data = matcher.group(1);
            tmpMap.put(key, data);
            /**
             * 建临时替换内容的原因如下：
             * 假设KQL语句为：
             * product.keyword : "绿盟TIP" and description.keyword : "C2主机" and threat_level.keyword : "5" and zlog_ori_msg : "ip"
             * 当检测出：zlog_ori_msg : "ip"时，那么我们会把  description.keyword  中的”ip“也进行替换
             * 导致KQL语句出错
             * 解决方案是：替换的时候进行内容判断，只能替换前边和后边为 ‘ ” ’引号的内容
             */
            String tempRegStr = "^\"" + data + "\"$";
            tempX = tempX.replace(tempRegStr, key);
        }


        String tempStr = tempX.replace(":", " ").replace("(", "").replace(")", "");
        //expression = expression.replace(">=","").replace("<=","").replace(">")
        dataMap = new HashMap<>();
        for (String data : tempStr.split(" ")) {
            if (StringUtils.isNotBlank(data)) {
                if (">=".equals(data) || "<=".equals(data) || ">".equals(data) || "<".equals(data)) {
                    continue;
                }
                dataMap.put(data.toLowerCase(), data);
            }
        }
        this.expression = tempX;
        //System.out.println("############");
        //System.out.println(expression);
        //System.out.println(JSON.toJSONString(tmpMap));
    }

    /**
     * 读取下一个表达式节点,如果读取失败则返回null
     *
     * @return
     */
    public ExpressionNode readNode() {
        ExpressionNode s = new ExpressionNode(null);
        boolean specialChar = false;
        //boolean spaceChar = false;
        // 空格的位置
        int whileSpacePos = -1;
        boolean flag = false;
        StringBuilder buffer = new StringBuilder();
        boolean fullKey = false;
        while (this.position < this.expression.length()) {
            char c = this.expression.charAt(this.position);

            char lastChar = DataUtils.getCharAt(this.expression, this.position - 1);
            if (c == '"' && lastChar != '\\') { //并且不是转义
                flag = !flag;
                if (!flag) {
                    this.position++;
                    buffer.append(c);
                    break;
                }
                if (buffer.length() != 0) {
                    break;
                }
            }
            if (flag) {
                this.position++;
                buffer.append(c);
            } else {
                if (s.IsWhileSpace(c)) {
                    if ((whileSpacePos >= 0) && ((this.position - whileSpacePos) > 1)) {
                        //throw new ExpressionException(
                        //        String.format("表达式\"%s\"在位置(%s)上的字符非法!", this.getExpression(), this.getPosition()));
                    }
                    if (buffer.length() == 0) {
                        whileSpacePos = -1;
                    } else {
                        whileSpacePos = this.position;
                    }
                    this.position++;
                    specialChar = true;
                    continue;
                }
                if (c == ':') {
                    specialChar = true;
                }

                if (dataMap.containsKey(buffer.toString().toLowerCase()) && specialChar) {
                    /**
                     * 这里加specialChar原因为：
                     * 如果kql为：src_ip:"10.0.197.177" and src_ip_type:"内网"
                     * 那么后面的src_ip_type由于包含了src_ip，那么导致了当遍历至src_ip时，
                     * 会因为dataMap包含了src_ip而跳出循环
                     * 一开始想直接用map移除key的方式，结果发现如果kql里面有多个相同运算符
                     * 那么会一次性讲相同的key全部移除，导致kql解析错误，所以暂用specialChar判断
                     */
                    fullKey = true;
                    break;//获取完整了一个字段Key 或 Value
                }
                /**
                 * 修改原因：
                 * 或条件后面的语句是为了：not age >= 10 这种情况出现bug，但是同时会影响到
                 * 类似：qw5abc.keyword : "123456" 这种格式
                 * 解决方案是：需要判断中间是否出现过空格，
                 * 如果没有：那么说明是同一个字符串
                 * 如果有：说明是两个字符串
                 */
                if (this.position > 0) {
                    char spaceChar = this.expression.charAt(this.position - 1);
                    if (buffer.length() == 0) {
                        this.position++;
                        buffer.append(c);
                    } else {
                        if (!s.IsCongener(c, buffer.charAt(buffer.length() - 1))) {
                            /**
                             * 如果是括号或者引号，则直接break
                             */
                            break;
                        }
                        if (!s.isAllNum(c, buffer.charAt(buffer.length() - 1))) {
                            if (spaceChar == ' ') {
                                break;
                            } else {
                                this.position++;
                                buffer.append(c);
                            }
                        } else {
                            this.position++;
                            buffer.append(c);
                        }
                    }
                } else {
                    this.position++;
                    buffer.append(c);
                }

            }
        }
        //log.info("buff={}", buffer);
        if (buffer.length() == 0) {
            return null;
        }
        //System.out.println(buffer);
        String nodeValue = buffer.toString();

        ExpressionNode node = new ExpressionNode(nodeValue);
        if (fullKey) {
            if ("not".equalsIgnoreCase(buffer.toString())) {
                node.setType(ExpressionNodeType.Not);
                node.setPri(8);
            } else if ("and".equalsIgnoreCase(buffer.toString())) {
                node.setType(ExpressionNodeType.And);
            } else if ("or".equalsIgnoreCase(buffer.toString())) {
                node.setType(ExpressionNodeType.Or);
            } else if (">=".equalsIgnoreCase(buffer.toString())) {
                node.setType(ExpressionNodeType.GTOrEqual);
            } else if ("<=".equalsIgnoreCase(buffer.toString())) {
                node.setType(ExpressionNodeType.LTOrEqual);
            } else if (">".equalsIgnoreCase(buffer.toString())) {
                node.setType(ExpressionNodeType.GT);
            } else if ("<".equalsIgnoreCase(buffer.toString())) {
                node.setType(ExpressionNodeType.LT);
            } else if ("in".equalsIgnoreCase(buffer.toString())) {
                node.setType(ExpressionNodeType.In);
                node.setPri(8);
            } else {
                if (node.isNumerics(buffer.toString())) {
                    node.setType(ExpressionNodeType.Numeric);
                } else
                    node.setType(ExpressionNodeType.String);
            }
        }
        if (node.getType() == ExpressionNodeType.Unknown) {
            log.error("{},错误KQL：{},node={}", this.getModelId(), this.getExpression(), JSON.toJSONString(node));
            throw new ExpressionException(this.expression + ",识别错误##，" + String.format("在位置%s上的字符\"%s\"非法!,buffer=%s",
                    this.getPosition() - node.getValue().length(), node.getValue(), buffer));
        }
        if (node.getValue().startsWith("\"")) {
            nodeValue = DataUtils.getSubString(nodeValue, 1, nodeValue.length() - 1);
            if (StringUtils.isNotBlank(nodeValue))
                node.setValue(nodeValue);
        }
        return node;
    }

}
