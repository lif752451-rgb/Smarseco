package com.crc.common.paser;

import com.crc.common.utils.EsUtils;
import org.elasticsearch.index.query.BoolQueryBuilder;

public class KqlResult {
    private int code;
    private String message;
    private String kql;
    private BoolQueryBuilder query;

    public String getKql() {
        return kql;
    }

    public void setKql(String kql) {
        this.kql = kql;
    }

    public String getMessage() {
        return message;
    }

    public void setMessage(String message) {
        this.message = message;
    }

    public int getCode() {
        return code;
    }

    public void setCode(int code) {
        this.code = code;
    }

    public BoolQueryBuilder getQuery() {
        return query;
    }

    public void setQuery(BoolQueryBuilder query) {
        this.query = query;
    }

    public void print() {
        if (this.query != null) {
            System.out.println(String.format("####KQL:%s", this.kql));
            if (!EsUtils.isBlankQuery(this.query)) {
                System.out.println("有效KQL");
            }
            System.out.println(this.query.toString());
        }
    }
}
