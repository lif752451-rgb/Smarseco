package com.crc.common.paser;

import com.alibaba.fastjson.JSONArray;
import com.alibaba.fastjson.JSONObject;
import com.crc.common.matcher.RuleParserV2;
import com.crc.common.utils.JsonUtils;
import com.crc.secface.entity.TbRule;
import org.apache.commons.lang3.StringUtils;
import org.elasticsearch.index.query.BoolQueryBuilder;

import java.util.ArrayList;
import java.util.List;

public class TreeParser {
    /**
     * 树规则到JSON业务模型转换为DSL
     *
     * @param treeJson
     * @return
     */
    public static BoolQueryBuilder toDsl(String treeJson) {
        JSONArray jsonArray = JsonUtils.parseArray(treeJson);
        if (jsonArray.size() > 0) {
            Object o = jsonArray.get(0);
            JSONObject jsonObject = JsonUtils.parse(o.toString());
            List<TbRule> ruleList = new ArrayList<>();
            if (jsonObject.containsKey("ruleName")) {
                TbRule rule = toRule(jsonObject, new TbRule());
                ruleList.add(rule);
                JSONArray array = jsonObject.getJSONArray("children");
                if (array != null && array.size() > 0) {
                    toRuleList(array, ruleList, rule);
                }
            }
            return RuleParserV2.parse(ruleList);
        } else {
            return null;
        }
    }

    private static void toRuleList(JSONArray arrayX, List<TbRule> ruleList, TbRule parent) {
        for (int i = 0; i < arrayX.size(); i++) {
            JSONObject jsonObject = arrayX.getJSONObject(i);
            TbRule newRule = toRule(jsonObject, parent);
            ruleList.add(newRule);
            JSONArray array = jsonObject.getJSONArray("children");
            if (array != null && array.size() > 0) {
                toRuleList(array, ruleList, newRule);
            }
        }
    }

    static Long parentId = -1L;

    private static TbRule toRule(JSONObject json, TbRule parent) {
        TbRule rule = new TbRule();
        rule.setPrevNodeViewId(JsonUtils.getInt(json, "prevNodeViewId"));
        //rule.setParentId(JsonUtils.getLong(json, "prevNodeViewId"));
        rule.setId(JsonUtils.getLong(json, "viewId"));
        rule.setRuleLabel(JsonUtils.getStr(json, "label"));
        rule.setRuleName(JsonUtils.getStr(json, "ruleName"));
        String ruleType = JsonUtils.getStr(json, "ruleType");
        String ruleTemp = JsonUtils.getStr(json, "rule");
        //rule.setRuleType(JsonUtils.getStr(json, "ruleType"));

        if (StringUtils.isBlank(ruleTemp)) {
            rule.setRuleType("4");
        } else {
            try {
                int i = Integer.parseInt(ruleType);
                rule.setRuleType(String.valueOf(i));
            } catch (Exception e) {
                switch (ruleType) {
                    case "AND":
                        rule.setRuleType("1");
                        break;
                    case "SHOULD":
                        rule.setRuleType("2");
                        break;
                    case "NOT":
                        rule.setRuleType("3");
                        break;
                }
            }
        }
        //rule.setRuleType(JsonUtils.getInt(json, "ruleType") + "");
        rule.setRule(ruleTemp);
        rule.setContent(JsonUtils.getStr(json, "content"));
        rule.setViewId(JsonUtils.getInt(json, "viewId"));
        rule.setAttributes(JsonUtils.getStr(json, "attributes"));
        String parentIds = "";
        boolean flag = false;
        if (rule.getPrevNodeViewId() == 0) {
            //规则树根节点
            parentIds = rule.getId() + "";
            parentId = rule.getViewId().longValue();
            flag = true;
        } else {
            if (parent != null && StringUtils.isNotBlank(parent.getParentIds()))
                parentIds = parent.getParentIds() + "," + rule.getId();
            else {
                parentIds = rule.getId() + "";
            }
        }
        rule.setParentIds(parentIds);
        rule.setParentId(parentId);
       /* if (flag) {
            rule.setParentId();
        } else {

        }*/
        return rule;
    }
}
