package com.crc.model;

import lombok.Getter;
import lombok.Setter;
import org.elasticsearch.search.aggregations.bucket.terms.TermsAggregationBuilder;

import java.util.LinkedHashMap;
import java.util.Map;

/**
 * @author jixiangqi
 * @date 2022/9/15
 */
@Getter
@Setter
public class EsEventParams {

    EsConditionTree tree;

    TermsAggregationBuilder lastAgg;

    LinkedHashMap<String, String> aggFields;

    StringBuffer treeSb = new StringBuffer();

    Map<String, Integer> countIndexMap;

}
