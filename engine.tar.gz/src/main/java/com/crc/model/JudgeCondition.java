package com.crc.model;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

/**
 * @author jixiangqi
 * @date 2022/9/6
 * 判断条件
 */
@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
public class JudgeCondition {

    /**
     * 统计类型
     * 0 计数
     * 1 唯一计数
     * 2 平均值
     * 3 最大值
     * 4 最小值
     */
    private int type;

    /**
     * 统计字段
     */
    private String censusFields;

    /**
     * 运算符
     */
    private String operator;

    /**
     * 数值
     */
    private int value;

}
