package com.crc.model;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

/**
 * @author jixiangqi
 * @date 2022/9/6
 * 聚合条件
 */
@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
public class AggCondition {

    /**
     * 聚合类型
     * 0 count
     */
    private int type;

    /**
     * 聚合字段
     */
    private String aggFields;

    /**
     * 数值
     */
    private int value;
}
