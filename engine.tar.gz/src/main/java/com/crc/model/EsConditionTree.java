package com.crc.model;

/**
 * @author jixiangqi
 * @date 2022/9/13
 *
 */
public class EsConditionTree {

    private String groupName;

    private EsConditionTree children;

    public String getGroupName() {
        return groupName;
    }

    public void setGroupName(String groupName) {
        this.groupName = groupName;
    }

    public EsConditionTree getChildren() {
        return children;
    }

    public void setChildren(EsConditionTree children) {
        this.children = children;
    }

    public EsConditionTree(String groupName, EsConditionTree children) {
        this.groupName = groupName;
        this.children = children;
    }

    public EsConditionTree() {
    }


}
