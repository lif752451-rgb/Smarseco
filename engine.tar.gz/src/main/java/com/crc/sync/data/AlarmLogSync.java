package com.crc.sync.data;

import com.alibaba.fastjson.JSONObject;
import com.crc.common.constants.LogConstants;
import com.crc.common.constants.LogConstantsX;
import com.crc.common.utils.*;
import com.crc.secface.config.ElasticsearchProperties;
import com.crc.secface.config.EsDataSource;
import com.crc.secface.config.GetSpringBean;
import com.crc.secface.entity.AlarmIp;
import com.crc.secface.entity.TbEventModel;
import com.crc.secface.es.EsSingleFactory;
import com.crc.secface.mapper.CommonMapper;
import com.crc.secface.mapper.TbEventModelMapper;
import com.crc.sync.send.SendEventExecutor;
import com.crc.sync.send.SendToScpInternetPublishApp;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.elasticsearch.action.search.SearchRequest;
import org.elasticsearch.action.search.SearchResponse;
import org.elasticsearch.client.RequestOptions;
import org.elasticsearch.client.RestHighLevelClient;
import org.elasticsearch.index.query.BoolQueryBuilder;
import org.elasticsearch.index.query.QueryBuilders;
import org.elasticsearch.index.query.RangeQueryBuilder;
import org.elasticsearch.search.SearchHit;
import org.elasticsearch.search.SearchHits;
import org.elasticsearch.search.builder.SearchSourceBuilder;

import java.util.*;

@Slf4j
public class AlarmLogSync extends Thread {

    @Override
    public void run() {
        MyTheadUtils.sleepBySec(60);
        log.info("告警原始日志");
        while (true) {
            try {
                logSync();
            } catch (Exception e) {
                log.error(e.getMessage(), e);
            }
            MyTheadUtils.sleepBySec(600);

        }
    }

    public void logSync() {
        log.info("告警原始日志开始........");

        try {
            CommonMapper commonMapper = GetSpringBean.getBean(CommonMapper.class);
            ElasticsearchProperties esConfig = GetSpringBean.getBean(ElasticsearchProperties.class);
            TbEventModelMapper modelMapper = GetSpringBean.getBean(TbEventModelMapper.class);
            commonMapper.exeSQL("update tb_alarm_ref_orilog set status = 0 where status is null");
            List<JSONObject> list = commonMapper.queryX("select * from tb_alarm_ref_orilog where status = 0 order by id desc limit 500");
            String sql = "select count(1) from tb_alarm_ori_log where id = '%s'";
            boolean good = false;
            for (JSONObject json : list) {
                String indexName = JsonUtils.getStr(json, "index_name");
                String createTime = JsonUtils.getStr(json, "create_time");
                String ids = JsonUtils.getStr(json, "ori_ids");
                String idx = JsonUtils.getStr(json, "id");
                String alarmId = JsonUtils.getStr(json, "alarm_id");
                String dataSource = JsonUtils.getStr(json, "data_source");
                if (StringUtils.isBlank(indexName)) {
                    indexName = "sec_all";
                }

                for(String id:ids.split(",")) {
                    String jsonStr = null;
                    try {
                        if (commonMapper.getCount(String.format(sql, id)) > 0) {
                            continue;
                        }
                        SearchSourceBuilder sourceBuilder = new SearchSourceBuilder();
                        BoolQueryBuilder boolQuery = buildQueryBuilder(createTime, id);

                        sourceBuilder.query(boolQuery);
                        sourceBuilder.size(1);
                        SearchResponse response = null;
                        String esIndex = indexName.split("-")[0] + "-*";

                        if (StringUtils.isNotBlank(dataSource)) {
                            //使用外部数据库
                            RestHighLevelClient client = null;
                            try {
                                Map<String, String> indexMap = modelMapper.getIndexAndSource(TbEventModel.createQuery(dataSource));
                                String indexNameStr = DataUtils.getString(indexMap, "indexRule");
                                SearchRequest searchRequest = new SearchRequest(indexNameStr);
                                searchRequest.source(sourceBuilder);
                                EsDataSource esDataSource = EsUtils.logSourceCheck(indexMap);
                                if(esDataSource != null) {
                                    client = EsSingleFactory.getInstance().getHighLevelClientHigh(esDataSource);
                                    response = client.search(searchRequest, RequestOptions.DEFAULT);
                                    SearchHits sh = response.getHits();
                                    for (SearchHit searchHit : sh) {
                                        jsonStr = searchHit.getSourceAsString();
                                        String newSql = "insert into tb_alarm_ori_log(id,msg)values('%s','%s')";
                                        SendEventExecutor.saveData(String.format(newSql, id, SimpleCodeTool.encryptBase64(jsonStr)));
                                        good = true;
                                    }
                                }
                            } catch (Exception e) {
                                log.error(e.getMessage(), e);
                            } finally {
                                EsSingleFactory.getInstance().close(client);
                            }
                        }
                        if(StringUtils.isBlank(jsonStr)) {
                            RestHighLevelClient client = null;
                            try {
                                SearchRequest searchRequest = new SearchRequest(esIndex);
                                searchRequest.source(sourceBuilder);
                                client = EsSingleFactory.getInstance().getHighLevelClient(esConfig);
                                response = client.search(searchRequest, RequestOptions.DEFAULT);
                                SearchHits sh = response.getHits();
                                for (SearchHit searchHit : sh) {
                                    jsonStr = searchHit.getSourceAsString();
                                    String newSql = "insert into tb_alarm_ori_log(id,msg)values('%s','%s')";
                                    SendEventExecutor.saveData(String.format(newSql,id, SimpleCodeTool.encryptBase64(jsonStr)));
                                    good = true;
                                }
                            } catch (Exception e) {
                                log.error(e.getMessage(), e);
                            } finally {
                                EsSingleFactory.getInstance().close(client);
                            }
                        }
                        JSONObject jsonObject = JsonUtils.parse(jsonStr);
                        if (StringUtils.isNotBlank(jsonStr) && jsonObject.size() > 0) {
                            AlarmIp alarmIp = new AlarmIp();
                            alarmIp.setAlarmId(alarmId);
                            alarmIp.setSrcIp(JsonUtils.getStr(jsonObject, LogConstantsX.SRC_IP));
                            alarmIp.setDestIp(JsonUtils.getStr(jsonObject, LogConstantsX.DEST_IP));
                            alarmIp.setUrl(JsonUtils.getStr(jsonObject, "url"));
                            alarmIp.setHost(JsonUtils.getStr(jsonObject, "host"));
                            SendToScpInternetPublishApp.magicQueue.offer(alarmIp);
                        }
                    } catch (Exception e) {
                        log.error("告警原始日志同步异常:{}", e.getMessage(), e);
                    }
                }
                log.info("已经同步日志={},flag={}",alarmId,good);
                commonMapper.exeSQL("update tb_alarm_ref_orilog set status = 1 where id=" + idx);
            }
        } catch (Exception e) {
            log.error("告警原始日志同步异常:{}",e.getMessage(), e);
        }
    }

    public BoolQueryBuilder buildQueryBuilder(String createTime, String id) {
        BoolQueryBuilder boolBuilder = QueryBuilders.boolQuery();
        BoolQueryBuilder should = QueryBuilders.boolQuery();
        should.should(QueryBuilders.matchPhraseQuery("_id", id));
        Date date = DateUtils.parseDate(createTime,DateUtils.DATE_FORMAT_STRING1);
        Calendar calendar = new GregorianCalendar();
        calendar.setTime(date);
        // 把日期往后增加一天,整数  往后推,负数往前移动
        calendar.add(Calendar.DAY_OF_MONTH, 1);
        calendar.setTime(date);
        // 这个时间就是日期往后推一天的结果
        Date endDate = calendar.getTime();
        calendar.add(Calendar.DAY_OF_MONTH, -2);
        Date startDate = calendar.getTime();
        RangeQueryBuilder rangeQueryBuilder = QueryBuilders.rangeQuery(LogConstants.SPARK_TIME_TAG);
        rangeQueryBuilder.gt(DateUtils.getSparkTime(startDate));
        rangeQueryBuilder.lte(DateUtils.getSparkTime(endDate));
        boolBuilder.filter(rangeQueryBuilder);
        boolBuilder.filter(should);
        return boolBuilder;
    }
}
