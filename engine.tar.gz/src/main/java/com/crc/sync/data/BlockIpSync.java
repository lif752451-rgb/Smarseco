package com.crc.sync.data;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;
import com.baomidou.mybatisplus.core.toolkit.StringUtils;
import com.crc.common.utils.*;
import com.crc.secface.config.GetSpringBean;
import com.crc.secface.config.SyncSecConfig;
import com.crc.secface.entity.SysDictData;
import com.crc.secface.entity.TbRiskIp;
import com.crc.secface.exception.CustomException;
import com.crc.secface.mapper.RiskIpMapper;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.HashMap;
import java.util.List;

/**
 * 下发封堵IP
 */
public class BlockIpSync extends Thread {
    private static final Logger logger = LoggerFactory.getLogger(BlockIpSync.class);

    @Override
    public void run() {
        logger.info("封堵IP下发同步");
        MyTheadUtils.sleepBySec(10);
        while (true) {
            if (SyncSecConfig.isEnable("block_ip_enable")) {
                try {
                    blockIpSync();
                } catch (Exception e) {
                    logger.error(e.getMessage(), e);
                }
            }
            MyTheadUtils.sleepBySec(10);

        }
    }

    public void blockIpSync() {
        RiskIpMapper riskIpMapper = GetSpringBean.getBean(RiskIpMapper.class);
        try {
            List<TbRiskIp> blockList = riskIpMapper.getAllBlockingList();
            if (blockList != null) {
                for (TbRiskIp riskIp : blockList) {
                    try {
                        if ("1".equals(riskIp.getType())) {
                            logger.info("准备封堵{}", riskIp.getIp());
                            blockIp(riskIp);
                        } else if ("2".equals(riskIp.getType())) {
                            logger.info("准备解封{}", riskIp.getIp());
                            unBlockIp(riskIp);
                        }
                        riskIpMapper.updateBlockStatus(riskIp.getId());
                    } catch (Exception e) {
                        logger.error(e.getMessage(), e);
                    }
                }
            }
        } catch (Exception e) {
            logger.error("同步风险封堵IP异常:{}", e.getMessage(), e);
        }
    }

    private void blockIp(TbRiskIp riskIp) {
        try {
/**
 * def ban_public_ip(ip_list,remark,expire_time):
 *     url = "http://10.200.0.152:12555/FireWall/publicGenerateConfig"
 *     headers = {'Content-Type': 'application/json'}
 *     data = json.dumps({"ip_list":ip_list, "remark":remark, "id":"123", "expire_time":expire_time})
 *     res = requests.post(url=url,headers=headers,data=data)
 *     print res.text
 *
 * ip_list = [
 *     "107.151.112.13",
 * ]
 * ban_public_ip(ip_list,"remark","2020-10-31") # expire_time, remark目前没有作用
 */
            List<String> ips = IpUtils.getIps(riskIp.getIp());
            if (ips.size() < 1) {
                throw new CustomException("ip参数格式不正确", 601);
            }
            List<SysDictData> list = DictUtil.getDict("block_ip_api_url");
            String apiUrl = "";
            String remark = "";
            if (list != null && list.size() > 0) {
                apiUrl = list.get(0).getDictValue();
                remark = list.get(0).getRemark();
            }
            if (StringUtils.isBlank(apiUrl)) {
                throw new CustomException("未配置IP封堵URL，字典【block_ip_api_url】", 601);
            }
            JSONObject json = new JSONObject();
            json.put("id", System.currentTimeMillis());
            json.put("remark", "STP下发IP封堵");
            json.put("ip_list", ips);
            logger.info(apiUrl + "-》封堵IP:" + json.toJSONString());
            if (riskIp.getEndTime() != null) {
                json.put("expire_time", riskIp.getEndTime());
            } else {
                //默认封堵一天
                json.put("expire_time", DateUtils.getDate(1));
            }
            HashMap<String, String> headerMap = new HashMap<>();
            if (StringUtils.isNotBlank(remark)) {
                JSONObject jsonObject = JsonUtils.parse(remark);
                jsonObject.forEach((k, v) -> {
                    try {
                        headerMap.put(k, v.toString());
                    } catch (Exception e) {
                        logger.error(e.getMessage(), e);
                    }
                });
            }
            String ret = HttpUtils.sendPost(apiUrl, json.toJSONString(), headerMap);
            logger.info("封堵IP=" + riskIp.getIp() + "，返回=" + ret);
        } catch (Exception e) {
            logger.error(e.getMessage(), e);
        }
    }

    private void unBlockIp(TbRiskIp riskIp) {
        try {
            /**
             * def unseal_public_ip(ip_list):
             *     url = "http://10.200.0.152:12555/FireWall/unsealPublicIP"
             *     headers = {'Content-Type': 'application/json'}
             *     data = json.dumps({"ip_list":ip_list})
             *     res = requests.post(url=url,headers=headers,data=data)
             *     print res.text
             */
            List<String> ips = IpUtils.getIps(riskIp.getIp());
            if (ips.size() < 1) {
                throw new CustomException("ip参数格式不正确", 601);
            }
            List<SysDictData> list = DictUtil.getDict("unblock_ip_api_url");
            String apiUrl = "";
            String remark = "";
            if (list != null && list.size() > 0) {
                apiUrl = list.get(0).getDictValue();
                remark = list.get(0).getRemark();
            }
            if (StringUtils.isBlank(apiUrl)) {
                throw new CustomException("未配置IP解封URL，字典【unblock_ip_api_url】", 601);
            }
            JSONObject json = new JSONObject();
            json.put("ip_list", ips);
            logger.info(apiUrl + "解封IP:" + JSON.toJSONString(ips));
            HashMap<String, String> headerMap = new HashMap<>();
            if (StringUtils.isNotBlank(remark)) {
                JSONObject jsonObject = JsonUtils.parse(remark);
                jsonObject.forEach((k, v) -> {
                    try {
                        headerMap.put(k, v.toString());
                    } catch (Exception e) {
                        logger.error(e.getMessage(), e);
                    }
                });
            }
            String ret = HttpUtils.sendPost(apiUrl, json.toJSONString(), headerMap);
            logger.info("解封IP=" + riskIp.getIp() + "，返回=" + ret);
        } catch (Exception e) {
            logger.error(e.getMessage(), e);
        }
    }
}
