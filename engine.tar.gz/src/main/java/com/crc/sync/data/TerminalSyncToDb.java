package com.crc.sync.data;

import com.alibaba.fastjson.JSONObject;
import com.crc.common.constants.LogConstants;
import com.crc.common.utils.IpUtils;
import com.crc.common.utils.JsonUtils;
import com.crc.common.utils.MyTheadUtils;
import com.crc.secface.config.ElasticsearchProperties;
import com.crc.secface.config.GetSpringBean;
import com.crc.secface.config.SyncSecConfig;
import com.crc.secface.entity.TbTerminalSoftwareInstall;
import com.crc.secface.es.EsSingleFactory;
import com.crc.secface.mapper.CommonMapper;
import com.crc.secface.mapper.TbTerminalSoftwareInstallMapper;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.elasticsearch.action.search.SearchRequest;
import org.elasticsearch.action.search.SearchResponse;
import org.elasticsearch.client.RequestOptions;
import org.elasticsearch.client.RestHighLevelClient;
import org.elasticsearch.index.query.BoolQueryBuilder;
import org.elasticsearch.index.query.QueryBuilders;
import org.elasticsearch.search.SearchHit;
import org.elasticsearch.search.SearchHits;
import org.elasticsearch.search.builder.SearchSourceBuilder;
import org.elasticsearch.search.sort.FieldSortBuilder;
import org.elasticsearch.search.sort.SortOrder;

@Slf4j
public class TerminalSyncToDb extends Thread {
    @Override
    public void run() {
        while (true) {
            MyTheadUtils.sleepBySec(30);
            try {
                if (SyncSecConfig.isEnable("ues_terminal_sync")) {
//                    clean();
                    sync();
                }
            } catch (Exception e) {
                log.error(e.getMessage(), e);
            }
            MyTheadUtils.sleepBySec(60);
        }

    }

    private void clean() {
        try {
            CommonMapper commonMapper = GetSpringBean.getBean(CommonMapper.class);
            commonMapper.exeSQL("DELETE c1\n" +
                    "FROM tb_terminal_software_install c1 \n" +
                    "JOIN (\n" +
                    "    SELECT str_dev_ip, MAX(id) AS max_id \n" +
                    "    FROM tb_terminal_software_install \n" +
                    "    GROUP BY str_dev_ip \n" +
                    "    ) c2 ON c1.str_dev_ip = c2.str_dev_ip AND c1.id < c2.max_id");
        } catch (Exception e) {
            log.error(e.getMessage(),e);
        }
    }

    public void sync() {
        SearchSourceBuilder sourceBuilder = new SearchSourceBuilder();
        sourceBuilder.size(2000);
        sourceBuilder.sort(new FieldSortBuilder(LogConstants.SPARK_TIME_TAG).order(SortOrder.DESC));
        ElasticsearchProperties esProperty = GetSpringBean.getBean(ElasticsearchProperties.class);
        RestHighLevelClient restHighLevelClient = EsSingleFactory.getInstance().getHighLevelClient(esProperty);
        TbTerminalSoftwareInstallMapper tbTerminalSoftwareInstallMapper = GetSpringBean.getBean(TbTerminalSoftwareInstallMapper.class);
        try {

            BoolQueryBuilder boolBuilder = QueryBuilders.boolQuery();
            boolBuilder.must(QueryBuilders.matchPhraseQuery("product.keyword", "慧盾UES"));
            boolBuilder.must(QueryBuilders.wildcardQuery("src_ip", "10.*"));
            boolBuilder.must(QueryBuilders.existsQuery("op_name"));
            boolBuilder.mustNot(QueryBuilders.matchPhraseQuery("op_name", ""));
            sourceBuilder.query(boolBuilder);
            SearchRequest searchRequest = new SearchRequest("sec_all-*");
            searchRequest.source(sourceBuilder);
            SearchResponse response = restHighLevelClient.search(searchRequest, RequestOptions.DEFAULT);
            SearchHits sh = response.getHits();
            log.info("发现终端{}",sh.getHits().length);
            for (SearchHit s : sh) {
                JSONObject client = JsonUtils.parse(s.getSourceAsString());
                String ip = null;
                if (client != null) {
                    String GroupName = JsonUtils.getStr(client, "GroupName");
                    String User = JsonUtils.getStr(client, "op_name");
                    String Name = JsonUtils.getStr(client, "Name");//hostname
                    String Mac = JsonUtils.getStr(client, "Mac");
                    if (StringUtils.isBlank(Mac)) {
                        Mac = JsonUtils.getStr(client, "mac");
                    }
                    if (StringUtils.isBlank(Mac)) {
                        Mac = JsonUtils.getStr(client, "host_mac");
                    }
                    if (StringUtils.isBlank(Name)) {
                        Name = JsonUtils.getStr(client, "host_name");
                    }
                    if (StringUtils.isBlank(GroupName)) {
                        GroupName = JsonUtils.getStr(client, "org_name");
                    }
                    GroupName = GroupName.replace("全网终端.账号树.华润集团UD.华润集团.", "");
                    StringUtils.isBlank(ip);
                    ip = JsonUtils.getStr(client, "src_ip");
                    if (StringUtils.isBlank(User)) {
                        User = JsonUtils.getStr(client, "User");
                    }
                    String Guid = JsonUtils.getStr(client, "Guid");
                    if (StringUtils.isBlank(Guid)) {
                        Guid = JsonUtils.getStr(client, "id");
                    }

                    TbTerminalSoftwareInstall terminal = new TbTerminalSoftwareInstall();
                    terminal.setStrDevIp(ip);
                    terminal.setStrDevName(Name);
                    terminal.setStrUserDes(User);
                    terminal.setStrUserName(User);
                    if (StringUtils.isBlank(terminal.getStrUserName()) || IpUtils.isIp(terminal.getStrUserName()) || terminal.getStrUserName().contains(":")) {
                        continue;
                    }
                    terminal.setStrRoleName(GroupName);
                    terminal.setStrMac(Mac);
                    terminal.setUidRoleId(Guid);
                    terminal.setUidDevRecordId(Guid);
                    TbTerminalSoftwareInstall tmp = tbTerminalSoftwareInstallMapper.selectTbTerminalSoftwareInstallByIp(ip);
                    if (tmp != null) {
                        terminal.setId(tmp.getId());
                        tbTerminalSoftwareInstallMapper.updateTbTerminalSoftwareInstall(terminal);
                    } else {
                        tbTerminalSoftwareInstallMapper.insertTbTerminalSoftwareInstall(terminal);
                    }
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            EsSingleFactory.getInstance().close(restHighLevelClient);
        }
    }
}

