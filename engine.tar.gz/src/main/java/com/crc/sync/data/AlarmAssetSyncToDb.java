package com.crc.sync.data;

import cn.hutool.core.collection.CollUtil;
import com.crc.common.utils.*;
import com.crc.secface.config.GetSpringBean;
import com.crc.secface.entity.*;
import com.crc.secface.es.ConfBuzziMySql;
import com.crc.secface.mapper.CommonMapper;
import com.crc.secface.mapper.SeverAssetTypeMapper;
import com.crc.secface.mapper.SysDeptMapper;
import com.crc.secface.mapper.TbAssetMapper;
import com.crc.secface.service.AssetRecordService;
import com.crc.secface.service.MailService;
import com.crc.sync.net.AlarmAssetSegmentLoad;
import com.crc.sync.net.NewSegmentLoad;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;

import java.util.*;
import java.util.concurrent.ArrayBlockingQueue;
import java.util.stream.Collectors;

import static com.crc.common.constants.Constants.Symbol.COMMA;
import static com.crc.common.constants.Constants.Symbol.SLASH;
import static com.crc.common.constants.DictTypeEnum.*;
import static com.crc.common.constants.StatusEnum.NO;

@Slf4j
public class AlarmAssetSyncToDb extends Thread {
    public static ArrayBlockingQueue<AlarmIp> magicQueue = new ArrayBlockingQueue<>(5000);
    public static final int SSP_CMDB = 200;//SSP

    @Override
    public void run() {
        log.info("新版本安全告警资产识别。。。。");
        while (true) {
            if (magicQueue.isEmpty()) {
                MyTheadUtils.sleep(20);
            } else {
                while (!magicQueue.isEmpty()) {
                    try {
                        AlarmIp flowData = magicQueue.poll();
                        sync(flowData);
                    } catch (Exception e) {
                        log.error(e.getMessage(), e);
                    }
                    MyTheadUtils.sleep(20);
                }
            }
        }

    }

    public void sync(AlarmIp alarmIp) {
        List<String> ipList = IpUtils.getIps(alarmIp.getSrcIp());
        //ipList.addAll(IpUtils.getIps(alarmIp.getDestIp()));
        if (ipList.size() < 1) {
            return;
        }
        HashMap<String, String> ipMap = new HashMap<>();
        for (String ip : ipList) {
            ipMap.put(ip, ip);
        }
        log.info("{},识别告警资产 IP:{}", alarmIp.getModelId(), String.join(",", DataUtils.mapKeyToList(ipMap)));
        TbAssetMapper assetMapper = GetSpringBean.getBean(TbAssetMapper.class);
        CommonMapper commonMapper = GetSpringBean.getBean(CommonMapper.class);
        AssetRecordService assetRecordService = GetSpringBean.getBean(AssetRecordService.class);
        List<SysDictData> mailUserList = DictUtil.getDict("asset_dept_duty_person");
        List<SysDictData> keyAssetList = DictUtil.getDict("asset_ip_level");
        List<SysDictData> environmentTypeList = DictUtil.getDict(ENVIRONMENT_TYPE.getName());
        List<SysDictData> operatingStatusList = DictUtil.getDict(OPERATING_STATUS.getName());
        List<SysDictData> equalProtectionLevelList = DictUtil.getDict(EQUAL_PROTECTION_LEVEL.getName());
        SeverAssetType defaultAssetType = findAssetTypeAll().stream()
                .filter(type -> type.getId().equals(type.getAncestors()))
                .min(Comparator.comparing(SeverAssetType::getSortNum)).orElse(null);
        ipMap.forEach((k, v) -> {
            try {
                if (!AlarmAssetSegmentLoad.getIPByHalf(k)) {
                    //不在白名单范围
                    return;
                }
                TbAsset asset = new TbAsset();
                TbAssetSegement rdata = NewSegmentLoad.getIPSegmentByHalf(k);
                if (rdata != null) {
                    asset.setArea(rdata.getAreaName());
                    asset.setAffiliationDeptName(rdata.getAffiliationDeptName());
                    asset.setAffiliationDeptNodeId(rdata.getAffiliationDeptNodeId());
                    asset.setAreaName(rdata.getAreaName());
                    asset.setAreaCustomUuid(rdata.getAreaCustomUuid());
                }
                TbAsset tmp = assetMapper.selectTbAssetByInnerIp(k);
                if (tmp == null) {
                    boolean flag = StringUtils.isNotBlank(asset.getArea()) && asset.getArea().contains("办公区");
                    if (!flag) {

                        if (ConfBuzziMySql.existTable("tb_asset_terminal_equipment") == 1) {
                            String sql = "SELECT count(1) FROM tb_asset_terminal_equipment WHERE report_ip = '" + v + "'";
                            if (commonMapper.getCount(sql) > 0) {
                                //终端资产
                                return;
                            }
                        }
                        if (ConfBuzziMySql.existTable("tb_terminal_software_install") == 1) {
                            String sql = "SELECT count(1) FROM tb_terminal_software_install WHERE str_dev_ip = '" + v + "'";
                            if (commonMapper.getCount(sql) > 0) {
                                //终端资产
                                return;
                            }
                        }


                        updateFullAreaDept(asset);
                        asset.setInternalIp(k);
                        asset.setSource(SSP_CMDB);
                        asset.setKeyAsset(3);
                        if (asset.getOperatingStatus() == null) {
                            asset.setOperatingStatus(1);
                        }

                        if (StringUtils.isBlank(asset.getInstance())) {
                            asset.setInstance(asset.getInternalIp());
                        }
                        //insert
                        if (asset.getOperatingStatus() == null) {
                            asset.setOperatingStatus(1);
                        }
                        asset.setStatus(0);
                        asset.setUpdateTime(new Date());
                        if (asset.getCreateTime() == null) {
                            asset.setCreateTime(new Date());
                        }
                        asset.setAlarmId(alarmIp.getAlarmId());
                        // 资产等级
                        keyAssetList.stream().findFirst().ifPresent(dict -> {
                            asset.setKeyAsset(Convert.toInt(dict.getDictValue()));
                            asset.setKeyAssetLabel(dict.getDictLabel());
                        });
                        // 资产类型
                        if (Objects.nonNull(defaultAssetType)) {
                            asset.setAssetTypeId(defaultAssetType.getId());
                            asset.setAssetTypeName(defaultAssetType.getFullPath());
                            asset.setAssetTypePath(defaultAssetType.getAncestors());
                        }
                        // 环境类型
                        String environmentType =
                                DictUtil.getDictDataValueOrDefault(environmentTypeList, asset.getEnvironmentTypeLabel());
                        if (com.crc.common.utils.StringUtils.isNotEmpty(environmentType)) {
                            asset.setEnvironmentType(environmentType);
                        }
                        // 资产状态
                        operatingStatusList.stream().findFirst().ifPresent(dict -> {
                            asset.setOperatingStatus(Convert.toInt(dict.getDictValue()));
                            asset.setOperatingStatusLabel(dict.getDictLabel());
                        });
                        // 是否为关键基础设施
                        asset.setAssetPower(NO.getValue());
                        // 是否完成国密改造0否1是 默认 0 否
                        asset.setTransformationCompleted(NO.getValue());
                        // 是否发布互联网
                        asset.setInternetPublic(NO.getValue());
                        // 是否集权系统 0否1是
                        asset.setCentralizedSystem(NO.getValue());
                        // 等保定级
                        equalProtectionLevelList.stream().findFirst().ifPresent(dict -> {
                            asset.setEqualProtectionLevel(Convert.toInt(dict.getDictValue()));
                            asset.setEqualProtectionLevelLabel(dict.getDictLabel());
                        });
                        // 实战期间是否授权关闭
                        asset.setIsCombatOff(NO.getValue());
                        // 实战期间是否有关闭计划
                        asset.setIsCombatPlan(NO.getValue());
                        // 是否包含个人信息 0 否(默认) 1 是
                        asset.setIsPersonalInfo(NO.getValue());
                        asset.setAlarmId(alarmIp.getAlarmId());
                        asset.setRuleBase(alarmIp.getRuleBase());
                        asset.setRuleBaseIp(alarmIp.getRuleBaseIp());
                        log.info("alarm_ip:{},insert", k);
                        assetMapper.insertOrUpdateSelective(asset);
                        if (ConfBuzziMySql.existTable("tb_asset_change_record") == 1) {
                            assetRecordService.addChangeRecord(new TbAsset(), asset);
                        }
                        if (asset.getAffiliationDeptNodeId() != null) {
                            String to = mailUserList.stream()
                                    .filter(dict -> dict.getDictValue().equals(String.valueOf(asset.getAffiliationDeptNodeId())))
                                    .map(SysDictData::getRemark).filter(com.crc.common.utils.StringUtils::isNotEmpty).collect(Collectors.joining(COMMA));
                            sendMail(to, asset.getInternalIp(), asset.getAffiliationDeptName());
                        }
                    }
                }
            } catch (Exception e) {
                log.error(e.getMessage(), e);
            }
        });
    }

    public void updateFullAreaDept(TbAsset asset) {
        SysDeptMapper sysDeptMapper = GetSpringBean.getBean(SysDeptMapper.class);
        try {
            if (asset.getAffiliationDeptNodeId() == null || asset.getAffiliationDeptNodeId() == 0L) {
                //update  tb_asset set dept_path=',0,100,99,' where dept_path is null
                asset.setDeptPath(",0,100,99,");
            } else {
                ////update  tb_asset set dept_path=(select concat(',',ancestors,',',dept_id,',') from sys_dept where dept_id=affiliation_dept_node_id)
                String deptPath = sysDeptMapper.getDeptPath(asset.getAffiliationDeptNodeId());
                asset.setDeptPath(deptPath);
            }
            if (StringUtils.isBlank(asset.getAreaCustomUuid())) {
                asset.setAreaPath(",0,96,");
            } else {
                String areaPath = sysDeptMapper.getAreaPath(asset.getAreaCustomUuid());
                asset.setAreaPath(areaPath);
            }
        } catch (Exception e) {
            log.error(e.getMessage(), e);
        }
    }

    public List<SeverAssetType> findAssetTypeAll() {
        SeverAssetTypeMapper severAssetTypeMapper = GetSpringBean.getBean(SeverAssetTypeMapper.class);
        List<SeverAssetType> typeAllList = severAssetTypeMapper.findAssetTypeAll();
        if (CollUtil.isNotEmpty(typeAllList)) {
            typeAllList.forEach(type -> {
                List<String> typeNameList = new ArrayList<>();
                for (String typeId : type.getAncestors().split(COMMA)) {
                    typeAllList.stream().filter(assetType -> typeId.equals(assetType.getId()))
                            .map(SeverAssetType::getTypeName).findFirst().ifPresent(typeNameList::add);
                }
                type.setFullPath(com.crc.common.utils.StringUtils.join(typeNameList, SLASH));
            });
        }
        return typeAllList;
    }

    private void sendMail(String user, String internalIp, String companyName) {
        log.info("asset mail:to={},ip={},companyName={}", user, internalIp, companyName);
        MailService mailService = GetSpringBean.getBean(MailService.class);
        /*
        Map<String, String> emailMap = new HashMap<>();
                    emailMap.put("internalIp", StringUtils.nvlString(asset.getInternalIp()));
                    emailMap.put("companyName", StringUtils.nvlString(asset.getCompanyName()));
                    emailMap.put("url", StringUtils.nvlString(url));
                    emailCustomer.task(MailDTO.builder().to(to)
                        .subject(StrFormatter.mailFormat(mailMsgConfig.getAlarmDiscoverAssetTitle(), emailMap))
                        .text(StrFormatter.mailFormat(mailMsgConfig.getAlarmDiscoverAssetMsg(), emailMap)).build());
         */
        String url = DictUtil.getDictLabel("mail_url", "alarmDiscoverAssetUrl");
        Map<String, String> emailMap = new HashMap<>();
        emailMap.put("internalIp", nvlString(internalIp));
        emailMap.put("companyName", nvlString(companyName));
        emailMap.put("url", nvlString(url));
        String subStr = "【告警发现资产认领】未知资产{internalIp}产生告警，请及时完善资产信息";
        String subText = "<html> <body style='margin: 30px 20px; font-family: Microsoft YaHei, 微软雅黑; font-size: 14px; color: #000;'> <p><span style=\"font-weight: bold;\">尊敬的用户：</span></p> <p>&emsp;&emsp;您好！</p> <p>&emsp;&emsp;告警发现资产{internalIp}未维护，根据网段匹配到所属组织为{companyName}，请前往慧联STP资产信息模块 <a style='color: #3370ff;' href='{url}'> {url} </a>查看，并及时完善资产信息。 </p> <p style='color: rgb(143, 149, 158);line-height: 30px;'> --------------------------------------------------------------------------------------------------- </p> <p style='color: rgb(143, 149, 158);font-style: italic;'> 温馨提示：此邮件为系统自动发出，请勿回复。如有问题，请与相关业务人员联系，谢谢。 </p> <p style='color: #4e6ef2;'> 慧联STP智慧安全协同平台专用邮箱 </p> </body> </html>";
        String text = StrFormatter.mailFormat(subText, emailMap);
        String subject = StrFormatter.mailFormat(subStr, emailMap);
        MailDTO mailDTO = MailDTO.builder()
                .to(user)
                .text(text)
                .subject(subject)
                .build();
        mailService.sendHtmlMail(mailDTO);
    }

    private static final String NULLSTR = "";

    public static String nvlString(String str) {
        return StringUtils.isBlank(str) ? NULLSTR : str;
    }
}
