package com.crc.sync.data;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;
import com.crc.common.constants.LogConstants;
import com.crc.common.constants.LogConstantsX;
import com.crc.common.utils.*;
import com.crc.secface.config.ElasticsearchProperties;
import com.crc.secface.config.EsDataSource;
import com.crc.secface.config.GetSpringBean;
import com.crc.secface.entity.AlarmIp;
import com.crc.secface.entity.AlarmLog;
import com.crc.secface.entity.TbEventModel;
import com.crc.secface.es.EsSingleFactory;
import com.crc.secface.mapper.CommonMapper;
import com.crc.secface.mapper.TbEventModelMapper;
import com.crc.sync.send.SendEventExecutor;
import com.crc.sync.send.SendToScpInternetPublishApp;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.elasticsearch.action.search.SearchRequest;
import org.elasticsearch.action.search.SearchResponse;
import org.elasticsearch.client.RequestOptions;
import org.elasticsearch.client.RestHighLevelClient;
import org.elasticsearch.index.query.BoolQueryBuilder;
import org.elasticsearch.index.query.QueryBuilders;
import org.elasticsearch.index.query.RangeQueryBuilder;
import org.elasticsearch.search.SearchHit;
import org.elasticsearch.search.SearchHits;
import org.elasticsearch.search.builder.SearchSourceBuilder;

import java.util.Calendar;
import java.util.Date;
import java.util.GregorianCalendar;
import java.util.Map;
import java.util.concurrent.ArrayBlockingQueue;

@Slf4j
public class AlarmLogSyncNow  {

    public static void addQueue(String dataSource,String indexName, String oriIds, String flowId, JSONObject json) {
        AlarmLog alarmLog = new AlarmLog();
        alarmLog.setAlarmId(flowId);
        alarmLog.setIds(oriIds);
        alarmLog.setIndexName(indexName);
        alarmLog.setJsonStr(JSON.toJSONString(json));
        alarmLog.setDataSource(dataSource);

        try {
            CommonMapper commonMapper = GetSpringBean.getBean(CommonMapper.class);
            ElasticsearchProperties esConfig = GetSpringBean.getBean(ElasticsearchProperties.class);
            TbEventModelMapper modelMapper = GetSpringBean.getBean(TbEventModelMapper.class);

            String ids = alarmLog.getIds();
            String alarmId = alarmLog.getAlarmId();
            if (StringUtils.isBlank(indexName)) {
                indexName = "sec_all-*";
            }
            log.info("同步原始日志={},开始@v@",alarmId);
            boolean good = false;
            String sql = "select count(1) from tb_alarm_ori_log where id = '%s'";
            for(String id:ids.split(",")) {
                String jsonStr = null;
                try {
                    if (commonMapper.getCount(String.format(sql, id)) > 0) {
                        if (StringUtils.isNotBlank(flowId)) {
                            String sqlx = "update tb_alarm_ori_log set alarm_id = '%s' where id = '%s'";
                            commonMapper.exeSQL(String.format(sqlx,flowId,id));
                        }
                        continue;
                    }
                    SearchSourceBuilder sourceBuilder = new SearchSourceBuilder();
                    BoolQueryBuilder boolQuery = buildQueryBuilder(id);

                    sourceBuilder.query(boolQuery);
                    sourceBuilder.size(1);
                    SearchResponse response = null;
                    String esIndex = indexName.split("-")[0] + "-*";

                    if (StringUtils.isNotBlank(dataSource)) {
                        //使用外部数据库
                        RestHighLevelClient client = null;
                        try {
                            Map<String, String> indexMap = modelMapper.getIndexAndSource(TbEventModel.createQuery(dataSource));
                            String indexNameStr = DataUtils.getString(indexMap, "indexRule");
                            SearchRequest searchRequest = new SearchRequest(indexNameStr);
                            searchRequest.source(sourceBuilder);
                            EsDataSource esDataSource = EsUtils.logSourceCheck(indexMap);
                            if(esDataSource != null) {
                                client = EsSingleFactory.getInstance().getHighLevelClientHigh(esDataSource);
                                response = client.search(searchRequest, RequestOptions.DEFAULT);
                                SearchHits sh = response.getHits();
                                for (SearchHit searchHit : sh) {
                                    jsonStr = searchHit.getSourceAsString();
                                    String newSql = "insert into tb_alarm_ori_log(id,msg,alarm_id)values('%s','%s','%s')";
                                    SendEventExecutor.saveData(String.format(newSql, id, SimpleCodeTool.encryptBase64(jsonStr),alarmId));
                                    good = true;
                                }
                            }
                        } catch (Exception e) {
                            log.error(e.getMessage(), e);
                        } finally {
                            EsSingleFactory.getInstance().close(client);
                        }
                    }
                    if(StringUtils.isBlank(jsonStr)) {
                        RestHighLevelClient client = null;
                        try {
                            SearchRequest searchRequest = new SearchRequest(esIndex);
                            searchRequest.source(sourceBuilder);
                            client = EsSingleFactory.getInstance().getHighLevelClient(esConfig);
                            response = client.search(searchRequest, RequestOptions.DEFAULT);
                            SearchHits sh = response.getHits();
                            for (SearchHit searchHit : sh) {
                                jsonStr = searchHit.getSourceAsString();
                                String newSql = "insert into tb_alarm_ori_log(id,msg,alarm_id)values('%s','%s','%s')";
                                SendEventExecutor.saveData(String.format(newSql,id, SimpleCodeTool.encryptBase64(jsonStr),alarmId));
                                good = true;
                            }
                        } catch (Exception e) {
                            log.error(e.getMessage(), e);
                        } finally {
                            EsSingleFactory.getInstance().close(client);
                        }
                    }
                    JSONObject jsonObject = JsonUtils.parse(jsonStr);
                    if (StringUtils.isNotBlank(jsonStr) && jsonObject.size() > 0) {
                        AlarmIp alarmIp = new AlarmIp();
                        alarmIp.setAlarmId(alarmId);
                        alarmIp.setSrcIp(JsonUtils.getStr(jsonObject, LogConstantsX.SRC_IP));
                        alarmIp.setDestIp(JsonUtils.getStr(jsonObject, LogConstantsX.DEST_IP));
                        alarmIp.setUrl(JsonUtils.getStr(jsonObject, "url"));
                        alarmIp.setHost(JsonUtils.getStr(jsonObject, "host"));
                        SendToScpInternetPublishApp.magicQueue.offer(alarmIp);
                    }
                } catch (Exception e) {
                    log.error("告警原始日志同步异常:{}", e.getMessage(), e);
                }
            }
            log.info("已经同步原始日志={},flag={}",alarmId,good);
        } catch (Exception e) {
            log.error("告警原始日志同步异常:{}", e.getMessage(), e);
        }
    }

    public static BoolQueryBuilder buildQueryBuilder(String id) {
        BoolQueryBuilder boolBuilder = QueryBuilders.boolQuery();
        BoolQueryBuilder should = QueryBuilders.boolQuery();
        should.should(QueryBuilders.matchPhraseQuery("_id", id));
        Date date = new Date();//当前时间
        Calendar calendar = new GregorianCalendar();
        calendar.setTime(date);
        calendar.add(Calendar.DAY_OF_MONTH, -2);
        Date startDate = calendar.getTime();
        RangeQueryBuilder rangeQueryBuilder = QueryBuilders.rangeQuery(LogConstants.SPARK_TIME_TAG);
        rangeQueryBuilder.gt(DateUtils.getSparkTime(startDate));
        boolBuilder.filter(rangeQueryBuilder);
        boolBuilder.filter(should);
        return boolBuilder;
    }
}
