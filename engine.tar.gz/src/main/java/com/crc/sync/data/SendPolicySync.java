package com.crc.sync.data;

import com.crc.common.utils.DataUtils;
import com.crc.common.utils.MyTheadUtils;
import com.crc.secface.config.GetSpringBean;
import com.crc.secface.entity.SendPolicy;
import com.crc.secface.entity.SendPolicyQuery;
import com.crc.secface.entity.SysDept;
import com.crc.secface.mapper.SendPolicyMapper;
import com.crc.secface.mapper.SysDeptMapper;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;

import java.util.Date;
import java.util.LinkedList;
import java.util.List;
import java.util.concurrent.ConcurrentHashMap;

@Slf4j
public class SendPolicySync extends Thread {
    public static ConcurrentHashMap<String, SendPolicy> policyMap = new ConcurrentHashMap<>();

    public void run() {
        while (true) {
            try {
                sync();
            } catch (Exception e) {
                log.error(e.getMessage(),e);
            }
            MyTheadUtils.sleepBySec(60 * 5);
        }
    }

    public void sync() {
        SendPolicyQuery sendPolicyQuery = new SendPolicyQuery();
        //sendPolicyQuery.setRuleIds(dangerEventSend.getModel().getId());
        sendPolicyQuery.setQueryDate(new Date());
        SendPolicyMapper sendPolicyMapper = GetSpringBean.getBean(SendPolicyMapper.class);
        List<SendPolicy> sendPolicyList = sendPolicyMapper.selectByQuery(sendPolicyQuery);
        List<SendPolicy> newPolicyList = getFilterPolicyList(sendPolicyList);
        for (SendPolicy sp : newPolicyList) {
            policyMap.put(sp.getId().toString(), sp);
        }
        log.info("同步告警推送策略：" + policyMap.size());
    }

    public List<SendPolicy> getFilterPolicyList(List<SendPolicy> sendPolicyList) {
        List<SendPolicy> newModelList = new LinkedList<>();
        SysDeptMapper sysDeptMapper = GetSpringBean.getBean(SysDeptMapper.class);
        for (SendPolicy ruleX : sendPolicyList) {
            if (StringUtils.isNotBlank(ruleX.getApplyCompany())) {
                for (String company : ruleX.getApplyCompany().split(",")) {
                    if (StringUtils.isNotBlank(company)) {
                        SysDept sysDept = sysDeptMapper.selectDeptById(DataUtils.toLong(company));
                        if (sysDept != null) {
                            if ("集团总部".equalsIgnoreCase(sysDept.getDeptName())) {
                                newModelList.add(ruleX);
                                break;
                            }
                        }
                    }
                }
            } else {
                newModelList.add(ruleX);
            }
        }
        return newModelList;
    }
}
