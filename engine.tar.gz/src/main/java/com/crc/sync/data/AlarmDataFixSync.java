package com.crc.sync.data;

import com.alibaba.fastjson.JSONObject;
import com.crc.common.utils.DataUtils;
import com.crc.common.utils.DictUtil;
import com.crc.common.utils.JsonUtils;
import com.crc.common.utils.MyTheadUtils;
import com.crc.secface.config.GetSpringBean;
import com.crc.secface.config.SyncSecConfig;
import com.crc.secface.mapper.CommonMapper;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;

import java.util.HashMap;
import java.util.List;
import java.util.Map;


@Slf4j
public class AlarmDataFixSync extends Thread {
    static HashMap<String, String> ATTACK_MAPING = new HashMap<>();

    static {
        ATTACK_MAPING.put("①", "①对重点人投毒进行社工攻击");
        ATTACK_MAPING.put("②", "②发现隐藏攻击隧道");
        ATTACK_MAPING.put("③", "③发现重要敏感数据被窃取");
        ATTACK_MAPING.put("④", "④系统被控制，植入木马等");
        ATTACK_MAPING.put("⑤", "⑤邮件系统被盯控");
        ATTACK_MAPING.put("⑥", "⑥近源攻击突破网络防线");
        ATTACK_MAPING.put("⑦", "⑦攻击链打击");
        ATTACK_MAPING.put("⑧", "⑧通过下属单位,跨网,迂回攻击");
        ATTACK_MAPING.put("⑨", "⑨内网敏感信息被收集利用（网段信息,密码本,网络拓扑,源代码,组织架构信息等让防守方补充）");
        ATTACK_MAPING.put("⑩", "⑩漏洞利用,口令滥用,权限提升等高危操作");
    }

    public void run() {
        while (true) {
            cleanDeviceLabel();
            if (SyncSecConfig.isEnable("alarm_attack_fix")) {
                try {
                    String sql = "SELECT id,attack_means,attack_means_label FROM tb_alarm_report WHERE  attack_means is null and attack_means_label is not null order by id desc limit 100";
                    CommonMapper commonMapper = GetSpringBean.getBean(CommonMapper.class);
                    List<HashMap<String, Object>> jsonList = commonMapper.query(sql);
                    log.info("补充常态化告警攻击手段数据=" + jsonList.size());
                    for (HashMap<String, Object> map : jsonList) {
                        MyTheadUtils.sleepBySec(1);
                        try {
                            String newAttack = getNewAttack(DataUtils.getStr(map, "attack_means_label"));
                            String id = DataUtils.getString(map, "id");
                            if (StringUtils.isNotBlank(newAttack)) {
                                String updateSQL = "update tb_alarm_report set attack_means = '%s',attack_means_label = '%s' where id = %s";
                                commonMapper.exeSQL(String.format(updateSQL, newAttack, newAttack, id));
                            }
                        } catch (Exception e) {
                            log.error(e.getMessage(), e);
                        }

                    }
                } catch (Exception e) {
                    log.error(e.getMessage(), e);
                }


                try {
                    String sql = "SELECT id,attack_means,attack_means_label FROM tb_alarm_combat_report WHERE  attack_means is null and attack_means_label is not null order by id desc limit 100";
                    CommonMapper commonMapper = GetSpringBean.getBean(CommonMapper.class);
                    List<HashMap<String, Object>> jsonList = commonMapper.query(sql);
                    log.info("补充实战告警攻击手段数据=" + jsonList.size());
                    for (HashMap<String, Object> map : jsonList) {
                        MyTheadUtils.sleepBySec(1);
                        try {
                            String newAttack = getNewAttack(DataUtils.getStr(map, "attack_means_label"));
                            String id = DataUtils.getString(map, "id");
                            if (StringUtils.isNotBlank(newAttack)) {
                                String updateSQL = "update tb_alarm_combat_report set attack_means = '%s',attack_means_label = '%s' where id = %s";
                                commonMapper.exeSQL(String.format(updateSQL, newAttack, newAttack, id));
                            }
                        } catch (Exception e) {
                            log.error(e.getMessage(), e);
                        }

                    }
                } catch (Exception e) {
                    log.error(e.getMessage(), e);
                }
            }
            MyTheadUtils.sleepBySec(120);
        }
    }


    public void cleanDeviceLabel() {
        try {
            Map<String, String> dictMap = DictUtil.getMapValueLabel("rule_base");
            String sql = "SELECT * FROM tb_alarm_report WHERE alarm_time >  DATE_SUB(NOW(), INTERVAL 7 DAY) AND (device_label REGEXP '^[0-9]+$') > 0  ORDER BY id DESC LIMIT 1000";
            CommonMapper commonMapper = GetSpringBean.getBean(CommonMapper.class);
            List<JSONObject> list = commonMapper.queryX(sql);
            log.info("##清洗设备告警数：{}", list.size());
            for (JSONObject json : list) {
                String device_label = JsonUtils.getStr(json, "device_label");
                String alarm_source = JsonUtils.getStr(json, "alarm_source");
                String alarm_id = JsonUtils.getStr(json, "alarm_id");
                String dict = dictMap.get(device_label);
                log.info("old={},new={}",device_label,dict);
                if(StringUtils.isNotBlank(dict)){
                    if (StringUtils.isBlank(alarm_source)) {
                        alarm_source = dict;
                    }else {
                        String []ss = alarm_source.split("/");
                        if (ss.length > 1) {
                            ss[ss.length - 1] = dict;
                            alarm_source = String.join("/",ss);
                        }else {
                            alarm_source = dict;
                        }
                    }
                    device_label = dict;
                    String update = "update tb_alarm_report set device = '%s',device_label = '%s',alarm_source = '%s' where alarm_id = '%s'";
                    commonMapper.exeSQL(String.format(update,device_label,device_label,alarm_source,alarm_id));
                    log.info("update {} deviceLabal={}",alarm_id,device_label);
                }
            }

        } catch (Exception e) {
            log.error(e.getMessage(),e);
        }
    }

    public String getNewAttack(String oldAttack) {
        if (oldAttack == null) {
            return "";
        }
        if (!oldAttack.contains("_")) {
            return oldAttack;
        }
        String code = oldAttack.split("_")[0].trim();
        String mapping = "1,->,⑩\n" +
                "        2,->,①\n" +
                "        3,->,⑦\n" +
                "        4,->,⑩\n" +
                "        5,->,⑩\n" +
                "        6,->,①\n" +
                "        7,->,①\n" +
                "        8,->,⑩\n" +
                "        9,->,④\n" +
                "        10,->,④\n" +
                "        11,->,⑥\n" +
                "        12,->,⑥\n" +
                "        13,->,⑩\n" +
                "        14,->,⑩\n" +
                "        15,->,②\n" +
                "        16,->,⑨\n" +
                "        17,->,⑦\n" +
                "        18,->,⑩";
        for (String map : mapping.split("\n")) {
            String[] arr = map.trim().split(",");
            if (arr.length == 3) {
                if (code.equalsIgnoreCase(arr[0].trim())) {
                    return ATTACK_MAPING.get(arr[2].trim());
                }
            }
        }
        return oldAttack;
    }


}
