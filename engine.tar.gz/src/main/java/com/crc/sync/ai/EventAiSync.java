package com.crc.sync.ai;

import com.alibaba.fastjson.JSONObject;
import com.crc.common.utils.*;
import com.crc.secface.config.GetSpringBean;
import com.crc.secface.config.SyncSecConfig;
import com.crc.secface.entity.TbAssetSegement;
import com.crc.secface.entity.TbEvent;
import com.crc.secface.mapper.CommonMapper;
import com.crc.secface.mapper.TbEventMapper;
import com.crc.sync.net.NewSegmentLoad;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;

import java.util.Date;
import java.util.List;
import java.util.Map;

@Slf4j
public class EventAiSync extends Thread {

    public void run() {
        while (true) {
            if (SyncSecConfig.isEnable("event_ai_sync")) {
                log.info("计算AI未识别的EVENT事件");
                try {
                    String sql = "SELECT * FROM tb_event WHERE is_whitelist = '0'  AND solutions IS  NULL ORDER BY create_time DESC LIMIT 100";
                    CommonMapper commonMapper = GetSpringBean.getBean(CommonMapper.class);
                    List<JSONObject> jsonList = commonMapper.queryX(sql);
                    log.info("计算AI未识别的Event={}", jsonList.size());
                    for (JSONObject jsonObject : jsonList) {
                        MyTheadUtils.sleepBySec(1);
                        try {
                            JSONObject paramJson = procV2(jsonObject);
                            try {
                                Map<String, String> resultMap = AiCheckSync.getAiInfo(paramJson,DataUtils.getStr(jsonObject,"qaxt_id"));
                                double ai = DataUtils.getDouble(resultMap, "priority");
                                String priority = DataUtils.getString(resultMap, "priority");
                                if (ai > 0) {
                                    TbEventMapper bean = GetSpringBean.getBean(TbEventMapper.class);
                                    TbEvent uu = new TbEvent();
                                    uu.setQaxtId(JsonUtils.getStr(jsonObject, "qaxt_id"));
                                    uu.setAttach(String.valueOf(ai));
                                    uu.setPriority(ai);
                                    uu.setSolution(DataUtils.getStr(resultMap, "solution"));
                                    uu.setSolutions(DataUtils.getStr(resultMap, "solutions"));
                                    bean.updateAiData(uu);
                                    log.info("{}-入库event - AI数据，{}", JsonUtils.getStr(jsonObject, "qaxt_id"), priority);
                                }

                            } catch (Exception e) {
                                log.error(e.getMessage(), e);
                            }
                        } catch (Exception e) {
                            log.error(e.getMessage(), e);
                        }
                    }
                } catch (Exception e) {
                    log.error(e.getMessage(), e);
                }
            }
            MyTheadUtils.sleepBySec(5);
        }
    }

    public JSONObject procV2(JSONObject json) {
        JSONObject jsonObject = new JSONObject();
        try {
                /*
                {
    "alarm_time": "2021-12-24 06:08:02",
    "event_description":"【192.168.30.157 进行 [Linux后门检测] 主机192.168.30.157存在后门检测问题，检查 /var/spool/cron/ 用户名里面是否存在 REGEX: REDIS\\d\\d\\d\\d】",
    "src_ip":"192.168.30.157",
    "dest_ip":"0.0.0.0",
    "isworkday": true,
    "attack_type": "9_网站木马攻击",
    "isdatacenter": false,
    "event_name": "主机存在高危后门文件（Linux）",
    "event_level": "二级",
    "event_source": "青藤",
    "reg_sub_area": "华润医药",
    "attack_result": "4",
    "reg_area": "前置机房"
}
                 */
            String srcIp = JsonUtils.getStr(json, "attack_ip");//攻击ip
            String destIp = JsonUtils.getStr(json, "attack_url");//受害ip
            TbAssetSegement ipBean = null;
            List<String> srcList = IpUtils.getIps(srcIp);
            String riskIp = null;
            if (srcList.size() > 0) {
                for (String ip : srcList) {
                    ipBean = NewSegmentLoad.getIPSegmentByHalf(ip);
                    if (ipBean != null) {
                        riskIp = ip;
                    }
                }
            }
            if (StringUtils.isBlank(riskIp)) {
                List<String> destList = IpUtils.getIps(destIp);
                for (String ip : destList) {
                    ipBean = NewSegmentLoad.getIPSegmentByHalf(ip);
                    if (ipBean != null) {
                        break;
                    }
                }
            }
            String area = "";
            String subArea = "";
            boolean isdatacenter = false;
            if (ipBean != null) {
                String bu = ipBean.getAffiliationDeptName();
                area = ipBean.getAreaName();
                if ("汕尾数据中心".equalsIgnoreCase(area) || area.contains("汕尾"))
                    isdatacenter = true;
                if (area.equalsIgnoreCase("前置机房")) {
                    subArea = bu;
                }
            }
            if (StringUtils.isBlank(area))
                area = "其他";
            if (StringUtils.isBlank(subArea))
                subArea = "其他";

            if (StringUtils.isBlank(area))
                area = "其他";
            if (StringUtils.isBlank(subArea))
                subArea = "其他";
            jsonObject.put("attack_result", DataUtils.getStr(json, "attack_result"));
            jsonObject.put("reg_area", area);
            jsonObject.put("reg_sub_area", subArea);
            jsonObject.put("event_source", DataUtils.getStr(json, "event_source").replace("SSP-", "").replace("-自动", ""));
            jsonObject.put("event_level", DataUtils.getStr(json, "event_level"));
            jsonObject.put("attack_type", DataUtils.getStr(json, "attack_type"));
            jsonObject.put("isdatacenter", isdatacenter);
            jsonObject.put("isworkday", ManualAlarmAiSync.checkTimeIsWork());
            Date alarmTime = DataUtils.getDateX(json, "alarm_time");
            if (alarmTime == null) {
                alarmTime = DataUtils.getDateX(json, "create_time");
            }
            if (alarmTime == null) {
                alarmTime = new Date();
            }
            jsonObject.put("alarm_time", DateUtils.getDateTimeString1(alarmTime));
            jsonObject.put("event_description", DataUtils.getStr(json, "remarks"));
            jsonObject.put("src_ip", srcIp);
            jsonObject.put("dest_ip", destIp);
            jsonObject.put("event_name", DataUtils.getStr(json, "event_name"));

            jsonObject.forEach((k, v) -> {
                if (v instanceof String) {
                    if (StringUtils.isBlank(v.toString())) {
                        jsonObject.put(k, "\\N");
                    } else {
                        if (k.equalsIgnoreCase("reg_area") && ((String) v).equalsIgnoreCase("其他")) {
                            jsonObject.put(k, "\\N");
                        } else if (k.equalsIgnoreCase("reg_sub_area") && ((String) v).equalsIgnoreCase("其他")) {
                            jsonObject.put(k, "\\N");
                        }
                    }
                }
            });
        } catch (Exception e) {
            log.error(e.getMessage(), e);
        }
        return jsonObject;
    }
}
