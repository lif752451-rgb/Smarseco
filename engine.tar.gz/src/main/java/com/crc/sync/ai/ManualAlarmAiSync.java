package com.crc.sync.ai;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;
import com.crc.SpringbootApplication;
import com.crc.common.utils.*;
import com.crc.secface.config.GetSpringBean;
import com.crc.secface.config.SyncSecConfig;
import com.crc.secface.entity.TbEvent;
import com.crc.secface.es.ConfBuzziMySql;
import com.crc.secface.mapper.CommonMapper;
import com.crc.secface.mapper.TbEventMapper;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.*;


@Slf4j
public class ManualAlarmAiSync extends Thread {

    public void run() {
        while (true) {
            if (SyncSecConfig.isEnable("alarm_ai_sync")) {
                log.info("计算AI未识别的工单");
                CommonMapper commonMapper = GetSpringBean.getBean(CommonMapper.class);
                try {
                    String sql = "SELECT * FROM tb_alarm_report WHERE  ai_check < 0.1 or ai_check is null order by id desc limit 100";
                    List<HashMap<String, Object>> jsonList = commonMapper.query(sql);
                    for (HashMap<String, Object> jsonObject : jsonList) {
                        MyTheadUtils.sleepBySec(1);
                        JSONObject paramJson = procV2(jsonObject);
                        try {
                            Map<String, String> resultMap = AiCheckSync.getAiInfo(paramJson,DataUtils.getStr(jsonObject, "alarm_id"));
                            double ai = DataUtils.getDouble(resultMap, "priority");
                            String priority = DataUtils.getString(resultMap, "priority");
                            if (ai > 0) {
                                String xSQL = "update tb_alarm_report set ai_check = %s where id=%s";
                                xSQL = String.format(xSQL, priority, DataUtils.getStr(jsonObject, "id"));
                                commonMapper.exeSQL(xSQL);

                                TbEventMapper bean = GetSpringBean.getBean(TbEventMapper.class);
                                TbEvent uu = new TbEvent();
                                uu.setQaxtId(DataUtils.getStr(jsonObject, "qaxt_id"));
                                uu.setAttach(String.valueOf(ai));
                                uu.setPriority(ai);
                                uu.setSolution(DataUtils.getStr(resultMap, "solution"));
                                uu.setSolutions(DataUtils.getStr(resultMap, "solutions"));
                                bean.updateAiData(uu);

                                log.info("{}-入库alarm - AI数据，{}", DataUtils.getStr(jsonObject, "alarm_id"), priority);
                            }
                        } catch (Exception e) {
                            log.error(e.getMessage(), e);
                        }

                    }
                } catch (Exception e) {
                    log.error(e.getMessage(), e);
                }
                MyTheadUtils.sleepBySec(5);
                if (ConfBuzziMySql.existTable("tb_alarm_combat_report") == 1) {
                    try {
                        String sql = "SELECT * FROM tb_alarm_combat_report WHERE  ai_check < 0.1 or ai_check is null order by id desc limit 100";
                        List<HashMap<String, Object>> jsonList = commonMapper.query(sql);
                        log.info("计算AI未识别的工单2={}", jsonList.size());
                        for (HashMap<String, Object> jsonObject : jsonList) {
                            MyTheadUtils.sleepBySec(5);
                            JSONObject paramJson = procV2(jsonObject);
                            try {
                                Map<String, String> resultMap = AiCheckSync.getAiInfo(paramJson);
                                double ai = DataUtils.getDouble(resultMap, "priority");
                                log.info("alarmCombatAI,{}-{}",DataUtils.getStr(jsonObject,"alarm_id"),ai);
                                String priority = DataUtils.getString(resultMap, "priority");
                                if (ai > 0) {
                                    String xSQL = "update tb_alarm_combat_report set ai_check = %s where id='%s'";
                                    xSQL = String.format(xSQL, priority, DataUtils.getStr(jsonObject, "id"));
                                    commonMapper.exeSQL(xSQL);

                                    TbEventMapper bean = GetSpringBean.getBean(TbEventMapper.class);
                                    TbEvent uu = new TbEvent();
                                    uu.setQaxtId(DataUtils.getStr(jsonObject, "qaxt_id"));
                                    uu.setAttach(String.valueOf(ai));
                                    uu.setPriority(ai);
                                    uu.setSolution(DataUtils.getStr(resultMap, "solution"));
                                    uu.setSolutions(DataUtils.getStr(resultMap, "solutions"));
                                    bean.updateAiData(uu);
                                }
                            } catch (Exception e) {
                                log.error(e.getMessage(), e);
                            }

                        }
                    } catch (Exception e) {
                        log.error(e.getMessage(), e);
                    }
                }
            }
            MyTheadUtils.sleepBySec(5);
        }
    }


    public JSONObject procV2(HashMap<String, Object> json) {
        JSONObject jsonObject = new JSONObject();
        try {
            /*
               {
                    "alarm_time": "2021-12-24 06:08:02",
                    "event_description":"【192.168.30.157 进行 [Linux后门检测] 主机192.168.30.157存在后门检测问题，检查 /var/spool/cron/ 用户名里面是否存在 REGEX: REDIS\\d\\d\\d\\d】",
                    "src_ip":"192.168.30.157",
                    "dest_ip":"0.0.0.0",
                    "isworkday": true,
                    "attack_type": "9_网站木马攻击",
                    "isdatacenter": false,
                    "event_name": "主机存在高危后门文件（Linux）",
                    "event_level": "二级",
                    "event_source": "青藤",
                    "reg_sub_area": "华润医药",
                    "attack_result": "4",
                    "reg_area": "前置机房"
                }
             */
            String srcIp = DataUtils.getStr(json, "attack_ip");//攻击ip
            String destIp = DataUtils.getStr(json, "victimized_ip");//受害ip
            String area = DataUtils.getStr(json, "attack_ascription");
            String subArea = DataUtils.getStr(json, "dept_label");
            boolean isdatacenter = false;
            if (StringUtils.isBlank(area))
                area = "其他";
            if (StringUtils.isBlank(subArea))
                subArea = "其他";
            String attackAscription = DataUtils.getStr(json, "attack_ascription");
            if (attackAscription.contains("数据中心")) {
                isdatacenter = true;
            }
            jsonObject.put("attack_result", DataUtils.getStr(json, "attack_result"));
            jsonObject.put("reg_area", area);
            jsonObject.put("reg_sub_area", subArea);
            jsonObject.put("event_source", DataUtils.getStr(json, "device_label").replace("SSP-", "").replace("-自动", ""));
            jsonObject.put("event_level", DataUtils.getStr(json, "level_label"));
            jsonObject.put("attack_type", DataUtils.getStr(json, "attack_means_label"));
            jsonObject.put("isdatacenter", isdatacenter);
            jsonObject.put("isworkday", checkTimeIsWork());
            Date alarmTime = DataUtils.getDateX(json, "alarm_time");
            if (alarmTime == null) {
                alarmTime = DataUtils.getDateX(json, "create_time");
            }
            if (alarmTime == null) {
                alarmTime = new Date();
            }
            jsonObject.put("alarm_time", DateUtils.getDateTimeString1(alarmTime));
            jsonObject.put("event_description", DataUtils.getStr(json, "detail"));
            jsonObject.put("src_ip", srcIp);
            jsonObject.put("dest_ip", destIp);
            jsonObject.put("event_name", DataUtils.getStr(json, "title"));

            jsonObject.forEach((k, v) -> {
                if (v instanceof String) {
                    if (StringUtils.isBlank(v.toString())) {
                        jsonObject.put(k, "\\N");
                    } else {
                        if (k.equalsIgnoreCase("reg_area") && ((String) v).equalsIgnoreCase("其他")) {
                            jsonObject.put(k, "\\N");
                        } else if (k.equalsIgnoreCase("reg_sub_area") && ((String) v).equalsIgnoreCase("其他")) {
                            jsonObject.put(k, "\\N");
                        }
                    }
                }
            });
        } catch (Exception e) {
            log.error(e.getMessage(), e);
        }
        return jsonObject;
    }

    //工作日还是周末
    public static boolean checkTimeIsWork() {
        boolean flag = false;
        try {
            DateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
            String date = sdf.format(new Date());
            Date testdate = sdf.parse(date);
            Calendar cal = Calendar.getInstance();
            cal.setTime(testdate);
            int x = cal.get(Calendar.DAY_OF_WEEK);
            switch (x) {
                case Calendar.MONDAY:
                case Calendar.TUESDAY:
                case Calendar.WEDNESDAY:
                case Calendar.THURSDAY:
                case Calendar.FRIDAY:
                    flag = true;
                    break;
                case Calendar.SATURDAY:
                case Calendar.SUNDAY:
                    flag = false;
                    break;
            }

        } catch (Exception e) {
            log.error(e.getMessage(), e);
        }
        return flag;
    }
}
