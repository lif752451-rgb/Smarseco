package com.crc.sync.ai;

import com.alibaba.fastjson.JSONObject;
import com.crc.SpringbootApplication;
import com.crc.common.constants.LogConstantsX;
import com.crc.common.utils.*;
import com.crc.secface.config.GetSpringBean;
import com.crc.secface.entity.TbAsset;
import com.crc.secface.entity.TbAssetSegement;
import com.crc.secface.entity.TbEventModel;
import com.crc.secface.mapper.TbAssetMapper;
import com.crc.sync.net.NewSegmentLoad;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.*;

/*
AI 研判
 */
@Slf4j
public class AiCheckSync {

    public static Map<String, String> getAiInfo(JSONObject json, String alarmId) {
        json.forEach((k, v) -> {
            if (v instanceof String) {
                if (StringUtils.isBlank(v.toString())) {
                    json.put(k, "\\N");
                } else {
                    if (k.equalsIgnoreCase("reg_area") && ((String) v).equalsIgnoreCase("其他")) {
                        json.put(k, "\\N");
                    } else if (k.equalsIgnoreCase("reg_sub_area") && ((String) v).equalsIgnoreCase("其他")) {
                        json.put(k, "\\N");
                    }
                }
            }
        });
        String ret = HttpUtils.sendPost(SpringbootApplication.OP_CONFIG.getAiUrl(), json.toJSONString());
        log.info("{},ret={}", alarmId, ret);
        JSONObject retJson = JsonUtils.parse(ret);
        Map<String, String> resultMap = new HashMap<>();
        try {
            if (retJson != null && retJson.size() > 0) {
                String priority = JsonUtils.getStr(retJson, "priority");
                String solution = JsonUtils.getStr(retJson, "solution");
                String solutions = JsonUtils.getStr(retJson, "solutions");
                resultMap.put("priority", priority);
                resultMap.put("solution", solution);
                resultMap.put("solutions", "{" + solutions + "}");
            }
        } catch (Exception e) {
            log.error(e.getMessage(), e);
        }
        log.info(String.format("%s AI:%s,AI研判置信度：%s", alarmId, json.toJSONString(), resultMap.get("priority")));
        return resultMap;
    }

    public static Map<String, String> getAiInfo(JSONObject json) {
        json.forEach((k, v) -> {
            if (v instanceof String) {
                if (StringUtils.isBlank(v.toString())) {
                    json.put(k, "\\N");
                } else {
                    if (k.equalsIgnoreCase("reg_area") && ((String) v).equalsIgnoreCase("其他")) {
                        json.put(k, "\\N");
                    } else if (k.equalsIgnoreCase("reg_sub_area") && ((String) v).equalsIgnoreCase("其他")) {
                        json.put(k, "\\N");
                    }
                }
            }
        });
        String ret = HttpUtils.sendPost(SpringbootApplication.OP_CONFIG.getAiUrl(), json.toJSONString());
        JSONObject retJson = JsonUtils.parse(ret);
        Map<String, String> resultMap = new HashMap<>();
        try {
            if (retJson != null && retJson.size() > 0) {
                String priority = JsonUtils.getStr(retJson, "priority");
                String solution = JsonUtils.getStr(retJson, "solution");
                String solutions = JsonUtils.getStr(retJson, "solutions");
                resultMap.put("priority", priority);
                resultMap.put("solution", solution);
                resultMap.put("solutions", "{" + solutions + "}");
            }
        } catch (Exception e) {
            log.error(e.getMessage(), e);
        }
        log.info(String.format("AI:%s,AI研判置信度：%s", json.toJSONString(), resultMap.get("priority")));
        return resultMap;
    }

    public static Map<String, String> getAiCheckV3(JSONObject jsonObject, TbEventModel model) {
        JSONObject json = transV3(jsonObject, model);

        json.forEach((k, v) -> {
            if (v instanceof String) {
                if (StringUtils.isBlank(v.toString())) {
                    json.put(k, "\\N");
                } else {
                    if (k.equalsIgnoreCase("reg_area") && ((String) v).equalsIgnoreCase("其他")) {
                        json.put(k, "\\N");
                    } else if (k.equalsIgnoreCase("reg_sub_area") && ((String) v).equalsIgnoreCase("其他")) {
                        json.put(k, "\\N");
                    }
                }
            }
        });
        return getAiInfo(json);
    }

    /**
     * 远程调用参数转换 V2
     *
     * @param json
     * @return
     */
    public static JSONObject transV3(JSONObject json, TbEventModel model) {
        JSONObject jsonObject = new JSONObject();
        String srcIp = JsonUtils.getStr(json, "src_ip");//攻击ip
        List<String> srcList = IpUtils.getIps(srcIp);
        TbAssetMapper assetMapper = GetSpringBean.getBean(TbAssetMapper.class);
        List<String> areaList = new ArrayList<>();
        List<String> subAreaList = new ArrayList<>();
        boolean isdatacenter = false;
        if (srcList.size() > 0) {
            for (String ip : srcList) {
                TbAsset asset = assetMapper.selectTbAssetByInnerIp(ip);
                if (asset != null) {
                    String area = DataUtils.getDeptTree(asset.getArea(),1);
                    if (asset.getArea() != null && asset.getArea().contains("数据中心"))
                        isdatacenter = true;
                    if (StringUtils.isNotBlank(area)) {
                        areaList.add(area);
                    }
                    String subArea = DataUtils.getDeptTree(asset.getArea(),2);
                    if (StringUtils.isNotBlank(subArea)) {
                        subAreaList.add(subArea);
                    }
                } else {
                    TbAssetSegement rdata = NewSegmentLoad.getIPSegmentByHalf(ip);
                    if (rdata != null) {
                        String area = DataUtils.getDeptTree(rdata.getAreaName(),1);
                        if (rdata.getAreaName() != null && area.contains("数据中心"))
                            isdatacenter = true;
                        if (StringUtils.isNotBlank(area)) {
                            areaList.add(area);
                        }
                        String subArea = DataUtils.getDeptTree(rdata.getAreaName(),2);
                        if (StringUtils.isNotBlank(subArea)) {
                            subAreaList.add(subArea);
                        }
                    }
                }
            }
        }
        String area = String.join(",", areaList);
        String subArea = String.join(",", subAreaList);

        if (StringUtils.isBlank(area))
            area = "其他";
        if (StringUtils.isBlank(subArea))
            subArea = "其他";
        jsonObject.put("attack_result", model.getAttackResult());
        jsonObject.put("reg_area", area);
        jsonObject.put("reg_sub_area", subArea);
        jsonObject.put("event_source", model.getDeviceNameStr() + "-自动");
        jsonObject.put("event_level", model.getEventLevelName());
        jsonObject.put("attack_type", model.getAttackTypeName());
        jsonObject.put("isdatacenter", isdatacenter);
        jsonObject.put("isworkday", checkTimeIsWork());
        if (!StringUtils.isBlank(JsonUtils.getStr(json, "log_start_time")))
            jsonObject.put("alarm_time", JsonUtils.getStr(json, "log_start_time").split(",")[0]);
        else {
            jsonObject.put("alarm_time", DateUtils.getDateTimeString1(new Date()));
        }
        jsonObject.put("event_description", JsonUtils.getStr(json, "event_description"));
        jsonObject.put("src_ip", JsonUtils.getStr(json, "src_ip"));
        jsonObject.put("dest_ip", JsonUtils.getStr(json, "dest_ip"));
        jsonObject.put("event_name", JsonUtils.getStr(json,LogConstantsX.LOG_NAME));
        return jsonObject;
    }


    //工作日还是周末
    private static boolean checkTimeIsWork() {
        boolean flag = false;
        try {
            DateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
            String date = sdf.format(new Date());
            Date testdate = sdf.parse(date);
            Calendar cal = Calendar.getInstance();
            cal.setTime(testdate);
            int x = cal.get(Calendar.DAY_OF_WEEK);
            switch (x) {
                case Calendar.MONDAY:
                case Calendar.TUESDAY:
                case Calendar.WEDNESDAY:
                case Calendar.THURSDAY:
                case Calendar.FRIDAY:
                    flag = true;
                    break;
                case Calendar.SATURDAY:
                case Calendar.SUNDAY:
                    flag = false;
                    break;
            }

        } catch (Exception e) {
            log.error(e.getMessage(), e);
        }
        if (flag) {
            return isEffectiveDate(DateUtils.getCurrentDayFormat6(), "09:00:00", "18:00:00");
        }
        return flag;
    }

    /**
     * 判断当前时间是否在[startTime, endTime]区间，注意时间格式要一致
     *
     * @param nowDate   当前时间
     * @param startDate 开始时间
     * @param endDate   结束时间
     * @return
     * @author szh
     */
    public static boolean isEffectiveDate(String nowDate, String startDate, String endDate) {
        try {
            String format = "HH:mm:ss";
            Date startTime = new SimpleDateFormat(format).parse(startDate);
            Date endTime = new SimpleDateFormat(format).parse(endDate);
            Date nowTime = new SimpleDateFormat(format).parse(nowDate);

            if (nowTime.getTime() == startTime.getTime()
                    || nowTime.getTime() == endTime.getTime()) {
                return true;
            }
            long now = nowTime.getTime();
            long begin = startTime.getTime();
            long end = endTime.getTime();

            return now > begin && now < end;
        } catch (Exception e) {
            log.error(e.getMessage(), e);
        }
        return false;
    }
}
