package com.crc.sync.send;

import com.alibaba.fastjson.JSON;
import com.crc.common.utils.IdGen;
import com.crc.common.utils.IpUtils;
import com.crc.common.utils.MyTheadUtils;
import com.crc.common.utils.StringUtils;
import com.crc.secface.config.GetSpringBean;
import com.crc.secface.config.SyncSecConfig;
import com.crc.secface.entity.AlarmIp;
import com.crc.secface.entity.InternetPublishApp;
import com.crc.secface.entity.TbAlarmCombatReport;
import com.crc.secface.entity.TbAlarmReport;
import com.crc.secface.mapper.InternetPublishAppMapper;
import com.crc.secface.mapper.TbAlarmReportMapper;
import com.crc.secface.response.AssetAsmInternetResponse;
import com.crc.secface.response.InternetPublishAppResponse;
import lombok.extern.slf4j.Slf4j;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Date;
import java.util.List;
import java.util.concurrent.ArrayBlockingQueue;

/**
 * @author jixiangqi
 * @date 2023/7/18
 * 发送消息到scp互联网发布应用
 */
@Slf4j
public class SendToScpInternetPublishApp extends Thread {

    public static ArrayBlockingQueue<AlarmIp> magicQueue = new ArrayBlockingQueue<>(50000);

    @Override
    public void run() {
        log.info("互联网发布告警消息入库。。。。");
        while (true) {
            if (magicQueue.isEmpty()) {
                MyTheadUtils.sleepBySec(1);
            } else {
                while (!magicQueue.isEmpty()) {
                    try {
                        AlarmIp alarmIp = magicQueue.poll();
                        insertOrUpdate(alarmIp);
                        MyTheadUtils.sleep(10);
                    } catch (Exception e) {
                        log.error(e.getMessage(), e);
                    }
                }
            }
        }
    }

    private void insertOrUpdate(AlarmIp alarmIp) {
        if (!SyncSecConfig.isEnable("sync_sec_config", "internet_app_alarm_enable")) {
            return;
        }
        TbAlarmReportMapper alarmReportMapper = GetSpringBean.getBean(TbAlarmReportMapper.class);
        InternetPublishAppMapper internetPublishAppMapper = GetSpringBean.getBean(InternetPublishAppMapper.class);

        List<String> ipList = IpUtils.getIps(alarmIp.getSrcIp());
        ipList.addAll(IpUtils.getIps(alarmIp.getDestIp()));
        List<String> outIpList = new ArrayList<>();
        if (ipList.size() > 0) {
            for (String ip : ipList) {
                if (IpUtils.isInternetIP(ip)) {
                    outIpList.add(ip);
                }
            }
        }
        if(outIpList.size() > 0) {
            log.info("{},发现互联网 IP={}", alarmIp.getAlarmId(), JSON.toJSONString(outIpList));
        }
        if (outIpList.size() > 0) {
            for (String ip : outIpList) {
                List<AssetAsmInternetResponse> dataList = internetPublishAppMapper.searchByIp(ip);
                if (dataList != null && dataList.size() > 0) {
                    for (AssetAsmInternetResponse internetAlarmResponse : dataList) {


                        if (alarmIp.getAlarmId().contains("-K-")) {
                            TbAlarmCombatReport alarmReport = alarmReportMapper.loadCombat(alarmIp.getAlarmId());
                            if (alarmReport == null) {
                                log.error("{}，没有找到对应的告警数据", alarmIp.getAlarmId());
                                continue;
                            }
                            if (100L != alarmReport.getOrganizationId()) {
                                continue;
                            }
                            AlarmIp q = new AlarmIp();
                            q.setSrcIp(internetAlarmResponse.getAssetId());
                            q.setAlarmId(alarmReport.getAlarmId());
                            List<InternetPublishAppResponse> tmpList = internetPublishAppMapper.getRepeatDataByAlarmNId(q);
                            if (tmpList == null || tmpList.size() < 1) {
                                InternetPublishApp internetPublishApp = new InternetPublishApp();
                                internetPublishApp.setAffiliationDeptNodeId(internetAlarmResponse.getAffiliationDeptNodeId());
                                internetPublishApp.setAffiliationDeptName(internetAlarmResponse.getAffiliationDeptName());
                                internetPublishApp.setAssetId(internetAlarmResponse.getAssetId());
                                internetPublishApp.setIp(internetAlarmResponse.getIp());
                                internetPublishApp.setPort(internetAlarmResponse.getPort());
                                internetPublishApp.setDomainName(internetAlarmResponse.getDomainName());
                                internetPublishApp.setRelationIp(internetAlarmResponse.getIp());
                                internetPublishApp.setFightPeriodType(alarmReport.getFightPeriodType());
                                internetPublishApp.setAlarmId(String.valueOf(alarmReport.getId()));
                                internetPublishApp.setAlarmCode(alarmReport.getAlarmId());
                                internetPublishApp.setAlarmLevel(alarmReport.getLevel());
                                internetPublishApp.setAlarmTitle(alarmReport.getTitle());
                                internetPublishApp.setAttackResult(alarmReport.getAttackResult());
                                internetPublishApp.setAttackMeans(alarmReport.getAttackMeans());
                                internetPublishApp.setAttackCount(alarmReport.getAttackCount());
                                internetPublishApp.setAlarmTime(alarmReport.getAlarmTime());
                                internetPublishApp.setAlarmCreateTime(alarmReport.getCreateTime());
                                internetPublishApp.setOrderStatus(alarmReport.getOrderStatus());
                                internetPublishApp.setInternetId(internetAlarmResponse.getId());
                                internetPublishApp.setType(2);
                                internetPublishApp.setOrganizationId(String.valueOf(alarmReport.getOrganizationId()));
                                internetPublishApp.setId(IdGen.uuid());
                                internetPublishApp.setCreateTime(new Date());
                                internetPublishApp.setUpdateTime(new Date());
                                internetPublishApp.setCreateBy("task");
                                log.info("作战周期，互联网资产关联-> {}--{}", alarmIp.getAlarmId(), alarmIp.getSrcIp());
                                internetPublishAppMapper.insert(Collections.singletonList(internetPublishApp));
                            }
                        } else {
                            TbAlarmReport alarmReport = alarmReportMapper.load(alarmIp.getAlarmId());
                            if (alarmReport == null) {
                                log.error("{}，没有找到对应的告警数据", alarmIp.getAlarmId());
                                continue;
                            }
                            if (100L != alarmReport.getOrganizationId()) {
                                continue;
                            }
                            AlarmIp q = new AlarmIp();
                            q.setSrcIp(internetAlarmResponse.getAssetId());
                            q.setAlarmId(alarmReport.getAlarmId());
                            List<InternetPublishAppResponse> tmpList = internetPublishAppMapper.getRepeatDataByAlarmNId(q);
                            if (tmpList == null || tmpList.size() < 1) {
                                InternetPublishApp internetPublishApp = new InternetPublishApp();
                                internetPublishApp.setAffiliationDeptNodeId(internetAlarmResponse.getAffiliationDeptNodeId());
                                internetPublishApp.setAffiliationDeptName(internetAlarmResponse.getAffiliationDeptName());
                                internetPublishApp.setAssetId(internetAlarmResponse.getAssetId());
                                internetPublishApp.setIp(internetAlarmResponse.getIp());
                                internetPublishApp.setPort(internetAlarmResponse.getPort());
                                internetPublishApp.setDomainName(internetAlarmResponse.getDomainName());
                                internetPublishApp.setRelationIp(internetAlarmResponse.getIp());
                                internetPublishApp.setAlarmId(String.valueOf(alarmReport.getId()));
                                internetPublishApp.setAlarmCode(alarmReport.getAlarmId());
                                internetPublishApp.setAlarmLevel(alarmReport.getLevel());
                                internetPublishApp.setAlarmTitle(alarmReport.getTitle());
                                internetPublishApp.setAttackResult(alarmReport.getAttackResult());
                                internetPublishApp.setAttackMeans(alarmReport.getAttackMeans());
                                internetPublishApp.setAttackCount(alarmReport.getAttackCount());
                                internetPublishApp.setAlarmTime(alarmReport.getAlarmTime());
                                internetPublishApp.setAlarmCreateTime(alarmReport.getCreateTime());
                                internetPublishApp.setOrderStatus(alarmReport.getOrderStatus());
                                internetPublishApp.setInternetId(internetAlarmResponse.getId());
                                internetPublishApp.setType(1);
                                internetPublishApp.setOrganizationId(String.valueOf(alarmReport.getOrganizationId()));
                                internetPublishApp.setId(IdGen.uuid());
                                internetPublishApp.setCreateTime(new Date());
                                internetPublishApp.setUpdateTime(new Date());
                                internetPublishApp.setCreateBy("task");
                                log.info("常态化，互联网资产关联-> {}--{}", alarmIp.getAlarmId(), alarmIp.getSrcIp());
                                internetPublishAppMapper.insert(Collections.singletonList(internetPublishApp));
                            }
                        }
                    }
                }
            }
        }
        List<String> urlList = new ArrayList<>();
        if (StringUtils.isNotBlank(alarmIp.getHost())) {
            urlList.add(alarmIp.getHost());
        }
        if (StringUtils.isNotBlank(alarmIp.getUrl())) {
            urlList.add(alarmIp.getUrl());
        }
        if(urlList.size() > 0) {
            log.info("{},发现互联网 URL={}", alarmIp.getAlarmId(), JSON.toJSONString(urlList));
        }
        if (urlList.size() > 0) {
            for (String url : urlList) {
                List<AssetAsmInternetResponse> dataList = internetPublishAppMapper.searchByUrlOrHost(url);
                if (dataList != null && dataList.size() > 0) {
                    for (AssetAsmInternetResponse internetAlarmResponse : dataList) {
                        if (alarmIp.getAlarmId().contains("-K-")) {
                            TbAlarmCombatReport alarmReport = alarmReportMapper.loadCombat(alarmIp.getAlarmId());
                            if (alarmReport == null) {
                                log.error("{}，没有找到对应的告警数据", alarmIp.getAlarmId());
                                continue;
                            }
                            if (100L != alarmReport.getOrganizationId()) {
                                continue;
                            }
                            AlarmIp q = new AlarmIp();
                            q.setSrcIp(internetAlarmResponse.getAssetId());
                            q.setAlarmId(alarmReport.getAlarmId());
                            List<InternetPublishAppResponse> tmpList = internetPublishAppMapper.getRepeatDataByAlarmNId(q);
                            if (tmpList == null || tmpList.size() < 1) {
                                InternetPublishApp internetPublishApp = new InternetPublishApp();
                                internetPublishApp.setAffiliationDeptNodeId(internetAlarmResponse.getAffiliationDeptNodeId());
                                internetPublishApp.setAffiliationDeptName(internetAlarmResponse.getAffiliationDeptName());
                                internetPublishApp.setAssetId(internetAlarmResponse.getAssetId());
                                internetPublishApp.setIp(internetAlarmResponse.getIp());
                                internetPublishApp.setPort(internetAlarmResponse.getPort());
                                internetPublishApp.setDomainName(internetAlarmResponse.getDomainName());
                                internetPublishApp.setRelationIp(internetAlarmResponse.getIp());
                                internetPublishApp.setFightPeriodType(alarmReport.getFightPeriodType());
                                internetPublishApp.setAlarmId(alarmReport.getId());
                                internetPublishApp.setAlarmCode(alarmReport.getAlarmId());
                                internetPublishApp.setAlarmLevel(alarmReport.getLevel());
                                internetPublishApp.setAlarmTitle(alarmReport.getTitle());
                                internetPublishApp.setAttackResult(alarmReport.getAttackResult());
                                internetPublishApp.setAttackMeans(alarmReport.getAttackMeans());
                                internetPublishApp.setAttackCount(alarmReport.getAttackCount());
                                internetPublishApp.setAlarmTime(alarmReport.getAlarmTime());
                                internetPublishApp.setAlarmCreateTime(alarmReport.getCreateTime());
                                internetPublishApp.setOrderStatus(alarmReport.getOrderStatus());
                                internetPublishApp.setInternetId(internetAlarmResponse.getId());
                                internetPublishApp.setType(2);
                                internetPublishApp.setOrganizationId(String.valueOf(alarmReport.getOrganizationId()));
                                internetPublishApp.setId(IdGen.uuid());
                                internetPublishApp.setCreateTime(new Date());
                                internetPublishApp.setUpdateTime(new Date());
                                internetPublishApp.setCreateBy("task");
                                log.info("作战周期，互联网资产关联-> {}--{}", alarmIp.getAlarmId(), alarmIp.getSrcIp());
                                internetPublishAppMapper.insert(Collections.singletonList(internetPublishApp));
                            }
                        } else {
                            TbAlarmReport alarmReport = alarmReportMapper.load(alarmIp.getAlarmId());
                            if (alarmReport == null) {
                                log.error("{}，没有找到对应的告警数据", alarmIp.getAlarmId());
                                continue;
                            }
                            if (100L != alarmReport.getOrganizationId()) {
                                continue;
                            }
                            AlarmIp q = new AlarmIp();
                            q.setSrcIp(internetAlarmResponse.getAssetId());
                            q.setAlarmId(alarmReport.getAlarmId());
                            List<InternetPublishAppResponse> tmpList = internetPublishAppMapper.getRepeatDataByAlarmNId(q);
                            if (tmpList == null || tmpList.size() < 1) {
                                InternetPublishApp internetPublishApp = new InternetPublishApp();
                                internetPublishApp.setAffiliationDeptNodeId(internetAlarmResponse.getAffiliationDeptNodeId());
                                internetPublishApp.setAffiliationDeptName(internetAlarmResponse.getAffiliationDeptName());
                                internetPublishApp.setAssetId(internetAlarmResponse.getAssetId());
                                internetPublishApp.setIp(internetAlarmResponse.getIp());
                                internetPublishApp.setPort(internetAlarmResponse.getPort());
                                internetPublishApp.setDomainName(internetAlarmResponse.getDomainName());
                                internetPublishApp.setRelationIp(internetAlarmResponse.getIp());
                                internetPublishApp.setAlarmId(String.valueOf(alarmReport.getId()));
                                internetPublishApp.setAlarmCode(alarmReport.getAlarmId());
                                internetPublishApp.setAlarmLevel(alarmReport.getLevel());
                                internetPublishApp.setAlarmTitle(alarmReport.getTitle());
                                internetPublishApp.setAttackResult(alarmReport.getAttackResult());
                                internetPublishApp.setAttackMeans(alarmReport.getAttackMeans());
                                internetPublishApp.setAttackCount(alarmReport.getAttackCount());
                                internetPublishApp.setAlarmTime(alarmReport.getAlarmTime());
                                internetPublishApp.setAlarmCreateTime(alarmReport.getCreateTime());
                                internetPublishApp.setOrderStatus(alarmReport.getOrderStatus());
                                internetPublishApp.setInternetId(internetAlarmResponse.getId());
                                internetPublishApp.setType(1);
                                internetPublishApp.setOrganizationId(String.valueOf(alarmReport.getOrganizationId()));
                                internetPublishApp.setId(IdGen.uuid());
                                internetPublishApp.setCreateTime(new Date());
                                internetPublishApp.setUpdateTime(new Date());
                                internetPublishApp.setCreateBy("task");
                                log.info("常态化，互联网资产关联-> {}--{}", alarmIp.getAlarmId(), alarmIp.getSrcIp());
                                internetPublishAppMapper.insert(Collections.singletonList(internetPublishApp));
                            }
                        }
                    }
                }
            }
        }
    }
}
