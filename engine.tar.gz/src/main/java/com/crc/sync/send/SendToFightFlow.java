package com.crc.sync.send;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;
import com.crc.SpringbootApplication;
import com.crc.common.constants.LogConstants;
import com.crc.common.constants.LogConstantsX;
import com.crc.common.constants.ModelTypeEnum;
import com.crc.common.utils.*;
import com.crc.secface.argo.AlarmUtils;
import com.crc.secface.argo.AssetUtils;
import com.crc.secface.config.GetSpringBean;
import com.crc.secface.config.SyncSecConfig;
import com.crc.secface.entity.*;
import com.crc.secface.mapper.CommonMapper;
import com.crc.secface.mapper.TbEventMapper;
import com.crc.secface.mapper.TbEventModelMapper;
import com.crc.secface.mapper.TbOriDangerEventMapper;
import com.crc.secface.redis.RedisUtil;
import com.crc.sync.ai.AiCheckSync;
import com.crc.sync.data.AlarmAssetSyncToDb;
import com.crc.sync.data.AlarmLogSyncNow;
import com.crc.sync.net.DataCenterLoad;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;

import java.util.*;
import java.util.concurrent.ArrayBlockingQueue;


/**
 * 实战告警推送
 */
@Slf4j
public class SendToFightFlow extends Thread {
    public static ArrayBlockingQueue<FlowModel> magicQueue = new ArrayBlockingQueue<>(50000);

    public void run() {
        log.info("新版本实战安全告警推送Fight。。。。");
        while (true) {
            if (magicQueue.isEmpty()) {
                MyTheadUtils.sleep(20);
            } else {
                while (!magicQueue.isEmpty()) {
                    try {
                        MyTheadUtils.sleep(20);
                        log.info("SendToFightFlow队列数量：{}", magicQueue.size());
                        FlowModel data = magicQueue.poll();
                        try {
                            TbEventModelMapper modelMapper = GetSpringBean.getBean(TbEventModelMapper.class);

                            int count = modelMapper.selectModelCount(data.getModel().getModelId());
                            if (count < 1) {
                                log.warn("{}已关闭，告警丢弃！", data.getModel().getModelId());
                                continue;
                            }
                        } catch (Exception e) {
                            log.error(e.getMessage(), e);
                        }

                        String indexName = JsonUtils.getStr(data.getFJson(), LogConstants.ES_LOG_INDEX);
                        JSONObject toSendJson = null;
                        String modelId = "";
                        if (data.getModel() != null) {
                            toSendJson = transV2(data.getFJson(), data.getModel());
                            modelId = data.getModel().getModelId();
                        }
                        if (toSendJson == null) {
                            log.error("{}转换工单推送结构失败！{}", modelId, data.getFJson().toJSONString());
                            continue;
                        }

                        //System.out.println(data.getfJson());
                        //String aiCheck = AiCheckSync.getAiCheck(data.getfJson());

                        // V2 版本，姬向奇2021年12月28日修改
                        Map<String, String> resultMap = new HashMap<>();
                        if ("T".equalsIgnoreCase(SpringbootApplication.OP_CONFIG.getAiCheck())) {
                            if (data.getModel() != null) {
                                resultMap = AiCheckSync.getAiCheckV3(data.getFJson(), data.getModel());
                                toSendJson.put("solutions", resultMap.get("solutions"));
                                toSendJson.put("aiCheck", resultMap.get("priority"));
                            }
                        }
                        //写入实战作战周期
                        toSendJson.put("fightPeriodType", data.getFightTab());
                        toSendJson.put("eventModelId", data.getModel().getId());
                        String stpApi = SyncSecConfig.getRemarkValue(SyncSecConfig.STP_API_URL);
                        if (StringUtils.isBlank(stpApi)) {
                            stpApi = SpringbootApplication.OP_CONFIG.getStpUrl();
                        }
                        //stpApi = SpringbootApplication.OP_CONFIG.getStpUrl() + "/alarm/combat/report/auto/report/alarm";
                        stpApi = stpApi + "/alarm/report/reportAlarmAuto";
                        String res = "";

                        List<SysDictData> dictList = DictUtil.getDict("company_alarm_push_config");
                        if (dictList == null) {
                            //没有配置规则
                            res = HttpUtils.sendPost(stpApi, toSendJson.toJSONString());
                        } else {
                            int sendCount = 0;//发送多少个业务单元
                            boolean sendBoth = false;//是否同时发（业务单元和集团）
                            log.info("自定义推送到利润中心配置数量=" + dictList.size());
                            for (SysDictData dictData : dictList) {
                                JSONObject sendJson = toSendJson.clone();
                                try {
                                    /*
                                     * {
                                     *   "src_ip": "华润创业",
                                     *   "dest_ip": "华润创业",
                                     *   "dept_id": "226",
                                     *    "policy":"all"
                                     * }
                                     */
                                    if (StringUtils.isBlank(dictData.getRemark())) {
                                        continue;
                                    }
                                    JSONObject jsonObject = JsonUtils.parse(dictData.getRemark());
                                    String srcDeptFix = JsonUtils.getStr(jsonObject, "src_ip");//源IP归属组织
                                    String destDeptFix = JsonUtils.getStr(jsonObject, "dest_ip");//目标IP归属组织
                                    long officeId = JsonUtils.getLong(jsonObject, "dept_id");//归属组织ID
                                    if (officeId < 1) {
                                        log.error("自定义推送到利润中心未配置推送组织ID，字典company_alarm_push_config");
                                        continue;
                                    }
                                    if (StringUtils.isBlank(srcDeptFix) && StringUtils.isBlank(destDeptFix)) {
                                        log.error("自定义推送到利润中心未配置推送,源IP或目标IP归属组织匹配策略，字典company_alarm_push_config");
                                        continue;
                                    }

                                    //attackIp 攻击IP
                                    //victimizedIp  受害IP
                                    List<String> srcFixList = new ArrayList<>(Arrays.asList(srcDeptFix.split(",")));
                                    List<String> destFixList = new ArrayList<>(Arrays.asList(destDeptFix.split(",")));
                                    if (srcFixList.size() < 1 && destFixList.size() < 1) {
                                        continue;
                                    }
                                    boolean tflag = AssetUtils.checkAssetByInFixName(srcFixList, destFixList, data.getFJson());
                                    if (!tflag) {
                                        continue;
                                    }

                                    try {
                                        sendJson.put("source", officeId);
                                        sendJson.put("organizationId", officeId);
                                        res = HttpUtils.sendPost(stpApi, sendJson.toJSONString());
                                        log.info("命中：{},{},自定义推送到利润中心:{}====发送{}", dictData.getDictLabel(), modelId, officeId, sendJson);
                                        sendCount++;
                                        saveSaasFlow(data, res, sendJson, resultMap, indexName, officeId);
                                    } catch (Exception e) {
                                        log.error(e.getMessage(), e);
                                    }

                                    String policy = JsonUtils.getStr(jsonObject, "policy");
                                    if ("all".equalsIgnoreCase(policy)) {
                                        sendBoth = true;
                                    }
                                } catch (Exception e) {
                                    log.error(e.getMessage(), e);
                                }
                            }
                            MyTheadUtils.sleep(20);
                            if (sendCount < 1) {
                                //没有命中用户的规则，须发给集团
                                log.info("{},没有命中用户的规则，须发给集团", modelId);
                                toSendJson.put("source", 100);
                                toSendJson.put("organizationId", 100);
                                res = HttpUtils.sendPost(stpApi, toSendJson.toJSONString());
                            } else {
                                if (sendBoth) {
                                    log.info("{},命中用户的规则，同时发给集团", modelId);
                                    toSendJson.put("source", 100);
                                    toSendJson.put("organizationId", 100);
                                    res = HttpUtils.sendPost(stpApi, toSendJson.toJSONString());
                                } else {
                                    log.info("{},命中用户的规则，但不需发给集团", modelId);
                                }
                            }
                        }


                        JSONObject jsonObject = JsonUtils.parse(res);
                        //{"msg":"SSP2021-1244","code":200}
                        log.info(modelId + String.format("线程返回:%s,推送新版STP:%s,AI研判置信度：%s", res, toSendJson.toJSONString(), resultMap.get("priority")));
                        if ("200".equals(JsonUtils.getStr(jsonObject, "code"))) {
                            String orderId = "";
                            if (jsonObject.get("data") instanceof JSONObject) {
                                orderId = JsonUtils.getStr(jsonObject.getJSONObject("data"), "data");
                            } else {
                                orderId = JsonUtils.getStr(jsonObject, "data");
                            }
                            if (StringUtils.isBlank(orderId)) {
                                orderId = JsonUtils.getStr(jsonObject, "msg");
                            } else if (orderId.contains("成功")) {
                                orderId = JsonUtils.getStr(jsonObject, "msg");
                            }
                            // 根据工单号更新tb_event表中的数据
                            proc(data, data.getFJson(), orderId, resultMap, indexName);

                            //TODO 写入消息队列
                            AlarmIp alarmIp = new AlarmIp();
                            alarmIp.setAlarmId(orderId);
                            alarmIp.setSrcIp(JsonUtils.getStr(data.getFJson(), LogConstantsX.SRC_IP));
                            alarmIp.setDestIp(JsonUtils.getStr(data.getFJson(), LogConstantsX.DEST_IP));
                            alarmIp.setFightPeriodType(data.getFightTab());
                            SendToScpInternetPublishApp.magicQueue.offer(alarmIp);

                            try {
                                RworkModel rm = new RworkModel();
                                data.getFJson().put("ai_check", resultMap.get("priority"));
                                data.getFJson().put("solution", resultMap.get("solution"));
                                rm.setOrderId(orderId);
                                rm.setJson(data.getFJson());
                                rm.setModel(data.getModel());
                                SendToRwork.magicQueue.offer(rm);
                            } catch (Exception e) {
                                log.error(modelId + ",根据工单号更新tb_event表中的数据失败，原因为" + e.getMessage(), e);
                            }
                            //web后门、勒索病毒、RDP暴力破解
                            data.setAlarmId(orderId);
                            String logName = JsonUtils.getStr(data.getFJson(), LogConstantsX.LOG_NAME);
                            if (DataCenterLoad.isNeedToSendDataCenter(logName)) {
                                DangerEventToAlarmCenter.magicQueue.offer(data);
                            } else {
                                log.info("{}不符合要求(后门/勒索/暴力破解)，不推送告警中心", logName);
                            }
                        } else {
                            //推送失败返回队列
                            if (JsonUtils.getStr(jsonObject, "msg").contains("限流中")) {
                                log.info("限流中：" + res);
                                MyTheadUtils.sleep(20);
                            } else {
                                log.info("推送失败：{},发送数据：{},原始：{}", res, toSendJson.toJSONString(), data.getFJson().toJSONString());
                            }
                        }
                        MyTheadUtils.sleep(10);
                    } catch (Exception e) {
                        log.error(e.getMessage(), e);
                    }
                }
            }
        }
    }

    public void proc(FlowModel model, JSONObject json, String flowId, Map<String, String> resultMap, String indexName) {
        try {
            TbEventMapper tbEventMapper = GetSpringBean.getBean(TbEventMapper.class);
            //事件基本信息
            TbEvent event = new TbEvent();
            String operator = "admin";
            TbEvent tx = tbEventMapper.getAlarmCombatId(flowId);
            if (tx == null || StringUtils.isBlank(tx.getId()))
                event.setId(IdGen.uuid());
            else {
                event.setId(tx.getId());
            }
            event.setStatus("研判");
            event.setCreateBy(operator);
            event.setDelFlag(0);
            if (model.getModel() != null) {
                event.setAttackResult(model.getModel().getAttackResult());
                event.setBusModel(model.getModel().getModelId());
                event.setEventName(JsonUtils.getStr(json, LogConstantsX.LOG_NAME));
                event.setAttackType(model.getModel().getAttackTypeName());
                event.setEventLevel(model.getModel().getEventLevelName());
                String product = AlarmUtils.getDeviceName(json, model.getModel());
                event.setEventSource(product);
            }
            event.setStatus("待处置");
            event.setCreateTime(new Date());
            event.setAttackCount(JsonUtils.getLong(json, LogConstantsX.LOG_COUNT, 1));
            event.setCommitTime(event.getCreateTime());
            event.setAlarmTime(JsonUtils.getDate(json, LogConstantsX.LOG_START_TIME));
            event.setAuditTime(event.getCreateTime());
            event.setUpdateTime(event.getCreateTime());
            event.setEventStartTime(event.getCreateTime());
            event.setIsWhitelist("0");
            String eventDesc = JsonUtils.getStr(json, LogConstantsX.ALERT_NAME);
            if (StringUtils.isBlank(eventDesc)) {
                eventDesc = JsonUtils.getStr(json, LogConstantsX.ALERT_NAME_BAK);
            }
            if (StringUtils.isBlank(eventDesc)) {
                eventDesc = JsonUtils.getStr(json, LogConstantsX.LOG_ORI_MSG);
            }
            event.setRemarks(eventDesc);
            event.setAttackIp(JsonUtils.getStr(json, "src_ip"));
            event.setAttackUrl(JsonUtils.getStr(json, "dest_ip"));
            event.setQaxtId(flowId);
            TbEvent tmp = tbEventMapper.selectTbEventById(event);
            if (tmp != null) {
                log.error("###数据库已存在：" + JSON.toJSONString(tmp));
            } else {
                if (event.getRegCompany() != null) {
                    event.setRegCompany("");
                }
                tbEventMapper.insertTbEvent(event);
            }

            try {
                //update tb_event set priority = #{sn}, solution = #{snBu}, solutions = #{snArea}
                String priority = DataUtils.getStr(resultMap, "priority");
                double ai = DataUtils.getDouble(priority);
                if (resultMap.size() > 0 && ai > 0) {
                    TbEvent uu = new TbEvent();
                    uu.setQaxtId(event.getQaxtId());
                    uu.setAttach(String.valueOf(DataUtils.getDouble(resultMap, "priority")));
                    uu.setPriority(ai);
                    uu.setSolution(DataUtils.getStr(resultMap, "solution"));
                    uu.setSolutions(DataUtils.getStr(resultMap, "solutions"));
                    tbEventMapper.updateAiData(uu);
                }
                log.info("{},{}-入库AI数据，{}", model.getModel().getModelId(), event.getQaxtId(), priority);
            } catch (Exception e) {
                log.error(e.getMessage(), e);
            }
        } catch (Exception e) {
            log.error(e.getMessage(), e);
        }

        CommonMapper commonMapper = GetSpringBean.getBean(CommonMapper.class);
        if (ModelTypeEnum.GUANLIAN.getValue().equalsIgnoreCase(model.getModel().getModelType())) {
            if (model.getRelationIdList() != null) {
                try {
                    model.getRelationIdList().forEach(v -> {
                        if ("1".equals(v.getType())) {
                            String sql = "update tb_alarm_ori_log set alarm_id = '%s' where id = '%s'";
                            commonMapper.exeSQL(String.format(sql, flowId, v.getId()));
                        } else {
                            String sql = "update tb_alarm_ori_log set alarm_id = '%s' where id = '%s'";
                            commonMapper.exeSQL(String.format(sql, flowId, v.getNewId()));
                        }
                    });
                } catch (Exception e) {
                    log.error(e.getMessage(), e);
                }
            }
        } else {
            try {
                TbOriDangerEventMapper oriDangerEventMapper = GetSpringBean.getBean(TbOriDangerEventMapper.class);
                if (oriDangerEventMapper.getRefLogCount(flowId) < 1) {
                    TbOriDangerEvent oriEvent = oriDangerEventMapper.selectTbOriDangerEventById(model.getOriEventId());
                    if (oriEvent != null) {
                        String oriIds = oriEvent.getEventId();
                        if (!StringUtils.isBlank(oriIds)) {
                            TbOriDangerEvent newEvent = new TbOriDangerEvent();
                            newEvent.setEventId(oriIds);
                            newEvent.setEventName(flowId);
                            newEvent.setDataScope(model.getModel().getDataSourceId());
                            newEvent.setModelId(model.getModel().getModelId());
                            if (StringUtils.isNotBlank(indexName)) {
                                AlarmLogSyncNow.addQueue(model.getModel().getDataSourceId(),indexName, oriIds, flowId, json);
                                String index = indexName.split("-")[0];
                                indexName = index + "-" + DateUtils.getDate1(0);
                                newEvent.setAlertLevel(indexName);
                                oriDangerEventMapper.insertAlarmRefOriLog(newEvent);
                            }
                        }
                    }
                }
            } catch (Exception e) {
                log.error(e.getMessage(), e);
            }
        }

        try {
            if (SyncSecConfig.isEnable("alarm_add_auto_asset")  || "T".equals(SpringbootApplication.OP_CONFIG.getCreateAsset())) {
                AlarmIp alarmIp = new AlarmIp();
                alarmIp.setDestIp(JsonUtils.getStr(json, LogConstantsX.DEST_IP));
                alarmIp.setSrcIp(JsonUtils.getStr(json, LogConstantsX.SRC_IP));
                alarmIp.setModelId(model.getModel().getModelId());
                alarmIp.setAlarmId(flowId);
                alarmIp.setRuleBaseIp(JsonUtils.getStr(json, "dev_ip"));
                alarmIp.setRuleBase(AlarmUtils.getDeviceName(json,model.getModel()));
                AlarmAssetSyncToDb.magicQueue.offer(alarmIp);
            }
        } catch (Exception e) {
            log.error(e.getMessage(),e);
        }

    }

    public void saveSaasFlow(FlowModel flowData, String res, JSONObject sendJson, Map<String, String> resultMap, String indexName, long officeId) {

        try {
            JSONObject jsonObject = JsonUtils.parse(res);
            //{"msg":"SSP2021-1244","code":200}
            log.info(flowData.getModel().getModelId() + String.format("租户=%d线程返回:%s,推送新版STP:%s,AI研判置信度：%s", officeId, res, sendJson.toJSONString(), resultMap.get("priority")));
            if ("200".equals(JsonUtils.getStr(jsonObject, "code"))) {
                String orderId = "";
                if (jsonObject.get("data") instanceof JSONObject) {
                    orderId = JsonUtils.getStr(jsonObject.getJSONObject("data"), "data");
                } else {
                    orderId = JsonUtils.getStr(jsonObject, "data");
                }
                if (StringUtils.isBlank(orderId)) {
                    orderId = JsonUtils.getStr(jsonObject, "msg");
                } else if (orderId.contains("成功")) {
                    orderId = JsonUtils.getStr(jsonObject, "msg");
                }
                // 根据工单号更新tb_event表中的数据
                proc(flowData, flowData.getFJson(), orderId, resultMap, indexName);
            } else {
                //推送失败返回队列
                if (JsonUtils.getStr(jsonObject, "msg").contains("限流中")) {
                    log.info("限流中：" + res);
                    MyTheadUtils.sleep(20);
                } else {
                    log.info("推送失败：{},发送数据：{},原始：{}", res, sendJson.toJSONString(), flowData.getFJson().toJSONString());

                }
            }
        } catch (Exception e) {
            log.error(e.getMessage(), e);
        }

    }

    /*
        {
  {
    "title":"告警标题",
    "vulKeyword":"漏洞关键字",
    "alarmSource":"告警来源名称",
    "alarmSourceLabel":"告警来源名称",
    "level":"告警级别",
    "levelLabel":"告警级别名称",
    "alarmTime": "2022-06-14 17:23:57",
    "detail":"告警详情",
    "remark":"备注",
    "fileJson":"附件",
    "attackIp":"10.200.194.96",
    "victimizedIp":"10.54.48.134",
    "attackResult":"攻击结果",
    "attackResultLabel":"攻击结果名称",
    "attackMeans":"攻击手段",
    "attackMeansLabel":"攻击手段名称",
    "attackCount":15,
    "attList":[
        {"fileName":"附件名称1","url":"附件链接1"},
        {"fileName":"附件名称2","url":"附件链接2"}
    ]
}
    }
         */
    /*
    V2版本告警模型
     */
    public JSONObject transV2(JSONObject json, TbEventModel modelInfoV2) {

        JSONObject ret = new JSONObject();
        ret.put("alarmTime", JsonUtils.getStr(json, LogConstantsX.LOG_START_TIME));
        String countField = "";
        try {
            RedisUtil redisUtil = GetSpringBean.getBean(RedisUtil.class);
            countField = (String) redisUtil.get("发生次数");
        } catch (Exception e) {
            log.error(e.getMessage(), e);
        }
        int attackCount = 0;
        if (StringUtils.isEmpty(countField)) {
            attackCount = JsonUtils.getInt(json, LogConstantsX.LOG_COUNT);
        } else {
            attackCount = JsonUtils.getInt(json, countField);
        }
        if (attackCount < 1) {
            attackCount = 1;
        }
        ret.put("attackCount", attackCount);
        ret.put("title", DataUtils.getShorter(JsonUtils.getStr(json,LogConstantsX.LOG_NAME), 2000));
        ret.put("attackIp", JsonUtils.getStr(json, LogConstantsX.SRC_IP));
        ret.put("victimizedIp", JsonUtils.getStr(json, LogConstantsX.DEST_IP));
        ret.put("levelLabel", modelInfoV2.getEventLevelName());
        ret.put("level", modelInfoV2.getEventLevel());

        String eventDesc = JsonUtils.getStr(json, LogConstantsX.ALERT_NAME);
        if (StringUtils.isBlank(eventDesc)) {
            eventDesc = JsonUtils.getStr(json, LogConstantsX.ALERT_NAME_BAK);
        }
        if (StringUtils.isBlank(eventDesc)) {
            eventDesc = JsonUtils.getStr(json, LogConstantsX.LOG_ORI_MSG);
        }

        ret.put("detail", DataUtils.getShorter(eventDesc, 32767));
        ret.put("vulKeyword", modelInfoV2.getVulKeyword());
        ret.put("attackMeans", modelInfoV2.getAttackTypeName());
        ret.put("attackResultLabel", modelInfoV2.getAttackResultName());
        String product = JsonUtils.getStr(json, LogConstantsX.LOG_PRODUCT);
                //AlarmUtils.getDeviceName(json, modelInfoV2);
        ret.put("rule_base", product);
        ret.put("deviceLabel", product);
        String source = JsonUtils.getStr(json, "source");
        if (DataUtils.toInt(source) < 1) {
            source = "100";
            ret.put("organizationId", source);
            ret.put("source", source);
        }
        return ret;
    }
}
