package com.crc.sync.send;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;
import com.crc.common.constants.LogConstantsX;
import com.crc.common.constants.ModelTypeEnum;
import com.crc.common.utils.DataUtils;
import com.crc.common.utils.IdGen;
import com.crc.common.utils.IpUtils;
import com.crc.common.utils.JsonUtils;
import com.crc.secface.argo.AlarmUtils;
import com.crc.secface.config.GetSpringBean;
import com.crc.secface.config.SyncSecConfig;
import com.crc.secface.entity.*;
import com.crc.secface.mapper.TbEventMapper;
import com.crc.secface.mapper.TbEventModelMapper;
import com.crc.sync.net.NewSegmentLoad;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;

import java.util.List;

/**
 * 高危事件推送Tota
 */
@Slf4j
public class DangerEventToStp extends Thread {

    private final JSONObject job;
    //private String evtId;//事件ID
    DangerEventSendModel eventInfo;
    TbEventModel model;
    JSONObject messageJSON;

    public DangerEventToStp(JSONObject job, DangerEventSendModel eventInfo) {
        this.job = job;
        this.eventInfo = eventInfo;
        this.model = eventInfo.getModel();
    }


    @Override
    public void run() {
        try {
            String srcIp = JsonUtils.getStr(job, LogConstantsX.SRC_IP);
            String destIp = JsonUtils.getStr(job, LogConstantsX.DEST_IP);
            if (NewSegmentLoad.FILTER_SEGMENT_FLAG) {
                boolean flag = false;
                try {
                    List<String> ipList = IpUtils.getIps(srcIp);
                    ipList.addAll(IpUtils.getIps(destIp));
                    for (String ip : ipList) {
                        TbAssetSegement seg = NewSegmentLoad.getIPSegmentByHalf(ip);
                        if (seg != null) {
                            flag = true;
                            break;
                        }
                    }
                } catch (Exception e) {
                    log.error(e.getMessage(),e);
                }
                if (!flag) {
                    log.error("启用了网段识别 IP 过滤机制，非网段数据不入库sync_sec_config/filter_segment_enable，没有 IP 命中网段，不入库");
                    return;
                }
            }


            if ("0.0.0.0".equals(srcIp) && "0.0.0.0".equals(destIp)) {
                log.error("{}非法 IP",model.getModelId());
                return;
            }

            if (ModelTypeEnum.JINGQUE.getValue().equalsIgnoreCase(model.getModelType())) {
                if (!SyncSecConfig.isEnable("send_accurate_alarm_stp")) {
                    log.warn("未启动{}推送STP", ModelTypeEnum.JINGQUE.getDesc());
                    proc(model, job);
                    return;
                }
            } else if (ModelTypeEnum.JUHE.getValue().equalsIgnoreCase(model.getModelType())) {
                if (!SyncSecConfig.isEnable("send_agg_alarm_stp")) {
                    log.warn("未启动{}推送STP", ModelTypeEnum.JUHE.getDesc());
                    proc(model, job);
                    return;
                }
            } else if (ModelTypeEnum.GUANLIAN.getValue().equalsIgnoreCase(model.getModelType())) {
                if (!SyncSecConfig.isEnable("send_rel_alarm")) {
                    log.warn("未启动{}推送STP", ModelTypeEnum.GUANLIAN.getDesc());
                    proc(model, job);
                    return;
                }
            } else {
                log.error("未知告警类型！！{}", model.getModelType());
                return;
            }
            if (isWhiteList(job)) {
                log.info("属于白名单:" + JsonUtils.getStr(job, LogConstantsX.ALERT_NAME));
                return;
            }



            messageJSON = new JSONObject(job);
            sendToStpFlow(job);

        } catch (Exception e) {
            log.error(e.getMessage(), e);
        }
    }

    public void proc(TbEventModel model,JSONObject json) {
        try {
            TbEventMapper tbEventMapper = GetSpringBean.getBean(TbEventMapper.class);
            //事件基本信息
            TbEvent event = new TbEvent();
            String operator = "admin";
            event.setId(IdGen.uuid());
            event.setStatus("研判");
            event.setCreateBy(operator);
            event.setDelFlag(0);
            if (model != null) {
                event.setAttackResult(model.getAttackResult());
                event.setBusModel(model.getModelId());
                event.setEventName(JsonUtils.getStr(json,LogConstantsX.LOG_NAME));
                event.setAttackType(model.getAttackTypeName());
                event.setEventLevel(model.getEventLevelName());
                String product = AlarmUtils.getDeviceName(json, model);
                event.setEventSource(product);
            }
            event.setStatus("待处置");
            //event.setEventNo(event.getId());
            event.setCreateTime(JsonUtils.getDate(json, "event_time"));
            event.setAttackCount(JsonUtils.getLong(json, LogConstantsX.LOG_COUNT, 1));
            event.setCommitTime(event.getCreateTime());
            event.setAlarmTime(JsonUtils.getDate(json, LogConstantsX.LOG_START_TIME));
            event.setAuditTime(event.getCreateTime());
            event.setUpdateTime(event.getCreateTime());
            event.setEventStartTime(event.getCreateTime());
            event.setIsWhitelist("0");
//            event.setRemarks(JsonUtils.getStr(json, "event_description"));
            String eventDesc = JsonUtils.getStr(json, LogConstantsX.ALERT_NAME);
            if (StringUtils.isBlank(eventDesc)) {
                eventDesc = JsonUtils.getStr(json, LogConstantsX.ALERT_NAME_BAK);
            }
            if (StringUtils.isBlank(eventDesc)) {
                eventDesc = JsonUtils.getStr(json, LogConstantsX.LOG_ORI_MSG);
            }
            event.setRemarks(eventDesc);
            event.setAttackIp(JsonUtils.getStr(json, "src_ip"));
            event.setAttackUrl(JsonUtils.getStr(json, "dest_ip"));
            event.setQaxtId(event.getId());
            TbAssetSegement ipBean = null;
            List<String> srcList = IpUtils.getIps(event.getAttackIp());
            if (srcList.size() > 0) {
                for (String ip : srcList) {
                    ipBean = NewSegmentLoad.getIPSegmentByHalf(ip);
                    if (ipBean != null) {
                        if (StringUtils.isBlank(event.getRiskIp())) {
                            event.setRiskIp(ip);
                        }
                        break;
                    }
                }
            }
            if (ipBean == null) {
                List<String> destList = IpUtils.getIps(event.getAttackUrl());
                for (String ip : destList) {
                    ipBean = NewSegmentLoad.getIPSegmentByHalf(ip);
                    if (ipBean != null) {
                        if (StringUtils.isBlank(event.getRiskIp())) {
                            event.setRiskIp(event.getAttackUrl());
                        }
                        break;
                    }
                }
            }
            //snData 4 swData 3 shData 3 ddData lrData bgwData
            event.setSn("0");
            if (ipBean != null) {
                String bu = DataUtils.getDeptTree(ipBean.getAffiliationDeptName(),1);
                String compay = DataUtils.getDeptTree(ipBean.getAffiliationDeptName(),2);
                if (StringUtils.isBlank(compay)) {
                    compay = bu;
                }
                event.setRegArea(DataUtils.getDeptTree(ipBean.getAreaName(),1));
                event.setRegSubArea(DataUtils.getDeptTree(ipBean.getAreaName(),2));
                event.setRegBu(bu);
                event.setRegCompany(compay);
            }
            TbEvent tmp = tbEventMapper.selectTbEventById(event);
            if (tmp != null) {
                log.error("###数据库已存在：" + JSON.toJSONString(tmp));
            } else {
                if (event.getRegCompany() != null) {
                    event.setRegCompany("");
                }
                tbEventMapper.insertTbEvent(event);
            }
        } catch (Exception e) {
            log.error(e.getMessage(), e);
        }
    }


    public boolean isWhiteList(JSONObject json) {
        return json.get(LogConstantsX.IS_WHITELIST) != null && json.getString(LogConstantsX.IS_WHITELIST).equals("1");
    }


    public void sendToStpFlow(JSONObject tota) {
        tota.put(LogConstantsX.LOG_COUNT, JsonUtils.getLong(tota,"times"));
        tota.put("attack_result_id", model.getAttackResult());
        //String baseUrl = "https://tota.crc.com.cn/new";
        //String url = baseUrl + "/openApi/event_ins/save";
        String srcIp = JsonUtils.getStr(tota, LogConstantsX.SRC_IP);
        String destIp = JsonUtils.getStr(tota, LogConstantsX.DEST_IP);
        List<String> srcList = IpUtils.getIps(srcIp);
        TbAssetSegement ipBean = null;
        if (srcList.size() > 0) {
            for (String ip : srcList) {
                ipBean = NewSegmentLoad.getIPSegmentByHalf(ip);
                if (ipBean != null) {
                    break;
                }
            }
        }
        if (ipBean != null) {
            List<String> destList = IpUtils.getIps(destIp);
            for (String ip : destList) {
                ipBean = NewSegmentLoad.getIPSegmentByHalf(ip);
                if (ipBean != null) {
                    break;
                }
            }
        }


        TbEventModelMapper modelMapper = GetSpringBean.getBean(TbEventModelMapper.class);
        int count = modelMapper.selectModelCount(model.getModelId());
        if (count < 1) {
            log.warn("{}已关闭，告警丢弃！",model.getModelId());
            return;
        }


        FlowModel fm = new FlowModel();
        fm.setFJson(tota);
        fm.setRJson(messageJSON);
        fm.setModel(model);
        fm.setRelationIdList(eventInfo.getIdList());
        fm.setOriEventId(eventInfo.getEventId());
        SendToFlowV2.magicQueue.offer(fm);
    }

    public String getStr(JSONObject json, String filter) {
        return JsonUtils.getStr(json, filter);
    }
}
