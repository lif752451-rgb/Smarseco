package com.crc.sync.send;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;
import com.crc.SpringbootApplication;
import com.crc.common.constants.LogConstants;
import com.crc.common.constants.LogConstantsX;
import com.crc.common.constants.ModelTypeEnum;
import com.crc.common.utils.*;
import com.crc.secface.argo.AlarmUtils;
import com.crc.secface.argo.CombatUtils;
import com.crc.secface.config.GetSpringBean;
import com.crc.secface.config.SyncSecConfig;
import com.crc.secface.entity.*;
import com.crc.secface.es.ConfBuzziMySql;
import com.crc.secface.mapper.CommonMapper;
import com.crc.secface.mapper.TbEventMapper;
import com.crc.secface.mapper.TbEventModelMapper;
import com.crc.secface.mapper.TbOriDangerEventMapper;
import com.crc.secface.redis.RedisUtil;
import com.crc.sync.ai.AiCheckSync;
import com.crc.sync.data.AlarmAssetSyncToDb;
import com.crc.sync.data.AlarmLogSyncNow;
import com.crc.sync.net.DataCenterLoad;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;

import java.util.Date;
import java.util.HashMap;
import java.util.Map;
import java.util.concurrent.ArrayBlockingQueue;


@Slf4j
public class SendToFlowV2 extends Thread {
    public static ArrayBlockingQueue<FlowModel> magicQueue = new ArrayBlockingQueue<>(50000);

    public void run() {
        log.info("新版本安全告警推送。。。。");
        while (true) {
            if (magicQueue.isEmpty()) {
                MyTheadUtils.sleep(20);
            } else {
                while (!magicQueue.isEmpty()) {
                    MyTheadUtils.sleep(20);
                    try {
                        log.info("SendToFlowV2队列数量：{}", magicQueue.size());
                        FlowModel flowData = magicQueue.poll();
                        try {
                            TbEventModelMapper modelMapper = GetSpringBean.getBean(TbEventModelMapper.class);
                            int count = modelMapper.selectModelCount(flowData.getModel().getModelId());
                            if (count < 1) {
                                log.warn("{}已关闭，告警丢弃！", flowData.getModel().getModelId());
                                continue;
                            }
                        } catch (Exception e) {
                            log.error(e.getMessage(), e);
                        }
                        String indexName = JsonUtils.getStr(flowData.getFJson(), LogConstants.ES_LOG_INDEX);
                        CombatVo vo = CombatUtils.getCombatTime();
                        try {
                            if (vo.isCombat()) {
                                FlowModel data = new FlowModel();
                                data.setFJson(flowData.getFJson());
                                data.setRJson(flowData.getRJson());
                                data.setModel(flowData.getModel());
                                data.setOriEventId(flowData.getOriEventId());
                                data.setRelationIdList(flowData.getRelationIdList());
                                data.setFightTab(vo.getType());
                                SendToFightFlow.magicQueue.put(data);
                                continue;
                            }
                        } catch (Exception e) {
                            log.error(e.getMessage(), e);
                        }

                        JSONObject toSendJson = null;
                        String modelId = "";
                        if (flowData.getModel() != null) {
                            toSendJson = transV2(flowData.getFJson(), flowData.getModel());
                            modelId = flowData.getModel().getModelId();
                        }
                        if (toSendJson == null) {
                            log.error("{}转换工单推送结构失败！{}", modelId, flowData.getFJson().toJSONString());
                            continue;
                        }


                        // V2 版本，姬向奇2021年12月28日修改
                        Map<String, String> resultMap = new HashMap<>();
                        if ("T".equalsIgnoreCase(SpringbootApplication.OP_CONFIG.getAiCheck())) {
                            if (flowData.getModel() != null) {
                                resultMap = AiCheckSync.getAiCheckV3(flowData.getFJson(), flowData.getModel());
                                toSendJson.put("solutions", resultMap.get("solutions"));
                                toSendJson.put("aiCheck", resultMap.get("priority"));
                            }
                        }
                        toSendJson.put("eventModelId", flowData.getModel().getId());
                        String stpApi = SyncSecConfig.getRemarkValue(SyncSecConfig.STP_API_URL);
                        if (StringUtils.isBlank(stpApi)) {
                            stpApi = SpringbootApplication.OP_CONFIG.getStpUrl();
                        }
                        stpApi = stpApi + "/alarm/report/reportAlarmAuto";
                        toSendJson.put("source", 100);
                        toSendJson.put("organizationId", 100);
                        String res = HttpUtils.sendPost(stpApi, toSendJson.toJSONString());


                        JSONObject jsonObject = JsonUtils.parse(res);
                        //{"msg":"SSP2021-1244","code":200}
                        log.info(modelId + String.format("线程返回:%s,推送新版STP:%s,AI研判置信度：%s", res, toSendJson.toJSONString(), resultMap.get("priority")));
                        if ("200".equals(JsonUtils.getStr(jsonObject, "code"))) {
                            String orderId = "";
                            if (jsonObject.get("data") instanceof JSONObject) {
                                orderId = JsonUtils.getStr(jsonObject.getJSONObject("data"), "data");
                            } else {
                                orderId = JsonUtils.getStr(jsonObject, "data");
                            }
                            if (StringUtils.isBlank(orderId)) {
                                orderId = JsonUtils.getStr(jsonObject, "msg");
                            } else if (orderId.contains("成功")) {
                                orderId = JsonUtils.getStr(jsonObject, "msg");
                            }
                            // 根据工单号更新tb_event表中的数据
                            proc(flowData, flowData.getFJson(), orderId, resultMap, indexName);
                            AlarmIp alarmIp = new AlarmIp();
                            alarmIp.setAlarmId(orderId);
                            alarmIp.setSrcIp(JsonUtils.getStr(flowData.getFJson(), LogConstantsX.SRC_IP));
                            alarmIp.setDestIp(JsonUtils.getStr(flowData.getFJson(), LogConstantsX.DEST_IP));
                            SendToScpInternetPublishApp.magicQueue.offer(alarmIp);

                            try {
                                RworkModel rm = new RworkModel();
                                flowData.getFJson().put("ai_check", resultMap.get("priority"));
                                flowData.getFJson().put("solution", resultMap.get("solution"));
                                rm.setOrderId(orderId);
                                rm.setJson(flowData.getFJson());
                                rm.setModel(flowData.getModel());
                                SendToRwork.magicQueue.offer(rm);
                            } catch (Exception e) {
                                log.error(modelId + ",根据工单号更新tb_event表中的数据失败，原因为" + e.getMessage(), e);
                            }
                            //web后门、勒索病毒、RDP暴力破解
                            flowData.setAlarmId(orderId);
                            String logName = JsonUtils.getStr(flowData.getFJson(), LogConstantsX.LOG_NAME);
                            if (DataCenterLoad.isNeedToSendDataCenter(logName)) {
                                DangerEventToAlarmCenter.magicQueue.offer(flowData);
                            } else {
                                log.info("{}不符合要求(后门/勒索/暴力破解)，不推送告警中心", logName);
                            }
                        } else {
                            //推送失败返回队列
                            if (JsonUtils.getStr(jsonObject, "msg").contains("限流中")) {
                                log.info("限流中：" + res);
                                MyTheadUtils.sleep(20);
                                magicQueue.put(flowData);
                            } else {
                                log.info("推送失败：{},发送数据：{},原始：{}", res, toSendJson.toJSONString(), flowData.getFJson().toJSONString());
                            }
                        }
                        MyTheadUtils.sleep(10);
                    } catch (Exception e) {
                        log.error(e.getMessage(), e);
                    }
                }
            }
        }

    }

    public void proc(FlowModel model, JSONObject json, String flowId, Map<String, String> resultMap, String indexName) {
        try {
            TbEventMapper tbEventMapper = GetSpringBean.getBean(TbEventMapper.class);
            //事件基本信息
            TbEvent event = new TbEvent();
            String operator = "admin";
            TbEvent tx = tbEventMapper.getAlarmId(flowId);
            if (tx == null || StringUtils.isBlank(tx.getId()))
                event.setId(IdGen.uuid());
            else {
                event.setId(tx.getId());
            }
            event.setStatus("研判");
            event.setCreateBy(operator);
            event.setDelFlag(0);
            if (model.getModel() != null) {
                event.setAttackResult(model.getModel().getAttackResult());
                event.setBusModel(model.getModel().getModelId());
                event.setEventName(JsonUtils.getStr(json, LogConstantsX.LOG_NAME));
                event.setAttackType(model.getModel().getAttackTypeName());
                event.setEventLevel(model.getModel().getEventLevelName());
                String product = AlarmUtils.getDeviceName(json, model.getModel());
                event.setEventSource(product);
            }
            event.setStatus("待处置");
            //event.setEventNo(event.getId());
            event.setCreateTime(new Date());
            event.setAttackCount(JsonUtils.getLong(json, LogConstantsX.LOG_COUNT, 1));
            event.setCommitTime(new Date());
            event.setAlarmTime(JsonUtils.getDate(json, LogConstantsX.LOG_START_TIME));
            event.setAuditTime(new Date());
            event.setUpdateTime(new Date());
            event.setEventStartTime(new Date());
            event.setIsWhitelist("0");
            String eventDesc = JsonUtils.getStr(json, LogConstantsX.ALERT_NAME);
            if (StringUtils.isBlank(eventDesc)) {
                eventDesc = JsonUtils.getStr(json, LogConstantsX.ALERT_NAME_BAK);
            }
            if (StringUtils.isBlank(eventDesc)) {
                eventDesc = JsonUtils.getStr(json, LogConstantsX.LOG_ORI_MSG);
            }
            event.setRemarks(eventDesc);
            event.setAttackIp(JsonUtils.getStr(json, "src_ip"));
            event.setAttackUrl(JsonUtils.getStr(json, "dest_ip"));
            event.setQaxtId(flowId);
            TbEvent tmp = tbEventMapper.selectTbEventById(event);
            if (tmp != null) {
                log.error("###数据库已存在：" + JSON.toJSONString(tmp));
            } else {
                if (event.getRegCompany() != null) {
                    event.setRegCompany("");
                }
                tbEventMapper.insertTbEvent(event);
            }

            try {
                //update tb_event set priority = #{sn}, solution = #{snBu}, solutions = #{snArea}
                String priority = DataUtils.getStr(resultMap, "priority");
                double ai = DataUtils.getDouble(priority);
                if (resultMap.size() > 0 && ai > 0) {
                    TbEvent uu = new TbEvent();
                    uu.setQaxtId(event.getQaxtId());
                    uu.setAttach(String.valueOf(DataUtils.getDouble(resultMap, "priority")));
                    uu.setPriority(ai);
                    uu.setSolution(DataUtils.getStr(resultMap, "solution"));
                    uu.setSolutions(DataUtils.getStr(resultMap, "solutions"));
                    tbEventMapper.updateAiData(uu);
                }
                log.info("{},{}-入库AI数据，{}", model.getModel().getModelId(), event.getQaxtId(), priority);
            } catch (Exception e) {
                log.error(e.getMessage(), e);
            }
        } catch (Exception e) {
            log.error(e.getMessage(), e);
        }
        CommonMapper commonMapper = GetSpringBean.getBean(CommonMapper.class);
        if (ModelTypeEnum.GUANLIAN.getValue().equalsIgnoreCase(model.getModel().getModelType())) {
            if (model.getRelationIdList() != null) {
                try {
                    model.getRelationIdList().forEach(v->{
                        if ("1".equals(v.getType())) {
                            String sql = "update tb_alarm_ori_log set alarm_id = '%s' where id = '%s'";
                            commonMapper.exeSQL(String.format(sql,flowId,v.getId()));
                        }else {
                            String sql = "update tb_alarm_ori_log set alarm_id = '%s' where id = '%s'";
                            commonMapper.exeSQL(String.format(sql,flowId,v.getNewId()));
                        }
                    });
                } catch (Exception e) {
                    log.error(e.getMessage(),e);
                }
            }
        } else {
            try {
                TbOriDangerEventMapper oriDangerEventMapper = GetSpringBean.getBean(TbOriDangerEventMapper.class);
                if (oriDangerEventMapper.getRefLogCount(flowId) < 1) {
                    TbOriDangerEvent oriEvent = oriDangerEventMapper.selectTbOriDangerEventById(model.getOriEventId());
                    if (oriEvent != null) {
                        String oriIds = oriEvent.getEventId();
                        if (!StringUtils.isBlank(oriIds)) {
                            TbOriDangerEvent newEvent = new TbOriDangerEvent();
                            newEvent.setEventId(oriIds);
                            newEvent.setEventName(flowId);
                            newEvent.setDataScope(model.getModel().getDataSourceId());
                            newEvent.setModelId(model.getModel().getModelId());
                            if (StringUtils.isNotBlank(indexName)) {
                                AlarmLogSyncNow.addQueue(model.getModel().getDataSourceId(),indexName, oriIds, flowId,json);
                                String index = indexName.split("-")[0];
                                indexName = index + "-" + DateUtils.getDate1(0);
                                newEvent.setAlertLevel(indexName);
                                oriDangerEventMapper.insertAlarmRefOriLog(newEvent);
                            }
                        }
                    }
                }
            } catch (Exception e) {
                log.error(e.getMessage(), e);
            }
        }

        try {
            if (SyncSecConfig.isEnable("alarm_add_auto_asset") || "T".equals(SpringbootApplication.OP_CONFIG.getCreateAsset())) {
                AlarmIp alarmIp = new AlarmIp();
                alarmIp.setDestIp(JsonUtils.getStr(json, LogConstantsX.DEST_IP));
                alarmIp.setSrcIp(JsonUtils.getStr(json, LogConstantsX.SRC_IP));
                alarmIp.setModelId(model.getModel().getModelId());
                alarmIp.setAlarmId(flowId);
                alarmIp.setRuleBaseIp(JsonUtils.getStr(json, "dev_ip"));
                alarmIp.setRuleBase(AlarmUtils.getDeviceName(json,model.getModel()));
                AlarmAssetSyncToDb.magicQueue.offer(alarmIp);
            }
        } catch (Exception e) {
            log.error(e.getMessage(),e);
        }
    }

    /*
        {
    alarmTime   告警时间  String YYYY-MM-dd HH:mm:ss
    attackCount	攻击次数 Integer
    attackIp	攻击IP String
    attackMeans	攻击手段 String
    attackMeansLabel	攻击手段名称  String
    attackResult	攻击结果  String
    attackResultLabel	攻击结果名称  String
    behaviorNature   行为性质(0 正常, 1异常) Integer
    dept	 告警单位 String
    deptLabel 告警单位名称 String
    detail 告警详情 String
    device 告警设备 String
    deviceLabel 告警设备名称 String
    level 告警级别 String  告警级别 1：一级 2：二级 3：三级 4：四级
    levelLabel 告警级别名称 String
    remark 备注 String
    title 标题 String
    victimizedIp 受害IP/URL String
    fileJson 附件 String
    }
         */
    /*
    V2版本告警模型
     */
    public JSONObject transV2(JSONObject json, TbEventModel modelInfoV2) {

        JSONObject ret = new JSONObject();
        ret.put("alarmTime", JsonUtils.getStr(json, LogConstantsX.LOG_START_TIME));
        String countField = "";
        try {
            RedisUtil redisUtil = GetSpringBean.getBean(RedisUtil.class);
            countField = (String) redisUtil.get("发生次数");
        } catch (Exception e) {
            log.error(e.getMessage(), e);
        }
        int attackCount = 0;
        if (StringUtils.isEmpty(countField)) {
            attackCount = JsonUtils.getInt(json, LogConstantsX.LOG_COUNT);
        } else {
            attackCount = JsonUtils.getInt(json, countField);
        }
        if (attackCount < 1) {
            attackCount = 1;
        }
        ret.put("attackCount", attackCount);
        ret.put("title", DataUtils.getShorter(JsonUtils.getStr(json,LogConstantsX.LOG_NAME), 2000));
        ret.put("attackIp", JsonUtils.getStr(json, LogConstantsX.SRC_IP));
        ret.put("victimizedIp", JsonUtils.getStr(json, LogConstantsX.DEST_IP));
        ret.put("levelLabel", modelInfoV2.getEventLevelName());
        ret.put("level", modelInfoV2.getEventLevel());

        //已经在DangerEventToStp类的resetTotaJSON方法里面处理了，直接获取即可
        String eventDesc = JsonUtils.getStr(json, LogConstantsX.ALERT_NAME);
        if (StringUtils.isBlank(eventDesc)) {
            eventDesc = JsonUtils.getStr(json, LogConstantsX.ALERT_NAME_BAK);
        }
        if (StringUtils.isBlank(eventDesc)) {
            eventDesc = JsonUtils.getStr(json, LogConstantsX.LOG_ORI_MSG);
        }
        ret.put("detail", DataUtils.getShorter(eventDesc, 32767));
        ret.put("attackMeans", modelInfoV2.getAttackTypeName());
        ret.put("attackResultLabel", modelInfoV2.getAttackResultName());
        ret.put("vulKeyword", modelInfoV2.getVulKeyword());
        String product = JsonUtils.getStr(json, LogConstantsX.LOG_PRODUCT);
                //AlarmUtils.getDeviceName(json, modelInfoV2);
        ret.put("rule_base", product);
        ret.put("deviceLabel", product);
        String source = JsonUtils.getStr(json, "source");
        if (DataUtils.toInt(source) < 1) {
            source = "100";
            ret.put("organizationId", source);
            ret.put("source", source);
        }
        return ret;
    }
}
