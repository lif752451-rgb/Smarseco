package com.crc.sync.send;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;
import com.crc.common.constants.LogConstantsX;
import com.crc.common.constants.ModelTypeEnum;
import com.crc.common.utils.*;
import com.crc.msg.rwork.RworkSend;
import com.crc.msg.wx.QyweixinSend;
import com.crc.secface.argo.AssetUtils;
import com.crc.secface.config.GetSpringBean;
import com.crc.secface.config.SyncSecConfig;
import com.crc.secface.entity.*;
import com.crc.secface.mapper.SendMessageMapper;
import com.crc.secface.mapper.SendPolicyMapper;
import com.crc.secface.service.MailService;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.List;
import java.util.concurrent.ArrayBlockingQueue;

@Slf4j
public class SendToRwork extends Thread {
    public static ArrayBlockingQueue<RworkModel> magicQueue = new ArrayBlockingQueue(50000);

    @Override
    public void run() {
        log.info("飞书推送。。。。");
        while (true) {
            if (magicQueue.isEmpty()) {
                MyTheadUtils.sleepBySec(1);
            } else {
                while (!magicQueue.isEmpty()) {
                    try {
                        RworkModel data = magicQueue.poll();
                        proc(data);
                        MyTheadUtils.sleep(10);
                    } catch (Exception e) {
                        log.error(e.getMessage(), e);
                    }
                }
            }
        }
    }

    public String pushRwork(JSONObject json, String orderId, TbEventModel model, List<String> userList) {
        String result = "飞书推送成功";
        try {
            String msg = toMsg(json, orderId, model, "\n");
            if (StringUtils.isBlank(msg)) {
                return "推送内容为空，不推送飞书";
            }
            if (ModelTypeEnum.JINGQUE.getValue().equalsIgnoreCase(model.getModelType())) {
                if (!SyncSecConfig.isEnable("send_accurate_alarm_rwork")) {
                    log.warn("未启动{}推送润工作", ModelTypeEnum.JINGQUE.getDesc());
                    return "未启动" + ModelTypeEnum.JINGQUE.getDesc() + "推送润工作";
                }
            } else if (ModelTypeEnum.JUHE.getValue().equalsIgnoreCase(model.getModelType())) {
                if (!SyncSecConfig.isEnable("send_agg_alarm_rwork")) {
                    log.warn("未启动{}推送润工作", ModelTypeEnum.JUHE.getDesc());
                    return "未启动" + ModelTypeEnum.JUHE.getDesc() + "推送润工作";
                }
            } else if (ModelTypeEnum.GUANLIAN.getValue().equalsIgnoreCase(model.getModelType())) {
                if (!SyncSecConfig.isEnable("send_rel_alarm")) {
                    log.warn("未启动{}推送润工作", ModelTypeEnum.GUANLIAN.getDesc());
                    return "未启动" + ModelTypeEnum.GUANLIAN.getDesc() + "推送润工作";
                }
            } else {
                log.error("未知告警类型！！{}", model.getModelType());
                return "未知告警类型";
            }
            log.info("推送飞书：" + msg);
            //send(userList, msg); tota api 调用tota的飞书推送
            RworkSend.batchSend(userList, msg);
        } catch (Exception e) {
            log.error(e.getMessage(), e);
            result = "飞书推送失败";
        }
        return result;
    }

    public String pushQyWx(JSONObject jsonx, String orderId, TbEventModel modelInfo, List<String> userIdList) {
        try {
            List<String> userIds = new ArrayList<>();
            for (String userId : userIdList) {
                if (userId.contains("@")) {
                    userId = userId.split("@")[0];
                }
                userIds.add(userId);
            }
            JSONObject json = jsonx.clone();
            String msg = toMsg(json, orderId, modelInfo, "\n");
            if (StringUtils.isBlank(msg)) {
                log.error("推送内容为空，不推送飞书");
            }

            if (userIds.size() > 0) {
                QyweixinSend.batchSend(userIds, msg);
            }
            log.info("推送企业微信：" + msg + ",to user:{}", JSON.toJSONString(userIds));
            return "推送成功";
        } catch (Exception e) {
            log.error(e.getMessage(), e);
            log.error("企业微信推送失败");
            return "推送失败";
        }
    }

    public void proc(RworkModel data) {
        //阻塞等待获取事件ID,再发送
        log.info("开始推送告警邮件/飞书" + data.getOrderId());
        SendPolicyQuery sendPolicyQuery = new SendPolicyQuery();
        SendPolicyMapper sendPolicyMapper = GetSpringBean.getBean(SendPolicyMapper.class);
        List<SendPolicy> newPolicyList = sendPolicyMapper.selectByQuery(sendPolicyQuery);
        for (SendPolicy sendPolicy : newPolicyList) {
            PolicyConfig policyConfig = sendPolicy.getPolicyConfig();
            boolean needSend = false;
            if (StringUtils.isNotBlank(sendPolicy.getRuleIds())) {
                //告警推送策略关联告警规则
                for (String ruleId : sendPolicy.getRuleIds().split(",")) {
                    if (StringUtils.isNotBlank(ruleId)) {
                        if (data.getModel() != null && ruleId.equals(data.getModel().getId())) {
                            needSend = true;
                        }
                    }
                }
            }
            if (!needSend) {
                log.info("告警推送策略没有命中，不需要执行推送@### policyId=" + sendPolicy.getId().toString() + " policeName=" + sendPolicy.getPolicyName());
                continue;
            }

            List<String> userIdList = new ArrayList<>();

            if (policyConfig.getEmailStatus() != null && policyConfig.getEmailStatus() == 1 && StringUtils.isNotBlank(policyConfig.getEmailReceiver())) {
                String[] userIdListx = policyConfig.getEmailReceiver().split(",");
                for (String mail : userIdListx) {
                    if (DataUtils.checkEmail(mail)) {
                        userIdList.add(mail);
                    }
                }
                if (userIdList.size() > 0) {
                    String result = pushEmail(data.getJson(), data.getOrderId(), data.getModel(), userIdList);
                    saveMessage(data.getOrderId(), data.getModel().getId(), policyConfig, sendPolicy, 0, result);
                } else {
                    log.info("未找到需要推送的邮箱:{}", policyConfig.getEmailReceiver());
                }

                /**
                 * 是否推送企业微信
                 */
                if(SyncSecConfig.isEnable("send_accurate_alarm_qywx")) {
                    pushQyWx(data.getJson(), data.getOrderId(), data.getModel(), userIdList);
                }
            }
        }
        log.info("结束推送告警邮件/飞书");
    }

    public String pushEmail(JSONObject json, String orderId, TbEventModel model, List<String> userList) {
        String result = "邮件推送成功";
        try {
            String msg = toMsg2(json, orderId, model, "\n <br>");
            if (StringUtils.isBlank(msg)) {
                return "推送内容为空，不推送邮件";
            }
            if (ModelTypeEnum.JINGQUE.getValue().equalsIgnoreCase(model.getModelType())) {
                if (!SyncSecConfig.isEnable("send_accurate_alarm_mail")) {
                    log.warn("未启动{}推送邮件", ModelTypeEnum.JINGQUE.getDesc());
                    return "未启动" + ModelTypeEnum.JINGQUE.getDesc() + "推送邮件";
                }
            } else if (ModelTypeEnum.JUHE.getValue().equalsIgnoreCase(model.getModelType())) {
                if (!SyncSecConfig.isEnable("send_agg_alarm_mail")) {
                    log.warn("未启动{}推送邮件", ModelTypeEnum.JUHE.getDesc());
                    return "未启动" + ModelTypeEnum.JUHE.getDesc() + "推送邮件";
                }
            } else if (ModelTypeEnum.GUANLIAN.getValue().equalsIgnoreCase(model.getModelType())) {
                if (!SyncSecConfig.isEnable("send_rel_alarm")) {
                    log.warn("未启动{}推送邮件", ModelTypeEnum.GUANLIAN.getDesc());
                    return "未启动" + ModelTypeEnum.GUANLIAN.getDesc() + "推送邮件";
                }
            } else {
                log.error("未知告警类型！！{}", model.getModelType());
                return "未知告警类型";
            }
            log.info("推送邮件：" + msg);
            //send(userList, msg); tota api 调用tota的飞书推送
            MailService mailService = GetSpringBean.getBean(MailService.class);
            String sb = "【安全告警消息】告警ID：" + orderId + "，请关注！";
            MailDTO mailDTO = MailDTO.builder()
                    .to(String.join(",",userList))
                    .text(msg)
                    .subject(sb)
                    .build();
            mailService.sendHtmlMail(mailDTO);
        } catch (Exception e) {
            log.error(e.getMessage(), e);
            result = "邮件推送失败";
        }
        return result;
    }

    /*
     * 转换飞书消息
     *
     * @param json
     * @return
     */
    public String toMsg(JSONObject json, String orderId, TbEventModel modelInfo, String type) {

        try {
            String attckType = modelInfo.getAttackTypeName();
            StringBuffer sb = new StringBuffer();
            if (StringUtils.isNotBlank(orderId)) {
                getStr(sb, "\uD83C\uDD94告警ID", orderId, type);
            } else {
                getStr(sb, "\uD83C\uDD94告警ID", "测试！请忽略！", type);
            }
            sb.append("\uD83D\uDCBB告警名称").append(": ").append(JsonUtils.getStr(json,LogConstantsX.LOG_NAME)).append(type);
            getStr(sb, "\uD83D\uDCBB告警设备", json, LogConstantsX.LOG_PRODUCT, "PROD", type);

            getStr(sb, "⚠️攻击手段", attckType, type);
            String logLevel = json.getString(LogConstantsX.LOG_LEVEL);
            if (StringUtils.isEmpty(logLevel)) {
                logLevel = "❗";
            } else {
                logLevel = logLevel.equalsIgnoreCase("高风险") ? "❗❗❗❗❗" : (
                        logLevel.equalsIgnoreCase("中风险") ? "❗❗❗" : "❗");
            }
            getStr(sb, "⚠️告警级别", logLevel, type);
            getStr(sb, "⚠️攻击状态", modelInfo.getAttackStatus(), type);
            getStr(sb, "\uD83D\uDCCC源IP", json, LogConstantsX.SRC_IP, "SRC", type);
            getStr(sb, "\uD83D\uDCCC源端口", json, LogConstantsX.SRC_PORT, type);
            getStr(sb, "\uD83D\uDCCC目标IP", json, LogConstantsX.DEST_IP, "DEST", type);
            getStr(sb, "\uD83D\uDCCC目标端口", json, LogConstantsX.DEST_PORT, type);
            getStr(sb, "⏰告警时间", json, LogConstantsX.LOG_START_TIME, type);
            getStr(sb, "\uD83D\uDCF0告警描述", json, LogConstantsX.ALERT_NAME, type);
            //getStr(sb, "解决方案", json, LogConstantsX.LOG_SOLUTION);
            getStr(sb, "\uD83D\uDCC8发生次数", json, "times", type);
            //⚛
            String aiValue = JsonUtils.getStr(json, "ai_check");
            if (StringUtils.isNotBlank(aiValue) && !"N/A".equalsIgnoreCase(aiValue))
                getStr(sb, "⚛AI研判", aiValue, type);
            String solution = JsonUtils.getStr(json, "solution");
            if (StringUtils.isNotBlank(solution) && !"N/A".equalsIgnoreCase(solution))
                getStr(sb, "⚛AI研判意见", solution, type);
            //历史命令
            return sb.toString();
        } catch (Exception e) {
            log.error(e.getMessage(), e);
        }
        return "";
    }

    /*
     * 转换飞书消息
     *
     * @param json
     * @return
     */
    public String toMsg2(JSONObject json, String orderId, TbEventModel modelInfo, String type) {

        try {
            String attckType = modelInfo.getAttackTypeName();
            StringBuffer sb = new StringBuffer();
            if (StringUtils.isNotBlank(orderId)) {
                getStr(sb, "\uD83C\uDD94告警ID", orderId, type);
            } else {
                getStr(sb, "\uD83C\uDD94告警ID", "测试！请忽略！", type);
            }
            //sb.append(title).append(": ").append(desc).append(type);
            sb.append("\uD83D\uDCBB告警名称").append(": ").append(JsonUtils.getStr(json,LogConstantsX.LOG_NAME)).append(type);
            getStr(sb, "\uD83D\uDCBB告警设备", json, LogConstantsX.LOG_PRODUCT, "PROD", type);

            getStr(sb, "⚠️攻击手段", attckType, type);
            String logLevel = json.getString(LogConstantsX.LOG_LEVEL);
            if (StringUtils.isEmpty(logLevel)) {
                logLevel = "❗";
            } else {
                logLevel = logLevel.equalsIgnoreCase("高风险") ? "❗❗❗❗❗" : (
                        logLevel.equalsIgnoreCase("中风险") ? "❗❗❗" : "❗");
            }
            getStr(sb, "⚠️告警级别", logLevel, type);
            getStr(sb, "⚠️攻击状态", modelInfo.getAttackResultName(), type);
            getStr(sb, "\uD83D\uDCCC源IP", json, LogConstantsX.SRC_IP, "SRC", type);
            getStr(sb, "\uD83D\uDCCC源端口", json, LogConstantsX.SRC_PORT, type);
            getStr(sb, "\uD83D\uDCCC目标IP", json, LogConstantsX.DEST_IP, "DEST", type);
            getStr(sb, "\uD83D\uDCCC目标端口", json, LogConstantsX.DEST_PORT, type);
            getStr(sb, "⏰告警时间", json, LogConstantsX.LOG_START_TIME, type);
            getStr(sb, "\uD83D\uDCF0告警描述", JsonUtils.getStr(json, LogConstantsX.ALERT_NAME), type);
            //getStr(sb, "解决方案", json, LogConstantsX.LOG_SOLUTION);
            getStr(sb, "\uD83D\uDCC8发生次数", json, "times", type);
            //⚛
            String aiValue = JsonUtils.getStr(json, "ai_check");
            if (StringUtils.isNotBlank(aiValue) && !"N/A".equalsIgnoreCase(aiValue))
                getStr(sb, "⚛AI研判", aiValue, type);
            String solution = JsonUtils.getStr(json, "solution");
            if (StringUtils.isNotBlank(solution) && !"N/A".equalsIgnoreCase(solution))
                getStr(sb, "⚛AI研判意见", solution, type);
            //历史命令
            return sb.toString();
        } catch (Exception e) {
            log.error(e.getMessage(), e);
        }
        return "";
    }

    public void getStr(StringBuffer sb, String title, JSONObject json, String filter, String x, String type) {
        String desc = JsonUtils.getStr(json, filter);
        if (StringUtils.isNotBlank(desc)) {
            if ("PROD".equalsIgnoreCase(x)) {
                if (StringUtils.isNotBlank(desc)) {
                    sb.append(title).append(": SSP-").append(desc).append(type);
                }
            } else if ("DEST".equalsIgnoreCase(x)) {
                if ("0.0.0.0".equalsIgnoreCase(desc)) {
                    sb.append(title).append(": ").append(desc).append(type);
                    return;
                }
                if (desc.contains(",")) {
                    getStrMoreIpInfo(sb, title, json, filter, type);
                } else {
                    if (IpUtils.isInternetIP(desc)) {
                        String ipInfo = AssetUtils.getInternetIpInfo(desc);
                        if (StringUtils.isNotBlank(ipInfo)) {
                            sb.append(title).append(": ").append(desc).append(String.format("(%s)", ipInfo)).append(type);
                        } else {
                            sb.append(title).append(": ").append(desc).append(type);
                        }
                    } else {
                        String vlanInfo = AssetUtils.getVlanIp(desc);
                        if (StringUtils.isNotBlank(vlanInfo)) {
                            sb.append(title).append(": ").append(vlanInfo).append(type);
                        } else {
                            sb.append(title).append(": ").append(desc).append(type);
                        }
                    }
                }
            } else if ("SRC".equalsIgnoreCase(x)) {
                if ("0.0.0.0".equalsIgnoreCase(desc)) {
                    sb.append(title).append(": ").append(desc).append(type);
                    return;
                }
                if (desc.contains(",")) {
                    getStrMoreIpInfo(sb, title, json, filter, type);
                } else {
                    if (IpUtils.isInternetIP(desc)) {
                        String ipInfo = AssetUtils.getInternetIpInfo(desc);
                        if (StringUtils.isNotBlank(ipInfo)) {
                            sb.append(title).append(": ").append(desc).append(String.format("(%s)", ipInfo)).append(type);
                        } else {
                            sb.append(title).append(": ").append(desc).append(type);
                        }
                    } else {
                        String vlanInfo = AssetUtils.getVlanIp(desc);
                        if (StringUtils.isNotBlank(vlanInfo)) {
                            sb.append(title).append(": ").append(vlanInfo).append(type);
                        } else {
                            sb.append(title).append(": ").append(desc).append(type);
                        }
                    }
                }
            } else if ("TIME".equalsIgnoreCase(x)) {
                Date date = DateUtils.parseDateTime(desc);
                Date alarmDate = new Date(date.getTime() + 60000 * 60 * 8);
                Date cur = new Date();
                if (alarmDate.after(cur)) {
                    alarmDate = cur;
                }
                sb.append(title).append(": ").append(DateUtils.getDateTimeString1(alarmDate)).append(type);
            }
        } else {
            //处理源IP或目标ip为空的情况
            if ("PROD".equalsIgnoreCase(x)) {
                //desc = "SSP";
                //sb.append(title + ": " + desc + type);
            } else {
                if ("DEST".equalsIgnoreCase(x)) {
                    desc = "0.0.0.0";
                } else {
                    desc = "127.0.0.1";
                }
                sb.append(title).append(": ").append(desc).append(type);
            }
        }

    }

    public void getStr(StringBuffer sb, String title, JSONObject json, String filter, String type) {
        String desc = JsonUtils.getStr(json, filter);
        if (LogConstantsX.ALERT_NAME.equals(filter)) {
            if (desc.contains("日志详情为")) {
                int pos = desc.indexOf("日志详情为:");
                if (pos == -1) {
                    pos = desc.indexOf("日志详情为：");
                }
                String newStr = DataUtils.getSubString(desc, 0, pos);
                if (StringUtils.isBlank(newStr)) {
                    newStr = desc;
                }
                sb.append(title).append(": ").append(newStr).append(type);
                return;
            } else if (desc.contains("原始日志:")) {
                int pos = desc.indexOf("原始日志:{");
                String newStr = DataUtils.getSubString(desc, 0, pos);
                if (StringUtils.isBlank(newStr)) {
                    newStr = desc;
                }
                sb.append(title).append(": ").append(newStr).append(type);
                return;
            } else if (desc.contains("【详情：")) {
                int pos = desc.indexOf("【详情：");
                String newStr = DataUtils.getSubString(desc, 0, pos);
                if (StringUtils.isBlank(newStr)) {
                    newStr = desc;
                }
                sb.append(title).append(": ").append(newStr).append(type);
                return;
            } else if (desc.contains("告警详情可查阅")) {
                int pos = desc.indexOf("告警详情可查阅");
                String newStr = DataUtils.getSubString(desc, 0, pos);
                if (StringUtils.isBlank(newStr)) {
                    newStr = desc;
                }
                sb.append(title).append(": ").append(newStr).append(type);
                return;
            }
        }
        if (LogConstantsX.LOG_START_TIME.equals(filter)) {
            String newDesc = DateUtils.getFirstEndTime(desc);
            if (StringUtils.isNotBlank(newDesc)) {
                sb.append(title).append(": ").append(newDesc).append(type);
                return;
            }
        }
        if (StringUtils.isNotBlank(desc)) {
            sb.append(title).append(": ").append(desc).append(type);
        }

    }


    /*
     * 解析合并IP清单信息
     *
     * @param sbMain
     * @param title
     * @param json
     * @param filter
     * @param endType
     */
    private void getStrMoreIpInfo(StringBuffer sbMain, String title, JSONObject json, String filter, String endType) {
        String desc = JsonUtils.getStr(json, filter);
        StringBuilder sb = new StringBuilder();
        String type = ",";
        for (String ip : desc.split(",")) {
            if (StringUtils.isNotBlank(ip)) {
                if (IpUtils.isInternetIP(ip)) {
                    String ipInfo = AssetUtils.getInternetIpInfo(ip);
                    if (StringUtils.isNotBlank(ipInfo)) {
                        sb.append(ip).append(String.format("(%s)", ipInfo)).append(type);
                    } else {
                        sb.append(ip).append(type);
                    }
                } else {
                    String vlanInfo = AssetUtils.getVlanIp(ip);
                    if (StringUtils.isNotBlank(vlanInfo)) {
                        sb.append(vlanInfo).append(type);
                    } else {
                        sb.append(ip).append(type);
                    }
                }
            }
        }
        String ret = DataUtils.getSubString(sb.toString(), 0, sb.toString().length() - 1);
        sbMain.append(title).append(": ").append(ret).append(endType);
    }


    public void getStr(StringBuffer sb, String title, String desc, String type) {
        if (StringUtils.isNotBlank(desc)) {
            sb.append(title).append(": ").append(desc).append(type);
        }
    }

    public void saveMessage(String evtId, String ruleId, PolicyConfig policyConfig, SendPolicy sendPolicy, int type, String result) {
        SendMessage sendMessage = new SendMessage();
        sendMessage.setEventId(evtId);
        sendMessage.setPolicyId(sendPolicy.getId().longValue());
        sendMessage.setRuleId(ruleId);
        if (type == 0) {
            sendMessage.setSender(policyConfig.getEmailSender());
        }
        if (type == 1) {
            sendMessage.setSender(policyConfig.getRworkSender());
        }
        sendMessage.setSendTime(new Date());
        if (type == 0) {
            sendMessage.setSendType("1");
            sendMessage.setReceiver(policyConfig.getEmailReceiver());
        }
        if (type == 1) {
            sendMessage.setSendType("2");
            sendMessage.setReceiver(policyConfig.getRworkReceiver());
        }

        sendMessage.setCreateBy("system");
        sendMessage.setCreateTime(new Date());
        sendMessage.setResult(result);
        SendMessageMapper sendMessageMapper = GetSpringBean.getBean(SendMessageMapper.class);
        sendMessageMapper.insertTbSendMessage(sendMessage);
    }
}
