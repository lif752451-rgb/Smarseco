package com.crc.sync.send;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;
import com.crc.SpringbootApplication;
import com.crc.common.constants.LogConstantsX;
import com.crc.common.utils.*;
import com.crc.secface.argo.AssetUtils;
import com.crc.secface.config.SyncSecConfig;
import com.crc.secface.entity.FlowModel;
import com.crc.secface.entity.TbEventModel;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;

import java.util.Date;
import java.util.HashMap;
import java.util.concurrent.ArrayBlockingQueue;

/**
 * 告警事件推送到告警中心
 */
@Slf4j
public class DangerEventToAlarmCenter extends Thread {
    public static ArrayBlockingQueue<FlowModel> magicQueue = new ArrayBlockingQueue<>(50000);

    @Override
    public void run() {
        while (true) {
            if (magicQueue.isEmpty()) {
                MyTheadUtils.sleep(20);
            } else {
                while (!magicQueue.isEmpty()) {
                    try {
                        MyTheadUtils.sleep(20);
                        FlowModel flowData = magicQueue.poll();
                        if (SyncSecConfig.isEnable("alarm_center_send") || "T".equals(SpringbootApplication.OP_CONFIG.getAlarmCenter())) {
                            try {
                                JSONObject msg = toMsg(flowData.getFJson(), flowData.getModel(), flowData.getAlarmId());
                                log.info("DangerEventToAlarmCenter 类推送的消息格式为:{}", msg);
                                send(msg);
                            } catch (Exception e) {
                                log.error(e.getMessage(), e);
                            }
                        } else {
                            log.error("不启动alarm_center_send");
                        }
                    } catch (Exception e) {
                        log.error(e.getMessage(), e);
                    }
                }
            }
            MyTheadUtils.sleep(100);
        }

    }

    private void send(JSONObject msg) {
        String url = "https://dubhe.crc.com.cn/alert_tunnel/api/alert";
        //  String url ="http://10.200.192.13:8002/api/alert";
        String json = JSON.toJSONString(msg);
        //System.out.println("sendAlarmCenter:" + json);
        //正式环境
        String ret = HttpUtils.sendSSLPost(url, json, new HashMap<>());
        //测试环境
        //  String ret = HttpUtils.sendPost(url,json );
        log.info(url + " RET= " + ret);
    }

    /**
     * 数据为json格式，字段包含：Summary：告警标题，Notes：告警内容，Alert_type：告警类型，Event_id：告警ID，IP：
     * 告警设备IP，Priority：告警级别（目前接进来的级别有一级到四级），Source：告警来源，Assignee：受派人
     * Summary, Notes, Priority, IP, Source参数为必填参数，其它参数可填可为空
     *
     * @param json
     * @param model
     * @return
     */
    private JSONObject toMsg(JSONObject json, TbEventModel model, String alarmId) {
        JSONObject ret = new JSONObject();

        if (model != null) {
            getStr(ret, "Summary", JsonUtils.getStr(json, LogConstantsX.LOG_NAME));
            getStr(ret, "Notes", toAlarmDetail(json, model, alarmId));
            getStr(ret, "Priority", model.getEventLevelName());
        }

        String title = "【STP/OP处理】" + JsonUtils.getStr(ret, "Summary");
        ret.put("Summary", title);
        String destIp = JsonUtils.getStr(json, LogConstantsX.DEST_IP);
        if (StringUtils.isNotBlank(destIp)) {
            // String destInstance =  json.getString()
            //  getStr(ret, "IP", destIp);
            String destInstance = JsonUtils.getStr(json, LogConstantsX.DEST_IP_INSTANCE).equals("") ? destIp : JsonUtils.getStr(json, LogConstantsX.DEST_IP_INSTANCE);
            getStr(ret, "IP", destInstance);
            getStr(ret, "Source", JsonUtils.getStr(json, LogConstantsX.LOG_PRODUCT) + "-" + JsonUtils.getStr(json, LogConstantsX.SRC_IP));
        } else {
            if (StringUtils.isEmpty(JsonUtils.getStr(json, LogConstantsX.SRC_IP))) {
                getStr(ret, "IP", "127.0.0.1");
            } else {
                String srcInstance = JsonUtils.getStr(json, LogConstantsX.SRC_IP_INSTANCE).equals("") ? JsonUtils.getStr(json, LogConstantsX.SRC_IP) :
                        JsonUtils.getStr(json, LogConstantsX.SRC_IP_INSTANCE);

                getStr(ret, "IP", srcInstance);
            }
            getStr(ret, "Source", JsonUtils.getStr(json, LogConstantsX.LOG_PRODUCT));
        }
        getStr(ret, "Alert_type", "安全告警");
        getStr(ret, "Event_id", alarmId);
        getStr(ret, "Assignee", "");
        return ret;
    }


    /**
     * 转换润工作消息
     *
     * @param json
     * @return
     */
    private String toAlarmDetail(JSONObject json, TbEventModel model, String alarmId) {
        StringBuffer sb = new StringBuffer();
        getStr(sb, "告警ID", alarmId);
        if (model != null) {
            getStr(sb, "告警名称", JsonUtils.getStr(json, LogConstantsX.LOG_NAME));
            String product = "";
            if (StringUtils.isNotBlank(model.getDeviceNameStr())) {
                product = model.getDeviceNameStr();
            } else if (StringUtils.isNotBlank(model.getDeviceName())) {
                product = model.getDeviceName();
            }
            if (StringUtils.isBlank(product) || DataUtils.isNotEmpty(DataUtils.replaceOutput(product))) {
                product = JsonUtils.getStr(json, LogConstantsX.LOG_PRODUCT);
            }
            getStr(sb, "告警设备", product);
            getStr(sb, "告警级别", model.getEventLevelName());
            getStr(sb, "攻击状态", model.getAttackResultName());
        }
        getStr(sb, "源IP", json, LogConstantsX.SRC_IP, "SRC");
        getStr(sb, "源端口", json, LogConstantsX.SRC_PORT);
        getStr(sb, "目标IP", json, LogConstantsX.DEST_IP, "DEST");
        getStr(sb, "目标端口", json, LogConstantsX.DEST_PORT);
        getStr(sb, "告警时间", json, LogConstantsX.LOG_START_TIME);
        getStr(sb, "告警描述", json, LogConstantsX.ALERT_NAME);
        //getStr(sb, "解决方案", json, LogConstantsX.LOG_SOLUTION);
        getStr(sb, "发生次数", json, "times");
        //历史命令
        return sb.toString();
    }

    private void getStr(StringBuffer sb, String title, JSONObject json, String filter, String x) {
        String desc = JsonUtils.getStr(json, filter);
        if (StringUtils.isNotBlank(desc)) {
            if ("PROD".equalsIgnoreCase(x)) {
                if (StringUtils.isNotBlank(desc))
                    sb.append(title).append(": SSP-").append(desc).append("\n");
            } else if ("DEST".equalsIgnoreCase(x)) {
                if ("0.0.0.0".equalsIgnoreCase(desc)) {
                    sb.append(title).append(": ").append(desc).append("\n");
                    return;
                }
                String vlanInfo = AssetUtils.getVlanIp(desc);
                if (StringUtils.isNotBlank(vlanInfo)) {
                    sb.append(title).append(": ").append(vlanInfo).append("\n");
                } else {
                    sb.append(title).append(": ").append(desc).append("\n");
                }
            } else if ("SRC".equalsIgnoreCase(x)) {
                String vlanInfo = AssetUtils.getVlanIp(desc);
                if (StringUtils.isNotBlank(vlanInfo)) {
                    sb.append(title).append(": ").append(vlanInfo).append("\n");
                } else {
                    sb.append(title).append(": ").append(desc).append("\n");
                }
            } else if ("TIME".equalsIgnoreCase(x)) {
                Date date = DateUtils.parseDateTime(desc);
                Date alarmDate = new Date(date.getTime() + 60000 * 60 * 8);
                Date cur = new Date();
                if (alarmDate.after(cur)) {
                    alarmDate = cur;
                }
                sb.append(title).append(": ").append(DateUtils.getDateTimeString1(alarmDate)).append("\n");
            }
        } else {
            //处理源IP或目标ip为空的情况
            if ("DEST".equalsIgnoreCase(x)) {
                desc = "0.0.0.0";
            } else {
                desc = "127.0.0.1";
            }
            sb.append(title).append(": ").append(desc).append("\n");
        }

    }

    private void getStr(StringBuffer sb, String title, String desc) {
        if (StringUtils.isNotBlank(desc))
            sb.append(title).append(": ").append(desc).append("\n");

    }

    private void getStr(StringBuffer sb, String title, JSONObject json, String filter) {
        String desc = JsonUtils.getStr(json, filter);
        if (StringUtils.isNotBlank(desc))
            sb.append(title).append(": ").append(desc).append("\n");

    }

    private void getStr(JSONObject ret, JSONObject json, String filter) {
        String desc = JsonUtils.getStr(json, filter);
        if (StringUtils.isNotBlank(desc)) {
            ret.put("Summary", desc);
        }
    }

    private void getStr(JSONObject ret, String title, String val) {
        //if (StringUtils.isNotBlank(val)) {
        ret.put(title, val);
        //}
    }
}
