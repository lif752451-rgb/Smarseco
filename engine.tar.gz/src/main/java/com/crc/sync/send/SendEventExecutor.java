package com.crc.sync.send;

import com.alibaba.fastjson.JSONObject;
import com.crc.common.constants.LogConstantsX;
import com.crc.common.constants.ModelTypeEnum;
import com.crc.common.utils.DateUtils;
import com.crc.common.utils.IdGen;
import com.crc.common.utils.JsonUtils;
import com.crc.common.utils.SimpleCodeTool;
import com.crc.secface.argo.AlarmUtils;
import com.crc.secface.config.EsDataSource;
import com.crc.secface.config.GetSpringBean;
import com.crc.secface.entity.DangerEventSendModel;
import com.crc.secface.entity.RelationId;
import com.crc.secface.es.EsSingleFactory;
import com.crc.secface.mapper.CommonMapper;
import com.crc.sync.data.AlarmLogSync;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.elasticsearch.action.search.SearchRequest;
import org.elasticsearch.action.search.SearchResponse;
import org.elasticsearch.client.RequestOptions;
import org.elasticsearch.client.RestHighLevelClient;
import org.elasticsearch.index.query.BoolQueryBuilder;
import org.elasticsearch.search.SearchHit;
import org.elasticsearch.search.SearchHits;
import org.elasticsearch.search.builder.SearchSourceBuilder;

import java.sql.SQLIntegrityConstraintViolationException;
import java.util.Date;
import java.util.List;

/**
 * @author simba@onlying.cn
 * @date 2020/12/9 16:18
 */
@Slf4j
public class SendEventExecutor {
    public static void doSend(DangerEventSendModel dangerEventSend) {
        //构建event对象,插入event 表
        JSONObject messageJSON = buildMessageJson(dangerEventSend);
        if (messageJSON == null) {
            log.error("转化信息内容报错。。。。。");
            return;
        }

        //保存关联告警ID
        if (ModelTypeEnum.GUANLIAN.getValue().equalsIgnoreCase(dangerEventSend.getModel().getModelType())) {
            List<RelationId> idList = dangerEventSend.getIdList();
            if (idList != null) {
                for (RelationId ido : idList) {
                    try {
                        if ("1".equals(ido.getType())) {
                            saveEsOriLog(ido.getEsDataSource(), ido.getId());
                        } else {
                            CommonMapper commonMapper = GetSpringBean.getBean(CommonMapper.class);
                            String sql = "select * from " + ido.getTableName() + " where crc_id = " + ido.getId();
                            List<JSONObject> list = commonMapper.queryX(sql);
                            if (list.size() > 0) {
                                ido.setNewId(saveEsOriLog(list.get(0)));
                            }
                        }
                    } catch (Exception e) {
                        log.error(e.getMessage(), e);
                    }
                }
            }
        } else {
            if (ModelTypeEnum.JINGQUE.getValue().equalsIgnoreCase(dangerEventSend.getModel().getModelType())) {
                String ids = dangerEventSend.getIds();
                if (ids != null && dangerEventSend.getLogMap() != null) {
                    for (String id : ids.split(",")) {
                        if (dangerEventSend.getLogMap().containsKey(id)) {
                            JSONObject json = dangerEventSend.getLogMap().get(id);
                            if (json != null) {
                                saveEsOriLog(id, json);
                            }
                        }
                    }
                }
            }
        }

        //先发送STP
        (new DangerEventToStp(messageJSON, dangerEventSend)).start();
    }


    public static void saveEsOriLog(EsDataSource esDataSource, String id) {
        CommonMapper commonMapper = GetSpringBean.getBean(CommonMapper.class);
        String sql = "select count(1) from tb_alarm_ori_log where id = '%s'";
        try {
            if (commonMapper.getCount(String.format(sql, id)) > 0) {
                return;
            }
            SearchSourceBuilder sourceBuilder = new SearchSourceBuilder();
            AlarmLogSync sync = new AlarmLogSync();
            BoolQueryBuilder boolQuery = sync.buildQueryBuilder(DateUtils.getDateTimeString1(new Date()), id);

            sourceBuilder.query(boolQuery);
            sourceBuilder.size(1);
            SearchResponse response = null;
            String esIndex = esDataSource.getIndexRule().split("-")[0] + "-*";
            RestHighLevelClient client = null;
            try {
                SearchRequest searchRequest = new SearchRequest(esIndex);
                searchRequest.source(sourceBuilder);
                client = EsSingleFactory.getInstance().getHighLevelClientHigh(esDataSource);
                response = client.search(searchRequest, RequestOptions.DEFAULT);
                SearchHits sh = response.getHits();
                for (SearchHit searchHit : sh) {
                    try {
                        String msg = searchHit.getSourceAsString();
                        JSONObject dataJson = JsonUtils.parse(msg);
                        if (dataJson.size() > 0) {
                            String newSql = "insert into tb_alarm_ori_log(id,msg)values('%s','%s')";
                            dataJson.remove("alert_name_bak");
                            saveData(String.format(newSql, id, SimpleCodeTool.encryptBase64(dataJson.toJSONString())));
                            return;
                        }else {
                            String newSql = "insert into tb_alarm_ori_log(id,msg)values('%s','%s')";
                            saveData(String.format(newSql, id, SimpleCodeTool.encryptBase64(msg)));
                            return;
                        }

                    } catch (Exception ignored) {

                    }
                }
            } catch (Exception e) {
                log.error(e.getMessage(), e);
            } finally {
                EsSingleFactory.getInstance().close(client);
            }
        } catch (Exception e) {
            log.error("告警原始日志同步异常:{}", e.getMessage(), e);
        }
    }

    public static String saveEsOriLog(JSONObject data) {
        String id = IdGen.uuid();
        try {
            JSONObject jsonObject = data.clone();
            jsonObject.remove("alert_name_bak");
            String msg = jsonObject.toJSONString();
            String newSql = "insert into tb_alarm_ori_log(id,msg)values('%s','%s')";
            saveData(String.format(newSql, id, SimpleCodeTool.encryptBase64(msg)));
        } catch (Exception e) {
            log.error("告警原始日志同步异常:{}", e.getMessage(), e);
        }
        return id;
    }


    private static JSONObject buildMessageJson(DangerEventSendModel dangerEventSend) {
        if (dangerEventSend == null)
            return null;
        JSONObject res = new JSONObject();
        String id = IdGen.uuid();
        JSONObject job = dangerEventSend.getEventJson();
        String srcIp = JsonUtils.getStr(job, LogConstantsX.SRC_IP);
        //List<String> commandHisList = new ArrayList<>();
        res.put(LogConstantsX.LOG_ID, id);
        res.putAll(job);
        if (StringUtils.isEmpty(srcIp)) {
            //源IP为空，放弃
            return null;
        }
        String destIp = JsonUtils.getStr(job, LogConstantsX.DEST_IP);
        if (StringUtils.isEmpty(destIp) || srcIp.equalsIgnoreCase(destIp)) {
            res.put(LogConstantsX.DEST_IP, "0.0.0.0");
        }

        res.put(LogConstantsX.DEST_IP, destIp);
        String product = JsonUtils.getStr(job, LogConstantsX.LOG_PRODUCT);
        res.put(LogConstantsX.LOG_PRODUCT, product);
        String startTime = JsonUtils.getStr(job, LogConstantsX.LOG_START_TIME);
        startTime = DateUtils.UTCToCSTAndCheck(startTime);
        if (StringUtils.isBlank(startTime)) {
            startTime = DateUtils.UTCToCST(JsonUtils.getStr(job, LogConstantsX.LOG_TIME));
        }
        res.put(LogConstantsX.LOG_START_TIME, startTime);

        res.put("instance", JsonUtils.getStr(job, LogConstantsX.SRC_INSTANCE));
        res.put(LogConstantsX.ORI_EVENT_ID, JsonUtils.getStr(job, LogConstantsX.ORI_EVENT_ID));

        return res;

    }

    public static void saveEsOriLog(String id, JSONObject data) {
        CommonMapper commonMapper = GetSpringBean.getBean(CommonMapper.class);
        try {
            String sql = "select count(1) from tb_alarm_ori_log where id = '%s'";
            if (commonMapper.getCount(String.format(sql, id)) > 0) {
                return;
            }
            JSONObject jsonObject = data.clone();
            jsonObject.remove("alert_name_bak");
            String msg = jsonObject.toJSONString();
            String newSql = "insert into tb_alarm_ori_log(id,msg)values('%s','%s')";
            saveData(String.format(newSql, id, SimpleCodeTool.encryptBase64(msg)));
        } catch (Exception e) {
            log.error("告警原始日志同步异常:{}", e.getMessage(), e);
        }
    }

    /**
     * 加锁入库
     * @param sql
     */
    public synchronized static void saveData(String sql) {
        CommonMapper commonMapper = GetSpringBean.getBean(CommonMapper.class);
        try {
            commonMapper.exeSQL(sql);
        } catch (Exception ignored) {

        }
    }
}
