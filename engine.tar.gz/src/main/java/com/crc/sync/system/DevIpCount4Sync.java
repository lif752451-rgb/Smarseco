package com.crc.sync.system;

import com.alibaba.fastjson.JSONObject;
import com.crc.common.enums.DatabaseEnums;
import com.crc.common.utils.*;
import com.crc.secface.config.GetSpringBean;
import com.crc.secface.entity.TbAsset;
import com.crc.secface.mapper.CommonMapper;
import com.crc.secface.mapper.TbAssetMapper;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;

import java.util.List;

@Slf4j
public class DevIpCount4Sync extends Thread {
    @Override
    public void run() {
        while (true) {
            MyTheadUtils.sleepBySec(60 * 10);
            try {
                checkAssetHaveLog();
            } catch (Exception e) {
                log.error(e.getMessage(), e);
            }

            MyTheadUtils.sleepBySec(60 * 5);
        }
    }

    private void checkAssetHaveLog() {
        try {
            if (isHaveColumn("tb_asset", "is_exist_log")) {
                String dateStr = DateUtils.getDate(-7);
                String sql = "select ip from es_ip_count where create_date > '" + dateStr + "' group by ip";
                TbAssetMapper assetMapper = GetSpringBean.getBean(TbAssetMapper.class);
                CommonMapper commonMapper = GetSpringBean.getBean(CommonMapper.class);
                List<JSONObject> list = commonMapper.queryX(sql);
                log.info("设备IP数有：" + list.size());
                if (list.size() < 1) {
                    return;
                }
                commonMapper.exeSQL("update tb_asset set office_id = 0");
                for (JSONObject map : list) {
                    String ip = DataUtils.getString(map, "ip");
                    if (StringUtils.isNotBlank(ip)) {
                        TbAsset q = new TbAsset();
                        q.setInternalIp(ip);
                        TbAsset asset = assetMapper.selectTbAssetByIp(q);
                        if (asset != null) {
                            String newSQl = "update tb_asset set is_exist_log = '1',office_id = 1 where id = " + asset.getId();
                            commonMapper.exeSQL(newSQl);
                        }
                    }
                }
                commonMapper.exeSQL("update tb_asset set is_exist_log = '0' where office_id = '0'");
            }
        } catch (Exception e) {
            log.error(e.getMessage(), e);
        }
    }


    /**
     * 检查是否是否存在字段
     *
     * @param tableName
     * @param col
     * @return
     */
    public static boolean isHaveColumn(String tableName, String col) {
        if (VersionUtils.getDatabase() == DatabaseEnums.MYSQL.getCode()) {
            try {
                if (StringUtils.isBlank(tableName) || StringUtils.isBlank(col)) {
                    return false;
                }
                String check = "desc " + tableName + " " + col;
                CommonMapper commonMapper = GetSpringBean.getBean(CommonMapper.class);
                List<JSONObject> list = commonMapper.queryX(check);
                return list != null && list.size() >= 1;
            } catch (Exception e) {
                log.info(e.getMessage(), e);
            }
        } else {
            String sql = "SELECT * FROM USER_TAB_COLUMNS  WHERE TABLE_NAME = '" + tableName + "'";
            CommonMapper commonMapper = GetSpringBean.getBean(CommonMapper.class);
            List<JSONObject> list = commonMapper.queryX(sql);
            for (JSONObject map : list) {
                String c = JsonUtils.getStr(map, "COLUMN_NAME");
                if (col.equalsIgnoreCase(c)) {
                    return true;
                }
            }
        }
        return false;
    }
}
