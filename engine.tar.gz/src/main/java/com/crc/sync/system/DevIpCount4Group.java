package com.crc.sync.system;

import com.crc.common.constants.LogConstants;
import com.crc.common.utils.DateUtils;
import com.crc.common.utils.IpUtils;
import com.crc.common.utils.Md5Utils;
import com.crc.secface.config.ElasticsearchProperties;
import com.crc.secface.entity.IndexIpCount;
import com.crc.secface.es.EsSingleFactory;
import org.apache.commons.lang3.StringUtils;
import org.elasticsearch.action.search.SearchRequest;
import org.elasticsearch.action.search.SearchResponse;
import org.elasticsearch.client.RequestOptions;
import org.elasticsearch.client.RestHighLevelClient;
import org.elasticsearch.search.aggregations.AggregationBuilders;
import org.elasticsearch.search.aggregations.bucket.terms.ParsedStringTerms;
import org.elasticsearch.search.aggregations.bucket.terms.Terms;
import org.elasticsearch.search.aggregations.bucket.terms.TermsAggregationBuilder;
import org.elasticsearch.search.builder.SearchSourceBuilder;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.Date;
import java.util.LinkedList;
import java.util.List;


/**
 * ES按产品按每小时统计总数
 */
public class DevIpCount4Group {
    private static final Logger logger = LoggerFactory.getLogger(DevIpCount4Group.class);

    public List<IndexIpCount> analy(ElasticsearchProperties esProperties, String index) {
        try {
            //根据时间分组统计总数
            String vx = "dev_ip.keyword";
            TermsAggregationBuilder productBuilder = AggregationBuilders.terms(LogConstants.PRODUCT_TAG).field(vx).size(10000);
            SearchSourceBuilder sourceBuilder = new SearchSourceBuilder();
            sourceBuilder.aggregation(productBuilder);
            RestHighLevelClient client = null;
            try {
                client = EsSingleFactory.getInstance().getHighLevelClient(esProperties);
                SearchRequest searchRequest = new SearchRequest(index);
                searchRequest.source(sourceBuilder);
                SearchResponse response = client.search(searchRequest, RequestOptions.DEFAULT);
                if (response == null) {
                    return null;
                }
                ParsedStringTerms countName = response.getAggregations().get(LogConstants.PRODUCT_TAG);
                List<? extends Terms.Bucket> sbuckets = countName.getBuckets();
                if (sbuckets != null) {
                    List<IndexIpCount> listx = new LinkedList<>();
                    for (Terms.Bucket product : sbuckets) {
                        String pk = (String) product.getKey();
                        long total = product.getDocCount();
                        //System.out.println("key:" + pk + " = " + total);
                        IndexIpCount iic = new IndexIpCount();
                        iic.setTotal(total);
                        if (!IpUtils.isIp(pk)) {
                            if (StringUtils.isBlank(pk)) {
                                continue;
                            }
                            List<String> ipList = IpUtils.getIps(pk);
                            if (ipList.size() < 1)
                                break;
                            pk = ipList.get(0);
                        }
                        iic.setIp(pk);
                        iic.setCreateDate(DateUtils.getDateTimeString1(new Date()));
                        String str = index + pk;
                        iic.setId(Md5Utils.hash(str));
                        iic.setIndexName(index);
                        listx.add(iic);
                    }
                    return listx;
                }
                logger.info("计算完成=" + index);
            } catch (Exception e) {
                logger.error(e.getMessage(), e);
            } finally {
                EsSingleFactory.getInstance().close(client);
            }
        } catch (Exception e) {
            logger.error(e.getMessage(), e);
        }
        return null;
    }
}

