package com.crc.sync.system;

import com.alibaba.fastjson.JSONObject;
import com.crc.common.utils.DataUtils;
import com.crc.common.utils.DateUtils;
import com.crc.secface.config.GetSpringBean;
import com.crc.secface.es.ConfBuzziMySql;
import com.crc.secface.es.SqliteTool;
import com.crc.secface.mapper.CommonMapper;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;

import java.util.Date;
import java.util.List;

@Slf4j
public class CleanAlarmTmp {
    public void clean(){
        try {
            log.info("清理tmp表");
            int offset = 2;//保留数据天数
            List<JSONObject> tbList = ConfBuzziMySql.getAllTable();
            CommonMapper commonMapper = GetSpringBean.getBean(CommonMapper.class);
            for (JSONObject json : tbList) {
                String tablename = DataUtils.getStr(json, "table_name");
                if (StringUtils.isNotBlank(tablename)) {
                    if (tablename.startsWith("ssp_") || tablename.startsWith("null_")) {
                        String[] dateStrs = tablename.split("_");
                        if (dateStrs.length == 3) {
                            Date date = DateUtils.parseDate(dateStrs[2].substring(0, "230609123010".length()), "yyMMddHHmmss");
                            Date curDate = new Date();
                            Date diffDate = DateUtils.minusHoursX(curDate, offset);
                            if (date.before(diffDate)) {
                                String sql = "drop table  " + tablename;
                                log.info(sql);
                                commonMapper.exeSQL(sql);
                            }
                        }
                    }
                    if (tablename.contains("tb_ori_danger_event_tmp")) {
                        String dateStr = tablename.replace("tb_ori_danger_event_tmp", "");
                        if (StringUtils.isBlank(dateStr)) {
                            String sql = "drop table  " + tablename;
                            commonMapper.exeSQL(sql);
                        } else {
                            dateStr = dateStr.replace("_", "");
                            Date date = DateUtils.parseDate(dateStr, "yyyyMMdd");
                            Date curDate = new Date();
                            Date diffDate = DateUtils.minusDays(curDate, offset);
                            if (date.before(diffDate)) {
                                String sql = "drop table  " + tablename;
                                commonMapper.exeSQL(sql);
                            }
                        }
                    }
                }
            }
        } catch (Exception e) {
            log.error(e.getMessage(),e);
        }

        try {
            List<JSONObject> tbList = SqliteTool.getSqlController().excuteSqlAndGetData("SELECT * FROM sqlite_master WHERE type = \"table\"", stmt -> {
            });
            int offset = 2;//保留数据天数
            for (JSONObject json : tbList) {
                String tablename = DataUtils.getStr(json, "table_name");
                if (StringUtils.isNotBlank(tablename)) {
                    if (tablename.startsWith("ssp_") || tablename.startsWith("null_")) {
                        String[] dateStrs = tablename.split("_");
                        if (dateStrs.length == 3) {
                            Date date = DateUtils.parseDate(dateStrs[2].substring(0, "230609123010".length()), "yyMMddHHmmss");
                            Date curDate = new Date();
                            Date diffDate = DateUtils.minusHoursX(curDate, offset);
                            if (date.before(diffDate)) {
                                String sql = "drop table  " + tablename;
                                log.info(sql);
                                SqliteTool.getSqlController().excuteSql(sql, stmt -> {});
                            }
                        }
                    }
                }
            }
        } catch (Exception e) {
            log.error(e.getMessage(),e);
        }
    }
}
