package com.crc.sync.system;

import com.crc.common.utils.DateUtils;
import com.crc.common.utils.IpUtils;
import com.crc.common.utils.MyTheadUtils;
import com.crc.secface.argo.CreateInsert;
import com.crc.secface.config.ElasticsearchProperties;
import com.crc.secface.config.GetSpringBean;
import com.crc.secface.entity.EsData;
import com.crc.secface.entity.IndexIpCount;
import com.crc.secface.es.EsSingleFactory;
import com.crc.secface.mapper.CommonMapper;
import org.apache.commons.lang3.StringUtils;
import org.apache.http.HttpEntity;
import org.apache.http.util.EntityUtils;
import org.elasticsearch.client.Request;
import org.elasticsearch.client.Response;
import org.elasticsearch.client.RestHighLevelClient;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.LinkedList;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * ES 存储空间统计
 */
public class EsIndexStaticJob4Group extends Thread {
    ElasticsearchProperties esProperty;
    private static final Logger logger = LoggerFactory.getLogger(EsIndexStaticJob4Group.class);

    @Override
    public void run() {
        (new DevIpCount4Sync()).start();
        logger.info("集团ES 索引空间统计。。");
        esProperty = GetSpringBean.getBean(ElasticsearchProperties.class);
        while (true) {
            MyTheadUtils.sleepBySec(60 * 10);
            try {
                proc();
            } catch (Exception e) {
                logger.error(e.getMessage(), e);
            }

            MyTheadUtils.sleepBySec(60 * 60);
        }
    }

    private void proc() {
        RestHighLevelClient restHighLevelClient = EsSingleFactory.getInstance().getHighLevelClient(esProperty);
        List<EsData> dataList = new LinkedList<>();
        try {
            Request request = new Request("GET", "/_cat/indices/*_all-*?v&h=index,docs.count,store.size&bytes=m");
            Response response = restHighLevelClient.getLowLevelClient().performRequest(request);
            HttpEntity entity = response.getEntity();
            String ret = EntityUtils.toString(entity);
            //System.out.println(ret);
            String[] retArrt = ret.split("\n");
            for (String oneLine : retArrt) {
                if (!indexContainDate(oneLine)) {
                    continue;
                }
                //System.out.println(oneLine);
                oneLine = oneLine.replaceAll("\\s{1,}", " ");
                String[] dataArr = oneLine.split(" ");
                if (dataArr.length >= 3) {
                    String indexName = dataArr[0].trim();
                    if (!indexName.contains("-")) {
                        continue;
                    }
                    String count = dataArr[dataArr.length - 2].trim();
                    String size = dataArr[dataArr.length - 1].trim();
                    String day = indexName.split("-")[1].replace(".", "-");
                    dataList.add(new EsData(indexName, size, count, day));

                }
            }
        } catch (Exception e) {
            logger.error(e.getMessage(), e);
        }
        //System.out.println("dataList=" + dataList.size());
        saveData(dataList);
    }

    /**
     * 符合索引规则，并在7天范围之内
     *
     * @param indexName
     * @return
     */
    public boolean indexContainDate(String indexName) {
        Pattern pattern = Pattern.compile("[0-9]{4}[.][0-9]{1,2}[.][0-9]{1,2}");
        Matcher matcher = pattern.matcher(indexName);
        while (matcher.find()) {
            String date = matcher.group(0);
            //统计7天内的数据
            long diff = DateUtils.getInterval(date);
            return diff <= 7;
        }
        return false;
    }

    /**
     * 计算单索引设备IP日志量
     *
     * @param dataList
     */
    public void saveData(List<EsData> dataList) {
        if (dataList != null) {
            CommonMapper commonMapper = GetSpringBean.getBean(CommonMapper.class);
            try {
                for (EsData data : dataList) {
                    //System.out.println("1=" + DateUtils.getDateTimeString1(new Date()));
                    CreateInsert<EsData> dataInsert = new CreateInsert<>();
                    String sql = dataInsert.createinsert(data, "es_index_statics");
                    //System.out.println("11=" + DateUtils.getDateTimeString1(new Date()));
                    String sqlCount = "select count(1) total from es_index_statics where id = '%s'";
                    String sqlUpdate = "update es_index_statics set store_size = %s,doc_count = %s where id = '%s'";
                    if (commonMapper.getCount(String.format(sqlCount, data.getId())) > 0) {
                        commonMapper.exeSQL(String.format(sqlUpdate, data.getStoreSize(), data.getDocCount(), data.getId()));
                    } else {
                        commonMapper.exeSQL(sql);
                    }
                }
                for (EsData data : dataList) {
                    try {
                        DevIpCount4Group cia = new DevIpCount4Group();
                        List<IndexIpCount> ilist = cia.analy(esProperty, data.getId());
                        if (ilist == null)
                            continue;
                        logger.info("{}--size={}",data.getId(),ilist.size());
                        saveIpCount(ilist);
                    } catch (Exception e) {
                        logger.error(e.getMessage(), e);
                    }
                }
            } catch (Exception e) {
                logger.error(e.getMessage(), e);
            }
        } else {
            System.err.println("读取DbConfig错误！");
        }
    }

    /**
     * 计算单索引设备IP日志量
     *
     * @param list
     */
    private void saveIpCount(List<IndexIpCount> list) {
        if (list != null) {
            CommonMapper commonMapper = GetSpringBean.getBean(CommonMapper.class);
            try {
                for (IndexIpCount data : list) {
                    if (!IpUtils.isIp(data.getIp()) && StringUtils.isNotBlank(data.getIp())) {
                        List<String> ipList = IpUtils.getIps(data.getIp());
                        if (ipList.size() < 1) {
                            break;
                        }
                        data.setIp(ipList.get(0));
                    }
                    CreateInsert<IndexIpCount> dataInsert = new CreateInsert<>();
                    String sql = dataInsert.createinsert(data, "es_ip_count");

                    String sqlCount = "select count(1) total from es_ip_count where id = '%s'";
                    String sqlUpdate = "update es_ip_count set total = %d where id = '%s'";
                    if (commonMapper.getCount(String.format(sqlCount, data.getId())) > 0) {
                        commonMapper.exeSQL(String.format(sqlUpdate, data.getTotal(), data.getId()));
                    } else {
                        commonMapper.exeSQL(sql);
                    }
                }
            } catch (Exception e) {
                logger.error(e.getMessage(), e);
            }
        } else {
            System.err.println("读取DbConfig错误！");
        }
    }
}
