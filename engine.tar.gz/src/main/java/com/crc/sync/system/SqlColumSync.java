package com.crc.sync.system;


import com.alibaba.fastjson.JSONObject;
import com.crc.common.enums.DatabaseEnums;
import com.crc.common.utils.JsonUtils;
import com.crc.common.utils.VersionUtils;
import com.crc.secface.config.GetSpringBean;
import com.crc.secface.es.ConfBuzziMySql;
import com.crc.secface.mapper.CommonMapper;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;

import java.util.List;

/**
 * 为兼容历史版本，创建必要的字段
 */
@Slf4j
public class SqlColumSync {
    public void sync() {
        log.info("初始化增量表和字段开始");
        if (VersionUtils.getDatabase() != DatabaseEnums.MYSQL.getCode()) {
            log.info("只支持 MYSQL 动态脚本执行");
            return;
        }
//        //端口表增加监控进程名称
        String sql = "desc tb_event whitelist_id";
        String addSql = "alter table tb_event add column whitelist_id varchar(255)";
        addCol(sql, addSql,"tb_event");

//        //端口表增加监控进程名称
        sql = "desc tb_event alarm_type";
        addSql = "alter table tb_event add column alarm_type varchar(50)";
        addCol(sql, addSql,"tb_event");

        //竹云同步缓存表

        String tableName = "tb_alarm_ref_orilog";
        String createTable = "CREATE TABLE tb_alarm_ref_orilog (\n" +
                "  id int(11) unsigned NOT NULL AUTO_INCREMENT,\n" +
                "  ori_ids text COMMENT '原始日志ID（多个）',\n" +
                "  alarm_id varchar(32) DEFAULT NULL COMMENT '告警ID',\n" +
                "  create_time timestamp NULL DEFAULT NULL COMMENT '创建时间',\n" +
                "  index_name varchar(64) DEFAULT NULL,\n" +
                "  PRIMARY KEY (id)\n" +
                ") ENGINE=InnoDB AUTO_INCREMENT=225 DEFAULT CHARSET=utf8 COMMENT='告警关联原始日志表'";
        addTable(tableName, createTable);


        sql = "desc tb_alarm_ref_orilog status";
        addSql = "alter table tb_alarm_ref_orilog add column status int(11)";
        addCol(sql, addSql,"tb_alarm_ref_orilog");

        tableName = "tb_danger_event_ori_tmp";
        createTable = "CREATE TABLE tb_danger_event_ori_tmp (\n" +
                "  id bigint(16) unsigned NOT NULL AUTO_INCREMENT,\n" +
                "  type varchar(32) DEFAULT NULL COMMENT 'IP',\n" +
                "  model_id varchar(32) DEFAULT NULL COMMENT '模型ID',\n" +
                "  create_time timestamp NULL DEFAULT NULL COMMENT '创建时间',\n" +
                "  ip varchar(1024) DEFAULT NULL COMMENT '攻击IP',\n" +
                "  PRIMARY KEY (id),\n" +
                "  KEY type (type),\n" +
                "  KEY model_id (model_id),\n" +
                "  KEY create_time (create_time),\n" +
                "  KEY ip (ip)\n" +
                ") ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='告警时间记录表'";
        addTable(tableName, createTable);


        tableName = "tb_alarm_ori_log";
        createTable = "CREATE TABLE tb_alarm_ori_log (\n" +
                "  id varchar(32) NOT NULL DEFAULT '' COMMENT '日志ID',\n" +
                "  msg longtext,\n" +
                "  PRIMARY KEY (id)\n" +
                ") ENGINE=InnoDB DEFAULT CHARSET=utf8";
        addTable(tableName, createTable);

        sql = "desc tb_alarm_ori_log alarm_id";
        addSql = "alter table tb_alarm_ori_log add column alarm_id varchar(50)";
        addCol(sql, addSql,"tb_alarm_ori_log");

        sql = "desc tb_ori_danger_event model_id";
        addSql = "alter table tb_ori_danger_event add column model_id varchar(50)";
        addCol(sql, addSql,"tb_ori_danger_event");

        sql = "desc tb_alarm_ori_log create_time";
        addSql = "alter table tb_alarm_ori_log add column create_time  timestamp  default now()";
        addCol(sql, addSql,"tb_alarm_ori_log");

        sql = "desc tb_ori_danger_event event_name";
        String modSql = "alter table tb_ori_danger_event modify column event_name varchar(1024)";
        modCol(sql, modSql,"varchar(1024)");

        sql = "desc tb_alarm_ori_log data_source";
        addSql = "alter table tb_alarm_ori_log add column data_source varchar(50)";
        addCol(sql, addSql,"tb_alarm_ori_log");

        sql = "desc tb_alarm_ref_orilog data_source";
        addSql = "alter table tb_alarm_ref_orilog add column data_source varchar(50)";
        addCol(sql, addSql,"tb_alarm_ref_orilog");

        sql = "desc tb_alarm_ref_orilog model_id";
        addSql = "alter table  tb_alarm_ref_orilog add column model_id varchar(50)";
        addCol(sql, addSql,"tb_alarm_ref_orilog");

        sql = "desc tb_asset alarm_id";
        addSql = "alter table tb_asset add column alarm_id varchar(50)";
        addCol(sql, addSql,"tb_asset");

        sql = "desc tb_asset rule_base";
        addSql = "alter table tb_asset add column rule_base varchar(50)";
        addCol(sql, addSql,"tb_asset");

        sql = "desc tb_asset rule_base_ip";
        addSql = "alter table tb_asset add column rule_base_ip varchar(50)";
        addCol(sql, addSql,"tb_asset");

        sql = "show index from tb_alarm_ori_log where key_name = 'alarm_id'";
        String addIndexSql = "create index alarm_id on tb_alarm_ori_log(alarm_id)";
        addIndex(sql, addIndexSql,"tb_alarm_ori_log");

        sql = "show index from tb_internet_publish_app where key_name = 'ip'";
        addIndexSql = "create index ip on tb_internet_publish_app(ip)";
        addIndex(sql, addIndexSql,"tb_internet_publish_app");//asset_id
        sql = "show index from tb_internet_publish_app where key_name = 'asset_id'";
        addIndexSql = "create index asset_id on tb_internet_publish_app(asset_id)";
        addIndex(sql, addIndexSql,"tb_internet_publish_app");

        sql = "show index from tb_internet_publish_app where key_name = 'alarm_code'";
        addIndexSql = "create index alarm_code on tb_internet_publish_app(alarm_code)";
        addIndex(sql, addIndexSql,"tb_internet_publish_app");

        sql = "show index from tb_internet_publish_app where key_name = 'create_time'";
        addIndexSql = "create index create_time on tb_internet_publish_app(create_time)";
        addIndex(sql, addIndexSql,"tb_internet_publish_app");
        log.info("初始化增量表和字段结束");
    }


    private void addIndex(String check, String addIndex,String tableName) {
        CommonMapper commonMapper = GetSpringBean.getBean(CommonMapper.class);
        try {
            if (ConfBuzziMySql.existTable(tableName) != 1) {
                return; //table not exist
            }
            List<JSONObject> list = commonMapper.queryX(check);
            if (list == null || list.size() < 1) {
                commonMapper.exeSQL(addIndex);
                log.info("add Table index Success");
            }
        } catch (Exception e) {
            log.info(e.getMessage(), e);
        }
    }

    private void modCol(String check,String modSql,String type) {
        CommonMapper commonMapper = GetSpringBean.getBean(CommonMapper.class);
        try {
            List<JSONObject> list = commonMapper.queryX(check);
            if (list != null && list.size() > 0) {
                if (JsonUtils.equalVal(list.get(0), "Type", type)) {
                    log.info("modified now!");
                    return;
                }
                commonMapper.exeSQL(modSql);
                log.info("modify Column Success=" + modSql);
            }
        } catch (Exception e) {
            log.info(e.getMessage(), e);
        }
    }

    private void addTable(String tableName, String addSql) {
        CommonMapper commonMapper = GetSpringBean.getBean(CommonMapper.class);
        try {
            if (ConfBuzziMySql.existTable(tableName) != 1) {
                commonMapper.exeSQL(addSql);
                log.info("add Table Success=" + tableName);
            }
        } catch (Exception e) {
            log.info(e.getMessage(), e);
        }
    }

    private void addCol(String check, String addSql,String tableName) {
        try {
            if (ConfBuzziMySql.existTable(tableName) != 1) {
                return; //table not exist
            }
            CommonMapper commonMapper = GetSpringBean.getBean(CommonMapper.class);
            List<JSONObject> list = commonMapper.queryX(check);
            if (list == null || list.size() < 1) {
                commonMapper.exeSQL(addSql);
                log.info("add Column Success=" + addSql);
            }
        } catch (Exception e) {
            log.info(e.getMessage(), e);
        }
    }

    /**
     * 检查是否是否存在字段
     * @param tableName
     * @param col
     * @return
     */
    public static boolean isHaveColumn(String tableName, String col) {
        try {
            CommonMapper commonMapper = GetSpringBean.getBean(CommonMapper.class);
            if (StringUtils.isBlank(tableName) || StringUtils.isBlank(col)) {
                return false;
            }
            String check = "desc " + tableName + " " + col;
            List<JSONObject> list = commonMapper.queryX(check);
            return list != null && list.size() >= 1;
        } catch (Exception e) {
            log.info(e.getMessage(), e);
        }
        return false;
    }
}
