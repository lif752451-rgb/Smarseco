package com.crc.sync.net;

import com.crc.common.utils.DataUtils;
import com.crc.common.utils.IpUtils;
import com.crc.secface.entity.TbAssetSegement;
import com.googlecode.ipv6.IPv6Network;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;

import java.math.BigInteger;
import java.util.List;
import java.util.concurrent.ConcurrentHashMap;
import java.util.stream.Collectors;

/*
 * 集团网段加载功能
 */
@Slf4j
public class NewSegmentLoad {
    private static final ConcurrentHashMap<String, List<TbAssetSegement>> ipSegMap = new ConcurrentHashMap<>();
    public static  boolean FILTER_SEGMENT_FLAG = false;//是否只认网段 IP 范围数据

    public static void setAllSegment(List<TbAssetSegement> segementList) {
        if (segementList != null) {
            ipSegMap.put("seg", segementList);
        }
    }

    public static List<TbAssetSegement> getAllSegment() {
        return ipSegMap.get("seg");
    }

    /*
      获取 IP 命中的最新网段
     */
    public static TbAssetSegement getIPSegmentByHalf(String ip) {
        List<TbAssetSegement> allSegment = getAllSegment();
        try {
            if (allSegment == null) {
                return null;
            }
            List<TbAssetSegement> list = allSegment.stream().filter(tbSegementInfoEvery -> {
                String segmentStr = tbSegementInfoEvery.getSegment();
                if (StringUtils.isEmpty(segmentStr)) {
                    return false;
                }
                //是否属于该网段
                return isBelongThisSegment(segmentStr, ip);
            }).collect(Collectors.toList());
            if (!list.isEmpty()) {
                return list.get(0);
            }
        } catch (Exception e) {
            log.error(e.getMessage(), e);
        }
        return null;
    }

    public static boolean getIPByHalf(List<String> ipSetList, String ip) {
        return isBelongThisSegment(String.join("\n", ipSetList), ip);
    }

    public static boolean isBelongThisSegment(String segmentStr, String targetIpStr) {
        if (StringUtils.isEmpty(segmentStr) || StringUtils.isEmpty(targetIpStr)) {
            return false;
        }
        try {
            BigInteger ip2long = IpUtils.getIp2long(targetIpStr.trim());
            String[] ipList = IpUtils.getIpSegment(segmentStr);
            for (String cidr : ipList) {
                BigInteger []rets = IpUtils.getIpStartAndEnd(cidr);
                if (rets == null || rets.length != 2) {
                    continue;
                }
                BigInteger startIp2long = rets[0];
                BigInteger endIp2long = rets[1];
                if (!DataUtils.bigTo0(startIp2long) || !DataUtils.bigTo0(endIp2long)) {
                    continue;
                }
                if (DataUtils.isIpInSegment(startIp2long,ip2long,endIp2long)) {
                    return true;
                }
            }
        } catch (Exception e) {
            log.error(e.getMessage(), e);
        }
        return false;
    }
}
