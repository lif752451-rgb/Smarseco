package com.crc.sync.net;

import com.crc.common.utils.StringUtils;

import java.util.concurrent.ConcurrentHashMap;

public class DataCenterLoad {
    public static final ConcurrentHashMap<String, String> nameMap = new ConcurrentHashMap<>();
    static {
        nameMap.put("后门", "1");
        nameMap.put("勒索", "1");
        nameMap.put("暴力破解", "1");
    }

    public static boolean isNeedToSendDataCenter(String logName) {
        if (StringUtils.isBlank(logName)) {
            return false;
        }
        for (String key : nameMap.keySet()) {
            if (logName.contains(key)) {
                return true;
            }
        }
        return false;
    }

}
