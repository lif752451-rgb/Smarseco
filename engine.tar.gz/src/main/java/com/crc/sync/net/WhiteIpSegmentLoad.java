package com.crc.sync.net;

import com.crc.common.utils.DictUtil;
import com.crc.secface.entity.SysDictData;
import com.crc.secface.entity.TbAssetSegement;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;

import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.ConcurrentHashMap;
import java.util.stream.Collectors;

@Slf4j
public class WhiteIpSegmentLoad {
    private static final ConcurrentHashMap<String, List<TbAssetSegement>> ipSegMap = new ConcurrentHashMap<>();
    public static void setAllSegment(List<TbAssetSegement> segementList) {
        if (segementList != null) {
            ipSegMap.put("seg", segementList);
        }
    }

    public static List<TbAssetSegement> getAllSegment() {
        if (ipSegMap.get("seg") == null) {
            return new ArrayList<>();
        }
        return ipSegMap.get("seg");
    }


    public static boolean getIPByHalf(String ip) {
        TbAssetSegement segment = getIPSegmentByHalf(ip);
        return segment != null;
    }
    /*
      获取 IP 命中的最新网段
     */
    public static TbAssetSegement getIPSegmentByHalf(String ip) {
        List<TbAssetSegement> allSegment = getAllSegment();
        try {
            if (allSegment == null) {
                return null;
            }
            List<TbAssetSegement> list = allSegment.stream().filter(tbSegementInfoEvery -> {
                String segmentStr = tbSegementInfoEvery.getSegment();
                if (StringUtils.isEmpty(segmentStr)) {
                    return false;
                }
                //是否属于该网段
                return NewSegmentLoad.isBelongThisSegment(segmentStr, ip);
            }).collect(Collectors.toList());
            if (!list.isEmpty()) {
                return list.get(0);
            }
        } catch (Exception e) {
            log.error(e.getMessage(), e);
        }
        return null;
    }


    /**
     * 同步解析规则
     */
    public void syncAll() {
        List<TbAssetSegement> segList = new ArrayList<>();
        try {
            List<SysDictData> blockWhiteDictList = DictUtil.getDict("block_white_list");
            for (SysDictData dict : blockWhiteDictList) {
                String dmz = dict.getRemark();
                /*
                 * 如有指定topic就使用指定topic
                 */
                if (StringUtils.isNotBlank(dmz)) {
                    try {
                        TbAssetSegement segement = new TbAssetSegement();
                        segement.setSegment(dmz);
                        segList.add(segement);
                    } catch (Exception e) {
                        log.error(e.getMessage(), e);
                    }
                }
            }
            setAllSegment(segList);
            System.out.printf("2023成功加载封堵白名单网段信息数：%d\n", segList.size());
        } catch (Exception e) {
            log.error(e.getMessage(), e);
        }
    }
}
