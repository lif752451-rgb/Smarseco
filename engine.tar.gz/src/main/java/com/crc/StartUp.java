package com.crc;

import com.crc.common.utils.MyTheadUtils;
import com.crc.sync.ai.EventAiSync;
import com.crc.sync.ai.ManualAlarmAiSync;
import com.crc.sync.data.*;
import com.crc.sync.send.*;
import com.crc.sync.system.EsIndexStaticJob4Group;
import com.crc.sync.system.SqlColumSync;

public class StartUp {
    public static void start() {
        try {
            /**
             * 同步网段信息
             */
            SqlColumSync columSync = new SqlColumSync();
            columSync.sync();
            MyTheadUtils.sleepBySec(1);
            /**
             * 同步告警策略
             */
            (new SendPolicySync()).start();
            (new AlarmLogSync()).start();
            (new BlockIpSync()).start();
            /**
             * 版本2的告警推送
             */
            (new SendToFlowV2()).start();

            (new SendToFightFlow()).start();
            (new TerminalSyncToDb()).start();

            /**
             * 飞书告警推送
             */
            (new SendToRwork()).start();
            (new AlarmAssetSyncToDb()).start();
            /**
             * 告警数据入库到互联网发布模块
             */
            (new SendToScpInternetPublishApp()).start();
            (new AlarmDataFixSync()).start();
            if ("T".equals(SpringbootApplication.OP_CONFIG.getAiCheck())) {
                (new ManualAlarmAiSync()).start();
                (new EventAiSync()).start();
            }

            //告警中心
            DangerEventToAlarmCenter xx = new DangerEventToAlarmCenter();
            xx.start();
            (new EsIndexStaticJob4Group()).start();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
