package com.crc.rwork;

import com.alibaba.fastjson.JSONObject;
import com.crc.secface.entity.TimeModel;
import org.apache.commons.lang3.StringUtils;
import org.apache.http.HttpEntity;
import org.apache.http.client.config.RequestConfig;
import org.apache.http.client.methods.CloseableHttpResponse;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.entity.StringEntity;
import org.apache.http.impl.client.CloseableHttpClient;
import org.apache.http.util.EntityUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.HashMap;
import java.util.Map;

public class KeyThread extends Thread {
    private static TimeModel rworkTimeKey;
    private static boolean SINGLE_START_FLAG = false;
    private static long GET_KEY_PERIOD = 1000 * 60 * 30L;
    private static Logger log = LoggerFactory.getLogger(KeyThread.class);

    public KeyThread() {
        if (rworkTimeKey == null) {
            rworkTimeKey = new TimeModel();
        }
    }

    public static String getToken() {
        KeyThread keyThread = new KeyThread();
        try {
            if (StringUtils.isBlank(rworkTimeKey.getKey())) {
                String token = keyThread.getRworkToken();
                rworkTimeKey.setKey(token);
                rworkTimeKey.setTimestamp(System.currentTimeMillis());
                KeyThread.startX();
                return token;
            } else {
                return rworkTimeKey.getKey();
            }
        } catch (Exception e) {
            log.error(e.getMessage(), e);
        }
        return "";
    }

    public static void startX() {
        if (!SINGLE_START_FLAG) {
            KeyThread keyThread = new KeyThread();
            keyThread.start();
        } else {
            SINGLE_START_FLAG = true;
        }
    }

    @Override
    public void run() {
        while (true) {
            try {
                long curTime = System.currentTimeMillis();
                long diff = curTime - rworkTimeKey.getTimestamp();
                if (diff > GET_KEY_PERIOD) {
                    rworkTimeKey.setKey(getRworkToken());
                    rworkTimeKey.setTimestamp(System.currentTimeMillis());
                }

                try {
                    Thread.sleep(60 * 1000L);
                } catch (Exception e) {
                    log.error(e.getMessage(), e);
                }
            } catch (Exception e) {
                log.error(e.getMessage(), e);
            }
        }
    }

    /**
     * 获取token
     */
    public String getRworkToken() {
        String Token = "";
        Map<String, String> parm = new HashMap<String, String>();
        parm.put("Api_ID", "crc.rgz.app.lark.gettoken");// UAT环境crc.rgz.lark0sit.lark.gettoken
        parm.put("Api_Version", "1.0");
        parm.put("App_Sub_ID", RworkSend.APP_SUB_ID);
        parm.put("App_Token", RworkSend.APP_TOKEN);
        parm.put("Partner_ID", RworkSend.PARTNER_ID);
        parm.put("Sign", "NO_SIGN");
        parm.put("Sys_ID", RworkSend.SYS_ID);
        parm.put("Time_Stamp", RworkSend.getTime());
        parm.put("User_Token", "");
        CloseableHttpClient httpClient = null;
        CloseableHttpResponse response = null;
        try {
            //获取token
            httpClient = RworkSend.createAcceptSelfSignedCertificateClient();
            HttpPost HTTPRequest = new HttpPost(RworkSend.URL + "/ssdp/cls/rf/?ssdp=" + RworkSend.getBase64(parm));
            HTTPRequest.setHeader("Content-Type", "application/json");
            HTTPRequest.setEntity(new StringEntity("{\"app_id\":\"" + RworkSend.APP_ID + "\",\"app_secret\":\"" + RworkSend.APP_SECRET + "\"}"));
            // 设置连接超时时间2秒
            RequestConfig requestConfig = RequestConfig.custom().setSocketTimeout(5000)
                    .setConnectTimeout(5000)
                    .build();
            HTTPRequest.setConfig(requestConfig);
            response = httpClient.execute(HTTPRequest);
            int code = response.getStatusLine().getStatusCode();
            HttpEntity entry = response.getEntity();
            String result = EntityUtils.toString(entry);//获取返回内容
            if (code == 200 && JSONObject.isValidObject(result)) {
                JSONObject data = JSONObject.parseObject(result);
                if (data.containsKey("tenant_access_token")) {
                    Token = data.getString("tenant_access_token");
                } else {
                    log.error("获取润工作token失败X");
                }
            } else {
                log.error("获取润工作token失败Y");
            }
            log.warn("获取润工作token=" + Token);
            return Token;
        } catch (Exception e) {
            log.error(e.getMessage(), e);
        } finally {
            try {
                if (httpClient != null) {
                    httpClient.close();
                }
            } catch (Exception e) {
                log.error(e.getMessage(), e);
            }

            try {
                if (response != null) {
                    response.close();
                }
            } catch (Exception e) {
                log.error(e.getMessage(), e);
            }

        }
        return "";
    }

}
