package com.crc.rwork;

import com.alibaba.fastjson.JSONObject;
import com.crc.common.utils.HttpUtils;
import com.crc.common.utils.StringUtils;
import com.crc.secface.entry.SmsModel;
import com.google.common.collect.Lists;
import lombok.extern.slf4j.Slf4j;

import java.util.List;
import java.util.concurrent.ConcurrentHashMap;

@Slf4j
public class SmsSend extends Thread {
    public static ConcurrentHashMap<String, SmsModel> smsMap = new ConcurrentHashMap<>();
    /*
    curl --location --request POST 'https://api-msct.crcloud.com/api/mcservices/sms/multisender' \
--header 's-crc-stage: PRD' \
--header 's-crc-token: 1e4c359131a94c9195651950cc6da857' \
--header 's-crc-api-id: crc.jvku.MultiSender' \
--header 's-crc-app-id: 2240' \
--header 'Content-Type: application/json' \
--data-raw '{
    "submiterName": "chenwei849",
    "submiter": "780654006956605440",
    "tenantId": "321163903681884160",
    "nationCode": "86",
    "phoneNumbers": [{"phoneNumber":"13800000000"},{"phoneNumber":"18600000000"}],
    "appId": "2240",
    "signCode": "MT_S_0_resolink",
    "templateCode": "CLY_T_0_NET00001_780654006956605440",
    "msg_tplparams2": {
        "sms_content": "test"
    }
}'
     */

    public String msg;
    public List<String> phoneList;

    public SmsSend(List<String> phoneList, String msg) {
        this.phoneList = phoneList;
        this.msg = msg;
    }

    public void run() {
        smsMap.forEach((k, v) -> {
            try {
                JSONObject header = new JSONObject();
                header.put("s-crc-stage", v.getStage());
                header.put("s-crc-token", v.getToken());
                header.put("s-crc-api-id", v.getApiId());
                header.put("s-crc-app-id", v.getAppId());

                JSONObject body = new JSONObject();
                body.put("submiterName", v.getSubmiterName());
                body.put("submiter", v.getSubmiter());
                body.put("tenantId", v.getTenantId());
                body.put("nationCode", v.getNationCode());
                body.put("signCode", v.getSignCode());
                body.put("appId", v.getAppId());
                body.put("templateCode", v.getTemplateCode());
                List<JSONObject> phoneNumbers = Lists.newArrayList();
                for (String numb : phoneList) {
                    JSONObject phoneNumber = new JSONObject();
                    phoneNumber.put("phoneNumber", numb);
                    phoneNumbers.add(phoneNumber);
                }
                body.put("phoneNumbers", phoneNumbers);
                JSONObject msgText = new JSONObject();
                body.put("msg_tplparams2", msgText);
                msgText.put("sms_content",msg);

                HttpUtils.sendPost("https://api-msct.crcloud.com/api/mcservices/sms/multisender", body.toJSONString(), header);
            } catch (Exception e) {
                log.error(e.getMessage(),e);
            }
        });

    }

    /**
     * 批量发送短信
     *
     * @param phoneList 手机号码
     * @param msg       消息
     */
    public static void batchSend(List<String> phoneList, String msg) {
        if (StringUtils.isNotBlank(msg) && phoneList != null && phoneList.size() > 0) {
            (new SmsSend(phoneList,msg)).start();
        }
    }
}
