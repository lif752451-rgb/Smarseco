linux启动方法：
java -jar -Xms1024m -Xmx2048m -XX:PermSize=456M -XX:MaxPermSize=712M -Dloader.path=lib out-crc-company-engine-1.0.0.jar --spring.config.location=config/ --logging.config=config/log4j2.xml

