java -Xms2024m -Xmx4536m -jar secface-1.0.jar  --logging.config=./config/log4j2.xml  >> /dev/null 2>&1 &
