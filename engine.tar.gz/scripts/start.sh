#!/bin/bash

cd /app/smartseco/back/engine
nohup java -XX:+UseG1GC -Xms2048m -Xmx2048m -Dloader.path=/app/smartseco/back/engine/lib -jar /app/smartseco/back/engine/out-engine-1.0.0.jar --spring.config.location=/app/smartseco/back/engine/config/ --logging.config=/app/smartseco/back/engine/config/log4j2.xml &