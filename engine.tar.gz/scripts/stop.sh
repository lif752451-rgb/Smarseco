#!/bin/bash

ps -ef | grep /app/smartseco/back/engine/out-engine-1.0.0.jar | grep -v grep | awk '{print $2}' | xargs kill -9